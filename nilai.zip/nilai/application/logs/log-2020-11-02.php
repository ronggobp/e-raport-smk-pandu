<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-02 01:27:51 --> Config Class Initialized
INFO - 2020-11-02 01:27:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 01:27:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 01:27:51 --> Utf8 Class Initialized
INFO - 2020-11-02 01:27:51 --> URI Class Initialized
DEBUG - 2020-11-02 01:27:51 --> No URI present. Default controller set.
INFO - 2020-11-02 01:27:51 --> Router Class Initialized
INFO - 2020-11-02 01:27:51 --> Output Class Initialized
INFO - 2020-11-02 01:27:51 --> Security Class Initialized
DEBUG - 2020-11-02 01:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 01:27:51 --> Input Class Initialized
INFO - 2020-11-02 01:27:51 --> Language Class Initialized
INFO - 2020-11-02 01:27:51 --> Language Class Initialized
INFO - 2020-11-02 01:27:51 --> Config Class Initialized
INFO - 2020-11-02 01:27:51 --> Loader Class Initialized
INFO - 2020-11-02 01:27:51 --> Helper loaded: url_helper
INFO - 2020-11-02 01:27:51 --> Helper loaded: file_helper
INFO - 2020-11-02 01:27:51 --> Helper loaded: form_helper
INFO - 2020-11-02 01:27:51 --> Helper loaded: my_helper
INFO - 2020-11-02 01:27:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 01:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 01:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 01:27:51 --> Controller Class Initialized
INFO - 2020-11-02 01:27:51 --> Config Class Initialized
INFO - 2020-11-02 01:27:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 01:27:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 01:27:51 --> Utf8 Class Initialized
INFO - 2020-11-02 01:27:51 --> URI Class Initialized
INFO - 2020-11-02 01:27:51 --> Router Class Initialized
INFO - 2020-11-02 01:27:51 --> Output Class Initialized
INFO - 2020-11-02 01:27:51 --> Security Class Initialized
DEBUG - 2020-11-02 01:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 01:27:51 --> Input Class Initialized
INFO - 2020-11-02 01:27:51 --> Language Class Initialized
INFO - 2020-11-02 01:27:51 --> Language Class Initialized
INFO - 2020-11-02 01:27:51 --> Config Class Initialized
INFO - 2020-11-02 01:27:51 --> Loader Class Initialized
INFO - 2020-11-02 01:27:51 --> Helper loaded: url_helper
INFO - 2020-11-02 01:27:51 --> Helper loaded: file_helper
INFO - 2020-11-02 01:27:51 --> Helper loaded: form_helper
INFO - 2020-11-02 01:27:51 --> Helper loaded: my_helper
INFO - 2020-11-02 01:27:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 01:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 01:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 01:27:51 --> Controller Class Initialized
DEBUG - 2020-11-02 01:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 01:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 01:27:51 --> Final output sent to browser
DEBUG - 2020-11-02 01:27:51 --> Total execution time: 0.1944
INFO - 2020-11-02 01:28:03 --> Config Class Initialized
INFO - 2020-11-02 01:28:03 --> Hooks Class Initialized
DEBUG - 2020-11-02 01:28:03 --> UTF-8 Support Enabled
INFO - 2020-11-02 01:28:03 --> Utf8 Class Initialized
INFO - 2020-11-02 01:28:03 --> URI Class Initialized
INFO - 2020-11-02 01:28:03 --> Router Class Initialized
INFO - 2020-11-02 01:28:03 --> Output Class Initialized
INFO - 2020-11-02 01:28:03 --> Security Class Initialized
DEBUG - 2020-11-02 01:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 01:28:03 --> Input Class Initialized
INFO - 2020-11-02 01:28:03 --> Language Class Initialized
INFO - 2020-11-02 01:28:03 --> Language Class Initialized
INFO - 2020-11-02 01:28:03 --> Config Class Initialized
INFO - 2020-11-02 01:28:03 --> Loader Class Initialized
INFO - 2020-11-02 01:28:03 --> Helper loaded: url_helper
INFO - 2020-11-02 01:28:03 --> Helper loaded: file_helper
INFO - 2020-11-02 01:28:03 --> Helper loaded: form_helper
INFO - 2020-11-02 01:28:03 --> Helper loaded: my_helper
INFO - 2020-11-02 01:28:03 --> Database Driver Class Initialized
DEBUG - 2020-11-02 01:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 01:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 01:28:03 --> Controller Class Initialized
INFO - 2020-11-02 01:28:03 --> Helper loaded: cookie_helper
INFO - 2020-11-02 01:28:03 --> Final output sent to browser
DEBUG - 2020-11-02 01:28:03 --> Total execution time: 0.2672
INFO - 2020-11-02 01:28:04 --> Config Class Initialized
INFO - 2020-11-02 01:28:04 --> Hooks Class Initialized
DEBUG - 2020-11-02 01:28:04 --> UTF-8 Support Enabled
INFO - 2020-11-02 01:28:04 --> Utf8 Class Initialized
INFO - 2020-11-02 01:28:04 --> URI Class Initialized
INFO - 2020-11-02 01:28:04 --> Router Class Initialized
INFO - 2020-11-02 01:28:04 --> Output Class Initialized
INFO - 2020-11-02 01:28:04 --> Security Class Initialized
DEBUG - 2020-11-02 01:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 01:28:05 --> Input Class Initialized
INFO - 2020-11-02 01:28:05 --> Language Class Initialized
INFO - 2020-11-02 01:28:05 --> Language Class Initialized
INFO - 2020-11-02 01:28:05 --> Config Class Initialized
INFO - 2020-11-02 01:28:05 --> Loader Class Initialized
INFO - 2020-11-02 01:28:05 --> Helper loaded: url_helper
INFO - 2020-11-02 01:28:05 --> Helper loaded: file_helper
INFO - 2020-11-02 01:28:05 --> Helper loaded: form_helper
INFO - 2020-11-02 01:28:05 --> Helper loaded: my_helper
INFO - 2020-11-02 01:28:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 01:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 01:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 01:28:05 --> Controller Class Initialized
DEBUG - 2020-11-02 01:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 01:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 01:28:05 --> Final output sent to browser
DEBUG - 2020-11-02 01:28:05 --> Total execution time: 0.4732
INFO - 2020-11-02 01:54:15 --> Config Class Initialized
INFO - 2020-11-02 01:54:15 --> Hooks Class Initialized
DEBUG - 2020-11-02 01:54:15 --> UTF-8 Support Enabled
INFO - 2020-11-02 01:54:15 --> Utf8 Class Initialized
INFO - 2020-11-02 01:54:15 --> URI Class Initialized
INFO - 2020-11-02 01:54:15 --> Router Class Initialized
INFO - 2020-11-02 01:54:15 --> Output Class Initialized
INFO - 2020-11-02 01:54:15 --> Security Class Initialized
DEBUG - 2020-11-02 01:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 01:54:15 --> Input Class Initialized
INFO - 2020-11-02 01:54:15 --> Language Class Initialized
INFO - 2020-11-02 01:54:15 --> Language Class Initialized
INFO - 2020-11-02 01:54:15 --> Config Class Initialized
INFO - 2020-11-02 01:54:15 --> Loader Class Initialized
INFO - 2020-11-02 01:54:15 --> Helper loaded: url_helper
INFO - 2020-11-02 01:54:15 --> Helper loaded: file_helper
INFO - 2020-11-02 01:54:15 --> Helper loaded: form_helper
INFO - 2020-11-02 01:54:15 --> Helper loaded: my_helper
INFO - 2020-11-02 01:54:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 01:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 01:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 01:54:15 --> Controller Class Initialized
DEBUG - 2020-11-02 01:54:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-02 01:54:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 01:54:15 --> Final output sent to browser
DEBUG - 2020-11-02 01:54:15 --> Total execution time: 0.2314
INFO - 2020-11-02 01:54:18 --> Config Class Initialized
INFO - 2020-11-02 01:54:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 01:54:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 01:54:18 --> Utf8 Class Initialized
INFO - 2020-11-02 01:54:18 --> URI Class Initialized
INFO - 2020-11-02 01:54:18 --> Router Class Initialized
INFO - 2020-11-02 01:54:18 --> Output Class Initialized
INFO - 2020-11-02 01:54:18 --> Security Class Initialized
DEBUG - 2020-11-02 01:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 01:54:18 --> Input Class Initialized
INFO - 2020-11-02 01:54:18 --> Language Class Initialized
INFO - 2020-11-02 01:54:18 --> Language Class Initialized
INFO - 2020-11-02 01:54:18 --> Config Class Initialized
INFO - 2020-11-02 01:54:18 --> Loader Class Initialized
INFO - 2020-11-02 01:54:19 --> Helper loaded: url_helper
INFO - 2020-11-02 01:54:19 --> Helper loaded: file_helper
INFO - 2020-11-02 01:54:19 --> Helper loaded: form_helper
INFO - 2020-11-02 01:54:19 --> Helper loaded: my_helper
INFO - 2020-11-02 01:54:19 --> Database Driver Class Initialized
DEBUG - 2020-11-02 01:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 01:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 01:54:19 --> Controller Class Initialized
DEBUG - 2020-11-02 01:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-02 01:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 01:54:19 --> Final output sent to browser
DEBUG - 2020-11-02 01:54:19 --> Total execution time: 0.2073
INFO - 2020-11-02 02:03:23 --> Config Class Initialized
INFO - 2020-11-02 02:03:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:03:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:03:23 --> Utf8 Class Initialized
INFO - 2020-11-02 02:03:23 --> URI Class Initialized
INFO - 2020-11-02 02:03:23 --> Router Class Initialized
INFO - 2020-11-02 02:03:23 --> Output Class Initialized
INFO - 2020-11-02 02:03:23 --> Security Class Initialized
DEBUG - 2020-11-02 02:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:03:23 --> Input Class Initialized
INFO - 2020-11-02 02:03:23 --> Language Class Initialized
INFO - 2020-11-02 02:03:23 --> Language Class Initialized
INFO - 2020-11-02 02:03:23 --> Config Class Initialized
INFO - 2020-11-02 02:03:23 --> Loader Class Initialized
INFO - 2020-11-02 02:03:23 --> Helper loaded: url_helper
INFO - 2020-11-02 02:03:23 --> Helper loaded: file_helper
INFO - 2020-11-02 02:03:23 --> Helper loaded: form_helper
INFO - 2020-11-02 02:03:23 --> Helper loaded: my_helper
INFO - 2020-11-02 02:03:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:03:23 --> Controller Class Initialized
INFO - 2020-11-02 02:03:23 --> Config Class Initialized
INFO - 2020-11-02 02:03:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:03:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:03:23 --> Utf8 Class Initialized
INFO - 2020-11-02 02:03:24 --> URI Class Initialized
INFO - 2020-11-02 02:03:24 --> Router Class Initialized
INFO - 2020-11-02 02:03:24 --> Output Class Initialized
INFO - 2020-11-02 02:03:24 --> Security Class Initialized
DEBUG - 2020-11-02 02:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:03:24 --> Input Class Initialized
INFO - 2020-11-02 02:03:24 --> Language Class Initialized
INFO - 2020-11-02 02:03:24 --> Language Class Initialized
INFO - 2020-11-02 02:03:24 --> Config Class Initialized
INFO - 2020-11-02 02:03:24 --> Loader Class Initialized
INFO - 2020-11-02 02:03:24 --> Helper loaded: url_helper
INFO - 2020-11-02 02:03:24 --> Helper loaded: file_helper
INFO - 2020-11-02 02:03:24 --> Helper loaded: form_helper
INFO - 2020-11-02 02:03:24 --> Helper loaded: my_helper
INFO - 2020-11-02 02:03:24 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:03:24 --> Controller Class Initialized
DEBUG - 2020-11-02 02:03:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-02 02:03:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:03:24 --> Final output sent to browser
DEBUG - 2020-11-02 02:03:24 --> Total execution time: 0.2077
INFO - 2020-11-02 02:03:29 --> Config Class Initialized
INFO - 2020-11-02 02:03:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:03:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:03:29 --> Utf8 Class Initialized
INFO - 2020-11-02 02:03:29 --> URI Class Initialized
INFO - 2020-11-02 02:03:29 --> Router Class Initialized
INFO - 2020-11-02 02:03:29 --> Output Class Initialized
INFO - 2020-11-02 02:03:29 --> Security Class Initialized
DEBUG - 2020-11-02 02:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:03:29 --> Input Class Initialized
INFO - 2020-11-02 02:03:29 --> Language Class Initialized
INFO - 2020-11-02 02:03:29 --> Language Class Initialized
INFO - 2020-11-02 02:03:29 --> Config Class Initialized
INFO - 2020-11-02 02:03:29 --> Loader Class Initialized
INFO - 2020-11-02 02:03:29 --> Helper loaded: url_helper
INFO - 2020-11-02 02:03:29 --> Helper loaded: file_helper
INFO - 2020-11-02 02:03:29 --> Helper loaded: form_helper
INFO - 2020-11-02 02:03:29 --> Helper loaded: my_helper
INFO - 2020-11-02 02:03:29 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:03:29 --> Controller Class Initialized
DEBUG - 2020-11-02 02:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-02 02:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:03:29 --> Final output sent to browser
DEBUG - 2020-11-02 02:03:29 --> Total execution time: 0.2967
INFO - 2020-11-02 02:03:29 --> Config Class Initialized
INFO - 2020-11-02 02:03:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:03:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:03:29 --> Utf8 Class Initialized
INFO - 2020-11-02 02:03:29 --> URI Class Initialized
INFO - 2020-11-02 02:03:29 --> Router Class Initialized
INFO - 2020-11-02 02:03:29 --> Output Class Initialized
INFO - 2020-11-02 02:03:29 --> Security Class Initialized
DEBUG - 2020-11-02 02:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:03:29 --> Input Class Initialized
INFO - 2020-11-02 02:03:29 --> Language Class Initialized
INFO - 2020-11-02 02:03:29 --> Language Class Initialized
INFO - 2020-11-02 02:03:29 --> Config Class Initialized
INFO - 2020-11-02 02:03:29 --> Loader Class Initialized
INFO - 2020-11-02 02:03:29 --> Helper loaded: url_helper
INFO - 2020-11-02 02:03:29 --> Helper loaded: file_helper
INFO - 2020-11-02 02:03:29 --> Helper loaded: form_helper
INFO - 2020-11-02 02:03:29 --> Helper loaded: my_helper
INFO - 2020-11-02 02:03:29 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:03:29 --> Controller Class Initialized
INFO - 2020-11-02 02:03:35 --> Config Class Initialized
INFO - 2020-11-02 02:03:35 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:03:35 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:03:35 --> Utf8 Class Initialized
INFO - 2020-11-02 02:03:35 --> URI Class Initialized
INFO - 2020-11-02 02:03:35 --> Router Class Initialized
INFO - 2020-11-02 02:03:35 --> Output Class Initialized
INFO - 2020-11-02 02:03:35 --> Security Class Initialized
DEBUG - 2020-11-02 02:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:03:35 --> Input Class Initialized
INFO - 2020-11-02 02:03:35 --> Language Class Initialized
INFO - 2020-11-02 02:03:35 --> Language Class Initialized
INFO - 2020-11-02 02:03:35 --> Config Class Initialized
INFO - 2020-11-02 02:03:35 --> Loader Class Initialized
INFO - 2020-11-02 02:03:35 --> Helper loaded: url_helper
INFO - 2020-11-02 02:03:35 --> Helper loaded: file_helper
INFO - 2020-11-02 02:03:35 --> Helper loaded: form_helper
INFO - 2020-11-02 02:03:35 --> Helper loaded: my_helper
INFO - 2020-11-02 02:03:35 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:03:35 --> Controller Class Initialized
DEBUG - 2020-11-02 02:03:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:03:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:03:35 --> Final output sent to browser
DEBUG - 2020-11-02 02:03:36 --> Total execution time: 0.1989
INFO - 2020-11-02 02:03:36 --> Config Class Initialized
INFO - 2020-11-02 02:03:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:03:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:03:36 --> Utf8 Class Initialized
INFO - 2020-11-02 02:03:36 --> URI Class Initialized
INFO - 2020-11-02 02:03:36 --> Router Class Initialized
INFO - 2020-11-02 02:03:36 --> Output Class Initialized
INFO - 2020-11-02 02:03:36 --> Security Class Initialized
DEBUG - 2020-11-02 02:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:03:36 --> Input Class Initialized
INFO - 2020-11-02 02:03:36 --> Language Class Initialized
INFO - 2020-11-02 02:03:36 --> Language Class Initialized
INFO - 2020-11-02 02:03:36 --> Config Class Initialized
INFO - 2020-11-02 02:03:36 --> Loader Class Initialized
INFO - 2020-11-02 02:03:36 --> Helper loaded: url_helper
INFO - 2020-11-02 02:03:36 --> Helper loaded: file_helper
INFO - 2020-11-02 02:03:36 --> Helper loaded: form_helper
INFO - 2020-11-02 02:03:36 --> Helper loaded: my_helper
INFO - 2020-11-02 02:03:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:03:36 --> Controller Class Initialized
INFO - 2020-11-02 02:03:37 --> Config Class Initialized
INFO - 2020-11-02 02:03:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:03:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:03:37 --> Utf8 Class Initialized
INFO - 2020-11-02 02:03:37 --> URI Class Initialized
INFO - 2020-11-02 02:03:37 --> Router Class Initialized
INFO - 2020-11-02 02:03:37 --> Output Class Initialized
INFO - 2020-11-02 02:03:37 --> Security Class Initialized
DEBUG - 2020-11-02 02:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:03:37 --> Input Class Initialized
INFO - 2020-11-02 02:03:37 --> Language Class Initialized
INFO - 2020-11-02 02:03:37 --> Language Class Initialized
INFO - 2020-11-02 02:03:37 --> Config Class Initialized
INFO - 2020-11-02 02:03:37 --> Loader Class Initialized
INFO - 2020-11-02 02:03:37 --> Helper loaded: url_helper
INFO - 2020-11-02 02:03:37 --> Helper loaded: file_helper
INFO - 2020-11-02 02:03:37 --> Helper loaded: form_helper
INFO - 2020-11-02 02:03:37 --> Helper loaded: my_helper
INFO - 2020-11-02 02:03:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:03:37 --> Controller Class Initialized
DEBUG - 2020-11-02 02:03:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-11-02 02:03:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:03:37 --> Final output sent to browser
DEBUG - 2020-11-02 02:03:37 --> Total execution time: 0.1982
INFO - 2020-11-02 02:04:38 --> Config Class Initialized
INFO - 2020-11-02 02:04:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:04:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:04:38 --> Utf8 Class Initialized
INFO - 2020-11-02 02:04:38 --> URI Class Initialized
INFO - 2020-11-02 02:04:38 --> Router Class Initialized
INFO - 2020-11-02 02:04:38 --> Output Class Initialized
INFO - 2020-11-02 02:04:38 --> Security Class Initialized
DEBUG - 2020-11-02 02:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:04:38 --> Input Class Initialized
INFO - 2020-11-02 02:04:38 --> Language Class Initialized
INFO - 2020-11-02 02:04:38 --> Language Class Initialized
INFO - 2020-11-02 02:04:38 --> Config Class Initialized
INFO - 2020-11-02 02:04:38 --> Loader Class Initialized
INFO - 2020-11-02 02:04:38 --> Helper loaded: url_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: file_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: form_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: my_helper
INFO - 2020-11-02 02:04:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:04:38 --> Controller Class Initialized
INFO - 2020-11-02 02:04:38 --> Config Class Initialized
INFO - 2020-11-02 02:04:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:04:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:04:38 --> Utf8 Class Initialized
INFO - 2020-11-02 02:04:38 --> URI Class Initialized
INFO - 2020-11-02 02:04:38 --> Router Class Initialized
INFO - 2020-11-02 02:04:38 --> Output Class Initialized
INFO - 2020-11-02 02:04:38 --> Security Class Initialized
DEBUG - 2020-11-02 02:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:04:38 --> Input Class Initialized
INFO - 2020-11-02 02:04:38 --> Language Class Initialized
INFO - 2020-11-02 02:04:38 --> Language Class Initialized
INFO - 2020-11-02 02:04:38 --> Config Class Initialized
INFO - 2020-11-02 02:04:38 --> Loader Class Initialized
INFO - 2020-11-02 02:04:38 --> Helper loaded: url_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: file_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: form_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: my_helper
INFO - 2020-11-02 02:04:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:04:38 --> Controller Class Initialized
DEBUG - 2020-11-02 02:04:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:04:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:04:38 --> Final output sent to browser
DEBUG - 2020-11-02 02:04:38 --> Total execution time: 0.2796
INFO - 2020-11-02 02:04:38 --> Config Class Initialized
INFO - 2020-11-02 02:04:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:04:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:04:38 --> Utf8 Class Initialized
INFO - 2020-11-02 02:04:38 --> URI Class Initialized
INFO - 2020-11-02 02:04:38 --> Router Class Initialized
INFO - 2020-11-02 02:04:38 --> Output Class Initialized
INFO - 2020-11-02 02:04:38 --> Security Class Initialized
DEBUG - 2020-11-02 02:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:04:38 --> Input Class Initialized
INFO - 2020-11-02 02:04:38 --> Language Class Initialized
INFO - 2020-11-02 02:04:38 --> Language Class Initialized
INFO - 2020-11-02 02:04:38 --> Config Class Initialized
INFO - 2020-11-02 02:04:38 --> Loader Class Initialized
INFO - 2020-11-02 02:04:38 --> Helper loaded: url_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: file_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: form_helper
INFO - 2020-11-02 02:04:38 --> Helper loaded: my_helper
INFO - 2020-11-02 02:04:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:04:38 --> Controller Class Initialized
INFO - 2020-11-02 02:04:41 --> Config Class Initialized
INFO - 2020-11-02 02:04:41 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:04:41 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:04:41 --> Utf8 Class Initialized
INFO - 2020-11-02 02:04:41 --> URI Class Initialized
INFO - 2020-11-02 02:04:41 --> Router Class Initialized
INFO - 2020-11-02 02:04:41 --> Output Class Initialized
INFO - 2020-11-02 02:04:41 --> Security Class Initialized
DEBUG - 2020-11-02 02:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:04:41 --> Input Class Initialized
INFO - 2020-11-02 02:04:41 --> Language Class Initialized
INFO - 2020-11-02 02:04:41 --> Language Class Initialized
INFO - 2020-11-02 02:04:41 --> Config Class Initialized
INFO - 2020-11-02 02:04:41 --> Loader Class Initialized
INFO - 2020-11-02 02:04:41 --> Helper loaded: url_helper
INFO - 2020-11-02 02:04:41 --> Helper loaded: file_helper
INFO - 2020-11-02 02:04:41 --> Helper loaded: form_helper
INFO - 2020-11-02 02:04:41 --> Helper loaded: my_helper
INFO - 2020-11-02 02:04:41 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:04:41 --> Controller Class Initialized
DEBUG - 2020-11-02 02:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-11-02 02:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:04:41 --> Final output sent to browser
DEBUG - 2020-11-02 02:04:41 --> Total execution time: 0.1843
INFO - 2020-11-02 02:04:53 --> Config Class Initialized
INFO - 2020-11-02 02:04:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:04:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:04:53 --> Utf8 Class Initialized
INFO - 2020-11-02 02:04:53 --> URI Class Initialized
INFO - 2020-11-02 02:04:53 --> Router Class Initialized
INFO - 2020-11-02 02:04:53 --> Output Class Initialized
INFO - 2020-11-02 02:04:53 --> Security Class Initialized
DEBUG - 2020-11-02 02:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:04:53 --> Input Class Initialized
INFO - 2020-11-02 02:04:53 --> Language Class Initialized
INFO - 2020-11-02 02:04:53 --> Language Class Initialized
INFO - 2020-11-02 02:04:53 --> Config Class Initialized
INFO - 2020-11-02 02:04:53 --> Loader Class Initialized
INFO - 2020-11-02 02:04:53 --> Helper loaded: url_helper
INFO - 2020-11-02 02:04:53 --> Helper loaded: file_helper
INFO - 2020-11-02 02:04:53 --> Helper loaded: form_helper
INFO - 2020-11-02 02:04:53 --> Helper loaded: my_helper
INFO - 2020-11-02 02:04:53 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:04:53 --> Controller Class Initialized
INFO - 2020-11-02 02:04:54 --> Config Class Initialized
INFO - 2020-11-02 02:04:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:04:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:04:54 --> Utf8 Class Initialized
INFO - 2020-11-02 02:04:54 --> URI Class Initialized
INFO - 2020-11-02 02:04:54 --> Router Class Initialized
INFO - 2020-11-02 02:04:54 --> Output Class Initialized
INFO - 2020-11-02 02:04:54 --> Security Class Initialized
DEBUG - 2020-11-02 02:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:04:54 --> Input Class Initialized
INFO - 2020-11-02 02:04:54 --> Language Class Initialized
INFO - 2020-11-02 02:04:54 --> Language Class Initialized
INFO - 2020-11-02 02:04:54 --> Config Class Initialized
INFO - 2020-11-02 02:04:54 --> Loader Class Initialized
INFO - 2020-11-02 02:04:54 --> Helper loaded: url_helper
INFO - 2020-11-02 02:04:54 --> Helper loaded: file_helper
INFO - 2020-11-02 02:04:54 --> Helper loaded: form_helper
INFO - 2020-11-02 02:04:54 --> Helper loaded: my_helper
INFO - 2020-11-02 02:04:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:04:54 --> Controller Class Initialized
DEBUG - 2020-11-02 02:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:04:54 --> Final output sent to browser
DEBUG - 2020-11-02 02:04:54 --> Total execution time: 0.1765
INFO - 2020-11-02 02:04:54 --> Config Class Initialized
INFO - 2020-11-02 02:04:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:04:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:04:54 --> Utf8 Class Initialized
INFO - 2020-11-02 02:04:54 --> URI Class Initialized
INFO - 2020-11-02 02:04:54 --> Router Class Initialized
INFO - 2020-11-02 02:04:54 --> Output Class Initialized
INFO - 2020-11-02 02:04:54 --> Security Class Initialized
DEBUG - 2020-11-02 02:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:04:54 --> Input Class Initialized
INFO - 2020-11-02 02:04:54 --> Language Class Initialized
INFO - 2020-11-02 02:04:54 --> Language Class Initialized
INFO - 2020-11-02 02:04:54 --> Config Class Initialized
INFO - 2020-11-02 02:04:54 --> Loader Class Initialized
INFO - 2020-11-02 02:04:54 --> Helper loaded: url_helper
INFO - 2020-11-02 02:04:54 --> Helper loaded: file_helper
INFO - 2020-11-02 02:04:54 --> Helper loaded: form_helper
INFO - 2020-11-02 02:04:54 --> Helper loaded: my_helper
INFO - 2020-11-02 02:04:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:04:54 --> Controller Class Initialized
INFO - 2020-11-02 02:04:56 --> Config Class Initialized
INFO - 2020-11-02 02:04:56 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:04:56 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:04:56 --> Utf8 Class Initialized
INFO - 2020-11-02 02:04:56 --> URI Class Initialized
INFO - 2020-11-02 02:04:56 --> Router Class Initialized
INFO - 2020-11-02 02:04:56 --> Output Class Initialized
INFO - 2020-11-02 02:04:56 --> Security Class Initialized
DEBUG - 2020-11-02 02:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:04:56 --> Input Class Initialized
INFO - 2020-11-02 02:04:56 --> Language Class Initialized
INFO - 2020-11-02 02:04:56 --> Language Class Initialized
INFO - 2020-11-02 02:04:56 --> Config Class Initialized
INFO - 2020-11-02 02:04:56 --> Loader Class Initialized
INFO - 2020-11-02 02:04:56 --> Helper loaded: url_helper
INFO - 2020-11-02 02:04:56 --> Helper loaded: file_helper
INFO - 2020-11-02 02:04:56 --> Helper loaded: form_helper
INFO - 2020-11-02 02:04:56 --> Helper loaded: my_helper
INFO - 2020-11-02 02:04:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:04:56 --> Controller Class Initialized
DEBUG - 2020-11-02 02:04:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-11-02 02:04:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:04:56 --> Final output sent to browser
DEBUG - 2020-11-02 02:04:56 --> Total execution time: 0.2121
INFO - 2020-11-02 02:05:28 --> Config Class Initialized
INFO - 2020-11-02 02:05:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:05:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:05:28 --> Utf8 Class Initialized
INFO - 2020-11-02 02:05:28 --> URI Class Initialized
INFO - 2020-11-02 02:05:28 --> Router Class Initialized
INFO - 2020-11-02 02:05:28 --> Output Class Initialized
INFO - 2020-11-02 02:05:28 --> Security Class Initialized
DEBUG - 2020-11-02 02:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:05:28 --> Input Class Initialized
INFO - 2020-11-02 02:05:28 --> Language Class Initialized
INFO - 2020-11-02 02:05:28 --> Language Class Initialized
INFO - 2020-11-02 02:05:28 --> Config Class Initialized
INFO - 2020-11-02 02:05:28 --> Loader Class Initialized
INFO - 2020-11-02 02:05:28 --> Helper loaded: url_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: file_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: form_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: my_helper
INFO - 2020-11-02 02:05:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:05:28 --> Controller Class Initialized
INFO - 2020-11-02 02:05:28 --> Config Class Initialized
INFO - 2020-11-02 02:05:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:05:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:05:28 --> Utf8 Class Initialized
INFO - 2020-11-02 02:05:28 --> URI Class Initialized
INFO - 2020-11-02 02:05:28 --> Router Class Initialized
INFO - 2020-11-02 02:05:28 --> Output Class Initialized
INFO - 2020-11-02 02:05:28 --> Security Class Initialized
DEBUG - 2020-11-02 02:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:05:28 --> Input Class Initialized
INFO - 2020-11-02 02:05:28 --> Language Class Initialized
INFO - 2020-11-02 02:05:28 --> Language Class Initialized
INFO - 2020-11-02 02:05:28 --> Config Class Initialized
INFO - 2020-11-02 02:05:28 --> Loader Class Initialized
INFO - 2020-11-02 02:05:28 --> Helper loaded: url_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: file_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: form_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: my_helper
INFO - 2020-11-02 02:05:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:05:28 --> Controller Class Initialized
DEBUG - 2020-11-02 02:05:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:05:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:05:28 --> Final output sent to browser
DEBUG - 2020-11-02 02:05:28 --> Total execution time: 0.2125
INFO - 2020-11-02 02:05:28 --> Config Class Initialized
INFO - 2020-11-02 02:05:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:05:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:05:28 --> Utf8 Class Initialized
INFO - 2020-11-02 02:05:28 --> URI Class Initialized
INFO - 2020-11-02 02:05:28 --> Router Class Initialized
INFO - 2020-11-02 02:05:28 --> Output Class Initialized
INFO - 2020-11-02 02:05:28 --> Security Class Initialized
DEBUG - 2020-11-02 02:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:05:28 --> Input Class Initialized
INFO - 2020-11-02 02:05:28 --> Language Class Initialized
INFO - 2020-11-02 02:05:28 --> Language Class Initialized
INFO - 2020-11-02 02:05:28 --> Config Class Initialized
INFO - 2020-11-02 02:05:28 --> Loader Class Initialized
INFO - 2020-11-02 02:05:28 --> Helper loaded: url_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: file_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: form_helper
INFO - 2020-11-02 02:05:28 --> Helper loaded: my_helper
INFO - 2020-11-02 02:05:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:05:28 --> Controller Class Initialized
INFO - 2020-11-02 02:05:33 --> Config Class Initialized
INFO - 2020-11-02 02:05:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:05:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:05:33 --> Utf8 Class Initialized
INFO - 2020-11-02 02:05:33 --> URI Class Initialized
INFO - 2020-11-02 02:05:33 --> Router Class Initialized
INFO - 2020-11-02 02:05:33 --> Output Class Initialized
INFO - 2020-11-02 02:05:33 --> Security Class Initialized
DEBUG - 2020-11-02 02:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:05:33 --> Input Class Initialized
INFO - 2020-11-02 02:05:33 --> Language Class Initialized
INFO - 2020-11-02 02:05:33 --> Language Class Initialized
INFO - 2020-11-02 02:05:33 --> Config Class Initialized
INFO - 2020-11-02 02:05:33 --> Loader Class Initialized
INFO - 2020-11-02 02:05:33 --> Helper loaded: url_helper
INFO - 2020-11-02 02:05:33 --> Helper loaded: file_helper
INFO - 2020-11-02 02:05:33 --> Helper loaded: form_helper
INFO - 2020-11-02 02:05:33 --> Helper loaded: my_helper
INFO - 2020-11-02 02:05:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:05:33 --> Controller Class Initialized
DEBUG - 2020-11-02 02:05:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-11-02 02:05:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:05:33 --> Final output sent to browser
DEBUG - 2020-11-02 02:05:33 --> Total execution time: 0.1847
INFO - 2020-11-02 02:05:50 --> Config Class Initialized
INFO - 2020-11-02 02:05:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:05:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:05:50 --> Utf8 Class Initialized
INFO - 2020-11-02 02:05:50 --> URI Class Initialized
INFO - 2020-11-02 02:05:50 --> Router Class Initialized
INFO - 2020-11-02 02:05:50 --> Output Class Initialized
INFO - 2020-11-02 02:05:50 --> Security Class Initialized
DEBUG - 2020-11-02 02:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:05:50 --> Input Class Initialized
INFO - 2020-11-02 02:05:50 --> Language Class Initialized
INFO - 2020-11-02 02:05:50 --> Language Class Initialized
INFO - 2020-11-02 02:05:50 --> Config Class Initialized
INFO - 2020-11-02 02:05:50 --> Loader Class Initialized
INFO - 2020-11-02 02:05:50 --> Helper loaded: url_helper
INFO - 2020-11-02 02:05:50 --> Helper loaded: file_helper
INFO - 2020-11-02 02:05:50 --> Helper loaded: form_helper
INFO - 2020-11-02 02:05:50 --> Helper loaded: my_helper
INFO - 2020-11-02 02:05:50 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:05:50 --> Controller Class Initialized
INFO - 2020-11-02 02:05:50 --> Config Class Initialized
INFO - 2020-11-02 02:05:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:05:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:05:50 --> Utf8 Class Initialized
INFO - 2020-11-02 02:05:50 --> URI Class Initialized
INFO - 2020-11-02 02:05:50 --> Router Class Initialized
INFO - 2020-11-02 02:05:50 --> Output Class Initialized
INFO - 2020-11-02 02:05:50 --> Security Class Initialized
DEBUG - 2020-11-02 02:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:05:50 --> Input Class Initialized
INFO - 2020-11-02 02:05:50 --> Language Class Initialized
INFO - 2020-11-02 02:05:50 --> Language Class Initialized
INFO - 2020-11-02 02:05:50 --> Config Class Initialized
INFO - 2020-11-02 02:05:50 --> Loader Class Initialized
INFO - 2020-11-02 02:05:50 --> Helper loaded: url_helper
INFO - 2020-11-02 02:05:50 --> Helper loaded: file_helper
INFO - 2020-11-02 02:05:50 --> Helper loaded: form_helper
INFO - 2020-11-02 02:05:50 --> Helper loaded: my_helper
INFO - 2020-11-02 02:05:50 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:05:50 --> Controller Class Initialized
DEBUG - 2020-11-02 02:05:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:05:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:05:50 --> Final output sent to browser
DEBUG - 2020-11-02 02:05:50 --> Total execution time: 0.2229
INFO - 2020-11-02 02:05:50 --> Config Class Initialized
INFO - 2020-11-02 02:05:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:05:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:05:50 --> Utf8 Class Initialized
INFO - 2020-11-02 02:05:50 --> URI Class Initialized
INFO - 2020-11-02 02:05:50 --> Router Class Initialized
INFO - 2020-11-02 02:05:50 --> Output Class Initialized
INFO - 2020-11-02 02:05:50 --> Security Class Initialized
DEBUG - 2020-11-02 02:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:05:50 --> Input Class Initialized
INFO - 2020-11-02 02:05:50 --> Language Class Initialized
INFO - 2020-11-02 02:05:50 --> Language Class Initialized
INFO - 2020-11-02 02:05:51 --> Config Class Initialized
INFO - 2020-11-02 02:05:51 --> Loader Class Initialized
INFO - 2020-11-02 02:05:51 --> Helper loaded: url_helper
INFO - 2020-11-02 02:05:51 --> Helper loaded: file_helper
INFO - 2020-11-02 02:05:51 --> Helper loaded: form_helper
INFO - 2020-11-02 02:05:51 --> Helper loaded: my_helper
INFO - 2020-11-02 02:05:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:05:51 --> Controller Class Initialized
INFO - 2020-11-02 02:05:52 --> Config Class Initialized
INFO - 2020-11-02 02:05:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:05:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:05:52 --> Utf8 Class Initialized
INFO - 2020-11-02 02:05:52 --> URI Class Initialized
INFO - 2020-11-02 02:05:52 --> Router Class Initialized
INFO - 2020-11-02 02:05:52 --> Output Class Initialized
INFO - 2020-11-02 02:05:52 --> Security Class Initialized
DEBUG - 2020-11-02 02:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:05:52 --> Input Class Initialized
INFO - 2020-11-02 02:05:52 --> Language Class Initialized
INFO - 2020-11-02 02:05:52 --> Language Class Initialized
INFO - 2020-11-02 02:05:52 --> Config Class Initialized
INFO - 2020-11-02 02:05:52 --> Loader Class Initialized
INFO - 2020-11-02 02:05:52 --> Helper loaded: url_helper
INFO - 2020-11-02 02:05:52 --> Helper loaded: file_helper
INFO - 2020-11-02 02:05:52 --> Helper loaded: form_helper
INFO - 2020-11-02 02:05:52 --> Helper loaded: my_helper
INFO - 2020-11-02 02:05:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:05:52 --> Controller Class Initialized
DEBUG - 2020-11-02 02:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-11-02 02:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:05:52 --> Final output sent to browser
DEBUG - 2020-11-02 02:05:52 --> Total execution time: 0.1882
INFO - 2020-11-02 02:06:06 --> Config Class Initialized
INFO - 2020-11-02 02:06:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:06 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:06 --> URI Class Initialized
INFO - 2020-11-02 02:06:06 --> Router Class Initialized
INFO - 2020-11-02 02:06:06 --> Output Class Initialized
INFO - 2020-11-02 02:06:06 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:06 --> Input Class Initialized
INFO - 2020-11-02 02:06:06 --> Language Class Initialized
INFO - 2020-11-02 02:06:06 --> Language Class Initialized
INFO - 2020-11-02 02:06:06 --> Config Class Initialized
INFO - 2020-11-02 02:06:06 --> Loader Class Initialized
INFO - 2020-11-02 02:06:06 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:06 --> Controller Class Initialized
INFO - 2020-11-02 02:06:06 --> Config Class Initialized
INFO - 2020-11-02 02:06:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:06 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:06 --> URI Class Initialized
INFO - 2020-11-02 02:06:06 --> Router Class Initialized
INFO - 2020-11-02 02:06:06 --> Output Class Initialized
INFO - 2020-11-02 02:06:06 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:06 --> Input Class Initialized
INFO - 2020-11-02 02:06:06 --> Language Class Initialized
INFO - 2020-11-02 02:06:06 --> Language Class Initialized
INFO - 2020-11-02 02:06:06 --> Config Class Initialized
INFO - 2020-11-02 02:06:06 --> Loader Class Initialized
INFO - 2020-11-02 02:06:06 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:06 --> Controller Class Initialized
DEBUG - 2020-11-02 02:06:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:06:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:06:06 --> Final output sent to browser
DEBUG - 2020-11-02 02:06:06 --> Total execution time: 0.1996
INFO - 2020-11-02 02:06:06 --> Config Class Initialized
INFO - 2020-11-02 02:06:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:06 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:06 --> URI Class Initialized
INFO - 2020-11-02 02:06:06 --> Router Class Initialized
INFO - 2020-11-02 02:06:06 --> Output Class Initialized
INFO - 2020-11-02 02:06:06 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:06 --> Input Class Initialized
INFO - 2020-11-02 02:06:06 --> Language Class Initialized
INFO - 2020-11-02 02:06:06 --> Language Class Initialized
INFO - 2020-11-02 02:06:06 --> Config Class Initialized
INFO - 2020-11-02 02:06:06 --> Loader Class Initialized
INFO - 2020-11-02 02:06:06 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:06 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:06 --> Controller Class Initialized
INFO - 2020-11-02 02:06:07 --> Config Class Initialized
INFO - 2020-11-02 02:06:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:07 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:07 --> URI Class Initialized
INFO - 2020-11-02 02:06:07 --> Router Class Initialized
INFO - 2020-11-02 02:06:07 --> Output Class Initialized
INFO - 2020-11-02 02:06:07 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:07 --> Input Class Initialized
INFO - 2020-11-02 02:06:07 --> Language Class Initialized
INFO - 2020-11-02 02:06:07 --> Language Class Initialized
INFO - 2020-11-02 02:06:07 --> Config Class Initialized
INFO - 2020-11-02 02:06:07 --> Loader Class Initialized
INFO - 2020-11-02 02:06:07 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:08 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:08 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:08 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:08 --> Controller Class Initialized
DEBUG - 2020-11-02 02:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-11-02 02:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:06:08 --> Final output sent to browser
DEBUG - 2020-11-02 02:06:08 --> Total execution time: 0.1891
INFO - 2020-11-02 02:06:16 --> Config Class Initialized
INFO - 2020-11-02 02:06:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:16 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:16 --> URI Class Initialized
INFO - 2020-11-02 02:06:16 --> Router Class Initialized
INFO - 2020-11-02 02:06:16 --> Output Class Initialized
INFO - 2020-11-02 02:06:16 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:16 --> Input Class Initialized
INFO - 2020-11-02 02:06:16 --> Language Class Initialized
INFO - 2020-11-02 02:06:16 --> Language Class Initialized
INFO - 2020-11-02 02:06:16 --> Config Class Initialized
INFO - 2020-11-02 02:06:16 --> Loader Class Initialized
INFO - 2020-11-02 02:06:16 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:16 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:16 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:16 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:16 --> Controller Class Initialized
INFO - 2020-11-02 02:06:17 --> Config Class Initialized
INFO - 2020-11-02 02:06:17 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:17 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:17 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:17 --> URI Class Initialized
INFO - 2020-11-02 02:06:17 --> Router Class Initialized
INFO - 2020-11-02 02:06:17 --> Output Class Initialized
INFO - 2020-11-02 02:06:17 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:17 --> Input Class Initialized
INFO - 2020-11-02 02:06:17 --> Language Class Initialized
INFO - 2020-11-02 02:06:17 --> Language Class Initialized
INFO - 2020-11-02 02:06:17 --> Config Class Initialized
INFO - 2020-11-02 02:06:17 --> Loader Class Initialized
INFO - 2020-11-02 02:06:17 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:17 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:17 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:17 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:17 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:17 --> Controller Class Initialized
DEBUG - 2020-11-02 02:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:06:17 --> Final output sent to browser
DEBUG - 2020-11-02 02:06:17 --> Total execution time: 0.2337
INFO - 2020-11-02 02:06:17 --> Config Class Initialized
INFO - 2020-11-02 02:06:17 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:17 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:17 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:17 --> URI Class Initialized
INFO - 2020-11-02 02:06:17 --> Router Class Initialized
INFO - 2020-11-02 02:06:17 --> Output Class Initialized
INFO - 2020-11-02 02:06:17 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:17 --> Input Class Initialized
INFO - 2020-11-02 02:06:17 --> Language Class Initialized
INFO - 2020-11-02 02:06:17 --> Language Class Initialized
INFO - 2020-11-02 02:06:17 --> Config Class Initialized
INFO - 2020-11-02 02:06:17 --> Loader Class Initialized
INFO - 2020-11-02 02:06:17 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:17 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:17 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:17 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:17 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:17 --> Controller Class Initialized
INFO - 2020-11-02 02:06:20 --> Config Class Initialized
INFO - 2020-11-02 02:06:20 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:20 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:20 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:20 --> URI Class Initialized
INFO - 2020-11-02 02:06:20 --> Router Class Initialized
INFO - 2020-11-02 02:06:20 --> Output Class Initialized
INFO - 2020-11-02 02:06:20 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:20 --> Input Class Initialized
INFO - 2020-11-02 02:06:20 --> Language Class Initialized
INFO - 2020-11-02 02:06:20 --> Language Class Initialized
INFO - 2020-11-02 02:06:20 --> Config Class Initialized
INFO - 2020-11-02 02:06:20 --> Loader Class Initialized
INFO - 2020-11-02 02:06:20 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:20 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:20 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:20 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:20 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:20 --> Controller Class Initialized
DEBUG - 2020-11-02 02:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-11-02 02:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:06:20 --> Final output sent to browser
DEBUG - 2020-11-02 02:06:20 --> Total execution time: 0.1947
INFO - 2020-11-02 02:06:27 --> Config Class Initialized
INFO - 2020-11-02 02:06:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:27 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:27 --> URI Class Initialized
INFO - 2020-11-02 02:06:27 --> Router Class Initialized
INFO - 2020-11-02 02:06:27 --> Output Class Initialized
INFO - 2020-11-02 02:06:27 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:27 --> Input Class Initialized
INFO - 2020-11-02 02:06:27 --> Language Class Initialized
INFO - 2020-11-02 02:06:27 --> Language Class Initialized
INFO - 2020-11-02 02:06:27 --> Config Class Initialized
INFO - 2020-11-02 02:06:27 --> Loader Class Initialized
INFO - 2020-11-02 02:06:27 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:27 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:27 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:27 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:27 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:27 --> Controller Class Initialized
DEBUG - 2020-11-02 02:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:06:27 --> Final output sent to browser
DEBUG - 2020-11-02 02:06:27 --> Total execution time: 0.1961
INFO - 2020-11-02 02:06:27 --> Config Class Initialized
INFO - 2020-11-02 02:06:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:27 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:27 --> URI Class Initialized
INFO - 2020-11-02 02:06:28 --> Router Class Initialized
INFO - 2020-11-02 02:06:28 --> Output Class Initialized
INFO - 2020-11-02 02:06:28 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:28 --> Input Class Initialized
INFO - 2020-11-02 02:06:28 --> Language Class Initialized
INFO - 2020-11-02 02:06:28 --> Language Class Initialized
INFO - 2020-11-02 02:06:28 --> Config Class Initialized
INFO - 2020-11-02 02:06:28 --> Loader Class Initialized
INFO - 2020-11-02 02:06:28 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:28 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:28 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:28 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:28 --> Controller Class Initialized
INFO - 2020-11-02 02:06:56 --> Config Class Initialized
INFO - 2020-11-02 02:06:56 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:56 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:56 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:56 --> URI Class Initialized
INFO - 2020-11-02 02:06:56 --> Router Class Initialized
INFO - 2020-11-02 02:06:56 --> Output Class Initialized
INFO - 2020-11-02 02:06:56 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:56 --> Input Class Initialized
INFO - 2020-11-02 02:06:56 --> Language Class Initialized
INFO - 2020-11-02 02:06:56 --> Language Class Initialized
INFO - 2020-11-02 02:06:56 --> Config Class Initialized
INFO - 2020-11-02 02:06:56 --> Loader Class Initialized
INFO - 2020-11-02 02:06:56 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:56 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:56 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:56 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:57 --> Controller Class Initialized
DEBUG - 2020-11-02 02:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-11-02 02:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:06:57 --> Final output sent to browser
DEBUG - 2020-11-02 02:06:57 --> Total execution time: 0.3450
INFO - 2020-11-02 02:06:57 --> Config Class Initialized
INFO - 2020-11-02 02:06:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:06:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:06:57 --> Utf8 Class Initialized
INFO - 2020-11-02 02:06:57 --> URI Class Initialized
INFO - 2020-11-02 02:06:57 --> Router Class Initialized
INFO - 2020-11-02 02:06:57 --> Output Class Initialized
INFO - 2020-11-02 02:06:57 --> Security Class Initialized
DEBUG - 2020-11-02 02:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:06:57 --> Input Class Initialized
INFO - 2020-11-02 02:06:57 --> Language Class Initialized
INFO - 2020-11-02 02:06:57 --> Language Class Initialized
INFO - 2020-11-02 02:06:57 --> Config Class Initialized
INFO - 2020-11-02 02:06:57 --> Loader Class Initialized
INFO - 2020-11-02 02:06:57 --> Helper loaded: url_helper
INFO - 2020-11-02 02:06:57 --> Helper loaded: file_helper
INFO - 2020-11-02 02:06:57 --> Helper loaded: form_helper
INFO - 2020-11-02 02:06:57 --> Helper loaded: my_helper
INFO - 2020-11-02 02:06:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:06:57 --> Controller Class Initialized
INFO - 2020-11-02 02:08:00 --> Config Class Initialized
INFO - 2020-11-02 02:08:00 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:00 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:00 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:00 --> URI Class Initialized
INFO - 2020-11-02 02:08:00 --> Router Class Initialized
INFO - 2020-11-02 02:08:00 --> Output Class Initialized
INFO - 2020-11-02 02:08:00 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:00 --> Input Class Initialized
INFO - 2020-11-02 02:08:00 --> Language Class Initialized
INFO - 2020-11-02 02:08:00 --> Language Class Initialized
INFO - 2020-11-02 02:08:00 --> Config Class Initialized
INFO - 2020-11-02 02:08:00 --> Loader Class Initialized
INFO - 2020-11-02 02:08:00 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:00 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:00 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:00 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:00 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:00 --> Controller Class Initialized
INFO - 2020-11-02 02:08:00 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:00 --> Total execution time: 0.1732
INFO - 2020-11-02 02:08:19 --> Config Class Initialized
INFO - 2020-11-02 02:08:19 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:19 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:19 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:19 --> URI Class Initialized
INFO - 2020-11-02 02:08:19 --> Router Class Initialized
INFO - 2020-11-02 02:08:19 --> Output Class Initialized
INFO - 2020-11-02 02:08:19 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:19 --> Input Class Initialized
INFO - 2020-11-02 02:08:19 --> Language Class Initialized
INFO - 2020-11-02 02:08:19 --> Language Class Initialized
INFO - 2020-11-02 02:08:19 --> Config Class Initialized
INFO - 2020-11-02 02:08:19 --> Loader Class Initialized
INFO - 2020-11-02 02:08:19 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:19 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:19 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:19 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:19 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:19 --> Controller Class Initialized
INFO - 2020-11-02 02:08:19 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:19 --> Total execution time: 0.2375
INFO - 2020-11-02 02:08:19 --> Config Class Initialized
INFO - 2020-11-02 02:08:19 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:19 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:19 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:19 --> URI Class Initialized
INFO - 2020-11-02 02:08:19 --> Router Class Initialized
INFO - 2020-11-02 02:08:19 --> Output Class Initialized
INFO - 2020-11-02 02:08:19 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:19 --> Input Class Initialized
INFO - 2020-11-02 02:08:19 --> Language Class Initialized
INFO - 2020-11-02 02:08:19 --> Language Class Initialized
INFO - 2020-11-02 02:08:19 --> Config Class Initialized
INFO - 2020-11-02 02:08:19 --> Loader Class Initialized
INFO - 2020-11-02 02:08:19 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:19 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:19 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:19 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:19 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:19 --> Controller Class Initialized
INFO - 2020-11-02 02:08:23 --> Config Class Initialized
INFO - 2020-11-02 02:08:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:23 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:23 --> URI Class Initialized
INFO - 2020-11-02 02:08:23 --> Router Class Initialized
INFO - 2020-11-02 02:08:23 --> Output Class Initialized
INFO - 2020-11-02 02:08:23 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:23 --> Input Class Initialized
INFO - 2020-11-02 02:08:23 --> Language Class Initialized
INFO - 2020-11-02 02:08:23 --> Language Class Initialized
INFO - 2020-11-02 02:08:23 --> Config Class Initialized
INFO - 2020-11-02 02:08:23 --> Loader Class Initialized
INFO - 2020-11-02 02:08:23 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:23 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:23 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:23 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:23 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:08:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:23 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:23 --> Total execution time: 0.1968
INFO - 2020-11-02 02:08:23 --> Config Class Initialized
INFO - 2020-11-02 02:08:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:23 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:23 --> URI Class Initialized
INFO - 2020-11-02 02:08:23 --> Router Class Initialized
INFO - 2020-11-02 02:08:23 --> Output Class Initialized
INFO - 2020-11-02 02:08:23 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:23 --> Input Class Initialized
INFO - 2020-11-02 02:08:23 --> Language Class Initialized
INFO - 2020-11-02 02:08:23 --> Language Class Initialized
INFO - 2020-11-02 02:08:23 --> Config Class Initialized
INFO - 2020-11-02 02:08:23 --> Loader Class Initialized
INFO - 2020-11-02 02:08:23 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:23 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:23 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:23 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:23 --> Controller Class Initialized
INFO - 2020-11-02 02:08:24 --> Config Class Initialized
INFO - 2020-11-02 02:08:24 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:24 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:24 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:24 --> URI Class Initialized
INFO - 2020-11-02 02:08:24 --> Router Class Initialized
INFO - 2020-11-02 02:08:24 --> Output Class Initialized
INFO - 2020-11-02 02:08:24 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:24 --> Input Class Initialized
INFO - 2020-11-02 02:08:24 --> Language Class Initialized
INFO - 2020-11-02 02:08:24 --> Language Class Initialized
INFO - 2020-11-02 02:08:24 --> Config Class Initialized
INFO - 2020-11-02 02:08:24 --> Loader Class Initialized
INFO - 2020-11-02 02:08:24 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:24 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:24 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:24 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:24 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:24 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-02 02:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:24 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:24 --> Total execution time: 0.2060
INFO - 2020-11-02 02:08:25 --> Config Class Initialized
INFO - 2020-11-02 02:08:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:25 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:25 --> URI Class Initialized
INFO - 2020-11-02 02:08:25 --> Router Class Initialized
INFO - 2020-11-02 02:08:25 --> Output Class Initialized
INFO - 2020-11-02 02:08:25 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:25 --> Input Class Initialized
INFO - 2020-11-02 02:08:25 --> Language Class Initialized
INFO - 2020-11-02 02:08:25 --> Language Class Initialized
INFO - 2020-11-02 02:08:25 --> Config Class Initialized
INFO - 2020-11-02 02:08:25 --> Loader Class Initialized
INFO - 2020-11-02 02:08:25 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:25 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:25 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:25 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:25 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-02 02:08:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:25 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:25 --> Total execution time: 0.2443
INFO - 2020-11-02 02:08:25 --> Config Class Initialized
INFO - 2020-11-02 02:08:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:25 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:25 --> URI Class Initialized
INFO - 2020-11-02 02:08:25 --> Router Class Initialized
INFO - 2020-11-02 02:08:25 --> Output Class Initialized
INFO - 2020-11-02 02:08:25 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:25 --> Input Class Initialized
INFO - 2020-11-02 02:08:25 --> Language Class Initialized
INFO - 2020-11-02 02:08:25 --> Language Class Initialized
INFO - 2020-11-02 02:08:25 --> Config Class Initialized
INFO - 2020-11-02 02:08:25 --> Loader Class Initialized
INFO - 2020-11-02 02:08:25 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:25 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:25 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:25 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:25 --> Controller Class Initialized
INFO - 2020-11-02 02:08:26 --> Config Class Initialized
INFO - 2020-11-02 02:08:26 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:26 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:26 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:26 --> URI Class Initialized
INFO - 2020-11-02 02:08:26 --> Router Class Initialized
INFO - 2020-11-02 02:08:26 --> Output Class Initialized
INFO - 2020-11-02 02:08:26 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:26 --> Input Class Initialized
INFO - 2020-11-02 02:08:26 --> Language Class Initialized
INFO - 2020-11-02 02:08:26 --> Language Class Initialized
INFO - 2020-11-02 02:08:26 --> Config Class Initialized
INFO - 2020-11-02 02:08:26 --> Loader Class Initialized
INFO - 2020-11-02 02:08:26 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:26 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:26 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:26 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:26 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:26 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-02 02:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:26 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:26 --> Total execution time: 0.2038
INFO - 2020-11-02 02:08:26 --> Config Class Initialized
INFO - 2020-11-02 02:08:26 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:26 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:26 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:26 --> URI Class Initialized
INFO - 2020-11-02 02:08:26 --> Router Class Initialized
INFO - 2020-11-02 02:08:26 --> Output Class Initialized
INFO - 2020-11-02 02:08:26 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:26 --> Input Class Initialized
INFO - 2020-11-02 02:08:26 --> Language Class Initialized
INFO - 2020-11-02 02:08:26 --> Language Class Initialized
INFO - 2020-11-02 02:08:26 --> Config Class Initialized
INFO - 2020-11-02 02:08:26 --> Loader Class Initialized
INFO - 2020-11-02 02:08:26 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:26 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:26 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:26 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:26 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:26 --> Controller Class Initialized
INFO - 2020-11-02 02:08:27 --> Config Class Initialized
INFO - 2020-11-02 02:08:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:27 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:27 --> URI Class Initialized
INFO - 2020-11-02 02:08:27 --> Router Class Initialized
INFO - 2020-11-02 02:08:27 --> Output Class Initialized
INFO - 2020-11-02 02:08:27 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:27 --> Input Class Initialized
INFO - 2020-11-02 02:08:27 --> Language Class Initialized
INFO - 2020-11-02 02:08:27 --> Language Class Initialized
INFO - 2020-11-02 02:08:27 --> Config Class Initialized
INFO - 2020-11-02 02:08:27 --> Loader Class Initialized
INFO - 2020-11-02 02:08:27 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:27 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:27 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:27 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:27 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:27 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-02 02:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:28 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:28 --> Total execution time: 0.3402
INFO - 2020-11-02 02:08:28 --> Config Class Initialized
INFO - 2020-11-02 02:08:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:28 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:28 --> URI Class Initialized
INFO - 2020-11-02 02:08:28 --> Router Class Initialized
INFO - 2020-11-02 02:08:28 --> Output Class Initialized
INFO - 2020-11-02 02:08:28 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:28 --> Input Class Initialized
INFO - 2020-11-02 02:08:28 --> Language Class Initialized
INFO - 2020-11-02 02:08:28 --> Language Class Initialized
INFO - 2020-11-02 02:08:28 --> Config Class Initialized
INFO - 2020-11-02 02:08:28 --> Loader Class Initialized
INFO - 2020-11-02 02:08:28 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:28 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:28 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:28 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:28 --> Controller Class Initialized
INFO - 2020-11-02 02:08:30 --> Config Class Initialized
INFO - 2020-11-02 02:08:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:30 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:30 --> URI Class Initialized
INFO - 2020-11-02 02:08:30 --> Router Class Initialized
INFO - 2020-11-02 02:08:30 --> Output Class Initialized
INFO - 2020-11-02 02:08:30 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:30 --> Input Class Initialized
INFO - 2020-11-02 02:08:30 --> Language Class Initialized
INFO - 2020-11-02 02:08:30 --> Language Class Initialized
INFO - 2020-11-02 02:08:30 --> Config Class Initialized
INFO - 2020-11-02 02:08:30 --> Loader Class Initialized
INFO - 2020-11-02 02:08:30 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:30 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:30 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:30 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:30 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-02 02:08:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:30 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:30 --> Total execution time: 0.2720
INFO - 2020-11-02 02:08:30 --> Config Class Initialized
INFO - 2020-11-02 02:08:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:30 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:30 --> URI Class Initialized
INFO - 2020-11-02 02:08:30 --> Router Class Initialized
INFO - 2020-11-02 02:08:30 --> Output Class Initialized
INFO - 2020-11-02 02:08:30 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:30 --> Input Class Initialized
INFO - 2020-11-02 02:08:30 --> Language Class Initialized
INFO - 2020-11-02 02:08:30 --> Language Class Initialized
INFO - 2020-11-02 02:08:30 --> Config Class Initialized
INFO - 2020-11-02 02:08:30 --> Loader Class Initialized
INFO - 2020-11-02 02:08:30 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:30 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:30 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:30 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:30 --> Controller Class Initialized
INFO - 2020-11-02 02:08:31 --> Config Class Initialized
INFO - 2020-11-02 02:08:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:31 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:31 --> URI Class Initialized
INFO - 2020-11-02 02:08:31 --> Router Class Initialized
INFO - 2020-11-02 02:08:31 --> Output Class Initialized
INFO - 2020-11-02 02:08:31 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:31 --> Input Class Initialized
INFO - 2020-11-02 02:08:31 --> Language Class Initialized
INFO - 2020-11-02 02:08:31 --> Language Class Initialized
INFO - 2020-11-02 02:08:31 --> Config Class Initialized
INFO - 2020-11-02 02:08:31 --> Loader Class Initialized
INFO - 2020-11-02 02:08:31 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:31 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:31 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:31 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:31 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-02 02:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:31 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:31 --> Total execution time: 0.2249
INFO - 2020-11-02 02:08:31 --> Config Class Initialized
INFO - 2020-11-02 02:08:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:31 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:31 --> URI Class Initialized
INFO - 2020-11-02 02:08:31 --> Router Class Initialized
INFO - 2020-11-02 02:08:31 --> Output Class Initialized
INFO - 2020-11-02 02:08:31 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:31 --> Input Class Initialized
INFO - 2020-11-02 02:08:31 --> Language Class Initialized
INFO - 2020-11-02 02:08:31 --> Language Class Initialized
INFO - 2020-11-02 02:08:31 --> Config Class Initialized
INFO - 2020-11-02 02:08:31 --> Loader Class Initialized
INFO - 2020-11-02 02:08:31 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:31 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:31 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:31 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:31 --> Controller Class Initialized
INFO - 2020-11-02 02:08:32 --> Config Class Initialized
INFO - 2020-11-02 02:08:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:32 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:32 --> URI Class Initialized
INFO - 2020-11-02 02:08:32 --> Router Class Initialized
INFO - 2020-11-02 02:08:32 --> Output Class Initialized
INFO - 2020-11-02 02:08:32 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:32 --> Input Class Initialized
INFO - 2020-11-02 02:08:32 --> Language Class Initialized
INFO - 2020-11-02 02:08:32 --> Language Class Initialized
INFO - 2020-11-02 02:08:32 --> Config Class Initialized
INFO - 2020-11-02 02:08:32 --> Loader Class Initialized
INFO - 2020-11-02 02:08:32 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:32 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:32 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:32 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:33 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-11-02 02:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:33 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:33 --> Total execution time: 0.3654
INFO - 2020-11-02 02:08:33 --> Config Class Initialized
INFO - 2020-11-02 02:08:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:33 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:33 --> URI Class Initialized
INFO - 2020-11-02 02:08:33 --> Router Class Initialized
INFO - 2020-11-02 02:08:33 --> Output Class Initialized
INFO - 2020-11-02 02:08:33 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:33 --> Input Class Initialized
INFO - 2020-11-02 02:08:33 --> Language Class Initialized
INFO - 2020-11-02 02:08:33 --> Language Class Initialized
INFO - 2020-11-02 02:08:33 --> Config Class Initialized
INFO - 2020-11-02 02:08:33 --> Loader Class Initialized
INFO - 2020-11-02 02:08:33 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:33 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:33 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:33 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:33 --> Controller Class Initialized
INFO - 2020-11-02 02:08:37 --> Config Class Initialized
INFO - 2020-11-02 02:08:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:37 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:37 --> URI Class Initialized
INFO - 2020-11-02 02:08:37 --> Router Class Initialized
INFO - 2020-11-02 02:08:37 --> Output Class Initialized
INFO - 2020-11-02 02:08:37 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:37 --> Input Class Initialized
INFO - 2020-11-02 02:08:37 --> Language Class Initialized
INFO - 2020-11-02 02:08:37 --> Language Class Initialized
INFO - 2020-11-02 02:08:37 --> Config Class Initialized
INFO - 2020-11-02 02:08:37 --> Loader Class Initialized
INFO - 2020-11-02 02:08:37 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:37 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:37 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:37 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:37 --> Controller Class Initialized
INFO - 2020-11-02 02:08:37 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:08:37 --> Config Class Initialized
INFO - 2020-11-02 02:08:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:37 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:37 --> URI Class Initialized
INFO - 2020-11-02 02:08:37 --> Router Class Initialized
INFO - 2020-11-02 02:08:37 --> Output Class Initialized
INFO - 2020-11-02 02:08:37 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:37 --> Input Class Initialized
INFO - 2020-11-02 02:08:37 --> Language Class Initialized
INFO - 2020-11-02 02:08:37 --> Language Class Initialized
INFO - 2020-11-02 02:08:37 --> Config Class Initialized
INFO - 2020-11-02 02:08:37 --> Loader Class Initialized
INFO - 2020-11-02 02:08:37 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:37 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:37 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:37 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:37 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 02:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:37 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:37 --> Total execution time: 0.2156
INFO - 2020-11-02 02:08:47 --> Config Class Initialized
INFO - 2020-11-02 02:08:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:47 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:47 --> URI Class Initialized
INFO - 2020-11-02 02:08:47 --> Router Class Initialized
INFO - 2020-11-02 02:08:47 --> Output Class Initialized
INFO - 2020-11-02 02:08:47 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:47 --> Input Class Initialized
INFO - 2020-11-02 02:08:47 --> Language Class Initialized
INFO - 2020-11-02 02:08:47 --> Language Class Initialized
INFO - 2020-11-02 02:08:47 --> Config Class Initialized
INFO - 2020-11-02 02:08:47 --> Loader Class Initialized
INFO - 2020-11-02 02:08:47 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:47 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:47 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:47 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:48 --> Controller Class Initialized
INFO - 2020-11-02 02:08:48 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:08:48 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:48 --> Total execution time: 0.2350
INFO - 2020-11-02 02:08:49 --> Config Class Initialized
INFO - 2020-11-02 02:08:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:49 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:49 --> URI Class Initialized
INFO - 2020-11-02 02:08:49 --> Router Class Initialized
INFO - 2020-11-02 02:08:49 --> Output Class Initialized
INFO - 2020-11-02 02:08:49 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:49 --> Input Class Initialized
INFO - 2020-11-02 02:08:49 --> Language Class Initialized
INFO - 2020-11-02 02:08:49 --> Language Class Initialized
INFO - 2020-11-02 02:08:49 --> Config Class Initialized
INFO - 2020-11-02 02:08:49 --> Loader Class Initialized
INFO - 2020-11-02 02:08:49 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:49 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:49 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:49 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:49 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:49 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 02:08:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:49 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:49 --> Total execution time: 0.2776
INFO - 2020-11-02 02:08:54 --> Config Class Initialized
INFO - 2020-11-02 02:08:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:08:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:08:54 --> Utf8 Class Initialized
INFO - 2020-11-02 02:08:54 --> URI Class Initialized
INFO - 2020-11-02 02:08:54 --> Router Class Initialized
INFO - 2020-11-02 02:08:54 --> Output Class Initialized
INFO - 2020-11-02 02:08:54 --> Security Class Initialized
DEBUG - 2020-11-02 02:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:08:54 --> Input Class Initialized
INFO - 2020-11-02 02:08:54 --> Language Class Initialized
INFO - 2020-11-02 02:08:54 --> Language Class Initialized
INFO - 2020-11-02 02:08:54 --> Config Class Initialized
INFO - 2020-11-02 02:08:54 --> Loader Class Initialized
INFO - 2020-11-02 02:08:54 --> Helper loaded: url_helper
INFO - 2020-11-02 02:08:54 --> Helper loaded: file_helper
INFO - 2020-11-02 02:08:54 --> Helper loaded: form_helper
INFO - 2020-11-02 02:08:54 --> Helper loaded: my_helper
INFO - 2020-11-02 02:08:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:08:54 --> Controller Class Initialized
DEBUG - 2020-11-02 02:08:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:08:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:08:54 --> Final output sent to browser
DEBUG - 2020-11-02 02:08:54 --> Total execution time: 0.3311
INFO - 2020-11-02 02:09:04 --> Config Class Initialized
INFO - 2020-11-02 02:09:04 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:04 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:04 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:04 --> URI Class Initialized
INFO - 2020-11-02 02:09:04 --> Router Class Initialized
INFO - 2020-11-02 02:09:04 --> Output Class Initialized
INFO - 2020-11-02 02:09:04 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:04 --> Input Class Initialized
INFO - 2020-11-02 02:09:04 --> Language Class Initialized
INFO - 2020-11-02 02:09:04 --> Language Class Initialized
INFO - 2020-11-02 02:09:04 --> Config Class Initialized
INFO - 2020-11-02 02:09:04 --> Loader Class Initialized
INFO - 2020-11-02 02:09:04 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:04 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:04 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:04 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:04 --> Controller Class Initialized
DEBUG - 2020-11-02 02:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-02 02:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:09:04 --> Final output sent to browser
DEBUG - 2020-11-02 02:09:04 --> Total execution time: 0.2795
INFO - 2020-11-02 02:09:11 --> Config Class Initialized
INFO - 2020-11-02 02:09:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:11 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:11 --> URI Class Initialized
INFO - 2020-11-02 02:09:11 --> Router Class Initialized
INFO - 2020-11-02 02:09:11 --> Output Class Initialized
INFO - 2020-11-02 02:09:11 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:11 --> Input Class Initialized
INFO - 2020-11-02 02:09:11 --> Language Class Initialized
INFO - 2020-11-02 02:09:11 --> Language Class Initialized
INFO - 2020-11-02 02:09:11 --> Config Class Initialized
INFO - 2020-11-02 02:09:11 --> Loader Class Initialized
INFO - 2020-11-02 02:09:11 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:11 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:11 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:11 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:11 --> Controller Class Initialized
INFO - 2020-11-02 02:09:11 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:09:11 --> Config Class Initialized
INFO - 2020-11-02 02:09:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:11 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:11 --> URI Class Initialized
INFO - 2020-11-02 02:09:11 --> Router Class Initialized
INFO - 2020-11-02 02:09:11 --> Output Class Initialized
INFO - 2020-11-02 02:09:11 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:11 --> Input Class Initialized
INFO - 2020-11-02 02:09:11 --> Language Class Initialized
INFO - 2020-11-02 02:09:11 --> Language Class Initialized
INFO - 2020-11-02 02:09:11 --> Config Class Initialized
INFO - 2020-11-02 02:09:11 --> Loader Class Initialized
INFO - 2020-11-02 02:09:11 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:11 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:11 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:11 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:11 --> Controller Class Initialized
DEBUG - 2020-11-02 02:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 02:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:09:11 --> Final output sent to browser
DEBUG - 2020-11-02 02:09:11 --> Total execution time: 0.2183
INFO - 2020-11-02 02:09:17 --> Config Class Initialized
INFO - 2020-11-02 02:09:17 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:17 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:17 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:17 --> URI Class Initialized
INFO - 2020-11-02 02:09:17 --> Router Class Initialized
INFO - 2020-11-02 02:09:17 --> Output Class Initialized
INFO - 2020-11-02 02:09:17 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:17 --> Input Class Initialized
INFO - 2020-11-02 02:09:17 --> Language Class Initialized
INFO - 2020-11-02 02:09:17 --> Language Class Initialized
INFO - 2020-11-02 02:09:17 --> Config Class Initialized
INFO - 2020-11-02 02:09:17 --> Loader Class Initialized
INFO - 2020-11-02 02:09:17 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:17 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:17 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:17 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:17 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:17 --> Controller Class Initialized
INFO - 2020-11-02 02:09:17 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:09:17 --> Final output sent to browser
DEBUG - 2020-11-02 02:09:17 --> Total execution time: 0.2055
INFO - 2020-11-02 02:09:18 --> Config Class Initialized
INFO - 2020-11-02 02:09:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:18 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:18 --> URI Class Initialized
INFO - 2020-11-02 02:09:18 --> Router Class Initialized
INFO - 2020-11-02 02:09:18 --> Output Class Initialized
INFO - 2020-11-02 02:09:18 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:18 --> Input Class Initialized
INFO - 2020-11-02 02:09:18 --> Language Class Initialized
INFO - 2020-11-02 02:09:18 --> Language Class Initialized
INFO - 2020-11-02 02:09:18 --> Config Class Initialized
INFO - 2020-11-02 02:09:18 --> Loader Class Initialized
INFO - 2020-11-02 02:09:18 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:18 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:18 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:18 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:18 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:18 --> Controller Class Initialized
DEBUG - 2020-11-02 02:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 02:09:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:09:19 --> Final output sent to browser
DEBUG - 2020-11-02 02:09:19 --> Total execution time: 0.2468
INFO - 2020-11-02 02:09:25 --> Config Class Initialized
INFO - 2020-11-02 02:09:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:25 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:25 --> URI Class Initialized
INFO - 2020-11-02 02:09:25 --> Router Class Initialized
INFO - 2020-11-02 02:09:25 --> Output Class Initialized
INFO - 2020-11-02 02:09:25 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:25 --> Input Class Initialized
INFO - 2020-11-02 02:09:25 --> Language Class Initialized
INFO - 2020-11-02 02:09:25 --> Language Class Initialized
INFO - 2020-11-02 02:09:25 --> Config Class Initialized
INFO - 2020-11-02 02:09:25 --> Loader Class Initialized
INFO - 2020-11-02 02:09:25 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:25 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:25 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:25 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:25 --> Controller Class Initialized
DEBUG - 2020-11-02 02:09:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:09:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:09:25 --> Final output sent to browser
DEBUG - 2020-11-02 02:09:25 --> Total execution time: 0.2135
INFO - 2020-11-02 02:09:25 --> Config Class Initialized
INFO - 2020-11-02 02:09:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:25 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:25 --> URI Class Initialized
INFO - 2020-11-02 02:09:25 --> Router Class Initialized
INFO - 2020-11-02 02:09:25 --> Output Class Initialized
INFO - 2020-11-02 02:09:25 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:25 --> Input Class Initialized
INFO - 2020-11-02 02:09:25 --> Language Class Initialized
INFO - 2020-11-02 02:09:25 --> Language Class Initialized
INFO - 2020-11-02 02:09:25 --> Config Class Initialized
INFO - 2020-11-02 02:09:25 --> Loader Class Initialized
INFO - 2020-11-02 02:09:25 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:25 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:25 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:25 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:25 --> Controller Class Initialized
INFO - 2020-11-02 02:09:49 --> Config Class Initialized
INFO - 2020-11-02 02:09:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:49 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:49 --> URI Class Initialized
INFO - 2020-11-02 02:09:49 --> Router Class Initialized
INFO - 2020-11-02 02:09:49 --> Output Class Initialized
INFO - 2020-11-02 02:09:49 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:49 --> Input Class Initialized
INFO - 2020-11-02 02:09:49 --> Language Class Initialized
INFO - 2020-11-02 02:09:49 --> Language Class Initialized
INFO - 2020-11-02 02:09:49 --> Config Class Initialized
INFO - 2020-11-02 02:09:49 --> Loader Class Initialized
INFO - 2020-11-02 02:09:49 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:49 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:49 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:49 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:49 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:49 --> Controller Class Initialized
DEBUG - 2020-11-02 02:09:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-11-02 02:09:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:09:49 --> Final output sent to browser
DEBUG - 2020-11-02 02:09:49 --> Total execution time: 0.2071
INFO - 2020-11-02 02:09:49 --> Config Class Initialized
INFO - 2020-11-02 02:09:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:09:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:09:49 --> Utf8 Class Initialized
INFO - 2020-11-02 02:09:49 --> URI Class Initialized
INFO - 2020-11-02 02:09:49 --> Router Class Initialized
INFO - 2020-11-02 02:09:49 --> Output Class Initialized
INFO - 2020-11-02 02:09:49 --> Security Class Initialized
DEBUG - 2020-11-02 02:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:09:49 --> Input Class Initialized
INFO - 2020-11-02 02:09:49 --> Language Class Initialized
INFO - 2020-11-02 02:09:49 --> Language Class Initialized
INFO - 2020-11-02 02:09:49 --> Config Class Initialized
INFO - 2020-11-02 02:09:49 --> Loader Class Initialized
INFO - 2020-11-02 02:09:49 --> Helper loaded: url_helper
INFO - 2020-11-02 02:09:49 --> Helper loaded: file_helper
INFO - 2020-11-02 02:09:49 --> Helper loaded: form_helper
INFO - 2020-11-02 02:09:49 --> Helper loaded: my_helper
INFO - 2020-11-02 02:09:49 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:09:49 --> Controller Class Initialized
INFO - 2020-11-02 02:10:03 --> Config Class Initialized
INFO - 2020-11-02 02:10:03 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:10:03 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:10:03 --> Utf8 Class Initialized
INFO - 2020-11-02 02:10:03 --> URI Class Initialized
INFO - 2020-11-02 02:10:03 --> Router Class Initialized
INFO - 2020-11-02 02:10:03 --> Output Class Initialized
INFO - 2020-11-02 02:10:03 --> Security Class Initialized
DEBUG - 2020-11-02 02:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:10:03 --> Input Class Initialized
INFO - 2020-11-02 02:10:03 --> Language Class Initialized
INFO - 2020-11-02 02:10:03 --> Language Class Initialized
INFO - 2020-11-02 02:10:03 --> Config Class Initialized
INFO - 2020-11-02 02:10:04 --> Loader Class Initialized
INFO - 2020-11-02 02:10:04 --> Helper loaded: url_helper
INFO - 2020-11-02 02:10:04 --> Helper loaded: file_helper
INFO - 2020-11-02 02:10:04 --> Helper loaded: form_helper
INFO - 2020-11-02 02:10:04 --> Helper loaded: my_helper
INFO - 2020-11-02 02:10:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:10:04 --> Controller Class Initialized
INFO - 2020-11-02 02:10:16 --> Config Class Initialized
INFO - 2020-11-02 02:10:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:10:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:10:16 --> Utf8 Class Initialized
INFO - 2020-11-02 02:10:16 --> URI Class Initialized
INFO - 2020-11-02 02:10:16 --> Router Class Initialized
INFO - 2020-11-02 02:10:16 --> Output Class Initialized
INFO - 2020-11-02 02:10:16 --> Security Class Initialized
DEBUG - 2020-11-02 02:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:10:16 --> Input Class Initialized
INFO - 2020-11-02 02:10:16 --> Language Class Initialized
INFO - 2020-11-02 02:10:16 --> Language Class Initialized
INFO - 2020-11-02 02:10:16 --> Config Class Initialized
INFO - 2020-11-02 02:10:16 --> Loader Class Initialized
INFO - 2020-11-02 02:10:16 --> Helper loaded: url_helper
INFO - 2020-11-02 02:10:16 --> Helper loaded: file_helper
INFO - 2020-11-02 02:10:16 --> Helper loaded: form_helper
INFO - 2020-11-02 02:10:16 --> Helper loaded: my_helper
INFO - 2020-11-02 02:10:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:10:16 --> Controller Class Initialized
INFO - 2020-11-02 02:10:25 --> Config Class Initialized
INFO - 2020-11-02 02:10:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:10:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:10:25 --> Utf8 Class Initialized
INFO - 2020-11-02 02:10:25 --> URI Class Initialized
INFO - 2020-11-02 02:10:25 --> Router Class Initialized
INFO - 2020-11-02 02:10:25 --> Output Class Initialized
INFO - 2020-11-02 02:10:25 --> Security Class Initialized
DEBUG - 2020-11-02 02:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:10:26 --> Input Class Initialized
INFO - 2020-11-02 02:10:26 --> Language Class Initialized
INFO - 2020-11-02 02:10:26 --> Language Class Initialized
INFO - 2020-11-02 02:10:26 --> Config Class Initialized
INFO - 2020-11-02 02:10:26 --> Loader Class Initialized
INFO - 2020-11-02 02:10:26 --> Helper loaded: url_helper
INFO - 2020-11-02 02:10:26 --> Helper loaded: file_helper
INFO - 2020-11-02 02:10:26 --> Helper loaded: form_helper
INFO - 2020-11-02 02:10:26 --> Helper loaded: my_helper
INFO - 2020-11-02 02:10:26 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:10:26 --> Controller Class Initialized
INFO - 2020-11-02 02:10:28 --> Config Class Initialized
INFO - 2020-11-02 02:10:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:10:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:10:28 --> Utf8 Class Initialized
INFO - 2020-11-02 02:10:28 --> URI Class Initialized
INFO - 2020-11-02 02:10:28 --> Router Class Initialized
INFO - 2020-11-02 02:10:28 --> Output Class Initialized
INFO - 2020-11-02 02:10:28 --> Security Class Initialized
DEBUG - 2020-11-02 02:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:10:28 --> Input Class Initialized
INFO - 2020-11-02 02:10:28 --> Language Class Initialized
INFO - 2020-11-02 02:10:28 --> Language Class Initialized
INFO - 2020-11-02 02:10:28 --> Config Class Initialized
INFO - 2020-11-02 02:10:28 --> Loader Class Initialized
INFO - 2020-11-02 02:10:28 --> Helper loaded: url_helper
INFO - 2020-11-02 02:10:28 --> Helper loaded: file_helper
INFO - 2020-11-02 02:10:28 --> Helper loaded: form_helper
INFO - 2020-11-02 02:10:28 --> Helper loaded: my_helper
INFO - 2020-11-02 02:10:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:10:28 --> Controller Class Initialized
INFO - 2020-11-02 02:10:52 --> Config Class Initialized
INFO - 2020-11-02 02:10:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:10:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:10:52 --> Utf8 Class Initialized
INFO - 2020-11-02 02:10:52 --> URI Class Initialized
INFO - 2020-11-02 02:10:52 --> Router Class Initialized
INFO - 2020-11-02 02:10:52 --> Output Class Initialized
INFO - 2020-11-02 02:10:52 --> Security Class Initialized
DEBUG - 2020-11-02 02:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:10:52 --> Input Class Initialized
INFO - 2020-11-02 02:10:52 --> Language Class Initialized
INFO - 2020-11-02 02:10:52 --> Language Class Initialized
INFO - 2020-11-02 02:10:52 --> Config Class Initialized
INFO - 2020-11-02 02:10:52 --> Loader Class Initialized
INFO - 2020-11-02 02:10:52 --> Helper loaded: url_helper
INFO - 2020-11-02 02:10:52 --> Helper loaded: file_helper
INFO - 2020-11-02 02:10:52 --> Helper loaded: form_helper
INFO - 2020-11-02 02:10:52 --> Helper loaded: my_helper
INFO - 2020-11-02 02:10:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:10:52 --> Controller Class Initialized
DEBUG - 2020-11-02 02:10:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-11-02 02:10:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:10:52 --> Final output sent to browser
DEBUG - 2020-11-02 02:10:52 --> Total execution time: 0.2598
INFO - 2020-11-02 02:10:52 --> Config Class Initialized
INFO - 2020-11-02 02:10:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:10:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:10:52 --> Utf8 Class Initialized
INFO - 2020-11-02 02:10:52 --> URI Class Initialized
INFO - 2020-11-02 02:10:52 --> Router Class Initialized
INFO - 2020-11-02 02:10:52 --> Output Class Initialized
INFO - 2020-11-02 02:10:52 --> Security Class Initialized
DEBUG - 2020-11-02 02:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:10:52 --> Input Class Initialized
INFO - 2020-11-02 02:10:52 --> Language Class Initialized
INFO - 2020-11-02 02:10:52 --> Language Class Initialized
INFO - 2020-11-02 02:10:52 --> Config Class Initialized
INFO - 2020-11-02 02:10:52 --> Loader Class Initialized
INFO - 2020-11-02 02:10:52 --> Helper loaded: url_helper
INFO - 2020-11-02 02:10:52 --> Helper loaded: file_helper
INFO - 2020-11-02 02:10:52 --> Helper loaded: form_helper
INFO - 2020-11-02 02:10:52 --> Helper loaded: my_helper
INFO - 2020-11-02 02:10:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:10:52 --> Controller Class Initialized
INFO - 2020-11-02 02:11:02 --> Config Class Initialized
INFO - 2020-11-02 02:11:02 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:02 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:02 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:02 --> URI Class Initialized
INFO - 2020-11-02 02:11:02 --> Router Class Initialized
INFO - 2020-11-02 02:11:02 --> Output Class Initialized
INFO - 2020-11-02 02:11:02 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:02 --> Input Class Initialized
INFO - 2020-11-02 02:11:02 --> Language Class Initialized
INFO - 2020-11-02 02:11:02 --> Language Class Initialized
INFO - 2020-11-02 02:11:02 --> Config Class Initialized
INFO - 2020-11-02 02:11:02 --> Loader Class Initialized
INFO - 2020-11-02 02:11:02 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:02 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:02 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:02 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:02 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:02 --> Controller Class Initialized
INFO - 2020-11-02 02:11:02 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:11:02 --> Config Class Initialized
INFO - 2020-11-02 02:11:02 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:02 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:02 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:02 --> URI Class Initialized
INFO - 2020-11-02 02:11:02 --> Router Class Initialized
INFO - 2020-11-02 02:11:02 --> Output Class Initialized
INFO - 2020-11-02 02:11:02 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:02 --> Input Class Initialized
INFO - 2020-11-02 02:11:02 --> Language Class Initialized
INFO - 2020-11-02 02:11:02 --> Language Class Initialized
INFO - 2020-11-02 02:11:02 --> Config Class Initialized
INFO - 2020-11-02 02:11:02 --> Loader Class Initialized
INFO - 2020-11-02 02:11:02 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:02 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:02 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:02 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:02 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:02 --> Controller Class Initialized
DEBUG - 2020-11-02 02:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 02:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:11:02 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:02 --> Total execution time: 0.2121
INFO - 2020-11-02 02:11:07 --> Config Class Initialized
INFO - 2020-11-02 02:11:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:07 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:07 --> URI Class Initialized
INFO - 2020-11-02 02:11:07 --> Router Class Initialized
INFO - 2020-11-02 02:11:07 --> Output Class Initialized
INFO - 2020-11-02 02:11:07 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:07 --> Input Class Initialized
INFO - 2020-11-02 02:11:07 --> Language Class Initialized
INFO - 2020-11-02 02:11:07 --> Language Class Initialized
INFO - 2020-11-02 02:11:07 --> Config Class Initialized
INFO - 2020-11-02 02:11:07 --> Loader Class Initialized
INFO - 2020-11-02 02:11:07 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:07 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:07 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:07 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:07 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:07 --> Controller Class Initialized
INFO - 2020-11-02 02:11:07 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:11:07 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:07 --> Total execution time: 0.2207
INFO - 2020-11-02 02:11:08 --> Config Class Initialized
INFO - 2020-11-02 02:11:08 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:08 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:08 --> URI Class Initialized
INFO - 2020-11-02 02:11:08 --> Router Class Initialized
INFO - 2020-11-02 02:11:08 --> Output Class Initialized
INFO - 2020-11-02 02:11:08 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:08 --> Input Class Initialized
INFO - 2020-11-02 02:11:08 --> Language Class Initialized
INFO - 2020-11-02 02:11:08 --> Language Class Initialized
INFO - 2020-11-02 02:11:08 --> Config Class Initialized
INFO - 2020-11-02 02:11:08 --> Loader Class Initialized
INFO - 2020-11-02 02:11:08 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:08 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:08 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:08 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:08 --> Controller Class Initialized
DEBUG - 2020-11-02 02:11:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 02:11:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:11:09 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:09 --> Total execution time: 0.2574
INFO - 2020-11-02 02:11:14 --> Config Class Initialized
INFO - 2020-11-02 02:11:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:14 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:14 --> URI Class Initialized
INFO - 2020-11-02 02:11:14 --> Router Class Initialized
INFO - 2020-11-02 02:11:14 --> Output Class Initialized
INFO - 2020-11-02 02:11:14 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:14 --> Input Class Initialized
INFO - 2020-11-02 02:11:14 --> Language Class Initialized
INFO - 2020-11-02 02:11:14 --> Language Class Initialized
INFO - 2020-11-02 02:11:14 --> Config Class Initialized
INFO - 2020-11-02 02:11:14 --> Loader Class Initialized
INFO - 2020-11-02 02:11:14 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:14 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:14 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:14 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:14 --> Controller Class Initialized
DEBUG - 2020-11-02 02:11:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:11:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:11:14 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:14 --> Total execution time: 0.2268
INFO - 2020-11-02 02:11:16 --> Config Class Initialized
INFO - 2020-11-02 02:11:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:16 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:16 --> URI Class Initialized
INFO - 2020-11-02 02:11:16 --> Router Class Initialized
INFO - 2020-11-02 02:11:16 --> Output Class Initialized
INFO - 2020-11-02 02:11:16 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:16 --> Input Class Initialized
INFO - 2020-11-02 02:11:16 --> Language Class Initialized
INFO - 2020-11-02 02:11:16 --> Language Class Initialized
INFO - 2020-11-02 02:11:16 --> Config Class Initialized
INFO - 2020-11-02 02:11:16 --> Loader Class Initialized
INFO - 2020-11-02 02:11:16 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:16 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:16 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:16 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:16 --> Controller Class Initialized
DEBUG - 2020-11-02 02:11:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:11:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:11:16 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:16 --> Total execution time: 0.2602
INFO - 2020-11-02 02:11:16 --> Config Class Initialized
INFO - 2020-11-02 02:11:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:16 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:16 --> URI Class Initialized
INFO - 2020-11-02 02:11:16 --> Router Class Initialized
INFO - 2020-11-02 02:11:16 --> Output Class Initialized
INFO - 2020-11-02 02:11:16 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:16 --> Input Class Initialized
INFO - 2020-11-02 02:11:16 --> Language Class Initialized
INFO - 2020-11-02 02:11:16 --> Language Class Initialized
INFO - 2020-11-02 02:11:16 --> Config Class Initialized
INFO - 2020-11-02 02:11:16 --> Loader Class Initialized
INFO - 2020-11-02 02:11:16 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:16 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:16 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:16 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:16 --> Controller Class Initialized
INFO - 2020-11-02 02:11:18 --> Config Class Initialized
INFO - 2020-11-02 02:11:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:18 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:18 --> URI Class Initialized
INFO - 2020-11-02 02:11:18 --> Router Class Initialized
INFO - 2020-11-02 02:11:18 --> Output Class Initialized
INFO - 2020-11-02 02:11:18 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:18 --> Input Class Initialized
INFO - 2020-11-02 02:11:18 --> Language Class Initialized
INFO - 2020-11-02 02:11:18 --> Language Class Initialized
INFO - 2020-11-02 02:11:18 --> Config Class Initialized
INFO - 2020-11-02 02:11:18 --> Loader Class Initialized
INFO - 2020-11-02 02:11:18 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:18 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:18 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:18 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:18 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:18 --> Controller Class Initialized
INFO - 2020-11-02 02:11:18 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:18 --> Total execution time: 0.2567
INFO - 2020-11-02 02:11:36 --> Config Class Initialized
INFO - 2020-11-02 02:11:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:36 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:36 --> URI Class Initialized
INFO - 2020-11-02 02:11:36 --> Router Class Initialized
INFO - 2020-11-02 02:11:36 --> Output Class Initialized
INFO - 2020-11-02 02:11:36 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:36 --> Input Class Initialized
INFO - 2020-11-02 02:11:36 --> Language Class Initialized
INFO - 2020-11-02 02:11:36 --> Language Class Initialized
INFO - 2020-11-02 02:11:36 --> Config Class Initialized
INFO - 2020-11-02 02:11:36 --> Loader Class Initialized
INFO - 2020-11-02 02:11:36 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:36 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:36 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:36 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:36 --> Controller Class Initialized
INFO - 2020-11-02 02:11:36 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:36 --> Total execution time: 0.2481
INFO - 2020-11-02 02:11:36 --> Config Class Initialized
INFO - 2020-11-02 02:11:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:36 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:36 --> URI Class Initialized
INFO - 2020-11-02 02:11:36 --> Router Class Initialized
INFO - 2020-11-02 02:11:36 --> Output Class Initialized
INFO - 2020-11-02 02:11:36 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:36 --> Input Class Initialized
INFO - 2020-11-02 02:11:36 --> Language Class Initialized
INFO - 2020-11-02 02:11:36 --> Language Class Initialized
INFO - 2020-11-02 02:11:36 --> Config Class Initialized
INFO - 2020-11-02 02:11:36 --> Loader Class Initialized
INFO - 2020-11-02 02:11:36 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:36 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:36 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:36 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:36 --> Controller Class Initialized
INFO - 2020-11-02 02:11:39 --> Config Class Initialized
INFO - 2020-11-02 02:11:39 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:39 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:39 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:39 --> URI Class Initialized
INFO - 2020-11-02 02:11:39 --> Router Class Initialized
INFO - 2020-11-02 02:11:39 --> Output Class Initialized
INFO - 2020-11-02 02:11:39 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:39 --> Input Class Initialized
INFO - 2020-11-02 02:11:39 --> Language Class Initialized
INFO - 2020-11-02 02:11:39 --> Language Class Initialized
INFO - 2020-11-02 02:11:39 --> Config Class Initialized
INFO - 2020-11-02 02:11:39 --> Loader Class Initialized
INFO - 2020-11-02 02:11:39 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:39 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:39 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:39 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:39 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:39 --> Controller Class Initialized
INFO - 2020-11-02 02:11:39 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:39 --> Total execution time: 0.1969
INFO - 2020-11-02 02:11:42 --> Config Class Initialized
INFO - 2020-11-02 02:11:42 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:42 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:42 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:42 --> URI Class Initialized
INFO - 2020-11-02 02:11:42 --> Router Class Initialized
INFO - 2020-11-02 02:11:42 --> Output Class Initialized
INFO - 2020-11-02 02:11:42 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:42 --> Input Class Initialized
INFO - 2020-11-02 02:11:42 --> Language Class Initialized
INFO - 2020-11-02 02:11:42 --> Language Class Initialized
INFO - 2020-11-02 02:11:42 --> Config Class Initialized
INFO - 2020-11-02 02:11:42 --> Loader Class Initialized
INFO - 2020-11-02 02:11:42 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:42 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:42 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:42 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:42 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:42 --> Controller Class Initialized
INFO - 2020-11-02 02:11:42 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:42 --> Total execution time: 0.2428
INFO - 2020-11-02 02:11:46 --> Config Class Initialized
INFO - 2020-11-02 02:11:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:46 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:46 --> URI Class Initialized
INFO - 2020-11-02 02:11:46 --> Router Class Initialized
INFO - 2020-11-02 02:11:46 --> Output Class Initialized
INFO - 2020-11-02 02:11:46 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:46 --> Input Class Initialized
INFO - 2020-11-02 02:11:46 --> Language Class Initialized
INFO - 2020-11-02 02:11:46 --> Language Class Initialized
INFO - 2020-11-02 02:11:46 --> Config Class Initialized
INFO - 2020-11-02 02:11:46 --> Loader Class Initialized
INFO - 2020-11-02 02:11:46 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:46 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:46 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:46 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:46 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:46 --> Controller Class Initialized
ERROR - 2020-11-02 02:11:46 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 857
INFO - 2020-11-02 02:11:47 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:47 --> Total execution time: 0.2965
INFO - 2020-11-02 02:11:59 --> Config Class Initialized
INFO - 2020-11-02 02:11:59 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:59 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:59 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:59 --> URI Class Initialized
INFO - 2020-11-02 02:11:59 --> Router Class Initialized
INFO - 2020-11-02 02:11:59 --> Output Class Initialized
INFO - 2020-11-02 02:11:59 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:59 --> Input Class Initialized
INFO - 2020-11-02 02:11:59 --> Language Class Initialized
INFO - 2020-11-02 02:11:59 --> Language Class Initialized
INFO - 2020-11-02 02:11:59 --> Config Class Initialized
INFO - 2020-11-02 02:11:59 --> Loader Class Initialized
INFO - 2020-11-02 02:11:59 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:59 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:59 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:59 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:59 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:59 --> Controller Class Initialized
DEBUG - 2020-11-02 02:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:11:59 --> Final output sent to browser
DEBUG - 2020-11-02 02:11:59 --> Total execution time: 0.2417
INFO - 2020-11-02 02:11:59 --> Config Class Initialized
INFO - 2020-11-02 02:11:59 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:11:59 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:11:59 --> Utf8 Class Initialized
INFO - 2020-11-02 02:11:59 --> URI Class Initialized
INFO - 2020-11-02 02:11:59 --> Router Class Initialized
INFO - 2020-11-02 02:11:59 --> Output Class Initialized
INFO - 2020-11-02 02:11:59 --> Security Class Initialized
DEBUG - 2020-11-02 02:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:11:59 --> Input Class Initialized
INFO - 2020-11-02 02:11:59 --> Language Class Initialized
INFO - 2020-11-02 02:11:59 --> Language Class Initialized
INFO - 2020-11-02 02:11:59 --> Config Class Initialized
INFO - 2020-11-02 02:11:59 --> Loader Class Initialized
INFO - 2020-11-02 02:11:59 --> Helper loaded: url_helper
INFO - 2020-11-02 02:11:59 --> Helper loaded: file_helper
INFO - 2020-11-02 02:11:59 --> Helper loaded: form_helper
INFO - 2020-11-02 02:11:59 --> Helper loaded: my_helper
INFO - 2020-11-02 02:11:59 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:11:59 --> Controller Class Initialized
INFO - 2020-11-02 02:12:01 --> Config Class Initialized
INFO - 2020-11-02 02:12:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:01 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:01 --> URI Class Initialized
INFO - 2020-11-02 02:12:01 --> Router Class Initialized
INFO - 2020-11-02 02:12:01 --> Output Class Initialized
INFO - 2020-11-02 02:12:01 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:01 --> Input Class Initialized
INFO - 2020-11-02 02:12:01 --> Language Class Initialized
INFO - 2020-11-02 02:12:01 --> Language Class Initialized
INFO - 2020-11-02 02:12:01 --> Config Class Initialized
INFO - 2020-11-02 02:12:01 --> Loader Class Initialized
INFO - 2020-11-02 02:12:01 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:01 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:01 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:01 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:01 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:01 --> Controller Class Initialized
INFO - 2020-11-02 02:12:01 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:01 --> Total execution time: 0.2068
INFO - 2020-11-02 02:12:05 --> Config Class Initialized
INFO - 2020-11-02 02:12:05 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:05 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:05 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:05 --> URI Class Initialized
INFO - 2020-11-02 02:12:05 --> Router Class Initialized
INFO - 2020-11-02 02:12:05 --> Output Class Initialized
INFO - 2020-11-02 02:12:05 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:05 --> Input Class Initialized
INFO - 2020-11-02 02:12:05 --> Language Class Initialized
INFO - 2020-11-02 02:12:05 --> Language Class Initialized
INFO - 2020-11-02 02:12:05 --> Config Class Initialized
INFO - 2020-11-02 02:12:05 --> Loader Class Initialized
INFO - 2020-11-02 02:12:05 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:05 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:05 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:05 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:05 --> Controller Class Initialized
INFO - 2020-11-02 02:12:05 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:05 --> Total execution time: 0.2527
INFO - 2020-11-02 02:12:08 --> Config Class Initialized
INFO - 2020-11-02 02:12:08 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:08 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:08 --> URI Class Initialized
INFO - 2020-11-02 02:12:08 --> Router Class Initialized
INFO - 2020-11-02 02:12:08 --> Output Class Initialized
INFO - 2020-11-02 02:12:08 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:08 --> Input Class Initialized
INFO - 2020-11-02 02:12:08 --> Language Class Initialized
INFO - 2020-11-02 02:12:08 --> Language Class Initialized
INFO - 2020-11-02 02:12:08 --> Config Class Initialized
INFO - 2020-11-02 02:12:08 --> Loader Class Initialized
INFO - 2020-11-02 02:12:08 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:08 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:08 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:08 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:09 --> Controller Class Initialized
DEBUG - 2020-11-02 02:12:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:12:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:12:09 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:09 --> Total execution time: 0.2399
INFO - 2020-11-02 02:12:09 --> Config Class Initialized
INFO - 2020-11-02 02:12:09 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:09 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:09 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:09 --> URI Class Initialized
INFO - 2020-11-02 02:12:09 --> Router Class Initialized
INFO - 2020-11-02 02:12:09 --> Output Class Initialized
INFO - 2020-11-02 02:12:09 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:09 --> Input Class Initialized
INFO - 2020-11-02 02:12:09 --> Language Class Initialized
INFO - 2020-11-02 02:12:09 --> Language Class Initialized
INFO - 2020-11-02 02:12:09 --> Config Class Initialized
INFO - 2020-11-02 02:12:09 --> Loader Class Initialized
INFO - 2020-11-02 02:12:09 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:09 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:09 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:09 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:09 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:09 --> Controller Class Initialized
INFO - 2020-11-02 02:12:10 --> Config Class Initialized
INFO - 2020-11-02 02:12:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:10 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:10 --> URI Class Initialized
INFO - 2020-11-02 02:12:10 --> Router Class Initialized
INFO - 2020-11-02 02:12:10 --> Output Class Initialized
INFO - 2020-11-02 02:12:10 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:10 --> Input Class Initialized
INFO - 2020-11-02 02:12:10 --> Language Class Initialized
INFO - 2020-11-02 02:12:10 --> Language Class Initialized
INFO - 2020-11-02 02:12:10 --> Config Class Initialized
INFO - 2020-11-02 02:12:10 --> Loader Class Initialized
INFO - 2020-11-02 02:12:10 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:10 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:10 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:10 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:10 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:10 --> Controller Class Initialized
INFO - 2020-11-02 02:12:10 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:10 --> Total execution time: 0.2436
INFO - 2020-11-02 02:12:14 --> Config Class Initialized
INFO - 2020-11-02 02:12:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:14 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:14 --> URI Class Initialized
INFO - 2020-11-02 02:12:14 --> Router Class Initialized
INFO - 2020-11-02 02:12:14 --> Output Class Initialized
INFO - 2020-11-02 02:12:14 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:14 --> Input Class Initialized
INFO - 2020-11-02 02:12:14 --> Language Class Initialized
INFO - 2020-11-02 02:12:14 --> Language Class Initialized
INFO - 2020-11-02 02:12:14 --> Config Class Initialized
INFO - 2020-11-02 02:12:14 --> Loader Class Initialized
INFO - 2020-11-02 02:12:14 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:14 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:14 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:14 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:14 --> Controller Class Initialized
INFO - 2020-11-02 02:12:14 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:14 --> Total execution time: 0.2783
INFO - 2020-11-02 02:12:18 --> Config Class Initialized
INFO - 2020-11-02 02:12:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:18 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:18 --> URI Class Initialized
INFO - 2020-11-02 02:12:18 --> Router Class Initialized
INFO - 2020-11-02 02:12:18 --> Output Class Initialized
INFO - 2020-11-02 02:12:18 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:18 --> Input Class Initialized
INFO - 2020-11-02 02:12:18 --> Language Class Initialized
INFO - 2020-11-02 02:12:18 --> Language Class Initialized
INFO - 2020-11-02 02:12:18 --> Config Class Initialized
INFO - 2020-11-02 02:12:18 --> Loader Class Initialized
INFO - 2020-11-02 02:12:18 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:19 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:19 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:19 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:19 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:19 --> Controller Class Initialized
DEBUG - 2020-11-02 02:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-02 02:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:12:19 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:19 --> Total execution time: 0.3542
INFO - 2020-11-02 02:12:20 --> Config Class Initialized
INFO - 2020-11-02 02:12:20 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:20 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:20 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:20 --> URI Class Initialized
INFO - 2020-11-02 02:12:20 --> Router Class Initialized
INFO - 2020-11-02 02:12:20 --> Output Class Initialized
INFO - 2020-11-02 02:12:20 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:20 --> Input Class Initialized
INFO - 2020-11-02 02:12:20 --> Language Class Initialized
INFO - 2020-11-02 02:12:20 --> Language Class Initialized
INFO - 2020-11-02 02:12:20 --> Config Class Initialized
INFO - 2020-11-02 02:12:20 --> Loader Class Initialized
INFO - 2020-11-02 02:12:21 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:21 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:21 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:21 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:21 --> Controller Class Initialized
DEBUG - 2020-11-02 02:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:12:21 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:21 --> Total execution time: 0.2463
INFO - 2020-11-02 02:12:22 --> Config Class Initialized
INFO - 2020-11-02 02:12:22 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:22 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:22 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:22 --> URI Class Initialized
INFO - 2020-11-02 02:12:22 --> Router Class Initialized
INFO - 2020-11-02 02:12:22 --> Output Class Initialized
INFO - 2020-11-02 02:12:22 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:22 --> Input Class Initialized
INFO - 2020-11-02 02:12:22 --> Language Class Initialized
INFO - 2020-11-02 02:12:22 --> Language Class Initialized
INFO - 2020-11-02 02:12:22 --> Config Class Initialized
INFO - 2020-11-02 02:12:22 --> Loader Class Initialized
INFO - 2020-11-02 02:12:22 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:22 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:22 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:22 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:22 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:22 --> Controller Class Initialized
DEBUG - 2020-11-02 02:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:12:22 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:22 --> Total execution time: 0.2189
INFO - 2020-11-02 02:12:22 --> Config Class Initialized
INFO - 2020-11-02 02:12:22 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:22 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:22 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:22 --> URI Class Initialized
INFO - 2020-11-02 02:12:22 --> Router Class Initialized
INFO - 2020-11-02 02:12:22 --> Output Class Initialized
INFO - 2020-11-02 02:12:22 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:22 --> Input Class Initialized
INFO - 2020-11-02 02:12:22 --> Language Class Initialized
INFO - 2020-11-02 02:12:22 --> Language Class Initialized
INFO - 2020-11-02 02:12:22 --> Config Class Initialized
INFO - 2020-11-02 02:12:22 --> Loader Class Initialized
INFO - 2020-11-02 02:12:22 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:22 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:22 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:22 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:22 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:22 --> Controller Class Initialized
INFO - 2020-11-02 02:12:24 --> Config Class Initialized
INFO - 2020-11-02 02:12:24 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:24 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:24 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:24 --> URI Class Initialized
INFO - 2020-11-02 02:12:24 --> Router Class Initialized
INFO - 2020-11-02 02:12:24 --> Output Class Initialized
INFO - 2020-11-02 02:12:24 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:24 --> Input Class Initialized
INFO - 2020-11-02 02:12:24 --> Language Class Initialized
INFO - 2020-11-02 02:12:24 --> Language Class Initialized
INFO - 2020-11-02 02:12:24 --> Config Class Initialized
INFO - 2020-11-02 02:12:24 --> Loader Class Initialized
INFO - 2020-11-02 02:12:24 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:24 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:24 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:24 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:24 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:24 --> Controller Class Initialized
INFO - 2020-11-02 02:12:24 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:24 --> Total execution time: 0.2182
INFO - 2020-11-02 02:12:30 --> Config Class Initialized
INFO - 2020-11-02 02:12:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:30 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:30 --> URI Class Initialized
INFO - 2020-11-02 02:12:30 --> Router Class Initialized
INFO - 2020-11-02 02:12:30 --> Output Class Initialized
INFO - 2020-11-02 02:12:30 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:30 --> Input Class Initialized
INFO - 2020-11-02 02:12:30 --> Language Class Initialized
INFO - 2020-11-02 02:12:30 --> Language Class Initialized
INFO - 2020-11-02 02:12:30 --> Config Class Initialized
INFO - 2020-11-02 02:12:30 --> Loader Class Initialized
INFO - 2020-11-02 02:12:30 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:30 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:30 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:30 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:30 --> Controller Class Initialized
INFO - 2020-11-02 02:12:30 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:31 --> Total execution time: 0.2562
INFO - 2020-11-02 02:12:32 --> Config Class Initialized
INFO - 2020-11-02 02:12:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:32 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:32 --> URI Class Initialized
INFO - 2020-11-02 02:12:32 --> Router Class Initialized
INFO - 2020-11-02 02:12:32 --> Output Class Initialized
INFO - 2020-11-02 02:12:32 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:32 --> Input Class Initialized
INFO - 2020-11-02 02:12:32 --> Language Class Initialized
INFO - 2020-11-02 02:12:32 --> Language Class Initialized
INFO - 2020-11-02 02:12:32 --> Config Class Initialized
INFO - 2020-11-02 02:12:32 --> Loader Class Initialized
INFO - 2020-11-02 02:12:32 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:32 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:32 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:32 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:32 --> Controller Class Initialized
INFO - 2020-11-02 02:12:32 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:32 --> Total execution time: 0.1886
INFO - 2020-11-02 02:12:38 --> Config Class Initialized
INFO - 2020-11-02 02:12:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:38 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:38 --> URI Class Initialized
INFO - 2020-11-02 02:12:38 --> Router Class Initialized
INFO - 2020-11-02 02:12:38 --> Output Class Initialized
INFO - 2020-11-02 02:12:38 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:38 --> Input Class Initialized
INFO - 2020-11-02 02:12:38 --> Language Class Initialized
INFO - 2020-11-02 02:12:38 --> Language Class Initialized
INFO - 2020-11-02 02:12:38 --> Config Class Initialized
INFO - 2020-11-02 02:12:38 --> Loader Class Initialized
INFO - 2020-11-02 02:12:38 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:38 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:38 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:38 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:39 --> Controller Class Initialized
ERROR - 2020-11-02 02:12:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 857
INFO - 2020-11-02 02:12:39 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:39 --> Total execution time: 0.2666
INFO - 2020-11-02 02:12:43 --> Config Class Initialized
INFO - 2020-11-02 02:12:43 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:43 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:43 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:43 --> URI Class Initialized
INFO - 2020-11-02 02:12:43 --> Router Class Initialized
INFO - 2020-11-02 02:12:43 --> Output Class Initialized
INFO - 2020-11-02 02:12:43 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:43 --> Input Class Initialized
INFO - 2020-11-02 02:12:43 --> Language Class Initialized
INFO - 2020-11-02 02:12:43 --> Language Class Initialized
INFO - 2020-11-02 02:12:43 --> Config Class Initialized
INFO - 2020-11-02 02:12:43 --> Loader Class Initialized
INFO - 2020-11-02 02:12:43 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:43 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:43 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:43 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:43 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:43 --> Controller Class Initialized
INFO - 2020-11-02 02:12:43 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:43 --> Total execution time: 0.2226
INFO - 2020-11-02 02:12:48 --> Config Class Initialized
INFO - 2020-11-02 02:12:48 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:48 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:48 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:48 --> URI Class Initialized
INFO - 2020-11-02 02:12:48 --> Router Class Initialized
INFO - 2020-11-02 02:12:48 --> Output Class Initialized
INFO - 2020-11-02 02:12:48 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:48 --> Input Class Initialized
INFO - 2020-11-02 02:12:48 --> Language Class Initialized
INFO - 2020-11-02 02:12:48 --> Language Class Initialized
INFO - 2020-11-02 02:12:48 --> Config Class Initialized
INFO - 2020-11-02 02:12:48 --> Loader Class Initialized
INFO - 2020-11-02 02:12:48 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:48 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:48 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:48 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:48 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:48 --> Controller Class Initialized
ERROR - 2020-11-02 02:12:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 857
INFO - 2020-11-02 02:12:48 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:49 --> Total execution time: 0.2710
INFO - 2020-11-02 02:12:51 --> Config Class Initialized
INFO - 2020-11-02 02:12:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:51 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:51 --> URI Class Initialized
INFO - 2020-11-02 02:12:51 --> Router Class Initialized
INFO - 2020-11-02 02:12:51 --> Output Class Initialized
INFO - 2020-11-02 02:12:51 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:51 --> Input Class Initialized
INFO - 2020-11-02 02:12:51 --> Language Class Initialized
INFO - 2020-11-02 02:12:51 --> Language Class Initialized
INFO - 2020-11-02 02:12:51 --> Config Class Initialized
INFO - 2020-11-02 02:12:51 --> Loader Class Initialized
INFO - 2020-11-02 02:12:51 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:51 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:51 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:51 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:51 --> Controller Class Initialized
INFO - 2020-11-02 02:12:51 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:51 --> Total execution time: 0.2110
INFO - 2020-11-02 02:12:52 --> Config Class Initialized
INFO - 2020-11-02 02:12:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:52 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:52 --> URI Class Initialized
INFO - 2020-11-02 02:12:52 --> Router Class Initialized
INFO - 2020-11-02 02:12:52 --> Output Class Initialized
INFO - 2020-11-02 02:12:52 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:52 --> Input Class Initialized
INFO - 2020-11-02 02:12:52 --> Language Class Initialized
INFO - 2020-11-02 02:12:52 --> Language Class Initialized
INFO - 2020-11-02 02:12:52 --> Config Class Initialized
INFO - 2020-11-02 02:12:52 --> Loader Class Initialized
INFO - 2020-11-02 02:12:52 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:52 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:52 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:52 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:52 --> Controller Class Initialized
INFO - 2020-11-02 02:12:52 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:52 --> Total execution time: 0.1910
INFO - 2020-11-02 02:12:52 --> Config Class Initialized
INFO - 2020-11-02 02:12:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:12:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:12:52 --> Utf8 Class Initialized
INFO - 2020-11-02 02:12:52 --> URI Class Initialized
INFO - 2020-11-02 02:12:52 --> Router Class Initialized
INFO - 2020-11-02 02:12:52 --> Output Class Initialized
INFO - 2020-11-02 02:12:52 --> Security Class Initialized
DEBUG - 2020-11-02 02:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:12:52 --> Input Class Initialized
INFO - 2020-11-02 02:12:52 --> Language Class Initialized
INFO - 2020-11-02 02:12:52 --> Language Class Initialized
INFO - 2020-11-02 02:12:52 --> Config Class Initialized
INFO - 2020-11-02 02:12:52 --> Loader Class Initialized
INFO - 2020-11-02 02:12:52 --> Helper loaded: url_helper
INFO - 2020-11-02 02:12:52 --> Helper loaded: file_helper
INFO - 2020-11-02 02:12:52 --> Helper loaded: form_helper
INFO - 2020-11-02 02:12:52 --> Helper loaded: my_helper
INFO - 2020-11-02 02:12:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:12:52 --> Controller Class Initialized
INFO - 2020-11-02 02:12:52 --> Final output sent to browser
DEBUG - 2020-11-02 02:12:52 --> Total execution time: 0.1934
INFO - 2020-11-02 02:14:17 --> Config Class Initialized
INFO - 2020-11-02 02:14:17 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:14:17 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:14:17 --> Utf8 Class Initialized
INFO - 2020-11-02 02:14:17 --> URI Class Initialized
INFO - 2020-11-02 02:14:17 --> Router Class Initialized
INFO - 2020-11-02 02:14:17 --> Output Class Initialized
INFO - 2020-11-02 02:14:17 --> Security Class Initialized
DEBUG - 2020-11-02 02:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:14:17 --> Input Class Initialized
INFO - 2020-11-02 02:14:17 --> Language Class Initialized
INFO - 2020-11-02 02:14:17 --> Language Class Initialized
INFO - 2020-11-02 02:14:17 --> Config Class Initialized
INFO - 2020-11-02 02:14:17 --> Loader Class Initialized
INFO - 2020-11-02 02:14:17 --> Helper loaded: url_helper
INFO - 2020-11-02 02:14:17 --> Helper loaded: file_helper
INFO - 2020-11-02 02:14:17 --> Helper loaded: form_helper
INFO - 2020-11-02 02:14:17 --> Helper loaded: my_helper
INFO - 2020-11-02 02:14:17 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:14:17 --> Controller Class Initialized
DEBUG - 2020-11-02 02:14:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:14:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:14:17 --> Final output sent to browser
DEBUG - 2020-11-02 02:14:17 --> Total execution time: 0.2459
INFO - 2020-11-02 02:23:10 --> Config Class Initialized
INFO - 2020-11-02 02:23:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:23:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:23:10 --> Utf8 Class Initialized
INFO - 2020-11-02 02:23:10 --> URI Class Initialized
INFO - 2020-11-02 02:23:10 --> Router Class Initialized
INFO - 2020-11-02 02:23:10 --> Output Class Initialized
INFO - 2020-11-02 02:23:10 --> Security Class Initialized
DEBUG - 2020-11-02 02:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:23:10 --> Input Class Initialized
INFO - 2020-11-02 02:23:10 --> Language Class Initialized
INFO - 2020-11-02 02:23:10 --> Language Class Initialized
INFO - 2020-11-02 02:23:10 --> Config Class Initialized
INFO - 2020-11-02 02:23:10 --> Loader Class Initialized
INFO - 2020-11-02 02:23:10 --> Helper loaded: url_helper
INFO - 2020-11-02 02:23:10 --> Helper loaded: file_helper
INFO - 2020-11-02 02:23:11 --> Helper loaded: form_helper
INFO - 2020-11-02 02:23:11 --> Helper loaded: my_helper
INFO - 2020-11-02 02:23:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:23:11 --> Controller Class Initialized
DEBUG - 2020-11-02 02:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:23:11 --> Final output sent to browser
DEBUG - 2020-11-02 02:23:11 --> Total execution time: 0.2744
INFO - 2020-11-02 02:23:12 --> Config Class Initialized
INFO - 2020-11-02 02:23:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:23:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:23:12 --> Utf8 Class Initialized
INFO - 2020-11-02 02:23:12 --> URI Class Initialized
INFO - 2020-11-02 02:23:12 --> Router Class Initialized
INFO - 2020-11-02 02:23:12 --> Output Class Initialized
INFO - 2020-11-02 02:23:12 --> Security Class Initialized
DEBUG - 2020-11-02 02:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:23:12 --> Input Class Initialized
INFO - 2020-11-02 02:23:12 --> Language Class Initialized
INFO - 2020-11-02 02:23:12 --> Language Class Initialized
INFO - 2020-11-02 02:23:12 --> Config Class Initialized
INFO - 2020-11-02 02:23:12 --> Loader Class Initialized
INFO - 2020-11-02 02:23:12 --> Helper loaded: url_helper
INFO - 2020-11-02 02:23:12 --> Helper loaded: file_helper
INFO - 2020-11-02 02:23:12 --> Helper loaded: form_helper
INFO - 2020-11-02 02:23:12 --> Helper loaded: my_helper
INFO - 2020-11-02 02:23:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:23:12 --> Controller Class Initialized
INFO - 2020-11-02 02:23:12 --> Final output sent to browser
DEBUG - 2020-11-02 02:23:12 --> Total execution time: 0.2306
INFO - 2020-11-02 02:23:31 --> Config Class Initialized
INFO - 2020-11-02 02:23:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:23:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:23:31 --> Utf8 Class Initialized
INFO - 2020-11-02 02:23:31 --> URI Class Initialized
INFO - 2020-11-02 02:23:31 --> Router Class Initialized
INFO - 2020-11-02 02:23:31 --> Output Class Initialized
INFO - 2020-11-02 02:23:31 --> Security Class Initialized
DEBUG - 2020-11-02 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:23:31 --> Input Class Initialized
INFO - 2020-11-02 02:23:31 --> Language Class Initialized
INFO - 2020-11-02 02:23:31 --> Language Class Initialized
INFO - 2020-11-02 02:23:31 --> Config Class Initialized
INFO - 2020-11-02 02:23:31 --> Loader Class Initialized
INFO - 2020-11-02 02:23:31 --> Helper loaded: url_helper
INFO - 2020-11-02 02:23:31 --> Helper loaded: file_helper
INFO - 2020-11-02 02:23:31 --> Helper loaded: form_helper
INFO - 2020-11-02 02:23:31 --> Helper loaded: my_helper
INFO - 2020-11-02 02:23:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:23:31 --> Controller Class Initialized
INFO - 2020-11-02 02:23:31 --> Final output sent to browser
DEBUG - 2020-11-02 02:23:31 --> Total execution time: 0.3044
INFO - 2020-11-02 02:23:31 --> Config Class Initialized
INFO - 2020-11-02 02:23:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:23:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:23:31 --> Utf8 Class Initialized
INFO - 2020-11-02 02:23:31 --> URI Class Initialized
INFO - 2020-11-02 02:23:31 --> Router Class Initialized
INFO - 2020-11-02 02:23:31 --> Output Class Initialized
INFO - 2020-11-02 02:23:31 --> Security Class Initialized
DEBUG - 2020-11-02 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:23:31 --> Input Class Initialized
INFO - 2020-11-02 02:23:31 --> Language Class Initialized
INFO - 2020-11-02 02:23:31 --> Language Class Initialized
INFO - 2020-11-02 02:23:31 --> Config Class Initialized
INFO - 2020-11-02 02:23:31 --> Loader Class Initialized
INFO - 2020-11-02 02:23:31 --> Helper loaded: url_helper
INFO - 2020-11-02 02:23:31 --> Helper loaded: file_helper
INFO - 2020-11-02 02:23:31 --> Helper loaded: form_helper
INFO - 2020-11-02 02:23:31 --> Helper loaded: my_helper
INFO - 2020-11-02 02:23:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:23:31 --> Controller Class Initialized
DEBUG - 2020-11-02 02:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:23:31 --> Final output sent to browser
DEBUG - 2020-11-02 02:23:31 --> Total execution time: 0.2941
INFO - 2020-11-02 02:23:33 --> Config Class Initialized
INFO - 2020-11-02 02:23:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:23:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:23:33 --> Utf8 Class Initialized
INFO - 2020-11-02 02:23:33 --> URI Class Initialized
INFO - 2020-11-02 02:23:33 --> Router Class Initialized
INFO - 2020-11-02 02:23:33 --> Output Class Initialized
INFO - 2020-11-02 02:23:33 --> Security Class Initialized
DEBUG - 2020-11-02 02:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:23:33 --> Input Class Initialized
INFO - 2020-11-02 02:23:33 --> Language Class Initialized
INFO - 2020-11-02 02:23:33 --> Language Class Initialized
INFO - 2020-11-02 02:23:33 --> Config Class Initialized
INFO - 2020-11-02 02:23:33 --> Loader Class Initialized
INFO - 2020-11-02 02:23:33 --> Helper loaded: url_helper
INFO - 2020-11-02 02:23:33 --> Helper loaded: file_helper
INFO - 2020-11-02 02:23:33 --> Helper loaded: form_helper
INFO - 2020-11-02 02:23:33 --> Helper loaded: my_helper
INFO - 2020-11-02 02:23:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:23:33 --> Controller Class Initialized
INFO - 2020-11-02 02:23:33 --> Final output sent to browser
DEBUG - 2020-11-02 02:23:33 --> Total execution time: 0.2177
INFO - 2020-11-02 02:23:37 --> Config Class Initialized
INFO - 2020-11-02 02:23:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:23:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:23:37 --> Utf8 Class Initialized
INFO - 2020-11-02 02:23:37 --> URI Class Initialized
INFO - 2020-11-02 02:23:37 --> Router Class Initialized
INFO - 2020-11-02 02:23:37 --> Output Class Initialized
INFO - 2020-11-02 02:23:37 --> Security Class Initialized
DEBUG - 2020-11-02 02:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:23:37 --> Input Class Initialized
INFO - 2020-11-02 02:23:37 --> Language Class Initialized
INFO - 2020-11-02 02:23:37 --> Language Class Initialized
INFO - 2020-11-02 02:23:37 --> Config Class Initialized
INFO - 2020-11-02 02:23:37 --> Loader Class Initialized
INFO - 2020-11-02 02:23:37 --> Helper loaded: url_helper
INFO - 2020-11-02 02:23:37 --> Helper loaded: file_helper
INFO - 2020-11-02 02:23:37 --> Helper loaded: form_helper
INFO - 2020-11-02 02:23:37 --> Helper loaded: my_helper
INFO - 2020-11-02 02:23:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:23:38 --> Controller Class Initialized
INFO - 2020-11-02 02:23:38 --> Final output sent to browser
DEBUG - 2020-11-02 02:23:38 --> Total execution time: 0.2642
INFO - 2020-11-02 02:23:40 --> Config Class Initialized
INFO - 2020-11-02 02:23:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:23:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:23:40 --> Utf8 Class Initialized
INFO - 2020-11-02 02:23:40 --> URI Class Initialized
INFO - 2020-11-02 02:23:40 --> Router Class Initialized
INFO - 2020-11-02 02:23:40 --> Output Class Initialized
INFO - 2020-11-02 02:23:40 --> Security Class Initialized
DEBUG - 2020-11-02 02:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:23:40 --> Input Class Initialized
INFO - 2020-11-02 02:23:40 --> Language Class Initialized
INFO - 2020-11-02 02:23:40 --> Language Class Initialized
INFO - 2020-11-02 02:23:40 --> Config Class Initialized
INFO - 2020-11-02 02:23:40 --> Loader Class Initialized
INFO - 2020-11-02 02:23:40 --> Helper loaded: url_helper
INFO - 2020-11-02 02:23:40 --> Helper loaded: file_helper
INFO - 2020-11-02 02:23:40 --> Helper loaded: form_helper
INFO - 2020-11-02 02:23:40 --> Helper loaded: my_helper
INFO - 2020-11-02 02:23:41 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:23:41 --> Controller Class Initialized
DEBUG - 2020-11-02 02:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:23:41 --> Final output sent to browser
DEBUG - 2020-11-02 02:23:41 --> Total execution time: 0.3577
INFO - 2020-11-02 02:23:42 --> Config Class Initialized
INFO - 2020-11-02 02:23:42 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:23:42 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:23:42 --> Utf8 Class Initialized
INFO - 2020-11-02 02:23:42 --> URI Class Initialized
INFO - 2020-11-02 02:23:42 --> Router Class Initialized
INFO - 2020-11-02 02:23:42 --> Output Class Initialized
INFO - 2020-11-02 02:23:42 --> Security Class Initialized
DEBUG - 2020-11-02 02:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:23:42 --> Input Class Initialized
INFO - 2020-11-02 02:23:42 --> Language Class Initialized
INFO - 2020-11-02 02:23:42 --> Language Class Initialized
INFO - 2020-11-02 02:23:42 --> Config Class Initialized
INFO - 2020-11-02 02:23:42 --> Loader Class Initialized
INFO - 2020-11-02 02:23:42 --> Helper loaded: url_helper
INFO - 2020-11-02 02:23:42 --> Helper loaded: file_helper
INFO - 2020-11-02 02:23:42 --> Helper loaded: form_helper
INFO - 2020-11-02 02:23:42 --> Helper loaded: my_helper
INFO - 2020-11-02 02:23:42 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:23:42 --> Controller Class Initialized
INFO - 2020-11-02 02:23:42 --> Final output sent to browser
DEBUG - 2020-11-02 02:23:42 --> Total execution time: 0.2222
INFO - 2020-11-02 02:26:11 --> Config Class Initialized
INFO - 2020-11-02 02:26:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:11 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:11 --> URI Class Initialized
INFO - 2020-11-02 02:26:11 --> Router Class Initialized
INFO - 2020-11-02 02:26:11 --> Output Class Initialized
INFO - 2020-11-02 02:26:11 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:11 --> Input Class Initialized
INFO - 2020-11-02 02:26:11 --> Language Class Initialized
INFO - 2020-11-02 02:26:11 --> Language Class Initialized
INFO - 2020-11-02 02:26:11 --> Config Class Initialized
INFO - 2020-11-02 02:26:11 --> Loader Class Initialized
INFO - 2020-11-02 02:26:11 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:11 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:11 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:11 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:11 --> Controller Class Initialized
DEBUG - 2020-11-02 02:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:26:11 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:11 --> Total execution time: 0.2417
INFO - 2020-11-02 02:26:12 --> Config Class Initialized
INFO - 2020-11-02 02:26:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:13 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:13 --> URI Class Initialized
INFO - 2020-11-02 02:26:13 --> Router Class Initialized
INFO - 2020-11-02 02:26:13 --> Output Class Initialized
INFO - 2020-11-02 02:26:13 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:13 --> Input Class Initialized
INFO - 2020-11-02 02:26:13 --> Language Class Initialized
INFO - 2020-11-02 02:26:13 --> Language Class Initialized
INFO - 2020-11-02 02:26:13 --> Config Class Initialized
INFO - 2020-11-02 02:26:13 --> Loader Class Initialized
INFO - 2020-11-02 02:26:13 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:13 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:13 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:13 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:13 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:13 --> Controller Class Initialized
DEBUG - 2020-11-02 02:26:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:26:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:26:13 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:13 --> Total execution time: 0.2343
INFO - 2020-11-02 02:26:14 --> Config Class Initialized
INFO - 2020-11-02 02:26:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:14 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:14 --> URI Class Initialized
INFO - 2020-11-02 02:26:14 --> Router Class Initialized
INFO - 2020-11-02 02:26:14 --> Output Class Initialized
INFO - 2020-11-02 02:26:14 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:14 --> Input Class Initialized
INFO - 2020-11-02 02:26:14 --> Language Class Initialized
INFO - 2020-11-02 02:26:14 --> Language Class Initialized
INFO - 2020-11-02 02:26:14 --> Config Class Initialized
INFO - 2020-11-02 02:26:14 --> Loader Class Initialized
INFO - 2020-11-02 02:26:15 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:15 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:15 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:15 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:15 --> Controller Class Initialized
INFO - 2020-11-02 02:26:15 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:15 --> Total execution time: 0.2253
INFO - 2020-11-02 02:26:17 --> Config Class Initialized
INFO - 2020-11-02 02:26:17 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:17 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:17 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:17 --> URI Class Initialized
INFO - 2020-11-02 02:26:17 --> Router Class Initialized
INFO - 2020-11-02 02:26:17 --> Output Class Initialized
INFO - 2020-11-02 02:26:17 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:17 --> Input Class Initialized
INFO - 2020-11-02 02:26:17 --> Language Class Initialized
INFO - 2020-11-02 02:26:17 --> Language Class Initialized
INFO - 2020-11-02 02:26:17 --> Config Class Initialized
INFO - 2020-11-02 02:26:17 --> Loader Class Initialized
INFO - 2020-11-02 02:26:17 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:17 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:17 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:17 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:17 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:17 --> Controller Class Initialized
DEBUG - 2020-11-02 02:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:26:17 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:17 --> Total execution time: 0.2454
INFO - 2020-11-02 02:26:18 --> Config Class Initialized
INFO - 2020-11-02 02:26:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:18 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:18 --> URI Class Initialized
INFO - 2020-11-02 02:26:18 --> Router Class Initialized
INFO - 2020-11-02 02:26:18 --> Output Class Initialized
INFO - 2020-11-02 02:26:18 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:18 --> Input Class Initialized
INFO - 2020-11-02 02:26:18 --> Language Class Initialized
INFO - 2020-11-02 02:26:18 --> Language Class Initialized
INFO - 2020-11-02 02:26:18 --> Config Class Initialized
INFO - 2020-11-02 02:26:18 --> Loader Class Initialized
INFO - 2020-11-02 02:26:18 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:18 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:18 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:18 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:18 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:18 --> Controller Class Initialized
DEBUG - 2020-11-02 02:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:26:18 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:18 --> Total execution time: 0.2762
INFO - 2020-11-02 02:26:18 --> Config Class Initialized
INFO - 2020-11-02 02:26:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:18 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:18 --> URI Class Initialized
INFO - 2020-11-02 02:26:18 --> Router Class Initialized
INFO - 2020-11-02 02:26:18 --> Output Class Initialized
INFO - 2020-11-02 02:26:18 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:18 --> Input Class Initialized
INFO - 2020-11-02 02:26:18 --> Language Class Initialized
INFO - 2020-11-02 02:26:18 --> Language Class Initialized
INFO - 2020-11-02 02:26:18 --> Config Class Initialized
INFO - 2020-11-02 02:26:18 --> Loader Class Initialized
INFO - 2020-11-02 02:26:18 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:18 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:18 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:18 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:18 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:18 --> Controller Class Initialized
INFO - 2020-11-02 02:26:20 --> Config Class Initialized
INFO - 2020-11-02 02:26:20 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:20 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:20 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:20 --> URI Class Initialized
INFO - 2020-11-02 02:26:20 --> Router Class Initialized
INFO - 2020-11-02 02:26:20 --> Output Class Initialized
INFO - 2020-11-02 02:26:20 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:20 --> Input Class Initialized
INFO - 2020-11-02 02:26:20 --> Language Class Initialized
INFO - 2020-11-02 02:26:20 --> Language Class Initialized
INFO - 2020-11-02 02:26:20 --> Config Class Initialized
INFO - 2020-11-02 02:26:20 --> Loader Class Initialized
INFO - 2020-11-02 02:26:20 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:20 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:20 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:20 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:20 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:20 --> Controller Class Initialized
INFO - 2020-11-02 02:26:20 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:20 --> Total execution time: 0.2335
INFO - 2020-11-02 02:26:24 --> Config Class Initialized
INFO - 2020-11-02 02:26:24 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:24 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:24 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:24 --> URI Class Initialized
INFO - 2020-11-02 02:26:24 --> Router Class Initialized
INFO - 2020-11-02 02:26:24 --> Output Class Initialized
INFO - 2020-11-02 02:26:24 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:24 --> Input Class Initialized
INFO - 2020-11-02 02:26:24 --> Language Class Initialized
INFO - 2020-11-02 02:26:24 --> Language Class Initialized
INFO - 2020-11-02 02:26:24 --> Config Class Initialized
INFO - 2020-11-02 02:26:24 --> Loader Class Initialized
INFO - 2020-11-02 02:26:24 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:24 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:24 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:24 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:24 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:24 --> Controller Class Initialized
INFO - 2020-11-02 02:26:24 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:24 --> Total execution time: 0.2769
INFO - 2020-11-02 02:26:27 --> Config Class Initialized
INFO - 2020-11-02 02:26:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:27 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:27 --> URI Class Initialized
INFO - 2020-11-02 02:26:27 --> Router Class Initialized
INFO - 2020-11-02 02:26:27 --> Output Class Initialized
INFO - 2020-11-02 02:26:27 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:27 --> Input Class Initialized
INFO - 2020-11-02 02:26:27 --> Language Class Initialized
INFO - 2020-11-02 02:26:27 --> Language Class Initialized
INFO - 2020-11-02 02:26:27 --> Config Class Initialized
INFO - 2020-11-02 02:26:27 --> Loader Class Initialized
INFO - 2020-11-02 02:26:27 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:27 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:27 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:27 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:27 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:27 --> Controller Class Initialized
INFO - 2020-11-02 02:26:27 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:27 --> Total execution time: 0.2336
INFO - 2020-11-02 02:26:29 --> Config Class Initialized
INFO - 2020-11-02 02:26:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:29 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:29 --> URI Class Initialized
INFO - 2020-11-02 02:26:29 --> Router Class Initialized
INFO - 2020-11-02 02:26:29 --> Output Class Initialized
INFO - 2020-11-02 02:26:29 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:29 --> Input Class Initialized
INFO - 2020-11-02 02:26:29 --> Language Class Initialized
INFO - 2020-11-02 02:26:29 --> Language Class Initialized
INFO - 2020-11-02 02:26:29 --> Config Class Initialized
INFO - 2020-11-02 02:26:29 --> Loader Class Initialized
INFO - 2020-11-02 02:26:29 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:29 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:29 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:29 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:29 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:29 --> Controller Class Initialized
INFO - 2020-11-02 02:26:29 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:29 --> Total execution time: 0.2727
INFO - 2020-11-02 02:26:31 --> Config Class Initialized
INFO - 2020-11-02 02:26:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:31 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:31 --> URI Class Initialized
INFO - 2020-11-02 02:26:31 --> Router Class Initialized
INFO - 2020-11-02 02:26:31 --> Output Class Initialized
INFO - 2020-11-02 02:26:31 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:31 --> Input Class Initialized
INFO - 2020-11-02 02:26:31 --> Language Class Initialized
INFO - 2020-11-02 02:26:31 --> Language Class Initialized
INFO - 2020-11-02 02:26:31 --> Config Class Initialized
INFO - 2020-11-02 02:26:31 --> Loader Class Initialized
INFO - 2020-11-02 02:26:31 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:31 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:31 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:31 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:31 --> Controller Class Initialized
INFO - 2020-11-02 02:26:31 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:31 --> Total execution time: 0.2382
INFO - 2020-11-02 02:26:34 --> Config Class Initialized
INFO - 2020-11-02 02:26:34 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:34 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:34 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:34 --> URI Class Initialized
INFO - 2020-11-02 02:26:34 --> Router Class Initialized
INFO - 2020-11-02 02:26:34 --> Output Class Initialized
INFO - 2020-11-02 02:26:34 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:34 --> Input Class Initialized
INFO - 2020-11-02 02:26:34 --> Language Class Initialized
INFO - 2020-11-02 02:26:34 --> Language Class Initialized
INFO - 2020-11-02 02:26:34 --> Config Class Initialized
INFO - 2020-11-02 02:26:34 --> Loader Class Initialized
INFO - 2020-11-02 02:26:34 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:34 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:34 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:34 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:34 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:34 --> Controller Class Initialized
INFO - 2020-11-02 02:26:34 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:34 --> Total execution time: 0.2948
INFO - 2020-11-02 02:26:37 --> Config Class Initialized
INFO - 2020-11-02 02:26:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:37 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:37 --> URI Class Initialized
INFO - 2020-11-02 02:26:37 --> Router Class Initialized
INFO - 2020-11-02 02:26:37 --> Output Class Initialized
INFO - 2020-11-02 02:26:37 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:37 --> Input Class Initialized
INFO - 2020-11-02 02:26:37 --> Language Class Initialized
INFO - 2020-11-02 02:26:37 --> Language Class Initialized
INFO - 2020-11-02 02:26:37 --> Config Class Initialized
INFO - 2020-11-02 02:26:37 --> Loader Class Initialized
INFO - 2020-11-02 02:26:37 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:37 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:37 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:37 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:37 --> Controller Class Initialized
DEBUG - 2020-11-02 02:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:26:37 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:37 --> Total execution time: 0.2657
INFO - 2020-11-02 02:26:38 --> Config Class Initialized
INFO - 2020-11-02 02:26:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:38 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:38 --> URI Class Initialized
INFO - 2020-11-02 02:26:38 --> Router Class Initialized
INFO - 2020-11-02 02:26:38 --> Output Class Initialized
INFO - 2020-11-02 02:26:38 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:38 --> Input Class Initialized
INFO - 2020-11-02 02:26:38 --> Language Class Initialized
INFO - 2020-11-02 02:26:38 --> Language Class Initialized
INFO - 2020-11-02 02:26:38 --> Config Class Initialized
INFO - 2020-11-02 02:26:38 --> Loader Class Initialized
INFO - 2020-11-02 02:26:38 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:38 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:38 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:38 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:38 --> Controller Class Initialized
DEBUG - 2020-11-02 02:26:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:26:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:26:38 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:38 --> Total execution time: 0.2530
INFO - 2020-11-02 02:26:40 --> Config Class Initialized
INFO - 2020-11-02 02:26:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:40 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:40 --> URI Class Initialized
INFO - 2020-11-02 02:26:40 --> Router Class Initialized
INFO - 2020-11-02 02:26:40 --> Output Class Initialized
INFO - 2020-11-02 02:26:40 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:40 --> Input Class Initialized
INFO - 2020-11-02 02:26:40 --> Language Class Initialized
INFO - 2020-11-02 02:26:40 --> Language Class Initialized
INFO - 2020-11-02 02:26:40 --> Config Class Initialized
INFO - 2020-11-02 02:26:40 --> Loader Class Initialized
INFO - 2020-11-02 02:26:40 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:40 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:40 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:40 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:40 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:40 --> Controller Class Initialized
DEBUG - 2020-11-02 02:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:26:40 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:40 --> Total execution time: 0.2731
INFO - 2020-11-02 02:26:40 --> Config Class Initialized
INFO - 2020-11-02 02:26:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:40 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:40 --> URI Class Initialized
INFO - 2020-11-02 02:26:40 --> Router Class Initialized
INFO - 2020-11-02 02:26:40 --> Output Class Initialized
INFO - 2020-11-02 02:26:40 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:40 --> Input Class Initialized
INFO - 2020-11-02 02:26:40 --> Language Class Initialized
INFO - 2020-11-02 02:26:40 --> Language Class Initialized
INFO - 2020-11-02 02:26:40 --> Config Class Initialized
INFO - 2020-11-02 02:26:40 --> Loader Class Initialized
INFO - 2020-11-02 02:26:40 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:40 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:40 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:40 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:40 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:40 --> Controller Class Initialized
INFO - 2020-11-02 02:26:42 --> Config Class Initialized
INFO - 2020-11-02 02:26:42 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:42 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:42 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:42 --> URI Class Initialized
INFO - 2020-11-02 02:26:42 --> Router Class Initialized
INFO - 2020-11-02 02:26:42 --> Output Class Initialized
INFO - 2020-11-02 02:26:42 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:42 --> Input Class Initialized
INFO - 2020-11-02 02:26:42 --> Language Class Initialized
INFO - 2020-11-02 02:26:42 --> Language Class Initialized
INFO - 2020-11-02 02:26:42 --> Config Class Initialized
INFO - 2020-11-02 02:26:42 --> Loader Class Initialized
INFO - 2020-11-02 02:26:42 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:42 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:42 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:42 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:42 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:42 --> Controller Class Initialized
INFO - 2020-11-02 02:26:42 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:42 --> Total execution time: 0.2303
INFO - 2020-11-02 02:26:43 --> Config Class Initialized
INFO - 2020-11-02 02:26:43 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:43 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:43 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:43 --> URI Class Initialized
INFO - 2020-11-02 02:26:43 --> Router Class Initialized
INFO - 2020-11-02 02:26:43 --> Output Class Initialized
INFO - 2020-11-02 02:26:43 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:43 --> Input Class Initialized
INFO - 2020-11-02 02:26:43 --> Language Class Initialized
INFO - 2020-11-02 02:26:43 --> Language Class Initialized
INFO - 2020-11-02 02:26:43 --> Config Class Initialized
INFO - 2020-11-02 02:26:43 --> Loader Class Initialized
INFO - 2020-11-02 02:26:43 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:43 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:43 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:43 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:43 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:43 --> Controller Class Initialized
INFO - 2020-11-02 02:26:43 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:43 --> Total execution time: 0.2195
INFO - 2020-11-02 02:26:44 --> Config Class Initialized
INFO - 2020-11-02 02:26:44 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:26:44 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:26:44 --> Utf8 Class Initialized
INFO - 2020-11-02 02:26:44 --> URI Class Initialized
INFO - 2020-11-02 02:26:44 --> Router Class Initialized
INFO - 2020-11-02 02:26:44 --> Output Class Initialized
INFO - 2020-11-02 02:26:44 --> Security Class Initialized
DEBUG - 2020-11-02 02:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:26:44 --> Input Class Initialized
INFO - 2020-11-02 02:26:44 --> Language Class Initialized
INFO - 2020-11-02 02:26:44 --> Language Class Initialized
INFO - 2020-11-02 02:26:44 --> Config Class Initialized
INFO - 2020-11-02 02:26:44 --> Loader Class Initialized
INFO - 2020-11-02 02:26:44 --> Helper loaded: url_helper
INFO - 2020-11-02 02:26:44 --> Helper loaded: file_helper
INFO - 2020-11-02 02:26:44 --> Helper loaded: form_helper
INFO - 2020-11-02 02:26:44 --> Helper loaded: my_helper
INFO - 2020-11-02 02:26:44 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:26:44 --> Controller Class Initialized
INFO - 2020-11-02 02:26:44 --> Final output sent to browser
DEBUG - 2020-11-02 02:26:44 --> Total execution time: 0.2437
INFO - 2020-11-02 02:27:13 --> Config Class Initialized
INFO - 2020-11-02 02:27:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:27:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:27:13 --> Utf8 Class Initialized
INFO - 2020-11-02 02:27:14 --> URI Class Initialized
INFO - 2020-11-02 02:27:14 --> Router Class Initialized
INFO - 2020-11-02 02:27:14 --> Output Class Initialized
INFO - 2020-11-02 02:27:14 --> Security Class Initialized
DEBUG - 2020-11-02 02:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:27:14 --> Input Class Initialized
INFO - 2020-11-02 02:27:14 --> Language Class Initialized
INFO - 2020-11-02 02:27:14 --> Language Class Initialized
INFO - 2020-11-02 02:27:14 --> Config Class Initialized
INFO - 2020-11-02 02:27:14 --> Loader Class Initialized
INFO - 2020-11-02 02:27:14 --> Helper loaded: url_helper
INFO - 2020-11-02 02:27:14 --> Helper loaded: file_helper
INFO - 2020-11-02 02:27:14 --> Helper loaded: form_helper
INFO - 2020-11-02 02:27:14 --> Helper loaded: my_helper
INFO - 2020-11-02 02:27:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:27:14 --> Controller Class Initialized
INFO - 2020-11-02 02:30:15 --> Config Class Initialized
INFO - 2020-11-02 02:30:15 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:30:15 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:30:15 --> Utf8 Class Initialized
INFO - 2020-11-02 02:30:15 --> URI Class Initialized
INFO - 2020-11-02 02:30:15 --> Router Class Initialized
INFO - 2020-11-02 02:30:15 --> Output Class Initialized
INFO - 2020-11-02 02:30:15 --> Security Class Initialized
DEBUG - 2020-11-02 02:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:30:15 --> Input Class Initialized
INFO - 2020-11-02 02:30:15 --> Language Class Initialized
INFO - 2020-11-02 02:30:15 --> Language Class Initialized
INFO - 2020-11-02 02:30:15 --> Config Class Initialized
INFO - 2020-11-02 02:30:15 --> Loader Class Initialized
INFO - 2020-11-02 02:30:15 --> Helper loaded: url_helper
INFO - 2020-11-02 02:30:15 --> Helper loaded: file_helper
INFO - 2020-11-02 02:30:15 --> Helper loaded: form_helper
INFO - 2020-11-02 02:30:15 --> Helper loaded: my_helper
INFO - 2020-11-02 02:30:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:30:15 --> Controller Class Initialized
INFO - 2020-11-02 02:30:15 --> Final output sent to browser
DEBUG - 2020-11-02 02:30:15 --> Total execution time: 0.2720
INFO - 2020-11-02 02:37:05 --> Config Class Initialized
INFO - 2020-11-02 02:37:05 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:37:05 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:37:05 --> Utf8 Class Initialized
INFO - 2020-11-02 02:37:05 --> URI Class Initialized
INFO - 2020-11-02 02:37:05 --> Router Class Initialized
INFO - 2020-11-02 02:37:05 --> Output Class Initialized
INFO - 2020-11-02 02:37:05 --> Security Class Initialized
DEBUG - 2020-11-02 02:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:37:05 --> Input Class Initialized
INFO - 2020-11-02 02:37:05 --> Language Class Initialized
INFO - 2020-11-02 02:37:05 --> Language Class Initialized
INFO - 2020-11-02 02:37:05 --> Config Class Initialized
INFO - 2020-11-02 02:37:05 --> Loader Class Initialized
INFO - 2020-11-02 02:37:05 --> Helper loaded: url_helper
INFO - 2020-11-02 02:37:05 --> Helper loaded: file_helper
INFO - 2020-11-02 02:37:05 --> Helper loaded: form_helper
INFO - 2020-11-02 02:37:05 --> Helper loaded: my_helper
INFO - 2020-11-02 02:37:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:37:05 --> Controller Class Initialized
DEBUG - 2020-11-02 02:37:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 02:37:05 --> Final output sent to browser
DEBUG - 2020-11-02 02:37:05 --> Total execution time: 0.2686
INFO - 2020-11-02 02:37:12 --> Config Class Initialized
INFO - 2020-11-02 02:37:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:37:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:37:12 --> Utf8 Class Initialized
INFO - 2020-11-02 02:37:12 --> URI Class Initialized
INFO - 2020-11-02 02:37:12 --> Router Class Initialized
INFO - 2020-11-02 02:37:12 --> Output Class Initialized
INFO - 2020-11-02 02:37:12 --> Security Class Initialized
DEBUG - 2020-11-02 02:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:37:12 --> Input Class Initialized
INFO - 2020-11-02 02:37:12 --> Language Class Initialized
INFO - 2020-11-02 02:37:12 --> Language Class Initialized
INFO - 2020-11-02 02:37:12 --> Config Class Initialized
INFO - 2020-11-02 02:37:12 --> Loader Class Initialized
INFO - 2020-11-02 02:37:12 --> Helper loaded: url_helper
INFO - 2020-11-02 02:37:12 --> Helper loaded: file_helper
INFO - 2020-11-02 02:37:12 --> Helper loaded: form_helper
INFO - 2020-11-02 02:37:12 --> Helper loaded: my_helper
INFO - 2020-11-02 02:37:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:37:12 --> Controller Class Initialized
DEBUG - 2020-11-02 02:37:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:37:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:37:12 --> Final output sent to browser
DEBUG - 2020-11-02 02:37:12 --> Total execution time: 0.2569
INFO - 2020-11-02 02:37:12 --> Config Class Initialized
INFO - 2020-11-02 02:37:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:37:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:37:12 --> Utf8 Class Initialized
INFO - 2020-11-02 02:37:12 --> URI Class Initialized
INFO - 2020-11-02 02:37:12 --> Router Class Initialized
INFO - 2020-11-02 02:37:12 --> Output Class Initialized
INFO - 2020-11-02 02:37:12 --> Security Class Initialized
DEBUG - 2020-11-02 02:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:37:12 --> Input Class Initialized
INFO - 2020-11-02 02:37:12 --> Language Class Initialized
INFO - 2020-11-02 02:37:12 --> Language Class Initialized
INFO - 2020-11-02 02:37:12 --> Config Class Initialized
INFO - 2020-11-02 02:37:12 --> Loader Class Initialized
INFO - 2020-11-02 02:37:12 --> Helper loaded: url_helper
INFO - 2020-11-02 02:37:12 --> Helper loaded: file_helper
INFO - 2020-11-02 02:37:12 --> Helper loaded: form_helper
INFO - 2020-11-02 02:37:12 --> Helper loaded: my_helper
INFO - 2020-11-02 02:37:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:37:12 --> Controller Class Initialized
INFO - 2020-11-02 02:37:13 --> Config Class Initialized
INFO - 2020-11-02 02:37:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:37:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:37:13 --> Utf8 Class Initialized
INFO - 2020-11-02 02:37:13 --> URI Class Initialized
INFO - 2020-11-02 02:37:13 --> Router Class Initialized
INFO - 2020-11-02 02:37:13 --> Output Class Initialized
INFO - 2020-11-02 02:37:13 --> Security Class Initialized
DEBUG - 2020-11-02 02:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:37:13 --> Input Class Initialized
INFO - 2020-11-02 02:37:13 --> Language Class Initialized
INFO - 2020-11-02 02:37:13 --> Language Class Initialized
INFO - 2020-11-02 02:37:13 --> Config Class Initialized
INFO - 2020-11-02 02:37:13 --> Loader Class Initialized
INFO - 2020-11-02 02:37:13 --> Helper loaded: url_helper
INFO - 2020-11-02 02:37:13 --> Helper loaded: file_helper
INFO - 2020-11-02 02:37:14 --> Helper loaded: form_helper
INFO - 2020-11-02 02:37:14 --> Helper loaded: my_helper
INFO - 2020-11-02 02:37:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:37:14 --> Controller Class Initialized
INFO - 2020-11-02 02:37:14 --> Final output sent to browser
DEBUG - 2020-11-02 02:37:14 --> Total execution time: 0.2325
INFO - 2020-11-02 02:37:24 --> Config Class Initialized
INFO - 2020-11-02 02:37:24 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:37:24 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:37:24 --> Utf8 Class Initialized
INFO - 2020-11-02 02:37:24 --> URI Class Initialized
INFO - 2020-11-02 02:37:24 --> Router Class Initialized
INFO - 2020-11-02 02:37:24 --> Output Class Initialized
INFO - 2020-11-02 02:37:24 --> Security Class Initialized
DEBUG - 2020-11-02 02:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:37:24 --> Input Class Initialized
INFO - 2020-11-02 02:37:24 --> Language Class Initialized
INFO - 2020-11-02 02:37:24 --> Language Class Initialized
INFO - 2020-11-02 02:37:24 --> Config Class Initialized
INFO - 2020-11-02 02:37:24 --> Loader Class Initialized
INFO - 2020-11-02 02:37:24 --> Helper loaded: url_helper
INFO - 2020-11-02 02:37:24 --> Helper loaded: file_helper
INFO - 2020-11-02 02:37:24 --> Helper loaded: form_helper
INFO - 2020-11-02 02:37:24 --> Helper loaded: my_helper
INFO - 2020-11-02 02:37:24 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:37:24 --> Controller Class Initialized
DEBUG - 2020-11-02 02:37:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:37:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:37:24 --> Final output sent to browser
DEBUG - 2020-11-02 02:37:24 --> Total execution time: 0.2547
INFO - 2020-11-02 02:37:25 --> Config Class Initialized
INFO - 2020-11-02 02:37:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:37:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:37:25 --> Utf8 Class Initialized
INFO - 2020-11-02 02:37:25 --> URI Class Initialized
INFO - 2020-11-02 02:37:25 --> Router Class Initialized
INFO - 2020-11-02 02:37:25 --> Output Class Initialized
INFO - 2020-11-02 02:37:25 --> Security Class Initialized
DEBUG - 2020-11-02 02:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:37:25 --> Input Class Initialized
INFO - 2020-11-02 02:37:25 --> Language Class Initialized
INFO - 2020-11-02 02:37:25 --> Language Class Initialized
INFO - 2020-11-02 02:37:25 --> Config Class Initialized
INFO - 2020-11-02 02:37:25 --> Loader Class Initialized
INFO - 2020-11-02 02:37:25 --> Helper loaded: url_helper
INFO - 2020-11-02 02:37:25 --> Helper loaded: file_helper
INFO - 2020-11-02 02:37:25 --> Helper loaded: form_helper
INFO - 2020-11-02 02:37:25 --> Helper loaded: my_helper
INFO - 2020-11-02 02:37:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:37:25 --> Controller Class Initialized
DEBUG - 2020-11-02 02:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:37:25 --> Final output sent to browser
DEBUG - 2020-11-02 02:37:25 --> Total execution time: 0.2806
INFO - 2020-11-02 02:37:27 --> Config Class Initialized
INFO - 2020-11-02 02:37:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:37:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:37:27 --> Utf8 Class Initialized
INFO - 2020-11-02 02:37:27 --> URI Class Initialized
INFO - 2020-11-02 02:37:27 --> Router Class Initialized
INFO - 2020-11-02 02:37:27 --> Output Class Initialized
INFO - 2020-11-02 02:37:27 --> Security Class Initialized
DEBUG - 2020-11-02 02:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:37:28 --> Input Class Initialized
INFO - 2020-11-02 02:37:28 --> Language Class Initialized
INFO - 2020-11-02 02:37:28 --> Language Class Initialized
INFO - 2020-11-02 02:37:28 --> Config Class Initialized
INFO - 2020-11-02 02:37:28 --> Loader Class Initialized
INFO - 2020-11-02 02:37:28 --> Helper loaded: url_helper
INFO - 2020-11-02 02:37:28 --> Helper loaded: file_helper
INFO - 2020-11-02 02:37:28 --> Helper loaded: form_helper
INFO - 2020-11-02 02:37:28 --> Helper loaded: my_helper
INFO - 2020-11-02 02:37:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:37:28 --> Controller Class Initialized
DEBUG - 2020-11-02 02:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-11-02 02:37:28 --> Final output sent to browser
DEBUG - 2020-11-02 02:37:28 --> Total execution time: 0.2582
INFO - 2020-11-02 02:41:06 --> Config Class Initialized
INFO - 2020-11-02 02:41:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:06 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:06 --> URI Class Initialized
INFO - 2020-11-02 02:41:06 --> Router Class Initialized
INFO - 2020-11-02 02:41:06 --> Output Class Initialized
INFO - 2020-11-02 02:41:06 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:06 --> Input Class Initialized
INFO - 2020-11-02 02:41:06 --> Language Class Initialized
INFO - 2020-11-02 02:41:06 --> Language Class Initialized
INFO - 2020-11-02 02:41:06 --> Config Class Initialized
INFO - 2020-11-02 02:41:06 --> Loader Class Initialized
INFO - 2020-11-02 02:41:06 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:06 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:06 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:06 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:06 --> Controller Class Initialized
INFO - 2020-11-02 02:41:06 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:41:06 --> Config Class Initialized
INFO - 2020-11-02 02:41:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:06 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:06 --> URI Class Initialized
INFO - 2020-11-02 02:41:06 --> Router Class Initialized
INFO - 2020-11-02 02:41:06 --> Output Class Initialized
INFO - 2020-11-02 02:41:06 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:06 --> Input Class Initialized
INFO - 2020-11-02 02:41:06 --> Language Class Initialized
INFO - 2020-11-02 02:41:06 --> Language Class Initialized
INFO - 2020-11-02 02:41:06 --> Config Class Initialized
INFO - 2020-11-02 02:41:06 --> Loader Class Initialized
INFO - 2020-11-02 02:41:06 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:06 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:06 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:06 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:07 --> Controller Class Initialized
DEBUG - 2020-11-02 02:41:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 02:41:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:41:07 --> Final output sent to browser
DEBUG - 2020-11-02 02:41:07 --> Total execution time: 0.2775
INFO - 2020-11-02 02:41:14 --> Config Class Initialized
INFO - 2020-11-02 02:41:15 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:15 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:15 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:15 --> URI Class Initialized
INFO - 2020-11-02 02:41:15 --> Router Class Initialized
INFO - 2020-11-02 02:41:15 --> Output Class Initialized
INFO - 2020-11-02 02:41:15 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:15 --> Input Class Initialized
INFO - 2020-11-02 02:41:15 --> Language Class Initialized
INFO - 2020-11-02 02:41:15 --> Language Class Initialized
INFO - 2020-11-02 02:41:15 --> Config Class Initialized
INFO - 2020-11-02 02:41:15 --> Loader Class Initialized
INFO - 2020-11-02 02:41:15 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:15 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:15 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:15 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:15 --> Controller Class Initialized
INFO - 2020-11-02 02:41:15 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:41:15 --> Final output sent to browser
DEBUG - 2020-11-02 02:41:15 --> Total execution time: 0.2682
INFO - 2020-11-02 02:41:16 --> Config Class Initialized
INFO - 2020-11-02 02:41:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:16 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:16 --> URI Class Initialized
INFO - 2020-11-02 02:41:16 --> Router Class Initialized
INFO - 2020-11-02 02:41:16 --> Output Class Initialized
INFO - 2020-11-02 02:41:16 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:16 --> Input Class Initialized
INFO - 2020-11-02 02:41:16 --> Language Class Initialized
INFO - 2020-11-02 02:41:16 --> Language Class Initialized
INFO - 2020-11-02 02:41:16 --> Config Class Initialized
INFO - 2020-11-02 02:41:16 --> Loader Class Initialized
INFO - 2020-11-02 02:41:16 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:16 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:16 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:16 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:16 --> Controller Class Initialized
DEBUG - 2020-11-02 02:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 02:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:41:16 --> Final output sent to browser
DEBUG - 2020-11-02 02:41:16 --> Total execution time: 0.2800
INFO - 2020-11-02 02:41:25 --> Config Class Initialized
INFO - 2020-11-02 02:41:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:25 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:25 --> URI Class Initialized
INFO - 2020-11-02 02:41:25 --> Router Class Initialized
INFO - 2020-11-02 02:41:25 --> Output Class Initialized
INFO - 2020-11-02 02:41:25 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:25 --> Input Class Initialized
INFO - 2020-11-02 02:41:25 --> Language Class Initialized
INFO - 2020-11-02 02:41:25 --> Language Class Initialized
INFO - 2020-11-02 02:41:25 --> Config Class Initialized
INFO - 2020-11-02 02:41:25 --> Loader Class Initialized
INFO - 2020-11-02 02:41:25 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:25 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:25 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:25 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:25 --> Controller Class Initialized
DEBUG - 2020-11-02 02:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-02 02:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:41:25 --> Final output sent to browser
DEBUG - 2020-11-02 02:41:25 --> Total execution time: 0.2568
INFO - 2020-11-02 02:41:28 --> Config Class Initialized
INFO - 2020-11-02 02:41:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:28 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:28 --> URI Class Initialized
INFO - 2020-11-02 02:41:28 --> Router Class Initialized
INFO - 2020-11-02 02:41:28 --> Output Class Initialized
INFO - 2020-11-02 02:41:28 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:28 --> Input Class Initialized
INFO - 2020-11-02 02:41:28 --> Language Class Initialized
INFO - 2020-11-02 02:41:28 --> Language Class Initialized
INFO - 2020-11-02 02:41:28 --> Config Class Initialized
INFO - 2020-11-02 02:41:28 --> Loader Class Initialized
INFO - 2020-11-02 02:41:28 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:28 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:28 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:28 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:28 --> Controller Class Initialized
DEBUG - 2020-11-02 02:41:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-02 02:41:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:41:28 --> Final output sent to browser
DEBUG - 2020-11-02 02:41:28 --> Total execution time: 0.2582
INFO - 2020-11-02 02:41:47 --> Config Class Initialized
INFO - 2020-11-02 02:41:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:47 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:47 --> URI Class Initialized
INFO - 2020-11-02 02:41:47 --> Router Class Initialized
INFO - 2020-11-02 02:41:48 --> Output Class Initialized
INFO - 2020-11-02 02:41:48 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:48 --> Input Class Initialized
INFO - 2020-11-02 02:41:48 --> Language Class Initialized
INFO - 2020-11-02 02:41:48 --> Language Class Initialized
INFO - 2020-11-02 02:41:48 --> Config Class Initialized
INFO - 2020-11-02 02:41:48 --> Loader Class Initialized
INFO - 2020-11-02 02:41:48 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:48 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:48 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:48 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:48 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:48 --> Controller Class Initialized
INFO - 2020-11-02 02:41:48 --> Config Class Initialized
INFO - 2020-11-02 02:41:48 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:48 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:48 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:48 --> URI Class Initialized
INFO - 2020-11-02 02:41:48 --> Router Class Initialized
INFO - 2020-11-02 02:41:48 --> Output Class Initialized
INFO - 2020-11-02 02:41:48 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:48 --> Input Class Initialized
INFO - 2020-11-02 02:41:48 --> Language Class Initialized
INFO - 2020-11-02 02:41:48 --> Language Class Initialized
INFO - 2020-11-02 02:41:48 --> Config Class Initialized
INFO - 2020-11-02 02:41:48 --> Loader Class Initialized
INFO - 2020-11-02 02:41:48 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:48 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:48 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:48 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:48 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:48 --> Controller Class Initialized
DEBUG - 2020-11-02 02:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-02 02:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:41:48 --> Final output sent to browser
DEBUG - 2020-11-02 02:41:48 --> Total execution time: 0.3546
INFO - 2020-11-02 02:41:51 --> Config Class Initialized
INFO - 2020-11-02 02:41:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:51 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:51 --> URI Class Initialized
INFO - 2020-11-02 02:41:51 --> Router Class Initialized
INFO - 2020-11-02 02:41:51 --> Output Class Initialized
INFO - 2020-11-02 02:41:51 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:51 --> Input Class Initialized
INFO - 2020-11-02 02:41:51 --> Language Class Initialized
INFO - 2020-11-02 02:41:51 --> Language Class Initialized
INFO - 2020-11-02 02:41:51 --> Config Class Initialized
INFO - 2020-11-02 02:41:51 --> Loader Class Initialized
INFO - 2020-11-02 02:41:51 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:51 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:51 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:51 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:51 --> Controller Class Initialized
DEBUG - 2020-11-02 02:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-02 02:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:41:51 --> Final output sent to browser
DEBUG - 2020-11-02 02:41:51 --> Total execution time: 0.2631
INFO - 2020-11-02 02:41:56 --> Config Class Initialized
INFO - 2020-11-02 02:41:56 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:56 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:56 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:56 --> URI Class Initialized
INFO - 2020-11-02 02:41:56 --> Router Class Initialized
INFO - 2020-11-02 02:41:56 --> Output Class Initialized
INFO - 2020-11-02 02:41:56 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:56 --> Input Class Initialized
INFO - 2020-11-02 02:41:56 --> Language Class Initialized
INFO - 2020-11-02 02:41:56 --> Language Class Initialized
INFO - 2020-11-02 02:41:56 --> Config Class Initialized
INFO - 2020-11-02 02:41:56 --> Loader Class Initialized
INFO - 2020-11-02 02:41:56 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:56 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:56 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:56 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:57 --> Controller Class Initialized
INFO - 2020-11-02 02:41:57 --> Config Class Initialized
INFO - 2020-11-02 02:41:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:41:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:41:57 --> Utf8 Class Initialized
INFO - 2020-11-02 02:41:57 --> URI Class Initialized
INFO - 2020-11-02 02:41:57 --> Router Class Initialized
INFO - 2020-11-02 02:41:57 --> Output Class Initialized
INFO - 2020-11-02 02:41:57 --> Security Class Initialized
DEBUG - 2020-11-02 02:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:41:57 --> Input Class Initialized
INFO - 2020-11-02 02:41:57 --> Language Class Initialized
INFO - 2020-11-02 02:41:57 --> Language Class Initialized
INFO - 2020-11-02 02:41:57 --> Config Class Initialized
INFO - 2020-11-02 02:41:57 --> Loader Class Initialized
INFO - 2020-11-02 02:41:57 --> Helper loaded: url_helper
INFO - 2020-11-02 02:41:57 --> Helper loaded: file_helper
INFO - 2020-11-02 02:41:57 --> Helper loaded: form_helper
INFO - 2020-11-02 02:41:57 --> Helper loaded: my_helper
INFO - 2020-11-02 02:41:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:41:57 --> Controller Class Initialized
DEBUG - 2020-11-02 02:41:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-02 02:41:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:41:57 --> Final output sent to browser
DEBUG - 2020-11-02 02:41:57 --> Total execution time: 0.2609
INFO - 2020-11-02 02:42:05 --> Config Class Initialized
INFO - 2020-11-02 02:42:05 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:05 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:05 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:05 --> URI Class Initialized
INFO - 2020-11-02 02:42:05 --> Router Class Initialized
INFO - 2020-11-02 02:42:05 --> Output Class Initialized
INFO - 2020-11-02 02:42:05 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:05 --> Input Class Initialized
INFO - 2020-11-02 02:42:05 --> Language Class Initialized
INFO - 2020-11-02 02:42:05 --> Language Class Initialized
INFO - 2020-11-02 02:42:05 --> Config Class Initialized
INFO - 2020-11-02 02:42:05 --> Loader Class Initialized
INFO - 2020-11-02 02:42:05 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:05 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:05 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:05 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:05 --> Controller Class Initialized
INFO - 2020-11-02 02:42:05 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:05 --> Total execution time: 0.4386
INFO - 2020-11-02 02:42:08 --> Config Class Initialized
INFO - 2020-11-02 02:42:08 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:08 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:08 --> URI Class Initialized
INFO - 2020-11-02 02:42:08 --> Router Class Initialized
INFO - 2020-11-02 02:42:08 --> Output Class Initialized
INFO - 2020-11-02 02:42:08 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:08 --> Input Class Initialized
INFO - 2020-11-02 02:42:08 --> Language Class Initialized
INFO - 2020-11-02 02:42:08 --> Language Class Initialized
INFO - 2020-11-02 02:42:08 --> Config Class Initialized
INFO - 2020-11-02 02:42:08 --> Loader Class Initialized
INFO - 2020-11-02 02:42:08 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:08 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:08 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:08 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:08 --> Controller Class Initialized
INFO - 2020-11-02 02:42:09 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:09 --> Total execution time: 0.3528
INFO - 2020-11-02 02:42:10 --> Config Class Initialized
INFO - 2020-11-02 02:42:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:10 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:10 --> URI Class Initialized
INFO - 2020-11-02 02:42:10 --> Router Class Initialized
INFO - 2020-11-02 02:42:10 --> Output Class Initialized
INFO - 2020-11-02 02:42:10 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:11 --> Input Class Initialized
INFO - 2020-11-02 02:42:11 --> Language Class Initialized
INFO - 2020-11-02 02:42:11 --> Language Class Initialized
INFO - 2020-11-02 02:42:11 --> Config Class Initialized
INFO - 2020-11-02 02:42:11 --> Loader Class Initialized
INFO - 2020-11-02 02:42:11 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:11 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:11 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:11 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:11 --> Controller Class Initialized
INFO - 2020-11-02 02:42:11 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:11 --> Total execution time: 0.3801
INFO - 2020-11-02 02:42:13 --> Config Class Initialized
INFO - 2020-11-02 02:42:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:13 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:13 --> URI Class Initialized
INFO - 2020-11-02 02:42:13 --> Router Class Initialized
INFO - 2020-11-02 02:42:13 --> Output Class Initialized
INFO - 2020-11-02 02:42:13 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:13 --> Input Class Initialized
INFO - 2020-11-02 02:42:13 --> Language Class Initialized
INFO - 2020-11-02 02:42:13 --> Language Class Initialized
INFO - 2020-11-02 02:42:13 --> Config Class Initialized
INFO - 2020-11-02 02:42:13 --> Loader Class Initialized
INFO - 2020-11-02 02:42:13 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:13 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:13 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:13 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:13 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:13 --> Controller Class Initialized
DEBUG - 2020-11-02 02:42:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-02 02:42:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:42:13 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:13 --> Total execution time: 0.3347
INFO - 2020-11-02 02:42:16 --> Config Class Initialized
INFO - 2020-11-02 02:42:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:16 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:16 --> URI Class Initialized
INFO - 2020-11-02 02:42:16 --> Router Class Initialized
INFO - 2020-11-02 02:42:16 --> Output Class Initialized
INFO - 2020-11-02 02:42:16 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:16 --> Input Class Initialized
INFO - 2020-11-02 02:42:16 --> Language Class Initialized
INFO - 2020-11-02 02:42:16 --> Language Class Initialized
INFO - 2020-11-02 02:42:16 --> Config Class Initialized
INFO - 2020-11-02 02:42:16 --> Loader Class Initialized
INFO - 2020-11-02 02:42:16 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:16 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:16 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:16 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:16 --> Controller Class Initialized
DEBUG - 2020-11-02 02:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-02 02:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:42:16 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:16 --> Total execution time: 0.2810
INFO - 2020-11-02 02:42:41 --> Config Class Initialized
INFO - 2020-11-02 02:42:41 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:41 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:41 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:41 --> URI Class Initialized
INFO - 2020-11-02 02:42:41 --> Router Class Initialized
INFO - 2020-11-02 02:42:41 --> Output Class Initialized
INFO - 2020-11-02 02:42:41 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:41 --> Input Class Initialized
INFO - 2020-11-02 02:42:41 --> Language Class Initialized
INFO - 2020-11-02 02:42:41 --> Language Class Initialized
INFO - 2020-11-02 02:42:41 --> Config Class Initialized
INFO - 2020-11-02 02:42:41 --> Loader Class Initialized
INFO - 2020-11-02 02:42:41 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:41 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:41 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:41 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:41 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:41 --> Controller Class Initialized
INFO - 2020-11-02 02:42:42 --> Config Class Initialized
INFO - 2020-11-02 02:42:42 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:42 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:42 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:42 --> URI Class Initialized
INFO - 2020-11-02 02:42:42 --> Router Class Initialized
INFO - 2020-11-02 02:42:42 --> Output Class Initialized
INFO - 2020-11-02 02:42:42 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:42 --> Input Class Initialized
INFO - 2020-11-02 02:42:42 --> Language Class Initialized
INFO - 2020-11-02 02:42:42 --> Language Class Initialized
INFO - 2020-11-02 02:42:42 --> Config Class Initialized
INFO - 2020-11-02 02:42:42 --> Loader Class Initialized
INFO - 2020-11-02 02:42:42 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:42 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:42 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:42 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:42 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:42 --> Controller Class Initialized
DEBUG - 2020-11-02 02:42:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-02 02:42:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:42:42 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:42 --> Total execution time: 0.2543
INFO - 2020-11-02 02:42:49 --> Config Class Initialized
INFO - 2020-11-02 02:42:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:49 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:49 --> URI Class Initialized
INFO - 2020-11-02 02:42:49 --> Router Class Initialized
INFO - 2020-11-02 02:42:49 --> Output Class Initialized
INFO - 2020-11-02 02:42:49 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:49 --> Input Class Initialized
INFO - 2020-11-02 02:42:49 --> Language Class Initialized
INFO - 2020-11-02 02:42:49 --> Language Class Initialized
INFO - 2020-11-02 02:42:49 --> Config Class Initialized
INFO - 2020-11-02 02:42:49 --> Loader Class Initialized
INFO - 2020-11-02 02:42:49 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:49 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:49 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:49 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:49 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:49 --> Controller Class Initialized
DEBUG - 2020-11-02 02:42:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-02 02:42:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:42:49 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:49 --> Total execution time: 0.2578
INFO - 2020-11-02 02:42:49 --> Config Class Initialized
INFO - 2020-11-02 02:42:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:49 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:49 --> URI Class Initialized
INFO - 2020-11-02 02:42:49 --> Router Class Initialized
INFO - 2020-11-02 02:42:49 --> Output Class Initialized
INFO - 2020-11-02 02:42:49 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:49 --> Input Class Initialized
INFO - 2020-11-02 02:42:49 --> Language Class Initialized
INFO - 2020-11-02 02:42:49 --> Language Class Initialized
INFO - 2020-11-02 02:42:49 --> Config Class Initialized
INFO - 2020-11-02 02:42:49 --> Loader Class Initialized
INFO - 2020-11-02 02:42:49 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:49 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:49 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:49 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:49 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:49 --> Controller Class Initialized
INFO - 2020-11-02 02:42:52 --> Config Class Initialized
INFO - 2020-11-02 02:42:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:52 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:52 --> URI Class Initialized
INFO - 2020-11-02 02:42:52 --> Router Class Initialized
INFO - 2020-11-02 02:42:52 --> Output Class Initialized
INFO - 2020-11-02 02:42:52 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:52 --> Input Class Initialized
INFO - 2020-11-02 02:42:52 --> Language Class Initialized
INFO - 2020-11-02 02:42:52 --> Language Class Initialized
INFO - 2020-11-02 02:42:52 --> Config Class Initialized
INFO - 2020-11-02 02:42:52 --> Loader Class Initialized
INFO - 2020-11-02 02:42:52 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:52 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:52 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:52 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:52 --> Controller Class Initialized
DEBUG - 2020-11-02 02:42:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-11-02 02:42:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:42:52 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:52 --> Total execution time: 0.2705
INFO - 2020-11-02 02:42:52 --> Config Class Initialized
INFO - 2020-11-02 02:42:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:53 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:53 --> URI Class Initialized
INFO - 2020-11-02 02:42:53 --> Router Class Initialized
INFO - 2020-11-02 02:42:53 --> Output Class Initialized
INFO - 2020-11-02 02:42:53 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:53 --> Input Class Initialized
INFO - 2020-11-02 02:42:53 --> Language Class Initialized
INFO - 2020-11-02 02:42:53 --> Language Class Initialized
INFO - 2020-11-02 02:42:53 --> Config Class Initialized
INFO - 2020-11-02 02:42:53 --> Loader Class Initialized
INFO - 2020-11-02 02:42:53 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:53 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:53 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:53 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:53 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:53 --> Controller Class Initialized
INFO - 2020-11-02 02:42:54 --> Config Class Initialized
INFO - 2020-11-02 02:42:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:55 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:55 --> URI Class Initialized
INFO - 2020-11-02 02:42:55 --> Router Class Initialized
INFO - 2020-11-02 02:42:55 --> Output Class Initialized
INFO - 2020-11-02 02:42:55 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:55 --> Input Class Initialized
INFO - 2020-11-02 02:42:55 --> Language Class Initialized
INFO - 2020-11-02 02:42:55 --> Language Class Initialized
INFO - 2020-11-02 02:42:55 --> Config Class Initialized
INFO - 2020-11-02 02:42:55 --> Loader Class Initialized
INFO - 2020-11-02 02:42:55 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:55 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:55 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:55 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:55 --> Controller Class Initialized
INFO - 2020-11-02 02:42:55 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:42:55 --> Config Class Initialized
INFO - 2020-11-02 02:42:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:42:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:42:55 --> Utf8 Class Initialized
INFO - 2020-11-02 02:42:55 --> URI Class Initialized
INFO - 2020-11-02 02:42:55 --> Router Class Initialized
INFO - 2020-11-02 02:42:55 --> Output Class Initialized
INFO - 2020-11-02 02:42:55 --> Security Class Initialized
DEBUG - 2020-11-02 02:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:42:55 --> Input Class Initialized
INFO - 2020-11-02 02:42:55 --> Language Class Initialized
INFO - 2020-11-02 02:42:55 --> Language Class Initialized
INFO - 2020-11-02 02:42:55 --> Config Class Initialized
INFO - 2020-11-02 02:42:55 --> Loader Class Initialized
INFO - 2020-11-02 02:42:55 --> Helper loaded: url_helper
INFO - 2020-11-02 02:42:55 --> Helper loaded: file_helper
INFO - 2020-11-02 02:42:55 --> Helper loaded: form_helper
INFO - 2020-11-02 02:42:55 --> Helper loaded: my_helper
INFO - 2020-11-02 02:42:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:42:55 --> Controller Class Initialized
DEBUG - 2020-11-02 02:42:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 02:42:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:42:55 --> Final output sent to browser
DEBUG - 2020-11-02 02:42:55 --> Total execution time: 0.2997
INFO - 2020-11-02 02:43:01 --> Config Class Initialized
INFO - 2020-11-02 02:43:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:01 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:01 --> URI Class Initialized
INFO - 2020-11-02 02:43:01 --> Router Class Initialized
INFO - 2020-11-02 02:43:01 --> Output Class Initialized
INFO - 2020-11-02 02:43:01 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:01 --> Input Class Initialized
INFO - 2020-11-02 02:43:01 --> Language Class Initialized
INFO - 2020-11-02 02:43:01 --> Language Class Initialized
INFO - 2020-11-02 02:43:01 --> Config Class Initialized
INFO - 2020-11-02 02:43:01 --> Loader Class Initialized
INFO - 2020-11-02 02:43:01 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:01 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:01 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:01 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:01 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:01 --> Controller Class Initialized
INFO - 2020-11-02 02:43:01 --> Helper loaded: cookie_helper
INFO - 2020-11-02 02:43:01 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:01 --> Total execution time: 0.2629
INFO - 2020-11-02 02:43:02 --> Config Class Initialized
INFO - 2020-11-02 02:43:02 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:02 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:02 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:02 --> URI Class Initialized
INFO - 2020-11-02 02:43:02 --> Router Class Initialized
INFO - 2020-11-02 02:43:02 --> Output Class Initialized
INFO - 2020-11-02 02:43:02 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:03 --> Input Class Initialized
INFO - 2020-11-02 02:43:03 --> Language Class Initialized
INFO - 2020-11-02 02:43:03 --> Language Class Initialized
INFO - 2020-11-02 02:43:03 --> Config Class Initialized
INFO - 2020-11-02 02:43:03 --> Loader Class Initialized
INFO - 2020-11-02 02:43:03 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:03 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:03 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:03 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:03 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:03 --> Controller Class Initialized
DEBUG - 2020-11-02 02:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 02:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:43:03 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:03 --> Total execution time: 0.2859
INFO - 2020-11-02 02:43:04 --> Config Class Initialized
INFO - 2020-11-02 02:43:04 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:04 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:04 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:04 --> URI Class Initialized
INFO - 2020-11-02 02:43:04 --> Router Class Initialized
INFO - 2020-11-02 02:43:04 --> Output Class Initialized
INFO - 2020-11-02 02:43:04 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:04 --> Input Class Initialized
INFO - 2020-11-02 02:43:04 --> Language Class Initialized
INFO - 2020-11-02 02:43:04 --> Language Class Initialized
INFO - 2020-11-02 02:43:04 --> Config Class Initialized
INFO - 2020-11-02 02:43:04 --> Loader Class Initialized
INFO - 2020-11-02 02:43:04 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:04 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:04 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:04 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:04 --> Controller Class Initialized
DEBUG - 2020-11-02 02:43:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:43:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:43:04 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:04 --> Total execution time: 0.2894
INFO - 2020-11-02 02:43:05 --> Config Class Initialized
INFO - 2020-11-02 02:43:05 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:05 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:05 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:05 --> URI Class Initialized
INFO - 2020-11-02 02:43:06 --> Router Class Initialized
INFO - 2020-11-02 02:43:06 --> Output Class Initialized
INFO - 2020-11-02 02:43:06 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:06 --> Input Class Initialized
INFO - 2020-11-02 02:43:06 --> Language Class Initialized
INFO - 2020-11-02 02:43:06 --> Language Class Initialized
INFO - 2020-11-02 02:43:06 --> Config Class Initialized
INFO - 2020-11-02 02:43:06 --> Loader Class Initialized
INFO - 2020-11-02 02:43:06 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:06 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:06 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:06 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:06 --> Controller Class Initialized
DEBUG - 2020-11-02 02:43:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:43:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:43:06 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:06 --> Total execution time: 0.2595
INFO - 2020-11-02 02:43:06 --> Config Class Initialized
INFO - 2020-11-02 02:43:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:06 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:06 --> URI Class Initialized
INFO - 2020-11-02 02:43:06 --> Router Class Initialized
INFO - 2020-11-02 02:43:06 --> Output Class Initialized
INFO - 2020-11-02 02:43:06 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:06 --> Input Class Initialized
INFO - 2020-11-02 02:43:06 --> Language Class Initialized
INFO - 2020-11-02 02:43:06 --> Language Class Initialized
INFO - 2020-11-02 02:43:06 --> Config Class Initialized
INFO - 2020-11-02 02:43:06 --> Loader Class Initialized
INFO - 2020-11-02 02:43:06 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:06 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:06 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:06 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:06 --> Controller Class Initialized
INFO - 2020-11-02 02:43:08 --> Config Class Initialized
INFO - 2020-11-02 02:43:08 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:08 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:08 --> URI Class Initialized
INFO - 2020-11-02 02:43:08 --> Router Class Initialized
INFO - 2020-11-02 02:43:08 --> Output Class Initialized
INFO - 2020-11-02 02:43:08 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:08 --> Input Class Initialized
INFO - 2020-11-02 02:43:08 --> Language Class Initialized
INFO - 2020-11-02 02:43:08 --> Language Class Initialized
INFO - 2020-11-02 02:43:08 --> Config Class Initialized
INFO - 2020-11-02 02:43:08 --> Loader Class Initialized
INFO - 2020-11-02 02:43:08 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:08 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:08 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:08 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:08 --> Controller Class Initialized
INFO - 2020-11-02 02:43:08 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:08 --> Total execution time: 0.2698
INFO - 2020-11-02 02:43:16 --> Config Class Initialized
INFO - 2020-11-02 02:43:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:16 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:16 --> URI Class Initialized
INFO - 2020-11-02 02:43:16 --> Router Class Initialized
INFO - 2020-11-02 02:43:16 --> Output Class Initialized
INFO - 2020-11-02 02:43:16 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:16 --> Input Class Initialized
INFO - 2020-11-02 02:43:16 --> Language Class Initialized
INFO - 2020-11-02 02:43:16 --> Language Class Initialized
INFO - 2020-11-02 02:43:16 --> Config Class Initialized
INFO - 2020-11-02 02:43:16 --> Loader Class Initialized
INFO - 2020-11-02 02:43:16 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:16 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:16 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:16 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:16 --> Controller Class Initialized
ERROR - 2020-11-02 02:43:16 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 853
INFO - 2020-11-02 02:43:17 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:17 --> Total execution time: 0.4330
INFO - 2020-11-02 02:43:36 --> Config Class Initialized
INFO - 2020-11-02 02:43:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:37 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:37 --> URI Class Initialized
INFO - 2020-11-02 02:43:37 --> Router Class Initialized
INFO - 2020-11-02 02:43:37 --> Output Class Initialized
INFO - 2020-11-02 02:43:37 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:37 --> Input Class Initialized
INFO - 2020-11-02 02:43:37 --> Language Class Initialized
INFO - 2020-11-02 02:43:37 --> Language Class Initialized
INFO - 2020-11-02 02:43:37 --> Config Class Initialized
INFO - 2020-11-02 02:43:37 --> Loader Class Initialized
INFO - 2020-11-02 02:43:37 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:37 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:37 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:37 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:37 --> Controller Class Initialized
DEBUG - 2020-11-02 02:43:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:43:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:43:37 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:37 --> Total execution time: 0.2956
INFO - 2020-11-02 02:43:37 --> Config Class Initialized
INFO - 2020-11-02 02:43:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:37 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:37 --> URI Class Initialized
INFO - 2020-11-02 02:43:37 --> Router Class Initialized
INFO - 2020-11-02 02:43:37 --> Output Class Initialized
INFO - 2020-11-02 02:43:37 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:37 --> Input Class Initialized
INFO - 2020-11-02 02:43:37 --> Language Class Initialized
INFO - 2020-11-02 02:43:37 --> Language Class Initialized
INFO - 2020-11-02 02:43:37 --> Config Class Initialized
INFO - 2020-11-02 02:43:37 --> Loader Class Initialized
INFO - 2020-11-02 02:43:37 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:37 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:37 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:37 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:37 --> Controller Class Initialized
INFO - 2020-11-02 02:43:39 --> Config Class Initialized
INFO - 2020-11-02 02:43:39 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:39 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:39 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:39 --> URI Class Initialized
INFO - 2020-11-02 02:43:39 --> Router Class Initialized
INFO - 2020-11-02 02:43:39 --> Output Class Initialized
INFO - 2020-11-02 02:43:39 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:39 --> Input Class Initialized
INFO - 2020-11-02 02:43:39 --> Language Class Initialized
INFO - 2020-11-02 02:43:39 --> Language Class Initialized
INFO - 2020-11-02 02:43:39 --> Config Class Initialized
INFO - 2020-11-02 02:43:39 --> Loader Class Initialized
INFO - 2020-11-02 02:43:39 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:39 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:39 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:39 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:39 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:39 --> Controller Class Initialized
INFO - 2020-11-02 02:43:39 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:39 --> Total execution time: 0.2666
INFO - 2020-11-02 02:43:59 --> Config Class Initialized
INFO - 2020-11-02 02:43:59 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:59 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:59 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:59 --> URI Class Initialized
INFO - 2020-11-02 02:43:59 --> Router Class Initialized
INFO - 2020-11-02 02:43:59 --> Output Class Initialized
INFO - 2020-11-02 02:43:59 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:59 --> Input Class Initialized
INFO - 2020-11-02 02:43:59 --> Language Class Initialized
INFO - 2020-11-02 02:43:59 --> Language Class Initialized
INFO - 2020-11-02 02:43:59 --> Config Class Initialized
INFO - 2020-11-02 02:43:59 --> Loader Class Initialized
INFO - 2020-11-02 02:43:59 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:59 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:59 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:59 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:59 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:59 --> Controller Class Initialized
DEBUG - 2020-11-02 02:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:43:59 --> Final output sent to browser
DEBUG - 2020-11-02 02:43:59 --> Total execution time: 0.2992
INFO - 2020-11-02 02:43:59 --> Config Class Initialized
INFO - 2020-11-02 02:43:59 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:43:59 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:43:59 --> Utf8 Class Initialized
INFO - 2020-11-02 02:43:59 --> URI Class Initialized
INFO - 2020-11-02 02:43:59 --> Router Class Initialized
INFO - 2020-11-02 02:43:59 --> Output Class Initialized
INFO - 2020-11-02 02:43:59 --> Security Class Initialized
DEBUG - 2020-11-02 02:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:43:59 --> Input Class Initialized
INFO - 2020-11-02 02:43:59 --> Language Class Initialized
INFO - 2020-11-02 02:43:59 --> Language Class Initialized
INFO - 2020-11-02 02:43:59 --> Config Class Initialized
INFO - 2020-11-02 02:43:59 --> Loader Class Initialized
INFO - 2020-11-02 02:43:59 --> Helper loaded: url_helper
INFO - 2020-11-02 02:43:59 --> Helper loaded: file_helper
INFO - 2020-11-02 02:43:59 --> Helper loaded: form_helper
INFO - 2020-11-02 02:43:59 --> Helper loaded: my_helper
INFO - 2020-11-02 02:43:59 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:43:59 --> Controller Class Initialized
INFO - 2020-11-02 02:44:01 --> Config Class Initialized
INFO - 2020-11-02 02:44:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:01 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:01 --> URI Class Initialized
INFO - 2020-11-02 02:44:01 --> Router Class Initialized
INFO - 2020-11-02 02:44:01 --> Output Class Initialized
INFO - 2020-11-02 02:44:01 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:01 --> Input Class Initialized
INFO - 2020-11-02 02:44:01 --> Language Class Initialized
INFO - 2020-11-02 02:44:01 --> Language Class Initialized
INFO - 2020-11-02 02:44:01 --> Config Class Initialized
INFO - 2020-11-02 02:44:01 --> Loader Class Initialized
INFO - 2020-11-02 02:44:01 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:01 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:01 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:01 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:01 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:01 --> Controller Class Initialized
INFO - 2020-11-02 02:44:01 --> Final output sent to browser
DEBUG - 2020-11-02 02:44:01 --> Total execution time: 0.2518
INFO - 2020-11-02 02:44:07 --> Config Class Initialized
INFO - 2020-11-02 02:44:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:07 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:07 --> URI Class Initialized
INFO - 2020-11-02 02:44:07 --> Router Class Initialized
INFO - 2020-11-02 02:44:07 --> Output Class Initialized
INFO - 2020-11-02 02:44:07 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:07 --> Input Class Initialized
INFO - 2020-11-02 02:44:07 --> Language Class Initialized
INFO - 2020-11-02 02:44:07 --> Language Class Initialized
INFO - 2020-11-02 02:44:07 --> Config Class Initialized
INFO - 2020-11-02 02:44:07 --> Loader Class Initialized
INFO - 2020-11-02 02:44:07 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:07 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:07 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:07 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:07 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:07 --> Controller Class Initialized
ERROR - 2020-11-02 02:44:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 853
ERROR - 2020-11-02 02:44:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 853
INFO - 2020-11-02 02:44:08 --> Final output sent to browser
DEBUG - 2020-11-02 02:44:08 --> Total execution time: 0.4077
INFO - 2020-11-02 02:44:30 --> Config Class Initialized
INFO - 2020-11-02 02:44:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:30 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:30 --> URI Class Initialized
INFO - 2020-11-02 02:44:30 --> Router Class Initialized
INFO - 2020-11-02 02:44:30 --> Output Class Initialized
INFO - 2020-11-02 02:44:30 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:30 --> Input Class Initialized
INFO - 2020-11-02 02:44:30 --> Language Class Initialized
INFO - 2020-11-02 02:44:30 --> Language Class Initialized
INFO - 2020-11-02 02:44:30 --> Config Class Initialized
INFO - 2020-11-02 02:44:30 --> Loader Class Initialized
INFO - 2020-11-02 02:44:30 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:30 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:30 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:30 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:30 --> Controller Class Initialized
DEBUG - 2020-11-02 02:44:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:44:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:44:30 --> Final output sent to browser
DEBUG - 2020-11-02 02:44:30 --> Total execution time: 0.2902
INFO - 2020-11-02 02:44:30 --> Config Class Initialized
INFO - 2020-11-02 02:44:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:30 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:30 --> URI Class Initialized
INFO - 2020-11-02 02:44:30 --> Router Class Initialized
INFO - 2020-11-02 02:44:30 --> Output Class Initialized
INFO - 2020-11-02 02:44:30 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:30 --> Input Class Initialized
INFO - 2020-11-02 02:44:30 --> Language Class Initialized
INFO - 2020-11-02 02:44:30 --> Language Class Initialized
INFO - 2020-11-02 02:44:30 --> Config Class Initialized
INFO - 2020-11-02 02:44:30 --> Loader Class Initialized
INFO - 2020-11-02 02:44:30 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:30 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:30 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:30 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:30 --> Controller Class Initialized
INFO - 2020-11-02 02:44:32 --> Config Class Initialized
INFO - 2020-11-02 02:44:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:32 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:32 --> URI Class Initialized
INFO - 2020-11-02 02:44:32 --> Router Class Initialized
INFO - 2020-11-02 02:44:32 --> Output Class Initialized
INFO - 2020-11-02 02:44:32 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:32 --> Input Class Initialized
INFO - 2020-11-02 02:44:32 --> Language Class Initialized
INFO - 2020-11-02 02:44:32 --> Language Class Initialized
INFO - 2020-11-02 02:44:32 --> Config Class Initialized
INFO - 2020-11-02 02:44:32 --> Loader Class Initialized
INFO - 2020-11-02 02:44:32 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:32 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:32 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:32 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:32 --> Controller Class Initialized
INFO - 2020-11-02 02:44:32 --> Final output sent to browser
DEBUG - 2020-11-02 02:44:32 --> Total execution time: 0.2587
INFO - 2020-11-02 02:44:37 --> Config Class Initialized
INFO - 2020-11-02 02:44:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:37 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:37 --> URI Class Initialized
INFO - 2020-11-02 02:44:37 --> Router Class Initialized
INFO - 2020-11-02 02:44:37 --> Output Class Initialized
INFO - 2020-11-02 02:44:37 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:37 --> Input Class Initialized
INFO - 2020-11-02 02:44:37 --> Language Class Initialized
INFO - 2020-11-02 02:44:37 --> Language Class Initialized
INFO - 2020-11-02 02:44:37 --> Config Class Initialized
INFO - 2020-11-02 02:44:37 --> Loader Class Initialized
INFO - 2020-11-02 02:44:37 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:37 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:37 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:37 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:37 --> Controller Class Initialized
INFO - 2020-11-02 02:44:37 --> Final output sent to browser
DEBUG - 2020-11-02 02:44:37 --> Total execution time: 0.3455
INFO - 2020-11-02 02:44:46 --> Config Class Initialized
INFO - 2020-11-02 02:44:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:46 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:46 --> URI Class Initialized
INFO - 2020-11-02 02:44:46 --> Router Class Initialized
INFO - 2020-11-02 02:44:46 --> Output Class Initialized
INFO - 2020-11-02 02:44:46 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:46 --> Input Class Initialized
INFO - 2020-11-02 02:44:46 --> Language Class Initialized
INFO - 2020-11-02 02:44:46 --> Language Class Initialized
INFO - 2020-11-02 02:44:46 --> Config Class Initialized
INFO - 2020-11-02 02:44:46 --> Loader Class Initialized
INFO - 2020-11-02 02:44:46 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:46 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:46 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:46 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:46 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:46 --> Controller Class Initialized
INFO - 2020-11-02 02:44:47 --> Final output sent to browser
DEBUG - 2020-11-02 02:44:47 --> Total execution time: 0.2608
INFO - 2020-11-02 02:44:48 --> Config Class Initialized
INFO - 2020-11-02 02:44:48 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:48 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:48 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:48 --> URI Class Initialized
INFO - 2020-11-02 02:44:48 --> Router Class Initialized
INFO - 2020-11-02 02:44:48 --> Output Class Initialized
INFO - 2020-11-02 02:44:48 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:48 --> Input Class Initialized
INFO - 2020-11-02 02:44:48 --> Language Class Initialized
INFO - 2020-11-02 02:44:48 --> Language Class Initialized
INFO - 2020-11-02 02:44:48 --> Config Class Initialized
INFO - 2020-11-02 02:44:48 --> Loader Class Initialized
INFO - 2020-11-02 02:44:48 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:48 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:48 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:48 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:48 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:48 --> Controller Class Initialized
INFO - 2020-11-02 02:44:48 --> Final output sent to browser
DEBUG - 2020-11-02 02:44:48 --> Total execution time: 0.2777
INFO - 2020-11-02 02:44:51 --> Config Class Initialized
INFO - 2020-11-02 02:44:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:44:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:44:51 --> Utf8 Class Initialized
INFO - 2020-11-02 02:44:51 --> URI Class Initialized
INFO - 2020-11-02 02:44:51 --> Router Class Initialized
INFO - 2020-11-02 02:44:51 --> Output Class Initialized
INFO - 2020-11-02 02:44:51 --> Security Class Initialized
DEBUG - 2020-11-02 02:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:44:51 --> Input Class Initialized
INFO - 2020-11-02 02:44:51 --> Language Class Initialized
INFO - 2020-11-02 02:44:51 --> Language Class Initialized
INFO - 2020-11-02 02:44:51 --> Config Class Initialized
INFO - 2020-11-02 02:44:51 --> Loader Class Initialized
INFO - 2020-11-02 02:44:51 --> Helper loaded: url_helper
INFO - 2020-11-02 02:44:51 --> Helper loaded: file_helper
INFO - 2020-11-02 02:44:51 --> Helper loaded: form_helper
INFO - 2020-11-02 02:44:51 --> Helper loaded: my_helper
INFO - 2020-11-02 02:44:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:44:52 --> Controller Class Initialized
INFO - 2020-11-02 02:44:52 --> Final output sent to browser
DEBUG - 2020-11-02 02:44:52 --> Total execution time: 0.2335
INFO - 2020-11-02 02:45:14 --> Config Class Initialized
INFO - 2020-11-02 02:45:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:45:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:45:14 --> Utf8 Class Initialized
INFO - 2020-11-02 02:45:14 --> URI Class Initialized
INFO - 2020-11-02 02:45:14 --> Router Class Initialized
INFO - 2020-11-02 02:45:14 --> Output Class Initialized
INFO - 2020-11-02 02:45:14 --> Security Class Initialized
DEBUG - 2020-11-02 02:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:45:14 --> Input Class Initialized
INFO - 2020-11-02 02:45:14 --> Language Class Initialized
INFO - 2020-11-02 02:45:14 --> Language Class Initialized
INFO - 2020-11-02 02:45:14 --> Config Class Initialized
INFO - 2020-11-02 02:45:14 --> Loader Class Initialized
INFO - 2020-11-02 02:45:14 --> Helper loaded: url_helper
INFO - 2020-11-02 02:45:14 --> Helper loaded: file_helper
INFO - 2020-11-02 02:45:14 --> Helper loaded: form_helper
INFO - 2020-11-02 02:45:14 --> Helper loaded: my_helper
INFO - 2020-11-02 02:45:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:45:14 --> Controller Class Initialized
DEBUG - 2020-11-02 02:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:45:14 --> Final output sent to browser
DEBUG - 2020-11-02 02:45:14 --> Total execution time: 0.2859
INFO - 2020-11-02 02:45:14 --> Config Class Initialized
INFO - 2020-11-02 02:45:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:45:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:45:14 --> Utf8 Class Initialized
INFO - 2020-11-02 02:45:14 --> URI Class Initialized
INFO - 2020-11-02 02:45:14 --> Router Class Initialized
INFO - 2020-11-02 02:45:14 --> Output Class Initialized
INFO - 2020-11-02 02:45:14 --> Security Class Initialized
DEBUG - 2020-11-02 02:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:45:14 --> Input Class Initialized
INFO - 2020-11-02 02:45:14 --> Language Class Initialized
INFO - 2020-11-02 02:45:14 --> Language Class Initialized
INFO - 2020-11-02 02:45:14 --> Config Class Initialized
INFO - 2020-11-02 02:45:14 --> Loader Class Initialized
INFO - 2020-11-02 02:45:14 --> Helper loaded: url_helper
INFO - 2020-11-02 02:45:14 --> Helper loaded: file_helper
INFO - 2020-11-02 02:45:14 --> Helper loaded: form_helper
INFO - 2020-11-02 02:45:14 --> Helper loaded: my_helper
INFO - 2020-11-02 02:45:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:45:14 --> Controller Class Initialized
INFO - 2020-11-02 02:45:23 --> Config Class Initialized
INFO - 2020-11-02 02:45:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:45:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:45:23 --> Utf8 Class Initialized
INFO - 2020-11-02 02:45:23 --> URI Class Initialized
INFO - 2020-11-02 02:45:23 --> Router Class Initialized
INFO - 2020-11-02 02:45:23 --> Output Class Initialized
INFO - 2020-11-02 02:45:23 --> Security Class Initialized
DEBUG - 2020-11-02 02:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:45:23 --> Input Class Initialized
INFO - 2020-11-02 02:45:23 --> Language Class Initialized
INFO - 2020-11-02 02:45:23 --> Language Class Initialized
INFO - 2020-11-02 02:45:23 --> Config Class Initialized
INFO - 2020-11-02 02:45:23 --> Loader Class Initialized
INFO - 2020-11-02 02:45:23 --> Helper loaded: url_helper
INFO - 2020-11-02 02:45:23 --> Helper loaded: file_helper
INFO - 2020-11-02 02:45:23 --> Helper loaded: form_helper
INFO - 2020-11-02 02:45:23 --> Helper loaded: my_helper
INFO - 2020-11-02 02:45:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:45:23 --> Controller Class Initialized
INFO - 2020-11-02 02:46:22 --> Config Class Initialized
INFO - 2020-11-02 02:46:22 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:46:22 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:46:22 --> Utf8 Class Initialized
INFO - 2020-11-02 02:46:22 --> URI Class Initialized
INFO - 2020-11-02 02:46:22 --> Router Class Initialized
INFO - 2020-11-02 02:46:22 --> Output Class Initialized
INFO - 2020-11-02 02:46:22 --> Security Class Initialized
DEBUG - 2020-11-02 02:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:46:22 --> Input Class Initialized
INFO - 2020-11-02 02:46:22 --> Language Class Initialized
INFO - 2020-11-02 02:46:22 --> Language Class Initialized
INFO - 2020-11-02 02:46:22 --> Config Class Initialized
INFO - 2020-11-02 02:46:22 --> Loader Class Initialized
INFO - 2020-11-02 02:46:22 --> Helper loaded: url_helper
INFO - 2020-11-02 02:46:22 --> Helper loaded: file_helper
INFO - 2020-11-02 02:46:22 --> Helper loaded: form_helper
INFO - 2020-11-02 02:46:22 --> Helper loaded: my_helper
INFO - 2020-11-02 02:46:22 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:46:22 --> Controller Class Initialized
DEBUG - 2020-11-02 02:46:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-11-02 02:46:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:46:22 --> Final output sent to browser
DEBUG - 2020-11-02 02:46:22 --> Total execution time: 0.3116
INFO - 2020-11-02 02:46:29 --> Config Class Initialized
INFO - 2020-11-02 02:46:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:46:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:46:29 --> Utf8 Class Initialized
INFO - 2020-11-02 02:46:29 --> URI Class Initialized
INFO - 2020-11-02 02:46:29 --> Router Class Initialized
INFO - 2020-11-02 02:46:29 --> Output Class Initialized
INFO - 2020-11-02 02:46:29 --> Security Class Initialized
DEBUG - 2020-11-02 02:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:46:29 --> Input Class Initialized
INFO - 2020-11-02 02:46:29 --> Language Class Initialized
INFO - 2020-11-02 02:46:30 --> Language Class Initialized
INFO - 2020-11-02 02:46:30 --> Config Class Initialized
INFO - 2020-11-02 02:46:30 --> Loader Class Initialized
INFO - 2020-11-02 02:46:30 --> Helper loaded: url_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: file_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: form_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: my_helper
INFO - 2020-11-02 02:46:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:46:30 --> Controller Class Initialized
INFO - 2020-11-02 02:46:30 --> Config Class Initialized
INFO - 2020-11-02 02:46:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:46:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:46:30 --> Utf8 Class Initialized
INFO - 2020-11-02 02:46:30 --> URI Class Initialized
INFO - 2020-11-02 02:46:30 --> Router Class Initialized
INFO - 2020-11-02 02:46:30 --> Output Class Initialized
INFO - 2020-11-02 02:46:30 --> Security Class Initialized
DEBUG - 2020-11-02 02:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:46:30 --> Input Class Initialized
INFO - 2020-11-02 02:46:30 --> Language Class Initialized
INFO - 2020-11-02 02:46:30 --> Language Class Initialized
INFO - 2020-11-02 02:46:30 --> Config Class Initialized
INFO - 2020-11-02 02:46:30 --> Loader Class Initialized
INFO - 2020-11-02 02:46:30 --> Helper loaded: url_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: file_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: form_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: my_helper
INFO - 2020-11-02 02:46:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:46:30 --> Controller Class Initialized
DEBUG - 2020-11-02 02:46:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:46:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:46:30 --> Final output sent to browser
DEBUG - 2020-11-02 02:46:30 --> Total execution time: 0.2996
INFO - 2020-11-02 02:46:30 --> Config Class Initialized
INFO - 2020-11-02 02:46:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:46:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:46:30 --> Utf8 Class Initialized
INFO - 2020-11-02 02:46:30 --> URI Class Initialized
INFO - 2020-11-02 02:46:30 --> Router Class Initialized
INFO - 2020-11-02 02:46:30 --> Output Class Initialized
INFO - 2020-11-02 02:46:30 --> Security Class Initialized
DEBUG - 2020-11-02 02:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:46:30 --> Input Class Initialized
INFO - 2020-11-02 02:46:30 --> Language Class Initialized
INFO - 2020-11-02 02:46:30 --> Language Class Initialized
INFO - 2020-11-02 02:46:30 --> Config Class Initialized
INFO - 2020-11-02 02:46:30 --> Loader Class Initialized
INFO - 2020-11-02 02:46:30 --> Helper loaded: url_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: file_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: form_helper
INFO - 2020-11-02 02:46:30 --> Helper loaded: my_helper
INFO - 2020-11-02 02:46:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:46:31 --> Controller Class Initialized
INFO - 2020-11-02 02:46:33 --> Config Class Initialized
INFO - 2020-11-02 02:46:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:46:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:46:33 --> Utf8 Class Initialized
INFO - 2020-11-02 02:46:33 --> URI Class Initialized
INFO - 2020-11-02 02:46:33 --> Router Class Initialized
INFO - 2020-11-02 02:46:33 --> Output Class Initialized
INFO - 2020-11-02 02:46:33 --> Security Class Initialized
DEBUG - 2020-11-02 02:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:46:33 --> Input Class Initialized
INFO - 2020-11-02 02:46:33 --> Language Class Initialized
INFO - 2020-11-02 02:46:33 --> Language Class Initialized
INFO - 2020-11-02 02:46:34 --> Config Class Initialized
INFO - 2020-11-02 02:46:34 --> Loader Class Initialized
INFO - 2020-11-02 02:46:34 --> Helper loaded: url_helper
INFO - 2020-11-02 02:46:34 --> Helper loaded: file_helper
INFO - 2020-11-02 02:46:34 --> Helper loaded: form_helper
INFO - 2020-11-02 02:46:34 --> Helper loaded: my_helper
INFO - 2020-11-02 02:46:34 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:46:34 --> Controller Class Initialized
INFO - 2020-11-02 02:46:34 --> Final output sent to browser
DEBUG - 2020-11-02 02:46:34 --> Total execution time: 0.2548
INFO - 2020-11-02 02:46:46 --> Config Class Initialized
INFO - 2020-11-02 02:46:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:46:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:46:46 --> Utf8 Class Initialized
INFO - 2020-11-02 02:46:46 --> URI Class Initialized
INFO - 2020-11-02 02:46:46 --> Router Class Initialized
INFO - 2020-11-02 02:46:46 --> Output Class Initialized
INFO - 2020-11-02 02:46:46 --> Security Class Initialized
DEBUG - 2020-11-02 02:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:46:46 --> Input Class Initialized
INFO - 2020-11-02 02:46:46 --> Language Class Initialized
INFO - 2020-11-02 02:46:46 --> Language Class Initialized
INFO - 2020-11-02 02:46:46 --> Config Class Initialized
INFO - 2020-11-02 02:46:46 --> Loader Class Initialized
INFO - 2020-11-02 02:46:46 --> Helper loaded: url_helper
INFO - 2020-11-02 02:46:46 --> Helper loaded: file_helper
INFO - 2020-11-02 02:46:46 --> Helper loaded: form_helper
INFO - 2020-11-02 02:46:46 --> Helper loaded: my_helper
INFO - 2020-11-02 02:46:46 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:46:46 --> Controller Class Initialized
DEBUG - 2020-11-02 02:46:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 02:46:46 --> Final output sent to browser
DEBUG - 2020-11-02 02:46:46 --> Total execution time: 0.2993
INFO - 2020-11-02 02:48:39 --> Config Class Initialized
INFO - 2020-11-02 02:48:39 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:48:39 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:48:39 --> Utf8 Class Initialized
INFO - 2020-11-02 02:48:39 --> URI Class Initialized
INFO - 2020-11-02 02:48:39 --> Router Class Initialized
INFO - 2020-11-02 02:48:39 --> Output Class Initialized
INFO - 2020-11-02 02:48:39 --> Security Class Initialized
DEBUG - 2020-11-02 02:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:48:39 --> Input Class Initialized
INFO - 2020-11-02 02:48:39 --> Language Class Initialized
INFO - 2020-11-02 02:48:39 --> Language Class Initialized
INFO - 2020-11-02 02:48:39 --> Config Class Initialized
INFO - 2020-11-02 02:48:39 --> Loader Class Initialized
INFO - 2020-11-02 02:48:39 --> Helper loaded: url_helper
INFO - 2020-11-02 02:48:39 --> Helper loaded: file_helper
INFO - 2020-11-02 02:48:39 --> Helper loaded: form_helper
INFO - 2020-11-02 02:48:39 --> Helper loaded: my_helper
INFO - 2020-11-02 02:48:39 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:48:39 --> Controller Class Initialized
DEBUG - 2020-11-02 02:48:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:48:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:48:39 --> Final output sent to browser
DEBUG - 2020-11-02 02:48:39 --> Total execution time: 0.2757
INFO - 2020-11-02 02:48:40 --> Config Class Initialized
INFO - 2020-11-02 02:48:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:48:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:48:40 --> Utf8 Class Initialized
INFO - 2020-11-02 02:48:40 --> URI Class Initialized
INFO - 2020-11-02 02:48:40 --> Router Class Initialized
INFO - 2020-11-02 02:48:40 --> Output Class Initialized
INFO - 2020-11-02 02:48:40 --> Security Class Initialized
DEBUG - 2020-11-02 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:48:40 --> Input Class Initialized
INFO - 2020-11-02 02:48:40 --> Language Class Initialized
INFO - 2020-11-02 02:48:40 --> Language Class Initialized
INFO - 2020-11-02 02:48:40 --> Config Class Initialized
INFO - 2020-11-02 02:48:40 --> Loader Class Initialized
INFO - 2020-11-02 02:48:40 --> Helper loaded: url_helper
INFO - 2020-11-02 02:48:40 --> Helper loaded: file_helper
INFO - 2020-11-02 02:48:40 --> Helper loaded: form_helper
INFO - 2020-11-02 02:48:40 --> Helper loaded: my_helper
INFO - 2020-11-02 02:48:40 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:48:40 --> Controller Class Initialized
DEBUG - 2020-11-02 02:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:48:40 --> Final output sent to browser
DEBUG - 2020-11-02 02:48:40 --> Total execution time: 0.2717
INFO - 2020-11-02 02:48:45 --> Config Class Initialized
INFO - 2020-11-02 02:48:45 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:48:45 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:48:45 --> Utf8 Class Initialized
INFO - 2020-11-02 02:48:45 --> URI Class Initialized
INFO - 2020-11-02 02:48:45 --> Router Class Initialized
INFO - 2020-11-02 02:48:45 --> Output Class Initialized
INFO - 2020-11-02 02:48:45 --> Security Class Initialized
DEBUG - 2020-11-02 02:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:48:45 --> Input Class Initialized
INFO - 2020-11-02 02:48:45 --> Language Class Initialized
INFO - 2020-11-02 02:48:45 --> Language Class Initialized
INFO - 2020-11-02 02:48:45 --> Config Class Initialized
INFO - 2020-11-02 02:48:45 --> Loader Class Initialized
INFO - 2020-11-02 02:48:45 --> Helper loaded: url_helper
INFO - 2020-11-02 02:48:45 --> Helper loaded: file_helper
INFO - 2020-11-02 02:48:45 --> Helper loaded: form_helper
INFO - 2020-11-02 02:48:45 --> Helper loaded: my_helper
INFO - 2020-11-02 02:48:45 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:48:45 --> Controller Class Initialized
INFO - 2020-11-02 02:48:45 --> Final output sent to browser
DEBUG - 2020-11-02 02:48:45 --> Total execution time: 0.2794
INFO - 2020-11-02 02:48:49 --> Config Class Initialized
INFO - 2020-11-02 02:48:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:48:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:48:49 --> Utf8 Class Initialized
INFO - 2020-11-02 02:48:49 --> URI Class Initialized
INFO - 2020-11-02 02:48:49 --> Router Class Initialized
INFO - 2020-11-02 02:48:50 --> Output Class Initialized
INFO - 2020-11-02 02:48:50 --> Security Class Initialized
DEBUG - 2020-11-02 02:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:48:50 --> Input Class Initialized
INFO - 2020-11-02 02:48:50 --> Language Class Initialized
INFO - 2020-11-02 02:48:50 --> Language Class Initialized
INFO - 2020-11-02 02:48:50 --> Config Class Initialized
INFO - 2020-11-02 02:48:50 --> Loader Class Initialized
INFO - 2020-11-02 02:48:50 --> Helper loaded: url_helper
INFO - 2020-11-02 02:48:50 --> Helper loaded: file_helper
INFO - 2020-11-02 02:48:50 --> Helper loaded: form_helper
INFO - 2020-11-02 02:48:50 --> Helper loaded: my_helper
INFO - 2020-11-02 02:48:50 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:48:50 --> Controller Class Initialized
DEBUG - 2020-11-02 02:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:48:50 --> Final output sent to browser
DEBUG - 2020-11-02 02:48:50 --> Total execution time: 0.3072
INFO - 2020-11-02 02:48:52 --> Config Class Initialized
INFO - 2020-11-02 02:48:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:48:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:48:52 --> Utf8 Class Initialized
INFO - 2020-11-02 02:48:52 --> URI Class Initialized
INFO - 2020-11-02 02:48:52 --> Router Class Initialized
INFO - 2020-11-02 02:48:52 --> Output Class Initialized
INFO - 2020-11-02 02:48:52 --> Security Class Initialized
DEBUG - 2020-11-02 02:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:48:52 --> Input Class Initialized
INFO - 2020-11-02 02:48:52 --> Language Class Initialized
INFO - 2020-11-02 02:48:52 --> Language Class Initialized
INFO - 2020-11-02 02:48:52 --> Config Class Initialized
INFO - 2020-11-02 02:48:52 --> Loader Class Initialized
INFO - 2020-11-02 02:48:52 --> Helper loaded: url_helper
INFO - 2020-11-02 02:48:52 --> Helper loaded: file_helper
INFO - 2020-11-02 02:48:52 --> Helper loaded: form_helper
INFO - 2020-11-02 02:48:52 --> Helper loaded: my_helper
INFO - 2020-11-02 02:48:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:48:52 --> Controller Class Initialized
INFO - 2020-11-02 02:48:52 --> Final output sent to browser
DEBUG - 2020-11-02 02:48:52 --> Total execution time: 0.2433
INFO - 2020-11-02 02:49:51 --> Config Class Initialized
INFO - 2020-11-02 02:49:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:49:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:49:51 --> Utf8 Class Initialized
INFO - 2020-11-02 02:49:51 --> URI Class Initialized
INFO - 2020-11-02 02:49:51 --> Router Class Initialized
INFO - 2020-11-02 02:49:51 --> Output Class Initialized
INFO - 2020-11-02 02:49:51 --> Security Class Initialized
DEBUG - 2020-11-02 02:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:49:51 --> Input Class Initialized
INFO - 2020-11-02 02:49:51 --> Language Class Initialized
INFO - 2020-11-02 02:49:51 --> Language Class Initialized
INFO - 2020-11-02 02:49:51 --> Config Class Initialized
INFO - 2020-11-02 02:49:51 --> Loader Class Initialized
INFO - 2020-11-02 02:49:51 --> Helper loaded: url_helper
INFO - 2020-11-02 02:49:51 --> Helper loaded: file_helper
INFO - 2020-11-02 02:49:51 --> Helper loaded: form_helper
INFO - 2020-11-02 02:49:51 --> Helper loaded: my_helper
INFO - 2020-11-02 02:49:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:49:51 --> Controller Class Initialized
DEBUG - 2020-11-02 02:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:49:51 --> Final output sent to browser
DEBUG - 2020-11-02 02:49:51 --> Total execution time: 0.2894
INFO - 2020-11-02 02:49:52 --> Config Class Initialized
INFO - 2020-11-02 02:49:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:49:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:49:52 --> Utf8 Class Initialized
INFO - 2020-11-02 02:49:52 --> URI Class Initialized
INFO - 2020-11-02 02:49:52 --> Router Class Initialized
INFO - 2020-11-02 02:49:52 --> Output Class Initialized
INFO - 2020-11-02 02:49:52 --> Security Class Initialized
DEBUG - 2020-11-02 02:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:49:52 --> Input Class Initialized
INFO - 2020-11-02 02:49:52 --> Language Class Initialized
INFO - 2020-11-02 02:49:52 --> Language Class Initialized
INFO - 2020-11-02 02:49:52 --> Config Class Initialized
INFO - 2020-11-02 02:49:52 --> Loader Class Initialized
INFO - 2020-11-02 02:49:52 --> Helper loaded: url_helper
INFO - 2020-11-02 02:49:52 --> Helper loaded: file_helper
INFO - 2020-11-02 02:49:52 --> Helper loaded: form_helper
INFO - 2020-11-02 02:49:52 --> Helper loaded: my_helper
INFO - 2020-11-02 02:49:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:49:53 --> Controller Class Initialized
DEBUG - 2020-11-02 02:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 02:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:49:53 --> Final output sent to browser
DEBUG - 2020-11-02 02:49:53 --> Total execution time: 0.2716
INFO - 2020-11-02 02:49:53 --> Config Class Initialized
INFO - 2020-11-02 02:49:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:49:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:49:53 --> Utf8 Class Initialized
INFO - 2020-11-02 02:49:53 --> URI Class Initialized
INFO - 2020-11-02 02:49:53 --> Router Class Initialized
INFO - 2020-11-02 02:49:53 --> Output Class Initialized
INFO - 2020-11-02 02:49:53 --> Security Class Initialized
DEBUG - 2020-11-02 02:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:49:53 --> Input Class Initialized
INFO - 2020-11-02 02:49:53 --> Language Class Initialized
INFO - 2020-11-02 02:49:53 --> Language Class Initialized
INFO - 2020-11-02 02:49:53 --> Config Class Initialized
INFO - 2020-11-02 02:49:53 --> Loader Class Initialized
INFO - 2020-11-02 02:49:53 --> Helper loaded: url_helper
INFO - 2020-11-02 02:49:53 --> Helper loaded: file_helper
INFO - 2020-11-02 02:49:53 --> Helper loaded: form_helper
INFO - 2020-11-02 02:49:53 --> Helper loaded: my_helper
INFO - 2020-11-02 02:49:53 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:49:53 --> Controller Class Initialized
INFO - 2020-11-02 02:49:55 --> Config Class Initialized
INFO - 2020-11-02 02:49:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:49:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:49:55 --> Utf8 Class Initialized
INFO - 2020-11-02 02:49:55 --> URI Class Initialized
INFO - 2020-11-02 02:49:55 --> Router Class Initialized
INFO - 2020-11-02 02:49:55 --> Output Class Initialized
INFO - 2020-11-02 02:49:55 --> Security Class Initialized
DEBUG - 2020-11-02 02:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:49:55 --> Input Class Initialized
INFO - 2020-11-02 02:49:55 --> Language Class Initialized
INFO - 2020-11-02 02:49:55 --> Language Class Initialized
INFO - 2020-11-02 02:49:55 --> Config Class Initialized
INFO - 2020-11-02 02:49:55 --> Loader Class Initialized
INFO - 2020-11-02 02:49:55 --> Helper loaded: url_helper
INFO - 2020-11-02 02:49:55 --> Helper loaded: file_helper
INFO - 2020-11-02 02:49:55 --> Helper loaded: form_helper
INFO - 2020-11-02 02:49:55 --> Helper loaded: my_helper
INFO - 2020-11-02 02:49:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:49:55 --> Controller Class Initialized
INFO - 2020-11-02 02:49:55 --> Final output sent to browser
DEBUG - 2020-11-02 02:49:55 --> Total execution time: 0.2505
INFO - 2020-11-02 02:50:03 --> Config Class Initialized
INFO - 2020-11-02 02:50:03 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:50:03 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:50:03 --> Utf8 Class Initialized
INFO - 2020-11-02 02:50:03 --> URI Class Initialized
INFO - 2020-11-02 02:50:03 --> Router Class Initialized
INFO - 2020-11-02 02:50:03 --> Output Class Initialized
INFO - 2020-11-02 02:50:03 --> Security Class Initialized
DEBUG - 2020-11-02 02:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:50:03 --> Input Class Initialized
INFO - 2020-11-02 02:50:03 --> Language Class Initialized
INFO - 2020-11-02 02:50:03 --> Language Class Initialized
INFO - 2020-11-02 02:50:03 --> Config Class Initialized
INFO - 2020-11-02 02:50:03 --> Loader Class Initialized
INFO - 2020-11-02 02:50:03 --> Helper loaded: url_helper
INFO - 2020-11-02 02:50:03 --> Helper loaded: file_helper
INFO - 2020-11-02 02:50:03 --> Helper loaded: form_helper
INFO - 2020-11-02 02:50:03 --> Helper loaded: my_helper
INFO - 2020-11-02 02:50:03 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:50:03 --> Controller Class Initialized
DEBUG - 2020-11-02 02:50:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 02:50:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:50:03 --> Final output sent to browser
DEBUG - 2020-11-02 02:50:03 --> Total execution time: 0.2826
INFO - 2020-11-02 02:50:05 --> Config Class Initialized
INFO - 2020-11-02 02:50:05 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:50:05 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:50:05 --> Utf8 Class Initialized
INFO - 2020-11-02 02:50:05 --> URI Class Initialized
INFO - 2020-11-02 02:50:05 --> Router Class Initialized
INFO - 2020-11-02 02:50:05 --> Output Class Initialized
INFO - 2020-11-02 02:50:05 --> Security Class Initialized
DEBUG - 2020-11-02 02:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:50:05 --> Input Class Initialized
INFO - 2020-11-02 02:50:05 --> Language Class Initialized
INFO - 2020-11-02 02:50:05 --> Language Class Initialized
INFO - 2020-11-02 02:50:05 --> Config Class Initialized
INFO - 2020-11-02 02:50:05 --> Loader Class Initialized
INFO - 2020-11-02 02:50:05 --> Helper loaded: url_helper
INFO - 2020-11-02 02:50:05 --> Helper loaded: file_helper
INFO - 2020-11-02 02:50:05 --> Helper loaded: form_helper
INFO - 2020-11-02 02:50:05 --> Helper loaded: my_helper
INFO - 2020-11-02 02:50:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:50:05 --> Controller Class Initialized
DEBUG - 2020-11-02 02:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:50:05 --> Final output sent to browser
DEBUG - 2020-11-02 02:50:05 --> Total execution time: 0.2717
INFO - 2020-11-02 02:50:07 --> Config Class Initialized
INFO - 2020-11-02 02:50:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:50:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:50:07 --> Utf8 Class Initialized
INFO - 2020-11-02 02:50:07 --> URI Class Initialized
INFO - 2020-11-02 02:50:07 --> Router Class Initialized
INFO - 2020-11-02 02:50:07 --> Output Class Initialized
INFO - 2020-11-02 02:50:07 --> Security Class Initialized
DEBUG - 2020-11-02 02:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:50:07 --> Input Class Initialized
INFO - 2020-11-02 02:50:07 --> Language Class Initialized
INFO - 2020-11-02 02:50:07 --> Language Class Initialized
INFO - 2020-11-02 02:50:07 --> Config Class Initialized
INFO - 2020-11-02 02:50:07 --> Loader Class Initialized
INFO - 2020-11-02 02:50:07 --> Helper loaded: url_helper
INFO - 2020-11-02 02:50:07 --> Helper loaded: file_helper
INFO - 2020-11-02 02:50:07 --> Helper loaded: form_helper
INFO - 2020-11-02 02:50:07 --> Helper loaded: my_helper
INFO - 2020-11-02 02:50:07 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:50:07 --> Controller Class Initialized
INFO - 2020-11-02 02:50:07 --> Final output sent to browser
DEBUG - 2020-11-02 02:50:07 --> Total execution time: 0.2617
INFO - 2020-11-02 02:50:19 --> Config Class Initialized
INFO - 2020-11-02 02:50:19 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:50:19 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:50:19 --> Utf8 Class Initialized
INFO - 2020-11-02 02:50:19 --> URI Class Initialized
INFO - 2020-11-02 02:50:19 --> Router Class Initialized
INFO - 2020-11-02 02:50:19 --> Output Class Initialized
INFO - 2020-11-02 02:50:19 --> Security Class Initialized
DEBUG - 2020-11-02 02:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:50:19 --> Input Class Initialized
INFO - 2020-11-02 02:50:19 --> Language Class Initialized
INFO - 2020-11-02 02:50:19 --> Language Class Initialized
INFO - 2020-11-02 02:50:19 --> Config Class Initialized
INFO - 2020-11-02 02:50:19 --> Loader Class Initialized
INFO - 2020-11-02 02:50:19 --> Helper loaded: url_helper
INFO - 2020-11-02 02:50:19 --> Helper loaded: file_helper
INFO - 2020-11-02 02:50:19 --> Helper loaded: form_helper
INFO - 2020-11-02 02:50:19 --> Helper loaded: my_helper
INFO - 2020-11-02 02:50:19 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:50:20 --> Controller Class Initialized
INFO - 2020-11-02 02:50:20 --> Final output sent to browser
DEBUG - 2020-11-02 02:50:20 --> Total execution time: 0.3329
INFO - 2020-11-02 02:50:21 --> Config Class Initialized
INFO - 2020-11-02 02:50:21 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:50:21 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:50:21 --> Utf8 Class Initialized
INFO - 2020-11-02 02:50:21 --> URI Class Initialized
INFO - 2020-11-02 02:50:21 --> Router Class Initialized
INFO - 2020-11-02 02:50:21 --> Output Class Initialized
INFO - 2020-11-02 02:50:21 --> Security Class Initialized
DEBUG - 2020-11-02 02:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:50:21 --> Input Class Initialized
INFO - 2020-11-02 02:50:21 --> Language Class Initialized
INFO - 2020-11-02 02:50:21 --> Language Class Initialized
INFO - 2020-11-02 02:50:21 --> Config Class Initialized
INFO - 2020-11-02 02:50:21 --> Loader Class Initialized
INFO - 2020-11-02 02:50:21 --> Helper loaded: url_helper
INFO - 2020-11-02 02:50:21 --> Helper loaded: file_helper
INFO - 2020-11-02 02:50:21 --> Helper loaded: form_helper
INFO - 2020-11-02 02:50:21 --> Helper loaded: my_helper
INFO - 2020-11-02 02:50:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:50:21 --> Controller Class Initialized
DEBUG - 2020-11-02 02:50:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 02:50:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 02:50:21 --> Final output sent to browser
DEBUG - 2020-11-02 02:50:21 --> Total execution time: 0.3148
INFO - 2020-11-02 02:50:23 --> Config Class Initialized
INFO - 2020-11-02 02:50:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 02:50:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 02:50:23 --> Utf8 Class Initialized
INFO - 2020-11-02 02:50:23 --> URI Class Initialized
INFO - 2020-11-02 02:50:23 --> Router Class Initialized
INFO - 2020-11-02 02:50:23 --> Output Class Initialized
INFO - 2020-11-02 02:50:23 --> Security Class Initialized
DEBUG - 2020-11-02 02:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 02:50:23 --> Input Class Initialized
INFO - 2020-11-02 02:50:23 --> Language Class Initialized
INFO - 2020-11-02 02:50:23 --> Language Class Initialized
INFO - 2020-11-02 02:50:23 --> Config Class Initialized
INFO - 2020-11-02 02:50:23 --> Loader Class Initialized
INFO - 2020-11-02 02:50:23 --> Helper loaded: url_helper
INFO - 2020-11-02 02:50:23 --> Helper loaded: file_helper
INFO - 2020-11-02 02:50:23 --> Helper loaded: form_helper
INFO - 2020-11-02 02:50:23 --> Helper loaded: my_helper
INFO - 2020-11-02 02:50:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 02:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 02:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 02:50:23 --> Controller Class Initialized
INFO - 2020-11-02 02:50:23 --> Final output sent to browser
DEBUG - 2020-11-02 02:50:23 --> Total execution time: 0.2604
INFO - 2020-11-02 03:06:53 --> Config Class Initialized
INFO - 2020-11-02 03:06:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:06:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:06:53 --> Utf8 Class Initialized
INFO - 2020-11-02 03:06:53 --> URI Class Initialized
INFO - 2020-11-02 03:06:53 --> Router Class Initialized
INFO - 2020-11-02 03:06:53 --> Output Class Initialized
INFO - 2020-11-02 03:06:53 --> Security Class Initialized
DEBUG - 2020-11-02 03:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:06:53 --> Input Class Initialized
INFO - 2020-11-02 03:06:53 --> Language Class Initialized
INFO - 2020-11-02 03:06:53 --> Language Class Initialized
INFO - 2020-11-02 03:06:53 --> Config Class Initialized
INFO - 2020-11-02 03:06:53 --> Loader Class Initialized
INFO - 2020-11-02 03:06:53 --> Helper loaded: url_helper
INFO - 2020-11-02 03:06:53 --> Helper loaded: file_helper
INFO - 2020-11-02 03:06:53 --> Helper loaded: form_helper
INFO - 2020-11-02 03:06:53 --> Helper loaded: my_helper
INFO - 2020-11-02 03:06:53 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:06:53 --> Controller Class Initialized
INFO - 2020-11-02 03:06:53 --> Final output sent to browser
DEBUG - 2020-11-02 03:06:53 --> Total execution time: 0.2583
INFO - 2020-11-02 03:06:55 --> Config Class Initialized
INFO - 2020-11-02 03:06:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:06:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:06:55 --> Utf8 Class Initialized
INFO - 2020-11-02 03:06:55 --> URI Class Initialized
INFO - 2020-11-02 03:06:55 --> Router Class Initialized
INFO - 2020-11-02 03:06:55 --> Output Class Initialized
INFO - 2020-11-02 03:06:55 --> Security Class Initialized
DEBUG - 2020-11-02 03:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:06:55 --> Input Class Initialized
INFO - 2020-11-02 03:06:55 --> Language Class Initialized
INFO - 2020-11-02 03:06:55 --> Language Class Initialized
INFO - 2020-11-02 03:06:55 --> Config Class Initialized
INFO - 2020-11-02 03:06:55 --> Loader Class Initialized
INFO - 2020-11-02 03:06:55 --> Helper loaded: url_helper
INFO - 2020-11-02 03:06:55 --> Helper loaded: file_helper
INFO - 2020-11-02 03:06:55 --> Helper loaded: form_helper
INFO - 2020-11-02 03:06:55 --> Helper loaded: my_helper
INFO - 2020-11-02 03:06:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:06:55 --> Controller Class Initialized
DEBUG - 2020-11-02 03:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 03:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:06:55 --> Final output sent to browser
DEBUG - 2020-11-02 03:06:55 --> Total execution time: 0.2831
INFO - 2020-11-02 03:06:56 --> Config Class Initialized
INFO - 2020-11-02 03:06:56 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:06:56 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:06:56 --> Utf8 Class Initialized
INFO - 2020-11-02 03:06:56 --> URI Class Initialized
INFO - 2020-11-02 03:06:56 --> Router Class Initialized
INFO - 2020-11-02 03:06:56 --> Output Class Initialized
INFO - 2020-11-02 03:06:56 --> Security Class Initialized
DEBUG - 2020-11-02 03:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:06:56 --> Input Class Initialized
INFO - 2020-11-02 03:06:56 --> Language Class Initialized
INFO - 2020-11-02 03:06:56 --> Language Class Initialized
INFO - 2020-11-02 03:06:56 --> Config Class Initialized
INFO - 2020-11-02 03:06:56 --> Loader Class Initialized
INFO - 2020-11-02 03:06:56 --> Helper loaded: url_helper
INFO - 2020-11-02 03:06:56 --> Helper loaded: file_helper
INFO - 2020-11-02 03:06:56 --> Helper loaded: form_helper
INFO - 2020-11-02 03:06:56 --> Helper loaded: my_helper
INFO - 2020-11-02 03:06:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:06:56 --> Controller Class Initialized
DEBUG - 2020-11-02 03:06:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 03:06:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:06:56 --> Final output sent to browser
DEBUG - 2020-11-02 03:06:56 --> Total execution time: 0.3320
INFO - 2020-11-02 03:06:57 --> Config Class Initialized
INFO - 2020-11-02 03:06:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:06:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:06:57 --> Utf8 Class Initialized
INFO - 2020-11-02 03:06:57 --> URI Class Initialized
INFO - 2020-11-02 03:06:57 --> Router Class Initialized
INFO - 2020-11-02 03:06:57 --> Output Class Initialized
INFO - 2020-11-02 03:06:57 --> Security Class Initialized
DEBUG - 2020-11-02 03:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:06:57 --> Input Class Initialized
INFO - 2020-11-02 03:06:57 --> Language Class Initialized
INFO - 2020-11-02 03:06:57 --> Language Class Initialized
INFO - 2020-11-02 03:06:57 --> Config Class Initialized
INFO - 2020-11-02 03:06:57 --> Loader Class Initialized
INFO - 2020-11-02 03:06:57 --> Helper loaded: url_helper
INFO - 2020-11-02 03:06:57 --> Helper loaded: file_helper
INFO - 2020-11-02 03:06:57 --> Helper loaded: form_helper
INFO - 2020-11-02 03:06:57 --> Helper loaded: my_helper
INFO - 2020-11-02 03:06:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:06:57 --> Controller Class Initialized
INFO - 2020-11-02 03:06:57 --> Config Class Initialized
INFO - 2020-11-02 03:06:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:06:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:06:57 --> Utf8 Class Initialized
INFO - 2020-11-02 03:06:57 --> URI Class Initialized
INFO - 2020-11-02 03:06:57 --> Router Class Initialized
INFO - 2020-11-02 03:06:57 --> Output Class Initialized
INFO - 2020-11-02 03:06:57 --> Security Class Initialized
DEBUG - 2020-11-02 03:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:06:57 --> Input Class Initialized
INFO - 2020-11-02 03:06:57 --> Language Class Initialized
INFO - 2020-11-02 03:06:57 --> Language Class Initialized
INFO - 2020-11-02 03:06:57 --> Config Class Initialized
INFO - 2020-11-02 03:06:57 --> Loader Class Initialized
INFO - 2020-11-02 03:06:57 --> Helper loaded: url_helper
INFO - 2020-11-02 03:06:57 --> Helper loaded: file_helper
INFO - 2020-11-02 03:06:57 --> Helper loaded: form_helper
INFO - 2020-11-02 03:06:57 --> Helper loaded: my_helper
INFO - 2020-11-02 03:06:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:06:57 --> Controller Class Initialized
DEBUG - 2020-11-02 03:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 03:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:06:57 --> Final output sent to browser
DEBUG - 2020-11-02 03:06:57 --> Total execution time: 0.3297
INFO - 2020-11-02 03:06:58 --> Config Class Initialized
INFO - 2020-11-02 03:06:58 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:06:58 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:06:58 --> Utf8 Class Initialized
INFO - 2020-11-02 03:06:58 --> URI Class Initialized
INFO - 2020-11-02 03:06:58 --> Router Class Initialized
INFO - 2020-11-02 03:06:58 --> Output Class Initialized
INFO - 2020-11-02 03:06:58 --> Security Class Initialized
DEBUG - 2020-11-02 03:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:06:58 --> Input Class Initialized
INFO - 2020-11-02 03:06:58 --> Language Class Initialized
INFO - 2020-11-02 03:06:58 --> Language Class Initialized
INFO - 2020-11-02 03:06:58 --> Config Class Initialized
INFO - 2020-11-02 03:06:58 --> Loader Class Initialized
INFO - 2020-11-02 03:06:58 --> Helper loaded: url_helper
INFO - 2020-11-02 03:06:58 --> Helper loaded: file_helper
INFO - 2020-11-02 03:06:58 --> Helper loaded: form_helper
INFO - 2020-11-02 03:06:58 --> Helper loaded: my_helper
INFO - 2020-11-02 03:06:58 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:06:58 --> Controller Class Initialized
INFO - 2020-11-02 03:06:59 --> Config Class Initialized
INFO - 2020-11-02 03:06:59 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:06:59 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:06:59 --> Utf8 Class Initialized
INFO - 2020-11-02 03:06:59 --> URI Class Initialized
INFO - 2020-11-02 03:06:59 --> Router Class Initialized
INFO - 2020-11-02 03:06:59 --> Output Class Initialized
INFO - 2020-11-02 03:06:59 --> Security Class Initialized
DEBUG - 2020-11-02 03:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:06:59 --> Input Class Initialized
INFO - 2020-11-02 03:06:59 --> Language Class Initialized
INFO - 2020-11-02 03:06:59 --> Language Class Initialized
INFO - 2020-11-02 03:06:59 --> Config Class Initialized
INFO - 2020-11-02 03:06:59 --> Loader Class Initialized
INFO - 2020-11-02 03:06:59 --> Helper loaded: url_helper
INFO - 2020-11-02 03:06:59 --> Helper loaded: file_helper
INFO - 2020-11-02 03:06:59 --> Helper loaded: form_helper
INFO - 2020-11-02 03:06:59 --> Helper loaded: my_helper
INFO - 2020-11-02 03:06:59 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:06:59 --> Controller Class Initialized
INFO - 2020-11-02 03:06:59 --> Final output sent to browser
DEBUG - 2020-11-02 03:06:59 --> Total execution time: 0.2794
INFO - 2020-11-02 03:07:04 --> Config Class Initialized
INFO - 2020-11-02 03:07:04 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:07:04 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:07:05 --> Utf8 Class Initialized
INFO - 2020-11-02 03:07:05 --> URI Class Initialized
INFO - 2020-11-02 03:07:05 --> Router Class Initialized
INFO - 2020-11-02 03:07:05 --> Output Class Initialized
INFO - 2020-11-02 03:07:05 --> Security Class Initialized
DEBUG - 2020-11-02 03:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:07:05 --> Input Class Initialized
INFO - 2020-11-02 03:07:05 --> Language Class Initialized
INFO - 2020-11-02 03:07:05 --> Language Class Initialized
INFO - 2020-11-02 03:07:05 --> Config Class Initialized
INFO - 2020-11-02 03:07:05 --> Loader Class Initialized
INFO - 2020-11-02 03:07:05 --> Helper loaded: url_helper
INFO - 2020-11-02 03:07:05 --> Helper loaded: file_helper
INFO - 2020-11-02 03:07:05 --> Helper loaded: form_helper
INFO - 2020-11-02 03:07:05 --> Helper loaded: my_helper
INFO - 2020-11-02 03:07:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:07:05 --> Controller Class Initialized
INFO - 2020-11-02 03:07:05 --> Final output sent to browser
DEBUG - 2020-11-02 03:07:05 --> Total execution time: 0.3537
INFO - 2020-11-02 03:07:07 --> Config Class Initialized
INFO - 2020-11-02 03:07:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:07:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:07:07 --> Utf8 Class Initialized
INFO - 2020-11-02 03:07:07 --> URI Class Initialized
INFO - 2020-11-02 03:07:07 --> Router Class Initialized
INFO - 2020-11-02 03:07:07 --> Output Class Initialized
INFO - 2020-11-02 03:07:07 --> Security Class Initialized
DEBUG - 2020-11-02 03:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:07:07 --> Input Class Initialized
INFO - 2020-11-02 03:07:07 --> Language Class Initialized
INFO - 2020-11-02 03:07:07 --> Language Class Initialized
INFO - 2020-11-02 03:07:07 --> Config Class Initialized
INFO - 2020-11-02 03:07:07 --> Loader Class Initialized
INFO - 2020-11-02 03:07:07 --> Helper loaded: url_helper
INFO - 2020-11-02 03:07:07 --> Helper loaded: file_helper
INFO - 2020-11-02 03:07:07 --> Helper loaded: form_helper
INFO - 2020-11-02 03:07:07 --> Helper loaded: my_helper
INFO - 2020-11-02 03:07:07 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:07:07 --> Controller Class Initialized
DEBUG - 2020-11-02 03:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 03:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:07:07 --> Final output sent to browser
DEBUG - 2020-11-02 03:07:07 --> Total execution time: 0.2979
INFO - 2020-11-02 03:07:07 --> Config Class Initialized
INFO - 2020-11-02 03:07:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:07:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:07:07 --> Utf8 Class Initialized
INFO - 2020-11-02 03:07:07 --> URI Class Initialized
INFO - 2020-11-02 03:07:07 --> Router Class Initialized
INFO - 2020-11-02 03:07:07 --> Output Class Initialized
INFO - 2020-11-02 03:07:07 --> Security Class Initialized
DEBUG - 2020-11-02 03:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:07:07 --> Input Class Initialized
INFO - 2020-11-02 03:07:07 --> Language Class Initialized
INFO - 2020-11-02 03:07:07 --> Language Class Initialized
INFO - 2020-11-02 03:07:07 --> Config Class Initialized
INFO - 2020-11-02 03:07:07 --> Loader Class Initialized
INFO - 2020-11-02 03:07:07 --> Helper loaded: url_helper
INFO - 2020-11-02 03:07:08 --> Helper loaded: file_helper
INFO - 2020-11-02 03:07:08 --> Helper loaded: form_helper
INFO - 2020-11-02 03:07:08 --> Helper loaded: my_helper
INFO - 2020-11-02 03:07:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:07:08 --> Controller Class Initialized
INFO - 2020-11-02 03:07:09 --> Config Class Initialized
INFO - 2020-11-02 03:07:09 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:07:09 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:07:09 --> Utf8 Class Initialized
INFO - 2020-11-02 03:07:09 --> URI Class Initialized
INFO - 2020-11-02 03:07:09 --> Router Class Initialized
INFO - 2020-11-02 03:07:09 --> Output Class Initialized
INFO - 2020-11-02 03:07:09 --> Security Class Initialized
DEBUG - 2020-11-02 03:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:07:09 --> Input Class Initialized
INFO - 2020-11-02 03:07:09 --> Language Class Initialized
INFO - 2020-11-02 03:07:09 --> Language Class Initialized
INFO - 2020-11-02 03:07:09 --> Config Class Initialized
INFO - 2020-11-02 03:07:09 --> Loader Class Initialized
INFO - 2020-11-02 03:07:09 --> Helper loaded: url_helper
INFO - 2020-11-02 03:07:09 --> Helper loaded: file_helper
INFO - 2020-11-02 03:07:09 --> Helper loaded: form_helper
INFO - 2020-11-02 03:07:09 --> Helper loaded: my_helper
INFO - 2020-11-02 03:07:09 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:07:09 --> Controller Class Initialized
INFO - 2020-11-02 03:07:09 --> Final output sent to browser
DEBUG - 2020-11-02 03:07:09 --> Total execution time: 0.2660
INFO - 2020-11-02 03:37:42 --> Config Class Initialized
INFO - 2020-11-02 03:37:42 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:37:42 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:37:42 --> Utf8 Class Initialized
INFO - 2020-11-02 03:37:42 --> URI Class Initialized
INFO - 2020-11-02 03:37:42 --> Router Class Initialized
INFO - 2020-11-02 03:37:42 --> Output Class Initialized
INFO - 2020-11-02 03:37:42 --> Security Class Initialized
DEBUG - 2020-11-02 03:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:37:42 --> Input Class Initialized
INFO - 2020-11-02 03:37:42 --> Language Class Initialized
INFO - 2020-11-02 03:37:42 --> Language Class Initialized
INFO - 2020-11-02 03:37:42 --> Config Class Initialized
INFO - 2020-11-02 03:37:42 --> Loader Class Initialized
INFO - 2020-11-02 03:37:42 --> Helper loaded: url_helper
INFO - 2020-11-02 03:37:42 --> Helper loaded: file_helper
INFO - 2020-11-02 03:37:42 --> Helper loaded: form_helper
INFO - 2020-11-02 03:37:42 --> Helper loaded: my_helper
INFO - 2020-11-02 03:37:42 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:37:42 --> Controller Class Initialized
DEBUG - 2020-11-02 03:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 03:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:37:42 --> Final output sent to browser
DEBUG - 2020-11-02 03:37:42 --> Total execution time: 0.3064
INFO - 2020-11-02 03:37:47 --> Config Class Initialized
INFO - 2020-11-02 03:37:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:37:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:37:47 --> Utf8 Class Initialized
INFO - 2020-11-02 03:37:47 --> URI Class Initialized
INFO - 2020-11-02 03:37:47 --> Router Class Initialized
INFO - 2020-11-02 03:37:47 --> Output Class Initialized
INFO - 2020-11-02 03:37:47 --> Security Class Initialized
DEBUG - 2020-11-02 03:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:37:47 --> Input Class Initialized
INFO - 2020-11-02 03:37:47 --> Language Class Initialized
INFO - 2020-11-02 03:37:47 --> Language Class Initialized
INFO - 2020-11-02 03:37:47 --> Config Class Initialized
INFO - 2020-11-02 03:37:47 --> Loader Class Initialized
INFO - 2020-11-02 03:37:47 --> Helper loaded: url_helper
INFO - 2020-11-02 03:37:47 --> Helper loaded: file_helper
INFO - 2020-11-02 03:37:47 --> Helper loaded: form_helper
INFO - 2020-11-02 03:37:47 --> Helper loaded: my_helper
INFO - 2020-11-02 03:37:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:37:47 --> Controller Class Initialized
INFO - 2020-11-02 03:37:48 --> Final output sent to browser
DEBUG - 2020-11-02 03:37:48 --> Total execution time: 0.2801
INFO - 2020-11-02 03:37:54 --> Config Class Initialized
INFO - 2020-11-02 03:37:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:37:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:37:54 --> Utf8 Class Initialized
INFO - 2020-11-02 03:37:54 --> URI Class Initialized
INFO - 2020-11-02 03:37:54 --> Router Class Initialized
INFO - 2020-11-02 03:37:54 --> Output Class Initialized
INFO - 2020-11-02 03:37:54 --> Security Class Initialized
DEBUG - 2020-11-02 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:37:54 --> Input Class Initialized
INFO - 2020-11-02 03:37:54 --> Language Class Initialized
INFO - 2020-11-02 03:37:54 --> Language Class Initialized
INFO - 2020-11-02 03:37:54 --> Config Class Initialized
INFO - 2020-11-02 03:37:54 --> Loader Class Initialized
INFO - 2020-11-02 03:37:54 --> Helper loaded: url_helper
INFO - 2020-11-02 03:37:55 --> Helper loaded: file_helper
INFO - 2020-11-02 03:37:55 --> Helper loaded: form_helper
INFO - 2020-11-02 03:37:55 --> Helper loaded: my_helper
INFO - 2020-11-02 03:37:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:37:55 --> Controller Class Initialized
INFO - 2020-11-02 03:37:55 --> Final output sent to browser
DEBUG - 2020-11-02 03:37:55 --> Total execution time: 0.3564
INFO - 2020-11-02 03:37:55 --> Config Class Initialized
INFO - 2020-11-02 03:37:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:37:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:37:55 --> Utf8 Class Initialized
INFO - 2020-11-02 03:37:55 --> URI Class Initialized
INFO - 2020-11-02 03:37:55 --> Router Class Initialized
INFO - 2020-11-02 03:37:55 --> Output Class Initialized
INFO - 2020-11-02 03:37:55 --> Security Class Initialized
DEBUG - 2020-11-02 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:37:55 --> Input Class Initialized
INFO - 2020-11-02 03:37:55 --> Language Class Initialized
INFO - 2020-11-02 03:37:55 --> Language Class Initialized
INFO - 2020-11-02 03:37:55 --> Config Class Initialized
INFO - 2020-11-02 03:37:55 --> Loader Class Initialized
INFO - 2020-11-02 03:37:55 --> Helper loaded: url_helper
INFO - 2020-11-02 03:37:55 --> Helper loaded: file_helper
INFO - 2020-11-02 03:37:55 --> Helper loaded: form_helper
INFO - 2020-11-02 03:37:55 --> Helper loaded: my_helper
INFO - 2020-11-02 03:37:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:37:55 --> Controller Class Initialized
DEBUG - 2020-11-02 03:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 03:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:37:55 --> Final output sent to browser
DEBUG - 2020-11-02 03:37:55 --> Total execution time: 0.3804
INFO - 2020-11-02 03:37:57 --> Config Class Initialized
INFO - 2020-11-02 03:37:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:37:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:37:57 --> Utf8 Class Initialized
INFO - 2020-11-02 03:37:57 --> URI Class Initialized
INFO - 2020-11-02 03:37:57 --> Router Class Initialized
INFO - 2020-11-02 03:37:57 --> Output Class Initialized
INFO - 2020-11-02 03:37:57 --> Security Class Initialized
DEBUG - 2020-11-02 03:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:37:57 --> Input Class Initialized
INFO - 2020-11-02 03:37:57 --> Language Class Initialized
INFO - 2020-11-02 03:37:57 --> Language Class Initialized
INFO - 2020-11-02 03:37:57 --> Config Class Initialized
INFO - 2020-11-02 03:37:58 --> Loader Class Initialized
INFO - 2020-11-02 03:37:58 --> Helper loaded: url_helper
INFO - 2020-11-02 03:37:58 --> Helper loaded: file_helper
INFO - 2020-11-02 03:37:58 --> Helper loaded: form_helper
INFO - 2020-11-02 03:37:58 --> Helper loaded: my_helper
INFO - 2020-11-02 03:37:58 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:37:58 --> Controller Class Initialized
DEBUG - 2020-11-02 03:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 03:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:37:58 --> Final output sent to browser
DEBUG - 2020-11-02 03:37:58 --> Total execution time: 0.3030
INFO - 2020-11-02 03:38:07 --> Config Class Initialized
INFO - 2020-11-02 03:38:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:38:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:38:07 --> Utf8 Class Initialized
INFO - 2020-11-02 03:38:07 --> URI Class Initialized
INFO - 2020-11-02 03:38:07 --> Router Class Initialized
INFO - 2020-11-02 03:38:07 --> Output Class Initialized
INFO - 2020-11-02 03:38:07 --> Security Class Initialized
DEBUG - 2020-11-02 03:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:38:07 --> Input Class Initialized
INFO - 2020-11-02 03:38:07 --> Language Class Initialized
INFO - 2020-11-02 03:38:07 --> Language Class Initialized
INFO - 2020-11-02 03:38:07 --> Config Class Initialized
INFO - 2020-11-02 03:38:07 --> Loader Class Initialized
INFO - 2020-11-02 03:38:07 --> Helper loaded: url_helper
INFO - 2020-11-02 03:38:07 --> Helper loaded: file_helper
INFO - 2020-11-02 03:38:07 --> Helper loaded: form_helper
INFO - 2020-11-02 03:38:07 --> Helper loaded: my_helper
INFO - 2020-11-02 03:38:07 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:38:07 --> Controller Class Initialized
DEBUG - 2020-11-02 03:38:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 03:38:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:38:07 --> Final output sent to browser
DEBUG - 2020-11-02 03:38:07 --> Total execution time: 0.3208
INFO - 2020-11-02 03:38:07 --> Config Class Initialized
INFO - 2020-11-02 03:38:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:38:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:38:07 --> Utf8 Class Initialized
INFO - 2020-11-02 03:38:07 --> URI Class Initialized
INFO - 2020-11-02 03:38:07 --> Router Class Initialized
INFO - 2020-11-02 03:38:07 --> Output Class Initialized
INFO - 2020-11-02 03:38:07 --> Security Class Initialized
DEBUG - 2020-11-02 03:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:38:07 --> Input Class Initialized
INFO - 2020-11-02 03:38:07 --> Language Class Initialized
INFO - 2020-11-02 03:38:07 --> Language Class Initialized
INFO - 2020-11-02 03:38:07 --> Config Class Initialized
INFO - 2020-11-02 03:38:07 --> Loader Class Initialized
INFO - 2020-11-02 03:38:07 --> Helper loaded: url_helper
INFO - 2020-11-02 03:38:07 --> Helper loaded: file_helper
INFO - 2020-11-02 03:38:07 --> Helper loaded: form_helper
INFO - 2020-11-02 03:38:07 --> Helper loaded: my_helper
INFO - 2020-11-02 03:38:07 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:38:08 --> Controller Class Initialized
INFO - 2020-11-02 03:38:10 --> Config Class Initialized
INFO - 2020-11-02 03:38:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:38:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:38:10 --> Utf8 Class Initialized
INFO - 2020-11-02 03:38:10 --> URI Class Initialized
INFO - 2020-11-02 03:38:10 --> Router Class Initialized
INFO - 2020-11-02 03:38:10 --> Output Class Initialized
INFO - 2020-11-02 03:38:10 --> Security Class Initialized
DEBUG - 2020-11-02 03:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:38:10 --> Input Class Initialized
INFO - 2020-11-02 03:38:10 --> Language Class Initialized
INFO - 2020-11-02 03:38:10 --> Language Class Initialized
INFO - 2020-11-02 03:38:10 --> Config Class Initialized
INFO - 2020-11-02 03:38:10 --> Loader Class Initialized
INFO - 2020-11-02 03:38:10 --> Helper loaded: url_helper
INFO - 2020-11-02 03:38:10 --> Helper loaded: file_helper
INFO - 2020-11-02 03:38:10 --> Helper loaded: form_helper
INFO - 2020-11-02 03:38:10 --> Helper loaded: my_helper
INFO - 2020-11-02 03:38:10 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:38:10 --> Controller Class Initialized
INFO - 2020-11-02 03:38:10 --> Final output sent to browser
DEBUG - 2020-11-02 03:38:10 --> Total execution time: 0.2544
INFO - 2020-11-02 03:38:11 --> Config Class Initialized
INFO - 2020-11-02 03:38:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:38:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:38:11 --> Utf8 Class Initialized
INFO - 2020-11-02 03:38:11 --> URI Class Initialized
INFO - 2020-11-02 03:38:11 --> Router Class Initialized
INFO - 2020-11-02 03:38:11 --> Output Class Initialized
INFO - 2020-11-02 03:38:11 --> Security Class Initialized
DEBUG - 2020-11-02 03:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:38:11 --> Input Class Initialized
INFO - 2020-11-02 03:38:11 --> Language Class Initialized
INFO - 2020-11-02 03:38:11 --> Language Class Initialized
INFO - 2020-11-02 03:38:11 --> Config Class Initialized
INFO - 2020-11-02 03:38:11 --> Loader Class Initialized
INFO - 2020-11-02 03:38:11 --> Helper loaded: url_helper
INFO - 2020-11-02 03:38:11 --> Helper loaded: file_helper
INFO - 2020-11-02 03:38:11 --> Helper loaded: form_helper
INFO - 2020-11-02 03:38:11 --> Helper loaded: my_helper
INFO - 2020-11-02 03:38:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:38:11 --> Controller Class Initialized
INFO - 2020-11-02 03:38:11 --> Final output sent to browser
DEBUG - 2020-11-02 03:38:11 --> Total execution time: 0.2519
INFO - 2020-11-02 03:38:14 --> Config Class Initialized
INFO - 2020-11-02 03:38:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:38:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:38:14 --> Utf8 Class Initialized
INFO - 2020-11-02 03:38:14 --> URI Class Initialized
INFO - 2020-11-02 03:38:14 --> Router Class Initialized
INFO - 2020-11-02 03:38:14 --> Output Class Initialized
INFO - 2020-11-02 03:38:14 --> Security Class Initialized
DEBUG - 2020-11-02 03:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:38:14 --> Input Class Initialized
INFO - 2020-11-02 03:38:14 --> Language Class Initialized
INFO - 2020-11-02 03:38:14 --> Language Class Initialized
INFO - 2020-11-02 03:38:14 --> Config Class Initialized
INFO - 2020-11-02 03:38:14 --> Loader Class Initialized
INFO - 2020-11-02 03:38:15 --> Helper loaded: url_helper
INFO - 2020-11-02 03:38:15 --> Helper loaded: file_helper
INFO - 2020-11-02 03:38:15 --> Helper loaded: form_helper
INFO - 2020-11-02 03:38:15 --> Helper loaded: my_helper
INFO - 2020-11-02 03:38:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:38:15 --> Controller Class Initialized
INFO - 2020-11-02 03:38:15 --> Final output sent to browser
DEBUG - 2020-11-02 03:38:15 --> Total execution time: 0.3827
INFO - 2020-11-02 03:38:15 --> Config Class Initialized
INFO - 2020-11-02 03:38:15 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:38:15 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:38:15 --> Utf8 Class Initialized
INFO - 2020-11-02 03:38:15 --> URI Class Initialized
INFO - 2020-11-02 03:38:15 --> Router Class Initialized
INFO - 2020-11-02 03:38:15 --> Output Class Initialized
INFO - 2020-11-02 03:38:15 --> Security Class Initialized
DEBUG - 2020-11-02 03:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:38:15 --> Input Class Initialized
INFO - 2020-11-02 03:38:15 --> Language Class Initialized
INFO - 2020-11-02 03:38:15 --> Language Class Initialized
INFO - 2020-11-02 03:38:15 --> Config Class Initialized
INFO - 2020-11-02 03:38:15 --> Loader Class Initialized
INFO - 2020-11-02 03:38:15 --> Helper loaded: url_helper
INFO - 2020-11-02 03:38:15 --> Helper loaded: file_helper
INFO - 2020-11-02 03:38:15 --> Helper loaded: form_helper
INFO - 2020-11-02 03:38:15 --> Helper loaded: my_helper
INFO - 2020-11-02 03:38:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:38:15 --> Controller Class Initialized
INFO - 2020-11-02 03:38:24 --> Config Class Initialized
INFO - 2020-11-02 03:38:24 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:38:24 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:38:24 --> Utf8 Class Initialized
INFO - 2020-11-02 03:38:24 --> URI Class Initialized
INFO - 2020-11-02 03:38:24 --> Router Class Initialized
INFO - 2020-11-02 03:38:24 --> Output Class Initialized
INFO - 2020-11-02 03:38:24 --> Security Class Initialized
DEBUG - 2020-11-02 03:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:38:24 --> Input Class Initialized
INFO - 2020-11-02 03:38:24 --> Language Class Initialized
INFO - 2020-11-02 03:38:25 --> Language Class Initialized
INFO - 2020-11-02 03:38:25 --> Config Class Initialized
INFO - 2020-11-02 03:38:25 --> Loader Class Initialized
INFO - 2020-11-02 03:38:25 --> Helper loaded: url_helper
INFO - 2020-11-02 03:38:25 --> Helper loaded: file_helper
INFO - 2020-11-02 03:38:25 --> Helper loaded: form_helper
INFO - 2020-11-02 03:38:25 --> Helper loaded: my_helper
INFO - 2020-11-02 03:38:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:38:25 --> Controller Class Initialized
INFO - 2020-11-02 03:38:25 --> Final output sent to browser
DEBUG - 2020-11-02 03:38:25 --> Total execution time: 0.3634
INFO - 2020-11-02 03:38:25 --> Config Class Initialized
INFO - 2020-11-02 03:38:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:38:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:38:25 --> Utf8 Class Initialized
INFO - 2020-11-02 03:38:25 --> URI Class Initialized
INFO - 2020-11-02 03:38:25 --> Router Class Initialized
INFO - 2020-11-02 03:38:25 --> Output Class Initialized
INFO - 2020-11-02 03:38:25 --> Security Class Initialized
DEBUG - 2020-11-02 03:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:38:25 --> Input Class Initialized
INFO - 2020-11-02 03:38:25 --> Language Class Initialized
INFO - 2020-11-02 03:38:25 --> Language Class Initialized
INFO - 2020-11-02 03:38:25 --> Config Class Initialized
INFO - 2020-11-02 03:38:25 --> Loader Class Initialized
INFO - 2020-11-02 03:38:25 --> Helper loaded: url_helper
INFO - 2020-11-02 03:38:25 --> Helper loaded: file_helper
INFO - 2020-11-02 03:38:25 --> Helper loaded: form_helper
INFO - 2020-11-02 03:38:25 --> Helper loaded: my_helper
INFO - 2020-11-02 03:38:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:38:25 --> Controller Class Initialized
INFO - 2020-11-02 03:39:47 --> Config Class Initialized
INFO - 2020-11-02 03:39:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:39:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:39:47 --> Utf8 Class Initialized
INFO - 2020-11-02 03:39:47 --> URI Class Initialized
INFO - 2020-11-02 03:39:47 --> Router Class Initialized
INFO - 2020-11-02 03:39:47 --> Output Class Initialized
INFO - 2020-11-02 03:39:47 --> Security Class Initialized
DEBUG - 2020-11-02 03:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:39:47 --> Input Class Initialized
INFO - 2020-11-02 03:39:47 --> Language Class Initialized
INFO - 2020-11-02 03:39:47 --> Language Class Initialized
INFO - 2020-11-02 03:39:47 --> Config Class Initialized
INFO - 2020-11-02 03:39:47 --> Loader Class Initialized
INFO - 2020-11-02 03:39:47 --> Helper loaded: url_helper
INFO - 2020-11-02 03:39:47 --> Helper loaded: file_helper
INFO - 2020-11-02 03:39:47 --> Helper loaded: form_helper
INFO - 2020-11-02 03:39:47 --> Helper loaded: my_helper
INFO - 2020-11-02 03:39:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:39:47 --> Controller Class Initialized
INFO - 2020-11-02 03:39:47 --> Final output sent to browser
DEBUG - 2020-11-02 03:39:47 --> Total execution time: 0.3999
INFO - 2020-11-02 03:39:50 --> Config Class Initialized
INFO - 2020-11-02 03:39:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:39:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:39:50 --> Utf8 Class Initialized
INFO - 2020-11-02 03:39:50 --> URI Class Initialized
INFO - 2020-11-02 03:39:50 --> Router Class Initialized
INFO - 2020-11-02 03:39:50 --> Output Class Initialized
INFO - 2020-11-02 03:39:50 --> Security Class Initialized
DEBUG - 2020-11-02 03:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:39:50 --> Input Class Initialized
INFO - 2020-11-02 03:39:50 --> Language Class Initialized
INFO - 2020-11-02 03:39:50 --> Language Class Initialized
INFO - 2020-11-02 03:39:51 --> Config Class Initialized
INFO - 2020-11-02 03:39:51 --> Loader Class Initialized
INFO - 2020-11-02 03:39:51 --> Helper loaded: url_helper
INFO - 2020-11-02 03:39:51 --> Helper loaded: file_helper
INFO - 2020-11-02 03:39:51 --> Helper loaded: form_helper
INFO - 2020-11-02 03:39:51 --> Helper loaded: my_helper
INFO - 2020-11-02 03:39:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:39:51 --> Controller Class Initialized
INFO - 2020-11-02 03:39:51 --> Final output sent to browser
DEBUG - 2020-11-02 03:39:51 --> Total execution time: 0.2837
INFO - 2020-11-02 03:40:01 --> Config Class Initialized
INFO - 2020-11-02 03:40:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:01 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:01 --> URI Class Initialized
INFO - 2020-11-02 03:40:01 --> Router Class Initialized
INFO - 2020-11-02 03:40:01 --> Output Class Initialized
INFO - 2020-11-02 03:40:01 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:01 --> Input Class Initialized
INFO - 2020-11-02 03:40:01 --> Language Class Initialized
INFO - 2020-11-02 03:40:01 --> Language Class Initialized
INFO - 2020-11-02 03:40:01 --> Config Class Initialized
INFO - 2020-11-02 03:40:01 --> Loader Class Initialized
INFO - 2020-11-02 03:40:01 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:01 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:01 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:01 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:01 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:01 --> Controller Class Initialized
INFO - 2020-11-02 03:40:01 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:01 --> Total execution time: 0.3402
INFO - 2020-11-02 03:40:03 --> Config Class Initialized
INFO - 2020-11-02 03:40:03 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:03 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:03 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:03 --> URI Class Initialized
INFO - 2020-11-02 03:40:03 --> Router Class Initialized
INFO - 2020-11-02 03:40:03 --> Output Class Initialized
INFO - 2020-11-02 03:40:03 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:03 --> Input Class Initialized
INFO - 2020-11-02 03:40:03 --> Language Class Initialized
INFO - 2020-11-02 03:40:03 --> Language Class Initialized
INFO - 2020-11-02 03:40:03 --> Config Class Initialized
INFO - 2020-11-02 03:40:03 --> Loader Class Initialized
INFO - 2020-11-02 03:40:03 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:03 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:03 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:03 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:03 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:03 --> Controller Class Initialized
INFO - 2020-11-02 03:40:03 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:03 --> Total execution time: 0.2800
INFO - 2020-11-02 03:40:07 --> Config Class Initialized
INFO - 2020-11-02 03:40:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:08 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:08 --> URI Class Initialized
INFO - 2020-11-02 03:40:08 --> Router Class Initialized
INFO - 2020-11-02 03:40:08 --> Output Class Initialized
INFO - 2020-11-02 03:40:08 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:08 --> Input Class Initialized
INFO - 2020-11-02 03:40:08 --> Language Class Initialized
INFO - 2020-11-02 03:40:08 --> Language Class Initialized
INFO - 2020-11-02 03:40:08 --> Config Class Initialized
INFO - 2020-11-02 03:40:08 --> Loader Class Initialized
INFO - 2020-11-02 03:40:08 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:08 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:08 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:08 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:08 --> Controller Class Initialized
INFO - 2020-11-02 03:40:08 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:08 --> Total execution time: 0.3533
INFO - 2020-11-02 03:40:32 --> Config Class Initialized
INFO - 2020-11-02 03:40:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:32 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:32 --> URI Class Initialized
INFO - 2020-11-02 03:40:32 --> Router Class Initialized
INFO - 2020-11-02 03:40:32 --> Output Class Initialized
INFO - 2020-11-02 03:40:32 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:32 --> Input Class Initialized
INFO - 2020-11-02 03:40:32 --> Language Class Initialized
INFO - 2020-11-02 03:40:32 --> Language Class Initialized
INFO - 2020-11-02 03:40:32 --> Config Class Initialized
INFO - 2020-11-02 03:40:32 --> Loader Class Initialized
INFO - 2020-11-02 03:40:32 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:32 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:32 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:32 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:32 --> Controller Class Initialized
DEBUG - 2020-11-02 03:40:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 03:40:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:40:32 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:32 --> Total execution time: 0.2966
INFO - 2020-11-02 03:40:33 --> Config Class Initialized
INFO - 2020-11-02 03:40:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:33 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:33 --> URI Class Initialized
INFO - 2020-11-02 03:40:33 --> Router Class Initialized
INFO - 2020-11-02 03:40:33 --> Output Class Initialized
INFO - 2020-11-02 03:40:33 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:33 --> Input Class Initialized
INFO - 2020-11-02 03:40:33 --> Language Class Initialized
INFO - 2020-11-02 03:40:33 --> Language Class Initialized
INFO - 2020-11-02 03:40:33 --> Config Class Initialized
INFO - 2020-11-02 03:40:33 --> Loader Class Initialized
INFO - 2020-11-02 03:40:33 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:33 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:33 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:33 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:33 --> Controller Class Initialized
DEBUG - 2020-11-02 03:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 03:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:40:33 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:33 --> Total execution time: 0.3135
INFO - 2020-11-02 03:40:36 --> Config Class Initialized
INFO - 2020-11-02 03:40:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:36 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:36 --> URI Class Initialized
INFO - 2020-11-02 03:40:36 --> Router Class Initialized
INFO - 2020-11-02 03:40:36 --> Output Class Initialized
INFO - 2020-11-02 03:40:36 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:36 --> Input Class Initialized
INFO - 2020-11-02 03:40:36 --> Language Class Initialized
INFO - 2020-11-02 03:40:36 --> Language Class Initialized
INFO - 2020-11-02 03:40:36 --> Config Class Initialized
INFO - 2020-11-02 03:40:36 --> Loader Class Initialized
INFO - 2020-11-02 03:40:36 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:36 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:36 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:36 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:36 --> Controller Class Initialized
INFO - 2020-11-02 03:40:36 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:36 --> Total execution time: 0.2900
INFO - 2020-11-02 03:40:38 --> Config Class Initialized
INFO - 2020-11-02 03:40:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:38 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:38 --> URI Class Initialized
INFO - 2020-11-02 03:40:38 --> Router Class Initialized
INFO - 2020-11-02 03:40:38 --> Output Class Initialized
INFO - 2020-11-02 03:40:38 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:38 --> Input Class Initialized
INFO - 2020-11-02 03:40:38 --> Language Class Initialized
INFO - 2020-11-02 03:40:38 --> Language Class Initialized
INFO - 2020-11-02 03:40:38 --> Config Class Initialized
INFO - 2020-11-02 03:40:38 --> Loader Class Initialized
INFO - 2020-11-02 03:40:38 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:38 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:38 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:38 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:38 --> Controller Class Initialized
INFO - 2020-11-02 03:40:38 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:38 --> Total execution time: 0.2565
INFO - 2020-11-02 03:40:48 --> Config Class Initialized
INFO - 2020-11-02 03:40:48 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:48 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:48 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:48 --> URI Class Initialized
INFO - 2020-11-02 03:40:48 --> Router Class Initialized
INFO - 2020-11-02 03:40:48 --> Output Class Initialized
INFO - 2020-11-02 03:40:48 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:48 --> Input Class Initialized
INFO - 2020-11-02 03:40:48 --> Language Class Initialized
INFO - 2020-11-02 03:40:48 --> Language Class Initialized
INFO - 2020-11-02 03:40:48 --> Config Class Initialized
INFO - 2020-11-02 03:40:48 --> Loader Class Initialized
INFO - 2020-11-02 03:40:48 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:48 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:48 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:48 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:48 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:48 --> Controller Class Initialized
INFO - 2020-11-02 03:40:48 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:48 --> Total execution time: 0.4126
INFO - 2020-11-02 03:40:50 --> Config Class Initialized
INFO - 2020-11-02 03:40:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:50 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:50 --> URI Class Initialized
INFO - 2020-11-02 03:40:50 --> Router Class Initialized
INFO - 2020-11-02 03:40:50 --> Output Class Initialized
INFO - 2020-11-02 03:40:50 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:50 --> Input Class Initialized
INFO - 2020-11-02 03:40:50 --> Language Class Initialized
INFO - 2020-11-02 03:40:50 --> Language Class Initialized
INFO - 2020-11-02 03:40:50 --> Config Class Initialized
INFO - 2020-11-02 03:40:50 --> Loader Class Initialized
INFO - 2020-11-02 03:40:50 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:50 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:50 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:50 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:50 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:50 --> Controller Class Initialized
DEBUG - 2020-11-02 03:40:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 03:40:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:40:50 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:50 --> Total execution time: 0.3291
INFO - 2020-11-02 03:40:53 --> Config Class Initialized
INFO - 2020-11-02 03:40:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:53 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:53 --> URI Class Initialized
INFO - 2020-11-02 03:40:53 --> Router Class Initialized
INFO - 2020-11-02 03:40:53 --> Output Class Initialized
INFO - 2020-11-02 03:40:53 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:53 --> Input Class Initialized
INFO - 2020-11-02 03:40:53 --> Language Class Initialized
INFO - 2020-11-02 03:40:53 --> Language Class Initialized
INFO - 2020-11-02 03:40:53 --> Config Class Initialized
INFO - 2020-11-02 03:40:53 --> Loader Class Initialized
INFO - 2020-11-02 03:40:53 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:53 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:53 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:53 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:53 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:53 --> Controller Class Initialized
DEBUG - 2020-11-02 03:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 03:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:40:53 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:53 --> Total execution time: 0.2954
INFO - 2020-11-02 03:40:55 --> Config Class Initialized
INFO - 2020-11-02 03:40:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:55 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:55 --> URI Class Initialized
INFO - 2020-11-02 03:40:55 --> Router Class Initialized
INFO - 2020-11-02 03:40:55 --> Output Class Initialized
INFO - 2020-11-02 03:40:55 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:55 --> Input Class Initialized
INFO - 2020-11-02 03:40:55 --> Language Class Initialized
INFO - 2020-11-02 03:40:55 --> Language Class Initialized
INFO - 2020-11-02 03:40:55 --> Config Class Initialized
INFO - 2020-11-02 03:40:55 --> Loader Class Initialized
INFO - 2020-11-02 03:40:55 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:55 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:55 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:55 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:55 --> Controller Class Initialized
DEBUG - 2020-11-02 03:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 03:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:40:55 --> Final output sent to browser
DEBUG - 2020-11-02 03:40:55 --> Total execution time: 0.2912
INFO - 2020-11-02 03:40:55 --> Config Class Initialized
INFO - 2020-11-02 03:40:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:40:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:40:55 --> Utf8 Class Initialized
INFO - 2020-11-02 03:40:55 --> URI Class Initialized
INFO - 2020-11-02 03:40:55 --> Router Class Initialized
INFO - 2020-11-02 03:40:55 --> Output Class Initialized
INFO - 2020-11-02 03:40:55 --> Security Class Initialized
DEBUG - 2020-11-02 03:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:40:55 --> Input Class Initialized
INFO - 2020-11-02 03:40:55 --> Language Class Initialized
INFO - 2020-11-02 03:40:55 --> Language Class Initialized
INFO - 2020-11-02 03:40:55 --> Config Class Initialized
INFO - 2020-11-02 03:40:55 --> Loader Class Initialized
INFO - 2020-11-02 03:40:55 --> Helper loaded: url_helper
INFO - 2020-11-02 03:40:55 --> Helper loaded: file_helper
INFO - 2020-11-02 03:40:55 --> Helper loaded: form_helper
INFO - 2020-11-02 03:40:55 --> Helper loaded: my_helper
INFO - 2020-11-02 03:40:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:40:55 --> Controller Class Initialized
INFO - 2020-11-02 03:41:27 --> Config Class Initialized
INFO - 2020-11-02 03:41:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:41:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:41:27 --> Utf8 Class Initialized
INFO - 2020-11-02 03:41:27 --> URI Class Initialized
INFO - 2020-11-02 03:41:27 --> Router Class Initialized
INFO - 2020-11-02 03:41:27 --> Output Class Initialized
INFO - 2020-11-02 03:41:27 --> Security Class Initialized
DEBUG - 2020-11-02 03:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:41:27 --> Input Class Initialized
INFO - 2020-11-02 03:41:27 --> Language Class Initialized
INFO - 2020-11-02 03:41:27 --> Language Class Initialized
INFO - 2020-11-02 03:41:27 --> Config Class Initialized
INFO - 2020-11-02 03:41:27 --> Loader Class Initialized
INFO - 2020-11-02 03:41:27 --> Helper loaded: url_helper
INFO - 2020-11-02 03:41:27 --> Helper loaded: file_helper
INFO - 2020-11-02 03:41:27 --> Helper loaded: form_helper
INFO - 2020-11-02 03:41:27 --> Helper loaded: my_helper
INFO - 2020-11-02 03:41:27 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:41:27 --> Controller Class Initialized
DEBUG - 2020-11-02 03:41:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-02 03:41:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 03:41:27 --> Final output sent to browser
DEBUG - 2020-11-02 03:41:27 --> Total execution time: 0.2937
INFO - 2020-11-02 03:41:29 --> Config Class Initialized
INFO - 2020-11-02 03:41:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:41:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:41:29 --> Utf8 Class Initialized
INFO - 2020-11-02 03:41:29 --> URI Class Initialized
INFO - 2020-11-02 03:41:29 --> Router Class Initialized
INFO - 2020-11-02 03:41:29 --> Output Class Initialized
INFO - 2020-11-02 03:41:29 --> Security Class Initialized
DEBUG - 2020-11-02 03:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:41:29 --> Input Class Initialized
INFO - 2020-11-02 03:41:29 --> Language Class Initialized
INFO - 2020-11-02 03:41:29 --> Language Class Initialized
INFO - 2020-11-02 03:41:29 --> Config Class Initialized
INFO - 2020-11-02 03:41:29 --> Loader Class Initialized
INFO - 2020-11-02 03:41:29 --> Helper loaded: url_helper
INFO - 2020-11-02 03:41:29 --> Helper loaded: file_helper
INFO - 2020-11-02 03:41:29 --> Helper loaded: form_helper
INFO - 2020-11-02 03:41:29 --> Helper loaded: my_helper
INFO - 2020-11-02 03:41:29 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:41:29 --> Controller Class Initialized
DEBUG - 2020-11-02 03:41:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 03:41:29 --> Final output sent to browser
DEBUG - 2020-11-02 03:41:29 --> Total execution time: 0.3315
INFO - 2020-11-02 03:41:36 --> Config Class Initialized
INFO - 2020-11-02 03:41:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 03:41:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 03:41:36 --> Utf8 Class Initialized
INFO - 2020-11-02 03:41:36 --> URI Class Initialized
INFO - 2020-11-02 03:41:36 --> Router Class Initialized
INFO - 2020-11-02 03:41:36 --> Output Class Initialized
INFO - 2020-11-02 03:41:36 --> Security Class Initialized
DEBUG - 2020-11-02 03:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 03:41:36 --> Input Class Initialized
INFO - 2020-11-02 03:41:36 --> Language Class Initialized
INFO - 2020-11-02 03:41:36 --> Language Class Initialized
INFO - 2020-11-02 03:41:36 --> Config Class Initialized
INFO - 2020-11-02 03:41:36 --> Loader Class Initialized
INFO - 2020-11-02 03:41:36 --> Helper loaded: url_helper
INFO - 2020-11-02 03:41:36 --> Helper loaded: file_helper
INFO - 2020-11-02 03:41:36 --> Helper loaded: form_helper
INFO - 2020-11-02 03:41:36 --> Helper loaded: my_helper
INFO - 2020-11-02 03:41:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 03:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 03:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 03:41:36 --> Controller Class Initialized
DEBUG - 2020-11-02 03:41:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-11-02 03:41:36 --> Final output sent to browser
DEBUG - 2020-11-02 03:41:36 --> Total execution time: 0.3093
INFO - 2020-11-02 04:13:35 --> Config Class Initialized
INFO - 2020-11-02 04:13:35 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:35 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:35 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:35 --> URI Class Initialized
INFO - 2020-11-02 04:13:35 --> Router Class Initialized
INFO - 2020-11-02 04:13:35 --> Output Class Initialized
INFO - 2020-11-02 04:13:35 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:35 --> Input Class Initialized
INFO - 2020-11-02 04:13:35 --> Language Class Initialized
INFO - 2020-11-02 04:13:35 --> Language Class Initialized
INFO - 2020-11-02 04:13:35 --> Config Class Initialized
INFO - 2020-11-02 04:13:35 --> Loader Class Initialized
INFO - 2020-11-02 04:13:35 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:35 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:35 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:35 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:35 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:35 --> Controller Class Initialized
DEBUG - 2020-11-02 04:13:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-11-02 04:13:35 --> Final output sent to browser
DEBUG - 2020-11-02 04:13:35 --> Total execution time: 0.2880
INFO - 2020-11-02 04:13:38 --> Config Class Initialized
INFO - 2020-11-02 04:13:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:38 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:38 --> URI Class Initialized
INFO - 2020-11-02 04:13:38 --> Router Class Initialized
INFO - 2020-11-02 04:13:38 --> Output Class Initialized
INFO - 2020-11-02 04:13:38 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:38 --> Input Class Initialized
INFO - 2020-11-02 04:13:38 --> Language Class Initialized
INFO - 2020-11-02 04:13:38 --> Language Class Initialized
INFO - 2020-11-02 04:13:38 --> Config Class Initialized
INFO - 2020-11-02 04:13:38 --> Loader Class Initialized
INFO - 2020-11-02 04:13:38 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:38 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:38 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:38 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:38 --> Controller Class Initialized
DEBUG - 2020-11-02 04:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:13:38 --> Final output sent to browser
DEBUG - 2020-11-02 04:13:38 --> Total execution time: 0.3009
INFO - 2020-11-02 04:13:40 --> Config Class Initialized
INFO - 2020-11-02 04:13:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:40 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:40 --> URI Class Initialized
INFO - 2020-11-02 04:13:40 --> Router Class Initialized
INFO - 2020-11-02 04:13:40 --> Output Class Initialized
INFO - 2020-11-02 04:13:40 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:40 --> Input Class Initialized
INFO - 2020-11-02 04:13:40 --> Language Class Initialized
INFO - 2020-11-02 04:13:40 --> Language Class Initialized
INFO - 2020-11-02 04:13:40 --> Config Class Initialized
INFO - 2020-11-02 04:13:40 --> Loader Class Initialized
INFO - 2020-11-02 04:13:40 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:40 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:40 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:40 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:40 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:40 --> Controller Class Initialized
DEBUG - 2020-11-02 04:13:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:13:40 --> Final output sent to browser
DEBUG - 2020-11-02 04:13:40 --> Total execution time: 0.3009
INFO - 2020-11-02 04:13:45 --> Config Class Initialized
INFO - 2020-11-02 04:13:45 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:45 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:45 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:45 --> URI Class Initialized
INFO - 2020-11-02 04:13:45 --> Router Class Initialized
INFO - 2020-11-02 04:13:45 --> Output Class Initialized
INFO - 2020-11-02 04:13:45 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:45 --> Input Class Initialized
INFO - 2020-11-02 04:13:45 --> Language Class Initialized
INFO - 2020-11-02 04:13:45 --> Language Class Initialized
INFO - 2020-11-02 04:13:45 --> Config Class Initialized
INFO - 2020-11-02 04:13:45 --> Loader Class Initialized
INFO - 2020-11-02 04:13:45 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:45 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:45 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:45 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:45 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:45 --> Controller Class Initialized
DEBUG - 2020-11-02 04:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:13:45 --> Final output sent to browser
DEBUG - 2020-11-02 04:13:45 --> Total execution time: 0.3031
INFO - 2020-11-02 04:13:46 --> Config Class Initialized
INFO - 2020-11-02 04:13:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:46 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:46 --> URI Class Initialized
INFO - 2020-11-02 04:13:46 --> Router Class Initialized
INFO - 2020-11-02 04:13:46 --> Output Class Initialized
INFO - 2020-11-02 04:13:46 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:46 --> Input Class Initialized
INFO - 2020-11-02 04:13:46 --> Language Class Initialized
INFO - 2020-11-02 04:13:46 --> Language Class Initialized
INFO - 2020-11-02 04:13:46 --> Config Class Initialized
INFO - 2020-11-02 04:13:46 --> Loader Class Initialized
INFO - 2020-11-02 04:13:46 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:46 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:46 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:46 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:46 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:46 --> Controller Class Initialized
DEBUG - 2020-11-02 04:13:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:13:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:13:46 --> Final output sent to browser
DEBUG - 2020-11-02 04:13:46 --> Total execution time: 0.3406
INFO - 2020-11-02 04:13:46 --> Config Class Initialized
INFO - 2020-11-02 04:13:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:47 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:47 --> URI Class Initialized
INFO - 2020-11-02 04:13:47 --> Router Class Initialized
INFO - 2020-11-02 04:13:47 --> Output Class Initialized
INFO - 2020-11-02 04:13:47 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:47 --> Input Class Initialized
INFO - 2020-11-02 04:13:47 --> Language Class Initialized
INFO - 2020-11-02 04:13:47 --> Language Class Initialized
INFO - 2020-11-02 04:13:47 --> Config Class Initialized
INFO - 2020-11-02 04:13:47 --> Loader Class Initialized
INFO - 2020-11-02 04:13:47 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:47 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:47 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:47 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:47 --> Controller Class Initialized
INFO - 2020-11-02 04:13:54 --> Config Class Initialized
INFO - 2020-11-02 04:13:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:54 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:54 --> URI Class Initialized
INFO - 2020-11-02 04:13:54 --> Router Class Initialized
INFO - 2020-11-02 04:13:54 --> Output Class Initialized
INFO - 2020-11-02 04:13:54 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:54 --> Input Class Initialized
INFO - 2020-11-02 04:13:55 --> Language Class Initialized
INFO - 2020-11-02 04:13:55 --> Language Class Initialized
INFO - 2020-11-02 04:13:55 --> Config Class Initialized
INFO - 2020-11-02 04:13:55 --> Loader Class Initialized
INFO - 2020-11-02 04:13:55 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:55 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:55 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:55 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:55 --> Controller Class Initialized
DEBUG - 2020-11-02 04:13:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:13:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:13:55 --> Final output sent to browser
DEBUG - 2020-11-02 04:13:55 --> Total execution time: 0.3218
INFO - 2020-11-02 04:13:55 --> Config Class Initialized
INFO - 2020-11-02 04:13:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:55 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:55 --> URI Class Initialized
INFO - 2020-11-02 04:13:55 --> Router Class Initialized
INFO - 2020-11-02 04:13:55 --> Output Class Initialized
INFO - 2020-11-02 04:13:55 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:55 --> Input Class Initialized
INFO - 2020-11-02 04:13:55 --> Language Class Initialized
INFO - 2020-11-02 04:13:55 --> Language Class Initialized
INFO - 2020-11-02 04:13:55 --> Config Class Initialized
INFO - 2020-11-02 04:13:55 --> Loader Class Initialized
INFO - 2020-11-02 04:13:55 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:55 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:55 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:55 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:55 --> Controller Class Initialized
INFO - 2020-11-02 04:13:57 --> Config Class Initialized
INFO - 2020-11-02 04:13:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:57 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:57 --> URI Class Initialized
INFO - 2020-11-02 04:13:57 --> Router Class Initialized
INFO - 2020-11-02 04:13:57 --> Output Class Initialized
INFO - 2020-11-02 04:13:57 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:57 --> Input Class Initialized
INFO - 2020-11-02 04:13:57 --> Language Class Initialized
INFO - 2020-11-02 04:13:57 --> Language Class Initialized
INFO - 2020-11-02 04:13:57 --> Config Class Initialized
INFO - 2020-11-02 04:13:57 --> Loader Class Initialized
INFO - 2020-11-02 04:13:57 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:57 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:57 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:57 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:57 --> Controller Class Initialized
DEBUG - 2020-11-02 04:13:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:13:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:13:58 --> Final output sent to browser
DEBUG - 2020-11-02 04:13:58 --> Total execution time: 0.3353
INFO - 2020-11-02 04:13:58 --> Config Class Initialized
INFO - 2020-11-02 04:13:58 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:13:58 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:13:58 --> Utf8 Class Initialized
INFO - 2020-11-02 04:13:58 --> URI Class Initialized
INFO - 2020-11-02 04:13:58 --> Router Class Initialized
INFO - 2020-11-02 04:13:58 --> Output Class Initialized
INFO - 2020-11-02 04:13:58 --> Security Class Initialized
DEBUG - 2020-11-02 04:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:13:58 --> Input Class Initialized
INFO - 2020-11-02 04:13:58 --> Language Class Initialized
INFO - 2020-11-02 04:13:58 --> Language Class Initialized
INFO - 2020-11-02 04:13:58 --> Config Class Initialized
INFO - 2020-11-02 04:13:58 --> Loader Class Initialized
INFO - 2020-11-02 04:13:58 --> Helper loaded: url_helper
INFO - 2020-11-02 04:13:58 --> Helper loaded: file_helper
INFO - 2020-11-02 04:13:58 --> Helper loaded: form_helper
INFO - 2020-11-02 04:13:58 --> Helper loaded: my_helper
INFO - 2020-11-02 04:13:58 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:13:58 --> Controller Class Initialized
INFO - 2020-11-02 04:14:15 --> Config Class Initialized
INFO - 2020-11-02 04:14:15 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:14:15 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:14:15 --> Utf8 Class Initialized
INFO - 2020-11-02 04:14:15 --> URI Class Initialized
INFO - 2020-11-02 04:14:15 --> Router Class Initialized
INFO - 2020-11-02 04:14:15 --> Output Class Initialized
INFO - 2020-11-02 04:14:15 --> Security Class Initialized
DEBUG - 2020-11-02 04:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:14:15 --> Input Class Initialized
INFO - 2020-11-02 04:14:15 --> Language Class Initialized
INFO - 2020-11-02 04:14:15 --> Language Class Initialized
INFO - 2020-11-02 04:14:15 --> Config Class Initialized
INFO - 2020-11-02 04:14:15 --> Loader Class Initialized
INFO - 2020-11-02 04:14:15 --> Helper loaded: url_helper
INFO - 2020-11-02 04:14:15 --> Helper loaded: file_helper
INFO - 2020-11-02 04:14:15 --> Helper loaded: form_helper
INFO - 2020-11-02 04:14:15 --> Helper loaded: my_helper
INFO - 2020-11-02 04:14:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:14:15 --> Controller Class Initialized
INFO - 2020-11-02 04:14:18 --> Config Class Initialized
INFO - 2020-11-02 04:14:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:14:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:14:18 --> Utf8 Class Initialized
INFO - 2020-11-02 04:14:18 --> URI Class Initialized
INFO - 2020-11-02 04:14:18 --> Router Class Initialized
INFO - 2020-11-02 04:14:18 --> Output Class Initialized
INFO - 2020-11-02 04:14:18 --> Security Class Initialized
DEBUG - 2020-11-02 04:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:14:18 --> Input Class Initialized
INFO - 2020-11-02 04:14:18 --> Language Class Initialized
INFO - 2020-11-02 04:14:18 --> Language Class Initialized
INFO - 2020-11-02 04:14:18 --> Config Class Initialized
INFO - 2020-11-02 04:14:18 --> Loader Class Initialized
INFO - 2020-11-02 04:14:18 --> Helper loaded: url_helper
INFO - 2020-11-02 04:14:18 --> Helper loaded: file_helper
INFO - 2020-11-02 04:14:18 --> Helper loaded: form_helper
INFO - 2020-11-02 04:14:18 --> Helper loaded: my_helper
INFO - 2020-11-02 04:14:18 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:14:18 --> Controller Class Initialized
DEBUG - 2020-11-02 04:14:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:14:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:14:18 --> Final output sent to browser
DEBUG - 2020-11-02 04:14:18 --> Total execution time: 0.3143
INFO - 2020-11-02 04:14:18 --> Config Class Initialized
INFO - 2020-11-02 04:14:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:14:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:14:18 --> Utf8 Class Initialized
INFO - 2020-11-02 04:14:18 --> URI Class Initialized
INFO - 2020-11-02 04:14:18 --> Router Class Initialized
INFO - 2020-11-02 04:14:18 --> Output Class Initialized
INFO - 2020-11-02 04:14:18 --> Security Class Initialized
DEBUG - 2020-11-02 04:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:14:18 --> Input Class Initialized
INFO - 2020-11-02 04:14:18 --> Language Class Initialized
INFO - 2020-11-02 04:14:18 --> Language Class Initialized
INFO - 2020-11-02 04:14:18 --> Config Class Initialized
INFO - 2020-11-02 04:14:18 --> Loader Class Initialized
INFO - 2020-11-02 04:14:18 --> Helper loaded: url_helper
INFO - 2020-11-02 04:14:18 --> Helper loaded: file_helper
INFO - 2020-11-02 04:14:18 --> Helper loaded: form_helper
INFO - 2020-11-02 04:14:18 --> Helper loaded: my_helper
INFO - 2020-11-02 04:14:18 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:14:18 --> Controller Class Initialized
INFO - 2020-11-02 04:14:46 --> Config Class Initialized
INFO - 2020-11-02 04:14:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:14:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:14:46 --> Utf8 Class Initialized
INFO - 2020-11-02 04:14:46 --> URI Class Initialized
INFO - 2020-11-02 04:14:46 --> Router Class Initialized
INFO - 2020-11-02 04:14:46 --> Output Class Initialized
INFO - 2020-11-02 04:14:46 --> Security Class Initialized
DEBUG - 2020-11-02 04:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:14:46 --> Input Class Initialized
INFO - 2020-11-02 04:14:46 --> Language Class Initialized
INFO - 2020-11-02 04:14:46 --> Language Class Initialized
INFO - 2020-11-02 04:14:46 --> Config Class Initialized
INFO - 2020-11-02 04:14:46 --> Loader Class Initialized
INFO - 2020-11-02 04:14:46 --> Helper loaded: url_helper
INFO - 2020-11-02 04:14:46 --> Helper loaded: file_helper
INFO - 2020-11-02 04:14:46 --> Helper loaded: form_helper
INFO - 2020-11-02 04:14:46 --> Helper loaded: my_helper
INFO - 2020-11-02 04:14:46 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:14:46 --> Controller Class Initialized
DEBUG - 2020-11-02 04:14:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:14:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:14:46 --> Final output sent to browser
DEBUG - 2020-11-02 04:14:46 --> Total execution time: 0.3047
INFO - 2020-11-02 04:14:46 --> Config Class Initialized
INFO - 2020-11-02 04:14:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:14:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:14:46 --> Utf8 Class Initialized
INFO - 2020-11-02 04:14:47 --> URI Class Initialized
INFO - 2020-11-02 04:14:47 --> Router Class Initialized
INFO - 2020-11-02 04:14:47 --> Output Class Initialized
INFO - 2020-11-02 04:14:47 --> Security Class Initialized
DEBUG - 2020-11-02 04:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:14:47 --> Input Class Initialized
INFO - 2020-11-02 04:14:47 --> Language Class Initialized
INFO - 2020-11-02 04:14:47 --> Language Class Initialized
INFO - 2020-11-02 04:14:47 --> Config Class Initialized
INFO - 2020-11-02 04:14:47 --> Loader Class Initialized
INFO - 2020-11-02 04:14:47 --> Helper loaded: url_helper
INFO - 2020-11-02 04:14:47 --> Helper loaded: file_helper
INFO - 2020-11-02 04:14:47 --> Helper loaded: form_helper
INFO - 2020-11-02 04:14:47 --> Helper loaded: my_helper
INFO - 2020-11-02 04:14:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:14:47 --> Controller Class Initialized
INFO - 2020-11-02 04:15:24 --> Config Class Initialized
INFO - 2020-11-02 04:15:24 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:24 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:24 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:24 --> URI Class Initialized
INFO - 2020-11-02 04:15:24 --> Router Class Initialized
INFO - 2020-11-02 04:15:24 --> Output Class Initialized
INFO - 2020-11-02 04:15:24 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:24 --> Input Class Initialized
INFO - 2020-11-02 04:15:24 --> Language Class Initialized
INFO - 2020-11-02 04:15:24 --> Language Class Initialized
INFO - 2020-11-02 04:15:24 --> Config Class Initialized
INFO - 2020-11-02 04:15:24 --> Loader Class Initialized
INFO - 2020-11-02 04:15:24 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:24 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:24 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:24 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:24 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:24 --> Controller Class Initialized
INFO - 2020-11-02 04:15:24 --> Final output sent to browser
DEBUG - 2020-11-02 04:15:24 --> Total execution time: 0.3067
INFO - 2020-11-02 04:15:30 --> Config Class Initialized
INFO - 2020-11-02 04:15:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:30 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:30 --> URI Class Initialized
INFO - 2020-11-02 04:15:30 --> Router Class Initialized
INFO - 2020-11-02 04:15:30 --> Output Class Initialized
INFO - 2020-11-02 04:15:30 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:30 --> Input Class Initialized
INFO - 2020-11-02 04:15:30 --> Language Class Initialized
INFO - 2020-11-02 04:15:30 --> Language Class Initialized
INFO - 2020-11-02 04:15:30 --> Config Class Initialized
INFO - 2020-11-02 04:15:30 --> Loader Class Initialized
INFO - 2020-11-02 04:15:30 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:30 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:30 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:30 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:30 --> Controller Class Initialized
INFO - 2020-11-02 04:15:30 --> Final output sent to browser
DEBUG - 2020-11-02 04:15:30 --> Total execution time: 0.3667
INFO - 2020-11-02 04:15:30 --> Config Class Initialized
INFO - 2020-11-02 04:15:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:30 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:30 --> URI Class Initialized
INFO - 2020-11-02 04:15:30 --> Router Class Initialized
INFO - 2020-11-02 04:15:30 --> Output Class Initialized
INFO - 2020-11-02 04:15:30 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:30 --> Input Class Initialized
INFO - 2020-11-02 04:15:30 --> Language Class Initialized
INFO - 2020-11-02 04:15:30 --> Language Class Initialized
INFO - 2020-11-02 04:15:30 --> Config Class Initialized
INFO - 2020-11-02 04:15:30 --> Loader Class Initialized
INFO - 2020-11-02 04:15:30 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:30 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:30 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:30 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:30 --> Controller Class Initialized
INFO - 2020-11-02 04:15:33 --> Config Class Initialized
INFO - 2020-11-02 04:15:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:33 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:33 --> URI Class Initialized
INFO - 2020-11-02 04:15:33 --> Router Class Initialized
INFO - 2020-11-02 04:15:33 --> Output Class Initialized
INFO - 2020-11-02 04:15:33 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:33 --> Input Class Initialized
INFO - 2020-11-02 04:15:33 --> Language Class Initialized
INFO - 2020-11-02 04:15:33 --> Language Class Initialized
INFO - 2020-11-02 04:15:33 --> Config Class Initialized
INFO - 2020-11-02 04:15:33 --> Loader Class Initialized
INFO - 2020-11-02 04:15:33 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:33 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:33 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:33 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:33 --> Controller Class Initialized
INFO - 2020-11-02 04:15:33 --> Final output sent to browser
DEBUG - 2020-11-02 04:15:33 --> Total execution time: 0.2741
INFO - 2020-11-02 04:15:49 --> Config Class Initialized
INFO - 2020-11-02 04:15:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:49 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:49 --> URI Class Initialized
INFO - 2020-11-02 04:15:49 --> Router Class Initialized
INFO - 2020-11-02 04:15:49 --> Output Class Initialized
INFO - 2020-11-02 04:15:49 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:49 --> Input Class Initialized
INFO - 2020-11-02 04:15:49 --> Language Class Initialized
INFO - 2020-11-02 04:15:49 --> Language Class Initialized
INFO - 2020-11-02 04:15:49 --> Config Class Initialized
INFO - 2020-11-02 04:15:49 --> Loader Class Initialized
INFO - 2020-11-02 04:15:49 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:49 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:50 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:50 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:50 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:50 --> Controller Class Initialized
DEBUG - 2020-11-02 04:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-11-02 04:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:15:50 --> Final output sent to browser
DEBUG - 2020-11-02 04:15:50 --> Total execution time: 0.3153
INFO - 2020-11-02 04:15:53 --> Config Class Initialized
INFO - 2020-11-02 04:15:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:53 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:53 --> URI Class Initialized
INFO - 2020-11-02 04:15:53 --> Router Class Initialized
INFO - 2020-11-02 04:15:53 --> Output Class Initialized
INFO - 2020-11-02 04:15:53 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:53 --> Input Class Initialized
INFO - 2020-11-02 04:15:53 --> Language Class Initialized
INFO - 2020-11-02 04:15:53 --> Language Class Initialized
INFO - 2020-11-02 04:15:53 --> Config Class Initialized
INFO - 2020-11-02 04:15:53 --> Loader Class Initialized
INFO - 2020-11-02 04:15:53 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:53 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:53 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:53 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:53 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:53 --> Controller Class Initialized
INFO - 2020-11-02 04:15:54 --> Config Class Initialized
INFO - 2020-11-02 04:15:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:54 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:54 --> URI Class Initialized
INFO - 2020-11-02 04:15:54 --> Router Class Initialized
INFO - 2020-11-02 04:15:54 --> Output Class Initialized
INFO - 2020-11-02 04:15:54 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:54 --> Input Class Initialized
INFO - 2020-11-02 04:15:54 --> Language Class Initialized
INFO - 2020-11-02 04:15:54 --> Language Class Initialized
INFO - 2020-11-02 04:15:54 --> Config Class Initialized
INFO - 2020-11-02 04:15:54 --> Loader Class Initialized
INFO - 2020-11-02 04:15:54 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:54 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:54 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:54 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:54 --> Controller Class Initialized
DEBUG - 2020-11-02 04:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:15:54 --> Final output sent to browser
DEBUG - 2020-11-02 04:15:54 --> Total execution time: 0.3299
INFO - 2020-11-02 04:15:54 --> Config Class Initialized
INFO - 2020-11-02 04:15:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:54 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:54 --> URI Class Initialized
INFO - 2020-11-02 04:15:54 --> Router Class Initialized
INFO - 2020-11-02 04:15:54 --> Output Class Initialized
INFO - 2020-11-02 04:15:54 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:54 --> Input Class Initialized
INFO - 2020-11-02 04:15:54 --> Language Class Initialized
INFO - 2020-11-02 04:15:54 --> Language Class Initialized
INFO - 2020-11-02 04:15:54 --> Config Class Initialized
INFO - 2020-11-02 04:15:54 --> Loader Class Initialized
INFO - 2020-11-02 04:15:54 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:54 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:54 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:54 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:54 --> Controller Class Initialized
INFO - 2020-11-02 04:15:56 --> Config Class Initialized
INFO - 2020-11-02 04:15:56 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:15:56 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:15:56 --> Utf8 Class Initialized
INFO - 2020-11-02 04:15:56 --> URI Class Initialized
INFO - 2020-11-02 04:15:56 --> Router Class Initialized
INFO - 2020-11-02 04:15:56 --> Output Class Initialized
INFO - 2020-11-02 04:15:56 --> Security Class Initialized
DEBUG - 2020-11-02 04:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:15:56 --> Input Class Initialized
INFO - 2020-11-02 04:15:56 --> Language Class Initialized
INFO - 2020-11-02 04:15:56 --> Language Class Initialized
INFO - 2020-11-02 04:15:56 --> Config Class Initialized
INFO - 2020-11-02 04:15:56 --> Loader Class Initialized
INFO - 2020-11-02 04:15:56 --> Helper loaded: url_helper
INFO - 2020-11-02 04:15:56 --> Helper loaded: file_helper
INFO - 2020-11-02 04:15:56 --> Helper loaded: form_helper
INFO - 2020-11-02 04:15:56 --> Helper loaded: my_helper
INFO - 2020-11-02 04:15:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:15:56 --> Controller Class Initialized
INFO - 2020-11-02 04:15:56 --> Final output sent to browser
DEBUG - 2020-11-02 04:15:56 --> Total execution time: 0.2849
INFO - 2020-11-02 04:16:59 --> Config Class Initialized
INFO - 2020-11-02 04:16:59 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:16:59 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:16:59 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:00 --> URI Class Initialized
INFO - 2020-11-02 04:17:00 --> Router Class Initialized
INFO - 2020-11-02 04:17:00 --> Output Class Initialized
INFO - 2020-11-02 04:17:00 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:00 --> Input Class Initialized
INFO - 2020-11-02 04:17:00 --> Language Class Initialized
INFO - 2020-11-02 04:17:00 --> Language Class Initialized
INFO - 2020-11-02 04:17:00 --> Config Class Initialized
INFO - 2020-11-02 04:17:00 --> Loader Class Initialized
INFO - 2020-11-02 04:17:00 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:00 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:00 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:00 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:00 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:00 --> Controller Class Initialized
INFO - 2020-11-02 04:17:00 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:17:00 --> Config Class Initialized
INFO - 2020-11-02 04:17:00 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:00 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:00 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:00 --> URI Class Initialized
INFO - 2020-11-02 04:17:00 --> Router Class Initialized
INFO - 2020-11-02 04:17:00 --> Output Class Initialized
INFO - 2020-11-02 04:17:00 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:00 --> Input Class Initialized
INFO - 2020-11-02 04:17:00 --> Language Class Initialized
INFO - 2020-11-02 04:17:00 --> Language Class Initialized
INFO - 2020-11-02 04:17:00 --> Config Class Initialized
INFO - 2020-11-02 04:17:00 --> Loader Class Initialized
INFO - 2020-11-02 04:17:00 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:00 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:00 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:00 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:00 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:00 --> Controller Class Initialized
DEBUG - 2020-11-02 04:17:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 04:17:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:17:00 --> Final output sent to browser
DEBUG - 2020-11-02 04:17:00 --> Total execution time: 0.2884
INFO - 2020-11-02 04:17:08 --> Config Class Initialized
INFO - 2020-11-02 04:17:08 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:08 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:08 --> URI Class Initialized
INFO - 2020-11-02 04:17:08 --> Router Class Initialized
INFO - 2020-11-02 04:17:08 --> Output Class Initialized
INFO - 2020-11-02 04:17:08 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:08 --> Input Class Initialized
INFO - 2020-11-02 04:17:08 --> Language Class Initialized
INFO - 2020-11-02 04:17:08 --> Language Class Initialized
INFO - 2020-11-02 04:17:08 --> Config Class Initialized
INFO - 2020-11-02 04:17:08 --> Loader Class Initialized
INFO - 2020-11-02 04:17:08 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:08 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:08 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:09 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:09 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:09 --> Controller Class Initialized
INFO - 2020-11-02 04:17:09 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:17:09 --> Final output sent to browser
DEBUG - 2020-11-02 04:17:09 --> Total execution time: 0.3407
INFO - 2020-11-02 04:17:10 --> Config Class Initialized
INFO - 2020-11-02 04:17:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:10 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:10 --> URI Class Initialized
INFO - 2020-11-02 04:17:10 --> Router Class Initialized
INFO - 2020-11-02 04:17:10 --> Output Class Initialized
INFO - 2020-11-02 04:17:10 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:10 --> Input Class Initialized
INFO - 2020-11-02 04:17:10 --> Language Class Initialized
INFO - 2020-11-02 04:17:10 --> Language Class Initialized
INFO - 2020-11-02 04:17:10 --> Config Class Initialized
INFO - 2020-11-02 04:17:10 --> Loader Class Initialized
INFO - 2020-11-02 04:17:10 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:10 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:10 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:10 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:10 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:10 --> Controller Class Initialized
DEBUG - 2020-11-02 04:17:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 04:17:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:17:10 --> Final output sent to browser
DEBUG - 2020-11-02 04:17:10 --> Total execution time: 0.3553
INFO - 2020-11-02 04:17:12 --> Config Class Initialized
INFO - 2020-11-02 04:17:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:12 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:12 --> URI Class Initialized
INFO - 2020-11-02 04:17:12 --> Router Class Initialized
INFO - 2020-11-02 04:17:12 --> Output Class Initialized
INFO - 2020-11-02 04:17:12 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:12 --> Input Class Initialized
INFO - 2020-11-02 04:17:12 --> Language Class Initialized
INFO - 2020-11-02 04:17:12 --> Language Class Initialized
INFO - 2020-11-02 04:17:12 --> Config Class Initialized
INFO - 2020-11-02 04:17:12 --> Loader Class Initialized
INFO - 2020-11-02 04:17:12 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:12 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:12 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:12 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:12 --> Controller Class Initialized
DEBUG - 2020-11-02 04:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:17:12 --> Final output sent to browser
DEBUG - 2020-11-02 04:17:12 --> Total execution time: 0.3325
INFO - 2020-11-02 04:17:13 --> Config Class Initialized
INFO - 2020-11-02 04:17:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:13 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:13 --> URI Class Initialized
INFO - 2020-11-02 04:17:13 --> Router Class Initialized
INFO - 2020-11-02 04:17:13 --> Output Class Initialized
INFO - 2020-11-02 04:17:13 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:13 --> Input Class Initialized
INFO - 2020-11-02 04:17:13 --> Language Class Initialized
INFO - 2020-11-02 04:17:13 --> Language Class Initialized
INFO - 2020-11-02 04:17:13 --> Config Class Initialized
INFO - 2020-11-02 04:17:13 --> Loader Class Initialized
INFO - 2020-11-02 04:17:13 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:13 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:13 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:13 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:13 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:13 --> Controller Class Initialized
DEBUG - 2020-11-02 04:17:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:17:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:17:13 --> Final output sent to browser
DEBUG - 2020-11-02 04:17:13 --> Total execution time: 0.2991
INFO - 2020-11-02 04:17:13 --> Config Class Initialized
INFO - 2020-11-02 04:17:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:13 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:13 --> URI Class Initialized
INFO - 2020-11-02 04:17:13 --> Router Class Initialized
INFO - 2020-11-02 04:17:13 --> Output Class Initialized
INFO - 2020-11-02 04:17:13 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:13 --> Input Class Initialized
INFO - 2020-11-02 04:17:13 --> Language Class Initialized
INFO - 2020-11-02 04:17:13 --> Language Class Initialized
INFO - 2020-11-02 04:17:14 --> Config Class Initialized
INFO - 2020-11-02 04:17:14 --> Loader Class Initialized
INFO - 2020-11-02 04:17:14 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:14 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:14 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:14 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:14 --> Controller Class Initialized
INFO - 2020-11-02 04:17:30 --> Config Class Initialized
INFO - 2020-11-02 04:17:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:30 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:30 --> URI Class Initialized
INFO - 2020-11-02 04:17:30 --> Router Class Initialized
INFO - 2020-11-02 04:17:30 --> Output Class Initialized
INFO - 2020-11-02 04:17:30 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:30 --> Input Class Initialized
INFO - 2020-11-02 04:17:30 --> Language Class Initialized
INFO - 2020-11-02 04:17:30 --> Language Class Initialized
INFO - 2020-11-02 04:17:30 --> Config Class Initialized
INFO - 2020-11-02 04:17:30 --> Loader Class Initialized
INFO - 2020-11-02 04:17:30 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:30 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:30 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:30 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:30 --> Controller Class Initialized
INFO - 2020-11-02 04:17:30 --> Final output sent to browser
DEBUG - 2020-11-02 04:17:30 --> Total execution time: 0.2705
INFO - 2020-11-02 04:17:55 --> Config Class Initialized
INFO - 2020-11-02 04:17:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:55 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:55 --> URI Class Initialized
INFO - 2020-11-02 04:17:55 --> Router Class Initialized
INFO - 2020-11-02 04:17:55 --> Output Class Initialized
INFO - 2020-11-02 04:17:55 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:55 --> Input Class Initialized
INFO - 2020-11-02 04:17:55 --> Language Class Initialized
INFO - 2020-11-02 04:17:55 --> Language Class Initialized
INFO - 2020-11-02 04:17:55 --> Config Class Initialized
INFO - 2020-11-02 04:17:55 --> Loader Class Initialized
INFO - 2020-11-02 04:17:55 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:55 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:55 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:55 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:55 --> Controller Class Initialized
INFO - 2020-11-02 04:17:55 --> Final output sent to browser
DEBUG - 2020-11-02 04:17:55 --> Total execution time: 0.3697
INFO - 2020-11-02 04:17:55 --> Config Class Initialized
INFO - 2020-11-02 04:17:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:56 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:56 --> URI Class Initialized
INFO - 2020-11-02 04:17:56 --> Router Class Initialized
INFO - 2020-11-02 04:17:56 --> Output Class Initialized
INFO - 2020-11-02 04:17:56 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:56 --> Input Class Initialized
INFO - 2020-11-02 04:17:56 --> Language Class Initialized
INFO - 2020-11-02 04:17:56 --> Language Class Initialized
INFO - 2020-11-02 04:17:56 --> Config Class Initialized
INFO - 2020-11-02 04:17:56 --> Loader Class Initialized
INFO - 2020-11-02 04:17:56 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:56 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:56 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:56 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:56 --> Controller Class Initialized
INFO - 2020-11-02 04:17:58 --> Config Class Initialized
INFO - 2020-11-02 04:17:58 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:17:58 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:17:58 --> Utf8 Class Initialized
INFO - 2020-11-02 04:17:58 --> URI Class Initialized
INFO - 2020-11-02 04:17:58 --> Router Class Initialized
INFO - 2020-11-02 04:17:58 --> Output Class Initialized
INFO - 2020-11-02 04:17:58 --> Security Class Initialized
DEBUG - 2020-11-02 04:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:17:58 --> Input Class Initialized
INFO - 2020-11-02 04:17:58 --> Language Class Initialized
INFO - 2020-11-02 04:17:58 --> Language Class Initialized
INFO - 2020-11-02 04:17:58 --> Config Class Initialized
INFO - 2020-11-02 04:17:58 --> Loader Class Initialized
INFO - 2020-11-02 04:17:58 --> Helper loaded: url_helper
INFO - 2020-11-02 04:17:58 --> Helper loaded: file_helper
INFO - 2020-11-02 04:17:58 --> Helper loaded: form_helper
INFO - 2020-11-02 04:17:58 --> Helper loaded: my_helper
INFO - 2020-11-02 04:17:58 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:17:58 --> Controller Class Initialized
INFO - 2020-11-02 04:17:58 --> Final output sent to browser
DEBUG - 2020-11-02 04:17:58 --> Total execution time: 0.2857
INFO - 2020-11-02 04:18:05 --> Config Class Initialized
INFO - 2020-11-02 04:18:05 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:05 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:05 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:05 --> URI Class Initialized
INFO - 2020-11-02 04:18:05 --> Router Class Initialized
INFO - 2020-11-02 04:18:05 --> Output Class Initialized
INFO - 2020-11-02 04:18:05 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:05 --> Input Class Initialized
INFO - 2020-11-02 04:18:05 --> Language Class Initialized
INFO - 2020-11-02 04:18:05 --> Language Class Initialized
INFO - 2020-11-02 04:18:05 --> Config Class Initialized
INFO - 2020-11-02 04:18:05 --> Loader Class Initialized
INFO - 2020-11-02 04:18:05 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:05 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:05 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:05 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:05 --> Controller Class Initialized
INFO - 2020-11-02 04:18:05 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:05 --> Total execution time: 0.3803
INFO - 2020-11-02 04:18:07 --> Config Class Initialized
INFO - 2020-11-02 04:18:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:07 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:07 --> URI Class Initialized
INFO - 2020-11-02 04:18:07 --> Router Class Initialized
INFO - 2020-11-02 04:18:07 --> Output Class Initialized
INFO - 2020-11-02 04:18:07 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:07 --> Input Class Initialized
INFO - 2020-11-02 04:18:07 --> Language Class Initialized
INFO - 2020-11-02 04:18:07 --> Language Class Initialized
INFO - 2020-11-02 04:18:07 --> Config Class Initialized
INFO - 2020-11-02 04:18:07 --> Loader Class Initialized
INFO - 2020-11-02 04:18:07 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:07 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:07 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:07 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:07 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:07 --> Controller Class Initialized
INFO - 2020-11-02 04:18:07 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:07 --> Total execution time: 0.2932
INFO - 2020-11-02 04:18:15 --> Config Class Initialized
INFO - 2020-11-02 04:18:15 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:15 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:15 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:15 --> URI Class Initialized
INFO - 2020-11-02 04:18:15 --> Router Class Initialized
INFO - 2020-11-02 04:18:15 --> Output Class Initialized
INFO - 2020-11-02 04:18:15 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:15 --> Input Class Initialized
INFO - 2020-11-02 04:18:15 --> Language Class Initialized
INFO - 2020-11-02 04:18:15 --> Language Class Initialized
INFO - 2020-11-02 04:18:15 --> Config Class Initialized
INFO - 2020-11-02 04:18:15 --> Loader Class Initialized
INFO - 2020-11-02 04:18:15 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:15 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:15 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:15 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:15 --> Controller Class Initialized
INFO - 2020-11-02 04:18:15 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:15 --> Total execution time: 0.3542
INFO - 2020-11-02 04:18:16 --> Config Class Initialized
INFO - 2020-11-02 04:18:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:16 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:16 --> URI Class Initialized
INFO - 2020-11-02 04:18:16 --> Router Class Initialized
INFO - 2020-11-02 04:18:16 --> Output Class Initialized
INFO - 2020-11-02 04:18:16 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:16 --> Input Class Initialized
INFO - 2020-11-02 04:18:16 --> Language Class Initialized
INFO - 2020-11-02 04:18:16 --> Language Class Initialized
INFO - 2020-11-02 04:18:16 --> Config Class Initialized
INFO - 2020-11-02 04:18:16 --> Loader Class Initialized
INFO - 2020-11-02 04:18:16 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:16 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:16 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:16 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:16 --> Controller Class Initialized
INFO - 2020-11-02 04:18:16 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:16 --> Total execution time: 0.2792
INFO - 2020-11-02 04:18:24 --> Config Class Initialized
INFO - 2020-11-02 04:18:24 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:24 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:24 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:25 --> URI Class Initialized
INFO - 2020-11-02 04:18:25 --> Router Class Initialized
INFO - 2020-11-02 04:18:25 --> Output Class Initialized
INFO - 2020-11-02 04:18:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:25 --> Input Class Initialized
INFO - 2020-11-02 04:18:25 --> Language Class Initialized
INFO - 2020-11-02 04:18:25 --> Language Class Initialized
INFO - 2020-11-02 04:18:25 --> Config Class Initialized
INFO - 2020-11-02 04:18:25 --> Loader Class Initialized
INFO - 2020-11-02 04:18:25 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:25 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:25 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:25 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:25 --> Controller Class Initialized
INFO - 2020-11-02 04:18:25 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:25 --> Total execution time: 0.3810
INFO - 2020-11-02 04:18:27 --> Config Class Initialized
INFO - 2020-11-02 04:18:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:27 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:27 --> URI Class Initialized
INFO - 2020-11-02 04:18:27 --> Router Class Initialized
INFO - 2020-11-02 04:18:27 --> Output Class Initialized
INFO - 2020-11-02 04:18:27 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:27 --> Input Class Initialized
INFO - 2020-11-02 04:18:27 --> Language Class Initialized
INFO - 2020-11-02 04:18:27 --> Language Class Initialized
INFO - 2020-11-02 04:18:27 --> Config Class Initialized
INFO - 2020-11-02 04:18:27 --> Loader Class Initialized
INFO - 2020-11-02 04:18:27 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:27 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:27 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:27 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:27 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:27 --> Controller Class Initialized
INFO - 2020-11-02 04:18:27 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:27 --> Total execution time: 0.2627
INFO - 2020-11-02 04:18:36 --> Config Class Initialized
INFO - 2020-11-02 04:18:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:36 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:36 --> URI Class Initialized
INFO - 2020-11-02 04:18:36 --> Router Class Initialized
INFO - 2020-11-02 04:18:36 --> Output Class Initialized
INFO - 2020-11-02 04:18:36 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:36 --> Input Class Initialized
INFO - 2020-11-02 04:18:36 --> Language Class Initialized
INFO - 2020-11-02 04:18:36 --> Language Class Initialized
INFO - 2020-11-02 04:18:36 --> Config Class Initialized
INFO - 2020-11-02 04:18:36 --> Loader Class Initialized
INFO - 2020-11-02 04:18:36 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:36 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:36 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:36 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:36 --> Controller Class Initialized
DEBUG - 2020-11-02 04:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:18:36 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:36 --> Total execution time: 0.3457
INFO - 2020-11-02 04:18:37 --> Config Class Initialized
INFO - 2020-11-02 04:18:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:37 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:37 --> URI Class Initialized
INFO - 2020-11-02 04:18:37 --> Router Class Initialized
INFO - 2020-11-02 04:18:37 --> Output Class Initialized
INFO - 2020-11-02 04:18:38 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:38 --> Input Class Initialized
INFO - 2020-11-02 04:18:38 --> Language Class Initialized
INFO - 2020-11-02 04:18:38 --> Language Class Initialized
INFO - 2020-11-02 04:18:38 --> Config Class Initialized
INFO - 2020-11-02 04:18:38 --> Loader Class Initialized
INFO - 2020-11-02 04:18:38 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:38 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:38 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:38 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:38 --> Controller Class Initialized
DEBUG - 2020-11-02 04:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:18:38 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:38 --> Total execution time: 0.3059
INFO - 2020-11-02 04:18:39 --> Config Class Initialized
INFO - 2020-11-02 04:18:39 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:39 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:39 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:39 --> URI Class Initialized
INFO - 2020-11-02 04:18:39 --> Router Class Initialized
INFO - 2020-11-02 04:18:39 --> Output Class Initialized
INFO - 2020-11-02 04:18:39 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:39 --> Input Class Initialized
INFO - 2020-11-02 04:18:39 --> Language Class Initialized
INFO - 2020-11-02 04:18:39 --> Language Class Initialized
INFO - 2020-11-02 04:18:39 --> Config Class Initialized
INFO - 2020-11-02 04:18:39 --> Loader Class Initialized
INFO - 2020-11-02 04:18:39 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:39 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:39 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:39 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:39 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:39 --> Controller Class Initialized
INFO - 2020-11-02 04:18:39 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:39 --> Total execution time: 0.2976
INFO - 2020-11-02 04:18:49 --> Config Class Initialized
INFO - 2020-11-02 04:18:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:49 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:49 --> URI Class Initialized
INFO - 2020-11-02 04:18:49 --> Router Class Initialized
INFO - 2020-11-02 04:18:49 --> Output Class Initialized
INFO - 2020-11-02 04:18:49 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:49 --> Input Class Initialized
INFO - 2020-11-02 04:18:49 --> Language Class Initialized
INFO - 2020-11-02 04:18:49 --> Language Class Initialized
INFO - 2020-11-02 04:18:49 --> Config Class Initialized
INFO - 2020-11-02 04:18:49 --> Loader Class Initialized
INFO - 2020-11-02 04:18:49 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:49 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:49 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:49 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:49 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:49 --> Controller Class Initialized
INFO - 2020-11-02 04:18:49 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:49 --> Total execution time: 0.3308
INFO - 2020-11-02 04:18:50 --> Config Class Initialized
INFO - 2020-11-02 04:18:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:50 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:50 --> URI Class Initialized
INFO - 2020-11-02 04:18:50 --> Router Class Initialized
INFO - 2020-11-02 04:18:50 --> Output Class Initialized
INFO - 2020-11-02 04:18:50 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:50 --> Input Class Initialized
INFO - 2020-11-02 04:18:50 --> Language Class Initialized
INFO - 2020-11-02 04:18:50 --> Language Class Initialized
INFO - 2020-11-02 04:18:50 --> Config Class Initialized
INFO - 2020-11-02 04:18:50 --> Loader Class Initialized
INFO - 2020-11-02 04:18:50 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:50 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:50 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:50 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:50 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:50 --> Controller Class Initialized
DEBUG - 2020-11-02 04:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:18:50 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:50 --> Total execution time: 0.3284
INFO - 2020-11-02 04:18:51 --> Config Class Initialized
INFO - 2020-11-02 04:18:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:51 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:51 --> URI Class Initialized
INFO - 2020-11-02 04:18:51 --> Router Class Initialized
INFO - 2020-11-02 04:18:51 --> Output Class Initialized
INFO - 2020-11-02 04:18:51 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:51 --> Input Class Initialized
INFO - 2020-11-02 04:18:51 --> Language Class Initialized
INFO - 2020-11-02 04:18:51 --> Language Class Initialized
INFO - 2020-11-02 04:18:51 --> Config Class Initialized
INFO - 2020-11-02 04:18:51 --> Loader Class Initialized
INFO - 2020-11-02 04:18:51 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:51 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:51 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:51 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:51 --> Controller Class Initialized
INFO - 2020-11-02 04:18:51 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:51 --> Total execution time: 0.2895
INFO - 2020-11-02 04:18:58 --> Config Class Initialized
INFO - 2020-11-02 04:18:58 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:18:58 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:18:58 --> Utf8 Class Initialized
INFO - 2020-11-02 04:18:58 --> URI Class Initialized
INFO - 2020-11-02 04:18:58 --> Router Class Initialized
INFO - 2020-11-02 04:18:58 --> Output Class Initialized
INFO - 2020-11-02 04:18:58 --> Security Class Initialized
DEBUG - 2020-11-02 04:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:18:59 --> Input Class Initialized
INFO - 2020-11-02 04:18:59 --> Language Class Initialized
INFO - 2020-11-02 04:18:59 --> Language Class Initialized
INFO - 2020-11-02 04:18:59 --> Config Class Initialized
INFO - 2020-11-02 04:18:59 --> Loader Class Initialized
INFO - 2020-11-02 04:18:59 --> Helper loaded: url_helper
INFO - 2020-11-02 04:18:59 --> Helper loaded: file_helper
INFO - 2020-11-02 04:18:59 --> Helper loaded: form_helper
INFO - 2020-11-02 04:18:59 --> Helper loaded: my_helper
INFO - 2020-11-02 04:18:59 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:18:59 --> Controller Class Initialized
INFO - 2020-11-02 04:18:59 --> Final output sent to browser
DEBUG - 2020-11-02 04:18:59 --> Total execution time: 0.3602
INFO - 2020-11-02 04:19:01 --> Config Class Initialized
INFO - 2020-11-02 04:19:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:19:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:19:01 --> Utf8 Class Initialized
INFO - 2020-11-02 04:19:01 --> URI Class Initialized
INFO - 2020-11-02 04:19:01 --> Router Class Initialized
INFO - 2020-11-02 04:19:01 --> Output Class Initialized
INFO - 2020-11-02 04:19:01 --> Security Class Initialized
DEBUG - 2020-11-02 04:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:19:02 --> Input Class Initialized
INFO - 2020-11-02 04:19:02 --> Language Class Initialized
INFO - 2020-11-02 04:19:02 --> Language Class Initialized
INFO - 2020-11-02 04:19:02 --> Config Class Initialized
INFO - 2020-11-02 04:19:02 --> Loader Class Initialized
INFO - 2020-11-02 04:19:02 --> Helper loaded: url_helper
INFO - 2020-11-02 04:19:02 --> Helper loaded: file_helper
INFO - 2020-11-02 04:19:02 --> Helper loaded: form_helper
INFO - 2020-11-02 04:19:02 --> Helper loaded: my_helper
INFO - 2020-11-02 04:19:02 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:19:02 --> Controller Class Initialized
DEBUG - 2020-11-02 04:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:19:02 --> Final output sent to browser
DEBUG - 2020-11-02 04:19:02 --> Total execution time: 0.3182
INFO - 2020-11-02 04:19:04 --> Config Class Initialized
INFO - 2020-11-02 04:19:04 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:19:04 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:19:04 --> Utf8 Class Initialized
INFO - 2020-11-02 04:19:04 --> URI Class Initialized
INFO - 2020-11-02 04:19:04 --> Router Class Initialized
INFO - 2020-11-02 04:19:04 --> Output Class Initialized
INFO - 2020-11-02 04:19:04 --> Security Class Initialized
DEBUG - 2020-11-02 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:19:04 --> Input Class Initialized
INFO - 2020-11-02 04:19:04 --> Language Class Initialized
INFO - 2020-11-02 04:19:04 --> Language Class Initialized
INFO - 2020-11-02 04:19:04 --> Config Class Initialized
INFO - 2020-11-02 04:19:04 --> Loader Class Initialized
INFO - 2020-11-02 04:19:04 --> Helper loaded: url_helper
INFO - 2020-11-02 04:19:04 --> Helper loaded: file_helper
INFO - 2020-11-02 04:19:04 --> Helper loaded: form_helper
INFO - 2020-11-02 04:19:04 --> Helper loaded: my_helper
INFO - 2020-11-02 04:19:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:19:04 --> Controller Class Initialized
INFO - 2020-11-02 04:19:04 --> Final output sent to browser
DEBUG - 2020-11-02 04:19:04 --> Total execution time: 0.2835
INFO - 2020-11-02 04:19:11 --> Config Class Initialized
INFO - 2020-11-02 04:19:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:19:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:19:11 --> Utf8 Class Initialized
INFO - 2020-11-02 04:19:11 --> URI Class Initialized
INFO - 2020-11-02 04:19:11 --> Router Class Initialized
INFO - 2020-11-02 04:19:11 --> Output Class Initialized
INFO - 2020-11-02 04:19:11 --> Security Class Initialized
DEBUG - 2020-11-02 04:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:19:11 --> Input Class Initialized
INFO - 2020-11-02 04:19:11 --> Language Class Initialized
INFO - 2020-11-02 04:19:11 --> Language Class Initialized
INFO - 2020-11-02 04:19:11 --> Config Class Initialized
INFO - 2020-11-02 04:19:11 --> Loader Class Initialized
INFO - 2020-11-02 04:19:11 --> Helper loaded: url_helper
INFO - 2020-11-02 04:19:11 --> Helper loaded: file_helper
INFO - 2020-11-02 04:19:11 --> Helper loaded: form_helper
INFO - 2020-11-02 04:19:11 --> Helper loaded: my_helper
INFO - 2020-11-02 04:19:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:19:11 --> Controller Class Initialized
DEBUG - 2020-11-02 04:19:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:19:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:19:11 --> Final output sent to browser
DEBUG - 2020-11-02 04:19:11 --> Total execution time: 0.3384
INFO - 2020-11-02 04:19:12 --> Config Class Initialized
INFO - 2020-11-02 04:19:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:19:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:19:12 --> Utf8 Class Initialized
INFO - 2020-11-02 04:19:12 --> URI Class Initialized
INFO - 2020-11-02 04:19:12 --> Router Class Initialized
INFO - 2020-11-02 04:19:12 --> Output Class Initialized
INFO - 2020-11-02 04:19:12 --> Security Class Initialized
DEBUG - 2020-11-02 04:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:19:12 --> Input Class Initialized
INFO - 2020-11-02 04:19:12 --> Language Class Initialized
INFO - 2020-11-02 04:19:12 --> Language Class Initialized
INFO - 2020-11-02 04:19:12 --> Config Class Initialized
INFO - 2020-11-02 04:19:12 --> Loader Class Initialized
INFO - 2020-11-02 04:19:12 --> Helper loaded: url_helper
INFO - 2020-11-02 04:19:12 --> Helper loaded: file_helper
INFO - 2020-11-02 04:19:12 --> Helper loaded: form_helper
INFO - 2020-11-02 04:19:12 --> Helper loaded: my_helper
INFO - 2020-11-02 04:19:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:19:12 --> Controller Class Initialized
DEBUG - 2020-11-02 04:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:19:12 --> Final output sent to browser
DEBUG - 2020-11-02 04:19:12 --> Total execution time: 0.3117
INFO - 2020-11-02 04:19:12 --> Config Class Initialized
INFO - 2020-11-02 04:19:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:19:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:19:12 --> Utf8 Class Initialized
INFO - 2020-11-02 04:19:12 --> URI Class Initialized
INFO - 2020-11-02 04:19:12 --> Router Class Initialized
INFO - 2020-11-02 04:19:12 --> Output Class Initialized
INFO - 2020-11-02 04:19:12 --> Security Class Initialized
DEBUG - 2020-11-02 04:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:19:12 --> Input Class Initialized
INFO - 2020-11-02 04:19:12 --> Language Class Initialized
INFO - 2020-11-02 04:19:12 --> Language Class Initialized
INFO - 2020-11-02 04:19:12 --> Config Class Initialized
INFO - 2020-11-02 04:19:12 --> Loader Class Initialized
INFO - 2020-11-02 04:19:12 --> Helper loaded: url_helper
INFO - 2020-11-02 04:19:12 --> Helper loaded: file_helper
INFO - 2020-11-02 04:19:12 --> Helper loaded: form_helper
INFO - 2020-11-02 04:19:12 --> Helper loaded: my_helper
INFO - 2020-11-02 04:19:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:19:13 --> Controller Class Initialized
INFO - 2020-11-02 04:19:13 --> Config Class Initialized
INFO - 2020-11-02 04:19:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:19:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:19:14 --> Utf8 Class Initialized
INFO - 2020-11-02 04:19:14 --> URI Class Initialized
INFO - 2020-11-02 04:19:14 --> Router Class Initialized
INFO - 2020-11-02 04:19:14 --> Output Class Initialized
INFO - 2020-11-02 04:19:14 --> Security Class Initialized
DEBUG - 2020-11-02 04:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:19:14 --> Input Class Initialized
INFO - 2020-11-02 04:19:14 --> Language Class Initialized
INFO - 2020-11-02 04:19:14 --> Language Class Initialized
INFO - 2020-11-02 04:19:14 --> Config Class Initialized
INFO - 2020-11-02 04:19:14 --> Loader Class Initialized
INFO - 2020-11-02 04:19:14 --> Helper loaded: url_helper
INFO - 2020-11-02 04:19:14 --> Helper loaded: file_helper
INFO - 2020-11-02 04:19:14 --> Helper loaded: form_helper
INFO - 2020-11-02 04:19:14 --> Helper loaded: my_helper
INFO - 2020-11-02 04:19:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:19:14 --> Controller Class Initialized
INFO - 2020-11-02 04:19:14 --> Final output sent to browser
DEBUG - 2020-11-02 04:19:14 --> Total execution time: 0.2789
INFO - 2020-11-02 04:19:15 --> Config Class Initialized
INFO - 2020-11-02 04:19:15 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:19:15 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:19:15 --> Utf8 Class Initialized
INFO - 2020-11-02 04:19:15 --> URI Class Initialized
INFO - 2020-11-02 04:19:15 --> Router Class Initialized
INFO - 2020-11-02 04:19:15 --> Output Class Initialized
INFO - 2020-11-02 04:19:15 --> Security Class Initialized
DEBUG - 2020-11-02 04:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:19:15 --> Input Class Initialized
INFO - 2020-11-02 04:19:15 --> Language Class Initialized
INFO - 2020-11-02 04:19:15 --> Language Class Initialized
INFO - 2020-11-02 04:19:15 --> Config Class Initialized
INFO - 2020-11-02 04:19:15 --> Loader Class Initialized
INFO - 2020-11-02 04:19:15 --> Helper loaded: url_helper
INFO - 2020-11-02 04:19:15 --> Helper loaded: file_helper
INFO - 2020-11-02 04:19:15 --> Helper loaded: form_helper
INFO - 2020-11-02 04:19:15 --> Helper loaded: my_helper
INFO - 2020-11-02 04:19:15 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:19:15 --> Controller Class Initialized
INFO - 2020-11-02 04:19:15 --> Final output sent to browser
DEBUG - 2020-11-02 04:19:15 --> Total execution time: 0.2705
INFO - 2020-11-02 04:20:51 --> Config Class Initialized
INFO - 2020-11-02 04:20:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:20:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:20:51 --> Utf8 Class Initialized
INFO - 2020-11-02 04:20:51 --> URI Class Initialized
INFO - 2020-11-02 04:20:51 --> Router Class Initialized
INFO - 2020-11-02 04:20:51 --> Output Class Initialized
INFO - 2020-11-02 04:20:51 --> Security Class Initialized
DEBUG - 2020-11-02 04:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:20:51 --> Input Class Initialized
INFO - 2020-11-02 04:20:51 --> Language Class Initialized
INFO - 2020-11-02 04:20:51 --> Language Class Initialized
INFO - 2020-11-02 04:20:51 --> Config Class Initialized
INFO - 2020-11-02 04:20:51 --> Loader Class Initialized
INFO - 2020-11-02 04:20:51 --> Helper loaded: url_helper
INFO - 2020-11-02 04:20:52 --> Helper loaded: file_helper
INFO - 2020-11-02 04:20:52 --> Helper loaded: form_helper
INFO - 2020-11-02 04:20:52 --> Helper loaded: my_helper
INFO - 2020-11-02 04:20:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:20:52 --> Controller Class Initialized
DEBUG - 2020-11-02 04:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:20:52 --> Final output sent to browser
DEBUG - 2020-11-02 04:20:52 --> Total execution time: 0.3530
INFO - 2020-11-02 04:20:52 --> Config Class Initialized
INFO - 2020-11-02 04:20:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:20:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:20:52 --> Utf8 Class Initialized
INFO - 2020-11-02 04:20:52 --> URI Class Initialized
INFO - 2020-11-02 04:20:52 --> Router Class Initialized
INFO - 2020-11-02 04:20:52 --> Output Class Initialized
INFO - 2020-11-02 04:20:52 --> Security Class Initialized
DEBUG - 2020-11-02 04:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:20:52 --> Input Class Initialized
INFO - 2020-11-02 04:20:52 --> Language Class Initialized
INFO - 2020-11-02 04:20:52 --> Language Class Initialized
INFO - 2020-11-02 04:20:52 --> Config Class Initialized
INFO - 2020-11-02 04:20:52 --> Loader Class Initialized
INFO - 2020-11-02 04:20:52 --> Helper loaded: url_helper
INFO - 2020-11-02 04:20:52 --> Helper loaded: file_helper
INFO - 2020-11-02 04:20:52 --> Helper loaded: form_helper
INFO - 2020-11-02 04:20:52 --> Helper loaded: my_helper
INFO - 2020-11-02 04:20:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:20:52 --> Controller Class Initialized
INFO - 2020-11-02 04:20:53 --> Config Class Initialized
INFO - 2020-11-02 04:20:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:20:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:20:53 --> Utf8 Class Initialized
INFO - 2020-11-02 04:20:53 --> URI Class Initialized
INFO - 2020-11-02 04:20:53 --> Router Class Initialized
INFO - 2020-11-02 04:20:53 --> Output Class Initialized
INFO - 2020-11-02 04:20:53 --> Security Class Initialized
DEBUG - 2020-11-02 04:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:20:53 --> Input Class Initialized
INFO - 2020-11-02 04:20:53 --> Language Class Initialized
INFO - 2020-11-02 04:20:53 --> Language Class Initialized
INFO - 2020-11-02 04:20:54 --> Config Class Initialized
INFO - 2020-11-02 04:20:54 --> Loader Class Initialized
INFO - 2020-11-02 04:20:54 --> Helper loaded: url_helper
INFO - 2020-11-02 04:20:54 --> Helper loaded: file_helper
INFO - 2020-11-02 04:20:54 --> Helper loaded: form_helper
INFO - 2020-11-02 04:20:54 --> Helper loaded: my_helper
INFO - 2020-11-02 04:20:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:20:54 --> Controller Class Initialized
INFO - 2020-11-02 04:20:54 --> Final output sent to browser
DEBUG - 2020-11-02 04:20:54 --> Total execution time: 0.2879
INFO - 2020-11-02 04:20:55 --> Config Class Initialized
INFO - 2020-11-02 04:20:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:20:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:20:55 --> Utf8 Class Initialized
INFO - 2020-11-02 04:20:55 --> URI Class Initialized
INFO - 2020-11-02 04:20:55 --> Router Class Initialized
INFO - 2020-11-02 04:20:55 --> Output Class Initialized
INFO - 2020-11-02 04:20:55 --> Security Class Initialized
DEBUG - 2020-11-02 04:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:20:55 --> Input Class Initialized
INFO - 2020-11-02 04:20:55 --> Language Class Initialized
INFO - 2020-11-02 04:20:55 --> Language Class Initialized
INFO - 2020-11-02 04:20:55 --> Config Class Initialized
INFO - 2020-11-02 04:20:55 --> Loader Class Initialized
INFO - 2020-11-02 04:20:55 --> Helper loaded: url_helper
INFO - 2020-11-02 04:20:55 --> Helper loaded: file_helper
INFO - 2020-11-02 04:20:55 --> Helper loaded: form_helper
INFO - 2020-11-02 04:20:55 --> Helper loaded: my_helper
INFO - 2020-11-02 04:20:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:20:55 --> Controller Class Initialized
INFO - 2020-11-02 04:20:55 --> Final output sent to browser
DEBUG - 2020-11-02 04:20:55 --> Total execution time: 0.3093
INFO - 2020-11-02 04:20:56 --> Config Class Initialized
INFO - 2020-11-02 04:20:56 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:20:56 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:20:56 --> Utf8 Class Initialized
INFO - 2020-11-02 04:20:56 --> URI Class Initialized
INFO - 2020-11-02 04:20:56 --> Router Class Initialized
INFO - 2020-11-02 04:20:56 --> Output Class Initialized
INFO - 2020-11-02 04:20:56 --> Security Class Initialized
DEBUG - 2020-11-02 04:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:20:56 --> Input Class Initialized
INFO - 2020-11-02 04:20:56 --> Language Class Initialized
INFO - 2020-11-02 04:20:56 --> Language Class Initialized
INFO - 2020-11-02 04:20:56 --> Config Class Initialized
INFO - 2020-11-02 04:20:56 --> Loader Class Initialized
INFO - 2020-11-02 04:20:56 --> Helper loaded: url_helper
INFO - 2020-11-02 04:20:56 --> Helper loaded: file_helper
INFO - 2020-11-02 04:20:56 --> Helper loaded: form_helper
INFO - 2020-11-02 04:20:56 --> Helper loaded: my_helper
INFO - 2020-11-02 04:20:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:20:56 --> Controller Class Initialized
INFO - 2020-11-02 04:20:56 --> Final output sent to browser
DEBUG - 2020-11-02 04:20:56 --> Total execution time: 0.2848
INFO - 2020-11-02 04:21:23 --> Config Class Initialized
INFO - 2020-11-02 04:21:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:23 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:23 --> URI Class Initialized
INFO - 2020-11-02 04:21:23 --> Router Class Initialized
INFO - 2020-11-02 04:21:23 --> Output Class Initialized
INFO - 2020-11-02 04:21:23 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:23 --> Input Class Initialized
INFO - 2020-11-02 04:21:23 --> Language Class Initialized
INFO - 2020-11-02 04:21:23 --> Language Class Initialized
INFO - 2020-11-02 04:21:23 --> Config Class Initialized
INFO - 2020-11-02 04:21:23 --> Loader Class Initialized
INFO - 2020-11-02 04:21:23 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:23 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:23 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:23 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:23 --> Controller Class Initialized
DEBUG - 2020-11-02 04:21:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:21:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:21:24 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:24 --> Total execution time: 0.3438
INFO - 2020-11-02 04:21:25 --> Config Class Initialized
INFO - 2020-11-02 04:21:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:25 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:25 --> URI Class Initialized
INFO - 2020-11-02 04:21:25 --> Router Class Initialized
INFO - 2020-11-02 04:21:25 --> Output Class Initialized
INFO - 2020-11-02 04:21:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:25 --> Input Class Initialized
INFO - 2020-11-02 04:21:25 --> Language Class Initialized
INFO - 2020-11-02 04:21:25 --> Language Class Initialized
INFO - 2020-11-02 04:21:25 --> Config Class Initialized
INFO - 2020-11-02 04:21:25 --> Loader Class Initialized
INFO - 2020-11-02 04:21:25 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:25 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:25 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:25 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:25 --> Controller Class Initialized
DEBUG - 2020-11-02 04:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:21:25 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:25 --> Total execution time: 0.3115
INFO - 2020-11-02 04:21:26 --> Config Class Initialized
INFO - 2020-11-02 04:21:26 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:26 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:26 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:26 --> URI Class Initialized
INFO - 2020-11-02 04:21:26 --> Router Class Initialized
INFO - 2020-11-02 04:21:26 --> Output Class Initialized
INFO - 2020-11-02 04:21:26 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:26 --> Input Class Initialized
INFO - 2020-11-02 04:21:26 --> Language Class Initialized
INFO - 2020-11-02 04:21:27 --> Language Class Initialized
INFO - 2020-11-02 04:21:27 --> Config Class Initialized
INFO - 2020-11-02 04:21:27 --> Loader Class Initialized
INFO - 2020-11-02 04:21:27 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:27 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:27 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:27 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:27 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:27 --> Controller Class Initialized
INFO - 2020-11-02 04:21:27 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:27 --> Total execution time: 0.2999
INFO - 2020-11-02 04:21:29 --> Config Class Initialized
INFO - 2020-11-02 04:21:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:29 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:29 --> URI Class Initialized
INFO - 2020-11-02 04:21:29 --> Router Class Initialized
INFO - 2020-11-02 04:21:29 --> Output Class Initialized
INFO - 2020-11-02 04:21:29 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:29 --> Input Class Initialized
INFO - 2020-11-02 04:21:29 --> Language Class Initialized
INFO - 2020-11-02 04:21:29 --> Language Class Initialized
INFO - 2020-11-02 04:21:29 --> Config Class Initialized
INFO - 2020-11-02 04:21:29 --> Loader Class Initialized
INFO - 2020-11-02 04:21:29 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:29 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:29 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:29 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:29 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:29 --> Controller Class Initialized
INFO - 2020-11-02 04:21:29 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:21:29 --> Config Class Initialized
INFO - 2020-11-02 04:21:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:29 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:29 --> URI Class Initialized
INFO - 2020-11-02 04:21:29 --> Router Class Initialized
INFO - 2020-11-02 04:21:29 --> Output Class Initialized
INFO - 2020-11-02 04:21:29 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:29 --> Input Class Initialized
INFO - 2020-11-02 04:21:29 --> Language Class Initialized
INFO - 2020-11-02 04:21:29 --> Language Class Initialized
INFO - 2020-11-02 04:21:29 --> Config Class Initialized
INFO - 2020-11-02 04:21:29 --> Loader Class Initialized
INFO - 2020-11-02 04:21:29 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:29 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:29 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:29 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:29 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:30 --> Controller Class Initialized
DEBUG - 2020-11-02 04:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 04:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:21:30 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:30 --> Total execution time: 0.3101
INFO - 2020-11-02 04:21:37 --> Config Class Initialized
INFO - 2020-11-02 04:21:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:37 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:37 --> URI Class Initialized
INFO - 2020-11-02 04:21:37 --> Router Class Initialized
INFO - 2020-11-02 04:21:37 --> Output Class Initialized
INFO - 2020-11-02 04:21:37 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:37 --> Input Class Initialized
INFO - 2020-11-02 04:21:37 --> Language Class Initialized
INFO - 2020-11-02 04:21:37 --> Language Class Initialized
INFO - 2020-11-02 04:21:37 --> Config Class Initialized
INFO - 2020-11-02 04:21:37 --> Loader Class Initialized
INFO - 2020-11-02 04:21:37 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:37 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:37 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:37 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:37 --> Controller Class Initialized
INFO - 2020-11-02 04:21:37 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:21:37 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:37 --> Total execution time: 0.3367
INFO - 2020-11-02 04:21:39 --> Config Class Initialized
INFO - 2020-11-02 04:21:39 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:39 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:39 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:39 --> URI Class Initialized
INFO - 2020-11-02 04:21:39 --> Router Class Initialized
INFO - 2020-11-02 04:21:39 --> Output Class Initialized
INFO - 2020-11-02 04:21:39 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:39 --> Input Class Initialized
INFO - 2020-11-02 04:21:39 --> Language Class Initialized
INFO - 2020-11-02 04:21:39 --> Language Class Initialized
INFO - 2020-11-02 04:21:39 --> Config Class Initialized
INFO - 2020-11-02 04:21:39 --> Loader Class Initialized
INFO - 2020-11-02 04:21:39 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:39 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:39 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:39 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:39 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:39 --> Controller Class Initialized
DEBUG - 2020-11-02 04:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 04:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:21:39 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:39 --> Total execution time: 0.4010
INFO - 2020-11-02 04:21:40 --> Config Class Initialized
INFO - 2020-11-02 04:21:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:40 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:40 --> URI Class Initialized
INFO - 2020-11-02 04:21:40 --> Router Class Initialized
INFO - 2020-11-02 04:21:40 --> Output Class Initialized
INFO - 2020-11-02 04:21:40 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:40 --> Input Class Initialized
INFO - 2020-11-02 04:21:41 --> Language Class Initialized
INFO - 2020-11-02 04:21:41 --> Language Class Initialized
INFO - 2020-11-02 04:21:41 --> Config Class Initialized
INFO - 2020-11-02 04:21:41 --> Loader Class Initialized
INFO - 2020-11-02 04:21:41 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:41 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:41 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:41 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:41 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:41 --> Controller Class Initialized
DEBUG - 2020-11-02 04:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:21:41 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:41 --> Total execution time: 0.3286
INFO - 2020-11-02 04:21:42 --> Config Class Initialized
INFO - 2020-11-02 04:21:42 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:42 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:42 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:42 --> URI Class Initialized
INFO - 2020-11-02 04:21:42 --> Router Class Initialized
INFO - 2020-11-02 04:21:42 --> Output Class Initialized
INFO - 2020-11-02 04:21:42 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:42 --> Input Class Initialized
INFO - 2020-11-02 04:21:42 --> Language Class Initialized
INFO - 2020-11-02 04:21:42 --> Language Class Initialized
INFO - 2020-11-02 04:21:42 --> Config Class Initialized
INFO - 2020-11-02 04:21:42 --> Loader Class Initialized
INFO - 2020-11-02 04:21:42 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:42 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:42 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:42 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:42 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:42 --> Controller Class Initialized
DEBUG - 2020-11-02 04:21:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:21:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:21:42 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:42 --> Total execution time: 0.3438
INFO - 2020-11-02 04:21:42 --> Config Class Initialized
INFO - 2020-11-02 04:21:42 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:42 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:42 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:42 --> URI Class Initialized
INFO - 2020-11-02 04:21:42 --> Router Class Initialized
INFO - 2020-11-02 04:21:42 --> Output Class Initialized
INFO - 2020-11-02 04:21:42 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:42 --> Input Class Initialized
INFO - 2020-11-02 04:21:42 --> Language Class Initialized
INFO - 2020-11-02 04:21:42 --> Language Class Initialized
INFO - 2020-11-02 04:21:42 --> Config Class Initialized
INFO - 2020-11-02 04:21:42 --> Loader Class Initialized
INFO - 2020-11-02 04:21:42 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:42 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:42 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:42 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:42 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:42 --> Controller Class Initialized
INFO - 2020-11-02 04:21:49 --> Config Class Initialized
INFO - 2020-11-02 04:21:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:21:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:21:49 --> Utf8 Class Initialized
INFO - 2020-11-02 04:21:49 --> URI Class Initialized
INFO - 2020-11-02 04:21:49 --> Router Class Initialized
INFO - 2020-11-02 04:21:50 --> Output Class Initialized
INFO - 2020-11-02 04:21:50 --> Security Class Initialized
DEBUG - 2020-11-02 04:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:21:50 --> Input Class Initialized
INFO - 2020-11-02 04:21:50 --> Language Class Initialized
INFO - 2020-11-02 04:21:50 --> Language Class Initialized
INFO - 2020-11-02 04:21:50 --> Config Class Initialized
INFO - 2020-11-02 04:21:50 --> Loader Class Initialized
INFO - 2020-11-02 04:21:50 --> Helper loaded: url_helper
INFO - 2020-11-02 04:21:50 --> Helper loaded: file_helper
INFO - 2020-11-02 04:21:50 --> Helper loaded: form_helper
INFO - 2020-11-02 04:21:50 --> Helper loaded: my_helper
INFO - 2020-11-02 04:21:50 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:21:50 --> Controller Class Initialized
INFO - 2020-11-02 04:21:50 --> Final output sent to browser
DEBUG - 2020-11-02 04:21:50 --> Total execution time: 0.3055
INFO - 2020-11-02 04:22:06 --> Config Class Initialized
INFO - 2020-11-02 04:22:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:06 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:06 --> URI Class Initialized
INFO - 2020-11-02 04:22:06 --> Router Class Initialized
INFO - 2020-11-02 04:22:06 --> Output Class Initialized
INFO - 2020-11-02 04:22:06 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:06 --> Input Class Initialized
INFO - 2020-11-02 04:22:06 --> Language Class Initialized
INFO - 2020-11-02 04:22:06 --> Language Class Initialized
INFO - 2020-11-02 04:22:06 --> Config Class Initialized
INFO - 2020-11-02 04:22:06 --> Loader Class Initialized
INFO - 2020-11-02 04:22:06 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:06 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:06 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:06 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:06 --> Controller Class Initialized
INFO - 2020-11-02 04:22:06 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:06 --> Total execution time: 0.3552
INFO - 2020-11-02 04:22:06 --> Config Class Initialized
INFO - 2020-11-02 04:22:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:06 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:06 --> URI Class Initialized
INFO - 2020-11-02 04:22:06 --> Router Class Initialized
INFO - 2020-11-02 04:22:06 --> Output Class Initialized
INFO - 2020-11-02 04:22:06 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:06 --> Input Class Initialized
INFO - 2020-11-02 04:22:06 --> Language Class Initialized
INFO - 2020-11-02 04:22:06 --> Language Class Initialized
INFO - 2020-11-02 04:22:06 --> Config Class Initialized
INFO - 2020-11-02 04:22:06 --> Loader Class Initialized
INFO - 2020-11-02 04:22:06 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:06 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:06 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:06 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:06 --> Controller Class Initialized
INFO - 2020-11-02 04:22:08 --> Config Class Initialized
INFO - 2020-11-02 04:22:08 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:08 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:08 --> URI Class Initialized
INFO - 2020-11-02 04:22:08 --> Router Class Initialized
INFO - 2020-11-02 04:22:08 --> Output Class Initialized
INFO - 2020-11-02 04:22:08 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:08 --> Input Class Initialized
INFO - 2020-11-02 04:22:08 --> Language Class Initialized
INFO - 2020-11-02 04:22:08 --> Language Class Initialized
INFO - 2020-11-02 04:22:08 --> Config Class Initialized
INFO - 2020-11-02 04:22:08 --> Loader Class Initialized
INFO - 2020-11-02 04:22:08 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:08 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:08 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:08 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:08 --> Controller Class Initialized
INFO - 2020-11-02 04:22:08 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:08 --> Total execution time: 0.2803
INFO - 2020-11-02 04:22:14 --> Config Class Initialized
INFO - 2020-11-02 04:22:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:14 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:14 --> URI Class Initialized
INFO - 2020-11-02 04:22:14 --> Router Class Initialized
INFO - 2020-11-02 04:22:14 --> Output Class Initialized
INFO - 2020-11-02 04:22:14 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:14 --> Input Class Initialized
INFO - 2020-11-02 04:22:14 --> Language Class Initialized
INFO - 2020-11-02 04:22:14 --> Language Class Initialized
INFO - 2020-11-02 04:22:14 --> Config Class Initialized
INFO - 2020-11-02 04:22:14 --> Loader Class Initialized
INFO - 2020-11-02 04:22:14 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:14 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:14 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:14 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:14 --> Controller Class Initialized
INFO - 2020-11-02 04:22:14 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:14 --> Total execution time: 0.3657
INFO - 2020-11-02 04:22:16 --> Config Class Initialized
INFO - 2020-11-02 04:22:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:16 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:16 --> URI Class Initialized
INFO - 2020-11-02 04:22:16 --> Router Class Initialized
INFO - 2020-11-02 04:22:16 --> Output Class Initialized
INFO - 2020-11-02 04:22:16 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:16 --> Input Class Initialized
INFO - 2020-11-02 04:22:16 --> Language Class Initialized
INFO - 2020-11-02 04:22:16 --> Language Class Initialized
INFO - 2020-11-02 04:22:16 --> Config Class Initialized
INFO - 2020-11-02 04:22:16 --> Loader Class Initialized
INFO - 2020-11-02 04:22:16 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:16 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:16 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:16 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:16 --> Controller Class Initialized
INFO - 2020-11-02 04:22:16 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:16 --> Total execution time: 0.2989
INFO - 2020-11-02 04:22:31 --> Config Class Initialized
INFO - 2020-11-02 04:22:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:31 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:31 --> URI Class Initialized
INFO - 2020-11-02 04:22:31 --> Router Class Initialized
INFO - 2020-11-02 04:22:31 --> Output Class Initialized
INFO - 2020-11-02 04:22:31 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:31 --> Input Class Initialized
INFO - 2020-11-02 04:22:31 --> Language Class Initialized
INFO - 2020-11-02 04:22:31 --> Language Class Initialized
INFO - 2020-11-02 04:22:31 --> Config Class Initialized
INFO - 2020-11-02 04:22:31 --> Loader Class Initialized
INFO - 2020-11-02 04:22:31 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:31 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:31 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:31 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:31 --> Controller Class Initialized
INFO - 2020-11-02 04:22:31 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:31 --> Total execution time: 0.3977
INFO - 2020-11-02 04:22:33 --> Config Class Initialized
INFO - 2020-11-02 04:22:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:33 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:33 --> URI Class Initialized
INFO - 2020-11-02 04:22:33 --> Router Class Initialized
INFO - 2020-11-02 04:22:33 --> Output Class Initialized
INFO - 2020-11-02 04:22:33 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:33 --> Input Class Initialized
INFO - 2020-11-02 04:22:33 --> Language Class Initialized
INFO - 2020-11-02 04:22:33 --> Language Class Initialized
INFO - 2020-11-02 04:22:33 --> Config Class Initialized
INFO - 2020-11-02 04:22:33 --> Loader Class Initialized
INFO - 2020-11-02 04:22:33 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:33 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:33 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:33 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:33 --> Controller Class Initialized
INFO - 2020-11-02 04:22:33 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:33 --> Total execution time: 0.2792
INFO - 2020-11-02 04:22:40 --> Config Class Initialized
INFO - 2020-11-02 04:22:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:40 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:40 --> URI Class Initialized
INFO - 2020-11-02 04:22:40 --> Router Class Initialized
INFO - 2020-11-02 04:22:40 --> Output Class Initialized
INFO - 2020-11-02 04:22:40 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:40 --> Input Class Initialized
INFO - 2020-11-02 04:22:40 --> Language Class Initialized
INFO - 2020-11-02 04:22:40 --> Language Class Initialized
INFO - 2020-11-02 04:22:40 --> Config Class Initialized
INFO - 2020-11-02 04:22:40 --> Loader Class Initialized
INFO - 2020-11-02 04:22:40 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:40 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:40 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:40 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:40 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:40 --> Controller Class Initialized
INFO - 2020-11-02 04:22:41 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:41 --> Total execution time: 0.3962
INFO - 2020-11-02 04:22:58 --> Config Class Initialized
INFO - 2020-11-02 04:22:58 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:58 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:58 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:58 --> URI Class Initialized
INFO - 2020-11-02 04:22:58 --> Router Class Initialized
INFO - 2020-11-02 04:22:58 --> Output Class Initialized
INFO - 2020-11-02 04:22:58 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:58 --> Input Class Initialized
INFO - 2020-11-02 04:22:58 --> Language Class Initialized
INFO - 2020-11-02 04:22:58 --> Language Class Initialized
INFO - 2020-11-02 04:22:58 --> Config Class Initialized
INFO - 2020-11-02 04:22:58 --> Loader Class Initialized
INFO - 2020-11-02 04:22:58 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:58 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:58 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:58 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:58 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:58 --> Controller Class Initialized
DEBUG - 2020-11-02 04:22:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:22:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:22:58 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:58 --> Total execution time: 0.3556
INFO - 2020-11-02 04:22:59 --> Config Class Initialized
INFO - 2020-11-02 04:22:59 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:22:59 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:22:59 --> Utf8 Class Initialized
INFO - 2020-11-02 04:22:59 --> URI Class Initialized
INFO - 2020-11-02 04:22:59 --> Router Class Initialized
INFO - 2020-11-02 04:22:59 --> Output Class Initialized
INFO - 2020-11-02 04:22:59 --> Security Class Initialized
DEBUG - 2020-11-02 04:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:22:59 --> Input Class Initialized
INFO - 2020-11-02 04:22:59 --> Language Class Initialized
INFO - 2020-11-02 04:22:59 --> Language Class Initialized
INFO - 2020-11-02 04:22:59 --> Config Class Initialized
INFO - 2020-11-02 04:22:59 --> Loader Class Initialized
INFO - 2020-11-02 04:22:59 --> Helper loaded: url_helper
INFO - 2020-11-02 04:22:59 --> Helper loaded: file_helper
INFO - 2020-11-02 04:22:59 --> Helper loaded: form_helper
INFO - 2020-11-02 04:22:59 --> Helper loaded: my_helper
INFO - 2020-11-02 04:22:59 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:22:59 --> Controller Class Initialized
DEBUG - 2020-11-02 04:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:22:59 --> Final output sent to browser
DEBUG - 2020-11-02 04:22:59 --> Total execution time: 0.3305
INFO - 2020-11-02 04:23:01 --> Config Class Initialized
INFO - 2020-11-02 04:23:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:23:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:23:01 --> Utf8 Class Initialized
INFO - 2020-11-02 04:23:01 --> URI Class Initialized
INFO - 2020-11-02 04:23:01 --> Router Class Initialized
INFO - 2020-11-02 04:23:01 --> Output Class Initialized
INFO - 2020-11-02 04:23:01 --> Security Class Initialized
DEBUG - 2020-11-02 04:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:23:01 --> Input Class Initialized
INFO - 2020-11-02 04:23:01 --> Language Class Initialized
INFO - 2020-11-02 04:23:01 --> Language Class Initialized
INFO - 2020-11-02 04:23:01 --> Config Class Initialized
INFO - 2020-11-02 04:23:01 --> Loader Class Initialized
INFO - 2020-11-02 04:23:01 --> Helper loaded: url_helper
INFO - 2020-11-02 04:23:01 --> Helper loaded: file_helper
INFO - 2020-11-02 04:23:01 --> Helper loaded: form_helper
INFO - 2020-11-02 04:23:01 --> Helper loaded: my_helper
INFO - 2020-11-02 04:23:01 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:23:01 --> Controller Class Initialized
INFO - 2020-11-02 04:23:01 --> Final output sent to browser
DEBUG - 2020-11-02 04:23:01 --> Total execution time: 0.3080
INFO - 2020-11-02 04:23:09 --> Config Class Initialized
INFO - 2020-11-02 04:23:09 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:23:09 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:23:09 --> Utf8 Class Initialized
INFO - 2020-11-02 04:23:09 --> URI Class Initialized
INFO - 2020-11-02 04:23:09 --> Router Class Initialized
INFO - 2020-11-02 04:23:09 --> Output Class Initialized
INFO - 2020-11-02 04:23:09 --> Security Class Initialized
DEBUG - 2020-11-02 04:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:23:09 --> Input Class Initialized
INFO - 2020-11-02 04:23:09 --> Language Class Initialized
INFO - 2020-11-02 04:23:09 --> Language Class Initialized
INFO - 2020-11-02 04:23:09 --> Config Class Initialized
INFO - 2020-11-02 04:23:09 --> Loader Class Initialized
INFO - 2020-11-02 04:23:09 --> Helper loaded: url_helper
INFO - 2020-11-02 04:23:09 --> Helper loaded: file_helper
INFO - 2020-11-02 04:23:09 --> Helper loaded: form_helper
INFO - 2020-11-02 04:23:09 --> Helper loaded: my_helper
INFO - 2020-11-02 04:23:09 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:23:09 --> Controller Class Initialized
INFO - 2020-11-02 04:23:09 --> Final output sent to browser
DEBUG - 2020-11-02 04:23:09 --> Total execution time: 0.3546
INFO - 2020-11-02 04:23:10 --> Config Class Initialized
INFO - 2020-11-02 04:23:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:23:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:23:10 --> Utf8 Class Initialized
INFO - 2020-11-02 04:23:10 --> URI Class Initialized
INFO - 2020-11-02 04:23:10 --> Router Class Initialized
INFO - 2020-11-02 04:23:10 --> Output Class Initialized
INFO - 2020-11-02 04:23:10 --> Security Class Initialized
DEBUG - 2020-11-02 04:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:23:10 --> Input Class Initialized
INFO - 2020-11-02 04:23:10 --> Language Class Initialized
INFO - 2020-11-02 04:23:10 --> Language Class Initialized
INFO - 2020-11-02 04:23:10 --> Config Class Initialized
INFO - 2020-11-02 04:23:10 --> Loader Class Initialized
INFO - 2020-11-02 04:23:10 --> Helper loaded: url_helper
INFO - 2020-11-02 04:23:10 --> Helper loaded: file_helper
INFO - 2020-11-02 04:23:10 --> Helper loaded: form_helper
INFO - 2020-11-02 04:23:10 --> Helper loaded: my_helper
INFO - 2020-11-02 04:23:10 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:23:10 --> Controller Class Initialized
DEBUG - 2020-11-02 04:23:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:23:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:23:10 --> Final output sent to browser
DEBUG - 2020-11-02 04:23:10 --> Total execution time: 0.3616
INFO - 2020-11-02 04:23:11 --> Config Class Initialized
INFO - 2020-11-02 04:23:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:23:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:23:11 --> Utf8 Class Initialized
INFO - 2020-11-02 04:23:11 --> URI Class Initialized
INFO - 2020-11-02 04:23:11 --> Router Class Initialized
INFO - 2020-11-02 04:23:11 --> Output Class Initialized
INFO - 2020-11-02 04:23:11 --> Security Class Initialized
DEBUG - 2020-11-02 04:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:23:11 --> Input Class Initialized
INFO - 2020-11-02 04:23:11 --> Language Class Initialized
INFO - 2020-11-02 04:23:11 --> Language Class Initialized
INFO - 2020-11-02 04:23:11 --> Config Class Initialized
INFO - 2020-11-02 04:23:11 --> Loader Class Initialized
INFO - 2020-11-02 04:23:11 --> Helper loaded: url_helper
INFO - 2020-11-02 04:23:11 --> Helper loaded: file_helper
INFO - 2020-11-02 04:23:11 --> Helper loaded: form_helper
INFO - 2020-11-02 04:23:11 --> Helper loaded: my_helper
INFO - 2020-11-02 04:23:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:23:11 --> Controller Class Initialized
INFO - 2020-11-02 04:23:11 --> Final output sent to browser
DEBUG - 2020-11-02 04:23:11 --> Total execution time: 0.2821
INFO - 2020-11-02 04:23:13 --> Config Class Initialized
INFO - 2020-11-02 04:23:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:23:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:23:13 --> Utf8 Class Initialized
INFO - 2020-11-02 04:23:13 --> URI Class Initialized
INFO - 2020-11-02 04:23:14 --> Router Class Initialized
INFO - 2020-11-02 04:23:14 --> Output Class Initialized
INFO - 2020-11-02 04:23:14 --> Security Class Initialized
DEBUG - 2020-11-02 04:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:23:14 --> Input Class Initialized
INFO - 2020-11-02 04:23:14 --> Language Class Initialized
INFO - 2020-11-02 04:23:14 --> Language Class Initialized
INFO - 2020-11-02 04:23:14 --> Config Class Initialized
INFO - 2020-11-02 04:23:14 --> Loader Class Initialized
INFO - 2020-11-02 04:23:14 --> Helper loaded: url_helper
INFO - 2020-11-02 04:23:14 --> Helper loaded: file_helper
INFO - 2020-11-02 04:23:14 --> Helper loaded: form_helper
INFO - 2020-11-02 04:23:14 --> Helper loaded: my_helper
INFO - 2020-11-02 04:23:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:23:14 --> Controller Class Initialized
INFO - 2020-11-02 04:23:14 --> Final output sent to browser
DEBUG - 2020-11-02 04:23:14 --> Total execution time: 0.3028
INFO - 2020-11-02 04:23:21 --> Config Class Initialized
INFO - 2020-11-02 04:23:21 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:23:21 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:23:21 --> Utf8 Class Initialized
INFO - 2020-11-02 04:23:21 --> URI Class Initialized
INFO - 2020-11-02 04:23:21 --> Router Class Initialized
INFO - 2020-11-02 04:23:21 --> Output Class Initialized
INFO - 2020-11-02 04:23:21 --> Security Class Initialized
DEBUG - 2020-11-02 04:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:23:21 --> Input Class Initialized
INFO - 2020-11-02 04:23:21 --> Language Class Initialized
INFO - 2020-11-02 04:23:21 --> Language Class Initialized
INFO - 2020-11-02 04:23:21 --> Config Class Initialized
INFO - 2020-11-02 04:23:21 --> Loader Class Initialized
INFO - 2020-11-02 04:23:21 --> Helper loaded: url_helper
INFO - 2020-11-02 04:23:21 --> Helper loaded: file_helper
INFO - 2020-11-02 04:23:21 --> Helper loaded: form_helper
INFO - 2020-11-02 04:23:21 --> Helper loaded: my_helper
INFO - 2020-11-02 04:23:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:23:21 --> Controller Class Initialized
INFO - 2020-11-02 04:23:21 --> Final output sent to browser
DEBUG - 2020-11-02 04:23:21 --> Total execution time: 0.3795
INFO - 2020-11-02 04:25:36 --> Config Class Initialized
INFO - 2020-11-02 04:25:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:25:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:25:36 --> Utf8 Class Initialized
INFO - 2020-11-02 04:25:36 --> URI Class Initialized
INFO - 2020-11-02 04:25:36 --> Router Class Initialized
INFO - 2020-11-02 04:25:36 --> Output Class Initialized
INFO - 2020-11-02 04:25:36 --> Security Class Initialized
DEBUG - 2020-11-02 04:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:25:36 --> Input Class Initialized
INFO - 2020-11-02 04:25:36 --> Language Class Initialized
INFO - 2020-11-02 04:25:36 --> Language Class Initialized
INFO - 2020-11-02 04:25:36 --> Config Class Initialized
INFO - 2020-11-02 04:25:36 --> Loader Class Initialized
INFO - 2020-11-02 04:25:36 --> Helper loaded: url_helper
INFO - 2020-11-02 04:25:36 --> Helper loaded: file_helper
INFO - 2020-11-02 04:25:36 --> Helper loaded: form_helper
INFO - 2020-11-02 04:25:36 --> Helper loaded: my_helper
INFO - 2020-11-02 04:25:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:25:36 --> Controller Class Initialized
DEBUG - 2020-11-02 04:25:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:25:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:25:36 --> Final output sent to browser
DEBUG - 2020-11-02 04:25:36 --> Total execution time: 0.3420
INFO - 2020-11-02 04:25:37 --> Config Class Initialized
INFO - 2020-11-02 04:25:37 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:25:37 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:25:37 --> Utf8 Class Initialized
INFO - 2020-11-02 04:25:37 --> URI Class Initialized
INFO - 2020-11-02 04:25:37 --> Router Class Initialized
INFO - 2020-11-02 04:25:37 --> Output Class Initialized
INFO - 2020-11-02 04:25:37 --> Security Class Initialized
DEBUG - 2020-11-02 04:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:25:37 --> Input Class Initialized
INFO - 2020-11-02 04:25:37 --> Language Class Initialized
INFO - 2020-11-02 04:25:37 --> Language Class Initialized
INFO - 2020-11-02 04:25:37 --> Config Class Initialized
INFO - 2020-11-02 04:25:37 --> Loader Class Initialized
INFO - 2020-11-02 04:25:37 --> Helper loaded: url_helper
INFO - 2020-11-02 04:25:37 --> Helper loaded: file_helper
INFO - 2020-11-02 04:25:37 --> Helper loaded: form_helper
INFO - 2020-11-02 04:25:37 --> Helper loaded: my_helper
INFO - 2020-11-02 04:25:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:25:38 --> Controller Class Initialized
DEBUG - 2020-11-02 04:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:25:38 --> Final output sent to browser
DEBUG - 2020-11-02 04:25:38 --> Total execution time: 0.3183
INFO - 2020-11-02 04:25:38 --> Config Class Initialized
INFO - 2020-11-02 04:25:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:25:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:25:38 --> Utf8 Class Initialized
INFO - 2020-11-02 04:25:38 --> URI Class Initialized
INFO - 2020-11-02 04:25:38 --> Router Class Initialized
INFO - 2020-11-02 04:25:38 --> Output Class Initialized
INFO - 2020-11-02 04:25:38 --> Security Class Initialized
DEBUG - 2020-11-02 04:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:25:38 --> Input Class Initialized
INFO - 2020-11-02 04:25:38 --> Language Class Initialized
INFO - 2020-11-02 04:25:38 --> Language Class Initialized
INFO - 2020-11-02 04:25:38 --> Config Class Initialized
INFO - 2020-11-02 04:25:38 --> Loader Class Initialized
INFO - 2020-11-02 04:25:38 --> Helper loaded: url_helper
INFO - 2020-11-02 04:25:38 --> Helper loaded: file_helper
INFO - 2020-11-02 04:25:38 --> Helper loaded: form_helper
INFO - 2020-11-02 04:25:38 --> Helper loaded: my_helper
INFO - 2020-11-02 04:25:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:25:38 --> Controller Class Initialized
INFO - 2020-11-02 04:26:03 --> Config Class Initialized
INFO - 2020-11-02 04:26:03 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:26:03 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:26:04 --> Utf8 Class Initialized
INFO - 2020-11-02 04:26:04 --> URI Class Initialized
INFO - 2020-11-02 04:26:04 --> Router Class Initialized
INFO - 2020-11-02 04:26:04 --> Output Class Initialized
INFO - 2020-11-02 04:26:04 --> Security Class Initialized
DEBUG - 2020-11-02 04:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:26:04 --> Input Class Initialized
INFO - 2020-11-02 04:26:04 --> Language Class Initialized
INFO - 2020-11-02 04:26:04 --> Language Class Initialized
INFO - 2020-11-02 04:26:04 --> Config Class Initialized
INFO - 2020-11-02 04:26:04 --> Loader Class Initialized
INFO - 2020-11-02 04:26:04 --> Helper loaded: url_helper
INFO - 2020-11-02 04:26:04 --> Helper loaded: file_helper
INFO - 2020-11-02 04:26:04 --> Helper loaded: form_helper
INFO - 2020-11-02 04:26:04 --> Helper loaded: my_helper
INFO - 2020-11-02 04:26:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:26:04 --> Controller Class Initialized
DEBUG - 2020-11-02 04:26:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:26:04 --> Final output sent to browser
DEBUG - 2020-11-02 04:26:04 --> Total execution time: 0.3392
INFO - 2020-11-02 04:26:49 --> Config Class Initialized
INFO - 2020-11-02 04:26:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:26:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:26:49 --> Utf8 Class Initialized
INFO - 2020-11-02 04:26:49 --> URI Class Initialized
INFO - 2020-11-02 04:26:49 --> Router Class Initialized
INFO - 2020-11-02 04:26:49 --> Output Class Initialized
INFO - 2020-11-02 04:26:49 --> Security Class Initialized
DEBUG - 2020-11-02 04:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:26:49 --> Input Class Initialized
INFO - 2020-11-02 04:26:49 --> Language Class Initialized
INFO - 2020-11-02 04:26:49 --> Language Class Initialized
INFO - 2020-11-02 04:26:49 --> Config Class Initialized
INFO - 2020-11-02 04:26:49 --> Loader Class Initialized
INFO - 2020-11-02 04:26:49 --> Helper loaded: url_helper
INFO - 2020-11-02 04:26:49 --> Helper loaded: file_helper
INFO - 2020-11-02 04:26:49 --> Helper loaded: form_helper
INFO - 2020-11-02 04:26:49 --> Helper loaded: my_helper
INFO - 2020-11-02 04:26:49 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:26:49 --> Controller Class Initialized
DEBUG - 2020-11-02 04:26:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:26:49 --> Final output sent to browser
DEBUG - 2020-11-02 04:26:49 --> Total execution time: 0.3267
INFO - 2020-11-02 04:26:53 --> Config Class Initialized
INFO - 2020-11-02 04:26:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:26:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:26:53 --> Utf8 Class Initialized
INFO - 2020-11-02 04:26:53 --> URI Class Initialized
INFO - 2020-11-02 04:26:53 --> Router Class Initialized
INFO - 2020-11-02 04:26:53 --> Output Class Initialized
INFO - 2020-11-02 04:26:53 --> Security Class Initialized
DEBUG - 2020-11-02 04:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:26:53 --> Input Class Initialized
INFO - 2020-11-02 04:26:53 --> Language Class Initialized
INFO - 2020-11-02 04:26:53 --> Language Class Initialized
INFO - 2020-11-02 04:26:53 --> Config Class Initialized
INFO - 2020-11-02 04:26:53 --> Loader Class Initialized
INFO - 2020-11-02 04:26:54 --> Helper loaded: url_helper
INFO - 2020-11-02 04:26:54 --> Helper loaded: file_helper
INFO - 2020-11-02 04:26:54 --> Helper loaded: form_helper
INFO - 2020-11-02 04:26:54 --> Helper loaded: my_helper
INFO - 2020-11-02 04:26:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:26:54 --> Controller Class Initialized
DEBUG - 2020-11-02 04:26:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:26:54 --> Final output sent to browser
DEBUG - 2020-11-02 04:26:54 --> Total execution time: 0.3277
INFO - 2020-11-02 04:27:45 --> Config Class Initialized
INFO - 2020-11-02 04:27:45 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:27:45 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:27:45 --> Utf8 Class Initialized
INFO - 2020-11-02 04:27:45 --> URI Class Initialized
INFO - 2020-11-02 04:27:45 --> Router Class Initialized
INFO - 2020-11-02 04:27:45 --> Output Class Initialized
INFO - 2020-11-02 04:27:45 --> Security Class Initialized
DEBUG - 2020-11-02 04:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:27:45 --> Input Class Initialized
INFO - 2020-11-02 04:27:45 --> Language Class Initialized
INFO - 2020-11-02 04:27:45 --> Language Class Initialized
INFO - 2020-11-02 04:27:45 --> Config Class Initialized
INFO - 2020-11-02 04:27:45 --> Loader Class Initialized
INFO - 2020-11-02 04:27:45 --> Helper loaded: url_helper
INFO - 2020-11-02 04:27:45 --> Helper loaded: file_helper
INFO - 2020-11-02 04:27:45 --> Helper loaded: form_helper
INFO - 2020-11-02 04:27:45 --> Helper loaded: my_helper
INFO - 2020-11-02 04:27:45 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:27:45 --> Controller Class Initialized
DEBUG - 2020-11-02 04:27:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:27:45 --> Final output sent to browser
DEBUG - 2020-11-02 04:27:45 --> Total execution time: 0.3147
INFO - 2020-11-02 04:33:08 --> Config Class Initialized
INFO - 2020-11-02 04:33:08 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:33:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:33:08 --> Utf8 Class Initialized
INFO - 2020-11-02 04:33:08 --> URI Class Initialized
INFO - 2020-11-02 04:33:08 --> Router Class Initialized
INFO - 2020-11-02 04:33:08 --> Output Class Initialized
INFO - 2020-11-02 04:33:08 --> Security Class Initialized
DEBUG - 2020-11-02 04:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:33:08 --> Input Class Initialized
INFO - 2020-11-02 04:33:08 --> Language Class Initialized
INFO - 2020-11-02 04:33:08 --> Language Class Initialized
INFO - 2020-11-02 04:33:08 --> Config Class Initialized
INFO - 2020-11-02 04:33:08 --> Loader Class Initialized
INFO - 2020-11-02 04:33:08 --> Helper loaded: url_helper
INFO - 2020-11-02 04:33:08 --> Helper loaded: file_helper
INFO - 2020-11-02 04:33:08 --> Helper loaded: form_helper
INFO - 2020-11-02 04:33:08 --> Helper loaded: my_helper
INFO - 2020-11-02 04:33:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:33:08 --> Controller Class Initialized
DEBUG - 2020-11-02 04:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:33:08 --> Final output sent to browser
DEBUG - 2020-11-02 04:33:08 --> Total execution time: 0.3071
INFO - 2020-11-02 04:34:05 --> Config Class Initialized
INFO - 2020-11-02 04:34:05 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:34:05 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:34:05 --> Utf8 Class Initialized
INFO - 2020-11-02 04:34:05 --> URI Class Initialized
INFO - 2020-11-02 04:34:05 --> Router Class Initialized
INFO - 2020-11-02 04:34:05 --> Output Class Initialized
INFO - 2020-11-02 04:34:05 --> Security Class Initialized
DEBUG - 2020-11-02 04:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:34:05 --> Input Class Initialized
INFO - 2020-11-02 04:34:05 --> Language Class Initialized
INFO - 2020-11-02 04:34:05 --> Language Class Initialized
INFO - 2020-11-02 04:34:05 --> Config Class Initialized
INFO - 2020-11-02 04:34:05 --> Loader Class Initialized
INFO - 2020-11-02 04:34:05 --> Helper loaded: url_helper
INFO - 2020-11-02 04:34:05 --> Helper loaded: file_helper
INFO - 2020-11-02 04:34:05 --> Helper loaded: form_helper
INFO - 2020-11-02 04:34:05 --> Helper loaded: my_helper
INFO - 2020-11-02 04:34:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:34:05 --> Controller Class Initialized
DEBUG - 2020-11-02 04:34:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:34:05 --> Final output sent to browser
DEBUG - 2020-11-02 04:34:05 --> Total execution time: 0.3211
INFO - 2020-11-02 04:34:06 --> Config Class Initialized
INFO - 2020-11-02 04:34:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:34:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:34:06 --> Utf8 Class Initialized
INFO - 2020-11-02 04:34:06 --> URI Class Initialized
INFO - 2020-11-02 04:34:06 --> Router Class Initialized
INFO - 2020-11-02 04:34:06 --> Output Class Initialized
INFO - 2020-11-02 04:34:06 --> Security Class Initialized
DEBUG - 2020-11-02 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:34:06 --> Input Class Initialized
INFO - 2020-11-02 04:34:06 --> Language Class Initialized
INFO - 2020-11-02 04:34:06 --> Language Class Initialized
INFO - 2020-11-02 04:34:06 --> Config Class Initialized
INFO - 2020-11-02 04:34:06 --> Loader Class Initialized
INFO - 2020-11-02 04:34:06 --> Helper loaded: url_helper
INFO - 2020-11-02 04:34:06 --> Helper loaded: file_helper
INFO - 2020-11-02 04:34:06 --> Helper loaded: form_helper
INFO - 2020-11-02 04:34:06 --> Helper loaded: my_helper
INFO - 2020-11-02 04:34:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:34:06 --> Controller Class Initialized
DEBUG - 2020-11-02 04:34:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:34:06 --> Final output sent to browser
DEBUG - 2020-11-02 04:34:06 --> Total execution time: 0.3332
INFO - 2020-11-02 04:34:18 --> Config Class Initialized
INFO - 2020-11-02 04:34:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:34:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:34:18 --> Utf8 Class Initialized
INFO - 2020-11-02 04:34:18 --> URI Class Initialized
INFO - 2020-11-02 04:34:18 --> Router Class Initialized
INFO - 2020-11-02 04:34:18 --> Output Class Initialized
INFO - 2020-11-02 04:34:18 --> Security Class Initialized
DEBUG - 2020-11-02 04:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:34:18 --> Input Class Initialized
INFO - 2020-11-02 04:34:18 --> Language Class Initialized
INFO - 2020-11-02 04:34:18 --> Language Class Initialized
INFO - 2020-11-02 04:34:18 --> Config Class Initialized
INFO - 2020-11-02 04:34:18 --> Loader Class Initialized
INFO - 2020-11-02 04:34:18 --> Helper loaded: url_helper
INFO - 2020-11-02 04:34:18 --> Helper loaded: file_helper
INFO - 2020-11-02 04:34:18 --> Helper loaded: form_helper
INFO - 2020-11-02 04:34:18 --> Helper loaded: my_helper
INFO - 2020-11-02 04:34:18 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:34:18 --> Controller Class Initialized
DEBUG - 2020-11-02 04:34:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-02 04:34:18 --> Final output sent to browser
DEBUG - 2020-11-02 04:34:18 --> Total execution time: 0.3205
INFO - 2020-11-02 04:36:06 --> Config Class Initialized
INFO - 2020-11-02 04:36:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:06 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:06 --> URI Class Initialized
INFO - 2020-11-02 04:36:06 --> Router Class Initialized
INFO - 2020-11-02 04:36:06 --> Output Class Initialized
INFO - 2020-11-02 04:36:06 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:06 --> Input Class Initialized
INFO - 2020-11-02 04:36:06 --> Language Class Initialized
INFO - 2020-11-02 04:36:06 --> Language Class Initialized
INFO - 2020-11-02 04:36:06 --> Config Class Initialized
INFO - 2020-11-02 04:36:06 --> Loader Class Initialized
INFO - 2020-11-02 04:36:06 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:06 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:06 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:06 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:06 --> Controller Class Initialized
DEBUG - 2020-11-02 04:36:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:36:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:36:06 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:06 --> Total execution time: 0.3150
INFO - 2020-11-02 04:36:07 --> Config Class Initialized
INFO - 2020-11-02 04:36:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:07 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:07 --> URI Class Initialized
INFO - 2020-11-02 04:36:07 --> Router Class Initialized
INFO - 2020-11-02 04:36:07 --> Output Class Initialized
INFO - 2020-11-02 04:36:07 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:07 --> Input Class Initialized
INFO - 2020-11-02 04:36:07 --> Language Class Initialized
INFO - 2020-11-02 04:36:07 --> Language Class Initialized
INFO - 2020-11-02 04:36:07 --> Config Class Initialized
INFO - 2020-11-02 04:36:07 --> Loader Class Initialized
INFO - 2020-11-02 04:36:07 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:07 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:07 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:08 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:08 --> Controller Class Initialized
DEBUG - 2020-11-02 04:36:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:36:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:36:08 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:08 --> Total execution time: 0.3518
INFO - 2020-11-02 04:36:10 --> Config Class Initialized
INFO - 2020-11-02 04:36:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:10 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:10 --> URI Class Initialized
INFO - 2020-11-02 04:36:10 --> Router Class Initialized
INFO - 2020-11-02 04:36:10 --> Output Class Initialized
INFO - 2020-11-02 04:36:10 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:10 --> Input Class Initialized
INFO - 2020-11-02 04:36:10 --> Language Class Initialized
INFO - 2020-11-02 04:36:10 --> Language Class Initialized
INFO - 2020-11-02 04:36:10 --> Config Class Initialized
INFO - 2020-11-02 04:36:10 --> Loader Class Initialized
INFO - 2020-11-02 04:36:10 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:10 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:10 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:10 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:10 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:10 --> Controller Class Initialized
INFO - 2020-11-02 04:36:10 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:10 --> Total execution time: 0.2771
INFO - 2020-11-02 04:36:12 --> Config Class Initialized
INFO - 2020-11-02 04:36:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:12 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:12 --> URI Class Initialized
INFO - 2020-11-02 04:36:12 --> Router Class Initialized
INFO - 2020-11-02 04:36:12 --> Output Class Initialized
INFO - 2020-11-02 04:36:12 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:12 --> Input Class Initialized
INFO - 2020-11-02 04:36:12 --> Language Class Initialized
INFO - 2020-11-02 04:36:12 --> Language Class Initialized
INFO - 2020-11-02 04:36:12 --> Config Class Initialized
INFO - 2020-11-02 04:36:12 --> Loader Class Initialized
INFO - 2020-11-02 04:36:12 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:12 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:12 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:12 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:12 --> Controller Class Initialized
INFO - 2020-11-02 04:36:12 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:36:12 --> Config Class Initialized
INFO - 2020-11-02 04:36:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:12 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:12 --> URI Class Initialized
INFO - 2020-11-02 04:36:12 --> Router Class Initialized
INFO - 2020-11-02 04:36:12 --> Output Class Initialized
INFO - 2020-11-02 04:36:12 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:12 --> Input Class Initialized
INFO - 2020-11-02 04:36:12 --> Language Class Initialized
INFO - 2020-11-02 04:36:12 --> Language Class Initialized
INFO - 2020-11-02 04:36:12 --> Config Class Initialized
INFO - 2020-11-02 04:36:12 --> Loader Class Initialized
INFO - 2020-11-02 04:36:12 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:12 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:12 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:12 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:12 --> Controller Class Initialized
DEBUG - 2020-11-02 04:36:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 04:36:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:36:12 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:12 --> Total execution time: 0.2994
INFO - 2020-11-02 04:36:21 --> Config Class Initialized
INFO - 2020-11-02 04:36:21 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:21 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:21 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:21 --> URI Class Initialized
INFO - 2020-11-02 04:36:21 --> Router Class Initialized
INFO - 2020-11-02 04:36:21 --> Output Class Initialized
INFO - 2020-11-02 04:36:21 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:21 --> Input Class Initialized
INFO - 2020-11-02 04:36:21 --> Language Class Initialized
INFO - 2020-11-02 04:36:21 --> Language Class Initialized
INFO - 2020-11-02 04:36:21 --> Config Class Initialized
INFO - 2020-11-02 04:36:21 --> Loader Class Initialized
INFO - 2020-11-02 04:36:21 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:21 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:21 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:21 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:21 --> Controller Class Initialized
INFO - 2020-11-02 04:36:21 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:36:21 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:21 --> Total execution time: 0.3192
INFO - 2020-11-02 04:36:22 --> Config Class Initialized
INFO - 2020-11-02 04:36:22 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:22 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:22 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:22 --> URI Class Initialized
INFO - 2020-11-02 04:36:22 --> Router Class Initialized
INFO - 2020-11-02 04:36:22 --> Output Class Initialized
INFO - 2020-11-02 04:36:23 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:23 --> Input Class Initialized
INFO - 2020-11-02 04:36:23 --> Language Class Initialized
INFO - 2020-11-02 04:36:23 --> Language Class Initialized
INFO - 2020-11-02 04:36:23 --> Config Class Initialized
INFO - 2020-11-02 04:36:23 --> Loader Class Initialized
INFO - 2020-11-02 04:36:23 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:23 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:23 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:23 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:23 --> Controller Class Initialized
DEBUG - 2020-11-02 04:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 04:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:36:23 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:23 --> Total execution time: 0.3703
INFO - 2020-11-02 04:36:24 --> Config Class Initialized
INFO - 2020-11-02 04:36:24 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:24 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:24 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:24 --> URI Class Initialized
INFO - 2020-11-02 04:36:24 --> Router Class Initialized
INFO - 2020-11-02 04:36:24 --> Output Class Initialized
INFO - 2020-11-02 04:36:24 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:24 --> Input Class Initialized
INFO - 2020-11-02 04:36:24 --> Language Class Initialized
INFO - 2020-11-02 04:36:24 --> Language Class Initialized
INFO - 2020-11-02 04:36:24 --> Config Class Initialized
INFO - 2020-11-02 04:36:24 --> Loader Class Initialized
INFO - 2020-11-02 04:36:24 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:24 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:24 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:24 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:24 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:24 --> Controller Class Initialized
DEBUG - 2020-11-02 04:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:36:24 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:24 --> Total execution time: 0.3178
INFO - 2020-11-02 04:36:26 --> Config Class Initialized
INFO - 2020-11-02 04:36:26 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:26 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:26 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:26 --> URI Class Initialized
INFO - 2020-11-02 04:36:26 --> Router Class Initialized
INFO - 2020-11-02 04:36:26 --> Output Class Initialized
INFO - 2020-11-02 04:36:26 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:26 --> Input Class Initialized
INFO - 2020-11-02 04:36:26 --> Language Class Initialized
INFO - 2020-11-02 04:36:26 --> Language Class Initialized
INFO - 2020-11-02 04:36:26 --> Config Class Initialized
INFO - 2020-11-02 04:36:26 --> Loader Class Initialized
INFO - 2020-11-02 04:36:26 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:26 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:26 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:26 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:26 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:26 --> Controller Class Initialized
DEBUG - 2020-11-02 04:36:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:36:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:36:26 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:26 --> Total execution time: 0.3152
INFO - 2020-11-02 04:36:26 --> Config Class Initialized
INFO - 2020-11-02 04:36:26 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:26 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:26 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:26 --> URI Class Initialized
INFO - 2020-11-02 04:36:26 --> Router Class Initialized
INFO - 2020-11-02 04:36:26 --> Output Class Initialized
INFO - 2020-11-02 04:36:26 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:26 --> Input Class Initialized
INFO - 2020-11-02 04:36:26 --> Language Class Initialized
INFO - 2020-11-02 04:36:26 --> Language Class Initialized
INFO - 2020-11-02 04:36:26 --> Config Class Initialized
INFO - 2020-11-02 04:36:26 --> Loader Class Initialized
INFO - 2020-11-02 04:36:26 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:26 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:26 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:26 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:26 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:27 --> Controller Class Initialized
INFO - 2020-11-02 04:36:39 --> Config Class Initialized
INFO - 2020-11-02 04:36:39 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:39 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:39 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:39 --> URI Class Initialized
INFO - 2020-11-02 04:36:39 --> Router Class Initialized
INFO - 2020-11-02 04:36:39 --> Output Class Initialized
INFO - 2020-11-02 04:36:39 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:39 --> Input Class Initialized
INFO - 2020-11-02 04:36:39 --> Language Class Initialized
INFO - 2020-11-02 04:36:39 --> Language Class Initialized
INFO - 2020-11-02 04:36:39 --> Config Class Initialized
INFO - 2020-11-02 04:36:39 --> Loader Class Initialized
INFO - 2020-11-02 04:36:39 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:39 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:39 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:39 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:39 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:39 --> Controller Class Initialized
INFO - 2020-11-02 04:36:39 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:39 --> Total execution time: 0.2929
INFO - 2020-11-02 04:36:53 --> Config Class Initialized
INFO - 2020-11-02 04:36:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:53 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:53 --> URI Class Initialized
INFO - 2020-11-02 04:36:53 --> Router Class Initialized
INFO - 2020-11-02 04:36:53 --> Output Class Initialized
INFO - 2020-11-02 04:36:53 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:53 --> Input Class Initialized
INFO - 2020-11-02 04:36:53 --> Language Class Initialized
INFO - 2020-11-02 04:36:53 --> Language Class Initialized
INFO - 2020-11-02 04:36:53 --> Config Class Initialized
INFO - 2020-11-02 04:36:53 --> Loader Class Initialized
INFO - 2020-11-02 04:36:53 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:53 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:53 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:53 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:53 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:53 --> Controller Class Initialized
INFO - 2020-11-02 04:36:53 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:53 --> Total execution time: 0.3471
INFO - 2020-11-02 04:36:53 --> Config Class Initialized
INFO - 2020-11-02 04:36:53 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:53 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:53 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:53 --> URI Class Initialized
INFO - 2020-11-02 04:36:53 --> Router Class Initialized
INFO - 2020-11-02 04:36:53 --> Output Class Initialized
INFO - 2020-11-02 04:36:53 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:53 --> Input Class Initialized
INFO - 2020-11-02 04:36:53 --> Language Class Initialized
INFO - 2020-11-02 04:36:53 --> Language Class Initialized
INFO - 2020-11-02 04:36:53 --> Config Class Initialized
INFO - 2020-11-02 04:36:53 --> Loader Class Initialized
INFO - 2020-11-02 04:36:53 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:54 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:54 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:54 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:54 --> Controller Class Initialized
INFO - 2020-11-02 04:36:55 --> Config Class Initialized
INFO - 2020-11-02 04:36:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:36:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:36:55 --> Utf8 Class Initialized
INFO - 2020-11-02 04:36:56 --> URI Class Initialized
INFO - 2020-11-02 04:36:56 --> Router Class Initialized
INFO - 2020-11-02 04:36:56 --> Output Class Initialized
INFO - 2020-11-02 04:36:56 --> Security Class Initialized
DEBUG - 2020-11-02 04:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:36:56 --> Input Class Initialized
INFO - 2020-11-02 04:36:56 --> Language Class Initialized
INFO - 2020-11-02 04:36:56 --> Language Class Initialized
INFO - 2020-11-02 04:36:56 --> Config Class Initialized
INFO - 2020-11-02 04:36:56 --> Loader Class Initialized
INFO - 2020-11-02 04:36:56 --> Helper loaded: url_helper
INFO - 2020-11-02 04:36:56 --> Helper loaded: file_helper
INFO - 2020-11-02 04:36:56 --> Helper loaded: form_helper
INFO - 2020-11-02 04:36:56 --> Helper loaded: my_helper
INFO - 2020-11-02 04:36:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:36:56 --> Controller Class Initialized
INFO - 2020-11-02 04:36:56 --> Final output sent to browser
DEBUG - 2020-11-02 04:36:56 --> Total execution time: 0.2905
INFO - 2020-11-02 04:37:05 --> Config Class Initialized
INFO - 2020-11-02 04:37:05 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:37:05 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:37:05 --> Utf8 Class Initialized
INFO - 2020-11-02 04:37:05 --> URI Class Initialized
INFO - 2020-11-02 04:37:05 --> Router Class Initialized
INFO - 2020-11-02 04:37:05 --> Output Class Initialized
INFO - 2020-11-02 04:37:05 --> Security Class Initialized
DEBUG - 2020-11-02 04:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:37:05 --> Input Class Initialized
INFO - 2020-11-02 04:37:05 --> Language Class Initialized
INFO - 2020-11-02 04:37:05 --> Language Class Initialized
INFO - 2020-11-02 04:37:05 --> Config Class Initialized
INFO - 2020-11-02 04:37:05 --> Loader Class Initialized
INFO - 2020-11-02 04:37:05 --> Helper loaded: url_helper
INFO - 2020-11-02 04:37:05 --> Helper loaded: file_helper
INFO - 2020-11-02 04:37:05 --> Helper loaded: form_helper
INFO - 2020-11-02 04:37:05 --> Helper loaded: my_helper
INFO - 2020-11-02 04:37:05 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:37:05 --> Controller Class Initialized
INFO - 2020-11-02 04:37:06 --> Final output sent to browser
DEBUG - 2020-11-02 04:37:06 --> Total execution time: 0.3463
INFO - 2020-11-02 04:37:08 --> Config Class Initialized
INFO - 2020-11-02 04:37:08 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:37:08 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:37:08 --> Utf8 Class Initialized
INFO - 2020-11-02 04:37:08 --> URI Class Initialized
INFO - 2020-11-02 04:37:08 --> Router Class Initialized
INFO - 2020-11-02 04:37:08 --> Output Class Initialized
INFO - 2020-11-02 04:37:08 --> Security Class Initialized
DEBUG - 2020-11-02 04:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:37:08 --> Input Class Initialized
INFO - 2020-11-02 04:37:08 --> Language Class Initialized
INFO - 2020-11-02 04:37:08 --> Language Class Initialized
INFO - 2020-11-02 04:37:08 --> Config Class Initialized
INFO - 2020-11-02 04:37:08 --> Loader Class Initialized
INFO - 2020-11-02 04:37:08 --> Helper loaded: url_helper
INFO - 2020-11-02 04:37:08 --> Helper loaded: file_helper
INFO - 2020-11-02 04:37:08 --> Helper loaded: form_helper
INFO - 2020-11-02 04:37:08 --> Helper loaded: my_helper
INFO - 2020-11-02 04:37:08 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:37:08 --> Controller Class Initialized
INFO - 2020-11-02 04:37:08 --> Final output sent to browser
DEBUG - 2020-11-02 04:37:08 --> Total execution time: 0.2693
INFO - 2020-11-02 04:37:23 --> Config Class Initialized
INFO - 2020-11-02 04:37:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:37:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:37:23 --> Utf8 Class Initialized
INFO - 2020-11-02 04:37:23 --> URI Class Initialized
INFO - 2020-11-02 04:37:23 --> Router Class Initialized
INFO - 2020-11-02 04:37:23 --> Output Class Initialized
INFO - 2020-11-02 04:37:23 --> Security Class Initialized
DEBUG - 2020-11-02 04:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:37:23 --> Input Class Initialized
INFO - 2020-11-02 04:37:23 --> Language Class Initialized
INFO - 2020-11-02 04:37:23 --> Language Class Initialized
INFO - 2020-11-02 04:37:23 --> Config Class Initialized
INFO - 2020-11-02 04:37:23 --> Loader Class Initialized
INFO - 2020-11-02 04:37:23 --> Helper loaded: url_helper
INFO - 2020-11-02 04:37:23 --> Helper loaded: file_helper
INFO - 2020-11-02 04:37:23 --> Helper loaded: form_helper
INFO - 2020-11-02 04:37:23 --> Helper loaded: my_helper
INFO - 2020-11-02 04:37:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:37:23 --> Controller Class Initialized
INFO - 2020-11-02 04:37:23 --> Final output sent to browser
DEBUG - 2020-11-02 04:37:23 --> Total execution time: 0.3950
INFO - 2020-11-02 04:37:25 --> Config Class Initialized
INFO - 2020-11-02 04:37:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:37:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:37:25 --> Utf8 Class Initialized
INFO - 2020-11-02 04:37:25 --> URI Class Initialized
INFO - 2020-11-02 04:37:25 --> Router Class Initialized
INFO - 2020-11-02 04:37:25 --> Output Class Initialized
INFO - 2020-11-02 04:37:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:37:25 --> Input Class Initialized
INFO - 2020-11-02 04:37:25 --> Language Class Initialized
INFO - 2020-11-02 04:37:25 --> Language Class Initialized
INFO - 2020-11-02 04:37:25 --> Config Class Initialized
INFO - 2020-11-02 04:37:25 --> Loader Class Initialized
INFO - 2020-11-02 04:37:25 --> Helper loaded: url_helper
INFO - 2020-11-02 04:37:25 --> Helper loaded: file_helper
INFO - 2020-11-02 04:37:25 --> Helper loaded: form_helper
INFO - 2020-11-02 04:37:25 --> Helper loaded: my_helper
INFO - 2020-11-02 04:37:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:37:25 --> Controller Class Initialized
INFO - 2020-11-02 04:37:25 --> Final output sent to browser
DEBUG - 2020-11-02 04:37:25 --> Total execution time: 0.3354
INFO - 2020-11-02 04:37:31 --> Config Class Initialized
INFO - 2020-11-02 04:37:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:37:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:37:31 --> Utf8 Class Initialized
INFO - 2020-11-02 04:37:31 --> URI Class Initialized
INFO - 2020-11-02 04:37:31 --> Router Class Initialized
INFO - 2020-11-02 04:37:31 --> Output Class Initialized
INFO - 2020-11-02 04:37:31 --> Security Class Initialized
DEBUG - 2020-11-02 04:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:37:31 --> Input Class Initialized
INFO - 2020-11-02 04:37:31 --> Language Class Initialized
INFO - 2020-11-02 04:37:31 --> Language Class Initialized
INFO - 2020-11-02 04:37:31 --> Config Class Initialized
INFO - 2020-11-02 04:37:31 --> Loader Class Initialized
INFO - 2020-11-02 04:37:31 --> Helper loaded: url_helper
INFO - 2020-11-02 04:37:31 --> Helper loaded: file_helper
INFO - 2020-11-02 04:37:31 --> Helper loaded: form_helper
INFO - 2020-11-02 04:37:31 --> Helper loaded: my_helper
INFO - 2020-11-02 04:37:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:37:31 --> Controller Class Initialized
INFO - 2020-11-02 04:37:31 --> Final output sent to browser
DEBUG - 2020-11-02 04:37:31 --> Total execution time: 0.3757
INFO - 2020-11-02 04:37:35 --> Config Class Initialized
INFO - 2020-11-02 04:37:35 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:37:35 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:37:35 --> Utf8 Class Initialized
INFO - 2020-11-02 04:37:35 --> URI Class Initialized
INFO - 2020-11-02 04:37:35 --> Router Class Initialized
INFO - 2020-11-02 04:37:35 --> Output Class Initialized
INFO - 2020-11-02 04:37:35 --> Security Class Initialized
DEBUG - 2020-11-02 04:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:37:35 --> Input Class Initialized
INFO - 2020-11-02 04:37:35 --> Language Class Initialized
INFO - 2020-11-02 04:37:35 --> Language Class Initialized
INFO - 2020-11-02 04:37:35 --> Config Class Initialized
INFO - 2020-11-02 04:37:35 --> Loader Class Initialized
INFO - 2020-11-02 04:37:35 --> Helper loaded: url_helper
INFO - 2020-11-02 04:37:35 --> Helper loaded: file_helper
INFO - 2020-11-02 04:37:35 --> Helper loaded: form_helper
INFO - 2020-11-02 04:37:35 --> Helper loaded: my_helper
INFO - 2020-11-02 04:37:35 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:37:35 --> Controller Class Initialized
DEBUG - 2020-11-02 04:37:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:37:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:37:35 --> Final output sent to browser
DEBUG - 2020-11-02 04:37:35 --> Total execution time: 0.3240
INFO - 2020-11-02 04:37:36 --> Config Class Initialized
INFO - 2020-11-02 04:37:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:37:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:37:36 --> Utf8 Class Initialized
INFO - 2020-11-02 04:37:36 --> URI Class Initialized
INFO - 2020-11-02 04:37:36 --> Router Class Initialized
INFO - 2020-11-02 04:37:36 --> Output Class Initialized
INFO - 2020-11-02 04:37:36 --> Security Class Initialized
DEBUG - 2020-11-02 04:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:37:36 --> Input Class Initialized
INFO - 2020-11-02 04:37:36 --> Language Class Initialized
INFO - 2020-11-02 04:37:36 --> Language Class Initialized
INFO - 2020-11-02 04:37:36 --> Config Class Initialized
INFO - 2020-11-02 04:37:37 --> Loader Class Initialized
INFO - 2020-11-02 04:37:37 --> Helper loaded: url_helper
INFO - 2020-11-02 04:37:37 --> Helper loaded: file_helper
INFO - 2020-11-02 04:37:37 --> Helper loaded: form_helper
INFO - 2020-11-02 04:37:37 --> Helper loaded: my_helper
INFO - 2020-11-02 04:37:37 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:37:37 --> Controller Class Initialized
DEBUG - 2020-11-02 04:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:37:37 --> Final output sent to browser
DEBUG - 2020-11-02 04:37:37 --> Total execution time: 0.3368
INFO - 2020-11-02 04:37:48 --> Config Class Initialized
INFO - 2020-11-02 04:37:48 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:37:48 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:37:48 --> Utf8 Class Initialized
INFO - 2020-11-02 04:37:48 --> URI Class Initialized
INFO - 2020-11-02 04:37:48 --> Router Class Initialized
INFO - 2020-11-02 04:37:48 --> Output Class Initialized
INFO - 2020-11-02 04:37:48 --> Security Class Initialized
DEBUG - 2020-11-02 04:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:37:48 --> Input Class Initialized
INFO - 2020-11-02 04:37:48 --> Language Class Initialized
INFO - 2020-11-02 04:37:48 --> Language Class Initialized
INFO - 2020-11-02 04:37:48 --> Config Class Initialized
INFO - 2020-11-02 04:37:48 --> Loader Class Initialized
INFO - 2020-11-02 04:37:48 --> Helper loaded: url_helper
INFO - 2020-11-02 04:37:48 --> Helper loaded: file_helper
INFO - 2020-11-02 04:37:48 --> Helper loaded: form_helper
INFO - 2020-11-02 04:37:48 --> Helper loaded: my_helper
INFO - 2020-11-02 04:37:48 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:37:48 --> Controller Class Initialized
INFO - 2020-11-02 04:37:48 --> Final output sent to browser
DEBUG - 2020-11-02 04:37:48 --> Total execution time: 0.3154
INFO - 2020-11-02 04:38:04 --> Config Class Initialized
INFO - 2020-11-02 04:38:04 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:04 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:04 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:04 --> URI Class Initialized
INFO - 2020-11-02 04:38:04 --> Router Class Initialized
INFO - 2020-11-02 04:38:04 --> Output Class Initialized
INFO - 2020-11-02 04:38:04 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:04 --> Input Class Initialized
INFO - 2020-11-02 04:38:04 --> Language Class Initialized
INFO - 2020-11-02 04:38:04 --> Language Class Initialized
INFO - 2020-11-02 04:38:04 --> Config Class Initialized
INFO - 2020-11-02 04:38:04 --> Loader Class Initialized
INFO - 2020-11-02 04:38:04 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:04 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:04 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:04 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:04 --> Controller Class Initialized
INFO - 2020-11-02 04:38:04 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:04 --> Total execution time: 0.3367
INFO - 2020-11-02 04:38:04 --> Config Class Initialized
INFO - 2020-11-02 04:38:04 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:04 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:04 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:04 --> URI Class Initialized
INFO - 2020-11-02 04:38:04 --> Router Class Initialized
INFO - 2020-11-02 04:38:04 --> Output Class Initialized
INFO - 2020-11-02 04:38:04 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:04 --> Input Class Initialized
INFO - 2020-11-02 04:38:04 --> Language Class Initialized
INFO - 2020-11-02 04:38:04 --> Language Class Initialized
INFO - 2020-11-02 04:38:04 --> Config Class Initialized
INFO - 2020-11-02 04:38:04 --> Loader Class Initialized
INFO - 2020-11-02 04:38:04 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:04 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:04 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:04 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:04 --> Controller Class Initialized
DEBUG - 2020-11-02 04:38:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:38:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:38:04 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:04 --> Total execution time: 0.3483
INFO - 2020-11-02 04:38:06 --> Config Class Initialized
INFO - 2020-11-02 04:38:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:06 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:06 --> URI Class Initialized
INFO - 2020-11-02 04:38:06 --> Router Class Initialized
INFO - 2020-11-02 04:38:06 --> Output Class Initialized
INFO - 2020-11-02 04:38:06 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:06 --> Input Class Initialized
INFO - 2020-11-02 04:38:06 --> Language Class Initialized
INFO - 2020-11-02 04:38:06 --> Language Class Initialized
INFO - 2020-11-02 04:38:06 --> Config Class Initialized
INFO - 2020-11-02 04:38:06 --> Loader Class Initialized
INFO - 2020-11-02 04:38:06 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:06 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:06 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:06 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:06 --> Controller Class Initialized
INFO - 2020-11-02 04:38:06 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:06 --> Total execution time: 0.2897
INFO - 2020-11-02 04:38:13 --> Config Class Initialized
INFO - 2020-11-02 04:38:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:13 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:13 --> URI Class Initialized
INFO - 2020-11-02 04:38:13 --> Router Class Initialized
INFO - 2020-11-02 04:38:13 --> Output Class Initialized
INFO - 2020-11-02 04:38:13 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:13 --> Input Class Initialized
INFO - 2020-11-02 04:38:13 --> Language Class Initialized
INFO - 2020-11-02 04:38:13 --> Language Class Initialized
INFO - 2020-11-02 04:38:13 --> Config Class Initialized
INFO - 2020-11-02 04:38:13 --> Loader Class Initialized
INFO - 2020-11-02 04:38:13 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:13 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:13 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:13 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:13 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:13 --> Controller Class Initialized
INFO - 2020-11-02 04:38:14 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:14 --> Total execution time: 0.3981
INFO - 2020-11-02 04:38:21 --> Config Class Initialized
INFO - 2020-11-02 04:38:21 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:21 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:21 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:21 --> URI Class Initialized
INFO - 2020-11-02 04:38:21 --> Router Class Initialized
INFO - 2020-11-02 04:38:21 --> Output Class Initialized
INFO - 2020-11-02 04:38:21 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:21 --> Input Class Initialized
INFO - 2020-11-02 04:38:21 --> Language Class Initialized
INFO - 2020-11-02 04:38:21 --> Language Class Initialized
INFO - 2020-11-02 04:38:21 --> Config Class Initialized
INFO - 2020-11-02 04:38:21 --> Loader Class Initialized
INFO - 2020-11-02 04:38:21 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:21 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:21 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:21 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:21 --> Controller Class Initialized
INFO - 2020-11-02 04:38:21 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:38:21 --> Config Class Initialized
INFO - 2020-11-02 04:38:21 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:21 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:21 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:21 --> URI Class Initialized
INFO - 2020-11-02 04:38:21 --> Router Class Initialized
INFO - 2020-11-02 04:38:21 --> Output Class Initialized
INFO - 2020-11-02 04:38:21 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:21 --> Input Class Initialized
INFO - 2020-11-02 04:38:21 --> Language Class Initialized
INFO - 2020-11-02 04:38:21 --> Language Class Initialized
INFO - 2020-11-02 04:38:21 --> Config Class Initialized
INFO - 2020-11-02 04:38:21 --> Loader Class Initialized
INFO - 2020-11-02 04:38:21 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:21 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:21 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:21 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:21 --> Controller Class Initialized
DEBUG - 2020-11-02 04:38:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 04:38:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:38:21 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:21 --> Total execution time: 0.3255
INFO - 2020-11-02 04:38:29 --> Config Class Initialized
INFO - 2020-11-02 04:38:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:29 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:29 --> URI Class Initialized
INFO - 2020-11-02 04:38:29 --> Router Class Initialized
INFO - 2020-11-02 04:38:29 --> Output Class Initialized
INFO - 2020-11-02 04:38:29 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:29 --> Input Class Initialized
INFO - 2020-11-02 04:38:29 --> Language Class Initialized
INFO - 2020-11-02 04:38:29 --> Language Class Initialized
INFO - 2020-11-02 04:38:29 --> Config Class Initialized
INFO - 2020-11-02 04:38:29 --> Loader Class Initialized
INFO - 2020-11-02 04:38:29 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:29 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:29 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:29 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:29 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:29 --> Controller Class Initialized
INFO - 2020-11-02 04:38:29 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:38:29 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:29 --> Total execution time: 0.3264
INFO - 2020-11-02 04:38:30 --> Config Class Initialized
INFO - 2020-11-02 04:38:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:30 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:30 --> URI Class Initialized
INFO - 2020-11-02 04:38:30 --> Router Class Initialized
INFO - 2020-11-02 04:38:30 --> Output Class Initialized
INFO - 2020-11-02 04:38:30 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:30 --> Input Class Initialized
INFO - 2020-11-02 04:38:30 --> Language Class Initialized
INFO - 2020-11-02 04:38:30 --> Language Class Initialized
INFO - 2020-11-02 04:38:30 --> Config Class Initialized
INFO - 2020-11-02 04:38:30 --> Loader Class Initialized
INFO - 2020-11-02 04:38:30 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:30 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:30 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:30 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:30 --> Controller Class Initialized
DEBUG - 2020-11-02 04:38:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 04:38:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:38:31 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:31 --> Total execution time: 0.3605
INFO - 2020-11-02 04:38:32 --> Config Class Initialized
INFO - 2020-11-02 04:38:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:32 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:32 --> URI Class Initialized
INFO - 2020-11-02 04:38:32 --> Router Class Initialized
INFO - 2020-11-02 04:38:32 --> Output Class Initialized
INFO - 2020-11-02 04:38:32 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:32 --> Input Class Initialized
INFO - 2020-11-02 04:38:32 --> Language Class Initialized
INFO - 2020-11-02 04:38:32 --> Language Class Initialized
INFO - 2020-11-02 04:38:32 --> Config Class Initialized
INFO - 2020-11-02 04:38:32 --> Loader Class Initialized
INFO - 2020-11-02 04:38:32 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:32 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:32 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:32 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:32 --> Controller Class Initialized
DEBUG - 2020-11-02 04:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:38:32 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:32 --> Total execution time: 0.3560
INFO - 2020-11-02 04:38:33 --> Config Class Initialized
INFO - 2020-11-02 04:38:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:33 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:33 --> URI Class Initialized
INFO - 2020-11-02 04:38:33 --> Router Class Initialized
INFO - 2020-11-02 04:38:33 --> Output Class Initialized
INFO - 2020-11-02 04:38:33 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:33 --> Input Class Initialized
INFO - 2020-11-02 04:38:33 --> Language Class Initialized
INFO - 2020-11-02 04:38:33 --> Language Class Initialized
INFO - 2020-11-02 04:38:33 --> Config Class Initialized
INFO - 2020-11-02 04:38:33 --> Loader Class Initialized
INFO - 2020-11-02 04:38:33 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:33 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:33 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:33 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:33 --> Controller Class Initialized
DEBUG - 2020-11-02 04:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:38:33 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:33 --> Total execution time: 0.3300
INFO - 2020-11-02 04:38:33 --> Config Class Initialized
INFO - 2020-11-02 04:38:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:34 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:34 --> URI Class Initialized
INFO - 2020-11-02 04:38:34 --> Router Class Initialized
INFO - 2020-11-02 04:38:34 --> Output Class Initialized
INFO - 2020-11-02 04:38:34 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:34 --> Input Class Initialized
INFO - 2020-11-02 04:38:34 --> Language Class Initialized
INFO - 2020-11-02 04:38:34 --> Language Class Initialized
INFO - 2020-11-02 04:38:34 --> Config Class Initialized
INFO - 2020-11-02 04:38:34 --> Loader Class Initialized
INFO - 2020-11-02 04:38:34 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:34 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:34 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:34 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:34 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:34 --> Controller Class Initialized
INFO - 2020-11-02 04:38:36 --> Config Class Initialized
INFO - 2020-11-02 04:38:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:38:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:38:36 --> Utf8 Class Initialized
INFO - 2020-11-02 04:38:36 --> URI Class Initialized
INFO - 2020-11-02 04:38:36 --> Router Class Initialized
INFO - 2020-11-02 04:38:36 --> Output Class Initialized
INFO - 2020-11-02 04:38:36 --> Security Class Initialized
DEBUG - 2020-11-02 04:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:38:36 --> Input Class Initialized
INFO - 2020-11-02 04:38:36 --> Language Class Initialized
INFO - 2020-11-02 04:38:36 --> Language Class Initialized
INFO - 2020-11-02 04:38:36 --> Config Class Initialized
INFO - 2020-11-02 04:38:36 --> Loader Class Initialized
INFO - 2020-11-02 04:38:36 --> Helper loaded: url_helper
INFO - 2020-11-02 04:38:36 --> Helper loaded: file_helper
INFO - 2020-11-02 04:38:36 --> Helper loaded: form_helper
INFO - 2020-11-02 04:38:36 --> Helper loaded: my_helper
INFO - 2020-11-02 04:38:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:38:36 --> Controller Class Initialized
INFO - 2020-11-02 04:38:36 --> Final output sent to browser
DEBUG - 2020-11-02 04:38:37 --> Total execution time: 0.3317
INFO - 2020-11-02 04:39:00 --> Config Class Initialized
INFO - 2020-11-02 04:39:00 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:00 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:00 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:00 --> URI Class Initialized
INFO - 2020-11-02 04:39:00 --> Router Class Initialized
INFO - 2020-11-02 04:39:00 --> Output Class Initialized
INFO - 2020-11-02 04:39:00 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:00 --> Input Class Initialized
INFO - 2020-11-02 04:39:00 --> Language Class Initialized
INFO - 2020-11-02 04:39:00 --> Language Class Initialized
INFO - 2020-11-02 04:39:00 --> Config Class Initialized
INFO - 2020-11-02 04:39:00 --> Loader Class Initialized
INFO - 2020-11-02 04:39:00 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:00 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:00 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:00 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:00 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:00 --> Controller Class Initialized
INFO - 2020-11-02 04:39:00 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:00 --> Total execution time: 0.3465
INFO - 2020-11-02 04:39:00 --> Config Class Initialized
INFO - 2020-11-02 04:39:00 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:00 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:00 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:00 --> URI Class Initialized
INFO - 2020-11-02 04:39:00 --> Router Class Initialized
INFO - 2020-11-02 04:39:00 --> Output Class Initialized
INFO - 2020-11-02 04:39:00 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:00 --> Input Class Initialized
INFO - 2020-11-02 04:39:00 --> Language Class Initialized
INFO - 2020-11-02 04:39:00 --> Language Class Initialized
INFO - 2020-11-02 04:39:00 --> Config Class Initialized
INFO - 2020-11-02 04:39:00 --> Loader Class Initialized
INFO - 2020-11-02 04:39:00 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:00 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:00 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:00 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:00 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:01 --> Controller Class Initialized
INFO - 2020-11-02 04:39:02 --> Config Class Initialized
INFO - 2020-11-02 04:39:02 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:02 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:02 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:02 --> URI Class Initialized
INFO - 2020-11-02 04:39:02 --> Router Class Initialized
INFO - 2020-11-02 04:39:02 --> Output Class Initialized
INFO - 2020-11-02 04:39:02 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:02 --> Input Class Initialized
INFO - 2020-11-02 04:39:02 --> Language Class Initialized
INFO - 2020-11-02 04:39:02 --> Language Class Initialized
INFO - 2020-11-02 04:39:02 --> Config Class Initialized
INFO - 2020-11-02 04:39:02 --> Loader Class Initialized
INFO - 2020-11-02 04:39:02 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:02 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:02 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:02 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:02 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:02 --> Controller Class Initialized
INFO - 2020-11-02 04:39:02 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:02 --> Total execution time: 0.2873
INFO - 2020-11-02 04:39:16 --> Config Class Initialized
INFO - 2020-11-02 04:39:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:16 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:16 --> URI Class Initialized
INFO - 2020-11-02 04:39:16 --> Router Class Initialized
INFO - 2020-11-02 04:39:16 --> Output Class Initialized
INFO - 2020-11-02 04:39:16 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:16 --> Input Class Initialized
INFO - 2020-11-02 04:39:16 --> Language Class Initialized
INFO - 2020-11-02 04:39:16 --> Language Class Initialized
INFO - 2020-11-02 04:39:16 --> Config Class Initialized
INFO - 2020-11-02 04:39:16 --> Loader Class Initialized
INFO - 2020-11-02 04:39:16 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:16 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:16 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:16 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:16 --> Controller Class Initialized
INFO - 2020-11-02 04:39:16 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:16 --> Total execution time: 0.4035
INFO - 2020-11-02 04:39:18 --> Config Class Initialized
INFO - 2020-11-02 04:39:18 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:18 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:18 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:18 --> URI Class Initialized
INFO - 2020-11-02 04:39:18 --> Router Class Initialized
INFO - 2020-11-02 04:39:18 --> Output Class Initialized
INFO - 2020-11-02 04:39:18 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:18 --> Input Class Initialized
INFO - 2020-11-02 04:39:18 --> Language Class Initialized
INFO - 2020-11-02 04:39:18 --> Language Class Initialized
INFO - 2020-11-02 04:39:18 --> Config Class Initialized
INFO - 2020-11-02 04:39:18 --> Loader Class Initialized
INFO - 2020-11-02 04:39:18 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:18 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:18 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:18 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:18 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:18 --> Controller Class Initialized
INFO - 2020-11-02 04:39:18 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:18 --> Total execution time: 0.2860
INFO - 2020-11-02 04:39:23 --> Config Class Initialized
INFO - 2020-11-02 04:39:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:23 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:23 --> URI Class Initialized
INFO - 2020-11-02 04:39:23 --> Router Class Initialized
INFO - 2020-11-02 04:39:23 --> Output Class Initialized
INFO - 2020-11-02 04:39:23 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:23 --> Input Class Initialized
INFO - 2020-11-02 04:39:23 --> Language Class Initialized
INFO - 2020-11-02 04:39:23 --> Language Class Initialized
INFO - 2020-11-02 04:39:23 --> Config Class Initialized
INFO - 2020-11-02 04:39:23 --> Loader Class Initialized
INFO - 2020-11-02 04:39:23 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:23 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:23 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:23 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:23 --> Controller Class Initialized
INFO - 2020-11-02 04:39:24 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:24 --> Total execution time: 0.4108
INFO - 2020-11-02 04:39:25 --> Config Class Initialized
INFO - 2020-11-02 04:39:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:25 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:25 --> URI Class Initialized
INFO - 2020-11-02 04:39:25 --> Router Class Initialized
INFO - 2020-11-02 04:39:25 --> Output Class Initialized
INFO - 2020-11-02 04:39:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:25 --> Input Class Initialized
INFO - 2020-11-02 04:39:25 --> Language Class Initialized
INFO - 2020-11-02 04:39:25 --> Language Class Initialized
INFO - 2020-11-02 04:39:25 --> Config Class Initialized
INFO - 2020-11-02 04:39:25 --> Loader Class Initialized
INFO - 2020-11-02 04:39:25 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:25 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:25 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:25 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:25 --> Controller Class Initialized
INFO - 2020-11-02 04:39:25 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:25 --> Total execution time: 0.2988
INFO - 2020-11-02 04:39:30 --> Config Class Initialized
INFO - 2020-11-02 04:39:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:30 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:30 --> URI Class Initialized
INFO - 2020-11-02 04:39:30 --> Router Class Initialized
INFO - 2020-11-02 04:39:30 --> Output Class Initialized
INFO - 2020-11-02 04:39:30 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:30 --> Input Class Initialized
INFO - 2020-11-02 04:39:30 --> Language Class Initialized
INFO - 2020-11-02 04:39:30 --> Language Class Initialized
INFO - 2020-11-02 04:39:31 --> Config Class Initialized
INFO - 2020-11-02 04:39:31 --> Loader Class Initialized
INFO - 2020-11-02 04:39:31 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:31 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:31 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:31 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:31 --> Controller Class Initialized
INFO - 2020-11-02 04:39:31 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:31 --> Total execution time: 0.4606
INFO - 2020-11-02 04:39:33 --> Config Class Initialized
INFO - 2020-11-02 04:39:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:33 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:33 --> URI Class Initialized
INFO - 2020-11-02 04:39:33 --> Router Class Initialized
INFO - 2020-11-02 04:39:33 --> Output Class Initialized
INFO - 2020-11-02 04:39:33 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:33 --> Input Class Initialized
INFO - 2020-11-02 04:39:33 --> Language Class Initialized
INFO - 2020-11-02 04:39:33 --> Language Class Initialized
INFO - 2020-11-02 04:39:33 --> Config Class Initialized
INFO - 2020-11-02 04:39:33 --> Loader Class Initialized
INFO - 2020-11-02 04:39:33 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:33 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:33 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:33 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:33 --> Controller Class Initialized
DEBUG - 2020-11-02 04:39:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:39:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:39:33 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:33 --> Total execution time: 0.3381
INFO - 2020-11-02 04:39:34 --> Config Class Initialized
INFO - 2020-11-02 04:39:34 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:34 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:34 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:34 --> URI Class Initialized
INFO - 2020-11-02 04:39:34 --> Router Class Initialized
INFO - 2020-11-02 04:39:34 --> Output Class Initialized
INFO - 2020-11-02 04:39:34 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:34 --> Input Class Initialized
INFO - 2020-11-02 04:39:34 --> Language Class Initialized
INFO - 2020-11-02 04:39:34 --> Language Class Initialized
INFO - 2020-11-02 04:39:34 --> Config Class Initialized
INFO - 2020-11-02 04:39:34 --> Loader Class Initialized
INFO - 2020-11-02 04:39:34 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:34 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:34 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:34 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:34 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:34 --> Controller Class Initialized
DEBUG - 2020-11-02 04:39:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:39:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:39:34 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:34 --> Total execution time: 0.3318
INFO - 2020-11-02 04:39:35 --> Config Class Initialized
INFO - 2020-11-02 04:39:35 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:35 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:35 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:35 --> URI Class Initialized
INFO - 2020-11-02 04:39:35 --> Router Class Initialized
INFO - 2020-11-02 04:39:35 --> Output Class Initialized
INFO - 2020-11-02 04:39:35 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:35 --> Input Class Initialized
INFO - 2020-11-02 04:39:35 --> Language Class Initialized
INFO - 2020-11-02 04:39:36 --> Language Class Initialized
INFO - 2020-11-02 04:39:36 --> Config Class Initialized
INFO - 2020-11-02 04:39:36 --> Loader Class Initialized
INFO - 2020-11-02 04:39:36 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:36 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:36 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:36 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:36 --> Controller Class Initialized
INFO - 2020-11-02 04:39:36 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:36 --> Total execution time: 0.3542
INFO - 2020-11-02 04:39:47 --> Config Class Initialized
INFO - 2020-11-02 04:39:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:47 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:47 --> URI Class Initialized
INFO - 2020-11-02 04:39:47 --> Router Class Initialized
INFO - 2020-11-02 04:39:47 --> Output Class Initialized
INFO - 2020-11-02 04:39:47 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:47 --> Input Class Initialized
INFO - 2020-11-02 04:39:47 --> Language Class Initialized
INFO - 2020-11-02 04:39:47 --> Language Class Initialized
INFO - 2020-11-02 04:39:47 --> Config Class Initialized
INFO - 2020-11-02 04:39:47 --> Loader Class Initialized
INFO - 2020-11-02 04:39:47 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:47 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:47 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:47 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:47 --> Controller Class Initialized
INFO - 2020-11-02 04:39:47 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:47 --> Total execution time: 0.3848
INFO - 2020-11-02 04:39:47 --> Config Class Initialized
INFO - 2020-11-02 04:39:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:47 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:47 --> URI Class Initialized
INFO - 2020-11-02 04:39:47 --> Router Class Initialized
INFO - 2020-11-02 04:39:47 --> Output Class Initialized
INFO - 2020-11-02 04:39:47 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:47 --> Input Class Initialized
INFO - 2020-11-02 04:39:47 --> Language Class Initialized
INFO - 2020-11-02 04:39:47 --> Language Class Initialized
INFO - 2020-11-02 04:39:47 --> Config Class Initialized
INFO - 2020-11-02 04:39:47 --> Loader Class Initialized
INFO - 2020-11-02 04:39:47 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:47 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:47 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:47 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:47 --> Controller Class Initialized
DEBUG - 2020-11-02 04:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:39:47 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:47 --> Total execution time: 0.3425
INFO - 2020-11-02 04:39:49 --> Config Class Initialized
INFO - 2020-11-02 04:39:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:49 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:49 --> URI Class Initialized
INFO - 2020-11-02 04:39:49 --> Router Class Initialized
INFO - 2020-11-02 04:39:49 --> Output Class Initialized
INFO - 2020-11-02 04:39:49 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:49 --> Input Class Initialized
INFO - 2020-11-02 04:39:49 --> Language Class Initialized
INFO - 2020-11-02 04:39:49 --> Language Class Initialized
INFO - 2020-11-02 04:39:49 --> Config Class Initialized
INFO - 2020-11-02 04:39:49 --> Loader Class Initialized
INFO - 2020-11-02 04:39:49 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:49 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:49 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:49 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:49 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:49 --> Controller Class Initialized
INFO - 2020-11-02 04:39:49 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:49 --> Total execution time: 0.2965
INFO - 2020-11-02 04:39:57 --> Config Class Initialized
INFO - 2020-11-02 04:39:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:39:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:39:57 --> Utf8 Class Initialized
INFO - 2020-11-02 04:39:57 --> URI Class Initialized
INFO - 2020-11-02 04:39:57 --> Router Class Initialized
INFO - 2020-11-02 04:39:57 --> Output Class Initialized
INFO - 2020-11-02 04:39:57 --> Security Class Initialized
DEBUG - 2020-11-02 04:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:39:57 --> Input Class Initialized
INFO - 2020-11-02 04:39:57 --> Language Class Initialized
INFO - 2020-11-02 04:39:57 --> Language Class Initialized
INFO - 2020-11-02 04:39:57 --> Config Class Initialized
INFO - 2020-11-02 04:39:57 --> Loader Class Initialized
INFO - 2020-11-02 04:39:57 --> Helper loaded: url_helper
INFO - 2020-11-02 04:39:57 --> Helper loaded: file_helper
INFO - 2020-11-02 04:39:57 --> Helper loaded: form_helper
INFO - 2020-11-02 04:39:57 --> Helper loaded: my_helper
INFO - 2020-11-02 04:39:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:39:57 --> Controller Class Initialized
INFO - 2020-11-02 04:39:57 --> Final output sent to browser
DEBUG - 2020-11-02 04:39:57 --> Total execution time: 0.4371
INFO - 2020-11-02 04:40:03 --> Config Class Initialized
INFO - 2020-11-02 04:40:03 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:03 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:03 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:03 --> URI Class Initialized
INFO - 2020-11-02 04:40:03 --> Router Class Initialized
INFO - 2020-11-02 04:40:03 --> Output Class Initialized
INFO - 2020-11-02 04:40:03 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:03 --> Input Class Initialized
INFO - 2020-11-02 04:40:03 --> Language Class Initialized
INFO - 2020-11-02 04:40:03 --> Language Class Initialized
INFO - 2020-11-02 04:40:03 --> Config Class Initialized
INFO - 2020-11-02 04:40:03 --> Loader Class Initialized
INFO - 2020-11-02 04:40:03 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:03 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:03 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:03 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:03 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:03 --> Controller Class Initialized
INFO - 2020-11-02 04:40:03 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:40:03 --> Config Class Initialized
INFO - 2020-11-02 04:40:03 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:03 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:03 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:03 --> URI Class Initialized
INFO - 2020-11-02 04:40:03 --> Router Class Initialized
INFO - 2020-11-02 04:40:03 --> Output Class Initialized
INFO - 2020-11-02 04:40:03 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:03 --> Input Class Initialized
INFO - 2020-11-02 04:40:03 --> Language Class Initialized
INFO - 2020-11-02 04:40:03 --> Language Class Initialized
INFO - 2020-11-02 04:40:03 --> Config Class Initialized
INFO - 2020-11-02 04:40:03 --> Loader Class Initialized
INFO - 2020-11-02 04:40:04 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:04 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:04 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:04 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:04 --> Controller Class Initialized
DEBUG - 2020-11-02 04:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 04:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:40:04 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:04 --> Total execution time: 0.3335
INFO - 2020-11-02 04:40:13 --> Config Class Initialized
INFO - 2020-11-02 04:40:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:13 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:13 --> URI Class Initialized
INFO - 2020-11-02 04:40:13 --> Router Class Initialized
INFO - 2020-11-02 04:40:13 --> Output Class Initialized
INFO - 2020-11-02 04:40:13 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:13 --> Input Class Initialized
INFO - 2020-11-02 04:40:13 --> Language Class Initialized
INFO - 2020-11-02 04:40:13 --> Language Class Initialized
INFO - 2020-11-02 04:40:13 --> Config Class Initialized
INFO - 2020-11-02 04:40:13 --> Loader Class Initialized
INFO - 2020-11-02 04:40:13 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:13 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:13 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:13 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:13 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:13 --> Controller Class Initialized
INFO - 2020-11-02 04:40:13 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:40:13 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:13 --> Total execution time: 0.3635
INFO - 2020-11-02 04:40:14 --> Config Class Initialized
INFO - 2020-11-02 04:40:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:14 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:14 --> URI Class Initialized
INFO - 2020-11-02 04:40:14 --> Router Class Initialized
INFO - 2020-11-02 04:40:14 --> Output Class Initialized
INFO - 2020-11-02 04:40:14 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:14 --> Input Class Initialized
INFO - 2020-11-02 04:40:14 --> Language Class Initialized
INFO - 2020-11-02 04:40:14 --> Language Class Initialized
INFO - 2020-11-02 04:40:14 --> Config Class Initialized
INFO - 2020-11-02 04:40:14 --> Loader Class Initialized
INFO - 2020-11-02 04:40:14 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:14 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:14 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:14 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:14 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:14 --> Controller Class Initialized
DEBUG - 2020-11-02 04:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 04:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:40:14 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:14 --> Total execution time: 0.3829
INFO - 2020-11-02 04:40:19 --> Config Class Initialized
INFO - 2020-11-02 04:40:19 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:19 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:19 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:19 --> URI Class Initialized
INFO - 2020-11-02 04:40:19 --> Router Class Initialized
INFO - 2020-11-02 04:40:19 --> Output Class Initialized
INFO - 2020-11-02 04:40:19 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:19 --> Input Class Initialized
INFO - 2020-11-02 04:40:19 --> Language Class Initialized
INFO - 2020-11-02 04:40:19 --> Language Class Initialized
INFO - 2020-11-02 04:40:19 --> Config Class Initialized
INFO - 2020-11-02 04:40:19 --> Loader Class Initialized
INFO - 2020-11-02 04:40:19 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:19 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:19 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:19 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:19 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:19 --> Controller Class Initialized
DEBUG - 2020-11-02 04:40:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:40:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:40:19 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:19 --> Total execution time: 0.3275
INFO - 2020-11-02 04:40:20 --> Config Class Initialized
INFO - 2020-11-02 04:40:20 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:20 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:20 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:20 --> URI Class Initialized
INFO - 2020-11-02 04:40:21 --> Router Class Initialized
INFO - 2020-11-02 04:40:21 --> Output Class Initialized
INFO - 2020-11-02 04:40:21 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:21 --> Input Class Initialized
INFO - 2020-11-02 04:40:21 --> Language Class Initialized
INFO - 2020-11-02 04:40:21 --> Language Class Initialized
INFO - 2020-11-02 04:40:21 --> Config Class Initialized
INFO - 2020-11-02 04:40:21 --> Loader Class Initialized
INFO - 2020-11-02 04:40:21 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:21 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:21 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:21 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:21 --> Controller Class Initialized
DEBUG - 2020-11-02 04:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:40:21 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:21 --> Total execution time: 0.3558
INFO - 2020-11-02 04:40:21 --> Config Class Initialized
INFO - 2020-11-02 04:40:21 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:21 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:21 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:21 --> URI Class Initialized
INFO - 2020-11-02 04:40:21 --> Router Class Initialized
INFO - 2020-11-02 04:40:21 --> Output Class Initialized
INFO - 2020-11-02 04:40:21 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:21 --> Input Class Initialized
INFO - 2020-11-02 04:40:21 --> Language Class Initialized
INFO - 2020-11-02 04:40:21 --> Language Class Initialized
INFO - 2020-11-02 04:40:21 --> Config Class Initialized
INFO - 2020-11-02 04:40:21 --> Loader Class Initialized
INFO - 2020-11-02 04:40:21 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:21 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:21 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:21 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:21 --> Controller Class Initialized
INFO - 2020-11-02 04:40:28 --> Config Class Initialized
INFO - 2020-11-02 04:40:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:28 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:28 --> URI Class Initialized
INFO - 2020-11-02 04:40:28 --> Router Class Initialized
INFO - 2020-11-02 04:40:28 --> Output Class Initialized
INFO - 2020-11-02 04:40:28 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:28 --> Input Class Initialized
INFO - 2020-11-02 04:40:28 --> Language Class Initialized
INFO - 2020-11-02 04:40:28 --> Language Class Initialized
INFO - 2020-11-02 04:40:28 --> Config Class Initialized
INFO - 2020-11-02 04:40:28 --> Loader Class Initialized
INFO - 2020-11-02 04:40:28 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:28 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:28 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:28 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:28 --> Controller Class Initialized
INFO - 2020-11-02 04:40:28 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:28 --> Total execution time: 0.3074
INFO - 2020-11-02 04:40:38 --> Config Class Initialized
INFO - 2020-11-02 04:40:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:38 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:38 --> URI Class Initialized
INFO - 2020-11-02 04:40:38 --> Router Class Initialized
INFO - 2020-11-02 04:40:38 --> Output Class Initialized
INFO - 2020-11-02 04:40:38 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:38 --> Input Class Initialized
INFO - 2020-11-02 04:40:38 --> Language Class Initialized
INFO - 2020-11-02 04:40:38 --> Language Class Initialized
INFO - 2020-11-02 04:40:38 --> Config Class Initialized
INFO - 2020-11-02 04:40:38 --> Loader Class Initialized
INFO - 2020-11-02 04:40:38 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:38 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:38 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:38 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:38 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:38 --> Controller Class Initialized
INFO - 2020-11-02 04:40:38 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:38 --> Total execution time: 0.3926
INFO - 2020-11-02 04:40:38 --> Config Class Initialized
INFO - 2020-11-02 04:40:38 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:38 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:38 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:38 --> URI Class Initialized
INFO - 2020-11-02 04:40:38 --> Router Class Initialized
INFO - 2020-11-02 04:40:38 --> Output Class Initialized
INFO - 2020-11-02 04:40:38 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:39 --> Input Class Initialized
INFO - 2020-11-02 04:40:39 --> Language Class Initialized
INFO - 2020-11-02 04:40:39 --> Language Class Initialized
INFO - 2020-11-02 04:40:39 --> Config Class Initialized
INFO - 2020-11-02 04:40:39 --> Loader Class Initialized
INFO - 2020-11-02 04:40:39 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:39 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:39 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:39 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:39 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:39 --> Controller Class Initialized
INFO - 2020-11-02 04:40:41 --> Config Class Initialized
INFO - 2020-11-02 04:40:41 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:41 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:41 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:41 --> URI Class Initialized
INFO - 2020-11-02 04:40:41 --> Router Class Initialized
INFO - 2020-11-02 04:40:41 --> Output Class Initialized
INFO - 2020-11-02 04:40:41 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:41 --> Input Class Initialized
INFO - 2020-11-02 04:40:41 --> Language Class Initialized
INFO - 2020-11-02 04:40:41 --> Language Class Initialized
INFO - 2020-11-02 04:40:41 --> Config Class Initialized
INFO - 2020-11-02 04:40:41 --> Loader Class Initialized
INFO - 2020-11-02 04:40:41 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:41 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:41 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:41 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:41 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:41 --> Controller Class Initialized
INFO - 2020-11-02 04:40:41 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:41 --> Total execution time: 0.3026
INFO - 2020-11-02 04:40:54 --> Config Class Initialized
INFO - 2020-11-02 04:40:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:54 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:54 --> URI Class Initialized
INFO - 2020-11-02 04:40:54 --> Router Class Initialized
INFO - 2020-11-02 04:40:54 --> Output Class Initialized
INFO - 2020-11-02 04:40:54 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:54 --> Input Class Initialized
INFO - 2020-11-02 04:40:54 --> Language Class Initialized
INFO - 2020-11-02 04:40:54 --> Language Class Initialized
INFO - 2020-11-02 04:40:54 --> Config Class Initialized
INFO - 2020-11-02 04:40:54 --> Loader Class Initialized
INFO - 2020-11-02 04:40:54 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:54 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:54 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:54 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:54 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:54 --> Controller Class Initialized
INFO - 2020-11-02 04:40:54 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:54 --> Total execution time: 0.3769
INFO - 2020-11-02 04:40:54 --> Config Class Initialized
INFO - 2020-11-02 04:40:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:54 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:54 --> URI Class Initialized
INFO - 2020-11-02 04:40:54 --> Router Class Initialized
INFO - 2020-11-02 04:40:55 --> Output Class Initialized
INFO - 2020-11-02 04:40:55 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:55 --> Input Class Initialized
INFO - 2020-11-02 04:40:55 --> Language Class Initialized
INFO - 2020-11-02 04:40:55 --> Language Class Initialized
INFO - 2020-11-02 04:40:55 --> Config Class Initialized
INFO - 2020-11-02 04:40:55 --> Loader Class Initialized
INFO - 2020-11-02 04:40:55 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:55 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:55 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:55 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:55 --> Controller Class Initialized
INFO - 2020-11-02 04:40:56 --> Config Class Initialized
INFO - 2020-11-02 04:40:56 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:40:56 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:40:56 --> Utf8 Class Initialized
INFO - 2020-11-02 04:40:56 --> URI Class Initialized
INFO - 2020-11-02 04:40:56 --> Router Class Initialized
INFO - 2020-11-02 04:40:56 --> Output Class Initialized
INFO - 2020-11-02 04:40:56 --> Security Class Initialized
DEBUG - 2020-11-02 04:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:40:56 --> Input Class Initialized
INFO - 2020-11-02 04:40:56 --> Language Class Initialized
INFO - 2020-11-02 04:40:56 --> Language Class Initialized
INFO - 2020-11-02 04:40:56 --> Config Class Initialized
INFO - 2020-11-02 04:40:56 --> Loader Class Initialized
INFO - 2020-11-02 04:40:56 --> Helper loaded: url_helper
INFO - 2020-11-02 04:40:56 --> Helper loaded: file_helper
INFO - 2020-11-02 04:40:56 --> Helper loaded: form_helper
INFO - 2020-11-02 04:40:56 --> Helper loaded: my_helper
INFO - 2020-11-02 04:40:56 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:40:56 --> Controller Class Initialized
INFO - 2020-11-02 04:40:56 --> Final output sent to browser
DEBUG - 2020-11-02 04:40:56 --> Total execution time: 0.2948
INFO - 2020-11-02 04:41:01 --> Config Class Initialized
INFO - 2020-11-02 04:41:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:01 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:02 --> URI Class Initialized
INFO - 2020-11-02 04:41:02 --> Router Class Initialized
INFO - 2020-11-02 04:41:02 --> Output Class Initialized
INFO - 2020-11-02 04:41:02 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:02 --> Input Class Initialized
INFO - 2020-11-02 04:41:02 --> Language Class Initialized
INFO - 2020-11-02 04:41:02 --> Language Class Initialized
INFO - 2020-11-02 04:41:02 --> Config Class Initialized
INFO - 2020-11-02 04:41:02 --> Loader Class Initialized
INFO - 2020-11-02 04:41:02 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:02 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:02 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:02 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:02 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:02 --> Controller Class Initialized
INFO - 2020-11-02 04:41:02 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:02 --> Total execution time: 0.4546
INFO - 2020-11-02 04:41:04 --> Config Class Initialized
INFO - 2020-11-02 04:41:04 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:04 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:04 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:04 --> URI Class Initialized
INFO - 2020-11-02 04:41:04 --> Router Class Initialized
INFO - 2020-11-02 04:41:04 --> Output Class Initialized
INFO - 2020-11-02 04:41:04 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:04 --> Input Class Initialized
INFO - 2020-11-02 04:41:04 --> Language Class Initialized
INFO - 2020-11-02 04:41:04 --> Language Class Initialized
INFO - 2020-11-02 04:41:04 --> Config Class Initialized
INFO - 2020-11-02 04:41:04 --> Loader Class Initialized
INFO - 2020-11-02 04:41:04 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:04 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:04 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:04 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:04 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:04 --> Controller Class Initialized
INFO - 2020-11-02 04:41:04 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:04 --> Total execution time: 0.2881
INFO - 2020-11-02 04:41:10 --> Config Class Initialized
INFO - 2020-11-02 04:41:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:10 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:10 --> URI Class Initialized
INFO - 2020-11-02 04:41:10 --> Router Class Initialized
INFO - 2020-11-02 04:41:10 --> Output Class Initialized
INFO - 2020-11-02 04:41:10 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:10 --> Input Class Initialized
INFO - 2020-11-02 04:41:10 --> Language Class Initialized
INFO - 2020-11-02 04:41:10 --> Language Class Initialized
INFO - 2020-11-02 04:41:10 --> Config Class Initialized
INFO - 2020-11-02 04:41:10 --> Loader Class Initialized
INFO - 2020-11-02 04:41:10 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:10 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:10 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:10 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:10 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:10 --> Controller Class Initialized
INFO - 2020-11-02 04:41:11 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:11 --> Total execution time: 0.4215
INFO - 2020-11-02 04:41:12 --> Config Class Initialized
INFO - 2020-11-02 04:41:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:12 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:12 --> URI Class Initialized
INFO - 2020-11-02 04:41:12 --> Router Class Initialized
INFO - 2020-11-02 04:41:12 --> Output Class Initialized
INFO - 2020-11-02 04:41:12 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:12 --> Input Class Initialized
INFO - 2020-11-02 04:41:12 --> Language Class Initialized
INFO - 2020-11-02 04:41:12 --> Language Class Initialized
INFO - 2020-11-02 04:41:12 --> Config Class Initialized
INFO - 2020-11-02 04:41:12 --> Loader Class Initialized
INFO - 2020-11-02 04:41:12 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:12 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:12 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:12 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:12 --> Controller Class Initialized
INFO - 2020-11-02 04:41:12 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:13 --> Total execution time: 0.3095
INFO - 2020-11-02 04:41:20 --> Config Class Initialized
INFO - 2020-11-02 04:41:21 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:21 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:21 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:21 --> URI Class Initialized
INFO - 2020-11-02 04:41:21 --> Router Class Initialized
INFO - 2020-11-02 04:41:21 --> Output Class Initialized
INFO - 2020-11-02 04:41:21 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:21 --> Input Class Initialized
INFO - 2020-11-02 04:41:21 --> Language Class Initialized
INFO - 2020-11-02 04:41:21 --> Language Class Initialized
INFO - 2020-11-02 04:41:21 --> Config Class Initialized
INFO - 2020-11-02 04:41:21 --> Loader Class Initialized
INFO - 2020-11-02 04:41:21 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:21 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:21 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:21 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:21 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:21 --> Controller Class Initialized
INFO - 2020-11-02 04:41:21 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:21 --> Total execution time: 0.4063
INFO - 2020-11-02 04:41:23 --> Config Class Initialized
INFO - 2020-11-02 04:41:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:23 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:23 --> URI Class Initialized
INFO - 2020-11-02 04:41:23 --> Router Class Initialized
INFO - 2020-11-02 04:41:23 --> Output Class Initialized
INFO - 2020-11-02 04:41:23 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:23 --> Input Class Initialized
INFO - 2020-11-02 04:41:23 --> Language Class Initialized
INFO - 2020-11-02 04:41:23 --> Language Class Initialized
INFO - 2020-11-02 04:41:23 --> Config Class Initialized
INFO - 2020-11-02 04:41:23 --> Loader Class Initialized
INFO - 2020-11-02 04:41:23 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:23 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:23 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:23 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:23 --> Controller Class Initialized
DEBUG - 2020-11-02 04:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:41:23 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:23 --> Total execution time: 0.3405
INFO - 2020-11-02 04:41:25 --> Config Class Initialized
INFO - 2020-11-02 04:41:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:25 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:25 --> URI Class Initialized
INFO - 2020-11-02 04:41:25 --> Router Class Initialized
INFO - 2020-11-02 04:41:25 --> Output Class Initialized
INFO - 2020-11-02 04:41:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:25 --> Input Class Initialized
INFO - 2020-11-02 04:41:25 --> Language Class Initialized
INFO - 2020-11-02 04:41:25 --> Language Class Initialized
INFO - 2020-11-02 04:41:25 --> Config Class Initialized
INFO - 2020-11-02 04:41:25 --> Loader Class Initialized
INFO - 2020-11-02 04:41:25 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:25 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:25 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:25 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:25 --> Controller Class Initialized
DEBUG - 2020-11-02 04:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-02 04:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:41:25 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:25 --> Total execution time: 0.3407
INFO - 2020-11-02 04:41:25 --> Config Class Initialized
INFO - 2020-11-02 04:41:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:25 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:25 --> URI Class Initialized
INFO - 2020-11-02 04:41:25 --> Router Class Initialized
INFO - 2020-11-02 04:41:25 --> Output Class Initialized
INFO - 2020-11-02 04:41:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:26 --> Input Class Initialized
INFO - 2020-11-02 04:41:26 --> Language Class Initialized
INFO - 2020-11-02 04:41:26 --> Language Class Initialized
INFO - 2020-11-02 04:41:26 --> Config Class Initialized
INFO - 2020-11-02 04:41:26 --> Loader Class Initialized
INFO - 2020-11-02 04:41:26 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:26 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:26 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:26 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:26 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:26 --> Controller Class Initialized
INFO - 2020-11-02 04:41:28 --> Config Class Initialized
INFO - 2020-11-02 04:41:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:28 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:28 --> URI Class Initialized
INFO - 2020-11-02 04:41:28 --> Router Class Initialized
INFO - 2020-11-02 04:41:28 --> Output Class Initialized
INFO - 2020-11-02 04:41:28 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:28 --> Input Class Initialized
INFO - 2020-11-02 04:41:28 --> Language Class Initialized
INFO - 2020-11-02 04:41:28 --> Language Class Initialized
INFO - 2020-11-02 04:41:28 --> Config Class Initialized
INFO - 2020-11-02 04:41:28 --> Loader Class Initialized
INFO - 2020-11-02 04:41:28 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:28 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:28 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:28 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:28 --> Controller Class Initialized
INFO - 2020-11-02 04:41:28 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:28 --> Total execution time: 0.3163
INFO - 2020-11-02 04:41:32 --> Config Class Initialized
INFO - 2020-11-02 04:41:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:32 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:32 --> URI Class Initialized
INFO - 2020-11-02 04:41:32 --> Router Class Initialized
INFO - 2020-11-02 04:41:32 --> Output Class Initialized
INFO - 2020-11-02 04:41:32 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:32 --> Input Class Initialized
INFO - 2020-11-02 04:41:32 --> Language Class Initialized
INFO - 2020-11-02 04:41:32 --> Language Class Initialized
INFO - 2020-11-02 04:41:32 --> Config Class Initialized
INFO - 2020-11-02 04:41:32 --> Loader Class Initialized
INFO - 2020-11-02 04:41:32 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:32 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:32 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:32 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:32 --> Controller Class Initialized
INFO - 2020-11-02 04:41:32 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:32 --> Total execution time: 0.3491
INFO - 2020-11-02 04:41:32 --> Config Class Initialized
INFO - 2020-11-02 04:41:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:32 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:32 --> URI Class Initialized
INFO - 2020-11-02 04:41:32 --> Router Class Initialized
INFO - 2020-11-02 04:41:32 --> Output Class Initialized
INFO - 2020-11-02 04:41:32 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:32 --> Input Class Initialized
INFO - 2020-11-02 04:41:32 --> Language Class Initialized
INFO - 2020-11-02 04:41:32 --> Language Class Initialized
INFO - 2020-11-02 04:41:32 --> Config Class Initialized
INFO - 2020-11-02 04:41:32 --> Loader Class Initialized
INFO - 2020-11-02 04:41:32 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:32 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:32 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:32 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:33 --> Controller Class Initialized
INFO - 2020-11-02 04:41:33 --> Config Class Initialized
INFO - 2020-11-02 04:41:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:33 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:33 --> URI Class Initialized
INFO - 2020-11-02 04:41:33 --> Router Class Initialized
INFO - 2020-11-02 04:41:34 --> Output Class Initialized
INFO - 2020-11-02 04:41:34 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:34 --> Input Class Initialized
INFO - 2020-11-02 04:41:34 --> Language Class Initialized
INFO - 2020-11-02 04:41:34 --> Language Class Initialized
INFO - 2020-11-02 04:41:34 --> Config Class Initialized
INFO - 2020-11-02 04:41:34 --> Loader Class Initialized
INFO - 2020-11-02 04:41:34 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:34 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:34 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:34 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:34 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:34 --> Controller Class Initialized
DEBUG - 2020-11-02 04:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:41:34 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:34 --> Total execution time: 0.3809
INFO - 2020-11-02 04:41:35 --> Config Class Initialized
INFO - 2020-11-02 04:41:35 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:35 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:35 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:35 --> URI Class Initialized
INFO - 2020-11-02 04:41:35 --> Router Class Initialized
INFO - 2020-11-02 04:41:35 --> Output Class Initialized
INFO - 2020-11-02 04:41:35 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:35 --> Input Class Initialized
INFO - 2020-11-02 04:41:35 --> Language Class Initialized
INFO - 2020-11-02 04:41:35 --> Language Class Initialized
INFO - 2020-11-02 04:41:35 --> Config Class Initialized
INFO - 2020-11-02 04:41:35 --> Loader Class Initialized
INFO - 2020-11-02 04:41:35 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:35 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:35 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:35 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:35 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:35 --> Controller Class Initialized
DEBUG - 2020-11-02 04:41:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:41:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:41:35 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:35 --> Total execution time: 0.3460
INFO - 2020-11-02 04:41:36 --> Config Class Initialized
INFO - 2020-11-02 04:41:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:36 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:36 --> URI Class Initialized
INFO - 2020-11-02 04:41:36 --> Router Class Initialized
INFO - 2020-11-02 04:41:36 --> Output Class Initialized
INFO - 2020-11-02 04:41:36 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:36 --> Input Class Initialized
INFO - 2020-11-02 04:41:36 --> Language Class Initialized
INFO - 2020-11-02 04:41:36 --> Language Class Initialized
INFO - 2020-11-02 04:41:36 --> Config Class Initialized
INFO - 2020-11-02 04:41:36 --> Loader Class Initialized
INFO - 2020-11-02 04:41:36 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:36 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:36 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:36 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:36 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:36 --> Controller Class Initialized
INFO - 2020-11-02 04:41:36 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:36 --> Total execution time: 0.3198
INFO - 2020-11-02 04:41:46 --> Config Class Initialized
INFO - 2020-11-02 04:41:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:46 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:46 --> URI Class Initialized
INFO - 2020-11-02 04:41:46 --> Router Class Initialized
INFO - 2020-11-02 04:41:46 --> Output Class Initialized
INFO - 2020-11-02 04:41:46 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:46 --> Input Class Initialized
INFO - 2020-11-02 04:41:46 --> Language Class Initialized
INFO - 2020-11-02 04:41:46 --> Language Class Initialized
INFO - 2020-11-02 04:41:46 --> Config Class Initialized
INFO - 2020-11-02 04:41:46 --> Loader Class Initialized
INFO - 2020-11-02 04:41:46 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:46 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:46 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:46 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:46 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:46 --> Controller Class Initialized
INFO - 2020-11-02 04:41:46 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:46 --> Total execution time: 0.4126
INFO - 2020-11-02 04:41:46 --> Config Class Initialized
INFO - 2020-11-02 04:41:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:46 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:46 --> URI Class Initialized
INFO - 2020-11-02 04:41:46 --> Router Class Initialized
INFO - 2020-11-02 04:41:46 --> Output Class Initialized
INFO - 2020-11-02 04:41:46 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:47 --> Input Class Initialized
INFO - 2020-11-02 04:41:47 --> Language Class Initialized
INFO - 2020-11-02 04:41:47 --> Language Class Initialized
INFO - 2020-11-02 04:41:47 --> Config Class Initialized
INFO - 2020-11-02 04:41:47 --> Loader Class Initialized
INFO - 2020-11-02 04:41:47 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:47 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:47 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:47 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:47 --> Controller Class Initialized
DEBUG - 2020-11-02 04:41:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-02 04:41:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:41:47 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:47 --> Total execution time: 0.3745
INFO - 2020-11-02 04:41:50 --> Config Class Initialized
INFO - 2020-11-02 04:41:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:50 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:50 --> URI Class Initialized
INFO - 2020-11-02 04:41:50 --> Router Class Initialized
INFO - 2020-11-02 04:41:50 --> Output Class Initialized
INFO - 2020-11-02 04:41:50 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:50 --> Input Class Initialized
INFO - 2020-11-02 04:41:50 --> Language Class Initialized
INFO - 2020-11-02 04:41:50 --> Language Class Initialized
INFO - 2020-11-02 04:41:50 --> Config Class Initialized
INFO - 2020-11-02 04:41:50 --> Loader Class Initialized
INFO - 2020-11-02 04:41:50 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:51 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:51 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:51 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:51 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:51 --> Controller Class Initialized
INFO - 2020-11-02 04:41:51 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:51 --> Total execution time: 0.3255
INFO - 2020-11-02 04:41:57 --> Config Class Initialized
INFO - 2020-11-02 04:41:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:41:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:41:57 --> Utf8 Class Initialized
INFO - 2020-11-02 04:41:57 --> URI Class Initialized
INFO - 2020-11-02 04:41:57 --> Router Class Initialized
INFO - 2020-11-02 04:41:57 --> Output Class Initialized
INFO - 2020-11-02 04:41:57 --> Security Class Initialized
DEBUG - 2020-11-02 04:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:41:57 --> Input Class Initialized
INFO - 2020-11-02 04:41:57 --> Language Class Initialized
INFO - 2020-11-02 04:41:57 --> Language Class Initialized
INFO - 2020-11-02 04:41:57 --> Config Class Initialized
INFO - 2020-11-02 04:41:57 --> Loader Class Initialized
INFO - 2020-11-02 04:41:57 --> Helper loaded: url_helper
INFO - 2020-11-02 04:41:57 --> Helper loaded: file_helper
INFO - 2020-11-02 04:41:57 --> Helper loaded: form_helper
INFO - 2020-11-02 04:41:57 --> Helper loaded: my_helper
INFO - 2020-11-02 04:41:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:41:57 --> Controller Class Initialized
INFO - 2020-11-02 04:41:57 --> Final output sent to browser
DEBUG - 2020-11-02 04:41:57 --> Total execution time: 0.4357
INFO - 2020-11-02 04:42:05 --> Config Class Initialized
INFO - 2020-11-02 04:42:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:06 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:06 --> URI Class Initialized
INFO - 2020-11-02 04:42:06 --> Router Class Initialized
INFO - 2020-11-02 04:42:06 --> Output Class Initialized
INFO - 2020-11-02 04:42:06 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:06 --> Input Class Initialized
INFO - 2020-11-02 04:42:06 --> Language Class Initialized
INFO - 2020-11-02 04:42:06 --> Language Class Initialized
INFO - 2020-11-02 04:42:06 --> Config Class Initialized
INFO - 2020-11-02 04:42:06 --> Loader Class Initialized
INFO - 2020-11-02 04:42:06 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:06 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:06 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:06 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:06 --> Controller Class Initialized
INFO - 2020-11-02 04:42:06 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:42:06 --> Config Class Initialized
INFO - 2020-11-02 04:42:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:06 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:06 --> URI Class Initialized
INFO - 2020-11-02 04:42:06 --> Router Class Initialized
INFO - 2020-11-02 04:42:06 --> Output Class Initialized
INFO - 2020-11-02 04:42:06 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:06 --> Input Class Initialized
INFO - 2020-11-02 04:42:06 --> Language Class Initialized
INFO - 2020-11-02 04:42:06 --> Language Class Initialized
INFO - 2020-11-02 04:42:06 --> Config Class Initialized
INFO - 2020-11-02 04:42:06 --> Loader Class Initialized
INFO - 2020-11-02 04:42:06 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:06 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:06 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:06 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:06 --> Controller Class Initialized
DEBUG - 2020-11-02 04:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-02 04:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:42:06 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:06 --> Total execution time: 0.3462
INFO - 2020-11-02 04:42:11 --> Config Class Initialized
INFO - 2020-11-02 04:42:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:11 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:11 --> URI Class Initialized
INFO - 2020-11-02 04:42:11 --> Router Class Initialized
INFO - 2020-11-02 04:42:11 --> Output Class Initialized
INFO - 2020-11-02 04:42:11 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:11 --> Input Class Initialized
INFO - 2020-11-02 04:42:11 --> Language Class Initialized
INFO - 2020-11-02 04:42:11 --> Language Class Initialized
INFO - 2020-11-02 04:42:11 --> Config Class Initialized
INFO - 2020-11-02 04:42:11 --> Loader Class Initialized
INFO - 2020-11-02 04:42:11 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:11 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:11 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:11 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:11 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:11 --> Controller Class Initialized
INFO - 2020-11-02 04:42:11 --> Helper loaded: cookie_helper
INFO - 2020-11-02 04:42:11 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:11 --> Total execution time: 0.3636
INFO - 2020-11-02 04:42:12 --> Config Class Initialized
INFO - 2020-11-02 04:42:12 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:12 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:12 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:12 --> URI Class Initialized
INFO - 2020-11-02 04:42:12 --> Router Class Initialized
INFO - 2020-11-02 04:42:12 --> Output Class Initialized
INFO - 2020-11-02 04:42:12 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:12 --> Input Class Initialized
INFO - 2020-11-02 04:42:12 --> Language Class Initialized
INFO - 2020-11-02 04:42:12 --> Language Class Initialized
INFO - 2020-11-02 04:42:12 --> Config Class Initialized
INFO - 2020-11-02 04:42:12 --> Loader Class Initialized
INFO - 2020-11-02 04:42:12 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:12 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:12 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:12 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:12 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:12 --> Controller Class Initialized
DEBUG - 2020-11-02 04:42:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-02 04:42:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:42:13 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:13 --> Total execution time: 0.3969
INFO - 2020-11-02 04:42:15 --> Config Class Initialized
INFO - 2020-11-02 04:42:15 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:15 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:15 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:15 --> URI Class Initialized
INFO - 2020-11-02 04:42:15 --> Router Class Initialized
INFO - 2020-11-02 04:42:15 --> Output Class Initialized
INFO - 2020-11-02 04:42:15 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:16 --> Input Class Initialized
INFO - 2020-11-02 04:42:16 --> Language Class Initialized
INFO - 2020-11-02 04:42:16 --> Language Class Initialized
INFO - 2020-11-02 04:42:16 --> Config Class Initialized
INFO - 2020-11-02 04:42:16 --> Loader Class Initialized
INFO - 2020-11-02 04:42:16 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:16 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:16 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:16 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:16 --> Controller Class Initialized
DEBUG - 2020-11-02 04:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-02 04:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:42:16 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:16 --> Total execution time: 0.3500
INFO - 2020-11-02 04:42:17 --> Config Class Initialized
INFO - 2020-11-02 04:42:17 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:17 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:17 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:17 --> URI Class Initialized
INFO - 2020-11-02 04:42:17 --> Router Class Initialized
INFO - 2020-11-02 04:42:17 --> Output Class Initialized
INFO - 2020-11-02 04:42:17 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:17 --> Input Class Initialized
INFO - 2020-11-02 04:42:17 --> Language Class Initialized
INFO - 2020-11-02 04:42:17 --> Language Class Initialized
INFO - 2020-11-02 04:42:17 --> Config Class Initialized
INFO - 2020-11-02 04:42:17 --> Loader Class Initialized
INFO - 2020-11-02 04:42:17 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:17 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:17 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:17 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:17 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:17 --> Controller Class Initialized
DEBUG - 2020-11-02 04:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-02 04:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:42:17 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:17 --> Total execution time: 0.3553
INFO - 2020-11-02 04:42:20 --> Config Class Initialized
INFO - 2020-11-02 04:42:20 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:20 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:20 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:20 --> URI Class Initialized
INFO - 2020-11-02 04:42:20 --> Router Class Initialized
INFO - 2020-11-02 04:42:20 --> Output Class Initialized
INFO - 2020-11-02 04:42:20 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:20 --> Input Class Initialized
INFO - 2020-11-02 04:42:20 --> Language Class Initialized
INFO - 2020-11-02 04:42:20 --> Language Class Initialized
INFO - 2020-11-02 04:42:20 --> Config Class Initialized
INFO - 2020-11-02 04:42:20 --> Loader Class Initialized
INFO - 2020-11-02 04:42:20 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:20 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:20 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:20 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:20 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:20 --> Controller Class Initialized
DEBUG - 2020-11-02 04:42:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-02 04:42:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:42:20 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:20 --> Total execution time: 0.3685
INFO - 2020-11-02 04:42:22 --> Config Class Initialized
INFO - 2020-11-02 04:42:22 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:22 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:22 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:22 --> URI Class Initialized
INFO - 2020-11-02 04:42:22 --> Router Class Initialized
INFO - 2020-11-02 04:42:22 --> Output Class Initialized
INFO - 2020-11-02 04:42:22 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:22 --> Input Class Initialized
INFO - 2020-11-02 04:42:22 --> Language Class Initialized
INFO - 2020-11-02 04:42:22 --> Language Class Initialized
INFO - 2020-11-02 04:42:22 --> Config Class Initialized
INFO - 2020-11-02 04:42:22 --> Loader Class Initialized
INFO - 2020-11-02 04:42:22 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:22 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:22 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:22 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:22 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:22 --> Controller Class Initialized
DEBUG - 2020-11-02 04:42:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-02 04:42:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:42:22 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:22 --> Total execution time: 0.3708
INFO - 2020-11-02 04:42:22 --> Config Class Initialized
INFO - 2020-11-02 04:42:22 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:22 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:22 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:22 --> URI Class Initialized
INFO - 2020-11-02 04:42:22 --> Router Class Initialized
INFO - 2020-11-02 04:42:22 --> Output Class Initialized
INFO - 2020-11-02 04:42:22 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:22 --> Input Class Initialized
INFO - 2020-11-02 04:42:22 --> Language Class Initialized
INFO - 2020-11-02 04:42:23 --> Language Class Initialized
INFO - 2020-11-02 04:42:23 --> Config Class Initialized
INFO - 2020-11-02 04:42:23 --> Loader Class Initialized
INFO - 2020-11-02 04:42:23 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:23 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:23 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:23 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:23 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:23 --> Controller Class Initialized
INFO - 2020-11-02 04:42:25 --> Config Class Initialized
INFO - 2020-11-02 04:42:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:25 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:25 --> URI Class Initialized
INFO - 2020-11-02 04:42:25 --> Router Class Initialized
INFO - 2020-11-02 04:42:25 --> Output Class Initialized
INFO - 2020-11-02 04:42:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:25 --> Input Class Initialized
INFO - 2020-11-02 04:42:25 --> Language Class Initialized
INFO - 2020-11-02 04:42:25 --> Language Class Initialized
INFO - 2020-11-02 04:42:25 --> Config Class Initialized
INFO - 2020-11-02 04:42:25 --> Loader Class Initialized
INFO - 2020-11-02 04:42:25 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:25 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:25 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:25 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:25 --> Controller Class Initialized
DEBUG - 2020-11-02 04:42:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-02 04:42:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:42:25 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:25 --> Total execution time: 0.4450
INFO - 2020-11-02 04:42:28 --> Config Class Initialized
INFO - 2020-11-02 04:42:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:28 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:28 --> URI Class Initialized
INFO - 2020-11-02 04:42:28 --> Router Class Initialized
INFO - 2020-11-02 04:42:28 --> Output Class Initialized
INFO - 2020-11-02 04:42:28 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:28 --> Input Class Initialized
INFO - 2020-11-02 04:42:28 --> Language Class Initialized
INFO - 2020-11-02 04:42:28 --> Language Class Initialized
INFO - 2020-11-02 04:42:28 --> Config Class Initialized
INFO - 2020-11-02 04:42:28 --> Loader Class Initialized
INFO - 2020-11-02 04:42:28 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:28 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:28 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:28 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:28 --> Controller Class Initialized
INFO - 2020-11-02 04:42:28 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:28 --> Total execution time: 0.3148
INFO - 2020-11-02 04:42:39 --> Config Class Initialized
INFO - 2020-11-02 04:42:39 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:39 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:39 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:39 --> URI Class Initialized
INFO - 2020-11-02 04:42:39 --> Router Class Initialized
INFO - 2020-11-02 04:42:39 --> Output Class Initialized
INFO - 2020-11-02 04:42:39 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:39 --> Input Class Initialized
INFO - 2020-11-02 04:42:39 --> Language Class Initialized
INFO - 2020-11-02 04:42:39 --> Language Class Initialized
INFO - 2020-11-02 04:42:39 --> Config Class Initialized
INFO - 2020-11-02 04:42:39 --> Loader Class Initialized
INFO - 2020-11-02 04:42:39 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:39 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:39 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:39 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:39 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:39 --> Controller Class Initialized
ERROR - 2020-11-02 04:42:39 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '1', '1418', 'B', 'Cukup memuaskan, aktif mengikuti kegiatan Pramuka mingguan')
INFO - 2020-11-02 04:42:39 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-02 04:42:55 --> Config Class Initialized
INFO - 2020-11-02 04:42:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:55 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:55 --> URI Class Initialized
INFO - 2020-11-02 04:42:55 --> Router Class Initialized
INFO - 2020-11-02 04:42:55 --> Output Class Initialized
INFO - 2020-11-02 04:42:55 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:55 --> Input Class Initialized
INFO - 2020-11-02 04:42:55 --> Language Class Initialized
INFO - 2020-11-02 04:42:55 --> Language Class Initialized
INFO - 2020-11-02 04:42:55 --> Config Class Initialized
INFO - 2020-11-02 04:42:55 --> Loader Class Initialized
INFO - 2020-11-02 04:42:55 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:55 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:55 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:55 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:55 --> Controller Class Initialized
DEBUG - 2020-11-02 04:42:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-02 04:42:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:42:55 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:55 --> Total execution time: 0.3560
INFO - 2020-11-02 04:42:57 --> Config Class Initialized
INFO - 2020-11-02 04:42:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:42:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:42:57 --> Utf8 Class Initialized
INFO - 2020-11-02 04:42:57 --> URI Class Initialized
INFO - 2020-11-02 04:42:57 --> Router Class Initialized
INFO - 2020-11-02 04:42:57 --> Output Class Initialized
INFO - 2020-11-02 04:42:57 --> Security Class Initialized
DEBUG - 2020-11-02 04:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:42:57 --> Input Class Initialized
INFO - 2020-11-02 04:42:57 --> Language Class Initialized
INFO - 2020-11-02 04:42:57 --> Language Class Initialized
INFO - 2020-11-02 04:42:57 --> Config Class Initialized
INFO - 2020-11-02 04:42:57 --> Loader Class Initialized
INFO - 2020-11-02 04:42:57 --> Helper loaded: url_helper
INFO - 2020-11-02 04:42:57 --> Helper loaded: file_helper
INFO - 2020-11-02 04:42:57 --> Helper loaded: form_helper
INFO - 2020-11-02 04:42:57 --> Helper loaded: my_helper
INFO - 2020-11-02 04:42:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:42:57 --> Controller Class Initialized
INFO - 2020-11-02 04:42:57 --> Final output sent to browser
DEBUG - 2020-11-02 04:42:57 --> Total execution time: 0.3107
INFO - 2020-11-02 04:43:25 --> Config Class Initialized
INFO - 2020-11-02 04:43:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:43:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:43:25 --> Utf8 Class Initialized
INFO - 2020-11-02 04:43:25 --> URI Class Initialized
INFO - 2020-11-02 04:43:25 --> Router Class Initialized
INFO - 2020-11-02 04:43:25 --> Output Class Initialized
INFO - 2020-11-02 04:43:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:43:25 --> Input Class Initialized
INFO - 2020-11-02 04:43:25 --> Language Class Initialized
INFO - 2020-11-02 04:43:25 --> Language Class Initialized
INFO - 2020-11-02 04:43:25 --> Config Class Initialized
INFO - 2020-11-02 04:43:25 --> Loader Class Initialized
INFO - 2020-11-02 04:43:25 --> Helper loaded: url_helper
INFO - 2020-11-02 04:43:25 --> Helper loaded: file_helper
INFO - 2020-11-02 04:43:25 --> Helper loaded: form_helper
INFO - 2020-11-02 04:43:25 --> Helper loaded: my_helper
INFO - 2020-11-02 04:43:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:43:25 --> Controller Class Initialized
ERROR - 2020-11-02 04:43:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '1', '1418', 'A', 'Memuaskan, aktif megikuti kegiatan Pramuka mingguan')
INFO - 2020-11-02 04:43:25 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-02 04:44:55 --> Config Class Initialized
INFO - 2020-11-02 04:44:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:44:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:44:55 --> Utf8 Class Initialized
INFO - 2020-11-02 04:44:55 --> URI Class Initialized
INFO - 2020-11-02 04:44:55 --> Router Class Initialized
INFO - 2020-11-02 04:44:55 --> Output Class Initialized
INFO - 2020-11-02 04:44:55 --> Security Class Initialized
DEBUG - 2020-11-02 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:44:55 --> Input Class Initialized
INFO - 2020-11-02 04:44:55 --> Language Class Initialized
INFO - 2020-11-02 04:44:55 --> Language Class Initialized
INFO - 2020-11-02 04:44:55 --> Config Class Initialized
INFO - 2020-11-02 04:44:55 --> Loader Class Initialized
INFO - 2020-11-02 04:44:55 --> Helper loaded: url_helper
INFO - 2020-11-02 04:44:55 --> Helper loaded: file_helper
INFO - 2020-11-02 04:44:55 --> Helper loaded: form_helper
INFO - 2020-11-02 04:44:55 --> Helper loaded: my_helper
INFO - 2020-11-02 04:44:55 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:44:55 --> Controller Class Initialized
DEBUG - 2020-11-02 04:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-02 04:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:44:55 --> Final output sent to browser
DEBUG - 2020-11-02 04:44:55 --> Total execution time: 0.3912
INFO - 2020-11-02 04:44:56 --> Config Class Initialized
INFO - 2020-11-02 04:44:56 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:44:56 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:44:56 --> Utf8 Class Initialized
INFO - 2020-11-02 04:44:56 --> URI Class Initialized
INFO - 2020-11-02 04:44:56 --> Router Class Initialized
INFO - 2020-11-02 04:44:56 --> Output Class Initialized
INFO - 2020-11-02 04:44:57 --> Security Class Initialized
DEBUG - 2020-11-02 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:44:57 --> Input Class Initialized
INFO - 2020-11-02 04:44:57 --> Language Class Initialized
INFO - 2020-11-02 04:44:57 --> Language Class Initialized
INFO - 2020-11-02 04:44:57 --> Config Class Initialized
INFO - 2020-11-02 04:44:57 --> Loader Class Initialized
INFO - 2020-11-02 04:44:57 --> Helper loaded: url_helper
INFO - 2020-11-02 04:44:57 --> Helper loaded: file_helper
INFO - 2020-11-02 04:44:57 --> Helper loaded: form_helper
INFO - 2020-11-02 04:44:57 --> Helper loaded: my_helper
INFO - 2020-11-02 04:44:57 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:44:57 --> Controller Class Initialized
INFO - 2020-11-02 04:44:57 --> Final output sent to browser
DEBUG - 2020-11-02 04:44:57 --> Total execution time: 0.3161
INFO - 2020-11-02 04:46:01 --> Config Class Initialized
INFO - 2020-11-02 04:46:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:46:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:46:01 --> Utf8 Class Initialized
INFO - 2020-11-02 04:46:01 --> URI Class Initialized
INFO - 2020-11-02 04:46:01 --> Router Class Initialized
INFO - 2020-11-02 04:46:01 --> Output Class Initialized
INFO - 2020-11-02 04:46:02 --> Security Class Initialized
DEBUG - 2020-11-02 04:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:46:02 --> Input Class Initialized
INFO - 2020-11-02 04:46:02 --> Language Class Initialized
INFO - 2020-11-02 04:46:02 --> Language Class Initialized
INFO - 2020-11-02 04:46:02 --> Config Class Initialized
INFO - 2020-11-02 04:46:02 --> Loader Class Initialized
INFO - 2020-11-02 04:46:02 --> Helper loaded: url_helper
INFO - 2020-11-02 04:46:02 --> Helper loaded: file_helper
INFO - 2020-11-02 04:46:02 --> Helper loaded: form_helper
INFO - 2020-11-02 04:46:02 --> Helper loaded: my_helper
INFO - 2020-11-02 04:46:02 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:46:02 --> Controller Class Initialized
ERROR - 2020-11-02 04:46:02 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '1', '1418', '-', '-')
INFO - 2020-11-02 04:46:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-02 04:47:25 --> Config Class Initialized
INFO - 2020-11-02 04:47:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:25 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:25 --> URI Class Initialized
INFO - 2020-11-02 04:47:25 --> Router Class Initialized
INFO - 2020-11-02 04:47:25 --> Output Class Initialized
INFO - 2020-11-02 04:47:25 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:25 --> Input Class Initialized
INFO - 2020-11-02 04:47:25 --> Language Class Initialized
INFO - 2020-11-02 04:47:25 --> Language Class Initialized
INFO - 2020-11-02 04:47:25 --> Config Class Initialized
INFO - 2020-11-02 04:47:25 --> Loader Class Initialized
INFO - 2020-11-02 04:47:25 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:25 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:25 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:25 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:25 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:25 --> Controller Class Initialized
INFO - 2020-11-02 04:47:25 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:25 --> Total execution time: 0.3092
INFO - 2020-11-02 04:47:26 --> Config Class Initialized
INFO - 2020-11-02 04:47:26 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:26 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:26 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:26 --> URI Class Initialized
INFO - 2020-11-02 04:47:26 --> Router Class Initialized
INFO - 2020-11-02 04:47:26 --> Output Class Initialized
INFO - 2020-11-02 04:47:26 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:26 --> Input Class Initialized
INFO - 2020-11-02 04:47:26 --> Language Class Initialized
INFO - 2020-11-02 04:47:26 --> Language Class Initialized
INFO - 2020-11-02 04:47:26 --> Config Class Initialized
INFO - 2020-11-02 04:47:26 --> Loader Class Initialized
INFO - 2020-11-02 04:47:26 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:26 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:26 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:26 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:26 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:26 --> Controller Class Initialized
INFO - 2020-11-02 04:47:26 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:26 --> Total execution time: 0.3094
INFO - 2020-11-02 04:47:28 --> Config Class Initialized
INFO - 2020-11-02 04:47:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:28 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:28 --> URI Class Initialized
INFO - 2020-11-02 04:47:28 --> Router Class Initialized
INFO - 2020-11-02 04:47:28 --> Output Class Initialized
INFO - 2020-11-02 04:47:28 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:28 --> Input Class Initialized
INFO - 2020-11-02 04:47:28 --> Language Class Initialized
INFO - 2020-11-02 04:47:28 --> Language Class Initialized
INFO - 2020-11-02 04:47:28 --> Config Class Initialized
INFO - 2020-11-02 04:47:28 --> Loader Class Initialized
INFO - 2020-11-02 04:47:28 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:28 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:28 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:28 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:28 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:28 --> Controller Class Initialized
INFO - 2020-11-02 04:47:28 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:28 --> Total execution time: 0.3118
INFO - 2020-11-02 04:47:29 --> Config Class Initialized
INFO - 2020-11-02 04:47:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:29 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:29 --> URI Class Initialized
INFO - 2020-11-02 04:47:29 --> Router Class Initialized
INFO - 2020-11-02 04:47:29 --> Output Class Initialized
INFO - 2020-11-02 04:47:29 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:29 --> Input Class Initialized
INFO - 2020-11-02 04:47:29 --> Language Class Initialized
INFO - 2020-11-02 04:47:29 --> Language Class Initialized
INFO - 2020-11-02 04:47:29 --> Config Class Initialized
INFO - 2020-11-02 04:47:29 --> Loader Class Initialized
INFO - 2020-11-02 04:47:29 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:29 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:29 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:29 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:29 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:29 --> Controller Class Initialized
INFO - 2020-11-02 04:47:29 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:29 --> Total execution time: 0.3097
INFO - 2020-11-02 04:47:29 --> Config Class Initialized
INFO - 2020-11-02 04:47:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:29 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:29 --> URI Class Initialized
INFO - 2020-11-02 04:47:29 --> Router Class Initialized
INFO - 2020-11-02 04:47:29 --> Output Class Initialized
INFO - 2020-11-02 04:47:29 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:29 --> Input Class Initialized
INFO - 2020-11-02 04:47:29 --> Language Class Initialized
INFO - 2020-11-02 04:47:29 --> Language Class Initialized
INFO - 2020-11-02 04:47:29 --> Config Class Initialized
INFO - 2020-11-02 04:47:29 --> Loader Class Initialized
INFO - 2020-11-02 04:47:29 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:29 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:30 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:30 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:30 --> Controller Class Initialized
INFO - 2020-11-02 04:47:30 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:30 --> Total execution time: 0.3103
INFO - 2020-11-02 04:47:30 --> Config Class Initialized
INFO - 2020-11-02 04:47:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:30 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:30 --> URI Class Initialized
INFO - 2020-11-02 04:47:30 --> Router Class Initialized
INFO - 2020-11-02 04:47:30 --> Output Class Initialized
INFO - 2020-11-02 04:47:30 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:30 --> Input Class Initialized
INFO - 2020-11-02 04:47:30 --> Language Class Initialized
INFO - 2020-11-02 04:47:30 --> Language Class Initialized
INFO - 2020-11-02 04:47:30 --> Config Class Initialized
INFO - 2020-11-02 04:47:30 --> Loader Class Initialized
INFO - 2020-11-02 04:47:30 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:30 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:30 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:30 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:30 --> Controller Class Initialized
INFO - 2020-11-02 04:47:30 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:30 --> Total execution time: 0.3005
INFO - 2020-11-02 04:47:30 --> Config Class Initialized
INFO - 2020-11-02 04:47:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:30 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:30 --> URI Class Initialized
INFO - 2020-11-02 04:47:30 --> Router Class Initialized
INFO - 2020-11-02 04:47:30 --> Output Class Initialized
INFO - 2020-11-02 04:47:30 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:30 --> Input Class Initialized
INFO - 2020-11-02 04:47:30 --> Language Class Initialized
INFO - 2020-11-02 04:47:30 --> Language Class Initialized
INFO - 2020-11-02 04:47:30 --> Config Class Initialized
INFO - 2020-11-02 04:47:30 --> Loader Class Initialized
INFO - 2020-11-02 04:47:30 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:30 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:30 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:30 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:30 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:31 --> Controller Class Initialized
INFO - 2020-11-02 04:47:31 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:31 --> Total execution time: 0.3130
INFO - 2020-11-02 04:47:31 --> Config Class Initialized
INFO - 2020-11-02 04:47:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:31 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:31 --> URI Class Initialized
INFO - 2020-11-02 04:47:31 --> Router Class Initialized
INFO - 2020-11-02 04:47:31 --> Output Class Initialized
INFO - 2020-11-02 04:47:31 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:31 --> Input Class Initialized
INFO - 2020-11-02 04:47:31 --> Language Class Initialized
INFO - 2020-11-02 04:47:31 --> Language Class Initialized
INFO - 2020-11-02 04:47:31 --> Config Class Initialized
INFO - 2020-11-02 04:47:31 --> Loader Class Initialized
INFO - 2020-11-02 04:47:31 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:31 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:31 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:31 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:31 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:31 --> Controller Class Initialized
INFO - 2020-11-02 04:47:31 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:31 --> Total execution time: 0.3108
INFO - 2020-11-02 04:47:31 --> Config Class Initialized
INFO - 2020-11-02 04:47:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:31 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:31 --> URI Class Initialized
INFO - 2020-11-02 04:47:31 --> Router Class Initialized
INFO - 2020-11-02 04:47:31 --> Output Class Initialized
INFO - 2020-11-02 04:47:31 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:31 --> Input Class Initialized
INFO - 2020-11-02 04:47:31 --> Language Class Initialized
INFO - 2020-11-02 04:47:31 --> Language Class Initialized
INFO - 2020-11-02 04:47:31 --> Config Class Initialized
INFO - 2020-11-02 04:47:31 --> Loader Class Initialized
INFO - 2020-11-02 04:47:31 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:31 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:31 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:31 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:32 --> Controller Class Initialized
INFO - 2020-11-02 04:47:32 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:32 --> Total execution time: 0.3114
INFO - 2020-11-02 04:47:32 --> Config Class Initialized
INFO - 2020-11-02 04:47:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:32 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:32 --> URI Class Initialized
INFO - 2020-11-02 04:47:32 --> Router Class Initialized
INFO - 2020-11-02 04:47:32 --> Output Class Initialized
INFO - 2020-11-02 04:47:32 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:32 --> Input Class Initialized
INFO - 2020-11-02 04:47:32 --> Language Class Initialized
INFO - 2020-11-02 04:47:32 --> Language Class Initialized
INFO - 2020-11-02 04:47:32 --> Config Class Initialized
INFO - 2020-11-02 04:47:32 --> Loader Class Initialized
INFO - 2020-11-02 04:47:32 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:32 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:32 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:32 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:32 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:32 --> Controller Class Initialized
INFO - 2020-11-02 04:47:32 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:32 --> Total execution time: 0.3021
INFO - 2020-11-02 04:47:32 --> Config Class Initialized
INFO - 2020-11-02 04:47:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:32 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:32 --> URI Class Initialized
INFO - 2020-11-02 04:47:32 --> Router Class Initialized
INFO - 2020-11-02 04:47:32 --> Output Class Initialized
INFO - 2020-11-02 04:47:32 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:32 --> Input Class Initialized
INFO - 2020-11-02 04:47:32 --> Language Class Initialized
INFO - 2020-11-02 04:47:32 --> Language Class Initialized
INFO - 2020-11-02 04:47:32 --> Config Class Initialized
INFO - 2020-11-02 04:47:32 --> Loader Class Initialized
INFO - 2020-11-02 04:47:33 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:33 --> Controller Class Initialized
INFO - 2020-11-02 04:47:33 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:33 --> Total execution time: 0.3130
INFO - 2020-11-02 04:47:33 --> Config Class Initialized
INFO - 2020-11-02 04:47:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:33 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:33 --> URI Class Initialized
INFO - 2020-11-02 04:47:33 --> Router Class Initialized
INFO - 2020-11-02 04:47:33 --> Output Class Initialized
INFO - 2020-11-02 04:47:33 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:33 --> Input Class Initialized
INFO - 2020-11-02 04:47:33 --> Language Class Initialized
INFO - 2020-11-02 04:47:33 --> Language Class Initialized
INFO - 2020-11-02 04:47:33 --> Config Class Initialized
INFO - 2020-11-02 04:47:33 --> Loader Class Initialized
INFO - 2020-11-02 04:47:33 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:33 --> Controller Class Initialized
INFO - 2020-11-02 04:47:33 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:33 --> Total execution time: 0.3124
INFO - 2020-11-02 04:47:33 --> Config Class Initialized
INFO - 2020-11-02 04:47:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:33 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:33 --> URI Class Initialized
INFO - 2020-11-02 04:47:33 --> Router Class Initialized
INFO - 2020-11-02 04:47:33 --> Output Class Initialized
INFO - 2020-11-02 04:47:33 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:33 --> Input Class Initialized
INFO - 2020-11-02 04:47:33 --> Language Class Initialized
INFO - 2020-11-02 04:47:33 --> Language Class Initialized
INFO - 2020-11-02 04:47:33 --> Config Class Initialized
INFO - 2020-11-02 04:47:33 --> Loader Class Initialized
INFO - 2020-11-02 04:47:33 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:33 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:33 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:34 --> Controller Class Initialized
INFO - 2020-11-02 04:47:34 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:34 --> Total execution time: 0.3123
INFO - 2020-11-02 04:47:34 --> Config Class Initialized
INFO - 2020-11-02 04:47:34 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:34 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:34 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:34 --> URI Class Initialized
INFO - 2020-11-02 04:47:34 --> Router Class Initialized
INFO - 2020-11-02 04:47:34 --> Output Class Initialized
INFO - 2020-11-02 04:47:34 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:34 --> Input Class Initialized
INFO - 2020-11-02 04:47:34 --> Language Class Initialized
INFO - 2020-11-02 04:47:34 --> Language Class Initialized
INFO - 2020-11-02 04:47:34 --> Config Class Initialized
INFO - 2020-11-02 04:47:34 --> Loader Class Initialized
INFO - 2020-11-02 04:47:34 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:34 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:34 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:34 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:34 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:34 --> Controller Class Initialized
INFO - 2020-11-02 04:47:34 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:34 --> Total execution time: 0.3020
INFO - 2020-11-02 04:47:45 --> Config Class Initialized
INFO - 2020-11-02 04:47:45 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:45 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:45 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:45 --> URI Class Initialized
INFO - 2020-11-02 04:47:45 --> Router Class Initialized
INFO - 2020-11-02 04:47:45 --> Output Class Initialized
INFO - 2020-11-02 04:47:45 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:45 --> Input Class Initialized
INFO - 2020-11-02 04:47:45 --> Language Class Initialized
INFO - 2020-11-02 04:47:45 --> Language Class Initialized
INFO - 2020-11-02 04:47:45 --> Config Class Initialized
INFO - 2020-11-02 04:47:45 --> Loader Class Initialized
INFO - 2020-11-02 04:47:45 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:45 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:45 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:45 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:45 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:45 --> Controller Class Initialized
ERROR - 2020-11-02 04:47:45 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '1', '1418', '-', '-')
INFO - 2020-11-02 04:47:45 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-02 04:47:47 --> Config Class Initialized
INFO - 2020-11-02 04:47:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:47 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:47 --> URI Class Initialized
INFO - 2020-11-02 04:47:47 --> Router Class Initialized
INFO - 2020-11-02 04:47:47 --> Output Class Initialized
INFO - 2020-11-02 04:47:47 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:47 --> Input Class Initialized
INFO - 2020-11-02 04:47:47 --> Language Class Initialized
INFO - 2020-11-02 04:47:47 --> Language Class Initialized
INFO - 2020-11-02 04:47:47 --> Config Class Initialized
INFO - 2020-11-02 04:47:47 --> Loader Class Initialized
INFO - 2020-11-02 04:47:47 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:47 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:47 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:47 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:47 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:47 --> Controller Class Initialized
DEBUG - 2020-11-02 04:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-02 04:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:47:47 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:47 --> Total execution time: 0.4092
INFO - 2020-11-02 04:47:51 --> Config Class Initialized
INFO - 2020-11-02 04:47:51 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:51 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:51 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:51 --> URI Class Initialized
INFO - 2020-11-02 04:47:51 --> Router Class Initialized
INFO - 2020-11-02 04:47:51 --> Output Class Initialized
INFO - 2020-11-02 04:47:51 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:51 --> Input Class Initialized
INFO - 2020-11-02 04:47:51 --> Language Class Initialized
INFO - 2020-11-02 04:47:51 --> Language Class Initialized
INFO - 2020-11-02 04:47:51 --> Config Class Initialized
INFO - 2020-11-02 04:47:51 --> Loader Class Initialized
INFO - 2020-11-02 04:47:51 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:51 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:51 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:51 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:52 --> Controller Class Initialized
DEBUG - 2020-11-02 04:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-02 04:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:47:52 --> Final output sent to browser
DEBUG - 2020-11-02 04:47:52 --> Total execution time: 0.3725
INFO - 2020-11-02 04:47:52 --> Config Class Initialized
INFO - 2020-11-02 04:47:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:47:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:47:52 --> Utf8 Class Initialized
INFO - 2020-11-02 04:47:52 --> URI Class Initialized
INFO - 2020-11-02 04:47:52 --> Router Class Initialized
INFO - 2020-11-02 04:47:52 --> Output Class Initialized
INFO - 2020-11-02 04:47:52 --> Security Class Initialized
DEBUG - 2020-11-02 04:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:47:52 --> Input Class Initialized
INFO - 2020-11-02 04:47:52 --> Language Class Initialized
INFO - 2020-11-02 04:47:52 --> Language Class Initialized
INFO - 2020-11-02 04:47:52 --> Config Class Initialized
INFO - 2020-11-02 04:47:52 --> Loader Class Initialized
INFO - 2020-11-02 04:47:52 --> Helper loaded: url_helper
INFO - 2020-11-02 04:47:52 --> Helper loaded: file_helper
INFO - 2020-11-02 04:47:52 --> Helper loaded: form_helper
INFO - 2020-11-02 04:47:52 --> Helper loaded: my_helper
INFO - 2020-11-02 04:47:52 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:47:52 --> Controller Class Initialized
INFO - 2020-11-02 04:48:00 --> Config Class Initialized
INFO - 2020-11-02 04:48:00 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:48:00 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:48:00 --> Utf8 Class Initialized
INFO - 2020-11-02 04:48:00 --> URI Class Initialized
INFO - 2020-11-02 04:48:00 --> Router Class Initialized
INFO - 2020-11-02 04:48:00 --> Output Class Initialized
INFO - 2020-11-02 04:48:00 --> Security Class Initialized
DEBUG - 2020-11-02 04:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:48:00 --> Input Class Initialized
INFO - 2020-11-02 04:48:00 --> Language Class Initialized
INFO - 2020-11-02 04:48:00 --> Language Class Initialized
INFO - 2020-11-02 04:48:00 --> Config Class Initialized
INFO - 2020-11-02 04:48:00 --> Loader Class Initialized
INFO - 2020-11-02 04:48:00 --> Helper loaded: url_helper
INFO - 2020-11-02 04:48:00 --> Helper loaded: file_helper
INFO - 2020-11-02 04:48:00 --> Helper loaded: form_helper
INFO - 2020-11-02 04:48:00 --> Helper loaded: my_helper
INFO - 2020-11-02 04:48:00 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:48:00 --> Controller Class Initialized
DEBUG - 2020-11-02 04:48:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-02 04:48:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:48:00 --> Final output sent to browser
DEBUG - 2020-11-02 04:48:00 --> Total execution time: 0.4355
INFO - 2020-11-02 04:48:10 --> Config Class Initialized
INFO - 2020-11-02 04:48:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:48:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:48:10 --> Utf8 Class Initialized
INFO - 2020-11-02 04:48:10 --> URI Class Initialized
INFO - 2020-11-02 04:48:10 --> Router Class Initialized
INFO - 2020-11-02 04:48:10 --> Output Class Initialized
INFO - 2020-11-02 04:48:10 --> Security Class Initialized
DEBUG - 2020-11-02 04:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:48:10 --> Input Class Initialized
INFO - 2020-11-02 04:48:10 --> Language Class Initialized
INFO - 2020-11-02 04:48:10 --> Language Class Initialized
INFO - 2020-11-02 04:48:10 --> Config Class Initialized
INFO - 2020-11-02 04:48:10 --> Loader Class Initialized
INFO - 2020-11-02 04:48:10 --> Helper loaded: url_helper
INFO - 2020-11-02 04:48:10 --> Helper loaded: file_helper
INFO - 2020-11-02 04:48:10 --> Helper loaded: form_helper
INFO - 2020-11-02 04:48:10 --> Helper loaded: my_helper
INFO - 2020-11-02 04:48:10 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:48:10 --> Controller Class Initialized
DEBUG - 2020-11-02 04:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-02 04:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:48:10 --> Final output sent to browser
DEBUG - 2020-11-02 04:48:10 --> Total execution time: 0.4121
INFO - 2020-11-02 04:48:13 --> Config Class Initialized
INFO - 2020-11-02 04:48:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:48:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:48:13 --> Utf8 Class Initialized
INFO - 2020-11-02 04:48:13 --> URI Class Initialized
INFO - 2020-11-02 04:48:13 --> Router Class Initialized
INFO - 2020-11-02 04:48:13 --> Output Class Initialized
INFO - 2020-11-02 04:48:13 --> Security Class Initialized
DEBUG - 2020-11-02 04:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:48:13 --> Input Class Initialized
INFO - 2020-11-02 04:48:13 --> Language Class Initialized
INFO - 2020-11-02 04:48:13 --> Language Class Initialized
INFO - 2020-11-02 04:48:13 --> Config Class Initialized
INFO - 2020-11-02 04:48:13 --> Loader Class Initialized
INFO - 2020-11-02 04:48:13 --> Helper loaded: url_helper
INFO - 2020-11-02 04:48:13 --> Helper loaded: file_helper
INFO - 2020-11-02 04:48:13 --> Helper loaded: form_helper
INFO - 2020-11-02 04:48:13 --> Helper loaded: my_helper
INFO - 2020-11-02 04:48:13 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:48:14 --> Controller Class Initialized
DEBUG - 2020-11-02 04:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-02 04:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 04:48:14 --> Final output sent to browser
DEBUG - 2020-11-02 04:48:14 --> Total execution time: 0.3594
INFO - 2020-11-02 04:48:16 --> Config Class Initialized
INFO - 2020-11-02 04:48:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 04:48:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 04:48:16 --> Utf8 Class Initialized
INFO - 2020-11-02 04:48:16 --> URI Class Initialized
INFO - 2020-11-02 04:48:16 --> Router Class Initialized
INFO - 2020-11-02 04:48:16 --> Output Class Initialized
INFO - 2020-11-02 04:48:16 --> Security Class Initialized
DEBUG - 2020-11-02 04:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 04:48:16 --> Input Class Initialized
INFO - 2020-11-02 04:48:16 --> Language Class Initialized
INFO - 2020-11-02 04:48:16 --> Language Class Initialized
INFO - 2020-11-02 04:48:16 --> Config Class Initialized
INFO - 2020-11-02 04:48:16 --> Loader Class Initialized
INFO - 2020-11-02 04:48:16 --> Helper loaded: url_helper
INFO - 2020-11-02 04:48:16 --> Helper loaded: file_helper
INFO - 2020-11-02 04:48:16 --> Helper loaded: form_helper
INFO - 2020-11-02 04:48:16 --> Helper loaded: my_helper
INFO - 2020-11-02 04:48:16 --> Database Driver Class Initialized
DEBUG - 2020-11-02 04:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 04:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 04:48:16 --> Controller Class Initialized
ERROR - 2020-11-02 04:48:16 --> Severity: Notice --> Undefined index: prog_keahlian C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 57
ERROR - 2020-11-02 04:48:16 --> Severity: Notice --> Undefined index: komp_keahlian C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
DEBUG - 2020-11-02 04:48:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-02 04:48:16 --> Final output sent to browser
DEBUG - 2020-11-02 04:48:16 --> Total execution time: 0.4854
INFO - 2020-11-02 09:19:06 --> Config Class Initialized
INFO - 2020-11-02 09:19:06 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:19:06 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:19:06 --> Utf8 Class Initialized
INFO - 2020-11-02 09:19:06 --> URI Class Initialized
INFO - 2020-11-02 09:19:06 --> Router Class Initialized
INFO - 2020-11-02 09:19:06 --> Output Class Initialized
INFO - 2020-11-02 09:19:06 --> Security Class Initialized
DEBUG - 2020-11-02 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:19:06 --> Input Class Initialized
INFO - 2020-11-02 09:19:06 --> Language Class Initialized
INFO - 2020-11-02 09:19:06 --> Language Class Initialized
INFO - 2020-11-02 09:19:06 --> Config Class Initialized
INFO - 2020-11-02 09:19:06 --> Loader Class Initialized
INFO - 2020-11-02 09:19:06 --> Helper loaded: url_helper
INFO - 2020-11-02 09:19:06 --> Helper loaded: file_helper
INFO - 2020-11-02 09:19:06 --> Helper loaded: form_helper
INFO - 2020-11-02 09:19:06 --> Helper loaded: my_helper
INFO - 2020-11-02 09:19:06 --> Database Driver Class Initialized
DEBUG - 2020-11-02 09:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-02 09:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:19:06 --> Controller Class Initialized
DEBUG - 2020-11-02 09:19:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-02 09:19:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-02 09:19:06 --> Final output sent to browser
DEBUG - 2020-11-02 09:19:06 --> Total execution time: 0.4544
