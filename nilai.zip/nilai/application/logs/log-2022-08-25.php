<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-25 08:05:11 --> Config Class Initialized
INFO - 2022-08-25 08:05:11 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:05:11 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:05:11 --> Utf8 Class Initialized
INFO - 2022-08-25 08:05:11 --> URI Class Initialized
DEBUG - 2022-08-25 08:05:11 --> No URI present. Default controller set.
INFO - 2022-08-25 08:05:11 --> Router Class Initialized
INFO - 2022-08-25 08:05:11 --> Output Class Initialized
INFO - 2022-08-25 08:05:11 --> Security Class Initialized
DEBUG - 2022-08-25 08:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:05:11 --> Input Class Initialized
INFO - 2022-08-25 08:05:11 --> Language Class Initialized
INFO - 2022-08-25 08:05:11 --> Language Class Initialized
INFO - 2022-08-25 08:05:11 --> Config Class Initialized
INFO - 2022-08-25 08:05:11 --> Loader Class Initialized
INFO - 2022-08-25 08:05:11 --> Helper loaded: url_helper
INFO - 2022-08-25 08:05:11 --> Helper loaded: file_helper
INFO - 2022-08-25 08:05:11 --> Helper loaded: form_helper
INFO - 2022-08-25 08:05:11 --> Helper loaded: my_helper
INFO - 2022-08-25 08:05:11 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:05:11 --> Controller Class Initialized
INFO - 2022-08-25 08:05:11 --> Config Class Initialized
INFO - 2022-08-25 08:05:11 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:05:11 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:05:11 --> Utf8 Class Initialized
INFO - 2022-08-25 08:05:11 --> URI Class Initialized
INFO - 2022-08-25 08:05:11 --> Router Class Initialized
INFO - 2022-08-25 08:05:11 --> Output Class Initialized
INFO - 2022-08-25 08:05:11 --> Security Class Initialized
DEBUG - 2022-08-25 08:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:05:11 --> Input Class Initialized
INFO - 2022-08-25 08:05:11 --> Language Class Initialized
INFO - 2022-08-25 08:05:11 --> Language Class Initialized
INFO - 2022-08-25 08:05:11 --> Config Class Initialized
INFO - 2022-08-25 08:05:11 --> Loader Class Initialized
INFO - 2022-08-25 08:05:11 --> Helper loaded: url_helper
INFO - 2022-08-25 08:05:11 --> Helper loaded: file_helper
INFO - 2022-08-25 08:05:11 --> Helper loaded: form_helper
INFO - 2022-08-25 08:05:11 --> Helper loaded: my_helper
INFO - 2022-08-25 08:05:11 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:05:11 --> Controller Class Initialized
DEBUG - 2022-08-25 08:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-08-25 08:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:05:11 --> Final output sent to browser
DEBUG - 2022-08-25 08:05:11 --> Total execution time: 0.1016
INFO - 2022-08-25 08:06:37 --> Config Class Initialized
INFO - 2022-08-25 08:06:37 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:06:37 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:06:37 --> Utf8 Class Initialized
INFO - 2022-08-25 08:06:37 --> URI Class Initialized
INFO - 2022-08-25 08:06:37 --> Router Class Initialized
INFO - 2022-08-25 08:06:37 --> Output Class Initialized
INFO - 2022-08-25 08:06:37 --> Security Class Initialized
DEBUG - 2022-08-25 08:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:06:37 --> Input Class Initialized
INFO - 2022-08-25 08:06:37 --> Language Class Initialized
INFO - 2022-08-25 08:06:37 --> Language Class Initialized
INFO - 2022-08-25 08:06:37 --> Config Class Initialized
INFO - 2022-08-25 08:06:37 --> Loader Class Initialized
INFO - 2022-08-25 08:06:37 --> Helper loaded: url_helper
INFO - 2022-08-25 08:06:37 --> Helper loaded: file_helper
INFO - 2022-08-25 08:06:37 --> Helper loaded: form_helper
INFO - 2022-08-25 08:06:37 --> Helper loaded: my_helper
INFO - 2022-08-25 08:06:37 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:06:37 --> Controller Class Initialized
INFO - 2022-08-25 08:06:37 --> Helper loaded: cookie_helper
INFO - 2022-08-25 08:06:37 --> Final output sent to browser
DEBUG - 2022-08-25 08:06:37 --> Total execution time: 0.0877
INFO - 2022-08-25 08:06:37 --> Config Class Initialized
INFO - 2022-08-25 08:06:37 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:06:37 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:06:37 --> Utf8 Class Initialized
INFO - 2022-08-25 08:06:37 --> URI Class Initialized
INFO - 2022-08-25 08:06:37 --> Router Class Initialized
INFO - 2022-08-25 08:06:37 --> Output Class Initialized
INFO - 2022-08-25 08:06:37 --> Security Class Initialized
DEBUG - 2022-08-25 08:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:06:37 --> Input Class Initialized
INFO - 2022-08-25 08:06:37 --> Language Class Initialized
INFO - 2022-08-25 08:06:37 --> Language Class Initialized
INFO - 2022-08-25 08:06:37 --> Config Class Initialized
INFO - 2022-08-25 08:06:37 --> Loader Class Initialized
INFO - 2022-08-25 08:06:37 --> Helper loaded: url_helper
INFO - 2022-08-25 08:06:37 --> Helper loaded: file_helper
INFO - 2022-08-25 08:06:37 --> Helper loaded: form_helper
INFO - 2022-08-25 08:06:37 --> Helper loaded: my_helper
INFO - 2022-08-25 08:06:37 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:06:37 --> Controller Class Initialized
DEBUG - 2022-08-25 08:06:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-08-25 08:06:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:06:37 --> Final output sent to browser
DEBUG - 2022-08-25 08:06:37 --> Total execution time: 0.1629
INFO - 2022-08-25 08:06:40 --> Config Class Initialized
INFO - 2022-08-25 08:06:40 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:06:40 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:06:40 --> Utf8 Class Initialized
INFO - 2022-08-25 08:06:40 --> URI Class Initialized
INFO - 2022-08-25 08:06:40 --> Router Class Initialized
INFO - 2022-08-25 08:06:40 --> Output Class Initialized
INFO - 2022-08-25 08:06:40 --> Security Class Initialized
DEBUG - 2022-08-25 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:06:40 --> Input Class Initialized
INFO - 2022-08-25 08:06:40 --> Language Class Initialized
INFO - 2022-08-25 08:06:40 --> Language Class Initialized
INFO - 2022-08-25 08:06:40 --> Config Class Initialized
INFO - 2022-08-25 08:06:40 --> Loader Class Initialized
INFO - 2022-08-25 08:06:40 --> Helper loaded: url_helper
INFO - 2022-08-25 08:06:40 --> Helper loaded: file_helper
INFO - 2022-08-25 08:06:40 --> Helper loaded: form_helper
INFO - 2022-08-25 08:06:40 --> Helper loaded: my_helper
INFO - 2022-08-25 08:06:40 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:06:40 --> Controller Class Initialized
DEBUG - 2022-08-25 08:06:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-08-25 08:06:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:06:40 --> Final output sent to browser
DEBUG - 2022-08-25 08:06:40 --> Total execution time: 0.1006
INFO - 2022-08-25 08:07:46 --> Config Class Initialized
INFO - 2022-08-25 08:07:46 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:07:46 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:07:46 --> Utf8 Class Initialized
INFO - 2022-08-25 08:07:46 --> URI Class Initialized
INFO - 2022-08-25 08:07:46 --> Router Class Initialized
INFO - 2022-08-25 08:07:46 --> Output Class Initialized
INFO - 2022-08-25 08:07:46 --> Security Class Initialized
DEBUG - 2022-08-25 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:07:46 --> Input Class Initialized
INFO - 2022-08-25 08:07:46 --> Language Class Initialized
INFO - 2022-08-25 08:07:46 --> Language Class Initialized
INFO - 2022-08-25 08:07:46 --> Config Class Initialized
INFO - 2022-08-25 08:07:46 --> Loader Class Initialized
INFO - 2022-08-25 08:07:46 --> Helper loaded: url_helper
INFO - 2022-08-25 08:07:46 --> Helper loaded: file_helper
INFO - 2022-08-25 08:07:46 --> Helper loaded: form_helper
INFO - 2022-08-25 08:07:46 --> Helper loaded: my_helper
INFO - 2022-08-25 08:07:46 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:07:46 --> Controller Class Initialized
INFO - 2022-08-25 08:07:46 --> Final output sent to browser
DEBUG - 2022-08-25 08:07:46 --> Total execution time: 0.0936
INFO - 2022-08-25 08:07:49 --> Config Class Initialized
INFO - 2022-08-25 08:07:49 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:07:49 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:07:49 --> Utf8 Class Initialized
INFO - 2022-08-25 08:07:49 --> URI Class Initialized
INFO - 2022-08-25 08:07:49 --> Router Class Initialized
INFO - 2022-08-25 08:07:49 --> Output Class Initialized
INFO - 2022-08-25 08:07:49 --> Security Class Initialized
DEBUG - 2022-08-25 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:07:49 --> Input Class Initialized
INFO - 2022-08-25 08:07:49 --> Language Class Initialized
INFO - 2022-08-25 08:07:49 --> Language Class Initialized
INFO - 2022-08-25 08:07:49 --> Config Class Initialized
INFO - 2022-08-25 08:07:49 --> Loader Class Initialized
INFO - 2022-08-25 08:07:49 --> Helper loaded: url_helper
INFO - 2022-08-25 08:07:49 --> Helper loaded: file_helper
INFO - 2022-08-25 08:07:49 --> Helper loaded: form_helper
INFO - 2022-08-25 08:07:49 --> Helper loaded: my_helper
INFO - 2022-08-25 08:07:49 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:07:49 --> Controller Class Initialized
DEBUG - 2022-08-25 08:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-08-25 08:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:07:49 --> Final output sent to browser
DEBUG - 2022-08-25 08:07:49 --> Total execution time: 0.0442
INFO - 2022-08-25 08:07:51 --> Config Class Initialized
INFO - 2022-08-25 08:07:51 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:07:51 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:07:51 --> Utf8 Class Initialized
INFO - 2022-08-25 08:07:51 --> URI Class Initialized
INFO - 2022-08-25 08:07:51 --> Router Class Initialized
INFO - 2022-08-25 08:07:51 --> Output Class Initialized
INFO - 2022-08-25 08:07:51 --> Security Class Initialized
DEBUG - 2022-08-25 08:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:07:51 --> Input Class Initialized
INFO - 2022-08-25 08:07:51 --> Language Class Initialized
INFO - 2022-08-25 08:07:51 --> Language Class Initialized
INFO - 2022-08-25 08:07:51 --> Config Class Initialized
INFO - 2022-08-25 08:07:51 --> Loader Class Initialized
INFO - 2022-08-25 08:07:51 --> Helper loaded: url_helper
INFO - 2022-08-25 08:07:51 --> Helper loaded: file_helper
INFO - 2022-08-25 08:07:51 --> Helper loaded: form_helper
INFO - 2022-08-25 08:07:51 --> Helper loaded: my_helper
INFO - 2022-08-25 08:07:51 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:07:51 --> Controller Class Initialized
DEBUG - 2022-08-25 08:07:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-08-25 08:07:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:07:51 --> Final output sent to browser
DEBUG - 2022-08-25 08:07:51 --> Total execution time: 0.1250
INFO - 2022-08-25 08:07:58 --> Config Class Initialized
INFO - 2022-08-25 08:07:58 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:07:58 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:07:58 --> Utf8 Class Initialized
INFO - 2022-08-25 08:07:58 --> URI Class Initialized
INFO - 2022-08-25 08:07:58 --> Router Class Initialized
INFO - 2022-08-25 08:07:58 --> Output Class Initialized
INFO - 2022-08-25 08:07:58 --> Security Class Initialized
DEBUG - 2022-08-25 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:07:58 --> Input Class Initialized
INFO - 2022-08-25 08:07:58 --> Language Class Initialized
INFO - 2022-08-25 08:07:58 --> Language Class Initialized
INFO - 2022-08-25 08:07:58 --> Config Class Initialized
INFO - 2022-08-25 08:07:58 --> Loader Class Initialized
INFO - 2022-08-25 08:07:58 --> Helper loaded: url_helper
INFO - 2022-08-25 08:07:58 --> Helper loaded: file_helper
INFO - 2022-08-25 08:07:58 --> Helper loaded: form_helper
INFO - 2022-08-25 08:07:58 --> Helper loaded: my_helper
INFO - 2022-08-25 08:07:58 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:07:58 --> Controller Class Initialized
DEBUG - 2022-08-25 08:07:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-08-25 08:07:59 --> Final output sent to browser
DEBUG - 2022-08-25 08:07:59 --> Total execution time: 0.1772
INFO - 2022-08-25 08:08:11 --> Config Class Initialized
INFO - 2022-08-25 08:08:11 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:11 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:11 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:11 --> URI Class Initialized
INFO - 2022-08-25 08:08:11 --> Router Class Initialized
INFO - 2022-08-25 08:08:11 --> Output Class Initialized
INFO - 2022-08-25 08:08:11 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:11 --> Input Class Initialized
INFO - 2022-08-25 08:08:11 --> Language Class Initialized
INFO - 2022-08-25 08:08:11 --> Language Class Initialized
INFO - 2022-08-25 08:08:11 --> Config Class Initialized
INFO - 2022-08-25 08:08:11 --> Loader Class Initialized
INFO - 2022-08-25 08:08:11 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:11 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:11 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:11 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:11 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:11 --> Controller Class Initialized
INFO - 2022-08-25 08:08:11 --> Helper loaded: cookie_helper
INFO - 2022-08-25 08:08:11 --> Config Class Initialized
INFO - 2022-08-25 08:08:11 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:11 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:11 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:11 --> URI Class Initialized
INFO - 2022-08-25 08:08:11 --> Router Class Initialized
INFO - 2022-08-25 08:08:11 --> Output Class Initialized
INFO - 2022-08-25 08:08:11 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:11 --> Input Class Initialized
INFO - 2022-08-25 08:08:11 --> Language Class Initialized
INFO - 2022-08-25 08:08:11 --> Language Class Initialized
INFO - 2022-08-25 08:08:11 --> Config Class Initialized
INFO - 2022-08-25 08:08:11 --> Loader Class Initialized
INFO - 2022-08-25 08:08:11 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:11 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:11 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:11 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:11 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:11 --> Controller Class Initialized
DEBUG - 2022-08-25 08:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-08-25 08:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:08:11 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:11 --> Total execution time: 0.0540
INFO - 2022-08-25 08:08:20 --> Config Class Initialized
INFO - 2022-08-25 08:08:20 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:20 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:20 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:20 --> URI Class Initialized
INFO - 2022-08-25 08:08:20 --> Router Class Initialized
INFO - 2022-08-25 08:08:20 --> Output Class Initialized
INFO - 2022-08-25 08:08:20 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:20 --> Input Class Initialized
INFO - 2022-08-25 08:08:20 --> Language Class Initialized
INFO - 2022-08-25 08:08:20 --> Language Class Initialized
INFO - 2022-08-25 08:08:20 --> Config Class Initialized
INFO - 2022-08-25 08:08:20 --> Loader Class Initialized
INFO - 2022-08-25 08:08:20 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:20 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:20 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:20 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:20 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:20 --> Controller Class Initialized
INFO - 2022-08-25 08:08:20 --> Helper loaded: cookie_helper
INFO - 2022-08-25 08:08:20 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:20 --> Total execution time: 0.0448
INFO - 2022-08-25 08:08:20 --> Config Class Initialized
INFO - 2022-08-25 08:08:20 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:20 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:20 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:20 --> URI Class Initialized
INFO - 2022-08-25 08:08:20 --> Router Class Initialized
INFO - 2022-08-25 08:08:20 --> Output Class Initialized
INFO - 2022-08-25 08:08:20 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:20 --> Input Class Initialized
INFO - 2022-08-25 08:08:20 --> Language Class Initialized
INFO - 2022-08-25 08:08:20 --> Language Class Initialized
INFO - 2022-08-25 08:08:20 --> Config Class Initialized
INFO - 2022-08-25 08:08:20 --> Loader Class Initialized
INFO - 2022-08-25 08:08:20 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:20 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:20 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:20 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:20 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:20 --> Controller Class Initialized
DEBUG - 2022-08-25 08:08:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-08-25 08:08:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:08:20 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:20 --> Total execution time: 0.0993
INFO - 2022-08-25 08:08:27 --> Config Class Initialized
INFO - 2022-08-25 08:08:27 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:27 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:27 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:27 --> URI Class Initialized
INFO - 2022-08-25 08:08:27 --> Router Class Initialized
INFO - 2022-08-25 08:08:27 --> Output Class Initialized
INFO - 2022-08-25 08:08:27 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:27 --> Input Class Initialized
INFO - 2022-08-25 08:08:27 --> Language Class Initialized
INFO - 2022-08-25 08:08:27 --> Language Class Initialized
INFO - 2022-08-25 08:08:27 --> Config Class Initialized
INFO - 2022-08-25 08:08:27 --> Loader Class Initialized
INFO - 2022-08-25 08:08:27 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:27 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:27 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:27 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:27 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:27 --> Controller Class Initialized
DEBUG - 2022-08-25 08:08:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-08-25 08:08:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:08:27 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:27 --> Total execution time: 0.0516
INFO - 2022-08-25 08:08:41 --> Config Class Initialized
INFO - 2022-08-25 08:08:41 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:41 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:41 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:41 --> URI Class Initialized
INFO - 2022-08-25 08:08:41 --> Router Class Initialized
INFO - 2022-08-25 08:08:41 --> Output Class Initialized
INFO - 2022-08-25 08:08:41 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:41 --> Input Class Initialized
INFO - 2022-08-25 08:08:41 --> Language Class Initialized
INFO - 2022-08-25 08:08:41 --> Language Class Initialized
INFO - 2022-08-25 08:08:41 --> Config Class Initialized
INFO - 2022-08-25 08:08:41 --> Loader Class Initialized
INFO - 2022-08-25 08:08:41 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:41 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:41 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:41 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:41 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:41 --> Controller Class Initialized
INFO - 2022-08-25 08:08:41 --> Helper loaded: cookie_helper
INFO - 2022-08-25 08:08:41 --> Config Class Initialized
INFO - 2022-08-25 08:08:41 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:41 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:41 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:41 --> URI Class Initialized
INFO - 2022-08-25 08:08:41 --> Router Class Initialized
INFO - 2022-08-25 08:08:41 --> Output Class Initialized
INFO - 2022-08-25 08:08:41 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:41 --> Input Class Initialized
INFO - 2022-08-25 08:08:41 --> Language Class Initialized
INFO - 2022-08-25 08:08:41 --> Language Class Initialized
INFO - 2022-08-25 08:08:41 --> Config Class Initialized
INFO - 2022-08-25 08:08:41 --> Loader Class Initialized
INFO - 2022-08-25 08:08:41 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:41 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:41 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:41 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:41 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:41 --> Controller Class Initialized
DEBUG - 2022-08-25 08:08:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-08-25 08:08:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:08:41 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:41 --> Total execution time: 0.0559
INFO - 2022-08-25 08:08:45 --> Config Class Initialized
INFO - 2022-08-25 08:08:45 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:45 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:45 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:45 --> URI Class Initialized
INFO - 2022-08-25 08:08:45 --> Router Class Initialized
INFO - 2022-08-25 08:08:45 --> Output Class Initialized
INFO - 2022-08-25 08:08:45 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:45 --> Input Class Initialized
INFO - 2022-08-25 08:08:45 --> Language Class Initialized
INFO - 2022-08-25 08:08:45 --> Language Class Initialized
INFO - 2022-08-25 08:08:45 --> Config Class Initialized
INFO - 2022-08-25 08:08:45 --> Loader Class Initialized
INFO - 2022-08-25 08:08:45 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:45 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:45 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:45 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:45 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:45 --> Controller Class Initialized
INFO - 2022-08-25 08:08:45 --> Helper loaded: cookie_helper
INFO - 2022-08-25 08:08:45 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:45 --> Total execution time: 0.0439
INFO - 2022-08-25 08:08:45 --> Config Class Initialized
INFO - 2022-08-25 08:08:45 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:45 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:45 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:45 --> URI Class Initialized
INFO - 2022-08-25 08:08:45 --> Router Class Initialized
INFO - 2022-08-25 08:08:45 --> Output Class Initialized
INFO - 2022-08-25 08:08:45 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:45 --> Input Class Initialized
INFO - 2022-08-25 08:08:45 --> Language Class Initialized
INFO - 2022-08-25 08:08:45 --> Language Class Initialized
INFO - 2022-08-25 08:08:45 --> Config Class Initialized
INFO - 2022-08-25 08:08:45 --> Loader Class Initialized
INFO - 2022-08-25 08:08:45 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:45 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:45 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:45 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:45 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:45 --> Controller Class Initialized
DEBUG - 2022-08-25 08:08:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-08-25 08:08:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:08:45 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:45 --> Total execution time: 0.0818
INFO - 2022-08-25 08:08:47 --> Config Class Initialized
INFO - 2022-08-25 08:08:47 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:47 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:47 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:47 --> URI Class Initialized
INFO - 2022-08-25 08:08:47 --> Router Class Initialized
INFO - 2022-08-25 08:08:47 --> Output Class Initialized
INFO - 2022-08-25 08:08:47 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:47 --> Input Class Initialized
INFO - 2022-08-25 08:08:47 --> Language Class Initialized
INFO - 2022-08-25 08:08:47 --> Language Class Initialized
INFO - 2022-08-25 08:08:47 --> Config Class Initialized
INFO - 2022-08-25 08:08:47 --> Loader Class Initialized
INFO - 2022-08-25 08:08:47 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:47 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:47 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:47 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:47 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:47 --> Controller Class Initialized
DEBUG - 2022-08-25 08:08:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-08-25 08:08:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:08:47 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:47 --> Total execution time: 0.0634
INFO - 2022-08-25 08:08:47 --> Config Class Initialized
INFO - 2022-08-25 08:08:47 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:47 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:47 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:47 --> URI Class Initialized
INFO - 2022-08-25 08:08:47 --> Router Class Initialized
INFO - 2022-08-25 08:08:47 --> Output Class Initialized
INFO - 2022-08-25 08:08:47 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:47 --> Input Class Initialized
INFO - 2022-08-25 08:08:47 --> Language Class Initialized
INFO - 2022-08-25 08:08:47 --> Language Class Initialized
INFO - 2022-08-25 08:08:47 --> Config Class Initialized
INFO - 2022-08-25 08:08:47 --> Loader Class Initialized
INFO - 2022-08-25 08:08:47 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:47 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:47 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:47 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:47 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:47 --> Controller Class Initialized
INFO - 2022-08-25 08:08:50 --> Config Class Initialized
INFO - 2022-08-25 08:08:50 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:50 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:50 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:50 --> URI Class Initialized
INFO - 2022-08-25 08:08:51 --> Router Class Initialized
INFO - 2022-08-25 08:08:51 --> Output Class Initialized
INFO - 2022-08-25 08:08:51 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:51 --> Input Class Initialized
INFO - 2022-08-25 08:08:51 --> Language Class Initialized
INFO - 2022-08-25 08:08:51 --> Language Class Initialized
INFO - 2022-08-25 08:08:51 --> Config Class Initialized
INFO - 2022-08-25 08:08:51 --> Loader Class Initialized
INFO - 2022-08-25 08:08:51 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:51 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:51 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:51 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:51 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:51 --> Controller Class Initialized
INFO - 2022-08-25 08:08:51 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:51 --> Total execution time: 0.0449
INFO - 2022-08-25 08:08:51 --> Config Class Initialized
INFO - 2022-08-25 08:08:51 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:51 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:51 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:51 --> URI Class Initialized
INFO - 2022-08-25 08:08:51 --> Router Class Initialized
INFO - 2022-08-25 08:08:51 --> Output Class Initialized
INFO - 2022-08-25 08:08:51 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:51 --> Input Class Initialized
INFO - 2022-08-25 08:08:51 --> Language Class Initialized
INFO - 2022-08-25 08:08:51 --> Language Class Initialized
INFO - 2022-08-25 08:08:51 --> Config Class Initialized
INFO - 2022-08-25 08:08:51 --> Loader Class Initialized
INFO - 2022-08-25 08:08:51 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:51 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:51 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:51 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:51 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:51 --> Controller Class Initialized
INFO - 2022-08-25 08:08:54 --> Config Class Initialized
INFO - 2022-08-25 08:08:54 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:54 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:54 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:54 --> URI Class Initialized
INFO - 2022-08-25 08:08:54 --> Router Class Initialized
INFO - 2022-08-25 08:08:54 --> Output Class Initialized
INFO - 2022-08-25 08:08:54 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:54 --> Input Class Initialized
INFO - 2022-08-25 08:08:54 --> Language Class Initialized
INFO - 2022-08-25 08:08:54 --> Language Class Initialized
INFO - 2022-08-25 08:08:54 --> Config Class Initialized
INFO - 2022-08-25 08:08:54 --> Loader Class Initialized
INFO - 2022-08-25 08:08:54 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:54 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:54 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:54 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:54 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:54 --> Controller Class Initialized
INFO - 2022-08-25 08:08:54 --> Helper loaded: cookie_helper
INFO - 2022-08-25 08:08:54 --> Config Class Initialized
INFO - 2022-08-25 08:08:54 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:54 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:54 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:54 --> URI Class Initialized
INFO - 2022-08-25 08:08:54 --> Router Class Initialized
INFO - 2022-08-25 08:08:54 --> Output Class Initialized
INFO - 2022-08-25 08:08:54 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:54 --> Input Class Initialized
INFO - 2022-08-25 08:08:54 --> Language Class Initialized
INFO - 2022-08-25 08:08:54 --> Language Class Initialized
INFO - 2022-08-25 08:08:54 --> Config Class Initialized
INFO - 2022-08-25 08:08:54 --> Loader Class Initialized
INFO - 2022-08-25 08:08:54 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:54 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:54 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:54 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:54 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:54 --> Controller Class Initialized
DEBUG - 2022-08-25 08:08:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-08-25 08:08:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:08:54 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:54 --> Total execution time: 0.0418
INFO - 2022-08-25 08:08:57 --> Config Class Initialized
INFO - 2022-08-25 08:08:57 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:57 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:57 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:57 --> URI Class Initialized
INFO - 2022-08-25 08:08:57 --> Router Class Initialized
INFO - 2022-08-25 08:08:57 --> Output Class Initialized
INFO - 2022-08-25 08:08:57 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:57 --> Input Class Initialized
INFO - 2022-08-25 08:08:57 --> Language Class Initialized
INFO - 2022-08-25 08:08:57 --> Language Class Initialized
INFO - 2022-08-25 08:08:57 --> Config Class Initialized
INFO - 2022-08-25 08:08:57 --> Loader Class Initialized
INFO - 2022-08-25 08:08:57 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:57 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:57 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:57 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:57 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:57 --> Controller Class Initialized
INFO - 2022-08-25 08:08:57 --> Helper loaded: cookie_helper
INFO - 2022-08-25 08:08:57 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:57 --> Total execution time: 0.0437
INFO - 2022-08-25 08:08:57 --> Config Class Initialized
INFO - 2022-08-25 08:08:57 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:08:57 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:08:57 --> Utf8 Class Initialized
INFO - 2022-08-25 08:08:57 --> URI Class Initialized
INFO - 2022-08-25 08:08:57 --> Router Class Initialized
INFO - 2022-08-25 08:08:57 --> Output Class Initialized
INFO - 2022-08-25 08:08:57 --> Security Class Initialized
DEBUG - 2022-08-25 08:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:08:57 --> Input Class Initialized
INFO - 2022-08-25 08:08:57 --> Language Class Initialized
INFO - 2022-08-25 08:08:57 --> Language Class Initialized
INFO - 2022-08-25 08:08:57 --> Config Class Initialized
INFO - 2022-08-25 08:08:57 --> Loader Class Initialized
INFO - 2022-08-25 08:08:57 --> Helper loaded: url_helper
INFO - 2022-08-25 08:08:57 --> Helper loaded: file_helper
INFO - 2022-08-25 08:08:57 --> Helper loaded: form_helper
INFO - 2022-08-25 08:08:57 --> Helper loaded: my_helper
INFO - 2022-08-25 08:08:57 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:08:57 --> Controller Class Initialized
DEBUG - 2022-08-25 08:08:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-08-25 08:08:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:08:58 --> Final output sent to browser
DEBUG - 2022-08-25 08:08:58 --> Total execution time: 0.4939
INFO - 2022-08-25 08:09:00 --> Config Class Initialized
INFO - 2022-08-25 08:09:00 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:09:00 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:09:00 --> Utf8 Class Initialized
INFO - 2022-08-25 08:09:00 --> URI Class Initialized
INFO - 2022-08-25 08:09:00 --> Router Class Initialized
INFO - 2022-08-25 08:09:00 --> Output Class Initialized
INFO - 2022-08-25 08:09:00 --> Security Class Initialized
DEBUG - 2022-08-25 08:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:09:00 --> Input Class Initialized
INFO - 2022-08-25 08:09:00 --> Language Class Initialized
INFO - 2022-08-25 08:09:00 --> Language Class Initialized
INFO - 2022-08-25 08:09:00 --> Config Class Initialized
INFO - 2022-08-25 08:09:00 --> Loader Class Initialized
INFO - 2022-08-25 08:09:00 --> Helper loaded: url_helper
INFO - 2022-08-25 08:09:00 --> Helper loaded: file_helper
INFO - 2022-08-25 08:09:00 --> Helper loaded: form_helper
INFO - 2022-08-25 08:09:00 --> Helper loaded: my_helper
INFO - 2022-08-25 08:09:00 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:09:00 --> Controller Class Initialized
DEBUG - 2022-08-25 08:09:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-08-25 08:09:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:09:00 --> Final output sent to browser
DEBUG - 2022-08-25 08:09:00 --> Total execution time: 0.0518
INFO - 2022-08-25 08:09:56 --> Config Class Initialized
INFO - 2022-08-25 08:09:56 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:09:56 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:09:56 --> Utf8 Class Initialized
INFO - 2022-08-25 08:09:56 --> URI Class Initialized
INFO - 2022-08-25 08:09:56 --> Router Class Initialized
INFO - 2022-08-25 08:09:56 --> Output Class Initialized
INFO - 2022-08-25 08:09:56 --> Security Class Initialized
DEBUG - 2022-08-25 08:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:09:56 --> Input Class Initialized
INFO - 2022-08-25 08:09:56 --> Language Class Initialized
INFO - 2022-08-25 08:09:56 --> Language Class Initialized
INFO - 2022-08-25 08:09:56 --> Config Class Initialized
INFO - 2022-08-25 08:09:56 --> Loader Class Initialized
INFO - 2022-08-25 08:09:56 --> Helper loaded: url_helper
INFO - 2022-08-25 08:09:56 --> Helper loaded: file_helper
INFO - 2022-08-25 08:09:56 --> Helper loaded: form_helper
INFO - 2022-08-25 08:09:56 --> Helper loaded: my_helper
INFO - 2022-08-25 08:09:56 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:09:56 --> Controller Class Initialized
INFO - 2022-08-25 08:09:56 --> Final output sent to browser
DEBUG - 2022-08-25 08:09:56 --> Total execution time: 0.1691
INFO - 2022-08-25 08:09:57 --> Config Class Initialized
INFO - 2022-08-25 08:09:57 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:09:57 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:09:57 --> Utf8 Class Initialized
INFO - 2022-08-25 08:09:57 --> URI Class Initialized
INFO - 2022-08-25 08:09:57 --> Router Class Initialized
INFO - 2022-08-25 08:09:57 --> Output Class Initialized
INFO - 2022-08-25 08:09:57 --> Security Class Initialized
DEBUG - 2022-08-25 08:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:09:57 --> Input Class Initialized
INFO - 2022-08-25 08:09:57 --> Language Class Initialized
INFO - 2022-08-25 08:09:57 --> Language Class Initialized
INFO - 2022-08-25 08:09:57 --> Config Class Initialized
INFO - 2022-08-25 08:09:57 --> Loader Class Initialized
INFO - 2022-08-25 08:09:57 --> Helper loaded: url_helper
INFO - 2022-08-25 08:09:57 --> Helper loaded: file_helper
INFO - 2022-08-25 08:09:57 --> Helper loaded: form_helper
INFO - 2022-08-25 08:09:57 --> Helper loaded: my_helper
INFO - 2022-08-25 08:09:57 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:09:57 --> Controller Class Initialized
DEBUG - 2022-08-25 08:09:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-08-25 08:09:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:09:57 --> Final output sent to browser
DEBUG - 2022-08-25 08:09:57 --> Total execution time: 0.0557
INFO - 2022-08-25 08:10:00 --> Config Class Initialized
INFO - 2022-08-25 08:10:00 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:10:00 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:10:00 --> Utf8 Class Initialized
INFO - 2022-08-25 08:10:00 --> URI Class Initialized
INFO - 2022-08-25 08:10:00 --> Router Class Initialized
INFO - 2022-08-25 08:10:00 --> Output Class Initialized
INFO - 2022-08-25 08:10:00 --> Security Class Initialized
DEBUG - 2022-08-25 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:10:00 --> Input Class Initialized
INFO - 2022-08-25 08:10:00 --> Language Class Initialized
INFO - 2022-08-25 08:10:00 --> Language Class Initialized
INFO - 2022-08-25 08:10:00 --> Config Class Initialized
INFO - 2022-08-25 08:10:00 --> Loader Class Initialized
INFO - 2022-08-25 08:10:00 --> Helper loaded: url_helper
INFO - 2022-08-25 08:10:00 --> Helper loaded: file_helper
INFO - 2022-08-25 08:10:00 --> Helper loaded: form_helper
INFO - 2022-08-25 08:10:00 --> Helper loaded: my_helper
INFO - 2022-08-25 08:10:00 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:10:00 --> Controller Class Initialized
DEBUG - 2022-08-25 08:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-08-25 08:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-25 08:10:00 --> Final output sent to browser
DEBUG - 2022-08-25 08:10:00 --> Total execution time: 0.0498
INFO - 2022-08-25 08:10:37 --> Config Class Initialized
INFO - 2022-08-25 08:10:37 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:10:37 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:10:37 --> Utf8 Class Initialized
INFO - 2022-08-25 08:10:37 --> URI Class Initialized
INFO - 2022-08-25 08:10:37 --> Router Class Initialized
INFO - 2022-08-25 08:10:37 --> Output Class Initialized
INFO - 2022-08-25 08:10:37 --> Security Class Initialized
DEBUG - 2022-08-25 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:10:37 --> Input Class Initialized
INFO - 2022-08-25 08:10:37 --> Language Class Initialized
INFO - 2022-08-25 08:10:37 --> Language Class Initialized
INFO - 2022-08-25 08:10:37 --> Config Class Initialized
INFO - 2022-08-25 08:10:37 --> Loader Class Initialized
INFO - 2022-08-25 08:10:37 --> Helper loaded: url_helper
INFO - 2022-08-25 08:10:37 --> Helper loaded: file_helper
INFO - 2022-08-25 08:10:37 --> Helper loaded: form_helper
INFO - 2022-08-25 08:10:37 --> Helper loaded: my_helper
INFO - 2022-08-25 08:10:37 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:10:37 --> Controller Class Initialized
DEBUG - 2022-08-25 08:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-08-25 08:10:37 --> Final output sent to browser
DEBUG - 2022-08-25 08:10:37 --> Total execution time: 0.2105
INFO - 2022-08-25 08:11:04 --> Config Class Initialized
INFO - 2022-08-25 08:11:04 --> Hooks Class Initialized
DEBUG - 2022-08-25 08:11:04 --> UTF-8 Support Enabled
INFO - 2022-08-25 08:11:04 --> Utf8 Class Initialized
INFO - 2022-08-25 08:11:04 --> URI Class Initialized
INFO - 2022-08-25 08:11:04 --> Router Class Initialized
INFO - 2022-08-25 08:11:04 --> Output Class Initialized
INFO - 2022-08-25 08:11:04 --> Security Class Initialized
DEBUG - 2022-08-25 08:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-25 08:11:04 --> Input Class Initialized
INFO - 2022-08-25 08:11:04 --> Language Class Initialized
INFO - 2022-08-25 08:11:04 --> Language Class Initialized
INFO - 2022-08-25 08:11:04 --> Config Class Initialized
INFO - 2022-08-25 08:11:04 --> Loader Class Initialized
INFO - 2022-08-25 08:11:04 --> Helper loaded: url_helper
INFO - 2022-08-25 08:11:04 --> Helper loaded: file_helper
INFO - 2022-08-25 08:11:04 --> Helper loaded: form_helper
INFO - 2022-08-25 08:11:04 --> Helper loaded: my_helper
INFO - 2022-08-25 08:11:04 --> Database Driver Class Initialized
DEBUG - 2022-08-25 08:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-25 08:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-25 08:11:04 --> Controller Class Initialized
DEBUG - 2022-08-25 08:11:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-08-25 08:11:04 --> Final output sent to browser
DEBUG - 2022-08-25 08:11:04 --> Total execution time: 0.1329
