<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-05 02:47:12 --> Config Class Initialized
INFO - 2021-04-05 02:47:12 --> Hooks Class Initialized
DEBUG - 2021-04-05 02:47:12 --> UTF-8 Support Enabled
INFO - 2021-04-05 02:47:12 --> Utf8 Class Initialized
INFO - 2021-04-05 02:47:12 --> URI Class Initialized
DEBUG - 2021-04-05 02:47:12 --> No URI present. Default controller set.
INFO - 2021-04-05 02:47:12 --> Router Class Initialized
INFO - 2021-04-05 02:47:12 --> Output Class Initialized
INFO - 2021-04-05 02:47:12 --> Security Class Initialized
DEBUG - 2021-04-05 02:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-05 02:47:12 --> Input Class Initialized
INFO - 2021-04-05 02:47:12 --> Language Class Initialized
INFO - 2021-04-05 02:47:13 --> Language Class Initialized
INFO - 2021-04-05 02:47:13 --> Config Class Initialized
INFO - 2021-04-05 02:47:13 --> Loader Class Initialized
INFO - 2021-04-05 02:47:13 --> Helper loaded: url_helper
INFO - 2021-04-05 02:47:13 --> Helper loaded: file_helper
INFO - 2021-04-05 02:47:13 --> Helper loaded: form_helper
INFO - 2021-04-05 02:47:13 --> Helper loaded: my_helper
INFO - 2021-04-05 02:47:13 --> Database Driver Class Initialized
DEBUG - 2021-04-05 02:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-05 02:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-05 02:47:14 --> Controller Class Initialized
INFO - 2021-04-05 02:47:14 --> Config Class Initialized
INFO - 2021-04-05 02:47:14 --> Hooks Class Initialized
DEBUG - 2021-04-05 02:47:14 --> UTF-8 Support Enabled
INFO - 2021-04-05 02:47:14 --> Utf8 Class Initialized
INFO - 2021-04-05 02:47:14 --> URI Class Initialized
INFO - 2021-04-05 02:47:14 --> Router Class Initialized
INFO - 2021-04-05 02:47:14 --> Output Class Initialized
INFO - 2021-04-05 02:47:14 --> Security Class Initialized
DEBUG - 2021-04-05 02:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-05 02:47:14 --> Input Class Initialized
INFO - 2021-04-05 02:47:14 --> Language Class Initialized
INFO - 2021-04-05 02:47:14 --> Language Class Initialized
INFO - 2021-04-05 02:47:14 --> Config Class Initialized
INFO - 2021-04-05 02:47:14 --> Loader Class Initialized
INFO - 2021-04-05 02:47:14 --> Helper loaded: url_helper
INFO - 2021-04-05 02:47:15 --> Helper loaded: file_helper
INFO - 2021-04-05 02:47:15 --> Helper loaded: form_helper
INFO - 2021-04-05 02:47:15 --> Helper loaded: my_helper
INFO - 2021-04-05 02:47:15 --> Database Driver Class Initialized
DEBUG - 2021-04-05 02:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-05 02:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-05 02:47:15 --> Controller Class Initialized
DEBUG - 2021-04-05 02:47:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-05 02:47:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-05 02:47:15 --> Final output sent to browser
DEBUG - 2021-04-05 02:47:15 --> Total execution time: 1.1424
INFO - 2021-04-05 02:47:26 --> Config Class Initialized
INFO - 2021-04-05 02:47:26 --> Hooks Class Initialized
DEBUG - 2021-04-05 02:47:26 --> UTF-8 Support Enabled
INFO - 2021-04-05 02:47:26 --> Utf8 Class Initialized
INFO - 2021-04-05 02:47:26 --> URI Class Initialized
INFO - 2021-04-05 02:47:26 --> Router Class Initialized
INFO - 2021-04-05 02:47:26 --> Output Class Initialized
INFO - 2021-04-05 02:47:26 --> Security Class Initialized
DEBUG - 2021-04-05 02:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-05 02:47:26 --> Input Class Initialized
INFO - 2021-04-05 02:47:26 --> Language Class Initialized
INFO - 2021-04-05 02:47:27 --> Language Class Initialized
INFO - 2021-04-05 02:47:27 --> Config Class Initialized
INFO - 2021-04-05 02:47:27 --> Loader Class Initialized
INFO - 2021-04-05 02:47:27 --> Helper loaded: url_helper
INFO - 2021-04-05 02:47:27 --> Helper loaded: file_helper
INFO - 2021-04-05 02:47:27 --> Helper loaded: form_helper
INFO - 2021-04-05 02:47:27 --> Helper loaded: my_helper
INFO - 2021-04-05 02:47:27 --> Database Driver Class Initialized
DEBUG - 2021-04-05 02:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-05 02:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-05 02:47:27 --> Controller Class Initialized
INFO - 2021-04-05 02:47:27 --> Helper loaded: cookie_helper
INFO - 2021-04-05 02:47:27 --> Final output sent to browser
DEBUG - 2021-04-05 02:47:27 --> Total execution time: 0.9472
INFO - 2021-04-05 02:47:27 --> Config Class Initialized
INFO - 2021-04-05 02:47:28 --> Hooks Class Initialized
DEBUG - 2021-04-05 02:47:28 --> UTF-8 Support Enabled
INFO - 2021-04-05 02:47:28 --> Utf8 Class Initialized
INFO - 2021-04-05 02:47:28 --> URI Class Initialized
INFO - 2021-04-05 02:47:28 --> Router Class Initialized
INFO - 2021-04-05 02:47:28 --> Output Class Initialized
INFO - 2021-04-05 02:47:28 --> Security Class Initialized
DEBUG - 2021-04-05 02:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-05 02:47:28 --> Input Class Initialized
INFO - 2021-04-05 02:47:28 --> Language Class Initialized
INFO - 2021-04-05 02:47:28 --> Language Class Initialized
INFO - 2021-04-05 02:47:28 --> Config Class Initialized
INFO - 2021-04-05 02:47:28 --> Loader Class Initialized
INFO - 2021-04-05 02:47:28 --> Helper loaded: url_helper
INFO - 2021-04-05 02:47:28 --> Helper loaded: file_helper
INFO - 2021-04-05 02:47:28 --> Helper loaded: form_helper
INFO - 2021-04-05 02:47:28 --> Helper loaded: my_helper
INFO - 2021-04-05 02:47:28 --> Database Driver Class Initialized
DEBUG - 2021-04-05 02:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-05 02:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-05 02:47:28 --> Controller Class Initialized
DEBUG - 2021-04-05 02:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-05 02:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-05 02:47:28 --> Final output sent to browser
DEBUG - 2021-04-05 02:47:29 --> Total execution time: 0.9727
