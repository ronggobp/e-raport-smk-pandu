<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-17 00:39:06 --> Config Class Initialized
INFO - 2020-11-17 00:39:06 --> Hooks Class Initialized
DEBUG - 2020-11-17 00:39:07 --> UTF-8 Support Enabled
INFO - 2020-11-17 00:39:07 --> Utf8 Class Initialized
INFO - 2020-11-17 00:39:07 --> URI Class Initialized
DEBUG - 2020-11-17 00:39:07 --> No URI present. Default controller set.
INFO - 2020-11-17 00:39:07 --> Router Class Initialized
INFO - 2020-11-17 00:39:07 --> Output Class Initialized
INFO - 2020-11-17 00:39:07 --> Security Class Initialized
DEBUG - 2020-11-17 00:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 00:39:07 --> Input Class Initialized
INFO - 2020-11-17 00:39:07 --> Language Class Initialized
INFO - 2020-11-17 00:39:07 --> Language Class Initialized
INFO - 2020-11-17 00:39:07 --> Config Class Initialized
INFO - 2020-11-17 00:39:07 --> Loader Class Initialized
INFO - 2020-11-17 00:39:08 --> Helper loaded: url_helper
INFO - 2020-11-17 00:39:08 --> Helper loaded: file_helper
INFO - 2020-11-17 00:39:08 --> Helper loaded: form_helper
INFO - 2020-11-17 00:39:08 --> Helper loaded: my_helper
INFO - 2020-11-17 00:39:08 --> Database Driver Class Initialized
DEBUG - 2020-11-17 00:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 00:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 00:39:08 --> Controller Class Initialized
INFO - 2020-11-17 00:39:08 --> Config Class Initialized
INFO - 2020-11-17 00:39:08 --> Hooks Class Initialized
DEBUG - 2020-11-17 00:39:08 --> UTF-8 Support Enabled
INFO - 2020-11-17 00:39:08 --> Utf8 Class Initialized
INFO - 2020-11-17 00:39:08 --> URI Class Initialized
INFO - 2020-11-17 00:39:08 --> Router Class Initialized
INFO - 2020-11-17 00:39:08 --> Output Class Initialized
INFO - 2020-11-17 00:39:08 --> Security Class Initialized
DEBUG - 2020-11-17 00:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 00:39:08 --> Input Class Initialized
INFO - 2020-11-17 00:39:08 --> Language Class Initialized
INFO - 2020-11-17 00:39:08 --> Language Class Initialized
INFO - 2020-11-17 00:39:08 --> Config Class Initialized
INFO - 2020-11-17 00:39:08 --> Loader Class Initialized
INFO - 2020-11-17 00:39:08 --> Helper loaded: url_helper
INFO - 2020-11-17 00:39:09 --> Helper loaded: file_helper
INFO - 2020-11-17 00:39:09 --> Helper loaded: form_helper
INFO - 2020-11-17 00:39:09 --> Helper loaded: my_helper
INFO - 2020-11-17 00:39:09 --> Database Driver Class Initialized
DEBUG - 2020-11-17 00:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 00:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 00:39:09 --> Controller Class Initialized
DEBUG - 2020-11-17 00:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 00:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 00:39:09 --> Final output sent to browser
DEBUG - 2020-11-17 00:39:09 --> Total execution time: 0.7320
INFO - 2020-11-17 01:10:30 --> Config Class Initialized
INFO - 2020-11-17 01:10:30 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:10:30 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:10:30 --> Utf8 Class Initialized
INFO - 2020-11-17 01:10:30 --> URI Class Initialized
INFO - 2020-11-17 01:10:30 --> Router Class Initialized
INFO - 2020-11-17 01:10:30 --> Output Class Initialized
INFO - 2020-11-17 01:10:30 --> Security Class Initialized
DEBUG - 2020-11-17 01:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:10:30 --> Input Class Initialized
INFO - 2020-11-17 01:10:30 --> Language Class Initialized
INFO - 2020-11-17 01:10:30 --> Language Class Initialized
INFO - 2020-11-17 01:10:30 --> Config Class Initialized
INFO - 2020-11-17 01:10:30 --> Loader Class Initialized
INFO - 2020-11-17 01:10:30 --> Helper loaded: url_helper
INFO - 2020-11-17 01:10:30 --> Helper loaded: file_helper
INFO - 2020-11-17 01:10:30 --> Helper loaded: form_helper
INFO - 2020-11-17 01:10:30 --> Helper loaded: my_helper
INFO - 2020-11-17 01:10:30 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:10:30 --> Controller Class Initialized
INFO - 2020-11-17 01:10:31 --> Helper loaded: cookie_helper
INFO - 2020-11-17 01:10:31 --> Final output sent to browser
DEBUG - 2020-11-17 01:10:31 --> Total execution time: 0.9558
INFO - 2020-11-17 01:10:32 --> Config Class Initialized
INFO - 2020-11-17 01:10:32 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:10:32 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:10:32 --> Utf8 Class Initialized
INFO - 2020-11-17 01:10:32 --> URI Class Initialized
INFO - 2020-11-17 01:10:32 --> Router Class Initialized
INFO - 2020-11-17 01:10:32 --> Output Class Initialized
INFO - 2020-11-17 01:10:32 --> Security Class Initialized
DEBUG - 2020-11-17 01:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:10:32 --> Input Class Initialized
INFO - 2020-11-17 01:10:32 --> Language Class Initialized
INFO - 2020-11-17 01:10:32 --> Language Class Initialized
INFO - 2020-11-17 01:10:32 --> Config Class Initialized
INFO - 2020-11-17 01:10:32 --> Loader Class Initialized
INFO - 2020-11-17 01:10:32 --> Helper loaded: url_helper
INFO - 2020-11-17 01:10:32 --> Helper loaded: file_helper
INFO - 2020-11-17 01:10:32 --> Helper loaded: form_helper
INFO - 2020-11-17 01:10:32 --> Helper loaded: my_helper
INFO - 2020-11-17 01:10:32 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:10:32 --> Controller Class Initialized
DEBUG - 2020-11-17 01:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 01:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:10:32 --> Final output sent to browser
DEBUG - 2020-11-17 01:10:32 --> Total execution time: 0.7483
INFO - 2020-11-17 01:36:40 --> Config Class Initialized
INFO - 2020-11-17 01:36:40 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:36:40 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:36:40 --> Utf8 Class Initialized
INFO - 2020-11-17 01:36:40 --> URI Class Initialized
INFO - 2020-11-17 01:36:40 --> Router Class Initialized
INFO - 2020-11-17 01:36:40 --> Output Class Initialized
INFO - 2020-11-17 01:36:40 --> Security Class Initialized
DEBUG - 2020-11-17 01:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:36:40 --> Input Class Initialized
INFO - 2020-11-17 01:36:40 --> Language Class Initialized
INFO - 2020-11-17 01:36:40 --> Language Class Initialized
INFO - 2020-11-17 01:36:40 --> Config Class Initialized
INFO - 2020-11-17 01:36:40 --> Loader Class Initialized
INFO - 2020-11-17 01:36:40 --> Helper loaded: url_helper
INFO - 2020-11-17 01:36:40 --> Helper loaded: file_helper
INFO - 2020-11-17 01:36:40 --> Helper loaded: form_helper
INFO - 2020-11-17 01:36:40 --> Helper loaded: my_helper
INFO - 2020-11-17 01:36:40 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:36:40 --> Controller Class Initialized
DEBUG - 2020-11-17 01:36:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 01:36:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:36:40 --> Final output sent to browser
DEBUG - 2020-11-17 01:36:40 --> Total execution time: 0.5297
INFO - 2020-11-17 01:36:42 --> Config Class Initialized
INFO - 2020-11-17 01:36:42 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:36:42 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:36:42 --> Utf8 Class Initialized
INFO - 2020-11-17 01:36:42 --> URI Class Initialized
INFO - 2020-11-17 01:36:42 --> Router Class Initialized
INFO - 2020-11-17 01:36:42 --> Output Class Initialized
INFO - 2020-11-17 01:36:42 --> Security Class Initialized
DEBUG - 2020-11-17 01:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:36:42 --> Input Class Initialized
INFO - 2020-11-17 01:36:42 --> Language Class Initialized
INFO - 2020-11-17 01:36:42 --> Language Class Initialized
INFO - 2020-11-17 01:36:42 --> Config Class Initialized
INFO - 2020-11-17 01:36:42 --> Loader Class Initialized
INFO - 2020-11-17 01:36:42 --> Helper loaded: url_helper
INFO - 2020-11-17 01:36:42 --> Helper loaded: file_helper
INFO - 2020-11-17 01:36:42 --> Helper loaded: form_helper
INFO - 2020-11-17 01:36:42 --> Helper loaded: my_helper
INFO - 2020-11-17 01:36:42 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:36:42 --> Controller Class Initialized
INFO - 2020-11-17 01:36:42 --> Helper loaded: cookie_helper
INFO - 2020-11-17 01:36:42 --> Config Class Initialized
INFO - 2020-11-17 01:36:42 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:36:42 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:36:42 --> Utf8 Class Initialized
INFO - 2020-11-17 01:36:42 --> URI Class Initialized
INFO - 2020-11-17 01:36:42 --> Router Class Initialized
INFO - 2020-11-17 01:36:43 --> Output Class Initialized
INFO - 2020-11-17 01:36:43 --> Security Class Initialized
DEBUG - 2020-11-17 01:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:36:43 --> Input Class Initialized
INFO - 2020-11-17 01:36:43 --> Language Class Initialized
INFO - 2020-11-17 01:36:43 --> Language Class Initialized
INFO - 2020-11-17 01:36:43 --> Config Class Initialized
INFO - 2020-11-17 01:36:43 --> Loader Class Initialized
INFO - 2020-11-17 01:36:43 --> Helper loaded: url_helper
INFO - 2020-11-17 01:36:43 --> Helper loaded: file_helper
INFO - 2020-11-17 01:36:43 --> Helper loaded: form_helper
INFO - 2020-11-17 01:36:43 --> Helper loaded: my_helper
INFO - 2020-11-17 01:36:43 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:36:43 --> Controller Class Initialized
DEBUG - 2020-11-17 01:36:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 01:36:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:36:43 --> Final output sent to browser
DEBUG - 2020-11-17 01:36:43 --> Total execution time: 0.8077
INFO - 2020-11-17 01:36:49 --> Config Class Initialized
INFO - 2020-11-17 01:36:49 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:36:49 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:36:49 --> Utf8 Class Initialized
INFO - 2020-11-17 01:36:49 --> URI Class Initialized
INFO - 2020-11-17 01:36:49 --> Router Class Initialized
INFO - 2020-11-17 01:36:49 --> Output Class Initialized
INFO - 2020-11-17 01:36:49 --> Security Class Initialized
DEBUG - 2020-11-17 01:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:36:50 --> Input Class Initialized
INFO - 2020-11-17 01:36:50 --> Language Class Initialized
INFO - 2020-11-17 01:36:50 --> Language Class Initialized
INFO - 2020-11-17 01:36:50 --> Config Class Initialized
INFO - 2020-11-17 01:36:50 --> Loader Class Initialized
INFO - 2020-11-17 01:36:50 --> Helper loaded: url_helper
INFO - 2020-11-17 01:36:50 --> Helper loaded: file_helper
INFO - 2020-11-17 01:36:50 --> Helper loaded: form_helper
INFO - 2020-11-17 01:36:50 --> Helper loaded: my_helper
INFO - 2020-11-17 01:36:50 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:36:50 --> Controller Class Initialized
INFO - 2020-11-17 01:36:50 --> Helper loaded: cookie_helper
INFO - 2020-11-17 01:36:50 --> Final output sent to browser
DEBUG - 2020-11-17 01:36:50 --> Total execution time: 0.7030
INFO - 2020-11-17 01:36:51 --> Config Class Initialized
INFO - 2020-11-17 01:36:51 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:36:51 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:36:51 --> Utf8 Class Initialized
INFO - 2020-11-17 01:36:51 --> URI Class Initialized
INFO - 2020-11-17 01:36:52 --> Router Class Initialized
INFO - 2020-11-17 01:36:52 --> Output Class Initialized
INFO - 2020-11-17 01:36:52 --> Security Class Initialized
DEBUG - 2020-11-17 01:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:36:52 --> Input Class Initialized
INFO - 2020-11-17 01:36:52 --> Language Class Initialized
INFO - 2020-11-17 01:36:52 --> Language Class Initialized
INFO - 2020-11-17 01:36:52 --> Config Class Initialized
INFO - 2020-11-17 01:36:52 --> Loader Class Initialized
INFO - 2020-11-17 01:36:52 --> Helper loaded: url_helper
INFO - 2020-11-17 01:36:52 --> Helper loaded: file_helper
INFO - 2020-11-17 01:36:52 --> Helper loaded: form_helper
INFO - 2020-11-17 01:36:52 --> Helper loaded: my_helper
INFO - 2020-11-17 01:36:52 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:36:52 --> Controller Class Initialized
DEBUG - 2020-11-17 01:36:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 01:36:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:36:52 --> Final output sent to browser
DEBUG - 2020-11-17 01:36:52 --> Total execution time: 0.7354
INFO - 2020-11-17 01:37:01 --> Config Class Initialized
INFO - 2020-11-17 01:37:01 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:37:01 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:37:01 --> Utf8 Class Initialized
INFO - 2020-11-17 01:37:01 --> URI Class Initialized
INFO - 2020-11-17 01:37:01 --> Router Class Initialized
INFO - 2020-11-17 01:37:01 --> Output Class Initialized
INFO - 2020-11-17 01:37:01 --> Security Class Initialized
DEBUG - 2020-11-17 01:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:37:01 --> Input Class Initialized
INFO - 2020-11-17 01:37:01 --> Language Class Initialized
INFO - 2020-11-17 01:37:01 --> Language Class Initialized
INFO - 2020-11-17 01:37:01 --> Config Class Initialized
INFO - 2020-11-17 01:37:01 --> Loader Class Initialized
INFO - 2020-11-17 01:37:01 --> Helper loaded: url_helper
INFO - 2020-11-17 01:37:01 --> Helper loaded: file_helper
INFO - 2020-11-17 01:37:01 --> Helper loaded: form_helper
INFO - 2020-11-17 01:37:01 --> Helper loaded: my_helper
INFO - 2020-11-17 01:37:02 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:37:02 --> Controller Class Initialized
DEBUG - 2020-11-17 01:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 01:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:37:02 --> Final output sent to browser
DEBUG - 2020-11-17 01:37:02 --> Total execution time: 0.9221
INFO - 2020-11-17 01:37:09 --> Config Class Initialized
INFO - 2020-11-17 01:37:09 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:37:09 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:37:09 --> Utf8 Class Initialized
INFO - 2020-11-17 01:37:09 --> URI Class Initialized
INFO - 2020-11-17 01:37:09 --> Router Class Initialized
INFO - 2020-11-17 01:37:09 --> Output Class Initialized
INFO - 2020-11-17 01:37:10 --> Security Class Initialized
DEBUG - 2020-11-17 01:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:37:10 --> Input Class Initialized
INFO - 2020-11-17 01:37:10 --> Language Class Initialized
INFO - 2020-11-17 01:37:10 --> Language Class Initialized
INFO - 2020-11-17 01:37:10 --> Config Class Initialized
INFO - 2020-11-17 01:37:10 --> Loader Class Initialized
INFO - 2020-11-17 01:37:10 --> Helper loaded: url_helper
INFO - 2020-11-17 01:37:10 --> Helper loaded: file_helper
INFO - 2020-11-17 01:37:10 --> Helper loaded: form_helper
INFO - 2020-11-17 01:37:10 --> Helper loaded: my_helper
INFO - 2020-11-17 01:37:10 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:37:10 --> Controller Class Initialized
DEBUG - 2020-11-17 01:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-17 01:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:37:10 --> Final output sent to browser
DEBUG - 2020-11-17 01:37:10 --> Total execution time: 0.8116
INFO - 2020-11-17 01:37:20 --> Config Class Initialized
INFO - 2020-11-17 01:37:20 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:37:20 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:37:20 --> Utf8 Class Initialized
INFO - 2020-11-17 01:37:20 --> URI Class Initialized
INFO - 2020-11-17 01:37:20 --> Router Class Initialized
INFO - 2020-11-17 01:37:20 --> Output Class Initialized
INFO - 2020-11-17 01:37:20 --> Security Class Initialized
DEBUG - 2020-11-17 01:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:37:20 --> Input Class Initialized
INFO - 2020-11-17 01:37:20 --> Language Class Initialized
INFO - 2020-11-17 01:37:20 --> Language Class Initialized
INFO - 2020-11-17 01:37:20 --> Config Class Initialized
INFO - 2020-11-17 01:37:20 --> Loader Class Initialized
INFO - 2020-11-17 01:37:20 --> Helper loaded: url_helper
INFO - 2020-11-17 01:37:20 --> Helper loaded: file_helper
INFO - 2020-11-17 01:37:20 --> Helper loaded: form_helper
INFO - 2020-11-17 01:37:20 --> Helper loaded: my_helper
INFO - 2020-11-17 01:37:21 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:37:21 --> Controller Class Initialized
DEBUG - 2020-11-17 01:37:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 01:37:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:37:21 --> Final output sent to browser
DEBUG - 2020-11-17 01:37:21 --> Total execution time: 0.8160
INFO - 2020-11-17 01:37:48 --> Config Class Initialized
INFO - 2020-11-17 01:37:48 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:37:48 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:37:48 --> Utf8 Class Initialized
INFO - 2020-11-17 01:37:48 --> URI Class Initialized
INFO - 2020-11-17 01:37:48 --> Router Class Initialized
INFO - 2020-11-17 01:37:48 --> Output Class Initialized
INFO - 2020-11-17 01:37:48 --> Security Class Initialized
DEBUG - 2020-11-17 01:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:37:48 --> Input Class Initialized
INFO - 2020-11-17 01:37:48 --> Language Class Initialized
INFO - 2020-11-17 01:37:48 --> Language Class Initialized
INFO - 2020-11-17 01:37:48 --> Config Class Initialized
INFO - 2020-11-17 01:37:48 --> Loader Class Initialized
INFO - 2020-11-17 01:37:48 --> Helper loaded: url_helper
INFO - 2020-11-17 01:37:48 --> Helper loaded: file_helper
INFO - 2020-11-17 01:37:48 --> Helper loaded: form_helper
INFO - 2020-11-17 01:37:48 --> Helper loaded: my_helper
INFO - 2020-11-17 01:37:48 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:37:48 --> Controller Class Initialized
DEBUG - 2020-11-17 01:37:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 01:37:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:37:48 --> Final output sent to browser
DEBUG - 2020-11-17 01:37:48 --> Total execution time: 0.6003
INFO - 2020-11-17 01:38:57 --> Config Class Initialized
INFO - 2020-11-17 01:38:57 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:38:57 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:38:57 --> Utf8 Class Initialized
INFO - 2020-11-17 01:38:57 --> URI Class Initialized
INFO - 2020-11-17 01:38:57 --> Router Class Initialized
INFO - 2020-11-17 01:38:57 --> Output Class Initialized
INFO - 2020-11-17 01:38:57 --> Security Class Initialized
DEBUG - 2020-11-17 01:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:38:57 --> Input Class Initialized
INFO - 2020-11-17 01:38:57 --> Language Class Initialized
INFO - 2020-11-17 01:38:57 --> Language Class Initialized
INFO - 2020-11-17 01:38:57 --> Config Class Initialized
INFO - 2020-11-17 01:38:57 --> Loader Class Initialized
INFO - 2020-11-17 01:38:57 --> Helper loaded: url_helper
INFO - 2020-11-17 01:38:58 --> Helper loaded: file_helper
INFO - 2020-11-17 01:38:58 --> Helper loaded: form_helper
INFO - 2020-11-17 01:38:58 --> Helper loaded: my_helper
INFO - 2020-11-17 01:38:58 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:38:58 --> Controller Class Initialized
DEBUG - 2020-11-17 01:38:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-17 01:38:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:38:58 --> Final output sent to browser
DEBUG - 2020-11-17 01:38:58 --> Total execution time: 0.8250
INFO - 2020-11-17 01:39:00 --> Config Class Initialized
INFO - 2020-11-17 01:39:00 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:39:00 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:39:00 --> Utf8 Class Initialized
INFO - 2020-11-17 01:39:00 --> URI Class Initialized
INFO - 2020-11-17 01:39:00 --> Router Class Initialized
INFO - 2020-11-17 01:39:00 --> Output Class Initialized
INFO - 2020-11-17 01:39:00 --> Security Class Initialized
DEBUG - 2020-11-17 01:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:39:00 --> Input Class Initialized
INFO - 2020-11-17 01:39:00 --> Language Class Initialized
INFO - 2020-11-17 01:39:00 --> Language Class Initialized
INFO - 2020-11-17 01:39:00 --> Config Class Initialized
INFO - 2020-11-17 01:39:00 --> Loader Class Initialized
INFO - 2020-11-17 01:39:00 --> Helper loaded: url_helper
INFO - 2020-11-17 01:39:00 --> Helper loaded: file_helper
INFO - 2020-11-17 01:39:00 --> Helper loaded: form_helper
INFO - 2020-11-17 01:39:00 --> Helper loaded: my_helper
INFO - 2020-11-17 01:39:00 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:39:00 --> Controller Class Initialized
DEBUG - 2020-11-17 01:39:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 01:39:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:39:00 --> Final output sent to browser
DEBUG - 2020-11-17 01:39:00 --> Total execution time: 0.5233
INFO - 2020-11-17 01:39:04 --> Config Class Initialized
INFO - 2020-11-17 01:39:04 --> Hooks Class Initialized
DEBUG - 2020-11-17 01:39:04 --> UTF-8 Support Enabled
INFO - 2020-11-17 01:39:04 --> Utf8 Class Initialized
INFO - 2020-11-17 01:39:04 --> URI Class Initialized
INFO - 2020-11-17 01:39:04 --> Router Class Initialized
INFO - 2020-11-17 01:39:04 --> Output Class Initialized
INFO - 2020-11-17 01:39:04 --> Security Class Initialized
DEBUG - 2020-11-17 01:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 01:39:04 --> Input Class Initialized
INFO - 2020-11-17 01:39:04 --> Language Class Initialized
INFO - 2020-11-17 01:39:04 --> Language Class Initialized
INFO - 2020-11-17 01:39:04 --> Config Class Initialized
INFO - 2020-11-17 01:39:04 --> Loader Class Initialized
INFO - 2020-11-17 01:39:04 --> Helper loaded: url_helper
INFO - 2020-11-17 01:39:04 --> Helper loaded: file_helper
INFO - 2020-11-17 01:39:04 --> Helper loaded: form_helper
INFO - 2020-11-17 01:39:04 --> Helper loaded: my_helper
INFO - 2020-11-17 01:39:04 --> Database Driver Class Initialized
DEBUG - 2020-11-17 01:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 01:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 01:39:04 --> Controller Class Initialized
DEBUG - 2020-11-17 01:39:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-17 01:39:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 01:39:05 --> Final output sent to browser
DEBUG - 2020-11-17 01:39:05 --> Total execution time: 0.8766
INFO - 2020-11-17 02:01:45 --> Config Class Initialized
INFO - 2020-11-17 02:01:45 --> Hooks Class Initialized
DEBUG - 2020-11-17 02:01:45 --> UTF-8 Support Enabled
INFO - 2020-11-17 02:01:45 --> Utf8 Class Initialized
INFO - 2020-11-17 02:01:45 --> URI Class Initialized
INFO - 2020-11-17 02:01:45 --> Router Class Initialized
INFO - 2020-11-17 02:01:45 --> Output Class Initialized
INFO - 2020-11-17 02:01:45 --> Security Class Initialized
DEBUG - 2020-11-17 02:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 02:01:45 --> Input Class Initialized
INFO - 2020-11-17 02:01:45 --> Language Class Initialized
INFO - 2020-11-17 02:01:45 --> Language Class Initialized
INFO - 2020-11-17 02:01:45 --> Config Class Initialized
INFO - 2020-11-17 02:01:45 --> Loader Class Initialized
INFO - 2020-11-17 02:01:45 --> Helper loaded: url_helper
INFO - 2020-11-17 02:01:45 --> Helper loaded: file_helper
INFO - 2020-11-17 02:01:45 --> Helper loaded: form_helper
INFO - 2020-11-17 02:01:45 --> Helper loaded: my_helper
INFO - 2020-11-17 02:01:45 --> Database Driver Class Initialized
DEBUG - 2020-11-17 02:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 02:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 02:01:45 --> Controller Class Initialized
DEBUG - 2020-11-17 02:01:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 02:01:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 02:01:46 --> Final output sent to browser
DEBUG - 2020-11-17 02:01:46 --> Total execution time: 0.8635
INFO - 2020-11-17 02:05:06 --> Config Class Initialized
INFO - 2020-11-17 02:05:06 --> Hooks Class Initialized
DEBUG - 2020-11-17 02:05:06 --> UTF-8 Support Enabled
INFO - 2020-11-17 02:05:06 --> Utf8 Class Initialized
INFO - 2020-11-17 02:05:06 --> URI Class Initialized
INFO - 2020-11-17 02:05:06 --> Router Class Initialized
INFO - 2020-11-17 02:05:06 --> Output Class Initialized
INFO - 2020-11-17 02:05:06 --> Security Class Initialized
DEBUG - 2020-11-17 02:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 02:05:06 --> Input Class Initialized
INFO - 2020-11-17 02:05:06 --> Language Class Initialized
INFO - 2020-11-17 02:05:06 --> Language Class Initialized
INFO - 2020-11-17 02:05:06 --> Config Class Initialized
INFO - 2020-11-17 02:05:06 --> Loader Class Initialized
INFO - 2020-11-17 02:05:06 --> Helper loaded: url_helper
INFO - 2020-11-17 02:05:06 --> Helper loaded: file_helper
INFO - 2020-11-17 02:05:06 --> Helper loaded: form_helper
INFO - 2020-11-17 02:05:06 --> Helper loaded: my_helper
INFO - 2020-11-17 02:05:06 --> Database Driver Class Initialized
DEBUG - 2020-11-17 02:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 02:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 02:05:06 --> Controller Class Initialized
DEBUG - 2020-11-17 02:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-17 02:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 02:05:06 --> Final output sent to browser
DEBUG - 2020-11-17 02:05:06 --> Total execution time: 0.8152
INFO - 2020-11-17 02:29:44 --> Config Class Initialized
INFO - 2020-11-17 02:29:44 --> Hooks Class Initialized
DEBUG - 2020-11-17 02:29:44 --> UTF-8 Support Enabled
INFO - 2020-11-17 02:29:44 --> Utf8 Class Initialized
INFO - 2020-11-17 02:29:44 --> URI Class Initialized
INFO - 2020-11-17 02:29:44 --> Router Class Initialized
INFO - 2020-11-17 02:29:44 --> Output Class Initialized
INFO - 2020-11-17 02:29:44 --> Security Class Initialized
DEBUG - 2020-11-17 02:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 02:29:44 --> Input Class Initialized
INFO - 2020-11-17 02:29:44 --> Language Class Initialized
INFO - 2020-11-17 02:29:44 --> Language Class Initialized
INFO - 2020-11-17 02:29:44 --> Config Class Initialized
INFO - 2020-11-17 02:29:44 --> Loader Class Initialized
INFO - 2020-11-17 02:29:44 --> Helper loaded: url_helper
INFO - 2020-11-17 02:29:44 --> Helper loaded: file_helper
INFO - 2020-11-17 02:29:44 --> Helper loaded: form_helper
INFO - 2020-11-17 02:29:44 --> Helper loaded: my_helper
INFO - 2020-11-17 02:29:44 --> Database Driver Class Initialized
DEBUG - 2020-11-17 02:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 02:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 02:29:44 --> Controller Class Initialized
DEBUG - 2020-11-17 02:29:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-17 02:29:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 02:29:44 --> Final output sent to browser
DEBUG - 2020-11-17 02:29:44 --> Total execution time: 0.7932
INFO - 2020-11-17 02:29:46 --> Config Class Initialized
INFO - 2020-11-17 02:29:46 --> Hooks Class Initialized
DEBUG - 2020-11-17 02:29:46 --> UTF-8 Support Enabled
INFO - 2020-11-17 02:29:46 --> Utf8 Class Initialized
INFO - 2020-11-17 02:29:46 --> URI Class Initialized
INFO - 2020-11-17 02:29:46 --> Router Class Initialized
INFO - 2020-11-17 02:29:46 --> Output Class Initialized
INFO - 2020-11-17 02:29:46 --> Security Class Initialized
DEBUG - 2020-11-17 02:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 02:29:46 --> Input Class Initialized
INFO - 2020-11-17 02:29:46 --> Language Class Initialized
INFO - 2020-11-17 02:29:46 --> Language Class Initialized
INFO - 2020-11-17 02:29:46 --> Config Class Initialized
INFO - 2020-11-17 02:29:46 --> Loader Class Initialized
INFO - 2020-11-17 02:29:46 --> Helper loaded: url_helper
INFO - 2020-11-17 02:29:46 --> Helper loaded: file_helper
INFO - 2020-11-17 02:29:46 --> Helper loaded: form_helper
INFO - 2020-11-17 02:29:47 --> Helper loaded: my_helper
INFO - 2020-11-17 02:29:47 --> Database Driver Class Initialized
DEBUG - 2020-11-17 02:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 02:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 02:29:47 --> Controller Class Initialized
INFO - 2020-11-17 02:29:47 --> Final output sent to browser
DEBUG - 2020-11-17 02:29:47 --> Total execution time: 0.5912
INFO - 2020-11-17 02:29:51 --> Config Class Initialized
INFO - 2020-11-17 02:29:51 --> Hooks Class Initialized
DEBUG - 2020-11-17 02:29:51 --> UTF-8 Support Enabled
INFO - 2020-11-17 02:29:51 --> Utf8 Class Initialized
INFO - 2020-11-17 02:29:51 --> URI Class Initialized
INFO - 2020-11-17 02:29:51 --> Router Class Initialized
INFO - 2020-11-17 02:29:51 --> Output Class Initialized
INFO - 2020-11-17 02:29:51 --> Security Class Initialized
DEBUG - 2020-11-17 02:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 02:29:51 --> Input Class Initialized
INFO - 2020-11-17 02:29:51 --> Language Class Initialized
INFO - 2020-11-17 02:29:51 --> Language Class Initialized
INFO - 2020-11-17 02:29:51 --> Config Class Initialized
INFO - 2020-11-17 02:29:51 --> Loader Class Initialized
INFO - 2020-11-17 02:29:52 --> Helper loaded: url_helper
INFO - 2020-11-17 02:29:52 --> Helper loaded: file_helper
INFO - 2020-11-17 02:29:52 --> Helper loaded: form_helper
INFO - 2020-11-17 02:29:52 --> Helper loaded: my_helper
INFO - 2020-11-17 02:29:52 --> Database Driver Class Initialized
DEBUG - 2020-11-17 02:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 02:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 02:29:52 --> Controller Class Initialized
INFO - 2020-11-17 02:29:52 --> Final output sent to browser
DEBUG - 2020-11-17 02:29:52 --> Total execution time: 0.7574
INFO - 2020-11-17 04:30:11 --> Config Class Initialized
INFO - 2020-11-17 04:30:11 --> Hooks Class Initialized
DEBUG - 2020-11-17 04:30:11 --> UTF-8 Support Enabled
INFO - 2020-11-17 04:30:11 --> Utf8 Class Initialized
INFO - 2020-11-17 04:30:11 --> URI Class Initialized
DEBUG - 2020-11-17 04:30:11 --> No URI present. Default controller set.
INFO - 2020-11-17 04:30:11 --> Router Class Initialized
INFO - 2020-11-17 04:30:11 --> Output Class Initialized
INFO - 2020-11-17 04:30:11 --> Security Class Initialized
DEBUG - 2020-11-17 04:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 04:30:11 --> Input Class Initialized
INFO - 2020-11-17 04:30:11 --> Language Class Initialized
INFO - 2020-11-17 04:30:11 --> Language Class Initialized
INFO - 2020-11-17 04:30:12 --> Config Class Initialized
INFO - 2020-11-17 04:30:12 --> Loader Class Initialized
INFO - 2020-11-17 04:30:12 --> Helper loaded: url_helper
INFO - 2020-11-17 04:30:12 --> Helper loaded: file_helper
INFO - 2020-11-17 04:30:12 --> Helper loaded: form_helper
INFO - 2020-11-17 04:30:12 --> Helper loaded: my_helper
INFO - 2020-11-17 04:30:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 04:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 04:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 04:30:12 --> Controller Class Initialized
INFO - 2020-11-17 04:30:12 --> Config Class Initialized
INFO - 2020-11-17 04:30:12 --> Hooks Class Initialized
DEBUG - 2020-11-17 04:30:12 --> UTF-8 Support Enabled
INFO - 2020-11-17 04:30:13 --> Utf8 Class Initialized
INFO - 2020-11-17 04:30:13 --> URI Class Initialized
INFO - 2020-11-17 04:30:13 --> Router Class Initialized
INFO - 2020-11-17 04:30:13 --> Output Class Initialized
INFO - 2020-11-17 04:30:13 --> Security Class Initialized
DEBUG - 2020-11-17 04:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 04:30:13 --> Input Class Initialized
INFO - 2020-11-17 04:30:13 --> Language Class Initialized
INFO - 2020-11-17 04:30:13 --> Language Class Initialized
INFO - 2020-11-17 04:30:13 --> Config Class Initialized
INFO - 2020-11-17 04:30:13 --> Loader Class Initialized
INFO - 2020-11-17 04:30:13 --> Helper loaded: url_helper
INFO - 2020-11-17 04:30:13 --> Helper loaded: file_helper
INFO - 2020-11-17 04:30:13 --> Helper loaded: form_helper
INFO - 2020-11-17 04:30:13 --> Helper loaded: my_helper
INFO - 2020-11-17 04:30:13 --> Database Driver Class Initialized
DEBUG - 2020-11-17 04:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 04:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 04:30:13 --> Controller Class Initialized
DEBUG - 2020-11-17 04:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 04:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 04:30:13 --> Final output sent to browser
DEBUG - 2020-11-17 04:30:13 --> Total execution time: 0.7426
INFO - 2020-11-17 04:30:21 --> Config Class Initialized
INFO - 2020-11-17 04:30:21 --> Hooks Class Initialized
DEBUG - 2020-11-17 04:30:21 --> UTF-8 Support Enabled
INFO - 2020-11-17 04:30:21 --> Utf8 Class Initialized
INFO - 2020-11-17 04:30:21 --> URI Class Initialized
INFO - 2020-11-17 04:30:21 --> Router Class Initialized
INFO - 2020-11-17 04:30:22 --> Output Class Initialized
INFO - 2020-11-17 04:30:22 --> Security Class Initialized
DEBUG - 2020-11-17 04:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 04:30:22 --> Input Class Initialized
INFO - 2020-11-17 04:30:22 --> Language Class Initialized
INFO - 2020-11-17 04:30:22 --> Language Class Initialized
INFO - 2020-11-17 04:30:22 --> Config Class Initialized
INFO - 2020-11-17 04:30:22 --> Loader Class Initialized
INFO - 2020-11-17 04:30:22 --> Helper loaded: url_helper
INFO - 2020-11-17 04:30:22 --> Helper loaded: file_helper
INFO - 2020-11-17 04:30:22 --> Helper loaded: form_helper
INFO - 2020-11-17 04:30:22 --> Helper loaded: my_helper
INFO - 2020-11-17 04:30:22 --> Database Driver Class Initialized
DEBUG - 2020-11-17 04:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 04:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 04:30:22 --> Controller Class Initialized
INFO - 2020-11-17 04:30:22 --> Helper loaded: cookie_helper
INFO - 2020-11-17 04:30:22 --> Final output sent to browser
DEBUG - 2020-11-17 04:30:22 --> Total execution time: 0.9138
INFO - 2020-11-17 04:30:24 --> Config Class Initialized
INFO - 2020-11-17 04:30:24 --> Hooks Class Initialized
DEBUG - 2020-11-17 04:30:24 --> UTF-8 Support Enabled
INFO - 2020-11-17 04:30:24 --> Utf8 Class Initialized
INFO - 2020-11-17 04:30:25 --> URI Class Initialized
INFO - 2020-11-17 04:30:25 --> Router Class Initialized
INFO - 2020-11-17 04:30:25 --> Output Class Initialized
INFO - 2020-11-17 04:30:25 --> Security Class Initialized
DEBUG - 2020-11-17 04:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 04:30:25 --> Input Class Initialized
INFO - 2020-11-17 04:30:25 --> Language Class Initialized
INFO - 2020-11-17 04:30:25 --> Language Class Initialized
INFO - 2020-11-17 04:30:25 --> Config Class Initialized
INFO - 2020-11-17 04:30:25 --> Loader Class Initialized
INFO - 2020-11-17 04:30:25 --> Helper loaded: url_helper
INFO - 2020-11-17 04:30:25 --> Helper loaded: file_helper
INFO - 2020-11-17 04:30:25 --> Helper loaded: form_helper
INFO - 2020-11-17 04:30:25 --> Helper loaded: my_helper
INFO - 2020-11-17 04:30:25 --> Database Driver Class Initialized
DEBUG - 2020-11-17 04:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 04:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 04:30:25 --> Controller Class Initialized
DEBUG - 2020-11-17 04:30:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 04:30:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 04:30:25 --> Final output sent to browser
DEBUG - 2020-11-17 04:30:25 --> Total execution time: 0.8075
INFO - 2020-11-17 04:31:54 --> Config Class Initialized
INFO - 2020-11-17 04:31:54 --> Hooks Class Initialized
DEBUG - 2020-11-17 04:31:54 --> UTF-8 Support Enabled
INFO - 2020-11-17 04:31:54 --> Utf8 Class Initialized
INFO - 2020-11-17 04:31:54 --> URI Class Initialized
INFO - 2020-11-17 04:31:54 --> Router Class Initialized
INFO - 2020-11-17 04:31:54 --> Output Class Initialized
INFO - 2020-11-17 04:31:54 --> Security Class Initialized
DEBUG - 2020-11-17 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 04:31:54 --> Input Class Initialized
INFO - 2020-11-17 04:31:54 --> Language Class Initialized
INFO - 2020-11-17 04:31:54 --> Language Class Initialized
INFO - 2020-11-17 04:31:54 --> Config Class Initialized
INFO - 2020-11-17 04:31:54 --> Loader Class Initialized
INFO - 2020-11-17 04:31:54 --> Helper loaded: url_helper
INFO - 2020-11-17 04:31:54 --> Helper loaded: file_helper
INFO - 2020-11-17 04:31:54 --> Helper loaded: form_helper
INFO - 2020-11-17 04:31:54 --> Helper loaded: my_helper
INFO - 2020-11-17 04:31:54 --> Database Driver Class Initialized
DEBUG - 2020-11-17 04:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 04:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 04:31:54 --> Controller Class Initialized
DEBUG - 2020-11-17 04:31:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 04:31:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 04:31:54 --> Final output sent to browser
DEBUG - 2020-11-17 04:31:54 --> Total execution time: 0.7273
INFO - 2020-11-17 04:32:29 --> Config Class Initialized
INFO - 2020-11-17 04:32:29 --> Hooks Class Initialized
DEBUG - 2020-11-17 04:32:29 --> UTF-8 Support Enabled
INFO - 2020-11-17 04:32:29 --> Utf8 Class Initialized
INFO - 2020-11-17 04:32:29 --> URI Class Initialized
INFO - 2020-11-17 04:32:29 --> Router Class Initialized
INFO - 2020-11-17 04:32:29 --> Output Class Initialized
INFO - 2020-11-17 04:32:29 --> Security Class Initialized
DEBUG - 2020-11-17 04:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 04:32:29 --> Input Class Initialized
INFO - 2020-11-17 04:32:29 --> Language Class Initialized
INFO - 2020-11-17 04:32:29 --> Language Class Initialized
INFO - 2020-11-17 04:32:29 --> Config Class Initialized
INFO - 2020-11-17 04:32:30 --> Loader Class Initialized
INFO - 2020-11-17 04:32:30 --> Helper loaded: url_helper
INFO - 2020-11-17 04:32:30 --> Helper loaded: file_helper
INFO - 2020-11-17 04:32:30 --> Helper loaded: form_helper
INFO - 2020-11-17 04:32:30 --> Helper loaded: my_helper
INFO - 2020-11-17 04:32:30 --> Database Driver Class Initialized
DEBUG - 2020-11-17 04:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 04:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 04:32:30 --> Controller Class Initialized
DEBUG - 2020-11-17 04:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-17 04:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 04:32:30 --> Final output sent to browser
DEBUG - 2020-11-17 04:32:30 --> Total execution time: 0.8246
INFO - 2020-11-17 04:32:30 --> Config Class Initialized
INFO - 2020-11-17 04:32:30 --> Hooks Class Initialized
DEBUG - 2020-11-17 04:32:30 --> UTF-8 Support Enabled
INFO - 2020-11-17 04:32:30 --> Utf8 Class Initialized
INFO - 2020-11-17 04:32:30 --> URI Class Initialized
INFO - 2020-11-17 04:32:30 --> Router Class Initialized
INFO - 2020-11-17 04:32:30 --> Output Class Initialized
INFO - 2020-11-17 04:32:30 --> Security Class Initialized
DEBUG - 2020-11-17 04:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 04:32:30 --> Input Class Initialized
INFO - 2020-11-17 04:32:30 --> Language Class Initialized
INFO - 2020-11-17 04:32:30 --> Language Class Initialized
INFO - 2020-11-17 04:32:30 --> Config Class Initialized
INFO - 2020-11-17 04:32:30 --> Loader Class Initialized
INFO - 2020-11-17 04:32:30 --> Helper loaded: url_helper
INFO - 2020-11-17 04:32:30 --> Helper loaded: file_helper
INFO - 2020-11-17 04:32:30 --> Helper loaded: form_helper
INFO - 2020-11-17 04:32:31 --> Helper loaded: my_helper
INFO - 2020-11-17 04:32:31 --> Database Driver Class Initialized
DEBUG - 2020-11-17 04:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 04:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 04:32:31 --> Controller Class Initialized
INFO - 2020-11-17 06:58:23 --> Config Class Initialized
INFO - 2020-11-17 06:58:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 06:58:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 06:58:23 --> Utf8 Class Initialized
INFO - 2020-11-17 06:58:23 --> URI Class Initialized
INFO - 2020-11-17 06:58:23 --> Router Class Initialized
INFO - 2020-11-17 06:58:23 --> Output Class Initialized
INFO - 2020-11-17 06:58:23 --> Security Class Initialized
DEBUG - 2020-11-17 06:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 06:58:23 --> Input Class Initialized
INFO - 2020-11-17 06:58:23 --> Language Class Initialized
INFO - 2020-11-17 06:58:23 --> Language Class Initialized
INFO - 2020-11-17 06:58:23 --> Config Class Initialized
INFO - 2020-11-17 06:58:23 --> Loader Class Initialized
INFO - 2020-11-17 06:58:23 --> Helper loaded: url_helper
INFO - 2020-11-17 06:58:23 --> Helper loaded: file_helper
INFO - 2020-11-17 06:58:23 --> Helper loaded: form_helper
INFO - 2020-11-17 06:58:23 --> Helper loaded: my_helper
INFO - 2020-11-17 06:58:24 --> Database Driver Class Initialized
DEBUG - 2020-11-17 06:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 06:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 06:58:24 --> Controller Class Initialized
DEBUG - 2020-11-17 06:58:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-17 06:58:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 06:58:24 --> Final output sent to browser
DEBUG - 2020-11-17 06:58:24 --> Total execution time: 0.7276
INFO - 2020-11-17 07:02:47 --> Config Class Initialized
INFO - 2020-11-17 07:02:47 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:02:47 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:02:47 --> Utf8 Class Initialized
INFO - 2020-11-17 07:02:47 --> URI Class Initialized
INFO - 2020-11-17 07:02:47 --> Router Class Initialized
INFO - 2020-11-17 07:02:47 --> Output Class Initialized
INFO - 2020-11-17 07:02:47 --> Security Class Initialized
DEBUG - 2020-11-17 07:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:02:47 --> Input Class Initialized
INFO - 2020-11-17 07:02:47 --> Language Class Initialized
INFO - 2020-11-17 07:02:47 --> Language Class Initialized
INFO - 2020-11-17 07:02:47 --> Config Class Initialized
INFO - 2020-11-17 07:02:47 --> Loader Class Initialized
INFO - 2020-11-17 07:02:47 --> Helper loaded: url_helper
INFO - 2020-11-17 07:02:47 --> Helper loaded: file_helper
INFO - 2020-11-17 07:02:47 --> Helper loaded: form_helper
INFO - 2020-11-17 07:02:47 --> Helper loaded: my_helper
INFO - 2020-11-17 07:02:48 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:02:48 --> Controller Class Initialized
DEBUG - 2020-11-17 07:02:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 07:02:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:02:48 --> Final output sent to browser
DEBUG - 2020-11-17 07:02:48 --> Total execution time: 0.6147
INFO - 2020-11-17 07:37:26 --> Config Class Initialized
INFO - 2020-11-17 07:37:26 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:37:26 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:37:26 --> Utf8 Class Initialized
INFO - 2020-11-17 07:37:26 --> URI Class Initialized
INFO - 2020-11-17 07:37:26 --> Router Class Initialized
INFO - 2020-11-17 07:37:26 --> Output Class Initialized
INFO - 2020-11-17 07:37:26 --> Security Class Initialized
DEBUG - 2020-11-17 07:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:37:26 --> Input Class Initialized
INFO - 2020-11-17 07:37:26 --> Language Class Initialized
INFO - 2020-11-17 07:37:26 --> Language Class Initialized
INFO - 2020-11-17 07:37:26 --> Config Class Initialized
INFO - 2020-11-17 07:37:26 --> Loader Class Initialized
INFO - 2020-11-17 07:37:26 --> Helper loaded: url_helper
INFO - 2020-11-17 07:37:26 --> Helper loaded: file_helper
INFO - 2020-11-17 07:37:26 --> Helper loaded: form_helper
INFO - 2020-11-17 07:37:26 --> Helper loaded: my_helper
INFO - 2020-11-17 07:37:26 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:37:26 --> Controller Class Initialized
DEBUG - 2020-11-17 07:37:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-17 07:37:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:37:26 --> Final output sent to browser
DEBUG - 2020-11-17 07:37:26 --> Total execution time: 0.2275
INFO - 2020-11-17 07:39:47 --> Config Class Initialized
INFO - 2020-11-17 07:39:47 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:39:47 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:39:47 --> Utf8 Class Initialized
INFO - 2020-11-17 07:39:47 --> URI Class Initialized
INFO - 2020-11-17 07:39:47 --> Router Class Initialized
INFO - 2020-11-17 07:39:47 --> Output Class Initialized
INFO - 2020-11-17 07:39:47 --> Security Class Initialized
DEBUG - 2020-11-17 07:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:39:47 --> Input Class Initialized
INFO - 2020-11-17 07:39:47 --> Language Class Initialized
INFO - 2020-11-17 07:39:47 --> Language Class Initialized
INFO - 2020-11-17 07:39:47 --> Config Class Initialized
INFO - 2020-11-17 07:39:47 --> Loader Class Initialized
INFO - 2020-11-17 07:39:47 --> Helper loaded: url_helper
INFO - 2020-11-17 07:39:47 --> Helper loaded: file_helper
INFO - 2020-11-17 07:39:47 --> Helper loaded: form_helper
INFO - 2020-11-17 07:39:47 --> Helper loaded: my_helper
INFO - 2020-11-17 07:39:47 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:39:47 --> Controller Class Initialized
DEBUG - 2020-11-17 07:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-17 07:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:39:47 --> Final output sent to browser
DEBUG - 2020-11-17 07:39:47 --> Total execution time: 0.2223
INFO - 2020-11-17 07:39:49 --> Config Class Initialized
INFO - 2020-11-17 07:39:49 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:39:49 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:39:49 --> Utf8 Class Initialized
INFO - 2020-11-17 07:39:49 --> URI Class Initialized
INFO - 2020-11-17 07:39:49 --> Router Class Initialized
INFO - 2020-11-17 07:39:49 --> Output Class Initialized
INFO - 2020-11-17 07:39:49 --> Security Class Initialized
DEBUG - 2020-11-17 07:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:39:49 --> Input Class Initialized
INFO - 2020-11-17 07:39:49 --> Language Class Initialized
INFO - 2020-11-17 07:39:49 --> Language Class Initialized
INFO - 2020-11-17 07:39:49 --> Config Class Initialized
INFO - 2020-11-17 07:39:49 --> Loader Class Initialized
INFO - 2020-11-17 07:39:49 --> Helper loaded: url_helper
INFO - 2020-11-17 07:39:49 --> Helper loaded: file_helper
INFO - 2020-11-17 07:39:49 --> Helper loaded: form_helper
INFO - 2020-11-17 07:39:49 --> Helper loaded: my_helper
INFO - 2020-11-17 07:39:49 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:39:49 --> Controller Class Initialized
ERROR - 2020-11-17 07:39:49 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_karakter
                                                    FROM t_c_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-11-17 07:39:49 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-17 07:39:56 --> Config Class Initialized
INFO - 2020-11-17 07:39:56 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:39:56 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:39:56 --> Utf8 Class Initialized
INFO - 2020-11-17 07:39:57 --> URI Class Initialized
INFO - 2020-11-17 07:39:57 --> Router Class Initialized
INFO - 2020-11-17 07:39:57 --> Output Class Initialized
INFO - 2020-11-17 07:39:57 --> Security Class Initialized
DEBUG - 2020-11-17 07:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:39:57 --> Input Class Initialized
INFO - 2020-11-17 07:39:57 --> Language Class Initialized
INFO - 2020-11-17 07:39:57 --> Language Class Initialized
INFO - 2020-11-17 07:39:57 --> Config Class Initialized
INFO - 2020-11-17 07:39:57 --> Loader Class Initialized
INFO - 2020-11-17 07:39:57 --> Helper loaded: url_helper
INFO - 2020-11-17 07:39:57 --> Helper loaded: file_helper
INFO - 2020-11-17 07:39:57 --> Helper loaded: form_helper
INFO - 2020-11-17 07:39:57 --> Helper loaded: my_helper
INFO - 2020-11-17 07:39:57 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:39:57 --> Controller Class Initialized
DEBUG - 2020-11-17 07:39:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-17 07:39:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:39:57 --> Final output sent to browser
DEBUG - 2020-11-17 07:39:57 --> Total execution time: 0.2385
INFO - 2020-11-17 07:39:58 --> Config Class Initialized
INFO - 2020-11-17 07:39:58 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:39:58 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:39:58 --> Utf8 Class Initialized
INFO - 2020-11-17 07:39:58 --> URI Class Initialized
INFO - 2020-11-17 07:39:58 --> Router Class Initialized
INFO - 2020-11-17 07:39:58 --> Output Class Initialized
INFO - 2020-11-17 07:39:58 --> Security Class Initialized
DEBUG - 2020-11-17 07:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:39:58 --> Input Class Initialized
INFO - 2020-11-17 07:39:58 --> Language Class Initialized
INFO - 2020-11-17 07:39:58 --> Language Class Initialized
INFO - 2020-11-17 07:39:58 --> Config Class Initialized
INFO - 2020-11-17 07:39:58 --> Loader Class Initialized
INFO - 2020-11-17 07:39:58 --> Helper loaded: url_helper
INFO - 2020-11-17 07:39:58 --> Helper loaded: file_helper
INFO - 2020-11-17 07:39:58 --> Helper loaded: form_helper
INFO - 2020-11-17 07:39:58 --> Helper loaded: my_helper
INFO - 2020-11-17 07:39:58 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:39:58 --> Controller Class Initialized
DEBUG - 2020-11-17 07:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-17 07:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:39:58 --> Final output sent to browser
DEBUG - 2020-11-17 07:39:58 --> Total execution time: 0.2894
INFO - 2020-11-17 07:39:59 --> Config Class Initialized
INFO - 2020-11-17 07:39:59 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:39:59 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:39:59 --> Utf8 Class Initialized
INFO - 2020-11-17 07:39:59 --> URI Class Initialized
INFO - 2020-11-17 07:39:59 --> Router Class Initialized
INFO - 2020-11-17 07:39:59 --> Output Class Initialized
INFO - 2020-11-17 07:39:59 --> Security Class Initialized
DEBUG - 2020-11-17 07:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:39:59 --> Input Class Initialized
INFO - 2020-11-17 07:39:59 --> Language Class Initialized
INFO - 2020-11-17 07:39:59 --> Language Class Initialized
INFO - 2020-11-17 07:39:59 --> Config Class Initialized
INFO - 2020-11-17 07:39:59 --> Loader Class Initialized
INFO - 2020-11-17 07:39:59 --> Helper loaded: url_helper
INFO - 2020-11-17 07:39:59 --> Helper loaded: file_helper
INFO - 2020-11-17 07:39:59 --> Helper loaded: form_helper
INFO - 2020-11-17 07:39:59 --> Helper loaded: my_helper
INFO - 2020-11-17 07:39:59 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:39:59 --> Controller Class Initialized
ERROR - 2020-11-17 07:39:59 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_karakter
                                                    FROM t_c_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-11-17 07:39:59 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-17 07:41:22 --> Config Class Initialized
INFO - 2020-11-17 07:41:22 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:41:22 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:41:22 --> Utf8 Class Initialized
INFO - 2020-11-17 07:41:22 --> URI Class Initialized
INFO - 2020-11-17 07:41:22 --> Router Class Initialized
INFO - 2020-11-17 07:41:22 --> Output Class Initialized
INFO - 2020-11-17 07:41:22 --> Security Class Initialized
DEBUG - 2020-11-17 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:41:22 --> Input Class Initialized
INFO - 2020-11-17 07:41:22 --> Language Class Initialized
INFO - 2020-11-17 07:41:22 --> Language Class Initialized
INFO - 2020-11-17 07:41:22 --> Config Class Initialized
INFO - 2020-11-17 07:41:22 --> Loader Class Initialized
INFO - 2020-11-17 07:41:22 --> Helper loaded: url_helper
INFO - 2020-11-17 07:41:22 --> Helper loaded: file_helper
INFO - 2020-11-17 07:41:23 --> Helper loaded: form_helper
INFO - 2020-11-17 07:41:23 --> Helper loaded: my_helper
INFO - 2020-11-17 07:41:23 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:41:23 --> Controller Class Initialized
ERROR - 2020-11-17 07:41:23 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_karakter
                                                    FROM t_c_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-11-17 07:41:23 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-17 07:41:24 --> Config Class Initialized
INFO - 2020-11-17 07:41:24 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:41:24 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:41:24 --> Utf8 Class Initialized
INFO - 2020-11-17 07:41:24 --> URI Class Initialized
INFO - 2020-11-17 07:41:24 --> Router Class Initialized
INFO - 2020-11-17 07:41:24 --> Output Class Initialized
INFO - 2020-11-17 07:41:24 --> Security Class Initialized
DEBUG - 2020-11-17 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:41:24 --> Input Class Initialized
INFO - 2020-11-17 07:41:24 --> Language Class Initialized
INFO - 2020-11-17 07:41:24 --> Language Class Initialized
INFO - 2020-11-17 07:41:24 --> Config Class Initialized
INFO - 2020-11-17 07:41:24 --> Loader Class Initialized
INFO - 2020-11-17 07:41:24 --> Helper loaded: url_helper
INFO - 2020-11-17 07:41:24 --> Helper loaded: file_helper
INFO - 2020-11-17 07:41:24 --> Helper loaded: form_helper
INFO - 2020-11-17 07:41:24 --> Helper loaded: my_helper
INFO - 2020-11-17 07:41:24 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:41:24 --> Controller Class Initialized
DEBUG - 2020-11-17 07:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-17 07:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:41:24 --> Final output sent to browser
DEBUG - 2020-11-17 07:41:24 --> Total execution time: 0.3031
INFO - 2020-11-17 07:41:26 --> Config Class Initialized
INFO - 2020-11-17 07:41:27 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:41:27 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:41:27 --> Utf8 Class Initialized
INFO - 2020-11-17 07:41:27 --> URI Class Initialized
INFO - 2020-11-17 07:41:27 --> Router Class Initialized
INFO - 2020-11-17 07:41:27 --> Output Class Initialized
INFO - 2020-11-17 07:41:27 --> Security Class Initialized
DEBUG - 2020-11-17 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:41:27 --> Input Class Initialized
INFO - 2020-11-17 07:41:27 --> Language Class Initialized
INFO - 2020-11-17 07:41:27 --> Language Class Initialized
INFO - 2020-11-17 07:41:27 --> Config Class Initialized
INFO - 2020-11-17 07:41:27 --> Loader Class Initialized
INFO - 2020-11-17 07:41:27 --> Helper loaded: url_helper
INFO - 2020-11-17 07:41:27 --> Helper loaded: file_helper
INFO - 2020-11-17 07:41:27 --> Helper loaded: form_helper
INFO - 2020-11-17 07:41:27 --> Helper loaded: my_helper
INFO - 2020-11-17 07:41:27 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:41:27 --> Controller Class Initialized
ERROR - 2020-11-17 07:41:27 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_karakter
                                                    FROM t_c_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-11-17 07:41:27 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-17 07:43:57 --> Config Class Initialized
INFO - 2020-11-17 07:43:57 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:43:57 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:43:57 --> Utf8 Class Initialized
INFO - 2020-11-17 07:43:57 --> URI Class Initialized
INFO - 2020-11-17 07:43:57 --> Router Class Initialized
INFO - 2020-11-17 07:43:57 --> Output Class Initialized
INFO - 2020-11-17 07:43:57 --> Security Class Initialized
DEBUG - 2020-11-17 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:43:57 --> Input Class Initialized
INFO - 2020-11-17 07:43:57 --> Language Class Initialized
INFO - 2020-11-17 07:43:57 --> Language Class Initialized
INFO - 2020-11-17 07:43:57 --> Config Class Initialized
INFO - 2020-11-17 07:43:57 --> Loader Class Initialized
INFO - 2020-11-17 07:43:57 --> Helper loaded: url_helper
INFO - 2020-11-17 07:43:57 --> Helper loaded: file_helper
INFO - 2020-11-17 07:43:57 --> Helper loaded: form_helper
INFO - 2020-11-17 07:43:57 --> Helper loaded: my_helper
INFO - 2020-11-17 07:43:57 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:43:57 --> Controller Class Initialized
ERROR - 2020-11-17 07:43:57 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_karakter
                                                    FROM t_c_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-11-17 07:43:57 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-17 07:43:58 --> Config Class Initialized
INFO - 2020-11-17 07:43:58 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:43:58 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:43:58 --> Utf8 Class Initialized
INFO - 2020-11-17 07:43:58 --> URI Class Initialized
INFO - 2020-11-17 07:43:58 --> Router Class Initialized
INFO - 2020-11-17 07:43:58 --> Output Class Initialized
INFO - 2020-11-17 07:43:58 --> Security Class Initialized
DEBUG - 2020-11-17 07:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:43:58 --> Input Class Initialized
INFO - 2020-11-17 07:43:58 --> Language Class Initialized
INFO - 2020-11-17 07:43:58 --> Language Class Initialized
INFO - 2020-11-17 07:43:58 --> Config Class Initialized
INFO - 2020-11-17 07:43:58 --> Loader Class Initialized
INFO - 2020-11-17 07:43:58 --> Helper loaded: url_helper
INFO - 2020-11-17 07:43:58 --> Helper loaded: file_helper
INFO - 2020-11-17 07:43:58 --> Helper loaded: form_helper
INFO - 2020-11-17 07:43:58 --> Helper loaded: my_helper
INFO - 2020-11-17 07:43:58 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:43:58 --> Controller Class Initialized
DEBUG - 2020-11-17 07:43:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-17 07:43:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:43:58 --> Final output sent to browser
DEBUG - 2020-11-17 07:43:58 --> Total execution time: 0.2147
INFO - 2020-11-17 07:43:59 --> Config Class Initialized
INFO - 2020-11-17 07:43:59 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:43:59 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:43:59 --> Utf8 Class Initialized
INFO - 2020-11-17 07:43:59 --> URI Class Initialized
INFO - 2020-11-17 07:43:59 --> Router Class Initialized
INFO - 2020-11-17 07:43:59 --> Output Class Initialized
INFO - 2020-11-17 07:43:59 --> Security Class Initialized
DEBUG - 2020-11-17 07:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:43:59 --> Input Class Initialized
INFO - 2020-11-17 07:43:59 --> Language Class Initialized
INFO - 2020-11-17 07:43:59 --> Language Class Initialized
INFO - 2020-11-17 07:43:59 --> Config Class Initialized
INFO - 2020-11-17 07:43:59 --> Loader Class Initialized
INFO - 2020-11-17 07:43:59 --> Helper loaded: url_helper
INFO - 2020-11-17 07:43:59 --> Helper loaded: file_helper
INFO - 2020-11-17 07:43:59 --> Helper loaded: form_helper
INFO - 2020-11-17 07:43:59 --> Helper loaded: my_helper
INFO - 2020-11-17 07:43:59 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:43:59 --> Controller Class Initialized
DEBUG - 2020-11-17 07:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-17 07:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:43:59 --> Final output sent to browser
DEBUG - 2020-11-17 07:43:59 --> Total execution time: 0.2945
INFO - 2020-11-17 07:43:59 --> Config Class Initialized
INFO - 2020-11-17 07:43:59 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:44:00 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:44:00 --> Utf8 Class Initialized
INFO - 2020-11-17 07:44:00 --> URI Class Initialized
INFO - 2020-11-17 07:44:00 --> Router Class Initialized
INFO - 2020-11-17 07:44:00 --> Output Class Initialized
INFO - 2020-11-17 07:44:00 --> Security Class Initialized
DEBUG - 2020-11-17 07:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:44:00 --> Input Class Initialized
INFO - 2020-11-17 07:44:00 --> Language Class Initialized
INFO - 2020-11-17 07:44:00 --> Language Class Initialized
INFO - 2020-11-17 07:44:00 --> Config Class Initialized
INFO - 2020-11-17 07:44:00 --> Loader Class Initialized
INFO - 2020-11-17 07:44:00 --> Helper loaded: url_helper
INFO - 2020-11-17 07:44:00 --> Helper loaded: file_helper
INFO - 2020-11-17 07:44:00 --> Helper loaded: form_helper
INFO - 2020-11-17 07:44:00 --> Helper loaded: my_helper
INFO - 2020-11-17 07:44:00 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:44:00 --> Controller Class Initialized
INFO - 2020-11-17 07:44:00 --> Config Class Initialized
INFO - 2020-11-17 07:44:00 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:44:00 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:44:00 --> Utf8 Class Initialized
INFO - 2020-11-17 07:44:00 --> URI Class Initialized
INFO - 2020-11-17 07:44:01 --> Router Class Initialized
INFO - 2020-11-17 07:44:01 --> Output Class Initialized
INFO - 2020-11-17 07:44:01 --> Security Class Initialized
DEBUG - 2020-11-17 07:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:44:01 --> Input Class Initialized
INFO - 2020-11-17 07:44:01 --> Language Class Initialized
INFO - 2020-11-17 07:44:01 --> Language Class Initialized
INFO - 2020-11-17 07:44:01 --> Config Class Initialized
INFO - 2020-11-17 07:44:01 --> Loader Class Initialized
INFO - 2020-11-17 07:44:01 --> Helper loaded: url_helper
INFO - 2020-11-17 07:44:01 --> Helper loaded: file_helper
INFO - 2020-11-17 07:44:01 --> Helper loaded: form_helper
INFO - 2020-11-17 07:44:01 --> Helper loaded: my_helper
INFO - 2020-11-17 07:44:01 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:44:01 --> Controller Class Initialized
ERROR - 2020-11-17 07:44:01 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_karakter
                                                    FROM t_c_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-11-17 07:44:01 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-17 07:54:46 --> Config Class Initialized
INFO - 2020-11-17 07:54:46 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:54:46 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:54:46 --> Utf8 Class Initialized
INFO - 2020-11-17 07:54:46 --> URI Class Initialized
INFO - 2020-11-17 07:54:46 --> Router Class Initialized
INFO - 2020-11-17 07:54:46 --> Output Class Initialized
INFO - 2020-11-17 07:54:46 --> Security Class Initialized
DEBUG - 2020-11-17 07:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:54:46 --> Input Class Initialized
INFO - 2020-11-17 07:54:46 --> Language Class Initialized
INFO - 2020-11-17 07:54:46 --> Language Class Initialized
INFO - 2020-11-17 07:54:46 --> Config Class Initialized
INFO - 2020-11-17 07:54:46 --> Loader Class Initialized
INFO - 2020-11-17 07:54:46 --> Helper loaded: url_helper
INFO - 2020-11-17 07:54:46 --> Helper loaded: file_helper
INFO - 2020-11-17 07:54:46 --> Helper loaded: form_helper
INFO - 2020-11-17 07:54:46 --> Helper loaded: my_helper
INFO - 2020-11-17 07:54:46 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:54:46 --> Controller Class Initialized
DEBUG - 2020-11-17 07:54:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-17 07:54:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:54:46 --> Final output sent to browser
DEBUG - 2020-11-17 07:54:46 --> Total execution time: 0.2278
INFO - 2020-11-17 07:54:46 --> Config Class Initialized
INFO - 2020-11-17 07:54:46 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:54:46 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:54:46 --> Utf8 Class Initialized
INFO - 2020-11-17 07:54:47 --> URI Class Initialized
INFO - 2020-11-17 07:54:47 --> Router Class Initialized
INFO - 2020-11-17 07:54:47 --> Output Class Initialized
INFO - 2020-11-17 07:54:47 --> Security Class Initialized
DEBUG - 2020-11-17 07:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:54:47 --> Input Class Initialized
INFO - 2020-11-17 07:54:47 --> Language Class Initialized
INFO - 2020-11-17 07:54:47 --> Language Class Initialized
INFO - 2020-11-17 07:54:47 --> Config Class Initialized
INFO - 2020-11-17 07:54:47 --> Loader Class Initialized
INFO - 2020-11-17 07:54:47 --> Helper loaded: url_helper
INFO - 2020-11-17 07:54:47 --> Helper loaded: file_helper
INFO - 2020-11-17 07:54:47 --> Helper loaded: form_helper
INFO - 2020-11-17 07:54:47 --> Helper loaded: my_helper
INFO - 2020-11-17 07:54:47 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:54:47 --> Controller Class Initialized
INFO - 2020-11-17 07:54:48 --> Config Class Initialized
INFO - 2020-11-17 07:54:48 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:54:48 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:54:48 --> Utf8 Class Initialized
INFO - 2020-11-17 07:54:48 --> URI Class Initialized
INFO - 2020-11-17 07:54:48 --> Router Class Initialized
INFO - 2020-11-17 07:54:48 --> Output Class Initialized
INFO - 2020-11-17 07:54:48 --> Security Class Initialized
DEBUG - 2020-11-17 07:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:54:48 --> Input Class Initialized
INFO - 2020-11-17 07:54:48 --> Language Class Initialized
INFO - 2020-11-17 07:54:48 --> Language Class Initialized
INFO - 2020-11-17 07:54:48 --> Config Class Initialized
INFO - 2020-11-17 07:54:48 --> Loader Class Initialized
INFO - 2020-11-17 07:54:48 --> Helper loaded: url_helper
INFO - 2020-11-17 07:54:48 --> Helper loaded: file_helper
INFO - 2020-11-17 07:54:48 --> Helper loaded: form_helper
INFO - 2020-11-17 07:54:48 --> Helper loaded: my_helper
INFO - 2020-11-17 07:54:48 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:54:48 --> Controller Class Initialized
ERROR - 2020-11-17 07:54:48 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_karakter
                                                    FROM t_c_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-11-17 07:54:48 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-17 07:54:50 --> Config Class Initialized
INFO - 2020-11-17 07:54:50 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:54:50 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:54:50 --> Utf8 Class Initialized
INFO - 2020-11-17 07:54:50 --> URI Class Initialized
INFO - 2020-11-17 07:54:50 --> Router Class Initialized
INFO - 2020-11-17 07:54:50 --> Output Class Initialized
INFO - 2020-11-17 07:54:50 --> Security Class Initialized
DEBUG - 2020-11-17 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:54:50 --> Input Class Initialized
INFO - 2020-11-17 07:54:50 --> Language Class Initialized
INFO - 2020-11-17 07:54:50 --> Language Class Initialized
INFO - 2020-11-17 07:54:50 --> Config Class Initialized
INFO - 2020-11-17 07:54:50 --> Loader Class Initialized
INFO - 2020-11-17 07:54:50 --> Helper loaded: url_helper
INFO - 2020-11-17 07:54:50 --> Helper loaded: file_helper
INFO - 2020-11-17 07:54:50 --> Helper loaded: form_helper
INFO - 2020-11-17 07:54:50 --> Helper loaded: my_helper
INFO - 2020-11-17 07:54:50 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:54:50 --> Controller Class Initialized
ERROR - 2020-11-17 07:54:50 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_karakter
                                                    FROM t_c_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-11-17 07:54:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-17 07:55:20 --> Config Class Initialized
INFO - 2020-11-17 07:55:20 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:55:20 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:55:20 --> Utf8 Class Initialized
INFO - 2020-11-17 07:55:20 --> URI Class Initialized
INFO - 2020-11-17 07:55:20 --> Router Class Initialized
INFO - 2020-11-17 07:55:20 --> Output Class Initialized
INFO - 2020-11-17 07:55:20 --> Security Class Initialized
DEBUG - 2020-11-17 07:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:55:20 --> Input Class Initialized
INFO - 2020-11-17 07:55:20 --> Language Class Initialized
INFO - 2020-11-17 07:55:20 --> Language Class Initialized
INFO - 2020-11-17 07:55:20 --> Config Class Initialized
INFO - 2020-11-17 07:55:20 --> Loader Class Initialized
INFO - 2020-11-17 07:55:20 --> Helper loaded: url_helper
INFO - 2020-11-17 07:55:20 --> Helper loaded: file_helper
INFO - 2020-11-17 07:55:20 --> Helper loaded: form_helper
INFO - 2020-11-17 07:55:20 --> Helper loaded: my_helper
INFO - 2020-11-17 07:55:20 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:55:20 --> Controller Class Initialized
ERROR - 2020-11-17 07:55:20 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\nilai\application\views\template_utama.php 173
ERROR - 2020-11-17 07:55:21 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\nilai\application\third_party\MX\Loader.php 342
INFO - 2020-11-17 07:55:26 --> Config Class Initialized
INFO - 2020-11-17 07:55:26 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:55:26 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:55:26 --> Utf8 Class Initialized
INFO - 2020-11-17 07:55:26 --> URI Class Initialized
INFO - 2020-11-17 07:55:26 --> Router Class Initialized
INFO - 2020-11-17 07:55:26 --> Output Class Initialized
INFO - 2020-11-17 07:55:26 --> Security Class Initialized
DEBUG - 2020-11-17 07:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:55:26 --> Input Class Initialized
INFO - 2020-11-17 07:55:26 --> Language Class Initialized
INFO - 2020-11-17 07:55:26 --> Language Class Initialized
INFO - 2020-11-17 07:55:26 --> Config Class Initialized
INFO - 2020-11-17 07:55:26 --> Loader Class Initialized
INFO - 2020-11-17 07:55:26 --> Helper loaded: url_helper
INFO - 2020-11-17 07:55:26 --> Helper loaded: file_helper
INFO - 2020-11-17 07:55:26 --> Helper loaded: form_helper
INFO - 2020-11-17 07:55:26 --> Helper loaded: my_helper
INFO - 2020-11-17 07:55:26 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:55:26 --> Controller Class Initialized
DEBUG - 2020-11-17 07:55:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-17 07:55:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:55:26 --> Final output sent to browser
DEBUG - 2020-11-17 07:55:26 --> Total execution time: 0.2571
INFO - 2020-11-17 07:55:26 --> Config Class Initialized
INFO - 2020-11-17 07:55:26 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:55:26 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:55:26 --> Utf8 Class Initialized
INFO - 2020-11-17 07:55:26 --> URI Class Initialized
INFO - 2020-11-17 07:55:26 --> Router Class Initialized
INFO - 2020-11-17 07:55:26 --> Output Class Initialized
INFO - 2020-11-17 07:55:26 --> Security Class Initialized
DEBUG - 2020-11-17 07:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:55:26 --> Input Class Initialized
INFO - 2020-11-17 07:55:26 --> Language Class Initialized
INFO - 2020-11-17 07:55:26 --> Language Class Initialized
INFO - 2020-11-17 07:55:26 --> Config Class Initialized
INFO - 2020-11-17 07:55:26 --> Loader Class Initialized
INFO - 2020-11-17 07:55:26 --> Helper loaded: url_helper
INFO - 2020-11-17 07:55:26 --> Helper loaded: file_helper
INFO - 2020-11-17 07:55:26 --> Helper loaded: form_helper
INFO - 2020-11-17 07:55:26 --> Helper loaded: my_helper
INFO - 2020-11-17 07:55:26 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:55:26 --> Controller Class Initialized
INFO - 2020-11-17 07:55:28 --> Config Class Initialized
INFO - 2020-11-17 07:55:28 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:55:28 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:55:28 --> Utf8 Class Initialized
INFO - 2020-11-17 07:55:28 --> URI Class Initialized
INFO - 2020-11-17 07:55:28 --> Router Class Initialized
INFO - 2020-11-17 07:55:28 --> Output Class Initialized
INFO - 2020-11-17 07:55:28 --> Security Class Initialized
DEBUG - 2020-11-17 07:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:55:28 --> Input Class Initialized
INFO - 2020-11-17 07:55:28 --> Language Class Initialized
INFO - 2020-11-17 07:55:28 --> Language Class Initialized
INFO - 2020-11-17 07:55:28 --> Config Class Initialized
INFO - 2020-11-17 07:55:28 --> Loader Class Initialized
INFO - 2020-11-17 07:55:28 --> Helper loaded: url_helper
INFO - 2020-11-17 07:55:28 --> Helper loaded: file_helper
INFO - 2020-11-17 07:55:28 --> Helper loaded: form_helper
INFO - 2020-11-17 07:55:28 --> Helper loaded: my_helper
INFO - 2020-11-17 07:55:28 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:55:29 --> Controller Class Initialized
ERROR - 2020-11-17 07:55:29 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\nilai\application\views\template_utama.php 173
ERROR - 2020-11-17 07:55:29 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\nilai\application\third_party\MX\Loader.php 342
INFO - 2020-11-17 07:56:12 --> Config Class Initialized
INFO - 2020-11-17 07:56:12 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:56:12 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:56:12 --> Utf8 Class Initialized
INFO - 2020-11-17 07:56:12 --> URI Class Initialized
INFO - 2020-11-17 07:56:12 --> Router Class Initialized
INFO - 2020-11-17 07:56:12 --> Output Class Initialized
INFO - 2020-11-17 07:56:12 --> Security Class Initialized
DEBUG - 2020-11-17 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:56:12 --> Input Class Initialized
INFO - 2020-11-17 07:56:12 --> Language Class Initialized
INFO - 2020-11-17 07:56:12 --> Language Class Initialized
INFO - 2020-11-17 07:56:12 --> Config Class Initialized
INFO - 2020-11-17 07:56:12 --> Loader Class Initialized
INFO - 2020-11-17 07:56:12 --> Helper loaded: url_helper
INFO - 2020-11-17 07:56:12 --> Helper loaded: file_helper
INFO - 2020-11-17 07:56:12 --> Helper loaded: form_helper
INFO - 2020-11-17 07:56:12 --> Helper loaded: my_helper
INFO - 2020-11-17 07:56:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:56:12 --> Controller Class Initialized
DEBUG - 2020-11-17 07:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-17 07:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:56:12 --> Final output sent to browser
DEBUG - 2020-11-17 07:56:12 --> Total execution time: 0.2265
INFO - 2020-11-17 07:56:12 --> Config Class Initialized
INFO - 2020-11-17 07:56:12 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:56:12 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:56:12 --> Utf8 Class Initialized
INFO - 2020-11-17 07:56:12 --> URI Class Initialized
INFO - 2020-11-17 07:56:12 --> Router Class Initialized
INFO - 2020-11-17 07:56:12 --> Output Class Initialized
INFO - 2020-11-17 07:56:12 --> Security Class Initialized
DEBUG - 2020-11-17 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:56:12 --> Input Class Initialized
INFO - 2020-11-17 07:56:12 --> Language Class Initialized
INFO - 2020-11-17 07:56:12 --> Language Class Initialized
INFO - 2020-11-17 07:56:12 --> Config Class Initialized
INFO - 2020-11-17 07:56:12 --> Loader Class Initialized
INFO - 2020-11-17 07:56:12 --> Helper loaded: url_helper
INFO - 2020-11-17 07:56:12 --> Helper loaded: file_helper
INFO - 2020-11-17 07:56:12 --> Helper loaded: form_helper
INFO - 2020-11-17 07:56:12 --> Helper loaded: my_helper
INFO - 2020-11-17 07:56:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:56:13 --> Controller Class Initialized
INFO - 2020-11-17 07:56:17 --> Config Class Initialized
INFO - 2020-11-17 07:56:17 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:56:17 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:56:17 --> Utf8 Class Initialized
INFO - 2020-11-17 07:56:17 --> URI Class Initialized
INFO - 2020-11-17 07:56:17 --> Router Class Initialized
INFO - 2020-11-17 07:56:17 --> Output Class Initialized
INFO - 2020-11-17 07:56:17 --> Security Class Initialized
DEBUG - 2020-11-17 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:56:17 --> Input Class Initialized
INFO - 2020-11-17 07:56:17 --> Language Class Initialized
INFO - 2020-11-17 07:56:17 --> Language Class Initialized
INFO - 2020-11-17 07:56:17 --> Config Class Initialized
INFO - 2020-11-17 07:56:17 --> Loader Class Initialized
INFO - 2020-11-17 07:56:17 --> Helper loaded: url_helper
INFO - 2020-11-17 07:56:17 --> Helper loaded: file_helper
INFO - 2020-11-17 07:56:17 --> Helper loaded: form_helper
INFO - 2020-11-17 07:56:17 --> Helper loaded: my_helper
INFO - 2020-11-17 07:56:17 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:56:17 --> Controller Class Initialized
DEBUG - 2020-11-17 07:56:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-17 07:56:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 07:56:17 --> Final output sent to browser
DEBUG - 2020-11-17 07:56:17 --> Total execution time: 0.2634
INFO - 2020-11-17 07:56:17 --> Config Class Initialized
INFO - 2020-11-17 07:56:17 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:56:17 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:56:17 --> Utf8 Class Initialized
INFO - 2020-11-17 07:56:17 --> URI Class Initialized
INFO - 2020-11-17 07:56:17 --> Router Class Initialized
INFO - 2020-11-17 07:56:17 --> Output Class Initialized
INFO - 2020-11-17 07:56:17 --> Security Class Initialized
DEBUG - 2020-11-17 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:56:17 --> Input Class Initialized
INFO - 2020-11-17 07:56:17 --> Language Class Initialized
INFO - 2020-11-17 07:56:17 --> Language Class Initialized
INFO - 2020-11-17 07:56:17 --> Config Class Initialized
INFO - 2020-11-17 07:56:17 --> Loader Class Initialized
INFO - 2020-11-17 07:56:17 --> Helper loaded: url_helper
INFO - 2020-11-17 07:56:17 --> Helper loaded: file_helper
INFO - 2020-11-17 07:56:17 --> Helper loaded: form_helper
INFO - 2020-11-17 07:56:17 --> Helper loaded: my_helper
INFO - 2020-11-17 07:56:17 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:56:17 --> Controller Class Initialized
INFO - 2020-11-17 07:56:18 --> Config Class Initialized
INFO - 2020-11-17 07:56:18 --> Hooks Class Initialized
DEBUG - 2020-11-17 07:56:18 --> UTF-8 Support Enabled
INFO - 2020-11-17 07:56:18 --> Utf8 Class Initialized
INFO - 2020-11-17 07:56:18 --> URI Class Initialized
INFO - 2020-11-17 07:56:18 --> Router Class Initialized
INFO - 2020-11-17 07:56:18 --> Output Class Initialized
INFO - 2020-11-17 07:56:18 --> Security Class Initialized
DEBUG - 2020-11-17 07:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 07:56:18 --> Input Class Initialized
INFO - 2020-11-17 07:56:18 --> Language Class Initialized
INFO - 2020-11-17 07:56:18 --> Language Class Initialized
INFO - 2020-11-17 07:56:18 --> Config Class Initialized
INFO - 2020-11-17 07:56:18 --> Loader Class Initialized
INFO - 2020-11-17 07:56:18 --> Helper loaded: url_helper
INFO - 2020-11-17 07:56:18 --> Helper loaded: file_helper
INFO - 2020-11-17 07:56:18 --> Helper loaded: form_helper
INFO - 2020-11-17 07:56:18 --> Helper loaded: my_helper
INFO - 2020-11-17 07:56:18 --> Database Driver Class Initialized
DEBUG - 2020-11-17 07:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 07:56:19 --> Controller Class Initialized
ERROR - 2020-11-17 07:56:19 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\nilai\application\views\template_utama.php 173
ERROR - 2020-11-17 07:56:19 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\nilai\application\third_party\MX\Loader.php 342
INFO - 2020-11-17 08:01:00 --> Config Class Initialized
INFO - 2020-11-17 08:01:00 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:01:00 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:01:00 --> Utf8 Class Initialized
INFO - 2020-11-17 08:01:00 --> URI Class Initialized
INFO - 2020-11-17 08:01:00 --> Router Class Initialized
INFO - 2020-11-17 08:01:00 --> Output Class Initialized
INFO - 2020-11-17 08:01:00 --> Security Class Initialized
DEBUG - 2020-11-17 08:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:01:00 --> Input Class Initialized
INFO - 2020-11-17 08:01:00 --> Language Class Initialized
INFO - 2020-11-17 08:01:00 --> Language Class Initialized
INFO - 2020-11-17 08:01:00 --> Config Class Initialized
INFO - 2020-11-17 08:01:00 --> Loader Class Initialized
INFO - 2020-11-17 08:01:00 --> Helper loaded: url_helper
INFO - 2020-11-17 08:01:00 --> Helper loaded: file_helper
INFO - 2020-11-17 08:01:00 --> Helper loaded: form_helper
INFO - 2020-11-17 08:01:00 --> Helper loaded: my_helper
INFO - 2020-11-17 08:01:00 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:01:00 --> Controller Class Initialized
DEBUG - 2020-11-17 08:01:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 08:01:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:01:00 --> Final output sent to browser
DEBUG - 2020-11-17 08:01:00 --> Total execution time: 0.2731
INFO - 2020-11-17 08:01:34 --> Config Class Initialized
INFO - 2020-11-17 08:01:34 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:01:34 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:01:34 --> Utf8 Class Initialized
INFO - 2020-11-17 08:01:34 --> URI Class Initialized
INFO - 2020-11-17 08:01:34 --> Router Class Initialized
INFO - 2020-11-17 08:01:34 --> Output Class Initialized
INFO - 2020-11-17 08:01:34 --> Security Class Initialized
DEBUG - 2020-11-17 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:01:34 --> Input Class Initialized
INFO - 2020-11-17 08:01:34 --> Language Class Initialized
INFO - 2020-11-17 08:01:34 --> Language Class Initialized
INFO - 2020-11-17 08:01:34 --> Config Class Initialized
INFO - 2020-11-17 08:01:34 --> Loader Class Initialized
INFO - 2020-11-17 08:01:34 --> Helper loaded: url_helper
INFO - 2020-11-17 08:01:34 --> Helper loaded: file_helper
INFO - 2020-11-17 08:01:34 --> Helper loaded: form_helper
INFO - 2020-11-17 08:01:34 --> Helper loaded: my_helper
INFO - 2020-11-17 08:01:34 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:01:34 --> Controller Class Initialized
ERROR - 2020-11-17 08:01:34 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\nilai\application\views\template_utama.php 173
ERROR - 2020-11-17 08:01:34 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\nilai\application\third_party\MX\Loader.php 342
INFO - 2020-11-17 08:05:44 --> Config Class Initialized
INFO - 2020-11-17 08:05:44 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:05:44 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:05:44 --> Utf8 Class Initialized
INFO - 2020-11-17 08:05:44 --> URI Class Initialized
INFO - 2020-11-17 08:05:44 --> Router Class Initialized
INFO - 2020-11-17 08:05:44 --> Output Class Initialized
INFO - 2020-11-17 08:05:44 --> Security Class Initialized
DEBUG - 2020-11-17 08:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:05:44 --> Input Class Initialized
INFO - 2020-11-17 08:05:44 --> Language Class Initialized
INFO - 2020-11-17 08:05:44 --> Language Class Initialized
INFO - 2020-11-17 08:05:44 --> Config Class Initialized
INFO - 2020-11-17 08:05:44 --> Loader Class Initialized
INFO - 2020-11-17 08:05:44 --> Helper loaded: url_helper
INFO - 2020-11-17 08:05:44 --> Helper loaded: file_helper
INFO - 2020-11-17 08:05:44 --> Helper loaded: form_helper
INFO - 2020-11-17 08:05:44 --> Helper loaded: my_helper
INFO - 2020-11-17 08:05:44 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:05:44 --> Controller Class Initialized
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:05:45 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
DEBUG - 2020-11-17 08:05:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-17 08:05:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:05:45 --> Final output sent to browser
DEBUG - 2020-11-17 08:05:45 --> Total execution time: 0.5496
INFO - 2020-11-17 08:11:44 --> Config Class Initialized
INFO - 2020-11-17 08:11:44 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:11:44 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:11:44 --> Utf8 Class Initialized
INFO - 2020-11-17 08:11:44 --> URI Class Initialized
INFO - 2020-11-17 08:11:44 --> Router Class Initialized
INFO - 2020-11-17 08:11:44 --> Output Class Initialized
INFO - 2020-11-17 08:11:44 --> Security Class Initialized
DEBUG - 2020-11-17 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:11:44 --> Input Class Initialized
INFO - 2020-11-17 08:11:44 --> Language Class Initialized
INFO - 2020-11-17 08:11:44 --> Language Class Initialized
INFO - 2020-11-17 08:11:44 --> Config Class Initialized
INFO - 2020-11-17 08:11:44 --> Loader Class Initialized
INFO - 2020-11-17 08:11:44 --> Helper loaded: url_helper
INFO - 2020-11-17 08:11:44 --> Helper loaded: file_helper
INFO - 2020-11-17 08:11:44 --> Helper loaded: form_helper
INFO - 2020-11-17 08:11:44 --> Helper loaded: my_helper
INFO - 2020-11-17 08:11:44 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:11:44 --> Controller Class Initialized
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
ERROR - 2020-11-17 08:11:44 --> Severity: Notice --> Undefined index: catatan_karakter C:\xampp\htdocs\nilai\application\modules\n_c_karakter\views\list.php 35
DEBUG - 2020-11-17 08:11:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-17 08:11:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:11:44 --> Final output sent to browser
DEBUG - 2020-11-17 08:11:44 --> Total execution time: 0.5651
INFO - 2020-11-17 08:17:17 --> Config Class Initialized
INFO - 2020-11-17 08:17:17 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:17:17 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:17:17 --> Utf8 Class Initialized
INFO - 2020-11-17 08:17:17 --> URI Class Initialized
INFO - 2020-11-17 08:17:17 --> Router Class Initialized
INFO - 2020-11-17 08:17:17 --> Output Class Initialized
INFO - 2020-11-17 08:17:17 --> Security Class Initialized
DEBUG - 2020-11-17 08:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:17:17 --> Input Class Initialized
INFO - 2020-11-17 08:17:17 --> Language Class Initialized
INFO - 2020-11-17 08:17:17 --> Language Class Initialized
INFO - 2020-11-17 08:17:17 --> Config Class Initialized
INFO - 2020-11-17 08:17:17 --> Loader Class Initialized
INFO - 2020-11-17 08:17:17 --> Helper loaded: url_helper
INFO - 2020-11-17 08:17:17 --> Helper loaded: file_helper
INFO - 2020-11-17 08:17:17 --> Helper loaded: form_helper
INFO - 2020-11-17 08:17:17 --> Helper loaded: my_helper
INFO - 2020-11-17 08:17:17 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:17:17 --> Controller Class Initialized
DEBUG - 2020-11-17 08:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-17 08:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:17:17 --> Final output sent to browser
DEBUG - 2020-11-17 08:17:17 --> Total execution time: 0.2519
INFO - 2020-11-17 08:17:40 --> Config Class Initialized
INFO - 2020-11-17 08:17:40 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:17:40 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:17:40 --> Utf8 Class Initialized
INFO - 2020-11-17 08:17:40 --> URI Class Initialized
INFO - 2020-11-17 08:17:40 --> Router Class Initialized
INFO - 2020-11-17 08:17:40 --> Output Class Initialized
INFO - 2020-11-17 08:17:40 --> Security Class Initialized
DEBUG - 2020-11-17 08:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:17:40 --> Input Class Initialized
INFO - 2020-11-17 08:17:40 --> Language Class Initialized
INFO - 2020-11-17 08:17:40 --> Language Class Initialized
INFO - 2020-11-17 08:17:40 --> Config Class Initialized
INFO - 2020-11-17 08:17:40 --> Loader Class Initialized
INFO - 2020-11-17 08:17:40 --> Helper loaded: url_helper
INFO - 2020-11-17 08:17:40 --> Helper loaded: file_helper
INFO - 2020-11-17 08:17:40 --> Helper loaded: form_helper
INFO - 2020-11-17 08:17:40 --> Helper loaded: my_helper
INFO - 2020-11-17 08:17:40 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:17:40 --> Controller Class Initialized
DEBUG - 2020-11-17 08:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 08:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:17:41 --> Final output sent to browser
DEBUG - 2020-11-17 08:17:41 --> Total execution time: 0.2713
INFO - 2020-11-17 08:18:20 --> Config Class Initialized
INFO - 2020-11-17 08:18:20 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:18:20 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:18:20 --> Utf8 Class Initialized
INFO - 2020-11-17 08:18:20 --> URI Class Initialized
INFO - 2020-11-17 08:18:20 --> Router Class Initialized
INFO - 2020-11-17 08:18:20 --> Output Class Initialized
INFO - 2020-11-17 08:18:20 --> Security Class Initialized
DEBUG - 2020-11-17 08:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:18:20 --> Input Class Initialized
INFO - 2020-11-17 08:18:20 --> Language Class Initialized
INFO - 2020-11-17 08:18:20 --> Language Class Initialized
INFO - 2020-11-17 08:18:20 --> Config Class Initialized
INFO - 2020-11-17 08:18:20 --> Loader Class Initialized
INFO - 2020-11-17 08:18:20 --> Helper loaded: url_helper
INFO - 2020-11-17 08:18:20 --> Helper loaded: file_helper
INFO - 2020-11-17 08:18:20 --> Helper loaded: form_helper
INFO - 2020-11-17 08:18:20 --> Helper loaded: my_helper
INFO - 2020-11-17 08:18:20 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:18:20 --> Controller Class Initialized
DEBUG - 2020-11-17 08:18:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 08:18:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:18:20 --> Final output sent to browser
DEBUG - 2020-11-17 08:18:20 --> Total execution time: 0.2657
INFO - 2020-11-17 08:18:21 --> Config Class Initialized
INFO - 2020-11-17 08:18:21 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:18:21 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:18:21 --> Utf8 Class Initialized
INFO - 2020-11-17 08:18:21 --> URI Class Initialized
INFO - 2020-11-17 08:18:21 --> Router Class Initialized
INFO - 2020-11-17 08:18:21 --> Output Class Initialized
INFO - 2020-11-17 08:18:21 --> Security Class Initialized
DEBUG - 2020-11-17 08:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:18:21 --> Input Class Initialized
INFO - 2020-11-17 08:18:21 --> Language Class Initialized
INFO - 2020-11-17 08:18:21 --> Language Class Initialized
INFO - 2020-11-17 08:18:21 --> Config Class Initialized
INFO - 2020-11-17 08:18:21 --> Loader Class Initialized
INFO - 2020-11-17 08:18:22 --> Helper loaded: url_helper
INFO - 2020-11-17 08:18:22 --> Helper loaded: file_helper
INFO - 2020-11-17 08:18:22 --> Helper loaded: form_helper
INFO - 2020-11-17 08:18:22 --> Helper loaded: my_helper
INFO - 2020-11-17 08:18:22 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:18:22 --> Controller Class Initialized
DEBUG - 2020-11-17 08:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-17 08:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:18:22 --> Final output sent to browser
DEBUG - 2020-11-17 08:18:22 --> Total execution time: 0.2574
INFO - 2020-11-17 08:18:28 --> Config Class Initialized
INFO - 2020-11-17 08:18:28 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:18:28 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:18:28 --> Utf8 Class Initialized
INFO - 2020-11-17 08:18:28 --> URI Class Initialized
INFO - 2020-11-17 08:18:28 --> Router Class Initialized
INFO - 2020-11-17 08:18:28 --> Output Class Initialized
INFO - 2020-11-17 08:18:28 --> Security Class Initialized
DEBUG - 2020-11-17 08:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:18:28 --> Input Class Initialized
INFO - 2020-11-17 08:18:28 --> Language Class Initialized
INFO - 2020-11-17 08:18:28 --> Language Class Initialized
INFO - 2020-11-17 08:18:28 --> Config Class Initialized
INFO - 2020-11-17 08:18:28 --> Loader Class Initialized
INFO - 2020-11-17 08:18:28 --> Helper loaded: url_helper
INFO - 2020-11-17 08:18:28 --> Helper loaded: file_helper
INFO - 2020-11-17 08:18:28 --> Helper loaded: form_helper
INFO - 2020-11-17 08:18:28 --> Helper loaded: my_helper
INFO - 2020-11-17 08:18:28 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:18:28 --> Controller Class Initialized
INFO - 2020-11-17 08:18:28 --> Final output sent to browser
DEBUG - 2020-11-17 08:18:28 --> Total execution time: 0.3386
INFO - 2020-11-17 08:28:22 --> Config Class Initialized
INFO - 2020-11-17 08:28:22 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:28:22 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:28:22 --> Utf8 Class Initialized
INFO - 2020-11-17 08:28:22 --> URI Class Initialized
INFO - 2020-11-17 08:28:22 --> Router Class Initialized
INFO - 2020-11-17 08:28:22 --> Output Class Initialized
INFO - 2020-11-17 08:28:22 --> Security Class Initialized
DEBUG - 2020-11-17 08:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:28:22 --> Input Class Initialized
INFO - 2020-11-17 08:28:22 --> Language Class Initialized
INFO - 2020-11-17 08:28:22 --> Language Class Initialized
INFO - 2020-11-17 08:28:22 --> Config Class Initialized
INFO - 2020-11-17 08:28:22 --> Loader Class Initialized
INFO - 2020-11-17 08:28:22 --> Helper loaded: url_helper
INFO - 2020-11-17 08:28:22 --> Helper loaded: file_helper
INFO - 2020-11-17 08:28:22 --> Helper loaded: form_helper
INFO - 2020-11-17 08:28:22 --> Helper loaded: my_helper
INFO - 2020-11-17 08:28:22 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:28:22 --> Controller Class Initialized
DEBUG - 2020-11-17 08:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 08:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:28:22 --> Final output sent to browser
DEBUG - 2020-11-17 08:28:22 --> Total execution time: 0.2800
INFO - 2020-11-17 08:30:51 --> Config Class Initialized
INFO - 2020-11-17 08:30:51 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:30:51 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:30:51 --> Utf8 Class Initialized
INFO - 2020-11-17 08:30:51 --> URI Class Initialized
INFO - 2020-11-17 08:30:51 --> Router Class Initialized
INFO - 2020-11-17 08:30:51 --> Output Class Initialized
INFO - 2020-11-17 08:30:51 --> Security Class Initialized
DEBUG - 2020-11-17 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:30:51 --> Input Class Initialized
INFO - 2020-11-17 08:30:51 --> Language Class Initialized
INFO - 2020-11-17 08:30:51 --> Language Class Initialized
INFO - 2020-11-17 08:30:51 --> Config Class Initialized
INFO - 2020-11-17 08:30:51 --> Loader Class Initialized
INFO - 2020-11-17 08:30:51 --> Helper loaded: url_helper
INFO - 2020-11-17 08:30:51 --> Helper loaded: file_helper
INFO - 2020-11-17 08:30:51 --> Helper loaded: form_helper
INFO - 2020-11-17 08:30:51 --> Helper loaded: my_helper
INFO - 2020-11-17 08:30:51 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:30:51 --> Controller Class Initialized
DEBUG - 2020-11-17 08:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-17 08:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:30:51 --> Final output sent to browser
DEBUG - 2020-11-17 08:30:51 --> Total execution time: 0.3190
INFO - 2020-11-17 08:30:53 --> Config Class Initialized
INFO - 2020-11-17 08:30:53 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:30:53 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:30:53 --> Utf8 Class Initialized
INFO - 2020-11-17 08:30:53 --> URI Class Initialized
INFO - 2020-11-17 08:30:53 --> Router Class Initialized
INFO - 2020-11-17 08:30:53 --> Output Class Initialized
INFO - 2020-11-17 08:30:53 --> Security Class Initialized
DEBUG - 2020-11-17 08:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:30:53 --> Input Class Initialized
INFO - 2020-11-17 08:30:53 --> Language Class Initialized
INFO - 2020-11-17 08:30:53 --> Language Class Initialized
INFO - 2020-11-17 08:30:53 --> Config Class Initialized
INFO - 2020-11-17 08:30:53 --> Loader Class Initialized
INFO - 2020-11-17 08:30:53 --> Helper loaded: url_helper
INFO - 2020-11-17 08:30:53 --> Helper loaded: file_helper
INFO - 2020-11-17 08:30:53 --> Helper loaded: form_helper
INFO - 2020-11-17 08:30:53 --> Helper loaded: my_helper
INFO - 2020-11-17 08:30:53 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:30:53 --> Controller Class Initialized
INFO - 2020-11-17 08:30:53 --> Final output sent to browser
DEBUG - 2020-11-17 08:30:53 --> Total execution time: 0.2181
INFO - 2020-11-17 08:31:06 --> Config Class Initialized
INFO - 2020-11-17 08:31:06 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:31:06 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:31:06 --> Utf8 Class Initialized
INFO - 2020-11-17 08:31:06 --> URI Class Initialized
INFO - 2020-11-17 08:31:06 --> Router Class Initialized
INFO - 2020-11-17 08:31:06 --> Output Class Initialized
INFO - 2020-11-17 08:31:06 --> Security Class Initialized
DEBUG - 2020-11-17 08:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:31:06 --> Input Class Initialized
INFO - 2020-11-17 08:31:06 --> Language Class Initialized
INFO - 2020-11-17 08:31:06 --> Language Class Initialized
INFO - 2020-11-17 08:31:06 --> Config Class Initialized
INFO - 2020-11-17 08:31:06 --> Loader Class Initialized
INFO - 2020-11-17 08:31:06 --> Helper loaded: url_helper
INFO - 2020-11-17 08:31:06 --> Helper loaded: file_helper
INFO - 2020-11-17 08:31:06 --> Helper loaded: form_helper
INFO - 2020-11-17 08:31:06 --> Helper loaded: my_helper
INFO - 2020-11-17 08:31:06 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:31:06 --> Controller Class Initialized
DEBUG - 2020-11-17 08:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 08:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:31:06 --> Final output sent to browser
DEBUG - 2020-11-17 08:31:06 --> Total execution time: 0.2808
INFO - 2020-11-17 08:37:03 --> Config Class Initialized
INFO - 2020-11-17 08:37:03 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:03 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:03 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:03 --> URI Class Initialized
INFO - 2020-11-17 08:37:03 --> Router Class Initialized
INFO - 2020-11-17 08:37:03 --> Output Class Initialized
INFO - 2020-11-17 08:37:03 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:03 --> Input Class Initialized
INFO - 2020-11-17 08:37:03 --> Language Class Initialized
INFO - 2020-11-17 08:37:03 --> Language Class Initialized
INFO - 2020-11-17 08:37:03 --> Config Class Initialized
INFO - 2020-11-17 08:37:03 --> Loader Class Initialized
INFO - 2020-11-17 08:37:03 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:03 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:03 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:03 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:04 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:04 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-17 08:37:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:04 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:04 --> Total execution time: 0.3205
INFO - 2020-11-17 08:37:06 --> Config Class Initialized
INFO - 2020-11-17 08:37:06 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:06 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:06 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:06 --> URI Class Initialized
INFO - 2020-11-17 08:37:06 --> Router Class Initialized
INFO - 2020-11-17 08:37:06 --> Output Class Initialized
INFO - 2020-11-17 08:37:06 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:06 --> Input Class Initialized
INFO - 2020-11-17 08:37:06 --> Language Class Initialized
INFO - 2020-11-17 08:37:06 --> Language Class Initialized
INFO - 2020-11-17 08:37:06 --> Config Class Initialized
INFO - 2020-11-17 08:37:06 --> Loader Class Initialized
INFO - 2020-11-17 08:37:06 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:06 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:06 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:06 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:06 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:06 --> Controller Class Initialized
INFO - 2020-11-17 08:37:06 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:06 --> Total execution time: 0.2301
INFO - 2020-11-17 08:37:22 --> Config Class Initialized
INFO - 2020-11-17 08:37:22 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:22 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:22 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:22 --> URI Class Initialized
INFO - 2020-11-17 08:37:22 --> Router Class Initialized
INFO - 2020-11-17 08:37:22 --> Output Class Initialized
INFO - 2020-11-17 08:37:22 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:22 --> Input Class Initialized
INFO - 2020-11-17 08:37:22 --> Language Class Initialized
INFO - 2020-11-17 08:37:22 --> Language Class Initialized
INFO - 2020-11-17 08:37:22 --> Config Class Initialized
INFO - 2020-11-17 08:37:22 --> Loader Class Initialized
INFO - 2020-11-17 08:37:22 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:22 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:22 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:22 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:22 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:22 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 08:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:22 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:22 --> Total execution time: 0.2865
INFO - 2020-11-17 08:37:23 --> Config Class Initialized
INFO - 2020-11-17 08:37:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:23 --> URI Class Initialized
INFO - 2020-11-17 08:37:23 --> Router Class Initialized
INFO - 2020-11-17 08:37:23 --> Output Class Initialized
INFO - 2020-11-17 08:37:23 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:23 --> Input Class Initialized
INFO - 2020-11-17 08:37:23 --> Language Class Initialized
INFO - 2020-11-17 08:37:23 --> Language Class Initialized
INFO - 2020-11-17 08:37:23 --> Config Class Initialized
INFO - 2020-11-17 08:37:23 --> Loader Class Initialized
INFO - 2020-11-17 08:37:23 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:23 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:23 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:23 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:23 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:23 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-17 08:37:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:23 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:23 --> Total execution time: 0.2580
INFO - 2020-11-17 08:37:23 --> Config Class Initialized
INFO - 2020-11-17 08:37:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:23 --> URI Class Initialized
INFO - 2020-11-17 08:37:23 --> Router Class Initialized
INFO - 2020-11-17 08:37:23 --> Output Class Initialized
INFO - 2020-11-17 08:37:23 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:24 --> Input Class Initialized
INFO - 2020-11-17 08:37:24 --> Language Class Initialized
INFO - 2020-11-17 08:37:24 --> Language Class Initialized
INFO - 2020-11-17 08:37:24 --> Config Class Initialized
INFO - 2020-11-17 08:37:24 --> Loader Class Initialized
INFO - 2020-11-17 08:37:24 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:24 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:24 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:24 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:24 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:24 --> Controller Class Initialized
INFO - 2020-11-17 08:37:26 --> Config Class Initialized
INFO - 2020-11-17 08:37:26 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:26 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:26 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:26 --> URI Class Initialized
INFO - 2020-11-17 08:37:26 --> Router Class Initialized
INFO - 2020-11-17 08:37:26 --> Output Class Initialized
INFO - 2020-11-17 08:37:26 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:26 --> Input Class Initialized
INFO - 2020-11-17 08:37:26 --> Language Class Initialized
INFO - 2020-11-17 08:37:26 --> Language Class Initialized
INFO - 2020-11-17 08:37:26 --> Config Class Initialized
INFO - 2020-11-17 08:37:26 --> Loader Class Initialized
INFO - 2020-11-17 08:37:26 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:26 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:26 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:26 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:26 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:26 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-11-17 08:37:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:26 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:26 --> Total execution time: 0.2719
INFO - 2020-11-17 08:37:27 --> Config Class Initialized
INFO - 2020-11-17 08:37:27 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:27 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:27 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:27 --> URI Class Initialized
INFO - 2020-11-17 08:37:27 --> Router Class Initialized
INFO - 2020-11-17 08:37:27 --> Output Class Initialized
INFO - 2020-11-17 08:37:27 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:27 --> Input Class Initialized
INFO - 2020-11-17 08:37:27 --> Language Class Initialized
INFO - 2020-11-17 08:37:27 --> Language Class Initialized
INFO - 2020-11-17 08:37:27 --> Config Class Initialized
INFO - 2020-11-17 08:37:27 --> Loader Class Initialized
INFO - 2020-11-17 08:37:27 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:27 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:27 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:27 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:27 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:27 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 08:37:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:27 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:27 --> Total execution time: 0.2660
INFO - 2020-11-17 08:37:28 --> Config Class Initialized
INFO - 2020-11-17 08:37:28 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:28 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:28 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:28 --> URI Class Initialized
INFO - 2020-11-17 08:37:28 --> Router Class Initialized
INFO - 2020-11-17 08:37:28 --> Output Class Initialized
INFO - 2020-11-17 08:37:28 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:28 --> Input Class Initialized
INFO - 2020-11-17 08:37:28 --> Language Class Initialized
INFO - 2020-11-17 08:37:28 --> Language Class Initialized
INFO - 2020-11-17 08:37:28 --> Config Class Initialized
INFO - 2020-11-17 08:37:28 --> Loader Class Initialized
INFO - 2020-11-17 08:37:28 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:28 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:28 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:28 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:28 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:28 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 08:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:28 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:28 --> Total execution time: 0.2667
INFO - 2020-11-17 08:37:29 --> Config Class Initialized
INFO - 2020-11-17 08:37:29 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:29 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:29 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:29 --> URI Class Initialized
INFO - 2020-11-17 08:37:29 --> Router Class Initialized
INFO - 2020-11-17 08:37:29 --> Output Class Initialized
INFO - 2020-11-17 08:37:29 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:29 --> Input Class Initialized
INFO - 2020-11-17 08:37:29 --> Language Class Initialized
INFO - 2020-11-17 08:37:29 --> Language Class Initialized
INFO - 2020-11-17 08:37:29 --> Config Class Initialized
INFO - 2020-11-17 08:37:29 --> Loader Class Initialized
INFO - 2020-11-17 08:37:29 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:29 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:29 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:29 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:29 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:30 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-17 08:37:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:30 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:30 --> Total execution time: 0.3069
INFO - 2020-11-17 08:37:32 --> Config Class Initialized
INFO - 2020-11-17 08:37:32 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:32 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:32 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:32 --> URI Class Initialized
INFO - 2020-11-17 08:37:32 --> Router Class Initialized
INFO - 2020-11-17 08:37:32 --> Output Class Initialized
INFO - 2020-11-17 08:37:32 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:32 --> Input Class Initialized
INFO - 2020-11-17 08:37:32 --> Language Class Initialized
INFO - 2020-11-17 08:37:32 --> Language Class Initialized
INFO - 2020-11-17 08:37:32 --> Config Class Initialized
INFO - 2020-11-17 08:37:32 --> Loader Class Initialized
INFO - 2020-11-17 08:37:32 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:32 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:32 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:32 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:32 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:32 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-17 08:37:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:32 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:32 --> Total execution time: 0.2814
INFO - 2020-11-17 08:37:46 --> Config Class Initialized
INFO - 2020-11-17 08:37:46 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:46 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:46 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:46 --> URI Class Initialized
INFO - 2020-11-17 08:37:46 --> Router Class Initialized
INFO - 2020-11-17 08:37:46 --> Output Class Initialized
INFO - 2020-11-17 08:37:46 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:46 --> Input Class Initialized
INFO - 2020-11-17 08:37:46 --> Language Class Initialized
INFO - 2020-11-17 08:37:46 --> Language Class Initialized
INFO - 2020-11-17 08:37:46 --> Config Class Initialized
INFO - 2020-11-17 08:37:46 --> Loader Class Initialized
INFO - 2020-11-17 08:37:46 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:46 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:46 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:46 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:46 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:47 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-17 08:37:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:47 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:47 --> Total execution time: 0.2608
INFO - 2020-11-17 08:37:47 --> Config Class Initialized
INFO - 2020-11-17 08:37:47 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:47 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:47 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:47 --> URI Class Initialized
INFO - 2020-11-17 08:37:47 --> Router Class Initialized
INFO - 2020-11-17 08:37:47 --> Output Class Initialized
INFO - 2020-11-17 08:37:47 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:47 --> Input Class Initialized
INFO - 2020-11-17 08:37:47 --> Language Class Initialized
INFO - 2020-11-17 08:37:47 --> Language Class Initialized
INFO - 2020-11-17 08:37:47 --> Config Class Initialized
INFO - 2020-11-17 08:37:47 --> Loader Class Initialized
INFO - 2020-11-17 08:37:47 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:47 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:47 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:47 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:47 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:47 --> Controller Class Initialized
INFO - 2020-11-17 08:37:56 --> Config Class Initialized
INFO - 2020-11-17 08:37:56 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:56 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:56 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:56 --> URI Class Initialized
INFO - 2020-11-17 08:37:56 --> Router Class Initialized
INFO - 2020-11-17 08:37:56 --> Output Class Initialized
INFO - 2020-11-17 08:37:56 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:56 --> Input Class Initialized
INFO - 2020-11-17 08:37:56 --> Language Class Initialized
INFO - 2020-11-17 08:37:56 --> Language Class Initialized
INFO - 2020-11-17 08:37:56 --> Config Class Initialized
INFO - 2020-11-17 08:37:56 --> Loader Class Initialized
INFO - 2020-11-17 08:37:56 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:56 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:56 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:56 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:56 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:56 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-17 08:37:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:56 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:56 --> Total execution time: 0.2541
INFO - 2020-11-17 08:37:58 --> Config Class Initialized
INFO - 2020-11-17 08:37:58 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:37:58 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:37:58 --> Utf8 Class Initialized
INFO - 2020-11-17 08:37:58 --> URI Class Initialized
INFO - 2020-11-17 08:37:58 --> Router Class Initialized
INFO - 2020-11-17 08:37:58 --> Output Class Initialized
INFO - 2020-11-17 08:37:58 --> Security Class Initialized
DEBUG - 2020-11-17 08:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:37:58 --> Input Class Initialized
INFO - 2020-11-17 08:37:58 --> Language Class Initialized
INFO - 2020-11-17 08:37:58 --> Language Class Initialized
INFO - 2020-11-17 08:37:58 --> Config Class Initialized
INFO - 2020-11-17 08:37:58 --> Loader Class Initialized
INFO - 2020-11-17 08:37:58 --> Helper loaded: url_helper
INFO - 2020-11-17 08:37:58 --> Helper loaded: file_helper
INFO - 2020-11-17 08:37:58 --> Helper loaded: form_helper
INFO - 2020-11-17 08:37:58 --> Helper loaded: my_helper
INFO - 2020-11-17 08:37:58 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:37:58 --> Controller Class Initialized
DEBUG - 2020-11-17 08:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-17 08:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:37:58 --> Final output sent to browser
DEBUG - 2020-11-17 08:37:58 --> Total execution time: 0.2729
INFO - 2020-11-17 08:38:01 --> Config Class Initialized
INFO - 2020-11-17 08:38:01 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:01 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:01 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:01 --> URI Class Initialized
INFO - 2020-11-17 08:38:01 --> Router Class Initialized
INFO - 2020-11-17 08:38:01 --> Output Class Initialized
INFO - 2020-11-17 08:38:01 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:01 --> Input Class Initialized
INFO - 2020-11-17 08:38:01 --> Language Class Initialized
INFO - 2020-11-17 08:38:01 --> Language Class Initialized
INFO - 2020-11-17 08:38:01 --> Config Class Initialized
INFO - 2020-11-17 08:38:01 --> Loader Class Initialized
INFO - 2020-11-17 08:38:01 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:01 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:01 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:01 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:01 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:01 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 08:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:01 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:01 --> Total execution time: 0.2842
INFO - 2020-11-17 08:38:06 --> Config Class Initialized
INFO - 2020-11-17 08:38:06 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:06 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:06 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:06 --> URI Class Initialized
INFO - 2020-11-17 08:38:06 --> Router Class Initialized
INFO - 2020-11-17 08:38:06 --> Output Class Initialized
INFO - 2020-11-17 08:38:06 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:06 --> Input Class Initialized
INFO - 2020-11-17 08:38:06 --> Language Class Initialized
INFO - 2020-11-17 08:38:06 --> Language Class Initialized
INFO - 2020-11-17 08:38:06 --> Config Class Initialized
INFO - 2020-11-17 08:38:06 --> Loader Class Initialized
INFO - 2020-11-17 08:38:06 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:06 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:06 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:06 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:06 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:06 --> Controller Class Initialized
INFO - 2020-11-17 08:38:06 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:38:06 --> Config Class Initialized
INFO - 2020-11-17 08:38:06 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:06 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:06 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:06 --> URI Class Initialized
INFO - 2020-11-17 08:38:06 --> Router Class Initialized
INFO - 2020-11-17 08:38:06 --> Output Class Initialized
INFO - 2020-11-17 08:38:06 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:06 --> Input Class Initialized
INFO - 2020-11-17 08:38:06 --> Language Class Initialized
INFO - 2020-11-17 08:38:06 --> Language Class Initialized
INFO - 2020-11-17 08:38:06 --> Config Class Initialized
INFO - 2020-11-17 08:38:06 --> Loader Class Initialized
INFO - 2020-11-17 08:38:06 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:06 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:06 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:06 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:06 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:06 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:38:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:06 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:06 --> Total execution time: 0.2561
INFO - 2020-11-17 08:38:11 --> Config Class Initialized
INFO - 2020-11-17 08:38:11 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:11 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:11 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:11 --> URI Class Initialized
INFO - 2020-11-17 08:38:11 --> Router Class Initialized
INFO - 2020-11-17 08:38:12 --> Output Class Initialized
INFO - 2020-11-17 08:38:12 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:12 --> Input Class Initialized
INFO - 2020-11-17 08:38:12 --> Language Class Initialized
INFO - 2020-11-17 08:38:12 --> Language Class Initialized
INFO - 2020-11-17 08:38:12 --> Config Class Initialized
INFO - 2020-11-17 08:38:12 --> Loader Class Initialized
INFO - 2020-11-17 08:38:12 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:12 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:12 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:12 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:12 --> Controller Class Initialized
INFO - 2020-11-17 08:38:12 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:38:12 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:12 --> Total execution time: 0.3288
INFO - 2020-11-17 08:38:13 --> Config Class Initialized
INFO - 2020-11-17 08:38:13 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:13 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:13 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:13 --> URI Class Initialized
INFO - 2020-11-17 08:38:13 --> Router Class Initialized
INFO - 2020-11-17 08:38:13 --> Output Class Initialized
INFO - 2020-11-17 08:38:13 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:13 --> Input Class Initialized
INFO - 2020-11-17 08:38:13 --> Language Class Initialized
INFO - 2020-11-17 08:38:13 --> Language Class Initialized
INFO - 2020-11-17 08:38:13 --> Config Class Initialized
INFO - 2020-11-17 08:38:13 --> Loader Class Initialized
INFO - 2020-11-17 08:38:13 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:13 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:13 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:13 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:13 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:13 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:38:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:13 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:13 --> Total execution time: 0.3811
INFO - 2020-11-17 08:38:23 --> Config Class Initialized
INFO - 2020-11-17 08:38:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:24 --> URI Class Initialized
INFO - 2020-11-17 08:38:24 --> Router Class Initialized
INFO - 2020-11-17 08:38:24 --> Output Class Initialized
INFO - 2020-11-17 08:38:24 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:24 --> Input Class Initialized
INFO - 2020-11-17 08:38:24 --> Language Class Initialized
INFO - 2020-11-17 08:38:24 --> Language Class Initialized
INFO - 2020-11-17 08:38:24 --> Config Class Initialized
INFO - 2020-11-17 08:38:24 --> Loader Class Initialized
INFO - 2020-11-17 08:38:24 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:24 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:24 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:24 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:24 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:24 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-11-17 08:38:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:24 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:24 --> Total execution time: 0.3446
INFO - 2020-11-17 08:38:24 --> Config Class Initialized
INFO - 2020-11-17 08:38:24 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:24 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:24 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:24 --> URI Class Initialized
INFO - 2020-11-17 08:38:24 --> Router Class Initialized
INFO - 2020-11-17 08:38:24 --> Output Class Initialized
INFO - 2020-11-17 08:38:24 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:24 --> Input Class Initialized
INFO - 2020-11-17 08:38:24 --> Language Class Initialized
INFO - 2020-11-17 08:38:24 --> Language Class Initialized
INFO - 2020-11-17 08:38:24 --> Config Class Initialized
INFO - 2020-11-17 08:38:24 --> Loader Class Initialized
INFO - 2020-11-17 08:38:24 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:24 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:24 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:24 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:24 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:24 --> Controller Class Initialized
INFO - 2020-11-17 08:38:25 --> Config Class Initialized
INFO - 2020-11-17 08:38:25 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:25 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:25 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:25 --> URI Class Initialized
INFO - 2020-11-17 08:38:25 --> Router Class Initialized
INFO - 2020-11-17 08:38:25 --> Output Class Initialized
INFO - 2020-11-17 08:38:25 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:25 --> Input Class Initialized
INFO - 2020-11-17 08:38:25 --> Language Class Initialized
INFO - 2020-11-17 08:38:25 --> Language Class Initialized
INFO - 2020-11-17 08:38:25 --> Config Class Initialized
INFO - 2020-11-17 08:38:25 --> Loader Class Initialized
INFO - 2020-11-17 08:38:25 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:25 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:25 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:25 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:25 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:25 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-17 08:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:25 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:25 --> Total execution time: 0.3076
INFO - 2020-11-17 08:38:25 --> Config Class Initialized
INFO - 2020-11-17 08:38:25 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:25 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:25 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:25 --> URI Class Initialized
INFO - 2020-11-17 08:38:25 --> Router Class Initialized
INFO - 2020-11-17 08:38:25 --> Output Class Initialized
INFO - 2020-11-17 08:38:25 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:25 --> Input Class Initialized
INFO - 2020-11-17 08:38:25 --> Language Class Initialized
INFO - 2020-11-17 08:38:25 --> Language Class Initialized
INFO - 2020-11-17 08:38:25 --> Config Class Initialized
INFO - 2020-11-17 08:38:25 --> Loader Class Initialized
INFO - 2020-11-17 08:38:25 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:25 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:25 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:25 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:25 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:26 --> Controller Class Initialized
INFO - 2020-11-17 08:38:27 --> Config Class Initialized
INFO - 2020-11-17 08:38:27 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:27 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:27 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:27 --> URI Class Initialized
INFO - 2020-11-17 08:38:27 --> Router Class Initialized
INFO - 2020-11-17 08:38:27 --> Output Class Initialized
INFO - 2020-11-17 08:38:27 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:27 --> Input Class Initialized
INFO - 2020-11-17 08:38:27 --> Language Class Initialized
INFO - 2020-11-17 08:38:27 --> Language Class Initialized
INFO - 2020-11-17 08:38:27 --> Config Class Initialized
INFO - 2020-11-17 08:38:27 --> Loader Class Initialized
INFO - 2020-11-17 08:38:27 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:27 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:27 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:27 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:27 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:27 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-17 08:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:27 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:27 --> Total execution time: 0.2970
INFO - 2020-11-17 08:38:27 --> Config Class Initialized
INFO - 2020-11-17 08:38:27 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:27 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:27 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:27 --> URI Class Initialized
INFO - 2020-11-17 08:38:27 --> Router Class Initialized
INFO - 2020-11-17 08:38:27 --> Output Class Initialized
INFO - 2020-11-17 08:38:27 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:27 --> Input Class Initialized
INFO - 2020-11-17 08:38:27 --> Language Class Initialized
INFO - 2020-11-17 08:38:28 --> Language Class Initialized
INFO - 2020-11-17 08:38:28 --> Config Class Initialized
INFO - 2020-11-17 08:38:28 --> Loader Class Initialized
INFO - 2020-11-17 08:38:28 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:28 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:28 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:28 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:28 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:28 --> Controller Class Initialized
INFO - 2020-11-17 08:38:29 --> Config Class Initialized
INFO - 2020-11-17 08:38:29 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:29 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:29 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:29 --> URI Class Initialized
INFO - 2020-11-17 08:38:29 --> Router Class Initialized
INFO - 2020-11-17 08:38:29 --> Output Class Initialized
INFO - 2020-11-17 08:38:29 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:29 --> Input Class Initialized
INFO - 2020-11-17 08:38:29 --> Language Class Initialized
INFO - 2020-11-17 08:38:29 --> Language Class Initialized
INFO - 2020-11-17 08:38:29 --> Config Class Initialized
INFO - 2020-11-17 08:38:29 --> Loader Class Initialized
INFO - 2020-11-17 08:38:29 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:29 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:29 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:29 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:29 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:29 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-17 08:38:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:29 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:29 --> Total execution time: 0.3121
INFO - 2020-11-17 08:38:29 --> Config Class Initialized
INFO - 2020-11-17 08:38:29 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:29 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:29 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:29 --> URI Class Initialized
INFO - 2020-11-17 08:38:29 --> Router Class Initialized
INFO - 2020-11-17 08:38:29 --> Output Class Initialized
INFO - 2020-11-17 08:38:29 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:29 --> Input Class Initialized
INFO - 2020-11-17 08:38:29 --> Language Class Initialized
INFO - 2020-11-17 08:38:29 --> Language Class Initialized
INFO - 2020-11-17 08:38:29 --> Config Class Initialized
INFO - 2020-11-17 08:38:29 --> Loader Class Initialized
INFO - 2020-11-17 08:38:29 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:29 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:29 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:29 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:29 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:29 --> Controller Class Initialized
INFO - 2020-11-17 08:38:30 --> Config Class Initialized
INFO - 2020-11-17 08:38:30 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:30 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:30 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:30 --> URI Class Initialized
INFO - 2020-11-17 08:38:30 --> Router Class Initialized
INFO - 2020-11-17 08:38:30 --> Output Class Initialized
INFO - 2020-11-17 08:38:30 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:30 --> Input Class Initialized
INFO - 2020-11-17 08:38:30 --> Language Class Initialized
INFO - 2020-11-17 08:38:30 --> Language Class Initialized
INFO - 2020-11-17 08:38:30 --> Config Class Initialized
INFO - 2020-11-17 08:38:30 --> Loader Class Initialized
INFO - 2020-11-17 08:38:30 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:30 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:30 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:30 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:30 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:30 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-17 08:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:30 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:30 --> Total execution time: 0.3112
INFO - 2020-11-17 08:38:30 --> Config Class Initialized
INFO - 2020-11-17 08:38:30 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:30 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:30 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:30 --> URI Class Initialized
INFO - 2020-11-17 08:38:30 --> Router Class Initialized
INFO - 2020-11-17 08:38:31 --> Output Class Initialized
INFO - 2020-11-17 08:38:31 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:31 --> Input Class Initialized
INFO - 2020-11-17 08:38:31 --> Language Class Initialized
INFO - 2020-11-17 08:38:31 --> Language Class Initialized
INFO - 2020-11-17 08:38:31 --> Config Class Initialized
INFO - 2020-11-17 08:38:31 --> Loader Class Initialized
INFO - 2020-11-17 08:38:31 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:31 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:31 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:31 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:31 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:31 --> Controller Class Initialized
INFO - 2020-11-17 08:38:32 --> Config Class Initialized
INFO - 2020-11-17 08:38:32 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:32 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:32 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:32 --> URI Class Initialized
INFO - 2020-11-17 08:38:32 --> Router Class Initialized
INFO - 2020-11-17 08:38:32 --> Output Class Initialized
INFO - 2020-11-17 08:38:32 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:32 --> Input Class Initialized
INFO - 2020-11-17 08:38:32 --> Language Class Initialized
INFO - 2020-11-17 08:38:32 --> Language Class Initialized
INFO - 2020-11-17 08:38:32 --> Config Class Initialized
INFO - 2020-11-17 08:38:32 --> Loader Class Initialized
INFO - 2020-11-17 08:38:32 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:32 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:32 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:32 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:32 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:33 --> Controller Class Initialized
DEBUG - 2020-11-17 08:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-17 08:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:38:33 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:33 --> Total execution time: 0.2780
INFO - 2020-11-17 08:38:33 --> Config Class Initialized
INFO - 2020-11-17 08:38:33 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:33 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:33 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:33 --> URI Class Initialized
INFO - 2020-11-17 08:38:33 --> Router Class Initialized
INFO - 2020-11-17 08:38:33 --> Output Class Initialized
INFO - 2020-11-17 08:38:33 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:33 --> Input Class Initialized
INFO - 2020-11-17 08:38:33 --> Language Class Initialized
INFO - 2020-11-17 08:38:33 --> Language Class Initialized
INFO - 2020-11-17 08:38:33 --> Config Class Initialized
INFO - 2020-11-17 08:38:33 --> Loader Class Initialized
INFO - 2020-11-17 08:38:33 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:33 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:33 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:33 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:33 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:33 --> Controller Class Initialized
INFO - 2020-11-17 08:38:43 --> Config Class Initialized
INFO - 2020-11-17 08:38:43 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:38:43 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:38:43 --> Utf8 Class Initialized
INFO - 2020-11-17 08:38:43 --> URI Class Initialized
INFO - 2020-11-17 08:38:43 --> Router Class Initialized
INFO - 2020-11-17 08:38:43 --> Output Class Initialized
INFO - 2020-11-17 08:38:43 --> Security Class Initialized
DEBUG - 2020-11-17 08:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:38:43 --> Input Class Initialized
INFO - 2020-11-17 08:38:43 --> Language Class Initialized
INFO - 2020-11-17 08:38:43 --> Language Class Initialized
INFO - 2020-11-17 08:38:43 --> Config Class Initialized
INFO - 2020-11-17 08:38:43 --> Loader Class Initialized
INFO - 2020-11-17 08:38:43 --> Helper loaded: url_helper
INFO - 2020-11-17 08:38:43 --> Helper loaded: file_helper
INFO - 2020-11-17 08:38:43 --> Helper loaded: form_helper
INFO - 2020-11-17 08:38:43 --> Helper loaded: my_helper
INFO - 2020-11-17 08:38:43 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:38:43 --> Controller Class Initialized
INFO - 2020-11-17 08:38:43 --> Final output sent to browser
DEBUG - 2020-11-17 08:38:43 --> Total execution time: 0.3312
INFO - 2020-11-17 08:40:08 --> Config Class Initialized
INFO - 2020-11-17 08:40:08 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:08 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:08 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:08 --> URI Class Initialized
INFO - 2020-11-17 08:40:08 --> Router Class Initialized
INFO - 2020-11-17 08:40:08 --> Output Class Initialized
INFO - 2020-11-17 08:40:08 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:08 --> Input Class Initialized
INFO - 2020-11-17 08:40:08 --> Language Class Initialized
INFO - 2020-11-17 08:40:08 --> Language Class Initialized
INFO - 2020-11-17 08:40:08 --> Config Class Initialized
INFO - 2020-11-17 08:40:08 --> Loader Class Initialized
INFO - 2020-11-17 08:40:08 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:08 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:08 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:08 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:08 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:08 --> Controller Class Initialized
INFO - 2020-11-17 08:40:08 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:08 --> Total execution time: 0.3323
INFO - 2020-11-17 08:40:08 --> Config Class Initialized
INFO - 2020-11-17 08:40:08 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:08 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:08 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:08 --> URI Class Initialized
INFO - 2020-11-17 08:40:08 --> Router Class Initialized
INFO - 2020-11-17 08:40:08 --> Output Class Initialized
INFO - 2020-11-17 08:40:08 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:08 --> Input Class Initialized
INFO - 2020-11-17 08:40:08 --> Language Class Initialized
INFO - 2020-11-17 08:40:08 --> Language Class Initialized
INFO - 2020-11-17 08:40:08 --> Config Class Initialized
INFO - 2020-11-17 08:40:08 --> Loader Class Initialized
INFO - 2020-11-17 08:40:08 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:08 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:08 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:08 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:08 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:08 --> Controller Class Initialized
INFO - 2020-11-17 08:40:11 --> Config Class Initialized
INFO - 2020-11-17 08:40:11 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:11 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:11 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:11 --> URI Class Initialized
INFO - 2020-11-17 08:40:11 --> Router Class Initialized
INFO - 2020-11-17 08:40:11 --> Output Class Initialized
INFO - 2020-11-17 08:40:11 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:11 --> Input Class Initialized
INFO - 2020-11-17 08:40:11 --> Language Class Initialized
INFO - 2020-11-17 08:40:11 --> Language Class Initialized
INFO - 2020-11-17 08:40:12 --> Config Class Initialized
INFO - 2020-11-17 08:40:12 --> Loader Class Initialized
INFO - 2020-11-17 08:40:12 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:12 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:12 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:12 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:12 --> Controller Class Initialized
INFO - 2020-11-17 08:40:12 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:40:12 --> Config Class Initialized
INFO - 2020-11-17 08:40:12 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:12 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:12 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:12 --> URI Class Initialized
INFO - 2020-11-17 08:40:12 --> Router Class Initialized
INFO - 2020-11-17 08:40:12 --> Output Class Initialized
INFO - 2020-11-17 08:40:12 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:12 --> Input Class Initialized
INFO - 2020-11-17 08:40:12 --> Language Class Initialized
INFO - 2020-11-17 08:40:12 --> Language Class Initialized
INFO - 2020-11-17 08:40:12 --> Config Class Initialized
INFO - 2020-11-17 08:40:12 --> Loader Class Initialized
INFO - 2020-11-17 08:40:12 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:12 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:12 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:12 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:12 --> Controller Class Initialized
DEBUG - 2020-11-17 08:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:40:12 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:12 --> Total execution time: 0.2771
INFO - 2020-11-17 08:40:18 --> Config Class Initialized
INFO - 2020-11-17 08:40:18 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:18 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:18 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:18 --> URI Class Initialized
INFO - 2020-11-17 08:40:18 --> Router Class Initialized
INFO - 2020-11-17 08:40:18 --> Output Class Initialized
INFO - 2020-11-17 08:40:18 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:18 --> Input Class Initialized
INFO - 2020-11-17 08:40:18 --> Language Class Initialized
INFO - 2020-11-17 08:40:18 --> Language Class Initialized
INFO - 2020-11-17 08:40:18 --> Config Class Initialized
INFO - 2020-11-17 08:40:18 --> Loader Class Initialized
INFO - 2020-11-17 08:40:18 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:18 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:18 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:18 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:18 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:18 --> Controller Class Initialized
INFO - 2020-11-17 08:40:18 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:40:18 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:18 --> Total execution time: 0.3531
INFO - 2020-11-17 08:40:19 --> Config Class Initialized
INFO - 2020-11-17 08:40:19 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:19 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:19 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:19 --> URI Class Initialized
INFO - 2020-11-17 08:40:19 --> Router Class Initialized
INFO - 2020-11-17 08:40:19 --> Output Class Initialized
INFO - 2020-11-17 08:40:19 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:19 --> Input Class Initialized
INFO - 2020-11-17 08:40:19 --> Language Class Initialized
INFO - 2020-11-17 08:40:19 --> Language Class Initialized
INFO - 2020-11-17 08:40:19 --> Config Class Initialized
INFO - 2020-11-17 08:40:19 --> Loader Class Initialized
INFO - 2020-11-17 08:40:19 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:19 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:19 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:19 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:19 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:19 --> Controller Class Initialized
DEBUG - 2020-11-17 08:40:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:40:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:40:19 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:19 --> Total execution time: 0.3881
INFO - 2020-11-17 08:40:21 --> Config Class Initialized
INFO - 2020-11-17 08:40:21 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:21 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:21 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:21 --> URI Class Initialized
INFO - 2020-11-17 08:40:21 --> Router Class Initialized
INFO - 2020-11-17 08:40:21 --> Output Class Initialized
INFO - 2020-11-17 08:40:21 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:21 --> Input Class Initialized
INFO - 2020-11-17 08:40:21 --> Language Class Initialized
INFO - 2020-11-17 08:40:21 --> Language Class Initialized
INFO - 2020-11-17 08:40:21 --> Config Class Initialized
INFO - 2020-11-17 08:40:21 --> Loader Class Initialized
INFO - 2020-11-17 08:40:21 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:21 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:21 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:21 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:21 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:21 --> Controller Class Initialized
DEBUG - 2020-11-17 08:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-17 08:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:40:21 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:21 --> Total execution time: 0.3383
INFO - 2020-11-17 08:40:22 --> Config Class Initialized
INFO - 2020-11-17 08:40:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:23 --> URI Class Initialized
INFO - 2020-11-17 08:40:23 --> Router Class Initialized
INFO - 2020-11-17 08:40:23 --> Output Class Initialized
INFO - 2020-11-17 08:40:23 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:23 --> Input Class Initialized
INFO - 2020-11-17 08:40:23 --> Language Class Initialized
INFO - 2020-11-17 08:40:23 --> Language Class Initialized
INFO - 2020-11-17 08:40:23 --> Config Class Initialized
INFO - 2020-11-17 08:40:23 --> Loader Class Initialized
INFO - 2020-11-17 08:40:23 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:23 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:23 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:23 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:23 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:23 --> Controller Class Initialized
DEBUG - 2020-11-17 08:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-11-17 08:40:23 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:23 --> Total execution time: 0.3173
INFO - 2020-11-17 08:40:26 --> Config Class Initialized
INFO - 2020-11-17 08:40:26 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:26 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:26 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:26 --> URI Class Initialized
INFO - 2020-11-17 08:40:26 --> Router Class Initialized
INFO - 2020-11-17 08:40:26 --> Output Class Initialized
INFO - 2020-11-17 08:40:26 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:26 --> Input Class Initialized
INFO - 2020-11-17 08:40:26 --> Language Class Initialized
INFO - 2020-11-17 08:40:26 --> Language Class Initialized
INFO - 2020-11-17 08:40:26 --> Config Class Initialized
INFO - 2020-11-17 08:40:26 --> Loader Class Initialized
INFO - 2020-11-17 08:40:26 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:26 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:26 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:26 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:26 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:26 --> Controller Class Initialized
DEBUG - 2020-11-17 08:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-17 08:40:26 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:26 --> Total execution time: 0.3209
INFO - 2020-11-17 08:40:45 --> Config Class Initialized
INFO - 2020-11-17 08:40:45 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:45 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:45 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:45 --> URI Class Initialized
INFO - 2020-11-17 08:40:45 --> Router Class Initialized
INFO - 2020-11-17 08:40:45 --> Output Class Initialized
INFO - 2020-11-17 08:40:45 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:45 --> Input Class Initialized
INFO - 2020-11-17 08:40:45 --> Language Class Initialized
INFO - 2020-11-17 08:40:45 --> Language Class Initialized
INFO - 2020-11-17 08:40:45 --> Config Class Initialized
INFO - 2020-11-17 08:40:45 --> Loader Class Initialized
INFO - 2020-11-17 08:40:45 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:45 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:45 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:45 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:45 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:45 --> Controller Class Initialized
INFO - 2020-11-17 08:40:45 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:40:45 --> Config Class Initialized
INFO - 2020-11-17 08:40:45 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:45 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:45 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:45 --> URI Class Initialized
INFO - 2020-11-17 08:40:45 --> Router Class Initialized
INFO - 2020-11-17 08:40:45 --> Output Class Initialized
INFO - 2020-11-17 08:40:45 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:45 --> Input Class Initialized
INFO - 2020-11-17 08:40:45 --> Language Class Initialized
INFO - 2020-11-17 08:40:45 --> Language Class Initialized
INFO - 2020-11-17 08:40:45 --> Config Class Initialized
INFO - 2020-11-17 08:40:45 --> Loader Class Initialized
INFO - 2020-11-17 08:40:45 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:45 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:45 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:45 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:45 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:45 --> Controller Class Initialized
DEBUG - 2020-11-17 08:40:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:40:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:40:45 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:45 --> Total execution time: 0.3046
INFO - 2020-11-17 08:40:51 --> Config Class Initialized
INFO - 2020-11-17 08:40:51 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:51 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:51 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:51 --> URI Class Initialized
INFO - 2020-11-17 08:40:51 --> Router Class Initialized
INFO - 2020-11-17 08:40:51 --> Output Class Initialized
INFO - 2020-11-17 08:40:51 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:51 --> Input Class Initialized
INFO - 2020-11-17 08:40:51 --> Language Class Initialized
INFO - 2020-11-17 08:40:51 --> Language Class Initialized
INFO - 2020-11-17 08:40:51 --> Config Class Initialized
INFO - 2020-11-17 08:40:51 --> Loader Class Initialized
INFO - 2020-11-17 08:40:51 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:51 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:51 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:51 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:51 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:51 --> Controller Class Initialized
INFO - 2020-11-17 08:40:51 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:40:51 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:51 --> Total execution time: 0.3442
INFO - 2020-11-17 08:40:51 --> Config Class Initialized
INFO - 2020-11-17 08:40:51 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:51 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:51 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:51 --> URI Class Initialized
INFO - 2020-11-17 08:40:51 --> Router Class Initialized
INFO - 2020-11-17 08:40:51 --> Output Class Initialized
INFO - 2020-11-17 08:40:51 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:52 --> Input Class Initialized
INFO - 2020-11-17 08:40:52 --> Language Class Initialized
INFO - 2020-11-17 08:40:52 --> Language Class Initialized
INFO - 2020-11-17 08:40:52 --> Config Class Initialized
INFO - 2020-11-17 08:40:52 --> Loader Class Initialized
INFO - 2020-11-17 08:40:52 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:52 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:52 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:52 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:52 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:52 --> Controller Class Initialized
DEBUG - 2020-11-17 08:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:40:52 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:52 --> Total execution time: 0.3819
INFO - 2020-11-17 08:40:53 --> Config Class Initialized
INFO - 2020-11-17 08:40:53 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:53 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:53 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:53 --> URI Class Initialized
INFO - 2020-11-17 08:40:53 --> Router Class Initialized
INFO - 2020-11-17 08:40:53 --> Output Class Initialized
INFO - 2020-11-17 08:40:53 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:53 --> Input Class Initialized
INFO - 2020-11-17 08:40:53 --> Language Class Initialized
INFO - 2020-11-17 08:40:53 --> Language Class Initialized
INFO - 2020-11-17 08:40:53 --> Config Class Initialized
INFO - 2020-11-17 08:40:53 --> Loader Class Initialized
INFO - 2020-11-17 08:40:53 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:53 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:53 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:53 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:53 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:53 --> Controller Class Initialized
DEBUG - 2020-11-17 08:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-17 08:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:40:53 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:53 --> Total execution time: 0.3739
INFO - 2020-11-17 08:40:54 --> Config Class Initialized
INFO - 2020-11-17 08:40:54 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:54 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:54 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:54 --> URI Class Initialized
INFO - 2020-11-17 08:40:54 --> Router Class Initialized
INFO - 2020-11-17 08:40:54 --> Output Class Initialized
INFO - 2020-11-17 08:40:54 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:54 --> Input Class Initialized
INFO - 2020-11-17 08:40:54 --> Language Class Initialized
INFO - 2020-11-17 08:40:54 --> Language Class Initialized
INFO - 2020-11-17 08:40:54 --> Config Class Initialized
INFO - 2020-11-17 08:40:54 --> Loader Class Initialized
INFO - 2020-11-17 08:40:54 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:54 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:54 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:54 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:54 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:54 --> Controller Class Initialized
INFO - 2020-11-17 08:40:55 --> Config Class Initialized
INFO - 2020-11-17 08:40:55 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:40:55 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:40:55 --> Utf8 Class Initialized
INFO - 2020-11-17 08:40:55 --> URI Class Initialized
INFO - 2020-11-17 08:40:55 --> Router Class Initialized
INFO - 2020-11-17 08:40:55 --> Output Class Initialized
INFO - 2020-11-17 08:40:55 --> Security Class Initialized
DEBUG - 2020-11-17 08:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:40:55 --> Input Class Initialized
INFO - 2020-11-17 08:40:55 --> Language Class Initialized
INFO - 2020-11-17 08:40:56 --> Language Class Initialized
INFO - 2020-11-17 08:40:56 --> Config Class Initialized
INFO - 2020-11-17 08:40:56 --> Loader Class Initialized
INFO - 2020-11-17 08:40:56 --> Helper loaded: url_helper
INFO - 2020-11-17 08:40:56 --> Helper loaded: file_helper
INFO - 2020-11-17 08:40:56 --> Helper loaded: form_helper
INFO - 2020-11-17 08:40:56 --> Helper loaded: my_helper
INFO - 2020-11-17 08:40:56 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:40:56 --> Controller Class Initialized
INFO - 2020-11-17 08:40:56 --> Final output sent to browser
DEBUG - 2020-11-17 08:40:56 --> Total execution time: 0.3285
INFO - 2020-11-17 08:41:08 --> Config Class Initialized
INFO - 2020-11-17 08:41:08 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:08 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:08 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:08 --> URI Class Initialized
INFO - 2020-11-17 08:41:08 --> Router Class Initialized
INFO - 2020-11-17 08:41:08 --> Output Class Initialized
INFO - 2020-11-17 08:41:08 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:08 --> Input Class Initialized
INFO - 2020-11-17 08:41:08 --> Language Class Initialized
INFO - 2020-11-17 08:41:08 --> Language Class Initialized
INFO - 2020-11-17 08:41:08 --> Config Class Initialized
INFO - 2020-11-17 08:41:08 --> Loader Class Initialized
INFO - 2020-11-17 08:41:08 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:08 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:08 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:08 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:08 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:09 --> Controller Class Initialized
INFO - 2020-11-17 08:41:09 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:09 --> Total execution time: 0.3713
INFO - 2020-11-17 08:41:09 --> Config Class Initialized
INFO - 2020-11-17 08:41:09 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:09 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:09 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:09 --> URI Class Initialized
INFO - 2020-11-17 08:41:09 --> Router Class Initialized
INFO - 2020-11-17 08:41:09 --> Output Class Initialized
INFO - 2020-11-17 08:41:09 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:09 --> Input Class Initialized
INFO - 2020-11-17 08:41:09 --> Language Class Initialized
INFO - 2020-11-17 08:41:09 --> Language Class Initialized
INFO - 2020-11-17 08:41:09 --> Config Class Initialized
INFO - 2020-11-17 08:41:09 --> Loader Class Initialized
INFO - 2020-11-17 08:41:09 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:09 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:09 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:09 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:09 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:09 --> Controller Class Initialized
INFO - 2020-11-17 08:41:11 --> Config Class Initialized
INFO - 2020-11-17 08:41:11 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:11 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:11 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:11 --> URI Class Initialized
INFO - 2020-11-17 08:41:11 --> Router Class Initialized
INFO - 2020-11-17 08:41:11 --> Output Class Initialized
INFO - 2020-11-17 08:41:11 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:11 --> Input Class Initialized
INFO - 2020-11-17 08:41:11 --> Language Class Initialized
INFO - 2020-11-17 08:41:11 --> Language Class Initialized
INFO - 2020-11-17 08:41:11 --> Config Class Initialized
INFO - 2020-11-17 08:41:11 --> Loader Class Initialized
INFO - 2020-11-17 08:41:11 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:11 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:11 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:11 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:11 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:12 --> Controller Class Initialized
INFO - 2020-11-17 08:41:12 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:41:12 --> Config Class Initialized
INFO - 2020-11-17 08:41:12 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:12 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:12 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:12 --> URI Class Initialized
INFO - 2020-11-17 08:41:12 --> Router Class Initialized
INFO - 2020-11-17 08:41:12 --> Output Class Initialized
INFO - 2020-11-17 08:41:12 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:12 --> Input Class Initialized
INFO - 2020-11-17 08:41:12 --> Language Class Initialized
INFO - 2020-11-17 08:41:12 --> Language Class Initialized
INFO - 2020-11-17 08:41:12 --> Config Class Initialized
INFO - 2020-11-17 08:41:12 --> Loader Class Initialized
INFO - 2020-11-17 08:41:12 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:12 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:12 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:12 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:12 --> Controller Class Initialized
DEBUG - 2020-11-17 08:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:41:12 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:12 --> Total execution time: 0.2798
INFO - 2020-11-17 08:41:16 --> Config Class Initialized
INFO - 2020-11-17 08:41:16 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:16 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:16 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:17 --> URI Class Initialized
INFO - 2020-11-17 08:41:17 --> Router Class Initialized
INFO - 2020-11-17 08:41:17 --> Output Class Initialized
INFO - 2020-11-17 08:41:17 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:17 --> Input Class Initialized
INFO - 2020-11-17 08:41:17 --> Language Class Initialized
INFO - 2020-11-17 08:41:17 --> Language Class Initialized
INFO - 2020-11-17 08:41:17 --> Config Class Initialized
INFO - 2020-11-17 08:41:17 --> Loader Class Initialized
INFO - 2020-11-17 08:41:17 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:17 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:17 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:17 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:17 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:17 --> Controller Class Initialized
INFO - 2020-11-17 08:41:17 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:41:17 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:17 --> Total execution time: 0.3561
INFO - 2020-11-17 08:41:17 --> Config Class Initialized
INFO - 2020-11-17 08:41:17 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:17 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:17 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:17 --> URI Class Initialized
INFO - 2020-11-17 08:41:17 --> Router Class Initialized
INFO - 2020-11-17 08:41:17 --> Output Class Initialized
INFO - 2020-11-17 08:41:18 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:18 --> Input Class Initialized
INFO - 2020-11-17 08:41:18 --> Language Class Initialized
INFO - 2020-11-17 08:41:18 --> Language Class Initialized
INFO - 2020-11-17 08:41:18 --> Config Class Initialized
INFO - 2020-11-17 08:41:18 --> Loader Class Initialized
INFO - 2020-11-17 08:41:18 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:18 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:18 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:18 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:18 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:18 --> Controller Class Initialized
DEBUG - 2020-11-17 08:41:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:41:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:41:18 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:18 --> Total execution time: 0.3991
INFO - 2020-11-17 08:41:23 --> Config Class Initialized
INFO - 2020-11-17 08:41:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:23 --> URI Class Initialized
INFO - 2020-11-17 08:41:23 --> Router Class Initialized
INFO - 2020-11-17 08:41:23 --> Output Class Initialized
INFO - 2020-11-17 08:41:23 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:23 --> Input Class Initialized
INFO - 2020-11-17 08:41:23 --> Language Class Initialized
INFO - 2020-11-17 08:41:23 --> Language Class Initialized
INFO - 2020-11-17 08:41:23 --> Config Class Initialized
INFO - 2020-11-17 08:41:23 --> Loader Class Initialized
INFO - 2020-11-17 08:41:23 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:24 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:24 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:24 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:24 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:24 --> Controller Class Initialized
DEBUG - 2020-11-17 08:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-17 08:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:41:24 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:24 --> Total execution time: 0.3410
INFO - 2020-11-17 08:41:25 --> Config Class Initialized
INFO - 2020-11-17 08:41:25 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:25 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:25 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:25 --> URI Class Initialized
INFO - 2020-11-17 08:41:25 --> Router Class Initialized
INFO - 2020-11-17 08:41:25 --> Output Class Initialized
INFO - 2020-11-17 08:41:25 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:25 --> Input Class Initialized
INFO - 2020-11-17 08:41:25 --> Language Class Initialized
INFO - 2020-11-17 08:41:25 --> Language Class Initialized
INFO - 2020-11-17 08:41:25 --> Config Class Initialized
INFO - 2020-11-17 08:41:25 --> Loader Class Initialized
INFO - 2020-11-17 08:41:25 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:25 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:25 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:25 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:25 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:25 --> Controller Class Initialized
DEBUG - 2020-11-17 08:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-17 08:41:25 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:25 --> Total execution time: 0.3205
INFO - 2020-11-17 08:41:40 --> Config Class Initialized
INFO - 2020-11-17 08:41:40 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:40 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:40 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:40 --> URI Class Initialized
INFO - 2020-11-17 08:41:40 --> Router Class Initialized
INFO - 2020-11-17 08:41:40 --> Output Class Initialized
INFO - 2020-11-17 08:41:40 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:40 --> Input Class Initialized
INFO - 2020-11-17 08:41:40 --> Language Class Initialized
INFO - 2020-11-17 08:41:40 --> Language Class Initialized
INFO - 2020-11-17 08:41:40 --> Config Class Initialized
INFO - 2020-11-17 08:41:40 --> Loader Class Initialized
INFO - 2020-11-17 08:41:40 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:40 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:40 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:40 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:40 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:40 --> Controller Class Initialized
INFO - 2020-11-17 08:41:40 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:41:40 --> Config Class Initialized
INFO - 2020-11-17 08:41:40 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:40 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:40 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:40 --> URI Class Initialized
INFO - 2020-11-17 08:41:40 --> Router Class Initialized
INFO - 2020-11-17 08:41:40 --> Output Class Initialized
INFO - 2020-11-17 08:41:40 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:40 --> Input Class Initialized
INFO - 2020-11-17 08:41:40 --> Language Class Initialized
INFO - 2020-11-17 08:41:40 --> Language Class Initialized
INFO - 2020-11-17 08:41:40 --> Config Class Initialized
INFO - 2020-11-17 08:41:40 --> Loader Class Initialized
INFO - 2020-11-17 08:41:41 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:41 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:41 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:41 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:41 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:41 --> Controller Class Initialized
DEBUG - 2020-11-17 08:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:41:41 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:41 --> Total execution time: 0.3173
INFO - 2020-11-17 08:41:48 --> Config Class Initialized
INFO - 2020-11-17 08:41:48 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:48 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:48 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:48 --> URI Class Initialized
INFO - 2020-11-17 08:41:48 --> Router Class Initialized
INFO - 2020-11-17 08:41:48 --> Output Class Initialized
INFO - 2020-11-17 08:41:48 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:48 --> Input Class Initialized
INFO - 2020-11-17 08:41:48 --> Language Class Initialized
INFO - 2020-11-17 08:41:48 --> Language Class Initialized
INFO - 2020-11-17 08:41:48 --> Config Class Initialized
INFO - 2020-11-17 08:41:48 --> Loader Class Initialized
INFO - 2020-11-17 08:41:48 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:48 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:48 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:48 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:48 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:48 --> Controller Class Initialized
INFO - 2020-11-17 08:41:48 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:41:48 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:48 --> Total execution time: 0.3550
INFO - 2020-11-17 08:41:49 --> Config Class Initialized
INFO - 2020-11-17 08:41:49 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:49 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:49 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:49 --> URI Class Initialized
INFO - 2020-11-17 08:41:49 --> Router Class Initialized
INFO - 2020-11-17 08:41:49 --> Output Class Initialized
INFO - 2020-11-17 08:41:49 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:49 --> Input Class Initialized
INFO - 2020-11-17 08:41:49 --> Language Class Initialized
INFO - 2020-11-17 08:41:49 --> Language Class Initialized
INFO - 2020-11-17 08:41:49 --> Config Class Initialized
INFO - 2020-11-17 08:41:49 --> Loader Class Initialized
INFO - 2020-11-17 08:41:49 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:49 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:49 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:49 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:49 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:49 --> Controller Class Initialized
DEBUG - 2020-11-17 08:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:41:49 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:49 --> Total execution time: 0.4013
INFO - 2020-11-17 08:41:51 --> Config Class Initialized
INFO - 2020-11-17 08:41:51 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:51 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:51 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:51 --> URI Class Initialized
INFO - 2020-11-17 08:41:51 --> Router Class Initialized
INFO - 2020-11-17 08:41:51 --> Output Class Initialized
INFO - 2020-11-17 08:41:51 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:51 --> Input Class Initialized
INFO - 2020-11-17 08:41:51 --> Language Class Initialized
INFO - 2020-11-17 08:41:51 --> Language Class Initialized
INFO - 2020-11-17 08:41:51 --> Config Class Initialized
INFO - 2020-11-17 08:41:51 --> Loader Class Initialized
INFO - 2020-11-17 08:41:51 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:51 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:51 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:51 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:51 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:51 --> Controller Class Initialized
DEBUG - 2020-11-17 08:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-17 08:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:41:51 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:51 --> Total execution time: 0.2913
INFO - 2020-11-17 08:41:51 --> Config Class Initialized
INFO - 2020-11-17 08:41:51 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:51 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:51 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:51 --> URI Class Initialized
INFO - 2020-11-17 08:41:51 --> Router Class Initialized
INFO - 2020-11-17 08:41:51 --> Output Class Initialized
INFO - 2020-11-17 08:41:51 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:51 --> Input Class Initialized
INFO - 2020-11-17 08:41:51 --> Language Class Initialized
INFO - 2020-11-17 08:41:51 --> Language Class Initialized
INFO - 2020-11-17 08:41:51 --> Config Class Initialized
INFO - 2020-11-17 08:41:51 --> Loader Class Initialized
INFO - 2020-11-17 08:41:51 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:51 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:51 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:51 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:51 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:51 --> Controller Class Initialized
INFO - 2020-11-17 08:41:58 --> Config Class Initialized
INFO - 2020-11-17 08:41:58 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:41:58 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:41:58 --> Utf8 Class Initialized
INFO - 2020-11-17 08:41:58 --> URI Class Initialized
INFO - 2020-11-17 08:41:58 --> Router Class Initialized
INFO - 2020-11-17 08:41:58 --> Output Class Initialized
INFO - 2020-11-17 08:41:58 --> Security Class Initialized
DEBUG - 2020-11-17 08:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:41:58 --> Input Class Initialized
INFO - 2020-11-17 08:41:58 --> Language Class Initialized
INFO - 2020-11-17 08:41:58 --> Language Class Initialized
INFO - 2020-11-17 08:41:58 --> Config Class Initialized
INFO - 2020-11-17 08:41:58 --> Loader Class Initialized
INFO - 2020-11-17 08:41:58 --> Helper loaded: url_helper
INFO - 2020-11-17 08:41:58 --> Helper loaded: file_helper
INFO - 2020-11-17 08:41:58 --> Helper loaded: form_helper
INFO - 2020-11-17 08:41:58 --> Helper loaded: my_helper
INFO - 2020-11-17 08:41:58 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:41:58 --> Controller Class Initialized
INFO - 2020-11-17 08:41:58 --> Final output sent to browser
DEBUG - 2020-11-17 08:41:58 --> Total execution time: 0.3398
INFO - 2020-11-17 08:42:12 --> Config Class Initialized
INFO - 2020-11-17 08:42:12 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:42:12 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:42:12 --> Utf8 Class Initialized
INFO - 2020-11-17 08:42:12 --> URI Class Initialized
INFO - 2020-11-17 08:42:12 --> Router Class Initialized
INFO - 2020-11-17 08:42:12 --> Output Class Initialized
INFO - 2020-11-17 08:42:12 --> Security Class Initialized
DEBUG - 2020-11-17 08:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:42:12 --> Input Class Initialized
INFO - 2020-11-17 08:42:12 --> Language Class Initialized
INFO - 2020-11-17 08:42:12 --> Language Class Initialized
INFO - 2020-11-17 08:42:12 --> Config Class Initialized
INFO - 2020-11-17 08:42:12 --> Loader Class Initialized
INFO - 2020-11-17 08:42:12 --> Helper loaded: url_helper
INFO - 2020-11-17 08:42:12 --> Helper loaded: file_helper
INFO - 2020-11-17 08:42:12 --> Helper loaded: form_helper
INFO - 2020-11-17 08:42:12 --> Helper loaded: my_helper
INFO - 2020-11-17 08:42:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:42:12 --> Controller Class Initialized
INFO - 2020-11-17 08:42:12 --> Final output sent to browser
DEBUG - 2020-11-17 08:42:12 --> Total execution time: 0.3398
INFO - 2020-11-17 08:42:27 --> Config Class Initialized
INFO - 2020-11-17 08:42:27 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:42:27 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:42:27 --> Utf8 Class Initialized
INFO - 2020-11-17 08:42:27 --> URI Class Initialized
INFO - 2020-11-17 08:42:27 --> Router Class Initialized
INFO - 2020-11-17 08:42:27 --> Output Class Initialized
INFO - 2020-11-17 08:42:28 --> Security Class Initialized
DEBUG - 2020-11-17 08:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:42:28 --> Input Class Initialized
INFO - 2020-11-17 08:42:28 --> Language Class Initialized
INFO - 2020-11-17 08:42:28 --> Language Class Initialized
INFO - 2020-11-17 08:42:28 --> Config Class Initialized
INFO - 2020-11-17 08:42:28 --> Loader Class Initialized
INFO - 2020-11-17 08:42:28 --> Helper loaded: url_helper
INFO - 2020-11-17 08:42:28 --> Helper loaded: file_helper
INFO - 2020-11-17 08:42:28 --> Helper loaded: form_helper
INFO - 2020-11-17 08:42:28 --> Helper loaded: my_helper
INFO - 2020-11-17 08:42:28 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:42:28 --> Controller Class Initialized
INFO - 2020-11-17 08:42:28 --> Final output sent to browser
DEBUG - 2020-11-17 08:42:28 --> Total execution time: 0.3629
INFO - 2020-11-17 08:42:48 --> Config Class Initialized
INFO - 2020-11-17 08:42:48 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:42:48 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:42:48 --> Utf8 Class Initialized
INFO - 2020-11-17 08:42:48 --> URI Class Initialized
INFO - 2020-11-17 08:42:48 --> Router Class Initialized
INFO - 2020-11-17 08:42:48 --> Output Class Initialized
INFO - 2020-11-17 08:42:48 --> Security Class Initialized
DEBUG - 2020-11-17 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:42:49 --> Input Class Initialized
INFO - 2020-11-17 08:42:49 --> Language Class Initialized
INFO - 2020-11-17 08:42:49 --> Language Class Initialized
INFO - 2020-11-17 08:42:49 --> Config Class Initialized
INFO - 2020-11-17 08:42:49 --> Loader Class Initialized
INFO - 2020-11-17 08:42:49 --> Helper loaded: url_helper
INFO - 2020-11-17 08:42:49 --> Helper loaded: file_helper
INFO - 2020-11-17 08:42:49 --> Helper loaded: form_helper
INFO - 2020-11-17 08:42:49 --> Helper loaded: my_helper
INFO - 2020-11-17 08:42:49 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:42:49 --> Controller Class Initialized
INFO - 2020-11-17 08:42:49 --> Final output sent to browser
DEBUG - 2020-11-17 08:42:49 --> Total execution time: 0.3621
INFO - 2020-11-17 08:42:49 --> Config Class Initialized
INFO - 2020-11-17 08:42:49 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:42:49 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:42:49 --> Utf8 Class Initialized
INFO - 2020-11-17 08:42:49 --> URI Class Initialized
INFO - 2020-11-17 08:42:49 --> Router Class Initialized
INFO - 2020-11-17 08:42:49 --> Output Class Initialized
INFO - 2020-11-17 08:42:49 --> Security Class Initialized
DEBUG - 2020-11-17 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:42:49 --> Input Class Initialized
INFO - 2020-11-17 08:42:49 --> Language Class Initialized
INFO - 2020-11-17 08:42:49 --> Language Class Initialized
INFO - 2020-11-17 08:42:49 --> Config Class Initialized
INFO - 2020-11-17 08:42:49 --> Loader Class Initialized
INFO - 2020-11-17 08:42:49 --> Helper loaded: url_helper
INFO - 2020-11-17 08:42:49 --> Helper loaded: file_helper
INFO - 2020-11-17 08:42:49 --> Helper loaded: form_helper
INFO - 2020-11-17 08:42:49 --> Helper loaded: my_helper
INFO - 2020-11-17 08:42:49 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:42:49 --> Controller Class Initialized
INFO - 2020-11-17 08:42:53 --> Config Class Initialized
INFO - 2020-11-17 08:42:53 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:42:53 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:42:53 --> Utf8 Class Initialized
INFO - 2020-11-17 08:42:53 --> URI Class Initialized
INFO - 2020-11-17 08:42:53 --> Router Class Initialized
INFO - 2020-11-17 08:42:53 --> Output Class Initialized
INFO - 2020-11-17 08:42:53 --> Security Class Initialized
DEBUG - 2020-11-17 08:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:42:53 --> Input Class Initialized
INFO - 2020-11-17 08:42:53 --> Language Class Initialized
INFO - 2020-11-17 08:42:53 --> Language Class Initialized
INFO - 2020-11-17 08:42:53 --> Config Class Initialized
INFO - 2020-11-17 08:42:53 --> Loader Class Initialized
INFO - 2020-11-17 08:42:53 --> Helper loaded: url_helper
INFO - 2020-11-17 08:42:53 --> Helper loaded: file_helper
INFO - 2020-11-17 08:42:53 --> Helper loaded: form_helper
INFO - 2020-11-17 08:42:53 --> Helper loaded: my_helper
INFO - 2020-11-17 08:42:53 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:42:53 --> Controller Class Initialized
INFO - 2020-11-17 08:42:53 --> Final output sent to browser
DEBUG - 2020-11-17 08:42:53 --> Total execution time: 0.2956
INFO - 2020-11-17 08:42:53 --> Config Class Initialized
INFO - 2020-11-17 08:42:53 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:42:53 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:42:53 --> Utf8 Class Initialized
INFO - 2020-11-17 08:42:53 --> URI Class Initialized
INFO - 2020-11-17 08:42:53 --> Router Class Initialized
INFO - 2020-11-17 08:42:53 --> Output Class Initialized
INFO - 2020-11-17 08:42:53 --> Security Class Initialized
DEBUG - 2020-11-17 08:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:42:53 --> Input Class Initialized
INFO - 2020-11-17 08:42:53 --> Language Class Initialized
INFO - 2020-11-17 08:42:53 --> Language Class Initialized
INFO - 2020-11-17 08:42:53 --> Config Class Initialized
INFO - 2020-11-17 08:42:53 --> Loader Class Initialized
INFO - 2020-11-17 08:42:53 --> Helper loaded: url_helper
INFO - 2020-11-17 08:42:54 --> Helper loaded: file_helper
INFO - 2020-11-17 08:42:54 --> Helper loaded: form_helper
INFO - 2020-11-17 08:42:54 --> Helper loaded: my_helper
INFO - 2020-11-17 08:42:54 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:42:54 --> Controller Class Initialized
INFO - 2020-11-17 08:43:01 --> Config Class Initialized
INFO - 2020-11-17 08:43:01 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:01 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:01 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:01 --> URI Class Initialized
INFO - 2020-11-17 08:43:01 --> Router Class Initialized
INFO - 2020-11-17 08:43:01 --> Output Class Initialized
INFO - 2020-11-17 08:43:01 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:01 --> Input Class Initialized
INFO - 2020-11-17 08:43:01 --> Language Class Initialized
INFO - 2020-11-17 08:43:01 --> Language Class Initialized
INFO - 2020-11-17 08:43:01 --> Config Class Initialized
INFO - 2020-11-17 08:43:01 --> Loader Class Initialized
INFO - 2020-11-17 08:43:01 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:01 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:01 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:01 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:01 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:01 --> Controller Class Initialized
INFO - 2020-11-17 08:43:01 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:01 --> Total execution time: 0.2894
INFO - 2020-11-17 08:43:01 --> Config Class Initialized
INFO - 2020-11-17 08:43:01 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:01 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:01 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:01 --> URI Class Initialized
INFO - 2020-11-17 08:43:01 --> Router Class Initialized
INFO - 2020-11-17 08:43:01 --> Output Class Initialized
INFO - 2020-11-17 08:43:01 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:01 --> Input Class Initialized
INFO - 2020-11-17 08:43:01 --> Language Class Initialized
INFO - 2020-11-17 08:43:01 --> Language Class Initialized
INFO - 2020-11-17 08:43:01 --> Config Class Initialized
INFO - 2020-11-17 08:43:01 --> Loader Class Initialized
INFO - 2020-11-17 08:43:01 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:01 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:01 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:01 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:01 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:01 --> Controller Class Initialized
INFO - 2020-11-17 08:43:21 --> Config Class Initialized
INFO - 2020-11-17 08:43:21 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:21 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:21 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:21 --> URI Class Initialized
INFO - 2020-11-17 08:43:21 --> Router Class Initialized
INFO - 2020-11-17 08:43:21 --> Output Class Initialized
INFO - 2020-11-17 08:43:21 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:21 --> Input Class Initialized
INFO - 2020-11-17 08:43:21 --> Language Class Initialized
INFO - 2020-11-17 08:43:21 --> Language Class Initialized
INFO - 2020-11-17 08:43:21 --> Config Class Initialized
INFO - 2020-11-17 08:43:21 --> Loader Class Initialized
INFO - 2020-11-17 08:43:21 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:21 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:21 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:21 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:21 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:21 --> Controller Class Initialized
INFO - 2020-11-17 08:43:21 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:21 --> Total execution time: 0.3135
INFO - 2020-11-17 08:43:21 --> Config Class Initialized
INFO - 2020-11-17 08:43:21 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:21 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:21 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:21 --> URI Class Initialized
INFO - 2020-11-17 08:43:21 --> Router Class Initialized
INFO - 2020-11-17 08:43:21 --> Output Class Initialized
INFO - 2020-11-17 08:43:21 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:21 --> Input Class Initialized
INFO - 2020-11-17 08:43:21 --> Language Class Initialized
INFO - 2020-11-17 08:43:21 --> Language Class Initialized
INFO - 2020-11-17 08:43:21 --> Config Class Initialized
INFO - 2020-11-17 08:43:21 --> Loader Class Initialized
INFO - 2020-11-17 08:43:21 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:21 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:21 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:21 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:21 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:21 --> Controller Class Initialized
INFO - 2020-11-17 08:43:23 --> Config Class Initialized
INFO - 2020-11-17 08:43:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:23 --> URI Class Initialized
INFO - 2020-11-17 08:43:23 --> Router Class Initialized
INFO - 2020-11-17 08:43:23 --> Output Class Initialized
INFO - 2020-11-17 08:43:23 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:23 --> Input Class Initialized
INFO - 2020-11-17 08:43:23 --> Language Class Initialized
INFO - 2020-11-17 08:43:23 --> Language Class Initialized
INFO - 2020-11-17 08:43:23 --> Config Class Initialized
INFO - 2020-11-17 08:43:23 --> Loader Class Initialized
INFO - 2020-11-17 08:43:23 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:23 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:23 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:23 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:23 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:23 --> Controller Class Initialized
INFO - 2020-11-17 08:43:23 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:43:23 --> Config Class Initialized
INFO - 2020-11-17 08:43:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:24 --> URI Class Initialized
INFO - 2020-11-17 08:43:24 --> Router Class Initialized
INFO - 2020-11-17 08:43:24 --> Output Class Initialized
INFO - 2020-11-17 08:43:24 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:24 --> Input Class Initialized
INFO - 2020-11-17 08:43:24 --> Language Class Initialized
INFO - 2020-11-17 08:43:24 --> Language Class Initialized
INFO - 2020-11-17 08:43:24 --> Config Class Initialized
INFO - 2020-11-17 08:43:24 --> Loader Class Initialized
INFO - 2020-11-17 08:43:24 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:24 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:24 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:24 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:24 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:24 --> Controller Class Initialized
DEBUG - 2020-11-17 08:43:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:43:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:43:24 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:24 --> Total execution time: 0.3097
INFO - 2020-11-17 08:43:29 --> Config Class Initialized
INFO - 2020-11-17 08:43:29 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:29 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:29 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:29 --> URI Class Initialized
INFO - 2020-11-17 08:43:29 --> Router Class Initialized
INFO - 2020-11-17 08:43:29 --> Output Class Initialized
INFO - 2020-11-17 08:43:29 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:29 --> Input Class Initialized
INFO - 2020-11-17 08:43:29 --> Language Class Initialized
INFO - 2020-11-17 08:43:29 --> Language Class Initialized
INFO - 2020-11-17 08:43:29 --> Config Class Initialized
INFO - 2020-11-17 08:43:29 --> Loader Class Initialized
INFO - 2020-11-17 08:43:29 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:29 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:29 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:29 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:29 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:29 --> Controller Class Initialized
INFO - 2020-11-17 08:43:29 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:43:29 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:29 --> Total execution time: 0.3851
INFO - 2020-11-17 08:43:30 --> Config Class Initialized
INFO - 2020-11-17 08:43:31 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:31 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:31 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:31 --> URI Class Initialized
INFO - 2020-11-17 08:43:31 --> Router Class Initialized
INFO - 2020-11-17 08:43:31 --> Output Class Initialized
INFO - 2020-11-17 08:43:31 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:31 --> Input Class Initialized
INFO - 2020-11-17 08:43:31 --> Language Class Initialized
INFO - 2020-11-17 08:43:31 --> Language Class Initialized
INFO - 2020-11-17 08:43:31 --> Config Class Initialized
INFO - 2020-11-17 08:43:31 --> Loader Class Initialized
INFO - 2020-11-17 08:43:31 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:31 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:31 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:31 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:31 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:31 --> Controller Class Initialized
DEBUG - 2020-11-17 08:43:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:43:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:43:31 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:31 --> Total execution time: 0.4318
INFO - 2020-11-17 08:43:40 --> Config Class Initialized
INFO - 2020-11-17 08:43:40 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:40 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:40 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:40 --> URI Class Initialized
INFO - 2020-11-17 08:43:40 --> Router Class Initialized
INFO - 2020-11-17 08:43:40 --> Output Class Initialized
INFO - 2020-11-17 08:43:40 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:40 --> Input Class Initialized
INFO - 2020-11-17 08:43:40 --> Language Class Initialized
INFO - 2020-11-17 08:43:40 --> Language Class Initialized
INFO - 2020-11-17 08:43:40 --> Config Class Initialized
INFO - 2020-11-17 08:43:40 --> Loader Class Initialized
INFO - 2020-11-17 08:43:40 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:40 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:40 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:40 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:40 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:40 --> Controller Class Initialized
INFO - 2020-11-17 08:43:40 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:43:40 --> Config Class Initialized
INFO - 2020-11-17 08:43:40 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:40 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:40 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:40 --> URI Class Initialized
INFO - 2020-11-17 08:43:40 --> Router Class Initialized
INFO - 2020-11-17 08:43:40 --> Output Class Initialized
INFO - 2020-11-17 08:43:40 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:40 --> Input Class Initialized
INFO - 2020-11-17 08:43:40 --> Language Class Initialized
INFO - 2020-11-17 08:43:40 --> Language Class Initialized
INFO - 2020-11-17 08:43:40 --> Config Class Initialized
INFO - 2020-11-17 08:43:40 --> Loader Class Initialized
INFO - 2020-11-17 08:43:40 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:40 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:40 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:40 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:40 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:40 --> Controller Class Initialized
DEBUG - 2020-11-17 08:43:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:43:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:43:40 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:40 --> Total execution time: 0.3088
INFO - 2020-11-17 08:43:47 --> Config Class Initialized
INFO - 2020-11-17 08:43:47 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:47 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:47 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:47 --> URI Class Initialized
INFO - 2020-11-17 08:43:47 --> Router Class Initialized
INFO - 2020-11-17 08:43:47 --> Output Class Initialized
INFO - 2020-11-17 08:43:47 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:47 --> Input Class Initialized
INFO - 2020-11-17 08:43:47 --> Language Class Initialized
INFO - 2020-11-17 08:43:47 --> Language Class Initialized
INFO - 2020-11-17 08:43:47 --> Config Class Initialized
INFO - 2020-11-17 08:43:47 --> Loader Class Initialized
INFO - 2020-11-17 08:43:47 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:47 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:47 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:47 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:47 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:48 --> Controller Class Initialized
INFO - 2020-11-17 08:43:48 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:48 --> Total execution time: 0.3554
INFO - 2020-11-17 08:43:52 --> Config Class Initialized
INFO - 2020-11-17 08:43:52 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:52 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:52 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:52 --> URI Class Initialized
INFO - 2020-11-17 08:43:52 --> Router Class Initialized
INFO - 2020-11-17 08:43:52 --> Output Class Initialized
INFO - 2020-11-17 08:43:52 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:52 --> Input Class Initialized
INFO - 2020-11-17 08:43:52 --> Language Class Initialized
INFO - 2020-11-17 08:43:52 --> Language Class Initialized
INFO - 2020-11-17 08:43:52 --> Config Class Initialized
INFO - 2020-11-17 08:43:52 --> Loader Class Initialized
INFO - 2020-11-17 08:43:52 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:52 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:52 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:52 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:52 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:52 --> Controller Class Initialized
INFO - 2020-11-17 08:43:52 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:43:52 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:52 --> Total execution time: 0.3720
INFO - 2020-11-17 08:43:53 --> Config Class Initialized
INFO - 2020-11-17 08:43:53 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:53 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:53 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:53 --> URI Class Initialized
INFO - 2020-11-17 08:43:53 --> Router Class Initialized
INFO - 2020-11-17 08:43:53 --> Output Class Initialized
INFO - 2020-11-17 08:43:53 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:53 --> Input Class Initialized
INFO - 2020-11-17 08:43:53 --> Language Class Initialized
INFO - 2020-11-17 08:43:53 --> Language Class Initialized
INFO - 2020-11-17 08:43:53 --> Config Class Initialized
INFO - 2020-11-17 08:43:53 --> Loader Class Initialized
INFO - 2020-11-17 08:43:53 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:53 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:53 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:53 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:53 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:53 --> Controller Class Initialized
DEBUG - 2020-11-17 08:43:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:43:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:43:53 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:53 --> Total execution time: 0.4123
INFO - 2020-11-17 08:43:55 --> Config Class Initialized
INFO - 2020-11-17 08:43:55 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:55 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:55 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:55 --> URI Class Initialized
INFO - 2020-11-17 08:43:55 --> Router Class Initialized
INFO - 2020-11-17 08:43:55 --> Output Class Initialized
INFO - 2020-11-17 08:43:55 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:55 --> Input Class Initialized
INFO - 2020-11-17 08:43:55 --> Language Class Initialized
INFO - 2020-11-17 08:43:55 --> Language Class Initialized
INFO - 2020-11-17 08:43:55 --> Config Class Initialized
INFO - 2020-11-17 08:43:55 --> Loader Class Initialized
INFO - 2020-11-17 08:43:55 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:55 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:55 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:55 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:55 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:55 --> Controller Class Initialized
DEBUG - 2020-11-17 08:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-11-17 08:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:43:55 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:55 --> Total execution time: 0.3541
INFO - 2020-11-17 08:43:55 --> Config Class Initialized
INFO - 2020-11-17 08:43:55 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:55 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:55 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:55 --> URI Class Initialized
INFO - 2020-11-17 08:43:55 --> Router Class Initialized
INFO - 2020-11-17 08:43:55 --> Output Class Initialized
INFO - 2020-11-17 08:43:55 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:55 --> Input Class Initialized
INFO - 2020-11-17 08:43:55 --> Language Class Initialized
INFO - 2020-11-17 08:43:55 --> Language Class Initialized
INFO - 2020-11-17 08:43:55 --> Config Class Initialized
INFO - 2020-11-17 08:43:55 --> Loader Class Initialized
INFO - 2020-11-17 08:43:55 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:55 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:55 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:55 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:55 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:55 --> Controller Class Initialized
INFO - 2020-11-17 08:43:59 --> Config Class Initialized
INFO - 2020-11-17 08:43:59 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:59 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:43:59 --> Utf8 Class Initialized
INFO - 2020-11-17 08:43:59 --> URI Class Initialized
INFO - 2020-11-17 08:43:59 --> Router Class Initialized
INFO - 2020-11-17 08:43:59 --> Output Class Initialized
INFO - 2020-11-17 08:43:59 --> Security Class Initialized
DEBUG - 2020-11-17 08:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:43:59 --> Input Class Initialized
INFO - 2020-11-17 08:43:59 --> Language Class Initialized
INFO - 2020-11-17 08:43:59 --> Language Class Initialized
INFO - 2020-11-17 08:43:59 --> Config Class Initialized
INFO - 2020-11-17 08:43:59 --> Loader Class Initialized
INFO - 2020-11-17 08:43:59 --> Helper loaded: url_helper
INFO - 2020-11-17 08:43:59 --> Helper loaded: file_helper
INFO - 2020-11-17 08:43:59 --> Helper loaded: form_helper
INFO - 2020-11-17 08:43:59 --> Helper loaded: my_helper
INFO - 2020-11-17 08:43:59 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:43:59 --> Controller Class Initialized
DEBUG - 2020-11-17 08:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-17 08:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:43:59 --> Final output sent to browser
DEBUG - 2020-11-17 08:43:59 --> Total execution time: 0.3714
INFO - 2020-11-17 08:43:59 --> Config Class Initialized
INFO - 2020-11-17 08:43:59 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:43:59 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:00 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:00 --> URI Class Initialized
INFO - 2020-11-17 08:44:00 --> Router Class Initialized
INFO - 2020-11-17 08:44:00 --> Output Class Initialized
INFO - 2020-11-17 08:44:00 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:00 --> Input Class Initialized
INFO - 2020-11-17 08:44:00 --> Language Class Initialized
INFO - 2020-11-17 08:44:00 --> Language Class Initialized
INFO - 2020-11-17 08:44:00 --> Config Class Initialized
INFO - 2020-11-17 08:44:00 --> Loader Class Initialized
INFO - 2020-11-17 08:44:00 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:00 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:00 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:00 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:00 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:00 --> Controller Class Initialized
INFO - 2020-11-17 08:44:05 --> Config Class Initialized
INFO - 2020-11-17 08:44:05 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:05 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:05 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:05 --> URI Class Initialized
INFO - 2020-11-17 08:44:05 --> Router Class Initialized
INFO - 2020-11-17 08:44:05 --> Output Class Initialized
INFO - 2020-11-17 08:44:05 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:05 --> Input Class Initialized
INFO - 2020-11-17 08:44:05 --> Language Class Initialized
INFO - 2020-11-17 08:44:05 --> Language Class Initialized
INFO - 2020-11-17 08:44:05 --> Config Class Initialized
INFO - 2020-11-17 08:44:05 --> Loader Class Initialized
INFO - 2020-11-17 08:44:05 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:05 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:05 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:05 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:05 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:05 --> Controller Class Initialized
INFO - 2020-11-17 08:44:05 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:05 --> Total execution time: 0.2946
INFO - 2020-11-17 08:44:05 --> Config Class Initialized
INFO - 2020-11-17 08:44:05 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:05 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:05 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:05 --> URI Class Initialized
INFO - 2020-11-17 08:44:05 --> Router Class Initialized
INFO - 2020-11-17 08:44:05 --> Output Class Initialized
INFO - 2020-11-17 08:44:05 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:05 --> Input Class Initialized
INFO - 2020-11-17 08:44:05 --> Language Class Initialized
INFO - 2020-11-17 08:44:05 --> Language Class Initialized
INFO - 2020-11-17 08:44:05 --> Config Class Initialized
INFO - 2020-11-17 08:44:05 --> Loader Class Initialized
INFO - 2020-11-17 08:44:05 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:05 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:05 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:05 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:05 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:06 --> Controller Class Initialized
INFO - 2020-11-17 08:44:13 --> Config Class Initialized
INFO - 2020-11-17 08:44:13 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:13 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:13 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:13 --> URI Class Initialized
INFO - 2020-11-17 08:44:13 --> Router Class Initialized
INFO - 2020-11-17 08:44:13 --> Output Class Initialized
INFO - 2020-11-17 08:44:13 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:13 --> Input Class Initialized
INFO - 2020-11-17 08:44:13 --> Language Class Initialized
INFO - 2020-11-17 08:44:13 --> Language Class Initialized
INFO - 2020-11-17 08:44:13 --> Config Class Initialized
INFO - 2020-11-17 08:44:13 --> Loader Class Initialized
INFO - 2020-11-17 08:44:13 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:13 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:13 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:13 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:13 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:14 --> Controller Class Initialized
INFO - 2020-11-17 08:44:14 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:44:14 --> Config Class Initialized
INFO - 2020-11-17 08:44:14 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:14 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:14 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:14 --> URI Class Initialized
INFO - 2020-11-17 08:44:14 --> Router Class Initialized
INFO - 2020-11-17 08:44:14 --> Output Class Initialized
INFO - 2020-11-17 08:44:14 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:14 --> Input Class Initialized
INFO - 2020-11-17 08:44:14 --> Language Class Initialized
INFO - 2020-11-17 08:44:14 --> Language Class Initialized
INFO - 2020-11-17 08:44:14 --> Config Class Initialized
INFO - 2020-11-17 08:44:14 --> Loader Class Initialized
INFO - 2020-11-17 08:44:14 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:14 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:14 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:14 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:14 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:14 --> Controller Class Initialized
DEBUG - 2020-11-17 08:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:44:14 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:14 --> Total execution time: 0.3087
INFO - 2020-11-17 08:44:19 --> Config Class Initialized
INFO - 2020-11-17 08:44:19 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:19 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:19 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:19 --> URI Class Initialized
INFO - 2020-11-17 08:44:19 --> Router Class Initialized
INFO - 2020-11-17 08:44:19 --> Output Class Initialized
INFO - 2020-11-17 08:44:19 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:19 --> Input Class Initialized
INFO - 2020-11-17 08:44:19 --> Language Class Initialized
INFO - 2020-11-17 08:44:19 --> Language Class Initialized
INFO - 2020-11-17 08:44:19 --> Config Class Initialized
INFO - 2020-11-17 08:44:20 --> Loader Class Initialized
INFO - 2020-11-17 08:44:20 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:20 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:20 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:20 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:20 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:20 --> Controller Class Initialized
INFO - 2020-11-17 08:44:20 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:44:20 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:20 --> Total execution time: 0.3623
INFO - 2020-11-17 08:44:20 --> Config Class Initialized
INFO - 2020-11-17 08:44:20 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:20 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:20 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:20 --> URI Class Initialized
INFO - 2020-11-17 08:44:20 --> Router Class Initialized
INFO - 2020-11-17 08:44:20 --> Output Class Initialized
INFO - 2020-11-17 08:44:20 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:20 --> Input Class Initialized
INFO - 2020-11-17 08:44:20 --> Language Class Initialized
INFO - 2020-11-17 08:44:20 --> Language Class Initialized
INFO - 2020-11-17 08:44:20 --> Config Class Initialized
INFO - 2020-11-17 08:44:20 --> Loader Class Initialized
INFO - 2020-11-17 08:44:20 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:20 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:20 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:20 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:20 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:20 --> Controller Class Initialized
DEBUG - 2020-11-17 08:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:44:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:44:21 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:21 --> Total execution time: 0.4049
INFO - 2020-11-17 08:44:22 --> Config Class Initialized
INFO - 2020-11-17 08:44:22 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:22 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:22 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:22 --> URI Class Initialized
INFO - 2020-11-17 08:44:22 --> Router Class Initialized
INFO - 2020-11-17 08:44:22 --> Output Class Initialized
INFO - 2020-11-17 08:44:22 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:23 --> Input Class Initialized
INFO - 2020-11-17 08:44:23 --> Language Class Initialized
INFO - 2020-11-17 08:44:23 --> Language Class Initialized
INFO - 2020-11-17 08:44:23 --> Config Class Initialized
INFO - 2020-11-17 08:44:23 --> Loader Class Initialized
INFO - 2020-11-17 08:44:23 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:23 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:23 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:23 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:23 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:23 --> Controller Class Initialized
INFO - 2020-11-17 08:44:23 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:44:23 --> Config Class Initialized
INFO - 2020-11-17 08:44:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:23 --> URI Class Initialized
INFO - 2020-11-17 08:44:23 --> Router Class Initialized
INFO - 2020-11-17 08:44:23 --> Output Class Initialized
INFO - 2020-11-17 08:44:23 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:23 --> Input Class Initialized
INFO - 2020-11-17 08:44:23 --> Language Class Initialized
INFO - 2020-11-17 08:44:23 --> Language Class Initialized
INFO - 2020-11-17 08:44:23 --> Config Class Initialized
INFO - 2020-11-17 08:44:23 --> Loader Class Initialized
INFO - 2020-11-17 08:44:23 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:23 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:23 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:23 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:23 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:23 --> Controller Class Initialized
DEBUG - 2020-11-17 08:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:44:23 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:23 --> Total execution time: 0.3095
INFO - 2020-11-17 08:44:31 --> Config Class Initialized
INFO - 2020-11-17 08:44:31 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:31 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:31 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:31 --> URI Class Initialized
INFO - 2020-11-17 08:44:31 --> Router Class Initialized
INFO - 2020-11-17 08:44:31 --> Output Class Initialized
INFO - 2020-11-17 08:44:31 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:31 --> Input Class Initialized
INFO - 2020-11-17 08:44:31 --> Language Class Initialized
INFO - 2020-11-17 08:44:31 --> Language Class Initialized
INFO - 2020-11-17 08:44:31 --> Config Class Initialized
INFO - 2020-11-17 08:44:31 --> Loader Class Initialized
INFO - 2020-11-17 08:44:31 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:31 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:31 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:31 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:31 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:31 --> Controller Class Initialized
INFO - 2020-11-17 08:44:31 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:44:31 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:31 --> Total execution time: 0.3864
INFO - 2020-11-17 08:44:32 --> Config Class Initialized
INFO - 2020-11-17 08:44:32 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:32 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:32 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:32 --> URI Class Initialized
INFO - 2020-11-17 08:44:32 --> Router Class Initialized
INFO - 2020-11-17 08:44:32 --> Output Class Initialized
INFO - 2020-11-17 08:44:32 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:32 --> Input Class Initialized
INFO - 2020-11-17 08:44:32 --> Language Class Initialized
INFO - 2020-11-17 08:44:32 --> Language Class Initialized
INFO - 2020-11-17 08:44:32 --> Config Class Initialized
INFO - 2020-11-17 08:44:32 --> Loader Class Initialized
INFO - 2020-11-17 08:44:32 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:32 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:32 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:32 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:32 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:32 --> Controller Class Initialized
DEBUG - 2020-11-17 08:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:44:33 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:33 --> Total execution time: 0.4243
INFO - 2020-11-17 08:44:38 --> Config Class Initialized
INFO - 2020-11-17 08:44:38 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:38 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:38 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:38 --> URI Class Initialized
INFO - 2020-11-17 08:44:38 --> Router Class Initialized
INFO - 2020-11-17 08:44:38 --> Output Class Initialized
INFO - 2020-11-17 08:44:38 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:38 --> Input Class Initialized
INFO - 2020-11-17 08:44:38 --> Language Class Initialized
INFO - 2020-11-17 08:44:38 --> Language Class Initialized
INFO - 2020-11-17 08:44:38 --> Config Class Initialized
INFO - 2020-11-17 08:44:38 --> Loader Class Initialized
INFO - 2020-11-17 08:44:38 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:39 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:39 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:39 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:39 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:39 --> Controller Class Initialized
DEBUG - 2020-11-17 08:44:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-17 08:44:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:44:39 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:39 --> Total execution time: 0.3396
INFO - 2020-11-17 08:44:39 --> Config Class Initialized
INFO - 2020-11-17 08:44:39 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:39 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:39 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:39 --> URI Class Initialized
INFO - 2020-11-17 08:44:39 --> Router Class Initialized
INFO - 2020-11-17 08:44:39 --> Output Class Initialized
INFO - 2020-11-17 08:44:39 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:39 --> Input Class Initialized
INFO - 2020-11-17 08:44:39 --> Language Class Initialized
INFO - 2020-11-17 08:44:39 --> Language Class Initialized
INFO - 2020-11-17 08:44:39 --> Config Class Initialized
INFO - 2020-11-17 08:44:39 --> Loader Class Initialized
INFO - 2020-11-17 08:44:39 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:39 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:39 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:39 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:39 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:39 --> Controller Class Initialized
INFO - 2020-11-17 08:44:42 --> Config Class Initialized
INFO - 2020-11-17 08:44:42 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:44:42 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:44:42 --> Utf8 Class Initialized
INFO - 2020-11-17 08:44:42 --> URI Class Initialized
INFO - 2020-11-17 08:44:42 --> Router Class Initialized
INFO - 2020-11-17 08:44:42 --> Output Class Initialized
INFO - 2020-11-17 08:44:43 --> Security Class Initialized
DEBUG - 2020-11-17 08:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:44:43 --> Input Class Initialized
INFO - 2020-11-17 08:44:43 --> Language Class Initialized
INFO - 2020-11-17 08:44:43 --> Language Class Initialized
INFO - 2020-11-17 08:44:43 --> Config Class Initialized
INFO - 2020-11-17 08:44:43 --> Loader Class Initialized
INFO - 2020-11-17 08:44:43 --> Helper loaded: url_helper
INFO - 2020-11-17 08:44:43 --> Helper loaded: file_helper
INFO - 2020-11-17 08:44:43 --> Helper loaded: form_helper
INFO - 2020-11-17 08:44:43 --> Helper loaded: my_helper
INFO - 2020-11-17 08:44:43 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:44:43 --> Controller Class Initialized
INFO - 2020-11-17 08:44:43 --> Final output sent to browser
DEBUG - 2020-11-17 08:44:43 --> Total execution time: 0.3755
INFO - 2020-11-17 08:45:04 --> Config Class Initialized
INFO - 2020-11-17 08:45:04 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:45:04 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:45:04 --> Utf8 Class Initialized
INFO - 2020-11-17 08:45:04 --> URI Class Initialized
INFO - 2020-11-17 08:45:04 --> Router Class Initialized
INFO - 2020-11-17 08:45:04 --> Output Class Initialized
INFO - 2020-11-17 08:45:04 --> Security Class Initialized
DEBUG - 2020-11-17 08:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:45:04 --> Input Class Initialized
INFO - 2020-11-17 08:45:04 --> Language Class Initialized
INFO - 2020-11-17 08:45:04 --> Language Class Initialized
INFO - 2020-11-17 08:45:04 --> Config Class Initialized
INFO - 2020-11-17 08:45:04 --> Loader Class Initialized
INFO - 2020-11-17 08:45:04 --> Helper loaded: url_helper
INFO - 2020-11-17 08:45:04 --> Helper loaded: file_helper
INFO - 2020-11-17 08:45:04 --> Helper loaded: form_helper
INFO - 2020-11-17 08:45:05 --> Helper loaded: my_helper
INFO - 2020-11-17 08:45:05 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:45:05 --> Controller Class Initialized
INFO - 2020-11-17 08:45:05 --> Final output sent to browser
DEBUG - 2020-11-17 08:45:05 --> Total execution time: 0.3594
INFO - 2020-11-17 08:45:05 --> Config Class Initialized
INFO - 2020-11-17 08:45:05 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:45:05 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:45:05 --> Utf8 Class Initialized
INFO - 2020-11-17 08:45:05 --> URI Class Initialized
INFO - 2020-11-17 08:45:05 --> Router Class Initialized
INFO - 2020-11-17 08:45:05 --> Output Class Initialized
INFO - 2020-11-17 08:45:05 --> Security Class Initialized
DEBUG - 2020-11-17 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:45:05 --> Input Class Initialized
INFO - 2020-11-17 08:45:05 --> Language Class Initialized
INFO - 2020-11-17 08:45:05 --> Language Class Initialized
INFO - 2020-11-17 08:45:05 --> Config Class Initialized
INFO - 2020-11-17 08:45:05 --> Loader Class Initialized
INFO - 2020-11-17 08:45:05 --> Helper loaded: url_helper
INFO - 2020-11-17 08:45:05 --> Helper loaded: file_helper
INFO - 2020-11-17 08:45:05 --> Helper loaded: form_helper
INFO - 2020-11-17 08:45:05 --> Helper loaded: my_helper
INFO - 2020-11-17 08:45:05 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:45:05 --> Controller Class Initialized
INFO - 2020-11-17 08:45:10 --> Config Class Initialized
INFO - 2020-11-17 08:45:10 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:45:10 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:45:11 --> Utf8 Class Initialized
INFO - 2020-11-17 08:45:11 --> URI Class Initialized
INFO - 2020-11-17 08:45:11 --> Router Class Initialized
INFO - 2020-11-17 08:45:11 --> Output Class Initialized
INFO - 2020-11-17 08:45:11 --> Security Class Initialized
DEBUG - 2020-11-17 08:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:45:11 --> Input Class Initialized
INFO - 2020-11-17 08:45:11 --> Language Class Initialized
INFO - 2020-11-17 08:45:11 --> Language Class Initialized
INFO - 2020-11-17 08:45:11 --> Config Class Initialized
INFO - 2020-11-17 08:45:11 --> Loader Class Initialized
INFO - 2020-11-17 08:45:11 --> Helper loaded: url_helper
INFO - 2020-11-17 08:45:11 --> Helper loaded: file_helper
INFO - 2020-11-17 08:45:11 --> Helper loaded: form_helper
INFO - 2020-11-17 08:45:11 --> Helper loaded: my_helper
INFO - 2020-11-17 08:45:11 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:45:11 --> Controller Class Initialized
INFO - 2020-11-17 08:45:11 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:45:11 --> Config Class Initialized
INFO - 2020-11-17 08:45:11 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:45:11 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:45:11 --> Utf8 Class Initialized
INFO - 2020-11-17 08:45:11 --> URI Class Initialized
INFO - 2020-11-17 08:45:11 --> Router Class Initialized
INFO - 2020-11-17 08:45:11 --> Output Class Initialized
INFO - 2020-11-17 08:45:11 --> Security Class Initialized
DEBUG - 2020-11-17 08:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:45:11 --> Input Class Initialized
INFO - 2020-11-17 08:45:11 --> Language Class Initialized
INFO - 2020-11-17 08:45:11 --> Language Class Initialized
INFO - 2020-11-17 08:45:11 --> Config Class Initialized
INFO - 2020-11-17 08:45:11 --> Loader Class Initialized
INFO - 2020-11-17 08:45:11 --> Helper loaded: url_helper
INFO - 2020-11-17 08:45:11 --> Helper loaded: file_helper
INFO - 2020-11-17 08:45:11 --> Helper loaded: form_helper
INFO - 2020-11-17 08:45:11 --> Helper loaded: my_helper
INFO - 2020-11-17 08:45:11 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:45:11 --> Controller Class Initialized
DEBUG - 2020-11-17 08:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:45:11 --> Final output sent to browser
DEBUG - 2020-11-17 08:45:11 --> Total execution time: 0.3206
INFO - 2020-11-17 08:45:17 --> Config Class Initialized
INFO - 2020-11-17 08:45:17 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:45:17 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:45:17 --> Utf8 Class Initialized
INFO - 2020-11-17 08:45:17 --> URI Class Initialized
INFO - 2020-11-17 08:45:17 --> Router Class Initialized
INFO - 2020-11-17 08:45:17 --> Output Class Initialized
INFO - 2020-11-17 08:45:17 --> Security Class Initialized
DEBUG - 2020-11-17 08:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:45:17 --> Input Class Initialized
INFO - 2020-11-17 08:45:17 --> Language Class Initialized
INFO - 2020-11-17 08:45:17 --> Language Class Initialized
INFO - 2020-11-17 08:45:17 --> Config Class Initialized
INFO - 2020-11-17 08:45:17 --> Loader Class Initialized
INFO - 2020-11-17 08:45:17 --> Helper loaded: url_helper
INFO - 2020-11-17 08:45:17 --> Helper loaded: file_helper
INFO - 2020-11-17 08:45:17 --> Helper loaded: form_helper
INFO - 2020-11-17 08:45:17 --> Helper loaded: my_helper
INFO - 2020-11-17 08:45:17 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:45:18 --> Controller Class Initialized
INFO - 2020-11-17 08:45:18 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:45:18 --> Final output sent to browser
DEBUG - 2020-11-17 08:45:18 --> Total execution time: 0.3786
INFO - 2020-11-17 08:45:18 --> Config Class Initialized
INFO - 2020-11-17 08:45:18 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:45:18 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:45:18 --> Utf8 Class Initialized
INFO - 2020-11-17 08:45:18 --> URI Class Initialized
INFO - 2020-11-17 08:45:18 --> Router Class Initialized
INFO - 2020-11-17 08:45:18 --> Output Class Initialized
INFO - 2020-11-17 08:45:18 --> Security Class Initialized
DEBUG - 2020-11-17 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:45:18 --> Input Class Initialized
INFO - 2020-11-17 08:45:18 --> Language Class Initialized
INFO - 2020-11-17 08:45:18 --> Language Class Initialized
INFO - 2020-11-17 08:45:18 --> Config Class Initialized
INFO - 2020-11-17 08:45:18 --> Loader Class Initialized
INFO - 2020-11-17 08:45:18 --> Helper loaded: url_helper
INFO - 2020-11-17 08:45:18 --> Helper loaded: file_helper
INFO - 2020-11-17 08:45:18 --> Helper loaded: form_helper
INFO - 2020-11-17 08:45:18 --> Helper loaded: my_helper
INFO - 2020-11-17 08:45:18 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:45:18 --> Controller Class Initialized
DEBUG - 2020-11-17 08:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:45:18 --> Final output sent to browser
DEBUG - 2020-11-17 08:45:18 --> Total execution time: 0.4192
INFO - 2020-11-17 08:45:21 --> Config Class Initialized
INFO - 2020-11-17 08:45:21 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:45:21 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:45:21 --> Utf8 Class Initialized
INFO - 2020-11-17 08:45:21 --> URI Class Initialized
INFO - 2020-11-17 08:45:21 --> Router Class Initialized
INFO - 2020-11-17 08:45:21 --> Output Class Initialized
INFO - 2020-11-17 08:45:21 --> Security Class Initialized
DEBUG - 2020-11-17 08:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:45:21 --> Input Class Initialized
INFO - 2020-11-17 08:45:21 --> Language Class Initialized
INFO - 2020-11-17 08:45:21 --> Language Class Initialized
INFO - 2020-11-17 08:45:21 --> Config Class Initialized
INFO - 2020-11-17 08:45:21 --> Loader Class Initialized
INFO - 2020-11-17 08:45:21 --> Helper loaded: url_helper
INFO - 2020-11-17 08:45:21 --> Helper loaded: file_helper
INFO - 2020-11-17 08:45:21 --> Helper loaded: form_helper
INFO - 2020-11-17 08:45:21 --> Helper loaded: my_helper
INFO - 2020-11-17 08:45:21 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:45:21 --> Controller Class Initialized
DEBUG - 2020-11-17 08:45:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-17 08:45:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:45:21 --> Final output sent to browser
DEBUG - 2020-11-17 08:45:21 --> Total execution time: 0.3618
INFO - 2020-11-17 08:45:22 --> Config Class Initialized
INFO - 2020-11-17 08:45:22 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:45:22 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:45:22 --> Utf8 Class Initialized
INFO - 2020-11-17 08:45:22 --> URI Class Initialized
INFO - 2020-11-17 08:45:22 --> Router Class Initialized
INFO - 2020-11-17 08:45:22 --> Output Class Initialized
INFO - 2020-11-17 08:45:22 --> Security Class Initialized
DEBUG - 2020-11-17 08:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:45:22 --> Input Class Initialized
INFO - 2020-11-17 08:45:23 --> Language Class Initialized
INFO - 2020-11-17 08:45:23 --> Language Class Initialized
INFO - 2020-11-17 08:45:23 --> Config Class Initialized
INFO - 2020-11-17 08:45:23 --> Loader Class Initialized
INFO - 2020-11-17 08:45:23 --> Helper loaded: url_helper
INFO - 2020-11-17 08:45:23 --> Helper loaded: file_helper
INFO - 2020-11-17 08:45:23 --> Helper loaded: form_helper
INFO - 2020-11-17 08:45:23 --> Helper loaded: my_helper
INFO - 2020-11-17 08:45:23 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:45:23 --> Controller Class Initialized
DEBUG - 2020-11-17 08:45:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-17 08:45:23 --> Final output sent to browser
DEBUG - 2020-11-17 08:45:23 --> Total execution time: 0.3465
INFO - 2020-11-17 08:46:06 --> Config Class Initialized
INFO - 2020-11-17 08:46:06 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:06 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:06 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:06 --> URI Class Initialized
INFO - 2020-11-17 08:46:06 --> Router Class Initialized
INFO - 2020-11-17 08:46:06 --> Output Class Initialized
INFO - 2020-11-17 08:46:06 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:06 --> Input Class Initialized
INFO - 2020-11-17 08:46:06 --> Language Class Initialized
INFO - 2020-11-17 08:46:06 --> Language Class Initialized
INFO - 2020-11-17 08:46:06 --> Config Class Initialized
INFO - 2020-11-17 08:46:06 --> Loader Class Initialized
INFO - 2020-11-17 08:46:06 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:06 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:06 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:06 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:06 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:06 --> Controller Class Initialized
INFO - 2020-11-17 08:46:06 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:46:06 --> Config Class Initialized
INFO - 2020-11-17 08:46:07 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:07 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:07 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:07 --> URI Class Initialized
INFO - 2020-11-17 08:46:07 --> Router Class Initialized
INFO - 2020-11-17 08:46:07 --> Output Class Initialized
INFO - 2020-11-17 08:46:07 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:07 --> Input Class Initialized
INFO - 2020-11-17 08:46:07 --> Language Class Initialized
INFO - 2020-11-17 08:46:07 --> Language Class Initialized
INFO - 2020-11-17 08:46:07 --> Config Class Initialized
INFO - 2020-11-17 08:46:07 --> Loader Class Initialized
INFO - 2020-11-17 08:46:07 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:07 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:07 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:07 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:07 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:07 --> Controller Class Initialized
DEBUG - 2020-11-17 08:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:46:07 --> Final output sent to browser
DEBUG - 2020-11-17 08:46:07 --> Total execution time: 0.3330
INFO - 2020-11-17 08:46:42 --> Config Class Initialized
INFO - 2020-11-17 08:46:42 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:42 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:42 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:42 --> URI Class Initialized
INFO - 2020-11-17 08:46:42 --> Router Class Initialized
INFO - 2020-11-17 08:46:42 --> Output Class Initialized
INFO - 2020-11-17 08:46:42 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:42 --> Input Class Initialized
INFO - 2020-11-17 08:46:42 --> Language Class Initialized
INFO - 2020-11-17 08:46:42 --> Language Class Initialized
INFO - 2020-11-17 08:46:42 --> Config Class Initialized
INFO - 2020-11-17 08:46:42 --> Loader Class Initialized
INFO - 2020-11-17 08:46:42 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:42 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:42 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:42 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:42 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:42 --> Controller Class Initialized
INFO - 2020-11-17 08:46:42 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:46:42 --> Final output sent to browser
DEBUG - 2020-11-17 08:46:42 --> Total execution time: 0.3802
INFO - 2020-11-17 08:46:43 --> Config Class Initialized
INFO - 2020-11-17 08:46:43 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:43 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:43 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:43 --> URI Class Initialized
INFO - 2020-11-17 08:46:43 --> Router Class Initialized
INFO - 2020-11-17 08:46:43 --> Output Class Initialized
INFO - 2020-11-17 08:46:43 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:43 --> Input Class Initialized
INFO - 2020-11-17 08:46:43 --> Language Class Initialized
INFO - 2020-11-17 08:46:43 --> Language Class Initialized
INFO - 2020-11-17 08:46:43 --> Config Class Initialized
INFO - 2020-11-17 08:46:43 --> Loader Class Initialized
INFO - 2020-11-17 08:46:43 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:43 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:43 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:43 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:43 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:43 --> Controller Class Initialized
DEBUG - 2020-11-17 08:46:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:46:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:46:43 --> Final output sent to browser
DEBUG - 2020-11-17 08:46:43 --> Total execution time: 0.4519
INFO - 2020-11-17 08:46:45 --> Config Class Initialized
INFO - 2020-11-17 08:46:45 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:45 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:45 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:45 --> URI Class Initialized
INFO - 2020-11-17 08:46:45 --> Router Class Initialized
INFO - 2020-11-17 08:46:45 --> Output Class Initialized
INFO - 2020-11-17 08:46:45 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:45 --> Input Class Initialized
INFO - 2020-11-17 08:46:45 --> Language Class Initialized
INFO - 2020-11-17 08:46:45 --> Language Class Initialized
INFO - 2020-11-17 08:46:45 --> Config Class Initialized
INFO - 2020-11-17 08:46:45 --> Loader Class Initialized
INFO - 2020-11-17 08:46:45 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:45 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:45 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:45 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:45 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:45 --> Controller Class Initialized
DEBUG - 2020-11-17 08:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-17 08:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:46:45 --> Final output sent to browser
DEBUG - 2020-11-17 08:46:45 --> Total execution time: 0.3553
INFO - 2020-11-17 08:46:45 --> Config Class Initialized
INFO - 2020-11-17 08:46:45 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:45 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:45 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:45 --> URI Class Initialized
INFO - 2020-11-17 08:46:45 --> Router Class Initialized
INFO - 2020-11-17 08:46:45 --> Output Class Initialized
INFO - 2020-11-17 08:46:45 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:45 --> Input Class Initialized
INFO - 2020-11-17 08:46:45 --> Language Class Initialized
INFO - 2020-11-17 08:46:46 --> Language Class Initialized
INFO - 2020-11-17 08:46:46 --> Config Class Initialized
INFO - 2020-11-17 08:46:46 --> Loader Class Initialized
INFO - 2020-11-17 08:46:46 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:46 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:46 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:46 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:46 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:46 --> Controller Class Initialized
INFO - 2020-11-17 08:46:47 --> Config Class Initialized
INFO - 2020-11-17 08:46:47 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:47 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:48 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:48 --> URI Class Initialized
INFO - 2020-11-17 08:46:48 --> Router Class Initialized
INFO - 2020-11-17 08:46:48 --> Output Class Initialized
INFO - 2020-11-17 08:46:48 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:48 --> Input Class Initialized
INFO - 2020-11-17 08:46:48 --> Language Class Initialized
INFO - 2020-11-17 08:46:48 --> Language Class Initialized
INFO - 2020-11-17 08:46:48 --> Config Class Initialized
INFO - 2020-11-17 08:46:48 --> Loader Class Initialized
INFO - 2020-11-17 08:46:48 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:48 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:48 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:48 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:48 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:48 --> Controller Class Initialized
INFO - 2020-11-17 08:46:48 --> Final output sent to browser
DEBUG - 2020-11-17 08:46:48 --> Total execution time: 0.3795
INFO - 2020-11-17 08:46:50 --> Config Class Initialized
INFO - 2020-11-17 08:46:50 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:50 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:50 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:50 --> URI Class Initialized
INFO - 2020-11-17 08:46:50 --> Router Class Initialized
INFO - 2020-11-17 08:46:50 --> Output Class Initialized
INFO - 2020-11-17 08:46:50 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:50 --> Input Class Initialized
INFO - 2020-11-17 08:46:50 --> Language Class Initialized
INFO - 2020-11-17 08:46:50 --> Language Class Initialized
INFO - 2020-11-17 08:46:50 --> Config Class Initialized
INFO - 2020-11-17 08:46:50 --> Loader Class Initialized
INFO - 2020-11-17 08:46:50 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:50 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:50 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:50 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:50 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:50 --> Controller Class Initialized
INFO - 2020-11-17 08:46:50 --> Final output sent to browser
DEBUG - 2020-11-17 08:46:50 --> Total execution time: 0.3655
INFO - 2020-11-17 08:46:50 --> Config Class Initialized
INFO - 2020-11-17 08:46:50 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:50 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:50 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:50 --> URI Class Initialized
INFO - 2020-11-17 08:46:50 --> Router Class Initialized
INFO - 2020-11-17 08:46:50 --> Output Class Initialized
INFO - 2020-11-17 08:46:50 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:50 --> Input Class Initialized
INFO - 2020-11-17 08:46:50 --> Language Class Initialized
INFO - 2020-11-17 08:46:50 --> Language Class Initialized
INFO - 2020-11-17 08:46:50 --> Config Class Initialized
INFO - 2020-11-17 08:46:50 --> Loader Class Initialized
INFO - 2020-11-17 08:46:50 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:50 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:50 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:51 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:51 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:51 --> Controller Class Initialized
INFO - 2020-11-17 08:46:54 --> Config Class Initialized
INFO - 2020-11-17 08:46:54 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:46:54 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:46:54 --> Utf8 Class Initialized
INFO - 2020-11-17 08:46:54 --> URI Class Initialized
INFO - 2020-11-17 08:46:54 --> Router Class Initialized
INFO - 2020-11-17 08:46:54 --> Output Class Initialized
INFO - 2020-11-17 08:46:54 --> Security Class Initialized
DEBUG - 2020-11-17 08:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:46:54 --> Input Class Initialized
INFO - 2020-11-17 08:46:54 --> Language Class Initialized
INFO - 2020-11-17 08:46:54 --> Language Class Initialized
INFO - 2020-11-17 08:46:54 --> Config Class Initialized
INFO - 2020-11-17 08:46:54 --> Loader Class Initialized
INFO - 2020-11-17 08:46:54 --> Helper loaded: url_helper
INFO - 2020-11-17 08:46:54 --> Helper loaded: file_helper
INFO - 2020-11-17 08:46:54 --> Helper loaded: form_helper
INFO - 2020-11-17 08:46:54 --> Helper loaded: my_helper
INFO - 2020-11-17 08:46:54 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:46:54 --> Controller Class Initialized
INFO - 2020-11-17 08:46:54 --> Final output sent to browser
DEBUG - 2020-11-17 08:46:54 --> Total execution time: 0.3645
INFO - 2020-11-17 08:47:02 --> Config Class Initialized
INFO - 2020-11-17 08:47:03 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:47:03 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:47:03 --> Utf8 Class Initialized
INFO - 2020-11-17 08:47:03 --> URI Class Initialized
INFO - 2020-11-17 08:47:03 --> Router Class Initialized
INFO - 2020-11-17 08:47:03 --> Output Class Initialized
INFO - 2020-11-17 08:47:03 --> Security Class Initialized
DEBUG - 2020-11-17 08:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:47:03 --> Input Class Initialized
INFO - 2020-11-17 08:47:03 --> Language Class Initialized
INFO - 2020-11-17 08:47:03 --> Language Class Initialized
INFO - 2020-11-17 08:47:03 --> Config Class Initialized
INFO - 2020-11-17 08:47:03 --> Loader Class Initialized
INFO - 2020-11-17 08:47:03 --> Helper loaded: url_helper
INFO - 2020-11-17 08:47:03 --> Helper loaded: file_helper
INFO - 2020-11-17 08:47:03 --> Helper loaded: form_helper
INFO - 2020-11-17 08:47:03 --> Helper loaded: my_helper
INFO - 2020-11-17 08:47:03 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:47:03 --> Controller Class Initialized
INFO - 2020-11-17 08:47:03 --> Final output sent to browser
DEBUG - 2020-11-17 08:47:03 --> Total execution time: 0.3634
INFO - 2020-11-17 08:47:03 --> Config Class Initialized
INFO - 2020-11-17 08:47:03 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:47:03 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:47:03 --> Utf8 Class Initialized
INFO - 2020-11-17 08:47:03 --> URI Class Initialized
INFO - 2020-11-17 08:47:03 --> Router Class Initialized
INFO - 2020-11-17 08:47:03 --> Output Class Initialized
INFO - 2020-11-17 08:47:03 --> Security Class Initialized
DEBUG - 2020-11-17 08:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:47:03 --> Input Class Initialized
INFO - 2020-11-17 08:47:03 --> Language Class Initialized
INFO - 2020-11-17 08:47:03 --> Language Class Initialized
INFO - 2020-11-17 08:47:03 --> Config Class Initialized
INFO - 2020-11-17 08:47:03 --> Loader Class Initialized
INFO - 2020-11-17 08:47:03 --> Helper loaded: url_helper
INFO - 2020-11-17 08:47:03 --> Helper loaded: file_helper
INFO - 2020-11-17 08:47:03 --> Helper loaded: form_helper
INFO - 2020-11-17 08:47:03 --> Helper loaded: my_helper
INFO - 2020-11-17 08:47:03 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:47:03 --> Controller Class Initialized
INFO - 2020-11-17 08:47:11 --> Config Class Initialized
INFO - 2020-11-17 08:47:11 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:47:11 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:47:11 --> Utf8 Class Initialized
INFO - 2020-11-17 08:47:11 --> URI Class Initialized
INFO - 2020-11-17 08:47:11 --> Router Class Initialized
INFO - 2020-11-17 08:47:11 --> Output Class Initialized
INFO - 2020-11-17 08:47:11 --> Security Class Initialized
DEBUG - 2020-11-17 08:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:47:11 --> Input Class Initialized
INFO - 2020-11-17 08:47:11 --> Language Class Initialized
INFO - 2020-11-17 08:47:11 --> Language Class Initialized
INFO - 2020-11-17 08:47:11 --> Config Class Initialized
INFO - 2020-11-17 08:47:11 --> Loader Class Initialized
INFO - 2020-11-17 08:47:11 --> Helper loaded: url_helper
INFO - 2020-11-17 08:47:11 --> Helper loaded: file_helper
INFO - 2020-11-17 08:47:11 --> Helper loaded: form_helper
INFO - 2020-11-17 08:47:11 --> Helper loaded: my_helper
INFO - 2020-11-17 08:47:11 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:47:11 --> Controller Class Initialized
INFO - 2020-11-17 08:47:11 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:47:12 --> Config Class Initialized
INFO - 2020-11-17 08:47:12 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:47:12 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:47:12 --> Utf8 Class Initialized
INFO - 2020-11-17 08:47:12 --> URI Class Initialized
INFO - 2020-11-17 08:47:12 --> Router Class Initialized
INFO - 2020-11-17 08:47:12 --> Output Class Initialized
INFO - 2020-11-17 08:47:12 --> Security Class Initialized
DEBUG - 2020-11-17 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:47:12 --> Input Class Initialized
INFO - 2020-11-17 08:47:12 --> Language Class Initialized
INFO - 2020-11-17 08:47:12 --> Language Class Initialized
INFO - 2020-11-17 08:47:12 --> Config Class Initialized
INFO - 2020-11-17 08:47:12 --> Loader Class Initialized
INFO - 2020-11-17 08:47:12 --> Helper loaded: url_helper
INFO - 2020-11-17 08:47:12 --> Helper loaded: file_helper
INFO - 2020-11-17 08:47:12 --> Helper loaded: form_helper
INFO - 2020-11-17 08:47:12 --> Helper loaded: my_helper
INFO - 2020-11-17 08:47:12 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:47:12 --> Controller Class Initialized
DEBUG - 2020-11-17 08:47:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-17 08:47:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:47:12 --> Final output sent to browser
DEBUG - 2020-11-17 08:47:12 --> Total execution time: 0.3353
INFO - 2020-11-17 08:47:20 --> Config Class Initialized
INFO - 2020-11-17 08:47:20 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:47:20 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:47:20 --> Utf8 Class Initialized
INFO - 2020-11-17 08:47:20 --> URI Class Initialized
INFO - 2020-11-17 08:47:20 --> Router Class Initialized
INFO - 2020-11-17 08:47:20 --> Output Class Initialized
INFO - 2020-11-17 08:47:20 --> Security Class Initialized
DEBUG - 2020-11-17 08:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:47:20 --> Input Class Initialized
INFO - 2020-11-17 08:47:20 --> Language Class Initialized
INFO - 2020-11-17 08:47:20 --> Language Class Initialized
INFO - 2020-11-17 08:47:20 --> Config Class Initialized
INFO - 2020-11-17 08:47:20 --> Loader Class Initialized
INFO - 2020-11-17 08:47:20 --> Helper loaded: url_helper
INFO - 2020-11-17 08:47:20 --> Helper loaded: file_helper
INFO - 2020-11-17 08:47:20 --> Helper loaded: form_helper
INFO - 2020-11-17 08:47:20 --> Helper loaded: my_helper
INFO - 2020-11-17 08:47:20 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:47:20 --> Controller Class Initialized
INFO - 2020-11-17 08:47:20 --> Helper loaded: cookie_helper
INFO - 2020-11-17 08:47:20 --> Final output sent to browser
DEBUG - 2020-11-17 08:47:20 --> Total execution time: 0.4028
INFO - 2020-11-17 08:47:23 --> Config Class Initialized
INFO - 2020-11-17 08:47:23 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:47:23 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:47:23 --> Utf8 Class Initialized
INFO - 2020-11-17 08:47:23 --> URI Class Initialized
INFO - 2020-11-17 08:47:23 --> Router Class Initialized
INFO - 2020-11-17 08:47:23 --> Output Class Initialized
INFO - 2020-11-17 08:47:23 --> Security Class Initialized
DEBUG - 2020-11-17 08:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:47:23 --> Input Class Initialized
INFO - 2020-11-17 08:47:23 --> Language Class Initialized
INFO - 2020-11-17 08:47:23 --> Language Class Initialized
INFO - 2020-11-17 08:47:23 --> Config Class Initialized
INFO - 2020-11-17 08:47:23 --> Loader Class Initialized
INFO - 2020-11-17 08:47:23 --> Helper loaded: url_helper
INFO - 2020-11-17 08:47:23 --> Helper loaded: file_helper
INFO - 2020-11-17 08:47:23 --> Helper loaded: form_helper
INFO - 2020-11-17 08:47:23 --> Helper loaded: my_helper
INFO - 2020-11-17 08:47:23 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:47:23 --> Controller Class Initialized
DEBUG - 2020-11-17 08:47:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-17 08:47:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:47:23 --> Final output sent to browser
DEBUG - 2020-11-17 08:47:23 --> Total execution time: 0.4339
INFO - 2020-11-17 08:47:35 --> Config Class Initialized
INFO - 2020-11-17 08:47:35 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:47:35 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:47:35 --> Utf8 Class Initialized
INFO - 2020-11-17 08:47:35 --> URI Class Initialized
INFO - 2020-11-17 08:47:35 --> Router Class Initialized
INFO - 2020-11-17 08:47:35 --> Output Class Initialized
INFO - 2020-11-17 08:47:35 --> Security Class Initialized
DEBUG - 2020-11-17 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:47:35 --> Input Class Initialized
INFO - 2020-11-17 08:47:35 --> Language Class Initialized
INFO - 2020-11-17 08:47:35 --> Language Class Initialized
INFO - 2020-11-17 08:47:35 --> Config Class Initialized
INFO - 2020-11-17 08:47:35 --> Loader Class Initialized
INFO - 2020-11-17 08:47:35 --> Helper loaded: url_helper
INFO - 2020-11-17 08:47:35 --> Helper loaded: file_helper
INFO - 2020-11-17 08:47:35 --> Helper loaded: form_helper
INFO - 2020-11-17 08:47:35 --> Helper loaded: my_helper
INFO - 2020-11-17 08:47:35 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:47:35 --> Controller Class Initialized
DEBUG - 2020-11-17 08:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 08:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:47:35 --> Final output sent to browser
DEBUG - 2020-11-17 08:47:35 --> Total execution time: 0.3648
INFO - 2020-11-17 08:48:00 --> Config Class Initialized
INFO - 2020-11-17 08:48:00 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:48:00 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:48:00 --> Utf8 Class Initialized
INFO - 2020-11-17 08:48:00 --> URI Class Initialized
INFO - 2020-11-17 08:48:00 --> Router Class Initialized
INFO - 2020-11-17 08:48:00 --> Output Class Initialized
INFO - 2020-11-17 08:48:00 --> Security Class Initialized
DEBUG - 2020-11-17 08:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:48:00 --> Input Class Initialized
INFO - 2020-11-17 08:48:00 --> Language Class Initialized
INFO - 2020-11-17 08:48:00 --> Language Class Initialized
INFO - 2020-11-17 08:48:00 --> Config Class Initialized
INFO - 2020-11-17 08:48:00 --> Loader Class Initialized
INFO - 2020-11-17 08:48:00 --> Helper loaded: url_helper
INFO - 2020-11-17 08:48:00 --> Helper loaded: file_helper
INFO - 2020-11-17 08:48:00 --> Helper loaded: form_helper
INFO - 2020-11-17 08:48:00 --> Helper loaded: my_helper
INFO - 2020-11-17 08:48:00 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:48:00 --> Controller Class Initialized
DEBUG - 2020-11-17 08:48:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-17 08:48:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 08:48:00 --> Final output sent to browser
DEBUG - 2020-11-17 08:48:00 --> Total execution time: 0.3282
INFO - 2020-11-17 08:48:01 --> Config Class Initialized
INFO - 2020-11-17 08:48:01 --> Hooks Class Initialized
DEBUG - 2020-11-17 08:48:01 --> UTF-8 Support Enabled
INFO - 2020-11-17 08:48:01 --> Utf8 Class Initialized
INFO - 2020-11-17 08:48:01 --> URI Class Initialized
INFO - 2020-11-17 08:48:01 --> Router Class Initialized
INFO - 2020-11-17 08:48:01 --> Output Class Initialized
INFO - 2020-11-17 08:48:01 --> Security Class Initialized
DEBUG - 2020-11-17 08:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 08:48:01 --> Input Class Initialized
INFO - 2020-11-17 08:48:01 --> Language Class Initialized
INFO - 2020-11-17 08:48:01 --> Language Class Initialized
INFO - 2020-11-17 08:48:01 --> Config Class Initialized
INFO - 2020-11-17 08:48:01 --> Loader Class Initialized
INFO - 2020-11-17 08:48:01 --> Helper loaded: url_helper
INFO - 2020-11-17 08:48:02 --> Helper loaded: file_helper
INFO - 2020-11-17 08:48:02 --> Helper loaded: form_helper
INFO - 2020-11-17 08:48:02 --> Helper loaded: my_helper
INFO - 2020-11-17 08:48:02 --> Database Driver Class Initialized
DEBUG - 2020-11-17 08:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 08:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 08:48:02 --> Controller Class Initialized
INFO - 2020-11-17 08:48:02 --> Final output sent to browser
DEBUG - 2020-11-17 08:48:02 --> Total execution time: 0.2948
INFO - 2020-11-17 09:05:17 --> Config Class Initialized
INFO - 2020-11-17 09:05:17 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:05:17 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:05:17 --> Utf8 Class Initialized
INFO - 2020-11-17 09:05:17 --> URI Class Initialized
INFO - 2020-11-17 09:05:17 --> Router Class Initialized
INFO - 2020-11-17 09:05:17 --> Output Class Initialized
INFO - 2020-11-17 09:05:17 --> Security Class Initialized
DEBUG - 2020-11-17 09:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:05:17 --> Input Class Initialized
INFO - 2020-11-17 09:05:17 --> Language Class Initialized
INFO - 2020-11-17 09:05:17 --> Language Class Initialized
INFO - 2020-11-17 09:05:17 --> Config Class Initialized
INFO - 2020-11-17 09:05:17 --> Loader Class Initialized
INFO - 2020-11-17 09:05:17 --> Helper loaded: url_helper
INFO - 2020-11-17 09:05:17 --> Helper loaded: file_helper
INFO - 2020-11-17 09:05:17 --> Helper loaded: form_helper
INFO - 2020-11-17 09:05:17 --> Helper loaded: my_helper
INFO - 2020-11-17 09:05:17 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:05:18 --> Controller Class Initialized
DEBUG - 2020-11-17 09:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-17 09:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 09:05:18 --> Final output sent to browser
DEBUG - 2020-11-17 09:05:18 --> Total execution time: 0.3340
INFO - 2020-11-17 09:07:53 --> Config Class Initialized
INFO - 2020-11-17 09:07:53 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:07:53 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:07:53 --> Utf8 Class Initialized
INFO - 2020-11-17 09:07:53 --> URI Class Initialized
INFO - 2020-11-17 09:07:53 --> Router Class Initialized
INFO - 2020-11-17 09:07:53 --> Output Class Initialized
INFO - 2020-11-17 09:07:53 --> Security Class Initialized
DEBUG - 2020-11-17 09:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:07:53 --> Input Class Initialized
INFO - 2020-11-17 09:07:53 --> Language Class Initialized
INFO - 2020-11-17 09:07:53 --> Language Class Initialized
INFO - 2020-11-17 09:07:53 --> Config Class Initialized
INFO - 2020-11-17 09:07:53 --> Loader Class Initialized
INFO - 2020-11-17 09:07:53 --> Helper loaded: url_helper
INFO - 2020-11-17 09:07:53 --> Helper loaded: file_helper
INFO - 2020-11-17 09:07:53 --> Helper loaded: form_helper
INFO - 2020-11-17 09:07:53 --> Helper loaded: my_helper
INFO - 2020-11-17 09:07:53 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:07:53 --> Controller Class Initialized
DEBUG - 2020-11-17 09:07:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-17 09:07:54 --> Final output sent to browser
DEBUG - 2020-11-17 09:07:54 --> Total execution time: 0.5180
INFO - 2020-11-17 09:07:55 --> Config Class Initialized
INFO - 2020-11-17 09:07:55 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:07:55 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:07:55 --> Utf8 Class Initialized
INFO - 2020-11-17 09:07:55 --> URI Class Initialized
INFO - 2020-11-17 09:07:55 --> Router Class Initialized
INFO - 2020-11-17 09:07:55 --> Output Class Initialized
INFO - 2020-11-17 09:07:55 --> Security Class Initialized
DEBUG - 2020-11-17 09:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:07:56 --> Input Class Initialized
INFO - 2020-11-17 09:07:56 --> Language Class Initialized
INFO - 2020-11-17 09:07:56 --> Language Class Initialized
INFO - 2020-11-17 09:07:56 --> Config Class Initialized
INFO - 2020-11-17 09:07:56 --> Loader Class Initialized
INFO - 2020-11-17 09:07:56 --> Helper loaded: url_helper
INFO - 2020-11-17 09:07:56 --> Helper loaded: file_helper
INFO - 2020-11-17 09:07:56 --> Helper loaded: form_helper
INFO - 2020-11-17 09:07:56 --> Helper loaded: my_helper
INFO - 2020-11-17 09:07:56 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:07:56 --> Controller Class Initialized
DEBUG - 2020-11-17 09:07:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-17 09:07:56 --> Final output sent to browser
DEBUG - 2020-11-17 09:07:56 --> Total execution time: 0.4307
INFO - 2020-11-17 09:10:54 --> Config Class Initialized
INFO - 2020-11-17 09:10:54 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:10:54 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:10:54 --> Utf8 Class Initialized
INFO - 2020-11-17 09:10:54 --> URI Class Initialized
INFO - 2020-11-17 09:10:54 --> Router Class Initialized
INFO - 2020-11-17 09:10:54 --> Output Class Initialized
INFO - 2020-11-17 09:10:54 --> Security Class Initialized
DEBUG - 2020-11-17 09:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:10:54 --> Input Class Initialized
INFO - 2020-11-17 09:10:54 --> Language Class Initialized
INFO - 2020-11-17 09:10:54 --> Language Class Initialized
INFO - 2020-11-17 09:10:54 --> Config Class Initialized
INFO - 2020-11-17 09:10:54 --> Loader Class Initialized
INFO - 2020-11-17 09:10:54 --> Helper loaded: url_helper
INFO - 2020-11-17 09:10:54 --> Helper loaded: file_helper
INFO - 2020-11-17 09:10:54 --> Helper loaded: form_helper
INFO - 2020-11-17 09:10:54 --> Helper loaded: my_helper
INFO - 2020-11-17 09:10:54 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:10:54 --> Controller Class Initialized
DEBUG - 2020-11-17 09:10:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-17 09:10:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 09:10:54 --> Final output sent to browser
DEBUG - 2020-11-17 09:10:54 --> Total execution time: 0.3324
INFO - 2020-11-17 09:10:58 --> Config Class Initialized
INFO - 2020-11-17 09:10:58 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:10:58 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:10:58 --> Utf8 Class Initialized
INFO - 2020-11-17 09:10:58 --> URI Class Initialized
INFO - 2020-11-17 09:10:58 --> Router Class Initialized
INFO - 2020-11-17 09:10:58 --> Output Class Initialized
INFO - 2020-11-17 09:10:58 --> Security Class Initialized
DEBUG - 2020-11-17 09:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:10:58 --> Input Class Initialized
INFO - 2020-11-17 09:10:58 --> Language Class Initialized
INFO - 2020-11-17 09:10:58 --> Language Class Initialized
INFO - 2020-11-17 09:10:58 --> Config Class Initialized
INFO - 2020-11-17 09:10:58 --> Loader Class Initialized
INFO - 2020-11-17 09:10:58 --> Helper loaded: url_helper
INFO - 2020-11-17 09:10:58 --> Helper loaded: file_helper
INFO - 2020-11-17 09:10:58 --> Helper loaded: form_helper
INFO - 2020-11-17 09:10:58 --> Helper loaded: my_helper
INFO - 2020-11-17 09:10:58 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:10:58 --> Controller Class Initialized
DEBUG - 2020-11-17 09:10:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-17 09:10:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-17 09:10:58 --> Final output sent to browser
DEBUG - 2020-11-17 09:10:58 --> Total execution time: 0.3114
INFO - 2020-11-17 09:11:00 --> Config Class Initialized
INFO - 2020-11-17 09:11:00 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:11:00 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:11:00 --> Utf8 Class Initialized
INFO - 2020-11-17 09:11:00 --> URI Class Initialized
INFO - 2020-11-17 09:11:00 --> Router Class Initialized
INFO - 2020-11-17 09:11:00 --> Output Class Initialized
INFO - 2020-11-17 09:11:00 --> Security Class Initialized
DEBUG - 2020-11-17 09:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:11:00 --> Input Class Initialized
INFO - 2020-11-17 09:11:00 --> Language Class Initialized
INFO - 2020-11-17 09:11:00 --> Language Class Initialized
INFO - 2020-11-17 09:11:00 --> Config Class Initialized
INFO - 2020-11-17 09:11:00 --> Loader Class Initialized
INFO - 2020-11-17 09:11:00 --> Helper loaded: url_helper
INFO - 2020-11-17 09:11:00 --> Helper loaded: file_helper
INFO - 2020-11-17 09:11:00 --> Helper loaded: form_helper
INFO - 2020-11-17 09:11:00 --> Helper loaded: my_helper
INFO - 2020-11-17 09:11:00 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:11:00 --> Controller Class Initialized
INFO - 2020-11-17 09:11:00 --> Final output sent to browser
DEBUG - 2020-11-17 09:11:00 --> Total execution time: 0.2616
INFO - 2020-11-17 09:11:02 --> Config Class Initialized
INFO - 2020-11-17 09:11:02 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:11:02 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:11:02 --> Utf8 Class Initialized
INFO - 2020-11-17 09:11:02 --> URI Class Initialized
INFO - 2020-11-17 09:11:02 --> Router Class Initialized
INFO - 2020-11-17 09:11:02 --> Output Class Initialized
INFO - 2020-11-17 09:11:02 --> Security Class Initialized
DEBUG - 2020-11-17 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:11:02 --> Input Class Initialized
INFO - 2020-11-17 09:11:02 --> Language Class Initialized
INFO - 2020-11-17 09:11:02 --> Language Class Initialized
INFO - 2020-11-17 09:11:02 --> Config Class Initialized
INFO - 2020-11-17 09:11:02 --> Loader Class Initialized
INFO - 2020-11-17 09:11:02 --> Helper loaded: url_helper
INFO - 2020-11-17 09:11:02 --> Helper loaded: file_helper
INFO - 2020-11-17 09:11:02 --> Helper loaded: form_helper
INFO - 2020-11-17 09:11:02 --> Helper loaded: my_helper
INFO - 2020-11-17 09:11:02 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:11:02 --> Controller Class Initialized
INFO - 2020-11-17 09:11:02 --> Final output sent to browser
DEBUG - 2020-11-17 09:11:02 --> Total execution time: 0.2471
INFO - 2020-11-17 09:11:02 --> Config Class Initialized
INFO - 2020-11-17 09:11:02 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:11:02 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:11:02 --> Utf8 Class Initialized
INFO - 2020-11-17 09:11:02 --> URI Class Initialized
INFO - 2020-11-17 09:11:03 --> Router Class Initialized
INFO - 2020-11-17 09:11:03 --> Output Class Initialized
INFO - 2020-11-17 09:11:03 --> Security Class Initialized
DEBUG - 2020-11-17 09:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:11:03 --> Input Class Initialized
INFO - 2020-11-17 09:11:03 --> Language Class Initialized
INFO - 2020-11-17 09:11:03 --> Language Class Initialized
INFO - 2020-11-17 09:11:03 --> Config Class Initialized
INFO - 2020-11-17 09:11:03 --> Loader Class Initialized
INFO - 2020-11-17 09:11:03 --> Helper loaded: url_helper
INFO - 2020-11-17 09:11:03 --> Helper loaded: file_helper
INFO - 2020-11-17 09:11:03 --> Helper loaded: form_helper
INFO - 2020-11-17 09:11:03 --> Helper loaded: my_helper
INFO - 2020-11-17 09:11:03 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:11:03 --> Controller Class Initialized
INFO - 2020-11-17 09:11:03 --> Final output sent to browser
DEBUG - 2020-11-17 09:11:03 --> Total execution time: 0.2534
INFO - 2020-11-17 09:11:03 --> Config Class Initialized
INFO - 2020-11-17 09:11:03 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:11:03 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:11:03 --> Utf8 Class Initialized
INFO - 2020-11-17 09:11:03 --> URI Class Initialized
INFO - 2020-11-17 09:11:03 --> Router Class Initialized
INFO - 2020-11-17 09:11:03 --> Output Class Initialized
INFO - 2020-11-17 09:11:03 --> Security Class Initialized
DEBUG - 2020-11-17 09:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:11:03 --> Input Class Initialized
INFO - 2020-11-17 09:11:03 --> Language Class Initialized
INFO - 2020-11-17 09:11:03 --> Language Class Initialized
INFO - 2020-11-17 09:11:03 --> Config Class Initialized
INFO - 2020-11-17 09:11:03 --> Loader Class Initialized
INFO - 2020-11-17 09:11:03 --> Helper loaded: url_helper
INFO - 2020-11-17 09:11:03 --> Helper loaded: file_helper
INFO - 2020-11-17 09:11:03 --> Helper loaded: form_helper
INFO - 2020-11-17 09:11:03 --> Helper loaded: my_helper
INFO - 2020-11-17 09:11:03 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:11:03 --> Controller Class Initialized
INFO - 2020-11-17 09:11:03 --> Final output sent to browser
DEBUG - 2020-11-17 09:11:03 --> Total execution time: 0.2619
INFO - 2020-11-17 09:11:04 --> Config Class Initialized
INFO - 2020-11-17 09:11:04 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:11:04 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:11:04 --> Utf8 Class Initialized
INFO - 2020-11-17 09:11:04 --> URI Class Initialized
INFO - 2020-11-17 09:11:04 --> Router Class Initialized
INFO - 2020-11-17 09:11:04 --> Output Class Initialized
INFO - 2020-11-17 09:11:04 --> Security Class Initialized
DEBUG - 2020-11-17 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:11:04 --> Input Class Initialized
INFO - 2020-11-17 09:11:04 --> Language Class Initialized
INFO - 2020-11-17 09:11:04 --> Language Class Initialized
INFO - 2020-11-17 09:11:04 --> Config Class Initialized
INFO - 2020-11-17 09:11:04 --> Loader Class Initialized
INFO - 2020-11-17 09:11:04 --> Helper loaded: url_helper
INFO - 2020-11-17 09:11:04 --> Helper loaded: file_helper
INFO - 2020-11-17 09:11:04 --> Helper loaded: form_helper
INFO - 2020-11-17 09:11:04 --> Helper loaded: my_helper
INFO - 2020-11-17 09:11:04 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:11:04 --> Controller Class Initialized
INFO - 2020-11-17 09:11:04 --> Final output sent to browser
DEBUG - 2020-11-17 09:11:04 --> Total execution time: 0.2490
INFO - 2020-11-17 09:11:04 --> Config Class Initialized
INFO - 2020-11-17 09:11:04 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:11:04 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:11:04 --> Utf8 Class Initialized
INFO - 2020-11-17 09:11:04 --> URI Class Initialized
INFO - 2020-11-17 09:11:04 --> Router Class Initialized
INFO - 2020-11-17 09:11:04 --> Output Class Initialized
INFO - 2020-11-17 09:11:04 --> Security Class Initialized
DEBUG - 2020-11-17 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:11:04 --> Input Class Initialized
INFO - 2020-11-17 09:11:04 --> Language Class Initialized
INFO - 2020-11-17 09:11:04 --> Language Class Initialized
INFO - 2020-11-17 09:11:05 --> Config Class Initialized
INFO - 2020-11-17 09:11:05 --> Loader Class Initialized
INFO - 2020-11-17 09:11:05 --> Helper loaded: url_helper
INFO - 2020-11-17 09:11:05 --> Helper loaded: file_helper
INFO - 2020-11-17 09:11:05 --> Helper loaded: form_helper
INFO - 2020-11-17 09:11:05 --> Helper loaded: my_helper
INFO - 2020-11-17 09:11:05 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:11:05 --> Controller Class Initialized
INFO - 2020-11-17 09:11:05 --> Final output sent to browser
DEBUG - 2020-11-17 09:11:05 --> Total execution time: 0.2503
INFO - 2020-11-17 09:11:05 --> Config Class Initialized
INFO - 2020-11-17 09:11:05 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:11:05 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:11:05 --> Utf8 Class Initialized
INFO - 2020-11-17 09:11:05 --> URI Class Initialized
INFO - 2020-11-17 09:11:05 --> Router Class Initialized
INFO - 2020-11-17 09:11:05 --> Output Class Initialized
INFO - 2020-11-17 09:11:05 --> Security Class Initialized
DEBUG - 2020-11-17 09:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:11:05 --> Input Class Initialized
INFO - 2020-11-17 09:11:05 --> Language Class Initialized
INFO - 2020-11-17 09:11:05 --> Language Class Initialized
INFO - 2020-11-17 09:11:05 --> Config Class Initialized
INFO - 2020-11-17 09:11:05 --> Loader Class Initialized
INFO - 2020-11-17 09:11:05 --> Helper loaded: url_helper
INFO - 2020-11-17 09:11:05 --> Helper loaded: file_helper
INFO - 2020-11-17 09:11:05 --> Helper loaded: form_helper
INFO - 2020-11-17 09:11:05 --> Helper loaded: my_helper
INFO - 2020-11-17 09:11:05 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:11:05 --> Controller Class Initialized
INFO - 2020-11-17 09:11:05 --> Final output sent to browser
DEBUG - 2020-11-17 09:11:05 --> Total execution time: 0.2538
INFO - 2020-11-17 09:11:06 --> Config Class Initialized
INFO - 2020-11-17 09:11:06 --> Hooks Class Initialized
DEBUG - 2020-11-17 09:11:06 --> UTF-8 Support Enabled
INFO - 2020-11-17 09:11:06 --> Utf8 Class Initialized
INFO - 2020-11-17 09:11:06 --> URI Class Initialized
INFO - 2020-11-17 09:11:06 --> Router Class Initialized
INFO - 2020-11-17 09:11:06 --> Output Class Initialized
INFO - 2020-11-17 09:11:06 --> Security Class Initialized
DEBUG - 2020-11-17 09:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-17 09:11:06 --> Input Class Initialized
INFO - 2020-11-17 09:11:06 --> Language Class Initialized
INFO - 2020-11-17 09:11:06 --> Language Class Initialized
INFO - 2020-11-17 09:11:06 --> Config Class Initialized
INFO - 2020-11-17 09:11:06 --> Loader Class Initialized
INFO - 2020-11-17 09:11:06 --> Helper loaded: url_helper
INFO - 2020-11-17 09:11:06 --> Helper loaded: file_helper
INFO - 2020-11-17 09:11:06 --> Helper loaded: form_helper
INFO - 2020-11-17 09:11:06 --> Helper loaded: my_helper
INFO - 2020-11-17 09:11:06 --> Database Driver Class Initialized
DEBUG - 2020-11-17 09:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-17 09:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-17 09:11:06 --> Controller Class Initialized
INFO - 2020-11-17 09:11:06 --> Final output sent to browser
DEBUG - 2020-11-17 09:11:06 --> Total execution time: 0.2618
