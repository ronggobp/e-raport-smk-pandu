<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-12 02:32:53 --> Config Class Initialized
INFO - 2020-12-12 02:32:53 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:32:53 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:32:53 --> Utf8 Class Initialized
INFO - 2020-12-12 02:32:53 --> URI Class Initialized
DEBUG - 2020-12-12 02:32:53 --> No URI present. Default controller set.
INFO - 2020-12-12 02:32:53 --> Router Class Initialized
INFO - 2020-12-12 02:32:53 --> Output Class Initialized
INFO - 2020-12-12 02:32:53 --> Security Class Initialized
DEBUG - 2020-12-12 02:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:32:53 --> Input Class Initialized
INFO - 2020-12-12 02:32:53 --> Language Class Initialized
INFO - 2020-12-12 02:32:53 --> Language Class Initialized
INFO - 2020-12-12 02:32:53 --> Config Class Initialized
INFO - 2020-12-12 02:32:53 --> Loader Class Initialized
INFO - 2020-12-12 02:32:53 --> Helper loaded: url_helper
INFO - 2020-12-12 02:32:53 --> Helper loaded: file_helper
INFO - 2020-12-12 02:32:53 --> Helper loaded: form_helper
INFO - 2020-12-12 02:32:53 --> Helper loaded: my_helper
INFO - 2020-12-12 02:32:54 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:32:54 --> Controller Class Initialized
INFO - 2020-12-12 02:32:54 --> Config Class Initialized
INFO - 2020-12-12 02:32:54 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:32:54 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:32:54 --> Utf8 Class Initialized
INFO - 2020-12-12 02:32:54 --> URI Class Initialized
INFO - 2020-12-12 02:32:54 --> Router Class Initialized
INFO - 2020-12-12 02:32:54 --> Output Class Initialized
INFO - 2020-12-12 02:32:54 --> Security Class Initialized
DEBUG - 2020-12-12 02:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:32:54 --> Input Class Initialized
INFO - 2020-12-12 02:32:54 --> Language Class Initialized
INFO - 2020-12-12 02:32:54 --> Language Class Initialized
INFO - 2020-12-12 02:32:54 --> Config Class Initialized
INFO - 2020-12-12 02:32:54 --> Loader Class Initialized
INFO - 2020-12-12 02:32:54 --> Helper loaded: url_helper
INFO - 2020-12-12 02:32:54 --> Helper loaded: file_helper
INFO - 2020-12-12 02:32:54 --> Helper loaded: form_helper
INFO - 2020-12-12 02:32:54 --> Helper loaded: my_helper
INFO - 2020-12-12 02:32:54 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:32:54 --> Controller Class Initialized
DEBUG - 2020-12-12 02:32:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-12 02:32:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-12 02:32:54 --> Final output sent to browser
DEBUG - 2020-12-12 02:32:54 --> Total execution time: 0.0944
INFO - 2020-12-12 02:33:13 --> Config Class Initialized
INFO - 2020-12-12 02:33:13 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:33:13 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:33:13 --> Utf8 Class Initialized
INFO - 2020-12-12 02:33:13 --> URI Class Initialized
INFO - 2020-12-12 02:33:13 --> Router Class Initialized
INFO - 2020-12-12 02:33:13 --> Output Class Initialized
INFO - 2020-12-12 02:33:13 --> Security Class Initialized
DEBUG - 2020-12-12 02:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:33:13 --> Input Class Initialized
INFO - 2020-12-12 02:33:13 --> Language Class Initialized
INFO - 2020-12-12 02:33:13 --> Language Class Initialized
INFO - 2020-12-12 02:33:13 --> Config Class Initialized
INFO - 2020-12-12 02:33:13 --> Loader Class Initialized
INFO - 2020-12-12 02:33:13 --> Helper loaded: url_helper
INFO - 2020-12-12 02:33:13 --> Helper loaded: file_helper
INFO - 2020-12-12 02:33:13 --> Helper loaded: form_helper
INFO - 2020-12-12 02:33:13 --> Helper loaded: my_helper
INFO - 2020-12-12 02:33:13 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:33:13 --> Controller Class Initialized
INFO - 2020-12-12 02:33:13 --> Helper loaded: cookie_helper
INFO - 2020-12-12 02:33:13 --> Final output sent to browser
DEBUG - 2020-12-12 02:33:13 --> Total execution time: 0.0788
INFO - 2020-12-12 02:33:14 --> Config Class Initialized
INFO - 2020-12-12 02:33:14 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:33:14 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:33:14 --> Utf8 Class Initialized
INFO - 2020-12-12 02:33:14 --> URI Class Initialized
INFO - 2020-12-12 02:33:14 --> Router Class Initialized
INFO - 2020-12-12 02:33:14 --> Output Class Initialized
INFO - 2020-12-12 02:33:14 --> Security Class Initialized
DEBUG - 2020-12-12 02:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:33:14 --> Input Class Initialized
INFO - 2020-12-12 02:33:14 --> Language Class Initialized
INFO - 2020-12-12 02:33:14 --> Language Class Initialized
INFO - 2020-12-12 02:33:14 --> Config Class Initialized
INFO - 2020-12-12 02:33:14 --> Loader Class Initialized
INFO - 2020-12-12 02:33:14 --> Helper loaded: url_helper
INFO - 2020-12-12 02:33:14 --> Helper loaded: file_helper
INFO - 2020-12-12 02:33:14 --> Helper loaded: form_helper
INFO - 2020-12-12 02:33:14 --> Helper loaded: my_helper
INFO - 2020-12-12 02:33:14 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:33:14 --> Controller Class Initialized
DEBUG - 2020-12-12 02:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-12 02:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-12 02:33:14 --> Final output sent to browser
DEBUG - 2020-12-12 02:33:14 --> Total execution time: 0.0886
INFO - 2020-12-12 02:33:17 --> Config Class Initialized
INFO - 2020-12-12 02:33:17 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:33:17 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:33:17 --> Utf8 Class Initialized
INFO - 2020-12-12 02:33:17 --> URI Class Initialized
INFO - 2020-12-12 02:33:17 --> Router Class Initialized
INFO - 2020-12-12 02:33:17 --> Output Class Initialized
INFO - 2020-12-12 02:33:17 --> Security Class Initialized
DEBUG - 2020-12-12 02:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:33:17 --> Input Class Initialized
INFO - 2020-12-12 02:33:17 --> Language Class Initialized
INFO - 2020-12-12 02:33:17 --> Language Class Initialized
INFO - 2020-12-12 02:33:17 --> Config Class Initialized
INFO - 2020-12-12 02:33:17 --> Loader Class Initialized
INFO - 2020-12-12 02:33:17 --> Helper loaded: url_helper
INFO - 2020-12-12 02:33:17 --> Helper loaded: file_helper
INFO - 2020-12-12 02:33:17 --> Helper loaded: form_helper
INFO - 2020-12-12 02:33:17 --> Helper loaded: my_helper
INFO - 2020-12-12 02:33:17 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:33:17 --> Controller Class Initialized
DEBUG - 2020-12-12 02:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-12 02:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-12 02:33:17 --> Final output sent to browser
DEBUG - 2020-12-12 02:33:17 --> Total execution time: 0.0865
INFO - 2020-12-12 02:33:59 --> Config Class Initialized
INFO - 2020-12-12 02:33:59 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:33:59 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:33:59 --> Utf8 Class Initialized
INFO - 2020-12-12 02:33:59 --> URI Class Initialized
INFO - 2020-12-12 02:33:59 --> Router Class Initialized
INFO - 2020-12-12 02:33:59 --> Output Class Initialized
INFO - 2020-12-12 02:33:59 --> Security Class Initialized
DEBUG - 2020-12-12 02:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:33:59 --> Input Class Initialized
INFO - 2020-12-12 02:33:59 --> Language Class Initialized
INFO - 2020-12-12 02:33:59 --> Language Class Initialized
INFO - 2020-12-12 02:33:59 --> Config Class Initialized
INFO - 2020-12-12 02:33:59 --> Loader Class Initialized
INFO - 2020-12-12 02:33:59 --> Helper loaded: url_helper
INFO - 2020-12-12 02:33:59 --> Helper loaded: file_helper
INFO - 2020-12-12 02:33:59 --> Helper loaded: form_helper
INFO - 2020-12-12 02:33:59 --> Helper loaded: my_helper
INFO - 2020-12-12 02:33:59 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:33:59 --> Controller Class Initialized
DEBUG - 2020-12-12 02:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-12 02:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-12 02:33:59 --> Final output sent to browser
DEBUG - 2020-12-12 02:33:59 --> Total execution time: 0.0620
INFO - 2020-12-12 02:55:22 --> Config Class Initialized
INFO - 2020-12-12 02:55:22 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:55:22 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:55:22 --> Utf8 Class Initialized
INFO - 2020-12-12 02:55:22 --> URI Class Initialized
INFO - 2020-12-12 02:55:22 --> Router Class Initialized
INFO - 2020-12-12 02:55:22 --> Output Class Initialized
INFO - 2020-12-12 02:55:22 --> Security Class Initialized
DEBUG - 2020-12-12 02:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:55:22 --> Input Class Initialized
INFO - 2020-12-12 02:55:22 --> Language Class Initialized
INFO - 2020-12-12 02:55:22 --> Language Class Initialized
INFO - 2020-12-12 02:55:22 --> Config Class Initialized
INFO - 2020-12-12 02:55:22 --> Loader Class Initialized
INFO - 2020-12-12 02:55:22 --> Helper loaded: url_helper
INFO - 2020-12-12 02:55:22 --> Helper loaded: file_helper
INFO - 2020-12-12 02:55:22 --> Helper loaded: form_helper
INFO - 2020-12-12 02:55:22 --> Helper loaded: my_helper
INFO - 2020-12-12 02:55:22 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:55:22 --> Controller Class Initialized
ERROR - 2020-12-12 02:55:22 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-12 02:56:50 --> Config Class Initialized
INFO - 2020-12-12 02:56:50 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:56:50 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:56:50 --> Utf8 Class Initialized
INFO - 2020-12-12 02:56:50 --> URI Class Initialized
INFO - 2020-12-12 02:56:50 --> Router Class Initialized
INFO - 2020-12-12 02:56:50 --> Output Class Initialized
INFO - 2020-12-12 02:56:50 --> Security Class Initialized
DEBUG - 2020-12-12 02:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:56:50 --> Input Class Initialized
INFO - 2020-12-12 02:56:50 --> Language Class Initialized
INFO - 2020-12-12 02:56:50 --> Language Class Initialized
INFO - 2020-12-12 02:56:50 --> Config Class Initialized
INFO - 2020-12-12 02:56:50 --> Loader Class Initialized
INFO - 2020-12-12 02:56:50 --> Helper loaded: url_helper
INFO - 2020-12-12 02:56:50 --> Helper loaded: file_helper
INFO - 2020-12-12 02:56:50 --> Helper loaded: form_helper
INFO - 2020-12-12 02:56:50 --> Helper loaded: my_helper
INFO - 2020-12-12 02:56:50 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:56:50 --> Controller Class Initialized
ERROR - 2020-12-12 02:56:50 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 83
INFO - 2020-12-12 02:57:09 --> Config Class Initialized
INFO - 2020-12-12 02:57:09 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:57:09 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:57:09 --> Utf8 Class Initialized
INFO - 2020-12-12 02:57:09 --> URI Class Initialized
INFO - 2020-12-12 02:57:09 --> Router Class Initialized
INFO - 2020-12-12 02:57:09 --> Output Class Initialized
INFO - 2020-12-12 02:57:09 --> Security Class Initialized
DEBUG - 2020-12-12 02:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:57:09 --> Input Class Initialized
INFO - 2020-12-12 02:57:09 --> Language Class Initialized
INFO - 2020-12-12 02:57:09 --> Language Class Initialized
INFO - 2020-12-12 02:57:09 --> Config Class Initialized
INFO - 2020-12-12 02:57:09 --> Loader Class Initialized
INFO - 2020-12-12 02:57:09 --> Helper loaded: url_helper
INFO - 2020-12-12 02:57:09 --> Helper loaded: file_helper
INFO - 2020-12-12 02:57:09 --> Helper loaded: form_helper
INFO - 2020-12-12 02:57:09 --> Helper loaded: my_helper
INFO - 2020-12-12 02:57:09 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:57:09 --> Controller Class Initialized
ERROR - 2020-12-12 02:57:09 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-12 02:57:10 --> Config Class Initialized
INFO - 2020-12-12 02:57:10 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:57:10 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:57:10 --> Utf8 Class Initialized
INFO - 2020-12-12 02:57:10 --> URI Class Initialized
INFO - 2020-12-12 02:57:10 --> Router Class Initialized
INFO - 2020-12-12 02:57:10 --> Output Class Initialized
INFO - 2020-12-12 02:57:10 --> Security Class Initialized
DEBUG - 2020-12-12 02:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:57:10 --> Input Class Initialized
INFO - 2020-12-12 02:57:10 --> Language Class Initialized
INFO - 2020-12-12 02:57:10 --> Language Class Initialized
INFO - 2020-12-12 02:57:10 --> Config Class Initialized
INFO - 2020-12-12 02:57:10 --> Loader Class Initialized
INFO - 2020-12-12 02:57:10 --> Helper loaded: url_helper
INFO - 2020-12-12 02:57:10 --> Helper loaded: file_helper
INFO - 2020-12-12 02:57:10 --> Helper loaded: form_helper
INFO - 2020-12-12 02:57:10 --> Helper loaded: my_helper
INFO - 2020-12-12 02:57:10 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:57:10 --> Controller Class Initialized
ERROR - 2020-12-12 02:57:10 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-12 02:57:11 --> Config Class Initialized
INFO - 2020-12-12 02:57:11 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:57:11 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:57:11 --> Utf8 Class Initialized
INFO - 2020-12-12 02:57:11 --> URI Class Initialized
INFO - 2020-12-12 02:57:11 --> Router Class Initialized
INFO - 2020-12-12 02:57:11 --> Output Class Initialized
INFO - 2020-12-12 02:57:11 --> Security Class Initialized
DEBUG - 2020-12-12 02:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:57:11 --> Input Class Initialized
INFO - 2020-12-12 02:57:11 --> Language Class Initialized
INFO - 2020-12-12 02:57:11 --> Language Class Initialized
INFO - 2020-12-12 02:57:11 --> Config Class Initialized
INFO - 2020-12-12 02:57:11 --> Loader Class Initialized
INFO - 2020-12-12 02:57:11 --> Helper loaded: url_helper
INFO - 2020-12-12 02:57:11 --> Helper loaded: file_helper
INFO - 2020-12-12 02:57:11 --> Helper loaded: form_helper
INFO - 2020-12-12 02:57:11 --> Helper loaded: my_helper
INFO - 2020-12-12 02:57:11 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:57:11 --> Controller Class Initialized
ERROR - 2020-12-12 02:57:11 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-12 02:57:11 --> Config Class Initialized
INFO - 2020-12-12 02:57:11 --> Hooks Class Initialized
DEBUG - 2020-12-12 02:57:11 --> UTF-8 Support Enabled
INFO - 2020-12-12 02:57:11 --> Utf8 Class Initialized
INFO - 2020-12-12 02:57:11 --> URI Class Initialized
INFO - 2020-12-12 02:57:11 --> Router Class Initialized
INFO - 2020-12-12 02:57:11 --> Output Class Initialized
INFO - 2020-12-12 02:57:11 --> Security Class Initialized
DEBUG - 2020-12-12 02:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 02:57:11 --> Input Class Initialized
INFO - 2020-12-12 02:57:11 --> Language Class Initialized
INFO - 2020-12-12 02:57:11 --> Language Class Initialized
INFO - 2020-12-12 02:57:11 --> Config Class Initialized
INFO - 2020-12-12 02:57:11 --> Loader Class Initialized
INFO - 2020-12-12 02:57:11 --> Helper loaded: url_helper
INFO - 2020-12-12 02:57:11 --> Helper loaded: file_helper
INFO - 2020-12-12 02:57:11 --> Helper loaded: form_helper
INFO - 2020-12-12 02:57:11 --> Helper loaded: my_helper
INFO - 2020-12-12 02:57:11 --> Database Driver Class Initialized
DEBUG - 2020-12-12 02:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 02:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 02:57:11 --> Controller Class Initialized
ERROR - 2020-12-12 02:57:11 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-12 03:00:37 --> Config Class Initialized
INFO - 2020-12-12 03:00:37 --> Hooks Class Initialized
DEBUG - 2020-12-12 03:00:37 --> UTF-8 Support Enabled
INFO - 2020-12-12 03:00:37 --> Utf8 Class Initialized
INFO - 2020-12-12 03:00:37 --> URI Class Initialized
INFO - 2020-12-12 03:00:37 --> Router Class Initialized
INFO - 2020-12-12 03:00:37 --> Output Class Initialized
INFO - 2020-12-12 03:00:37 --> Security Class Initialized
DEBUG - 2020-12-12 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 03:00:37 --> Input Class Initialized
INFO - 2020-12-12 03:00:37 --> Language Class Initialized
INFO - 2020-12-12 03:00:37 --> Language Class Initialized
INFO - 2020-12-12 03:00:37 --> Config Class Initialized
INFO - 2020-12-12 03:00:37 --> Loader Class Initialized
INFO - 2020-12-12 03:00:37 --> Helper loaded: url_helper
INFO - 2020-12-12 03:00:37 --> Helper loaded: file_helper
INFO - 2020-12-12 03:00:37 --> Helper loaded: form_helper
INFO - 2020-12-12 03:00:37 --> Helper loaded: my_helper
INFO - 2020-12-12 03:00:37 --> Database Driver Class Initialized
DEBUG - 2020-12-12 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 03:00:37 --> Controller Class Initialized
ERROR - 2020-12-12 03:00:37 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 105
INFO - 2020-12-12 05:29:05 --> Config Class Initialized
INFO - 2020-12-12 05:29:05 --> Hooks Class Initialized
DEBUG - 2020-12-12 05:29:05 --> UTF-8 Support Enabled
INFO - 2020-12-12 05:29:05 --> Utf8 Class Initialized
INFO - 2020-12-12 05:29:05 --> URI Class Initialized
INFO - 2020-12-12 05:29:05 --> Router Class Initialized
INFO - 2020-12-12 05:29:05 --> Output Class Initialized
INFO - 2020-12-12 05:29:05 --> Security Class Initialized
DEBUG - 2020-12-12 05:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 05:29:05 --> Input Class Initialized
INFO - 2020-12-12 05:29:05 --> Language Class Initialized
INFO - 2020-12-12 05:29:05 --> Language Class Initialized
INFO - 2020-12-12 05:29:05 --> Config Class Initialized
INFO - 2020-12-12 05:29:05 --> Loader Class Initialized
INFO - 2020-12-12 05:29:05 --> Helper loaded: url_helper
INFO - 2020-12-12 05:29:05 --> Helper loaded: file_helper
INFO - 2020-12-12 05:29:05 --> Helper loaded: form_helper
INFO - 2020-12-12 05:29:05 --> Helper loaded: my_helper
INFO - 2020-12-12 05:29:05 --> Database Driver Class Initialized
DEBUG - 2020-12-12 05:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 05:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 05:29:05 --> Controller Class Initialized
ERROR - 2020-12-12 05:29:05 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 105
INFO - 2020-12-12 05:29:08 --> Config Class Initialized
INFO - 2020-12-12 05:29:08 --> Hooks Class Initialized
DEBUG - 2020-12-12 05:29:08 --> UTF-8 Support Enabled
INFO - 2020-12-12 05:29:08 --> Utf8 Class Initialized
INFO - 2020-12-12 05:29:08 --> URI Class Initialized
INFO - 2020-12-12 05:29:08 --> Router Class Initialized
INFO - 2020-12-12 05:29:08 --> Output Class Initialized
INFO - 2020-12-12 05:29:08 --> Security Class Initialized
DEBUG - 2020-12-12 05:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 05:29:08 --> Input Class Initialized
INFO - 2020-12-12 05:29:08 --> Language Class Initialized
INFO - 2020-12-12 05:29:08 --> Language Class Initialized
INFO - 2020-12-12 05:29:08 --> Config Class Initialized
INFO - 2020-12-12 05:29:08 --> Loader Class Initialized
INFO - 2020-12-12 05:29:08 --> Helper loaded: url_helper
INFO - 2020-12-12 05:29:08 --> Helper loaded: file_helper
INFO - 2020-12-12 05:29:08 --> Helper loaded: form_helper
INFO - 2020-12-12 05:29:08 --> Helper loaded: my_helper
INFO - 2020-12-12 05:29:08 --> Database Driver Class Initialized
DEBUG - 2020-12-12 05:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 05:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 05:29:08 --> Controller Class Initialized
ERROR - 2020-12-12 05:29:08 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 105
INFO - 2020-12-12 05:31:49 --> Config Class Initialized
INFO - 2020-12-12 05:31:49 --> Hooks Class Initialized
DEBUG - 2020-12-12 05:31:49 --> UTF-8 Support Enabled
INFO - 2020-12-12 05:31:49 --> Utf8 Class Initialized
INFO - 2020-12-12 05:31:49 --> URI Class Initialized
INFO - 2020-12-12 05:31:49 --> Router Class Initialized
INFO - 2020-12-12 05:31:49 --> Output Class Initialized
INFO - 2020-12-12 05:31:49 --> Security Class Initialized
DEBUG - 2020-12-12 05:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 05:31:49 --> Input Class Initialized
INFO - 2020-12-12 05:31:49 --> Language Class Initialized
INFO - 2020-12-12 05:31:49 --> Language Class Initialized
INFO - 2020-12-12 05:31:49 --> Config Class Initialized
INFO - 2020-12-12 05:31:49 --> Loader Class Initialized
INFO - 2020-12-12 05:31:49 --> Helper loaded: url_helper
INFO - 2020-12-12 05:31:49 --> Helper loaded: file_helper
INFO - 2020-12-12 05:31:49 --> Helper loaded: form_helper
INFO - 2020-12-12 05:31:49 --> Helper loaded: my_helper
INFO - 2020-12-12 05:31:49 --> Database Driver Class Initialized
DEBUG - 2020-12-12 05:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 05:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 05:31:49 --> Controller Class Initialized
ERROR - 2020-12-12 05:31:49 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 83
INFO - 2020-12-12 09:03:33 --> Config Class Initialized
INFO - 2020-12-12 09:03:33 --> Hooks Class Initialized
DEBUG - 2020-12-12 09:03:33 --> UTF-8 Support Enabled
INFO - 2020-12-12 09:03:33 --> Utf8 Class Initialized
INFO - 2020-12-12 09:03:33 --> URI Class Initialized
INFO - 2020-12-12 09:03:34 --> Router Class Initialized
INFO - 2020-12-12 09:03:34 --> Output Class Initialized
INFO - 2020-12-12 09:03:34 --> Security Class Initialized
DEBUG - 2020-12-12 09:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 09:03:34 --> Input Class Initialized
INFO - 2020-12-12 09:03:34 --> Language Class Initialized
INFO - 2020-12-12 09:03:34 --> Language Class Initialized
INFO - 2020-12-12 09:03:34 --> Config Class Initialized
INFO - 2020-12-12 09:03:34 --> Loader Class Initialized
INFO - 2020-12-12 09:03:34 --> Helper loaded: url_helper
INFO - 2020-12-12 09:03:34 --> Helper loaded: file_helper
INFO - 2020-12-12 09:03:34 --> Helper loaded: form_helper
INFO - 2020-12-12 09:03:34 --> Helper loaded: my_helper
INFO - 2020-12-12 09:03:34 --> Database Driver Class Initialized
DEBUG - 2020-12-12 09:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 09:03:34 --> Controller Class Initialized
ERROR - 2020-12-12 09:03:34 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 83
INFO - 2020-12-12 09:07:22 --> Config Class Initialized
INFO - 2020-12-12 09:07:22 --> Hooks Class Initialized
DEBUG - 2020-12-12 09:07:22 --> UTF-8 Support Enabled
INFO - 2020-12-12 09:07:22 --> Utf8 Class Initialized
INFO - 2020-12-12 09:07:22 --> URI Class Initialized
INFO - 2020-12-12 09:07:22 --> Router Class Initialized
INFO - 2020-12-12 09:07:22 --> Output Class Initialized
INFO - 2020-12-12 09:07:22 --> Security Class Initialized
DEBUG - 2020-12-12 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 09:07:22 --> Input Class Initialized
INFO - 2020-12-12 09:07:22 --> Language Class Initialized
INFO - 2020-12-12 09:07:22 --> Language Class Initialized
INFO - 2020-12-12 09:07:22 --> Config Class Initialized
INFO - 2020-12-12 09:07:22 --> Loader Class Initialized
INFO - 2020-12-12 09:07:22 --> Helper loaded: url_helper
INFO - 2020-12-12 09:07:22 --> Helper loaded: file_helper
INFO - 2020-12-12 09:07:22 --> Helper loaded: form_helper
INFO - 2020-12-12 09:07:22 --> Helper loaded: my_helper
INFO - 2020-12-12 09:07:22 --> Database Driver Class Initialized
DEBUG - 2020-12-12 09:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-12 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 09:07:22 --> Controller Class Initialized
ERROR - 2020-12-12 09:07:22 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
