<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-11-11 06:07:58 --> Config Class Initialized
INFO - 2021-11-11 06:07:58 --> Hooks Class Initialized
DEBUG - 2021-11-11 06:07:58 --> UTF-8 Support Enabled
INFO - 2021-11-11 06:07:58 --> Utf8 Class Initialized
INFO - 2021-11-11 06:07:58 --> URI Class Initialized
DEBUG - 2021-11-11 06:07:58 --> No URI present. Default controller set.
INFO - 2021-11-11 06:07:58 --> Router Class Initialized
INFO - 2021-11-11 06:07:58 --> Output Class Initialized
INFO - 2021-11-11 06:07:58 --> Security Class Initialized
DEBUG - 2021-11-11 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-11 06:07:58 --> Input Class Initialized
INFO - 2021-11-11 06:07:58 --> Language Class Initialized
INFO - 2021-11-11 06:07:58 --> Language Class Initialized
INFO - 2021-11-11 06:07:58 --> Config Class Initialized
INFO - 2021-11-11 06:07:58 --> Loader Class Initialized
INFO - 2021-11-11 06:07:58 --> Helper loaded: url_helper
INFO - 2021-11-11 06:07:58 --> Helper loaded: file_helper
INFO - 2021-11-11 06:07:58 --> Helper loaded: form_helper
INFO - 2021-11-11 06:07:58 --> Helper loaded: my_helper
INFO - 2021-11-11 06:07:58 --> Database Driver Class Initialized
DEBUG - 2021-11-11 06:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-11 06:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-11 06:07:58 --> Controller Class Initialized
INFO - 2021-11-11 06:07:58 --> Config Class Initialized
INFO - 2021-11-11 06:07:58 --> Hooks Class Initialized
DEBUG - 2021-11-11 06:07:58 --> UTF-8 Support Enabled
INFO - 2021-11-11 06:07:58 --> Utf8 Class Initialized
INFO - 2021-11-11 06:07:58 --> URI Class Initialized
INFO - 2021-11-11 06:07:58 --> Router Class Initialized
INFO - 2021-11-11 06:07:58 --> Output Class Initialized
INFO - 2021-11-11 06:07:58 --> Security Class Initialized
DEBUG - 2021-11-11 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-11 06:07:58 --> Input Class Initialized
INFO - 2021-11-11 06:07:58 --> Language Class Initialized
INFO - 2021-11-11 06:07:58 --> Language Class Initialized
INFO - 2021-11-11 06:07:58 --> Config Class Initialized
INFO - 2021-11-11 06:07:58 --> Loader Class Initialized
INFO - 2021-11-11 06:07:58 --> Helper loaded: url_helper
INFO - 2021-11-11 06:07:58 --> Helper loaded: file_helper
INFO - 2021-11-11 06:07:58 --> Helper loaded: form_helper
INFO - 2021-11-11 06:07:58 --> Helper loaded: my_helper
INFO - 2021-11-11 06:07:58 --> Database Driver Class Initialized
DEBUG - 2021-11-11 06:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-11 06:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-11 06:07:58 --> Controller Class Initialized
DEBUG - 2021-11-11 06:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-11 06:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-11 06:07:58 --> Final output sent to browser
DEBUG - 2021-11-11 06:07:58 --> Total execution time: 0.1109
