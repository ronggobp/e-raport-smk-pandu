<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-22 05:41:42 --> Config Class Initialized
INFO - 2021-08-22 05:41:42 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:41:42 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:41:42 --> Utf8 Class Initialized
INFO - 2021-08-22 05:41:42 --> URI Class Initialized
DEBUG - 2021-08-22 05:41:42 --> No URI present. Default controller set.
INFO - 2021-08-22 05:41:42 --> Router Class Initialized
INFO - 2021-08-22 05:41:42 --> Output Class Initialized
INFO - 2021-08-22 05:41:42 --> Security Class Initialized
DEBUG - 2021-08-22 05:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:41:42 --> Input Class Initialized
INFO - 2021-08-22 05:41:42 --> Language Class Initialized
INFO - 2021-08-22 05:41:42 --> Language Class Initialized
INFO - 2021-08-22 05:41:42 --> Config Class Initialized
INFO - 2021-08-22 05:41:42 --> Loader Class Initialized
INFO - 2021-08-22 05:41:42 --> Helper loaded: url_helper
INFO - 2021-08-22 05:41:42 --> Helper loaded: file_helper
INFO - 2021-08-22 05:41:42 --> Helper loaded: form_helper
INFO - 2021-08-22 05:41:42 --> Helper loaded: my_helper
INFO - 2021-08-22 05:41:42 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:41:42 --> Controller Class Initialized
INFO - 2021-08-22 05:41:42 --> Config Class Initialized
INFO - 2021-08-22 05:41:42 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:41:42 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:41:42 --> Utf8 Class Initialized
INFO - 2021-08-22 05:41:42 --> URI Class Initialized
INFO - 2021-08-22 05:41:42 --> Router Class Initialized
INFO - 2021-08-22 05:41:42 --> Output Class Initialized
INFO - 2021-08-22 05:41:42 --> Security Class Initialized
DEBUG - 2021-08-22 05:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:41:42 --> Input Class Initialized
INFO - 2021-08-22 05:41:42 --> Language Class Initialized
INFO - 2021-08-22 05:41:42 --> Language Class Initialized
INFO - 2021-08-22 05:41:42 --> Config Class Initialized
INFO - 2021-08-22 05:41:42 --> Loader Class Initialized
INFO - 2021-08-22 05:41:42 --> Helper loaded: url_helper
INFO - 2021-08-22 05:41:42 --> Helper loaded: file_helper
INFO - 2021-08-22 05:41:42 --> Helper loaded: form_helper
INFO - 2021-08-22 05:41:42 --> Helper loaded: my_helper
INFO - 2021-08-22 05:41:42 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:41:42 --> Controller Class Initialized
DEBUG - 2021-08-22 05:41:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-22 05:41:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-22 05:41:42 --> Final output sent to browser
DEBUG - 2021-08-22 05:41:42 --> Total execution time: 0.0531
INFO - 2021-08-22 05:41:43 --> Config Class Initialized
INFO - 2021-08-22 05:41:43 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:41:43 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:41:43 --> Utf8 Class Initialized
INFO - 2021-08-22 05:41:43 --> URI Class Initialized
DEBUG - 2021-08-22 05:41:43 --> No URI present. Default controller set.
INFO - 2021-08-22 05:41:43 --> Router Class Initialized
INFO - 2021-08-22 05:41:43 --> Output Class Initialized
INFO - 2021-08-22 05:41:43 --> Security Class Initialized
DEBUG - 2021-08-22 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:41:43 --> Input Class Initialized
INFO - 2021-08-22 05:41:43 --> Language Class Initialized
INFO - 2021-08-22 05:41:43 --> Language Class Initialized
INFO - 2021-08-22 05:41:43 --> Config Class Initialized
INFO - 2021-08-22 05:41:43 --> Loader Class Initialized
INFO - 2021-08-22 05:41:43 --> Helper loaded: url_helper
INFO - 2021-08-22 05:41:43 --> Helper loaded: file_helper
INFO - 2021-08-22 05:41:43 --> Helper loaded: form_helper
INFO - 2021-08-22 05:41:43 --> Helper loaded: my_helper
INFO - 2021-08-22 05:41:43 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:41:43 --> Controller Class Initialized
INFO - 2021-08-22 05:41:43 --> Config Class Initialized
INFO - 2021-08-22 05:41:43 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:41:43 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:41:43 --> Utf8 Class Initialized
INFO - 2021-08-22 05:41:43 --> URI Class Initialized
INFO - 2021-08-22 05:41:43 --> Router Class Initialized
INFO - 2021-08-22 05:41:43 --> Output Class Initialized
INFO - 2021-08-22 05:41:43 --> Security Class Initialized
DEBUG - 2021-08-22 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:41:43 --> Input Class Initialized
INFO - 2021-08-22 05:41:43 --> Language Class Initialized
INFO - 2021-08-22 05:41:43 --> Language Class Initialized
INFO - 2021-08-22 05:41:43 --> Config Class Initialized
INFO - 2021-08-22 05:41:43 --> Loader Class Initialized
INFO - 2021-08-22 05:41:43 --> Helper loaded: url_helper
INFO - 2021-08-22 05:41:43 --> Helper loaded: file_helper
INFO - 2021-08-22 05:41:43 --> Helper loaded: form_helper
INFO - 2021-08-22 05:41:43 --> Helper loaded: my_helper
INFO - 2021-08-22 05:41:43 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:41:43 --> Controller Class Initialized
DEBUG - 2021-08-22 05:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-22 05:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-22 05:41:43 --> Final output sent to browser
DEBUG - 2021-08-22 05:41:43 --> Total execution time: 0.0417
INFO - 2021-08-22 05:41:47 --> Config Class Initialized
INFO - 2021-08-22 05:41:47 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:41:47 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:41:47 --> Utf8 Class Initialized
INFO - 2021-08-22 05:41:47 --> URI Class Initialized
INFO - 2021-08-22 05:41:47 --> Router Class Initialized
INFO - 2021-08-22 05:41:47 --> Output Class Initialized
INFO - 2021-08-22 05:41:47 --> Security Class Initialized
DEBUG - 2021-08-22 05:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:41:47 --> Input Class Initialized
INFO - 2021-08-22 05:41:47 --> Language Class Initialized
INFO - 2021-08-22 05:41:47 --> Language Class Initialized
INFO - 2021-08-22 05:41:47 --> Config Class Initialized
INFO - 2021-08-22 05:41:47 --> Loader Class Initialized
INFO - 2021-08-22 05:41:47 --> Helper loaded: url_helper
INFO - 2021-08-22 05:41:47 --> Helper loaded: file_helper
INFO - 2021-08-22 05:41:47 --> Helper loaded: form_helper
INFO - 2021-08-22 05:41:47 --> Helper loaded: my_helper
INFO - 2021-08-22 05:41:47 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:41:47 --> Controller Class Initialized
INFO - 2021-08-22 05:41:47 --> Helper loaded: cookie_helper
INFO - 2021-08-22 05:41:47 --> Final output sent to browser
DEBUG - 2021-08-22 05:41:47 --> Total execution time: 0.0662
INFO - 2021-08-22 05:41:47 --> Config Class Initialized
INFO - 2021-08-22 05:41:47 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:41:47 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:41:47 --> Utf8 Class Initialized
INFO - 2021-08-22 05:41:47 --> URI Class Initialized
INFO - 2021-08-22 05:41:47 --> Router Class Initialized
INFO - 2021-08-22 05:41:47 --> Output Class Initialized
INFO - 2021-08-22 05:41:47 --> Security Class Initialized
DEBUG - 2021-08-22 05:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:41:47 --> Input Class Initialized
INFO - 2021-08-22 05:41:47 --> Language Class Initialized
INFO - 2021-08-22 05:41:47 --> Language Class Initialized
INFO - 2021-08-22 05:41:47 --> Config Class Initialized
INFO - 2021-08-22 05:41:47 --> Loader Class Initialized
INFO - 2021-08-22 05:41:47 --> Helper loaded: url_helper
INFO - 2021-08-22 05:41:47 --> Helper loaded: file_helper
INFO - 2021-08-22 05:41:47 --> Helper loaded: form_helper
INFO - 2021-08-22 05:41:47 --> Helper loaded: my_helper
INFO - 2021-08-22 05:41:47 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:41:47 --> Controller Class Initialized
DEBUG - 2021-08-22 05:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-22 05:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-22 05:41:48 --> Final output sent to browser
DEBUG - 2021-08-22 05:41:48 --> Total execution time: 0.5724
INFO - 2021-08-22 05:41:50 --> Config Class Initialized
INFO - 2021-08-22 05:41:50 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:41:50 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:41:50 --> Utf8 Class Initialized
INFO - 2021-08-22 05:41:50 --> URI Class Initialized
INFO - 2021-08-22 05:41:50 --> Router Class Initialized
INFO - 2021-08-22 05:41:50 --> Output Class Initialized
INFO - 2021-08-22 05:41:50 --> Security Class Initialized
DEBUG - 2021-08-22 05:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:41:50 --> Input Class Initialized
INFO - 2021-08-22 05:41:50 --> Language Class Initialized
INFO - 2021-08-22 05:41:50 --> Language Class Initialized
INFO - 2021-08-22 05:41:50 --> Config Class Initialized
INFO - 2021-08-22 05:41:50 --> Loader Class Initialized
INFO - 2021-08-22 05:41:50 --> Helper loaded: url_helper
INFO - 2021-08-22 05:41:50 --> Helper loaded: file_helper
INFO - 2021-08-22 05:41:50 --> Helper loaded: form_helper
INFO - 2021-08-22 05:41:50 --> Helper loaded: my_helper
INFO - 2021-08-22 05:41:50 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:41:50 --> Controller Class Initialized
DEBUG - 2021-08-22 05:41:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-22 05:41:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-22 05:41:50 --> Final output sent to browser
DEBUG - 2021-08-22 05:41:50 --> Total execution time: 0.0694
INFO - 2021-08-22 05:41:51 --> Config Class Initialized
INFO - 2021-08-22 05:41:51 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:41:51 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:41:51 --> Utf8 Class Initialized
INFO - 2021-08-22 05:41:51 --> URI Class Initialized
INFO - 2021-08-22 05:41:51 --> Router Class Initialized
INFO - 2021-08-22 05:41:51 --> Output Class Initialized
INFO - 2021-08-22 05:41:51 --> Security Class Initialized
DEBUG - 2021-08-22 05:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:41:51 --> Input Class Initialized
INFO - 2021-08-22 05:41:51 --> Language Class Initialized
INFO - 2021-08-22 05:41:51 --> Language Class Initialized
INFO - 2021-08-22 05:41:51 --> Config Class Initialized
INFO - 2021-08-22 05:41:51 --> Loader Class Initialized
INFO - 2021-08-22 05:41:51 --> Helper loaded: url_helper
INFO - 2021-08-22 05:41:51 --> Helper loaded: file_helper
INFO - 2021-08-22 05:41:51 --> Helper loaded: form_helper
INFO - 2021-08-22 05:41:51 --> Helper loaded: my_helper
INFO - 2021-08-22 05:41:51 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:41:51 --> Controller Class Initialized
DEBUG - 2021-08-22 05:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-22 05:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-22 05:41:51 --> Final output sent to browser
DEBUG - 2021-08-22 05:41:51 --> Total execution time: 0.0645
INFO - 2021-08-22 05:42:05 --> Config Class Initialized
INFO - 2021-08-22 05:42:05 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:42:05 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:42:05 --> Utf8 Class Initialized
INFO - 2021-08-22 05:42:05 --> URI Class Initialized
INFO - 2021-08-22 05:42:05 --> Router Class Initialized
INFO - 2021-08-22 05:42:05 --> Output Class Initialized
INFO - 2021-08-22 05:42:05 --> Security Class Initialized
DEBUG - 2021-08-22 05:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:42:05 --> Input Class Initialized
INFO - 2021-08-22 05:42:05 --> Language Class Initialized
INFO - 2021-08-22 05:42:05 --> Language Class Initialized
INFO - 2021-08-22 05:42:05 --> Config Class Initialized
INFO - 2021-08-22 05:42:05 --> Loader Class Initialized
INFO - 2021-08-22 05:42:05 --> Helper loaded: url_helper
INFO - 2021-08-22 05:42:05 --> Helper loaded: file_helper
INFO - 2021-08-22 05:42:05 --> Helper loaded: form_helper
INFO - 2021-08-22 05:42:05 --> Helper loaded: my_helper
INFO - 2021-08-22 05:42:05 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:42:05 --> Controller Class Initialized
INFO - 2021-08-22 05:42:05 --> Config Class Initialized
INFO - 2021-08-22 05:42:05 --> Hooks Class Initialized
DEBUG - 2021-08-22 05:42:05 --> UTF-8 Support Enabled
INFO - 2021-08-22 05:42:05 --> Utf8 Class Initialized
INFO - 2021-08-22 05:42:05 --> URI Class Initialized
INFO - 2021-08-22 05:42:05 --> Router Class Initialized
INFO - 2021-08-22 05:42:05 --> Output Class Initialized
INFO - 2021-08-22 05:42:05 --> Security Class Initialized
DEBUG - 2021-08-22 05:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-22 05:42:05 --> Input Class Initialized
INFO - 2021-08-22 05:42:05 --> Language Class Initialized
INFO - 2021-08-22 05:42:05 --> Language Class Initialized
INFO - 2021-08-22 05:42:05 --> Config Class Initialized
INFO - 2021-08-22 05:42:05 --> Loader Class Initialized
INFO - 2021-08-22 05:42:05 --> Helper loaded: url_helper
INFO - 2021-08-22 05:42:05 --> Helper loaded: file_helper
INFO - 2021-08-22 05:42:05 --> Helper loaded: form_helper
INFO - 2021-08-22 05:42:05 --> Helper loaded: my_helper
INFO - 2021-08-22 05:42:05 --> Database Driver Class Initialized
DEBUG - 2021-08-22 05:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-22 05:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-22 05:42:05 --> Controller Class Initialized
DEBUG - 2021-08-22 05:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-22 05:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-22 05:42:05 --> Final output sent to browser
DEBUG - 2021-08-22 05:42:05 --> Total execution time: 0.0632
