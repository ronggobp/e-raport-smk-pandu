<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-24 00:43:14 --> Config Class Initialized
INFO - 2020-11-24 00:43:14 --> Hooks Class Initialized
DEBUG - 2020-11-24 00:43:14 --> UTF-8 Support Enabled
INFO - 2020-11-24 00:43:14 --> Utf8 Class Initialized
INFO - 2020-11-24 00:43:14 --> URI Class Initialized
DEBUG - 2020-11-24 00:43:15 --> No URI present. Default controller set.
INFO - 2020-11-24 00:43:15 --> Router Class Initialized
INFO - 2020-11-24 00:43:15 --> Output Class Initialized
INFO - 2020-11-24 00:43:15 --> Security Class Initialized
DEBUG - 2020-11-24 00:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 00:43:15 --> Input Class Initialized
INFO - 2020-11-24 00:43:15 --> Language Class Initialized
INFO - 2020-11-24 00:43:15 --> Language Class Initialized
INFO - 2020-11-24 00:43:15 --> Config Class Initialized
INFO - 2020-11-24 00:43:15 --> Loader Class Initialized
INFO - 2020-11-24 00:43:15 --> Helper loaded: url_helper
INFO - 2020-11-24 00:43:15 --> Helper loaded: file_helper
INFO - 2020-11-24 00:43:15 --> Helper loaded: form_helper
INFO - 2020-11-24 00:43:15 --> Helper loaded: my_helper
INFO - 2020-11-24 00:43:15 --> Database Driver Class Initialized
DEBUG - 2020-11-24 00:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 00:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 00:43:15 --> Controller Class Initialized
INFO - 2020-11-24 00:43:15 --> Config Class Initialized
INFO - 2020-11-24 00:43:15 --> Hooks Class Initialized
DEBUG - 2020-11-24 00:43:15 --> UTF-8 Support Enabled
INFO - 2020-11-24 00:43:15 --> Utf8 Class Initialized
INFO - 2020-11-24 00:43:15 --> URI Class Initialized
INFO - 2020-11-24 00:43:15 --> Router Class Initialized
INFO - 2020-11-24 00:43:15 --> Output Class Initialized
INFO - 2020-11-24 00:43:15 --> Security Class Initialized
DEBUG - 2020-11-24 00:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 00:43:15 --> Input Class Initialized
INFO - 2020-11-24 00:43:15 --> Language Class Initialized
INFO - 2020-11-24 00:43:15 --> Language Class Initialized
INFO - 2020-11-24 00:43:15 --> Config Class Initialized
INFO - 2020-11-24 00:43:15 --> Loader Class Initialized
INFO - 2020-11-24 00:43:15 --> Helper loaded: url_helper
INFO - 2020-11-24 00:43:15 --> Helper loaded: file_helper
INFO - 2020-11-24 00:43:15 --> Helper loaded: form_helper
INFO - 2020-11-24 00:43:15 --> Helper loaded: my_helper
INFO - 2020-11-24 00:43:16 --> Database Driver Class Initialized
DEBUG - 2020-11-24 00:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 00:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 00:43:16 --> Controller Class Initialized
DEBUG - 2020-11-24 00:43:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-24 00:43:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 00:43:16 --> Final output sent to browser
DEBUG - 2020-11-24 00:43:16 --> Total execution time: 0.6556
INFO - 2020-11-24 01:01:25 --> Config Class Initialized
INFO - 2020-11-24 01:01:25 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:01:25 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:01:25 --> Utf8 Class Initialized
INFO - 2020-11-24 01:01:25 --> URI Class Initialized
INFO - 2020-11-24 01:01:25 --> Router Class Initialized
INFO - 2020-11-24 01:01:25 --> Output Class Initialized
INFO - 2020-11-24 01:01:25 --> Security Class Initialized
DEBUG - 2020-11-24 01:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:01:25 --> Input Class Initialized
INFO - 2020-11-24 01:01:25 --> Language Class Initialized
INFO - 2020-11-24 01:01:25 --> Language Class Initialized
INFO - 2020-11-24 01:01:25 --> Config Class Initialized
INFO - 2020-11-24 01:01:25 --> Loader Class Initialized
INFO - 2020-11-24 01:01:25 --> Helper loaded: url_helper
INFO - 2020-11-24 01:01:25 --> Helper loaded: file_helper
INFO - 2020-11-24 01:01:25 --> Helper loaded: form_helper
INFO - 2020-11-24 01:01:25 --> Helper loaded: my_helper
INFO - 2020-11-24 01:01:25 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:01:25 --> Controller Class Initialized
INFO - 2020-11-24 01:01:25 --> Helper loaded: cookie_helper
INFO - 2020-11-24 01:01:25 --> Final output sent to browser
DEBUG - 2020-11-24 01:01:25 --> Total execution time: 0.3000
INFO - 2020-11-24 01:01:25 --> Config Class Initialized
INFO - 2020-11-24 01:01:25 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:01:25 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:01:25 --> Utf8 Class Initialized
INFO - 2020-11-24 01:01:25 --> URI Class Initialized
INFO - 2020-11-24 01:01:25 --> Router Class Initialized
INFO - 2020-11-24 01:01:25 --> Output Class Initialized
INFO - 2020-11-24 01:01:25 --> Security Class Initialized
DEBUG - 2020-11-24 01:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:01:26 --> Input Class Initialized
INFO - 2020-11-24 01:01:26 --> Language Class Initialized
INFO - 2020-11-24 01:01:26 --> Language Class Initialized
INFO - 2020-11-24 01:01:26 --> Config Class Initialized
INFO - 2020-11-24 01:01:26 --> Loader Class Initialized
INFO - 2020-11-24 01:01:26 --> Helper loaded: url_helper
INFO - 2020-11-24 01:01:26 --> Helper loaded: file_helper
INFO - 2020-11-24 01:01:26 --> Helper loaded: form_helper
INFO - 2020-11-24 01:01:26 --> Helper loaded: my_helper
INFO - 2020-11-24 01:01:26 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:01:26 --> Controller Class Initialized
DEBUG - 2020-11-24 01:01:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-24 01:01:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:01:26 --> Final output sent to browser
DEBUG - 2020-11-24 01:01:26 --> Total execution time: 0.3199
INFO - 2020-11-24 01:01:31 --> Config Class Initialized
INFO - 2020-11-24 01:01:31 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:01:31 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:01:31 --> Utf8 Class Initialized
INFO - 2020-11-24 01:01:31 --> URI Class Initialized
INFO - 2020-11-24 01:01:31 --> Router Class Initialized
INFO - 2020-11-24 01:01:31 --> Output Class Initialized
INFO - 2020-11-24 01:01:31 --> Security Class Initialized
DEBUG - 2020-11-24 01:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:01:31 --> Input Class Initialized
INFO - 2020-11-24 01:01:31 --> Language Class Initialized
INFO - 2020-11-24 01:01:31 --> Language Class Initialized
INFO - 2020-11-24 01:01:31 --> Config Class Initialized
INFO - 2020-11-24 01:01:31 --> Loader Class Initialized
INFO - 2020-11-24 01:01:31 --> Helper loaded: url_helper
INFO - 2020-11-24 01:01:31 --> Helper loaded: file_helper
INFO - 2020-11-24 01:01:31 --> Helper loaded: form_helper
INFO - 2020-11-24 01:01:31 --> Helper loaded: my_helper
INFO - 2020-11-24 01:01:31 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:01:31 --> Controller Class Initialized
DEBUG - 2020-11-24 01:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-24 01:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:01:32 --> Final output sent to browser
DEBUG - 2020-11-24 01:01:32 --> Total execution time: 0.5328
INFO - 2020-11-24 01:45:56 --> Config Class Initialized
INFO - 2020-11-24 01:45:56 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:45:56 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:45:56 --> Utf8 Class Initialized
INFO - 2020-11-24 01:45:56 --> URI Class Initialized
INFO - 2020-11-24 01:45:56 --> Router Class Initialized
INFO - 2020-11-24 01:45:56 --> Output Class Initialized
INFO - 2020-11-24 01:45:56 --> Security Class Initialized
DEBUG - 2020-11-24 01:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:45:56 --> Input Class Initialized
INFO - 2020-11-24 01:45:56 --> Language Class Initialized
INFO - 2020-11-24 01:45:56 --> Language Class Initialized
INFO - 2020-11-24 01:45:56 --> Config Class Initialized
INFO - 2020-11-24 01:45:56 --> Loader Class Initialized
INFO - 2020-11-24 01:45:56 --> Helper loaded: url_helper
INFO - 2020-11-24 01:45:56 --> Helper loaded: file_helper
INFO - 2020-11-24 01:45:56 --> Helper loaded: form_helper
INFO - 2020-11-24 01:45:56 --> Helper loaded: my_helper
INFO - 2020-11-24 01:45:56 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:45:56 --> Controller Class Initialized
DEBUG - 2020-11-24 01:45:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-24 01:45:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:45:57 --> Final output sent to browser
DEBUG - 2020-11-24 01:45:57 --> Total execution time: 0.6106
INFO - 2020-11-24 01:46:09 --> Config Class Initialized
INFO - 2020-11-24 01:46:09 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:46:09 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:46:09 --> Utf8 Class Initialized
INFO - 2020-11-24 01:46:09 --> URI Class Initialized
INFO - 2020-11-24 01:46:09 --> Router Class Initialized
INFO - 2020-11-24 01:46:09 --> Output Class Initialized
INFO - 2020-11-24 01:46:09 --> Security Class Initialized
DEBUG - 2020-11-24 01:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:46:09 --> Input Class Initialized
INFO - 2020-11-24 01:46:09 --> Language Class Initialized
INFO - 2020-11-24 01:46:09 --> Language Class Initialized
INFO - 2020-11-24 01:46:09 --> Config Class Initialized
INFO - 2020-11-24 01:46:09 --> Loader Class Initialized
INFO - 2020-11-24 01:46:09 --> Helper loaded: url_helper
INFO - 2020-11-24 01:46:09 --> Helper loaded: file_helper
INFO - 2020-11-24 01:46:09 --> Helper loaded: form_helper
INFO - 2020-11-24 01:46:09 --> Helper loaded: my_helper
INFO - 2020-11-24 01:46:09 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:46:09 --> Controller Class Initialized
DEBUG - 2020-11-24 01:46:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-24 01:46:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:46:09 --> Final output sent to browser
DEBUG - 2020-11-24 01:46:09 --> Total execution time: 0.2106
INFO - 2020-11-24 01:46:15 --> Config Class Initialized
INFO - 2020-11-24 01:46:15 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:46:15 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:46:15 --> Utf8 Class Initialized
INFO - 2020-11-24 01:46:15 --> URI Class Initialized
INFO - 2020-11-24 01:46:15 --> Router Class Initialized
INFO - 2020-11-24 01:46:15 --> Output Class Initialized
INFO - 2020-11-24 01:46:15 --> Security Class Initialized
DEBUG - 2020-11-24 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:46:15 --> Input Class Initialized
INFO - 2020-11-24 01:46:15 --> Language Class Initialized
INFO - 2020-11-24 01:46:15 --> Language Class Initialized
INFO - 2020-11-24 01:46:15 --> Config Class Initialized
INFO - 2020-11-24 01:46:15 --> Loader Class Initialized
INFO - 2020-11-24 01:46:15 --> Helper loaded: url_helper
INFO - 2020-11-24 01:46:15 --> Helper loaded: file_helper
INFO - 2020-11-24 01:46:15 --> Helper loaded: form_helper
INFO - 2020-11-24 01:46:15 --> Helper loaded: my_helper
INFO - 2020-11-24 01:46:15 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:46:15 --> Controller Class Initialized
DEBUG - 2020-11-24 01:46:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-24 01:46:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:46:15 --> Final output sent to browser
DEBUG - 2020-11-24 01:46:15 --> Total execution time: 0.1836
INFO - 2020-11-24 01:53:34 --> Config Class Initialized
INFO - 2020-11-24 01:53:34 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:53:34 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:53:34 --> Utf8 Class Initialized
INFO - 2020-11-24 01:53:34 --> URI Class Initialized
INFO - 2020-11-24 01:53:34 --> Router Class Initialized
INFO - 2020-11-24 01:53:34 --> Output Class Initialized
INFO - 2020-11-24 01:53:34 --> Security Class Initialized
DEBUG - 2020-11-24 01:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:53:34 --> Input Class Initialized
INFO - 2020-11-24 01:53:34 --> Language Class Initialized
INFO - 2020-11-24 01:53:34 --> Language Class Initialized
INFO - 2020-11-24 01:53:34 --> Config Class Initialized
INFO - 2020-11-24 01:53:34 --> Loader Class Initialized
INFO - 2020-11-24 01:53:34 --> Helper loaded: url_helper
INFO - 2020-11-24 01:53:34 --> Helper loaded: file_helper
INFO - 2020-11-24 01:53:34 --> Helper loaded: form_helper
INFO - 2020-11-24 01:53:34 --> Helper loaded: my_helper
INFO - 2020-11-24 01:53:34 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:53:34 --> Controller Class Initialized
DEBUG - 2020-11-24 01:53:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-24 01:53:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:53:34 --> Final output sent to browser
DEBUG - 2020-11-24 01:53:34 --> Total execution time: 0.1981
INFO - 2020-11-24 01:53:45 --> Config Class Initialized
INFO - 2020-11-24 01:53:45 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:53:45 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:53:45 --> Utf8 Class Initialized
INFO - 2020-11-24 01:53:45 --> URI Class Initialized
INFO - 2020-11-24 01:53:45 --> Router Class Initialized
INFO - 2020-11-24 01:53:45 --> Output Class Initialized
INFO - 2020-11-24 01:53:45 --> Security Class Initialized
DEBUG - 2020-11-24 01:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:53:45 --> Input Class Initialized
INFO - 2020-11-24 01:53:45 --> Language Class Initialized
INFO - 2020-11-24 01:53:45 --> Language Class Initialized
INFO - 2020-11-24 01:53:45 --> Config Class Initialized
INFO - 2020-11-24 01:53:45 --> Loader Class Initialized
INFO - 2020-11-24 01:53:45 --> Helper loaded: url_helper
INFO - 2020-11-24 01:53:45 --> Helper loaded: file_helper
INFO - 2020-11-24 01:53:45 --> Helper loaded: form_helper
INFO - 2020-11-24 01:53:45 --> Helper loaded: my_helper
INFO - 2020-11-24 01:53:45 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:53:45 --> Controller Class Initialized
DEBUG - 2020-11-24 01:53:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-24 01:53:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:53:45 --> Final output sent to browser
DEBUG - 2020-11-24 01:53:45 --> Total execution time: 0.2006
INFO - 2020-11-24 01:53:47 --> Config Class Initialized
INFO - 2020-11-24 01:53:47 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:53:47 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:53:47 --> Utf8 Class Initialized
INFO - 2020-11-24 01:53:47 --> URI Class Initialized
INFO - 2020-11-24 01:53:47 --> Router Class Initialized
INFO - 2020-11-24 01:53:47 --> Output Class Initialized
INFO - 2020-11-24 01:53:47 --> Security Class Initialized
DEBUG - 2020-11-24 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:53:47 --> Input Class Initialized
INFO - 2020-11-24 01:53:47 --> Language Class Initialized
INFO - 2020-11-24 01:53:47 --> Language Class Initialized
INFO - 2020-11-24 01:53:47 --> Config Class Initialized
INFO - 2020-11-24 01:53:47 --> Loader Class Initialized
INFO - 2020-11-24 01:53:47 --> Helper loaded: url_helper
INFO - 2020-11-24 01:53:47 --> Helper loaded: file_helper
INFO - 2020-11-24 01:53:47 --> Helper loaded: form_helper
INFO - 2020-11-24 01:53:47 --> Helper loaded: my_helper
INFO - 2020-11-24 01:53:47 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:53:47 --> Controller Class Initialized
INFO - 2020-11-24 01:53:47 --> Final output sent to browser
DEBUG - 2020-11-24 01:53:47 --> Total execution time: 0.1666
INFO - 2020-11-24 01:56:41 --> Config Class Initialized
INFO - 2020-11-24 01:56:41 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:56:41 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:56:41 --> Utf8 Class Initialized
INFO - 2020-11-24 01:56:41 --> URI Class Initialized
INFO - 2020-11-24 01:56:41 --> Router Class Initialized
INFO - 2020-11-24 01:56:41 --> Output Class Initialized
INFO - 2020-11-24 01:56:41 --> Security Class Initialized
DEBUG - 2020-11-24 01:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:56:41 --> Input Class Initialized
INFO - 2020-11-24 01:56:41 --> Language Class Initialized
INFO - 2020-11-24 01:56:41 --> Language Class Initialized
INFO - 2020-11-24 01:56:41 --> Config Class Initialized
INFO - 2020-11-24 01:56:41 --> Loader Class Initialized
INFO - 2020-11-24 01:56:41 --> Helper loaded: url_helper
INFO - 2020-11-24 01:56:41 --> Helper loaded: file_helper
INFO - 2020-11-24 01:56:41 --> Helper loaded: form_helper
INFO - 2020-11-24 01:56:41 --> Helper loaded: my_helper
INFO - 2020-11-24 01:56:41 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:56:41 --> Controller Class Initialized
DEBUG - 2020-11-24 01:56:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-24 01:56:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:56:41 --> Final output sent to browser
DEBUG - 2020-11-24 01:56:41 --> Total execution time: 0.1890
INFO - 2020-11-24 01:56:51 --> Config Class Initialized
INFO - 2020-11-24 01:56:51 --> Hooks Class Initialized
DEBUG - 2020-11-24 01:56:51 --> UTF-8 Support Enabled
INFO - 2020-11-24 01:56:51 --> Utf8 Class Initialized
INFO - 2020-11-24 01:56:51 --> URI Class Initialized
INFO - 2020-11-24 01:56:51 --> Router Class Initialized
INFO - 2020-11-24 01:56:51 --> Output Class Initialized
INFO - 2020-11-24 01:56:51 --> Security Class Initialized
DEBUG - 2020-11-24 01:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 01:56:51 --> Input Class Initialized
INFO - 2020-11-24 01:56:51 --> Language Class Initialized
INFO - 2020-11-24 01:56:51 --> Language Class Initialized
INFO - 2020-11-24 01:56:51 --> Config Class Initialized
INFO - 2020-11-24 01:56:51 --> Loader Class Initialized
INFO - 2020-11-24 01:56:51 --> Helper loaded: url_helper
INFO - 2020-11-24 01:56:51 --> Helper loaded: file_helper
INFO - 2020-11-24 01:56:51 --> Helper loaded: form_helper
INFO - 2020-11-24 01:56:51 --> Helper loaded: my_helper
INFO - 2020-11-24 01:56:51 --> Database Driver Class Initialized
DEBUG - 2020-11-24 01:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 01:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 01:56:51 --> Controller Class Initialized
DEBUG - 2020-11-24 01:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-24 01:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 01:56:51 --> Final output sent to browser
DEBUG - 2020-11-24 01:56:51 --> Total execution time: 0.1857
INFO - 2020-11-24 04:25:01 --> Config Class Initialized
INFO - 2020-11-24 04:25:02 --> Hooks Class Initialized
DEBUG - 2020-11-24 04:25:02 --> UTF-8 Support Enabled
INFO - 2020-11-24 04:25:02 --> Utf8 Class Initialized
INFO - 2020-11-24 04:25:02 --> URI Class Initialized
INFO - 2020-11-24 04:25:02 --> Router Class Initialized
INFO - 2020-11-24 04:25:02 --> Output Class Initialized
INFO - 2020-11-24 04:25:02 --> Security Class Initialized
DEBUG - 2020-11-24 04:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 04:25:02 --> Input Class Initialized
INFO - 2020-11-24 04:25:02 --> Language Class Initialized
INFO - 2020-11-24 04:25:02 --> Language Class Initialized
INFO - 2020-11-24 04:25:02 --> Config Class Initialized
INFO - 2020-11-24 04:25:02 --> Loader Class Initialized
INFO - 2020-11-24 04:25:02 --> Helper loaded: url_helper
INFO - 2020-11-24 04:25:02 --> Helper loaded: file_helper
INFO - 2020-11-24 04:25:02 --> Helper loaded: form_helper
INFO - 2020-11-24 04:25:02 --> Helper loaded: my_helper
INFO - 2020-11-24 04:25:02 --> Database Driver Class Initialized
DEBUG - 2020-11-24 04:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 04:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 04:25:02 --> Controller Class Initialized
DEBUG - 2020-11-24 04:25:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-24 04:25:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 04:25:02 --> Final output sent to browser
DEBUG - 2020-11-24 04:25:02 --> Total execution time: 0.7427
INFO - 2020-11-24 04:25:07 --> Config Class Initialized
INFO - 2020-11-24 04:25:07 --> Hooks Class Initialized
DEBUG - 2020-11-24 04:25:07 --> UTF-8 Support Enabled
INFO - 2020-11-24 04:25:07 --> Utf8 Class Initialized
INFO - 2020-11-24 04:25:07 --> URI Class Initialized
INFO - 2020-11-24 04:25:07 --> Router Class Initialized
INFO - 2020-11-24 04:25:07 --> Output Class Initialized
INFO - 2020-11-24 04:25:07 --> Security Class Initialized
DEBUG - 2020-11-24 04:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 04:25:07 --> Input Class Initialized
INFO - 2020-11-24 04:25:07 --> Language Class Initialized
INFO - 2020-11-24 04:25:07 --> Language Class Initialized
INFO - 2020-11-24 04:25:07 --> Config Class Initialized
INFO - 2020-11-24 04:25:07 --> Loader Class Initialized
INFO - 2020-11-24 04:25:07 --> Helper loaded: url_helper
INFO - 2020-11-24 04:25:07 --> Helper loaded: file_helper
INFO - 2020-11-24 04:25:07 --> Helper loaded: form_helper
INFO - 2020-11-24 04:25:07 --> Helper loaded: my_helper
INFO - 2020-11-24 04:25:07 --> Database Driver Class Initialized
DEBUG - 2020-11-24 04:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 04:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 04:25:07 --> Controller Class Initialized
DEBUG - 2020-11-24 04:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-24 04:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 04:25:07 --> Final output sent to browser
DEBUG - 2020-11-24 04:25:07 --> Total execution time: 0.2322
INFO - 2020-11-24 04:25:12 --> Config Class Initialized
INFO - 2020-11-24 04:25:12 --> Hooks Class Initialized
DEBUG - 2020-11-24 04:25:12 --> UTF-8 Support Enabled
INFO - 2020-11-24 04:25:12 --> Utf8 Class Initialized
INFO - 2020-11-24 04:25:12 --> URI Class Initialized
INFO - 2020-11-24 04:25:13 --> Router Class Initialized
INFO - 2020-11-24 04:25:13 --> Output Class Initialized
INFO - 2020-11-24 04:25:13 --> Security Class Initialized
DEBUG - 2020-11-24 04:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 04:25:13 --> Input Class Initialized
INFO - 2020-11-24 04:25:13 --> Language Class Initialized
INFO - 2020-11-24 04:25:13 --> Language Class Initialized
INFO - 2020-11-24 04:25:13 --> Config Class Initialized
INFO - 2020-11-24 04:25:13 --> Loader Class Initialized
INFO - 2020-11-24 04:25:13 --> Helper loaded: url_helper
INFO - 2020-11-24 04:25:13 --> Helper loaded: file_helper
INFO - 2020-11-24 04:25:13 --> Helper loaded: form_helper
INFO - 2020-11-24 04:25:13 --> Helper loaded: my_helper
INFO - 2020-11-24 04:25:13 --> Database Driver Class Initialized
DEBUG - 2020-11-24 04:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 04:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 04:25:13 --> Controller Class Initialized
INFO - 2020-11-24 04:25:13 --> Final output sent to browser
DEBUG - 2020-11-24 04:25:13 --> Total execution time: 0.1669
INFO - 2020-11-24 04:25:20 --> Config Class Initialized
INFO - 2020-11-24 04:25:20 --> Hooks Class Initialized
DEBUG - 2020-11-24 04:25:20 --> UTF-8 Support Enabled
INFO - 2020-11-24 04:25:20 --> Utf8 Class Initialized
INFO - 2020-11-24 04:25:20 --> URI Class Initialized
INFO - 2020-11-24 04:25:20 --> Router Class Initialized
INFO - 2020-11-24 04:25:20 --> Output Class Initialized
INFO - 2020-11-24 04:25:20 --> Security Class Initialized
DEBUG - 2020-11-24 04:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 04:25:20 --> Input Class Initialized
INFO - 2020-11-24 04:25:20 --> Language Class Initialized
INFO - 2020-11-24 04:25:20 --> Language Class Initialized
INFO - 2020-11-24 04:25:20 --> Config Class Initialized
INFO - 2020-11-24 04:25:20 --> Loader Class Initialized
INFO - 2020-11-24 04:25:20 --> Helper loaded: url_helper
INFO - 2020-11-24 04:25:20 --> Helper loaded: file_helper
INFO - 2020-11-24 04:25:20 --> Helper loaded: form_helper
INFO - 2020-11-24 04:25:20 --> Helper loaded: my_helper
INFO - 2020-11-24 04:25:20 --> Database Driver Class Initialized
DEBUG - 2020-11-24 04:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 04:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 04:25:20 --> Controller Class Initialized
INFO - 2020-11-24 04:25:20 --> Final output sent to browser
DEBUG - 2020-11-24 04:25:20 --> Total execution time: 0.2621
INFO - 2020-11-24 08:20:07 --> Config Class Initialized
INFO - 2020-11-24 08:20:07 --> Hooks Class Initialized
DEBUG - 2020-11-24 08:20:07 --> UTF-8 Support Enabled
INFO - 2020-11-24 08:20:07 --> Utf8 Class Initialized
INFO - 2020-11-24 08:20:07 --> URI Class Initialized
INFO - 2020-11-24 08:20:07 --> Router Class Initialized
INFO - 2020-11-24 08:20:07 --> Output Class Initialized
INFO - 2020-11-24 08:20:07 --> Security Class Initialized
DEBUG - 2020-11-24 08:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 08:20:07 --> Input Class Initialized
INFO - 2020-11-24 08:20:07 --> Language Class Initialized
INFO - 2020-11-24 08:20:07 --> Language Class Initialized
INFO - 2020-11-24 08:20:07 --> Config Class Initialized
INFO - 2020-11-24 08:20:07 --> Loader Class Initialized
INFO - 2020-11-24 08:20:07 --> Helper loaded: url_helper
INFO - 2020-11-24 08:20:07 --> Helper loaded: file_helper
INFO - 2020-11-24 08:20:07 --> Helper loaded: form_helper
INFO - 2020-11-24 08:20:07 --> Helper loaded: my_helper
INFO - 2020-11-24 08:20:07 --> Database Driver Class Initialized
DEBUG - 2020-11-24 08:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 08:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 08:20:07 --> Controller Class Initialized
INFO - 2020-11-24 08:20:07 --> Helper loaded: cookie_helper
INFO - 2020-11-24 08:20:07 --> Config Class Initialized
INFO - 2020-11-24 08:20:07 --> Hooks Class Initialized
DEBUG - 2020-11-24 08:20:07 --> UTF-8 Support Enabled
INFO - 2020-11-24 08:20:07 --> Utf8 Class Initialized
INFO - 2020-11-24 08:20:07 --> URI Class Initialized
INFO - 2020-11-24 08:20:07 --> Router Class Initialized
INFO - 2020-11-24 08:20:07 --> Output Class Initialized
INFO - 2020-11-24 08:20:07 --> Security Class Initialized
DEBUG - 2020-11-24 08:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 08:20:07 --> Input Class Initialized
INFO - 2020-11-24 08:20:07 --> Language Class Initialized
INFO - 2020-11-24 08:20:07 --> Language Class Initialized
INFO - 2020-11-24 08:20:07 --> Config Class Initialized
INFO - 2020-11-24 08:20:07 --> Loader Class Initialized
INFO - 2020-11-24 08:20:07 --> Helper loaded: url_helper
INFO - 2020-11-24 08:20:07 --> Helper loaded: file_helper
INFO - 2020-11-24 08:20:07 --> Helper loaded: form_helper
INFO - 2020-11-24 08:20:07 --> Helper loaded: my_helper
INFO - 2020-11-24 08:20:07 --> Database Driver Class Initialized
DEBUG - 2020-11-24 08:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 08:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 08:20:07 --> Controller Class Initialized
DEBUG - 2020-11-24 08:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-24 08:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 08:20:07 --> Final output sent to browser
DEBUG - 2020-11-24 08:20:07 --> Total execution time: 0.2081
INFO - 2020-11-24 08:20:12 --> Config Class Initialized
INFO - 2020-11-24 08:20:12 --> Hooks Class Initialized
DEBUG - 2020-11-24 08:20:12 --> UTF-8 Support Enabled
INFO - 2020-11-24 08:20:12 --> Utf8 Class Initialized
INFO - 2020-11-24 08:20:12 --> URI Class Initialized
INFO - 2020-11-24 08:20:12 --> Router Class Initialized
INFO - 2020-11-24 08:20:12 --> Output Class Initialized
INFO - 2020-11-24 08:20:12 --> Security Class Initialized
DEBUG - 2020-11-24 08:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 08:20:12 --> Input Class Initialized
INFO - 2020-11-24 08:20:12 --> Language Class Initialized
INFO - 2020-11-24 08:20:12 --> Language Class Initialized
INFO - 2020-11-24 08:20:12 --> Config Class Initialized
INFO - 2020-11-24 08:20:12 --> Loader Class Initialized
INFO - 2020-11-24 08:20:12 --> Helper loaded: url_helper
INFO - 2020-11-24 08:20:12 --> Helper loaded: file_helper
INFO - 2020-11-24 08:20:12 --> Helper loaded: form_helper
INFO - 2020-11-24 08:20:12 --> Helper loaded: my_helper
INFO - 2020-11-24 08:20:12 --> Database Driver Class Initialized
DEBUG - 2020-11-24 08:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 08:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 08:20:12 --> Controller Class Initialized
INFO - 2020-11-24 08:20:12 --> Helper loaded: cookie_helper
INFO - 2020-11-24 08:20:12 --> Final output sent to browser
DEBUG - 2020-11-24 08:20:12 --> Total execution time: 0.1885
INFO - 2020-11-24 08:20:12 --> Config Class Initialized
INFO - 2020-11-24 08:20:12 --> Hooks Class Initialized
DEBUG - 2020-11-24 08:20:12 --> UTF-8 Support Enabled
INFO - 2020-11-24 08:20:12 --> Utf8 Class Initialized
INFO - 2020-11-24 08:20:12 --> URI Class Initialized
INFO - 2020-11-24 08:20:12 --> Router Class Initialized
INFO - 2020-11-24 08:20:12 --> Output Class Initialized
INFO - 2020-11-24 08:20:12 --> Security Class Initialized
DEBUG - 2020-11-24 08:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 08:20:13 --> Input Class Initialized
INFO - 2020-11-24 08:20:13 --> Language Class Initialized
INFO - 2020-11-24 08:20:13 --> Language Class Initialized
INFO - 2020-11-24 08:20:13 --> Config Class Initialized
INFO - 2020-11-24 08:20:13 --> Loader Class Initialized
INFO - 2020-11-24 08:20:13 --> Helper loaded: url_helper
INFO - 2020-11-24 08:20:13 --> Helper loaded: file_helper
INFO - 2020-11-24 08:20:13 --> Helper loaded: form_helper
INFO - 2020-11-24 08:20:13 --> Helper loaded: my_helper
INFO - 2020-11-24 08:20:13 --> Database Driver Class Initialized
DEBUG - 2020-11-24 08:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 08:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 08:20:13 --> Controller Class Initialized
DEBUG - 2020-11-24 08:20:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-24 08:20:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 08:20:13 --> Final output sent to browser
DEBUG - 2020-11-24 08:20:13 --> Total execution time: 0.3009
INFO - 2020-11-24 09:51:58 --> Config Class Initialized
INFO - 2020-11-24 09:51:58 --> Hooks Class Initialized
DEBUG - 2020-11-24 09:51:58 --> UTF-8 Support Enabled
INFO - 2020-11-24 09:51:58 --> Utf8 Class Initialized
INFO - 2020-11-24 09:51:58 --> URI Class Initialized
DEBUG - 2020-11-24 09:51:58 --> No URI present. Default controller set.
INFO - 2020-11-24 09:51:58 --> Router Class Initialized
INFO - 2020-11-24 09:51:58 --> Output Class Initialized
INFO - 2020-11-24 09:51:58 --> Security Class Initialized
DEBUG - 2020-11-24 09:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 09:51:58 --> Input Class Initialized
INFO - 2020-11-24 09:51:58 --> Language Class Initialized
INFO - 2020-11-24 09:51:58 --> Language Class Initialized
INFO - 2020-11-24 09:51:58 --> Config Class Initialized
INFO - 2020-11-24 09:51:58 --> Loader Class Initialized
INFO - 2020-11-24 09:51:58 --> Helper loaded: url_helper
INFO - 2020-11-24 09:51:58 --> Helper loaded: file_helper
INFO - 2020-11-24 09:51:58 --> Helper loaded: form_helper
INFO - 2020-11-24 09:51:58 --> Helper loaded: my_helper
INFO - 2020-11-24 09:51:58 --> Database Driver Class Initialized
DEBUG - 2020-11-24 09:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 09:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 09:51:58 --> Controller Class Initialized
INFO - 2020-11-24 09:51:58 --> Config Class Initialized
INFO - 2020-11-24 09:51:58 --> Hooks Class Initialized
DEBUG - 2020-11-24 09:51:58 --> UTF-8 Support Enabled
INFO - 2020-11-24 09:51:58 --> Utf8 Class Initialized
INFO - 2020-11-24 09:51:58 --> URI Class Initialized
INFO - 2020-11-24 09:51:58 --> Router Class Initialized
INFO - 2020-11-24 09:51:58 --> Output Class Initialized
INFO - 2020-11-24 09:51:58 --> Security Class Initialized
DEBUG - 2020-11-24 09:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-24 09:51:58 --> Input Class Initialized
INFO - 2020-11-24 09:51:58 --> Language Class Initialized
INFO - 2020-11-24 09:51:58 --> Language Class Initialized
INFO - 2020-11-24 09:51:58 --> Config Class Initialized
INFO - 2020-11-24 09:51:58 --> Loader Class Initialized
INFO - 2020-11-24 09:51:58 --> Helper loaded: url_helper
INFO - 2020-11-24 09:51:58 --> Helper loaded: file_helper
INFO - 2020-11-24 09:51:58 --> Helper loaded: form_helper
INFO - 2020-11-24 09:51:58 --> Helper loaded: my_helper
INFO - 2020-11-24 09:51:58 --> Database Driver Class Initialized
DEBUG - 2020-11-24 09:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-24 09:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-24 09:51:58 --> Controller Class Initialized
DEBUG - 2020-11-24 09:51:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-24 09:51:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-24 09:51:58 --> Final output sent to browser
DEBUG - 2020-11-24 09:51:58 --> Total execution time: 0.2114
