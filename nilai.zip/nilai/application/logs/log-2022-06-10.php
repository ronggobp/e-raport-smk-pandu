<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-10 04:54:52 --> Config Class Initialized
INFO - 2022-06-10 04:54:52 --> Hooks Class Initialized
DEBUG - 2022-06-10 04:54:53 --> UTF-8 Support Enabled
INFO - 2022-06-10 04:54:53 --> Utf8 Class Initialized
INFO - 2022-06-10 04:54:53 --> URI Class Initialized
INFO - 2022-06-10 04:54:53 --> Router Class Initialized
INFO - 2022-06-10 04:54:53 --> Output Class Initialized
INFO - 2022-06-10 04:54:53 --> Security Class Initialized
DEBUG - 2022-06-10 04:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 04:54:53 --> Input Class Initialized
INFO - 2022-06-10 04:54:53 --> Language Class Initialized
INFO - 2022-06-10 04:54:53 --> Language Class Initialized
INFO - 2022-06-10 04:54:53 --> Config Class Initialized
INFO - 2022-06-10 04:54:53 --> Loader Class Initialized
INFO - 2022-06-10 04:54:53 --> Helper loaded: url_helper
INFO - 2022-06-10 04:54:53 --> Helper loaded: file_helper
INFO - 2022-06-10 04:54:53 --> Helper loaded: form_helper
INFO - 2022-06-10 04:54:53 --> Helper loaded: my_helper
INFO - 2022-06-10 04:54:53 --> Database Driver Class Initialized
DEBUG - 2022-06-10 04:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 04:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 04:54:53 --> Controller Class Initialized
DEBUG - 2022-06-10 04:54:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-06-10 04:54:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-10 04:54:53 --> Final output sent to browser
DEBUG - 2022-06-10 04:54:53 --> Total execution time: 0.6523
INFO - 2022-06-10 04:54:53 --> Config Class Initialized
INFO - 2022-06-10 04:54:53 --> Hooks Class Initialized
DEBUG - 2022-06-10 04:54:53 --> UTF-8 Support Enabled
INFO - 2022-06-10 04:54:53 --> Utf8 Class Initialized
INFO - 2022-06-10 04:54:53 --> URI Class Initialized
INFO - 2022-06-10 04:54:53 --> Router Class Initialized
INFO - 2022-06-10 04:54:53 --> Output Class Initialized
INFO - 2022-06-10 04:54:53 --> Security Class Initialized
DEBUG - 2022-06-10 04:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 04:54:53 --> Input Class Initialized
INFO - 2022-06-10 04:54:53 --> Language Class Initialized
INFO - 2022-06-10 04:54:53 --> Language Class Initialized
INFO - 2022-06-10 04:54:53 --> Config Class Initialized
INFO - 2022-06-10 04:54:53 --> Loader Class Initialized
INFO - 2022-06-10 04:54:53 --> Helper loaded: url_helper
INFO - 2022-06-10 04:54:53 --> Helper loaded: file_helper
INFO - 2022-06-10 04:54:53 --> Helper loaded: form_helper
INFO - 2022-06-10 04:54:53 --> Helper loaded: my_helper
INFO - 2022-06-10 04:54:53 --> Database Driver Class Initialized
DEBUG - 2022-06-10 04:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 04:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 04:54:53 --> Controller Class Initialized
INFO - 2022-06-10 04:54:54 --> Config Class Initialized
INFO - 2022-06-10 04:54:54 --> Hooks Class Initialized
DEBUG - 2022-06-10 04:54:54 --> UTF-8 Support Enabled
INFO - 2022-06-10 04:54:54 --> Utf8 Class Initialized
INFO - 2022-06-10 04:54:54 --> URI Class Initialized
INFO - 2022-06-10 04:54:54 --> Router Class Initialized
INFO - 2022-06-10 04:54:54 --> Output Class Initialized
INFO - 2022-06-10 04:54:54 --> Security Class Initialized
DEBUG - 2022-06-10 04:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 04:54:54 --> Input Class Initialized
INFO - 2022-06-10 04:54:54 --> Language Class Initialized
INFO - 2022-06-10 04:54:54 --> Language Class Initialized
INFO - 2022-06-10 04:54:54 --> Config Class Initialized
INFO - 2022-06-10 04:54:54 --> Loader Class Initialized
INFO - 2022-06-10 04:54:54 --> Helper loaded: url_helper
INFO - 2022-06-10 04:54:54 --> Helper loaded: file_helper
INFO - 2022-06-10 04:54:54 --> Helper loaded: form_helper
INFO - 2022-06-10 04:54:54 --> Helper loaded: my_helper
INFO - 2022-06-10 04:54:54 --> Database Driver Class Initialized
DEBUG - 2022-06-10 04:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 04:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 04:54:54 --> Controller Class Initialized
DEBUG - 2022-06-10 04:54:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-10 04:54:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-10 04:54:54 --> Final output sent to browser
DEBUG - 2022-06-10 04:54:54 --> Total execution time: 0.0987
INFO - 2022-06-10 05:09:01 --> Config Class Initialized
INFO - 2022-06-10 05:09:01 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:09:01 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:09:01 --> Utf8 Class Initialized
INFO - 2022-06-10 05:09:01 --> URI Class Initialized
INFO - 2022-06-10 05:09:01 --> Router Class Initialized
INFO - 2022-06-10 05:09:01 --> Output Class Initialized
INFO - 2022-06-10 05:09:01 --> Security Class Initialized
DEBUG - 2022-06-10 05:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:09:01 --> Input Class Initialized
INFO - 2022-06-10 05:09:01 --> Language Class Initialized
INFO - 2022-06-10 05:09:01 --> Language Class Initialized
INFO - 2022-06-10 05:09:01 --> Config Class Initialized
INFO - 2022-06-10 05:09:01 --> Loader Class Initialized
INFO - 2022-06-10 05:09:01 --> Helper loaded: url_helper
INFO - 2022-06-10 05:09:01 --> Helper loaded: file_helper
INFO - 2022-06-10 05:09:01 --> Helper loaded: form_helper
INFO - 2022-06-10 05:09:01 --> Helper loaded: my_helper
INFO - 2022-06-10 05:09:01 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:09:01 --> Controller Class Initialized
ERROR - 2022-06-10 05:09:01 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '443' AND tasm = '20212'
INFO - 2022-06-10 05:09:01 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:10:04 --> Config Class Initialized
INFO - 2022-06-10 05:10:04 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:10:04 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:10:04 --> Utf8 Class Initialized
INFO - 2022-06-10 05:10:04 --> URI Class Initialized
INFO - 2022-06-10 05:10:04 --> Router Class Initialized
INFO - 2022-06-10 05:10:04 --> Output Class Initialized
INFO - 2022-06-10 05:10:04 --> Security Class Initialized
DEBUG - 2022-06-10 05:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:10:04 --> Input Class Initialized
INFO - 2022-06-10 05:10:04 --> Language Class Initialized
INFO - 2022-06-10 05:10:04 --> Language Class Initialized
INFO - 2022-06-10 05:10:04 --> Config Class Initialized
INFO - 2022-06-10 05:10:04 --> Loader Class Initialized
INFO - 2022-06-10 05:10:04 --> Helper loaded: url_helper
INFO - 2022-06-10 05:10:04 --> Helper loaded: file_helper
INFO - 2022-06-10 05:10:04 --> Helper loaded: form_helper
INFO - 2022-06-10 05:10:04 --> Helper loaded: my_helper
INFO - 2022-06-10 05:10:04 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:10:04 --> Controller Class Initialized
ERROR - 2022-06-10 05:10:04 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '454' AND tasm = '20212'
INFO - 2022-06-10 05:10:04 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:11:17 --> Config Class Initialized
INFO - 2022-06-10 05:11:17 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:11:17 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:11:17 --> Utf8 Class Initialized
INFO - 2022-06-10 05:11:17 --> URI Class Initialized
INFO - 2022-06-10 05:11:17 --> Router Class Initialized
INFO - 2022-06-10 05:11:17 --> Output Class Initialized
INFO - 2022-06-10 05:11:17 --> Security Class Initialized
DEBUG - 2022-06-10 05:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:11:17 --> Input Class Initialized
INFO - 2022-06-10 05:11:17 --> Language Class Initialized
INFO - 2022-06-10 05:11:17 --> Language Class Initialized
INFO - 2022-06-10 05:11:17 --> Config Class Initialized
INFO - 2022-06-10 05:11:17 --> Loader Class Initialized
INFO - 2022-06-10 05:11:17 --> Helper loaded: url_helper
INFO - 2022-06-10 05:11:17 --> Helper loaded: file_helper
INFO - 2022-06-10 05:11:17 --> Helper loaded: form_helper
INFO - 2022-06-10 05:11:17 --> Helper loaded: my_helper
INFO - 2022-06-10 05:11:17 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:11:17 --> Controller Class Initialized
ERROR - 2022-06-10 05:11:17 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '466' AND tasm = '20212'
INFO - 2022-06-10 05:11:17 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:11:28 --> Config Class Initialized
INFO - 2022-06-10 05:11:28 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:11:28 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:11:28 --> Utf8 Class Initialized
INFO - 2022-06-10 05:11:28 --> URI Class Initialized
INFO - 2022-06-10 05:11:28 --> Router Class Initialized
INFO - 2022-06-10 05:11:28 --> Output Class Initialized
INFO - 2022-06-10 05:11:28 --> Security Class Initialized
DEBUG - 2022-06-10 05:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:11:28 --> Input Class Initialized
INFO - 2022-06-10 05:11:28 --> Language Class Initialized
INFO - 2022-06-10 05:11:28 --> Language Class Initialized
INFO - 2022-06-10 05:11:28 --> Config Class Initialized
INFO - 2022-06-10 05:11:28 --> Loader Class Initialized
INFO - 2022-06-10 05:11:28 --> Helper loaded: url_helper
INFO - 2022-06-10 05:11:28 --> Helper loaded: file_helper
INFO - 2022-06-10 05:11:28 --> Helper loaded: form_helper
INFO - 2022-06-10 05:11:28 --> Helper loaded: my_helper
INFO - 2022-06-10 05:11:28 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:11:28 --> Controller Class Initialized
ERROR - 2022-06-10 05:11:28 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '470' AND tasm = '20212'
INFO - 2022-06-10 05:11:28 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:12:07 --> Config Class Initialized
INFO - 2022-06-10 05:12:07 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:12:07 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:12:07 --> Utf8 Class Initialized
INFO - 2022-06-10 05:12:07 --> URI Class Initialized
INFO - 2022-06-10 05:12:07 --> Router Class Initialized
INFO - 2022-06-10 05:12:07 --> Output Class Initialized
INFO - 2022-06-10 05:12:07 --> Security Class Initialized
DEBUG - 2022-06-10 05:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:12:07 --> Input Class Initialized
INFO - 2022-06-10 05:12:07 --> Language Class Initialized
INFO - 2022-06-10 05:12:07 --> Language Class Initialized
INFO - 2022-06-10 05:12:07 --> Config Class Initialized
INFO - 2022-06-10 05:12:07 --> Loader Class Initialized
INFO - 2022-06-10 05:12:07 --> Helper loaded: url_helper
INFO - 2022-06-10 05:12:07 --> Helper loaded: file_helper
INFO - 2022-06-10 05:12:07 --> Helper loaded: form_helper
INFO - 2022-06-10 05:12:07 --> Helper loaded: my_helper
INFO - 2022-06-10 05:12:07 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:12:07 --> Controller Class Initialized
DEBUG - 2022-06-10 05:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-10 05:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-10 05:12:07 --> Final output sent to browser
DEBUG - 2022-06-10 05:12:07 --> Total execution time: 0.0720
INFO - 2022-06-10 05:15:28 --> Config Class Initialized
INFO - 2022-06-10 05:15:28 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:15:28 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:15:28 --> Utf8 Class Initialized
INFO - 2022-06-10 05:15:28 --> URI Class Initialized
INFO - 2022-06-10 05:15:28 --> Router Class Initialized
INFO - 2022-06-10 05:15:28 --> Output Class Initialized
INFO - 2022-06-10 05:15:28 --> Security Class Initialized
DEBUG - 2022-06-10 05:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:15:28 --> Input Class Initialized
INFO - 2022-06-10 05:15:28 --> Language Class Initialized
INFO - 2022-06-10 05:15:28 --> Language Class Initialized
INFO - 2022-06-10 05:15:28 --> Config Class Initialized
INFO - 2022-06-10 05:15:28 --> Loader Class Initialized
INFO - 2022-06-10 05:15:28 --> Helper loaded: url_helper
INFO - 2022-06-10 05:15:28 --> Helper loaded: file_helper
INFO - 2022-06-10 05:15:28 --> Helper loaded: form_helper
INFO - 2022-06-10 05:15:28 --> Helper loaded: my_helper
INFO - 2022-06-10 05:15:28 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:15:28 --> Controller Class Initialized
ERROR - 2022-06-10 05:15:28 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '425' AND tasm = '20212'
INFO - 2022-06-10 05:15:28 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:15:30 --> Config Class Initialized
INFO - 2022-06-10 05:15:30 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:15:30 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:15:30 --> Utf8 Class Initialized
INFO - 2022-06-10 05:15:30 --> URI Class Initialized
INFO - 2022-06-10 05:15:30 --> Router Class Initialized
INFO - 2022-06-10 05:15:30 --> Output Class Initialized
INFO - 2022-06-10 05:15:30 --> Security Class Initialized
DEBUG - 2022-06-10 05:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:15:30 --> Input Class Initialized
INFO - 2022-06-10 05:15:30 --> Language Class Initialized
INFO - 2022-06-10 05:15:30 --> Language Class Initialized
INFO - 2022-06-10 05:15:30 --> Config Class Initialized
INFO - 2022-06-10 05:15:30 --> Loader Class Initialized
INFO - 2022-06-10 05:15:30 --> Helper loaded: url_helper
INFO - 2022-06-10 05:15:30 --> Helper loaded: file_helper
INFO - 2022-06-10 05:15:30 --> Helper loaded: form_helper
INFO - 2022-06-10 05:15:30 --> Helper loaded: my_helper
INFO - 2022-06-10 05:15:30 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:15:30 --> Controller Class Initialized
ERROR - 2022-06-10 05:15:30 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '413' AND tasm = '20212'
INFO - 2022-06-10 05:15:30 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:15:40 --> Config Class Initialized
INFO - 2022-06-10 05:15:40 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:15:40 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:15:40 --> Utf8 Class Initialized
INFO - 2022-06-10 05:15:40 --> URI Class Initialized
INFO - 2022-06-10 05:15:40 --> Router Class Initialized
INFO - 2022-06-10 05:15:40 --> Output Class Initialized
INFO - 2022-06-10 05:15:40 --> Security Class Initialized
DEBUG - 2022-06-10 05:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:15:40 --> Input Class Initialized
INFO - 2022-06-10 05:15:40 --> Language Class Initialized
INFO - 2022-06-10 05:15:40 --> Language Class Initialized
INFO - 2022-06-10 05:15:40 --> Config Class Initialized
INFO - 2022-06-10 05:15:40 --> Loader Class Initialized
INFO - 2022-06-10 05:15:40 --> Helper loaded: url_helper
INFO - 2022-06-10 05:15:40 --> Helper loaded: file_helper
INFO - 2022-06-10 05:15:40 --> Helper loaded: form_helper
INFO - 2022-06-10 05:15:40 --> Helper loaded: my_helper
INFO - 2022-06-10 05:15:40 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:15:40 --> Controller Class Initialized
ERROR - 2022-06-10 05:15:40 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '426' AND tasm = '20212'
INFO - 2022-06-10 05:15:40 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:16:23 --> Config Class Initialized
INFO - 2022-06-10 05:16:23 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:16:23 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:16:23 --> Utf8 Class Initialized
INFO - 2022-06-10 05:16:23 --> URI Class Initialized
INFO - 2022-06-10 05:16:23 --> Router Class Initialized
INFO - 2022-06-10 05:16:23 --> Output Class Initialized
INFO - 2022-06-10 05:16:23 --> Security Class Initialized
DEBUG - 2022-06-10 05:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:16:23 --> Input Class Initialized
INFO - 2022-06-10 05:16:23 --> Language Class Initialized
INFO - 2022-06-10 05:16:23 --> Language Class Initialized
INFO - 2022-06-10 05:16:23 --> Config Class Initialized
INFO - 2022-06-10 05:16:23 --> Loader Class Initialized
INFO - 2022-06-10 05:16:23 --> Helper loaded: url_helper
INFO - 2022-06-10 05:16:23 --> Helper loaded: file_helper
INFO - 2022-06-10 05:16:23 --> Helper loaded: form_helper
INFO - 2022-06-10 05:16:23 --> Helper loaded: my_helper
INFO - 2022-06-10 05:16:23 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:16:23 --> Controller Class Initialized
ERROR - 2022-06-10 05:16:23 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '427' AND tasm = '20212'
INFO - 2022-06-10 05:16:23 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:21:26 --> Config Class Initialized
INFO - 2022-06-10 05:21:26 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:21:26 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:21:26 --> Utf8 Class Initialized
INFO - 2022-06-10 05:21:26 --> URI Class Initialized
INFO - 2022-06-10 05:21:26 --> Router Class Initialized
INFO - 2022-06-10 05:21:26 --> Output Class Initialized
INFO - 2022-06-10 05:21:26 --> Security Class Initialized
DEBUG - 2022-06-10 05:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:21:26 --> Input Class Initialized
INFO - 2022-06-10 05:21:26 --> Language Class Initialized
INFO - 2022-06-10 05:21:26 --> Language Class Initialized
INFO - 2022-06-10 05:21:26 --> Config Class Initialized
INFO - 2022-06-10 05:21:26 --> Loader Class Initialized
INFO - 2022-06-10 05:21:26 --> Helper loaded: url_helper
INFO - 2022-06-10 05:21:26 --> Helper loaded: file_helper
INFO - 2022-06-10 05:21:26 --> Helper loaded: form_helper
INFO - 2022-06-10 05:21:26 --> Helper loaded: my_helper
INFO - 2022-06-10 05:21:26 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:21:26 --> Controller Class Initialized
ERROR - 2022-06-10 05:21:26 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '414' AND tasm = '20212'
INFO - 2022-06-10 05:21:26 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:26:49 --> Config Class Initialized
INFO - 2022-06-10 05:26:49 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:26:49 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:26:49 --> Utf8 Class Initialized
INFO - 2022-06-10 05:26:49 --> URI Class Initialized
INFO - 2022-06-10 05:26:49 --> Router Class Initialized
INFO - 2022-06-10 05:26:49 --> Output Class Initialized
INFO - 2022-06-10 05:26:49 --> Security Class Initialized
DEBUG - 2022-06-10 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:26:49 --> Input Class Initialized
INFO - 2022-06-10 05:26:49 --> Language Class Initialized
INFO - 2022-06-10 05:26:49 --> Language Class Initialized
INFO - 2022-06-10 05:26:49 --> Config Class Initialized
INFO - 2022-06-10 05:26:49 --> Loader Class Initialized
INFO - 2022-06-10 05:26:49 --> Helper loaded: url_helper
INFO - 2022-06-10 05:26:49 --> Helper loaded: file_helper
INFO - 2022-06-10 05:26:49 --> Helper loaded: form_helper
INFO - 2022-06-10 05:26:49 --> Helper loaded: my_helper
INFO - 2022-06-10 05:26:49 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:26:49 --> Controller Class Initialized
ERROR - 2022-06-10 05:26:49 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '415' AND tasm = '20212'
INFO - 2022-06-10 05:26:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:26:51 --> Config Class Initialized
INFO - 2022-06-10 05:26:51 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:26:51 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:26:51 --> Utf8 Class Initialized
INFO - 2022-06-10 05:26:51 --> URI Class Initialized
INFO - 2022-06-10 05:26:51 --> Router Class Initialized
INFO - 2022-06-10 05:26:51 --> Output Class Initialized
INFO - 2022-06-10 05:26:51 --> Security Class Initialized
DEBUG - 2022-06-10 05:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:26:51 --> Input Class Initialized
INFO - 2022-06-10 05:26:51 --> Language Class Initialized
INFO - 2022-06-10 05:26:51 --> Language Class Initialized
INFO - 2022-06-10 05:26:51 --> Config Class Initialized
INFO - 2022-06-10 05:26:51 --> Loader Class Initialized
INFO - 2022-06-10 05:26:51 --> Helper loaded: url_helper
INFO - 2022-06-10 05:26:51 --> Helper loaded: file_helper
INFO - 2022-06-10 05:26:51 --> Helper loaded: form_helper
INFO - 2022-06-10 05:26:51 --> Helper loaded: my_helper
INFO - 2022-06-10 05:26:51 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:26:51 --> Controller Class Initialized
ERROR - 2022-06-10 05:26:51 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '428' AND tasm = '20212'
INFO - 2022-06-10 05:26:51 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:26:59 --> Config Class Initialized
INFO - 2022-06-10 05:26:59 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:26:59 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:26:59 --> Utf8 Class Initialized
INFO - 2022-06-10 05:26:59 --> URI Class Initialized
INFO - 2022-06-10 05:26:59 --> Router Class Initialized
INFO - 2022-06-10 05:26:59 --> Output Class Initialized
INFO - 2022-06-10 05:26:59 --> Security Class Initialized
DEBUG - 2022-06-10 05:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:26:59 --> Input Class Initialized
INFO - 2022-06-10 05:26:59 --> Language Class Initialized
INFO - 2022-06-10 05:26:59 --> Language Class Initialized
INFO - 2022-06-10 05:26:59 --> Config Class Initialized
INFO - 2022-06-10 05:26:59 --> Loader Class Initialized
INFO - 2022-06-10 05:26:59 --> Helper loaded: url_helper
INFO - 2022-06-10 05:26:59 --> Helper loaded: file_helper
INFO - 2022-06-10 05:26:59 --> Helper loaded: form_helper
INFO - 2022-06-10 05:26:59 --> Helper loaded: my_helper
INFO - 2022-06-10 05:26:59 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:26:59 --> Controller Class Initialized
ERROR - 2022-06-10 05:26:59 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '429' AND tasm = '20212'
INFO - 2022-06-10 05:26:59 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:01 --> Config Class Initialized
INFO - 2022-06-10 05:27:01 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:01 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:01 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:01 --> URI Class Initialized
INFO - 2022-06-10 05:27:01 --> Router Class Initialized
INFO - 2022-06-10 05:27:01 --> Output Class Initialized
INFO - 2022-06-10 05:27:01 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:01 --> Input Class Initialized
INFO - 2022-06-10 05:27:01 --> Language Class Initialized
INFO - 2022-06-10 05:27:01 --> Language Class Initialized
INFO - 2022-06-10 05:27:01 --> Config Class Initialized
INFO - 2022-06-10 05:27:01 --> Loader Class Initialized
INFO - 2022-06-10 05:27:01 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:01 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:01 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:01 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:01 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:01 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:01 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '430' AND tasm = '20212'
INFO - 2022-06-10 05:27:01 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:12 --> Config Class Initialized
INFO - 2022-06-10 05:27:12 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:12 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:12 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:12 --> URI Class Initialized
INFO - 2022-06-10 05:27:12 --> Router Class Initialized
INFO - 2022-06-10 05:27:12 --> Output Class Initialized
INFO - 2022-06-10 05:27:12 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:12 --> Input Class Initialized
INFO - 2022-06-10 05:27:12 --> Language Class Initialized
INFO - 2022-06-10 05:27:12 --> Language Class Initialized
INFO - 2022-06-10 05:27:12 --> Config Class Initialized
INFO - 2022-06-10 05:27:12 --> Loader Class Initialized
INFO - 2022-06-10 05:27:12 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:12 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:12 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:12 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:12 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:12 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:12 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '431' AND tasm = '20212'
INFO - 2022-06-10 05:27:12 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:14 --> Config Class Initialized
INFO - 2022-06-10 05:27:14 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:14 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:14 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:14 --> URI Class Initialized
INFO - 2022-06-10 05:27:14 --> Router Class Initialized
INFO - 2022-06-10 05:27:14 --> Output Class Initialized
INFO - 2022-06-10 05:27:14 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:14 --> Input Class Initialized
INFO - 2022-06-10 05:27:14 --> Language Class Initialized
INFO - 2022-06-10 05:27:14 --> Language Class Initialized
INFO - 2022-06-10 05:27:14 --> Config Class Initialized
INFO - 2022-06-10 05:27:14 --> Loader Class Initialized
INFO - 2022-06-10 05:27:14 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:14 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:14 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:14 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:14 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:14 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:14 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '416' AND tasm = '20212'
INFO - 2022-06-10 05:27:14 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:16 --> Config Class Initialized
INFO - 2022-06-10 05:27:16 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:16 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:16 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:16 --> URI Class Initialized
INFO - 2022-06-10 05:27:16 --> Router Class Initialized
INFO - 2022-06-10 05:27:16 --> Output Class Initialized
INFO - 2022-06-10 05:27:16 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:16 --> Input Class Initialized
INFO - 2022-06-10 05:27:16 --> Language Class Initialized
INFO - 2022-06-10 05:27:16 --> Language Class Initialized
INFO - 2022-06-10 05:27:16 --> Config Class Initialized
INFO - 2022-06-10 05:27:16 --> Loader Class Initialized
INFO - 2022-06-10 05:27:16 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:16 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:16 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:16 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:16 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:16 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:16 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '417' AND tasm = '20212'
INFO - 2022-06-10 05:27:16 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:18 --> Config Class Initialized
INFO - 2022-06-10 05:27:18 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:18 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:18 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:18 --> URI Class Initialized
INFO - 2022-06-10 05:27:18 --> Router Class Initialized
INFO - 2022-06-10 05:27:18 --> Output Class Initialized
INFO - 2022-06-10 05:27:18 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:18 --> Input Class Initialized
INFO - 2022-06-10 05:27:18 --> Language Class Initialized
INFO - 2022-06-10 05:27:18 --> Language Class Initialized
INFO - 2022-06-10 05:27:18 --> Config Class Initialized
INFO - 2022-06-10 05:27:18 --> Loader Class Initialized
INFO - 2022-06-10 05:27:18 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:18 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:18 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:18 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:18 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:18 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:18 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '418' AND tasm = '20212'
INFO - 2022-06-10 05:27:18 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:20 --> Config Class Initialized
INFO - 2022-06-10 05:27:20 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:20 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:20 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:20 --> URI Class Initialized
INFO - 2022-06-10 05:27:20 --> Router Class Initialized
INFO - 2022-06-10 05:27:20 --> Output Class Initialized
INFO - 2022-06-10 05:27:20 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:20 --> Input Class Initialized
INFO - 2022-06-10 05:27:20 --> Language Class Initialized
INFO - 2022-06-10 05:27:20 --> Language Class Initialized
INFO - 2022-06-10 05:27:20 --> Config Class Initialized
INFO - 2022-06-10 05:27:20 --> Loader Class Initialized
INFO - 2022-06-10 05:27:20 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:20 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:20 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:20 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:20 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:20 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:20 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '432' AND tasm = '20212'
INFO - 2022-06-10 05:27:20 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:24 --> Config Class Initialized
INFO - 2022-06-10 05:27:24 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:24 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:24 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:24 --> URI Class Initialized
INFO - 2022-06-10 05:27:24 --> Router Class Initialized
INFO - 2022-06-10 05:27:24 --> Output Class Initialized
INFO - 2022-06-10 05:27:24 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:24 --> Input Class Initialized
INFO - 2022-06-10 05:27:24 --> Language Class Initialized
INFO - 2022-06-10 05:27:24 --> Language Class Initialized
INFO - 2022-06-10 05:27:24 --> Config Class Initialized
INFO - 2022-06-10 05:27:24 --> Loader Class Initialized
INFO - 2022-06-10 05:27:24 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:24 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:24 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:24 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:24 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:24 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:24 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '419' AND tasm = '20212'
INFO - 2022-06-10 05:27:24 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:33 --> Config Class Initialized
INFO - 2022-06-10 05:27:33 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:33 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:33 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:33 --> URI Class Initialized
INFO - 2022-06-10 05:27:33 --> Router Class Initialized
INFO - 2022-06-10 05:27:33 --> Output Class Initialized
INFO - 2022-06-10 05:27:33 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:33 --> Input Class Initialized
INFO - 2022-06-10 05:27:33 --> Language Class Initialized
INFO - 2022-06-10 05:27:33 --> Language Class Initialized
INFO - 2022-06-10 05:27:33 --> Config Class Initialized
INFO - 2022-06-10 05:27:33 --> Loader Class Initialized
INFO - 2022-06-10 05:27:33 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:33 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:33 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:33 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:33 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:33 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:33 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '433' AND tasm = '20212'
INFO - 2022-06-10 05:27:33 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:27:35 --> Config Class Initialized
INFO - 2022-06-10 05:27:35 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:27:35 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:27:35 --> Utf8 Class Initialized
INFO - 2022-06-10 05:27:35 --> URI Class Initialized
INFO - 2022-06-10 05:27:35 --> Router Class Initialized
INFO - 2022-06-10 05:27:35 --> Output Class Initialized
INFO - 2022-06-10 05:27:35 --> Security Class Initialized
DEBUG - 2022-06-10 05:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:27:35 --> Input Class Initialized
INFO - 2022-06-10 05:27:35 --> Language Class Initialized
INFO - 2022-06-10 05:27:35 --> Language Class Initialized
INFO - 2022-06-10 05:27:35 --> Config Class Initialized
INFO - 2022-06-10 05:27:35 --> Loader Class Initialized
INFO - 2022-06-10 05:27:35 --> Helper loaded: url_helper
INFO - 2022-06-10 05:27:35 --> Helper loaded: file_helper
INFO - 2022-06-10 05:27:35 --> Helper loaded: form_helper
INFO - 2022-06-10 05:27:35 --> Helper loaded: my_helper
INFO - 2022-06-10 05:27:35 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:27:35 --> Controller Class Initialized
ERROR - 2022-06-10 05:27:35 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '434' AND tasm = '20212'
INFO - 2022-06-10 05:27:35 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:28:20 --> Config Class Initialized
INFO - 2022-06-10 05:28:20 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:28:20 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:28:20 --> Utf8 Class Initialized
INFO - 2022-06-10 05:28:20 --> URI Class Initialized
INFO - 2022-06-10 05:28:20 --> Router Class Initialized
INFO - 2022-06-10 05:28:20 --> Output Class Initialized
INFO - 2022-06-10 05:28:20 --> Security Class Initialized
DEBUG - 2022-06-10 05:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:28:20 --> Input Class Initialized
INFO - 2022-06-10 05:28:20 --> Language Class Initialized
INFO - 2022-06-10 05:28:20 --> Language Class Initialized
INFO - 2022-06-10 05:28:20 --> Config Class Initialized
INFO - 2022-06-10 05:28:20 --> Loader Class Initialized
INFO - 2022-06-10 05:28:20 --> Helper loaded: url_helper
INFO - 2022-06-10 05:28:20 --> Helper loaded: file_helper
INFO - 2022-06-10 05:28:20 --> Helper loaded: form_helper
INFO - 2022-06-10 05:28:20 --> Helper loaded: my_helper
INFO - 2022-06-10 05:28:20 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:28:20 --> Controller Class Initialized
ERROR - 2022-06-10 05:28:20 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '435' AND tasm = '20212'
INFO - 2022-06-10 05:28:20 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:28:22 --> Config Class Initialized
INFO - 2022-06-10 05:28:22 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:28:22 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:28:22 --> Utf8 Class Initialized
INFO - 2022-06-10 05:28:22 --> URI Class Initialized
INFO - 2022-06-10 05:28:22 --> Router Class Initialized
INFO - 2022-06-10 05:28:22 --> Output Class Initialized
INFO - 2022-06-10 05:28:22 --> Security Class Initialized
DEBUG - 2022-06-10 05:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:28:22 --> Input Class Initialized
INFO - 2022-06-10 05:28:22 --> Language Class Initialized
INFO - 2022-06-10 05:28:22 --> Language Class Initialized
INFO - 2022-06-10 05:28:22 --> Config Class Initialized
INFO - 2022-06-10 05:28:22 --> Loader Class Initialized
INFO - 2022-06-10 05:28:22 --> Helper loaded: url_helper
INFO - 2022-06-10 05:28:22 --> Helper loaded: file_helper
INFO - 2022-06-10 05:28:22 --> Helper loaded: form_helper
INFO - 2022-06-10 05:28:22 --> Helper loaded: my_helper
INFO - 2022-06-10 05:28:22 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:28:22 --> Controller Class Initialized
ERROR - 2022-06-10 05:28:22 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '436' AND tasm = '20212'
INFO - 2022-06-10 05:28:22 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:28:24 --> Config Class Initialized
INFO - 2022-06-10 05:28:24 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:28:24 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:28:24 --> Utf8 Class Initialized
INFO - 2022-06-10 05:28:24 --> URI Class Initialized
INFO - 2022-06-10 05:28:24 --> Router Class Initialized
INFO - 2022-06-10 05:28:24 --> Output Class Initialized
INFO - 2022-06-10 05:28:24 --> Security Class Initialized
DEBUG - 2022-06-10 05:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:28:24 --> Input Class Initialized
INFO - 2022-06-10 05:28:24 --> Language Class Initialized
INFO - 2022-06-10 05:28:24 --> Language Class Initialized
INFO - 2022-06-10 05:28:24 --> Config Class Initialized
INFO - 2022-06-10 05:28:24 --> Loader Class Initialized
INFO - 2022-06-10 05:28:24 --> Helper loaded: url_helper
INFO - 2022-06-10 05:28:24 --> Helper loaded: file_helper
INFO - 2022-06-10 05:28:24 --> Helper loaded: form_helper
INFO - 2022-06-10 05:28:24 --> Helper loaded: my_helper
INFO - 2022-06-10 05:28:24 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:28:24 --> Controller Class Initialized
ERROR - 2022-06-10 05:28:24 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '420' AND tasm = '20212'
INFO - 2022-06-10 05:28:24 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:28:34 --> Config Class Initialized
INFO - 2022-06-10 05:28:34 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:28:34 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:28:34 --> Utf8 Class Initialized
INFO - 2022-06-10 05:28:34 --> URI Class Initialized
INFO - 2022-06-10 05:28:34 --> Router Class Initialized
INFO - 2022-06-10 05:28:34 --> Output Class Initialized
INFO - 2022-06-10 05:28:34 --> Security Class Initialized
DEBUG - 2022-06-10 05:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:28:34 --> Input Class Initialized
INFO - 2022-06-10 05:28:34 --> Language Class Initialized
INFO - 2022-06-10 05:28:34 --> Language Class Initialized
INFO - 2022-06-10 05:28:34 --> Config Class Initialized
INFO - 2022-06-10 05:28:34 --> Loader Class Initialized
INFO - 2022-06-10 05:28:34 --> Helper loaded: url_helper
INFO - 2022-06-10 05:28:34 --> Helper loaded: file_helper
INFO - 2022-06-10 05:28:34 --> Helper loaded: form_helper
INFO - 2022-06-10 05:28:34 --> Helper loaded: my_helper
INFO - 2022-06-10 05:28:34 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:28:34 --> Controller Class Initialized
ERROR - 2022-06-10 05:28:34 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '422' AND tasm = '20212'
INFO - 2022-06-10 05:28:34 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:28:42 --> Config Class Initialized
INFO - 2022-06-10 05:28:42 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:28:42 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:28:42 --> Utf8 Class Initialized
INFO - 2022-06-10 05:28:42 --> URI Class Initialized
INFO - 2022-06-10 05:28:42 --> Router Class Initialized
INFO - 2022-06-10 05:28:42 --> Output Class Initialized
INFO - 2022-06-10 05:28:42 --> Security Class Initialized
DEBUG - 2022-06-10 05:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:28:42 --> Input Class Initialized
INFO - 2022-06-10 05:28:42 --> Language Class Initialized
INFO - 2022-06-10 05:28:42 --> Language Class Initialized
INFO - 2022-06-10 05:28:42 --> Config Class Initialized
INFO - 2022-06-10 05:28:42 --> Loader Class Initialized
INFO - 2022-06-10 05:28:42 --> Helper loaded: url_helper
INFO - 2022-06-10 05:28:42 --> Helper loaded: file_helper
INFO - 2022-06-10 05:28:42 --> Helper loaded: form_helper
INFO - 2022-06-10 05:28:42 --> Helper loaded: my_helper
INFO - 2022-06-10 05:28:42 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:28:42 --> Controller Class Initialized
ERROR - 2022-06-10 05:28:42 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '424' AND tasm = '20212'
INFO - 2022-06-10 05:28:42 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:28:47 --> Config Class Initialized
INFO - 2022-06-10 05:28:47 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:28:47 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:28:47 --> Utf8 Class Initialized
INFO - 2022-06-10 05:28:47 --> URI Class Initialized
INFO - 2022-06-10 05:28:47 --> Router Class Initialized
INFO - 2022-06-10 05:28:47 --> Output Class Initialized
INFO - 2022-06-10 05:28:47 --> Security Class Initialized
DEBUG - 2022-06-10 05:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:28:47 --> Input Class Initialized
INFO - 2022-06-10 05:28:47 --> Language Class Initialized
INFO - 2022-06-10 05:28:47 --> Language Class Initialized
INFO - 2022-06-10 05:28:47 --> Config Class Initialized
INFO - 2022-06-10 05:28:47 --> Loader Class Initialized
INFO - 2022-06-10 05:28:47 --> Helper loaded: url_helper
INFO - 2022-06-10 05:28:47 --> Helper loaded: file_helper
INFO - 2022-06-10 05:28:47 --> Helper loaded: form_helper
INFO - 2022-06-10 05:28:47 --> Helper loaded: my_helper
INFO - 2022-06-10 05:28:47 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:28:47 --> Controller Class Initialized
DEBUG - 2022-06-10 05:28:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-10 05:28:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-10 05:28:47 --> Final output sent to browser
DEBUG - 2022-06-10 05:28:47 --> Total execution time: 0.0755
INFO - 2022-06-10 05:34:22 --> Config Class Initialized
INFO - 2022-06-10 05:34:22 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:34:22 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:34:22 --> Utf8 Class Initialized
INFO - 2022-06-10 05:34:22 --> URI Class Initialized
INFO - 2022-06-10 05:34:22 --> Router Class Initialized
INFO - 2022-06-10 05:34:22 --> Output Class Initialized
INFO - 2022-06-10 05:34:22 --> Security Class Initialized
DEBUG - 2022-06-10 05:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:34:22 --> Input Class Initialized
INFO - 2022-06-10 05:34:22 --> Language Class Initialized
INFO - 2022-06-10 05:34:22 --> Language Class Initialized
INFO - 2022-06-10 05:34:22 --> Config Class Initialized
INFO - 2022-06-10 05:34:22 --> Loader Class Initialized
INFO - 2022-06-10 05:34:22 --> Helper loaded: url_helper
INFO - 2022-06-10 05:34:22 --> Helper loaded: file_helper
INFO - 2022-06-10 05:34:22 --> Helper loaded: form_helper
INFO - 2022-06-10 05:34:22 --> Helper loaded: my_helper
INFO - 2022-06-10 05:34:22 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:34:22 --> Controller Class Initialized
ERROR - 2022-06-10 05:34:22 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '493' AND tasm = '20212'
INFO - 2022-06-10 05:34:22 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:34:53 --> Config Class Initialized
INFO - 2022-06-10 05:34:53 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:34:53 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:34:53 --> Utf8 Class Initialized
INFO - 2022-06-10 05:34:53 --> URI Class Initialized
INFO - 2022-06-10 05:34:53 --> Router Class Initialized
INFO - 2022-06-10 05:34:53 --> Output Class Initialized
INFO - 2022-06-10 05:34:53 --> Security Class Initialized
DEBUG - 2022-06-10 05:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:34:53 --> Input Class Initialized
INFO - 2022-06-10 05:34:53 --> Language Class Initialized
INFO - 2022-06-10 05:34:53 --> Language Class Initialized
INFO - 2022-06-10 05:34:53 --> Config Class Initialized
INFO - 2022-06-10 05:34:53 --> Loader Class Initialized
INFO - 2022-06-10 05:34:53 --> Helper loaded: url_helper
INFO - 2022-06-10 05:34:53 --> Helper loaded: file_helper
INFO - 2022-06-10 05:34:53 --> Helper loaded: form_helper
INFO - 2022-06-10 05:34:53 --> Helper loaded: my_helper
INFO - 2022-06-10 05:34:53 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:34:53 --> Controller Class Initialized
DEBUG - 2022-06-10 05:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-10 05:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-10 05:34:53 --> Final output sent to browser
DEBUG - 2022-06-10 05:34:53 --> Total execution time: 0.0750
INFO - 2022-06-10 05:35:04 --> Config Class Initialized
INFO - 2022-06-10 05:35:04 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:35:04 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:35:04 --> Utf8 Class Initialized
INFO - 2022-06-10 05:35:04 --> URI Class Initialized
INFO - 2022-06-10 05:35:04 --> Router Class Initialized
INFO - 2022-06-10 05:35:04 --> Output Class Initialized
INFO - 2022-06-10 05:35:04 --> Security Class Initialized
DEBUG - 2022-06-10 05:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:35:04 --> Input Class Initialized
INFO - 2022-06-10 05:35:04 --> Language Class Initialized
INFO - 2022-06-10 05:35:04 --> Language Class Initialized
INFO - 2022-06-10 05:35:04 --> Config Class Initialized
INFO - 2022-06-10 05:35:04 --> Loader Class Initialized
INFO - 2022-06-10 05:35:04 --> Helper loaded: url_helper
INFO - 2022-06-10 05:35:04 --> Helper loaded: file_helper
INFO - 2022-06-10 05:35:04 --> Helper loaded: form_helper
INFO - 2022-06-10 05:35:04 --> Helper loaded: my_helper
INFO - 2022-06-10 05:35:04 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:35:04 --> Controller Class Initialized
ERROR - 2022-06-10 05:35:05 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '496' AND tasm = '20212'
INFO - 2022-06-10 05:35:05 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:35:17 --> Config Class Initialized
INFO - 2022-06-10 05:35:17 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:35:17 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:35:17 --> Utf8 Class Initialized
INFO - 2022-06-10 05:35:17 --> URI Class Initialized
INFO - 2022-06-10 05:35:17 --> Router Class Initialized
INFO - 2022-06-10 05:35:17 --> Output Class Initialized
INFO - 2022-06-10 05:35:17 --> Security Class Initialized
DEBUG - 2022-06-10 05:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:35:17 --> Input Class Initialized
INFO - 2022-06-10 05:35:17 --> Language Class Initialized
INFO - 2022-06-10 05:35:17 --> Language Class Initialized
INFO - 2022-06-10 05:35:17 --> Config Class Initialized
INFO - 2022-06-10 05:35:17 --> Loader Class Initialized
INFO - 2022-06-10 05:35:17 --> Helper loaded: url_helper
INFO - 2022-06-10 05:35:17 --> Helper loaded: file_helper
INFO - 2022-06-10 05:35:17 --> Helper loaded: form_helper
INFO - 2022-06-10 05:35:17 --> Helper loaded: my_helper
INFO - 2022-06-10 05:35:17 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:35:17 --> Controller Class Initialized
ERROR - 2022-06-10 05:35:17 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '497' AND tasm = '20212'
INFO - 2022-06-10 05:35:17 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:35:19 --> Config Class Initialized
INFO - 2022-06-10 05:35:19 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:35:19 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:35:19 --> Utf8 Class Initialized
INFO - 2022-06-10 05:35:19 --> URI Class Initialized
INFO - 2022-06-10 05:35:19 --> Router Class Initialized
INFO - 2022-06-10 05:35:19 --> Output Class Initialized
INFO - 2022-06-10 05:35:19 --> Security Class Initialized
DEBUG - 2022-06-10 05:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:35:19 --> Input Class Initialized
INFO - 2022-06-10 05:35:19 --> Language Class Initialized
INFO - 2022-06-10 05:35:19 --> Language Class Initialized
INFO - 2022-06-10 05:35:19 --> Config Class Initialized
INFO - 2022-06-10 05:35:19 --> Loader Class Initialized
INFO - 2022-06-10 05:35:19 --> Helper loaded: url_helper
INFO - 2022-06-10 05:35:19 --> Helper loaded: file_helper
INFO - 2022-06-10 05:35:19 --> Helper loaded: form_helper
INFO - 2022-06-10 05:35:19 --> Helper loaded: my_helper
INFO - 2022-06-10 05:35:19 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:35:19 --> Controller Class Initialized
ERROR - 2022-06-10 05:35:19 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '498' AND tasm = '20212'
INFO - 2022-06-10 05:35:19 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:35:44 --> Config Class Initialized
INFO - 2022-06-10 05:35:44 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:35:44 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:35:44 --> Utf8 Class Initialized
INFO - 2022-06-10 05:35:44 --> URI Class Initialized
INFO - 2022-06-10 05:35:44 --> Router Class Initialized
INFO - 2022-06-10 05:35:44 --> Output Class Initialized
INFO - 2022-06-10 05:35:44 --> Security Class Initialized
DEBUG - 2022-06-10 05:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:35:44 --> Input Class Initialized
INFO - 2022-06-10 05:35:44 --> Language Class Initialized
INFO - 2022-06-10 05:35:44 --> Language Class Initialized
INFO - 2022-06-10 05:35:44 --> Config Class Initialized
INFO - 2022-06-10 05:35:44 --> Loader Class Initialized
INFO - 2022-06-10 05:35:44 --> Helper loaded: url_helper
INFO - 2022-06-10 05:35:44 --> Helper loaded: file_helper
INFO - 2022-06-10 05:35:44 --> Helper loaded: form_helper
INFO - 2022-06-10 05:35:44 --> Helper loaded: my_helper
INFO - 2022-06-10 05:35:44 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:35:44 --> Controller Class Initialized
ERROR - 2022-06-10 05:35:44 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '499' AND tasm = '20212'
INFO - 2022-06-10 05:35:44 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:36:49 --> Config Class Initialized
INFO - 2022-06-10 05:36:49 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:36:49 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:36:49 --> Utf8 Class Initialized
INFO - 2022-06-10 05:36:49 --> URI Class Initialized
INFO - 2022-06-10 05:36:49 --> Router Class Initialized
INFO - 2022-06-10 05:36:49 --> Output Class Initialized
INFO - 2022-06-10 05:36:49 --> Security Class Initialized
DEBUG - 2022-06-10 05:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:36:49 --> Input Class Initialized
INFO - 2022-06-10 05:36:49 --> Language Class Initialized
INFO - 2022-06-10 05:36:49 --> Language Class Initialized
INFO - 2022-06-10 05:36:49 --> Config Class Initialized
INFO - 2022-06-10 05:36:49 --> Loader Class Initialized
INFO - 2022-06-10 05:36:49 --> Helper loaded: url_helper
INFO - 2022-06-10 05:36:49 --> Helper loaded: file_helper
INFO - 2022-06-10 05:36:49 --> Helper loaded: form_helper
INFO - 2022-06-10 05:36:49 --> Helper loaded: my_helper
INFO - 2022-06-10 05:36:49 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:36:49 --> Controller Class Initialized
DEBUG - 2022-06-10 05:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-10 05:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-10 05:36:49 --> Final output sent to browser
DEBUG - 2022-06-10 05:36:49 --> Total execution time: 0.0741
INFO - 2022-06-10 05:36:59 --> Config Class Initialized
INFO - 2022-06-10 05:36:59 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:36:59 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:36:59 --> Utf8 Class Initialized
INFO - 2022-06-10 05:36:59 --> URI Class Initialized
INFO - 2022-06-10 05:36:59 --> Router Class Initialized
INFO - 2022-06-10 05:36:59 --> Output Class Initialized
INFO - 2022-06-10 05:36:59 --> Security Class Initialized
DEBUG - 2022-06-10 05:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:36:59 --> Input Class Initialized
INFO - 2022-06-10 05:36:59 --> Language Class Initialized
INFO - 2022-06-10 05:36:59 --> Language Class Initialized
INFO - 2022-06-10 05:36:59 --> Config Class Initialized
INFO - 2022-06-10 05:36:59 --> Loader Class Initialized
INFO - 2022-06-10 05:36:59 --> Helper loaded: url_helper
INFO - 2022-06-10 05:36:59 --> Helper loaded: file_helper
INFO - 2022-06-10 05:36:59 --> Helper loaded: form_helper
INFO - 2022-06-10 05:36:59 --> Helper loaded: my_helper
INFO - 2022-06-10 05:36:59 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:36:59 --> Controller Class Initialized
ERROR - 2022-06-10 05:36:59 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '501' AND tasm = '20212'
INFO - 2022-06-10 05:36:59 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:37:17 --> Config Class Initialized
INFO - 2022-06-10 05:37:17 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:37:17 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:37:17 --> Utf8 Class Initialized
INFO - 2022-06-10 05:37:17 --> URI Class Initialized
INFO - 2022-06-10 05:37:17 --> Router Class Initialized
INFO - 2022-06-10 05:37:17 --> Output Class Initialized
INFO - 2022-06-10 05:37:17 --> Security Class Initialized
DEBUG - 2022-06-10 05:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:37:17 --> Input Class Initialized
INFO - 2022-06-10 05:37:17 --> Language Class Initialized
INFO - 2022-06-10 05:37:17 --> Language Class Initialized
INFO - 2022-06-10 05:37:17 --> Config Class Initialized
INFO - 2022-06-10 05:37:17 --> Loader Class Initialized
INFO - 2022-06-10 05:37:17 --> Helper loaded: url_helper
INFO - 2022-06-10 05:37:17 --> Helper loaded: file_helper
INFO - 2022-06-10 05:37:17 --> Helper loaded: form_helper
INFO - 2022-06-10 05:37:17 --> Helper loaded: my_helper
INFO - 2022-06-10 05:37:17 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:37:17 --> Controller Class Initialized
ERROR - 2022-06-10 05:37:17 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '505' AND tasm = '20212'
INFO - 2022-06-10 05:37:17 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:37:24 --> Config Class Initialized
INFO - 2022-06-10 05:37:25 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:37:25 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:37:25 --> Utf8 Class Initialized
INFO - 2022-06-10 05:37:25 --> URI Class Initialized
INFO - 2022-06-10 05:37:25 --> Router Class Initialized
INFO - 2022-06-10 05:37:25 --> Output Class Initialized
INFO - 2022-06-10 05:37:25 --> Security Class Initialized
DEBUG - 2022-06-10 05:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:37:25 --> Input Class Initialized
INFO - 2022-06-10 05:37:25 --> Language Class Initialized
INFO - 2022-06-10 05:37:25 --> Language Class Initialized
INFO - 2022-06-10 05:37:25 --> Config Class Initialized
INFO - 2022-06-10 05:37:25 --> Loader Class Initialized
INFO - 2022-06-10 05:37:25 --> Helper loaded: url_helper
INFO - 2022-06-10 05:37:25 --> Helper loaded: file_helper
INFO - 2022-06-10 05:37:25 --> Helper loaded: form_helper
INFO - 2022-06-10 05:37:25 --> Helper loaded: my_helper
INFO - 2022-06-10 05:37:25 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:37:25 --> Controller Class Initialized
ERROR - 2022-06-10 05:37:25 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '506' AND tasm = '20212'
INFO - 2022-06-10 05:37:25 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:37:26 --> Config Class Initialized
INFO - 2022-06-10 05:37:26 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:37:26 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:37:26 --> Utf8 Class Initialized
INFO - 2022-06-10 05:37:26 --> URI Class Initialized
INFO - 2022-06-10 05:37:26 --> Router Class Initialized
INFO - 2022-06-10 05:37:26 --> Output Class Initialized
INFO - 2022-06-10 05:37:26 --> Security Class Initialized
DEBUG - 2022-06-10 05:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:37:26 --> Input Class Initialized
INFO - 2022-06-10 05:37:26 --> Language Class Initialized
INFO - 2022-06-10 05:37:26 --> Language Class Initialized
INFO - 2022-06-10 05:37:26 --> Config Class Initialized
INFO - 2022-06-10 05:37:26 --> Loader Class Initialized
INFO - 2022-06-10 05:37:26 --> Helper loaded: url_helper
INFO - 2022-06-10 05:37:26 --> Helper loaded: file_helper
INFO - 2022-06-10 05:37:26 --> Helper loaded: form_helper
INFO - 2022-06-10 05:37:26 --> Helper loaded: my_helper
INFO - 2022-06-10 05:37:26 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:37:26 --> Controller Class Initialized
ERROR - 2022-06-10 05:37:26 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '507' AND tasm = '20212'
INFO - 2022-06-10 05:37:26 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:37:28 --> Config Class Initialized
INFO - 2022-06-10 05:37:28 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:37:28 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:37:28 --> Utf8 Class Initialized
INFO - 2022-06-10 05:37:28 --> URI Class Initialized
INFO - 2022-06-10 05:37:28 --> Router Class Initialized
INFO - 2022-06-10 05:37:28 --> Output Class Initialized
INFO - 2022-06-10 05:37:28 --> Security Class Initialized
DEBUG - 2022-06-10 05:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:37:28 --> Input Class Initialized
INFO - 2022-06-10 05:37:28 --> Language Class Initialized
INFO - 2022-06-10 05:37:28 --> Language Class Initialized
INFO - 2022-06-10 05:37:28 --> Config Class Initialized
INFO - 2022-06-10 05:37:28 --> Loader Class Initialized
INFO - 2022-06-10 05:37:28 --> Helper loaded: url_helper
INFO - 2022-06-10 05:37:28 --> Helper loaded: file_helper
INFO - 2022-06-10 05:37:28 --> Helper loaded: form_helper
INFO - 2022-06-10 05:37:28 --> Helper loaded: my_helper
INFO - 2022-06-10 05:37:28 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:37:28 --> Controller Class Initialized
ERROR - 2022-06-10 05:37:28 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '508' AND tasm = '20212'
INFO - 2022-06-10 05:37:28 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:39:47 --> Config Class Initialized
INFO - 2022-06-10 05:39:47 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:39:47 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:39:47 --> Utf8 Class Initialized
INFO - 2022-06-10 05:39:47 --> URI Class Initialized
INFO - 2022-06-10 05:39:47 --> Router Class Initialized
INFO - 2022-06-10 05:39:47 --> Output Class Initialized
INFO - 2022-06-10 05:39:47 --> Security Class Initialized
DEBUG - 2022-06-10 05:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:39:47 --> Input Class Initialized
INFO - 2022-06-10 05:39:47 --> Language Class Initialized
INFO - 2022-06-10 05:39:47 --> Language Class Initialized
INFO - 2022-06-10 05:39:47 --> Config Class Initialized
INFO - 2022-06-10 05:39:47 --> Loader Class Initialized
INFO - 2022-06-10 05:39:47 --> Helper loaded: url_helper
INFO - 2022-06-10 05:39:47 --> Helper loaded: file_helper
INFO - 2022-06-10 05:39:47 --> Helper loaded: form_helper
INFO - 2022-06-10 05:39:47 --> Helper loaded: my_helper
INFO - 2022-06-10 05:39:47 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:39:47 --> Controller Class Initialized
ERROR - 2022-06-10 05:39:47 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '509' AND tasm = '20212'
INFO - 2022-06-10 05:39:47 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:39:49 --> Config Class Initialized
INFO - 2022-06-10 05:39:49 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:39:49 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:39:49 --> Utf8 Class Initialized
INFO - 2022-06-10 05:39:49 --> URI Class Initialized
INFO - 2022-06-10 05:39:49 --> Router Class Initialized
INFO - 2022-06-10 05:39:49 --> Output Class Initialized
INFO - 2022-06-10 05:39:49 --> Security Class Initialized
DEBUG - 2022-06-10 05:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:39:49 --> Input Class Initialized
INFO - 2022-06-10 05:39:49 --> Language Class Initialized
INFO - 2022-06-10 05:39:49 --> Language Class Initialized
INFO - 2022-06-10 05:39:49 --> Config Class Initialized
INFO - 2022-06-10 05:39:49 --> Loader Class Initialized
INFO - 2022-06-10 05:39:49 --> Helper loaded: url_helper
INFO - 2022-06-10 05:39:49 --> Helper loaded: file_helper
INFO - 2022-06-10 05:39:49 --> Helper loaded: form_helper
INFO - 2022-06-10 05:39:49 --> Helper loaded: my_helper
INFO - 2022-06-10 05:39:49 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:39:49 --> Controller Class Initialized
ERROR - 2022-06-10 05:39:49 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '510' AND tasm = '20212'
INFO - 2022-06-10 05:39:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:39:51 --> Config Class Initialized
INFO - 2022-06-10 05:39:51 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:39:51 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:39:51 --> Utf8 Class Initialized
INFO - 2022-06-10 05:39:51 --> URI Class Initialized
INFO - 2022-06-10 05:39:51 --> Router Class Initialized
INFO - 2022-06-10 05:39:51 --> Output Class Initialized
INFO - 2022-06-10 05:39:51 --> Security Class Initialized
DEBUG - 2022-06-10 05:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:39:51 --> Input Class Initialized
INFO - 2022-06-10 05:39:51 --> Language Class Initialized
INFO - 2022-06-10 05:39:51 --> Language Class Initialized
INFO - 2022-06-10 05:39:51 --> Config Class Initialized
INFO - 2022-06-10 05:39:51 --> Loader Class Initialized
INFO - 2022-06-10 05:39:51 --> Helper loaded: url_helper
INFO - 2022-06-10 05:39:51 --> Helper loaded: file_helper
INFO - 2022-06-10 05:39:51 --> Helper loaded: form_helper
INFO - 2022-06-10 05:39:51 --> Helper loaded: my_helper
INFO - 2022-06-10 05:39:51 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:39:51 --> Controller Class Initialized
ERROR - 2022-06-10 05:39:51 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '511' AND tasm = '20212'
INFO - 2022-06-10 05:39:51 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:39:55 --> Config Class Initialized
INFO - 2022-06-10 05:39:55 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:39:55 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:39:55 --> Utf8 Class Initialized
INFO - 2022-06-10 05:39:55 --> URI Class Initialized
INFO - 2022-06-10 05:39:55 --> Router Class Initialized
INFO - 2022-06-10 05:39:55 --> Output Class Initialized
INFO - 2022-06-10 05:39:55 --> Security Class Initialized
DEBUG - 2022-06-10 05:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:39:55 --> Input Class Initialized
INFO - 2022-06-10 05:39:55 --> Language Class Initialized
INFO - 2022-06-10 05:39:55 --> Language Class Initialized
INFO - 2022-06-10 05:39:55 --> Config Class Initialized
INFO - 2022-06-10 05:39:55 --> Loader Class Initialized
INFO - 2022-06-10 05:39:55 --> Helper loaded: url_helper
INFO - 2022-06-10 05:39:55 --> Helper loaded: file_helper
INFO - 2022-06-10 05:39:55 --> Helper loaded: form_helper
INFO - 2022-06-10 05:39:55 --> Helper loaded: my_helper
INFO - 2022-06-10 05:39:55 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:39:55 --> Controller Class Initialized
ERROR - 2022-06-10 05:39:55 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '514' AND tasm = '20212'
INFO - 2022-06-10 05:39:55 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:39:57 --> Config Class Initialized
INFO - 2022-06-10 05:39:57 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:39:57 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:39:57 --> Utf8 Class Initialized
INFO - 2022-06-10 05:39:57 --> URI Class Initialized
INFO - 2022-06-10 05:39:57 --> Router Class Initialized
INFO - 2022-06-10 05:39:57 --> Output Class Initialized
INFO - 2022-06-10 05:39:57 --> Security Class Initialized
DEBUG - 2022-06-10 05:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:39:57 --> Input Class Initialized
INFO - 2022-06-10 05:39:57 --> Language Class Initialized
INFO - 2022-06-10 05:39:57 --> Language Class Initialized
INFO - 2022-06-10 05:39:57 --> Config Class Initialized
INFO - 2022-06-10 05:39:57 --> Loader Class Initialized
INFO - 2022-06-10 05:39:57 --> Helper loaded: url_helper
INFO - 2022-06-10 05:39:57 --> Helper loaded: file_helper
INFO - 2022-06-10 05:39:57 --> Helper loaded: form_helper
INFO - 2022-06-10 05:39:57 --> Helper loaded: my_helper
INFO - 2022-06-10 05:39:57 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:39:57 --> Controller Class Initialized
ERROR - 2022-06-10 05:39:57 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '515' AND tasm = '20212'
INFO - 2022-06-10 05:39:57 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-10 05:39:59 --> Config Class Initialized
INFO - 2022-06-10 05:39:59 --> Hooks Class Initialized
DEBUG - 2022-06-10 05:39:59 --> UTF-8 Support Enabled
INFO - 2022-06-10 05:39:59 --> Utf8 Class Initialized
INFO - 2022-06-10 05:39:59 --> URI Class Initialized
INFO - 2022-06-10 05:39:59 --> Router Class Initialized
INFO - 2022-06-10 05:39:59 --> Output Class Initialized
INFO - 2022-06-10 05:39:59 --> Security Class Initialized
DEBUG - 2022-06-10 05:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-10 05:39:59 --> Input Class Initialized
INFO - 2022-06-10 05:39:59 --> Language Class Initialized
INFO - 2022-06-10 05:39:59 --> Language Class Initialized
INFO - 2022-06-10 05:39:59 --> Config Class Initialized
INFO - 2022-06-10 05:39:59 --> Loader Class Initialized
INFO - 2022-06-10 05:39:59 --> Helper loaded: url_helper
INFO - 2022-06-10 05:39:59 --> Helper loaded: file_helper
INFO - 2022-06-10 05:39:59 --> Helper loaded: form_helper
INFO - 2022-06-10 05:39:59 --> Helper loaded: my_helper
INFO - 2022-06-10 05:39:59 --> Database Driver Class Initialized
DEBUG - 2022-06-10 05:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-10 05:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-10 05:39:59 --> Controller Class Initialized
ERROR - 2022-06-10 05:39:59 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '516' AND tasm = '20212'
INFO - 2022-06-10 05:39:59 --> Language file loaded: language/english/db_lang.php
