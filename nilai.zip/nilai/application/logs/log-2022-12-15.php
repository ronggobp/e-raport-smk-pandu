<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-15 02:07:00 --> Config Class Initialized
INFO - 2022-12-15 02:07:00 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:07:00 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:07:00 --> Utf8 Class Initialized
INFO - 2022-12-15 02:07:00 --> URI Class Initialized
DEBUG - 2022-12-15 02:07:00 --> No URI present. Default controller set.
INFO - 2022-12-15 02:07:00 --> Router Class Initialized
INFO - 2022-12-15 02:07:00 --> Output Class Initialized
INFO - 2022-12-15 02:07:00 --> Security Class Initialized
DEBUG - 2022-12-15 02:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:07:00 --> Input Class Initialized
INFO - 2022-12-15 02:07:00 --> Language Class Initialized
INFO - 2022-12-15 02:07:01 --> Language Class Initialized
INFO - 2022-12-15 02:07:01 --> Config Class Initialized
INFO - 2022-12-15 02:07:01 --> Loader Class Initialized
INFO - 2022-12-15 02:07:01 --> Helper loaded: url_helper
INFO - 2022-12-15 02:07:01 --> Helper loaded: file_helper
INFO - 2022-12-15 02:07:01 --> Helper loaded: form_helper
INFO - 2022-12-15 02:07:01 --> Helper loaded: my_helper
INFO - 2022-12-15 02:07:01 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:07:01 --> Controller Class Initialized
INFO - 2022-12-15 02:07:01 --> Config Class Initialized
INFO - 2022-12-15 02:07:01 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:07:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:07:01 --> Utf8 Class Initialized
INFO - 2022-12-15 02:07:01 --> URI Class Initialized
INFO - 2022-12-15 02:07:01 --> Router Class Initialized
INFO - 2022-12-15 02:07:01 --> Output Class Initialized
INFO - 2022-12-15 02:07:01 --> Security Class Initialized
DEBUG - 2022-12-15 02:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:07:01 --> Input Class Initialized
INFO - 2022-12-15 02:07:01 --> Language Class Initialized
INFO - 2022-12-15 02:07:01 --> Language Class Initialized
INFO - 2022-12-15 02:07:01 --> Config Class Initialized
INFO - 2022-12-15 02:07:01 --> Loader Class Initialized
INFO - 2022-12-15 02:07:01 --> Helper loaded: url_helper
INFO - 2022-12-15 02:07:01 --> Helper loaded: file_helper
INFO - 2022-12-15 02:07:01 --> Helper loaded: form_helper
INFO - 2022-12-15 02:07:01 --> Helper loaded: my_helper
INFO - 2022-12-15 02:07:01 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:07:01 --> Controller Class Initialized
DEBUG - 2022-12-15 02:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-15 02:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:07:01 --> Final output sent to browser
DEBUG - 2022-12-15 02:07:01 --> Total execution time: 0.1223
INFO - 2022-12-15 02:23:14 --> Config Class Initialized
INFO - 2022-12-15 02:23:14 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:23:14 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:23:14 --> Utf8 Class Initialized
INFO - 2022-12-15 02:23:14 --> URI Class Initialized
INFO - 2022-12-15 02:23:14 --> Router Class Initialized
INFO - 2022-12-15 02:23:14 --> Output Class Initialized
INFO - 2022-12-15 02:23:14 --> Security Class Initialized
DEBUG - 2022-12-15 02:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:23:14 --> Input Class Initialized
INFO - 2022-12-15 02:23:14 --> Language Class Initialized
INFO - 2022-12-15 02:23:14 --> Language Class Initialized
INFO - 2022-12-15 02:23:14 --> Config Class Initialized
INFO - 2022-12-15 02:23:14 --> Loader Class Initialized
INFO - 2022-12-15 02:23:14 --> Helper loaded: url_helper
INFO - 2022-12-15 02:23:14 --> Helper loaded: file_helper
INFO - 2022-12-15 02:23:14 --> Helper loaded: form_helper
INFO - 2022-12-15 02:23:14 --> Helper loaded: my_helper
INFO - 2022-12-15 02:23:14 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:23:14 --> Controller Class Initialized
INFO - 2022-12-15 02:23:14 --> Helper loaded: cookie_helper
INFO - 2022-12-15 02:23:14 --> Final output sent to browser
DEBUG - 2022-12-15 02:23:14 --> Total execution time: 0.0900
INFO - 2022-12-15 02:23:16 --> Config Class Initialized
INFO - 2022-12-15 02:23:16 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:23:16 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:23:16 --> Utf8 Class Initialized
INFO - 2022-12-15 02:23:16 --> URI Class Initialized
INFO - 2022-12-15 02:23:16 --> Router Class Initialized
INFO - 2022-12-15 02:23:16 --> Output Class Initialized
INFO - 2022-12-15 02:23:16 --> Security Class Initialized
DEBUG - 2022-12-15 02:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:23:16 --> Input Class Initialized
INFO - 2022-12-15 02:23:16 --> Language Class Initialized
INFO - 2022-12-15 02:23:16 --> Language Class Initialized
INFO - 2022-12-15 02:23:16 --> Config Class Initialized
INFO - 2022-12-15 02:23:16 --> Loader Class Initialized
INFO - 2022-12-15 02:23:16 --> Helper loaded: url_helper
INFO - 2022-12-15 02:23:16 --> Helper loaded: file_helper
INFO - 2022-12-15 02:23:16 --> Helper loaded: form_helper
INFO - 2022-12-15 02:23:16 --> Helper loaded: my_helper
INFO - 2022-12-15 02:23:16 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:23:16 --> Controller Class Initialized
DEBUG - 2022-12-15 02:23:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-12-15 02:23:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:23:16 --> Final output sent to browser
DEBUG - 2022-12-15 02:23:16 --> Total execution time: 0.1207
INFO - 2022-12-15 02:32:14 --> Config Class Initialized
INFO - 2022-12-15 02:32:14 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:32:14 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:32:14 --> Utf8 Class Initialized
INFO - 2022-12-15 02:32:14 --> URI Class Initialized
INFO - 2022-12-15 02:32:14 --> Router Class Initialized
INFO - 2022-12-15 02:32:14 --> Output Class Initialized
INFO - 2022-12-15 02:32:14 --> Security Class Initialized
DEBUG - 2022-12-15 02:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:32:14 --> Input Class Initialized
INFO - 2022-12-15 02:32:14 --> Language Class Initialized
INFO - 2022-12-15 02:32:14 --> Language Class Initialized
INFO - 2022-12-15 02:32:14 --> Config Class Initialized
INFO - 2022-12-15 02:32:14 --> Loader Class Initialized
INFO - 2022-12-15 02:32:14 --> Helper loaded: url_helper
INFO - 2022-12-15 02:32:14 --> Helper loaded: file_helper
INFO - 2022-12-15 02:32:14 --> Helper loaded: form_helper
INFO - 2022-12-15 02:32:14 --> Helper loaded: my_helper
INFO - 2022-12-15 02:32:14 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:32:14 --> Controller Class Initialized
DEBUG - 2022-12-15 02:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-12-15 02:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:32:14 --> Final output sent to browser
DEBUG - 2022-12-15 02:32:14 --> Total execution time: 0.1022
INFO - 2022-12-15 02:32:14 --> Config Class Initialized
INFO - 2022-12-15 02:32:14 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:32:14 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:32:14 --> Utf8 Class Initialized
INFO - 2022-12-15 02:32:14 --> URI Class Initialized
INFO - 2022-12-15 02:32:14 --> Router Class Initialized
INFO - 2022-12-15 02:32:14 --> Output Class Initialized
INFO - 2022-12-15 02:32:14 --> Security Class Initialized
DEBUG - 2022-12-15 02:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:32:14 --> Input Class Initialized
INFO - 2022-12-15 02:32:14 --> Language Class Initialized
INFO - 2022-12-15 02:32:14 --> Language Class Initialized
INFO - 2022-12-15 02:32:14 --> Config Class Initialized
INFO - 2022-12-15 02:32:14 --> Loader Class Initialized
INFO - 2022-12-15 02:32:14 --> Helper loaded: url_helper
INFO - 2022-12-15 02:32:14 --> Helper loaded: file_helper
INFO - 2022-12-15 02:32:14 --> Helper loaded: form_helper
INFO - 2022-12-15 02:32:14 --> Helper loaded: my_helper
INFO - 2022-12-15 02:32:14 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:32:14 --> Controller Class Initialized
INFO - 2022-12-15 02:32:44 --> Config Class Initialized
INFO - 2022-12-15 02:32:44 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:32:44 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:32:44 --> Utf8 Class Initialized
INFO - 2022-12-15 02:32:44 --> URI Class Initialized
INFO - 2022-12-15 02:32:44 --> Router Class Initialized
INFO - 2022-12-15 02:32:44 --> Output Class Initialized
INFO - 2022-12-15 02:32:44 --> Security Class Initialized
DEBUG - 2022-12-15 02:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:32:44 --> Input Class Initialized
INFO - 2022-12-15 02:32:44 --> Language Class Initialized
INFO - 2022-12-15 02:32:44 --> Language Class Initialized
INFO - 2022-12-15 02:32:44 --> Config Class Initialized
INFO - 2022-12-15 02:32:44 --> Loader Class Initialized
INFO - 2022-12-15 02:32:44 --> Helper loaded: url_helper
INFO - 2022-12-15 02:32:44 --> Helper loaded: file_helper
INFO - 2022-12-15 02:32:44 --> Helper loaded: form_helper
INFO - 2022-12-15 02:32:44 --> Helper loaded: my_helper
INFO - 2022-12-15 02:32:44 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:32:44 --> Controller Class Initialized
INFO - 2022-12-15 02:32:44 --> Final output sent to browser
DEBUG - 2022-12-15 02:32:44 --> Total execution time: 0.0580
INFO - 2022-12-15 02:33:27 --> Config Class Initialized
INFO - 2022-12-15 02:33:27 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:33:27 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:33:27 --> Utf8 Class Initialized
INFO - 2022-12-15 02:33:27 --> URI Class Initialized
INFO - 2022-12-15 02:33:27 --> Router Class Initialized
INFO - 2022-12-15 02:33:27 --> Output Class Initialized
INFO - 2022-12-15 02:33:27 --> Security Class Initialized
DEBUG - 2022-12-15 02:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:33:27 --> Input Class Initialized
INFO - 2022-12-15 02:33:27 --> Language Class Initialized
INFO - 2022-12-15 02:33:27 --> Language Class Initialized
INFO - 2022-12-15 02:33:27 --> Config Class Initialized
INFO - 2022-12-15 02:33:27 --> Loader Class Initialized
INFO - 2022-12-15 02:33:27 --> Helper loaded: url_helper
INFO - 2022-12-15 02:33:27 --> Helper loaded: file_helper
INFO - 2022-12-15 02:33:27 --> Helper loaded: form_helper
INFO - 2022-12-15 02:33:27 --> Helper loaded: my_helper
INFO - 2022-12-15 02:33:27 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:33:27 --> Controller Class Initialized
INFO - 2022-12-15 02:33:27 --> Final output sent to browser
DEBUG - 2022-12-15 02:33:27 --> Total execution time: 0.0743
INFO - 2022-12-15 02:33:27 --> Config Class Initialized
INFO - 2022-12-15 02:33:27 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:33:27 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:33:27 --> Utf8 Class Initialized
INFO - 2022-12-15 02:33:27 --> URI Class Initialized
INFO - 2022-12-15 02:33:27 --> Router Class Initialized
INFO - 2022-12-15 02:33:27 --> Output Class Initialized
INFO - 2022-12-15 02:33:27 --> Security Class Initialized
DEBUG - 2022-12-15 02:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:33:27 --> Input Class Initialized
INFO - 2022-12-15 02:33:27 --> Language Class Initialized
INFO - 2022-12-15 02:33:27 --> Language Class Initialized
INFO - 2022-12-15 02:33:27 --> Config Class Initialized
INFO - 2022-12-15 02:33:27 --> Loader Class Initialized
INFO - 2022-12-15 02:33:27 --> Helper loaded: url_helper
INFO - 2022-12-15 02:33:27 --> Helper loaded: file_helper
INFO - 2022-12-15 02:33:27 --> Helper loaded: form_helper
INFO - 2022-12-15 02:33:27 --> Helper loaded: my_helper
INFO - 2022-12-15 02:33:27 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:33:27 --> Controller Class Initialized
INFO - 2022-12-15 02:33:34 --> Config Class Initialized
INFO - 2022-12-15 02:33:34 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:33:34 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:33:34 --> Utf8 Class Initialized
INFO - 2022-12-15 02:33:34 --> URI Class Initialized
INFO - 2022-12-15 02:33:34 --> Router Class Initialized
INFO - 2022-12-15 02:33:34 --> Output Class Initialized
INFO - 2022-12-15 02:33:34 --> Security Class Initialized
DEBUG - 2022-12-15 02:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:33:34 --> Input Class Initialized
INFO - 2022-12-15 02:33:34 --> Language Class Initialized
INFO - 2022-12-15 02:33:34 --> Language Class Initialized
INFO - 2022-12-15 02:33:34 --> Config Class Initialized
INFO - 2022-12-15 02:33:34 --> Loader Class Initialized
INFO - 2022-12-15 02:33:34 --> Helper loaded: url_helper
INFO - 2022-12-15 02:33:34 --> Helper loaded: file_helper
INFO - 2022-12-15 02:33:34 --> Helper loaded: form_helper
INFO - 2022-12-15 02:33:34 --> Helper loaded: my_helper
INFO - 2022-12-15 02:33:34 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:33:34 --> Controller Class Initialized
INFO - 2022-12-15 02:33:34 --> Final output sent to browser
DEBUG - 2022-12-15 02:33:34 --> Total execution time: 0.0756
INFO - 2022-12-15 02:33:34 --> Config Class Initialized
INFO - 2022-12-15 02:33:34 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:33:34 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:33:34 --> Utf8 Class Initialized
INFO - 2022-12-15 02:33:34 --> URI Class Initialized
INFO - 2022-12-15 02:33:34 --> Router Class Initialized
INFO - 2022-12-15 02:33:34 --> Output Class Initialized
INFO - 2022-12-15 02:33:34 --> Security Class Initialized
DEBUG - 2022-12-15 02:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:33:34 --> Input Class Initialized
INFO - 2022-12-15 02:33:34 --> Language Class Initialized
INFO - 2022-12-15 02:33:34 --> Language Class Initialized
INFO - 2022-12-15 02:33:34 --> Config Class Initialized
INFO - 2022-12-15 02:33:34 --> Loader Class Initialized
INFO - 2022-12-15 02:33:34 --> Helper loaded: url_helper
INFO - 2022-12-15 02:33:34 --> Helper loaded: file_helper
INFO - 2022-12-15 02:33:34 --> Helper loaded: form_helper
INFO - 2022-12-15 02:33:34 --> Helper loaded: my_helper
INFO - 2022-12-15 02:33:34 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:33:34 --> Controller Class Initialized
INFO - 2022-12-15 02:34:21 --> Config Class Initialized
INFO - 2022-12-15 02:34:21 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:21 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:21 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:21 --> URI Class Initialized
INFO - 2022-12-15 02:34:21 --> Router Class Initialized
INFO - 2022-12-15 02:34:21 --> Output Class Initialized
INFO - 2022-12-15 02:34:21 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:21 --> Input Class Initialized
INFO - 2022-12-15 02:34:21 --> Language Class Initialized
INFO - 2022-12-15 02:34:21 --> Language Class Initialized
INFO - 2022-12-15 02:34:21 --> Config Class Initialized
INFO - 2022-12-15 02:34:21 --> Loader Class Initialized
INFO - 2022-12-15 02:34:21 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:21 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:21 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:21 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:21 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:21 --> Controller Class Initialized
DEBUG - 2022-12-15 02:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-15 02:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:34:21 --> Final output sent to browser
DEBUG - 2022-12-15 02:34:21 --> Total execution time: 0.0839
INFO - 2022-12-15 02:34:21 --> Config Class Initialized
INFO - 2022-12-15 02:34:21 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:21 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:21 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:21 --> URI Class Initialized
INFO - 2022-12-15 02:34:21 --> Router Class Initialized
INFO - 2022-12-15 02:34:21 --> Output Class Initialized
INFO - 2022-12-15 02:34:21 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:21 --> Input Class Initialized
INFO - 2022-12-15 02:34:21 --> Language Class Initialized
INFO - 2022-12-15 02:34:21 --> Language Class Initialized
INFO - 2022-12-15 02:34:21 --> Config Class Initialized
INFO - 2022-12-15 02:34:21 --> Loader Class Initialized
INFO - 2022-12-15 02:34:21 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:21 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:21 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:21 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:21 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:21 --> Controller Class Initialized
INFO - 2022-12-15 02:34:23 --> Config Class Initialized
INFO - 2022-12-15 02:34:23 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:23 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:23 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:23 --> URI Class Initialized
INFO - 2022-12-15 02:34:23 --> Router Class Initialized
INFO - 2022-12-15 02:34:23 --> Output Class Initialized
INFO - 2022-12-15 02:34:23 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:23 --> Input Class Initialized
INFO - 2022-12-15 02:34:23 --> Language Class Initialized
INFO - 2022-12-15 02:34:23 --> Language Class Initialized
INFO - 2022-12-15 02:34:23 --> Config Class Initialized
INFO - 2022-12-15 02:34:23 --> Loader Class Initialized
INFO - 2022-12-15 02:34:23 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:23 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:23 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:23 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:23 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:23 --> Controller Class Initialized
DEBUG - 2022-12-15 02:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2022-12-15 02:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:34:23 --> Final output sent to browser
DEBUG - 2022-12-15 02:34:23 --> Total execution time: 0.1069
INFO - 2022-12-15 02:34:23 --> Config Class Initialized
INFO - 2022-12-15 02:34:23 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:23 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:23 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:24 --> URI Class Initialized
INFO - 2022-12-15 02:34:24 --> Router Class Initialized
INFO - 2022-12-15 02:34:24 --> Output Class Initialized
INFO - 2022-12-15 02:34:24 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:24 --> Input Class Initialized
INFO - 2022-12-15 02:34:24 --> Language Class Initialized
INFO - 2022-12-15 02:34:24 --> Language Class Initialized
INFO - 2022-12-15 02:34:24 --> Config Class Initialized
INFO - 2022-12-15 02:34:24 --> Loader Class Initialized
INFO - 2022-12-15 02:34:24 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:24 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:24 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:24 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:24 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:24 --> Controller Class Initialized
INFO - 2022-12-15 02:34:28 --> Config Class Initialized
INFO - 2022-12-15 02:34:28 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:28 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:28 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:28 --> URI Class Initialized
INFO - 2022-12-15 02:34:28 --> Router Class Initialized
INFO - 2022-12-15 02:34:28 --> Output Class Initialized
INFO - 2022-12-15 02:34:28 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:28 --> Input Class Initialized
INFO - 2022-12-15 02:34:28 --> Language Class Initialized
INFO - 2022-12-15 02:34:28 --> Language Class Initialized
INFO - 2022-12-15 02:34:28 --> Config Class Initialized
INFO - 2022-12-15 02:34:28 --> Loader Class Initialized
INFO - 2022-12-15 02:34:28 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:28 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:28 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:28 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:28 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:28 --> Controller Class Initialized
DEBUG - 2022-12-15 02:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2022-12-15 02:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:34:28 --> Final output sent to browser
DEBUG - 2022-12-15 02:34:28 --> Total execution time: 0.0862
INFO - 2022-12-15 02:34:28 --> Config Class Initialized
INFO - 2022-12-15 02:34:28 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:28 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:28 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:28 --> URI Class Initialized
INFO - 2022-12-15 02:34:28 --> Router Class Initialized
INFO - 2022-12-15 02:34:28 --> Output Class Initialized
INFO - 2022-12-15 02:34:28 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:28 --> Input Class Initialized
INFO - 2022-12-15 02:34:28 --> Language Class Initialized
INFO - 2022-12-15 02:34:28 --> Language Class Initialized
INFO - 2022-12-15 02:34:28 --> Config Class Initialized
INFO - 2022-12-15 02:34:28 --> Loader Class Initialized
INFO - 2022-12-15 02:34:28 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:28 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:28 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:28 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:29 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:29 --> Controller Class Initialized
INFO - 2022-12-15 02:34:29 --> Config Class Initialized
INFO - 2022-12-15 02:34:29 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:29 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:29 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:29 --> URI Class Initialized
INFO - 2022-12-15 02:34:29 --> Router Class Initialized
INFO - 2022-12-15 02:34:29 --> Output Class Initialized
INFO - 2022-12-15 02:34:29 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:29 --> Input Class Initialized
INFO - 2022-12-15 02:34:29 --> Language Class Initialized
INFO - 2022-12-15 02:34:29 --> Language Class Initialized
INFO - 2022-12-15 02:34:29 --> Config Class Initialized
INFO - 2022-12-15 02:34:29 --> Loader Class Initialized
INFO - 2022-12-15 02:34:29 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:29 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:29 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:29 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:29 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:29 --> Controller Class Initialized
DEBUG - 2022-12-15 02:34:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-12-15 02:34:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:34:29 --> Final output sent to browser
DEBUG - 2022-12-15 02:34:29 --> Total execution time: 0.0707
INFO - 2022-12-15 02:34:29 --> Config Class Initialized
INFO - 2022-12-15 02:34:29 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:29 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:29 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:29 --> URI Class Initialized
INFO - 2022-12-15 02:34:29 --> Router Class Initialized
INFO - 2022-12-15 02:34:29 --> Output Class Initialized
INFO - 2022-12-15 02:34:29 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:29 --> Input Class Initialized
INFO - 2022-12-15 02:34:29 --> Language Class Initialized
INFO - 2022-12-15 02:34:29 --> Language Class Initialized
INFO - 2022-12-15 02:34:29 --> Config Class Initialized
INFO - 2022-12-15 02:34:29 --> Loader Class Initialized
INFO - 2022-12-15 02:34:29 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:29 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:29 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:29 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:29 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:29 --> Controller Class Initialized
INFO - 2022-12-15 02:34:30 --> Config Class Initialized
INFO - 2022-12-15 02:34:30 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:30 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:30 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:30 --> URI Class Initialized
INFO - 2022-12-15 02:34:30 --> Router Class Initialized
INFO - 2022-12-15 02:34:30 --> Output Class Initialized
INFO - 2022-12-15 02:34:30 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:30 --> Input Class Initialized
INFO - 2022-12-15 02:34:30 --> Language Class Initialized
INFO - 2022-12-15 02:34:30 --> Language Class Initialized
INFO - 2022-12-15 02:34:30 --> Config Class Initialized
INFO - 2022-12-15 02:34:30 --> Loader Class Initialized
INFO - 2022-12-15 02:34:30 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:30 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:30 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:30 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:30 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:30 --> Controller Class Initialized
DEBUG - 2022-12-15 02:34:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-15 02:34:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:34:30 --> Final output sent to browser
DEBUG - 2022-12-15 02:34:30 --> Total execution time: 0.0723
INFO - 2022-12-15 02:34:32 --> Config Class Initialized
INFO - 2022-12-15 02:34:32 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:32 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:32 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:32 --> URI Class Initialized
INFO - 2022-12-15 02:34:32 --> Router Class Initialized
INFO - 2022-12-15 02:34:32 --> Output Class Initialized
INFO - 2022-12-15 02:34:32 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:32 --> Input Class Initialized
INFO - 2022-12-15 02:34:32 --> Language Class Initialized
INFO - 2022-12-15 02:34:32 --> Language Class Initialized
INFO - 2022-12-15 02:34:32 --> Config Class Initialized
INFO - 2022-12-15 02:34:32 --> Loader Class Initialized
INFO - 2022-12-15 02:34:32 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:32 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:32 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:32 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:32 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:32 --> Controller Class Initialized
DEBUG - 2022-12-15 02:34:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-15 02:34:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:34:32 --> Final output sent to browser
DEBUG - 2022-12-15 02:34:32 --> Total execution time: 0.1038
INFO - 2022-12-15 02:34:32 --> Config Class Initialized
INFO - 2022-12-15 02:34:32 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:32 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:32 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:32 --> URI Class Initialized
INFO - 2022-12-15 02:34:32 --> Router Class Initialized
INFO - 2022-12-15 02:34:32 --> Output Class Initialized
INFO - 2022-12-15 02:34:32 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:32 --> Input Class Initialized
INFO - 2022-12-15 02:34:32 --> Language Class Initialized
INFO - 2022-12-15 02:34:32 --> Language Class Initialized
INFO - 2022-12-15 02:34:32 --> Config Class Initialized
INFO - 2022-12-15 02:34:32 --> Loader Class Initialized
INFO - 2022-12-15 02:34:32 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:32 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:32 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:32 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:32 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:32 --> Controller Class Initialized
INFO - 2022-12-15 02:34:33 --> Config Class Initialized
INFO - 2022-12-15 02:34:33 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:33 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:33 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:33 --> URI Class Initialized
INFO - 2022-12-15 02:34:33 --> Router Class Initialized
INFO - 2022-12-15 02:34:33 --> Output Class Initialized
INFO - 2022-12-15 02:34:33 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:33 --> Input Class Initialized
INFO - 2022-12-15 02:34:33 --> Language Class Initialized
INFO - 2022-12-15 02:34:33 --> Language Class Initialized
INFO - 2022-12-15 02:34:33 --> Config Class Initialized
INFO - 2022-12-15 02:34:33 --> Loader Class Initialized
INFO - 2022-12-15 02:34:33 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:33 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:33 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:33 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:33 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:33 --> Controller Class Initialized
DEBUG - 2022-12-15 02:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-12-15 02:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 02:34:33 --> Final output sent to browser
DEBUG - 2022-12-15 02:34:33 --> Total execution time: 0.0674
INFO - 2022-12-15 02:34:33 --> Config Class Initialized
INFO - 2022-12-15 02:34:33 --> Hooks Class Initialized
DEBUG - 2022-12-15 02:34:33 --> UTF-8 Support Enabled
INFO - 2022-12-15 02:34:33 --> Utf8 Class Initialized
INFO - 2022-12-15 02:34:33 --> URI Class Initialized
INFO - 2022-12-15 02:34:33 --> Router Class Initialized
INFO - 2022-12-15 02:34:33 --> Output Class Initialized
INFO - 2022-12-15 02:34:33 --> Security Class Initialized
DEBUG - 2022-12-15 02:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 02:34:33 --> Input Class Initialized
INFO - 2022-12-15 02:34:33 --> Language Class Initialized
INFO - 2022-12-15 02:34:33 --> Language Class Initialized
INFO - 2022-12-15 02:34:33 --> Config Class Initialized
INFO - 2022-12-15 02:34:33 --> Loader Class Initialized
INFO - 2022-12-15 02:34:33 --> Helper loaded: url_helper
INFO - 2022-12-15 02:34:33 --> Helper loaded: file_helper
INFO - 2022-12-15 02:34:33 --> Helper loaded: form_helper
INFO - 2022-12-15 02:34:33 --> Helper loaded: my_helper
INFO - 2022-12-15 02:34:33 --> Database Driver Class Initialized
DEBUG - 2022-12-15 02:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 02:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 02:34:33 --> Controller Class Initialized
INFO - 2022-12-15 04:35:44 --> Config Class Initialized
INFO - 2022-12-15 04:35:44 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:35:44 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:35:44 --> Utf8 Class Initialized
INFO - 2022-12-15 04:35:44 --> URI Class Initialized
INFO - 2022-12-15 04:35:44 --> Router Class Initialized
INFO - 2022-12-15 04:35:44 --> Output Class Initialized
INFO - 2022-12-15 04:35:44 --> Security Class Initialized
DEBUG - 2022-12-15 04:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:35:44 --> Input Class Initialized
INFO - 2022-12-15 04:35:44 --> Language Class Initialized
INFO - 2022-12-15 04:35:44 --> Language Class Initialized
INFO - 2022-12-15 04:35:44 --> Config Class Initialized
INFO - 2022-12-15 04:35:44 --> Loader Class Initialized
INFO - 2022-12-15 04:35:44 --> Helper loaded: url_helper
INFO - 2022-12-15 04:35:44 --> Helper loaded: file_helper
INFO - 2022-12-15 04:35:44 --> Helper loaded: form_helper
INFO - 2022-12-15 04:35:44 --> Helper loaded: my_helper
INFO - 2022-12-15 04:35:44 --> Database Driver Class Initialized
DEBUG - 2022-12-15 04:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 04:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 04:35:45 --> Controller Class Initialized
INFO - 2022-12-15 04:35:45 --> Final output sent to browser
DEBUG - 2022-12-15 04:35:45 --> Total execution time: 0.0664
INFO - 2022-12-15 04:36:01 --> Config Class Initialized
INFO - 2022-12-15 04:36:01 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:36:01 --> Utf8 Class Initialized
INFO - 2022-12-15 04:36:01 --> URI Class Initialized
INFO - 2022-12-15 04:36:01 --> Router Class Initialized
INFO - 2022-12-15 04:36:01 --> Output Class Initialized
INFO - 2022-12-15 04:36:01 --> Security Class Initialized
DEBUG - 2022-12-15 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:36:01 --> Input Class Initialized
INFO - 2022-12-15 04:36:01 --> Language Class Initialized
INFO - 2022-12-15 04:36:01 --> Language Class Initialized
INFO - 2022-12-15 04:36:01 --> Config Class Initialized
INFO - 2022-12-15 04:36:01 --> Loader Class Initialized
INFO - 2022-12-15 04:36:01 --> Helper loaded: url_helper
INFO - 2022-12-15 04:36:01 --> Helper loaded: file_helper
INFO - 2022-12-15 04:36:01 --> Helper loaded: form_helper
INFO - 2022-12-15 04:36:01 --> Helper loaded: my_helper
INFO - 2022-12-15 04:36:01 --> Database Driver Class Initialized
DEBUG - 2022-12-15 04:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 04:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 04:36:01 --> Controller Class Initialized
DEBUG - 2022-12-15 04:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-15 04:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 04:36:01 --> Final output sent to browser
DEBUG - 2022-12-15 04:36:01 --> Total execution time: 0.0570
INFO - 2022-12-15 04:36:01 --> Config Class Initialized
INFO - 2022-12-15 04:36:01 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:36:01 --> Utf8 Class Initialized
INFO - 2022-12-15 04:36:01 --> URI Class Initialized
INFO - 2022-12-15 04:36:01 --> Router Class Initialized
INFO - 2022-12-15 04:36:01 --> Output Class Initialized
INFO - 2022-12-15 04:36:01 --> Security Class Initialized
DEBUG - 2022-12-15 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:36:01 --> Input Class Initialized
INFO - 2022-12-15 04:36:01 --> Language Class Initialized
INFO - 2022-12-15 04:36:01 --> Language Class Initialized
INFO - 2022-12-15 04:36:01 --> Config Class Initialized
INFO - 2022-12-15 04:36:01 --> Loader Class Initialized
INFO - 2022-12-15 04:36:01 --> Helper loaded: url_helper
INFO - 2022-12-15 04:36:01 --> Helper loaded: file_helper
INFO - 2022-12-15 04:36:01 --> Helper loaded: form_helper
INFO - 2022-12-15 04:36:01 --> Helper loaded: my_helper
INFO - 2022-12-15 04:36:01 --> Database Driver Class Initialized
DEBUG - 2022-12-15 04:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 04:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 04:36:01 --> Controller Class Initialized
INFO - 2022-12-15 06:07:38 --> Config Class Initialized
INFO - 2022-12-15 06:07:38 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:07:38 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:07:38 --> Utf8 Class Initialized
INFO - 2022-12-15 06:07:38 --> URI Class Initialized
INFO - 2022-12-15 06:07:38 --> Router Class Initialized
INFO - 2022-12-15 06:07:38 --> Output Class Initialized
INFO - 2022-12-15 06:07:38 --> Security Class Initialized
DEBUG - 2022-12-15 06:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:07:38 --> Input Class Initialized
INFO - 2022-12-15 06:07:38 --> Language Class Initialized
INFO - 2022-12-15 06:07:38 --> Language Class Initialized
INFO - 2022-12-15 06:07:38 --> Config Class Initialized
INFO - 2022-12-15 06:07:38 --> Loader Class Initialized
INFO - 2022-12-15 06:07:38 --> Helper loaded: url_helper
INFO - 2022-12-15 06:07:38 --> Helper loaded: file_helper
INFO - 2022-12-15 06:07:38 --> Helper loaded: form_helper
INFO - 2022-12-15 06:07:38 --> Helper loaded: my_helper
INFO - 2022-12-15 06:07:38 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:07:38 --> Controller Class Initialized
DEBUG - 2022-12-15 06:07:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-15 06:07:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 06:07:38 --> Final output sent to browser
DEBUG - 2022-12-15 06:07:38 --> Total execution time: 0.0774
INFO - 2022-12-15 06:07:38 --> Config Class Initialized
INFO - 2022-12-15 06:07:38 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:07:38 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:07:38 --> Utf8 Class Initialized
INFO - 2022-12-15 06:07:38 --> URI Class Initialized
INFO - 2022-12-15 06:07:38 --> Router Class Initialized
INFO - 2022-12-15 06:07:38 --> Output Class Initialized
INFO - 2022-12-15 06:07:38 --> Security Class Initialized
DEBUG - 2022-12-15 06:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:07:38 --> Input Class Initialized
INFO - 2022-12-15 06:07:38 --> Language Class Initialized
INFO - 2022-12-15 06:07:38 --> Language Class Initialized
INFO - 2022-12-15 06:07:38 --> Config Class Initialized
INFO - 2022-12-15 06:07:38 --> Loader Class Initialized
INFO - 2022-12-15 06:07:38 --> Helper loaded: url_helper
INFO - 2022-12-15 06:07:38 --> Helper loaded: file_helper
INFO - 2022-12-15 06:07:38 --> Helper loaded: form_helper
INFO - 2022-12-15 06:07:38 --> Helper loaded: my_helper
INFO - 2022-12-15 06:07:38 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:07:38 --> Controller Class Initialized
INFO - 2022-12-15 06:07:40 --> Config Class Initialized
INFO - 2022-12-15 06:07:40 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:07:40 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:07:40 --> Utf8 Class Initialized
INFO - 2022-12-15 06:07:40 --> URI Class Initialized
INFO - 2022-12-15 06:07:40 --> Router Class Initialized
INFO - 2022-12-15 06:07:40 --> Output Class Initialized
INFO - 2022-12-15 06:07:40 --> Security Class Initialized
DEBUG - 2022-12-15 06:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:07:40 --> Input Class Initialized
INFO - 2022-12-15 06:07:40 --> Language Class Initialized
INFO - 2022-12-15 06:07:40 --> Language Class Initialized
INFO - 2022-12-15 06:07:40 --> Config Class Initialized
INFO - 2022-12-15 06:07:40 --> Loader Class Initialized
INFO - 2022-12-15 06:07:40 --> Helper loaded: url_helper
INFO - 2022-12-15 06:07:40 --> Helper loaded: file_helper
INFO - 2022-12-15 06:07:40 --> Helper loaded: form_helper
INFO - 2022-12-15 06:07:40 --> Helper loaded: my_helper
INFO - 2022-12-15 06:07:40 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:07:40 --> Controller Class Initialized
ERROR - 2022-12-15 06:07:40 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-12-15 06:07:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-12-15 06:07:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 06:07:40 --> Final output sent to browser
DEBUG - 2022-12-15 06:07:40 --> Total execution time: 0.2394
INFO - 2022-12-15 06:07:58 --> Config Class Initialized
INFO - 2022-12-15 06:07:58 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:07:58 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:07:58 --> Utf8 Class Initialized
INFO - 2022-12-15 06:07:58 --> URI Class Initialized
INFO - 2022-12-15 06:07:58 --> Router Class Initialized
INFO - 2022-12-15 06:07:58 --> Output Class Initialized
INFO - 2022-12-15 06:07:58 --> Security Class Initialized
DEBUG - 2022-12-15 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:07:58 --> Input Class Initialized
INFO - 2022-12-15 06:07:58 --> Language Class Initialized
INFO - 2022-12-15 06:07:58 --> Language Class Initialized
INFO - 2022-12-15 06:07:58 --> Config Class Initialized
INFO - 2022-12-15 06:07:58 --> Loader Class Initialized
INFO - 2022-12-15 06:07:58 --> Helper loaded: url_helper
INFO - 2022-12-15 06:07:58 --> Helper loaded: file_helper
INFO - 2022-12-15 06:07:58 --> Helper loaded: form_helper
INFO - 2022-12-15 06:07:58 --> Helper loaded: my_helper
INFO - 2022-12-15 06:07:58 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:07:58 --> Controller Class Initialized
DEBUG - 2022-12-15 06:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-15 06:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 06:07:58 --> Final output sent to browser
DEBUG - 2022-12-15 06:07:58 --> Total execution time: 0.0861
INFO - 2022-12-15 06:07:58 --> Config Class Initialized
INFO - 2022-12-15 06:07:58 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:07:58 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:07:58 --> Utf8 Class Initialized
INFO - 2022-12-15 06:07:58 --> URI Class Initialized
INFO - 2022-12-15 06:07:58 --> Router Class Initialized
INFO - 2022-12-15 06:07:58 --> Output Class Initialized
INFO - 2022-12-15 06:07:58 --> Security Class Initialized
DEBUG - 2022-12-15 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:07:58 --> Input Class Initialized
INFO - 2022-12-15 06:07:58 --> Language Class Initialized
INFO - 2022-12-15 06:07:58 --> Language Class Initialized
INFO - 2022-12-15 06:07:58 --> Config Class Initialized
INFO - 2022-12-15 06:07:58 --> Loader Class Initialized
INFO - 2022-12-15 06:07:58 --> Helper loaded: url_helper
INFO - 2022-12-15 06:07:58 --> Helper loaded: file_helper
INFO - 2022-12-15 06:07:58 --> Helper loaded: form_helper
INFO - 2022-12-15 06:07:58 --> Helper loaded: my_helper
INFO - 2022-12-15 06:07:58 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:07:58 --> Controller Class Initialized
INFO - 2022-12-15 06:08:00 --> Config Class Initialized
INFO - 2022-12-15 06:08:00 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:00 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:00 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:00 --> URI Class Initialized
INFO - 2022-12-15 06:08:00 --> Router Class Initialized
INFO - 2022-12-15 06:08:00 --> Output Class Initialized
INFO - 2022-12-15 06:08:00 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:00 --> Input Class Initialized
INFO - 2022-12-15 06:08:00 --> Language Class Initialized
INFO - 2022-12-15 06:08:00 --> Language Class Initialized
INFO - 2022-12-15 06:08:00 --> Config Class Initialized
INFO - 2022-12-15 06:08:00 --> Loader Class Initialized
INFO - 2022-12-15 06:08:00 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:00 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:00 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:00 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:00 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:00 --> Controller Class Initialized
INFO - 2022-12-15 06:08:01 --> Config Class Initialized
INFO - 2022-12-15 06:08:01 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:01 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:01 --> URI Class Initialized
INFO - 2022-12-15 06:08:01 --> Router Class Initialized
INFO - 2022-12-15 06:08:01 --> Output Class Initialized
INFO - 2022-12-15 06:08:01 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:01 --> Input Class Initialized
INFO - 2022-12-15 06:08:01 --> Language Class Initialized
INFO - 2022-12-15 06:08:01 --> Language Class Initialized
INFO - 2022-12-15 06:08:01 --> Config Class Initialized
INFO - 2022-12-15 06:08:01 --> Loader Class Initialized
INFO - 2022-12-15 06:08:01 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:01 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:01 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:01 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:01 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:01 --> Controller Class Initialized
INFO - 2022-12-15 06:08:02 --> Config Class Initialized
INFO - 2022-12-15 06:08:02 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:02 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:02 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:02 --> URI Class Initialized
INFO - 2022-12-15 06:08:02 --> Router Class Initialized
INFO - 2022-12-15 06:08:02 --> Output Class Initialized
INFO - 2022-12-15 06:08:02 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:02 --> Input Class Initialized
INFO - 2022-12-15 06:08:02 --> Language Class Initialized
INFO - 2022-12-15 06:08:02 --> Language Class Initialized
INFO - 2022-12-15 06:08:02 --> Config Class Initialized
INFO - 2022-12-15 06:08:02 --> Loader Class Initialized
INFO - 2022-12-15 06:08:02 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:02 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:02 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:02 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:02 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:02 --> Controller Class Initialized
INFO - 2022-12-15 06:08:02 --> Config Class Initialized
INFO - 2022-12-15 06:08:02 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:02 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:02 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:02 --> URI Class Initialized
INFO - 2022-12-15 06:08:02 --> Router Class Initialized
INFO - 2022-12-15 06:08:02 --> Output Class Initialized
INFO - 2022-12-15 06:08:02 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:02 --> Input Class Initialized
INFO - 2022-12-15 06:08:02 --> Language Class Initialized
INFO - 2022-12-15 06:08:02 --> Language Class Initialized
INFO - 2022-12-15 06:08:02 --> Config Class Initialized
INFO - 2022-12-15 06:08:02 --> Loader Class Initialized
INFO - 2022-12-15 06:08:02 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:02 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:02 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:02 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:02 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:03 --> Controller Class Initialized
INFO - 2022-12-15 06:08:03 --> Config Class Initialized
INFO - 2022-12-15 06:08:03 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:03 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:03 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:03 --> URI Class Initialized
INFO - 2022-12-15 06:08:03 --> Router Class Initialized
INFO - 2022-12-15 06:08:03 --> Output Class Initialized
INFO - 2022-12-15 06:08:03 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:03 --> Input Class Initialized
INFO - 2022-12-15 06:08:03 --> Language Class Initialized
INFO - 2022-12-15 06:08:03 --> Language Class Initialized
INFO - 2022-12-15 06:08:03 --> Config Class Initialized
INFO - 2022-12-15 06:08:03 --> Loader Class Initialized
INFO - 2022-12-15 06:08:03 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:03 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:03 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:03 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:03 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:03 --> Controller Class Initialized
INFO - 2022-12-15 06:08:03 --> Config Class Initialized
INFO - 2022-12-15 06:08:03 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:03 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:03 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:03 --> URI Class Initialized
INFO - 2022-12-15 06:08:04 --> Router Class Initialized
INFO - 2022-12-15 06:08:04 --> Output Class Initialized
INFO - 2022-12-15 06:08:04 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:04 --> Input Class Initialized
INFO - 2022-12-15 06:08:04 --> Language Class Initialized
INFO - 2022-12-15 06:08:04 --> Language Class Initialized
INFO - 2022-12-15 06:08:04 --> Config Class Initialized
INFO - 2022-12-15 06:08:04 --> Loader Class Initialized
INFO - 2022-12-15 06:08:04 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:04 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:04 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:04 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:04 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:04 --> Controller Class Initialized
INFO - 2022-12-15 06:08:06 --> Config Class Initialized
INFO - 2022-12-15 06:08:06 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:06 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:06 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:06 --> URI Class Initialized
INFO - 2022-12-15 06:08:06 --> Router Class Initialized
INFO - 2022-12-15 06:08:06 --> Output Class Initialized
INFO - 2022-12-15 06:08:06 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:06 --> Input Class Initialized
INFO - 2022-12-15 06:08:06 --> Language Class Initialized
INFO - 2022-12-15 06:08:06 --> Language Class Initialized
INFO - 2022-12-15 06:08:06 --> Config Class Initialized
INFO - 2022-12-15 06:08:06 --> Loader Class Initialized
INFO - 2022-12-15 06:08:06 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:06 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:06 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:06 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:06 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:06 --> Controller Class Initialized
INFO - 2022-12-15 06:08:06 --> Config Class Initialized
INFO - 2022-12-15 06:08:06 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:06 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:06 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:06 --> URI Class Initialized
INFO - 2022-12-15 06:08:06 --> Router Class Initialized
INFO - 2022-12-15 06:08:06 --> Output Class Initialized
INFO - 2022-12-15 06:08:06 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:06 --> Input Class Initialized
INFO - 2022-12-15 06:08:06 --> Language Class Initialized
INFO - 2022-12-15 06:08:06 --> Language Class Initialized
INFO - 2022-12-15 06:08:06 --> Config Class Initialized
INFO - 2022-12-15 06:08:06 --> Loader Class Initialized
INFO - 2022-12-15 06:08:06 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:06 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:06 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:06 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:06 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:07 --> Controller Class Initialized
INFO - 2022-12-15 06:08:09 --> Config Class Initialized
INFO - 2022-12-15 06:08:09 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:08:09 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:08:09 --> Utf8 Class Initialized
INFO - 2022-12-15 06:08:09 --> URI Class Initialized
INFO - 2022-12-15 06:08:09 --> Router Class Initialized
INFO - 2022-12-15 06:08:09 --> Output Class Initialized
INFO - 2022-12-15 06:08:09 --> Security Class Initialized
DEBUG - 2022-12-15 06:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:08:09 --> Input Class Initialized
INFO - 2022-12-15 06:08:09 --> Language Class Initialized
INFO - 2022-12-15 06:08:09 --> Language Class Initialized
INFO - 2022-12-15 06:08:09 --> Config Class Initialized
INFO - 2022-12-15 06:08:09 --> Loader Class Initialized
INFO - 2022-12-15 06:08:09 --> Helper loaded: url_helper
INFO - 2022-12-15 06:08:09 --> Helper loaded: file_helper
INFO - 2022-12-15 06:08:09 --> Helper loaded: form_helper
INFO - 2022-12-15 06:08:09 --> Helper loaded: my_helper
INFO - 2022-12-15 06:08:09 --> Database Driver Class Initialized
DEBUG - 2022-12-15 06:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 06:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 06:08:09 --> Controller Class Initialized
ERROR - 2022-12-15 06:08:09 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-12-15 06:08:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-12-15 06:08:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 06:08:09 --> Final output sent to browser
DEBUG - 2022-12-15 06:08:09 --> Total execution time: 0.0972
INFO - 2022-12-15 08:39:52 --> Config Class Initialized
INFO - 2022-12-15 08:39:52 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:39:52 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:39:52 --> Utf8 Class Initialized
INFO - 2022-12-15 08:39:52 --> URI Class Initialized
DEBUG - 2022-12-15 08:39:52 --> No URI present. Default controller set.
INFO - 2022-12-15 08:39:52 --> Router Class Initialized
INFO - 2022-12-15 08:39:52 --> Output Class Initialized
INFO - 2022-12-15 08:39:52 --> Security Class Initialized
DEBUG - 2022-12-15 08:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:39:52 --> Input Class Initialized
INFO - 2022-12-15 08:39:52 --> Language Class Initialized
INFO - 2022-12-15 08:39:52 --> Language Class Initialized
INFO - 2022-12-15 08:39:52 --> Config Class Initialized
INFO - 2022-12-15 08:39:52 --> Loader Class Initialized
INFO - 2022-12-15 08:39:52 --> Helper loaded: url_helper
INFO - 2022-12-15 08:39:52 --> Helper loaded: file_helper
INFO - 2022-12-15 08:39:52 --> Helper loaded: form_helper
INFO - 2022-12-15 08:39:52 --> Helper loaded: my_helper
INFO - 2022-12-15 08:39:52 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:39:52 --> Controller Class Initialized
INFO - 2022-12-15 08:39:52 --> Config Class Initialized
INFO - 2022-12-15 08:39:52 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:39:52 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:39:52 --> Utf8 Class Initialized
INFO - 2022-12-15 08:39:52 --> URI Class Initialized
INFO - 2022-12-15 08:39:52 --> Router Class Initialized
INFO - 2022-12-15 08:39:52 --> Output Class Initialized
INFO - 2022-12-15 08:39:52 --> Security Class Initialized
DEBUG - 2022-12-15 08:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:39:52 --> Input Class Initialized
INFO - 2022-12-15 08:39:52 --> Language Class Initialized
INFO - 2022-12-15 08:39:52 --> Language Class Initialized
INFO - 2022-12-15 08:39:52 --> Config Class Initialized
INFO - 2022-12-15 08:39:52 --> Loader Class Initialized
INFO - 2022-12-15 08:39:52 --> Helper loaded: url_helper
INFO - 2022-12-15 08:39:52 --> Helper loaded: file_helper
INFO - 2022-12-15 08:39:52 --> Helper loaded: form_helper
INFO - 2022-12-15 08:39:52 --> Helper loaded: my_helper
INFO - 2022-12-15 08:39:52 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:39:52 --> Controller Class Initialized
DEBUG - 2022-12-15 08:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-15 08:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 08:39:52 --> Final output sent to browser
DEBUG - 2022-12-15 08:39:52 --> Total execution time: 0.1251
INFO - 2022-12-15 08:49:26 --> Config Class Initialized
INFO - 2022-12-15 08:49:26 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:49:26 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:49:26 --> Utf8 Class Initialized
INFO - 2022-12-15 08:49:26 --> URI Class Initialized
INFO - 2022-12-15 08:49:26 --> Router Class Initialized
INFO - 2022-12-15 08:49:26 --> Output Class Initialized
INFO - 2022-12-15 08:49:26 --> Security Class Initialized
DEBUG - 2022-12-15 08:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:49:26 --> Input Class Initialized
INFO - 2022-12-15 08:49:26 --> Language Class Initialized
INFO - 2022-12-15 08:49:26 --> Language Class Initialized
INFO - 2022-12-15 08:49:26 --> Config Class Initialized
INFO - 2022-12-15 08:49:26 --> Loader Class Initialized
INFO - 2022-12-15 08:49:26 --> Helper loaded: url_helper
INFO - 2022-12-15 08:49:26 --> Helper loaded: file_helper
INFO - 2022-12-15 08:49:26 --> Helper loaded: form_helper
INFO - 2022-12-15 08:49:26 --> Helper loaded: my_helper
INFO - 2022-12-15 08:49:26 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:49:26 --> Controller Class Initialized
INFO - 2022-12-15 08:49:26 --> Helper loaded: cookie_helper
INFO - 2022-12-15 08:49:26 --> Final output sent to browser
DEBUG - 2022-12-15 08:49:26 --> Total execution time: 0.1031
INFO - 2022-12-15 08:49:27 --> Config Class Initialized
INFO - 2022-12-15 08:49:27 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:49:27 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:49:27 --> Utf8 Class Initialized
INFO - 2022-12-15 08:49:27 --> URI Class Initialized
INFO - 2022-12-15 08:49:27 --> Router Class Initialized
INFO - 2022-12-15 08:49:27 --> Output Class Initialized
INFO - 2022-12-15 08:49:27 --> Security Class Initialized
DEBUG - 2022-12-15 08:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:49:27 --> Input Class Initialized
INFO - 2022-12-15 08:49:27 --> Language Class Initialized
INFO - 2022-12-15 08:49:27 --> Language Class Initialized
INFO - 2022-12-15 08:49:27 --> Config Class Initialized
INFO - 2022-12-15 08:49:27 --> Loader Class Initialized
INFO - 2022-12-15 08:49:27 --> Helper loaded: url_helper
INFO - 2022-12-15 08:49:27 --> Helper loaded: file_helper
INFO - 2022-12-15 08:49:27 --> Helper loaded: form_helper
INFO - 2022-12-15 08:49:27 --> Helper loaded: my_helper
INFO - 2022-12-15 08:49:27 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:49:27 --> Controller Class Initialized
DEBUG - 2022-12-15 08:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-12-15 08:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 08:49:27 --> Final output sent to browser
DEBUG - 2022-12-15 08:49:27 --> Total execution time: 0.1366
INFO - 2022-12-15 08:49:28 --> Config Class Initialized
INFO - 2022-12-15 08:49:28 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:49:28 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:49:28 --> Utf8 Class Initialized
INFO - 2022-12-15 08:49:28 --> URI Class Initialized
INFO - 2022-12-15 08:49:28 --> Router Class Initialized
INFO - 2022-12-15 08:49:28 --> Output Class Initialized
INFO - 2022-12-15 08:49:28 --> Security Class Initialized
DEBUG - 2022-12-15 08:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:49:28 --> Input Class Initialized
INFO - 2022-12-15 08:49:28 --> Language Class Initialized
INFO - 2022-12-15 08:49:28 --> Language Class Initialized
INFO - 2022-12-15 08:49:28 --> Config Class Initialized
INFO - 2022-12-15 08:49:28 --> Loader Class Initialized
INFO - 2022-12-15 08:49:28 --> Helper loaded: url_helper
INFO - 2022-12-15 08:49:28 --> Helper loaded: file_helper
INFO - 2022-12-15 08:49:28 --> Helper loaded: form_helper
INFO - 2022-12-15 08:49:28 --> Helper loaded: my_helper
INFO - 2022-12-15 08:49:28 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:49:28 --> Controller Class Initialized
DEBUG - 2022-12-15 08:49:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2022-12-15 08:49:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 08:49:28 --> Final output sent to browser
DEBUG - 2022-12-15 08:49:28 --> Total execution time: 0.0990
INFO - 2022-12-15 08:49:28 --> Config Class Initialized
INFO - 2022-12-15 08:49:28 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:49:28 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:49:28 --> Utf8 Class Initialized
INFO - 2022-12-15 08:49:28 --> URI Class Initialized
INFO - 2022-12-15 08:49:28 --> Router Class Initialized
INFO - 2022-12-15 08:49:28 --> Output Class Initialized
INFO - 2022-12-15 08:49:28 --> Security Class Initialized
DEBUG - 2022-12-15 08:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:49:28 --> Input Class Initialized
INFO - 2022-12-15 08:49:28 --> Language Class Initialized
INFO - 2022-12-15 08:49:28 --> Language Class Initialized
INFO - 2022-12-15 08:49:28 --> Config Class Initialized
INFO - 2022-12-15 08:49:28 --> Loader Class Initialized
INFO - 2022-12-15 08:49:28 --> Helper loaded: url_helper
INFO - 2022-12-15 08:49:28 --> Helper loaded: file_helper
INFO - 2022-12-15 08:49:28 --> Helper loaded: form_helper
INFO - 2022-12-15 08:49:28 --> Helper loaded: my_helper
INFO - 2022-12-15 08:49:28 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:49:28 --> Controller Class Initialized
INFO - 2022-12-15 08:49:29 --> Config Class Initialized
INFO - 2022-12-15 08:49:29 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:49:29 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:49:29 --> Utf8 Class Initialized
INFO - 2022-12-15 08:49:29 --> URI Class Initialized
INFO - 2022-12-15 08:49:29 --> Router Class Initialized
INFO - 2022-12-15 08:49:29 --> Output Class Initialized
INFO - 2022-12-15 08:49:29 --> Security Class Initialized
DEBUG - 2022-12-15 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:49:29 --> Input Class Initialized
INFO - 2022-12-15 08:49:29 --> Language Class Initialized
INFO - 2022-12-15 08:49:29 --> Language Class Initialized
INFO - 2022-12-15 08:49:29 --> Config Class Initialized
INFO - 2022-12-15 08:49:29 --> Loader Class Initialized
INFO - 2022-12-15 08:49:29 --> Helper loaded: url_helper
INFO - 2022-12-15 08:49:29 --> Helper loaded: file_helper
INFO - 2022-12-15 08:49:29 --> Helper loaded: form_helper
INFO - 2022-12-15 08:49:29 --> Helper loaded: my_helper
INFO - 2022-12-15 08:49:29 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:49:29 --> Controller Class Initialized
DEBUG - 2022-12-15 08:49:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-15 08:49:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 08:49:29 --> Final output sent to browser
DEBUG - 2022-12-15 08:49:29 --> Total execution time: 0.0947
INFO - 2022-12-15 08:49:29 --> Config Class Initialized
INFO - 2022-12-15 08:49:29 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:49:29 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:49:29 --> Utf8 Class Initialized
INFO - 2022-12-15 08:49:29 --> URI Class Initialized
INFO - 2022-12-15 08:49:29 --> Router Class Initialized
INFO - 2022-12-15 08:49:29 --> Output Class Initialized
INFO - 2022-12-15 08:49:29 --> Security Class Initialized
DEBUG - 2022-12-15 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:49:29 --> Input Class Initialized
INFO - 2022-12-15 08:49:29 --> Language Class Initialized
INFO - 2022-12-15 08:49:29 --> Language Class Initialized
INFO - 2022-12-15 08:49:29 --> Config Class Initialized
INFO - 2022-12-15 08:49:29 --> Loader Class Initialized
INFO - 2022-12-15 08:49:29 --> Helper loaded: url_helper
INFO - 2022-12-15 08:49:29 --> Helper loaded: file_helper
INFO - 2022-12-15 08:49:29 --> Helper loaded: form_helper
INFO - 2022-12-15 08:49:29 --> Helper loaded: my_helper
INFO - 2022-12-15 08:49:29 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:49:29 --> Controller Class Initialized
INFO - 2022-12-15 08:49:30 --> Config Class Initialized
INFO - 2022-12-15 08:49:30 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:49:30 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:49:30 --> Utf8 Class Initialized
INFO - 2022-12-15 08:49:30 --> URI Class Initialized
INFO - 2022-12-15 08:49:30 --> Router Class Initialized
INFO - 2022-12-15 08:49:30 --> Output Class Initialized
INFO - 2022-12-15 08:49:30 --> Security Class Initialized
DEBUG - 2022-12-15 08:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:49:30 --> Input Class Initialized
INFO - 2022-12-15 08:49:30 --> Language Class Initialized
INFO - 2022-12-15 08:49:30 --> Language Class Initialized
INFO - 2022-12-15 08:49:30 --> Config Class Initialized
INFO - 2022-12-15 08:49:30 --> Loader Class Initialized
INFO - 2022-12-15 08:49:30 --> Helper loaded: url_helper
INFO - 2022-12-15 08:49:30 --> Helper loaded: file_helper
INFO - 2022-12-15 08:49:30 --> Helper loaded: form_helper
INFO - 2022-12-15 08:49:30 --> Helper loaded: my_helper
INFO - 2022-12-15 08:49:30 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-15 08:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-15 08:49:30 --> Controller Class Initialized
ERROR - 2022-12-15 08:49:30 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-12-15 08:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-12-15 08:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-15 08:49:30 --> Final output sent to browser
DEBUG - 2022-12-15 08:49:30 --> Total execution time: 0.1766
