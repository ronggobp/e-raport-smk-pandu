<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-20 03:29:56 --> Config Class Initialized
INFO - 2022-05-20 03:29:56 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:29:56 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:29:56 --> Utf8 Class Initialized
INFO - 2022-05-20 03:29:56 --> URI Class Initialized
DEBUG - 2022-05-20 03:29:56 --> No URI present. Default controller set.
INFO - 2022-05-20 03:29:56 --> Router Class Initialized
INFO - 2022-05-20 03:29:56 --> Output Class Initialized
INFO - 2022-05-20 03:29:56 --> Security Class Initialized
DEBUG - 2022-05-20 03:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:29:56 --> Input Class Initialized
INFO - 2022-05-20 03:29:56 --> Language Class Initialized
INFO - 2022-05-20 03:29:56 --> Language Class Initialized
INFO - 2022-05-20 03:29:56 --> Config Class Initialized
INFO - 2022-05-20 03:29:56 --> Loader Class Initialized
INFO - 2022-05-20 03:29:56 --> Helper loaded: url_helper
INFO - 2022-05-20 03:29:56 --> Helper loaded: file_helper
INFO - 2022-05-20 03:29:56 --> Helper loaded: form_helper
INFO - 2022-05-20 03:29:56 --> Helper loaded: my_helper
INFO - 2022-05-20 03:29:56 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:29:56 --> Controller Class Initialized
INFO - 2022-05-20 03:29:57 --> Config Class Initialized
INFO - 2022-05-20 03:29:57 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:29:57 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:29:57 --> Utf8 Class Initialized
INFO - 2022-05-20 03:29:57 --> URI Class Initialized
INFO - 2022-05-20 03:29:57 --> Router Class Initialized
INFO - 2022-05-20 03:29:57 --> Output Class Initialized
INFO - 2022-05-20 03:29:57 --> Security Class Initialized
DEBUG - 2022-05-20 03:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:29:57 --> Input Class Initialized
INFO - 2022-05-20 03:29:57 --> Language Class Initialized
INFO - 2022-05-20 03:29:57 --> Language Class Initialized
INFO - 2022-05-20 03:29:57 --> Config Class Initialized
INFO - 2022-05-20 03:29:57 --> Loader Class Initialized
INFO - 2022-05-20 03:29:57 --> Helper loaded: url_helper
INFO - 2022-05-20 03:29:57 --> Helper loaded: file_helper
INFO - 2022-05-20 03:29:57 --> Helper loaded: form_helper
INFO - 2022-05-20 03:29:57 --> Helper loaded: my_helper
INFO - 2022-05-20 03:29:57 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:29:57 --> Controller Class Initialized
DEBUG - 2022-05-20 03:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-20 03:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-20 03:29:57 --> Final output sent to browser
DEBUG - 2022-05-20 03:29:57 --> Total execution time: 0.1151
INFO - 2022-05-20 03:30:01 --> Config Class Initialized
INFO - 2022-05-20 03:30:01 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:30:01 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:30:01 --> Utf8 Class Initialized
INFO - 2022-05-20 03:30:01 --> URI Class Initialized
INFO - 2022-05-20 03:30:01 --> Router Class Initialized
INFO - 2022-05-20 03:30:01 --> Output Class Initialized
INFO - 2022-05-20 03:30:01 --> Security Class Initialized
DEBUG - 2022-05-20 03:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:30:01 --> Input Class Initialized
INFO - 2022-05-20 03:30:01 --> Language Class Initialized
INFO - 2022-05-20 03:30:01 --> Language Class Initialized
INFO - 2022-05-20 03:30:01 --> Config Class Initialized
INFO - 2022-05-20 03:30:01 --> Loader Class Initialized
INFO - 2022-05-20 03:30:01 --> Helper loaded: url_helper
INFO - 2022-05-20 03:30:01 --> Helper loaded: file_helper
INFO - 2022-05-20 03:30:01 --> Helper loaded: form_helper
INFO - 2022-05-20 03:30:01 --> Helper loaded: my_helper
INFO - 2022-05-20 03:30:01 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:30:01 --> Controller Class Initialized
INFO - 2022-05-20 03:30:01 --> Helper loaded: cookie_helper
INFO - 2022-05-20 03:30:01 --> Final output sent to browser
DEBUG - 2022-05-20 03:30:01 --> Total execution time: 0.0909
INFO - 2022-05-20 03:30:01 --> Config Class Initialized
INFO - 2022-05-20 03:30:01 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:30:01 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:30:01 --> Utf8 Class Initialized
INFO - 2022-05-20 03:30:01 --> URI Class Initialized
INFO - 2022-05-20 03:30:01 --> Router Class Initialized
INFO - 2022-05-20 03:30:01 --> Output Class Initialized
INFO - 2022-05-20 03:30:01 --> Security Class Initialized
DEBUG - 2022-05-20 03:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:30:01 --> Input Class Initialized
INFO - 2022-05-20 03:30:01 --> Language Class Initialized
INFO - 2022-05-20 03:30:01 --> Language Class Initialized
INFO - 2022-05-20 03:30:01 --> Config Class Initialized
INFO - 2022-05-20 03:30:01 --> Loader Class Initialized
INFO - 2022-05-20 03:30:01 --> Helper loaded: url_helper
INFO - 2022-05-20 03:30:01 --> Helper loaded: file_helper
INFO - 2022-05-20 03:30:01 --> Helper loaded: form_helper
INFO - 2022-05-20 03:30:01 --> Helper loaded: my_helper
INFO - 2022-05-20 03:30:01 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:30:01 --> Controller Class Initialized
DEBUG - 2022-05-20 03:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-20 03:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-20 03:30:01 --> Final output sent to browser
DEBUG - 2022-05-20 03:30:01 --> Total execution time: 0.1676
INFO - 2022-05-20 03:30:04 --> Config Class Initialized
INFO - 2022-05-20 03:30:04 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:30:04 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:30:04 --> Utf8 Class Initialized
INFO - 2022-05-20 03:30:04 --> URI Class Initialized
INFO - 2022-05-20 03:30:04 --> Router Class Initialized
INFO - 2022-05-20 03:30:04 --> Output Class Initialized
INFO - 2022-05-20 03:30:04 --> Security Class Initialized
DEBUG - 2022-05-20 03:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:30:05 --> Input Class Initialized
INFO - 2022-05-20 03:30:05 --> Language Class Initialized
INFO - 2022-05-20 03:30:05 --> Language Class Initialized
INFO - 2022-05-20 03:30:05 --> Config Class Initialized
INFO - 2022-05-20 03:30:05 --> Loader Class Initialized
INFO - 2022-05-20 03:30:05 --> Helper loaded: url_helper
INFO - 2022-05-20 03:30:05 --> Helper loaded: file_helper
INFO - 2022-05-20 03:30:05 --> Helper loaded: form_helper
INFO - 2022-05-20 03:30:05 --> Helper loaded: my_helper
INFO - 2022-05-20 03:30:05 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:30:05 --> Controller Class Initialized
DEBUG - 2022-05-20 03:30:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-05-20 03:30:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-20 03:30:05 --> Final output sent to browser
DEBUG - 2022-05-20 03:30:05 --> Total execution time: 0.1013
INFO - 2022-05-20 03:30:05 --> Config Class Initialized
INFO - 2022-05-20 03:30:05 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:30:05 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:30:05 --> Utf8 Class Initialized
INFO - 2022-05-20 03:30:05 --> URI Class Initialized
INFO - 2022-05-20 03:30:05 --> Router Class Initialized
INFO - 2022-05-20 03:30:05 --> Output Class Initialized
INFO - 2022-05-20 03:30:05 --> Security Class Initialized
DEBUG - 2022-05-20 03:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:30:05 --> Input Class Initialized
INFO - 2022-05-20 03:30:05 --> Language Class Initialized
INFO - 2022-05-20 03:30:05 --> Language Class Initialized
INFO - 2022-05-20 03:30:05 --> Config Class Initialized
INFO - 2022-05-20 03:30:05 --> Loader Class Initialized
INFO - 2022-05-20 03:30:05 --> Helper loaded: url_helper
INFO - 2022-05-20 03:30:05 --> Helper loaded: file_helper
INFO - 2022-05-20 03:30:05 --> Helper loaded: form_helper
INFO - 2022-05-20 03:30:05 --> Helper loaded: my_helper
INFO - 2022-05-20 03:30:05 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:30:05 --> Controller Class Initialized
INFO - 2022-05-20 03:30:08 --> Config Class Initialized
INFO - 2022-05-20 03:30:08 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:30:08 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:30:08 --> Utf8 Class Initialized
INFO - 2022-05-20 03:30:08 --> URI Class Initialized
INFO - 2022-05-20 03:30:08 --> Router Class Initialized
INFO - 2022-05-20 03:30:08 --> Output Class Initialized
INFO - 2022-05-20 03:30:08 --> Security Class Initialized
DEBUG - 2022-05-20 03:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:30:08 --> Input Class Initialized
INFO - 2022-05-20 03:30:08 --> Language Class Initialized
INFO - 2022-05-20 03:30:08 --> Language Class Initialized
INFO - 2022-05-20 03:30:08 --> Config Class Initialized
INFO - 2022-05-20 03:30:08 --> Loader Class Initialized
INFO - 2022-05-20 03:30:08 --> Helper loaded: url_helper
INFO - 2022-05-20 03:30:08 --> Helper loaded: file_helper
INFO - 2022-05-20 03:30:08 --> Helper loaded: form_helper
INFO - 2022-05-20 03:30:08 --> Helper loaded: my_helper
INFO - 2022-05-20 03:30:08 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:30:08 --> Controller Class Initialized
ERROR - 2022-05-20 03:30:08 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-05-20 03:30:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-05-20 03:30:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-20 03:30:08 --> Final output sent to browser
DEBUG - 2022-05-20 03:30:08 --> Total execution time: 0.1469
INFO - 2022-05-20 03:30:41 --> Config Class Initialized
INFO - 2022-05-20 03:30:41 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:30:41 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:30:41 --> Utf8 Class Initialized
INFO - 2022-05-20 03:30:41 --> URI Class Initialized
INFO - 2022-05-20 03:30:41 --> Router Class Initialized
INFO - 2022-05-20 03:30:41 --> Output Class Initialized
INFO - 2022-05-20 03:30:41 --> Security Class Initialized
DEBUG - 2022-05-20 03:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:30:41 --> Input Class Initialized
INFO - 2022-05-20 03:30:41 --> Language Class Initialized
INFO - 2022-05-20 03:30:41 --> Language Class Initialized
INFO - 2022-05-20 03:30:41 --> Config Class Initialized
INFO - 2022-05-20 03:30:41 --> Loader Class Initialized
INFO - 2022-05-20 03:30:41 --> Helper loaded: url_helper
INFO - 2022-05-20 03:30:41 --> Helper loaded: file_helper
INFO - 2022-05-20 03:30:41 --> Helper loaded: form_helper
INFO - 2022-05-20 03:30:41 --> Helper loaded: my_helper
INFO - 2022-05-20 03:30:41 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:30:41 --> Controller Class Initialized
DEBUG - 2022-05-20 03:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-05-20 03:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-20 03:30:41 --> Final output sent to browser
DEBUG - 2022-05-20 03:30:41 --> Total execution time: 0.0765
INFO - 2022-05-20 03:30:41 --> Config Class Initialized
INFO - 2022-05-20 03:30:41 --> Hooks Class Initialized
DEBUG - 2022-05-20 03:30:41 --> UTF-8 Support Enabled
INFO - 2022-05-20 03:30:41 --> Utf8 Class Initialized
INFO - 2022-05-20 03:30:41 --> URI Class Initialized
INFO - 2022-05-20 03:30:41 --> Router Class Initialized
INFO - 2022-05-20 03:30:41 --> Output Class Initialized
INFO - 2022-05-20 03:30:41 --> Security Class Initialized
DEBUG - 2022-05-20 03:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-20 03:30:41 --> Input Class Initialized
INFO - 2022-05-20 03:30:41 --> Language Class Initialized
INFO - 2022-05-20 03:30:41 --> Language Class Initialized
INFO - 2022-05-20 03:30:41 --> Config Class Initialized
INFO - 2022-05-20 03:30:41 --> Loader Class Initialized
INFO - 2022-05-20 03:30:41 --> Helper loaded: url_helper
INFO - 2022-05-20 03:30:41 --> Helper loaded: file_helper
INFO - 2022-05-20 03:30:41 --> Helper loaded: form_helper
INFO - 2022-05-20 03:30:41 --> Helper loaded: my_helper
INFO - 2022-05-20 03:30:41 --> Database Driver Class Initialized
DEBUG - 2022-05-20 03:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-20 03:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-20 03:30:41 --> Controller Class Initialized
