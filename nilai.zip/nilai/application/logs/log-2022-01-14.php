<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-01-14 07:31:55 --> Config Class Initialized
INFO - 2022-01-14 07:31:55 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:31:55 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:31:55 --> Utf8 Class Initialized
INFO - 2022-01-14 07:31:55 --> URI Class Initialized
DEBUG - 2022-01-14 07:31:55 --> No URI present. Default controller set.
INFO - 2022-01-14 07:31:55 --> Router Class Initialized
INFO - 2022-01-14 07:31:55 --> Output Class Initialized
INFO - 2022-01-14 07:31:55 --> Security Class Initialized
DEBUG - 2022-01-14 07:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:31:55 --> Input Class Initialized
INFO - 2022-01-14 07:31:55 --> Language Class Initialized
INFO - 2022-01-14 07:31:55 --> Language Class Initialized
INFO - 2022-01-14 07:31:55 --> Config Class Initialized
INFO - 2022-01-14 07:31:55 --> Loader Class Initialized
INFO - 2022-01-14 07:31:55 --> Helper loaded: url_helper
INFO - 2022-01-14 07:31:55 --> Helper loaded: file_helper
INFO - 2022-01-14 07:31:55 --> Helper loaded: form_helper
INFO - 2022-01-14 07:31:55 --> Helper loaded: my_helper
INFO - 2022-01-14 07:31:55 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:31:55 --> Controller Class Initialized
INFO - 2022-01-14 07:31:55 --> Config Class Initialized
INFO - 2022-01-14 07:31:55 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:31:55 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:31:55 --> Utf8 Class Initialized
INFO - 2022-01-14 07:31:55 --> URI Class Initialized
INFO - 2022-01-14 07:31:55 --> Router Class Initialized
INFO - 2022-01-14 07:31:55 --> Output Class Initialized
INFO - 2022-01-14 07:31:55 --> Security Class Initialized
DEBUG - 2022-01-14 07:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:31:55 --> Input Class Initialized
INFO - 2022-01-14 07:31:55 --> Language Class Initialized
INFO - 2022-01-14 07:31:55 --> Language Class Initialized
INFO - 2022-01-14 07:31:55 --> Config Class Initialized
INFO - 2022-01-14 07:31:55 --> Loader Class Initialized
INFO - 2022-01-14 07:31:55 --> Helper loaded: url_helper
INFO - 2022-01-14 07:31:55 --> Helper loaded: file_helper
INFO - 2022-01-14 07:31:55 --> Helper loaded: form_helper
INFO - 2022-01-14 07:31:55 --> Helper loaded: my_helper
INFO - 2022-01-14 07:31:55 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:31:55 --> Controller Class Initialized
DEBUG - 2022-01-14 07:31:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-14 07:31:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-14 07:31:55 --> Final output sent to browser
DEBUG - 2022-01-14 07:31:55 --> Total execution time: 0.0400
INFO - 2022-01-14 07:32:09 --> Config Class Initialized
INFO - 2022-01-14 07:32:09 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:32:09 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:32:09 --> Utf8 Class Initialized
INFO - 2022-01-14 07:32:09 --> URI Class Initialized
INFO - 2022-01-14 07:32:09 --> Router Class Initialized
INFO - 2022-01-14 07:32:09 --> Output Class Initialized
INFO - 2022-01-14 07:32:09 --> Security Class Initialized
DEBUG - 2022-01-14 07:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:32:09 --> Input Class Initialized
INFO - 2022-01-14 07:32:09 --> Language Class Initialized
INFO - 2022-01-14 07:32:09 --> Language Class Initialized
INFO - 2022-01-14 07:32:09 --> Config Class Initialized
INFO - 2022-01-14 07:32:09 --> Loader Class Initialized
INFO - 2022-01-14 07:32:09 --> Helper loaded: url_helper
INFO - 2022-01-14 07:32:09 --> Helper loaded: file_helper
INFO - 2022-01-14 07:32:09 --> Helper loaded: form_helper
INFO - 2022-01-14 07:32:09 --> Helper loaded: my_helper
INFO - 2022-01-14 07:32:09 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:32:09 --> Controller Class Initialized
INFO - 2022-01-14 07:32:09 --> Helper loaded: cookie_helper
INFO - 2022-01-14 07:32:09 --> Final output sent to browser
DEBUG - 2022-01-14 07:32:09 --> Total execution time: 0.0612
INFO - 2022-01-14 07:32:09 --> Config Class Initialized
INFO - 2022-01-14 07:32:09 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:32:09 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:32:09 --> Utf8 Class Initialized
INFO - 2022-01-14 07:32:09 --> URI Class Initialized
INFO - 2022-01-14 07:32:09 --> Router Class Initialized
INFO - 2022-01-14 07:32:09 --> Output Class Initialized
INFO - 2022-01-14 07:32:09 --> Security Class Initialized
DEBUG - 2022-01-14 07:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:32:09 --> Input Class Initialized
INFO - 2022-01-14 07:32:09 --> Language Class Initialized
INFO - 2022-01-14 07:32:09 --> Language Class Initialized
INFO - 2022-01-14 07:32:09 --> Config Class Initialized
INFO - 2022-01-14 07:32:09 --> Loader Class Initialized
INFO - 2022-01-14 07:32:09 --> Helper loaded: url_helper
INFO - 2022-01-14 07:32:09 --> Helper loaded: file_helper
INFO - 2022-01-14 07:32:09 --> Helper loaded: form_helper
INFO - 2022-01-14 07:32:09 --> Helper loaded: my_helper
INFO - 2022-01-14 07:32:09 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:32:09 --> Controller Class Initialized
DEBUG - 2022-01-14 07:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-14 07:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-14 07:32:10 --> Final output sent to browser
DEBUG - 2022-01-14 07:32:10 --> Total execution time: 0.7750
INFO - 2022-01-14 07:32:13 --> Config Class Initialized
INFO - 2022-01-14 07:32:13 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:32:13 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:32:13 --> Utf8 Class Initialized
INFO - 2022-01-14 07:32:13 --> URI Class Initialized
INFO - 2022-01-14 07:32:13 --> Router Class Initialized
INFO - 2022-01-14 07:32:13 --> Output Class Initialized
INFO - 2022-01-14 07:32:13 --> Security Class Initialized
DEBUG - 2022-01-14 07:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:32:13 --> Input Class Initialized
INFO - 2022-01-14 07:32:13 --> Language Class Initialized
INFO - 2022-01-14 07:32:13 --> Language Class Initialized
INFO - 2022-01-14 07:32:13 --> Config Class Initialized
INFO - 2022-01-14 07:32:13 --> Loader Class Initialized
INFO - 2022-01-14 07:32:13 --> Helper loaded: url_helper
INFO - 2022-01-14 07:32:13 --> Helper loaded: file_helper
INFO - 2022-01-14 07:32:13 --> Helper loaded: form_helper
INFO - 2022-01-14 07:32:13 --> Helper loaded: my_helper
INFO - 2022-01-14 07:32:13 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:32:13 --> Controller Class Initialized
DEBUG - 2022-01-14 07:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-14 07:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-14 07:32:13 --> Final output sent to browser
DEBUG - 2022-01-14 07:32:13 --> Total execution time: 0.0650
INFO - 2022-01-14 07:32:16 --> Config Class Initialized
INFO - 2022-01-14 07:32:16 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:32:16 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:32:16 --> Utf8 Class Initialized
INFO - 2022-01-14 07:32:16 --> URI Class Initialized
INFO - 2022-01-14 07:32:16 --> Router Class Initialized
INFO - 2022-01-14 07:32:16 --> Output Class Initialized
INFO - 2022-01-14 07:32:16 --> Security Class Initialized
DEBUG - 2022-01-14 07:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:32:16 --> Input Class Initialized
INFO - 2022-01-14 07:32:16 --> Language Class Initialized
INFO - 2022-01-14 07:32:16 --> Language Class Initialized
INFO - 2022-01-14 07:32:16 --> Config Class Initialized
INFO - 2022-01-14 07:32:16 --> Loader Class Initialized
INFO - 2022-01-14 07:32:16 --> Helper loaded: url_helper
INFO - 2022-01-14 07:32:16 --> Helper loaded: file_helper
INFO - 2022-01-14 07:32:16 --> Helper loaded: form_helper
INFO - 2022-01-14 07:32:16 --> Helper loaded: my_helper
INFO - 2022-01-14 07:32:16 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:32:16 --> Controller Class Initialized
DEBUG - 2022-01-14 07:32:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-01-14 07:32:16 --> Final output sent to browser
DEBUG - 2022-01-14 07:32:16 --> Total execution time: 0.1870
INFO - 2022-01-14 07:32:55 --> Config Class Initialized
INFO - 2022-01-14 07:32:55 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:32:55 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:32:55 --> Utf8 Class Initialized
INFO - 2022-01-14 07:32:55 --> URI Class Initialized
INFO - 2022-01-14 07:32:55 --> Router Class Initialized
INFO - 2022-01-14 07:32:55 --> Output Class Initialized
INFO - 2022-01-14 07:32:55 --> Security Class Initialized
DEBUG - 2022-01-14 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:32:55 --> Input Class Initialized
INFO - 2022-01-14 07:32:55 --> Language Class Initialized
INFO - 2022-01-14 07:32:55 --> Language Class Initialized
INFO - 2022-01-14 07:32:55 --> Config Class Initialized
INFO - 2022-01-14 07:32:55 --> Loader Class Initialized
INFO - 2022-01-14 07:32:55 --> Helper loaded: url_helper
INFO - 2022-01-14 07:32:55 --> Helper loaded: file_helper
INFO - 2022-01-14 07:32:55 --> Helper loaded: form_helper
INFO - 2022-01-14 07:32:55 --> Helper loaded: my_helper
INFO - 2022-01-14 07:32:55 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:32:55 --> Controller Class Initialized
INFO - 2022-01-14 07:32:55 --> Helper loaded: cookie_helper
INFO - 2022-01-14 07:32:55 --> Config Class Initialized
INFO - 2022-01-14 07:32:55 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:32:55 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:32:55 --> Utf8 Class Initialized
INFO - 2022-01-14 07:32:55 --> URI Class Initialized
INFO - 2022-01-14 07:32:55 --> Router Class Initialized
INFO - 2022-01-14 07:32:55 --> Output Class Initialized
INFO - 2022-01-14 07:32:55 --> Security Class Initialized
DEBUG - 2022-01-14 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:32:55 --> Input Class Initialized
INFO - 2022-01-14 07:32:55 --> Language Class Initialized
INFO - 2022-01-14 07:32:55 --> Language Class Initialized
INFO - 2022-01-14 07:32:55 --> Config Class Initialized
INFO - 2022-01-14 07:32:55 --> Loader Class Initialized
INFO - 2022-01-14 07:32:55 --> Helper loaded: url_helper
INFO - 2022-01-14 07:32:55 --> Helper loaded: file_helper
INFO - 2022-01-14 07:32:55 --> Helper loaded: form_helper
INFO - 2022-01-14 07:32:55 --> Helper loaded: my_helper
INFO - 2022-01-14 07:32:55 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:32:55 --> Controller Class Initialized
DEBUG - 2022-01-14 07:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-14 07:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-14 07:32:55 --> Final output sent to browser
DEBUG - 2022-01-14 07:32:55 --> Total execution time: 0.0350
INFO - 2022-01-14 07:33:09 --> Config Class Initialized
INFO - 2022-01-14 07:33:09 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:33:09 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:33:09 --> Utf8 Class Initialized
INFO - 2022-01-14 07:33:09 --> URI Class Initialized
INFO - 2022-01-14 07:33:09 --> Router Class Initialized
INFO - 2022-01-14 07:33:09 --> Output Class Initialized
INFO - 2022-01-14 07:33:09 --> Security Class Initialized
DEBUG - 2022-01-14 07:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:33:09 --> Input Class Initialized
INFO - 2022-01-14 07:33:09 --> Language Class Initialized
INFO - 2022-01-14 07:33:09 --> Language Class Initialized
INFO - 2022-01-14 07:33:09 --> Config Class Initialized
INFO - 2022-01-14 07:33:09 --> Loader Class Initialized
INFO - 2022-01-14 07:33:09 --> Helper loaded: url_helper
INFO - 2022-01-14 07:33:09 --> Helper loaded: file_helper
INFO - 2022-01-14 07:33:09 --> Helper loaded: form_helper
INFO - 2022-01-14 07:33:09 --> Helper loaded: my_helper
INFO - 2022-01-14 07:33:09 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:33:09 --> Controller Class Initialized
INFO - 2022-01-14 07:33:09 --> Helper loaded: cookie_helper
INFO - 2022-01-14 07:33:09 --> Final output sent to browser
DEBUG - 2022-01-14 07:33:09 --> Total execution time: 0.0602
INFO - 2022-01-14 07:33:10 --> Config Class Initialized
INFO - 2022-01-14 07:33:10 --> Hooks Class Initialized
DEBUG - 2022-01-14 07:33:10 --> UTF-8 Support Enabled
INFO - 2022-01-14 07:33:10 --> Utf8 Class Initialized
INFO - 2022-01-14 07:33:10 --> URI Class Initialized
INFO - 2022-01-14 07:33:10 --> Router Class Initialized
INFO - 2022-01-14 07:33:10 --> Output Class Initialized
INFO - 2022-01-14 07:33:10 --> Security Class Initialized
DEBUG - 2022-01-14 07:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 07:33:10 --> Input Class Initialized
INFO - 2022-01-14 07:33:10 --> Language Class Initialized
INFO - 2022-01-14 07:33:10 --> Language Class Initialized
INFO - 2022-01-14 07:33:10 --> Config Class Initialized
INFO - 2022-01-14 07:33:10 --> Loader Class Initialized
INFO - 2022-01-14 07:33:10 --> Helper loaded: url_helper
INFO - 2022-01-14 07:33:10 --> Helper loaded: file_helper
INFO - 2022-01-14 07:33:10 --> Helper loaded: form_helper
INFO - 2022-01-14 07:33:10 --> Helper loaded: my_helper
INFO - 2022-01-14 07:33:10 --> Database Driver Class Initialized
DEBUG - 2022-01-14 07:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 07:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 07:33:10 --> Controller Class Initialized
DEBUG - 2022-01-14 07:33:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-14 07:33:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-14 07:33:10 --> Final output sent to browser
DEBUG - 2022-01-14 07:33:10 --> Total execution time: 0.7840
