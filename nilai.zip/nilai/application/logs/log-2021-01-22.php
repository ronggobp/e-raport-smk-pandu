<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-22 01:17:16 --> Config Class Initialized
INFO - 2021-01-22 01:17:16 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:17:16 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:17:16 --> Utf8 Class Initialized
INFO - 2021-01-22 01:17:16 --> URI Class Initialized
DEBUG - 2021-01-22 01:17:16 --> No URI present. Default controller set.
INFO - 2021-01-22 01:17:16 --> Router Class Initialized
INFO - 2021-01-22 01:17:16 --> Output Class Initialized
INFO - 2021-01-22 01:17:16 --> Security Class Initialized
DEBUG - 2021-01-22 01:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:17:16 --> Input Class Initialized
INFO - 2021-01-22 01:17:16 --> Language Class Initialized
INFO - 2021-01-22 01:17:17 --> Language Class Initialized
INFO - 2021-01-22 01:17:17 --> Config Class Initialized
INFO - 2021-01-22 01:17:17 --> Loader Class Initialized
INFO - 2021-01-22 01:17:17 --> Helper loaded: url_helper
INFO - 2021-01-22 01:17:17 --> Helper loaded: file_helper
INFO - 2021-01-22 01:17:17 --> Helper loaded: form_helper
INFO - 2021-01-22 01:17:17 --> Helper loaded: my_helper
INFO - 2021-01-22 01:17:17 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:17:17 --> Controller Class Initialized
INFO - 2021-01-22 01:17:17 --> Config Class Initialized
INFO - 2021-01-22 01:17:17 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:17:17 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:17:17 --> Utf8 Class Initialized
INFO - 2021-01-22 01:17:17 --> URI Class Initialized
INFO - 2021-01-22 01:17:17 --> Router Class Initialized
INFO - 2021-01-22 01:17:17 --> Output Class Initialized
INFO - 2021-01-22 01:17:17 --> Security Class Initialized
DEBUG - 2021-01-22 01:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:17:17 --> Input Class Initialized
INFO - 2021-01-22 01:17:17 --> Language Class Initialized
INFO - 2021-01-22 01:17:17 --> Language Class Initialized
INFO - 2021-01-22 01:17:17 --> Config Class Initialized
INFO - 2021-01-22 01:17:17 --> Loader Class Initialized
INFO - 2021-01-22 01:17:17 --> Helper loaded: url_helper
INFO - 2021-01-22 01:17:17 --> Helper loaded: file_helper
INFO - 2021-01-22 01:17:17 --> Helper loaded: form_helper
INFO - 2021-01-22 01:17:17 --> Helper loaded: my_helper
INFO - 2021-01-22 01:17:17 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:17:17 --> Controller Class Initialized
DEBUG - 2021-01-22 01:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:17:18 --> Final output sent to browser
DEBUG - 2021-01-22 01:17:18 --> Total execution time: 0.6615
INFO - 2021-01-22 01:19:16 --> Config Class Initialized
INFO - 2021-01-22 01:19:16 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:19:16 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:19:16 --> Utf8 Class Initialized
INFO - 2021-01-22 01:19:16 --> URI Class Initialized
INFO - 2021-01-22 01:19:16 --> Router Class Initialized
INFO - 2021-01-22 01:19:16 --> Output Class Initialized
INFO - 2021-01-22 01:19:16 --> Security Class Initialized
DEBUG - 2021-01-22 01:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:19:16 --> Input Class Initialized
INFO - 2021-01-22 01:19:16 --> Language Class Initialized
INFO - 2021-01-22 01:19:16 --> Language Class Initialized
INFO - 2021-01-22 01:19:16 --> Config Class Initialized
INFO - 2021-01-22 01:19:16 --> Loader Class Initialized
INFO - 2021-01-22 01:19:16 --> Helper loaded: url_helper
INFO - 2021-01-22 01:19:16 --> Helper loaded: file_helper
INFO - 2021-01-22 01:19:16 --> Helper loaded: form_helper
INFO - 2021-01-22 01:19:16 --> Helper loaded: my_helper
INFO - 2021-01-22 01:19:16 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:19:16 --> Controller Class Initialized
INFO - 2021-01-22 01:19:16 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:19:16 --> Final output sent to browser
DEBUG - 2021-01-22 01:19:16 --> Total execution time: 0.8758
INFO - 2021-01-22 01:19:18 --> Config Class Initialized
INFO - 2021-01-22 01:19:18 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:19:18 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:19:18 --> Utf8 Class Initialized
INFO - 2021-01-22 01:19:18 --> URI Class Initialized
INFO - 2021-01-22 01:19:18 --> Router Class Initialized
INFO - 2021-01-22 01:19:18 --> Output Class Initialized
INFO - 2021-01-22 01:19:18 --> Security Class Initialized
DEBUG - 2021-01-22 01:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:19:18 --> Input Class Initialized
INFO - 2021-01-22 01:19:18 --> Language Class Initialized
INFO - 2021-01-22 01:19:19 --> Language Class Initialized
INFO - 2021-01-22 01:19:19 --> Config Class Initialized
INFO - 2021-01-22 01:19:19 --> Loader Class Initialized
INFO - 2021-01-22 01:19:19 --> Helper loaded: url_helper
INFO - 2021-01-22 01:19:19 --> Helper loaded: file_helper
INFO - 2021-01-22 01:19:19 --> Helper loaded: form_helper
INFO - 2021-01-22 01:19:19 --> Helper loaded: my_helper
INFO - 2021-01-22 01:19:19 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:19:19 --> Controller Class Initialized
DEBUG - 2021-01-22 01:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:19:19 --> Final output sent to browser
DEBUG - 2021-01-22 01:19:19 --> Total execution time: 1.0180
INFO - 2021-01-22 01:19:41 --> Config Class Initialized
INFO - 2021-01-22 01:19:41 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:19:41 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:19:41 --> Utf8 Class Initialized
INFO - 2021-01-22 01:19:41 --> URI Class Initialized
INFO - 2021-01-22 01:19:41 --> Router Class Initialized
INFO - 2021-01-22 01:19:41 --> Output Class Initialized
INFO - 2021-01-22 01:19:41 --> Security Class Initialized
DEBUG - 2021-01-22 01:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:19:41 --> Input Class Initialized
INFO - 2021-01-22 01:19:41 --> Language Class Initialized
INFO - 2021-01-22 01:19:42 --> Language Class Initialized
INFO - 2021-01-22 01:19:42 --> Config Class Initialized
INFO - 2021-01-22 01:19:42 --> Loader Class Initialized
INFO - 2021-01-22 01:19:42 --> Helper loaded: url_helper
INFO - 2021-01-22 01:19:42 --> Helper loaded: file_helper
INFO - 2021-01-22 01:19:42 --> Helper loaded: form_helper
INFO - 2021-01-22 01:19:42 --> Helper loaded: my_helper
INFO - 2021-01-22 01:19:42 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:19:42 --> Controller Class Initialized
DEBUG - 2021-01-22 01:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:19:42 --> Final output sent to browser
DEBUG - 2021-01-22 01:19:42 --> Total execution time: 1.0246
INFO - 2021-01-22 01:19:47 --> Config Class Initialized
INFO - 2021-01-22 01:19:47 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:19:47 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:19:47 --> Utf8 Class Initialized
INFO - 2021-01-22 01:19:47 --> URI Class Initialized
INFO - 2021-01-22 01:19:47 --> Router Class Initialized
INFO - 2021-01-22 01:19:47 --> Output Class Initialized
INFO - 2021-01-22 01:19:47 --> Security Class Initialized
DEBUG - 2021-01-22 01:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:19:48 --> Input Class Initialized
INFO - 2021-01-22 01:19:48 --> Language Class Initialized
INFO - 2021-01-22 01:19:48 --> Language Class Initialized
INFO - 2021-01-22 01:19:48 --> Config Class Initialized
INFO - 2021-01-22 01:19:48 --> Loader Class Initialized
INFO - 2021-01-22 01:19:48 --> Helper loaded: url_helper
INFO - 2021-01-22 01:19:48 --> Helper loaded: file_helper
INFO - 2021-01-22 01:19:48 --> Helper loaded: form_helper
INFO - 2021-01-22 01:19:48 --> Helper loaded: my_helper
INFO - 2021-01-22 01:19:48 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:19:48 --> Controller Class Initialized
DEBUG - 2021-01-22 01:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-22 01:19:48 --> Final output sent to browser
DEBUG - 2021-01-22 01:19:48 --> Total execution time: 0.9950
INFO - 2021-01-22 01:21:23 --> Config Class Initialized
INFO - 2021-01-22 01:21:23 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:21:23 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:21:23 --> Utf8 Class Initialized
INFO - 2021-01-22 01:21:23 --> URI Class Initialized
INFO - 2021-01-22 01:21:23 --> Router Class Initialized
INFO - 2021-01-22 01:21:23 --> Output Class Initialized
INFO - 2021-01-22 01:21:23 --> Security Class Initialized
DEBUG - 2021-01-22 01:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:21:23 --> Input Class Initialized
INFO - 2021-01-22 01:21:23 --> Language Class Initialized
INFO - 2021-01-22 01:21:23 --> Language Class Initialized
INFO - 2021-01-22 01:21:23 --> Config Class Initialized
INFO - 2021-01-22 01:21:23 --> Loader Class Initialized
INFO - 2021-01-22 01:21:23 --> Helper loaded: url_helper
INFO - 2021-01-22 01:21:23 --> Helper loaded: file_helper
INFO - 2021-01-22 01:21:23 --> Helper loaded: form_helper
INFO - 2021-01-22 01:21:23 --> Helper loaded: my_helper
INFO - 2021-01-22 01:21:23 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:21:23 --> Controller Class Initialized
DEBUG - 2021-01-22 01:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-22 01:21:23 --> Final output sent to browser
DEBUG - 2021-01-22 01:21:23 --> Total execution time: 0.7045
INFO - 2021-01-22 01:22:29 --> Config Class Initialized
INFO - 2021-01-22 01:22:29 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:22:29 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:22:29 --> Utf8 Class Initialized
INFO - 2021-01-22 01:22:29 --> URI Class Initialized
INFO - 2021-01-22 01:22:29 --> Router Class Initialized
INFO - 2021-01-22 01:22:29 --> Output Class Initialized
INFO - 2021-01-22 01:22:29 --> Security Class Initialized
DEBUG - 2021-01-22 01:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:22:29 --> Input Class Initialized
INFO - 2021-01-22 01:22:29 --> Language Class Initialized
INFO - 2021-01-22 01:22:29 --> Language Class Initialized
INFO - 2021-01-22 01:22:29 --> Config Class Initialized
INFO - 2021-01-22 01:22:29 --> Loader Class Initialized
INFO - 2021-01-22 01:22:29 --> Helper loaded: url_helper
INFO - 2021-01-22 01:22:29 --> Helper loaded: file_helper
INFO - 2021-01-22 01:22:29 --> Helper loaded: form_helper
INFO - 2021-01-22 01:22:29 --> Helper loaded: my_helper
INFO - 2021-01-22 01:22:29 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:22:29 --> Controller Class Initialized
DEBUG - 2021-01-22 01:22:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-22 01:22:30 --> Final output sent to browser
DEBUG - 2021-01-22 01:22:30 --> Total execution time: 1.1468
INFO - 2021-01-22 01:22:58 --> Config Class Initialized
INFO - 2021-01-22 01:22:58 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:22:58 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:22:58 --> Utf8 Class Initialized
INFO - 2021-01-22 01:22:58 --> URI Class Initialized
INFO - 2021-01-22 01:22:58 --> Router Class Initialized
INFO - 2021-01-22 01:22:58 --> Output Class Initialized
INFO - 2021-01-22 01:22:58 --> Security Class Initialized
DEBUG - 2021-01-22 01:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:22:58 --> Input Class Initialized
INFO - 2021-01-22 01:22:58 --> Language Class Initialized
INFO - 2021-01-22 01:22:59 --> Language Class Initialized
INFO - 2021-01-22 01:22:59 --> Config Class Initialized
INFO - 2021-01-22 01:22:59 --> Loader Class Initialized
INFO - 2021-01-22 01:22:59 --> Helper loaded: url_helper
INFO - 2021-01-22 01:22:59 --> Helper loaded: file_helper
INFO - 2021-01-22 01:22:59 --> Helper loaded: form_helper
INFO - 2021-01-22 01:22:59 --> Helper loaded: my_helper
INFO - 2021-01-22 01:22:59 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:22:59 --> Controller Class Initialized
DEBUG - 2021-01-22 01:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-22 01:22:59 --> Final output sent to browser
DEBUG - 2021-01-22 01:22:59 --> Total execution time: 1.0442
INFO - 2021-01-22 01:23:44 --> Config Class Initialized
INFO - 2021-01-22 01:23:45 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:23:45 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:23:45 --> Utf8 Class Initialized
INFO - 2021-01-22 01:23:45 --> URI Class Initialized
INFO - 2021-01-22 01:23:45 --> Router Class Initialized
INFO - 2021-01-22 01:23:45 --> Output Class Initialized
INFO - 2021-01-22 01:23:45 --> Security Class Initialized
DEBUG - 2021-01-22 01:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:23:45 --> Input Class Initialized
INFO - 2021-01-22 01:23:45 --> Language Class Initialized
INFO - 2021-01-22 01:23:45 --> Language Class Initialized
INFO - 2021-01-22 01:23:45 --> Config Class Initialized
INFO - 2021-01-22 01:23:45 --> Loader Class Initialized
INFO - 2021-01-22 01:23:45 --> Helper loaded: url_helper
INFO - 2021-01-22 01:23:45 --> Helper loaded: file_helper
INFO - 2021-01-22 01:23:45 --> Helper loaded: form_helper
INFO - 2021-01-22 01:23:45 --> Helper loaded: my_helper
INFO - 2021-01-22 01:23:45 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:23:45 --> Controller Class Initialized
DEBUG - 2021-01-22 01:23:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-22 01:23:46 --> Final output sent to browser
DEBUG - 2021-01-22 01:23:46 --> Total execution time: 1.1684
INFO - 2021-01-22 01:25:01 --> Config Class Initialized
INFO - 2021-01-22 01:25:01 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:01 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:01 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:01 --> URI Class Initialized
INFO - 2021-01-22 01:25:01 --> Router Class Initialized
INFO - 2021-01-22 01:25:02 --> Output Class Initialized
INFO - 2021-01-22 01:25:02 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:02 --> Input Class Initialized
INFO - 2021-01-22 01:25:02 --> Language Class Initialized
INFO - 2021-01-22 01:25:02 --> Language Class Initialized
INFO - 2021-01-22 01:25:02 --> Config Class Initialized
INFO - 2021-01-22 01:25:02 --> Loader Class Initialized
INFO - 2021-01-22 01:25:02 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:02 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:02 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:02 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:02 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:02 --> Controller Class Initialized
INFO - 2021-01-22 01:25:02 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:25:02 --> Config Class Initialized
INFO - 2021-01-22 01:25:02 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:02 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:02 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:02 --> URI Class Initialized
INFO - 2021-01-22 01:25:02 --> Router Class Initialized
INFO - 2021-01-22 01:25:02 --> Output Class Initialized
INFO - 2021-01-22 01:25:02 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:02 --> Input Class Initialized
INFO - 2021-01-22 01:25:02 --> Language Class Initialized
INFO - 2021-01-22 01:25:02 --> Language Class Initialized
INFO - 2021-01-22 01:25:02 --> Config Class Initialized
INFO - 2021-01-22 01:25:02 --> Loader Class Initialized
INFO - 2021-01-22 01:25:02 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:02 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:02 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:03 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:03 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:03 --> Controller Class Initialized
DEBUG - 2021-01-22 01:25:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:25:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:25:03 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:03 --> Total execution time: 0.7619
INFO - 2021-01-22 01:25:08 --> Config Class Initialized
INFO - 2021-01-22 01:25:08 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:08 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:08 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:08 --> URI Class Initialized
INFO - 2021-01-22 01:25:08 --> Router Class Initialized
INFO - 2021-01-22 01:25:08 --> Output Class Initialized
INFO - 2021-01-22 01:25:08 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:08 --> Input Class Initialized
INFO - 2021-01-22 01:25:08 --> Language Class Initialized
INFO - 2021-01-22 01:25:08 --> Language Class Initialized
INFO - 2021-01-22 01:25:08 --> Config Class Initialized
INFO - 2021-01-22 01:25:08 --> Loader Class Initialized
INFO - 2021-01-22 01:25:08 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:08 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:08 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:08 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:08 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:08 --> Controller Class Initialized
INFO - 2021-01-22 01:25:08 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:25:08 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:08 --> Total execution time: 0.5955
INFO - 2021-01-22 01:25:09 --> Config Class Initialized
INFO - 2021-01-22 01:25:09 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:09 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:09 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:09 --> URI Class Initialized
INFO - 2021-01-22 01:25:09 --> Router Class Initialized
INFO - 2021-01-22 01:25:09 --> Output Class Initialized
INFO - 2021-01-22 01:25:09 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:09 --> Input Class Initialized
INFO - 2021-01-22 01:25:09 --> Language Class Initialized
INFO - 2021-01-22 01:25:09 --> Language Class Initialized
INFO - 2021-01-22 01:25:09 --> Config Class Initialized
INFO - 2021-01-22 01:25:09 --> Loader Class Initialized
INFO - 2021-01-22 01:25:09 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:09 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:09 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:09 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:09 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:09 --> Controller Class Initialized
DEBUG - 2021-01-22 01:25:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:25:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:25:10 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:10 --> Total execution time: 0.7657
INFO - 2021-01-22 01:25:11 --> Config Class Initialized
INFO - 2021-01-22 01:25:11 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:11 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:11 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:11 --> URI Class Initialized
INFO - 2021-01-22 01:25:11 --> Router Class Initialized
INFO - 2021-01-22 01:25:11 --> Output Class Initialized
INFO - 2021-01-22 01:25:11 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:11 --> Input Class Initialized
INFO - 2021-01-22 01:25:12 --> Language Class Initialized
INFO - 2021-01-22 01:25:12 --> Language Class Initialized
INFO - 2021-01-22 01:25:12 --> Config Class Initialized
INFO - 2021-01-22 01:25:12 --> Loader Class Initialized
INFO - 2021-01-22 01:25:12 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:12 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:12 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:12 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:12 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:12 --> Controller Class Initialized
DEBUG - 2021-01-22 01:25:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:25:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:25:12 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:12 --> Total execution time: 0.8133
INFO - 2021-01-22 01:25:14 --> Config Class Initialized
INFO - 2021-01-22 01:25:14 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:14 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:14 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:14 --> URI Class Initialized
INFO - 2021-01-22 01:25:14 --> Router Class Initialized
INFO - 2021-01-22 01:25:14 --> Output Class Initialized
INFO - 2021-01-22 01:25:14 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:14 --> Input Class Initialized
INFO - 2021-01-22 01:25:14 --> Language Class Initialized
INFO - 2021-01-22 01:25:14 --> Language Class Initialized
INFO - 2021-01-22 01:25:14 --> Config Class Initialized
INFO - 2021-01-22 01:25:14 --> Loader Class Initialized
INFO - 2021-01-22 01:25:14 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:14 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:14 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:14 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:15 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:15 --> Controller Class Initialized
DEBUG - 2021-01-22 01:25:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-22 01:25:15 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:15 --> Total execution time: 1.0946
INFO - 2021-01-22 01:25:40 --> Config Class Initialized
INFO - 2021-01-22 01:25:40 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:40 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:40 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:40 --> URI Class Initialized
INFO - 2021-01-22 01:25:40 --> Router Class Initialized
INFO - 2021-01-22 01:25:40 --> Output Class Initialized
INFO - 2021-01-22 01:25:40 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:40 --> Input Class Initialized
INFO - 2021-01-22 01:25:40 --> Language Class Initialized
INFO - 2021-01-22 01:25:40 --> Language Class Initialized
INFO - 2021-01-22 01:25:40 --> Config Class Initialized
INFO - 2021-01-22 01:25:40 --> Loader Class Initialized
INFO - 2021-01-22 01:25:40 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:40 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:40 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:40 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:40 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:41 --> Controller Class Initialized
INFO - 2021-01-22 01:25:41 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:25:41 --> Config Class Initialized
INFO - 2021-01-22 01:25:41 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:41 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:41 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:41 --> URI Class Initialized
INFO - 2021-01-22 01:25:41 --> Router Class Initialized
INFO - 2021-01-22 01:25:41 --> Output Class Initialized
INFO - 2021-01-22 01:25:41 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:41 --> Input Class Initialized
INFO - 2021-01-22 01:25:41 --> Language Class Initialized
INFO - 2021-01-22 01:25:41 --> Language Class Initialized
INFO - 2021-01-22 01:25:41 --> Config Class Initialized
INFO - 2021-01-22 01:25:41 --> Loader Class Initialized
INFO - 2021-01-22 01:25:41 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:41 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:41 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:41 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:41 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:41 --> Controller Class Initialized
DEBUG - 2021-01-22 01:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:25:41 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:42 --> Total execution time: 0.8616
INFO - 2021-01-22 01:25:48 --> Config Class Initialized
INFO - 2021-01-22 01:25:48 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:48 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:48 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:48 --> URI Class Initialized
INFO - 2021-01-22 01:25:48 --> Router Class Initialized
INFO - 2021-01-22 01:25:48 --> Output Class Initialized
INFO - 2021-01-22 01:25:48 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:48 --> Input Class Initialized
INFO - 2021-01-22 01:25:48 --> Language Class Initialized
INFO - 2021-01-22 01:25:48 --> Language Class Initialized
INFO - 2021-01-22 01:25:48 --> Config Class Initialized
INFO - 2021-01-22 01:25:48 --> Loader Class Initialized
INFO - 2021-01-22 01:25:48 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:48 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:48 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:48 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:48 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:48 --> Controller Class Initialized
INFO - 2021-01-22 01:25:48 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:25:48 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:48 --> Total execution time: 0.7123
INFO - 2021-01-22 01:25:49 --> Config Class Initialized
INFO - 2021-01-22 01:25:49 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:49 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:49 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:49 --> URI Class Initialized
INFO - 2021-01-22 01:25:49 --> Router Class Initialized
INFO - 2021-01-22 01:25:49 --> Output Class Initialized
INFO - 2021-01-22 01:25:49 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:49 --> Input Class Initialized
INFO - 2021-01-22 01:25:49 --> Language Class Initialized
INFO - 2021-01-22 01:25:49 --> Language Class Initialized
INFO - 2021-01-22 01:25:49 --> Config Class Initialized
INFO - 2021-01-22 01:25:49 --> Loader Class Initialized
INFO - 2021-01-22 01:25:50 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:50 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:50 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:50 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:50 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:50 --> Controller Class Initialized
DEBUG - 2021-01-22 01:25:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:25:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:25:50 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:50 --> Total execution time: 1.2868
INFO - 2021-01-22 01:25:54 --> Config Class Initialized
INFO - 2021-01-22 01:25:54 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:54 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:54 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:54 --> URI Class Initialized
INFO - 2021-01-22 01:25:54 --> Router Class Initialized
INFO - 2021-01-22 01:25:55 --> Output Class Initialized
INFO - 2021-01-22 01:25:55 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:55 --> Input Class Initialized
INFO - 2021-01-22 01:25:55 --> Language Class Initialized
INFO - 2021-01-22 01:25:55 --> Language Class Initialized
INFO - 2021-01-22 01:25:55 --> Config Class Initialized
INFO - 2021-01-22 01:25:55 --> Loader Class Initialized
INFO - 2021-01-22 01:25:55 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:55 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:55 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:55 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:55 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:55 --> Controller Class Initialized
DEBUG - 2021-01-22 01:25:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:25:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:25:55 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:55 --> Total execution time: 0.6684
INFO - 2021-01-22 01:25:57 --> Config Class Initialized
INFO - 2021-01-22 01:25:57 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:25:57 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:25:57 --> Utf8 Class Initialized
INFO - 2021-01-22 01:25:57 --> URI Class Initialized
INFO - 2021-01-22 01:25:57 --> Router Class Initialized
INFO - 2021-01-22 01:25:57 --> Output Class Initialized
INFO - 2021-01-22 01:25:57 --> Security Class Initialized
DEBUG - 2021-01-22 01:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:25:57 --> Input Class Initialized
INFO - 2021-01-22 01:25:57 --> Language Class Initialized
INFO - 2021-01-22 01:25:57 --> Language Class Initialized
INFO - 2021-01-22 01:25:57 --> Config Class Initialized
INFO - 2021-01-22 01:25:57 --> Loader Class Initialized
INFO - 2021-01-22 01:25:58 --> Helper loaded: url_helper
INFO - 2021-01-22 01:25:58 --> Helper loaded: file_helper
INFO - 2021-01-22 01:25:58 --> Helper loaded: form_helper
INFO - 2021-01-22 01:25:58 --> Helper loaded: my_helper
INFO - 2021-01-22 01:25:58 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:25:58 --> Controller Class Initialized
DEBUG - 2021-01-22 01:25:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-22 01:25:58 --> Final output sent to browser
DEBUG - 2021-01-22 01:25:58 --> Total execution time: 1.1610
INFO - 2021-01-22 01:38:26 --> Config Class Initialized
INFO - 2021-01-22 01:38:26 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:38:27 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:38:27 --> Utf8 Class Initialized
INFO - 2021-01-22 01:38:27 --> URI Class Initialized
INFO - 2021-01-22 01:38:27 --> Router Class Initialized
INFO - 2021-01-22 01:38:28 --> Output Class Initialized
INFO - 2021-01-22 01:38:28 --> Security Class Initialized
DEBUG - 2021-01-22 01:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:38:28 --> Input Class Initialized
INFO - 2021-01-22 01:38:28 --> Language Class Initialized
INFO - 2021-01-22 01:38:28 --> Language Class Initialized
INFO - 2021-01-22 01:38:28 --> Config Class Initialized
INFO - 2021-01-22 01:38:28 --> Loader Class Initialized
INFO - 2021-01-22 01:38:29 --> Helper loaded: url_helper
INFO - 2021-01-22 01:38:29 --> Helper loaded: file_helper
INFO - 2021-01-22 01:38:29 --> Helper loaded: form_helper
INFO - 2021-01-22 01:38:29 --> Helper loaded: my_helper
INFO - 2021-01-22 01:38:29 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:38:30 --> Controller Class Initialized
DEBUG - 2021-01-22 01:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-22 01:38:30 --> Final output sent to browser
DEBUG - 2021-01-22 01:38:30 --> Total execution time: 4.0340
INFO - 2021-01-22 01:38:59 --> Config Class Initialized
INFO - 2021-01-22 01:38:59 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:38:59 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:38:59 --> Utf8 Class Initialized
INFO - 2021-01-22 01:38:59 --> URI Class Initialized
INFO - 2021-01-22 01:38:59 --> Router Class Initialized
INFO - 2021-01-22 01:38:59 --> Output Class Initialized
INFO - 2021-01-22 01:38:59 --> Security Class Initialized
DEBUG - 2021-01-22 01:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:38:59 --> Input Class Initialized
INFO - 2021-01-22 01:38:59 --> Language Class Initialized
INFO - 2021-01-22 01:38:59 --> Language Class Initialized
INFO - 2021-01-22 01:38:59 --> Config Class Initialized
INFO - 2021-01-22 01:38:59 --> Loader Class Initialized
INFO - 2021-01-22 01:38:59 --> Helper loaded: url_helper
INFO - 2021-01-22 01:38:59 --> Helper loaded: file_helper
INFO - 2021-01-22 01:38:59 --> Helper loaded: form_helper
INFO - 2021-01-22 01:38:59 --> Helper loaded: my_helper
INFO - 2021-01-22 01:38:59 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:39:00 --> Controller Class Initialized
DEBUG - 2021-01-22 01:39:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-22 01:39:00 --> Final output sent to browser
DEBUG - 2021-01-22 01:39:00 --> Total execution time: 1.4001
INFO - 2021-01-22 01:39:17 --> Config Class Initialized
INFO - 2021-01-22 01:39:17 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:39:17 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:39:17 --> Utf8 Class Initialized
INFO - 2021-01-22 01:39:17 --> URI Class Initialized
INFO - 2021-01-22 01:39:17 --> Router Class Initialized
INFO - 2021-01-22 01:39:17 --> Output Class Initialized
INFO - 2021-01-22 01:39:17 --> Security Class Initialized
DEBUG - 2021-01-22 01:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:39:17 --> Input Class Initialized
INFO - 2021-01-22 01:39:17 --> Language Class Initialized
INFO - 2021-01-22 01:39:17 --> Language Class Initialized
INFO - 2021-01-22 01:39:17 --> Config Class Initialized
INFO - 2021-01-22 01:39:17 --> Loader Class Initialized
INFO - 2021-01-22 01:39:17 --> Helper loaded: url_helper
INFO - 2021-01-22 01:39:17 --> Helper loaded: file_helper
INFO - 2021-01-22 01:39:17 --> Helper loaded: form_helper
INFO - 2021-01-22 01:39:17 --> Helper loaded: my_helper
INFO - 2021-01-22 01:39:17 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:39:18 --> Controller Class Initialized
DEBUG - 2021-01-22 01:39:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-22 01:39:18 --> Final output sent to browser
DEBUG - 2021-01-22 01:39:18 --> Total execution time: 1.1786
INFO - 2021-01-22 01:39:52 --> Config Class Initialized
INFO - 2021-01-22 01:39:52 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:39:52 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:39:52 --> Utf8 Class Initialized
INFO - 2021-01-22 01:39:52 --> URI Class Initialized
INFO - 2021-01-22 01:39:52 --> Router Class Initialized
INFO - 2021-01-22 01:39:52 --> Output Class Initialized
INFO - 2021-01-22 01:39:52 --> Security Class Initialized
DEBUG - 2021-01-22 01:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:39:52 --> Input Class Initialized
INFO - 2021-01-22 01:39:52 --> Language Class Initialized
INFO - 2021-01-22 01:39:52 --> Language Class Initialized
INFO - 2021-01-22 01:39:52 --> Config Class Initialized
INFO - 2021-01-22 01:39:52 --> Loader Class Initialized
INFO - 2021-01-22 01:39:52 --> Helper loaded: url_helper
INFO - 2021-01-22 01:39:52 --> Helper loaded: file_helper
INFO - 2021-01-22 01:39:52 --> Helper loaded: form_helper
INFO - 2021-01-22 01:39:53 --> Helper loaded: my_helper
INFO - 2021-01-22 01:39:53 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:39:53 --> Controller Class Initialized
DEBUG - 2021-01-22 01:39:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-22 01:39:53 --> Final output sent to browser
DEBUG - 2021-01-22 01:39:53 --> Total execution time: 1.3417
INFO - 2021-01-22 01:40:26 --> Config Class Initialized
INFO - 2021-01-22 01:40:27 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:40:27 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:40:27 --> Utf8 Class Initialized
INFO - 2021-01-22 01:40:27 --> URI Class Initialized
INFO - 2021-01-22 01:40:27 --> Router Class Initialized
INFO - 2021-01-22 01:40:27 --> Output Class Initialized
INFO - 2021-01-22 01:40:27 --> Security Class Initialized
DEBUG - 2021-01-22 01:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:40:27 --> Input Class Initialized
INFO - 2021-01-22 01:40:27 --> Language Class Initialized
INFO - 2021-01-22 01:40:27 --> Language Class Initialized
INFO - 2021-01-22 01:40:27 --> Config Class Initialized
INFO - 2021-01-22 01:40:27 --> Loader Class Initialized
INFO - 2021-01-22 01:40:27 --> Helper loaded: url_helper
INFO - 2021-01-22 01:40:27 --> Helper loaded: file_helper
INFO - 2021-01-22 01:40:27 --> Helper loaded: form_helper
INFO - 2021-01-22 01:40:27 --> Helper loaded: my_helper
INFO - 2021-01-22 01:40:28 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:40:28 --> Controller Class Initialized
INFO - 2021-01-22 01:40:28 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:40:28 --> Config Class Initialized
INFO - 2021-01-22 01:40:28 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:40:28 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:40:28 --> Utf8 Class Initialized
INFO - 2021-01-22 01:40:28 --> URI Class Initialized
INFO - 2021-01-22 01:40:28 --> Router Class Initialized
INFO - 2021-01-22 01:40:28 --> Output Class Initialized
INFO - 2021-01-22 01:40:28 --> Security Class Initialized
DEBUG - 2021-01-22 01:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:40:29 --> Input Class Initialized
INFO - 2021-01-22 01:40:29 --> Language Class Initialized
INFO - 2021-01-22 01:40:29 --> Language Class Initialized
INFO - 2021-01-22 01:40:29 --> Config Class Initialized
INFO - 2021-01-22 01:40:29 --> Loader Class Initialized
INFO - 2021-01-22 01:40:29 --> Helper loaded: url_helper
INFO - 2021-01-22 01:40:29 --> Helper loaded: file_helper
INFO - 2021-01-22 01:40:29 --> Helper loaded: form_helper
INFO - 2021-01-22 01:40:29 --> Helper loaded: my_helper
INFO - 2021-01-22 01:40:29 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:40:29 --> Controller Class Initialized
DEBUG - 2021-01-22 01:40:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:40:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:40:30 --> Final output sent to browser
DEBUG - 2021-01-22 01:40:30 --> Total execution time: 1.4477
INFO - 2021-01-22 01:40:35 --> Config Class Initialized
INFO - 2021-01-22 01:40:35 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:40:35 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:40:35 --> Utf8 Class Initialized
INFO - 2021-01-22 01:40:35 --> URI Class Initialized
INFO - 2021-01-22 01:40:35 --> Router Class Initialized
INFO - 2021-01-22 01:40:35 --> Output Class Initialized
INFO - 2021-01-22 01:40:35 --> Security Class Initialized
DEBUG - 2021-01-22 01:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:40:35 --> Input Class Initialized
INFO - 2021-01-22 01:40:35 --> Language Class Initialized
INFO - 2021-01-22 01:40:35 --> Language Class Initialized
INFO - 2021-01-22 01:40:35 --> Config Class Initialized
INFO - 2021-01-22 01:40:35 --> Loader Class Initialized
INFO - 2021-01-22 01:40:35 --> Helper loaded: url_helper
INFO - 2021-01-22 01:40:36 --> Helper loaded: file_helper
INFO - 2021-01-22 01:40:36 --> Helper loaded: form_helper
INFO - 2021-01-22 01:40:36 --> Helper loaded: my_helper
INFO - 2021-01-22 01:40:36 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:40:36 --> Controller Class Initialized
INFO - 2021-01-22 01:40:36 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:40:36 --> Final output sent to browser
DEBUG - 2021-01-22 01:40:36 --> Total execution time: 1.3855
INFO - 2021-01-22 01:40:37 --> Config Class Initialized
INFO - 2021-01-22 01:40:37 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:40:37 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:40:37 --> Utf8 Class Initialized
INFO - 2021-01-22 01:40:37 --> URI Class Initialized
INFO - 2021-01-22 01:40:37 --> Router Class Initialized
INFO - 2021-01-22 01:40:37 --> Output Class Initialized
INFO - 2021-01-22 01:40:37 --> Security Class Initialized
DEBUG - 2021-01-22 01:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:40:37 --> Input Class Initialized
INFO - 2021-01-22 01:40:37 --> Language Class Initialized
INFO - 2021-01-22 01:40:38 --> Language Class Initialized
INFO - 2021-01-22 01:40:38 --> Config Class Initialized
INFO - 2021-01-22 01:40:38 --> Loader Class Initialized
INFO - 2021-01-22 01:40:38 --> Helper loaded: url_helper
INFO - 2021-01-22 01:40:38 --> Helper loaded: file_helper
INFO - 2021-01-22 01:40:38 --> Helper loaded: form_helper
INFO - 2021-01-22 01:40:38 --> Helper loaded: my_helper
INFO - 2021-01-22 01:40:38 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:40:38 --> Controller Class Initialized
DEBUG - 2021-01-22 01:40:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:40:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:40:39 --> Final output sent to browser
DEBUG - 2021-01-22 01:40:39 --> Total execution time: 2.0207
INFO - 2021-01-22 01:40:48 --> Config Class Initialized
INFO - 2021-01-22 01:40:48 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:40:48 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:40:48 --> Utf8 Class Initialized
INFO - 2021-01-22 01:40:48 --> URI Class Initialized
INFO - 2021-01-22 01:40:48 --> Router Class Initialized
INFO - 2021-01-22 01:40:48 --> Output Class Initialized
INFO - 2021-01-22 01:40:48 --> Security Class Initialized
DEBUG - 2021-01-22 01:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:40:48 --> Input Class Initialized
INFO - 2021-01-22 01:40:48 --> Language Class Initialized
INFO - 2021-01-22 01:40:48 --> Language Class Initialized
INFO - 2021-01-22 01:40:48 --> Config Class Initialized
INFO - 2021-01-22 01:40:48 --> Loader Class Initialized
INFO - 2021-01-22 01:40:48 --> Helper loaded: url_helper
INFO - 2021-01-22 01:40:48 --> Helper loaded: file_helper
INFO - 2021-01-22 01:40:48 --> Helper loaded: form_helper
INFO - 2021-01-22 01:40:49 --> Helper loaded: my_helper
INFO - 2021-01-22 01:40:49 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:40:49 --> Controller Class Initialized
DEBUG - 2021-01-22 01:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:40:49 --> Final output sent to browser
DEBUG - 2021-01-22 01:40:49 --> Total execution time: 1.1151
INFO - 2021-01-22 01:40:51 --> Config Class Initialized
INFO - 2021-01-22 01:40:51 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:40:51 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:40:51 --> Utf8 Class Initialized
INFO - 2021-01-22 01:40:51 --> URI Class Initialized
INFO - 2021-01-22 01:40:51 --> Router Class Initialized
INFO - 2021-01-22 01:40:51 --> Output Class Initialized
INFO - 2021-01-22 01:40:51 --> Security Class Initialized
DEBUG - 2021-01-22 01:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:40:51 --> Input Class Initialized
INFO - 2021-01-22 01:40:51 --> Language Class Initialized
INFO - 2021-01-22 01:40:51 --> Language Class Initialized
INFO - 2021-01-22 01:40:51 --> Config Class Initialized
INFO - 2021-01-22 01:40:51 --> Loader Class Initialized
INFO - 2021-01-22 01:40:51 --> Helper loaded: url_helper
INFO - 2021-01-22 01:40:51 --> Helper loaded: file_helper
INFO - 2021-01-22 01:40:51 --> Helper loaded: form_helper
INFO - 2021-01-22 01:40:51 --> Helper loaded: my_helper
INFO - 2021-01-22 01:40:51 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:40:52 --> Controller Class Initialized
DEBUG - 2021-01-22 01:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-22 01:40:52 --> Final output sent to browser
DEBUG - 2021-01-22 01:40:52 --> Total execution time: 1.2426
INFO - 2021-01-22 01:42:19 --> Config Class Initialized
INFO - 2021-01-22 01:42:19 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:42:19 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:42:19 --> Utf8 Class Initialized
INFO - 2021-01-22 01:42:19 --> URI Class Initialized
INFO - 2021-01-22 01:42:20 --> Router Class Initialized
INFO - 2021-01-22 01:42:20 --> Output Class Initialized
INFO - 2021-01-22 01:42:20 --> Security Class Initialized
DEBUG - 2021-01-22 01:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:42:20 --> Input Class Initialized
INFO - 2021-01-22 01:42:20 --> Language Class Initialized
INFO - 2021-01-22 01:42:20 --> Language Class Initialized
INFO - 2021-01-22 01:42:20 --> Config Class Initialized
INFO - 2021-01-22 01:42:20 --> Loader Class Initialized
INFO - 2021-01-22 01:42:20 --> Helper loaded: url_helper
INFO - 2021-01-22 01:42:20 --> Helper loaded: file_helper
INFO - 2021-01-22 01:42:20 --> Helper loaded: form_helper
INFO - 2021-01-22 01:42:20 --> Helper loaded: my_helper
INFO - 2021-01-22 01:42:20 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:42:20 --> Controller Class Initialized
DEBUG - 2021-01-22 01:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-22 01:42:21 --> Final output sent to browser
DEBUG - 2021-01-22 01:42:21 --> Total execution time: 1.3345
INFO - 2021-01-22 01:43:08 --> Config Class Initialized
INFO - 2021-01-22 01:43:08 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:43:08 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:43:08 --> Utf8 Class Initialized
INFO - 2021-01-22 01:43:08 --> URI Class Initialized
INFO - 2021-01-22 01:43:08 --> Router Class Initialized
INFO - 2021-01-22 01:43:08 --> Output Class Initialized
INFO - 2021-01-22 01:43:08 --> Security Class Initialized
DEBUG - 2021-01-22 01:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:43:08 --> Input Class Initialized
INFO - 2021-01-22 01:43:08 --> Language Class Initialized
INFO - 2021-01-22 01:43:08 --> Language Class Initialized
INFO - 2021-01-22 01:43:08 --> Config Class Initialized
INFO - 2021-01-22 01:43:08 --> Loader Class Initialized
INFO - 2021-01-22 01:43:08 --> Helper loaded: url_helper
INFO - 2021-01-22 01:43:08 --> Helper loaded: file_helper
INFO - 2021-01-22 01:43:08 --> Helper loaded: form_helper
INFO - 2021-01-22 01:43:08 --> Helper loaded: my_helper
INFO - 2021-01-22 01:43:08 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:43:08 --> Controller Class Initialized
DEBUG - 2021-01-22 01:43:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-22 01:43:09 --> Final output sent to browser
DEBUG - 2021-01-22 01:43:09 --> Total execution time: 1.1780
INFO - 2021-01-22 01:43:32 --> Config Class Initialized
INFO - 2021-01-22 01:43:33 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:43:33 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:43:33 --> Utf8 Class Initialized
INFO - 2021-01-22 01:43:33 --> URI Class Initialized
INFO - 2021-01-22 01:43:33 --> Router Class Initialized
INFO - 2021-01-22 01:43:33 --> Output Class Initialized
INFO - 2021-01-22 01:43:33 --> Security Class Initialized
DEBUG - 2021-01-22 01:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:43:33 --> Input Class Initialized
INFO - 2021-01-22 01:43:33 --> Language Class Initialized
INFO - 2021-01-22 01:43:33 --> Language Class Initialized
INFO - 2021-01-22 01:43:33 --> Config Class Initialized
INFO - 2021-01-22 01:43:33 --> Loader Class Initialized
INFO - 2021-01-22 01:43:33 --> Helper loaded: url_helper
INFO - 2021-01-22 01:43:33 --> Helper loaded: file_helper
INFO - 2021-01-22 01:43:33 --> Helper loaded: form_helper
INFO - 2021-01-22 01:43:33 --> Helper loaded: my_helper
INFO - 2021-01-22 01:43:33 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:43:34 --> Controller Class Initialized
DEBUG - 2021-01-22 01:43:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-22 01:43:34 --> Final output sent to browser
DEBUG - 2021-01-22 01:43:34 --> Total execution time: 1.4030
INFO - 2021-01-22 01:43:46 --> Config Class Initialized
INFO - 2021-01-22 01:43:46 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:43:46 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:43:46 --> Utf8 Class Initialized
INFO - 2021-01-22 01:43:46 --> URI Class Initialized
INFO - 2021-01-22 01:43:46 --> Router Class Initialized
INFO - 2021-01-22 01:43:46 --> Output Class Initialized
INFO - 2021-01-22 01:43:46 --> Security Class Initialized
DEBUG - 2021-01-22 01:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:43:46 --> Input Class Initialized
INFO - 2021-01-22 01:43:46 --> Language Class Initialized
INFO - 2021-01-22 01:43:46 --> Language Class Initialized
INFO - 2021-01-22 01:43:46 --> Config Class Initialized
INFO - 2021-01-22 01:43:46 --> Loader Class Initialized
INFO - 2021-01-22 01:43:46 --> Helper loaded: url_helper
INFO - 2021-01-22 01:43:46 --> Helper loaded: file_helper
INFO - 2021-01-22 01:43:46 --> Helper loaded: form_helper
INFO - 2021-01-22 01:43:47 --> Helper loaded: my_helper
INFO - 2021-01-22 01:43:47 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:43:47 --> Controller Class Initialized
DEBUG - 2021-01-22 01:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-22 01:43:47 --> Final output sent to browser
DEBUG - 2021-01-22 01:43:47 --> Total execution time: 1.5845
INFO - 2021-01-22 01:43:56 --> Config Class Initialized
INFO - 2021-01-22 01:43:56 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:43:56 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:43:56 --> Utf8 Class Initialized
INFO - 2021-01-22 01:43:57 --> URI Class Initialized
INFO - 2021-01-22 01:43:57 --> Router Class Initialized
INFO - 2021-01-22 01:43:57 --> Output Class Initialized
INFO - 2021-01-22 01:43:57 --> Security Class Initialized
DEBUG - 2021-01-22 01:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:43:57 --> Input Class Initialized
INFO - 2021-01-22 01:43:57 --> Language Class Initialized
INFO - 2021-01-22 01:43:57 --> Language Class Initialized
INFO - 2021-01-22 01:43:57 --> Config Class Initialized
INFO - 2021-01-22 01:43:57 --> Loader Class Initialized
INFO - 2021-01-22 01:43:57 --> Helper loaded: url_helper
INFO - 2021-01-22 01:43:57 --> Helper loaded: file_helper
INFO - 2021-01-22 01:43:57 --> Helper loaded: form_helper
INFO - 2021-01-22 01:43:57 --> Helper loaded: my_helper
INFO - 2021-01-22 01:43:57 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:43:57 --> Controller Class Initialized
DEBUG - 2021-01-22 01:43:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-22 01:43:58 --> Final output sent to browser
DEBUG - 2021-01-22 01:43:58 --> Total execution time: 1.3597
INFO - 2021-01-22 01:44:51 --> Config Class Initialized
INFO - 2021-01-22 01:44:51 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:44:51 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:44:51 --> Utf8 Class Initialized
INFO - 2021-01-22 01:44:51 --> URI Class Initialized
INFO - 2021-01-22 01:44:51 --> Router Class Initialized
INFO - 2021-01-22 01:44:51 --> Output Class Initialized
INFO - 2021-01-22 01:44:51 --> Security Class Initialized
DEBUG - 2021-01-22 01:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:44:51 --> Input Class Initialized
INFO - 2021-01-22 01:44:51 --> Language Class Initialized
INFO - 2021-01-22 01:44:51 --> Language Class Initialized
INFO - 2021-01-22 01:44:51 --> Config Class Initialized
INFO - 2021-01-22 01:44:51 --> Loader Class Initialized
INFO - 2021-01-22 01:44:52 --> Helper loaded: url_helper
INFO - 2021-01-22 01:44:52 --> Helper loaded: file_helper
INFO - 2021-01-22 01:44:52 --> Helper loaded: form_helper
INFO - 2021-01-22 01:44:52 --> Helper loaded: my_helper
INFO - 2021-01-22 01:44:52 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:44:52 --> Controller Class Initialized
INFO - 2021-01-22 01:44:52 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:44:52 --> Config Class Initialized
INFO - 2021-01-22 01:44:52 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:44:52 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:44:52 --> Utf8 Class Initialized
INFO - 2021-01-22 01:44:52 --> URI Class Initialized
INFO - 2021-01-22 01:44:53 --> Router Class Initialized
INFO - 2021-01-22 01:44:53 --> Output Class Initialized
INFO - 2021-01-22 01:44:53 --> Security Class Initialized
DEBUG - 2021-01-22 01:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:44:53 --> Input Class Initialized
INFO - 2021-01-22 01:44:53 --> Language Class Initialized
INFO - 2021-01-22 01:44:53 --> Language Class Initialized
INFO - 2021-01-22 01:44:53 --> Config Class Initialized
INFO - 2021-01-22 01:44:53 --> Loader Class Initialized
INFO - 2021-01-22 01:44:53 --> Helper loaded: url_helper
INFO - 2021-01-22 01:44:53 --> Helper loaded: file_helper
INFO - 2021-01-22 01:44:53 --> Helper loaded: form_helper
INFO - 2021-01-22 01:44:53 --> Helper loaded: my_helper
INFO - 2021-01-22 01:44:53 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:44:53 --> Controller Class Initialized
DEBUG - 2021-01-22 01:44:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:44:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:44:54 --> Final output sent to browser
DEBUG - 2021-01-22 01:44:54 --> Total execution time: 1.3890
INFO - 2021-01-22 01:45:01 --> Config Class Initialized
INFO - 2021-01-22 01:45:01 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:45:01 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:45:01 --> Utf8 Class Initialized
INFO - 2021-01-22 01:45:01 --> URI Class Initialized
INFO - 2021-01-22 01:45:01 --> Router Class Initialized
INFO - 2021-01-22 01:45:01 --> Output Class Initialized
INFO - 2021-01-22 01:45:01 --> Security Class Initialized
DEBUG - 2021-01-22 01:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:45:01 --> Input Class Initialized
INFO - 2021-01-22 01:45:01 --> Language Class Initialized
INFO - 2021-01-22 01:45:01 --> Language Class Initialized
INFO - 2021-01-22 01:45:01 --> Config Class Initialized
INFO - 2021-01-22 01:45:01 --> Loader Class Initialized
INFO - 2021-01-22 01:45:02 --> Helper loaded: url_helper
INFO - 2021-01-22 01:45:02 --> Helper loaded: file_helper
INFO - 2021-01-22 01:45:02 --> Helper loaded: form_helper
INFO - 2021-01-22 01:45:02 --> Helper loaded: my_helper
INFO - 2021-01-22 01:45:02 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:45:02 --> Controller Class Initialized
INFO - 2021-01-22 01:45:02 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:45:02 --> Final output sent to browser
DEBUG - 2021-01-22 01:45:02 --> Total execution time: 0.9787
INFO - 2021-01-22 01:45:02 --> Config Class Initialized
INFO - 2021-01-22 01:45:02 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:45:03 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:45:03 --> Utf8 Class Initialized
INFO - 2021-01-22 01:45:03 --> URI Class Initialized
INFO - 2021-01-22 01:45:03 --> Router Class Initialized
INFO - 2021-01-22 01:45:03 --> Output Class Initialized
INFO - 2021-01-22 01:45:03 --> Security Class Initialized
DEBUG - 2021-01-22 01:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:45:03 --> Input Class Initialized
INFO - 2021-01-22 01:45:03 --> Language Class Initialized
INFO - 2021-01-22 01:45:03 --> Language Class Initialized
INFO - 2021-01-22 01:45:03 --> Config Class Initialized
INFO - 2021-01-22 01:45:03 --> Loader Class Initialized
INFO - 2021-01-22 01:45:03 --> Helper loaded: url_helper
INFO - 2021-01-22 01:45:03 --> Helper loaded: file_helper
INFO - 2021-01-22 01:45:03 --> Helper loaded: form_helper
INFO - 2021-01-22 01:45:04 --> Helper loaded: my_helper
INFO - 2021-01-22 01:45:04 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:45:04 --> Controller Class Initialized
DEBUG - 2021-01-22 01:45:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:45:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:45:04 --> Final output sent to browser
DEBUG - 2021-01-22 01:45:04 --> Total execution time: 1.6896
INFO - 2021-01-22 01:45:06 --> Config Class Initialized
INFO - 2021-01-22 01:45:06 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:45:06 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:45:06 --> Utf8 Class Initialized
INFO - 2021-01-22 01:45:06 --> URI Class Initialized
INFO - 2021-01-22 01:45:06 --> Router Class Initialized
INFO - 2021-01-22 01:45:06 --> Output Class Initialized
INFO - 2021-01-22 01:45:06 --> Security Class Initialized
DEBUG - 2021-01-22 01:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:45:06 --> Input Class Initialized
INFO - 2021-01-22 01:45:06 --> Language Class Initialized
INFO - 2021-01-22 01:45:06 --> Language Class Initialized
INFO - 2021-01-22 01:45:06 --> Config Class Initialized
INFO - 2021-01-22 01:45:06 --> Loader Class Initialized
INFO - 2021-01-22 01:45:07 --> Helper loaded: url_helper
INFO - 2021-01-22 01:45:07 --> Helper loaded: file_helper
INFO - 2021-01-22 01:45:07 --> Helper loaded: form_helper
INFO - 2021-01-22 01:45:07 --> Helper loaded: my_helper
INFO - 2021-01-22 01:45:07 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:45:07 --> Controller Class Initialized
DEBUG - 2021-01-22 01:45:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:45:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:45:07 --> Final output sent to browser
DEBUG - 2021-01-22 01:45:07 --> Total execution time: 1.3278
INFO - 2021-01-22 01:45:11 --> Config Class Initialized
INFO - 2021-01-22 01:45:11 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:45:11 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:45:11 --> Utf8 Class Initialized
INFO - 2021-01-22 01:45:11 --> URI Class Initialized
INFO - 2021-01-22 01:45:11 --> Router Class Initialized
INFO - 2021-01-22 01:45:11 --> Output Class Initialized
INFO - 2021-01-22 01:45:11 --> Security Class Initialized
DEBUG - 2021-01-22 01:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:45:11 --> Input Class Initialized
INFO - 2021-01-22 01:45:12 --> Language Class Initialized
INFO - 2021-01-22 01:45:12 --> Language Class Initialized
INFO - 2021-01-22 01:45:12 --> Config Class Initialized
INFO - 2021-01-22 01:45:12 --> Loader Class Initialized
INFO - 2021-01-22 01:45:12 --> Helper loaded: url_helper
INFO - 2021-01-22 01:45:12 --> Helper loaded: file_helper
INFO - 2021-01-22 01:45:12 --> Helper loaded: form_helper
INFO - 2021-01-22 01:45:12 --> Helper loaded: my_helper
INFO - 2021-01-22 01:45:12 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:45:12 --> Controller Class Initialized
DEBUG - 2021-01-22 01:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-22 01:45:12 --> Final output sent to browser
DEBUG - 2021-01-22 01:45:13 --> Total execution time: 1.3323
INFO - 2021-01-22 01:46:45 --> Config Class Initialized
INFO - 2021-01-22 01:46:45 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:46:45 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:46:45 --> Utf8 Class Initialized
INFO - 2021-01-22 01:46:45 --> URI Class Initialized
INFO - 2021-01-22 01:46:45 --> Router Class Initialized
INFO - 2021-01-22 01:46:45 --> Output Class Initialized
INFO - 2021-01-22 01:46:45 --> Security Class Initialized
DEBUG - 2021-01-22 01:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:46:46 --> Input Class Initialized
INFO - 2021-01-22 01:46:46 --> Language Class Initialized
INFO - 2021-01-22 01:46:46 --> Language Class Initialized
INFO - 2021-01-22 01:46:46 --> Config Class Initialized
INFO - 2021-01-22 01:46:46 --> Loader Class Initialized
INFO - 2021-01-22 01:46:46 --> Helper loaded: url_helper
INFO - 2021-01-22 01:46:46 --> Helper loaded: file_helper
INFO - 2021-01-22 01:46:46 --> Helper loaded: form_helper
INFO - 2021-01-22 01:46:46 --> Helper loaded: my_helper
INFO - 2021-01-22 01:46:46 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:46:46 --> Controller Class Initialized
DEBUG - 2021-01-22 01:46:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-22 01:46:47 --> Final output sent to browser
DEBUG - 2021-01-22 01:46:47 --> Total execution time: 1.3911
INFO - 2021-01-22 01:47:23 --> Config Class Initialized
INFO - 2021-01-22 01:47:24 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:47:24 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:47:24 --> Utf8 Class Initialized
INFO - 2021-01-22 01:47:24 --> URI Class Initialized
INFO - 2021-01-22 01:47:24 --> Router Class Initialized
INFO - 2021-01-22 01:47:24 --> Output Class Initialized
INFO - 2021-01-22 01:47:24 --> Security Class Initialized
DEBUG - 2021-01-22 01:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:47:24 --> Input Class Initialized
INFO - 2021-01-22 01:47:24 --> Language Class Initialized
INFO - 2021-01-22 01:47:24 --> Language Class Initialized
INFO - 2021-01-22 01:47:24 --> Config Class Initialized
INFO - 2021-01-22 01:47:24 --> Loader Class Initialized
INFO - 2021-01-22 01:47:24 --> Helper loaded: url_helper
INFO - 2021-01-22 01:47:24 --> Helper loaded: file_helper
INFO - 2021-01-22 01:47:24 --> Helper loaded: form_helper
INFO - 2021-01-22 01:47:24 --> Helper loaded: my_helper
INFO - 2021-01-22 01:47:24 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:47:24 --> Controller Class Initialized
DEBUG - 2021-01-22 01:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-22 01:47:25 --> Final output sent to browser
DEBUG - 2021-01-22 01:47:25 --> Total execution time: 1.0756
INFO - 2021-01-22 01:47:41 --> Config Class Initialized
INFO - 2021-01-22 01:47:42 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:47:42 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:47:42 --> Utf8 Class Initialized
INFO - 2021-01-22 01:47:42 --> URI Class Initialized
INFO - 2021-01-22 01:47:42 --> Router Class Initialized
INFO - 2021-01-22 01:47:42 --> Output Class Initialized
INFO - 2021-01-22 01:47:42 --> Security Class Initialized
DEBUG - 2021-01-22 01:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:47:42 --> Input Class Initialized
INFO - 2021-01-22 01:47:42 --> Language Class Initialized
INFO - 2021-01-22 01:47:42 --> Language Class Initialized
INFO - 2021-01-22 01:47:42 --> Config Class Initialized
INFO - 2021-01-22 01:47:42 --> Loader Class Initialized
INFO - 2021-01-22 01:47:42 --> Helper loaded: url_helper
INFO - 2021-01-22 01:47:42 --> Helper loaded: file_helper
INFO - 2021-01-22 01:47:42 --> Helper loaded: form_helper
INFO - 2021-01-22 01:47:42 --> Helper loaded: my_helper
INFO - 2021-01-22 01:47:42 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:47:42 --> Controller Class Initialized
DEBUG - 2021-01-22 01:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-22 01:47:43 --> Final output sent to browser
DEBUG - 2021-01-22 01:47:43 --> Total execution time: 1.3413
INFO - 2021-01-22 01:48:15 --> Config Class Initialized
INFO - 2021-01-22 01:48:15 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:48:15 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:48:15 --> Utf8 Class Initialized
INFO - 2021-01-22 01:48:15 --> URI Class Initialized
INFO - 2021-01-22 01:48:15 --> Router Class Initialized
INFO - 2021-01-22 01:48:15 --> Output Class Initialized
INFO - 2021-01-22 01:48:15 --> Security Class Initialized
DEBUG - 2021-01-22 01:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:48:15 --> Input Class Initialized
INFO - 2021-01-22 01:48:15 --> Language Class Initialized
INFO - 2021-01-22 01:48:15 --> Language Class Initialized
INFO - 2021-01-22 01:48:15 --> Config Class Initialized
INFO - 2021-01-22 01:48:15 --> Loader Class Initialized
INFO - 2021-01-22 01:48:15 --> Helper loaded: url_helper
INFO - 2021-01-22 01:48:16 --> Helper loaded: file_helper
INFO - 2021-01-22 01:48:16 --> Helper loaded: form_helper
INFO - 2021-01-22 01:48:16 --> Helper loaded: my_helper
INFO - 2021-01-22 01:48:16 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:48:16 --> Controller Class Initialized
DEBUG - 2021-01-22 01:48:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-22 01:48:16 --> Final output sent to browser
DEBUG - 2021-01-22 01:48:16 --> Total execution time: 1.3831
INFO - 2021-01-22 01:48:27 --> Config Class Initialized
INFO - 2021-01-22 01:48:27 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:48:27 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:48:27 --> Utf8 Class Initialized
INFO - 2021-01-22 01:48:27 --> URI Class Initialized
INFO - 2021-01-22 01:48:27 --> Router Class Initialized
INFO - 2021-01-22 01:48:27 --> Output Class Initialized
INFO - 2021-01-22 01:48:28 --> Security Class Initialized
DEBUG - 2021-01-22 01:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:48:28 --> Input Class Initialized
INFO - 2021-01-22 01:48:28 --> Language Class Initialized
INFO - 2021-01-22 01:48:28 --> Language Class Initialized
INFO - 2021-01-22 01:48:28 --> Config Class Initialized
INFO - 2021-01-22 01:48:28 --> Loader Class Initialized
INFO - 2021-01-22 01:48:28 --> Helper loaded: url_helper
INFO - 2021-01-22 01:48:28 --> Helper loaded: file_helper
INFO - 2021-01-22 01:48:28 --> Helper loaded: form_helper
INFO - 2021-01-22 01:48:28 --> Helper loaded: my_helper
INFO - 2021-01-22 01:48:28 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:48:28 --> Controller Class Initialized
INFO - 2021-01-22 01:48:28 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:48:28 --> Config Class Initialized
INFO - 2021-01-22 01:48:28 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:48:29 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:48:29 --> Utf8 Class Initialized
INFO - 2021-01-22 01:48:29 --> URI Class Initialized
INFO - 2021-01-22 01:48:29 --> Router Class Initialized
INFO - 2021-01-22 01:48:29 --> Output Class Initialized
INFO - 2021-01-22 01:48:29 --> Security Class Initialized
DEBUG - 2021-01-22 01:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:48:29 --> Input Class Initialized
INFO - 2021-01-22 01:48:29 --> Language Class Initialized
INFO - 2021-01-22 01:48:29 --> Language Class Initialized
INFO - 2021-01-22 01:48:29 --> Config Class Initialized
INFO - 2021-01-22 01:48:29 --> Loader Class Initialized
INFO - 2021-01-22 01:48:29 --> Helper loaded: url_helper
INFO - 2021-01-22 01:48:29 --> Helper loaded: file_helper
INFO - 2021-01-22 01:48:29 --> Helper loaded: form_helper
INFO - 2021-01-22 01:48:29 --> Helper loaded: my_helper
INFO - 2021-01-22 01:48:29 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:48:29 --> Controller Class Initialized
DEBUG - 2021-01-22 01:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:48:29 --> Final output sent to browser
DEBUG - 2021-01-22 01:48:30 --> Total execution time: 1.0570
INFO - 2021-01-22 01:48:37 --> Config Class Initialized
INFO - 2021-01-22 01:48:37 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:48:37 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:48:37 --> Utf8 Class Initialized
INFO - 2021-01-22 01:48:37 --> URI Class Initialized
INFO - 2021-01-22 01:48:37 --> Router Class Initialized
INFO - 2021-01-22 01:48:38 --> Output Class Initialized
INFO - 2021-01-22 01:48:38 --> Security Class Initialized
DEBUG - 2021-01-22 01:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:48:38 --> Input Class Initialized
INFO - 2021-01-22 01:48:38 --> Language Class Initialized
INFO - 2021-01-22 01:48:38 --> Language Class Initialized
INFO - 2021-01-22 01:48:38 --> Config Class Initialized
INFO - 2021-01-22 01:48:38 --> Loader Class Initialized
INFO - 2021-01-22 01:48:38 --> Helper loaded: url_helper
INFO - 2021-01-22 01:48:38 --> Helper loaded: file_helper
INFO - 2021-01-22 01:48:38 --> Helper loaded: form_helper
INFO - 2021-01-22 01:48:38 --> Helper loaded: my_helper
INFO - 2021-01-22 01:48:38 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:48:38 --> Controller Class Initialized
INFO - 2021-01-22 01:48:38 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:48:38 --> Final output sent to browser
DEBUG - 2021-01-22 01:48:38 --> Total execution time: 1.1061
INFO - 2021-01-22 01:48:39 --> Config Class Initialized
INFO - 2021-01-22 01:48:39 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:48:39 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:48:39 --> Utf8 Class Initialized
INFO - 2021-01-22 01:48:39 --> URI Class Initialized
INFO - 2021-01-22 01:48:39 --> Router Class Initialized
INFO - 2021-01-22 01:48:39 --> Output Class Initialized
INFO - 2021-01-22 01:48:39 --> Security Class Initialized
DEBUG - 2021-01-22 01:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:48:40 --> Input Class Initialized
INFO - 2021-01-22 01:48:40 --> Language Class Initialized
INFO - 2021-01-22 01:48:40 --> Language Class Initialized
INFO - 2021-01-22 01:48:40 --> Config Class Initialized
INFO - 2021-01-22 01:48:40 --> Loader Class Initialized
INFO - 2021-01-22 01:48:40 --> Helper loaded: url_helper
INFO - 2021-01-22 01:48:40 --> Helper loaded: file_helper
INFO - 2021-01-22 01:48:40 --> Helper loaded: form_helper
INFO - 2021-01-22 01:48:40 --> Helper loaded: my_helper
INFO - 2021-01-22 01:48:40 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:48:40 --> Controller Class Initialized
DEBUG - 2021-01-22 01:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:48:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:48:41 --> Final output sent to browser
DEBUG - 2021-01-22 01:48:41 --> Total execution time: 1.7718
INFO - 2021-01-22 01:48:43 --> Config Class Initialized
INFO - 2021-01-22 01:48:43 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:48:43 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:48:43 --> Utf8 Class Initialized
INFO - 2021-01-22 01:48:43 --> URI Class Initialized
INFO - 2021-01-22 01:48:43 --> Router Class Initialized
INFO - 2021-01-22 01:48:43 --> Output Class Initialized
INFO - 2021-01-22 01:48:43 --> Security Class Initialized
DEBUG - 2021-01-22 01:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:48:43 --> Input Class Initialized
INFO - 2021-01-22 01:48:43 --> Language Class Initialized
INFO - 2021-01-22 01:48:43 --> Language Class Initialized
INFO - 2021-01-22 01:48:43 --> Config Class Initialized
INFO - 2021-01-22 01:48:43 --> Loader Class Initialized
INFO - 2021-01-22 01:48:44 --> Helper loaded: url_helper
INFO - 2021-01-22 01:48:44 --> Helper loaded: file_helper
INFO - 2021-01-22 01:48:44 --> Helper loaded: form_helper
INFO - 2021-01-22 01:48:44 --> Helper loaded: my_helper
INFO - 2021-01-22 01:48:44 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:48:44 --> Controller Class Initialized
DEBUG - 2021-01-22 01:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:48:44 --> Final output sent to browser
DEBUG - 2021-01-22 01:48:44 --> Total execution time: 1.0203
INFO - 2021-01-22 01:48:47 --> Config Class Initialized
INFO - 2021-01-22 01:48:47 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:48:47 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:48:47 --> Utf8 Class Initialized
INFO - 2021-01-22 01:48:47 --> URI Class Initialized
INFO - 2021-01-22 01:48:47 --> Router Class Initialized
INFO - 2021-01-22 01:48:47 --> Output Class Initialized
INFO - 2021-01-22 01:48:47 --> Security Class Initialized
DEBUG - 2021-01-22 01:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:48:47 --> Input Class Initialized
INFO - 2021-01-22 01:48:47 --> Language Class Initialized
INFO - 2021-01-22 01:48:47 --> Language Class Initialized
INFO - 2021-01-22 01:48:47 --> Config Class Initialized
INFO - 2021-01-22 01:48:47 --> Loader Class Initialized
INFO - 2021-01-22 01:48:47 --> Helper loaded: url_helper
INFO - 2021-01-22 01:48:47 --> Helper loaded: file_helper
INFO - 2021-01-22 01:48:47 --> Helper loaded: form_helper
INFO - 2021-01-22 01:48:47 --> Helper loaded: my_helper
INFO - 2021-01-22 01:48:48 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:48:48 --> Controller Class Initialized
DEBUG - 2021-01-22 01:48:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-22 01:48:48 --> Final output sent to browser
DEBUG - 2021-01-22 01:48:48 --> Total execution time: 1.1138
INFO - 2021-01-22 01:49:57 --> Config Class Initialized
INFO - 2021-01-22 01:49:57 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:49:57 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:49:57 --> Utf8 Class Initialized
INFO - 2021-01-22 01:49:57 --> URI Class Initialized
INFO - 2021-01-22 01:49:57 --> Router Class Initialized
INFO - 2021-01-22 01:49:57 --> Output Class Initialized
INFO - 2021-01-22 01:49:57 --> Security Class Initialized
DEBUG - 2021-01-22 01:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:49:58 --> Input Class Initialized
INFO - 2021-01-22 01:49:58 --> Language Class Initialized
INFO - 2021-01-22 01:49:58 --> Language Class Initialized
INFO - 2021-01-22 01:49:58 --> Config Class Initialized
INFO - 2021-01-22 01:49:58 --> Loader Class Initialized
INFO - 2021-01-22 01:49:58 --> Helper loaded: url_helper
INFO - 2021-01-22 01:49:58 --> Helper loaded: file_helper
INFO - 2021-01-22 01:49:58 --> Helper loaded: form_helper
INFO - 2021-01-22 01:49:58 --> Helper loaded: my_helper
INFO - 2021-01-22 01:49:58 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:49:58 --> Controller Class Initialized
DEBUG - 2021-01-22 01:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-22 01:49:58 --> Final output sent to browser
DEBUG - 2021-01-22 01:49:59 --> Total execution time: 1.3119
INFO - 2021-01-22 01:50:50 --> Config Class Initialized
INFO - 2021-01-22 01:50:50 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:50:51 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:50:51 --> Utf8 Class Initialized
INFO - 2021-01-22 01:50:51 --> URI Class Initialized
INFO - 2021-01-22 01:50:51 --> Router Class Initialized
INFO - 2021-01-22 01:50:51 --> Output Class Initialized
INFO - 2021-01-22 01:50:51 --> Security Class Initialized
DEBUG - 2021-01-22 01:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:50:51 --> Input Class Initialized
INFO - 2021-01-22 01:50:51 --> Language Class Initialized
INFO - 2021-01-22 01:50:51 --> Language Class Initialized
INFO - 2021-01-22 01:50:51 --> Config Class Initialized
INFO - 2021-01-22 01:50:51 --> Loader Class Initialized
INFO - 2021-01-22 01:50:51 --> Helper loaded: url_helper
INFO - 2021-01-22 01:50:51 --> Helper loaded: file_helper
INFO - 2021-01-22 01:50:51 --> Helper loaded: form_helper
INFO - 2021-01-22 01:50:51 --> Helper loaded: my_helper
INFO - 2021-01-22 01:50:51 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:50:51 --> Controller Class Initialized
DEBUG - 2021-01-22 01:50:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-22 01:50:52 --> Final output sent to browser
DEBUG - 2021-01-22 01:50:52 --> Total execution time: 1.2436
INFO - 2021-01-22 01:51:09 --> Config Class Initialized
INFO - 2021-01-22 01:51:09 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:51:09 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:51:09 --> Utf8 Class Initialized
INFO - 2021-01-22 01:51:09 --> URI Class Initialized
INFO - 2021-01-22 01:51:09 --> Router Class Initialized
INFO - 2021-01-22 01:51:09 --> Output Class Initialized
INFO - 2021-01-22 01:51:09 --> Security Class Initialized
DEBUG - 2021-01-22 01:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:51:09 --> Input Class Initialized
INFO - 2021-01-22 01:51:10 --> Language Class Initialized
INFO - 2021-01-22 01:51:10 --> Language Class Initialized
INFO - 2021-01-22 01:51:10 --> Config Class Initialized
INFO - 2021-01-22 01:51:10 --> Loader Class Initialized
INFO - 2021-01-22 01:51:10 --> Helper loaded: url_helper
INFO - 2021-01-22 01:51:10 --> Helper loaded: file_helper
INFO - 2021-01-22 01:51:10 --> Helper loaded: form_helper
INFO - 2021-01-22 01:51:10 --> Helper loaded: my_helper
INFO - 2021-01-22 01:51:10 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:51:10 --> Controller Class Initialized
DEBUG - 2021-01-22 01:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-22 01:51:10 --> Final output sent to browser
DEBUG - 2021-01-22 01:51:10 --> Total execution time: 1.1524
INFO - 2021-01-22 01:51:25 --> Config Class Initialized
INFO - 2021-01-22 01:51:25 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:51:25 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:51:25 --> Utf8 Class Initialized
INFO - 2021-01-22 01:51:25 --> URI Class Initialized
INFO - 2021-01-22 01:51:25 --> Router Class Initialized
INFO - 2021-01-22 01:51:25 --> Output Class Initialized
INFO - 2021-01-22 01:51:25 --> Security Class Initialized
DEBUG - 2021-01-22 01:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:51:25 --> Input Class Initialized
INFO - 2021-01-22 01:51:25 --> Language Class Initialized
INFO - 2021-01-22 01:51:25 --> Language Class Initialized
INFO - 2021-01-22 01:51:26 --> Config Class Initialized
INFO - 2021-01-22 01:51:26 --> Loader Class Initialized
INFO - 2021-01-22 01:51:26 --> Helper loaded: url_helper
INFO - 2021-01-22 01:51:26 --> Helper loaded: file_helper
INFO - 2021-01-22 01:51:26 --> Helper loaded: form_helper
INFO - 2021-01-22 01:51:26 --> Helper loaded: my_helper
INFO - 2021-01-22 01:51:26 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:51:26 --> Controller Class Initialized
DEBUG - 2021-01-22 01:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-22 01:51:26 --> Final output sent to browser
DEBUG - 2021-01-22 01:51:26 --> Total execution time: 1.6003
INFO - 2021-01-22 01:51:42 --> Config Class Initialized
INFO - 2021-01-22 01:51:42 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:51:42 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:51:42 --> Utf8 Class Initialized
INFO - 2021-01-22 01:51:42 --> URI Class Initialized
INFO - 2021-01-22 01:51:42 --> Router Class Initialized
INFO - 2021-01-22 01:51:42 --> Output Class Initialized
INFO - 2021-01-22 01:51:42 --> Security Class Initialized
DEBUG - 2021-01-22 01:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:51:42 --> Input Class Initialized
INFO - 2021-01-22 01:51:42 --> Language Class Initialized
INFO - 2021-01-22 01:51:43 --> Language Class Initialized
INFO - 2021-01-22 01:51:43 --> Config Class Initialized
INFO - 2021-01-22 01:51:43 --> Loader Class Initialized
INFO - 2021-01-22 01:51:43 --> Helper loaded: url_helper
INFO - 2021-01-22 01:51:43 --> Helper loaded: file_helper
INFO - 2021-01-22 01:51:43 --> Helper loaded: form_helper
INFO - 2021-01-22 01:51:43 --> Helper loaded: my_helper
INFO - 2021-01-22 01:51:43 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:51:43 --> Controller Class Initialized
INFO - 2021-01-22 01:51:43 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:51:43 --> Config Class Initialized
INFO - 2021-01-22 01:51:43 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:51:43 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:51:43 --> Utf8 Class Initialized
INFO - 2021-01-22 01:51:43 --> URI Class Initialized
INFO - 2021-01-22 01:51:43 --> Router Class Initialized
INFO - 2021-01-22 01:51:43 --> Output Class Initialized
INFO - 2021-01-22 01:51:43 --> Security Class Initialized
DEBUG - 2021-01-22 01:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:51:43 --> Input Class Initialized
INFO - 2021-01-22 01:51:44 --> Language Class Initialized
INFO - 2021-01-22 01:51:44 --> Language Class Initialized
INFO - 2021-01-22 01:51:44 --> Config Class Initialized
INFO - 2021-01-22 01:51:44 --> Loader Class Initialized
INFO - 2021-01-22 01:51:44 --> Helper loaded: url_helper
INFO - 2021-01-22 01:51:44 --> Helper loaded: file_helper
INFO - 2021-01-22 01:51:44 --> Helper loaded: form_helper
INFO - 2021-01-22 01:51:44 --> Helper loaded: my_helper
INFO - 2021-01-22 01:51:44 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:51:44 --> Controller Class Initialized
DEBUG - 2021-01-22 01:51:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:51:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:51:44 --> Final output sent to browser
DEBUG - 2021-01-22 01:51:44 --> Total execution time: 0.9961
INFO - 2021-01-22 01:52:32 --> Config Class Initialized
INFO - 2021-01-22 01:52:32 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:52:32 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:52:32 --> Utf8 Class Initialized
INFO - 2021-01-22 01:52:32 --> URI Class Initialized
INFO - 2021-01-22 01:52:32 --> Router Class Initialized
INFO - 2021-01-22 01:52:32 --> Output Class Initialized
INFO - 2021-01-22 01:52:32 --> Security Class Initialized
DEBUG - 2021-01-22 01:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:52:32 --> Input Class Initialized
INFO - 2021-01-22 01:52:32 --> Language Class Initialized
INFO - 2021-01-22 01:52:33 --> Language Class Initialized
INFO - 2021-01-22 01:52:33 --> Config Class Initialized
INFO - 2021-01-22 01:52:33 --> Loader Class Initialized
INFO - 2021-01-22 01:52:33 --> Helper loaded: url_helper
INFO - 2021-01-22 01:52:33 --> Helper loaded: file_helper
INFO - 2021-01-22 01:52:33 --> Helper loaded: form_helper
INFO - 2021-01-22 01:52:33 --> Helper loaded: my_helper
INFO - 2021-01-22 01:52:33 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:52:33 --> Controller Class Initialized
INFO - 2021-01-22 01:52:33 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:52:33 --> Final output sent to browser
DEBUG - 2021-01-22 01:52:33 --> Total execution time: 1.0885
INFO - 2021-01-22 01:52:34 --> Config Class Initialized
INFO - 2021-01-22 01:52:34 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:52:34 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:52:34 --> Utf8 Class Initialized
INFO - 2021-01-22 01:52:34 --> URI Class Initialized
INFO - 2021-01-22 01:52:34 --> Router Class Initialized
INFO - 2021-01-22 01:52:34 --> Output Class Initialized
INFO - 2021-01-22 01:52:34 --> Security Class Initialized
DEBUG - 2021-01-22 01:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:52:34 --> Input Class Initialized
INFO - 2021-01-22 01:52:34 --> Language Class Initialized
INFO - 2021-01-22 01:52:34 --> Language Class Initialized
INFO - 2021-01-22 01:52:34 --> Config Class Initialized
INFO - 2021-01-22 01:52:34 --> Loader Class Initialized
INFO - 2021-01-22 01:52:34 --> Helper loaded: url_helper
INFO - 2021-01-22 01:52:35 --> Helper loaded: file_helper
INFO - 2021-01-22 01:52:35 --> Helper loaded: form_helper
INFO - 2021-01-22 01:52:35 --> Helper loaded: my_helper
INFO - 2021-01-22 01:52:35 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:52:35 --> Controller Class Initialized
DEBUG - 2021-01-22 01:52:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:52:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:52:35 --> Final output sent to browser
DEBUG - 2021-01-22 01:52:35 --> Total execution time: 1.4289
INFO - 2021-01-22 01:52:37 --> Config Class Initialized
INFO - 2021-01-22 01:52:37 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:52:37 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:52:37 --> Utf8 Class Initialized
INFO - 2021-01-22 01:52:37 --> URI Class Initialized
INFO - 2021-01-22 01:52:37 --> Router Class Initialized
INFO - 2021-01-22 01:52:37 --> Output Class Initialized
INFO - 2021-01-22 01:52:37 --> Security Class Initialized
DEBUG - 2021-01-22 01:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:52:37 --> Input Class Initialized
INFO - 2021-01-22 01:52:37 --> Language Class Initialized
INFO - 2021-01-22 01:52:37 --> Language Class Initialized
INFO - 2021-01-22 01:52:37 --> Config Class Initialized
INFO - 2021-01-22 01:52:37 --> Loader Class Initialized
INFO - 2021-01-22 01:52:38 --> Helper loaded: url_helper
INFO - 2021-01-22 01:52:38 --> Helper loaded: file_helper
INFO - 2021-01-22 01:52:38 --> Helper loaded: form_helper
INFO - 2021-01-22 01:52:38 --> Helper loaded: my_helper
INFO - 2021-01-22 01:52:38 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:52:38 --> Controller Class Initialized
DEBUG - 2021-01-22 01:52:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:52:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:52:38 --> Final output sent to browser
DEBUG - 2021-01-22 01:52:38 --> Total execution time: 1.4339
INFO - 2021-01-22 01:52:40 --> Config Class Initialized
INFO - 2021-01-22 01:52:40 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:52:40 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:52:40 --> Utf8 Class Initialized
INFO - 2021-01-22 01:52:40 --> URI Class Initialized
INFO - 2021-01-22 01:52:40 --> Router Class Initialized
INFO - 2021-01-22 01:52:40 --> Output Class Initialized
INFO - 2021-01-22 01:52:40 --> Security Class Initialized
DEBUG - 2021-01-22 01:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:52:40 --> Input Class Initialized
INFO - 2021-01-22 01:52:41 --> Language Class Initialized
INFO - 2021-01-22 01:52:41 --> Language Class Initialized
INFO - 2021-01-22 01:52:41 --> Config Class Initialized
INFO - 2021-01-22 01:52:41 --> Loader Class Initialized
INFO - 2021-01-22 01:52:41 --> Helper loaded: url_helper
INFO - 2021-01-22 01:52:41 --> Helper loaded: file_helper
INFO - 2021-01-22 01:52:41 --> Helper loaded: form_helper
INFO - 2021-01-22 01:52:41 --> Helper loaded: my_helper
INFO - 2021-01-22 01:52:41 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:52:41 --> Controller Class Initialized
DEBUG - 2021-01-22 01:52:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-22 01:52:42 --> Final output sent to browser
DEBUG - 2021-01-22 01:52:42 --> Total execution time: 1.5854
INFO - 2021-01-22 01:53:49 --> Config Class Initialized
INFO - 2021-01-22 01:53:50 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:53:50 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:53:50 --> Utf8 Class Initialized
INFO - 2021-01-22 01:53:50 --> URI Class Initialized
INFO - 2021-01-22 01:53:50 --> Router Class Initialized
INFO - 2021-01-22 01:53:50 --> Output Class Initialized
INFO - 2021-01-22 01:53:50 --> Security Class Initialized
DEBUG - 2021-01-22 01:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:53:50 --> Input Class Initialized
INFO - 2021-01-22 01:53:50 --> Language Class Initialized
INFO - 2021-01-22 01:53:50 --> Language Class Initialized
INFO - 2021-01-22 01:53:50 --> Config Class Initialized
INFO - 2021-01-22 01:53:50 --> Loader Class Initialized
INFO - 2021-01-22 01:53:50 --> Helper loaded: url_helper
INFO - 2021-01-22 01:53:50 --> Helper loaded: file_helper
INFO - 2021-01-22 01:53:50 --> Helper loaded: form_helper
INFO - 2021-01-22 01:53:50 --> Helper loaded: my_helper
INFO - 2021-01-22 01:53:50 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:53:50 --> Controller Class Initialized
DEBUG - 2021-01-22 01:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-22 01:53:51 --> Final output sent to browser
DEBUG - 2021-01-22 01:53:51 --> Total execution time: 1.2305
INFO - 2021-01-22 01:54:03 --> Config Class Initialized
INFO - 2021-01-22 01:54:03 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:54:03 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:54:03 --> Utf8 Class Initialized
INFO - 2021-01-22 01:54:03 --> URI Class Initialized
INFO - 2021-01-22 01:54:03 --> Router Class Initialized
INFO - 2021-01-22 01:54:03 --> Output Class Initialized
INFO - 2021-01-22 01:54:03 --> Security Class Initialized
DEBUG - 2021-01-22 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:54:04 --> Input Class Initialized
INFO - 2021-01-22 01:54:04 --> Language Class Initialized
INFO - 2021-01-22 01:54:04 --> Language Class Initialized
INFO - 2021-01-22 01:54:04 --> Config Class Initialized
INFO - 2021-01-22 01:54:04 --> Loader Class Initialized
INFO - 2021-01-22 01:54:04 --> Helper loaded: url_helper
INFO - 2021-01-22 01:54:04 --> Helper loaded: file_helper
INFO - 2021-01-22 01:54:04 --> Helper loaded: form_helper
INFO - 2021-01-22 01:54:04 --> Helper loaded: my_helper
INFO - 2021-01-22 01:54:04 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:54:04 --> Controller Class Initialized
DEBUG - 2021-01-22 01:54:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-22 01:54:04 --> Final output sent to browser
DEBUG - 2021-01-22 01:54:04 --> Total execution time: 1.2137
INFO - 2021-01-22 01:54:32 --> Config Class Initialized
INFO - 2021-01-22 01:54:32 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:54:32 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:54:32 --> Utf8 Class Initialized
INFO - 2021-01-22 01:54:32 --> URI Class Initialized
INFO - 2021-01-22 01:54:32 --> Router Class Initialized
INFO - 2021-01-22 01:54:32 --> Output Class Initialized
INFO - 2021-01-22 01:54:32 --> Security Class Initialized
DEBUG - 2021-01-22 01:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:54:32 --> Input Class Initialized
INFO - 2021-01-22 01:54:33 --> Language Class Initialized
INFO - 2021-01-22 01:54:33 --> Language Class Initialized
INFO - 2021-01-22 01:54:33 --> Config Class Initialized
INFO - 2021-01-22 01:54:33 --> Loader Class Initialized
INFO - 2021-01-22 01:54:33 --> Helper loaded: url_helper
INFO - 2021-01-22 01:54:33 --> Helper loaded: file_helper
INFO - 2021-01-22 01:54:33 --> Helper loaded: form_helper
INFO - 2021-01-22 01:54:33 --> Helper loaded: my_helper
INFO - 2021-01-22 01:54:33 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:54:33 --> Controller Class Initialized
INFO - 2021-01-22 01:54:33 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:54:33 --> Config Class Initialized
INFO - 2021-01-22 01:54:33 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:54:33 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:54:34 --> Utf8 Class Initialized
INFO - 2021-01-22 01:54:34 --> URI Class Initialized
INFO - 2021-01-22 01:54:34 --> Router Class Initialized
INFO - 2021-01-22 01:54:34 --> Output Class Initialized
INFO - 2021-01-22 01:54:34 --> Security Class Initialized
DEBUG - 2021-01-22 01:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:54:34 --> Input Class Initialized
INFO - 2021-01-22 01:54:34 --> Language Class Initialized
INFO - 2021-01-22 01:54:34 --> Language Class Initialized
INFO - 2021-01-22 01:54:34 --> Config Class Initialized
INFO - 2021-01-22 01:54:34 --> Loader Class Initialized
INFO - 2021-01-22 01:54:34 --> Helper loaded: url_helper
INFO - 2021-01-22 01:54:34 --> Helper loaded: file_helper
INFO - 2021-01-22 01:54:34 --> Helper loaded: form_helper
INFO - 2021-01-22 01:54:34 --> Helper loaded: my_helper
INFO - 2021-01-22 01:54:34 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:54:34 --> Controller Class Initialized
DEBUG - 2021-01-22 01:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:54:34 --> Final output sent to browser
DEBUG - 2021-01-22 01:54:35 --> Total execution time: 1.1635
INFO - 2021-01-22 01:54:40 --> Config Class Initialized
INFO - 2021-01-22 01:54:40 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:54:40 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:54:40 --> Utf8 Class Initialized
INFO - 2021-01-22 01:54:40 --> URI Class Initialized
INFO - 2021-01-22 01:54:40 --> Router Class Initialized
INFO - 2021-01-22 01:54:40 --> Output Class Initialized
INFO - 2021-01-22 01:54:40 --> Security Class Initialized
DEBUG - 2021-01-22 01:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:54:40 --> Input Class Initialized
INFO - 2021-01-22 01:54:40 --> Language Class Initialized
INFO - 2021-01-22 01:54:40 --> Language Class Initialized
INFO - 2021-01-22 01:54:40 --> Config Class Initialized
INFO - 2021-01-22 01:54:40 --> Loader Class Initialized
INFO - 2021-01-22 01:54:40 --> Helper loaded: url_helper
INFO - 2021-01-22 01:54:41 --> Helper loaded: file_helper
INFO - 2021-01-22 01:54:41 --> Helper loaded: form_helper
INFO - 2021-01-22 01:54:41 --> Helper loaded: my_helper
INFO - 2021-01-22 01:54:41 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:54:41 --> Controller Class Initialized
INFO - 2021-01-22 01:54:41 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:54:41 --> Final output sent to browser
DEBUG - 2021-01-22 01:54:41 --> Total execution time: 1.5122
INFO - 2021-01-22 01:54:42 --> Config Class Initialized
INFO - 2021-01-22 01:54:42 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:54:42 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:54:42 --> Utf8 Class Initialized
INFO - 2021-01-22 01:54:42 --> URI Class Initialized
INFO - 2021-01-22 01:54:42 --> Router Class Initialized
INFO - 2021-01-22 01:54:42 --> Output Class Initialized
INFO - 2021-01-22 01:54:42 --> Security Class Initialized
DEBUG - 2021-01-22 01:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:54:42 --> Input Class Initialized
INFO - 2021-01-22 01:54:43 --> Language Class Initialized
INFO - 2021-01-22 01:54:43 --> Language Class Initialized
INFO - 2021-01-22 01:54:43 --> Config Class Initialized
INFO - 2021-01-22 01:54:43 --> Loader Class Initialized
INFO - 2021-01-22 01:54:43 --> Helper loaded: url_helper
INFO - 2021-01-22 01:54:43 --> Helper loaded: file_helper
INFO - 2021-01-22 01:54:43 --> Helper loaded: form_helper
INFO - 2021-01-22 01:54:43 --> Helper loaded: my_helper
INFO - 2021-01-22 01:54:43 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:54:43 --> Controller Class Initialized
DEBUG - 2021-01-22 01:54:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:54:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:54:44 --> Final output sent to browser
DEBUG - 2021-01-22 01:54:44 --> Total execution time: 1.8436
INFO - 2021-01-22 01:54:52 --> Config Class Initialized
INFO - 2021-01-22 01:54:52 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:54:52 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:54:52 --> Utf8 Class Initialized
INFO - 2021-01-22 01:54:52 --> URI Class Initialized
INFO - 2021-01-22 01:54:52 --> Router Class Initialized
INFO - 2021-01-22 01:54:52 --> Output Class Initialized
INFO - 2021-01-22 01:54:52 --> Security Class Initialized
DEBUG - 2021-01-22 01:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:54:52 --> Input Class Initialized
INFO - 2021-01-22 01:54:52 --> Language Class Initialized
INFO - 2021-01-22 01:54:52 --> Language Class Initialized
INFO - 2021-01-22 01:54:52 --> Config Class Initialized
INFO - 2021-01-22 01:54:52 --> Loader Class Initialized
INFO - 2021-01-22 01:54:53 --> Helper loaded: url_helper
INFO - 2021-01-22 01:54:53 --> Helper loaded: file_helper
INFO - 2021-01-22 01:54:53 --> Helper loaded: form_helper
INFO - 2021-01-22 01:54:53 --> Helper loaded: my_helper
INFO - 2021-01-22 01:54:53 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:54:53 --> Controller Class Initialized
DEBUG - 2021-01-22 01:54:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:54:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:54:53 --> Final output sent to browser
DEBUG - 2021-01-22 01:54:53 --> Total execution time: 0.9634
INFO - 2021-01-22 01:54:55 --> Config Class Initialized
INFO - 2021-01-22 01:54:55 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:54:55 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:54:55 --> Utf8 Class Initialized
INFO - 2021-01-22 01:54:55 --> URI Class Initialized
INFO - 2021-01-22 01:54:55 --> Router Class Initialized
INFO - 2021-01-22 01:54:55 --> Output Class Initialized
INFO - 2021-01-22 01:54:55 --> Security Class Initialized
DEBUG - 2021-01-22 01:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:54:56 --> Input Class Initialized
INFO - 2021-01-22 01:54:56 --> Language Class Initialized
INFO - 2021-01-22 01:54:56 --> Language Class Initialized
INFO - 2021-01-22 01:54:56 --> Config Class Initialized
INFO - 2021-01-22 01:54:56 --> Loader Class Initialized
INFO - 2021-01-22 01:54:56 --> Helper loaded: url_helper
INFO - 2021-01-22 01:54:56 --> Helper loaded: file_helper
INFO - 2021-01-22 01:54:56 --> Helper loaded: form_helper
INFO - 2021-01-22 01:54:56 --> Helper loaded: my_helper
INFO - 2021-01-22 01:54:56 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:54:56 --> Controller Class Initialized
DEBUG - 2021-01-22 01:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-22 01:54:56 --> Final output sent to browser
DEBUG - 2021-01-22 01:54:56 --> Total execution time: 1.2487
INFO - 2021-01-22 01:56:08 --> Config Class Initialized
INFO - 2021-01-22 01:56:08 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:56:08 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:56:08 --> Utf8 Class Initialized
INFO - 2021-01-22 01:56:08 --> URI Class Initialized
INFO - 2021-01-22 01:56:08 --> Router Class Initialized
INFO - 2021-01-22 01:56:08 --> Output Class Initialized
INFO - 2021-01-22 01:56:08 --> Security Class Initialized
DEBUG - 2021-01-22 01:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:56:08 --> Input Class Initialized
INFO - 2021-01-22 01:56:08 --> Language Class Initialized
INFO - 2021-01-22 01:56:08 --> Language Class Initialized
INFO - 2021-01-22 01:56:08 --> Config Class Initialized
INFO - 2021-01-22 01:56:08 --> Loader Class Initialized
INFO - 2021-01-22 01:56:08 --> Helper loaded: url_helper
INFO - 2021-01-22 01:56:08 --> Helper loaded: file_helper
INFO - 2021-01-22 01:56:08 --> Helper loaded: form_helper
INFO - 2021-01-22 01:56:08 --> Helper loaded: my_helper
INFO - 2021-01-22 01:56:09 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:56:09 --> Controller Class Initialized
DEBUG - 2021-01-22 01:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-22 01:56:09 --> Final output sent to browser
DEBUG - 2021-01-22 01:56:09 --> Total execution time: 1.3821
INFO - 2021-01-22 01:56:25 --> Config Class Initialized
INFO - 2021-01-22 01:56:26 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:56:26 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:56:26 --> Utf8 Class Initialized
INFO - 2021-01-22 01:56:26 --> URI Class Initialized
INFO - 2021-01-22 01:56:26 --> Router Class Initialized
INFO - 2021-01-22 01:56:26 --> Output Class Initialized
INFO - 2021-01-22 01:56:26 --> Security Class Initialized
DEBUG - 2021-01-22 01:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:56:26 --> Input Class Initialized
INFO - 2021-01-22 01:56:26 --> Language Class Initialized
INFO - 2021-01-22 01:56:26 --> Language Class Initialized
INFO - 2021-01-22 01:56:26 --> Config Class Initialized
INFO - 2021-01-22 01:56:26 --> Loader Class Initialized
INFO - 2021-01-22 01:56:26 --> Helper loaded: url_helper
INFO - 2021-01-22 01:56:26 --> Helper loaded: file_helper
INFO - 2021-01-22 01:56:26 --> Helper loaded: form_helper
INFO - 2021-01-22 01:56:26 --> Helper loaded: my_helper
INFO - 2021-01-22 01:56:26 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:56:26 --> Controller Class Initialized
DEBUG - 2021-01-22 01:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-22 01:56:27 --> Final output sent to browser
DEBUG - 2021-01-22 01:56:27 --> Total execution time: 1.3188
INFO - 2021-01-22 01:56:37 --> Config Class Initialized
INFO - 2021-01-22 01:56:37 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:56:37 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:56:37 --> Utf8 Class Initialized
INFO - 2021-01-22 01:56:37 --> URI Class Initialized
INFO - 2021-01-22 01:56:37 --> Router Class Initialized
INFO - 2021-01-22 01:56:37 --> Output Class Initialized
INFO - 2021-01-22 01:56:37 --> Security Class Initialized
DEBUG - 2021-01-22 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:56:37 --> Input Class Initialized
INFO - 2021-01-22 01:56:37 --> Language Class Initialized
INFO - 2021-01-22 01:56:37 --> Language Class Initialized
INFO - 2021-01-22 01:56:37 --> Config Class Initialized
INFO - 2021-01-22 01:56:37 --> Loader Class Initialized
INFO - 2021-01-22 01:56:38 --> Helper loaded: url_helper
INFO - 2021-01-22 01:56:38 --> Helper loaded: file_helper
INFO - 2021-01-22 01:56:38 --> Helper loaded: form_helper
INFO - 2021-01-22 01:56:38 --> Helper loaded: my_helper
INFO - 2021-01-22 01:56:38 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:56:38 --> Controller Class Initialized
INFO - 2021-01-22 01:56:38 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:56:38 --> Config Class Initialized
INFO - 2021-01-22 01:56:38 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:56:38 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:56:38 --> Utf8 Class Initialized
INFO - 2021-01-22 01:56:38 --> URI Class Initialized
INFO - 2021-01-22 01:56:38 --> Router Class Initialized
INFO - 2021-01-22 01:56:38 --> Output Class Initialized
INFO - 2021-01-22 01:56:38 --> Security Class Initialized
DEBUG - 2021-01-22 01:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:56:38 --> Input Class Initialized
INFO - 2021-01-22 01:56:38 --> Language Class Initialized
INFO - 2021-01-22 01:56:39 --> Language Class Initialized
INFO - 2021-01-22 01:56:39 --> Config Class Initialized
INFO - 2021-01-22 01:56:39 --> Loader Class Initialized
INFO - 2021-01-22 01:56:39 --> Helper loaded: url_helper
INFO - 2021-01-22 01:56:39 --> Helper loaded: file_helper
INFO - 2021-01-22 01:56:39 --> Helper loaded: form_helper
INFO - 2021-01-22 01:56:39 --> Helper loaded: my_helper
INFO - 2021-01-22 01:56:39 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:56:39 --> Controller Class Initialized
DEBUG - 2021-01-22 01:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:56:39 --> Final output sent to browser
DEBUG - 2021-01-22 01:56:39 --> Total execution time: 1.2527
INFO - 2021-01-22 01:56:45 --> Config Class Initialized
INFO - 2021-01-22 01:56:45 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:56:45 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:56:45 --> Utf8 Class Initialized
INFO - 2021-01-22 01:56:45 --> URI Class Initialized
INFO - 2021-01-22 01:56:46 --> Router Class Initialized
INFO - 2021-01-22 01:56:46 --> Output Class Initialized
INFO - 2021-01-22 01:56:46 --> Security Class Initialized
DEBUG - 2021-01-22 01:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:56:46 --> Input Class Initialized
INFO - 2021-01-22 01:56:46 --> Language Class Initialized
INFO - 2021-01-22 01:56:46 --> Language Class Initialized
INFO - 2021-01-22 01:56:46 --> Config Class Initialized
INFO - 2021-01-22 01:56:46 --> Loader Class Initialized
INFO - 2021-01-22 01:56:46 --> Helper loaded: url_helper
INFO - 2021-01-22 01:56:46 --> Helper loaded: file_helper
INFO - 2021-01-22 01:56:46 --> Helper loaded: form_helper
INFO - 2021-01-22 01:56:46 --> Helper loaded: my_helper
INFO - 2021-01-22 01:56:46 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:56:46 --> Controller Class Initialized
INFO - 2021-01-22 01:56:46 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:56:46 --> Final output sent to browser
DEBUG - 2021-01-22 01:56:46 --> Total execution time: 1.0645
INFO - 2021-01-22 01:56:47 --> Config Class Initialized
INFO - 2021-01-22 01:56:47 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:56:47 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:56:47 --> Utf8 Class Initialized
INFO - 2021-01-22 01:56:47 --> URI Class Initialized
INFO - 2021-01-22 01:56:47 --> Router Class Initialized
INFO - 2021-01-22 01:56:47 --> Output Class Initialized
INFO - 2021-01-22 01:56:47 --> Security Class Initialized
DEBUG - 2021-01-22 01:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:56:47 --> Input Class Initialized
INFO - 2021-01-22 01:56:47 --> Language Class Initialized
INFO - 2021-01-22 01:56:48 --> Language Class Initialized
INFO - 2021-01-22 01:56:48 --> Config Class Initialized
INFO - 2021-01-22 01:56:48 --> Loader Class Initialized
INFO - 2021-01-22 01:56:48 --> Helper loaded: url_helper
INFO - 2021-01-22 01:56:48 --> Helper loaded: file_helper
INFO - 2021-01-22 01:56:48 --> Helper loaded: form_helper
INFO - 2021-01-22 01:56:48 --> Helper loaded: my_helper
INFO - 2021-01-22 01:56:48 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:56:48 --> Controller Class Initialized
DEBUG - 2021-01-22 01:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:56:48 --> Final output sent to browser
DEBUG - 2021-01-22 01:56:48 --> Total execution time: 1.2533
INFO - 2021-01-22 01:56:50 --> Config Class Initialized
INFO - 2021-01-22 01:56:50 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:56:50 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:56:50 --> Utf8 Class Initialized
INFO - 2021-01-22 01:56:50 --> URI Class Initialized
INFO - 2021-01-22 01:56:50 --> Router Class Initialized
INFO - 2021-01-22 01:56:50 --> Output Class Initialized
INFO - 2021-01-22 01:56:51 --> Security Class Initialized
DEBUG - 2021-01-22 01:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:56:51 --> Input Class Initialized
INFO - 2021-01-22 01:56:51 --> Language Class Initialized
INFO - 2021-01-22 01:56:51 --> Language Class Initialized
INFO - 2021-01-22 01:56:51 --> Config Class Initialized
INFO - 2021-01-22 01:56:51 --> Loader Class Initialized
INFO - 2021-01-22 01:56:51 --> Helper loaded: url_helper
INFO - 2021-01-22 01:56:51 --> Helper loaded: file_helper
INFO - 2021-01-22 01:56:51 --> Helper loaded: form_helper
INFO - 2021-01-22 01:56:51 --> Helper loaded: my_helper
INFO - 2021-01-22 01:56:51 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:56:51 --> Controller Class Initialized
DEBUG - 2021-01-22 01:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:56:51 --> Final output sent to browser
DEBUG - 2021-01-22 01:56:51 --> Total execution time: 1.2209
INFO - 2021-01-22 01:56:53 --> Config Class Initialized
INFO - 2021-01-22 01:56:53 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:56:53 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:56:53 --> Utf8 Class Initialized
INFO - 2021-01-22 01:56:53 --> URI Class Initialized
INFO - 2021-01-22 01:56:53 --> Router Class Initialized
INFO - 2021-01-22 01:56:53 --> Output Class Initialized
INFO - 2021-01-22 01:56:53 --> Security Class Initialized
DEBUG - 2021-01-22 01:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:56:53 --> Input Class Initialized
INFO - 2021-01-22 01:56:53 --> Language Class Initialized
INFO - 2021-01-22 01:56:53 --> Language Class Initialized
INFO - 2021-01-22 01:56:53 --> Config Class Initialized
INFO - 2021-01-22 01:56:53 --> Loader Class Initialized
INFO - 2021-01-22 01:56:53 --> Helper loaded: url_helper
INFO - 2021-01-22 01:56:53 --> Helper loaded: file_helper
INFO - 2021-01-22 01:56:53 --> Helper loaded: form_helper
INFO - 2021-01-22 01:56:53 --> Helper loaded: my_helper
INFO - 2021-01-22 01:56:54 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:56:54 --> Controller Class Initialized
DEBUG - 2021-01-22 01:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-22 01:56:54 --> Final output sent to browser
DEBUG - 2021-01-22 01:56:54 --> Total execution time: 1.2183
INFO - 2021-01-22 01:57:07 --> Config Class Initialized
INFO - 2021-01-22 01:57:07 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:57:07 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:57:07 --> Utf8 Class Initialized
INFO - 2021-01-22 01:57:07 --> URI Class Initialized
INFO - 2021-01-22 01:57:07 --> Router Class Initialized
INFO - 2021-01-22 01:57:07 --> Output Class Initialized
INFO - 2021-01-22 01:57:07 --> Security Class Initialized
DEBUG - 2021-01-22 01:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:57:07 --> Input Class Initialized
INFO - 2021-01-22 01:57:07 --> Language Class Initialized
INFO - 2021-01-22 01:57:07 --> Language Class Initialized
INFO - 2021-01-22 01:57:07 --> Config Class Initialized
INFO - 2021-01-22 01:57:08 --> Loader Class Initialized
INFO - 2021-01-22 01:57:08 --> Helper loaded: url_helper
INFO - 2021-01-22 01:57:08 --> Helper loaded: file_helper
INFO - 2021-01-22 01:57:08 --> Helper loaded: form_helper
INFO - 2021-01-22 01:57:08 --> Helper loaded: my_helper
INFO - 2021-01-22 01:57:08 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:57:08 --> Controller Class Initialized
INFO - 2021-01-22 01:57:08 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:57:08 --> Config Class Initialized
INFO - 2021-01-22 01:57:08 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:57:08 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:57:08 --> Utf8 Class Initialized
INFO - 2021-01-22 01:57:08 --> URI Class Initialized
INFO - 2021-01-22 01:57:08 --> Router Class Initialized
INFO - 2021-01-22 01:57:08 --> Output Class Initialized
INFO - 2021-01-22 01:57:08 --> Security Class Initialized
DEBUG - 2021-01-22 01:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:57:09 --> Input Class Initialized
INFO - 2021-01-22 01:57:09 --> Language Class Initialized
INFO - 2021-01-22 01:57:09 --> Language Class Initialized
INFO - 2021-01-22 01:57:09 --> Config Class Initialized
INFO - 2021-01-22 01:57:09 --> Loader Class Initialized
INFO - 2021-01-22 01:57:09 --> Helper loaded: url_helper
INFO - 2021-01-22 01:57:09 --> Helper loaded: file_helper
INFO - 2021-01-22 01:57:09 --> Helper loaded: form_helper
INFO - 2021-01-22 01:57:09 --> Helper loaded: my_helper
INFO - 2021-01-22 01:57:09 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:57:09 --> Controller Class Initialized
DEBUG - 2021-01-22 01:57:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 01:57:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:57:09 --> Final output sent to browser
DEBUG - 2021-01-22 01:57:09 --> Total execution time: 1.3123
INFO - 2021-01-22 01:57:13 --> Config Class Initialized
INFO - 2021-01-22 01:57:13 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:57:13 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:57:13 --> Utf8 Class Initialized
INFO - 2021-01-22 01:57:14 --> URI Class Initialized
INFO - 2021-01-22 01:57:14 --> Router Class Initialized
INFO - 2021-01-22 01:57:14 --> Output Class Initialized
INFO - 2021-01-22 01:57:14 --> Security Class Initialized
DEBUG - 2021-01-22 01:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:57:14 --> Input Class Initialized
INFO - 2021-01-22 01:57:14 --> Language Class Initialized
INFO - 2021-01-22 01:57:14 --> Language Class Initialized
INFO - 2021-01-22 01:57:14 --> Config Class Initialized
INFO - 2021-01-22 01:57:14 --> Loader Class Initialized
INFO - 2021-01-22 01:57:14 --> Helper loaded: url_helper
INFO - 2021-01-22 01:57:14 --> Helper loaded: file_helper
INFO - 2021-01-22 01:57:14 --> Helper loaded: form_helper
INFO - 2021-01-22 01:57:14 --> Helper loaded: my_helper
INFO - 2021-01-22 01:57:14 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:57:15 --> Controller Class Initialized
INFO - 2021-01-22 01:57:15 --> Helper loaded: cookie_helper
INFO - 2021-01-22 01:57:15 --> Final output sent to browser
DEBUG - 2021-01-22 01:57:15 --> Total execution time: 1.4221
INFO - 2021-01-22 01:57:15 --> Config Class Initialized
INFO - 2021-01-22 01:57:15 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:57:16 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:57:16 --> Utf8 Class Initialized
INFO - 2021-01-22 01:57:16 --> URI Class Initialized
INFO - 2021-01-22 01:57:16 --> Router Class Initialized
INFO - 2021-01-22 01:57:16 --> Output Class Initialized
INFO - 2021-01-22 01:57:16 --> Security Class Initialized
DEBUG - 2021-01-22 01:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:57:16 --> Input Class Initialized
INFO - 2021-01-22 01:57:16 --> Language Class Initialized
INFO - 2021-01-22 01:57:16 --> Language Class Initialized
INFO - 2021-01-22 01:57:16 --> Config Class Initialized
INFO - 2021-01-22 01:57:16 --> Loader Class Initialized
INFO - 2021-01-22 01:57:16 --> Helper loaded: url_helper
INFO - 2021-01-22 01:57:16 --> Helper loaded: file_helper
INFO - 2021-01-22 01:57:16 --> Helper loaded: form_helper
INFO - 2021-01-22 01:57:17 --> Helper loaded: my_helper
INFO - 2021-01-22 01:57:17 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:57:17 --> Controller Class Initialized
DEBUG - 2021-01-22 01:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 01:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:57:17 --> Final output sent to browser
DEBUG - 2021-01-22 01:57:17 --> Total execution time: 1.6761
INFO - 2021-01-22 01:57:18 --> Config Class Initialized
INFO - 2021-01-22 01:57:18 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:57:19 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:57:19 --> Utf8 Class Initialized
INFO - 2021-01-22 01:57:19 --> URI Class Initialized
INFO - 2021-01-22 01:57:19 --> Router Class Initialized
INFO - 2021-01-22 01:57:19 --> Output Class Initialized
INFO - 2021-01-22 01:57:19 --> Security Class Initialized
DEBUG - 2021-01-22 01:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:57:19 --> Input Class Initialized
INFO - 2021-01-22 01:57:19 --> Language Class Initialized
INFO - 2021-01-22 01:57:19 --> Language Class Initialized
INFO - 2021-01-22 01:57:19 --> Config Class Initialized
INFO - 2021-01-22 01:57:19 --> Loader Class Initialized
INFO - 2021-01-22 01:57:19 --> Helper loaded: url_helper
INFO - 2021-01-22 01:57:19 --> Helper loaded: file_helper
INFO - 2021-01-22 01:57:19 --> Helper loaded: form_helper
INFO - 2021-01-22 01:57:19 --> Helper loaded: my_helper
INFO - 2021-01-22 01:57:19 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:57:19 --> Controller Class Initialized
DEBUG - 2021-01-22 01:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 01:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 01:57:19 --> Final output sent to browser
DEBUG - 2021-01-22 01:57:19 --> Total execution time: 0.9858
INFO - 2021-01-22 01:57:21 --> Config Class Initialized
INFO - 2021-01-22 01:57:21 --> Hooks Class Initialized
DEBUG - 2021-01-22 01:57:21 --> UTF-8 Support Enabled
INFO - 2021-01-22 01:57:21 --> Utf8 Class Initialized
INFO - 2021-01-22 01:57:21 --> URI Class Initialized
INFO - 2021-01-22 01:57:21 --> Router Class Initialized
INFO - 2021-01-22 01:57:21 --> Output Class Initialized
INFO - 2021-01-22 01:57:21 --> Security Class Initialized
DEBUG - 2021-01-22 01:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 01:57:21 --> Input Class Initialized
INFO - 2021-01-22 01:57:21 --> Language Class Initialized
INFO - 2021-01-22 01:57:21 --> Language Class Initialized
INFO - 2021-01-22 01:57:21 --> Config Class Initialized
INFO - 2021-01-22 01:57:21 --> Loader Class Initialized
INFO - 2021-01-22 01:57:21 --> Helper loaded: url_helper
INFO - 2021-01-22 01:57:21 --> Helper loaded: file_helper
INFO - 2021-01-22 01:57:21 --> Helper loaded: form_helper
INFO - 2021-01-22 01:57:21 --> Helper loaded: my_helper
INFO - 2021-01-22 01:57:22 --> Database Driver Class Initialized
DEBUG - 2021-01-22 01:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 01:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 01:57:22 --> Controller Class Initialized
DEBUG - 2021-01-22 01:57:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-22 01:57:22 --> Final output sent to browser
DEBUG - 2021-01-22 01:57:22 --> Total execution time: 1.0083
INFO - 2021-01-22 02:48:33 --> Config Class Initialized
INFO - 2021-01-22 02:48:33 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:48:33 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:48:33 --> Utf8 Class Initialized
INFO - 2021-01-22 02:48:33 --> URI Class Initialized
DEBUG - 2021-01-22 02:48:33 --> No URI present. Default controller set.
INFO - 2021-01-22 02:48:33 --> Router Class Initialized
INFO - 2021-01-22 02:48:33 --> Output Class Initialized
INFO - 2021-01-22 02:48:33 --> Security Class Initialized
DEBUG - 2021-01-22 02:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:48:33 --> Input Class Initialized
INFO - 2021-01-22 02:48:33 --> Language Class Initialized
INFO - 2021-01-22 02:48:33 --> Language Class Initialized
INFO - 2021-01-22 02:48:33 --> Config Class Initialized
INFO - 2021-01-22 02:48:33 --> Loader Class Initialized
INFO - 2021-01-22 02:48:33 --> Helper loaded: url_helper
INFO - 2021-01-22 02:48:33 --> Helper loaded: file_helper
INFO - 2021-01-22 02:48:33 --> Helper loaded: form_helper
INFO - 2021-01-22 02:48:34 --> Helper loaded: my_helper
INFO - 2021-01-22 02:48:34 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:48:34 --> Controller Class Initialized
INFO - 2021-01-22 02:48:34 --> Config Class Initialized
INFO - 2021-01-22 02:48:34 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:48:34 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:48:34 --> Utf8 Class Initialized
INFO - 2021-01-22 02:48:34 --> URI Class Initialized
INFO - 2021-01-22 02:48:34 --> Router Class Initialized
INFO - 2021-01-22 02:48:34 --> Output Class Initialized
INFO - 2021-01-22 02:48:34 --> Security Class Initialized
DEBUG - 2021-01-22 02:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:48:34 --> Input Class Initialized
INFO - 2021-01-22 02:48:34 --> Language Class Initialized
INFO - 2021-01-22 02:48:34 --> Language Class Initialized
INFO - 2021-01-22 02:48:34 --> Config Class Initialized
INFO - 2021-01-22 02:48:34 --> Loader Class Initialized
INFO - 2021-01-22 02:48:34 --> Helper loaded: url_helper
INFO - 2021-01-22 02:48:34 --> Helper loaded: file_helper
INFO - 2021-01-22 02:48:34 --> Helper loaded: form_helper
INFO - 2021-01-22 02:48:34 --> Helper loaded: my_helper
INFO - 2021-01-22 02:48:34 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:48:34 --> Controller Class Initialized
DEBUG - 2021-01-22 02:48:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 02:48:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:48:34 --> Final output sent to browser
DEBUG - 2021-01-22 02:48:34 --> Total execution time: 0.3850
INFO - 2021-01-22 02:48:42 --> Config Class Initialized
INFO - 2021-01-22 02:48:42 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:48:42 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:48:42 --> Utf8 Class Initialized
INFO - 2021-01-22 02:48:42 --> URI Class Initialized
INFO - 2021-01-22 02:48:42 --> Router Class Initialized
INFO - 2021-01-22 02:48:42 --> Output Class Initialized
INFO - 2021-01-22 02:48:42 --> Security Class Initialized
DEBUG - 2021-01-22 02:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:48:43 --> Input Class Initialized
INFO - 2021-01-22 02:48:43 --> Language Class Initialized
INFO - 2021-01-22 02:48:43 --> Language Class Initialized
INFO - 2021-01-22 02:48:43 --> Config Class Initialized
INFO - 2021-01-22 02:48:43 --> Loader Class Initialized
INFO - 2021-01-22 02:48:43 --> Helper loaded: url_helper
INFO - 2021-01-22 02:48:43 --> Helper loaded: file_helper
INFO - 2021-01-22 02:48:43 --> Helper loaded: form_helper
INFO - 2021-01-22 02:48:43 --> Helper loaded: my_helper
INFO - 2021-01-22 02:48:43 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:48:43 --> Controller Class Initialized
INFO - 2021-01-22 02:48:43 --> Helper loaded: cookie_helper
INFO - 2021-01-22 02:48:43 --> Final output sent to browser
DEBUG - 2021-01-22 02:48:43 --> Total execution time: 0.6984
INFO - 2021-01-22 02:48:44 --> Config Class Initialized
INFO - 2021-01-22 02:48:44 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:48:44 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:48:44 --> Utf8 Class Initialized
INFO - 2021-01-22 02:48:44 --> URI Class Initialized
INFO - 2021-01-22 02:48:44 --> Router Class Initialized
INFO - 2021-01-22 02:48:44 --> Output Class Initialized
INFO - 2021-01-22 02:48:44 --> Security Class Initialized
DEBUG - 2021-01-22 02:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:48:44 --> Input Class Initialized
INFO - 2021-01-22 02:48:44 --> Language Class Initialized
INFO - 2021-01-22 02:48:44 --> Language Class Initialized
INFO - 2021-01-22 02:48:44 --> Config Class Initialized
INFO - 2021-01-22 02:48:44 --> Loader Class Initialized
INFO - 2021-01-22 02:48:44 --> Helper loaded: url_helper
INFO - 2021-01-22 02:48:44 --> Helper loaded: file_helper
INFO - 2021-01-22 02:48:44 --> Helper loaded: form_helper
INFO - 2021-01-22 02:48:44 --> Helper loaded: my_helper
INFO - 2021-01-22 02:48:44 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:48:44 --> Controller Class Initialized
DEBUG - 2021-01-22 02:48:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 02:48:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:48:45 --> Final output sent to browser
DEBUG - 2021-01-22 02:48:45 --> Total execution time: 0.5090
INFO - 2021-01-22 02:48:47 --> Config Class Initialized
INFO - 2021-01-22 02:48:47 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:48:47 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:48:47 --> Utf8 Class Initialized
INFO - 2021-01-22 02:48:47 --> URI Class Initialized
INFO - 2021-01-22 02:48:47 --> Router Class Initialized
INFO - 2021-01-22 02:48:47 --> Output Class Initialized
INFO - 2021-01-22 02:48:47 --> Security Class Initialized
DEBUG - 2021-01-22 02:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:48:47 --> Input Class Initialized
INFO - 2021-01-22 02:48:47 --> Language Class Initialized
INFO - 2021-01-22 02:48:47 --> Language Class Initialized
INFO - 2021-01-22 02:48:47 --> Config Class Initialized
INFO - 2021-01-22 02:48:47 --> Loader Class Initialized
INFO - 2021-01-22 02:48:47 --> Helper loaded: url_helper
INFO - 2021-01-22 02:48:47 --> Helper loaded: file_helper
INFO - 2021-01-22 02:48:47 --> Helper loaded: form_helper
INFO - 2021-01-22 02:48:47 --> Helper loaded: my_helper
INFO - 2021-01-22 02:48:47 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:48:47 --> Controller Class Initialized
DEBUG - 2021-01-22 02:48:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 02:48:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:48:47 --> Final output sent to browser
DEBUG - 2021-01-22 02:48:47 --> Total execution time: 0.3286
INFO - 2021-01-22 02:48:51 --> Config Class Initialized
INFO - 2021-01-22 02:48:52 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:48:52 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:48:52 --> Utf8 Class Initialized
INFO - 2021-01-22 02:48:52 --> URI Class Initialized
DEBUG - 2021-01-22 02:48:52 --> No URI present. Default controller set.
INFO - 2021-01-22 02:48:52 --> Router Class Initialized
INFO - 2021-01-22 02:48:52 --> Output Class Initialized
INFO - 2021-01-22 02:48:52 --> Security Class Initialized
DEBUG - 2021-01-22 02:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:48:52 --> Input Class Initialized
INFO - 2021-01-22 02:48:52 --> Language Class Initialized
INFO - 2021-01-22 02:48:52 --> Language Class Initialized
INFO - 2021-01-22 02:48:52 --> Config Class Initialized
INFO - 2021-01-22 02:48:52 --> Loader Class Initialized
INFO - 2021-01-22 02:48:52 --> Helper loaded: url_helper
INFO - 2021-01-22 02:48:52 --> Helper loaded: file_helper
INFO - 2021-01-22 02:48:52 --> Helper loaded: form_helper
INFO - 2021-01-22 02:48:52 --> Helper loaded: my_helper
INFO - 2021-01-22 02:48:52 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:48:52 --> Controller Class Initialized
DEBUG - 2021-01-22 02:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 02:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:48:52 --> Final output sent to browser
DEBUG - 2021-01-22 02:48:52 --> Total execution time: 0.2696
INFO - 2021-01-22 02:48:56 --> Config Class Initialized
INFO - 2021-01-22 02:48:56 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:48:56 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:48:56 --> Utf8 Class Initialized
INFO - 2021-01-22 02:48:56 --> URI Class Initialized
INFO - 2021-01-22 02:48:56 --> Router Class Initialized
INFO - 2021-01-22 02:48:56 --> Output Class Initialized
INFO - 2021-01-22 02:48:56 --> Security Class Initialized
DEBUG - 2021-01-22 02:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:48:56 --> Input Class Initialized
INFO - 2021-01-22 02:48:56 --> Language Class Initialized
INFO - 2021-01-22 02:48:56 --> Language Class Initialized
INFO - 2021-01-22 02:48:56 --> Config Class Initialized
INFO - 2021-01-22 02:48:56 --> Loader Class Initialized
INFO - 2021-01-22 02:48:56 --> Helper loaded: url_helper
INFO - 2021-01-22 02:48:56 --> Helper loaded: file_helper
INFO - 2021-01-22 02:48:56 --> Helper loaded: form_helper
INFO - 2021-01-22 02:48:56 --> Helper loaded: my_helper
INFO - 2021-01-22 02:48:56 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:48:56 --> Controller Class Initialized
DEBUG - 2021-01-22 02:48:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 02:48:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:48:56 --> Final output sent to browser
DEBUG - 2021-01-22 02:48:56 --> Total execution time: 0.2598
INFO - 2021-01-22 02:49:00 --> Config Class Initialized
INFO - 2021-01-22 02:49:00 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:00 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:00 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:00 --> URI Class Initialized
INFO - 2021-01-22 02:49:00 --> Router Class Initialized
INFO - 2021-01-22 02:49:00 --> Output Class Initialized
INFO - 2021-01-22 02:49:00 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:00 --> Input Class Initialized
INFO - 2021-01-22 02:49:00 --> Language Class Initialized
INFO - 2021-01-22 02:49:00 --> Language Class Initialized
INFO - 2021-01-22 02:49:00 --> Config Class Initialized
INFO - 2021-01-22 02:49:00 --> Loader Class Initialized
INFO - 2021-01-22 02:49:00 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:00 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:00 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:00 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:00 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:00 --> Controller Class Initialized
DEBUG - 2021-01-22 02:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-22 02:49:00 --> Final output sent to browser
DEBUG - 2021-01-22 02:49:00 --> Total execution time: 0.4367
INFO - 2021-01-22 02:49:12 --> Config Class Initialized
INFO - 2021-01-22 02:49:12 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:12 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:12 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:12 --> URI Class Initialized
INFO - 2021-01-22 02:49:12 --> Router Class Initialized
INFO - 2021-01-22 02:49:12 --> Output Class Initialized
INFO - 2021-01-22 02:49:12 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:12 --> Input Class Initialized
INFO - 2021-01-22 02:49:12 --> Language Class Initialized
INFO - 2021-01-22 02:49:12 --> Language Class Initialized
INFO - 2021-01-22 02:49:12 --> Config Class Initialized
INFO - 2021-01-22 02:49:12 --> Loader Class Initialized
INFO - 2021-01-22 02:49:12 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:12 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:12 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:12 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:12 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:12 --> Controller Class Initialized
DEBUG - 2021-01-22 02:49:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-22 02:49:13 --> Final output sent to browser
DEBUG - 2021-01-22 02:49:13 --> Total execution time: 0.3259
INFO - 2021-01-22 02:49:23 --> Config Class Initialized
INFO - 2021-01-22 02:49:23 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:23 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:23 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:23 --> URI Class Initialized
INFO - 2021-01-22 02:49:23 --> Router Class Initialized
INFO - 2021-01-22 02:49:23 --> Output Class Initialized
INFO - 2021-01-22 02:49:23 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:23 --> Input Class Initialized
INFO - 2021-01-22 02:49:23 --> Language Class Initialized
INFO - 2021-01-22 02:49:23 --> Language Class Initialized
INFO - 2021-01-22 02:49:23 --> Config Class Initialized
INFO - 2021-01-22 02:49:23 --> Loader Class Initialized
INFO - 2021-01-22 02:49:23 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:23 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:23 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:23 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:23 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:23 --> Controller Class Initialized
DEBUG - 2021-01-22 02:49:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-22 02:49:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:49:23 --> Final output sent to browser
DEBUG - 2021-01-22 02:49:23 --> Total execution time: 0.2798
INFO - 2021-01-22 02:49:36 --> Config Class Initialized
INFO - 2021-01-22 02:49:36 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:36 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:36 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:37 --> URI Class Initialized
INFO - 2021-01-22 02:49:37 --> Router Class Initialized
INFO - 2021-01-22 02:49:37 --> Output Class Initialized
INFO - 2021-01-22 02:49:37 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:37 --> Input Class Initialized
INFO - 2021-01-22 02:49:37 --> Language Class Initialized
INFO - 2021-01-22 02:49:37 --> Language Class Initialized
INFO - 2021-01-22 02:49:37 --> Config Class Initialized
INFO - 2021-01-22 02:49:37 --> Loader Class Initialized
INFO - 2021-01-22 02:49:37 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:37 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:37 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:37 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:37 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:37 --> Controller Class Initialized
DEBUG - 2021-01-22 02:49:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-22 02:49:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:49:37 --> Final output sent to browser
DEBUG - 2021-01-22 02:49:37 --> Total execution time: 0.9098
INFO - 2021-01-22 02:49:37 --> Config Class Initialized
INFO - 2021-01-22 02:49:37 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:37 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:38 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:38 --> URI Class Initialized
INFO - 2021-01-22 02:49:38 --> Router Class Initialized
INFO - 2021-01-22 02:49:38 --> Output Class Initialized
INFO - 2021-01-22 02:49:38 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:38 --> Input Class Initialized
INFO - 2021-01-22 02:49:38 --> Language Class Initialized
INFO - 2021-01-22 02:49:38 --> Language Class Initialized
INFO - 2021-01-22 02:49:38 --> Config Class Initialized
INFO - 2021-01-22 02:49:38 --> Loader Class Initialized
INFO - 2021-01-22 02:49:38 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:38 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:38 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:38 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:38 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:38 --> Controller Class Initialized
INFO - 2021-01-22 02:49:42 --> Config Class Initialized
INFO - 2021-01-22 02:49:42 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:42 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:42 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:42 --> URI Class Initialized
INFO - 2021-01-22 02:49:42 --> Router Class Initialized
INFO - 2021-01-22 02:49:42 --> Output Class Initialized
INFO - 2021-01-22 02:49:42 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:42 --> Input Class Initialized
INFO - 2021-01-22 02:49:42 --> Language Class Initialized
INFO - 2021-01-22 02:49:42 --> Language Class Initialized
INFO - 2021-01-22 02:49:42 --> Config Class Initialized
INFO - 2021-01-22 02:49:42 --> Loader Class Initialized
INFO - 2021-01-22 02:49:42 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:42 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:42 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:42 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:42 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:43 --> Controller Class Initialized
INFO - 2021-01-22 02:49:43 --> Final output sent to browser
DEBUG - 2021-01-22 02:49:43 --> Total execution time: 0.6342
INFO - 2021-01-22 02:49:44 --> Config Class Initialized
INFO - 2021-01-22 02:49:44 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:44 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:44 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:44 --> URI Class Initialized
INFO - 2021-01-22 02:49:44 --> Router Class Initialized
INFO - 2021-01-22 02:49:44 --> Output Class Initialized
INFO - 2021-01-22 02:49:44 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:44 --> Input Class Initialized
INFO - 2021-01-22 02:49:44 --> Language Class Initialized
INFO - 2021-01-22 02:49:44 --> Language Class Initialized
INFO - 2021-01-22 02:49:44 --> Config Class Initialized
INFO - 2021-01-22 02:49:44 --> Loader Class Initialized
INFO - 2021-01-22 02:49:44 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:44 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:44 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:44 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:44 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:45 --> Controller Class Initialized
INFO - 2021-01-22 02:49:45 --> Final output sent to browser
DEBUG - 2021-01-22 02:49:45 --> Total execution time: 0.7211
INFO - 2021-01-22 02:49:56 --> Config Class Initialized
INFO - 2021-01-22 02:49:56 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:56 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:56 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:56 --> URI Class Initialized
INFO - 2021-01-22 02:49:56 --> Router Class Initialized
INFO - 2021-01-22 02:49:56 --> Output Class Initialized
INFO - 2021-01-22 02:49:56 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:56 --> Input Class Initialized
INFO - 2021-01-22 02:49:56 --> Language Class Initialized
INFO - 2021-01-22 02:49:56 --> Language Class Initialized
INFO - 2021-01-22 02:49:56 --> Config Class Initialized
INFO - 2021-01-22 02:49:56 --> Loader Class Initialized
INFO - 2021-01-22 02:49:56 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:56 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:56 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:56 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:56 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:56 --> Controller Class Initialized
INFO - 2021-01-22 02:49:56 --> Final output sent to browser
DEBUG - 2021-01-22 02:49:56 --> Total execution time: 0.6959
INFO - 2021-01-22 02:49:57 --> Config Class Initialized
INFO - 2021-01-22 02:49:57 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:49:57 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:49:57 --> Utf8 Class Initialized
INFO - 2021-01-22 02:49:57 --> URI Class Initialized
INFO - 2021-01-22 02:49:57 --> Router Class Initialized
INFO - 2021-01-22 02:49:57 --> Output Class Initialized
INFO - 2021-01-22 02:49:57 --> Security Class Initialized
DEBUG - 2021-01-22 02:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:49:57 --> Input Class Initialized
INFO - 2021-01-22 02:49:58 --> Language Class Initialized
INFO - 2021-01-22 02:49:58 --> Language Class Initialized
INFO - 2021-01-22 02:49:58 --> Config Class Initialized
INFO - 2021-01-22 02:49:58 --> Loader Class Initialized
INFO - 2021-01-22 02:49:58 --> Helper loaded: url_helper
INFO - 2021-01-22 02:49:58 --> Helper loaded: file_helper
INFO - 2021-01-22 02:49:58 --> Helper loaded: form_helper
INFO - 2021-01-22 02:49:58 --> Helper loaded: my_helper
INFO - 2021-01-22 02:49:58 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:49:58 --> Controller Class Initialized
INFO - 2021-01-22 02:51:05 --> Config Class Initialized
INFO - 2021-01-22 02:51:05 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:51:05 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:51:05 --> Utf8 Class Initialized
INFO - 2021-01-22 02:51:05 --> URI Class Initialized
INFO - 2021-01-22 02:51:05 --> Router Class Initialized
INFO - 2021-01-22 02:51:05 --> Output Class Initialized
INFO - 2021-01-22 02:51:05 --> Security Class Initialized
DEBUG - 2021-01-22 02:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:51:05 --> Input Class Initialized
INFO - 2021-01-22 02:51:05 --> Language Class Initialized
INFO - 2021-01-22 02:51:05 --> Language Class Initialized
INFO - 2021-01-22 02:51:05 --> Config Class Initialized
INFO - 2021-01-22 02:51:05 --> Loader Class Initialized
INFO - 2021-01-22 02:51:05 --> Helper loaded: url_helper
INFO - 2021-01-22 02:51:05 --> Helper loaded: file_helper
INFO - 2021-01-22 02:51:05 --> Helper loaded: form_helper
INFO - 2021-01-22 02:51:05 --> Helper loaded: my_helper
INFO - 2021-01-22 02:51:05 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:51:05 --> Controller Class Initialized
INFO - 2021-01-22 02:51:05 --> Final output sent to browser
DEBUG - 2021-01-22 02:51:05 --> Total execution time: 0.8157
INFO - 2021-01-22 02:51:46 --> Config Class Initialized
INFO - 2021-01-22 02:51:46 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:51:46 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:51:46 --> Utf8 Class Initialized
INFO - 2021-01-22 02:51:46 --> URI Class Initialized
INFO - 2021-01-22 02:51:46 --> Router Class Initialized
INFO - 2021-01-22 02:51:46 --> Output Class Initialized
INFO - 2021-01-22 02:51:46 --> Security Class Initialized
DEBUG - 2021-01-22 02:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:51:46 --> Input Class Initialized
INFO - 2021-01-22 02:51:46 --> Language Class Initialized
INFO - 2021-01-22 02:51:46 --> Language Class Initialized
INFO - 2021-01-22 02:51:46 --> Config Class Initialized
INFO - 2021-01-22 02:51:46 --> Loader Class Initialized
INFO - 2021-01-22 02:51:46 --> Helper loaded: url_helper
INFO - 2021-01-22 02:51:46 --> Helper loaded: file_helper
INFO - 2021-01-22 02:51:46 --> Helper loaded: form_helper
INFO - 2021-01-22 02:51:46 --> Helper loaded: my_helper
INFO - 2021-01-22 02:51:46 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:51:46 --> Controller Class Initialized
INFO - 2021-01-22 02:51:46 --> Final output sent to browser
DEBUG - 2021-01-22 02:51:46 --> Total execution time: 0.7831
INFO - 2021-01-22 02:53:54 --> Config Class Initialized
INFO - 2021-01-22 02:53:54 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:53:54 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:53:54 --> Utf8 Class Initialized
INFO - 2021-01-22 02:53:54 --> URI Class Initialized
INFO - 2021-01-22 02:53:54 --> Router Class Initialized
INFO - 2021-01-22 02:53:55 --> Output Class Initialized
INFO - 2021-01-22 02:53:55 --> Security Class Initialized
DEBUG - 2021-01-22 02:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:53:55 --> Input Class Initialized
INFO - 2021-01-22 02:53:55 --> Language Class Initialized
INFO - 2021-01-22 02:53:55 --> Language Class Initialized
INFO - 2021-01-22 02:53:55 --> Config Class Initialized
INFO - 2021-01-22 02:53:55 --> Loader Class Initialized
INFO - 2021-01-22 02:53:55 --> Helper loaded: url_helper
INFO - 2021-01-22 02:53:55 --> Helper loaded: file_helper
INFO - 2021-01-22 02:53:55 --> Helper loaded: form_helper
INFO - 2021-01-22 02:53:55 --> Helper loaded: my_helper
INFO - 2021-01-22 02:53:55 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:53:55 --> Controller Class Initialized
INFO - 2021-01-22 02:53:55 --> Final output sent to browser
DEBUG - 2021-01-22 02:53:55 --> Total execution time: 0.6484
INFO - 2021-01-22 02:54:03 --> Config Class Initialized
INFO - 2021-01-22 02:54:03 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:54:03 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:54:03 --> Utf8 Class Initialized
INFO - 2021-01-22 02:54:03 --> URI Class Initialized
INFO - 2021-01-22 02:54:03 --> Router Class Initialized
INFO - 2021-01-22 02:54:03 --> Output Class Initialized
INFO - 2021-01-22 02:54:03 --> Security Class Initialized
DEBUG - 2021-01-22 02:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:54:03 --> Input Class Initialized
INFO - 2021-01-22 02:54:03 --> Language Class Initialized
INFO - 2021-01-22 02:54:03 --> Language Class Initialized
INFO - 2021-01-22 02:54:03 --> Config Class Initialized
INFO - 2021-01-22 02:54:04 --> Loader Class Initialized
INFO - 2021-01-22 02:54:04 --> Helper loaded: url_helper
INFO - 2021-01-22 02:54:04 --> Helper loaded: file_helper
INFO - 2021-01-22 02:54:04 --> Helper loaded: form_helper
INFO - 2021-01-22 02:54:04 --> Helper loaded: my_helper
INFO - 2021-01-22 02:54:04 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:54:04 --> Controller Class Initialized
INFO - 2021-01-22 02:54:04 --> Final output sent to browser
DEBUG - 2021-01-22 02:54:04 --> Total execution time: 0.8996
INFO - 2021-01-22 02:54:04 --> Config Class Initialized
INFO - 2021-01-22 02:54:04 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:54:04 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:54:04 --> Utf8 Class Initialized
INFO - 2021-01-22 02:54:04 --> URI Class Initialized
INFO - 2021-01-22 02:54:04 --> Router Class Initialized
INFO - 2021-01-22 02:54:04 --> Output Class Initialized
INFO - 2021-01-22 02:54:04 --> Security Class Initialized
DEBUG - 2021-01-22 02:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:54:04 --> Input Class Initialized
INFO - 2021-01-22 02:54:04 --> Language Class Initialized
INFO - 2021-01-22 02:54:05 --> Language Class Initialized
INFO - 2021-01-22 02:54:05 --> Config Class Initialized
INFO - 2021-01-22 02:54:05 --> Loader Class Initialized
INFO - 2021-01-22 02:54:05 --> Helper loaded: url_helper
INFO - 2021-01-22 02:54:05 --> Helper loaded: file_helper
INFO - 2021-01-22 02:54:05 --> Helper loaded: form_helper
INFO - 2021-01-22 02:54:05 --> Helper loaded: my_helper
INFO - 2021-01-22 02:54:05 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:54:05 --> Controller Class Initialized
INFO - 2021-01-22 02:54:11 --> Config Class Initialized
INFO - 2021-01-22 02:54:11 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:54:11 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:54:11 --> Utf8 Class Initialized
INFO - 2021-01-22 02:54:11 --> URI Class Initialized
INFO - 2021-01-22 02:54:11 --> Router Class Initialized
INFO - 2021-01-22 02:54:11 --> Output Class Initialized
INFO - 2021-01-22 02:54:11 --> Security Class Initialized
DEBUG - 2021-01-22 02:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:54:11 --> Input Class Initialized
INFO - 2021-01-22 02:54:12 --> Language Class Initialized
INFO - 2021-01-22 02:54:12 --> Language Class Initialized
INFO - 2021-01-22 02:54:12 --> Config Class Initialized
INFO - 2021-01-22 02:54:12 --> Loader Class Initialized
INFO - 2021-01-22 02:54:12 --> Helper loaded: url_helper
INFO - 2021-01-22 02:54:12 --> Helper loaded: file_helper
INFO - 2021-01-22 02:54:12 --> Helper loaded: form_helper
INFO - 2021-01-22 02:54:12 --> Helper loaded: my_helper
INFO - 2021-01-22 02:54:12 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:54:12 --> Controller Class Initialized
INFO - 2021-01-22 02:54:23 --> Config Class Initialized
INFO - 2021-01-22 02:54:23 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:54:23 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:54:23 --> Utf8 Class Initialized
INFO - 2021-01-22 02:54:23 --> URI Class Initialized
INFO - 2021-01-22 02:54:23 --> Router Class Initialized
INFO - 2021-01-22 02:54:23 --> Output Class Initialized
INFO - 2021-01-22 02:54:23 --> Security Class Initialized
DEBUG - 2021-01-22 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:54:23 --> Input Class Initialized
INFO - 2021-01-22 02:54:23 --> Language Class Initialized
INFO - 2021-01-22 02:54:23 --> Language Class Initialized
INFO - 2021-01-22 02:54:23 --> Config Class Initialized
INFO - 2021-01-22 02:54:23 --> Loader Class Initialized
INFO - 2021-01-22 02:54:23 --> Helper loaded: url_helper
INFO - 2021-01-22 02:54:24 --> Helper loaded: file_helper
INFO - 2021-01-22 02:54:24 --> Helper loaded: form_helper
INFO - 2021-01-22 02:54:24 --> Helper loaded: my_helper
INFO - 2021-01-22 02:54:24 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:54:24 --> Controller Class Initialized
INFO - 2021-01-22 02:54:24 --> Final output sent to browser
DEBUG - 2021-01-22 02:54:24 --> Total execution time: 0.8616
INFO - 2021-01-22 02:54:51 --> Config Class Initialized
INFO - 2021-01-22 02:54:51 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:54:51 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:54:51 --> Utf8 Class Initialized
INFO - 2021-01-22 02:54:51 --> URI Class Initialized
INFO - 2021-01-22 02:54:51 --> Router Class Initialized
INFO - 2021-01-22 02:54:51 --> Output Class Initialized
INFO - 2021-01-22 02:54:51 --> Security Class Initialized
DEBUG - 2021-01-22 02:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:54:51 --> Input Class Initialized
INFO - 2021-01-22 02:54:51 --> Language Class Initialized
INFO - 2021-01-22 02:54:51 --> Language Class Initialized
INFO - 2021-01-22 02:54:51 --> Config Class Initialized
INFO - 2021-01-22 02:54:51 --> Loader Class Initialized
INFO - 2021-01-22 02:54:51 --> Helper loaded: url_helper
INFO - 2021-01-22 02:54:51 --> Helper loaded: file_helper
INFO - 2021-01-22 02:54:51 --> Helper loaded: form_helper
INFO - 2021-01-22 02:54:51 --> Helper loaded: my_helper
INFO - 2021-01-22 02:54:51 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:54:51 --> Controller Class Initialized
DEBUG - 2021-01-22 02:54:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-22 02:54:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:54:51 --> Final output sent to browser
DEBUG - 2021-01-22 02:54:51 --> Total execution time: 0.6721
INFO - 2021-01-22 02:54:58 --> Config Class Initialized
INFO - 2021-01-22 02:54:58 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:54:58 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:54:58 --> Utf8 Class Initialized
INFO - 2021-01-22 02:54:58 --> URI Class Initialized
INFO - 2021-01-22 02:54:59 --> Router Class Initialized
INFO - 2021-01-22 02:54:59 --> Output Class Initialized
INFO - 2021-01-22 02:54:59 --> Security Class Initialized
DEBUG - 2021-01-22 02:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:54:59 --> Input Class Initialized
INFO - 2021-01-22 02:54:59 --> Language Class Initialized
INFO - 2021-01-22 02:54:59 --> Language Class Initialized
INFO - 2021-01-22 02:54:59 --> Config Class Initialized
INFO - 2021-01-22 02:54:59 --> Loader Class Initialized
INFO - 2021-01-22 02:54:59 --> Helper loaded: url_helper
INFO - 2021-01-22 02:54:59 --> Helper loaded: file_helper
INFO - 2021-01-22 02:54:59 --> Helper loaded: form_helper
INFO - 2021-01-22 02:54:59 --> Helper loaded: my_helper
INFO - 2021-01-22 02:54:59 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:54:59 --> Controller Class Initialized
DEBUG - 2021-01-22 02:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-22 02:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:54:59 --> Final output sent to browser
DEBUG - 2021-01-22 02:54:59 --> Total execution time: 1.0364
INFO - 2021-01-22 02:55:10 --> Config Class Initialized
INFO - 2021-01-22 02:55:10 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:55:10 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:55:10 --> Utf8 Class Initialized
INFO - 2021-01-22 02:55:10 --> URI Class Initialized
INFO - 2021-01-22 02:55:10 --> Router Class Initialized
INFO - 2021-01-22 02:55:10 --> Output Class Initialized
INFO - 2021-01-22 02:55:11 --> Security Class Initialized
DEBUG - 2021-01-22 02:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:55:11 --> Input Class Initialized
INFO - 2021-01-22 02:55:11 --> Language Class Initialized
INFO - 2021-01-22 02:55:11 --> Language Class Initialized
INFO - 2021-01-22 02:55:11 --> Config Class Initialized
INFO - 2021-01-22 02:55:11 --> Loader Class Initialized
INFO - 2021-01-22 02:55:11 --> Helper loaded: url_helper
INFO - 2021-01-22 02:55:11 --> Helper loaded: file_helper
INFO - 2021-01-22 02:55:11 --> Helper loaded: form_helper
INFO - 2021-01-22 02:55:11 --> Helper loaded: my_helper
INFO - 2021-01-22 02:55:11 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:55:11 --> Controller Class Initialized
INFO - 2021-01-22 02:55:11 --> Final output sent to browser
DEBUG - 2021-01-22 02:55:11 --> Total execution time: 0.5835
INFO - 2021-01-22 02:55:16 --> Config Class Initialized
INFO - 2021-01-22 02:55:16 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:55:16 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:55:16 --> Utf8 Class Initialized
INFO - 2021-01-22 02:55:16 --> URI Class Initialized
INFO - 2021-01-22 02:55:16 --> Router Class Initialized
INFO - 2021-01-22 02:55:16 --> Output Class Initialized
INFO - 2021-01-22 02:55:16 --> Security Class Initialized
DEBUG - 2021-01-22 02:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:55:16 --> Input Class Initialized
INFO - 2021-01-22 02:55:16 --> Language Class Initialized
INFO - 2021-01-22 02:55:16 --> Language Class Initialized
INFO - 2021-01-22 02:55:16 --> Config Class Initialized
INFO - 2021-01-22 02:55:16 --> Loader Class Initialized
INFO - 2021-01-22 02:55:16 --> Helper loaded: url_helper
INFO - 2021-01-22 02:55:16 --> Helper loaded: file_helper
INFO - 2021-01-22 02:55:16 --> Helper loaded: form_helper
INFO - 2021-01-22 02:55:16 --> Helper loaded: my_helper
INFO - 2021-01-22 02:55:16 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:55:16 --> Controller Class Initialized
INFO - 2021-01-22 02:56:51 --> Config Class Initialized
INFO - 2021-01-22 02:56:51 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:56:51 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:56:51 --> Utf8 Class Initialized
INFO - 2021-01-22 02:56:51 --> URI Class Initialized
INFO - 2021-01-22 02:56:51 --> Router Class Initialized
INFO - 2021-01-22 02:56:51 --> Output Class Initialized
INFO - 2021-01-22 02:56:51 --> Security Class Initialized
DEBUG - 2021-01-22 02:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:56:51 --> Input Class Initialized
INFO - 2021-01-22 02:56:51 --> Language Class Initialized
INFO - 2021-01-22 02:56:51 --> Language Class Initialized
INFO - 2021-01-22 02:56:51 --> Config Class Initialized
INFO - 2021-01-22 02:56:51 --> Loader Class Initialized
INFO - 2021-01-22 02:56:51 --> Helper loaded: url_helper
INFO - 2021-01-22 02:56:51 --> Helper loaded: file_helper
INFO - 2021-01-22 02:56:51 --> Helper loaded: form_helper
INFO - 2021-01-22 02:56:51 --> Helper loaded: my_helper
INFO - 2021-01-22 02:56:52 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:56:52 --> Controller Class Initialized
DEBUG - 2021-01-22 02:56:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-01-22 02:56:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:56:52 --> Final output sent to browser
DEBUG - 2021-01-22 02:56:52 --> Total execution time: 0.9981
INFO - 2021-01-22 02:56:54 --> Config Class Initialized
INFO - 2021-01-22 02:56:54 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:56:54 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:56:54 --> Utf8 Class Initialized
INFO - 2021-01-22 02:56:54 --> URI Class Initialized
INFO - 2021-01-22 02:56:54 --> Router Class Initialized
INFO - 2021-01-22 02:56:54 --> Output Class Initialized
INFO - 2021-01-22 02:56:54 --> Security Class Initialized
DEBUG - 2021-01-22 02:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:56:55 --> Input Class Initialized
INFO - 2021-01-22 02:56:55 --> Language Class Initialized
INFO - 2021-01-22 02:56:55 --> Language Class Initialized
INFO - 2021-01-22 02:56:55 --> Config Class Initialized
INFO - 2021-01-22 02:56:55 --> Loader Class Initialized
INFO - 2021-01-22 02:56:55 --> Helper loaded: url_helper
INFO - 2021-01-22 02:56:55 --> Helper loaded: file_helper
INFO - 2021-01-22 02:56:55 --> Helper loaded: form_helper
INFO - 2021-01-22 02:56:55 --> Helper loaded: my_helper
INFO - 2021-01-22 02:56:55 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:56:55 --> Controller Class Initialized
INFO - 2021-01-22 02:56:55 --> Final output sent to browser
DEBUG - 2021-01-22 02:56:55 --> Total execution time: 0.8296
INFO - 2021-01-22 02:57:03 --> Config Class Initialized
INFO - 2021-01-22 02:57:03 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:57:03 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:57:03 --> Utf8 Class Initialized
INFO - 2021-01-22 02:57:03 --> URI Class Initialized
INFO - 2021-01-22 02:57:03 --> Router Class Initialized
INFO - 2021-01-22 02:57:03 --> Output Class Initialized
INFO - 2021-01-22 02:57:03 --> Security Class Initialized
DEBUG - 2021-01-22 02:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:57:03 --> Input Class Initialized
INFO - 2021-01-22 02:57:03 --> Language Class Initialized
INFO - 2021-01-22 02:57:03 --> Language Class Initialized
INFO - 2021-01-22 02:57:03 --> Config Class Initialized
INFO - 2021-01-22 02:57:03 --> Loader Class Initialized
INFO - 2021-01-22 02:57:04 --> Helper loaded: url_helper
INFO - 2021-01-22 02:57:04 --> Helper loaded: file_helper
INFO - 2021-01-22 02:57:04 --> Helper loaded: form_helper
INFO - 2021-01-22 02:57:04 --> Helper loaded: my_helper
INFO - 2021-01-22 02:57:04 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:57:04 --> Controller Class Initialized
DEBUG - 2021-01-22 02:57:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-01-22 02:57:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:57:04 --> Final output sent to browser
DEBUG - 2021-01-22 02:57:04 --> Total execution time: 1.1254
INFO - 2021-01-22 02:57:09 --> Config Class Initialized
INFO - 2021-01-22 02:57:09 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:57:09 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:57:09 --> Utf8 Class Initialized
INFO - 2021-01-22 02:57:09 --> URI Class Initialized
INFO - 2021-01-22 02:57:09 --> Router Class Initialized
INFO - 2021-01-22 02:57:09 --> Output Class Initialized
INFO - 2021-01-22 02:57:09 --> Security Class Initialized
DEBUG - 2021-01-22 02:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:57:09 --> Input Class Initialized
INFO - 2021-01-22 02:57:09 --> Language Class Initialized
INFO - 2021-01-22 02:57:09 --> Language Class Initialized
INFO - 2021-01-22 02:57:09 --> Config Class Initialized
INFO - 2021-01-22 02:57:09 --> Loader Class Initialized
INFO - 2021-01-22 02:57:09 --> Helper loaded: url_helper
INFO - 2021-01-22 02:57:09 --> Helper loaded: file_helper
INFO - 2021-01-22 02:57:09 --> Helper loaded: form_helper
INFO - 2021-01-22 02:57:09 --> Helper loaded: my_helper
INFO - 2021-01-22 02:57:09 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:57:10 --> Controller Class Initialized
DEBUG - 2021-01-22 02:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-01-22 02:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:57:10 --> Final output sent to browser
DEBUG - 2021-01-22 02:57:10 --> Total execution time: 1.0355
INFO - 2021-01-22 02:57:17 --> Config Class Initialized
INFO - 2021-01-22 02:57:17 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:57:17 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:57:17 --> Utf8 Class Initialized
INFO - 2021-01-22 02:57:17 --> URI Class Initialized
INFO - 2021-01-22 02:57:17 --> Router Class Initialized
INFO - 2021-01-22 02:57:17 --> Output Class Initialized
INFO - 2021-01-22 02:57:17 --> Security Class Initialized
DEBUG - 2021-01-22 02:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:57:17 --> Input Class Initialized
INFO - 2021-01-22 02:57:17 --> Language Class Initialized
INFO - 2021-01-22 02:57:18 --> Language Class Initialized
INFO - 2021-01-22 02:57:18 --> Config Class Initialized
INFO - 2021-01-22 02:57:18 --> Loader Class Initialized
INFO - 2021-01-22 02:57:18 --> Helper loaded: url_helper
INFO - 2021-01-22 02:57:18 --> Helper loaded: file_helper
INFO - 2021-01-22 02:57:18 --> Helper loaded: form_helper
INFO - 2021-01-22 02:57:18 --> Helper loaded: my_helper
INFO - 2021-01-22 02:57:18 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:57:18 --> Controller Class Initialized
DEBUG - 2021-01-22 02:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 02:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:57:18 --> Final output sent to browser
DEBUG - 2021-01-22 02:57:18 --> Total execution time: 1.1181
INFO - 2021-01-22 02:58:27 --> Config Class Initialized
INFO - 2021-01-22 02:58:27 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:58:27 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:58:27 --> Utf8 Class Initialized
INFO - 2021-01-22 02:58:27 --> URI Class Initialized
INFO - 2021-01-22 02:58:27 --> Router Class Initialized
INFO - 2021-01-22 02:58:27 --> Output Class Initialized
INFO - 2021-01-22 02:58:27 --> Security Class Initialized
DEBUG - 2021-01-22 02:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:58:28 --> Input Class Initialized
INFO - 2021-01-22 02:58:28 --> Language Class Initialized
INFO - 2021-01-22 02:58:28 --> Language Class Initialized
INFO - 2021-01-22 02:58:28 --> Config Class Initialized
INFO - 2021-01-22 02:58:28 --> Loader Class Initialized
INFO - 2021-01-22 02:58:28 --> Helper loaded: url_helper
INFO - 2021-01-22 02:58:28 --> Helper loaded: file_helper
INFO - 2021-01-22 02:58:28 --> Helper loaded: form_helper
INFO - 2021-01-22 02:58:28 --> Helper loaded: my_helper
INFO - 2021-01-22 02:58:28 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:58:28 --> Controller Class Initialized
DEBUG - 2021-01-22 02:58:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-01-22 02:58:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:58:28 --> Final output sent to browser
DEBUG - 2021-01-22 02:58:28 --> Total execution time: 1.1261
INFO - 2021-01-22 02:58:34 --> Config Class Initialized
INFO - 2021-01-22 02:58:34 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:58:34 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:58:34 --> Utf8 Class Initialized
INFO - 2021-01-22 02:58:34 --> URI Class Initialized
INFO - 2021-01-22 02:58:34 --> Router Class Initialized
INFO - 2021-01-22 02:58:34 --> Output Class Initialized
INFO - 2021-01-22 02:58:34 --> Security Class Initialized
DEBUG - 2021-01-22 02:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:58:35 --> Input Class Initialized
INFO - 2021-01-22 02:58:35 --> Language Class Initialized
INFO - 2021-01-22 02:58:35 --> Language Class Initialized
INFO - 2021-01-22 02:58:35 --> Config Class Initialized
INFO - 2021-01-22 02:58:35 --> Loader Class Initialized
INFO - 2021-01-22 02:58:35 --> Helper loaded: url_helper
INFO - 2021-01-22 02:58:35 --> Helper loaded: file_helper
INFO - 2021-01-22 02:58:35 --> Helper loaded: form_helper
INFO - 2021-01-22 02:58:35 --> Helper loaded: my_helper
INFO - 2021-01-22 02:58:35 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:58:35 --> Controller Class Initialized
DEBUG - 2021-01-22 02:58:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 02:58:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 02:58:35 --> Final output sent to browser
DEBUG - 2021-01-22 02:58:35 --> Total execution time: 1.0372
INFO - 2021-01-22 02:59:06 --> Config Class Initialized
INFO - 2021-01-22 02:59:06 --> Hooks Class Initialized
DEBUG - 2021-01-22 02:59:06 --> UTF-8 Support Enabled
INFO - 2021-01-22 02:59:06 --> Utf8 Class Initialized
INFO - 2021-01-22 02:59:06 --> URI Class Initialized
INFO - 2021-01-22 02:59:06 --> Router Class Initialized
INFO - 2021-01-22 02:59:06 --> Output Class Initialized
INFO - 2021-01-22 02:59:06 --> Security Class Initialized
DEBUG - 2021-01-22 02:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 02:59:06 --> Input Class Initialized
INFO - 2021-01-22 02:59:06 --> Language Class Initialized
INFO - 2021-01-22 02:59:06 --> Language Class Initialized
INFO - 2021-01-22 02:59:06 --> Config Class Initialized
INFO - 2021-01-22 02:59:06 --> Loader Class Initialized
INFO - 2021-01-22 02:59:06 --> Helper loaded: url_helper
INFO - 2021-01-22 02:59:06 --> Helper loaded: file_helper
INFO - 2021-01-22 02:59:06 --> Helper loaded: form_helper
INFO - 2021-01-22 02:59:06 --> Helper loaded: my_helper
INFO - 2021-01-22 02:59:07 --> Database Driver Class Initialized
DEBUG - 2021-01-22 02:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 02:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 02:59:07 --> Controller Class Initialized
DEBUG - 2021-01-22 02:59:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-22 02:59:07 --> Final output sent to browser
DEBUG - 2021-01-22 02:59:07 --> Total execution time: 0.9026
INFO - 2021-01-22 03:03:26 --> Config Class Initialized
INFO - 2021-01-22 03:03:26 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:03:26 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:03:26 --> Utf8 Class Initialized
INFO - 2021-01-22 03:03:26 --> URI Class Initialized
INFO - 2021-01-22 03:03:26 --> Router Class Initialized
INFO - 2021-01-22 03:03:26 --> Output Class Initialized
INFO - 2021-01-22 03:03:26 --> Security Class Initialized
DEBUG - 2021-01-22 03:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:03:26 --> Input Class Initialized
INFO - 2021-01-22 03:03:26 --> Language Class Initialized
INFO - 2021-01-22 03:03:27 --> Language Class Initialized
INFO - 2021-01-22 03:03:27 --> Config Class Initialized
INFO - 2021-01-22 03:03:27 --> Loader Class Initialized
INFO - 2021-01-22 03:03:27 --> Helper loaded: url_helper
INFO - 2021-01-22 03:03:27 --> Helper loaded: file_helper
INFO - 2021-01-22 03:03:27 --> Helper loaded: form_helper
INFO - 2021-01-22 03:03:27 --> Helper loaded: my_helper
INFO - 2021-01-22 03:03:27 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:03:27 --> Controller Class Initialized
DEBUG - 2021-01-22 03:03:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-01-22 03:03:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:03:27 --> Final output sent to browser
DEBUG - 2021-01-22 03:03:27 --> Total execution time: 0.9076
INFO - 2021-01-22 03:03:30 --> Config Class Initialized
INFO - 2021-01-22 03:03:30 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:03:30 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:03:30 --> Utf8 Class Initialized
INFO - 2021-01-22 03:03:30 --> URI Class Initialized
INFO - 2021-01-22 03:03:31 --> Router Class Initialized
INFO - 2021-01-22 03:03:31 --> Output Class Initialized
INFO - 2021-01-22 03:03:31 --> Security Class Initialized
DEBUG - 2021-01-22 03:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:03:31 --> Input Class Initialized
INFO - 2021-01-22 03:03:31 --> Language Class Initialized
INFO - 2021-01-22 03:03:31 --> Language Class Initialized
INFO - 2021-01-22 03:03:31 --> Config Class Initialized
INFO - 2021-01-22 03:03:31 --> Loader Class Initialized
INFO - 2021-01-22 03:03:31 --> Helper loaded: url_helper
INFO - 2021-01-22 03:03:31 --> Helper loaded: file_helper
INFO - 2021-01-22 03:03:31 --> Helper loaded: form_helper
INFO - 2021-01-22 03:03:31 --> Helper loaded: my_helper
INFO - 2021-01-22 03:03:31 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:03:31 --> Controller Class Initialized
DEBUG - 2021-01-22 03:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-01-22 03:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:03:31 --> Final output sent to browser
DEBUG - 2021-01-22 03:03:31 --> Total execution time: 1.0162
INFO - 2021-01-22 03:06:14 --> Config Class Initialized
INFO - 2021-01-22 03:06:14 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:06:14 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:06:14 --> Utf8 Class Initialized
INFO - 2021-01-22 03:06:14 --> URI Class Initialized
INFO - 2021-01-22 03:06:14 --> Router Class Initialized
INFO - 2021-01-22 03:06:14 --> Output Class Initialized
INFO - 2021-01-22 03:06:14 --> Security Class Initialized
DEBUG - 2021-01-22 03:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:06:14 --> Input Class Initialized
INFO - 2021-01-22 03:06:14 --> Language Class Initialized
INFO - 2021-01-22 03:06:14 --> Language Class Initialized
INFO - 2021-01-22 03:06:14 --> Config Class Initialized
INFO - 2021-01-22 03:06:14 --> Loader Class Initialized
INFO - 2021-01-22 03:06:14 --> Helper loaded: url_helper
INFO - 2021-01-22 03:06:14 --> Helper loaded: file_helper
INFO - 2021-01-22 03:06:14 --> Helper loaded: form_helper
INFO - 2021-01-22 03:06:14 --> Helper loaded: my_helper
INFO - 2021-01-22 03:06:14 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:06:14 --> Controller Class Initialized
DEBUG - 2021-01-22 03:06:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 03:06:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:06:15 --> Final output sent to browser
DEBUG - 2021-01-22 03:06:15 --> Total execution time: 0.9976
INFO - 2021-01-22 03:06:40 --> Config Class Initialized
INFO - 2021-01-22 03:06:40 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:06:40 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:06:40 --> Utf8 Class Initialized
INFO - 2021-01-22 03:06:40 --> URI Class Initialized
INFO - 2021-01-22 03:06:40 --> Router Class Initialized
INFO - 2021-01-22 03:06:40 --> Output Class Initialized
INFO - 2021-01-22 03:06:40 --> Security Class Initialized
DEBUG - 2021-01-22 03:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:06:40 --> Input Class Initialized
INFO - 2021-01-22 03:06:40 --> Language Class Initialized
INFO - 2021-01-22 03:06:40 --> Language Class Initialized
INFO - 2021-01-22 03:06:40 --> Config Class Initialized
INFO - 2021-01-22 03:06:40 --> Loader Class Initialized
INFO - 2021-01-22 03:06:40 --> Helper loaded: url_helper
INFO - 2021-01-22 03:06:40 --> Helper loaded: file_helper
INFO - 2021-01-22 03:06:40 --> Helper loaded: form_helper
INFO - 2021-01-22 03:06:40 --> Helper loaded: my_helper
INFO - 2021-01-22 03:06:40 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:06:41 --> Controller Class Initialized
INFO - 2021-01-22 03:06:41 --> Helper loaded: cookie_helper
INFO - 2021-01-22 03:06:41 --> Config Class Initialized
INFO - 2021-01-22 03:06:41 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:06:41 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:06:41 --> Utf8 Class Initialized
INFO - 2021-01-22 03:06:41 --> URI Class Initialized
INFO - 2021-01-22 03:06:41 --> Router Class Initialized
INFO - 2021-01-22 03:06:41 --> Output Class Initialized
INFO - 2021-01-22 03:06:41 --> Security Class Initialized
DEBUG - 2021-01-22 03:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:06:41 --> Input Class Initialized
INFO - 2021-01-22 03:06:41 --> Language Class Initialized
INFO - 2021-01-22 03:06:41 --> Language Class Initialized
INFO - 2021-01-22 03:06:41 --> Config Class Initialized
INFO - 2021-01-22 03:06:41 --> Loader Class Initialized
INFO - 2021-01-22 03:06:41 --> Helper loaded: url_helper
INFO - 2021-01-22 03:06:41 --> Helper loaded: file_helper
INFO - 2021-01-22 03:06:41 --> Helper loaded: form_helper
INFO - 2021-01-22 03:06:41 --> Helper loaded: my_helper
INFO - 2021-01-22 03:06:41 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:06:41 --> Controller Class Initialized
DEBUG - 2021-01-22 03:06:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-22 03:06:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:06:42 --> Final output sent to browser
DEBUG - 2021-01-22 03:06:42 --> Total execution time: 0.9474
INFO - 2021-01-22 03:18:38 --> Config Class Initialized
INFO - 2021-01-22 03:18:38 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:18:38 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:18:38 --> Utf8 Class Initialized
INFO - 2021-01-22 03:18:38 --> URI Class Initialized
INFO - 2021-01-22 03:18:38 --> Router Class Initialized
INFO - 2021-01-22 03:18:38 --> Output Class Initialized
INFO - 2021-01-22 03:18:39 --> Security Class Initialized
DEBUG - 2021-01-22 03:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:18:39 --> Input Class Initialized
INFO - 2021-01-22 03:18:39 --> Language Class Initialized
INFO - 2021-01-22 03:18:39 --> Language Class Initialized
INFO - 2021-01-22 03:18:39 --> Config Class Initialized
INFO - 2021-01-22 03:18:39 --> Loader Class Initialized
INFO - 2021-01-22 03:18:39 --> Helper loaded: url_helper
INFO - 2021-01-22 03:18:39 --> Helper loaded: file_helper
INFO - 2021-01-22 03:18:39 --> Helper loaded: form_helper
INFO - 2021-01-22 03:18:39 --> Helper loaded: my_helper
INFO - 2021-01-22 03:18:39 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:18:39 --> Controller Class Initialized
INFO - 2021-01-22 03:18:39 --> Helper loaded: cookie_helper
INFO - 2021-01-22 03:18:39 --> Final output sent to browser
DEBUG - 2021-01-22 03:18:39 --> Total execution time: 0.7777
INFO - 2021-01-22 03:18:40 --> Config Class Initialized
INFO - 2021-01-22 03:18:40 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:18:40 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:18:40 --> Utf8 Class Initialized
INFO - 2021-01-22 03:18:40 --> URI Class Initialized
INFO - 2021-01-22 03:18:40 --> Router Class Initialized
INFO - 2021-01-22 03:18:40 --> Output Class Initialized
INFO - 2021-01-22 03:18:40 --> Security Class Initialized
DEBUG - 2021-01-22 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:18:40 --> Input Class Initialized
INFO - 2021-01-22 03:18:40 --> Language Class Initialized
INFO - 2021-01-22 03:18:40 --> Language Class Initialized
INFO - 2021-01-22 03:18:40 --> Config Class Initialized
INFO - 2021-01-22 03:18:40 --> Loader Class Initialized
INFO - 2021-01-22 03:18:40 --> Helper loaded: url_helper
INFO - 2021-01-22 03:18:40 --> Helper loaded: file_helper
INFO - 2021-01-22 03:18:40 --> Helper loaded: form_helper
INFO - 2021-01-22 03:18:40 --> Helper loaded: my_helper
INFO - 2021-01-22 03:18:40 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:18:40 --> Controller Class Initialized
DEBUG - 2021-01-22 03:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-22 03:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:18:40 --> Final output sent to browser
DEBUG - 2021-01-22 03:18:40 --> Total execution time: 0.9208
INFO - 2021-01-22 03:21:07 --> Config Class Initialized
INFO - 2021-01-22 03:21:07 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:21:07 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:21:07 --> Utf8 Class Initialized
INFO - 2021-01-22 03:21:07 --> URI Class Initialized
INFO - 2021-01-22 03:21:07 --> Router Class Initialized
INFO - 2021-01-22 03:21:07 --> Output Class Initialized
INFO - 2021-01-22 03:21:07 --> Security Class Initialized
DEBUG - 2021-01-22 03:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:21:07 --> Input Class Initialized
INFO - 2021-01-22 03:21:07 --> Language Class Initialized
INFO - 2021-01-22 03:21:07 --> Language Class Initialized
INFO - 2021-01-22 03:21:07 --> Config Class Initialized
INFO - 2021-01-22 03:21:07 --> Loader Class Initialized
INFO - 2021-01-22 03:21:08 --> Helper loaded: url_helper
INFO - 2021-01-22 03:21:08 --> Helper loaded: file_helper
INFO - 2021-01-22 03:21:08 --> Helper loaded: form_helper
INFO - 2021-01-22 03:21:08 --> Helper loaded: my_helper
INFO - 2021-01-22 03:21:08 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:21:08 --> Controller Class Initialized
DEBUG - 2021-01-22 03:21:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-22 03:21:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:21:08 --> Final output sent to browser
DEBUG - 2021-01-22 03:21:08 --> Total execution time: 1.0876
INFO - 2021-01-22 03:21:11 --> Config Class Initialized
INFO - 2021-01-22 03:21:11 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:21:11 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:21:11 --> Utf8 Class Initialized
INFO - 2021-01-22 03:21:11 --> URI Class Initialized
INFO - 2021-01-22 03:21:11 --> Router Class Initialized
INFO - 2021-01-22 03:21:11 --> Output Class Initialized
INFO - 2021-01-22 03:21:11 --> Security Class Initialized
DEBUG - 2021-01-22 03:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:21:11 --> Input Class Initialized
INFO - 2021-01-22 03:21:11 --> Language Class Initialized
INFO - 2021-01-22 03:21:11 --> Language Class Initialized
INFO - 2021-01-22 03:21:11 --> Config Class Initialized
INFO - 2021-01-22 03:21:11 --> Loader Class Initialized
INFO - 2021-01-22 03:21:11 --> Helper loaded: url_helper
INFO - 2021-01-22 03:21:11 --> Helper loaded: file_helper
INFO - 2021-01-22 03:21:11 --> Helper loaded: form_helper
INFO - 2021-01-22 03:21:11 --> Helper loaded: my_helper
INFO - 2021-01-22 03:21:12 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:21:12 --> Controller Class Initialized
DEBUG - 2021-01-22 03:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-22 03:21:12 --> Final output sent to browser
DEBUG - 2021-01-22 03:21:12 --> Total execution time: 1.0250
INFO - 2021-01-22 03:21:21 --> Config Class Initialized
INFO - 2021-01-22 03:21:21 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:21:21 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:21:21 --> Utf8 Class Initialized
INFO - 2021-01-22 03:21:21 --> URI Class Initialized
INFO - 2021-01-22 03:21:21 --> Router Class Initialized
INFO - 2021-01-22 03:21:21 --> Output Class Initialized
INFO - 2021-01-22 03:21:21 --> Security Class Initialized
DEBUG - 2021-01-22 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:21:22 --> Input Class Initialized
INFO - 2021-01-22 03:21:22 --> Language Class Initialized
INFO - 2021-01-22 03:21:22 --> Language Class Initialized
INFO - 2021-01-22 03:21:22 --> Config Class Initialized
INFO - 2021-01-22 03:21:22 --> Loader Class Initialized
INFO - 2021-01-22 03:21:22 --> Helper loaded: url_helper
INFO - 2021-01-22 03:21:22 --> Helper loaded: file_helper
INFO - 2021-01-22 03:21:22 --> Helper loaded: form_helper
INFO - 2021-01-22 03:21:22 --> Helper loaded: my_helper
INFO - 2021-01-22 03:21:22 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:21:22 --> Controller Class Initialized
DEBUG - 2021-01-22 03:21:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 03:21:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:21:22 --> Final output sent to browser
DEBUG - 2021-01-22 03:21:22 --> Total execution time: 0.9729
INFO - 2021-01-22 03:22:00 --> Config Class Initialized
INFO - 2021-01-22 03:22:00 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:22:00 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:22:00 --> Utf8 Class Initialized
INFO - 2021-01-22 03:22:01 --> URI Class Initialized
INFO - 2021-01-22 03:22:01 --> Router Class Initialized
INFO - 2021-01-22 03:22:01 --> Output Class Initialized
INFO - 2021-01-22 03:22:01 --> Security Class Initialized
DEBUG - 2021-01-22 03:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:22:01 --> Input Class Initialized
INFO - 2021-01-22 03:22:01 --> Language Class Initialized
INFO - 2021-01-22 03:22:01 --> Language Class Initialized
INFO - 2021-01-22 03:22:01 --> Config Class Initialized
INFO - 2021-01-22 03:22:01 --> Loader Class Initialized
INFO - 2021-01-22 03:22:01 --> Helper loaded: url_helper
INFO - 2021-01-22 03:22:01 --> Helper loaded: file_helper
INFO - 2021-01-22 03:22:01 --> Helper loaded: form_helper
INFO - 2021-01-22 03:22:01 --> Helper loaded: my_helper
INFO - 2021-01-22 03:22:01 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:22:01 --> Controller Class Initialized
DEBUG - 2021-01-22 03:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-01-22 03:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:22:01 --> Final output sent to browser
DEBUG - 2021-01-22 03:22:01 --> Total execution time: 0.9767
INFO - 2021-01-22 03:22:07 --> Config Class Initialized
INFO - 2021-01-22 03:22:07 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:22:07 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:22:07 --> Utf8 Class Initialized
INFO - 2021-01-22 03:22:07 --> URI Class Initialized
INFO - 2021-01-22 03:22:07 --> Router Class Initialized
INFO - 2021-01-22 03:22:08 --> Output Class Initialized
INFO - 2021-01-22 03:22:08 --> Security Class Initialized
DEBUG - 2021-01-22 03:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:22:08 --> Input Class Initialized
INFO - 2021-01-22 03:22:08 --> Language Class Initialized
INFO - 2021-01-22 03:22:08 --> Language Class Initialized
INFO - 2021-01-22 03:22:08 --> Config Class Initialized
INFO - 2021-01-22 03:22:08 --> Loader Class Initialized
INFO - 2021-01-22 03:22:08 --> Helper loaded: url_helper
INFO - 2021-01-22 03:22:08 --> Helper loaded: file_helper
INFO - 2021-01-22 03:22:08 --> Helper loaded: form_helper
INFO - 2021-01-22 03:22:08 --> Helper loaded: my_helper
INFO - 2021-01-22 03:22:08 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:22:08 --> Controller Class Initialized
DEBUG - 2021-01-22 03:22:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-22 03:22:08 --> Final output sent to browser
DEBUG - 2021-01-22 03:22:08 --> Total execution time: 1.0267
INFO - 2021-01-22 03:22:17 --> Config Class Initialized
INFO - 2021-01-22 03:22:17 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:22:17 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:22:17 --> Utf8 Class Initialized
INFO - 2021-01-22 03:22:17 --> URI Class Initialized
INFO - 2021-01-22 03:22:17 --> Router Class Initialized
INFO - 2021-01-22 03:22:17 --> Output Class Initialized
INFO - 2021-01-22 03:22:17 --> Security Class Initialized
DEBUG - 2021-01-22 03:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:22:17 --> Input Class Initialized
INFO - 2021-01-22 03:22:17 --> Language Class Initialized
INFO - 2021-01-22 03:22:17 --> Language Class Initialized
INFO - 2021-01-22 03:22:17 --> Config Class Initialized
INFO - 2021-01-22 03:22:17 --> Loader Class Initialized
INFO - 2021-01-22 03:22:17 --> Helper loaded: url_helper
INFO - 2021-01-22 03:22:17 --> Helper loaded: file_helper
INFO - 2021-01-22 03:22:18 --> Helper loaded: form_helper
INFO - 2021-01-22 03:22:18 --> Helper loaded: my_helper
INFO - 2021-01-22 03:22:18 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:22:18 --> Controller Class Initialized
DEBUG - 2021-01-22 03:22:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-22 03:22:18 --> Final output sent to browser
DEBUG - 2021-01-22 03:22:18 --> Total execution time: 0.8908
INFO - 2021-01-22 03:22:26 --> Config Class Initialized
INFO - 2021-01-22 03:22:26 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:22:26 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:22:26 --> Utf8 Class Initialized
INFO - 2021-01-22 03:22:26 --> URI Class Initialized
INFO - 2021-01-22 03:22:26 --> Router Class Initialized
INFO - 2021-01-22 03:22:27 --> Output Class Initialized
INFO - 2021-01-22 03:22:27 --> Security Class Initialized
DEBUG - 2021-01-22 03:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:22:27 --> Input Class Initialized
INFO - 2021-01-22 03:22:27 --> Language Class Initialized
INFO - 2021-01-22 03:22:27 --> Language Class Initialized
INFO - 2021-01-22 03:22:27 --> Config Class Initialized
INFO - 2021-01-22 03:22:27 --> Loader Class Initialized
INFO - 2021-01-22 03:22:27 --> Helper loaded: url_helper
INFO - 2021-01-22 03:22:27 --> Helper loaded: file_helper
INFO - 2021-01-22 03:22:27 --> Helper loaded: form_helper
INFO - 2021-01-22 03:22:27 --> Helper loaded: my_helper
INFO - 2021-01-22 03:22:27 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:22:27 --> Controller Class Initialized
DEBUG - 2021-01-22 03:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-01-22 03:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:22:27 --> Final output sent to browser
DEBUG - 2021-01-22 03:22:27 --> Total execution time: 0.9337
INFO - 2021-01-22 03:27:12 --> Config Class Initialized
INFO - 2021-01-22 03:27:12 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:27:12 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:27:12 --> Utf8 Class Initialized
INFO - 2021-01-22 03:27:12 --> URI Class Initialized
INFO - 2021-01-22 03:27:12 --> Router Class Initialized
INFO - 2021-01-22 03:27:12 --> Output Class Initialized
INFO - 2021-01-22 03:27:12 --> Security Class Initialized
DEBUG - 2021-01-22 03:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:27:13 --> Input Class Initialized
INFO - 2021-01-22 03:27:13 --> Language Class Initialized
INFO - 2021-01-22 03:27:13 --> Language Class Initialized
INFO - 2021-01-22 03:27:13 --> Config Class Initialized
INFO - 2021-01-22 03:27:13 --> Loader Class Initialized
INFO - 2021-01-22 03:27:13 --> Helper loaded: url_helper
INFO - 2021-01-22 03:27:13 --> Helper loaded: file_helper
INFO - 2021-01-22 03:27:13 --> Helper loaded: form_helper
INFO - 2021-01-22 03:27:13 --> Helper loaded: my_helper
INFO - 2021-01-22 03:27:13 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:27:13 --> Controller Class Initialized
DEBUG - 2021-01-22 03:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 03:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:27:13 --> Final output sent to browser
DEBUG - 2021-01-22 03:27:13 --> Total execution time: 0.8096
INFO - 2021-01-22 03:28:10 --> Config Class Initialized
INFO - 2021-01-22 03:28:10 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:28:10 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:28:10 --> Utf8 Class Initialized
INFO - 2021-01-22 03:28:10 --> URI Class Initialized
INFO - 2021-01-22 03:28:10 --> Router Class Initialized
INFO - 2021-01-22 03:28:10 --> Output Class Initialized
INFO - 2021-01-22 03:28:11 --> Security Class Initialized
DEBUG - 2021-01-22 03:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:28:11 --> Input Class Initialized
INFO - 2021-01-22 03:28:11 --> Language Class Initialized
INFO - 2021-01-22 03:28:11 --> Language Class Initialized
INFO - 2021-01-22 03:28:11 --> Config Class Initialized
INFO - 2021-01-22 03:28:11 --> Loader Class Initialized
INFO - 2021-01-22 03:28:11 --> Helper loaded: url_helper
INFO - 2021-01-22 03:28:11 --> Helper loaded: file_helper
INFO - 2021-01-22 03:28:11 --> Helper loaded: form_helper
INFO - 2021-01-22 03:28:11 --> Helper loaded: my_helper
INFO - 2021-01-22 03:28:11 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:28:11 --> Controller Class Initialized
INFO - 2021-01-22 03:28:11 --> Final output sent to browser
DEBUG - 2021-01-22 03:28:11 --> Total execution time: 0.9201
INFO - 2021-01-22 03:28:15 --> Config Class Initialized
INFO - 2021-01-22 03:28:15 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:28:16 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:28:16 --> Utf8 Class Initialized
INFO - 2021-01-22 03:28:16 --> URI Class Initialized
INFO - 2021-01-22 03:28:16 --> Router Class Initialized
INFO - 2021-01-22 03:28:16 --> Output Class Initialized
INFO - 2021-01-22 03:28:16 --> Security Class Initialized
DEBUG - 2021-01-22 03:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:28:16 --> Input Class Initialized
INFO - 2021-01-22 03:28:16 --> Language Class Initialized
INFO - 2021-01-22 03:28:16 --> Language Class Initialized
INFO - 2021-01-22 03:28:16 --> Config Class Initialized
INFO - 2021-01-22 03:28:16 --> Loader Class Initialized
INFO - 2021-01-22 03:28:16 --> Helper loaded: url_helper
INFO - 2021-01-22 03:28:16 --> Helper loaded: file_helper
INFO - 2021-01-22 03:28:16 --> Helper loaded: form_helper
INFO - 2021-01-22 03:28:16 --> Helper loaded: my_helper
INFO - 2021-01-22 03:28:16 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:28:16 --> Controller Class Initialized
DEBUG - 2021-01-22 03:28:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-22 03:28:16 --> Final output sent to browser
DEBUG - 2021-01-22 03:28:16 --> Total execution time: 1.0266
INFO - 2021-01-22 03:38:26 --> Config Class Initialized
INFO - 2021-01-22 03:38:26 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:38:26 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:38:26 --> Utf8 Class Initialized
INFO - 2021-01-22 03:38:26 --> URI Class Initialized
INFO - 2021-01-22 03:38:26 --> Router Class Initialized
INFO - 2021-01-22 03:38:26 --> Output Class Initialized
INFO - 2021-01-22 03:38:26 --> Security Class Initialized
DEBUG - 2021-01-22 03:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:38:26 --> Input Class Initialized
INFO - 2021-01-22 03:38:26 --> Language Class Initialized
ERROR - 2021-01-22 03:38:26 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\nilai\application\modules\n_c_akademik\controllers\N_c_akademik.php 64
INFO - 2021-01-22 03:38:37 --> Config Class Initialized
INFO - 2021-01-22 03:38:37 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:38:37 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:38:37 --> Utf8 Class Initialized
INFO - 2021-01-22 03:38:37 --> URI Class Initialized
INFO - 2021-01-22 03:38:37 --> Router Class Initialized
INFO - 2021-01-22 03:38:37 --> Output Class Initialized
INFO - 2021-01-22 03:38:37 --> Security Class Initialized
DEBUG - 2021-01-22 03:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:38:37 --> Input Class Initialized
INFO - 2021-01-22 03:38:37 --> Language Class Initialized
ERROR - 2021-01-22 03:38:37 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\nilai\application\modules\n_c_akademik\controllers\N_c_akademik.php 64
INFO - 2021-01-22 03:39:38 --> Config Class Initialized
INFO - 2021-01-22 03:39:38 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:39:38 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:39:38 --> Utf8 Class Initialized
INFO - 2021-01-22 03:39:38 --> URI Class Initialized
INFO - 2021-01-22 03:39:38 --> Router Class Initialized
INFO - 2021-01-22 03:39:38 --> Output Class Initialized
INFO - 2021-01-22 03:39:38 --> Security Class Initialized
DEBUG - 2021-01-22 03:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:39:38 --> Input Class Initialized
INFO - 2021-01-22 03:39:38 --> Language Class Initialized
ERROR - 2021-01-22 03:39:38 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\nilai\application\modules\n_c_akademik\controllers\N_c_akademik.php 63
INFO - 2021-01-22 03:41:10 --> Config Class Initialized
INFO - 2021-01-22 03:41:10 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:41:10 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:41:10 --> Utf8 Class Initialized
INFO - 2021-01-22 03:41:11 --> URI Class Initialized
INFO - 2021-01-22 03:41:11 --> Router Class Initialized
INFO - 2021-01-22 03:41:11 --> Output Class Initialized
INFO - 2021-01-22 03:41:11 --> Security Class Initialized
DEBUG - 2021-01-22 03:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:41:11 --> Input Class Initialized
INFO - 2021-01-22 03:41:11 --> Language Class Initialized
ERROR - 2021-01-22 03:41:11 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\nilai\application\modules\n_c_akademik\controllers\N_c_akademik.php 65
INFO - 2021-01-22 03:44:16 --> Config Class Initialized
INFO - 2021-01-22 03:44:16 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:44:16 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:44:16 --> Utf8 Class Initialized
INFO - 2021-01-22 03:44:16 --> URI Class Initialized
INFO - 2021-01-22 03:44:16 --> Router Class Initialized
INFO - 2021-01-22 03:44:16 --> Output Class Initialized
INFO - 2021-01-22 03:44:16 --> Security Class Initialized
DEBUG - 2021-01-22 03:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:44:16 --> Input Class Initialized
INFO - 2021-01-22 03:44:16 --> Language Class Initialized
ERROR - 2021-01-22 03:44:16 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\nilai\application\modules\n_c_akademik\controllers\N_c_akademik.php 65
INFO - 2021-01-22 03:45:38 --> Config Class Initialized
INFO - 2021-01-22 03:45:38 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:45:38 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:45:38 --> Utf8 Class Initialized
INFO - 2021-01-22 03:45:38 --> URI Class Initialized
INFO - 2021-01-22 03:45:38 --> Router Class Initialized
INFO - 2021-01-22 03:45:38 --> Output Class Initialized
INFO - 2021-01-22 03:45:38 --> Security Class Initialized
DEBUG - 2021-01-22 03:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:45:38 --> Input Class Initialized
INFO - 2021-01-22 03:45:38 --> Language Class Initialized
INFO - 2021-01-22 03:45:38 --> Language Class Initialized
INFO - 2021-01-22 03:45:38 --> Config Class Initialized
INFO - 2021-01-22 03:45:38 --> Loader Class Initialized
INFO - 2021-01-22 03:45:38 --> Helper loaded: url_helper
INFO - 2021-01-22 03:45:38 --> Helper loaded: file_helper
INFO - 2021-01-22 03:45:38 --> Helper loaded: form_helper
INFO - 2021-01-22 03:45:38 --> Helper loaded: my_helper
INFO - 2021-01-22 03:45:38 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:45:39 --> Controller Class Initialized
ERROR - 2021-01-22 03:45:39 --> Severity: Parsing Error --> syntax error, unexpected '$sk' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 36
INFO - 2021-01-22 03:46:15 --> Config Class Initialized
INFO - 2021-01-22 03:46:15 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:46:15 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:46:15 --> Utf8 Class Initialized
INFO - 2021-01-22 03:46:16 --> URI Class Initialized
INFO - 2021-01-22 03:46:16 --> Router Class Initialized
INFO - 2021-01-22 03:46:16 --> Output Class Initialized
INFO - 2021-01-22 03:46:16 --> Security Class Initialized
DEBUG - 2021-01-22 03:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:46:16 --> Input Class Initialized
INFO - 2021-01-22 03:46:16 --> Language Class Initialized
INFO - 2021-01-22 03:46:16 --> Language Class Initialized
INFO - 2021-01-22 03:46:16 --> Config Class Initialized
INFO - 2021-01-22 03:46:16 --> Loader Class Initialized
INFO - 2021-01-22 03:46:16 --> Helper loaded: url_helper
INFO - 2021-01-22 03:46:16 --> Helper loaded: file_helper
INFO - 2021-01-22 03:46:16 --> Helper loaded: form_helper
INFO - 2021-01-22 03:46:16 --> Helper loaded: my_helper
INFO - 2021-01-22 03:46:16 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:46:16 --> Controller Class Initialized
ERROR - 2021-01-22 03:46:16 --> Severity: Parsing Error --> syntax error, unexpected '$sk' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 36
INFO - 2021-01-22 03:46:27 --> Config Class Initialized
INFO - 2021-01-22 03:46:27 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:46:27 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:46:27 --> Utf8 Class Initialized
INFO - 2021-01-22 03:46:27 --> URI Class Initialized
INFO - 2021-01-22 03:46:27 --> Router Class Initialized
INFO - 2021-01-22 03:46:27 --> Output Class Initialized
INFO - 2021-01-22 03:46:27 --> Security Class Initialized
DEBUG - 2021-01-22 03:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:46:28 --> Input Class Initialized
INFO - 2021-01-22 03:46:28 --> Language Class Initialized
INFO - 2021-01-22 03:46:28 --> Language Class Initialized
INFO - 2021-01-22 03:46:28 --> Config Class Initialized
INFO - 2021-01-22 03:46:28 --> Loader Class Initialized
INFO - 2021-01-22 03:46:28 --> Helper loaded: url_helper
INFO - 2021-01-22 03:46:28 --> Helper loaded: file_helper
INFO - 2021-01-22 03:46:28 --> Helper loaded: form_helper
INFO - 2021-01-22 03:46:28 --> Helper loaded: my_helper
INFO - 2021-01-22 03:46:28 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:46:28 --> Controller Class Initialized
ERROR - 2021-01-22 03:46:28 --> Severity: Parsing Error --> syntax error, unexpected '$sk' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 36
INFO - 2021-01-22 03:48:31 --> Config Class Initialized
INFO - 2021-01-22 03:48:31 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:48:31 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:48:31 --> Utf8 Class Initialized
INFO - 2021-01-22 03:48:31 --> URI Class Initialized
INFO - 2021-01-22 03:48:31 --> Router Class Initialized
INFO - 2021-01-22 03:48:31 --> Output Class Initialized
INFO - 2021-01-22 03:48:31 --> Security Class Initialized
DEBUG - 2021-01-22 03:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:48:31 --> Input Class Initialized
INFO - 2021-01-22 03:48:31 --> Language Class Initialized
INFO - 2021-01-22 03:48:31 --> Language Class Initialized
INFO - 2021-01-22 03:48:31 --> Config Class Initialized
INFO - 2021-01-22 03:48:31 --> Loader Class Initialized
INFO - 2021-01-22 03:48:31 --> Helper loaded: url_helper
INFO - 2021-01-22 03:48:31 --> Helper loaded: file_helper
INFO - 2021-01-22 03:48:31 --> Helper loaded: form_helper
INFO - 2021-01-22 03:48:32 --> Helper loaded: my_helper
INFO - 2021-01-22 03:48:32 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:48:32 --> Controller Class Initialized
ERROR - 2021-01-22 03:48:32 --> Severity: Parsing Error --> syntax error, unexpected '$sk' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 36
INFO - 2021-01-22 03:48:57 --> Config Class Initialized
INFO - 2021-01-22 03:48:58 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:48:58 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:48:58 --> Utf8 Class Initialized
INFO - 2021-01-22 03:48:58 --> URI Class Initialized
INFO - 2021-01-22 03:48:58 --> Router Class Initialized
INFO - 2021-01-22 03:48:58 --> Output Class Initialized
INFO - 2021-01-22 03:48:58 --> Security Class Initialized
DEBUG - 2021-01-22 03:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:48:58 --> Input Class Initialized
INFO - 2021-01-22 03:48:58 --> Language Class Initialized
INFO - 2021-01-22 03:48:58 --> Language Class Initialized
INFO - 2021-01-22 03:48:58 --> Config Class Initialized
INFO - 2021-01-22 03:48:58 --> Loader Class Initialized
INFO - 2021-01-22 03:48:58 --> Helper loaded: url_helper
INFO - 2021-01-22 03:48:58 --> Helper loaded: file_helper
INFO - 2021-01-22 03:48:58 --> Helper loaded: form_helper
INFO - 2021-01-22 03:48:58 --> Helper loaded: my_helper
INFO - 2021-01-22 03:48:58 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:48:58 --> Controller Class Initialized
DEBUG - 2021-01-22 03:48:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-01-22 03:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:48:59 --> Final output sent to browser
DEBUG - 2021-01-22 03:48:59 --> Total execution time: 1.1200
INFO - 2021-01-22 03:49:03 --> Config Class Initialized
INFO - 2021-01-22 03:49:03 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:49:03 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:49:03 --> Utf8 Class Initialized
INFO - 2021-01-22 03:49:03 --> URI Class Initialized
INFO - 2021-01-22 03:49:03 --> Router Class Initialized
INFO - 2021-01-22 03:49:03 --> Output Class Initialized
INFO - 2021-01-22 03:49:03 --> Security Class Initialized
DEBUG - 2021-01-22 03:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:49:03 --> Input Class Initialized
INFO - 2021-01-22 03:49:03 --> Language Class Initialized
INFO - 2021-01-22 03:49:03 --> Language Class Initialized
INFO - 2021-01-22 03:49:03 --> Config Class Initialized
INFO - 2021-01-22 03:49:03 --> Loader Class Initialized
INFO - 2021-01-22 03:49:03 --> Helper loaded: url_helper
INFO - 2021-01-22 03:49:03 --> Helper loaded: file_helper
INFO - 2021-01-22 03:49:03 --> Helper loaded: form_helper
INFO - 2021-01-22 03:49:03 --> Helper loaded: my_helper
INFO - 2021-01-22 03:49:03 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:49:04 --> Controller Class Initialized
DEBUG - 2021-01-22 03:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 03:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:49:04 --> Final output sent to browser
DEBUG - 2021-01-22 03:49:04 --> Total execution time: 0.7160
INFO - 2021-01-22 03:50:29 --> Config Class Initialized
INFO - 2021-01-22 03:50:29 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:50:29 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:50:29 --> Utf8 Class Initialized
INFO - 2021-01-22 03:50:29 --> URI Class Initialized
INFO - 2021-01-22 03:50:29 --> Router Class Initialized
INFO - 2021-01-22 03:50:29 --> Output Class Initialized
INFO - 2021-01-22 03:50:29 --> Security Class Initialized
DEBUG - 2021-01-22 03:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:50:29 --> Input Class Initialized
INFO - 2021-01-22 03:50:29 --> Language Class Initialized
INFO - 2021-01-22 03:50:29 --> Language Class Initialized
INFO - 2021-01-22 03:50:29 --> Config Class Initialized
INFO - 2021-01-22 03:50:29 --> Loader Class Initialized
INFO - 2021-01-22 03:50:29 --> Helper loaded: url_helper
INFO - 2021-01-22 03:50:29 --> Helper loaded: file_helper
INFO - 2021-01-22 03:50:29 --> Helper loaded: form_helper
INFO - 2021-01-22 03:50:29 --> Helper loaded: my_helper
INFO - 2021-01-22 03:50:29 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:50:30 --> Controller Class Initialized
DEBUG - 2021-01-22 03:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 03:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:50:30 --> Final output sent to browser
DEBUG - 2021-01-22 03:50:30 --> Total execution time: 1.0183
INFO - 2021-01-22 03:52:35 --> Config Class Initialized
INFO - 2021-01-22 03:52:35 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:52:35 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:52:35 --> Utf8 Class Initialized
INFO - 2021-01-22 03:52:35 --> URI Class Initialized
INFO - 2021-01-22 03:52:35 --> Router Class Initialized
INFO - 2021-01-22 03:52:35 --> Output Class Initialized
INFO - 2021-01-22 03:52:35 --> Security Class Initialized
DEBUG - 2021-01-22 03:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:52:35 --> Input Class Initialized
INFO - 2021-01-22 03:52:35 --> Language Class Initialized
INFO - 2021-01-22 03:52:35 --> Language Class Initialized
INFO - 2021-01-22 03:52:35 --> Config Class Initialized
INFO - 2021-01-22 03:52:35 --> Loader Class Initialized
INFO - 2021-01-22 03:52:35 --> Helper loaded: url_helper
INFO - 2021-01-22 03:52:36 --> Helper loaded: file_helper
INFO - 2021-01-22 03:52:36 --> Helper loaded: form_helper
INFO - 2021-01-22 03:52:36 --> Helper loaded: my_helper
INFO - 2021-01-22 03:52:36 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:52:36 --> Controller Class Initialized
DEBUG - 2021-01-22 03:52:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 03:52:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 03:52:36 --> Final output sent to browser
DEBUG - 2021-01-22 03:52:36 --> Total execution time: 0.8027
INFO - 2021-01-22 03:52:46 --> Config Class Initialized
INFO - 2021-01-22 03:52:46 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:52:46 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:52:46 --> Utf8 Class Initialized
INFO - 2021-01-22 03:52:46 --> URI Class Initialized
INFO - 2021-01-22 03:52:46 --> Router Class Initialized
INFO - 2021-01-22 03:52:46 --> Output Class Initialized
INFO - 2021-01-22 03:52:46 --> Security Class Initialized
DEBUG - 2021-01-22 03:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:52:46 --> Input Class Initialized
INFO - 2021-01-22 03:52:46 --> Language Class Initialized
INFO - 2021-01-22 03:52:46 --> Language Class Initialized
INFO - 2021-01-22 03:52:46 --> Config Class Initialized
INFO - 2021-01-22 03:52:46 --> Loader Class Initialized
INFO - 2021-01-22 03:52:46 --> Helper loaded: url_helper
INFO - 2021-01-22 03:52:46 --> Helper loaded: file_helper
INFO - 2021-01-22 03:52:46 --> Helper loaded: form_helper
INFO - 2021-01-22 03:52:46 --> Helper loaded: my_helper
INFO - 2021-01-22 03:52:46 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:52:47 --> Controller Class Initialized
INFO - 2021-01-22 03:52:47 --> Final output sent to browser
DEBUG - 2021-01-22 03:52:47 --> Total execution time: 0.8656
INFO - 2021-01-22 03:52:53 --> Config Class Initialized
INFO - 2021-01-22 03:52:53 --> Hooks Class Initialized
DEBUG - 2021-01-22 03:52:53 --> UTF-8 Support Enabled
INFO - 2021-01-22 03:52:53 --> Utf8 Class Initialized
INFO - 2021-01-22 03:52:53 --> URI Class Initialized
INFO - 2021-01-22 03:52:53 --> Router Class Initialized
INFO - 2021-01-22 03:52:53 --> Output Class Initialized
INFO - 2021-01-22 03:52:53 --> Security Class Initialized
DEBUG - 2021-01-22 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 03:52:53 --> Input Class Initialized
INFO - 2021-01-22 03:52:53 --> Language Class Initialized
INFO - 2021-01-22 03:52:53 --> Language Class Initialized
INFO - 2021-01-22 03:52:53 --> Config Class Initialized
INFO - 2021-01-22 03:52:53 --> Loader Class Initialized
INFO - 2021-01-22 03:52:53 --> Helper loaded: url_helper
INFO - 2021-01-22 03:52:53 --> Helper loaded: file_helper
INFO - 2021-01-22 03:52:53 --> Helper loaded: form_helper
INFO - 2021-01-22 03:52:53 --> Helper loaded: my_helper
INFO - 2021-01-22 03:52:53 --> Database Driver Class Initialized
DEBUG - 2021-01-22 03:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 03:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 03:52:53 --> Controller Class Initialized
DEBUG - 2021-01-22 03:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-22 03:52:53 --> Final output sent to browser
DEBUG - 2021-01-22 03:52:53 --> Total execution time: 0.8128
INFO - 2021-01-22 04:15:16 --> Config Class Initialized
INFO - 2021-01-22 04:15:17 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:15:17 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:15:17 --> Utf8 Class Initialized
INFO - 2021-01-22 04:15:17 --> URI Class Initialized
INFO - 2021-01-22 04:15:17 --> Router Class Initialized
INFO - 2021-01-22 04:15:17 --> Output Class Initialized
INFO - 2021-01-22 04:15:17 --> Security Class Initialized
DEBUG - 2021-01-22 04:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:15:17 --> Input Class Initialized
INFO - 2021-01-22 04:15:17 --> Language Class Initialized
INFO - 2021-01-22 04:15:17 --> Language Class Initialized
INFO - 2021-01-22 04:15:17 --> Config Class Initialized
INFO - 2021-01-22 04:15:17 --> Loader Class Initialized
INFO - 2021-01-22 04:15:17 --> Helper loaded: url_helper
INFO - 2021-01-22 04:15:17 --> Helper loaded: file_helper
INFO - 2021-01-22 04:15:17 --> Helper loaded: form_helper
INFO - 2021-01-22 04:15:17 --> Helper loaded: my_helper
INFO - 2021-01-22 04:15:17 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:15:17 --> Controller Class Initialized
ERROR - 2021-01-22 04:15:17 --> Severity: Parsing Error --> syntax error, unexpected '"required id=catatan_akademik"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 34
INFO - 2021-01-22 04:19:58 --> Config Class Initialized
INFO - 2021-01-22 04:19:58 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:19:58 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:19:58 --> Utf8 Class Initialized
INFO - 2021-01-22 04:19:58 --> URI Class Initialized
INFO - 2021-01-22 04:19:58 --> Router Class Initialized
INFO - 2021-01-22 04:19:58 --> Output Class Initialized
INFO - 2021-01-22 04:19:58 --> Security Class Initialized
DEBUG - 2021-01-22 04:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:19:58 --> Input Class Initialized
INFO - 2021-01-22 04:19:58 --> Language Class Initialized
INFO - 2021-01-22 04:19:58 --> Language Class Initialized
INFO - 2021-01-22 04:19:59 --> Config Class Initialized
INFO - 2021-01-22 04:19:59 --> Loader Class Initialized
INFO - 2021-01-22 04:19:59 --> Helper loaded: url_helper
INFO - 2021-01-22 04:19:59 --> Helper loaded: file_helper
INFO - 2021-01-22 04:19:59 --> Helper loaded: form_helper
INFO - 2021-01-22 04:19:59 --> Helper loaded: my_helper
INFO - 2021-01-22 04:19:59 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:19:59 --> Controller Class Initialized
ERROR - 2021-01-22 04:19:59 --> Severity: Parsing Error --> syntax error, unexpected '$sk' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 36
INFO - 2021-01-22 04:20:11 --> Config Class Initialized
INFO - 2021-01-22 04:20:11 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:20:11 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:20:11 --> Utf8 Class Initialized
INFO - 2021-01-22 04:20:11 --> URI Class Initialized
INFO - 2021-01-22 04:20:11 --> Router Class Initialized
INFO - 2021-01-22 04:20:11 --> Output Class Initialized
INFO - 2021-01-22 04:20:11 --> Security Class Initialized
DEBUG - 2021-01-22 04:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:20:11 --> Input Class Initialized
INFO - 2021-01-22 04:20:11 --> Language Class Initialized
INFO - 2021-01-22 04:20:11 --> Language Class Initialized
INFO - 2021-01-22 04:20:11 --> Config Class Initialized
INFO - 2021-01-22 04:20:11 --> Loader Class Initialized
INFO - 2021-01-22 04:20:11 --> Helper loaded: url_helper
INFO - 2021-01-22 04:20:11 --> Helper loaded: file_helper
INFO - 2021-01-22 04:20:11 --> Helper loaded: form_helper
INFO - 2021-01-22 04:20:11 --> Helper loaded: my_helper
INFO - 2021-01-22 04:20:11 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:20:11 --> Controller Class Initialized
ERROR - 2021-01-22 04:20:11 --> Severity: Parsing Error --> syntax error, unexpected 'form_dropdown' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 36
INFO - 2021-01-22 04:20:27 --> Config Class Initialized
INFO - 2021-01-22 04:20:27 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:20:27 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:20:27 --> Utf8 Class Initialized
INFO - 2021-01-22 04:20:27 --> URI Class Initialized
INFO - 2021-01-22 04:20:27 --> Router Class Initialized
INFO - 2021-01-22 04:20:27 --> Output Class Initialized
INFO - 2021-01-22 04:20:27 --> Security Class Initialized
DEBUG - 2021-01-22 04:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:20:28 --> Input Class Initialized
INFO - 2021-01-22 04:20:28 --> Language Class Initialized
INFO - 2021-01-22 04:20:28 --> Language Class Initialized
INFO - 2021-01-22 04:20:28 --> Config Class Initialized
INFO - 2021-01-22 04:20:28 --> Loader Class Initialized
INFO - 2021-01-22 04:20:28 --> Helper loaded: url_helper
INFO - 2021-01-22 04:20:28 --> Helper loaded: file_helper
INFO - 2021-01-22 04:20:28 --> Helper loaded: form_helper
INFO - 2021-01-22 04:20:28 --> Helper loaded: my_helper
INFO - 2021-01-22 04:20:28 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:20:28 --> Controller Class Initialized
DEBUG - 2021-01-22 04:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 04:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 04:20:28 --> Final output sent to browser
DEBUG - 2021-01-22 04:20:28 --> Total execution time: 1.0946
INFO - 2021-01-22 04:20:38 --> Config Class Initialized
INFO - 2021-01-22 04:20:39 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:20:39 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:20:39 --> Utf8 Class Initialized
INFO - 2021-01-22 04:20:39 --> URI Class Initialized
INFO - 2021-01-22 04:20:39 --> Router Class Initialized
INFO - 2021-01-22 04:20:39 --> Output Class Initialized
INFO - 2021-01-22 04:20:39 --> Security Class Initialized
DEBUG - 2021-01-22 04:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:20:39 --> Input Class Initialized
INFO - 2021-01-22 04:20:39 --> Language Class Initialized
INFO - 2021-01-22 04:20:39 --> Language Class Initialized
INFO - 2021-01-22 04:20:39 --> Config Class Initialized
INFO - 2021-01-22 04:20:39 --> Loader Class Initialized
INFO - 2021-01-22 04:20:39 --> Helper loaded: url_helper
INFO - 2021-01-22 04:20:39 --> Helper loaded: file_helper
INFO - 2021-01-22 04:20:39 --> Helper loaded: form_helper
INFO - 2021-01-22 04:20:39 --> Helper loaded: my_helper
INFO - 2021-01-22 04:20:39 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:20:39 --> Controller Class Initialized
ERROR - 2021-01-22 04:20:39 --> Severity: Parsing Error --> syntax error, unexpected 'form_dropdown' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 36
INFO - 2021-01-22 04:20:57 --> Config Class Initialized
INFO - 2021-01-22 04:20:57 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:20:57 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:20:57 --> Utf8 Class Initialized
INFO - 2021-01-22 04:20:57 --> URI Class Initialized
INFO - 2021-01-22 04:20:57 --> Router Class Initialized
INFO - 2021-01-22 04:20:57 --> Output Class Initialized
INFO - 2021-01-22 04:20:57 --> Security Class Initialized
DEBUG - 2021-01-22 04:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:20:57 --> Input Class Initialized
INFO - 2021-01-22 04:20:57 --> Language Class Initialized
INFO - 2021-01-22 04:20:57 --> Language Class Initialized
INFO - 2021-01-22 04:20:57 --> Config Class Initialized
INFO - 2021-01-22 04:20:57 --> Loader Class Initialized
INFO - 2021-01-22 04:20:57 --> Helper loaded: url_helper
INFO - 2021-01-22 04:20:57 --> Helper loaded: file_helper
INFO - 2021-01-22 04:20:57 --> Helper loaded: form_helper
INFO - 2021-01-22 04:20:57 --> Helper loaded: my_helper
INFO - 2021-01-22 04:20:57 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:20:58 --> Controller Class Initialized
DEBUG - 2021-01-22 04:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 04:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 04:20:58 --> Final output sent to browser
DEBUG - 2021-01-22 04:20:58 --> Total execution time: 0.9294
INFO - 2021-01-22 04:21:52 --> Config Class Initialized
INFO - 2021-01-22 04:21:52 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:21:52 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:21:52 --> Utf8 Class Initialized
INFO - 2021-01-22 04:21:52 --> URI Class Initialized
INFO - 2021-01-22 04:21:52 --> Router Class Initialized
INFO - 2021-01-22 04:21:52 --> Output Class Initialized
INFO - 2021-01-22 04:21:52 --> Security Class Initialized
DEBUG - 2021-01-22 04:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:21:52 --> Input Class Initialized
INFO - 2021-01-22 04:21:52 --> Language Class Initialized
INFO - 2021-01-22 04:21:52 --> Language Class Initialized
INFO - 2021-01-22 04:21:52 --> Config Class Initialized
INFO - 2021-01-22 04:21:52 --> Loader Class Initialized
INFO - 2021-01-22 04:21:52 --> Helper loaded: url_helper
INFO - 2021-01-22 04:21:52 --> Helper loaded: file_helper
INFO - 2021-01-22 04:21:52 --> Helper loaded: form_helper
INFO - 2021-01-22 04:21:52 --> Helper loaded: my_helper
INFO - 2021-01-22 04:21:52 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:21:52 --> Controller Class Initialized
ERROR - 2021-01-22 04:21:52 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\nilai\application\modules\n_c_akademik\controllers\N_c_akademik.php 62
ERROR - 2021-01-22 04:21:53 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\nilai\application\modules\n_c_akademik\controllers\N_c_akademik.php 62
DEBUG - 2021-01-22 04:21:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 04:21:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 04:21:53 --> Final output sent to browser
DEBUG - 2021-01-22 04:21:53 --> Total execution time: 1.1028
INFO - 2021-01-22 04:23:14 --> Config Class Initialized
INFO - 2021-01-22 04:23:14 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:23:14 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:23:14 --> Utf8 Class Initialized
INFO - 2021-01-22 04:23:14 --> URI Class Initialized
INFO - 2021-01-22 04:23:14 --> Router Class Initialized
INFO - 2021-01-22 04:23:14 --> Output Class Initialized
INFO - 2021-01-22 04:23:15 --> Security Class Initialized
DEBUG - 2021-01-22 04:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:23:15 --> Input Class Initialized
INFO - 2021-01-22 04:23:15 --> Language Class Initialized
INFO - 2021-01-22 04:23:15 --> Language Class Initialized
INFO - 2021-01-22 04:23:15 --> Config Class Initialized
INFO - 2021-01-22 04:23:15 --> Loader Class Initialized
INFO - 2021-01-22 04:23:15 --> Helper loaded: url_helper
INFO - 2021-01-22 04:23:15 --> Helper loaded: file_helper
INFO - 2021-01-22 04:23:15 --> Helper loaded: form_helper
INFO - 2021-01-22 04:23:15 --> Helper loaded: my_helper
INFO - 2021-01-22 04:23:15 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:23:15 --> Controller Class Initialized
DEBUG - 2021-01-22 04:23:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 04:23:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 04:23:15 --> Final output sent to browser
DEBUG - 2021-01-22 04:23:15 --> Total execution time: 1.0377
INFO - 2021-01-22 04:29:23 --> Config Class Initialized
INFO - 2021-01-22 04:29:24 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:29:24 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:29:24 --> Utf8 Class Initialized
INFO - 2021-01-22 04:29:24 --> URI Class Initialized
INFO - 2021-01-22 04:29:24 --> Router Class Initialized
INFO - 2021-01-22 04:29:24 --> Output Class Initialized
INFO - 2021-01-22 04:29:24 --> Security Class Initialized
DEBUG - 2021-01-22 04:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:29:24 --> Input Class Initialized
INFO - 2021-01-22 04:29:24 --> Language Class Initialized
INFO - 2021-01-22 04:29:24 --> Language Class Initialized
INFO - 2021-01-22 04:29:24 --> Config Class Initialized
INFO - 2021-01-22 04:29:24 --> Loader Class Initialized
INFO - 2021-01-22 04:29:24 --> Helper loaded: url_helper
INFO - 2021-01-22 04:29:24 --> Helper loaded: file_helper
INFO - 2021-01-22 04:29:24 --> Helper loaded: form_helper
INFO - 2021-01-22 04:29:24 --> Helper loaded: my_helper
INFO - 2021-01-22 04:29:24 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:29:24 --> Controller Class Initialized
DEBUG - 2021-01-22 04:29:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-22 04:29:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-22 04:29:25 --> Final output sent to browser
DEBUG - 2021-01-22 04:29:25 --> Total execution time: 1.0885
INFO - 2021-01-22 04:29:30 --> Config Class Initialized
INFO - 2021-01-22 04:29:30 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:29:30 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:29:30 --> Utf8 Class Initialized
INFO - 2021-01-22 04:29:30 --> URI Class Initialized
INFO - 2021-01-22 04:29:30 --> Router Class Initialized
INFO - 2021-01-22 04:29:30 --> Output Class Initialized
INFO - 2021-01-22 04:29:30 --> Security Class Initialized
DEBUG - 2021-01-22 04:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:29:30 --> Input Class Initialized
INFO - 2021-01-22 04:29:30 --> Language Class Initialized
INFO - 2021-01-22 04:29:30 --> Language Class Initialized
INFO - 2021-01-22 04:29:30 --> Config Class Initialized
INFO - 2021-01-22 04:29:30 --> Loader Class Initialized
INFO - 2021-01-22 04:29:30 --> Helper loaded: url_helper
INFO - 2021-01-22 04:29:30 --> Helper loaded: file_helper
INFO - 2021-01-22 04:29:31 --> Helper loaded: form_helper
INFO - 2021-01-22 04:29:31 --> Helper loaded: my_helper
INFO - 2021-01-22 04:29:31 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:29:31 --> Controller Class Initialized
INFO - 2021-01-22 04:29:31 --> Final output sent to browser
DEBUG - 2021-01-22 04:29:31 --> Total execution time: 1.0057
INFO - 2021-01-22 04:29:34 --> Config Class Initialized
INFO - 2021-01-22 04:29:34 --> Hooks Class Initialized
DEBUG - 2021-01-22 04:29:34 --> UTF-8 Support Enabled
INFO - 2021-01-22 04:29:34 --> Utf8 Class Initialized
INFO - 2021-01-22 04:29:34 --> URI Class Initialized
INFO - 2021-01-22 04:29:34 --> Router Class Initialized
INFO - 2021-01-22 04:29:34 --> Output Class Initialized
INFO - 2021-01-22 04:29:34 --> Security Class Initialized
DEBUG - 2021-01-22 04:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-22 04:29:34 --> Input Class Initialized
INFO - 2021-01-22 04:29:34 --> Language Class Initialized
INFO - 2021-01-22 04:29:34 --> Language Class Initialized
INFO - 2021-01-22 04:29:34 --> Config Class Initialized
INFO - 2021-01-22 04:29:34 --> Loader Class Initialized
INFO - 2021-01-22 04:29:34 --> Helper loaded: url_helper
INFO - 2021-01-22 04:29:34 --> Helper loaded: file_helper
INFO - 2021-01-22 04:29:34 --> Helper loaded: form_helper
INFO - 2021-01-22 04:29:34 --> Helper loaded: my_helper
INFO - 2021-01-22 04:29:34 --> Database Driver Class Initialized
DEBUG - 2021-01-22 04:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-22 04:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-22 04:29:34 --> Controller Class Initialized
DEBUG - 2021-01-22 04:29:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-22 04:29:35 --> Final output sent to browser
DEBUG - 2021-01-22 04:29:35 --> Total execution time: 0.9081
