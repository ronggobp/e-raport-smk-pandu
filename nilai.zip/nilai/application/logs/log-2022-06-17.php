<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-17 08:24:02 --> Config Class Initialized
INFO - 2022-06-17 08:24:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:24:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:24:02 --> Utf8 Class Initialized
INFO - 2022-06-17 08:24:02 --> URI Class Initialized
DEBUG - 2022-06-17 08:24:02 --> No URI present. Default controller set.
INFO - 2022-06-17 08:24:02 --> Router Class Initialized
INFO - 2022-06-17 08:24:02 --> Output Class Initialized
INFO - 2022-06-17 08:24:02 --> Security Class Initialized
DEBUG - 2022-06-17 08:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:24:02 --> Input Class Initialized
INFO - 2022-06-17 08:24:02 --> Language Class Initialized
INFO - 2022-06-17 08:24:03 --> Language Class Initialized
INFO - 2022-06-17 08:24:03 --> Config Class Initialized
INFO - 2022-06-17 08:24:03 --> Loader Class Initialized
INFO - 2022-06-17 08:24:03 --> Helper loaded: url_helper
INFO - 2022-06-17 08:24:03 --> Helper loaded: file_helper
INFO - 2022-06-17 08:24:03 --> Helper loaded: form_helper
INFO - 2022-06-17 08:24:03 --> Helper loaded: my_helper
INFO - 2022-06-17 08:24:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:24:03 --> Controller Class Initialized
INFO - 2022-06-17 08:24:03 --> Config Class Initialized
INFO - 2022-06-17 08:24:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:24:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:24:03 --> Utf8 Class Initialized
INFO - 2022-06-17 08:24:03 --> URI Class Initialized
INFO - 2022-06-17 08:24:03 --> Router Class Initialized
INFO - 2022-06-17 08:24:03 --> Output Class Initialized
INFO - 2022-06-17 08:24:03 --> Security Class Initialized
DEBUG - 2022-06-17 08:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:24:03 --> Input Class Initialized
INFO - 2022-06-17 08:24:03 --> Language Class Initialized
INFO - 2022-06-17 08:24:03 --> Language Class Initialized
INFO - 2022-06-17 08:24:03 --> Config Class Initialized
INFO - 2022-06-17 08:24:03 --> Loader Class Initialized
INFO - 2022-06-17 08:24:03 --> Helper loaded: url_helper
INFO - 2022-06-17 08:24:03 --> Helper loaded: file_helper
INFO - 2022-06-17 08:24:03 --> Helper loaded: form_helper
INFO - 2022-06-17 08:24:03 --> Helper loaded: my_helper
INFO - 2022-06-17 08:24:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:24:03 --> Controller Class Initialized
DEBUG - 2022-06-17 08:24:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 08:24:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:24:03 --> Final output sent to browser
DEBUG - 2022-06-17 08:24:03 --> Total execution time: 0.1031
INFO - 2022-06-17 08:27:02 --> Config Class Initialized
INFO - 2022-06-17 08:27:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:02 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:02 --> URI Class Initialized
INFO - 2022-06-17 08:27:02 --> Router Class Initialized
INFO - 2022-06-17 08:27:02 --> Output Class Initialized
INFO - 2022-06-17 08:27:02 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:02 --> Input Class Initialized
INFO - 2022-06-17 08:27:02 --> Language Class Initialized
INFO - 2022-06-17 08:27:02 --> Language Class Initialized
INFO - 2022-06-17 08:27:02 --> Config Class Initialized
INFO - 2022-06-17 08:27:02 --> Loader Class Initialized
INFO - 2022-06-17 08:27:02 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:02 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:02 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:02 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:02 --> Controller Class Initialized
INFO - 2022-06-17 08:27:02 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:02 --> Total execution time: 0.0477
INFO - 2022-06-17 08:27:05 --> Config Class Initialized
INFO - 2022-06-17 08:27:05 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:05 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:05 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:05 --> URI Class Initialized
INFO - 2022-06-17 08:27:05 --> Router Class Initialized
INFO - 2022-06-17 08:27:05 --> Output Class Initialized
INFO - 2022-06-17 08:27:05 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:05 --> Input Class Initialized
INFO - 2022-06-17 08:27:05 --> Language Class Initialized
INFO - 2022-06-17 08:27:05 --> Language Class Initialized
INFO - 2022-06-17 08:27:05 --> Config Class Initialized
INFO - 2022-06-17 08:27:05 --> Loader Class Initialized
INFO - 2022-06-17 08:27:05 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:05 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:05 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:05 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:05 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:05 --> Controller Class Initialized
INFO - 2022-06-17 08:27:05 --> Helper loaded: cookie_helper
INFO - 2022-06-17 08:27:05 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:05 --> Total execution time: 0.0739
INFO - 2022-06-17 08:27:05 --> Config Class Initialized
INFO - 2022-06-17 08:27:05 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:05 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:05 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:05 --> URI Class Initialized
INFO - 2022-06-17 08:27:05 --> Router Class Initialized
INFO - 2022-06-17 08:27:05 --> Output Class Initialized
INFO - 2022-06-17 08:27:05 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:05 --> Input Class Initialized
INFO - 2022-06-17 08:27:05 --> Language Class Initialized
INFO - 2022-06-17 08:27:05 --> Language Class Initialized
INFO - 2022-06-17 08:27:05 --> Config Class Initialized
INFO - 2022-06-17 08:27:05 --> Loader Class Initialized
INFO - 2022-06-17 08:27:05 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:05 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:05 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:05 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:05 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:05 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:05 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:05 --> Total execution time: 0.1187
INFO - 2022-06-17 08:27:17 --> Config Class Initialized
INFO - 2022-06-17 08:27:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:17 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:17 --> URI Class Initialized
INFO - 2022-06-17 08:27:17 --> Router Class Initialized
INFO - 2022-06-17 08:27:17 --> Output Class Initialized
INFO - 2022-06-17 08:27:17 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:17 --> Input Class Initialized
INFO - 2022-06-17 08:27:17 --> Language Class Initialized
INFO - 2022-06-17 08:27:17 --> Language Class Initialized
INFO - 2022-06-17 08:27:17 --> Config Class Initialized
INFO - 2022-06-17 08:27:17 --> Loader Class Initialized
INFO - 2022-06-17 08:27:17 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:17 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:17 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:17 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:17 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 08:27:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:17 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:17 --> Total execution time: 0.0740
INFO - 2022-06-17 08:27:24 --> Config Class Initialized
INFO - 2022-06-17 08:27:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:24 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:24 --> URI Class Initialized
INFO - 2022-06-17 08:27:24 --> Router Class Initialized
INFO - 2022-06-17 08:27:24 --> Output Class Initialized
INFO - 2022-06-17 08:27:24 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:24 --> Input Class Initialized
INFO - 2022-06-17 08:27:24 --> Language Class Initialized
INFO - 2022-06-17 08:27:24 --> Language Class Initialized
INFO - 2022-06-17 08:27:24 --> Config Class Initialized
INFO - 2022-06-17 08:27:24 --> Loader Class Initialized
INFO - 2022-06-17 08:27:24 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:24 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:24 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:24 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:24 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:24 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:24 --> Total execution time: 0.0935
INFO - 2022-06-17 08:27:24 --> Config Class Initialized
INFO - 2022-06-17 08:27:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:24 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:24 --> URI Class Initialized
INFO - 2022-06-17 08:27:24 --> Router Class Initialized
INFO - 2022-06-17 08:27:24 --> Output Class Initialized
INFO - 2022-06-17 08:27:24 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:24 --> Input Class Initialized
INFO - 2022-06-17 08:27:24 --> Language Class Initialized
INFO - 2022-06-17 08:27:24 --> Language Class Initialized
INFO - 2022-06-17 08:27:24 --> Config Class Initialized
INFO - 2022-06-17 08:27:24 --> Loader Class Initialized
INFO - 2022-06-17 08:27:24 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:24 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:24 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:24 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:24 --> Controller Class Initialized
INFO - 2022-06-17 08:27:26 --> Config Class Initialized
INFO - 2022-06-17 08:27:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:26 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:26 --> URI Class Initialized
INFO - 2022-06-17 08:27:26 --> Router Class Initialized
INFO - 2022-06-17 08:27:26 --> Output Class Initialized
INFO - 2022-06-17 08:27:26 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:26 --> Input Class Initialized
INFO - 2022-06-17 08:27:26 --> Language Class Initialized
INFO - 2022-06-17 08:27:26 --> Language Class Initialized
INFO - 2022-06-17 08:27:26 --> Config Class Initialized
INFO - 2022-06-17 08:27:26 --> Loader Class Initialized
INFO - 2022-06-17 08:27:26 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:26 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:26 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:26 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:26 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:27:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:26 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:26 --> Total execution time: 0.0999
INFO - 2022-06-17 08:27:28 --> Config Class Initialized
INFO - 2022-06-17 08:27:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:28 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:28 --> URI Class Initialized
INFO - 2022-06-17 08:27:28 --> Router Class Initialized
INFO - 2022-06-17 08:27:28 --> Output Class Initialized
INFO - 2022-06-17 08:27:28 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:28 --> Input Class Initialized
INFO - 2022-06-17 08:27:28 --> Language Class Initialized
INFO - 2022-06-17 08:27:28 --> Language Class Initialized
INFO - 2022-06-17 08:27:28 --> Config Class Initialized
INFO - 2022-06-17 08:27:28 --> Loader Class Initialized
INFO - 2022-06-17 08:27:28 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:28 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:28 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:28 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:28 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:28 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:28 --> Total execution time: 0.0652
INFO - 2022-06-17 08:27:35 --> Config Class Initialized
INFO - 2022-06-17 08:27:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:35 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:35 --> URI Class Initialized
INFO - 2022-06-17 08:27:35 --> Router Class Initialized
INFO - 2022-06-17 08:27:35 --> Output Class Initialized
INFO - 2022-06-17 08:27:35 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:35 --> Input Class Initialized
INFO - 2022-06-17 08:27:35 --> Language Class Initialized
INFO - 2022-06-17 08:27:35 --> Language Class Initialized
INFO - 2022-06-17 08:27:35 --> Config Class Initialized
INFO - 2022-06-17 08:27:35 --> Loader Class Initialized
INFO - 2022-06-17 08:27:35 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:35 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:35 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:35 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:35 --> Controller Class Initialized
INFO - 2022-06-17 08:27:36 --> Config Class Initialized
INFO - 2022-06-17 08:27:36 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:36 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:36 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:36 --> URI Class Initialized
INFO - 2022-06-17 08:27:36 --> Router Class Initialized
INFO - 2022-06-17 08:27:36 --> Output Class Initialized
INFO - 2022-06-17 08:27:36 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:36 --> Input Class Initialized
INFO - 2022-06-17 08:27:36 --> Language Class Initialized
INFO - 2022-06-17 08:27:36 --> Language Class Initialized
INFO - 2022-06-17 08:27:36 --> Config Class Initialized
INFO - 2022-06-17 08:27:36 --> Loader Class Initialized
INFO - 2022-06-17 08:27:36 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:36 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:36 --> Controller Class Initialized
INFO - 2022-06-17 08:27:36 --> Config Class Initialized
INFO - 2022-06-17 08:27:36 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:36 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:36 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:36 --> URI Class Initialized
INFO - 2022-06-17 08:27:36 --> Router Class Initialized
INFO - 2022-06-17 08:27:36 --> Output Class Initialized
INFO - 2022-06-17 08:27:36 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:36 --> Input Class Initialized
INFO - 2022-06-17 08:27:36 --> Language Class Initialized
INFO - 2022-06-17 08:27:36 --> Language Class Initialized
INFO - 2022-06-17 08:27:36 --> Config Class Initialized
INFO - 2022-06-17 08:27:36 --> Loader Class Initialized
INFO - 2022-06-17 08:27:36 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:36 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:36 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:36 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:36 --> Total execution time: 0.0541
INFO - 2022-06-17 08:27:36 --> Config Class Initialized
INFO - 2022-06-17 08:27:36 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:36 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:36 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:36 --> URI Class Initialized
INFO - 2022-06-17 08:27:36 --> Router Class Initialized
INFO - 2022-06-17 08:27:36 --> Output Class Initialized
INFO - 2022-06-17 08:27:36 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:36 --> Input Class Initialized
INFO - 2022-06-17 08:27:36 --> Language Class Initialized
INFO - 2022-06-17 08:27:36 --> Language Class Initialized
INFO - 2022-06-17 08:27:36 --> Config Class Initialized
INFO - 2022-06-17 08:27:36 --> Loader Class Initialized
INFO - 2022-06-17 08:27:36 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:36 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:36 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:36 --> Controller Class Initialized
INFO - 2022-06-17 08:27:38 --> Config Class Initialized
INFO - 2022-06-17 08:27:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:38 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:38 --> URI Class Initialized
INFO - 2022-06-17 08:27:38 --> Router Class Initialized
INFO - 2022-06-17 08:27:38 --> Output Class Initialized
INFO - 2022-06-17 08:27:38 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:38 --> Input Class Initialized
INFO - 2022-06-17 08:27:38 --> Language Class Initialized
INFO - 2022-06-17 08:27:38 --> Language Class Initialized
INFO - 2022-06-17 08:27:38 --> Config Class Initialized
INFO - 2022-06-17 08:27:38 --> Loader Class Initialized
INFO - 2022-06-17 08:27:38 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:38 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:38 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:38 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:38 --> Controller Class Initialized
INFO - 2022-06-17 08:27:38 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:38 --> Total execution time: 0.0504
INFO - 2022-06-17 08:27:40 --> Config Class Initialized
INFO - 2022-06-17 08:27:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:40 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:40 --> URI Class Initialized
INFO - 2022-06-17 08:27:40 --> Router Class Initialized
INFO - 2022-06-17 08:27:40 --> Output Class Initialized
INFO - 2022-06-17 08:27:40 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:40 --> Input Class Initialized
INFO - 2022-06-17 08:27:40 --> Language Class Initialized
INFO - 2022-06-17 08:27:40 --> Language Class Initialized
INFO - 2022-06-17 08:27:40 --> Config Class Initialized
INFO - 2022-06-17 08:27:40 --> Loader Class Initialized
INFO - 2022-06-17 08:27:40 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:40 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:40 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:40 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:40 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:40 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:40 --> Total execution time: 0.0521
INFO - 2022-06-17 08:27:43 --> Config Class Initialized
INFO - 2022-06-17 08:27:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:43 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:43 --> URI Class Initialized
INFO - 2022-06-17 08:27:43 --> Router Class Initialized
INFO - 2022-06-17 08:27:43 --> Output Class Initialized
INFO - 2022-06-17 08:27:43 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:43 --> Input Class Initialized
INFO - 2022-06-17 08:27:43 --> Language Class Initialized
INFO - 2022-06-17 08:27:43 --> Language Class Initialized
INFO - 2022-06-17 08:27:43 --> Config Class Initialized
INFO - 2022-06-17 08:27:43 --> Loader Class Initialized
INFO - 2022-06-17 08:27:43 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:43 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:43 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:43 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:43 --> Controller Class Initialized
INFO - 2022-06-17 08:27:43 --> Config Class Initialized
INFO - 2022-06-17 08:27:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:43 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:43 --> URI Class Initialized
INFO - 2022-06-17 08:27:43 --> Router Class Initialized
INFO - 2022-06-17 08:27:43 --> Output Class Initialized
INFO - 2022-06-17 08:27:43 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:43 --> Input Class Initialized
INFO - 2022-06-17 08:27:43 --> Language Class Initialized
INFO - 2022-06-17 08:27:43 --> Language Class Initialized
INFO - 2022-06-17 08:27:43 --> Config Class Initialized
INFO - 2022-06-17 08:27:43 --> Loader Class Initialized
INFO - 2022-06-17 08:27:43 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:43 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:43 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:43 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:43 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:43 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:43 --> Total execution time: 0.0537
INFO - 2022-06-17 08:27:57 --> Config Class Initialized
INFO - 2022-06-17 08:27:57 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:57 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:57 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:57 --> URI Class Initialized
INFO - 2022-06-17 08:27:57 --> Router Class Initialized
INFO - 2022-06-17 08:27:57 --> Output Class Initialized
INFO - 2022-06-17 08:27:57 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:57 --> Input Class Initialized
INFO - 2022-06-17 08:27:57 --> Language Class Initialized
INFO - 2022-06-17 08:27:57 --> Language Class Initialized
INFO - 2022-06-17 08:27:57 --> Config Class Initialized
INFO - 2022-06-17 08:27:57 --> Loader Class Initialized
INFO - 2022-06-17 08:27:57 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:57 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:57 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:57 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:57 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:57 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:57 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:57 --> Total execution time: 0.0464
INFO - 2022-06-17 08:27:58 --> Config Class Initialized
INFO - 2022-06-17 08:27:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:58 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:58 --> URI Class Initialized
INFO - 2022-06-17 08:27:58 --> Router Class Initialized
INFO - 2022-06-17 08:27:58 --> Output Class Initialized
INFO - 2022-06-17 08:27:58 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:58 --> Input Class Initialized
INFO - 2022-06-17 08:27:58 --> Language Class Initialized
INFO - 2022-06-17 08:27:58 --> Language Class Initialized
INFO - 2022-06-17 08:27:58 --> Config Class Initialized
INFO - 2022-06-17 08:27:58 --> Loader Class Initialized
INFO - 2022-06-17 08:27:58 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:58 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:58 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:58 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:58 --> Controller Class Initialized
INFO - 2022-06-17 08:27:59 --> Config Class Initialized
INFO - 2022-06-17 08:27:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:27:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:27:59 --> Utf8 Class Initialized
INFO - 2022-06-17 08:27:59 --> URI Class Initialized
INFO - 2022-06-17 08:27:59 --> Router Class Initialized
INFO - 2022-06-17 08:27:59 --> Output Class Initialized
INFO - 2022-06-17 08:27:59 --> Security Class Initialized
DEBUG - 2022-06-17 08:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:27:59 --> Input Class Initialized
INFO - 2022-06-17 08:27:59 --> Language Class Initialized
INFO - 2022-06-17 08:27:59 --> Language Class Initialized
INFO - 2022-06-17 08:27:59 --> Config Class Initialized
INFO - 2022-06-17 08:27:59 --> Loader Class Initialized
INFO - 2022-06-17 08:27:59 --> Helper loaded: url_helper
INFO - 2022-06-17 08:27:59 --> Helper loaded: file_helper
INFO - 2022-06-17 08:27:59 --> Helper loaded: form_helper
INFO - 2022-06-17 08:27:59 --> Helper loaded: my_helper
INFO - 2022-06-17 08:27:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:27:59 --> Controller Class Initialized
DEBUG - 2022-06-17 08:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:27:59 --> Final output sent to browser
DEBUG - 2022-06-17 08:27:59 --> Total execution time: 0.0459
INFO - 2022-06-17 08:28:01 --> Config Class Initialized
INFO - 2022-06-17 08:28:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:01 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:01 --> URI Class Initialized
INFO - 2022-06-17 08:28:01 --> Router Class Initialized
INFO - 2022-06-17 08:28:01 --> Output Class Initialized
INFO - 2022-06-17 08:28:01 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:01 --> Input Class Initialized
INFO - 2022-06-17 08:28:01 --> Language Class Initialized
INFO - 2022-06-17 08:28:01 --> Language Class Initialized
INFO - 2022-06-17 08:28:01 --> Config Class Initialized
INFO - 2022-06-17 08:28:01 --> Loader Class Initialized
INFO - 2022-06-17 08:28:01 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:01 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:01 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:01 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:01 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:28:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:01 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:01 --> Total execution time: 0.0431
INFO - 2022-06-17 08:28:06 --> Config Class Initialized
INFO - 2022-06-17 08:28:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:06 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:06 --> URI Class Initialized
INFO - 2022-06-17 08:28:06 --> Router Class Initialized
INFO - 2022-06-17 08:28:06 --> Output Class Initialized
INFO - 2022-06-17 08:28:06 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:06 --> Input Class Initialized
INFO - 2022-06-17 08:28:06 --> Language Class Initialized
INFO - 2022-06-17 08:28:06 --> Language Class Initialized
INFO - 2022-06-17 08:28:06 --> Config Class Initialized
INFO - 2022-06-17 08:28:06 --> Loader Class Initialized
INFO - 2022-06-17 08:28:06 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:06 --> Controller Class Initialized
INFO - 2022-06-17 08:28:06 --> Config Class Initialized
INFO - 2022-06-17 08:28:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:06 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:06 --> URI Class Initialized
INFO - 2022-06-17 08:28:06 --> Router Class Initialized
INFO - 2022-06-17 08:28:06 --> Output Class Initialized
INFO - 2022-06-17 08:28:06 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:06 --> Input Class Initialized
INFO - 2022-06-17 08:28:06 --> Language Class Initialized
INFO - 2022-06-17 08:28:06 --> Language Class Initialized
INFO - 2022-06-17 08:28:06 --> Config Class Initialized
INFO - 2022-06-17 08:28:06 --> Loader Class Initialized
INFO - 2022-06-17 08:28:06 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:06 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:06 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:06 --> Total execution time: 0.0462
INFO - 2022-06-17 08:28:06 --> Config Class Initialized
INFO - 2022-06-17 08:28:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:06 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:06 --> URI Class Initialized
INFO - 2022-06-17 08:28:06 --> Router Class Initialized
INFO - 2022-06-17 08:28:06 --> Output Class Initialized
INFO - 2022-06-17 08:28:06 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:06 --> Input Class Initialized
INFO - 2022-06-17 08:28:06 --> Language Class Initialized
INFO - 2022-06-17 08:28:06 --> Language Class Initialized
INFO - 2022-06-17 08:28:06 --> Config Class Initialized
INFO - 2022-06-17 08:28:06 --> Loader Class Initialized
INFO - 2022-06-17 08:28:06 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:06 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:06 --> Controller Class Initialized
INFO - 2022-06-17 08:28:08 --> Config Class Initialized
INFO - 2022-06-17 08:28:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:08 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:08 --> URI Class Initialized
INFO - 2022-06-17 08:28:08 --> Router Class Initialized
INFO - 2022-06-17 08:28:08 --> Output Class Initialized
INFO - 2022-06-17 08:28:08 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:08 --> Input Class Initialized
INFO - 2022-06-17 08:28:08 --> Language Class Initialized
INFO - 2022-06-17 08:28:08 --> Language Class Initialized
INFO - 2022-06-17 08:28:08 --> Config Class Initialized
INFO - 2022-06-17 08:28:08 --> Loader Class Initialized
INFO - 2022-06-17 08:28:08 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:08 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:08 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:08 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:08 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:28:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:08 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:08 --> Total execution time: 0.0440
INFO - 2022-06-17 08:28:11 --> Config Class Initialized
INFO - 2022-06-17 08:28:11 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:11 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:11 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:11 --> URI Class Initialized
INFO - 2022-06-17 08:28:11 --> Router Class Initialized
INFO - 2022-06-17 08:28:11 --> Output Class Initialized
INFO - 2022-06-17 08:28:11 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:11 --> Input Class Initialized
INFO - 2022-06-17 08:28:11 --> Language Class Initialized
INFO - 2022-06-17 08:28:11 --> Language Class Initialized
INFO - 2022-06-17 08:28:11 --> Config Class Initialized
INFO - 2022-06-17 08:28:11 --> Loader Class Initialized
INFO - 2022-06-17 08:28:11 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:11 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:11 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:11 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:11 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:11 --> Controller Class Initialized
INFO - 2022-06-17 08:28:11 --> Config Class Initialized
INFO - 2022-06-17 08:28:11 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:11 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:11 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:11 --> URI Class Initialized
INFO - 2022-06-17 08:28:11 --> Router Class Initialized
INFO - 2022-06-17 08:28:11 --> Output Class Initialized
INFO - 2022-06-17 08:28:11 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:11 --> Input Class Initialized
INFO - 2022-06-17 08:28:11 --> Language Class Initialized
INFO - 2022-06-17 08:28:11 --> Language Class Initialized
INFO - 2022-06-17 08:28:11 --> Config Class Initialized
INFO - 2022-06-17 08:28:11 --> Loader Class Initialized
INFO - 2022-06-17 08:28:11 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:11 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:11 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:11 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:11 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:11 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:28:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:11 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:11 --> Total execution time: 0.0441
INFO - 2022-06-17 08:28:28 --> Config Class Initialized
INFO - 2022-06-17 08:28:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:28 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:28 --> URI Class Initialized
INFO - 2022-06-17 08:28:28 --> Router Class Initialized
INFO - 2022-06-17 08:28:28 --> Output Class Initialized
INFO - 2022-06-17 08:28:28 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:28 --> Input Class Initialized
INFO - 2022-06-17 08:28:28 --> Language Class Initialized
INFO - 2022-06-17 08:28:28 --> Language Class Initialized
INFO - 2022-06-17 08:28:28 --> Config Class Initialized
INFO - 2022-06-17 08:28:28 --> Loader Class Initialized
INFO - 2022-06-17 08:28:28 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:28 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:28 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:28 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:28 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:28 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:28 --> Total execution time: 0.0480
INFO - 2022-06-17 08:28:28 --> Config Class Initialized
INFO - 2022-06-17 08:28:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:28 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:28 --> URI Class Initialized
INFO - 2022-06-17 08:28:28 --> Router Class Initialized
INFO - 2022-06-17 08:28:28 --> Output Class Initialized
INFO - 2022-06-17 08:28:28 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:28 --> Input Class Initialized
INFO - 2022-06-17 08:28:28 --> Language Class Initialized
INFO - 2022-06-17 08:28:28 --> Language Class Initialized
INFO - 2022-06-17 08:28:28 --> Config Class Initialized
INFO - 2022-06-17 08:28:28 --> Loader Class Initialized
INFO - 2022-06-17 08:28:28 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:28 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:28 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:28 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:28 --> Controller Class Initialized
INFO - 2022-06-17 08:28:29 --> Config Class Initialized
INFO - 2022-06-17 08:28:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:29 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:29 --> URI Class Initialized
INFO - 2022-06-17 08:28:29 --> Router Class Initialized
INFO - 2022-06-17 08:28:29 --> Output Class Initialized
INFO - 2022-06-17 08:28:29 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:29 --> Input Class Initialized
INFO - 2022-06-17 08:28:29 --> Language Class Initialized
INFO - 2022-06-17 08:28:29 --> Language Class Initialized
INFO - 2022-06-17 08:28:29 --> Config Class Initialized
INFO - 2022-06-17 08:28:29 --> Loader Class Initialized
INFO - 2022-06-17 08:28:29 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:29 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:29 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:29 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:29 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:29 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:29 --> Total execution time: 0.0477
INFO - 2022-06-17 08:28:30 --> Config Class Initialized
INFO - 2022-06-17 08:28:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:30 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:30 --> URI Class Initialized
INFO - 2022-06-17 08:28:30 --> Router Class Initialized
INFO - 2022-06-17 08:28:30 --> Output Class Initialized
INFO - 2022-06-17 08:28:30 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:30 --> Input Class Initialized
INFO - 2022-06-17 08:28:30 --> Language Class Initialized
INFO - 2022-06-17 08:28:30 --> Language Class Initialized
INFO - 2022-06-17 08:28:30 --> Config Class Initialized
INFO - 2022-06-17 08:28:30 --> Loader Class Initialized
INFO - 2022-06-17 08:28:30 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:30 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:30 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:30 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:30 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:30 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:30 --> Total execution time: 0.0478
INFO - 2022-06-17 08:28:30 --> Config Class Initialized
INFO - 2022-06-17 08:28:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:30 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:30 --> URI Class Initialized
INFO - 2022-06-17 08:28:30 --> Router Class Initialized
INFO - 2022-06-17 08:28:30 --> Output Class Initialized
INFO - 2022-06-17 08:28:30 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:30 --> Input Class Initialized
INFO - 2022-06-17 08:28:30 --> Language Class Initialized
INFO - 2022-06-17 08:28:30 --> Language Class Initialized
INFO - 2022-06-17 08:28:30 --> Config Class Initialized
INFO - 2022-06-17 08:28:30 --> Loader Class Initialized
INFO - 2022-06-17 08:28:30 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:30 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:30 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:30 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:30 --> Controller Class Initialized
INFO - 2022-06-17 08:28:31 --> Config Class Initialized
INFO - 2022-06-17 08:28:31 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:31 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:31 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:31 --> URI Class Initialized
INFO - 2022-06-17 08:28:31 --> Router Class Initialized
INFO - 2022-06-17 08:28:31 --> Output Class Initialized
INFO - 2022-06-17 08:28:31 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:31 --> Input Class Initialized
INFO - 2022-06-17 08:28:31 --> Language Class Initialized
INFO - 2022-06-17 08:28:31 --> Language Class Initialized
INFO - 2022-06-17 08:28:31 --> Config Class Initialized
INFO - 2022-06-17 08:28:31 --> Loader Class Initialized
INFO - 2022-06-17 08:28:31 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:31 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:31 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:31 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:31 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:31 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:31 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:31 --> Total execution time: 0.0465
INFO - 2022-06-17 08:28:34 --> Config Class Initialized
INFO - 2022-06-17 08:28:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:34 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:34 --> URI Class Initialized
INFO - 2022-06-17 08:28:34 --> Router Class Initialized
INFO - 2022-06-17 08:28:34 --> Output Class Initialized
INFO - 2022-06-17 08:28:34 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:34 --> Input Class Initialized
INFO - 2022-06-17 08:28:34 --> Language Class Initialized
INFO - 2022-06-17 08:28:34 --> Language Class Initialized
INFO - 2022-06-17 08:28:34 --> Config Class Initialized
INFO - 2022-06-17 08:28:34 --> Loader Class Initialized
INFO - 2022-06-17 08:28:34 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:34 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:34 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:34 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:34 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:34 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:34 --> Total execution time: 0.0457
INFO - 2022-06-17 08:28:34 --> Config Class Initialized
INFO - 2022-06-17 08:28:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:34 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:34 --> URI Class Initialized
INFO - 2022-06-17 08:28:34 --> Router Class Initialized
INFO - 2022-06-17 08:28:34 --> Output Class Initialized
INFO - 2022-06-17 08:28:34 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:34 --> Input Class Initialized
INFO - 2022-06-17 08:28:34 --> Language Class Initialized
INFO - 2022-06-17 08:28:34 --> Language Class Initialized
INFO - 2022-06-17 08:28:34 --> Config Class Initialized
INFO - 2022-06-17 08:28:34 --> Loader Class Initialized
INFO - 2022-06-17 08:28:34 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:34 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:34 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:34 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:34 --> Controller Class Initialized
INFO - 2022-06-17 08:28:35 --> Config Class Initialized
INFO - 2022-06-17 08:28:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:35 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:35 --> URI Class Initialized
INFO - 2022-06-17 08:28:35 --> Router Class Initialized
INFO - 2022-06-17 08:28:35 --> Output Class Initialized
INFO - 2022-06-17 08:28:35 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:35 --> Input Class Initialized
INFO - 2022-06-17 08:28:35 --> Language Class Initialized
INFO - 2022-06-17 08:28:35 --> Language Class Initialized
INFO - 2022-06-17 08:28:35 --> Config Class Initialized
INFO - 2022-06-17 08:28:35 --> Loader Class Initialized
INFO - 2022-06-17 08:28:35 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:35 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:35 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:35 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:35 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:35 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:35 --> Total execution time: 0.0469
INFO - 2022-06-17 08:28:49 --> Config Class Initialized
INFO - 2022-06-17 08:28:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:49 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:49 --> URI Class Initialized
INFO - 2022-06-17 08:28:49 --> Router Class Initialized
INFO - 2022-06-17 08:28:49 --> Output Class Initialized
INFO - 2022-06-17 08:28:49 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:49 --> Input Class Initialized
INFO - 2022-06-17 08:28:49 --> Language Class Initialized
INFO - 2022-06-17 08:28:49 --> Language Class Initialized
INFO - 2022-06-17 08:28:49 --> Config Class Initialized
INFO - 2022-06-17 08:28:49 --> Loader Class Initialized
INFO - 2022-06-17 08:28:49 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:49 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:49 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:49 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:49 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:49 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:49 --> Total execution time: 0.0467
INFO - 2022-06-17 08:28:49 --> Config Class Initialized
INFO - 2022-06-17 08:28:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:49 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:49 --> URI Class Initialized
INFO - 2022-06-17 08:28:49 --> Router Class Initialized
INFO - 2022-06-17 08:28:49 --> Output Class Initialized
INFO - 2022-06-17 08:28:49 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:49 --> Input Class Initialized
INFO - 2022-06-17 08:28:49 --> Language Class Initialized
INFO - 2022-06-17 08:28:49 --> Language Class Initialized
INFO - 2022-06-17 08:28:49 --> Config Class Initialized
INFO - 2022-06-17 08:28:49 --> Loader Class Initialized
INFO - 2022-06-17 08:28:49 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:49 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:49 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:49 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:49 --> Controller Class Initialized
INFO - 2022-06-17 08:28:50 --> Config Class Initialized
INFO - 2022-06-17 08:28:50 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:50 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:50 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:50 --> URI Class Initialized
INFO - 2022-06-17 08:28:50 --> Router Class Initialized
INFO - 2022-06-17 08:28:50 --> Output Class Initialized
INFO - 2022-06-17 08:28:50 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:50 --> Input Class Initialized
INFO - 2022-06-17 08:28:50 --> Language Class Initialized
INFO - 2022-06-17 08:28:50 --> Language Class Initialized
INFO - 2022-06-17 08:28:50 --> Config Class Initialized
INFO - 2022-06-17 08:28:50 --> Loader Class Initialized
INFO - 2022-06-17 08:28:50 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:50 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:50 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:50 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:50 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:50 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:28:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:50 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:50 --> Total execution time: 0.0459
INFO - 2022-06-17 08:28:59 --> Config Class Initialized
INFO - 2022-06-17 08:28:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:59 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:59 --> URI Class Initialized
INFO - 2022-06-17 08:28:59 --> Router Class Initialized
INFO - 2022-06-17 08:28:59 --> Output Class Initialized
INFO - 2022-06-17 08:28:59 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:59 --> Input Class Initialized
INFO - 2022-06-17 08:28:59 --> Language Class Initialized
INFO - 2022-06-17 08:28:59 --> Language Class Initialized
INFO - 2022-06-17 08:28:59 --> Config Class Initialized
INFO - 2022-06-17 08:28:59 --> Loader Class Initialized
INFO - 2022-06-17 08:28:59 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:59 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:59 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:59 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:59 --> Controller Class Initialized
DEBUG - 2022-06-17 08:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:28:59 --> Final output sent to browser
DEBUG - 2022-06-17 08:28:59 --> Total execution time: 0.0479
INFO - 2022-06-17 08:28:59 --> Config Class Initialized
INFO - 2022-06-17 08:28:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:28:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:28:59 --> Utf8 Class Initialized
INFO - 2022-06-17 08:28:59 --> URI Class Initialized
INFO - 2022-06-17 08:28:59 --> Router Class Initialized
INFO - 2022-06-17 08:28:59 --> Output Class Initialized
INFO - 2022-06-17 08:28:59 --> Security Class Initialized
DEBUG - 2022-06-17 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:28:59 --> Input Class Initialized
INFO - 2022-06-17 08:28:59 --> Language Class Initialized
INFO - 2022-06-17 08:28:59 --> Language Class Initialized
INFO - 2022-06-17 08:28:59 --> Config Class Initialized
INFO - 2022-06-17 08:28:59 --> Loader Class Initialized
INFO - 2022-06-17 08:28:59 --> Helper loaded: url_helper
INFO - 2022-06-17 08:28:59 --> Helper loaded: file_helper
INFO - 2022-06-17 08:28:59 --> Helper loaded: form_helper
INFO - 2022-06-17 08:28:59 --> Helper loaded: my_helper
INFO - 2022-06-17 08:28:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:28:59 --> Controller Class Initialized
INFO - 2022-06-17 08:29:01 --> Config Class Initialized
INFO - 2022-06-17 08:29:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:01 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:01 --> URI Class Initialized
INFO - 2022-06-17 08:29:01 --> Router Class Initialized
INFO - 2022-06-17 08:29:01 --> Output Class Initialized
INFO - 2022-06-17 08:29:01 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:01 --> Input Class Initialized
INFO - 2022-06-17 08:29:01 --> Language Class Initialized
INFO - 2022-06-17 08:29:01 --> Language Class Initialized
INFO - 2022-06-17 08:29:01 --> Config Class Initialized
INFO - 2022-06-17 08:29:01 --> Loader Class Initialized
INFO - 2022-06-17 08:29:01 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:01 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:01 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:01 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:01 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:29:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:01 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:01 --> Total execution time: 0.0474
INFO - 2022-06-17 08:29:03 --> Config Class Initialized
INFO - 2022-06-17 08:29:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:03 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:03 --> URI Class Initialized
INFO - 2022-06-17 08:29:03 --> Router Class Initialized
INFO - 2022-06-17 08:29:03 --> Output Class Initialized
INFO - 2022-06-17 08:29:03 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:03 --> Input Class Initialized
INFO - 2022-06-17 08:29:03 --> Language Class Initialized
INFO - 2022-06-17 08:29:03 --> Language Class Initialized
INFO - 2022-06-17 08:29:03 --> Config Class Initialized
INFO - 2022-06-17 08:29:03 --> Loader Class Initialized
INFO - 2022-06-17 08:29:03 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:03 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:03 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:03 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:03 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:29:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:03 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:03 --> Total execution time: 0.0480
INFO - 2022-06-17 08:29:03 --> Config Class Initialized
INFO - 2022-06-17 08:29:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:03 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:03 --> URI Class Initialized
INFO - 2022-06-17 08:29:03 --> Router Class Initialized
INFO - 2022-06-17 08:29:03 --> Output Class Initialized
INFO - 2022-06-17 08:29:03 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:03 --> Input Class Initialized
INFO - 2022-06-17 08:29:03 --> Language Class Initialized
INFO - 2022-06-17 08:29:03 --> Language Class Initialized
INFO - 2022-06-17 08:29:03 --> Config Class Initialized
INFO - 2022-06-17 08:29:03 --> Loader Class Initialized
INFO - 2022-06-17 08:29:03 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:03 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:03 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:03 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:03 --> Controller Class Initialized
INFO - 2022-06-17 08:29:04 --> Config Class Initialized
INFO - 2022-06-17 08:29:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:04 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:04 --> URI Class Initialized
INFO - 2022-06-17 08:29:04 --> Router Class Initialized
INFO - 2022-06-17 08:29:04 --> Output Class Initialized
INFO - 2022-06-17 08:29:04 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:04 --> Input Class Initialized
INFO - 2022-06-17 08:29:04 --> Language Class Initialized
INFO - 2022-06-17 08:29:04 --> Language Class Initialized
INFO - 2022-06-17 08:29:04 --> Config Class Initialized
INFO - 2022-06-17 08:29:04 --> Loader Class Initialized
INFO - 2022-06-17 08:29:04 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:04 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:04 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:04 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:04 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:04 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:04 --> Total execution time: 0.0502
INFO - 2022-06-17 08:29:21 --> Config Class Initialized
INFO - 2022-06-17 08:29:21 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:21 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:21 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:21 --> URI Class Initialized
INFO - 2022-06-17 08:29:21 --> Router Class Initialized
INFO - 2022-06-17 08:29:21 --> Output Class Initialized
INFO - 2022-06-17 08:29:21 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:21 --> Input Class Initialized
INFO - 2022-06-17 08:29:21 --> Language Class Initialized
INFO - 2022-06-17 08:29:21 --> Language Class Initialized
INFO - 2022-06-17 08:29:21 --> Config Class Initialized
INFO - 2022-06-17 08:29:21 --> Loader Class Initialized
INFO - 2022-06-17 08:29:21 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:21 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:21 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:21 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:21 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:21 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:21 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:21 --> Total execution time: 0.0550
INFO - 2022-06-17 08:29:25 --> Config Class Initialized
INFO - 2022-06-17 08:29:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:25 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:25 --> URI Class Initialized
INFO - 2022-06-17 08:29:25 --> Router Class Initialized
INFO - 2022-06-17 08:29:25 --> Output Class Initialized
INFO - 2022-06-17 08:29:25 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:25 --> Input Class Initialized
INFO - 2022-06-17 08:29:25 --> Language Class Initialized
INFO - 2022-06-17 08:29:25 --> Language Class Initialized
INFO - 2022-06-17 08:29:25 --> Config Class Initialized
INFO - 2022-06-17 08:29:25 --> Loader Class Initialized
INFO - 2022-06-17 08:29:25 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:25 --> Controller Class Initialized
INFO - 2022-06-17 08:29:25 --> Config Class Initialized
INFO - 2022-06-17 08:29:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:25 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:25 --> URI Class Initialized
INFO - 2022-06-17 08:29:25 --> Router Class Initialized
INFO - 2022-06-17 08:29:25 --> Output Class Initialized
INFO - 2022-06-17 08:29:25 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:25 --> Input Class Initialized
INFO - 2022-06-17 08:29:25 --> Language Class Initialized
INFO - 2022-06-17 08:29:25 --> Language Class Initialized
INFO - 2022-06-17 08:29:25 --> Config Class Initialized
INFO - 2022-06-17 08:29:25 --> Loader Class Initialized
INFO - 2022-06-17 08:29:25 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:25 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:29:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:25 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:25 --> Total execution time: 0.0485
INFO - 2022-06-17 08:29:25 --> Config Class Initialized
INFO - 2022-06-17 08:29:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:25 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:25 --> URI Class Initialized
INFO - 2022-06-17 08:29:25 --> Router Class Initialized
INFO - 2022-06-17 08:29:25 --> Output Class Initialized
INFO - 2022-06-17 08:29:25 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:25 --> Input Class Initialized
INFO - 2022-06-17 08:29:25 --> Language Class Initialized
INFO - 2022-06-17 08:29:25 --> Language Class Initialized
INFO - 2022-06-17 08:29:25 --> Config Class Initialized
INFO - 2022-06-17 08:29:25 --> Loader Class Initialized
INFO - 2022-06-17 08:29:25 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:25 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:25 --> Controller Class Initialized
INFO - 2022-06-17 08:29:27 --> Config Class Initialized
INFO - 2022-06-17 08:29:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:27 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:27 --> URI Class Initialized
INFO - 2022-06-17 08:29:27 --> Router Class Initialized
INFO - 2022-06-17 08:29:27 --> Output Class Initialized
INFO - 2022-06-17 08:29:27 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:27 --> Input Class Initialized
INFO - 2022-06-17 08:29:27 --> Language Class Initialized
INFO - 2022-06-17 08:29:27 --> Language Class Initialized
INFO - 2022-06-17 08:29:27 --> Config Class Initialized
INFO - 2022-06-17 08:29:27 --> Loader Class Initialized
INFO - 2022-06-17 08:29:27 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:27 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:27 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:27 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:27 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:27 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:27 --> Total execution time: 0.0527
INFO - 2022-06-17 08:29:30 --> Config Class Initialized
INFO - 2022-06-17 08:29:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:30 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:30 --> URI Class Initialized
INFO - 2022-06-17 08:29:30 --> Router Class Initialized
INFO - 2022-06-17 08:29:30 --> Output Class Initialized
INFO - 2022-06-17 08:29:30 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:30 --> Input Class Initialized
INFO - 2022-06-17 08:29:30 --> Language Class Initialized
INFO - 2022-06-17 08:29:30 --> Language Class Initialized
INFO - 2022-06-17 08:29:30 --> Config Class Initialized
INFO - 2022-06-17 08:29:30 --> Loader Class Initialized
INFO - 2022-06-17 08:29:30 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:30 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:30 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:30 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:30 --> Controller Class Initialized
INFO - 2022-06-17 08:29:30 --> Config Class Initialized
INFO - 2022-06-17 08:29:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:30 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:30 --> URI Class Initialized
INFO - 2022-06-17 08:29:30 --> Router Class Initialized
INFO - 2022-06-17 08:29:30 --> Output Class Initialized
INFO - 2022-06-17 08:29:30 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:30 --> Input Class Initialized
INFO - 2022-06-17 08:29:30 --> Language Class Initialized
INFO - 2022-06-17 08:29:30 --> Language Class Initialized
INFO - 2022-06-17 08:29:30 --> Config Class Initialized
INFO - 2022-06-17 08:29:30 --> Loader Class Initialized
INFO - 2022-06-17 08:29:30 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:30 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:30 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:30 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:30 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:30 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:30 --> Total execution time: 0.0459
INFO - 2022-06-17 08:29:32 --> Config Class Initialized
INFO - 2022-06-17 08:29:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:32 --> URI Class Initialized
INFO - 2022-06-17 08:29:32 --> Router Class Initialized
INFO - 2022-06-17 08:29:32 --> Output Class Initialized
INFO - 2022-06-17 08:29:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:32 --> Input Class Initialized
INFO - 2022-06-17 08:29:32 --> Language Class Initialized
INFO - 2022-06-17 08:29:32 --> Language Class Initialized
INFO - 2022-06-17 08:29:32 --> Config Class Initialized
INFO - 2022-06-17 08:29:32 --> Loader Class Initialized
INFO - 2022-06-17 08:29:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:32 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:29:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:32 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:32 --> Total execution time: 0.0526
INFO - 2022-06-17 08:29:36 --> Config Class Initialized
INFO - 2022-06-17 08:29:36 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:36 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:36 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:36 --> URI Class Initialized
INFO - 2022-06-17 08:29:36 --> Router Class Initialized
INFO - 2022-06-17 08:29:36 --> Output Class Initialized
INFO - 2022-06-17 08:29:36 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:36 --> Input Class Initialized
INFO - 2022-06-17 08:29:36 --> Language Class Initialized
INFO - 2022-06-17 08:29:36 --> Language Class Initialized
INFO - 2022-06-17 08:29:36 --> Config Class Initialized
INFO - 2022-06-17 08:29:36 --> Loader Class Initialized
INFO - 2022-06-17 08:29:36 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:36 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:36 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:36 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:36 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:36 --> Controller Class Initialized
INFO - 2022-06-17 08:29:36 --> Config Class Initialized
INFO - 2022-06-17 08:29:36 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:36 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:36 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:36 --> URI Class Initialized
INFO - 2022-06-17 08:29:36 --> Router Class Initialized
INFO - 2022-06-17 08:29:36 --> Output Class Initialized
INFO - 2022-06-17 08:29:36 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:36 --> Input Class Initialized
INFO - 2022-06-17 08:29:36 --> Language Class Initialized
INFO - 2022-06-17 08:29:36 --> Language Class Initialized
INFO - 2022-06-17 08:29:36 --> Config Class Initialized
INFO - 2022-06-17 08:29:36 --> Loader Class Initialized
INFO - 2022-06-17 08:29:36 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:36 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:36 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:36 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:36 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:36 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:36 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:36 --> Total execution time: 0.0552
INFO - 2022-06-17 08:29:37 --> Config Class Initialized
INFO - 2022-06-17 08:29:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:37 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:37 --> URI Class Initialized
INFO - 2022-06-17 08:29:37 --> Router Class Initialized
INFO - 2022-06-17 08:29:37 --> Output Class Initialized
INFO - 2022-06-17 08:29:37 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:37 --> Input Class Initialized
INFO - 2022-06-17 08:29:37 --> Language Class Initialized
INFO - 2022-06-17 08:29:37 --> Language Class Initialized
INFO - 2022-06-17 08:29:37 --> Config Class Initialized
INFO - 2022-06-17 08:29:37 --> Loader Class Initialized
INFO - 2022-06-17 08:29:37 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:37 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:37 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:37 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:37 --> Controller Class Initialized
INFO - 2022-06-17 08:29:38 --> Config Class Initialized
INFO - 2022-06-17 08:29:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:38 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:38 --> URI Class Initialized
INFO - 2022-06-17 08:29:38 --> Router Class Initialized
INFO - 2022-06-17 08:29:38 --> Output Class Initialized
INFO - 2022-06-17 08:29:38 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:38 --> Input Class Initialized
INFO - 2022-06-17 08:29:38 --> Language Class Initialized
INFO - 2022-06-17 08:29:38 --> Language Class Initialized
INFO - 2022-06-17 08:29:38 --> Config Class Initialized
INFO - 2022-06-17 08:29:38 --> Loader Class Initialized
INFO - 2022-06-17 08:29:38 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:38 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:38 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:38 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:38 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:38 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:38 --> Total execution time: 0.0536
INFO - 2022-06-17 08:29:41 --> Config Class Initialized
INFO - 2022-06-17 08:29:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:41 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:41 --> URI Class Initialized
INFO - 2022-06-17 08:29:41 --> Router Class Initialized
INFO - 2022-06-17 08:29:41 --> Output Class Initialized
INFO - 2022-06-17 08:29:41 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:41 --> Input Class Initialized
INFO - 2022-06-17 08:29:41 --> Language Class Initialized
INFO - 2022-06-17 08:29:41 --> Language Class Initialized
INFO - 2022-06-17 08:29:41 --> Config Class Initialized
INFO - 2022-06-17 08:29:41 --> Loader Class Initialized
INFO - 2022-06-17 08:29:41 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:41 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:41 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:41 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:41 --> Controller Class Initialized
INFO - 2022-06-17 08:29:41 --> Config Class Initialized
INFO - 2022-06-17 08:29:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:41 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:41 --> URI Class Initialized
INFO - 2022-06-17 08:29:41 --> Router Class Initialized
INFO - 2022-06-17 08:29:41 --> Output Class Initialized
INFO - 2022-06-17 08:29:41 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:41 --> Input Class Initialized
INFO - 2022-06-17 08:29:41 --> Language Class Initialized
INFO - 2022-06-17 08:29:41 --> Language Class Initialized
INFO - 2022-06-17 08:29:41 --> Config Class Initialized
INFO - 2022-06-17 08:29:41 --> Loader Class Initialized
INFO - 2022-06-17 08:29:41 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:41 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:41 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:41 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:41 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:41 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:41 --> Total execution time: 0.0553
INFO - 2022-06-17 08:29:43 --> Config Class Initialized
INFO - 2022-06-17 08:29:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:43 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:43 --> URI Class Initialized
INFO - 2022-06-17 08:29:43 --> Router Class Initialized
INFO - 2022-06-17 08:29:43 --> Output Class Initialized
INFO - 2022-06-17 08:29:43 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:43 --> Input Class Initialized
INFO - 2022-06-17 08:29:43 --> Language Class Initialized
INFO - 2022-06-17 08:29:43 --> Language Class Initialized
INFO - 2022-06-17 08:29:43 --> Config Class Initialized
INFO - 2022-06-17 08:29:43 --> Loader Class Initialized
INFO - 2022-06-17 08:29:43 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:43 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:43 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:43 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:43 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:29:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:43 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:43 --> Total execution time: 0.0440
INFO - 2022-06-17 08:29:47 --> Config Class Initialized
INFO - 2022-06-17 08:29:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:47 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:47 --> URI Class Initialized
INFO - 2022-06-17 08:29:47 --> Router Class Initialized
INFO - 2022-06-17 08:29:47 --> Output Class Initialized
INFO - 2022-06-17 08:29:47 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:47 --> Input Class Initialized
INFO - 2022-06-17 08:29:47 --> Language Class Initialized
INFO - 2022-06-17 08:29:47 --> Language Class Initialized
INFO - 2022-06-17 08:29:47 --> Config Class Initialized
INFO - 2022-06-17 08:29:47 --> Loader Class Initialized
INFO - 2022-06-17 08:29:47 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:47 --> Controller Class Initialized
INFO - 2022-06-17 08:29:47 --> Config Class Initialized
INFO - 2022-06-17 08:29:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:47 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:47 --> URI Class Initialized
INFO - 2022-06-17 08:29:47 --> Router Class Initialized
INFO - 2022-06-17 08:29:47 --> Output Class Initialized
INFO - 2022-06-17 08:29:47 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:47 --> Input Class Initialized
INFO - 2022-06-17 08:29:47 --> Language Class Initialized
INFO - 2022-06-17 08:29:47 --> Language Class Initialized
INFO - 2022-06-17 08:29:47 --> Config Class Initialized
INFO - 2022-06-17 08:29:47 --> Loader Class Initialized
INFO - 2022-06-17 08:29:47 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:47 --> Controller Class Initialized
INFO - 2022-06-17 08:29:47 --> Config Class Initialized
INFO - 2022-06-17 08:29:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:47 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:47 --> URI Class Initialized
INFO - 2022-06-17 08:29:47 --> Router Class Initialized
INFO - 2022-06-17 08:29:47 --> Output Class Initialized
INFO - 2022-06-17 08:29:47 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:47 --> Input Class Initialized
INFO - 2022-06-17 08:29:47 --> Language Class Initialized
INFO - 2022-06-17 08:29:47 --> Language Class Initialized
INFO - 2022-06-17 08:29:47 --> Config Class Initialized
INFO - 2022-06-17 08:29:47 --> Loader Class Initialized
INFO - 2022-06-17 08:29:47 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:47 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:29:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:47 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:47 --> Total execution time: 0.0466
INFO - 2022-06-17 08:29:47 --> Config Class Initialized
INFO - 2022-06-17 08:29:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:47 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:47 --> URI Class Initialized
INFO - 2022-06-17 08:29:47 --> Router Class Initialized
INFO - 2022-06-17 08:29:47 --> Output Class Initialized
INFO - 2022-06-17 08:29:47 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:47 --> Input Class Initialized
INFO - 2022-06-17 08:29:47 --> Language Class Initialized
INFO - 2022-06-17 08:29:47 --> Language Class Initialized
INFO - 2022-06-17 08:29:47 --> Config Class Initialized
INFO - 2022-06-17 08:29:47 --> Loader Class Initialized
INFO - 2022-06-17 08:29:47 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:47 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:47 --> Controller Class Initialized
INFO - 2022-06-17 08:29:49 --> Config Class Initialized
INFO - 2022-06-17 08:29:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:49 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:49 --> URI Class Initialized
INFO - 2022-06-17 08:29:49 --> Router Class Initialized
INFO - 2022-06-17 08:29:49 --> Output Class Initialized
INFO - 2022-06-17 08:29:49 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:49 --> Input Class Initialized
INFO - 2022-06-17 08:29:49 --> Language Class Initialized
INFO - 2022-06-17 08:29:49 --> Language Class Initialized
INFO - 2022-06-17 08:29:49 --> Config Class Initialized
INFO - 2022-06-17 08:29:49 --> Loader Class Initialized
INFO - 2022-06-17 08:29:49 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:49 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:49 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:49 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:49 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:49 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:49 --> Total execution time: 0.0526
INFO - 2022-06-17 08:29:52 --> Config Class Initialized
INFO - 2022-06-17 08:29:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:52 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:52 --> URI Class Initialized
INFO - 2022-06-17 08:29:52 --> Router Class Initialized
INFO - 2022-06-17 08:29:52 --> Output Class Initialized
INFO - 2022-06-17 08:29:52 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:52 --> Input Class Initialized
INFO - 2022-06-17 08:29:52 --> Language Class Initialized
INFO - 2022-06-17 08:29:52 --> Language Class Initialized
INFO - 2022-06-17 08:29:52 --> Config Class Initialized
INFO - 2022-06-17 08:29:52 --> Loader Class Initialized
INFO - 2022-06-17 08:29:52 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:52 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:52 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:52 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:52 --> Controller Class Initialized
INFO - 2022-06-17 08:29:52 --> Config Class Initialized
INFO - 2022-06-17 08:29:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:29:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:29:52 --> Utf8 Class Initialized
INFO - 2022-06-17 08:29:52 --> URI Class Initialized
INFO - 2022-06-17 08:29:52 --> Router Class Initialized
INFO - 2022-06-17 08:29:52 --> Output Class Initialized
INFO - 2022-06-17 08:29:52 --> Security Class Initialized
DEBUG - 2022-06-17 08:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:29:52 --> Input Class Initialized
INFO - 2022-06-17 08:29:52 --> Language Class Initialized
INFO - 2022-06-17 08:29:52 --> Language Class Initialized
INFO - 2022-06-17 08:29:52 --> Config Class Initialized
INFO - 2022-06-17 08:29:52 --> Loader Class Initialized
INFO - 2022-06-17 08:29:52 --> Helper loaded: url_helper
INFO - 2022-06-17 08:29:52 --> Helper loaded: file_helper
INFO - 2022-06-17 08:29:52 --> Helper loaded: form_helper
INFO - 2022-06-17 08:29:52 --> Helper loaded: my_helper
INFO - 2022-06-17 08:29:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:29:52 --> Controller Class Initialized
DEBUG - 2022-06-17 08:29:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:29:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:29:52 --> Final output sent to browser
DEBUG - 2022-06-17 08:29:52 --> Total execution time: 0.0538
INFO - 2022-06-17 08:30:05 --> Config Class Initialized
INFO - 2022-06-17 08:30:05 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:05 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:05 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:05 --> URI Class Initialized
INFO - 2022-06-17 08:30:05 --> Router Class Initialized
INFO - 2022-06-17 08:30:05 --> Output Class Initialized
INFO - 2022-06-17 08:30:05 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:05 --> Input Class Initialized
INFO - 2022-06-17 08:30:05 --> Language Class Initialized
INFO - 2022-06-17 08:30:05 --> Language Class Initialized
INFO - 2022-06-17 08:30:05 --> Config Class Initialized
INFO - 2022-06-17 08:30:05 --> Loader Class Initialized
INFO - 2022-06-17 08:30:05 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:05 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:05 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:05 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:05 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:05 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:30:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:05 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:05 --> Total execution time: 0.0540
INFO - 2022-06-17 08:30:08 --> Config Class Initialized
INFO - 2022-06-17 08:30:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:08 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:08 --> URI Class Initialized
INFO - 2022-06-17 08:30:08 --> Router Class Initialized
INFO - 2022-06-17 08:30:08 --> Output Class Initialized
INFO - 2022-06-17 08:30:08 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:08 --> Input Class Initialized
INFO - 2022-06-17 08:30:08 --> Language Class Initialized
INFO - 2022-06-17 08:30:08 --> Language Class Initialized
INFO - 2022-06-17 08:30:08 --> Config Class Initialized
INFO - 2022-06-17 08:30:08 --> Loader Class Initialized
INFO - 2022-06-17 08:30:08 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:08 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:08 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:08 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:08 --> Controller Class Initialized
INFO - 2022-06-17 08:30:08 --> Config Class Initialized
INFO - 2022-06-17 08:30:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:08 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:08 --> URI Class Initialized
INFO - 2022-06-17 08:30:08 --> Router Class Initialized
INFO - 2022-06-17 08:30:08 --> Output Class Initialized
INFO - 2022-06-17 08:30:08 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:08 --> Input Class Initialized
INFO - 2022-06-17 08:30:08 --> Language Class Initialized
INFO - 2022-06-17 08:30:09 --> Language Class Initialized
INFO - 2022-06-17 08:30:09 --> Config Class Initialized
INFO - 2022-06-17 08:30:09 --> Loader Class Initialized
INFO - 2022-06-17 08:30:09 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:09 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:09 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:09 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:09 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:09 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:30:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:09 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:09 --> Total execution time: 0.0447
INFO - 2022-06-17 08:30:09 --> Config Class Initialized
INFO - 2022-06-17 08:30:09 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:09 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:09 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:09 --> URI Class Initialized
INFO - 2022-06-17 08:30:09 --> Router Class Initialized
INFO - 2022-06-17 08:30:09 --> Output Class Initialized
INFO - 2022-06-17 08:30:09 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:09 --> Input Class Initialized
INFO - 2022-06-17 08:30:09 --> Language Class Initialized
INFO - 2022-06-17 08:30:09 --> Language Class Initialized
INFO - 2022-06-17 08:30:09 --> Config Class Initialized
INFO - 2022-06-17 08:30:09 --> Loader Class Initialized
INFO - 2022-06-17 08:30:09 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:09 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:09 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:09 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:09 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:09 --> Controller Class Initialized
INFO - 2022-06-17 08:30:10 --> Config Class Initialized
INFO - 2022-06-17 08:30:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:10 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:10 --> URI Class Initialized
INFO - 2022-06-17 08:30:10 --> Router Class Initialized
INFO - 2022-06-17 08:30:10 --> Output Class Initialized
INFO - 2022-06-17 08:30:10 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:10 --> Input Class Initialized
INFO - 2022-06-17 08:30:10 --> Language Class Initialized
INFO - 2022-06-17 08:30:10 --> Language Class Initialized
INFO - 2022-06-17 08:30:10 --> Config Class Initialized
INFO - 2022-06-17 08:30:10 --> Loader Class Initialized
INFO - 2022-06-17 08:30:10 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:10 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:10 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:10 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:10 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:10 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:10 --> Total execution time: 0.0441
INFO - 2022-06-17 08:30:13 --> Config Class Initialized
INFO - 2022-06-17 08:30:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:13 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:13 --> URI Class Initialized
INFO - 2022-06-17 08:30:13 --> Router Class Initialized
INFO - 2022-06-17 08:30:13 --> Output Class Initialized
INFO - 2022-06-17 08:30:13 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:13 --> Input Class Initialized
INFO - 2022-06-17 08:30:13 --> Language Class Initialized
INFO - 2022-06-17 08:30:13 --> Language Class Initialized
INFO - 2022-06-17 08:30:13 --> Config Class Initialized
INFO - 2022-06-17 08:30:13 --> Loader Class Initialized
INFO - 2022-06-17 08:30:13 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:13 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:13 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:13 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:13 --> Controller Class Initialized
INFO - 2022-06-17 08:30:13 --> Config Class Initialized
INFO - 2022-06-17 08:30:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:13 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:13 --> URI Class Initialized
INFO - 2022-06-17 08:30:13 --> Router Class Initialized
INFO - 2022-06-17 08:30:13 --> Output Class Initialized
INFO - 2022-06-17 08:30:13 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:13 --> Input Class Initialized
INFO - 2022-06-17 08:30:13 --> Language Class Initialized
INFO - 2022-06-17 08:30:13 --> Language Class Initialized
INFO - 2022-06-17 08:30:13 --> Config Class Initialized
INFO - 2022-06-17 08:30:13 --> Loader Class Initialized
INFO - 2022-06-17 08:30:13 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:13 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:13 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:13 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:13 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:13 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:13 --> Total execution time: 0.0546
INFO - 2022-06-17 08:30:15 --> Config Class Initialized
INFO - 2022-06-17 08:30:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:15 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:15 --> URI Class Initialized
INFO - 2022-06-17 08:30:15 --> Router Class Initialized
INFO - 2022-06-17 08:30:15 --> Output Class Initialized
INFO - 2022-06-17 08:30:15 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:15 --> Input Class Initialized
INFO - 2022-06-17 08:30:15 --> Language Class Initialized
INFO - 2022-06-17 08:30:15 --> Language Class Initialized
INFO - 2022-06-17 08:30:15 --> Config Class Initialized
INFO - 2022-06-17 08:30:15 --> Loader Class Initialized
INFO - 2022-06-17 08:30:15 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:15 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:15 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:15 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:15 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:15 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:15 --> Total execution time: 0.0535
INFO - 2022-06-17 08:30:18 --> Config Class Initialized
INFO - 2022-06-17 08:30:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:18 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:18 --> URI Class Initialized
INFO - 2022-06-17 08:30:18 --> Router Class Initialized
INFO - 2022-06-17 08:30:18 --> Output Class Initialized
INFO - 2022-06-17 08:30:18 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:19 --> Input Class Initialized
INFO - 2022-06-17 08:30:19 --> Language Class Initialized
INFO - 2022-06-17 08:30:19 --> Language Class Initialized
INFO - 2022-06-17 08:30:19 --> Config Class Initialized
INFO - 2022-06-17 08:30:19 --> Loader Class Initialized
INFO - 2022-06-17 08:30:19 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:19 --> Controller Class Initialized
INFO - 2022-06-17 08:30:19 --> Config Class Initialized
INFO - 2022-06-17 08:30:19 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:19 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:19 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:19 --> URI Class Initialized
INFO - 2022-06-17 08:30:19 --> Router Class Initialized
INFO - 2022-06-17 08:30:19 --> Output Class Initialized
INFO - 2022-06-17 08:30:19 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:19 --> Input Class Initialized
INFO - 2022-06-17 08:30:19 --> Language Class Initialized
INFO - 2022-06-17 08:30:19 --> Language Class Initialized
INFO - 2022-06-17 08:30:19 --> Config Class Initialized
INFO - 2022-06-17 08:30:19 --> Loader Class Initialized
INFO - 2022-06-17 08:30:19 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:19 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:30:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:19 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:19 --> Total execution time: 0.0593
INFO - 2022-06-17 08:30:19 --> Config Class Initialized
INFO - 2022-06-17 08:30:19 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:19 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:19 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:19 --> URI Class Initialized
INFO - 2022-06-17 08:30:19 --> Router Class Initialized
INFO - 2022-06-17 08:30:19 --> Output Class Initialized
INFO - 2022-06-17 08:30:19 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:19 --> Input Class Initialized
INFO - 2022-06-17 08:30:19 --> Language Class Initialized
INFO - 2022-06-17 08:30:19 --> Language Class Initialized
INFO - 2022-06-17 08:30:19 --> Config Class Initialized
INFO - 2022-06-17 08:30:19 --> Loader Class Initialized
INFO - 2022-06-17 08:30:19 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:19 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:19 --> Controller Class Initialized
INFO - 2022-06-17 08:30:20 --> Config Class Initialized
INFO - 2022-06-17 08:30:20 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:20 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:20 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:20 --> URI Class Initialized
INFO - 2022-06-17 08:30:20 --> Router Class Initialized
INFO - 2022-06-17 08:30:20 --> Output Class Initialized
INFO - 2022-06-17 08:30:20 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:20 --> Input Class Initialized
INFO - 2022-06-17 08:30:20 --> Language Class Initialized
INFO - 2022-06-17 08:30:20 --> Language Class Initialized
INFO - 2022-06-17 08:30:20 --> Config Class Initialized
INFO - 2022-06-17 08:30:20 --> Loader Class Initialized
INFO - 2022-06-17 08:30:20 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:20 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:20 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:20 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:20 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:20 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:30:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:20 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:20 --> Total execution time: 0.0553
INFO - 2022-06-17 08:30:25 --> Config Class Initialized
INFO - 2022-06-17 08:30:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:25 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:25 --> URI Class Initialized
INFO - 2022-06-17 08:30:25 --> Router Class Initialized
INFO - 2022-06-17 08:30:25 --> Output Class Initialized
INFO - 2022-06-17 08:30:25 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:26 --> Input Class Initialized
INFO - 2022-06-17 08:30:26 --> Language Class Initialized
INFO - 2022-06-17 08:30:26 --> Language Class Initialized
INFO - 2022-06-17 08:30:26 --> Config Class Initialized
INFO - 2022-06-17 08:30:26 --> Loader Class Initialized
INFO - 2022-06-17 08:30:26 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:26 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:26 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:26 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:26 --> Controller Class Initialized
INFO - 2022-06-17 08:30:26 --> Config Class Initialized
INFO - 2022-06-17 08:30:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:26 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:26 --> URI Class Initialized
INFO - 2022-06-17 08:30:26 --> Router Class Initialized
INFO - 2022-06-17 08:30:26 --> Output Class Initialized
INFO - 2022-06-17 08:30:26 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:26 --> Input Class Initialized
INFO - 2022-06-17 08:30:26 --> Language Class Initialized
INFO - 2022-06-17 08:30:26 --> Language Class Initialized
INFO - 2022-06-17 08:30:26 --> Config Class Initialized
INFO - 2022-06-17 08:30:26 --> Loader Class Initialized
INFO - 2022-06-17 08:30:26 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:26 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:26 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:26 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:26 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:30:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:26 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:26 --> Total execution time: 0.0532
INFO - 2022-06-17 08:30:27 --> Config Class Initialized
INFO - 2022-06-17 08:30:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:27 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:27 --> URI Class Initialized
INFO - 2022-06-17 08:30:27 --> Router Class Initialized
INFO - 2022-06-17 08:30:27 --> Output Class Initialized
INFO - 2022-06-17 08:30:27 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:27 --> Input Class Initialized
INFO - 2022-06-17 08:30:27 --> Language Class Initialized
INFO - 2022-06-17 08:30:27 --> Language Class Initialized
INFO - 2022-06-17 08:30:27 --> Config Class Initialized
INFO - 2022-06-17 08:30:27 --> Loader Class Initialized
INFO - 2022-06-17 08:30:27 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:27 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:27 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:27 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:27 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:30:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:27 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:27 --> Total execution time: 0.0447
INFO - 2022-06-17 08:30:32 --> Config Class Initialized
INFO - 2022-06-17 08:30:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:32 --> URI Class Initialized
INFO - 2022-06-17 08:30:32 --> Router Class Initialized
INFO - 2022-06-17 08:30:32 --> Output Class Initialized
INFO - 2022-06-17 08:30:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:32 --> Input Class Initialized
INFO - 2022-06-17 08:30:32 --> Language Class Initialized
INFO - 2022-06-17 08:30:32 --> Language Class Initialized
INFO - 2022-06-17 08:30:32 --> Config Class Initialized
INFO - 2022-06-17 08:30:32 --> Loader Class Initialized
INFO - 2022-06-17 08:30:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:32 --> Controller Class Initialized
INFO - 2022-06-17 08:30:32 --> Config Class Initialized
INFO - 2022-06-17 08:30:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:32 --> URI Class Initialized
INFO - 2022-06-17 08:30:32 --> Router Class Initialized
INFO - 2022-06-17 08:30:32 --> Output Class Initialized
INFO - 2022-06-17 08:30:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:32 --> Input Class Initialized
INFO - 2022-06-17 08:30:32 --> Language Class Initialized
INFO - 2022-06-17 08:30:32 --> Language Class Initialized
INFO - 2022-06-17 08:30:32 --> Config Class Initialized
INFO - 2022-06-17 08:30:32 --> Loader Class Initialized
INFO - 2022-06-17 08:30:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:32 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:30:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:32 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:32 --> Total execution time: 0.0530
INFO - 2022-06-17 08:30:32 --> Config Class Initialized
INFO - 2022-06-17 08:30:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:32 --> URI Class Initialized
INFO - 2022-06-17 08:30:32 --> Router Class Initialized
INFO - 2022-06-17 08:30:32 --> Output Class Initialized
INFO - 2022-06-17 08:30:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:32 --> Input Class Initialized
INFO - 2022-06-17 08:30:32 --> Language Class Initialized
INFO - 2022-06-17 08:30:32 --> Language Class Initialized
INFO - 2022-06-17 08:30:32 --> Config Class Initialized
INFO - 2022-06-17 08:30:32 --> Loader Class Initialized
INFO - 2022-06-17 08:30:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:32 --> Controller Class Initialized
INFO - 2022-06-17 08:30:34 --> Config Class Initialized
INFO - 2022-06-17 08:30:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:34 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:34 --> URI Class Initialized
INFO - 2022-06-17 08:30:34 --> Router Class Initialized
INFO - 2022-06-17 08:30:34 --> Output Class Initialized
INFO - 2022-06-17 08:30:34 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:34 --> Input Class Initialized
INFO - 2022-06-17 08:30:34 --> Language Class Initialized
INFO - 2022-06-17 08:30:34 --> Language Class Initialized
INFO - 2022-06-17 08:30:34 --> Config Class Initialized
INFO - 2022-06-17 08:30:34 --> Loader Class Initialized
INFO - 2022-06-17 08:30:34 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:34 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:34 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:34 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:34 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:34 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:34 --> Total execution time: 0.0530
INFO - 2022-06-17 08:30:38 --> Config Class Initialized
INFO - 2022-06-17 08:30:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:38 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:38 --> URI Class Initialized
INFO - 2022-06-17 08:30:38 --> Router Class Initialized
INFO - 2022-06-17 08:30:38 --> Output Class Initialized
INFO - 2022-06-17 08:30:38 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:38 --> Input Class Initialized
INFO - 2022-06-17 08:30:38 --> Language Class Initialized
INFO - 2022-06-17 08:30:38 --> Language Class Initialized
INFO - 2022-06-17 08:30:38 --> Config Class Initialized
INFO - 2022-06-17 08:30:38 --> Loader Class Initialized
INFO - 2022-06-17 08:30:38 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:38 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:38 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:38 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:38 --> Controller Class Initialized
ERROR - 2022-06-17 08:30:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 324
ERROR - 2022-06-17 08:30:38 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 334
ERROR - 2022-06-17 08:30:38 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 334
ERROR - 2022-06-17 08:30:38 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 334
ERROR - 2022-06-17 08:30:38 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 334
INFO - 2022-06-17 08:30:38 --> Config Class Initialized
INFO - 2022-06-17 08:30:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:38 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:38 --> URI Class Initialized
INFO - 2022-06-17 08:30:38 --> Router Class Initialized
INFO - 2022-06-17 08:30:38 --> Output Class Initialized
INFO - 2022-06-17 08:30:38 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:38 --> Input Class Initialized
INFO - 2022-06-17 08:30:38 --> Language Class Initialized
INFO - 2022-06-17 08:30:38 --> Language Class Initialized
INFO - 2022-06-17 08:30:38 --> Config Class Initialized
INFO - 2022-06-17 08:30:38 --> Loader Class Initialized
INFO - 2022-06-17 08:30:38 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:38 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:38 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:38 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:38 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:30:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:38 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:38 --> Total execution time: 0.0538
INFO - 2022-06-17 08:30:48 --> Config Class Initialized
INFO - 2022-06-17 08:30:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:48 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:48 --> URI Class Initialized
INFO - 2022-06-17 08:30:48 --> Router Class Initialized
INFO - 2022-06-17 08:30:48 --> Output Class Initialized
INFO - 2022-06-17 08:30:48 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:48 --> Input Class Initialized
INFO - 2022-06-17 08:30:48 --> Language Class Initialized
INFO - 2022-06-17 08:30:49 --> Language Class Initialized
INFO - 2022-06-17 08:30:49 --> Config Class Initialized
INFO - 2022-06-17 08:30:49 --> Loader Class Initialized
INFO - 2022-06-17 08:30:49 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:49 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:49 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:49 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:49 --> Controller Class Initialized
INFO - 2022-06-17 08:30:49 --> Helper loaded: cookie_helper
INFO - 2022-06-17 08:30:49 --> Config Class Initialized
INFO - 2022-06-17 08:30:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:30:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:30:49 --> Utf8 Class Initialized
INFO - 2022-06-17 08:30:49 --> URI Class Initialized
INFO - 2022-06-17 08:30:49 --> Router Class Initialized
INFO - 2022-06-17 08:30:49 --> Output Class Initialized
INFO - 2022-06-17 08:30:49 --> Security Class Initialized
DEBUG - 2022-06-17 08:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:30:49 --> Input Class Initialized
INFO - 2022-06-17 08:30:49 --> Language Class Initialized
INFO - 2022-06-17 08:30:49 --> Language Class Initialized
INFO - 2022-06-17 08:30:49 --> Config Class Initialized
INFO - 2022-06-17 08:30:49 --> Loader Class Initialized
INFO - 2022-06-17 08:30:49 --> Helper loaded: url_helper
INFO - 2022-06-17 08:30:49 --> Helper loaded: file_helper
INFO - 2022-06-17 08:30:49 --> Helper loaded: form_helper
INFO - 2022-06-17 08:30:49 --> Helper loaded: my_helper
INFO - 2022-06-17 08:30:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:30:49 --> Controller Class Initialized
DEBUG - 2022-06-17 08:30:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 08:30:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:30:49 --> Final output sent to browser
DEBUG - 2022-06-17 08:30:49 --> Total execution time: 0.0533
INFO - 2022-06-17 08:31:14 --> Config Class Initialized
INFO - 2022-06-17 08:31:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:31:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:31:14 --> Utf8 Class Initialized
INFO - 2022-06-17 08:31:14 --> URI Class Initialized
INFO - 2022-06-17 08:31:14 --> Router Class Initialized
INFO - 2022-06-17 08:31:14 --> Output Class Initialized
INFO - 2022-06-17 08:31:14 --> Security Class Initialized
DEBUG - 2022-06-17 08:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:31:14 --> Input Class Initialized
INFO - 2022-06-17 08:31:14 --> Language Class Initialized
INFO - 2022-06-17 08:31:14 --> Language Class Initialized
INFO - 2022-06-17 08:31:14 --> Config Class Initialized
INFO - 2022-06-17 08:31:14 --> Loader Class Initialized
INFO - 2022-06-17 08:31:14 --> Helper loaded: url_helper
INFO - 2022-06-17 08:31:14 --> Helper loaded: file_helper
INFO - 2022-06-17 08:31:14 --> Helper loaded: form_helper
INFO - 2022-06-17 08:31:14 --> Helper loaded: my_helper
INFO - 2022-06-17 08:31:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:31:14 --> Controller Class Initialized
INFO - 2022-06-17 08:31:14 --> Helper loaded: cookie_helper
INFO - 2022-06-17 08:31:14 --> Final output sent to browser
DEBUG - 2022-06-17 08:31:14 --> Total execution time: 0.0439
INFO - 2022-06-17 08:31:14 --> Config Class Initialized
INFO - 2022-06-17 08:31:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:31:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:31:14 --> Utf8 Class Initialized
INFO - 2022-06-17 08:31:14 --> URI Class Initialized
INFO - 2022-06-17 08:31:14 --> Router Class Initialized
INFO - 2022-06-17 08:31:14 --> Output Class Initialized
INFO - 2022-06-17 08:31:14 --> Security Class Initialized
DEBUG - 2022-06-17 08:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:31:14 --> Input Class Initialized
INFO - 2022-06-17 08:31:14 --> Language Class Initialized
INFO - 2022-06-17 08:31:14 --> Language Class Initialized
INFO - 2022-06-17 08:31:14 --> Config Class Initialized
INFO - 2022-06-17 08:31:14 --> Loader Class Initialized
INFO - 2022-06-17 08:31:14 --> Helper loaded: url_helper
INFO - 2022-06-17 08:31:14 --> Helper loaded: file_helper
INFO - 2022-06-17 08:31:14 --> Helper loaded: form_helper
INFO - 2022-06-17 08:31:14 --> Helper loaded: my_helper
INFO - 2022-06-17 08:31:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:31:14 --> Controller Class Initialized
DEBUG - 2022-06-17 08:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:31:14 --> Final output sent to browser
DEBUG - 2022-06-17 08:31:14 --> Total execution time: 0.0816
INFO - 2022-06-17 08:31:49 --> Config Class Initialized
INFO - 2022-06-17 08:31:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:31:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:31:49 --> Utf8 Class Initialized
INFO - 2022-06-17 08:31:49 --> URI Class Initialized
INFO - 2022-06-17 08:31:49 --> Router Class Initialized
INFO - 2022-06-17 08:31:49 --> Output Class Initialized
INFO - 2022-06-17 08:31:49 --> Security Class Initialized
DEBUG - 2022-06-17 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:31:49 --> Input Class Initialized
INFO - 2022-06-17 08:31:49 --> Language Class Initialized
INFO - 2022-06-17 08:31:49 --> Language Class Initialized
INFO - 2022-06-17 08:31:49 --> Config Class Initialized
INFO - 2022-06-17 08:31:49 --> Loader Class Initialized
INFO - 2022-06-17 08:31:49 --> Helper loaded: url_helper
INFO - 2022-06-17 08:31:49 --> Helper loaded: file_helper
INFO - 2022-06-17 08:31:49 --> Helper loaded: form_helper
INFO - 2022-06-17 08:31:49 --> Helper loaded: my_helper
INFO - 2022-06-17 08:31:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:31:49 --> Controller Class Initialized
DEBUG - 2022-06-17 08:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 08:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:31:49 --> Final output sent to browser
DEBUG - 2022-06-17 08:31:49 --> Total execution time: 0.0530
INFO - 2022-06-17 08:32:02 --> Config Class Initialized
INFO - 2022-06-17 08:32:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:02 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:02 --> URI Class Initialized
INFO - 2022-06-17 08:32:02 --> Router Class Initialized
INFO - 2022-06-17 08:32:02 --> Output Class Initialized
INFO - 2022-06-17 08:32:02 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:02 --> Input Class Initialized
INFO - 2022-06-17 08:32:02 --> Language Class Initialized
INFO - 2022-06-17 08:32:02 --> Language Class Initialized
INFO - 2022-06-17 08:32:02 --> Config Class Initialized
INFO - 2022-06-17 08:32:02 --> Loader Class Initialized
INFO - 2022-06-17 08:32:02 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:02 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:02 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:02 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:02 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:02 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:02 --> Total execution time: 0.0472
INFO - 2022-06-17 08:32:03 --> Config Class Initialized
INFO - 2022-06-17 08:32:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:03 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:03 --> URI Class Initialized
INFO - 2022-06-17 08:32:03 --> Router Class Initialized
INFO - 2022-06-17 08:32:03 --> Output Class Initialized
INFO - 2022-06-17 08:32:03 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:03 --> Input Class Initialized
INFO - 2022-06-17 08:32:03 --> Language Class Initialized
INFO - 2022-06-17 08:32:03 --> Language Class Initialized
INFO - 2022-06-17 08:32:03 --> Config Class Initialized
INFO - 2022-06-17 08:32:03 --> Loader Class Initialized
INFO - 2022-06-17 08:32:03 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:03 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:03 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:03 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:03 --> Controller Class Initialized
INFO - 2022-06-17 08:32:04 --> Config Class Initialized
INFO - 2022-06-17 08:32:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:04 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:04 --> URI Class Initialized
INFO - 2022-06-17 08:32:04 --> Router Class Initialized
INFO - 2022-06-17 08:32:04 --> Output Class Initialized
INFO - 2022-06-17 08:32:04 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:04 --> Input Class Initialized
INFO - 2022-06-17 08:32:04 --> Language Class Initialized
INFO - 2022-06-17 08:32:04 --> Language Class Initialized
INFO - 2022-06-17 08:32:04 --> Config Class Initialized
INFO - 2022-06-17 08:32:04 --> Loader Class Initialized
INFO - 2022-06-17 08:32:04 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:04 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:04 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:04 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:04 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:32:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:04 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:04 --> Total execution time: 0.0459
INFO - 2022-06-17 08:32:06 --> Config Class Initialized
INFO - 2022-06-17 08:32:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:06 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:06 --> URI Class Initialized
INFO - 2022-06-17 08:32:06 --> Router Class Initialized
INFO - 2022-06-17 08:32:06 --> Output Class Initialized
INFO - 2022-06-17 08:32:06 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:06 --> Input Class Initialized
INFO - 2022-06-17 08:32:06 --> Language Class Initialized
INFO - 2022-06-17 08:32:06 --> Language Class Initialized
INFO - 2022-06-17 08:32:06 --> Config Class Initialized
INFO - 2022-06-17 08:32:06 --> Loader Class Initialized
INFO - 2022-06-17 08:32:06 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:06 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:06 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:06 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:06 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:06 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:06 --> Total execution time: 0.0472
INFO - 2022-06-17 08:32:06 --> Config Class Initialized
INFO - 2022-06-17 08:32:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:06 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:06 --> URI Class Initialized
INFO - 2022-06-17 08:32:06 --> Router Class Initialized
INFO - 2022-06-17 08:32:06 --> Output Class Initialized
INFO - 2022-06-17 08:32:06 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:06 --> Input Class Initialized
INFO - 2022-06-17 08:32:06 --> Language Class Initialized
INFO - 2022-06-17 08:32:06 --> Language Class Initialized
INFO - 2022-06-17 08:32:06 --> Config Class Initialized
INFO - 2022-06-17 08:32:06 --> Loader Class Initialized
INFO - 2022-06-17 08:32:06 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:06 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:06 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:06 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:06 --> Controller Class Initialized
INFO - 2022-06-17 08:32:08 --> Config Class Initialized
INFO - 2022-06-17 08:32:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:08 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:08 --> URI Class Initialized
INFO - 2022-06-17 08:32:08 --> Router Class Initialized
INFO - 2022-06-17 08:32:08 --> Output Class Initialized
INFO - 2022-06-17 08:32:08 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:08 --> Input Class Initialized
INFO - 2022-06-17 08:32:08 --> Language Class Initialized
INFO - 2022-06-17 08:32:08 --> Language Class Initialized
INFO - 2022-06-17 08:32:08 --> Config Class Initialized
INFO - 2022-06-17 08:32:08 --> Loader Class Initialized
INFO - 2022-06-17 08:32:08 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:08 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:08 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:08 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:08 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:32:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:08 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:08 --> Total execution time: 0.0465
INFO - 2022-06-17 08:32:09 --> Config Class Initialized
INFO - 2022-06-17 08:32:09 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:09 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:09 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:09 --> URI Class Initialized
INFO - 2022-06-17 08:32:09 --> Router Class Initialized
INFO - 2022-06-17 08:32:09 --> Output Class Initialized
INFO - 2022-06-17 08:32:09 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:09 --> Input Class Initialized
INFO - 2022-06-17 08:32:09 --> Language Class Initialized
INFO - 2022-06-17 08:32:09 --> Language Class Initialized
INFO - 2022-06-17 08:32:09 --> Config Class Initialized
INFO - 2022-06-17 08:32:09 --> Loader Class Initialized
INFO - 2022-06-17 08:32:09 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:09 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:09 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:09 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:09 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:09 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:09 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:09 --> Total execution time: 0.0484
INFO - 2022-06-17 08:32:09 --> Config Class Initialized
INFO - 2022-06-17 08:32:09 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:09 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:09 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:09 --> URI Class Initialized
INFO - 2022-06-17 08:32:09 --> Router Class Initialized
INFO - 2022-06-17 08:32:09 --> Output Class Initialized
INFO - 2022-06-17 08:32:09 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:09 --> Input Class Initialized
INFO - 2022-06-17 08:32:09 --> Language Class Initialized
INFO - 2022-06-17 08:32:09 --> Language Class Initialized
INFO - 2022-06-17 08:32:09 --> Config Class Initialized
INFO - 2022-06-17 08:32:09 --> Loader Class Initialized
INFO - 2022-06-17 08:32:09 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:09 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:09 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:09 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:09 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:09 --> Controller Class Initialized
INFO - 2022-06-17 08:32:10 --> Config Class Initialized
INFO - 2022-06-17 08:32:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:10 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:10 --> URI Class Initialized
INFO - 2022-06-17 08:32:10 --> Router Class Initialized
INFO - 2022-06-17 08:32:10 --> Output Class Initialized
INFO - 2022-06-17 08:32:10 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:10 --> Input Class Initialized
INFO - 2022-06-17 08:32:10 --> Language Class Initialized
INFO - 2022-06-17 08:32:10 --> Language Class Initialized
INFO - 2022-06-17 08:32:10 --> Config Class Initialized
INFO - 2022-06-17 08:32:10 --> Loader Class Initialized
INFO - 2022-06-17 08:32:10 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:10 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:10 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:10 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:10 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:32:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:10 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:10 --> Total execution time: 0.0492
INFO - 2022-06-17 08:32:12 --> Config Class Initialized
INFO - 2022-06-17 08:32:12 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:12 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:12 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:12 --> URI Class Initialized
INFO - 2022-06-17 08:32:12 --> Router Class Initialized
INFO - 2022-06-17 08:32:12 --> Output Class Initialized
INFO - 2022-06-17 08:32:12 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:12 --> Input Class Initialized
INFO - 2022-06-17 08:32:12 --> Language Class Initialized
INFO - 2022-06-17 08:32:12 --> Language Class Initialized
INFO - 2022-06-17 08:32:12 --> Config Class Initialized
INFO - 2022-06-17 08:32:12 --> Loader Class Initialized
INFO - 2022-06-17 08:32:12 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:12 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:12 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:12 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:12 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:12 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:12 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:12 --> Total execution time: 0.0469
INFO - 2022-06-17 08:32:12 --> Config Class Initialized
INFO - 2022-06-17 08:32:12 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:12 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:12 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:12 --> URI Class Initialized
INFO - 2022-06-17 08:32:12 --> Router Class Initialized
INFO - 2022-06-17 08:32:12 --> Output Class Initialized
INFO - 2022-06-17 08:32:12 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:12 --> Input Class Initialized
INFO - 2022-06-17 08:32:12 --> Language Class Initialized
INFO - 2022-06-17 08:32:12 --> Language Class Initialized
INFO - 2022-06-17 08:32:12 --> Config Class Initialized
INFO - 2022-06-17 08:32:12 --> Loader Class Initialized
INFO - 2022-06-17 08:32:12 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:12 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:12 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:12 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:12 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:12 --> Controller Class Initialized
INFO - 2022-06-17 08:32:13 --> Config Class Initialized
INFO - 2022-06-17 08:32:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:13 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:13 --> URI Class Initialized
INFO - 2022-06-17 08:32:13 --> Router Class Initialized
INFO - 2022-06-17 08:32:13 --> Output Class Initialized
INFO - 2022-06-17 08:32:13 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:13 --> Input Class Initialized
INFO - 2022-06-17 08:32:13 --> Language Class Initialized
INFO - 2022-06-17 08:32:13 --> Language Class Initialized
INFO - 2022-06-17 08:32:13 --> Config Class Initialized
INFO - 2022-06-17 08:32:13 --> Loader Class Initialized
INFO - 2022-06-17 08:32:13 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:13 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:13 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:13 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:13 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:13 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:13 --> Total execution time: 0.0460
INFO - 2022-06-17 08:32:23 --> Config Class Initialized
INFO - 2022-06-17 08:32:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:23 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:23 --> URI Class Initialized
INFO - 2022-06-17 08:32:23 --> Router Class Initialized
INFO - 2022-06-17 08:32:23 --> Output Class Initialized
INFO - 2022-06-17 08:32:23 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:23 --> Input Class Initialized
INFO - 2022-06-17 08:32:23 --> Language Class Initialized
INFO - 2022-06-17 08:32:23 --> Language Class Initialized
INFO - 2022-06-17 08:32:23 --> Config Class Initialized
INFO - 2022-06-17 08:32:23 --> Loader Class Initialized
INFO - 2022-06-17 08:32:23 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:23 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:23 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:23 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:23 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:23 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:23 --> Total execution time: 0.0486
INFO - 2022-06-17 08:32:23 --> Config Class Initialized
INFO - 2022-06-17 08:32:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:23 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:23 --> URI Class Initialized
INFO - 2022-06-17 08:32:23 --> Router Class Initialized
INFO - 2022-06-17 08:32:23 --> Output Class Initialized
INFO - 2022-06-17 08:32:23 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:23 --> Input Class Initialized
INFO - 2022-06-17 08:32:23 --> Language Class Initialized
INFO - 2022-06-17 08:32:23 --> Language Class Initialized
INFO - 2022-06-17 08:32:23 --> Config Class Initialized
INFO - 2022-06-17 08:32:23 --> Loader Class Initialized
INFO - 2022-06-17 08:32:23 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:23 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:23 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:23 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:23 --> Controller Class Initialized
INFO - 2022-06-17 08:32:24 --> Config Class Initialized
INFO - 2022-06-17 08:32:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:24 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:24 --> URI Class Initialized
INFO - 2022-06-17 08:32:24 --> Router Class Initialized
INFO - 2022-06-17 08:32:24 --> Output Class Initialized
INFO - 2022-06-17 08:32:24 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:24 --> Input Class Initialized
INFO - 2022-06-17 08:32:24 --> Language Class Initialized
INFO - 2022-06-17 08:32:24 --> Language Class Initialized
INFO - 2022-06-17 08:32:24 --> Config Class Initialized
INFO - 2022-06-17 08:32:24 --> Loader Class Initialized
INFO - 2022-06-17 08:32:24 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:24 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:24 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:24 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:24 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:24 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:24 --> Total execution time: 0.0471
INFO - 2022-06-17 08:32:26 --> Config Class Initialized
INFO - 2022-06-17 08:32:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:26 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:26 --> URI Class Initialized
INFO - 2022-06-17 08:32:26 --> Router Class Initialized
INFO - 2022-06-17 08:32:26 --> Output Class Initialized
INFO - 2022-06-17 08:32:26 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:26 --> Input Class Initialized
INFO - 2022-06-17 08:32:26 --> Language Class Initialized
INFO - 2022-06-17 08:32:26 --> Language Class Initialized
INFO - 2022-06-17 08:32:26 --> Config Class Initialized
INFO - 2022-06-17 08:32:26 --> Loader Class Initialized
INFO - 2022-06-17 08:32:26 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:26 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:26 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:26 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:26 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:26 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:26 --> Total execution time: 0.0468
INFO - 2022-06-17 08:32:26 --> Config Class Initialized
INFO - 2022-06-17 08:32:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:26 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:26 --> URI Class Initialized
INFO - 2022-06-17 08:32:26 --> Router Class Initialized
INFO - 2022-06-17 08:32:26 --> Output Class Initialized
INFO - 2022-06-17 08:32:26 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:26 --> Input Class Initialized
INFO - 2022-06-17 08:32:26 --> Language Class Initialized
INFO - 2022-06-17 08:32:26 --> Language Class Initialized
INFO - 2022-06-17 08:32:26 --> Config Class Initialized
INFO - 2022-06-17 08:32:26 --> Loader Class Initialized
INFO - 2022-06-17 08:32:26 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:26 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:26 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:26 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:26 --> Controller Class Initialized
INFO - 2022-06-17 08:32:28 --> Config Class Initialized
INFO - 2022-06-17 08:32:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:28 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:28 --> URI Class Initialized
INFO - 2022-06-17 08:32:28 --> Router Class Initialized
INFO - 2022-06-17 08:32:28 --> Output Class Initialized
INFO - 2022-06-17 08:32:28 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:28 --> Input Class Initialized
INFO - 2022-06-17 08:32:28 --> Language Class Initialized
INFO - 2022-06-17 08:32:28 --> Language Class Initialized
INFO - 2022-06-17 08:32:28 --> Config Class Initialized
INFO - 2022-06-17 08:32:28 --> Loader Class Initialized
INFO - 2022-06-17 08:32:28 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:28 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:28 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:28 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:28 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:32:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:28 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:28 --> Total execution time: 0.0470
INFO - 2022-06-17 08:32:30 --> Config Class Initialized
INFO - 2022-06-17 08:32:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:30 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:30 --> URI Class Initialized
INFO - 2022-06-17 08:32:30 --> Router Class Initialized
INFO - 2022-06-17 08:32:30 --> Output Class Initialized
INFO - 2022-06-17 08:32:30 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:30 --> Input Class Initialized
INFO - 2022-06-17 08:32:30 --> Language Class Initialized
INFO - 2022-06-17 08:32:30 --> Language Class Initialized
INFO - 2022-06-17 08:32:30 --> Config Class Initialized
INFO - 2022-06-17 08:32:30 --> Loader Class Initialized
INFO - 2022-06-17 08:32:30 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:30 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:30 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:30 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:30 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:30 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:30 --> Total execution time: 0.0487
INFO - 2022-06-17 08:32:30 --> Config Class Initialized
INFO - 2022-06-17 08:32:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:30 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:30 --> URI Class Initialized
INFO - 2022-06-17 08:32:30 --> Router Class Initialized
INFO - 2022-06-17 08:32:30 --> Output Class Initialized
INFO - 2022-06-17 08:32:30 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:30 --> Input Class Initialized
INFO - 2022-06-17 08:32:30 --> Language Class Initialized
INFO - 2022-06-17 08:32:30 --> Language Class Initialized
INFO - 2022-06-17 08:32:30 --> Config Class Initialized
INFO - 2022-06-17 08:32:30 --> Loader Class Initialized
INFO - 2022-06-17 08:32:30 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:30 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:30 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:30 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:30 --> Controller Class Initialized
INFO - 2022-06-17 08:32:32 --> Config Class Initialized
INFO - 2022-06-17 08:32:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:32 --> URI Class Initialized
INFO - 2022-06-17 08:32:32 --> Router Class Initialized
INFO - 2022-06-17 08:32:32 --> Output Class Initialized
INFO - 2022-06-17 08:32:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:32 --> Input Class Initialized
INFO - 2022-06-17 08:32:32 --> Language Class Initialized
INFO - 2022-06-17 08:32:32 --> Language Class Initialized
INFO - 2022-06-17 08:32:32 --> Config Class Initialized
INFO - 2022-06-17 08:32:32 --> Loader Class Initialized
INFO - 2022-06-17 08:32:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:32 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:32:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:32 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:32 --> Total execution time: 0.0463
INFO - 2022-06-17 08:32:33 --> Config Class Initialized
INFO - 2022-06-17 08:32:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:33 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:33 --> URI Class Initialized
INFO - 2022-06-17 08:32:33 --> Router Class Initialized
INFO - 2022-06-17 08:32:33 --> Output Class Initialized
INFO - 2022-06-17 08:32:33 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:33 --> Input Class Initialized
INFO - 2022-06-17 08:32:33 --> Language Class Initialized
INFO - 2022-06-17 08:32:33 --> Language Class Initialized
INFO - 2022-06-17 08:32:33 --> Config Class Initialized
INFO - 2022-06-17 08:32:33 --> Loader Class Initialized
INFO - 2022-06-17 08:32:33 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:33 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:33 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:33 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:33 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:32:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:33 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:33 --> Total execution time: 0.0558
INFO - 2022-06-17 08:32:40 --> Config Class Initialized
INFO - 2022-06-17 08:32:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:40 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:40 --> URI Class Initialized
INFO - 2022-06-17 08:32:40 --> Router Class Initialized
INFO - 2022-06-17 08:32:40 --> Output Class Initialized
INFO - 2022-06-17 08:32:40 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:40 --> Input Class Initialized
INFO - 2022-06-17 08:32:40 --> Language Class Initialized
INFO - 2022-06-17 08:32:40 --> Language Class Initialized
INFO - 2022-06-17 08:32:40 --> Config Class Initialized
INFO - 2022-06-17 08:32:40 --> Loader Class Initialized
INFO - 2022-06-17 08:32:40 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:40 --> Controller Class Initialized
INFO - 2022-06-17 08:32:40 --> Config Class Initialized
INFO - 2022-06-17 08:32:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:40 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:40 --> URI Class Initialized
INFO - 2022-06-17 08:32:40 --> Router Class Initialized
INFO - 2022-06-17 08:32:40 --> Output Class Initialized
INFO - 2022-06-17 08:32:40 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:40 --> Input Class Initialized
INFO - 2022-06-17 08:32:40 --> Language Class Initialized
INFO - 2022-06-17 08:32:40 --> Language Class Initialized
INFO - 2022-06-17 08:32:40 --> Config Class Initialized
INFO - 2022-06-17 08:32:40 --> Loader Class Initialized
INFO - 2022-06-17 08:32:40 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:40 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:40 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:40 --> Total execution time: 0.0483
INFO - 2022-06-17 08:32:40 --> Config Class Initialized
INFO - 2022-06-17 08:32:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:40 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:40 --> URI Class Initialized
INFO - 2022-06-17 08:32:40 --> Router Class Initialized
INFO - 2022-06-17 08:32:40 --> Output Class Initialized
INFO - 2022-06-17 08:32:40 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:40 --> Input Class Initialized
INFO - 2022-06-17 08:32:40 --> Language Class Initialized
INFO - 2022-06-17 08:32:40 --> Language Class Initialized
INFO - 2022-06-17 08:32:40 --> Config Class Initialized
INFO - 2022-06-17 08:32:40 --> Loader Class Initialized
INFO - 2022-06-17 08:32:40 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:40 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:40 --> Controller Class Initialized
INFO - 2022-06-17 08:32:42 --> Config Class Initialized
INFO - 2022-06-17 08:32:42 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:42 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:42 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:42 --> URI Class Initialized
INFO - 2022-06-17 08:32:42 --> Router Class Initialized
INFO - 2022-06-17 08:32:42 --> Output Class Initialized
INFO - 2022-06-17 08:32:42 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:42 --> Input Class Initialized
INFO - 2022-06-17 08:32:42 --> Language Class Initialized
INFO - 2022-06-17 08:32:42 --> Language Class Initialized
INFO - 2022-06-17 08:32:42 --> Config Class Initialized
INFO - 2022-06-17 08:32:42 --> Loader Class Initialized
INFO - 2022-06-17 08:32:42 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:42 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:42 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:42 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:42 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:42 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:32:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:42 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:42 --> Total execution time: 0.0564
INFO - 2022-06-17 08:32:45 --> Config Class Initialized
INFO - 2022-06-17 08:32:45 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:45 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:45 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:45 --> URI Class Initialized
INFO - 2022-06-17 08:32:45 --> Router Class Initialized
INFO - 2022-06-17 08:32:45 --> Output Class Initialized
INFO - 2022-06-17 08:32:45 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:45 --> Input Class Initialized
INFO - 2022-06-17 08:32:45 --> Language Class Initialized
INFO - 2022-06-17 08:32:45 --> Language Class Initialized
INFO - 2022-06-17 08:32:45 --> Config Class Initialized
INFO - 2022-06-17 08:32:45 --> Loader Class Initialized
INFO - 2022-06-17 08:32:45 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:45 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:45 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:45 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:45 --> Controller Class Initialized
INFO - 2022-06-17 08:32:45 --> Config Class Initialized
INFO - 2022-06-17 08:32:45 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:45 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:45 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:45 --> URI Class Initialized
INFO - 2022-06-17 08:32:45 --> Router Class Initialized
INFO - 2022-06-17 08:32:45 --> Output Class Initialized
INFO - 2022-06-17 08:32:45 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:45 --> Input Class Initialized
INFO - 2022-06-17 08:32:45 --> Language Class Initialized
INFO - 2022-06-17 08:32:45 --> Language Class Initialized
INFO - 2022-06-17 08:32:45 --> Config Class Initialized
INFO - 2022-06-17 08:32:45 --> Loader Class Initialized
INFO - 2022-06-17 08:32:45 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:45 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:45 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:45 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:45 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:32:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:45 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:45 --> Total execution time: 0.0434
INFO - 2022-06-17 08:32:52 --> Config Class Initialized
INFO - 2022-06-17 08:32:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:52 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:52 --> URI Class Initialized
INFO - 2022-06-17 08:32:52 --> Router Class Initialized
INFO - 2022-06-17 08:32:52 --> Output Class Initialized
INFO - 2022-06-17 08:32:52 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:52 --> Input Class Initialized
INFO - 2022-06-17 08:32:52 --> Language Class Initialized
INFO - 2022-06-17 08:32:52 --> Language Class Initialized
INFO - 2022-06-17 08:32:52 --> Config Class Initialized
INFO - 2022-06-17 08:32:52 --> Loader Class Initialized
INFO - 2022-06-17 08:32:52 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:52 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:52 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:52 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:52 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:52 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:52 --> Total execution time: 0.0444
INFO - 2022-06-17 08:32:58 --> Config Class Initialized
INFO - 2022-06-17 08:32:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:58 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:58 --> URI Class Initialized
INFO - 2022-06-17 08:32:58 --> Router Class Initialized
INFO - 2022-06-17 08:32:58 --> Output Class Initialized
INFO - 2022-06-17 08:32:58 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:58 --> Input Class Initialized
INFO - 2022-06-17 08:32:58 --> Language Class Initialized
INFO - 2022-06-17 08:32:58 --> Language Class Initialized
INFO - 2022-06-17 08:32:58 --> Config Class Initialized
INFO - 2022-06-17 08:32:58 --> Loader Class Initialized
INFO - 2022-06-17 08:32:58 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:58 --> Controller Class Initialized
INFO - 2022-06-17 08:32:58 --> Config Class Initialized
INFO - 2022-06-17 08:32:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:58 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:58 --> URI Class Initialized
INFO - 2022-06-17 08:32:58 --> Router Class Initialized
INFO - 2022-06-17 08:32:58 --> Output Class Initialized
INFO - 2022-06-17 08:32:58 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:58 --> Input Class Initialized
INFO - 2022-06-17 08:32:58 --> Language Class Initialized
INFO - 2022-06-17 08:32:58 --> Language Class Initialized
INFO - 2022-06-17 08:32:58 --> Config Class Initialized
INFO - 2022-06-17 08:32:58 --> Loader Class Initialized
INFO - 2022-06-17 08:32:58 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:58 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:58 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:58 --> Total execution time: 0.0538
INFO - 2022-06-17 08:32:58 --> Config Class Initialized
INFO - 2022-06-17 08:32:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:58 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:58 --> URI Class Initialized
INFO - 2022-06-17 08:32:58 --> Router Class Initialized
INFO - 2022-06-17 08:32:58 --> Output Class Initialized
INFO - 2022-06-17 08:32:58 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:58 --> Input Class Initialized
INFO - 2022-06-17 08:32:58 --> Language Class Initialized
INFO - 2022-06-17 08:32:58 --> Language Class Initialized
INFO - 2022-06-17 08:32:58 --> Config Class Initialized
INFO - 2022-06-17 08:32:58 --> Loader Class Initialized
INFO - 2022-06-17 08:32:58 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:58 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:58 --> Controller Class Initialized
INFO - 2022-06-17 08:32:59 --> Config Class Initialized
INFO - 2022-06-17 08:32:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:32:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:32:59 --> Utf8 Class Initialized
INFO - 2022-06-17 08:32:59 --> URI Class Initialized
INFO - 2022-06-17 08:32:59 --> Router Class Initialized
INFO - 2022-06-17 08:32:59 --> Output Class Initialized
INFO - 2022-06-17 08:32:59 --> Security Class Initialized
DEBUG - 2022-06-17 08:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:32:59 --> Input Class Initialized
INFO - 2022-06-17 08:32:59 --> Language Class Initialized
INFO - 2022-06-17 08:32:59 --> Language Class Initialized
INFO - 2022-06-17 08:32:59 --> Config Class Initialized
INFO - 2022-06-17 08:32:59 --> Loader Class Initialized
INFO - 2022-06-17 08:32:59 --> Helper loaded: url_helper
INFO - 2022-06-17 08:32:59 --> Helper loaded: file_helper
INFO - 2022-06-17 08:32:59 --> Helper loaded: form_helper
INFO - 2022-06-17 08:32:59 --> Helper loaded: my_helper
INFO - 2022-06-17 08:32:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:32:59 --> Controller Class Initialized
DEBUG - 2022-06-17 08:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:32:59 --> Final output sent to browser
DEBUG - 2022-06-17 08:32:59 --> Total execution time: 0.0431
INFO - 2022-06-17 08:33:02 --> Config Class Initialized
INFO - 2022-06-17 08:33:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:02 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:02 --> URI Class Initialized
INFO - 2022-06-17 08:33:02 --> Router Class Initialized
INFO - 2022-06-17 08:33:02 --> Output Class Initialized
INFO - 2022-06-17 08:33:02 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:02 --> Input Class Initialized
INFO - 2022-06-17 08:33:02 --> Language Class Initialized
INFO - 2022-06-17 08:33:02 --> Language Class Initialized
INFO - 2022-06-17 08:33:02 --> Config Class Initialized
INFO - 2022-06-17 08:33:02 --> Loader Class Initialized
INFO - 2022-06-17 08:33:02 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:02 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:02 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:02 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:02 --> Controller Class Initialized
INFO - 2022-06-17 08:33:02 --> Config Class Initialized
INFO - 2022-06-17 08:33:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:02 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:02 --> URI Class Initialized
INFO - 2022-06-17 08:33:02 --> Router Class Initialized
INFO - 2022-06-17 08:33:02 --> Output Class Initialized
INFO - 2022-06-17 08:33:02 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:02 --> Input Class Initialized
INFO - 2022-06-17 08:33:02 --> Language Class Initialized
INFO - 2022-06-17 08:33:02 --> Language Class Initialized
INFO - 2022-06-17 08:33:02 --> Config Class Initialized
INFO - 2022-06-17 08:33:02 --> Loader Class Initialized
INFO - 2022-06-17 08:33:02 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:02 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:02 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:02 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:02 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:33:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:02 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:02 --> Total execution time: 0.0427
INFO - 2022-06-17 08:33:04 --> Config Class Initialized
INFO - 2022-06-17 08:33:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:04 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:04 --> URI Class Initialized
INFO - 2022-06-17 08:33:04 --> Router Class Initialized
INFO - 2022-06-17 08:33:04 --> Output Class Initialized
INFO - 2022-06-17 08:33:04 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:04 --> Input Class Initialized
INFO - 2022-06-17 08:33:04 --> Language Class Initialized
INFO - 2022-06-17 08:33:04 --> Language Class Initialized
INFO - 2022-06-17 08:33:04 --> Config Class Initialized
INFO - 2022-06-17 08:33:04 --> Loader Class Initialized
INFO - 2022-06-17 08:33:04 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:04 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:04 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:04 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:04 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:33:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:04 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:04 --> Total execution time: 0.0446
INFO - 2022-06-17 08:33:08 --> Config Class Initialized
INFO - 2022-06-17 08:33:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:08 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:08 --> URI Class Initialized
INFO - 2022-06-17 08:33:08 --> Router Class Initialized
INFO - 2022-06-17 08:33:08 --> Output Class Initialized
INFO - 2022-06-17 08:33:08 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:08 --> Input Class Initialized
INFO - 2022-06-17 08:33:08 --> Language Class Initialized
INFO - 2022-06-17 08:33:08 --> Language Class Initialized
INFO - 2022-06-17 08:33:08 --> Config Class Initialized
INFO - 2022-06-17 08:33:08 --> Loader Class Initialized
INFO - 2022-06-17 08:33:08 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:08 --> Controller Class Initialized
INFO - 2022-06-17 08:33:08 --> Config Class Initialized
INFO - 2022-06-17 08:33:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:08 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:08 --> URI Class Initialized
INFO - 2022-06-17 08:33:08 --> Router Class Initialized
INFO - 2022-06-17 08:33:08 --> Output Class Initialized
INFO - 2022-06-17 08:33:08 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:08 --> Input Class Initialized
INFO - 2022-06-17 08:33:08 --> Language Class Initialized
INFO - 2022-06-17 08:33:08 --> Language Class Initialized
INFO - 2022-06-17 08:33:08 --> Config Class Initialized
INFO - 2022-06-17 08:33:08 --> Loader Class Initialized
INFO - 2022-06-17 08:33:08 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:08 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:08 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:08 --> Total execution time: 0.0444
INFO - 2022-06-17 08:33:08 --> Config Class Initialized
INFO - 2022-06-17 08:33:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:08 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:08 --> URI Class Initialized
INFO - 2022-06-17 08:33:08 --> Router Class Initialized
INFO - 2022-06-17 08:33:08 --> Output Class Initialized
INFO - 2022-06-17 08:33:08 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:08 --> Input Class Initialized
INFO - 2022-06-17 08:33:08 --> Language Class Initialized
INFO - 2022-06-17 08:33:08 --> Language Class Initialized
INFO - 2022-06-17 08:33:08 --> Config Class Initialized
INFO - 2022-06-17 08:33:08 --> Loader Class Initialized
INFO - 2022-06-17 08:33:08 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:08 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:08 --> Controller Class Initialized
INFO - 2022-06-17 08:33:09 --> Config Class Initialized
INFO - 2022-06-17 08:33:09 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:09 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:09 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:09 --> URI Class Initialized
INFO - 2022-06-17 08:33:09 --> Router Class Initialized
INFO - 2022-06-17 08:33:09 --> Output Class Initialized
INFO - 2022-06-17 08:33:09 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:09 --> Input Class Initialized
INFO - 2022-06-17 08:33:09 --> Language Class Initialized
INFO - 2022-06-17 08:33:10 --> Language Class Initialized
INFO - 2022-06-17 08:33:10 --> Config Class Initialized
INFO - 2022-06-17 08:33:10 --> Loader Class Initialized
INFO - 2022-06-17 08:33:10 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:10 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:10 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:10 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:10 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:33:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:10 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:10 --> Total execution time: 0.0439
INFO - 2022-06-17 08:33:13 --> Config Class Initialized
INFO - 2022-06-17 08:33:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:13 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:13 --> URI Class Initialized
INFO - 2022-06-17 08:33:13 --> Router Class Initialized
INFO - 2022-06-17 08:33:13 --> Output Class Initialized
INFO - 2022-06-17 08:33:13 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:13 --> Input Class Initialized
INFO - 2022-06-17 08:33:13 --> Language Class Initialized
INFO - 2022-06-17 08:33:13 --> Language Class Initialized
INFO - 2022-06-17 08:33:13 --> Config Class Initialized
INFO - 2022-06-17 08:33:13 --> Loader Class Initialized
INFO - 2022-06-17 08:33:13 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:13 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:13 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:13 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:13 --> Controller Class Initialized
INFO - 2022-06-17 08:33:13 --> Config Class Initialized
INFO - 2022-06-17 08:33:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:13 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:13 --> URI Class Initialized
INFO - 2022-06-17 08:33:13 --> Router Class Initialized
INFO - 2022-06-17 08:33:13 --> Output Class Initialized
INFO - 2022-06-17 08:33:13 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:13 --> Input Class Initialized
INFO - 2022-06-17 08:33:13 --> Language Class Initialized
INFO - 2022-06-17 08:33:13 --> Language Class Initialized
INFO - 2022-06-17 08:33:13 --> Config Class Initialized
INFO - 2022-06-17 08:33:13 --> Loader Class Initialized
INFO - 2022-06-17 08:33:13 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:13 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:13 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:13 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:13 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:13 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:13 --> Total execution time: 0.0438
INFO - 2022-06-17 08:33:14 --> Config Class Initialized
INFO - 2022-06-17 08:33:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:14 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:14 --> URI Class Initialized
INFO - 2022-06-17 08:33:14 --> Router Class Initialized
INFO - 2022-06-17 08:33:14 --> Output Class Initialized
INFO - 2022-06-17 08:33:14 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:14 --> Input Class Initialized
INFO - 2022-06-17 08:33:14 --> Language Class Initialized
INFO - 2022-06-17 08:33:14 --> Language Class Initialized
INFO - 2022-06-17 08:33:14 --> Config Class Initialized
INFO - 2022-06-17 08:33:14 --> Loader Class Initialized
INFO - 2022-06-17 08:33:14 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:14 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:14 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:14 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:14 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:14 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:14 --> Total execution time: 0.0435
INFO - 2022-06-17 08:33:18 --> Config Class Initialized
INFO - 2022-06-17 08:33:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:18 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:18 --> URI Class Initialized
INFO - 2022-06-17 08:33:18 --> Router Class Initialized
INFO - 2022-06-17 08:33:18 --> Output Class Initialized
INFO - 2022-06-17 08:33:18 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:18 --> Input Class Initialized
INFO - 2022-06-17 08:33:18 --> Language Class Initialized
INFO - 2022-06-17 08:33:18 --> Language Class Initialized
INFO - 2022-06-17 08:33:18 --> Config Class Initialized
INFO - 2022-06-17 08:33:18 --> Loader Class Initialized
INFO - 2022-06-17 08:33:18 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:18 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:18 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:18 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:19 --> Controller Class Initialized
INFO - 2022-06-17 08:33:19 --> Config Class Initialized
INFO - 2022-06-17 08:33:19 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:19 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:19 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:19 --> URI Class Initialized
INFO - 2022-06-17 08:33:19 --> Router Class Initialized
INFO - 2022-06-17 08:33:19 --> Output Class Initialized
INFO - 2022-06-17 08:33:19 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:19 --> Input Class Initialized
INFO - 2022-06-17 08:33:19 --> Language Class Initialized
INFO - 2022-06-17 08:33:19 --> Language Class Initialized
INFO - 2022-06-17 08:33:19 --> Config Class Initialized
INFO - 2022-06-17 08:33:19 --> Loader Class Initialized
INFO - 2022-06-17 08:33:19 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:19 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:19 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:19 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:19 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:19 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:19 --> Total execution time: 0.0432
INFO - 2022-06-17 08:33:19 --> Config Class Initialized
INFO - 2022-06-17 08:33:19 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:19 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:19 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:19 --> URI Class Initialized
INFO - 2022-06-17 08:33:19 --> Router Class Initialized
INFO - 2022-06-17 08:33:19 --> Output Class Initialized
INFO - 2022-06-17 08:33:19 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:19 --> Input Class Initialized
INFO - 2022-06-17 08:33:19 --> Language Class Initialized
INFO - 2022-06-17 08:33:19 --> Language Class Initialized
INFO - 2022-06-17 08:33:19 --> Config Class Initialized
INFO - 2022-06-17 08:33:19 --> Loader Class Initialized
INFO - 2022-06-17 08:33:19 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:19 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:19 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:19 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:19 --> Controller Class Initialized
INFO - 2022-06-17 08:33:20 --> Config Class Initialized
INFO - 2022-06-17 08:33:20 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:20 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:20 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:20 --> URI Class Initialized
INFO - 2022-06-17 08:33:20 --> Router Class Initialized
INFO - 2022-06-17 08:33:20 --> Output Class Initialized
INFO - 2022-06-17 08:33:20 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:20 --> Input Class Initialized
INFO - 2022-06-17 08:33:20 --> Language Class Initialized
INFO - 2022-06-17 08:33:20 --> Language Class Initialized
INFO - 2022-06-17 08:33:20 --> Config Class Initialized
INFO - 2022-06-17 08:33:20 --> Loader Class Initialized
INFO - 2022-06-17 08:33:20 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:20 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:20 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:20 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:20 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:20 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:20 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:20 --> Total execution time: 0.0530
INFO - 2022-06-17 08:33:23 --> Config Class Initialized
INFO - 2022-06-17 08:33:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:23 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:23 --> URI Class Initialized
INFO - 2022-06-17 08:33:23 --> Router Class Initialized
INFO - 2022-06-17 08:33:23 --> Output Class Initialized
INFO - 2022-06-17 08:33:23 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:23 --> Input Class Initialized
INFO - 2022-06-17 08:33:23 --> Language Class Initialized
INFO - 2022-06-17 08:33:23 --> Language Class Initialized
INFO - 2022-06-17 08:33:23 --> Config Class Initialized
INFO - 2022-06-17 08:33:23 --> Loader Class Initialized
INFO - 2022-06-17 08:33:23 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:23 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:23 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:23 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:23 --> Controller Class Initialized
INFO - 2022-06-17 08:33:23 --> Config Class Initialized
INFO - 2022-06-17 08:33:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:23 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:23 --> URI Class Initialized
INFO - 2022-06-17 08:33:23 --> Router Class Initialized
INFO - 2022-06-17 08:33:23 --> Output Class Initialized
INFO - 2022-06-17 08:33:23 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:23 --> Input Class Initialized
INFO - 2022-06-17 08:33:23 --> Language Class Initialized
INFO - 2022-06-17 08:33:23 --> Language Class Initialized
INFO - 2022-06-17 08:33:23 --> Config Class Initialized
INFO - 2022-06-17 08:33:23 --> Loader Class Initialized
INFO - 2022-06-17 08:33:23 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:23 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:23 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:23 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:23 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:33:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:23 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:23 --> Total execution time: 0.0469
INFO - 2022-06-17 08:33:25 --> Config Class Initialized
INFO - 2022-06-17 08:33:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:25 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:25 --> URI Class Initialized
INFO - 2022-06-17 08:33:25 --> Router Class Initialized
INFO - 2022-06-17 08:33:25 --> Output Class Initialized
INFO - 2022-06-17 08:33:25 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:25 --> Input Class Initialized
INFO - 2022-06-17 08:33:25 --> Language Class Initialized
INFO - 2022-06-17 08:33:25 --> Language Class Initialized
INFO - 2022-06-17 08:33:25 --> Config Class Initialized
INFO - 2022-06-17 08:33:25 --> Loader Class Initialized
INFO - 2022-06-17 08:33:25 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:25 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:25 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:25 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:25 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:33:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:25 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:25 --> Total execution time: 0.0527
INFO - 2022-06-17 08:33:28 --> Config Class Initialized
INFO - 2022-06-17 08:33:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:28 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:28 --> URI Class Initialized
INFO - 2022-06-17 08:33:28 --> Router Class Initialized
INFO - 2022-06-17 08:33:28 --> Output Class Initialized
INFO - 2022-06-17 08:33:28 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:28 --> Input Class Initialized
INFO - 2022-06-17 08:33:28 --> Language Class Initialized
INFO - 2022-06-17 08:33:28 --> Language Class Initialized
INFO - 2022-06-17 08:33:28 --> Config Class Initialized
INFO - 2022-06-17 08:33:28 --> Loader Class Initialized
INFO - 2022-06-17 08:33:28 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:28 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:28 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:28 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:29 --> Controller Class Initialized
INFO - 2022-06-17 08:33:29 --> Config Class Initialized
INFO - 2022-06-17 08:33:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:29 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:29 --> URI Class Initialized
INFO - 2022-06-17 08:33:29 --> Router Class Initialized
INFO - 2022-06-17 08:33:29 --> Output Class Initialized
INFO - 2022-06-17 08:33:29 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:29 --> Input Class Initialized
INFO - 2022-06-17 08:33:29 --> Language Class Initialized
INFO - 2022-06-17 08:33:29 --> Language Class Initialized
INFO - 2022-06-17 08:33:29 --> Config Class Initialized
INFO - 2022-06-17 08:33:29 --> Loader Class Initialized
INFO - 2022-06-17 08:33:29 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:29 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:29 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:29 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:29 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:29 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:29 --> Total execution time: 0.0451
INFO - 2022-06-17 08:33:29 --> Config Class Initialized
INFO - 2022-06-17 08:33:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:29 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:29 --> URI Class Initialized
INFO - 2022-06-17 08:33:29 --> Router Class Initialized
INFO - 2022-06-17 08:33:29 --> Output Class Initialized
INFO - 2022-06-17 08:33:29 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:29 --> Input Class Initialized
INFO - 2022-06-17 08:33:29 --> Language Class Initialized
INFO - 2022-06-17 08:33:29 --> Language Class Initialized
INFO - 2022-06-17 08:33:29 --> Config Class Initialized
INFO - 2022-06-17 08:33:29 --> Loader Class Initialized
INFO - 2022-06-17 08:33:29 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:29 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:29 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:29 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:29 --> Controller Class Initialized
INFO - 2022-06-17 08:33:30 --> Config Class Initialized
INFO - 2022-06-17 08:33:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:30 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:30 --> URI Class Initialized
INFO - 2022-06-17 08:33:30 --> Router Class Initialized
INFO - 2022-06-17 08:33:30 --> Output Class Initialized
INFO - 2022-06-17 08:33:30 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:30 --> Input Class Initialized
INFO - 2022-06-17 08:33:30 --> Language Class Initialized
INFO - 2022-06-17 08:33:30 --> Language Class Initialized
INFO - 2022-06-17 08:33:30 --> Config Class Initialized
INFO - 2022-06-17 08:33:30 --> Loader Class Initialized
INFO - 2022-06-17 08:33:30 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:30 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:30 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:30 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:30 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:30 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:30 --> Total execution time: 0.0431
INFO - 2022-06-17 08:33:35 --> Config Class Initialized
INFO - 2022-06-17 08:33:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:35 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:35 --> URI Class Initialized
INFO - 2022-06-17 08:33:35 --> Router Class Initialized
INFO - 2022-06-17 08:33:35 --> Output Class Initialized
INFO - 2022-06-17 08:33:35 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:35 --> Input Class Initialized
INFO - 2022-06-17 08:33:35 --> Language Class Initialized
INFO - 2022-06-17 08:33:35 --> Language Class Initialized
INFO - 2022-06-17 08:33:35 --> Config Class Initialized
INFO - 2022-06-17 08:33:35 --> Loader Class Initialized
INFO - 2022-06-17 08:33:35 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:35 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:35 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:35 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:35 --> Controller Class Initialized
INFO - 2022-06-17 08:33:35 --> Config Class Initialized
INFO - 2022-06-17 08:33:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:35 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:35 --> URI Class Initialized
INFO - 2022-06-17 08:33:35 --> Router Class Initialized
INFO - 2022-06-17 08:33:35 --> Output Class Initialized
INFO - 2022-06-17 08:33:35 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:35 --> Input Class Initialized
INFO - 2022-06-17 08:33:35 --> Language Class Initialized
INFO - 2022-06-17 08:33:35 --> Language Class Initialized
INFO - 2022-06-17 08:33:35 --> Config Class Initialized
INFO - 2022-06-17 08:33:35 --> Loader Class Initialized
INFO - 2022-06-17 08:33:35 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:35 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:35 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:35 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:35 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:35 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:35 --> Total execution time: 0.0534
INFO - 2022-06-17 08:33:37 --> Config Class Initialized
INFO - 2022-06-17 08:33:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:37 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:37 --> URI Class Initialized
INFO - 2022-06-17 08:33:37 --> Router Class Initialized
INFO - 2022-06-17 08:33:37 --> Output Class Initialized
INFO - 2022-06-17 08:33:37 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:37 --> Input Class Initialized
INFO - 2022-06-17 08:33:37 --> Language Class Initialized
INFO - 2022-06-17 08:33:37 --> Language Class Initialized
INFO - 2022-06-17 08:33:37 --> Config Class Initialized
INFO - 2022-06-17 08:33:37 --> Loader Class Initialized
INFO - 2022-06-17 08:33:37 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:37 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:37 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:37 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:37 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:33:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:37 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:37 --> Total execution time: 0.0523
INFO - 2022-06-17 08:33:42 --> Config Class Initialized
INFO - 2022-06-17 08:33:42 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:42 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:42 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:42 --> URI Class Initialized
INFO - 2022-06-17 08:33:42 --> Router Class Initialized
INFO - 2022-06-17 08:33:42 --> Output Class Initialized
INFO - 2022-06-17 08:33:42 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:42 --> Input Class Initialized
INFO - 2022-06-17 08:33:42 --> Language Class Initialized
INFO - 2022-06-17 08:33:42 --> Language Class Initialized
INFO - 2022-06-17 08:33:42 --> Config Class Initialized
INFO - 2022-06-17 08:33:42 --> Loader Class Initialized
INFO - 2022-06-17 08:33:42 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:42 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:42 --> Controller Class Initialized
INFO - 2022-06-17 08:33:42 --> Config Class Initialized
INFO - 2022-06-17 08:33:42 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:42 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:42 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:42 --> URI Class Initialized
INFO - 2022-06-17 08:33:42 --> Router Class Initialized
INFO - 2022-06-17 08:33:42 --> Output Class Initialized
INFO - 2022-06-17 08:33:42 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:42 --> Input Class Initialized
INFO - 2022-06-17 08:33:42 --> Language Class Initialized
INFO - 2022-06-17 08:33:42 --> Language Class Initialized
INFO - 2022-06-17 08:33:42 --> Config Class Initialized
INFO - 2022-06-17 08:33:42 --> Loader Class Initialized
INFO - 2022-06-17 08:33:42 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:42 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:42 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:33:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:42 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:42 --> Total execution time: 0.0437
INFO - 2022-06-17 08:33:42 --> Config Class Initialized
INFO - 2022-06-17 08:33:42 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:42 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:42 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:42 --> URI Class Initialized
INFO - 2022-06-17 08:33:42 --> Router Class Initialized
INFO - 2022-06-17 08:33:42 --> Output Class Initialized
INFO - 2022-06-17 08:33:42 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:42 --> Input Class Initialized
INFO - 2022-06-17 08:33:42 --> Language Class Initialized
INFO - 2022-06-17 08:33:42 --> Language Class Initialized
INFO - 2022-06-17 08:33:42 --> Config Class Initialized
INFO - 2022-06-17 08:33:42 --> Loader Class Initialized
INFO - 2022-06-17 08:33:42 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:42 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:42 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:42 --> Controller Class Initialized
INFO - 2022-06-17 08:33:43 --> Config Class Initialized
INFO - 2022-06-17 08:33:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:43 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:43 --> URI Class Initialized
INFO - 2022-06-17 08:33:43 --> Router Class Initialized
INFO - 2022-06-17 08:33:43 --> Output Class Initialized
INFO - 2022-06-17 08:33:43 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:43 --> Input Class Initialized
INFO - 2022-06-17 08:33:43 --> Language Class Initialized
INFO - 2022-06-17 08:33:43 --> Language Class Initialized
INFO - 2022-06-17 08:33:43 --> Config Class Initialized
INFO - 2022-06-17 08:33:43 --> Loader Class Initialized
INFO - 2022-06-17 08:33:43 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:43 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:43 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:43 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:43 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:33:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:43 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:43 --> Total execution time: 0.0550
INFO - 2022-06-17 08:33:47 --> Config Class Initialized
INFO - 2022-06-17 08:33:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:47 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:47 --> URI Class Initialized
INFO - 2022-06-17 08:33:47 --> Router Class Initialized
INFO - 2022-06-17 08:33:47 --> Output Class Initialized
INFO - 2022-06-17 08:33:47 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:47 --> Input Class Initialized
INFO - 2022-06-17 08:33:47 --> Language Class Initialized
INFO - 2022-06-17 08:33:47 --> Language Class Initialized
INFO - 2022-06-17 08:33:47 --> Config Class Initialized
INFO - 2022-06-17 08:33:47 --> Loader Class Initialized
INFO - 2022-06-17 08:33:47 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:47 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:47 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:47 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:47 --> Controller Class Initialized
INFO - 2022-06-17 08:33:47 --> Config Class Initialized
INFO - 2022-06-17 08:33:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:47 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:47 --> URI Class Initialized
INFO - 2022-06-17 08:33:47 --> Router Class Initialized
INFO - 2022-06-17 08:33:47 --> Output Class Initialized
INFO - 2022-06-17 08:33:47 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:47 --> Input Class Initialized
INFO - 2022-06-17 08:33:47 --> Language Class Initialized
INFO - 2022-06-17 08:33:47 --> Language Class Initialized
INFO - 2022-06-17 08:33:47 --> Config Class Initialized
INFO - 2022-06-17 08:33:47 --> Loader Class Initialized
INFO - 2022-06-17 08:33:47 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:47 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:47 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:47 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:47 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:33:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:47 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:47 --> Total execution time: 0.0438
INFO - 2022-06-17 08:33:48 --> Config Class Initialized
INFO - 2022-06-17 08:33:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:33:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:33:48 --> Utf8 Class Initialized
INFO - 2022-06-17 08:33:48 --> URI Class Initialized
INFO - 2022-06-17 08:33:48 --> Router Class Initialized
INFO - 2022-06-17 08:33:48 --> Output Class Initialized
INFO - 2022-06-17 08:33:48 --> Security Class Initialized
DEBUG - 2022-06-17 08:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:33:48 --> Input Class Initialized
INFO - 2022-06-17 08:33:48 --> Language Class Initialized
INFO - 2022-06-17 08:33:48 --> Language Class Initialized
INFO - 2022-06-17 08:33:48 --> Config Class Initialized
INFO - 2022-06-17 08:33:48 --> Loader Class Initialized
INFO - 2022-06-17 08:33:48 --> Helper loaded: url_helper
INFO - 2022-06-17 08:33:48 --> Helper loaded: file_helper
INFO - 2022-06-17 08:33:48 --> Helper loaded: form_helper
INFO - 2022-06-17 08:33:48 --> Helper loaded: my_helper
INFO - 2022-06-17 08:33:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:33:48 --> Controller Class Initialized
DEBUG - 2022-06-17 08:33:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:33:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:33:48 --> Final output sent to browser
DEBUG - 2022-06-17 08:33:48 --> Total execution time: 0.0532
INFO - 2022-06-17 08:34:02 --> Config Class Initialized
INFO - 2022-06-17 08:34:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:02 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:02 --> URI Class Initialized
INFO - 2022-06-17 08:34:02 --> Router Class Initialized
INFO - 2022-06-17 08:34:02 --> Output Class Initialized
INFO - 2022-06-17 08:34:02 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:02 --> Input Class Initialized
INFO - 2022-06-17 08:34:02 --> Language Class Initialized
INFO - 2022-06-17 08:34:02 --> Language Class Initialized
INFO - 2022-06-17 08:34:02 --> Config Class Initialized
INFO - 2022-06-17 08:34:02 --> Loader Class Initialized
INFO - 2022-06-17 08:34:02 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:02 --> Controller Class Initialized
INFO - 2022-06-17 08:34:02 --> Config Class Initialized
INFO - 2022-06-17 08:34:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:02 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:02 --> URI Class Initialized
INFO - 2022-06-17 08:34:02 --> Router Class Initialized
INFO - 2022-06-17 08:34:02 --> Output Class Initialized
INFO - 2022-06-17 08:34:02 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:02 --> Input Class Initialized
INFO - 2022-06-17 08:34:02 --> Language Class Initialized
INFO - 2022-06-17 08:34:02 --> Language Class Initialized
INFO - 2022-06-17 08:34:02 --> Config Class Initialized
INFO - 2022-06-17 08:34:02 --> Loader Class Initialized
INFO - 2022-06-17 08:34:02 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:02 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:34:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:02 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:02 --> Total execution time: 0.0543
INFO - 2022-06-17 08:34:02 --> Config Class Initialized
INFO - 2022-06-17 08:34:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:02 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:02 --> URI Class Initialized
INFO - 2022-06-17 08:34:02 --> Router Class Initialized
INFO - 2022-06-17 08:34:02 --> Output Class Initialized
INFO - 2022-06-17 08:34:02 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:02 --> Input Class Initialized
INFO - 2022-06-17 08:34:02 --> Language Class Initialized
INFO - 2022-06-17 08:34:02 --> Language Class Initialized
INFO - 2022-06-17 08:34:02 --> Config Class Initialized
INFO - 2022-06-17 08:34:02 --> Loader Class Initialized
INFO - 2022-06-17 08:34:02 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:02 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:02 --> Controller Class Initialized
INFO - 2022-06-17 08:34:04 --> Config Class Initialized
INFO - 2022-06-17 08:34:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:04 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:04 --> URI Class Initialized
INFO - 2022-06-17 08:34:04 --> Router Class Initialized
INFO - 2022-06-17 08:34:04 --> Output Class Initialized
INFO - 2022-06-17 08:34:04 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:04 --> Input Class Initialized
INFO - 2022-06-17 08:34:04 --> Language Class Initialized
INFO - 2022-06-17 08:34:04 --> Language Class Initialized
INFO - 2022-06-17 08:34:04 --> Config Class Initialized
INFO - 2022-06-17 08:34:04 --> Loader Class Initialized
INFO - 2022-06-17 08:34:04 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:04 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:04 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:04 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:04 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:34:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:04 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:04 --> Total execution time: 0.0517
INFO - 2022-06-17 08:34:10 --> Config Class Initialized
INFO - 2022-06-17 08:34:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:10 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:10 --> URI Class Initialized
INFO - 2022-06-17 08:34:10 --> Router Class Initialized
INFO - 2022-06-17 08:34:10 --> Output Class Initialized
INFO - 2022-06-17 08:34:10 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:10 --> Input Class Initialized
INFO - 2022-06-17 08:34:10 --> Language Class Initialized
INFO - 2022-06-17 08:34:10 --> Language Class Initialized
INFO - 2022-06-17 08:34:10 --> Config Class Initialized
INFO - 2022-06-17 08:34:10 --> Loader Class Initialized
INFO - 2022-06-17 08:34:10 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:10 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:10 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:10 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:10 --> Controller Class Initialized
INFO - 2022-06-17 08:34:10 --> Config Class Initialized
INFO - 2022-06-17 08:34:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:10 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:10 --> URI Class Initialized
INFO - 2022-06-17 08:34:10 --> Router Class Initialized
INFO - 2022-06-17 08:34:10 --> Output Class Initialized
INFO - 2022-06-17 08:34:10 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:10 --> Input Class Initialized
INFO - 2022-06-17 08:34:10 --> Language Class Initialized
INFO - 2022-06-17 08:34:10 --> Language Class Initialized
INFO - 2022-06-17 08:34:10 --> Config Class Initialized
INFO - 2022-06-17 08:34:10 --> Loader Class Initialized
INFO - 2022-06-17 08:34:10 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:10 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:10 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:10 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:10 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:34:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:10 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:10 --> Total execution time: 0.0545
INFO - 2022-06-17 08:34:19 --> Config Class Initialized
INFO - 2022-06-17 08:34:19 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:19 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:19 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:19 --> URI Class Initialized
INFO - 2022-06-17 08:34:19 --> Router Class Initialized
INFO - 2022-06-17 08:34:19 --> Output Class Initialized
INFO - 2022-06-17 08:34:19 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:19 --> Input Class Initialized
INFO - 2022-06-17 08:34:19 --> Language Class Initialized
INFO - 2022-06-17 08:34:19 --> Language Class Initialized
INFO - 2022-06-17 08:34:19 --> Config Class Initialized
INFO - 2022-06-17 08:34:19 --> Loader Class Initialized
INFO - 2022-06-17 08:34:19 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:19 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:19 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:19 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:19 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:34:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:19 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:19 --> Total execution time: 0.0471
INFO - 2022-06-17 08:34:19 --> Config Class Initialized
INFO - 2022-06-17 08:34:19 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:19 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:19 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:19 --> URI Class Initialized
INFO - 2022-06-17 08:34:19 --> Router Class Initialized
INFO - 2022-06-17 08:34:19 --> Output Class Initialized
INFO - 2022-06-17 08:34:19 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:19 --> Input Class Initialized
INFO - 2022-06-17 08:34:19 --> Language Class Initialized
INFO - 2022-06-17 08:34:19 --> Language Class Initialized
INFO - 2022-06-17 08:34:19 --> Config Class Initialized
INFO - 2022-06-17 08:34:19 --> Loader Class Initialized
INFO - 2022-06-17 08:34:19 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:19 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:19 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:19 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:19 --> Controller Class Initialized
INFO - 2022-06-17 08:34:21 --> Config Class Initialized
INFO - 2022-06-17 08:34:21 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:21 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:21 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:21 --> URI Class Initialized
INFO - 2022-06-17 08:34:21 --> Router Class Initialized
INFO - 2022-06-17 08:34:21 --> Output Class Initialized
INFO - 2022-06-17 08:34:21 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:21 --> Input Class Initialized
INFO - 2022-06-17 08:34:21 --> Language Class Initialized
INFO - 2022-06-17 08:34:21 --> Language Class Initialized
INFO - 2022-06-17 08:34:21 --> Config Class Initialized
INFO - 2022-06-17 08:34:21 --> Loader Class Initialized
INFO - 2022-06-17 08:34:21 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:21 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:21 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:21 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:21 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:21 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:21 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:21 --> Total execution time: 0.0462
INFO - 2022-06-17 08:34:23 --> Config Class Initialized
INFO - 2022-06-17 08:34:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:23 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:23 --> URI Class Initialized
INFO - 2022-06-17 08:34:23 --> Router Class Initialized
INFO - 2022-06-17 08:34:23 --> Output Class Initialized
INFO - 2022-06-17 08:34:23 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:23 --> Input Class Initialized
INFO - 2022-06-17 08:34:23 --> Language Class Initialized
INFO - 2022-06-17 08:34:23 --> Language Class Initialized
INFO - 2022-06-17 08:34:23 --> Config Class Initialized
INFO - 2022-06-17 08:34:23 --> Loader Class Initialized
INFO - 2022-06-17 08:34:23 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:23 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:23 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:23 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:23 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:23 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:23 --> Total execution time: 0.0465
INFO - 2022-06-17 08:34:23 --> Config Class Initialized
INFO - 2022-06-17 08:34:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:23 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:23 --> URI Class Initialized
INFO - 2022-06-17 08:34:23 --> Router Class Initialized
INFO - 2022-06-17 08:34:23 --> Output Class Initialized
INFO - 2022-06-17 08:34:23 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:23 --> Input Class Initialized
INFO - 2022-06-17 08:34:23 --> Language Class Initialized
INFO - 2022-06-17 08:34:23 --> Language Class Initialized
INFO - 2022-06-17 08:34:23 --> Config Class Initialized
INFO - 2022-06-17 08:34:23 --> Loader Class Initialized
INFO - 2022-06-17 08:34:23 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:23 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:23 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:23 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:23 --> Controller Class Initialized
INFO - 2022-06-17 08:34:24 --> Config Class Initialized
INFO - 2022-06-17 08:34:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:24 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:24 --> URI Class Initialized
INFO - 2022-06-17 08:34:24 --> Router Class Initialized
INFO - 2022-06-17 08:34:24 --> Output Class Initialized
INFO - 2022-06-17 08:34:24 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:24 --> Input Class Initialized
INFO - 2022-06-17 08:34:24 --> Language Class Initialized
INFO - 2022-06-17 08:34:24 --> Language Class Initialized
INFO - 2022-06-17 08:34:24 --> Config Class Initialized
INFO - 2022-06-17 08:34:24 --> Loader Class Initialized
INFO - 2022-06-17 08:34:24 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:24 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:24 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:24 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:24 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:24 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:24 --> Total execution time: 0.0450
INFO - 2022-06-17 08:34:25 --> Config Class Initialized
INFO - 2022-06-17 08:34:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:25 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:25 --> URI Class Initialized
INFO - 2022-06-17 08:34:25 --> Router Class Initialized
INFO - 2022-06-17 08:34:25 --> Output Class Initialized
INFO - 2022-06-17 08:34:25 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:25 --> Input Class Initialized
INFO - 2022-06-17 08:34:25 --> Language Class Initialized
INFO - 2022-06-17 08:34:25 --> Language Class Initialized
INFO - 2022-06-17 08:34:25 --> Config Class Initialized
INFO - 2022-06-17 08:34:25 --> Loader Class Initialized
INFO - 2022-06-17 08:34:25 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:25 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:25 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:25 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:25 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:25 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:25 --> Total execution time: 0.0466
INFO - 2022-06-17 08:34:25 --> Config Class Initialized
INFO - 2022-06-17 08:34:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:25 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:25 --> URI Class Initialized
INFO - 2022-06-17 08:34:25 --> Router Class Initialized
INFO - 2022-06-17 08:34:25 --> Output Class Initialized
INFO - 2022-06-17 08:34:25 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:25 --> Input Class Initialized
INFO - 2022-06-17 08:34:25 --> Language Class Initialized
INFO - 2022-06-17 08:34:25 --> Language Class Initialized
INFO - 2022-06-17 08:34:25 --> Config Class Initialized
INFO - 2022-06-17 08:34:25 --> Loader Class Initialized
INFO - 2022-06-17 08:34:25 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:25 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:25 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:25 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:25 --> Controller Class Initialized
INFO - 2022-06-17 08:34:26 --> Config Class Initialized
INFO - 2022-06-17 08:34:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:26 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:26 --> URI Class Initialized
INFO - 2022-06-17 08:34:26 --> Router Class Initialized
INFO - 2022-06-17 08:34:26 --> Output Class Initialized
INFO - 2022-06-17 08:34:26 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:26 --> Input Class Initialized
INFO - 2022-06-17 08:34:26 --> Language Class Initialized
INFO - 2022-06-17 08:34:26 --> Language Class Initialized
INFO - 2022-06-17 08:34:26 --> Config Class Initialized
INFO - 2022-06-17 08:34:26 --> Loader Class Initialized
INFO - 2022-06-17 08:34:26 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:26 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:26 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:26 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:26 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:34:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:26 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:26 --> Total execution time: 0.0479
INFO - 2022-06-17 08:34:27 --> Config Class Initialized
INFO - 2022-06-17 08:34:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:27 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:27 --> URI Class Initialized
INFO - 2022-06-17 08:34:27 --> Router Class Initialized
INFO - 2022-06-17 08:34:27 --> Output Class Initialized
INFO - 2022-06-17 08:34:27 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:27 --> Input Class Initialized
INFO - 2022-06-17 08:34:27 --> Language Class Initialized
INFO - 2022-06-17 08:34:27 --> Language Class Initialized
INFO - 2022-06-17 08:34:27 --> Config Class Initialized
INFO - 2022-06-17 08:34:27 --> Loader Class Initialized
INFO - 2022-06-17 08:34:27 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:27 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:27 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:27 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:27 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:34:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:27 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:27 --> Total execution time: 0.0538
INFO - 2022-06-17 08:34:32 --> Config Class Initialized
INFO - 2022-06-17 08:34:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:32 --> URI Class Initialized
INFO - 2022-06-17 08:34:32 --> Router Class Initialized
INFO - 2022-06-17 08:34:32 --> Output Class Initialized
INFO - 2022-06-17 08:34:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:32 --> Input Class Initialized
INFO - 2022-06-17 08:34:32 --> Language Class Initialized
INFO - 2022-06-17 08:34:32 --> Language Class Initialized
INFO - 2022-06-17 08:34:32 --> Config Class Initialized
INFO - 2022-06-17 08:34:32 --> Loader Class Initialized
INFO - 2022-06-17 08:34:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:32 --> Controller Class Initialized
INFO - 2022-06-17 08:34:32 --> Config Class Initialized
INFO - 2022-06-17 08:34:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:32 --> URI Class Initialized
INFO - 2022-06-17 08:34:32 --> Router Class Initialized
INFO - 2022-06-17 08:34:32 --> Output Class Initialized
INFO - 2022-06-17 08:34:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:32 --> Input Class Initialized
INFO - 2022-06-17 08:34:32 --> Language Class Initialized
INFO - 2022-06-17 08:34:32 --> Language Class Initialized
INFO - 2022-06-17 08:34:32 --> Config Class Initialized
INFO - 2022-06-17 08:34:32 --> Loader Class Initialized
INFO - 2022-06-17 08:34:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:32 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:34:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:32 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:32 --> Total execution time: 0.0554
INFO - 2022-06-17 08:34:32 --> Config Class Initialized
INFO - 2022-06-17 08:34:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:32 --> URI Class Initialized
INFO - 2022-06-17 08:34:32 --> Router Class Initialized
INFO - 2022-06-17 08:34:32 --> Output Class Initialized
INFO - 2022-06-17 08:34:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:32 --> Input Class Initialized
INFO - 2022-06-17 08:34:32 --> Language Class Initialized
INFO - 2022-06-17 08:34:32 --> Language Class Initialized
INFO - 2022-06-17 08:34:32 --> Config Class Initialized
INFO - 2022-06-17 08:34:32 --> Loader Class Initialized
INFO - 2022-06-17 08:34:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:32 --> Controller Class Initialized
INFO - 2022-06-17 08:34:33 --> Config Class Initialized
INFO - 2022-06-17 08:34:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:33 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:33 --> URI Class Initialized
INFO - 2022-06-17 08:34:33 --> Router Class Initialized
INFO - 2022-06-17 08:34:33 --> Output Class Initialized
INFO - 2022-06-17 08:34:33 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:33 --> Input Class Initialized
INFO - 2022-06-17 08:34:33 --> Language Class Initialized
INFO - 2022-06-17 08:34:33 --> Language Class Initialized
INFO - 2022-06-17 08:34:33 --> Config Class Initialized
INFO - 2022-06-17 08:34:33 --> Loader Class Initialized
INFO - 2022-06-17 08:34:33 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:33 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:33 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:33 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:33 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:33 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:33 --> Total execution time: 0.0583
INFO - 2022-06-17 08:34:33 --> Config Class Initialized
INFO - 2022-06-17 08:34:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:33 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:33 --> URI Class Initialized
INFO - 2022-06-17 08:34:33 --> Router Class Initialized
INFO - 2022-06-17 08:34:33 --> Output Class Initialized
INFO - 2022-06-17 08:34:33 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:33 --> Input Class Initialized
INFO - 2022-06-17 08:34:33 --> Language Class Initialized
INFO - 2022-06-17 08:34:33 --> Language Class Initialized
INFO - 2022-06-17 08:34:33 --> Config Class Initialized
INFO - 2022-06-17 08:34:33 --> Loader Class Initialized
INFO - 2022-06-17 08:34:33 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:33 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:33 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:33 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:33 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:33 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:33 --> Total execution time: 0.0437
INFO - 2022-06-17 08:34:37 --> Config Class Initialized
INFO - 2022-06-17 08:34:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:37 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:37 --> URI Class Initialized
INFO - 2022-06-17 08:34:37 --> Router Class Initialized
INFO - 2022-06-17 08:34:37 --> Output Class Initialized
INFO - 2022-06-17 08:34:37 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:37 --> Input Class Initialized
INFO - 2022-06-17 08:34:37 --> Language Class Initialized
INFO - 2022-06-17 08:34:37 --> Language Class Initialized
INFO - 2022-06-17 08:34:37 --> Config Class Initialized
INFO - 2022-06-17 08:34:37 --> Loader Class Initialized
INFO - 2022-06-17 08:34:37 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:37 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:37 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:37 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:37 --> Controller Class Initialized
INFO - 2022-06-17 08:34:37 --> Config Class Initialized
INFO - 2022-06-17 08:34:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:37 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:37 --> URI Class Initialized
INFO - 2022-06-17 08:34:37 --> Router Class Initialized
INFO - 2022-06-17 08:34:37 --> Output Class Initialized
INFO - 2022-06-17 08:34:37 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:37 --> Input Class Initialized
INFO - 2022-06-17 08:34:37 --> Language Class Initialized
INFO - 2022-06-17 08:34:37 --> Language Class Initialized
INFO - 2022-06-17 08:34:37 --> Config Class Initialized
INFO - 2022-06-17 08:34:37 --> Loader Class Initialized
INFO - 2022-06-17 08:34:37 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:37 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:37 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:37 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:37 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:34:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:37 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:37 --> Total execution time: 0.0533
INFO - 2022-06-17 08:34:38 --> Config Class Initialized
INFO - 2022-06-17 08:34:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:38 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:38 --> URI Class Initialized
INFO - 2022-06-17 08:34:38 --> Router Class Initialized
INFO - 2022-06-17 08:34:38 --> Output Class Initialized
INFO - 2022-06-17 08:34:38 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:38 --> Input Class Initialized
INFO - 2022-06-17 08:34:38 --> Language Class Initialized
INFO - 2022-06-17 08:34:38 --> Language Class Initialized
INFO - 2022-06-17 08:34:38 --> Config Class Initialized
INFO - 2022-06-17 08:34:38 --> Loader Class Initialized
INFO - 2022-06-17 08:34:38 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:38 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:38 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:38 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:38 --> Controller Class Initialized
INFO - 2022-06-17 08:34:38 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:38 --> Total execution time: 0.0526
INFO - 2022-06-17 08:34:41 --> Config Class Initialized
INFO - 2022-06-17 08:34:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:41 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:41 --> URI Class Initialized
INFO - 2022-06-17 08:34:41 --> Router Class Initialized
INFO - 2022-06-17 08:34:41 --> Output Class Initialized
INFO - 2022-06-17 08:34:41 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:41 --> Input Class Initialized
INFO - 2022-06-17 08:34:41 --> Language Class Initialized
INFO - 2022-06-17 08:34:41 --> Language Class Initialized
INFO - 2022-06-17 08:34:41 --> Config Class Initialized
INFO - 2022-06-17 08:34:41 --> Loader Class Initialized
INFO - 2022-06-17 08:34:41 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:41 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:41 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:41 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:41 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:34:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:41 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:41 --> Total execution time: 0.0568
INFO - 2022-06-17 08:34:44 --> Config Class Initialized
INFO - 2022-06-17 08:34:44 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:44 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:44 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:44 --> URI Class Initialized
INFO - 2022-06-17 08:34:44 --> Router Class Initialized
INFO - 2022-06-17 08:34:44 --> Output Class Initialized
INFO - 2022-06-17 08:34:44 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:44 --> Input Class Initialized
INFO - 2022-06-17 08:34:44 --> Language Class Initialized
INFO - 2022-06-17 08:34:44 --> Language Class Initialized
INFO - 2022-06-17 08:34:44 --> Config Class Initialized
INFO - 2022-06-17 08:34:44 --> Loader Class Initialized
INFO - 2022-06-17 08:34:44 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:44 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:44 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:44 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:44 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:44 --> Controller Class Initialized
INFO - 2022-06-17 08:34:44 --> Config Class Initialized
INFO - 2022-06-17 08:34:44 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:44 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:44 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:44 --> URI Class Initialized
INFO - 2022-06-17 08:34:44 --> Router Class Initialized
INFO - 2022-06-17 08:34:44 --> Output Class Initialized
INFO - 2022-06-17 08:34:44 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:44 --> Input Class Initialized
INFO - 2022-06-17 08:34:44 --> Language Class Initialized
INFO - 2022-06-17 08:34:44 --> Language Class Initialized
INFO - 2022-06-17 08:34:44 --> Config Class Initialized
INFO - 2022-06-17 08:34:44 --> Loader Class Initialized
INFO - 2022-06-17 08:34:44 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:44 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:44 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:44 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:44 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:44 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:34:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:44 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:44 --> Total execution time: 0.0420
INFO - 2022-06-17 08:34:44 --> Config Class Initialized
INFO - 2022-06-17 08:34:44 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:44 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:44 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:44 --> URI Class Initialized
INFO - 2022-06-17 08:34:44 --> Router Class Initialized
INFO - 2022-06-17 08:34:44 --> Output Class Initialized
INFO - 2022-06-17 08:34:44 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:44 --> Input Class Initialized
INFO - 2022-06-17 08:34:44 --> Language Class Initialized
INFO - 2022-06-17 08:34:44 --> Language Class Initialized
INFO - 2022-06-17 08:34:44 --> Config Class Initialized
INFO - 2022-06-17 08:34:45 --> Loader Class Initialized
INFO - 2022-06-17 08:34:45 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:45 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:45 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:45 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:45 --> Controller Class Initialized
INFO - 2022-06-17 08:34:46 --> Config Class Initialized
INFO - 2022-06-17 08:34:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:46 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:46 --> URI Class Initialized
INFO - 2022-06-17 08:34:46 --> Router Class Initialized
INFO - 2022-06-17 08:34:46 --> Output Class Initialized
INFO - 2022-06-17 08:34:46 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:46 --> Input Class Initialized
INFO - 2022-06-17 08:34:46 --> Language Class Initialized
INFO - 2022-06-17 08:34:46 --> Language Class Initialized
INFO - 2022-06-17 08:34:46 --> Config Class Initialized
INFO - 2022-06-17 08:34:46 --> Loader Class Initialized
INFO - 2022-06-17 08:34:46 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:46 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:46 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:46 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:46 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:46 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:46 --> Total execution time: 0.0439
INFO - 2022-06-17 08:34:50 --> Config Class Initialized
INFO - 2022-06-17 08:34:50 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:50 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:50 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:50 --> URI Class Initialized
INFO - 2022-06-17 08:34:50 --> Router Class Initialized
INFO - 2022-06-17 08:34:50 --> Output Class Initialized
INFO - 2022-06-17 08:34:50 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:50 --> Input Class Initialized
INFO - 2022-06-17 08:34:50 --> Language Class Initialized
INFO - 2022-06-17 08:34:50 --> Language Class Initialized
INFO - 2022-06-17 08:34:50 --> Config Class Initialized
INFO - 2022-06-17 08:34:50 --> Loader Class Initialized
INFO - 2022-06-17 08:34:50 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:50 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:50 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:50 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:50 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:50 --> Controller Class Initialized
INFO - 2022-06-17 08:34:50 --> Config Class Initialized
INFO - 2022-06-17 08:34:50 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:50 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:50 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:50 --> URI Class Initialized
INFO - 2022-06-17 08:34:50 --> Router Class Initialized
INFO - 2022-06-17 08:34:50 --> Output Class Initialized
INFO - 2022-06-17 08:34:50 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:50 --> Input Class Initialized
INFO - 2022-06-17 08:34:50 --> Language Class Initialized
INFO - 2022-06-17 08:34:50 --> Language Class Initialized
INFO - 2022-06-17 08:34:50 --> Config Class Initialized
INFO - 2022-06-17 08:34:50 --> Loader Class Initialized
INFO - 2022-06-17 08:34:50 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:50 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:50 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:50 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:50 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:50 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:50 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:50 --> Total execution time: 0.0447
INFO - 2022-06-17 08:34:52 --> Config Class Initialized
INFO - 2022-06-17 08:34:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:52 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:52 --> URI Class Initialized
INFO - 2022-06-17 08:34:52 --> Router Class Initialized
INFO - 2022-06-17 08:34:52 --> Output Class Initialized
INFO - 2022-06-17 08:34:52 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:52 --> Input Class Initialized
INFO - 2022-06-17 08:34:52 --> Language Class Initialized
INFO - 2022-06-17 08:34:52 --> Language Class Initialized
INFO - 2022-06-17 08:34:52 --> Config Class Initialized
INFO - 2022-06-17 08:34:52 --> Loader Class Initialized
INFO - 2022-06-17 08:34:52 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:52 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:52 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:52 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:52 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:34:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:52 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:52 --> Total execution time: 0.0448
INFO - 2022-06-17 08:34:55 --> Config Class Initialized
INFO - 2022-06-17 08:34:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:55 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:55 --> URI Class Initialized
INFO - 2022-06-17 08:34:55 --> Router Class Initialized
INFO - 2022-06-17 08:34:55 --> Output Class Initialized
INFO - 2022-06-17 08:34:55 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:55 --> Input Class Initialized
INFO - 2022-06-17 08:34:55 --> Language Class Initialized
INFO - 2022-06-17 08:34:55 --> Language Class Initialized
INFO - 2022-06-17 08:34:55 --> Config Class Initialized
INFO - 2022-06-17 08:34:55 --> Loader Class Initialized
INFO - 2022-06-17 08:34:55 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:55 --> Controller Class Initialized
INFO - 2022-06-17 08:34:55 --> Config Class Initialized
INFO - 2022-06-17 08:34:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:55 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:55 --> URI Class Initialized
INFO - 2022-06-17 08:34:55 --> Router Class Initialized
INFO - 2022-06-17 08:34:55 --> Output Class Initialized
INFO - 2022-06-17 08:34:55 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:55 --> Input Class Initialized
INFO - 2022-06-17 08:34:55 --> Language Class Initialized
INFO - 2022-06-17 08:34:55 --> Language Class Initialized
INFO - 2022-06-17 08:34:55 --> Config Class Initialized
INFO - 2022-06-17 08:34:55 --> Loader Class Initialized
INFO - 2022-06-17 08:34:55 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:55 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:34:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:55 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:55 --> Total execution time: 0.0560
INFO - 2022-06-17 08:34:55 --> Config Class Initialized
INFO - 2022-06-17 08:34:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:55 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:55 --> URI Class Initialized
INFO - 2022-06-17 08:34:55 --> Router Class Initialized
INFO - 2022-06-17 08:34:55 --> Output Class Initialized
INFO - 2022-06-17 08:34:55 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:55 --> Input Class Initialized
INFO - 2022-06-17 08:34:55 --> Language Class Initialized
INFO - 2022-06-17 08:34:55 --> Language Class Initialized
INFO - 2022-06-17 08:34:55 --> Config Class Initialized
INFO - 2022-06-17 08:34:55 --> Loader Class Initialized
INFO - 2022-06-17 08:34:55 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:55 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:55 --> Controller Class Initialized
INFO - 2022-06-17 08:34:57 --> Config Class Initialized
INFO - 2022-06-17 08:34:57 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:34:57 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:34:57 --> Utf8 Class Initialized
INFO - 2022-06-17 08:34:57 --> URI Class Initialized
INFO - 2022-06-17 08:34:57 --> Router Class Initialized
INFO - 2022-06-17 08:34:57 --> Output Class Initialized
INFO - 2022-06-17 08:34:57 --> Security Class Initialized
DEBUG - 2022-06-17 08:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:34:57 --> Input Class Initialized
INFO - 2022-06-17 08:34:57 --> Language Class Initialized
INFO - 2022-06-17 08:34:57 --> Language Class Initialized
INFO - 2022-06-17 08:34:57 --> Config Class Initialized
INFO - 2022-06-17 08:34:57 --> Loader Class Initialized
INFO - 2022-06-17 08:34:57 --> Helper loaded: url_helper
INFO - 2022-06-17 08:34:57 --> Helper loaded: file_helper
INFO - 2022-06-17 08:34:57 --> Helper loaded: form_helper
INFO - 2022-06-17 08:34:57 --> Helper loaded: my_helper
INFO - 2022-06-17 08:34:57 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:34:57 --> Controller Class Initialized
DEBUG - 2022-06-17 08:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:34:57 --> Final output sent to browser
DEBUG - 2022-06-17 08:34:57 --> Total execution time: 0.0528
INFO - 2022-06-17 08:35:01 --> Config Class Initialized
INFO - 2022-06-17 08:35:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:01 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:01 --> URI Class Initialized
INFO - 2022-06-17 08:35:01 --> Router Class Initialized
INFO - 2022-06-17 08:35:01 --> Output Class Initialized
INFO - 2022-06-17 08:35:01 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:01 --> Input Class Initialized
INFO - 2022-06-17 08:35:01 --> Language Class Initialized
INFO - 2022-06-17 08:35:01 --> Language Class Initialized
INFO - 2022-06-17 08:35:01 --> Config Class Initialized
INFO - 2022-06-17 08:35:01 --> Loader Class Initialized
INFO - 2022-06-17 08:35:01 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:01 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:01 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:01 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:01 --> Controller Class Initialized
INFO - 2022-06-17 08:35:01 --> Config Class Initialized
INFO - 2022-06-17 08:35:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:01 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:01 --> URI Class Initialized
INFO - 2022-06-17 08:35:01 --> Router Class Initialized
INFO - 2022-06-17 08:35:01 --> Output Class Initialized
INFO - 2022-06-17 08:35:01 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:01 --> Input Class Initialized
INFO - 2022-06-17 08:35:01 --> Language Class Initialized
INFO - 2022-06-17 08:35:01 --> Language Class Initialized
INFO - 2022-06-17 08:35:01 --> Config Class Initialized
INFO - 2022-06-17 08:35:01 --> Loader Class Initialized
INFO - 2022-06-17 08:35:01 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:01 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:01 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:01 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:01 --> Controller Class Initialized
DEBUG - 2022-06-17 08:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:35:01 --> Final output sent to browser
DEBUG - 2022-06-17 08:35:01 --> Total execution time: 0.0439
INFO - 2022-06-17 08:35:16 --> Config Class Initialized
INFO - 2022-06-17 08:35:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:16 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:16 --> URI Class Initialized
INFO - 2022-06-17 08:35:16 --> Router Class Initialized
INFO - 2022-06-17 08:35:16 --> Output Class Initialized
INFO - 2022-06-17 08:35:16 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:16 --> Input Class Initialized
INFO - 2022-06-17 08:35:16 --> Language Class Initialized
INFO - 2022-06-17 08:35:16 --> Language Class Initialized
INFO - 2022-06-17 08:35:16 --> Config Class Initialized
INFO - 2022-06-17 08:35:16 --> Loader Class Initialized
INFO - 2022-06-17 08:35:16 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:16 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:16 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:16 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:16 --> Controller Class Initialized
INFO - 2022-06-17 08:35:16 --> Helper loaded: cookie_helper
INFO - 2022-06-17 08:35:16 --> Config Class Initialized
INFO - 2022-06-17 08:35:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:16 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:16 --> URI Class Initialized
INFO - 2022-06-17 08:35:16 --> Router Class Initialized
INFO - 2022-06-17 08:35:16 --> Output Class Initialized
INFO - 2022-06-17 08:35:16 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:16 --> Input Class Initialized
INFO - 2022-06-17 08:35:16 --> Language Class Initialized
INFO - 2022-06-17 08:35:16 --> Language Class Initialized
INFO - 2022-06-17 08:35:16 --> Config Class Initialized
INFO - 2022-06-17 08:35:16 --> Loader Class Initialized
INFO - 2022-06-17 08:35:16 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:16 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:16 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:16 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:16 --> Controller Class Initialized
DEBUG - 2022-06-17 08:35:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 08:35:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:35:16 --> Final output sent to browser
DEBUG - 2022-06-17 08:35:16 --> Total execution time: 0.0402
INFO - 2022-06-17 08:35:21 --> Config Class Initialized
INFO - 2022-06-17 08:35:21 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:21 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:21 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:21 --> URI Class Initialized
INFO - 2022-06-17 08:35:21 --> Router Class Initialized
INFO - 2022-06-17 08:35:21 --> Output Class Initialized
INFO - 2022-06-17 08:35:21 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:21 --> Input Class Initialized
INFO - 2022-06-17 08:35:21 --> Language Class Initialized
INFO - 2022-06-17 08:35:21 --> Language Class Initialized
INFO - 2022-06-17 08:35:21 --> Config Class Initialized
INFO - 2022-06-17 08:35:21 --> Loader Class Initialized
INFO - 2022-06-17 08:35:21 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:21 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:21 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:21 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:21 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:21 --> Controller Class Initialized
INFO - 2022-06-17 08:35:21 --> Helper loaded: cookie_helper
INFO - 2022-06-17 08:35:21 --> Final output sent to browser
DEBUG - 2022-06-17 08:35:21 --> Total execution time: 0.0513
INFO - 2022-06-17 08:35:22 --> Config Class Initialized
INFO - 2022-06-17 08:35:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:22 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:22 --> URI Class Initialized
INFO - 2022-06-17 08:35:22 --> Router Class Initialized
INFO - 2022-06-17 08:35:22 --> Output Class Initialized
INFO - 2022-06-17 08:35:22 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:22 --> Input Class Initialized
INFO - 2022-06-17 08:35:22 --> Language Class Initialized
INFO - 2022-06-17 08:35:22 --> Language Class Initialized
INFO - 2022-06-17 08:35:22 --> Config Class Initialized
INFO - 2022-06-17 08:35:22 --> Loader Class Initialized
INFO - 2022-06-17 08:35:22 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:22 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:22 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:22 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:22 --> Controller Class Initialized
DEBUG - 2022-06-17 08:35:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:35:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:35:22 --> Final output sent to browser
DEBUG - 2022-06-17 08:35:22 --> Total execution time: 0.0999
INFO - 2022-06-17 08:35:26 --> Config Class Initialized
INFO - 2022-06-17 08:35:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:26 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:26 --> URI Class Initialized
INFO - 2022-06-17 08:35:26 --> Router Class Initialized
INFO - 2022-06-17 08:35:26 --> Output Class Initialized
INFO - 2022-06-17 08:35:26 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:26 --> Input Class Initialized
INFO - 2022-06-17 08:35:26 --> Language Class Initialized
INFO - 2022-06-17 08:35:26 --> Language Class Initialized
INFO - 2022-06-17 08:35:26 --> Config Class Initialized
INFO - 2022-06-17 08:35:26 --> Loader Class Initialized
INFO - 2022-06-17 08:35:26 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:26 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:26 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:26 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:26 --> Controller Class Initialized
DEBUG - 2022-06-17 08:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 08:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:35:26 --> Final output sent to browser
DEBUG - 2022-06-17 08:35:26 --> Total execution time: 0.0522
INFO - 2022-06-17 08:35:26 --> Config Class Initialized
INFO - 2022-06-17 08:35:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:26 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:26 --> URI Class Initialized
INFO - 2022-06-17 08:35:26 --> Router Class Initialized
INFO - 2022-06-17 08:35:26 --> Output Class Initialized
INFO - 2022-06-17 08:35:26 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:26 --> Input Class Initialized
INFO - 2022-06-17 08:35:26 --> Language Class Initialized
INFO - 2022-06-17 08:35:26 --> Language Class Initialized
INFO - 2022-06-17 08:35:26 --> Config Class Initialized
INFO - 2022-06-17 08:35:26 --> Loader Class Initialized
INFO - 2022-06-17 08:35:26 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:26 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:26 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:26 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:26 --> Controller Class Initialized
DEBUG - 2022-06-17 08:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 08:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:35:26 --> Final output sent to browser
DEBUG - 2022-06-17 08:35:26 --> Total execution time: 0.0513
INFO - 2022-06-17 08:35:32 --> Config Class Initialized
INFO - 2022-06-17 08:35:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:32 --> URI Class Initialized
INFO - 2022-06-17 08:35:32 --> Router Class Initialized
INFO - 2022-06-17 08:35:32 --> Output Class Initialized
INFO - 2022-06-17 08:35:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:32 --> Input Class Initialized
INFO - 2022-06-17 08:35:32 --> Language Class Initialized
INFO - 2022-06-17 08:35:32 --> Language Class Initialized
INFO - 2022-06-17 08:35:32 --> Config Class Initialized
INFO - 2022-06-17 08:35:32 --> Loader Class Initialized
INFO - 2022-06-17 08:35:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:32 --> Controller Class Initialized
DEBUG - 2022-06-17 08:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:35:32 --> Final output sent to browser
DEBUG - 2022-06-17 08:35:32 --> Total execution time: 0.0473
INFO - 2022-06-17 08:35:32 --> Config Class Initialized
INFO - 2022-06-17 08:35:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:32 --> URI Class Initialized
INFO - 2022-06-17 08:35:32 --> Router Class Initialized
INFO - 2022-06-17 08:35:32 --> Output Class Initialized
INFO - 2022-06-17 08:35:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:32 --> Input Class Initialized
INFO - 2022-06-17 08:35:32 --> Language Class Initialized
INFO - 2022-06-17 08:35:32 --> Language Class Initialized
INFO - 2022-06-17 08:35:32 --> Config Class Initialized
INFO - 2022-06-17 08:35:32 --> Loader Class Initialized
INFO - 2022-06-17 08:35:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:32 --> Controller Class Initialized
INFO - 2022-06-17 08:35:33 --> Config Class Initialized
INFO - 2022-06-17 08:35:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:33 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:33 --> URI Class Initialized
INFO - 2022-06-17 08:35:33 --> Router Class Initialized
INFO - 2022-06-17 08:35:33 --> Output Class Initialized
INFO - 2022-06-17 08:35:33 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:33 --> Input Class Initialized
INFO - 2022-06-17 08:35:33 --> Language Class Initialized
INFO - 2022-06-17 08:35:33 --> Language Class Initialized
INFO - 2022-06-17 08:35:33 --> Config Class Initialized
INFO - 2022-06-17 08:35:33 --> Loader Class Initialized
INFO - 2022-06-17 08:35:33 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:33 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:33 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:33 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:33 --> Controller Class Initialized
DEBUG - 2022-06-17 08:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:35:33 --> Final output sent to browser
DEBUG - 2022-06-17 08:35:33 --> Total execution time: 0.0447
INFO - 2022-06-17 08:35:41 --> Config Class Initialized
INFO - 2022-06-17 08:35:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:41 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:41 --> URI Class Initialized
INFO - 2022-06-17 08:35:41 --> Router Class Initialized
INFO - 2022-06-17 08:35:41 --> Output Class Initialized
INFO - 2022-06-17 08:35:41 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:41 --> Input Class Initialized
INFO - 2022-06-17 08:35:41 --> Language Class Initialized
INFO - 2022-06-17 08:35:41 --> Language Class Initialized
INFO - 2022-06-17 08:35:41 --> Config Class Initialized
INFO - 2022-06-17 08:35:41 --> Loader Class Initialized
INFO - 2022-06-17 08:35:41 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:41 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:41 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:41 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:41 --> Controller Class Initialized
INFO - 2022-06-17 08:35:42 --> Config Class Initialized
INFO - 2022-06-17 08:35:42 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:35:42 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:35:42 --> Utf8 Class Initialized
INFO - 2022-06-17 08:35:42 --> URI Class Initialized
INFO - 2022-06-17 08:35:42 --> Router Class Initialized
INFO - 2022-06-17 08:35:42 --> Output Class Initialized
INFO - 2022-06-17 08:35:42 --> Security Class Initialized
DEBUG - 2022-06-17 08:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:35:42 --> Input Class Initialized
INFO - 2022-06-17 08:35:42 --> Language Class Initialized
INFO - 2022-06-17 08:35:42 --> Language Class Initialized
INFO - 2022-06-17 08:35:42 --> Config Class Initialized
INFO - 2022-06-17 08:35:42 --> Loader Class Initialized
INFO - 2022-06-17 08:35:42 --> Helper loaded: url_helper
INFO - 2022-06-17 08:35:42 --> Helper loaded: file_helper
INFO - 2022-06-17 08:35:42 --> Helper loaded: form_helper
INFO - 2022-06-17 08:35:42 --> Helper loaded: my_helper
INFO - 2022-06-17 08:35:42 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:35:42 --> Controller Class Initialized
INFO - 2022-06-17 08:37:37 --> Config Class Initialized
INFO - 2022-06-17 08:37:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:37:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:37:37 --> Utf8 Class Initialized
INFO - 2022-06-17 08:37:37 --> URI Class Initialized
DEBUG - 2022-06-17 08:37:37 --> No URI present. Default controller set.
INFO - 2022-06-17 08:37:37 --> Router Class Initialized
INFO - 2022-06-17 08:37:37 --> Output Class Initialized
INFO - 2022-06-17 08:37:37 --> Security Class Initialized
DEBUG - 2022-06-17 08:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:37:37 --> Input Class Initialized
INFO - 2022-06-17 08:37:37 --> Language Class Initialized
INFO - 2022-06-17 08:37:37 --> Language Class Initialized
INFO - 2022-06-17 08:37:37 --> Config Class Initialized
INFO - 2022-06-17 08:37:37 --> Loader Class Initialized
INFO - 2022-06-17 08:37:37 --> Helper loaded: url_helper
INFO - 2022-06-17 08:37:37 --> Helper loaded: file_helper
INFO - 2022-06-17 08:37:37 --> Helper loaded: form_helper
INFO - 2022-06-17 08:37:37 --> Helper loaded: my_helper
INFO - 2022-06-17 08:37:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:37:37 --> Controller Class Initialized
INFO - 2022-06-17 08:37:37 --> Config Class Initialized
INFO - 2022-06-17 08:37:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:37:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:37:37 --> Utf8 Class Initialized
INFO - 2022-06-17 08:37:37 --> URI Class Initialized
INFO - 2022-06-17 08:37:37 --> Router Class Initialized
INFO - 2022-06-17 08:37:37 --> Output Class Initialized
INFO - 2022-06-17 08:37:37 --> Security Class Initialized
DEBUG - 2022-06-17 08:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:37:37 --> Input Class Initialized
INFO - 2022-06-17 08:37:37 --> Language Class Initialized
INFO - 2022-06-17 08:37:37 --> Language Class Initialized
INFO - 2022-06-17 08:37:37 --> Config Class Initialized
INFO - 2022-06-17 08:37:37 --> Loader Class Initialized
INFO - 2022-06-17 08:37:37 --> Helper loaded: url_helper
INFO - 2022-06-17 08:37:37 --> Helper loaded: file_helper
INFO - 2022-06-17 08:37:37 --> Helper loaded: form_helper
INFO - 2022-06-17 08:37:37 --> Helper loaded: my_helper
INFO - 2022-06-17 08:37:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:37:37 --> Controller Class Initialized
DEBUG - 2022-06-17 08:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 08:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:37:37 --> Final output sent to browser
DEBUG - 2022-06-17 08:37:37 --> Total execution time: 0.0496
INFO - 2022-06-17 08:37:46 --> Config Class Initialized
INFO - 2022-06-17 08:37:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:37:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:37:46 --> Utf8 Class Initialized
INFO - 2022-06-17 08:37:46 --> URI Class Initialized
INFO - 2022-06-17 08:37:46 --> Router Class Initialized
INFO - 2022-06-17 08:37:46 --> Output Class Initialized
INFO - 2022-06-17 08:37:46 --> Security Class Initialized
DEBUG - 2022-06-17 08:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:37:46 --> Input Class Initialized
INFO - 2022-06-17 08:37:46 --> Language Class Initialized
INFO - 2022-06-17 08:37:46 --> Language Class Initialized
INFO - 2022-06-17 08:37:46 --> Config Class Initialized
INFO - 2022-06-17 08:37:46 --> Loader Class Initialized
INFO - 2022-06-17 08:37:46 --> Helper loaded: url_helper
INFO - 2022-06-17 08:37:46 --> Helper loaded: file_helper
INFO - 2022-06-17 08:37:46 --> Helper loaded: form_helper
INFO - 2022-06-17 08:37:46 --> Helper loaded: my_helper
INFO - 2022-06-17 08:37:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:37:46 --> Controller Class Initialized
INFO - 2022-06-17 08:37:46 --> Final output sent to browser
DEBUG - 2022-06-17 08:37:46 --> Total execution time: 0.0484
INFO - 2022-06-17 08:37:57 --> Config Class Initialized
INFO - 2022-06-17 08:37:57 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:37:57 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:37:57 --> Utf8 Class Initialized
INFO - 2022-06-17 08:37:57 --> URI Class Initialized
INFO - 2022-06-17 08:37:57 --> Router Class Initialized
INFO - 2022-06-17 08:37:57 --> Output Class Initialized
INFO - 2022-06-17 08:37:57 --> Security Class Initialized
DEBUG - 2022-06-17 08:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:37:57 --> Input Class Initialized
INFO - 2022-06-17 08:37:57 --> Language Class Initialized
INFO - 2022-06-17 08:37:57 --> Language Class Initialized
INFO - 2022-06-17 08:37:57 --> Config Class Initialized
INFO - 2022-06-17 08:37:57 --> Loader Class Initialized
INFO - 2022-06-17 08:37:57 --> Helper loaded: url_helper
INFO - 2022-06-17 08:37:57 --> Helper loaded: file_helper
INFO - 2022-06-17 08:37:57 --> Helper loaded: form_helper
INFO - 2022-06-17 08:37:57 --> Helper loaded: my_helper
INFO - 2022-06-17 08:37:57 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:37:57 --> Controller Class Initialized
INFO - 2022-06-17 08:37:57 --> Final output sent to browser
DEBUG - 2022-06-17 08:37:57 --> Total execution time: 0.0494
INFO - 2022-06-17 08:38:13 --> Config Class Initialized
INFO - 2022-06-17 08:38:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:13 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:13 --> URI Class Initialized
INFO - 2022-06-17 08:38:14 --> Router Class Initialized
INFO - 2022-06-17 08:38:14 --> Output Class Initialized
INFO - 2022-06-17 08:38:14 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:14 --> Input Class Initialized
INFO - 2022-06-17 08:38:14 --> Language Class Initialized
INFO - 2022-06-17 08:38:14 --> Language Class Initialized
INFO - 2022-06-17 08:38:14 --> Config Class Initialized
INFO - 2022-06-17 08:38:14 --> Loader Class Initialized
INFO - 2022-06-17 08:38:14 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:14 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:14 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:14 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:14 --> Controller Class Initialized
INFO - 2022-06-17 08:38:14 --> Helper loaded: cookie_helper
INFO - 2022-06-17 08:38:14 --> Final output sent to browser
DEBUG - 2022-06-17 08:38:14 --> Total execution time: 0.0504
INFO - 2022-06-17 08:38:17 --> Config Class Initialized
INFO - 2022-06-17 08:38:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:17 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:17 --> URI Class Initialized
INFO - 2022-06-17 08:38:17 --> Router Class Initialized
INFO - 2022-06-17 08:38:17 --> Output Class Initialized
INFO - 2022-06-17 08:38:17 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:17 --> Input Class Initialized
INFO - 2022-06-17 08:38:17 --> Language Class Initialized
INFO - 2022-06-17 08:38:17 --> Language Class Initialized
INFO - 2022-06-17 08:38:17 --> Config Class Initialized
INFO - 2022-06-17 08:38:17 --> Loader Class Initialized
INFO - 2022-06-17 08:38:17 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:17 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:17 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:17 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:17 --> Controller Class Initialized
DEBUG - 2022-06-17 08:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:38:17 --> Final output sent to browser
DEBUG - 2022-06-17 08:38:17 --> Total execution time: 0.0934
INFO - 2022-06-17 08:38:28 --> Config Class Initialized
INFO - 2022-06-17 08:38:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:28 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:28 --> URI Class Initialized
INFO - 2022-06-17 08:38:28 --> Router Class Initialized
INFO - 2022-06-17 08:38:28 --> Output Class Initialized
INFO - 2022-06-17 08:38:28 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:28 --> Input Class Initialized
INFO - 2022-06-17 08:38:28 --> Language Class Initialized
INFO - 2022-06-17 08:38:28 --> Language Class Initialized
INFO - 2022-06-17 08:38:28 --> Config Class Initialized
INFO - 2022-06-17 08:38:28 --> Loader Class Initialized
INFO - 2022-06-17 08:38:28 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:28 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:28 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:28 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:28 --> Controller Class Initialized
DEBUG - 2022-06-17 08:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 08:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:38:28 --> Final output sent to browser
DEBUG - 2022-06-17 08:38:28 --> Total execution time: 0.0488
INFO - 2022-06-17 08:38:30 --> Config Class Initialized
INFO - 2022-06-17 08:38:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:30 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:30 --> URI Class Initialized
INFO - 2022-06-17 08:38:30 --> Router Class Initialized
INFO - 2022-06-17 08:38:30 --> Output Class Initialized
INFO - 2022-06-17 08:38:30 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:30 --> Input Class Initialized
INFO - 2022-06-17 08:38:30 --> Language Class Initialized
INFO - 2022-06-17 08:38:30 --> Language Class Initialized
INFO - 2022-06-17 08:38:30 --> Config Class Initialized
INFO - 2022-06-17 08:38:30 --> Loader Class Initialized
INFO - 2022-06-17 08:38:30 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:30 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:30 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:30 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:30 --> Controller Class Initialized
DEBUG - 2022-06-17 08:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:38:30 --> Final output sent to browser
DEBUG - 2022-06-17 08:38:30 --> Total execution time: 0.0404
INFO - 2022-06-17 08:38:31 --> Config Class Initialized
INFO - 2022-06-17 08:38:31 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:31 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:31 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:31 --> URI Class Initialized
INFO - 2022-06-17 08:38:31 --> Router Class Initialized
INFO - 2022-06-17 08:38:31 --> Output Class Initialized
INFO - 2022-06-17 08:38:31 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:31 --> Input Class Initialized
INFO - 2022-06-17 08:38:31 --> Language Class Initialized
INFO - 2022-06-17 08:38:31 --> Language Class Initialized
INFO - 2022-06-17 08:38:31 --> Config Class Initialized
INFO - 2022-06-17 08:38:31 --> Loader Class Initialized
INFO - 2022-06-17 08:38:31 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:31 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:31 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:31 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:31 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:31 --> Controller Class Initialized
INFO - 2022-06-17 08:38:38 --> Config Class Initialized
INFO - 2022-06-17 08:38:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:38 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:38 --> URI Class Initialized
INFO - 2022-06-17 08:38:38 --> Router Class Initialized
INFO - 2022-06-17 08:38:38 --> Output Class Initialized
INFO - 2022-06-17 08:38:38 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:38 --> Input Class Initialized
INFO - 2022-06-17 08:38:38 --> Language Class Initialized
INFO - 2022-06-17 08:38:38 --> Language Class Initialized
INFO - 2022-06-17 08:38:38 --> Config Class Initialized
INFO - 2022-06-17 08:38:38 --> Loader Class Initialized
INFO - 2022-06-17 08:38:38 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:38 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:38 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:38 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:38 --> Controller Class Initialized
INFO - 2022-06-17 08:38:38 --> Final output sent to browser
DEBUG - 2022-06-17 08:38:38 --> Total execution time: 0.0484
INFO - 2022-06-17 08:38:48 --> Config Class Initialized
INFO - 2022-06-17 08:38:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:48 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:48 --> URI Class Initialized
DEBUG - 2022-06-17 08:38:48 --> No URI present. Default controller set.
INFO - 2022-06-17 08:38:48 --> Router Class Initialized
INFO - 2022-06-17 08:38:48 --> Output Class Initialized
INFO - 2022-06-17 08:38:48 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:48 --> Input Class Initialized
INFO - 2022-06-17 08:38:48 --> Language Class Initialized
INFO - 2022-06-17 08:38:48 --> Language Class Initialized
INFO - 2022-06-17 08:38:48 --> Config Class Initialized
INFO - 2022-06-17 08:38:48 --> Loader Class Initialized
INFO - 2022-06-17 08:38:48 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:48 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:48 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:48 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:48 --> Controller Class Initialized
DEBUG - 2022-06-17 08:38:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:38:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:38:48 --> Final output sent to browser
DEBUG - 2022-06-17 08:38:48 --> Total execution time: 0.0840
INFO - 2022-06-17 08:38:53 --> Config Class Initialized
INFO - 2022-06-17 08:38:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:53 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:53 --> URI Class Initialized
INFO - 2022-06-17 08:38:53 --> Router Class Initialized
INFO - 2022-06-17 08:38:53 --> Output Class Initialized
INFO - 2022-06-17 08:38:53 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:53 --> Input Class Initialized
INFO - 2022-06-17 08:38:53 --> Language Class Initialized
INFO - 2022-06-17 08:38:53 --> Language Class Initialized
INFO - 2022-06-17 08:38:53 --> Config Class Initialized
INFO - 2022-06-17 08:38:53 --> Loader Class Initialized
INFO - 2022-06-17 08:38:53 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:53 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:53 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:53 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:53 --> Controller Class Initialized
DEBUG - 2022-06-17 08:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 08:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:38:53 --> Final output sent to browser
DEBUG - 2022-06-17 08:38:53 --> Total execution time: 0.0441
INFO - 2022-06-17 08:38:59 --> Config Class Initialized
INFO - 2022-06-17 08:38:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:38:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:38:59 --> Utf8 Class Initialized
INFO - 2022-06-17 08:38:59 --> URI Class Initialized
INFO - 2022-06-17 08:38:59 --> Router Class Initialized
INFO - 2022-06-17 08:38:59 --> Output Class Initialized
INFO - 2022-06-17 08:38:59 --> Security Class Initialized
DEBUG - 2022-06-17 08:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:38:59 --> Input Class Initialized
INFO - 2022-06-17 08:38:59 --> Language Class Initialized
INFO - 2022-06-17 08:38:59 --> Language Class Initialized
INFO - 2022-06-17 08:38:59 --> Config Class Initialized
INFO - 2022-06-17 08:38:59 --> Loader Class Initialized
INFO - 2022-06-17 08:38:59 --> Helper loaded: url_helper
INFO - 2022-06-17 08:38:59 --> Helper loaded: file_helper
INFO - 2022-06-17 08:38:59 --> Helper loaded: form_helper
INFO - 2022-06-17 08:38:59 --> Helper loaded: my_helper
INFO - 2022-06-17 08:38:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:38:59 --> Controller Class Initialized
DEBUG - 2022-06-17 08:38:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:38:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:38:59 --> Final output sent to browser
DEBUG - 2022-06-17 08:38:59 --> Total execution time: 0.0577
INFO - 2022-06-17 08:39:00 --> Config Class Initialized
INFO - 2022-06-17 08:39:00 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:39:00 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:39:00 --> Utf8 Class Initialized
INFO - 2022-06-17 08:39:00 --> URI Class Initialized
INFO - 2022-06-17 08:39:00 --> Router Class Initialized
INFO - 2022-06-17 08:39:00 --> Output Class Initialized
INFO - 2022-06-17 08:39:00 --> Security Class Initialized
DEBUG - 2022-06-17 08:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:39:00 --> Input Class Initialized
INFO - 2022-06-17 08:39:00 --> Language Class Initialized
INFO - 2022-06-17 08:39:00 --> Language Class Initialized
INFO - 2022-06-17 08:39:00 --> Config Class Initialized
INFO - 2022-06-17 08:39:00 --> Loader Class Initialized
INFO - 2022-06-17 08:39:00 --> Helper loaded: url_helper
INFO - 2022-06-17 08:39:00 --> Helper loaded: file_helper
INFO - 2022-06-17 08:39:00 --> Helper loaded: form_helper
INFO - 2022-06-17 08:39:00 --> Helper loaded: my_helper
INFO - 2022-06-17 08:39:00 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:39:00 --> Controller Class Initialized
INFO - 2022-06-17 08:39:21 --> Config Class Initialized
INFO - 2022-06-17 08:39:21 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:39:21 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:39:21 --> Utf8 Class Initialized
INFO - 2022-06-17 08:39:21 --> URI Class Initialized
INFO - 2022-06-17 08:39:21 --> Router Class Initialized
INFO - 2022-06-17 08:39:21 --> Output Class Initialized
INFO - 2022-06-17 08:39:21 --> Security Class Initialized
DEBUG - 2022-06-17 08:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:39:21 --> Input Class Initialized
INFO - 2022-06-17 08:39:21 --> Language Class Initialized
INFO - 2022-06-17 08:39:21 --> Language Class Initialized
INFO - 2022-06-17 08:39:21 --> Config Class Initialized
INFO - 2022-06-17 08:39:21 --> Loader Class Initialized
INFO - 2022-06-17 08:39:21 --> Helper loaded: url_helper
INFO - 2022-06-17 08:39:21 --> Helper loaded: file_helper
INFO - 2022-06-17 08:39:21 --> Helper loaded: form_helper
INFO - 2022-06-17 08:39:21 --> Helper loaded: my_helper
INFO - 2022-06-17 08:39:21 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:39:21 --> Controller Class Initialized
INFO - 2022-06-17 08:39:21 --> Final output sent to browser
DEBUG - 2022-06-17 08:39:21 --> Total execution time: 0.0429
INFO - 2022-06-17 08:39:28 --> Config Class Initialized
INFO - 2022-06-17 08:39:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:39:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:39:28 --> Utf8 Class Initialized
INFO - 2022-06-17 08:39:28 --> URI Class Initialized
DEBUG - 2022-06-17 08:39:28 --> No URI present. Default controller set.
INFO - 2022-06-17 08:39:28 --> Router Class Initialized
INFO - 2022-06-17 08:39:28 --> Output Class Initialized
INFO - 2022-06-17 08:39:28 --> Security Class Initialized
DEBUG - 2022-06-17 08:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:39:28 --> Input Class Initialized
INFO - 2022-06-17 08:39:28 --> Language Class Initialized
INFO - 2022-06-17 08:39:28 --> Language Class Initialized
INFO - 2022-06-17 08:39:28 --> Config Class Initialized
INFO - 2022-06-17 08:39:28 --> Loader Class Initialized
INFO - 2022-06-17 08:39:28 --> Helper loaded: url_helper
INFO - 2022-06-17 08:39:28 --> Helper loaded: file_helper
INFO - 2022-06-17 08:39:28 --> Helper loaded: form_helper
INFO - 2022-06-17 08:39:28 --> Helper loaded: my_helper
INFO - 2022-06-17 08:39:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:39:28 --> Controller Class Initialized
DEBUG - 2022-06-17 08:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:39:29 --> Final output sent to browser
DEBUG - 2022-06-17 08:39:29 --> Total execution time: 0.0908
INFO - 2022-06-17 08:39:32 --> Config Class Initialized
INFO - 2022-06-17 08:39:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:39:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:39:32 --> Utf8 Class Initialized
INFO - 2022-06-17 08:39:32 --> URI Class Initialized
INFO - 2022-06-17 08:39:32 --> Router Class Initialized
INFO - 2022-06-17 08:39:32 --> Output Class Initialized
INFO - 2022-06-17 08:39:32 --> Security Class Initialized
DEBUG - 2022-06-17 08:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:39:32 --> Input Class Initialized
INFO - 2022-06-17 08:39:32 --> Language Class Initialized
INFO - 2022-06-17 08:39:32 --> Language Class Initialized
INFO - 2022-06-17 08:39:32 --> Config Class Initialized
INFO - 2022-06-17 08:39:32 --> Loader Class Initialized
INFO - 2022-06-17 08:39:32 --> Helper loaded: url_helper
INFO - 2022-06-17 08:39:32 --> Helper loaded: file_helper
INFO - 2022-06-17 08:39:32 --> Helper loaded: form_helper
INFO - 2022-06-17 08:39:32 --> Helper loaded: my_helper
INFO - 2022-06-17 08:39:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:39:32 --> Controller Class Initialized
DEBUG - 2022-06-17 08:39:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-06-17 08:39:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:39:32 --> Final output sent to browser
DEBUG - 2022-06-17 08:39:32 --> Total execution time: 0.0808
INFO - 2022-06-17 08:39:40 --> Config Class Initialized
INFO - 2022-06-17 08:39:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:39:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:39:40 --> Utf8 Class Initialized
INFO - 2022-06-17 08:39:40 --> URI Class Initialized
DEBUG - 2022-06-17 08:39:40 --> No URI present. Default controller set.
INFO - 2022-06-17 08:39:40 --> Router Class Initialized
INFO - 2022-06-17 08:39:40 --> Output Class Initialized
INFO - 2022-06-17 08:39:41 --> Security Class Initialized
DEBUG - 2022-06-17 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:39:41 --> Input Class Initialized
INFO - 2022-06-17 08:39:41 --> Language Class Initialized
INFO - 2022-06-17 08:39:41 --> Language Class Initialized
INFO - 2022-06-17 08:39:41 --> Config Class Initialized
INFO - 2022-06-17 08:39:41 --> Loader Class Initialized
INFO - 2022-06-17 08:39:41 --> Helper loaded: url_helper
INFO - 2022-06-17 08:39:41 --> Helper loaded: file_helper
INFO - 2022-06-17 08:39:41 --> Helper loaded: form_helper
INFO - 2022-06-17 08:39:41 --> Helper loaded: my_helper
INFO - 2022-06-17 08:39:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:39:41 --> Controller Class Initialized
DEBUG - 2022-06-17 08:39:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:39:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:39:41 --> Final output sent to browser
DEBUG - 2022-06-17 08:39:41 --> Total execution time: 0.0906
INFO - 2022-06-17 08:39:48 --> Config Class Initialized
INFO - 2022-06-17 08:39:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:39:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:39:48 --> Utf8 Class Initialized
INFO - 2022-06-17 08:39:48 --> URI Class Initialized
INFO - 2022-06-17 08:39:48 --> Router Class Initialized
INFO - 2022-06-17 08:39:48 --> Output Class Initialized
INFO - 2022-06-17 08:39:48 --> Security Class Initialized
DEBUG - 2022-06-17 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:39:48 --> Input Class Initialized
INFO - 2022-06-17 08:39:48 --> Language Class Initialized
INFO - 2022-06-17 08:39:48 --> Language Class Initialized
INFO - 2022-06-17 08:39:48 --> Config Class Initialized
INFO - 2022-06-17 08:39:48 --> Loader Class Initialized
INFO - 2022-06-17 08:39:48 --> Helper loaded: url_helper
INFO - 2022-06-17 08:39:48 --> Helper loaded: file_helper
INFO - 2022-06-17 08:39:48 --> Helper loaded: form_helper
INFO - 2022-06-17 08:39:48 --> Helper loaded: my_helper
INFO - 2022-06-17 08:39:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:39:48 --> Controller Class Initialized
DEBUG - 2022-06-17 08:39:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 08:39:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:39:48 --> Final output sent to browser
DEBUG - 2022-06-17 08:39:48 --> Total execution time: 0.0486
INFO - 2022-06-17 08:39:54 --> Config Class Initialized
INFO - 2022-06-17 08:39:54 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:39:54 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:39:54 --> Utf8 Class Initialized
INFO - 2022-06-17 08:39:54 --> URI Class Initialized
INFO - 2022-06-17 08:39:54 --> Router Class Initialized
INFO - 2022-06-17 08:39:54 --> Output Class Initialized
INFO - 2022-06-17 08:39:54 --> Security Class Initialized
DEBUG - 2022-06-17 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:39:54 --> Input Class Initialized
INFO - 2022-06-17 08:39:54 --> Language Class Initialized
INFO - 2022-06-17 08:39:54 --> Language Class Initialized
INFO - 2022-06-17 08:39:54 --> Config Class Initialized
INFO - 2022-06-17 08:39:54 --> Loader Class Initialized
INFO - 2022-06-17 08:39:54 --> Helper loaded: url_helper
INFO - 2022-06-17 08:39:54 --> Helper loaded: file_helper
INFO - 2022-06-17 08:39:54 --> Helper loaded: form_helper
INFO - 2022-06-17 08:39:54 --> Helper loaded: my_helper
INFO - 2022-06-17 08:39:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:39:54 --> Controller Class Initialized
DEBUG - 2022-06-17 08:39:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:39:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:39:54 --> Final output sent to browser
DEBUG - 2022-06-17 08:39:54 --> Total execution time: 0.0414
INFO - 2022-06-17 08:39:54 --> Config Class Initialized
INFO - 2022-06-17 08:39:54 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:39:54 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:39:54 --> Utf8 Class Initialized
INFO - 2022-06-17 08:39:54 --> URI Class Initialized
INFO - 2022-06-17 08:39:54 --> Router Class Initialized
INFO - 2022-06-17 08:39:54 --> Output Class Initialized
INFO - 2022-06-17 08:39:54 --> Security Class Initialized
DEBUG - 2022-06-17 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:39:54 --> Input Class Initialized
INFO - 2022-06-17 08:39:54 --> Language Class Initialized
INFO - 2022-06-17 08:39:54 --> Language Class Initialized
INFO - 2022-06-17 08:39:54 --> Config Class Initialized
INFO - 2022-06-17 08:39:54 --> Loader Class Initialized
INFO - 2022-06-17 08:39:54 --> Helper loaded: url_helper
INFO - 2022-06-17 08:39:54 --> Helper loaded: file_helper
INFO - 2022-06-17 08:39:54 --> Helper loaded: form_helper
INFO - 2022-06-17 08:39:54 --> Helper loaded: my_helper
INFO - 2022-06-17 08:39:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:39:54 --> Controller Class Initialized
INFO - 2022-06-17 08:40:03 --> Config Class Initialized
INFO - 2022-06-17 08:40:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:40:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:40:03 --> Utf8 Class Initialized
INFO - 2022-06-17 08:40:03 --> URI Class Initialized
INFO - 2022-06-17 08:40:03 --> Router Class Initialized
INFO - 2022-06-17 08:40:03 --> Output Class Initialized
INFO - 2022-06-17 08:40:03 --> Security Class Initialized
DEBUG - 2022-06-17 08:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:40:03 --> Input Class Initialized
INFO - 2022-06-17 08:40:03 --> Language Class Initialized
INFO - 2022-06-17 08:40:03 --> Language Class Initialized
INFO - 2022-06-17 08:40:03 --> Config Class Initialized
INFO - 2022-06-17 08:40:03 --> Loader Class Initialized
INFO - 2022-06-17 08:40:03 --> Helper loaded: url_helper
INFO - 2022-06-17 08:40:03 --> Helper loaded: file_helper
INFO - 2022-06-17 08:40:03 --> Helper loaded: form_helper
INFO - 2022-06-17 08:40:03 --> Helper loaded: my_helper
INFO - 2022-06-17 08:40:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:40:03 --> Controller Class Initialized
INFO - 2022-06-17 08:40:03 --> Final output sent to browser
DEBUG - 2022-06-17 08:40:03 --> Total execution time: 0.0481
INFO - 2022-06-17 08:40:22 --> Config Class Initialized
INFO - 2022-06-17 08:40:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:40:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:40:22 --> Utf8 Class Initialized
INFO - 2022-06-17 08:40:22 --> URI Class Initialized
DEBUG - 2022-06-17 08:40:22 --> No URI present. Default controller set.
INFO - 2022-06-17 08:40:22 --> Router Class Initialized
INFO - 2022-06-17 08:40:22 --> Output Class Initialized
INFO - 2022-06-17 08:40:22 --> Security Class Initialized
DEBUG - 2022-06-17 08:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:40:22 --> Input Class Initialized
INFO - 2022-06-17 08:40:22 --> Language Class Initialized
INFO - 2022-06-17 08:40:22 --> Language Class Initialized
INFO - 2022-06-17 08:40:22 --> Config Class Initialized
INFO - 2022-06-17 08:40:22 --> Loader Class Initialized
INFO - 2022-06-17 08:40:22 --> Helper loaded: url_helper
INFO - 2022-06-17 08:40:22 --> Helper loaded: file_helper
INFO - 2022-06-17 08:40:22 --> Helper loaded: form_helper
INFO - 2022-06-17 08:40:22 --> Helper loaded: my_helper
INFO - 2022-06-17 08:40:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:40:22 --> Controller Class Initialized
DEBUG - 2022-06-17 08:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:40:22 --> Final output sent to browser
DEBUG - 2022-06-17 08:40:22 --> Total execution time: 0.0815
INFO - 2022-06-17 08:41:01 --> Config Class Initialized
INFO - 2022-06-17 08:41:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:01 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:01 --> URI Class Initialized
INFO - 2022-06-17 08:41:01 --> Router Class Initialized
INFO - 2022-06-17 08:41:01 --> Output Class Initialized
INFO - 2022-06-17 08:41:01 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:01 --> Input Class Initialized
INFO - 2022-06-17 08:41:01 --> Language Class Initialized
INFO - 2022-06-17 08:41:01 --> Language Class Initialized
INFO - 2022-06-17 08:41:01 --> Config Class Initialized
INFO - 2022-06-17 08:41:01 --> Loader Class Initialized
INFO - 2022-06-17 08:41:01 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:01 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:01 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:01 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:01 --> Controller Class Initialized
DEBUG - 2022-06-17 08:41:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 08:41:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:41:01 --> Final output sent to browser
DEBUG - 2022-06-17 08:41:01 --> Total execution time: 0.0534
INFO - 2022-06-17 08:41:04 --> Config Class Initialized
INFO - 2022-06-17 08:41:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:04 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:04 --> URI Class Initialized
DEBUG - 2022-06-17 08:41:04 --> No URI present. Default controller set.
INFO - 2022-06-17 08:41:04 --> Router Class Initialized
INFO - 2022-06-17 08:41:04 --> Output Class Initialized
INFO - 2022-06-17 08:41:04 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:04 --> Input Class Initialized
INFO - 2022-06-17 08:41:04 --> Language Class Initialized
INFO - 2022-06-17 08:41:04 --> Language Class Initialized
INFO - 2022-06-17 08:41:04 --> Config Class Initialized
INFO - 2022-06-17 08:41:04 --> Loader Class Initialized
INFO - 2022-06-17 08:41:04 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:04 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:04 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:04 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:04 --> Controller Class Initialized
DEBUG - 2022-06-17 08:41:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 08:41:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:41:04 --> Final output sent to browser
DEBUG - 2022-06-17 08:41:04 --> Total execution time: 0.0839
INFO - 2022-06-17 08:41:05 --> Config Class Initialized
INFO - 2022-06-17 08:41:05 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:05 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:05 --> URI Class Initialized
INFO - 2022-06-17 08:41:05 --> Router Class Initialized
INFO - 2022-06-17 08:41:05 --> Output Class Initialized
INFO - 2022-06-17 08:41:05 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:05 --> Input Class Initialized
INFO - 2022-06-17 08:41:05 --> Language Class Initialized
INFO - 2022-06-17 08:41:05 --> Language Class Initialized
INFO - 2022-06-17 08:41:05 --> Config Class Initialized
INFO - 2022-06-17 08:41:05 --> Loader Class Initialized
INFO - 2022-06-17 08:41:05 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:05 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:05 --> Controller Class Initialized
INFO - 2022-06-17 08:41:05 --> Config Class Initialized
INFO - 2022-06-17 08:41:05 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:05 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:05 --> URI Class Initialized
INFO - 2022-06-17 08:41:05 --> Router Class Initialized
INFO - 2022-06-17 08:41:05 --> Output Class Initialized
INFO - 2022-06-17 08:41:05 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:05 --> Input Class Initialized
INFO - 2022-06-17 08:41:05 --> Language Class Initialized
INFO - 2022-06-17 08:41:05 --> Language Class Initialized
INFO - 2022-06-17 08:41:05 --> Config Class Initialized
INFO - 2022-06-17 08:41:05 --> Loader Class Initialized
INFO - 2022-06-17 08:41:05 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:05 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:05 --> Controller Class Initialized
DEBUG - 2022-06-17 08:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 08:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:41:05 --> Final output sent to browser
DEBUG - 2022-06-17 08:41:05 --> Total execution time: 0.0432
INFO - 2022-06-17 08:41:05 --> Config Class Initialized
INFO - 2022-06-17 08:41:05 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:05 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:05 --> URI Class Initialized
INFO - 2022-06-17 08:41:05 --> Router Class Initialized
INFO - 2022-06-17 08:41:05 --> Output Class Initialized
INFO - 2022-06-17 08:41:05 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:05 --> Input Class Initialized
INFO - 2022-06-17 08:41:05 --> Language Class Initialized
INFO - 2022-06-17 08:41:05 --> Language Class Initialized
INFO - 2022-06-17 08:41:05 --> Config Class Initialized
INFO - 2022-06-17 08:41:05 --> Loader Class Initialized
INFO - 2022-06-17 08:41:05 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:05 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:05 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:05 --> Controller Class Initialized
INFO - 2022-06-17 08:41:07 --> Config Class Initialized
INFO - 2022-06-17 08:41:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:07 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:07 --> URI Class Initialized
INFO - 2022-06-17 08:41:07 --> Router Class Initialized
INFO - 2022-06-17 08:41:07 --> Output Class Initialized
INFO - 2022-06-17 08:41:07 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:07 --> Input Class Initialized
INFO - 2022-06-17 08:41:07 --> Language Class Initialized
INFO - 2022-06-17 08:41:07 --> Language Class Initialized
INFO - 2022-06-17 08:41:07 --> Config Class Initialized
INFO - 2022-06-17 08:41:07 --> Loader Class Initialized
INFO - 2022-06-17 08:41:07 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:07 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:07 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:07 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:07 --> Controller Class Initialized
DEBUG - 2022-06-17 08:41:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 08:41:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:41:07 --> Final output sent to browser
DEBUG - 2022-06-17 08:41:07 --> Total execution time: 0.0432
INFO - 2022-06-17 08:41:07 --> Config Class Initialized
INFO - 2022-06-17 08:41:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:07 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:07 --> URI Class Initialized
INFO - 2022-06-17 08:41:07 --> Router Class Initialized
INFO - 2022-06-17 08:41:07 --> Output Class Initialized
INFO - 2022-06-17 08:41:07 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:07 --> Input Class Initialized
INFO - 2022-06-17 08:41:07 --> Language Class Initialized
INFO - 2022-06-17 08:41:07 --> Language Class Initialized
INFO - 2022-06-17 08:41:07 --> Config Class Initialized
INFO - 2022-06-17 08:41:07 --> Loader Class Initialized
INFO - 2022-06-17 08:41:07 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:07 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:07 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:07 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:07 --> Controller Class Initialized
DEBUG - 2022-06-17 08:41:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 08:41:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:41:07 --> Final output sent to browser
DEBUG - 2022-06-17 08:41:07 --> Total execution time: 0.0400
INFO - 2022-06-17 08:41:10 --> Config Class Initialized
INFO - 2022-06-17 08:41:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:10 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:10 --> URI Class Initialized
INFO - 2022-06-17 08:41:10 --> Router Class Initialized
INFO - 2022-06-17 08:41:10 --> Output Class Initialized
INFO - 2022-06-17 08:41:10 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:10 --> Input Class Initialized
INFO - 2022-06-17 08:41:10 --> Language Class Initialized
INFO - 2022-06-17 08:41:10 --> Language Class Initialized
INFO - 2022-06-17 08:41:10 --> Config Class Initialized
INFO - 2022-06-17 08:41:10 --> Loader Class Initialized
INFO - 2022-06-17 08:41:10 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:10 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:10 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:10 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:10 --> Controller Class Initialized
INFO - 2022-06-17 08:41:10 --> Config Class Initialized
INFO - 2022-06-17 08:41:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:10 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:10 --> URI Class Initialized
INFO - 2022-06-17 08:41:10 --> Router Class Initialized
INFO - 2022-06-17 08:41:10 --> Output Class Initialized
INFO - 2022-06-17 08:41:10 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:10 --> Input Class Initialized
INFO - 2022-06-17 08:41:10 --> Language Class Initialized
INFO - 2022-06-17 08:41:10 --> Language Class Initialized
INFO - 2022-06-17 08:41:10 --> Config Class Initialized
INFO - 2022-06-17 08:41:10 --> Loader Class Initialized
INFO - 2022-06-17 08:41:10 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:10 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:10 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:10 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:10 --> Controller Class Initialized
DEBUG - 2022-06-17 08:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 08:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:41:10 --> Final output sent to browser
DEBUG - 2022-06-17 08:41:10 --> Total execution time: 0.0423
INFO - 2022-06-17 08:41:13 --> Config Class Initialized
INFO - 2022-06-17 08:41:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:13 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:13 --> URI Class Initialized
INFO - 2022-06-17 08:41:13 --> Router Class Initialized
INFO - 2022-06-17 08:41:13 --> Output Class Initialized
INFO - 2022-06-17 08:41:13 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:13 --> Input Class Initialized
INFO - 2022-06-17 08:41:13 --> Language Class Initialized
INFO - 2022-06-17 08:41:13 --> Language Class Initialized
INFO - 2022-06-17 08:41:13 --> Config Class Initialized
INFO - 2022-06-17 08:41:13 --> Loader Class Initialized
INFO - 2022-06-17 08:41:13 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:13 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:13 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:13 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:13 --> Controller Class Initialized
INFO - 2022-06-17 08:41:13 --> Helper loaded: cookie_helper
INFO - 2022-06-17 08:41:13 --> Config Class Initialized
INFO - 2022-06-17 08:41:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:41:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:41:13 --> Utf8 Class Initialized
INFO - 2022-06-17 08:41:13 --> URI Class Initialized
INFO - 2022-06-17 08:41:13 --> Router Class Initialized
INFO - 2022-06-17 08:41:13 --> Output Class Initialized
INFO - 2022-06-17 08:41:13 --> Security Class Initialized
DEBUG - 2022-06-17 08:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:41:13 --> Input Class Initialized
INFO - 2022-06-17 08:41:13 --> Language Class Initialized
INFO - 2022-06-17 08:41:13 --> Language Class Initialized
INFO - 2022-06-17 08:41:13 --> Config Class Initialized
INFO - 2022-06-17 08:41:13 --> Loader Class Initialized
INFO - 2022-06-17 08:41:13 --> Helper loaded: url_helper
INFO - 2022-06-17 08:41:13 --> Helper loaded: file_helper
INFO - 2022-06-17 08:41:13 --> Helper loaded: form_helper
INFO - 2022-06-17 08:41:13 --> Helper loaded: my_helper
INFO - 2022-06-17 08:41:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:41:13 --> Controller Class Initialized
DEBUG - 2022-06-17 08:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 08:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:41:13 --> Final output sent to browser
DEBUG - 2022-06-17 08:41:13 --> Total execution time: 0.0403
INFO - 2022-06-17 08:44:27 --> Config Class Initialized
INFO - 2022-06-17 08:44:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:44:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:44:27 --> Utf8 Class Initialized
INFO - 2022-06-17 08:44:27 --> URI Class Initialized
DEBUG - 2022-06-17 08:44:27 --> No URI present. Default controller set.
INFO - 2022-06-17 08:44:27 --> Router Class Initialized
INFO - 2022-06-17 08:44:27 --> Output Class Initialized
INFO - 2022-06-17 08:44:27 --> Security Class Initialized
DEBUG - 2022-06-17 08:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:44:27 --> Input Class Initialized
INFO - 2022-06-17 08:44:27 --> Language Class Initialized
INFO - 2022-06-17 08:44:27 --> Language Class Initialized
INFO - 2022-06-17 08:44:27 --> Config Class Initialized
INFO - 2022-06-17 08:44:27 --> Loader Class Initialized
INFO - 2022-06-17 08:44:27 --> Helper loaded: url_helper
INFO - 2022-06-17 08:44:27 --> Helper loaded: file_helper
INFO - 2022-06-17 08:44:27 --> Helper loaded: form_helper
INFO - 2022-06-17 08:44:27 --> Helper loaded: my_helper
INFO - 2022-06-17 08:44:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:44:27 --> Controller Class Initialized
INFO - 2022-06-17 08:44:27 --> Config Class Initialized
INFO - 2022-06-17 08:44:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 08:44:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 08:44:27 --> Utf8 Class Initialized
INFO - 2022-06-17 08:44:27 --> URI Class Initialized
INFO - 2022-06-17 08:44:27 --> Router Class Initialized
INFO - 2022-06-17 08:44:27 --> Output Class Initialized
INFO - 2022-06-17 08:44:27 --> Security Class Initialized
DEBUG - 2022-06-17 08:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 08:44:27 --> Input Class Initialized
INFO - 2022-06-17 08:44:27 --> Language Class Initialized
INFO - 2022-06-17 08:44:27 --> Language Class Initialized
INFO - 2022-06-17 08:44:27 --> Config Class Initialized
INFO - 2022-06-17 08:44:27 --> Loader Class Initialized
INFO - 2022-06-17 08:44:27 --> Helper loaded: url_helper
INFO - 2022-06-17 08:44:27 --> Helper loaded: file_helper
INFO - 2022-06-17 08:44:27 --> Helper loaded: form_helper
INFO - 2022-06-17 08:44:27 --> Helper loaded: my_helper
INFO - 2022-06-17 08:44:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 08:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 08:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 08:44:27 --> Controller Class Initialized
DEBUG - 2022-06-17 08:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 08:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 08:44:27 --> Final output sent to browser
DEBUG - 2022-06-17 08:44:27 --> Total execution time: 0.0466
INFO - 2022-06-17 09:03:23 --> Config Class Initialized
INFO - 2022-06-17 09:03:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:03:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:03:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:03:23 --> URI Class Initialized
INFO - 2022-06-17 09:03:23 --> Router Class Initialized
INFO - 2022-06-17 09:03:23 --> Output Class Initialized
INFO - 2022-06-17 09:03:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:03:23 --> Input Class Initialized
INFO - 2022-06-17 09:03:23 --> Language Class Initialized
INFO - 2022-06-17 09:03:23 --> Language Class Initialized
INFO - 2022-06-17 09:03:23 --> Config Class Initialized
INFO - 2022-06-17 09:03:23 --> Loader Class Initialized
INFO - 2022-06-17 09:03:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:03:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:03:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:03:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:03:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:03:23 --> Controller Class Initialized
INFO - 2022-06-17 09:03:23 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:03:23 --> Config Class Initialized
INFO - 2022-06-17 09:03:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:03:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:03:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:03:23 --> URI Class Initialized
INFO - 2022-06-17 09:03:23 --> Router Class Initialized
INFO - 2022-06-17 09:03:23 --> Output Class Initialized
INFO - 2022-06-17 09:03:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:03:23 --> Input Class Initialized
INFO - 2022-06-17 09:03:23 --> Language Class Initialized
INFO - 2022-06-17 09:03:23 --> Language Class Initialized
INFO - 2022-06-17 09:03:23 --> Config Class Initialized
INFO - 2022-06-17 09:03:23 --> Loader Class Initialized
INFO - 2022-06-17 09:03:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:03:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:03:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:03:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:03:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:03:23 --> Controller Class Initialized
DEBUG - 2022-06-17 09:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 09:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:03:23 --> Final output sent to browser
DEBUG - 2022-06-17 09:03:23 --> Total execution time: 0.0449
INFO - 2022-06-17 09:03:39 --> Config Class Initialized
INFO - 2022-06-17 09:03:39 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:03:39 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:03:39 --> Utf8 Class Initialized
INFO - 2022-06-17 09:03:39 --> URI Class Initialized
INFO - 2022-06-17 09:03:39 --> Router Class Initialized
INFO - 2022-06-17 09:03:39 --> Output Class Initialized
INFO - 2022-06-17 09:03:39 --> Security Class Initialized
DEBUG - 2022-06-17 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:03:39 --> Input Class Initialized
INFO - 2022-06-17 09:03:39 --> Language Class Initialized
INFO - 2022-06-17 09:03:39 --> Language Class Initialized
INFO - 2022-06-17 09:03:39 --> Config Class Initialized
INFO - 2022-06-17 09:03:39 --> Loader Class Initialized
INFO - 2022-06-17 09:03:39 --> Helper loaded: url_helper
INFO - 2022-06-17 09:03:39 --> Helper loaded: file_helper
INFO - 2022-06-17 09:03:39 --> Helper loaded: form_helper
INFO - 2022-06-17 09:03:39 --> Helper loaded: my_helper
INFO - 2022-06-17 09:03:39 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:03:39 --> Controller Class Initialized
INFO - 2022-06-17 09:03:39 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:03:39 --> Final output sent to browser
DEBUG - 2022-06-17 09:03:39 --> Total execution time: 0.0440
INFO - 2022-06-17 09:03:41 --> Config Class Initialized
INFO - 2022-06-17 09:03:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:03:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:03:41 --> Utf8 Class Initialized
INFO - 2022-06-17 09:03:41 --> URI Class Initialized
INFO - 2022-06-17 09:03:41 --> Router Class Initialized
INFO - 2022-06-17 09:03:41 --> Output Class Initialized
INFO - 2022-06-17 09:03:41 --> Security Class Initialized
DEBUG - 2022-06-17 09:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:03:41 --> Input Class Initialized
INFO - 2022-06-17 09:03:41 --> Language Class Initialized
INFO - 2022-06-17 09:03:41 --> Language Class Initialized
INFO - 2022-06-17 09:03:41 --> Config Class Initialized
INFO - 2022-06-17 09:03:41 --> Loader Class Initialized
INFO - 2022-06-17 09:03:41 --> Helper loaded: url_helper
INFO - 2022-06-17 09:03:41 --> Helper loaded: file_helper
INFO - 2022-06-17 09:03:41 --> Helper loaded: form_helper
INFO - 2022-06-17 09:03:41 --> Helper loaded: my_helper
INFO - 2022-06-17 09:03:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:03:41 --> Controller Class Initialized
DEBUG - 2022-06-17 09:03:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 09:03:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:03:41 --> Final output sent to browser
DEBUG - 2022-06-17 09:03:41 --> Total execution time: 0.0922
INFO - 2022-06-17 09:03:48 --> Config Class Initialized
INFO - 2022-06-17 09:03:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:03:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:03:48 --> Utf8 Class Initialized
INFO - 2022-06-17 09:03:48 --> URI Class Initialized
INFO - 2022-06-17 09:03:48 --> Router Class Initialized
INFO - 2022-06-17 09:03:48 --> Output Class Initialized
INFO - 2022-06-17 09:03:48 --> Security Class Initialized
DEBUG - 2022-06-17 09:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:03:48 --> Input Class Initialized
INFO - 2022-06-17 09:03:48 --> Language Class Initialized
INFO - 2022-06-17 09:03:49 --> Language Class Initialized
INFO - 2022-06-17 09:03:49 --> Config Class Initialized
INFO - 2022-06-17 09:03:49 --> Loader Class Initialized
INFO - 2022-06-17 09:03:49 --> Helper loaded: url_helper
INFO - 2022-06-17 09:03:49 --> Helper loaded: file_helper
INFO - 2022-06-17 09:03:49 --> Helper loaded: form_helper
INFO - 2022-06-17 09:03:49 --> Helper loaded: my_helper
INFO - 2022-06-17 09:03:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:03:49 --> Controller Class Initialized
DEBUG - 2022-06-17 09:03:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:03:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:03:49 --> Final output sent to browser
DEBUG - 2022-06-17 09:03:49 --> Total execution time: 0.0450
INFO - 2022-06-17 09:04:04 --> Config Class Initialized
INFO - 2022-06-17 09:04:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:04:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:04:04 --> Utf8 Class Initialized
INFO - 2022-06-17 09:04:04 --> URI Class Initialized
INFO - 2022-06-17 09:04:04 --> Router Class Initialized
INFO - 2022-06-17 09:04:04 --> Output Class Initialized
INFO - 2022-06-17 09:04:04 --> Security Class Initialized
DEBUG - 2022-06-17 09:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:04:04 --> Input Class Initialized
INFO - 2022-06-17 09:04:04 --> Language Class Initialized
INFO - 2022-06-17 09:04:04 --> Language Class Initialized
INFO - 2022-06-17 09:04:04 --> Config Class Initialized
INFO - 2022-06-17 09:04:04 --> Loader Class Initialized
INFO - 2022-06-17 09:04:04 --> Helper loaded: url_helper
INFO - 2022-06-17 09:04:04 --> Helper loaded: file_helper
INFO - 2022-06-17 09:04:04 --> Helper loaded: form_helper
INFO - 2022-06-17 09:04:04 --> Helper loaded: my_helper
INFO - 2022-06-17 09:04:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:04:04 --> Controller Class Initialized
DEBUG - 2022-06-17 09:04:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:04:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:04:04 --> Final output sent to browser
DEBUG - 2022-06-17 09:04:04 --> Total execution time: 0.0489
INFO - 2022-06-17 09:04:04 --> Config Class Initialized
INFO - 2022-06-17 09:04:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:04:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:04:04 --> Utf8 Class Initialized
INFO - 2022-06-17 09:04:04 --> URI Class Initialized
INFO - 2022-06-17 09:04:04 --> Router Class Initialized
INFO - 2022-06-17 09:04:04 --> Output Class Initialized
INFO - 2022-06-17 09:04:04 --> Security Class Initialized
DEBUG - 2022-06-17 09:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:04:04 --> Input Class Initialized
INFO - 2022-06-17 09:04:04 --> Language Class Initialized
INFO - 2022-06-17 09:04:04 --> Language Class Initialized
INFO - 2022-06-17 09:04:04 --> Config Class Initialized
INFO - 2022-06-17 09:04:04 --> Loader Class Initialized
INFO - 2022-06-17 09:04:04 --> Helper loaded: url_helper
INFO - 2022-06-17 09:04:04 --> Helper loaded: file_helper
INFO - 2022-06-17 09:04:04 --> Helper loaded: form_helper
INFO - 2022-06-17 09:04:04 --> Helper loaded: my_helper
INFO - 2022-06-17 09:04:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:04:04 --> Controller Class Initialized
INFO - 2022-06-17 09:05:45 --> Config Class Initialized
INFO - 2022-06-17 09:05:45 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:05:45 --> Utf8 Class Initialized
INFO - 2022-06-17 09:05:45 --> URI Class Initialized
INFO - 2022-06-17 09:05:45 --> Router Class Initialized
INFO - 2022-06-17 09:05:45 --> Output Class Initialized
INFO - 2022-06-17 09:05:45 --> Security Class Initialized
DEBUG - 2022-06-17 09:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:05:45 --> Input Class Initialized
INFO - 2022-06-17 09:05:45 --> Language Class Initialized
INFO - 2022-06-17 09:05:45 --> Language Class Initialized
INFO - 2022-06-17 09:05:45 --> Config Class Initialized
INFO - 2022-06-17 09:05:45 --> Loader Class Initialized
INFO - 2022-06-17 09:05:45 --> Helper loaded: url_helper
INFO - 2022-06-17 09:05:45 --> Helper loaded: file_helper
INFO - 2022-06-17 09:05:45 --> Helper loaded: form_helper
INFO - 2022-06-17 09:05:45 --> Helper loaded: my_helper
INFO - 2022-06-17 09:05:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:05:45 --> Controller Class Initialized
INFO - 2022-06-17 09:05:45 --> Final output sent to browser
DEBUG - 2022-06-17 09:05:45 --> Total execution time: 0.0498
INFO - 2022-06-17 09:06:34 --> Config Class Initialized
INFO - 2022-06-17 09:06:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:06:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:06:34 --> Utf8 Class Initialized
INFO - 2022-06-17 09:06:34 --> URI Class Initialized
INFO - 2022-06-17 09:06:34 --> Router Class Initialized
INFO - 2022-06-17 09:06:34 --> Output Class Initialized
INFO - 2022-06-17 09:06:34 --> Security Class Initialized
DEBUG - 2022-06-17 09:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:06:34 --> Input Class Initialized
INFO - 2022-06-17 09:06:34 --> Language Class Initialized
INFO - 2022-06-17 09:06:34 --> Language Class Initialized
INFO - 2022-06-17 09:06:34 --> Config Class Initialized
INFO - 2022-06-17 09:06:34 --> Loader Class Initialized
INFO - 2022-06-17 09:06:34 --> Helper loaded: url_helper
INFO - 2022-06-17 09:06:34 --> Helper loaded: file_helper
INFO - 2022-06-17 09:06:34 --> Helper loaded: form_helper
INFO - 2022-06-17 09:06:34 --> Helper loaded: my_helper
INFO - 2022-06-17 09:06:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:06:34 --> Controller Class Initialized
INFO - 2022-06-17 09:06:34 --> Final output sent to browser
DEBUG - 2022-06-17 09:06:34 --> Total execution time: 0.0390
INFO - 2022-06-17 09:09:16 --> Config Class Initialized
INFO - 2022-06-17 09:09:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:16 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:16 --> URI Class Initialized
INFO - 2022-06-17 09:09:16 --> Router Class Initialized
INFO - 2022-06-17 09:09:16 --> Output Class Initialized
INFO - 2022-06-17 09:09:16 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:16 --> Input Class Initialized
INFO - 2022-06-17 09:09:16 --> Language Class Initialized
INFO - 2022-06-17 09:09:16 --> Language Class Initialized
INFO - 2022-06-17 09:09:16 --> Config Class Initialized
INFO - 2022-06-17 09:09:16 --> Loader Class Initialized
INFO - 2022-06-17 09:09:16 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:16 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:16 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:16 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:16 --> Controller Class Initialized
INFO - 2022-06-17 09:09:16 --> Final output sent to browser
DEBUG - 2022-06-17 09:09:16 --> Total execution time: 0.0458
INFO - 2022-06-17 09:09:16 --> Config Class Initialized
INFO - 2022-06-17 09:09:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:16 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:16 --> URI Class Initialized
INFO - 2022-06-17 09:09:16 --> Router Class Initialized
INFO - 2022-06-17 09:09:16 --> Output Class Initialized
INFO - 2022-06-17 09:09:16 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:16 --> Input Class Initialized
INFO - 2022-06-17 09:09:16 --> Language Class Initialized
INFO - 2022-06-17 09:09:16 --> Language Class Initialized
INFO - 2022-06-17 09:09:16 --> Config Class Initialized
INFO - 2022-06-17 09:09:16 --> Loader Class Initialized
INFO - 2022-06-17 09:09:16 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:16 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:16 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:16 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:16 --> Controller Class Initialized
INFO - 2022-06-17 09:09:18 --> Config Class Initialized
INFO - 2022-06-17 09:09:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:18 --> URI Class Initialized
INFO - 2022-06-17 09:09:18 --> Router Class Initialized
INFO - 2022-06-17 09:09:18 --> Output Class Initialized
INFO - 2022-06-17 09:09:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:18 --> Input Class Initialized
INFO - 2022-06-17 09:09:18 --> Language Class Initialized
INFO - 2022-06-17 09:09:18 --> Language Class Initialized
INFO - 2022-06-17 09:09:18 --> Config Class Initialized
INFO - 2022-06-17 09:09:18 --> Loader Class Initialized
INFO - 2022-06-17 09:09:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:18 --> Controller Class Initialized
INFO - 2022-06-17 09:09:18 --> Final output sent to browser
DEBUG - 2022-06-17 09:09:18 --> Total execution time: 0.0478
INFO - 2022-06-17 09:09:45 --> Config Class Initialized
INFO - 2022-06-17 09:09:45 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:45 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:45 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:45 --> URI Class Initialized
INFO - 2022-06-17 09:09:45 --> Router Class Initialized
INFO - 2022-06-17 09:09:45 --> Output Class Initialized
INFO - 2022-06-17 09:09:45 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:45 --> Input Class Initialized
INFO - 2022-06-17 09:09:45 --> Language Class Initialized
INFO - 2022-06-17 09:09:45 --> Language Class Initialized
INFO - 2022-06-17 09:09:45 --> Config Class Initialized
INFO - 2022-06-17 09:09:45 --> Loader Class Initialized
INFO - 2022-06-17 09:09:45 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:45 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:45 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:45 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:45 --> Controller Class Initialized
INFO - 2022-06-17 09:09:45 --> Final output sent to browser
DEBUG - 2022-06-17 09:09:45 --> Total execution time: 0.0432
INFO - 2022-06-17 09:09:51 --> Config Class Initialized
INFO - 2022-06-17 09:09:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:51 --> URI Class Initialized
INFO - 2022-06-17 09:09:51 --> Router Class Initialized
INFO - 2022-06-17 09:09:51 --> Output Class Initialized
INFO - 2022-06-17 09:09:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:51 --> Input Class Initialized
INFO - 2022-06-17 09:09:51 --> Language Class Initialized
INFO - 2022-06-17 09:09:51 --> Language Class Initialized
INFO - 2022-06-17 09:09:51 --> Config Class Initialized
INFO - 2022-06-17 09:09:51 --> Loader Class Initialized
INFO - 2022-06-17 09:09:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:51 --> Controller Class Initialized
INFO - 2022-06-17 09:09:51 --> Final output sent to browser
DEBUG - 2022-06-17 09:09:51 --> Total execution time: 0.0513
INFO - 2022-06-17 09:09:51 --> Config Class Initialized
INFO - 2022-06-17 09:09:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:51 --> URI Class Initialized
INFO - 2022-06-17 09:09:51 --> Router Class Initialized
INFO - 2022-06-17 09:09:51 --> Output Class Initialized
INFO - 2022-06-17 09:09:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:51 --> Input Class Initialized
INFO - 2022-06-17 09:09:51 --> Language Class Initialized
INFO - 2022-06-17 09:09:51 --> Language Class Initialized
INFO - 2022-06-17 09:09:51 --> Config Class Initialized
INFO - 2022-06-17 09:09:51 --> Loader Class Initialized
INFO - 2022-06-17 09:09:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:51 --> Controller Class Initialized
INFO - 2022-06-17 09:09:52 --> Config Class Initialized
INFO - 2022-06-17 09:09:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:52 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:52 --> URI Class Initialized
INFO - 2022-06-17 09:09:52 --> Router Class Initialized
INFO - 2022-06-17 09:09:52 --> Output Class Initialized
INFO - 2022-06-17 09:09:52 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:52 --> Input Class Initialized
INFO - 2022-06-17 09:09:52 --> Language Class Initialized
INFO - 2022-06-17 09:09:52 --> Language Class Initialized
INFO - 2022-06-17 09:09:52 --> Config Class Initialized
INFO - 2022-06-17 09:09:52 --> Loader Class Initialized
INFO - 2022-06-17 09:09:52 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:52 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:52 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:52 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:52 --> Controller Class Initialized
INFO - 2022-06-17 09:09:52 --> Final output sent to browser
DEBUG - 2022-06-17 09:09:52 --> Total execution time: 0.0507
INFO - 2022-06-17 09:09:59 --> Config Class Initialized
INFO - 2022-06-17 09:09:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:59 --> URI Class Initialized
INFO - 2022-06-17 09:09:59 --> Router Class Initialized
INFO - 2022-06-17 09:09:59 --> Output Class Initialized
INFO - 2022-06-17 09:09:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:59 --> Input Class Initialized
INFO - 2022-06-17 09:09:59 --> Language Class Initialized
INFO - 2022-06-17 09:09:59 --> Language Class Initialized
INFO - 2022-06-17 09:09:59 --> Config Class Initialized
INFO - 2022-06-17 09:09:59 --> Loader Class Initialized
INFO - 2022-06-17 09:09:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:59 --> Controller Class Initialized
INFO - 2022-06-17 09:09:59 --> Final output sent to browser
DEBUG - 2022-06-17 09:09:59 --> Total execution time: 0.0528
INFO - 2022-06-17 09:09:59 --> Config Class Initialized
INFO - 2022-06-17 09:09:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:09:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:09:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:09:59 --> URI Class Initialized
INFO - 2022-06-17 09:09:59 --> Router Class Initialized
INFO - 2022-06-17 09:09:59 --> Output Class Initialized
INFO - 2022-06-17 09:09:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:09:59 --> Input Class Initialized
INFO - 2022-06-17 09:09:59 --> Language Class Initialized
INFO - 2022-06-17 09:09:59 --> Language Class Initialized
INFO - 2022-06-17 09:09:59 --> Config Class Initialized
INFO - 2022-06-17 09:09:59 --> Loader Class Initialized
INFO - 2022-06-17 09:09:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:09:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:09:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:09:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:09:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:09:59 --> Controller Class Initialized
INFO - 2022-06-17 09:10:00 --> Config Class Initialized
INFO - 2022-06-17 09:10:00 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:10:00 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:10:00 --> Utf8 Class Initialized
INFO - 2022-06-17 09:10:00 --> URI Class Initialized
INFO - 2022-06-17 09:10:00 --> Router Class Initialized
INFO - 2022-06-17 09:10:00 --> Output Class Initialized
INFO - 2022-06-17 09:10:00 --> Security Class Initialized
DEBUG - 2022-06-17 09:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:10:00 --> Input Class Initialized
INFO - 2022-06-17 09:10:00 --> Language Class Initialized
INFO - 2022-06-17 09:10:00 --> Language Class Initialized
INFO - 2022-06-17 09:10:00 --> Config Class Initialized
INFO - 2022-06-17 09:10:00 --> Loader Class Initialized
INFO - 2022-06-17 09:10:00 --> Helper loaded: url_helper
INFO - 2022-06-17 09:10:00 --> Helper loaded: file_helper
INFO - 2022-06-17 09:10:00 --> Helper loaded: form_helper
INFO - 2022-06-17 09:10:00 --> Helper loaded: my_helper
INFO - 2022-06-17 09:10:00 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:10:00 --> Controller Class Initialized
INFO - 2022-06-17 09:10:00 --> Final output sent to browser
DEBUG - 2022-06-17 09:10:00 --> Total execution time: 0.0387
INFO - 2022-06-17 09:11:50 --> Config Class Initialized
INFO - 2022-06-17 09:11:50 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:11:50 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:11:50 --> Utf8 Class Initialized
INFO - 2022-06-17 09:11:50 --> URI Class Initialized
INFO - 2022-06-17 09:11:50 --> Router Class Initialized
INFO - 2022-06-17 09:11:50 --> Output Class Initialized
INFO - 2022-06-17 09:11:50 --> Security Class Initialized
DEBUG - 2022-06-17 09:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:11:50 --> Input Class Initialized
INFO - 2022-06-17 09:11:50 --> Language Class Initialized
INFO - 2022-06-17 09:11:50 --> Language Class Initialized
INFO - 2022-06-17 09:11:50 --> Config Class Initialized
INFO - 2022-06-17 09:11:50 --> Loader Class Initialized
INFO - 2022-06-17 09:11:50 --> Helper loaded: url_helper
INFO - 2022-06-17 09:11:50 --> Helper loaded: file_helper
INFO - 2022-06-17 09:11:50 --> Helper loaded: form_helper
INFO - 2022-06-17 09:11:50 --> Helper loaded: my_helper
INFO - 2022-06-17 09:11:50 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:11:50 --> Controller Class Initialized
INFO - 2022-06-17 09:11:50 --> Final output sent to browser
DEBUG - 2022-06-17 09:11:50 --> Total execution time: 0.0437
INFO - 2022-06-17 09:11:50 --> Config Class Initialized
INFO - 2022-06-17 09:11:50 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:11:50 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:11:50 --> Utf8 Class Initialized
INFO - 2022-06-17 09:11:50 --> URI Class Initialized
INFO - 2022-06-17 09:11:50 --> Router Class Initialized
INFO - 2022-06-17 09:11:50 --> Output Class Initialized
INFO - 2022-06-17 09:11:50 --> Security Class Initialized
DEBUG - 2022-06-17 09:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:11:50 --> Input Class Initialized
INFO - 2022-06-17 09:11:50 --> Language Class Initialized
INFO - 2022-06-17 09:11:50 --> Language Class Initialized
INFO - 2022-06-17 09:11:50 --> Config Class Initialized
INFO - 2022-06-17 09:11:50 --> Loader Class Initialized
INFO - 2022-06-17 09:11:50 --> Helper loaded: url_helper
INFO - 2022-06-17 09:11:50 --> Helper loaded: file_helper
INFO - 2022-06-17 09:11:50 --> Helper loaded: form_helper
INFO - 2022-06-17 09:11:50 --> Helper loaded: my_helper
INFO - 2022-06-17 09:11:50 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:11:50 --> Controller Class Initialized
INFO - 2022-06-17 09:11:52 --> Config Class Initialized
INFO - 2022-06-17 09:11:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:11:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:11:52 --> Utf8 Class Initialized
INFO - 2022-06-17 09:11:52 --> URI Class Initialized
INFO - 2022-06-17 09:11:52 --> Router Class Initialized
INFO - 2022-06-17 09:11:52 --> Output Class Initialized
INFO - 2022-06-17 09:11:52 --> Security Class Initialized
DEBUG - 2022-06-17 09:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:11:52 --> Input Class Initialized
INFO - 2022-06-17 09:11:52 --> Language Class Initialized
INFO - 2022-06-17 09:11:52 --> Language Class Initialized
INFO - 2022-06-17 09:11:52 --> Config Class Initialized
INFO - 2022-06-17 09:11:52 --> Loader Class Initialized
INFO - 2022-06-17 09:11:52 --> Helper loaded: url_helper
INFO - 2022-06-17 09:11:52 --> Helper loaded: file_helper
INFO - 2022-06-17 09:11:52 --> Helper loaded: form_helper
INFO - 2022-06-17 09:11:52 --> Helper loaded: my_helper
INFO - 2022-06-17 09:11:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:11:52 --> Controller Class Initialized
INFO - 2022-06-17 09:11:52 --> Final output sent to browser
DEBUG - 2022-06-17 09:11:52 --> Total execution time: 0.0406
INFO - 2022-06-17 09:12:41 --> Config Class Initialized
INFO - 2022-06-17 09:12:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:12:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:12:41 --> Utf8 Class Initialized
INFO - 2022-06-17 09:12:41 --> URI Class Initialized
INFO - 2022-06-17 09:12:41 --> Router Class Initialized
INFO - 2022-06-17 09:12:41 --> Output Class Initialized
INFO - 2022-06-17 09:12:41 --> Security Class Initialized
DEBUG - 2022-06-17 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:12:41 --> Input Class Initialized
INFO - 2022-06-17 09:12:41 --> Language Class Initialized
INFO - 2022-06-17 09:12:41 --> Language Class Initialized
INFO - 2022-06-17 09:12:41 --> Config Class Initialized
INFO - 2022-06-17 09:12:41 --> Loader Class Initialized
INFO - 2022-06-17 09:12:41 --> Helper loaded: url_helper
INFO - 2022-06-17 09:12:41 --> Helper loaded: file_helper
INFO - 2022-06-17 09:12:41 --> Helper loaded: form_helper
INFO - 2022-06-17 09:12:41 --> Helper loaded: my_helper
INFO - 2022-06-17 09:12:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:12:41 --> Controller Class Initialized
INFO - 2022-06-17 09:12:41 --> Final output sent to browser
DEBUG - 2022-06-17 09:12:41 --> Total execution time: 0.0524
INFO - 2022-06-17 09:12:41 --> Config Class Initialized
INFO - 2022-06-17 09:12:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:12:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:12:41 --> Utf8 Class Initialized
INFO - 2022-06-17 09:12:41 --> URI Class Initialized
INFO - 2022-06-17 09:12:41 --> Router Class Initialized
INFO - 2022-06-17 09:12:41 --> Output Class Initialized
INFO - 2022-06-17 09:12:41 --> Security Class Initialized
DEBUG - 2022-06-17 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:12:41 --> Input Class Initialized
INFO - 2022-06-17 09:12:41 --> Language Class Initialized
INFO - 2022-06-17 09:12:41 --> Language Class Initialized
INFO - 2022-06-17 09:12:41 --> Config Class Initialized
INFO - 2022-06-17 09:12:41 --> Loader Class Initialized
INFO - 2022-06-17 09:12:41 --> Helper loaded: url_helper
INFO - 2022-06-17 09:12:41 --> Helper loaded: file_helper
INFO - 2022-06-17 09:12:41 --> Helper loaded: form_helper
INFO - 2022-06-17 09:12:41 --> Helper loaded: my_helper
INFO - 2022-06-17 09:12:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:12:41 --> Controller Class Initialized
INFO - 2022-06-17 09:13:06 --> Config Class Initialized
INFO - 2022-06-17 09:13:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:06 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:06 --> URI Class Initialized
INFO - 2022-06-17 09:13:06 --> Router Class Initialized
INFO - 2022-06-17 09:13:06 --> Output Class Initialized
INFO - 2022-06-17 09:13:06 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:07 --> Input Class Initialized
INFO - 2022-06-17 09:13:07 --> Language Class Initialized
INFO - 2022-06-17 09:13:07 --> Language Class Initialized
INFO - 2022-06-17 09:13:07 --> Config Class Initialized
INFO - 2022-06-17 09:13:07 --> Loader Class Initialized
INFO - 2022-06-17 09:13:07 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:07 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:07 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:07 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:07 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:13:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:07 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:07 --> Total execution time: 0.0397
INFO - 2022-06-17 09:13:13 --> Config Class Initialized
INFO - 2022-06-17 09:13:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:13 --> URI Class Initialized
INFO - 2022-06-17 09:13:13 --> Router Class Initialized
INFO - 2022-06-17 09:13:13 --> Output Class Initialized
INFO - 2022-06-17 09:13:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:13 --> Input Class Initialized
INFO - 2022-06-17 09:13:13 --> Language Class Initialized
INFO - 2022-06-17 09:13:13 --> Language Class Initialized
INFO - 2022-06-17 09:13:13 --> Config Class Initialized
INFO - 2022-06-17 09:13:13 --> Loader Class Initialized
INFO - 2022-06-17 09:13:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:13 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:13:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:13 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:13 --> Total execution time: 0.0416
INFO - 2022-06-17 09:13:13 --> Config Class Initialized
INFO - 2022-06-17 09:13:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:13 --> URI Class Initialized
INFO - 2022-06-17 09:13:13 --> Router Class Initialized
INFO - 2022-06-17 09:13:13 --> Output Class Initialized
INFO - 2022-06-17 09:13:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:13 --> Input Class Initialized
INFO - 2022-06-17 09:13:13 --> Language Class Initialized
INFO - 2022-06-17 09:13:13 --> Language Class Initialized
INFO - 2022-06-17 09:13:13 --> Config Class Initialized
INFO - 2022-06-17 09:13:13 --> Loader Class Initialized
INFO - 2022-06-17 09:13:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:13 --> Controller Class Initialized
INFO - 2022-06-17 09:13:17 --> Config Class Initialized
INFO - 2022-06-17 09:13:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:17 --> URI Class Initialized
INFO - 2022-06-17 09:13:17 --> Router Class Initialized
INFO - 2022-06-17 09:13:17 --> Output Class Initialized
INFO - 2022-06-17 09:13:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:17 --> Input Class Initialized
INFO - 2022-06-17 09:13:17 --> Language Class Initialized
INFO - 2022-06-17 09:13:17 --> Language Class Initialized
INFO - 2022-06-17 09:13:17 --> Config Class Initialized
INFO - 2022-06-17 09:13:17 --> Loader Class Initialized
INFO - 2022-06-17 09:13:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:17 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:17 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:17 --> Total execution time: 0.0526
INFO - 2022-06-17 09:13:20 --> Config Class Initialized
INFO - 2022-06-17 09:13:20 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:20 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:20 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:20 --> URI Class Initialized
INFO - 2022-06-17 09:13:20 --> Router Class Initialized
INFO - 2022-06-17 09:13:20 --> Output Class Initialized
INFO - 2022-06-17 09:13:20 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:20 --> Input Class Initialized
INFO - 2022-06-17 09:13:20 --> Language Class Initialized
INFO - 2022-06-17 09:13:20 --> Language Class Initialized
INFO - 2022-06-17 09:13:20 --> Config Class Initialized
INFO - 2022-06-17 09:13:20 --> Loader Class Initialized
INFO - 2022-06-17 09:13:20 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:20 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:20 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:20 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:20 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:20 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:13:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:20 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:20 --> Total execution time: 0.0447
INFO - 2022-06-17 09:13:20 --> Config Class Initialized
INFO - 2022-06-17 09:13:20 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:20 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:20 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:20 --> URI Class Initialized
INFO - 2022-06-17 09:13:20 --> Router Class Initialized
INFO - 2022-06-17 09:13:20 --> Output Class Initialized
INFO - 2022-06-17 09:13:20 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:20 --> Input Class Initialized
INFO - 2022-06-17 09:13:20 --> Language Class Initialized
INFO - 2022-06-17 09:13:20 --> Language Class Initialized
INFO - 2022-06-17 09:13:20 --> Config Class Initialized
INFO - 2022-06-17 09:13:20 --> Loader Class Initialized
INFO - 2022-06-17 09:13:20 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:20 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:20 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:20 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:20 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:20 --> Controller Class Initialized
INFO - 2022-06-17 09:13:24 --> Config Class Initialized
INFO - 2022-06-17 09:13:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:24 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:24 --> URI Class Initialized
INFO - 2022-06-17 09:13:24 --> Router Class Initialized
INFO - 2022-06-17 09:13:24 --> Output Class Initialized
INFO - 2022-06-17 09:13:24 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:24 --> Input Class Initialized
INFO - 2022-06-17 09:13:24 --> Language Class Initialized
INFO - 2022-06-17 09:13:24 --> Language Class Initialized
INFO - 2022-06-17 09:13:24 --> Config Class Initialized
INFO - 2022-06-17 09:13:24 --> Loader Class Initialized
INFO - 2022-06-17 09:13:24 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:24 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:24 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:24 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:24 --> Controller Class Initialized
INFO - 2022-06-17 09:13:24 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:24 --> Total execution time: 0.0477
INFO - 2022-06-17 09:13:28 --> Config Class Initialized
INFO - 2022-06-17 09:13:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:28 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:28 --> URI Class Initialized
INFO - 2022-06-17 09:13:28 --> Router Class Initialized
INFO - 2022-06-17 09:13:28 --> Output Class Initialized
INFO - 2022-06-17 09:13:28 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:28 --> Input Class Initialized
INFO - 2022-06-17 09:13:28 --> Language Class Initialized
INFO - 2022-06-17 09:13:28 --> Language Class Initialized
INFO - 2022-06-17 09:13:28 --> Config Class Initialized
INFO - 2022-06-17 09:13:28 --> Loader Class Initialized
INFO - 2022-06-17 09:13:28 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:28 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:28 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:28 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:28 --> Controller Class Initialized
INFO - 2022-06-17 09:13:28 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:28 --> Total execution time: 0.0408
INFO - 2022-06-17 09:13:28 --> Config Class Initialized
INFO - 2022-06-17 09:13:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:28 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:28 --> URI Class Initialized
INFO - 2022-06-17 09:13:28 --> Router Class Initialized
INFO - 2022-06-17 09:13:28 --> Output Class Initialized
INFO - 2022-06-17 09:13:28 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:28 --> Input Class Initialized
INFO - 2022-06-17 09:13:28 --> Language Class Initialized
INFO - 2022-06-17 09:13:28 --> Language Class Initialized
INFO - 2022-06-17 09:13:28 --> Config Class Initialized
INFO - 2022-06-17 09:13:28 --> Loader Class Initialized
INFO - 2022-06-17 09:13:28 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:28 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:28 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:28 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:28 --> Controller Class Initialized
INFO - 2022-06-17 09:13:30 --> Config Class Initialized
INFO - 2022-06-17 09:13:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:30 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:30 --> URI Class Initialized
INFO - 2022-06-17 09:13:30 --> Router Class Initialized
INFO - 2022-06-17 09:13:30 --> Output Class Initialized
INFO - 2022-06-17 09:13:30 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:30 --> Input Class Initialized
INFO - 2022-06-17 09:13:30 --> Language Class Initialized
INFO - 2022-06-17 09:13:30 --> Language Class Initialized
INFO - 2022-06-17 09:13:30 --> Config Class Initialized
INFO - 2022-06-17 09:13:30 --> Loader Class Initialized
INFO - 2022-06-17 09:13:30 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:30 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:30 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:30 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:30 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:30 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:30 --> Total execution time: 0.0471
INFO - 2022-06-17 09:13:33 --> Config Class Initialized
INFO - 2022-06-17 09:13:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:33 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:33 --> URI Class Initialized
INFO - 2022-06-17 09:13:33 --> Router Class Initialized
INFO - 2022-06-17 09:13:33 --> Output Class Initialized
INFO - 2022-06-17 09:13:33 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:33 --> Input Class Initialized
INFO - 2022-06-17 09:13:33 --> Language Class Initialized
INFO - 2022-06-17 09:13:33 --> Language Class Initialized
INFO - 2022-06-17 09:13:33 --> Config Class Initialized
INFO - 2022-06-17 09:13:33 --> Loader Class Initialized
INFO - 2022-06-17 09:13:33 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:33 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:33 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:33 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:33 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:33 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:33 --> Total execution time: 0.0524
INFO - 2022-06-17 09:13:33 --> Config Class Initialized
INFO - 2022-06-17 09:13:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:33 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:33 --> URI Class Initialized
INFO - 2022-06-17 09:13:33 --> Router Class Initialized
INFO - 2022-06-17 09:13:33 --> Output Class Initialized
INFO - 2022-06-17 09:13:33 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:33 --> Input Class Initialized
INFO - 2022-06-17 09:13:33 --> Language Class Initialized
INFO - 2022-06-17 09:13:33 --> Language Class Initialized
INFO - 2022-06-17 09:13:33 --> Config Class Initialized
INFO - 2022-06-17 09:13:33 --> Loader Class Initialized
INFO - 2022-06-17 09:13:33 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:33 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:33 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:33 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:33 --> Controller Class Initialized
INFO - 2022-06-17 09:13:35 --> Config Class Initialized
INFO - 2022-06-17 09:13:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:35 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:35 --> URI Class Initialized
INFO - 2022-06-17 09:13:35 --> Router Class Initialized
INFO - 2022-06-17 09:13:35 --> Output Class Initialized
INFO - 2022-06-17 09:13:35 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:35 --> Input Class Initialized
INFO - 2022-06-17 09:13:35 --> Language Class Initialized
INFO - 2022-06-17 09:13:35 --> Language Class Initialized
INFO - 2022-06-17 09:13:35 --> Config Class Initialized
INFO - 2022-06-17 09:13:35 --> Loader Class Initialized
INFO - 2022-06-17 09:13:35 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:35 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:35 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:35 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:35 --> Controller Class Initialized
INFO - 2022-06-17 09:13:35 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:35 --> Total execution time: 0.0425
INFO - 2022-06-17 09:13:42 --> Config Class Initialized
INFO - 2022-06-17 09:13:42 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:42 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:42 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:42 --> URI Class Initialized
INFO - 2022-06-17 09:13:42 --> Router Class Initialized
INFO - 2022-06-17 09:13:42 --> Output Class Initialized
INFO - 2022-06-17 09:13:42 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:42 --> Input Class Initialized
INFO - 2022-06-17 09:13:42 --> Language Class Initialized
INFO - 2022-06-17 09:13:42 --> Language Class Initialized
INFO - 2022-06-17 09:13:42 --> Config Class Initialized
INFO - 2022-06-17 09:13:42 --> Loader Class Initialized
INFO - 2022-06-17 09:13:42 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:42 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:42 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:42 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:42 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:42 --> Controller Class Initialized
INFO - 2022-06-17 09:13:42 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:42 --> Total execution time: 0.0410
INFO - 2022-06-17 09:13:42 --> Config Class Initialized
INFO - 2022-06-17 09:13:42 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:42 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:42 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:42 --> URI Class Initialized
INFO - 2022-06-17 09:13:42 --> Router Class Initialized
INFO - 2022-06-17 09:13:42 --> Output Class Initialized
INFO - 2022-06-17 09:13:42 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:42 --> Input Class Initialized
INFO - 2022-06-17 09:13:42 --> Language Class Initialized
INFO - 2022-06-17 09:13:42 --> Language Class Initialized
INFO - 2022-06-17 09:13:42 --> Config Class Initialized
INFO - 2022-06-17 09:13:42 --> Loader Class Initialized
INFO - 2022-06-17 09:13:42 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:42 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:42 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:42 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:42 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:42 --> Controller Class Initialized
INFO - 2022-06-17 09:13:45 --> Config Class Initialized
INFO - 2022-06-17 09:13:45 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:45 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:45 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:45 --> URI Class Initialized
INFO - 2022-06-17 09:13:45 --> Router Class Initialized
INFO - 2022-06-17 09:13:45 --> Output Class Initialized
INFO - 2022-06-17 09:13:45 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:45 --> Input Class Initialized
INFO - 2022-06-17 09:13:45 --> Language Class Initialized
INFO - 2022-06-17 09:13:45 --> Language Class Initialized
INFO - 2022-06-17 09:13:45 --> Config Class Initialized
INFO - 2022-06-17 09:13:45 --> Loader Class Initialized
INFO - 2022-06-17 09:13:45 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:45 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:45 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:45 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:45 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:45 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:45 --> Total execution time: 0.0505
INFO - 2022-06-17 09:13:47 --> Config Class Initialized
INFO - 2022-06-17 09:13:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:47 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:47 --> URI Class Initialized
INFO - 2022-06-17 09:13:47 --> Router Class Initialized
INFO - 2022-06-17 09:13:47 --> Output Class Initialized
INFO - 2022-06-17 09:13:47 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:47 --> Input Class Initialized
INFO - 2022-06-17 09:13:47 --> Language Class Initialized
INFO - 2022-06-17 09:13:47 --> Language Class Initialized
INFO - 2022-06-17 09:13:47 --> Config Class Initialized
INFO - 2022-06-17 09:13:47 --> Loader Class Initialized
INFO - 2022-06-17 09:13:47 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:47 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:47 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:47 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:48 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:48 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:48 --> Total execution time: 0.0451
INFO - 2022-06-17 09:13:48 --> Config Class Initialized
INFO - 2022-06-17 09:13:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:48 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:48 --> URI Class Initialized
INFO - 2022-06-17 09:13:48 --> Router Class Initialized
INFO - 2022-06-17 09:13:48 --> Output Class Initialized
INFO - 2022-06-17 09:13:48 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:48 --> Input Class Initialized
INFO - 2022-06-17 09:13:48 --> Language Class Initialized
INFO - 2022-06-17 09:13:48 --> Language Class Initialized
INFO - 2022-06-17 09:13:48 --> Config Class Initialized
INFO - 2022-06-17 09:13:48 --> Loader Class Initialized
INFO - 2022-06-17 09:13:48 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:48 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:48 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:48 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:48 --> Controller Class Initialized
INFO - 2022-06-17 09:13:49 --> Config Class Initialized
INFO - 2022-06-17 09:13:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:49 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:49 --> URI Class Initialized
INFO - 2022-06-17 09:13:49 --> Router Class Initialized
INFO - 2022-06-17 09:13:49 --> Output Class Initialized
INFO - 2022-06-17 09:13:49 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:49 --> Input Class Initialized
INFO - 2022-06-17 09:13:49 --> Language Class Initialized
INFO - 2022-06-17 09:13:49 --> Language Class Initialized
INFO - 2022-06-17 09:13:49 --> Config Class Initialized
INFO - 2022-06-17 09:13:49 --> Loader Class Initialized
INFO - 2022-06-17 09:13:49 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:49 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:49 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:49 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:49 --> Controller Class Initialized
INFO - 2022-06-17 09:13:49 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:49 --> Total execution time: 0.0456
INFO - 2022-06-17 09:13:53 --> Config Class Initialized
INFO - 2022-06-17 09:13:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:53 --> URI Class Initialized
INFO - 2022-06-17 09:13:53 --> Router Class Initialized
INFO - 2022-06-17 09:13:53 --> Output Class Initialized
INFO - 2022-06-17 09:13:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:53 --> Input Class Initialized
INFO - 2022-06-17 09:13:53 --> Language Class Initialized
INFO - 2022-06-17 09:13:53 --> Language Class Initialized
INFO - 2022-06-17 09:13:53 --> Config Class Initialized
INFO - 2022-06-17 09:13:53 --> Loader Class Initialized
INFO - 2022-06-17 09:13:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:53 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:53 --> Controller Class Initialized
INFO - 2022-06-17 09:13:53 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:53 --> Total execution time: 0.0492
INFO - 2022-06-17 09:13:53 --> Config Class Initialized
INFO - 2022-06-17 09:13:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:53 --> URI Class Initialized
INFO - 2022-06-17 09:13:53 --> Router Class Initialized
INFO - 2022-06-17 09:13:53 --> Output Class Initialized
INFO - 2022-06-17 09:13:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:53 --> Input Class Initialized
INFO - 2022-06-17 09:13:53 --> Language Class Initialized
INFO - 2022-06-17 09:13:53 --> Language Class Initialized
INFO - 2022-06-17 09:13:53 --> Config Class Initialized
INFO - 2022-06-17 09:13:53 --> Loader Class Initialized
INFO - 2022-06-17 09:13:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:53 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:53 --> Controller Class Initialized
INFO - 2022-06-17 09:13:54 --> Config Class Initialized
INFO - 2022-06-17 09:13:54 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:54 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:54 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:54 --> URI Class Initialized
INFO - 2022-06-17 09:13:54 --> Router Class Initialized
INFO - 2022-06-17 09:13:54 --> Output Class Initialized
INFO - 2022-06-17 09:13:54 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:54 --> Input Class Initialized
INFO - 2022-06-17 09:13:54 --> Language Class Initialized
INFO - 2022-06-17 09:13:54 --> Language Class Initialized
INFO - 2022-06-17 09:13:54 --> Config Class Initialized
INFO - 2022-06-17 09:13:54 --> Loader Class Initialized
INFO - 2022-06-17 09:13:54 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:54 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:54 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:54 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:54 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:13:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:54 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:54 --> Total execution time: 0.0488
INFO - 2022-06-17 09:13:56 --> Config Class Initialized
INFO - 2022-06-17 09:13:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:56 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:56 --> URI Class Initialized
INFO - 2022-06-17 09:13:56 --> Router Class Initialized
INFO - 2022-06-17 09:13:56 --> Output Class Initialized
INFO - 2022-06-17 09:13:56 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:56 --> Input Class Initialized
INFO - 2022-06-17 09:13:56 --> Language Class Initialized
INFO - 2022-06-17 09:13:56 --> Language Class Initialized
INFO - 2022-06-17 09:13:56 --> Config Class Initialized
INFO - 2022-06-17 09:13:56 --> Loader Class Initialized
INFO - 2022-06-17 09:13:56 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:56 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:56 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:56 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:56 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:13:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:56 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:56 --> Total execution time: 0.0395
INFO - 2022-06-17 09:13:58 --> Config Class Initialized
INFO - 2022-06-17 09:13:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:13:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:13:58 --> Utf8 Class Initialized
INFO - 2022-06-17 09:13:58 --> URI Class Initialized
INFO - 2022-06-17 09:13:58 --> Router Class Initialized
INFO - 2022-06-17 09:13:58 --> Output Class Initialized
INFO - 2022-06-17 09:13:58 --> Security Class Initialized
DEBUG - 2022-06-17 09:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:13:58 --> Input Class Initialized
INFO - 2022-06-17 09:13:58 --> Language Class Initialized
INFO - 2022-06-17 09:13:58 --> Language Class Initialized
INFO - 2022-06-17 09:13:58 --> Config Class Initialized
INFO - 2022-06-17 09:13:58 --> Loader Class Initialized
INFO - 2022-06-17 09:13:58 --> Helper loaded: url_helper
INFO - 2022-06-17 09:13:58 --> Helper loaded: file_helper
INFO - 2022-06-17 09:13:58 --> Helper loaded: form_helper
INFO - 2022-06-17 09:13:58 --> Helper loaded: my_helper
INFO - 2022-06-17 09:13:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:13:58 --> Controller Class Initialized
DEBUG - 2022-06-17 09:13:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:13:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:13:58 --> Final output sent to browser
DEBUG - 2022-06-17 09:13:58 --> Total execution time: 0.0531
INFO - 2022-06-17 09:14:00 --> Config Class Initialized
INFO - 2022-06-17 09:14:00 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:00 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:00 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:00 --> URI Class Initialized
INFO - 2022-06-17 09:14:00 --> Router Class Initialized
INFO - 2022-06-17 09:14:00 --> Output Class Initialized
INFO - 2022-06-17 09:14:00 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:00 --> Input Class Initialized
INFO - 2022-06-17 09:14:00 --> Language Class Initialized
INFO - 2022-06-17 09:14:00 --> Language Class Initialized
INFO - 2022-06-17 09:14:00 --> Config Class Initialized
INFO - 2022-06-17 09:14:00 --> Loader Class Initialized
INFO - 2022-06-17 09:14:00 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:00 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:00 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:00 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:00 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:00 --> Controller Class Initialized
DEBUG - 2022-06-17 09:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:14:00 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:00 --> Total execution time: 0.0419
INFO - 2022-06-17 09:14:00 --> Config Class Initialized
INFO - 2022-06-17 09:14:00 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:00 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:00 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:00 --> URI Class Initialized
INFO - 2022-06-17 09:14:00 --> Router Class Initialized
INFO - 2022-06-17 09:14:00 --> Output Class Initialized
INFO - 2022-06-17 09:14:00 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:00 --> Input Class Initialized
INFO - 2022-06-17 09:14:00 --> Language Class Initialized
INFO - 2022-06-17 09:14:00 --> Language Class Initialized
INFO - 2022-06-17 09:14:00 --> Config Class Initialized
INFO - 2022-06-17 09:14:00 --> Loader Class Initialized
INFO - 2022-06-17 09:14:00 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:00 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:00 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:00 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:00 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:00 --> Controller Class Initialized
INFO - 2022-06-17 09:14:02 --> Config Class Initialized
INFO - 2022-06-17 09:14:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:02 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:02 --> URI Class Initialized
INFO - 2022-06-17 09:14:02 --> Router Class Initialized
INFO - 2022-06-17 09:14:02 --> Output Class Initialized
INFO - 2022-06-17 09:14:02 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:02 --> Input Class Initialized
INFO - 2022-06-17 09:14:02 --> Language Class Initialized
INFO - 2022-06-17 09:14:02 --> Language Class Initialized
INFO - 2022-06-17 09:14:02 --> Config Class Initialized
INFO - 2022-06-17 09:14:02 --> Loader Class Initialized
INFO - 2022-06-17 09:14:02 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:02 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:02 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:02 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:02 --> Controller Class Initialized
INFO - 2022-06-17 09:14:02 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:02 --> Total execution time: 0.0373
INFO - 2022-06-17 09:14:07 --> Config Class Initialized
INFO - 2022-06-17 09:14:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:07 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:07 --> URI Class Initialized
INFO - 2022-06-17 09:14:07 --> Router Class Initialized
INFO - 2022-06-17 09:14:07 --> Output Class Initialized
INFO - 2022-06-17 09:14:07 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:07 --> Input Class Initialized
INFO - 2022-06-17 09:14:07 --> Language Class Initialized
INFO - 2022-06-17 09:14:07 --> Language Class Initialized
INFO - 2022-06-17 09:14:07 --> Config Class Initialized
INFO - 2022-06-17 09:14:07 --> Loader Class Initialized
INFO - 2022-06-17 09:14:07 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:07 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:07 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:07 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:07 --> Controller Class Initialized
INFO - 2022-06-17 09:14:07 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:07 --> Total execution time: 0.0532
INFO - 2022-06-17 09:14:07 --> Config Class Initialized
INFO - 2022-06-17 09:14:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:07 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:07 --> URI Class Initialized
INFO - 2022-06-17 09:14:07 --> Router Class Initialized
INFO - 2022-06-17 09:14:07 --> Output Class Initialized
INFO - 2022-06-17 09:14:07 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:07 --> Input Class Initialized
INFO - 2022-06-17 09:14:07 --> Language Class Initialized
INFO - 2022-06-17 09:14:07 --> Language Class Initialized
INFO - 2022-06-17 09:14:07 --> Config Class Initialized
INFO - 2022-06-17 09:14:07 --> Loader Class Initialized
INFO - 2022-06-17 09:14:07 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:07 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:07 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:07 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:07 --> Controller Class Initialized
INFO - 2022-06-17 09:14:09 --> Config Class Initialized
INFO - 2022-06-17 09:14:09 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:09 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:09 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:09 --> URI Class Initialized
INFO - 2022-06-17 09:14:09 --> Router Class Initialized
INFO - 2022-06-17 09:14:09 --> Output Class Initialized
INFO - 2022-06-17 09:14:09 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:09 --> Input Class Initialized
INFO - 2022-06-17 09:14:09 --> Language Class Initialized
INFO - 2022-06-17 09:14:09 --> Language Class Initialized
INFO - 2022-06-17 09:14:09 --> Config Class Initialized
INFO - 2022-06-17 09:14:09 --> Loader Class Initialized
INFO - 2022-06-17 09:14:09 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:09 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:09 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:09 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:09 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:09 --> Controller Class Initialized
DEBUG - 2022-06-17 09:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:14:09 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:09 --> Total execution time: 0.0475
INFO - 2022-06-17 09:14:11 --> Config Class Initialized
INFO - 2022-06-17 09:14:11 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:11 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:11 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:11 --> URI Class Initialized
INFO - 2022-06-17 09:14:11 --> Router Class Initialized
INFO - 2022-06-17 09:14:11 --> Output Class Initialized
INFO - 2022-06-17 09:14:11 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:11 --> Input Class Initialized
INFO - 2022-06-17 09:14:11 --> Language Class Initialized
INFO - 2022-06-17 09:14:11 --> Language Class Initialized
INFO - 2022-06-17 09:14:11 --> Config Class Initialized
INFO - 2022-06-17 09:14:11 --> Loader Class Initialized
INFO - 2022-06-17 09:14:11 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:11 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:11 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:11 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:11 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:11 --> Controller Class Initialized
DEBUG - 2022-06-17 09:14:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:14:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:14:11 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:11 --> Total execution time: 0.0435
INFO - 2022-06-17 09:14:11 --> Config Class Initialized
INFO - 2022-06-17 09:14:11 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:11 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:11 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:11 --> URI Class Initialized
INFO - 2022-06-17 09:14:11 --> Router Class Initialized
INFO - 2022-06-17 09:14:11 --> Output Class Initialized
INFO - 2022-06-17 09:14:11 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:11 --> Input Class Initialized
INFO - 2022-06-17 09:14:11 --> Language Class Initialized
INFO - 2022-06-17 09:14:11 --> Language Class Initialized
INFO - 2022-06-17 09:14:11 --> Config Class Initialized
INFO - 2022-06-17 09:14:11 --> Loader Class Initialized
INFO - 2022-06-17 09:14:11 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:11 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:11 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:11 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:11 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:11 --> Controller Class Initialized
INFO - 2022-06-17 09:14:13 --> Config Class Initialized
INFO - 2022-06-17 09:14:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:13 --> URI Class Initialized
INFO - 2022-06-17 09:14:13 --> Router Class Initialized
INFO - 2022-06-17 09:14:13 --> Output Class Initialized
INFO - 2022-06-17 09:14:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:13 --> Input Class Initialized
INFO - 2022-06-17 09:14:13 --> Language Class Initialized
INFO - 2022-06-17 09:14:13 --> Language Class Initialized
INFO - 2022-06-17 09:14:13 --> Config Class Initialized
INFO - 2022-06-17 09:14:13 --> Loader Class Initialized
INFO - 2022-06-17 09:14:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:13 --> Controller Class Initialized
INFO - 2022-06-17 09:14:13 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:13 --> Total execution time: 0.0474
INFO - 2022-06-17 09:14:17 --> Config Class Initialized
INFO - 2022-06-17 09:14:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:17 --> URI Class Initialized
INFO - 2022-06-17 09:14:17 --> Router Class Initialized
INFO - 2022-06-17 09:14:17 --> Output Class Initialized
INFO - 2022-06-17 09:14:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:17 --> Input Class Initialized
INFO - 2022-06-17 09:14:17 --> Language Class Initialized
INFO - 2022-06-17 09:14:17 --> Language Class Initialized
INFO - 2022-06-17 09:14:17 --> Config Class Initialized
INFO - 2022-06-17 09:14:17 --> Loader Class Initialized
INFO - 2022-06-17 09:14:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:17 --> Controller Class Initialized
INFO - 2022-06-17 09:14:17 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:17 --> Total execution time: 0.0485
INFO - 2022-06-17 09:14:17 --> Config Class Initialized
INFO - 2022-06-17 09:14:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:17 --> URI Class Initialized
INFO - 2022-06-17 09:14:17 --> Router Class Initialized
INFO - 2022-06-17 09:14:17 --> Output Class Initialized
INFO - 2022-06-17 09:14:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:17 --> Input Class Initialized
INFO - 2022-06-17 09:14:17 --> Language Class Initialized
INFO - 2022-06-17 09:14:17 --> Language Class Initialized
INFO - 2022-06-17 09:14:17 --> Config Class Initialized
INFO - 2022-06-17 09:14:17 --> Loader Class Initialized
INFO - 2022-06-17 09:14:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:17 --> Controller Class Initialized
INFO - 2022-06-17 09:14:21 --> Config Class Initialized
INFO - 2022-06-17 09:14:21 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:21 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:21 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:21 --> URI Class Initialized
INFO - 2022-06-17 09:14:21 --> Router Class Initialized
INFO - 2022-06-17 09:14:21 --> Output Class Initialized
INFO - 2022-06-17 09:14:21 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:21 --> Input Class Initialized
INFO - 2022-06-17 09:14:21 --> Language Class Initialized
INFO - 2022-06-17 09:14:21 --> Language Class Initialized
INFO - 2022-06-17 09:14:21 --> Config Class Initialized
INFO - 2022-06-17 09:14:21 --> Loader Class Initialized
INFO - 2022-06-17 09:14:21 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:21 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:21 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:21 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:21 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:21 --> Controller Class Initialized
DEBUG - 2022-06-17 09:14:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:14:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:14:21 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:21 --> Total execution time: 0.0437
INFO - 2022-06-17 09:14:22 --> Config Class Initialized
INFO - 2022-06-17 09:14:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:22 --> URI Class Initialized
INFO - 2022-06-17 09:14:22 --> Router Class Initialized
INFO - 2022-06-17 09:14:22 --> Output Class Initialized
INFO - 2022-06-17 09:14:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:22 --> Input Class Initialized
INFO - 2022-06-17 09:14:22 --> Language Class Initialized
INFO - 2022-06-17 09:14:22 --> Language Class Initialized
INFO - 2022-06-17 09:14:22 --> Config Class Initialized
INFO - 2022-06-17 09:14:22 --> Loader Class Initialized
INFO - 2022-06-17 09:14:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:23 --> Controller Class Initialized
DEBUG - 2022-06-17 09:14:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:14:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:14:23 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:23 --> Total execution time: 0.0439
INFO - 2022-06-17 09:14:23 --> Config Class Initialized
INFO - 2022-06-17 09:14:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:23 --> URI Class Initialized
INFO - 2022-06-17 09:14:23 --> Router Class Initialized
INFO - 2022-06-17 09:14:23 --> Output Class Initialized
INFO - 2022-06-17 09:14:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:23 --> Input Class Initialized
INFO - 2022-06-17 09:14:23 --> Language Class Initialized
INFO - 2022-06-17 09:14:23 --> Language Class Initialized
INFO - 2022-06-17 09:14:23 --> Config Class Initialized
INFO - 2022-06-17 09:14:23 --> Loader Class Initialized
INFO - 2022-06-17 09:14:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:23 --> Controller Class Initialized
INFO - 2022-06-17 09:14:25 --> Config Class Initialized
INFO - 2022-06-17 09:14:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:25 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:25 --> URI Class Initialized
INFO - 2022-06-17 09:14:25 --> Router Class Initialized
INFO - 2022-06-17 09:14:25 --> Output Class Initialized
INFO - 2022-06-17 09:14:25 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:25 --> Input Class Initialized
INFO - 2022-06-17 09:14:25 --> Language Class Initialized
INFO - 2022-06-17 09:14:25 --> Language Class Initialized
INFO - 2022-06-17 09:14:25 --> Config Class Initialized
INFO - 2022-06-17 09:14:25 --> Loader Class Initialized
INFO - 2022-06-17 09:14:25 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:25 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:25 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:25 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:25 --> Controller Class Initialized
INFO - 2022-06-17 09:14:25 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:25 --> Total execution time: 0.0394
INFO - 2022-06-17 09:14:30 --> Config Class Initialized
INFO - 2022-06-17 09:14:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:30 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:30 --> URI Class Initialized
INFO - 2022-06-17 09:14:30 --> Router Class Initialized
INFO - 2022-06-17 09:14:30 --> Output Class Initialized
INFO - 2022-06-17 09:14:30 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:30 --> Input Class Initialized
INFO - 2022-06-17 09:14:30 --> Language Class Initialized
INFO - 2022-06-17 09:14:30 --> Language Class Initialized
INFO - 2022-06-17 09:14:30 --> Config Class Initialized
INFO - 2022-06-17 09:14:30 --> Loader Class Initialized
INFO - 2022-06-17 09:14:30 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:30 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:30 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:30 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:30 --> Controller Class Initialized
INFO - 2022-06-17 09:14:30 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:30 --> Total execution time: 0.0528
INFO - 2022-06-17 09:14:30 --> Config Class Initialized
INFO - 2022-06-17 09:14:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:30 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:30 --> URI Class Initialized
INFO - 2022-06-17 09:14:30 --> Router Class Initialized
INFO - 2022-06-17 09:14:30 --> Output Class Initialized
INFO - 2022-06-17 09:14:30 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:30 --> Input Class Initialized
INFO - 2022-06-17 09:14:30 --> Language Class Initialized
INFO - 2022-06-17 09:14:30 --> Language Class Initialized
INFO - 2022-06-17 09:14:30 --> Config Class Initialized
INFO - 2022-06-17 09:14:30 --> Loader Class Initialized
INFO - 2022-06-17 09:14:30 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:30 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:30 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:30 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:30 --> Controller Class Initialized
INFO - 2022-06-17 09:14:33 --> Config Class Initialized
INFO - 2022-06-17 09:14:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:33 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:33 --> URI Class Initialized
INFO - 2022-06-17 09:14:33 --> Router Class Initialized
INFO - 2022-06-17 09:14:33 --> Output Class Initialized
INFO - 2022-06-17 09:14:33 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:33 --> Input Class Initialized
INFO - 2022-06-17 09:14:33 --> Language Class Initialized
INFO - 2022-06-17 09:14:33 --> Language Class Initialized
INFO - 2022-06-17 09:14:33 --> Config Class Initialized
INFO - 2022-06-17 09:14:33 --> Loader Class Initialized
INFO - 2022-06-17 09:14:33 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:33 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:33 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:33 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:33 --> Controller Class Initialized
DEBUG - 2022-06-17 09:14:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:14:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:14:33 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:33 --> Total execution time: 0.0457
INFO - 2022-06-17 09:14:55 --> Config Class Initialized
INFO - 2022-06-17 09:14:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:55 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:55 --> URI Class Initialized
INFO - 2022-06-17 09:14:55 --> Router Class Initialized
INFO - 2022-06-17 09:14:55 --> Output Class Initialized
INFO - 2022-06-17 09:14:55 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:55 --> Input Class Initialized
INFO - 2022-06-17 09:14:55 --> Language Class Initialized
INFO - 2022-06-17 09:14:55 --> Language Class Initialized
INFO - 2022-06-17 09:14:55 --> Config Class Initialized
INFO - 2022-06-17 09:14:55 --> Loader Class Initialized
INFO - 2022-06-17 09:14:55 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:55 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:55 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:55 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:55 --> Controller Class Initialized
DEBUG - 2022-06-17 09:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:14:55 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:55 --> Total execution time: 0.0502
INFO - 2022-06-17 09:14:55 --> Config Class Initialized
INFO - 2022-06-17 09:14:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:55 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:55 --> URI Class Initialized
INFO - 2022-06-17 09:14:55 --> Router Class Initialized
INFO - 2022-06-17 09:14:55 --> Output Class Initialized
INFO - 2022-06-17 09:14:55 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:55 --> Input Class Initialized
INFO - 2022-06-17 09:14:55 --> Language Class Initialized
INFO - 2022-06-17 09:14:55 --> Language Class Initialized
INFO - 2022-06-17 09:14:55 --> Config Class Initialized
INFO - 2022-06-17 09:14:55 --> Loader Class Initialized
INFO - 2022-06-17 09:14:55 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:55 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:55 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:55 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:55 --> Controller Class Initialized
INFO - 2022-06-17 09:14:57 --> Config Class Initialized
INFO - 2022-06-17 09:14:57 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:14:57 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:14:57 --> Utf8 Class Initialized
INFO - 2022-06-17 09:14:57 --> URI Class Initialized
INFO - 2022-06-17 09:14:57 --> Router Class Initialized
INFO - 2022-06-17 09:14:57 --> Output Class Initialized
INFO - 2022-06-17 09:14:57 --> Security Class Initialized
DEBUG - 2022-06-17 09:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:14:57 --> Input Class Initialized
INFO - 2022-06-17 09:14:57 --> Language Class Initialized
INFO - 2022-06-17 09:14:57 --> Language Class Initialized
INFO - 2022-06-17 09:14:57 --> Config Class Initialized
INFO - 2022-06-17 09:14:57 --> Loader Class Initialized
INFO - 2022-06-17 09:14:57 --> Helper loaded: url_helper
INFO - 2022-06-17 09:14:57 --> Helper loaded: file_helper
INFO - 2022-06-17 09:14:57 --> Helper loaded: form_helper
INFO - 2022-06-17 09:14:57 --> Helper loaded: my_helper
INFO - 2022-06-17 09:14:57 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:14:57 --> Controller Class Initialized
INFO - 2022-06-17 09:14:57 --> Final output sent to browser
DEBUG - 2022-06-17 09:14:57 --> Total execution time: 0.0431
INFO - 2022-06-17 09:15:03 --> Config Class Initialized
INFO - 2022-06-17 09:15:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:03 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:03 --> URI Class Initialized
INFO - 2022-06-17 09:15:03 --> Router Class Initialized
INFO - 2022-06-17 09:15:03 --> Output Class Initialized
INFO - 2022-06-17 09:15:03 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:03 --> Input Class Initialized
INFO - 2022-06-17 09:15:03 --> Language Class Initialized
INFO - 2022-06-17 09:15:03 --> Language Class Initialized
INFO - 2022-06-17 09:15:03 --> Config Class Initialized
INFO - 2022-06-17 09:15:03 --> Loader Class Initialized
INFO - 2022-06-17 09:15:03 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:03 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:03 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:03 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:03 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:03 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:03 --> Total execution time: 0.0394
INFO - 2022-06-17 09:15:06 --> Config Class Initialized
INFO - 2022-06-17 09:15:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:06 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:06 --> URI Class Initialized
INFO - 2022-06-17 09:15:06 --> Router Class Initialized
INFO - 2022-06-17 09:15:06 --> Output Class Initialized
INFO - 2022-06-17 09:15:06 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:06 --> Input Class Initialized
INFO - 2022-06-17 09:15:06 --> Language Class Initialized
INFO - 2022-06-17 09:15:06 --> Language Class Initialized
INFO - 2022-06-17 09:15:06 --> Config Class Initialized
INFO - 2022-06-17 09:15:06 --> Loader Class Initialized
INFO - 2022-06-17 09:15:06 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:06 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:06 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:06 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:06 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:06 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:06 --> Total execution time: 0.0403
INFO - 2022-06-17 09:15:13 --> Config Class Initialized
INFO - 2022-06-17 09:15:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:13 --> URI Class Initialized
INFO - 2022-06-17 09:15:13 --> Router Class Initialized
INFO - 2022-06-17 09:15:13 --> Output Class Initialized
INFO - 2022-06-17 09:15:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:13 --> Input Class Initialized
INFO - 2022-06-17 09:15:13 --> Language Class Initialized
INFO - 2022-06-17 09:15:13 --> Language Class Initialized
INFO - 2022-06-17 09:15:13 --> Config Class Initialized
INFO - 2022-06-17 09:15:13 --> Loader Class Initialized
INFO - 2022-06-17 09:15:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:13 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:15:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:13 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:13 --> Total execution time: 0.0399
INFO - 2022-06-17 09:15:17 --> Config Class Initialized
INFO - 2022-06-17 09:15:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:17 --> URI Class Initialized
INFO - 2022-06-17 09:15:17 --> Router Class Initialized
INFO - 2022-06-17 09:15:17 --> Output Class Initialized
INFO - 2022-06-17 09:15:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:17 --> Input Class Initialized
INFO - 2022-06-17 09:15:17 --> Language Class Initialized
INFO - 2022-06-17 09:15:17 --> Language Class Initialized
INFO - 2022-06-17 09:15:17 --> Config Class Initialized
INFO - 2022-06-17 09:15:17 --> Loader Class Initialized
INFO - 2022-06-17 09:15:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:17 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:17 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:17 --> Total execution time: 0.0408
INFO - 2022-06-17 09:15:18 --> Config Class Initialized
INFO - 2022-06-17 09:15:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:18 --> URI Class Initialized
INFO - 2022-06-17 09:15:18 --> Router Class Initialized
INFO - 2022-06-17 09:15:18 --> Output Class Initialized
INFO - 2022-06-17 09:15:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:18 --> Input Class Initialized
INFO - 2022-06-17 09:15:18 --> Language Class Initialized
INFO - 2022-06-17 09:15:18 --> Language Class Initialized
INFO - 2022-06-17 09:15:18 --> Config Class Initialized
INFO - 2022-06-17 09:15:18 --> Loader Class Initialized
INFO - 2022-06-17 09:15:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:19 --> Controller Class Initialized
INFO - 2022-06-17 09:15:19 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:19 --> Total execution time: 0.0438
INFO - 2022-06-17 09:15:34 --> Config Class Initialized
INFO - 2022-06-17 09:15:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:34 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:34 --> URI Class Initialized
INFO - 2022-06-17 09:15:34 --> Router Class Initialized
INFO - 2022-06-17 09:15:34 --> Output Class Initialized
INFO - 2022-06-17 09:15:34 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:34 --> Input Class Initialized
INFO - 2022-06-17 09:15:34 --> Language Class Initialized
INFO - 2022-06-17 09:15:34 --> Language Class Initialized
INFO - 2022-06-17 09:15:34 --> Config Class Initialized
INFO - 2022-06-17 09:15:34 --> Loader Class Initialized
INFO - 2022-06-17 09:15:34 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:34 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:34 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:34 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:34 --> Controller Class Initialized
INFO - 2022-06-17 09:15:34 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:34 --> Total execution time: 0.0391
INFO - 2022-06-17 09:15:34 --> Config Class Initialized
INFO - 2022-06-17 09:15:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:34 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:34 --> URI Class Initialized
INFO - 2022-06-17 09:15:34 --> Router Class Initialized
INFO - 2022-06-17 09:15:34 --> Output Class Initialized
INFO - 2022-06-17 09:15:34 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:34 --> Input Class Initialized
INFO - 2022-06-17 09:15:34 --> Language Class Initialized
INFO - 2022-06-17 09:15:34 --> Language Class Initialized
INFO - 2022-06-17 09:15:34 --> Config Class Initialized
INFO - 2022-06-17 09:15:34 --> Loader Class Initialized
INFO - 2022-06-17 09:15:34 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:34 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:34 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:34 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:34 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:34 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:34 --> Total execution time: 0.0470
INFO - 2022-06-17 09:15:37 --> Config Class Initialized
INFO - 2022-06-17 09:15:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:37 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:37 --> URI Class Initialized
INFO - 2022-06-17 09:15:37 --> Router Class Initialized
INFO - 2022-06-17 09:15:37 --> Output Class Initialized
INFO - 2022-06-17 09:15:37 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:37 --> Input Class Initialized
INFO - 2022-06-17 09:15:37 --> Language Class Initialized
INFO - 2022-06-17 09:15:37 --> Language Class Initialized
INFO - 2022-06-17 09:15:37 --> Config Class Initialized
INFO - 2022-06-17 09:15:37 --> Loader Class Initialized
INFO - 2022-06-17 09:15:37 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:37 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:37 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:37 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:37 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:15:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:37 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:37 --> Total execution time: 0.0483
INFO - 2022-06-17 09:15:40 --> Config Class Initialized
INFO - 2022-06-17 09:15:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:40 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:40 --> URI Class Initialized
INFO - 2022-06-17 09:15:40 --> Router Class Initialized
INFO - 2022-06-17 09:15:40 --> Output Class Initialized
INFO - 2022-06-17 09:15:40 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:40 --> Input Class Initialized
INFO - 2022-06-17 09:15:40 --> Language Class Initialized
INFO - 2022-06-17 09:15:40 --> Language Class Initialized
INFO - 2022-06-17 09:15:40 --> Config Class Initialized
INFO - 2022-06-17 09:15:40 --> Loader Class Initialized
INFO - 2022-06-17 09:15:40 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:40 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:40 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:40 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:40 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:15:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:40 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:40 --> Total execution time: 0.0404
INFO - 2022-06-17 09:15:40 --> Config Class Initialized
INFO - 2022-06-17 09:15:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:40 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:40 --> URI Class Initialized
INFO - 2022-06-17 09:15:40 --> Router Class Initialized
INFO - 2022-06-17 09:15:40 --> Output Class Initialized
INFO - 2022-06-17 09:15:40 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:40 --> Input Class Initialized
INFO - 2022-06-17 09:15:40 --> Language Class Initialized
INFO - 2022-06-17 09:15:40 --> Language Class Initialized
INFO - 2022-06-17 09:15:40 --> Config Class Initialized
INFO - 2022-06-17 09:15:40 --> Loader Class Initialized
INFO - 2022-06-17 09:15:40 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:40 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:40 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:40 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:40 --> Controller Class Initialized
INFO - 2022-06-17 09:15:42 --> Config Class Initialized
INFO - 2022-06-17 09:15:42 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:42 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:42 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:42 --> URI Class Initialized
INFO - 2022-06-17 09:15:42 --> Router Class Initialized
INFO - 2022-06-17 09:15:42 --> Output Class Initialized
INFO - 2022-06-17 09:15:42 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:42 --> Input Class Initialized
INFO - 2022-06-17 09:15:42 --> Language Class Initialized
INFO - 2022-06-17 09:15:42 --> Language Class Initialized
INFO - 2022-06-17 09:15:42 --> Config Class Initialized
INFO - 2022-06-17 09:15:42 --> Loader Class Initialized
INFO - 2022-06-17 09:15:42 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:42 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:42 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:42 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:42 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:42 --> Controller Class Initialized
INFO - 2022-06-17 09:15:42 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:42 --> Total execution time: 0.0425
INFO - 2022-06-17 09:15:46 --> Config Class Initialized
INFO - 2022-06-17 09:15:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:46 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:46 --> URI Class Initialized
INFO - 2022-06-17 09:15:46 --> Router Class Initialized
INFO - 2022-06-17 09:15:46 --> Output Class Initialized
INFO - 2022-06-17 09:15:46 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:46 --> Input Class Initialized
INFO - 2022-06-17 09:15:46 --> Language Class Initialized
INFO - 2022-06-17 09:15:47 --> Language Class Initialized
INFO - 2022-06-17 09:15:47 --> Config Class Initialized
INFO - 2022-06-17 09:15:47 --> Loader Class Initialized
INFO - 2022-06-17 09:15:47 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:47 --> Controller Class Initialized
INFO - 2022-06-17 09:15:47 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:47 --> Total execution time: 0.0401
INFO - 2022-06-17 09:15:47 --> Config Class Initialized
INFO - 2022-06-17 09:15:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:47 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:47 --> URI Class Initialized
INFO - 2022-06-17 09:15:47 --> Router Class Initialized
INFO - 2022-06-17 09:15:47 --> Output Class Initialized
INFO - 2022-06-17 09:15:47 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:47 --> Input Class Initialized
INFO - 2022-06-17 09:15:47 --> Language Class Initialized
INFO - 2022-06-17 09:15:47 --> Language Class Initialized
INFO - 2022-06-17 09:15:47 --> Config Class Initialized
INFO - 2022-06-17 09:15:47 --> Loader Class Initialized
INFO - 2022-06-17 09:15:47 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:47 --> Controller Class Initialized
INFO - 2022-06-17 09:15:47 --> Config Class Initialized
INFO - 2022-06-17 09:15:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:47 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:47 --> URI Class Initialized
INFO - 2022-06-17 09:15:47 --> Router Class Initialized
INFO - 2022-06-17 09:15:47 --> Output Class Initialized
INFO - 2022-06-17 09:15:47 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:47 --> Input Class Initialized
INFO - 2022-06-17 09:15:47 --> Language Class Initialized
INFO - 2022-06-17 09:15:47 --> Language Class Initialized
INFO - 2022-06-17 09:15:47 --> Config Class Initialized
INFO - 2022-06-17 09:15:47 --> Loader Class Initialized
INFO - 2022-06-17 09:15:47 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:47 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:47 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:15:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:47 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:47 --> Total execution time: 0.0417
INFO - 2022-06-17 09:15:49 --> Config Class Initialized
INFO - 2022-06-17 09:15:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:49 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:49 --> URI Class Initialized
INFO - 2022-06-17 09:15:49 --> Router Class Initialized
INFO - 2022-06-17 09:15:49 --> Output Class Initialized
INFO - 2022-06-17 09:15:49 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:49 --> Input Class Initialized
INFO - 2022-06-17 09:15:49 --> Language Class Initialized
INFO - 2022-06-17 09:15:49 --> Language Class Initialized
INFO - 2022-06-17 09:15:49 --> Config Class Initialized
INFO - 2022-06-17 09:15:49 --> Loader Class Initialized
INFO - 2022-06-17 09:15:49 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:49 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:49 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:49 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:49 --> Controller Class Initialized
DEBUG - 2022-06-17 09:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:15:49 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:49 --> Total execution time: 0.0528
INFO - 2022-06-17 09:15:51 --> Config Class Initialized
INFO - 2022-06-17 09:15:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:15:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:15:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:15:51 --> URI Class Initialized
INFO - 2022-06-17 09:15:51 --> Router Class Initialized
INFO - 2022-06-17 09:15:51 --> Output Class Initialized
INFO - 2022-06-17 09:15:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:15:51 --> Input Class Initialized
INFO - 2022-06-17 09:15:51 --> Language Class Initialized
INFO - 2022-06-17 09:15:51 --> Language Class Initialized
INFO - 2022-06-17 09:15:51 --> Config Class Initialized
INFO - 2022-06-17 09:15:51 --> Loader Class Initialized
INFO - 2022-06-17 09:15:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:15:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:15:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:15:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:15:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:15:51 --> Controller Class Initialized
INFO - 2022-06-17 09:15:51 --> Final output sent to browser
DEBUG - 2022-06-17 09:15:51 --> Total execution time: 0.0370
INFO - 2022-06-17 09:16:08 --> Config Class Initialized
INFO - 2022-06-17 09:16:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:08 --> URI Class Initialized
INFO - 2022-06-17 09:16:08 --> Router Class Initialized
INFO - 2022-06-17 09:16:08 --> Output Class Initialized
INFO - 2022-06-17 09:16:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:08 --> Input Class Initialized
INFO - 2022-06-17 09:16:08 --> Language Class Initialized
INFO - 2022-06-17 09:16:08 --> Language Class Initialized
INFO - 2022-06-17 09:16:08 --> Config Class Initialized
INFO - 2022-06-17 09:16:08 --> Loader Class Initialized
INFO - 2022-06-17 09:16:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:08 --> Controller Class Initialized
INFO - 2022-06-17 09:16:08 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:08 --> Total execution time: 0.0541
INFO - 2022-06-17 09:16:08 --> Config Class Initialized
INFO - 2022-06-17 09:16:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:08 --> URI Class Initialized
INFO - 2022-06-17 09:16:08 --> Router Class Initialized
INFO - 2022-06-17 09:16:08 --> Output Class Initialized
INFO - 2022-06-17 09:16:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:08 --> Input Class Initialized
INFO - 2022-06-17 09:16:08 --> Language Class Initialized
INFO - 2022-06-17 09:16:08 --> Language Class Initialized
INFO - 2022-06-17 09:16:08 --> Config Class Initialized
INFO - 2022-06-17 09:16:08 --> Loader Class Initialized
INFO - 2022-06-17 09:16:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:08 --> Controller Class Initialized
DEBUG - 2022-06-17 09:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:16:08 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:08 --> Total execution time: 0.0437
INFO - 2022-06-17 09:16:17 --> Config Class Initialized
INFO - 2022-06-17 09:16:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:17 --> URI Class Initialized
INFO - 2022-06-17 09:16:17 --> Router Class Initialized
INFO - 2022-06-17 09:16:17 --> Output Class Initialized
INFO - 2022-06-17 09:16:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:17 --> Input Class Initialized
INFO - 2022-06-17 09:16:17 --> Language Class Initialized
INFO - 2022-06-17 09:16:17 --> Language Class Initialized
INFO - 2022-06-17 09:16:17 --> Config Class Initialized
INFO - 2022-06-17 09:16:17 --> Loader Class Initialized
INFO - 2022-06-17 09:16:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:17 --> Controller Class Initialized
DEBUG - 2022-06-17 09:16:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:16:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:16:17 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:17 --> Total execution time: 0.0558
INFO - 2022-06-17 09:16:20 --> Config Class Initialized
INFO - 2022-06-17 09:16:20 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:20 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:20 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:20 --> URI Class Initialized
INFO - 2022-06-17 09:16:20 --> Router Class Initialized
INFO - 2022-06-17 09:16:20 --> Output Class Initialized
INFO - 2022-06-17 09:16:20 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:20 --> Input Class Initialized
INFO - 2022-06-17 09:16:20 --> Language Class Initialized
INFO - 2022-06-17 09:16:20 --> Language Class Initialized
INFO - 2022-06-17 09:16:20 --> Config Class Initialized
INFO - 2022-06-17 09:16:20 --> Loader Class Initialized
INFO - 2022-06-17 09:16:20 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:20 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:20 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:20 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:20 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:20 --> Controller Class Initialized
DEBUG - 2022-06-17 09:16:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:16:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:16:20 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:20 --> Total execution time: 0.0542
INFO - 2022-06-17 09:16:21 --> Config Class Initialized
INFO - 2022-06-17 09:16:21 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:21 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:21 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:21 --> URI Class Initialized
INFO - 2022-06-17 09:16:21 --> Router Class Initialized
INFO - 2022-06-17 09:16:21 --> Output Class Initialized
INFO - 2022-06-17 09:16:21 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:21 --> Input Class Initialized
INFO - 2022-06-17 09:16:21 --> Language Class Initialized
INFO - 2022-06-17 09:16:21 --> Language Class Initialized
INFO - 2022-06-17 09:16:21 --> Config Class Initialized
INFO - 2022-06-17 09:16:21 --> Loader Class Initialized
INFO - 2022-06-17 09:16:21 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:21 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:21 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:21 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:21 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:21 --> Controller Class Initialized
INFO - 2022-06-17 09:16:23 --> Config Class Initialized
INFO - 2022-06-17 09:16:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:23 --> URI Class Initialized
INFO - 2022-06-17 09:16:23 --> Router Class Initialized
INFO - 2022-06-17 09:16:23 --> Output Class Initialized
INFO - 2022-06-17 09:16:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:23 --> Input Class Initialized
INFO - 2022-06-17 09:16:23 --> Language Class Initialized
INFO - 2022-06-17 09:16:23 --> Language Class Initialized
INFO - 2022-06-17 09:16:23 --> Config Class Initialized
INFO - 2022-06-17 09:16:23 --> Loader Class Initialized
INFO - 2022-06-17 09:16:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:23 --> Controller Class Initialized
INFO - 2022-06-17 09:16:23 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:23 --> Total execution time: 0.0502
INFO - 2022-06-17 09:16:28 --> Config Class Initialized
INFO - 2022-06-17 09:16:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:28 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:28 --> URI Class Initialized
INFO - 2022-06-17 09:16:28 --> Router Class Initialized
INFO - 2022-06-17 09:16:28 --> Output Class Initialized
INFO - 2022-06-17 09:16:28 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:28 --> Input Class Initialized
INFO - 2022-06-17 09:16:28 --> Language Class Initialized
INFO - 2022-06-17 09:16:28 --> Language Class Initialized
INFO - 2022-06-17 09:16:28 --> Config Class Initialized
INFO - 2022-06-17 09:16:28 --> Loader Class Initialized
INFO - 2022-06-17 09:16:28 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:28 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:28 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:28 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:28 --> Controller Class Initialized
INFO - 2022-06-17 09:16:28 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:28 --> Total execution time: 0.0513
INFO - 2022-06-17 09:16:28 --> Config Class Initialized
INFO - 2022-06-17 09:16:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:28 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:28 --> URI Class Initialized
INFO - 2022-06-17 09:16:28 --> Router Class Initialized
INFO - 2022-06-17 09:16:28 --> Output Class Initialized
INFO - 2022-06-17 09:16:28 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:28 --> Input Class Initialized
INFO - 2022-06-17 09:16:28 --> Language Class Initialized
INFO - 2022-06-17 09:16:28 --> Language Class Initialized
INFO - 2022-06-17 09:16:28 --> Config Class Initialized
INFO - 2022-06-17 09:16:28 --> Loader Class Initialized
INFO - 2022-06-17 09:16:28 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:28 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:28 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:28 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:28 --> Controller Class Initialized
INFO - 2022-06-17 09:16:29 --> Config Class Initialized
INFO - 2022-06-17 09:16:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:29 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:29 --> URI Class Initialized
INFO - 2022-06-17 09:16:29 --> Router Class Initialized
INFO - 2022-06-17 09:16:29 --> Output Class Initialized
INFO - 2022-06-17 09:16:29 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:29 --> Input Class Initialized
INFO - 2022-06-17 09:16:29 --> Language Class Initialized
INFO - 2022-06-17 09:16:29 --> Language Class Initialized
INFO - 2022-06-17 09:16:29 --> Config Class Initialized
INFO - 2022-06-17 09:16:29 --> Loader Class Initialized
INFO - 2022-06-17 09:16:29 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:29 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:29 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:29 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:29 --> Controller Class Initialized
DEBUG - 2022-06-17 09:16:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:16:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:16:29 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:29 --> Total execution time: 0.0525
INFO - 2022-06-17 09:16:32 --> Config Class Initialized
INFO - 2022-06-17 09:16:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:32 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:32 --> URI Class Initialized
INFO - 2022-06-17 09:16:32 --> Router Class Initialized
INFO - 2022-06-17 09:16:32 --> Output Class Initialized
INFO - 2022-06-17 09:16:32 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:32 --> Input Class Initialized
INFO - 2022-06-17 09:16:32 --> Language Class Initialized
INFO - 2022-06-17 09:16:32 --> Language Class Initialized
INFO - 2022-06-17 09:16:32 --> Config Class Initialized
INFO - 2022-06-17 09:16:32 --> Loader Class Initialized
INFO - 2022-06-17 09:16:32 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:32 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:32 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:32 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:32 --> Controller Class Initialized
DEBUG - 2022-06-17 09:16:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:16:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:16:32 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:32 --> Total execution time: 0.0453
INFO - 2022-06-17 09:16:34 --> Config Class Initialized
INFO - 2022-06-17 09:16:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:34 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:34 --> URI Class Initialized
INFO - 2022-06-17 09:16:34 --> Router Class Initialized
INFO - 2022-06-17 09:16:34 --> Output Class Initialized
INFO - 2022-06-17 09:16:34 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:34 --> Input Class Initialized
INFO - 2022-06-17 09:16:34 --> Language Class Initialized
INFO - 2022-06-17 09:16:34 --> Language Class Initialized
INFO - 2022-06-17 09:16:34 --> Config Class Initialized
INFO - 2022-06-17 09:16:34 --> Loader Class Initialized
INFO - 2022-06-17 09:16:34 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:34 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:34 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:34 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:34 --> Controller Class Initialized
INFO - 2022-06-17 09:16:34 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:34 --> Total execution time: 0.0527
INFO - 2022-06-17 09:16:45 --> Config Class Initialized
INFO - 2022-06-17 09:16:45 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:45 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:45 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:45 --> URI Class Initialized
INFO - 2022-06-17 09:16:45 --> Router Class Initialized
INFO - 2022-06-17 09:16:45 --> Output Class Initialized
INFO - 2022-06-17 09:16:45 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:45 --> Input Class Initialized
INFO - 2022-06-17 09:16:45 --> Language Class Initialized
INFO - 2022-06-17 09:16:45 --> Language Class Initialized
INFO - 2022-06-17 09:16:45 --> Config Class Initialized
INFO - 2022-06-17 09:16:45 --> Loader Class Initialized
INFO - 2022-06-17 09:16:45 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:45 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:45 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:45 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:45 --> Controller Class Initialized
INFO - 2022-06-17 09:16:45 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:45 --> Total execution time: 0.0483
INFO - 2022-06-17 09:16:45 --> Config Class Initialized
INFO - 2022-06-17 09:16:45 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:16:45 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:16:45 --> Utf8 Class Initialized
INFO - 2022-06-17 09:16:45 --> URI Class Initialized
INFO - 2022-06-17 09:16:45 --> Router Class Initialized
INFO - 2022-06-17 09:16:45 --> Output Class Initialized
INFO - 2022-06-17 09:16:45 --> Security Class Initialized
DEBUG - 2022-06-17 09:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:16:45 --> Input Class Initialized
INFO - 2022-06-17 09:16:45 --> Language Class Initialized
INFO - 2022-06-17 09:16:45 --> Language Class Initialized
INFO - 2022-06-17 09:16:45 --> Config Class Initialized
INFO - 2022-06-17 09:16:45 --> Loader Class Initialized
INFO - 2022-06-17 09:16:45 --> Helper loaded: url_helper
INFO - 2022-06-17 09:16:45 --> Helper loaded: file_helper
INFO - 2022-06-17 09:16:45 --> Helper loaded: form_helper
INFO - 2022-06-17 09:16:45 --> Helper loaded: my_helper
INFO - 2022-06-17 09:16:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:16:45 --> Controller Class Initialized
DEBUG - 2022-06-17 09:16:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:16:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:16:45 --> Final output sent to browser
DEBUG - 2022-06-17 09:16:45 --> Total execution time: 0.0536
INFO - 2022-06-17 09:17:41 --> Config Class Initialized
INFO - 2022-06-17 09:17:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:17:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:17:41 --> Utf8 Class Initialized
INFO - 2022-06-17 09:17:41 --> URI Class Initialized
INFO - 2022-06-17 09:17:41 --> Router Class Initialized
INFO - 2022-06-17 09:17:41 --> Output Class Initialized
INFO - 2022-06-17 09:17:41 --> Security Class Initialized
DEBUG - 2022-06-17 09:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:17:41 --> Input Class Initialized
INFO - 2022-06-17 09:17:41 --> Language Class Initialized
INFO - 2022-06-17 09:17:41 --> Language Class Initialized
INFO - 2022-06-17 09:17:41 --> Config Class Initialized
INFO - 2022-06-17 09:17:41 --> Loader Class Initialized
INFO - 2022-06-17 09:17:41 --> Helper loaded: url_helper
INFO - 2022-06-17 09:17:41 --> Helper loaded: file_helper
INFO - 2022-06-17 09:17:41 --> Helper loaded: form_helper
INFO - 2022-06-17 09:17:41 --> Helper loaded: my_helper
INFO - 2022-06-17 09:17:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:17:41 --> Controller Class Initialized
DEBUG - 2022-06-17 09:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:17:41 --> Final output sent to browser
DEBUG - 2022-06-17 09:17:41 --> Total execution time: 0.0527
INFO - 2022-06-17 09:17:51 --> Config Class Initialized
INFO - 2022-06-17 09:17:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:17:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:17:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:17:51 --> URI Class Initialized
INFO - 2022-06-17 09:17:51 --> Router Class Initialized
INFO - 2022-06-17 09:17:51 --> Output Class Initialized
INFO - 2022-06-17 09:17:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:17:51 --> Input Class Initialized
INFO - 2022-06-17 09:17:51 --> Language Class Initialized
INFO - 2022-06-17 09:17:51 --> Language Class Initialized
INFO - 2022-06-17 09:17:51 --> Config Class Initialized
INFO - 2022-06-17 09:17:51 --> Loader Class Initialized
INFO - 2022-06-17 09:17:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:17:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:17:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:17:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:17:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:17:51 --> Controller Class Initialized
DEBUG - 2022-06-17 09:17:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:17:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:17:51 --> Final output sent to browser
DEBUG - 2022-06-17 09:17:51 --> Total execution time: 0.0446
INFO - 2022-06-17 09:17:51 --> Config Class Initialized
INFO - 2022-06-17 09:17:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:17:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:17:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:17:51 --> URI Class Initialized
INFO - 2022-06-17 09:17:51 --> Router Class Initialized
INFO - 2022-06-17 09:17:51 --> Output Class Initialized
INFO - 2022-06-17 09:17:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:17:51 --> Input Class Initialized
INFO - 2022-06-17 09:17:51 --> Language Class Initialized
INFO - 2022-06-17 09:17:51 --> Language Class Initialized
INFO - 2022-06-17 09:17:51 --> Config Class Initialized
INFO - 2022-06-17 09:17:51 --> Loader Class Initialized
INFO - 2022-06-17 09:17:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:17:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:17:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:17:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:17:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:17:51 --> Controller Class Initialized
INFO - 2022-06-17 09:18:17 --> Config Class Initialized
INFO - 2022-06-17 09:18:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:18:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:18:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:18:17 --> URI Class Initialized
INFO - 2022-06-17 09:18:17 --> Router Class Initialized
INFO - 2022-06-17 09:18:17 --> Output Class Initialized
INFO - 2022-06-17 09:18:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:18:17 --> Input Class Initialized
INFO - 2022-06-17 09:18:17 --> Language Class Initialized
INFO - 2022-06-17 09:18:17 --> Language Class Initialized
INFO - 2022-06-17 09:18:17 --> Config Class Initialized
INFO - 2022-06-17 09:18:17 --> Loader Class Initialized
INFO - 2022-06-17 09:18:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:18:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:18:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:18:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:18:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:18:17 --> Controller Class Initialized
INFO - 2022-06-17 09:18:17 --> Final output sent to browser
DEBUG - 2022-06-17 09:18:17 --> Total execution time: 0.0499
INFO - 2022-06-17 09:19:59 --> Config Class Initialized
INFO - 2022-06-17 09:19:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:19:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:19:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:19:59 --> URI Class Initialized
INFO - 2022-06-17 09:19:59 --> Router Class Initialized
INFO - 2022-06-17 09:19:59 --> Output Class Initialized
INFO - 2022-06-17 09:19:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:19:59 --> Input Class Initialized
INFO - 2022-06-17 09:19:59 --> Language Class Initialized
INFO - 2022-06-17 09:19:59 --> Language Class Initialized
INFO - 2022-06-17 09:19:59 --> Config Class Initialized
INFO - 2022-06-17 09:19:59 --> Loader Class Initialized
INFO - 2022-06-17 09:19:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:19:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:19:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:19:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:19:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:19:59 --> Controller Class Initialized
INFO - 2022-06-17 09:19:59 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:19:59 --> Final output sent to browser
DEBUG - 2022-06-17 09:19:59 --> Total execution time: 0.0528
INFO - 2022-06-17 09:19:59 --> Config Class Initialized
INFO - 2022-06-17 09:19:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:19:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:19:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:19:59 --> URI Class Initialized
INFO - 2022-06-17 09:19:59 --> Router Class Initialized
INFO - 2022-06-17 09:19:59 --> Output Class Initialized
INFO - 2022-06-17 09:19:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:19:59 --> Input Class Initialized
INFO - 2022-06-17 09:19:59 --> Language Class Initialized
INFO - 2022-06-17 09:19:59 --> Language Class Initialized
INFO - 2022-06-17 09:19:59 --> Config Class Initialized
INFO - 2022-06-17 09:19:59 --> Loader Class Initialized
INFO - 2022-06-17 09:19:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:19:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:19:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:19:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:19:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:19:59 --> Controller Class Initialized
DEBUG - 2022-06-17 09:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 09:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:19:59 --> Final output sent to browser
DEBUG - 2022-06-17 09:19:59 --> Total execution time: 0.0904
INFO - 2022-06-17 09:20:23 --> Config Class Initialized
INFO - 2022-06-17 09:20:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:23 --> URI Class Initialized
INFO - 2022-06-17 09:20:23 --> Router Class Initialized
INFO - 2022-06-17 09:20:23 --> Output Class Initialized
INFO - 2022-06-17 09:20:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:23 --> Input Class Initialized
INFO - 2022-06-17 09:20:23 --> Language Class Initialized
INFO - 2022-06-17 09:20:23 --> Language Class Initialized
INFO - 2022-06-17 09:20:23 --> Config Class Initialized
INFO - 2022-06-17 09:20:23 --> Loader Class Initialized
INFO - 2022-06-17 09:20:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:23 --> Controller Class Initialized
INFO - 2022-06-17 09:20:23 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:23 --> Total execution time: 0.0524
INFO - 2022-06-17 09:20:23 --> Config Class Initialized
INFO - 2022-06-17 09:20:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:23 --> URI Class Initialized
INFO - 2022-06-17 09:20:23 --> Router Class Initialized
INFO - 2022-06-17 09:20:23 --> Output Class Initialized
INFO - 2022-06-17 09:20:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:23 --> Input Class Initialized
INFO - 2022-06-17 09:20:23 --> Language Class Initialized
INFO - 2022-06-17 09:20:23 --> Language Class Initialized
INFO - 2022-06-17 09:20:23 --> Config Class Initialized
INFO - 2022-06-17 09:20:23 --> Loader Class Initialized
INFO - 2022-06-17 09:20:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:23 --> Controller Class Initialized
INFO - 2022-06-17 09:20:24 --> Config Class Initialized
INFO - 2022-06-17 09:20:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:24 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:24 --> URI Class Initialized
INFO - 2022-06-17 09:20:24 --> Router Class Initialized
INFO - 2022-06-17 09:20:24 --> Output Class Initialized
INFO - 2022-06-17 09:20:24 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:24 --> Input Class Initialized
INFO - 2022-06-17 09:20:24 --> Language Class Initialized
INFO - 2022-06-17 09:20:24 --> Language Class Initialized
INFO - 2022-06-17 09:20:24 --> Config Class Initialized
INFO - 2022-06-17 09:20:24 --> Loader Class Initialized
INFO - 2022-06-17 09:20:24 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:24 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:24 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:24 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:24 --> Controller Class Initialized
INFO - 2022-06-17 09:20:24 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:24 --> Total execution time: 0.0502
INFO - 2022-06-17 09:20:38 --> Config Class Initialized
INFO - 2022-06-17 09:20:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:38 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:38 --> URI Class Initialized
INFO - 2022-06-17 09:20:38 --> Router Class Initialized
INFO - 2022-06-17 09:20:38 --> Output Class Initialized
INFO - 2022-06-17 09:20:38 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:38 --> Input Class Initialized
INFO - 2022-06-17 09:20:38 --> Language Class Initialized
INFO - 2022-06-17 09:20:38 --> Language Class Initialized
INFO - 2022-06-17 09:20:38 --> Config Class Initialized
INFO - 2022-06-17 09:20:38 --> Loader Class Initialized
INFO - 2022-06-17 09:20:38 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:38 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:38 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:38 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:38 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:38 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:38 --> Total execution time: 0.0450
INFO - 2022-06-17 09:20:43 --> Config Class Initialized
INFO - 2022-06-17 09:20:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:43 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:43 --> URI Class Initialized
INFO - 2022-06-17 09:20:43 --> Router Class Initialized
INFO - 2022-06-17 09:20:43 --> Output Class Initialized
INFO - 2022-06-17 09:20:43 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:43 --> Input Class Initialized
INFO - 2022-06-17 09:20:43 --> Language Class Initialized
INFO - 2022-06-17 09:20:43 --> Language Class Initialized
INFO - 2022-06-17 09:20:43 --> Config Class Initialized
INFO - 2022-06-17 09:20:43 --> Loader Class Initialized
INFO - 2022-06-17 09:20:43 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:43 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:43 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:43 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:43 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:43 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:43 --> Total execution time: 0.0467
INFO - 2022-06-17 09:20:43 --> Config Class Initialized
INFO - 2022-06-17 09:20:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:43 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:43 --> URI Class Initialized
INFO - 2022-06-17 09:20:43 --> Router Class Initialized
INFO - 2022-06-17 09:20:43 --> Output Class Initialized
INFO - 2022-06-17 09:20:43 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:43 --> Input Class Initialized
INFO - 2022-06-17 09:20:43 --> Language Class Initialized
INFO - 2022-06-17 09:20:44 --> Language Class Initialized
INFO - 2022-06-17 09:20:44 --> Config Class Initialized
INFO - 2022-06-17 09:20:44 --> Loader Class Initialized
INFO - 2022-06-17 09:20:44 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:44 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:44 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:44 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:44 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:44 --> Controller Class Initialized
INFO - 2022-06-17 09:20:44 --> Config Class Initialized
INFO - 2022-06-17 09:20:44 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:44 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:44 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:44 --> URI Class Initialized
INFO - 2022-06-17 09:20:44 --> Router Class Initialized
INFO - 2022-06-17 09:20:44 --> Output Class Initialized
INFO - 2022-06-17 09:20:44 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:44 --> Input Class Initialized
INFO - 2022-06-17 09:20:44 --> Language Class Initialized
INFO - 2022-06-17 09:20:44 --> Language Class Initialized
INFO - 2022-06-17 09:20:44 --> Config Class Initialized
INFO - 2022-06-17 09:20:44 --> Loader Class Initialized
INFO - 2022-06-17 09:20:44 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:44 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:44 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:44 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:44 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:44 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:44 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:44 --> Total execution time: 0.0473
INFO - 2022-06-17 09:20:46 --> Config Class Initialized
INFO - 2022-06-17 09:20:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:46 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:46 --> URI Class Initialized
INFO - 2022-06-17 09:20:46 --> Router Class Initialized
INFO - 2022-06-17 09:20:46 --> Output Class Initialized
INFO - 2022-06-17 09:20:46 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:46 --> Input Class Initialized
INFO - 2022-06-17 09:20:46 --> Language Class Initialized
INFO - 2022-06-17 09:20:46 --> Language Class Initialized
INFO - 2022-06-17 09:20:46 --> Config Class Initialized
INFO - 2022-06-17 09:20:46 --> Loader Class Initialized
INFO - 2022-06-17 09:20:46 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:46 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:46 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:46 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:46 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:46 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:46 --> Total execution time: 0.0476
INFO - 2022-06-17 09:20:46 --> Config Class Initialized
INFO - 2022-06-17 09:20:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:46 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:46 --> URI Class Initialized
INFO - 2022-06-17 09:20:46 --> Router Class Initialized
INFO - 2022-06-17 09:20:46 --> Output Class Initialized
INFO - 2022-06-17 09:20:46 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:46 --> Input Class Initialized
INFO - 2022-06-17 09:20:46 --> Language Class Initialized
INFO - 2022-06-17 09:20:46 --> Language Class Initialized
INFO - 2022-06-17 09:20:46 --> Config Class Initialized
INFO - 2022-06-17 09:20:46 --> Loader Class Initialized
INFO - 2022-06-17 09:20:46 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:46 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:46 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:46 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:47 --> Controller Class Initialized
INFO - 2022-06-17 09:20:48 --> Config Class Initialized
INFO - 2022-06-17 09:20:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:48 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:48 --> URI Class Initialized
INFO - 2022-06-17 09:20:48 --> Router Class Initialized
INFO - 2022-06-17 09:20:48 --> Output Class Initialized
INFO - 2022-06-17 09:20:48 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:48 --> Input Class Initialized
INFO - 2022-06-17 09:20:48 --> Language Class Initialized
INFO - 2022-06-17 09:20:48 --> Language Class Initialized
INFO - 2022-06-17 09:20:48 --> Config Class Initialized
INFO - 2022-06-17 09:20:48 --> Loader Class Initialized
INFO - 2022-06-17 09:20:48 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:48 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:48 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:48 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:48 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:48 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:48 --> Total execution time: 0.0471
INFO - 2022-06-17 09:20:51 --> Config Class Initialized
INFO - 2022-06-17 09:20:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:51 --> URI Class Initialized
INFO - 2022-06-17 09:20:51 --> Router Class Initialized
INFO - 2022-06-17 09:20:51 --> Output Class Initialized
INFO - 2022-06-17 09:20:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:51 --> Input Class Initialized
INFO - 2022-06-17 09:20:51 --> Language Class Initialized
INFO - 2022-06-17 09:20:51 --> Language Class Initialized
INFO - 2022-06-17 09:20:51 --> Config Class Initialized
INFO - 2022-06-17 09:20:51 --> Loader Class Initialized
INFO - 2022-06-17 09:20:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:51 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:51 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:51 --> Total execution time: 0.0478
INFO - 2022-06-17 09:20:51 --> Config Class Initialized
INFO - 2022-06-17 09:20:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:51 --> URI Class Initialized
INFO - 2022-06-17 09:20:51 --> Router Class Initialized
INFO - 2022-06-17 09:20:51 --> Output Class Initialized
INFO - 2022-06-17 09:20:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:51 --> Input Class Initialized
INFO - 2022-06-17 09:20:51 --> Language Class Initialized
INFO - 2022-06-17 09:20:51 --> Language Class Initialized
INFO - 2022-06-17 09:20:51 --> Config Class Initialized
INFO - 2022-06-17 09:20:51 --> Loader Class Initialized
INFO - 2022-06-17 09:20:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:51 --> Controller Class Initialized
INFO - 2022-06-17 09:20:52 --> Config Class Initialized
INFO - 2022-06-17 09:20:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:52 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:52 --> URI Class Initialized
INFO - 2022-06-17 09:20:52 --> Router Class Initialized
INFO - 2022-06-17 09:20:52 --> Output Class Initialized
INFO - 2022-06-17 09:20:52 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:52 --> Input Class Initialized
INFO - 2022-06-17 09:20:52 --> Language Class Initialized
INFO - 2022-06-17 09:20:52 --> Language Class Initialized
INFO - 2022-06-17 09:20:52 --> Config Class Initialized
INFO - 2022-06-17 09:20:52 --> Loader Class Initialized
INFO - 2022-06-17 09:20:52 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:52 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:52 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:52 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:52 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:52 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:52 --> Total execution time: 0.0858
INFO - 2022-06-17 09:20:53 --> Config Class Initialized
INFO - 2022-06-17 09:20:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:53 --> URI Class Initialized
INFO - 2022-06-17 09:20:53 --> Router Class Initialized
INFO - 2022-06-17 09:20:53 --> Output Class Initialized
INFO - 2022-06-17 09:20:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:53 --> Input Class Initialized
INFO - 2022-06-17 09:20:53 --> Language Class Initialized
INFO - 2022-06-17 09:20:53 --> Language Class Initialized
INFO - 2022-06-17 09:20:53 --> Config Class Initialized
INFO - 2022-06-17 09:20:53 --> Loader Class Initialized
INFO - 2022-06-17 09:20:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:54 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:54 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:54 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:54 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:54 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:54 --> Total execution time: 0.0470
INFO - 2022-06-17 09:20:54 --> Config Class Initialized
INFO - 2022-06-17 09:20:54 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:54 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:54 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:54 --> URI Class Initialized
INFO - 2022-06-17 09:20:54 --> Router Class Initialized
INFO - 2022-06-17 09:20:54 --> Output Class Initialized
INFO - 2022-06-17 09:20:54 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:54 --> Input Class Initialized
INFO - 2022-06-17 09:20:54 --> Language Class Initialized
INFO - 2022-06-17 09:20:54 --> Language Class Initialized
INFO - 2022-06-17 09:20:54 --> Config Class Initialized
INFO - 2022-06-17 09:20:54 --> Loader Class Initialized
INFO - 2022-06-17 09:20:54 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:54 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:54 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:54 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:54 --> Controller Class Initialized
INFO - 2022-06-17 09:20:55 --> Config Class Initialized
INFO - 2022-06-17 09:20:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:55 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:55 --> URI Class Initialized
INFO - 2022-06-17 09:20:55 --> Router Class Initialized
INFO - 2022-06-17 09:20:55 --> Output Class Initialized
INFO - 2022-06-17 09:20:55 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:55 --> Input Class Initialized
INFO - 2022-06-17 09:20:55 --> Language Class Initialized
INFO - 2022-06-17 09:20:55 --> Language Class Initialized
INFO - 2022-06-17 09:20:55 --> Config Class Initialized
INFO - 2022-06-17 09:20:55 --> Loader Class Initialized
INFO - 2022-06-17 09:20:55 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:55 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:55 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:55 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:55 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:20:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:55 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:55 --> Total execution time: 0.0490
INFO - 2022-06-17 09:20:56 --> Config Class Initialized
INFO - 2022-06-17 09:20:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:20:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:20:56 --> Utf8 Class Initialized
INFO - 2022-06-17 09:20:56 --> URI Class Initialized
INFO - 2022-06-17 09:20:56 --> Router Class Initialized
INFO - 2022-06-17 09:20:56 --> Output Class Initialized
INFO - 2022-06-17 09:20:56 --> Security Class Initialized
DEBUG - 2022-06-17 09:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:20:56 --> Input Class Initialized
INFO - 2022-06-17 09:20:56 --> Language Class Initialized
INFO - 2022-06-17 09:20:56 --> Language Class Initialized
INFO - 2022-06-17 09:20:56 --> Config Class Initialized
INFO - 2022-06-17 09:20:56 --> Loader Class Initialized
INFO - 2022-06-17 09:20:56 --> Helper loaded: url_helper
INFO - 2022-06-17 09:20:56 --> Helper loaded: file_helper
INFO - 2022-06-17 09:20:56 --> Helper loaded: form_helper
INFO - 2022-06-17 09:20:56 --> Helper loaded: my_helper
INFO - 2022-06-17 09:20:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:20:56 --> Controller Class Initialized
DEBUG - 2022-06-17 09:20:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 09:20:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:20:56 --> Final output sent to browser
DEBUG - 2022-06-17 09:20:56 --> Total execution time: 0.0539
INFO - 2022-06-17 09:21:17 --> Config Class Initialized
INFO - 2022-06-17 09:21:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:17 --> URI Class Initialized
INFO - 2022-06-17 09:21:17 --> Router Class Initialized
INFO - 2022-06-17 09:21:17 --> Output Class Initialized
INFO - 2022-06-17 09:21:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:17 --> Input Class Initialized
INFO - 2022-06-17 09:21:17 --> Language Class Initialized
INFO - 2022-06-17 09:21:17 --> Language Class Initialized
INFO - 2022-06-17 09:21:17 --> Config Class Initialized
INFO - 2022-06-17 09:21:17 --> Loader Class Initialized
INFO - 2022-06-17 09:21:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:17 --> Controller Class Initialized
INFO - 2022-06-17 09:21:17 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:17 --> Total execution time: 0.0418
INFO - 2022-06-17 09:21:17 --> Config Class Initialized
INFO - 2022-06-17 09:21:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:17 --> URI Class Initialized
INFO - 2022-06-17 09:21:17 --> Router Class Initialized
INFO - 2022-06-17 09:21:17 --> Output Class Initialized
INFO - 2022-06-17 09:21:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:17 --> Input Class Initialized
INFO - 2022-06-17 09:21:17 --> Language Class Initialized
INFO - 2022-06-17 09:21:17 --> Language Class Initialized
INFO - 2022-06-17 09:21:17 --> Config Class Initialized
INFO - 2022-06-17 09:21:17 --> Loader Class Initialized
INFO - 2022-06-17 09:21:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:17 --> Controller Class Initialized
INFO - 2022-06-17 09:21:20 --> Config Class Initialized
INFO - 2022-06-17 09:21:20 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:20 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:20 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:20 --> URI Class Initialized
INFO - 2022-06-17 09:21:20 --> Router Class Initialized
INFO - 2022-06-17 09:21:20 --> Output Class Initialized
INFO - 2022-06-17 09:21:20 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:20 --> Input Class Initialized
INFO - 2022-06-17 09:21:20 --> Language Class Initialized
INFO - 2022-06-17 09:21:20 --> Language Class Initialized
INFO - 2022-06-17 09:21:20 --> Config Class Initialized
INFO - 2022-06-17 09:21:20 --> Loader Class Initialized
INFO - 2022-06-17 09:21:20 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:20 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:20 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:20 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:20 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:20 --> Controller Class Initialized
INFO - 2022-06-17 09:21:20 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:20 --> Total execution time: 0.0370
INFO - 2022-06-17 09:21:33 --> Config Class Initialized
INFO - 2022-06-17 09:21:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:33 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:33 --> URI Class Initialized
INFO - 2022-06-17 09:21:33 --> Router Class Initialized
INFO - 2022-06-17 09:21:33 --> Output Class Initialized
INFO - 2022-06-17 09:21:33 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:33 --> Input Class Initialized
INFO - 2022-06-17 09:21:33 --> Language Class Initialized
INFO - 2022-06-17 09:21:33 --> Language Class Initialized
INFO - 2022-06-17 09:21:33 --> Config Class Initialized
INFO - 2022-06-17 09:21:33 --> Loader Class Initialized
INFO - 2022-06-17 09:21:33 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:33 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:33 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:33 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:33 --> Controller Class Initialized
INFO - 2022-06-17 09:21:33 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:33 --> Total execution time: 0.0408
INFO - 2022-06-17 09:21:33 --> Config Class Initialized
INFO - 2022-06-17 09:21:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:33 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:33 --> URI Class Initialized
INFO - 2022-06-17 09:21:33 --> Router Class Initialized
INFO - 2022-06-17 09:21:33 --> Output Class Initialized
INFO - 2022-06-17 09:21:33 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:33 --> Input Class Initialized
INFO - 2022-06-17 09:21:33 --> Language Class Initialized
INFO - 2022-06-17 09:21:33 --> Language Class Initialized
INFO - 2022-06-17 09:21:33 --> Config Class Initialized
INFO - 2022-06-17 09:21:33 --> Loader Class Initialized
INFO - 2022-06-17 09:21:33 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:33 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:33 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:33 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:33 --> Controller Class Initialized
INFO - 2022-06-17 09:21:43 --> Config Class Initialized
INFO - 2022-06-17 09:21:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:43 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:43 --> URI Class Initialized
INFO - 2022-06-17 09:21:43 --> Router Class Initialized
INFO - 2022-06-17 09:21:43 --> Output Class Initialized
INFO - 2022-06-17 09:21:43 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:43 --> Input Class Initialized
INFO - 2022-06-17 09:21:43 --> Language Class Initialized
INFO - 2022-06-17 09:21:43 --> Language Class Initialized
INFO - 2022-06-17 09:21:43 --> Config Class Initialized
INFO - 2022-06-17 09:21:43 --> Loader Class Initialized
INFO - 2022-06-17 09:21:43 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:43 --> Controller Class Initialized
INFO - 2022-06-17 09:21:43 --> Config Class Initialized
INFO - 2022-06-17 09:21:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:43 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:43 --> URI Class Initialized
INFO - 2022-06-17 09:21:43 --> Router Class Initialized
INFO - 2022-06-17 09:21:43 --> Output Class Initialized
INFO - 2022-06-17 09:21:43 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:43 --> Input Class Initialized
INFO - 2022-06-17 09:21:43 --> Language Class Initialized
INFO - 2022-06-17 09:21:43 --> Language Class Initialized
INFO - 2022-06-17 09:21:43 --> Config Class Initialized
INFO - 2022-06-17 09:21:43 --> Loader Class Initialized
INFO - 2022-06-17 09:21:43 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:43 --> Controller Class Initialized
DEBUG - 2022-06-17 09:21:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:21:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:21:43 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:43 --> Total execution time: 0.0451
INFO - 2022-06-17 09:21:43 --> Config Class Initialized
INFO - 2022-06-17 09:21:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:43 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:43 --> URI Class Initialized
INFO - 2022-06-17 09:21:43 --> Router Class Initialized
INFO - 2022-06-17 09:21:43 --> Output Class Initialized
INFO - 2022-06-17 09:21:43 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:43 --> Input Class Initialized
INFO - 2022-06-17 09:21:43 --> Language Class Initialized
INFO - 2022-06-17 09:21:43 --> Language Class Initialized
INFO - 2022-06-17 09:21:43 --> Config Class Initialized
INFO - 2022-06-17 09:21:43 --> Loader Class Initialized
INFO - 2022-06-17 09:21:43 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:43 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:43 --> Controller Class Initialized
INFO - 2022-06-17 09:21:44 --> Config Class Initialized
INFO - 2022-06-17 09:21:44 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:44 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:44 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:44 --> URI Class Initialized
INFO - 2022-06-17 09:21:44 --> Router Class Initialized
INFO - 2022-06-17 09:21:44 --> Output Class Initialized
INFO - 2022-06-17 09:21:44 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:44 --> Input Class Initialized
INFO - 2022-06-17 09:21:44 --> Language Class Initialized
INFO - 2022-06-17 09:21:44 --> Language Class Initialized
INFO - 2022-06-17 09:21:44 --> Config Class Initialized
INFO - 2022-06-17 09:21:44 --> Loader Class Initialized
INFO - 2022-06-17 09:21:44 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:44 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:44 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:44 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:44 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:44 --> Controller Class Initialized
DEBUG - 2022-06-17 09:21:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 09:21:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:21:44 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:44 --> Total execution time: 0.0463
INFO - 2022-06-17 09:21:47 --> Config Class Initialized
INFO - 2022-06-17 09:21:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:47 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:47 --> URI Class Initialized
INFO - 2022-06-17 09:21:47 --> Router Class Initialized
INFO - 2022-06-17 09:21:47 --> Output Class Initialized
INFO - 2022-06-17 09:21:47 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:47 --> Input Class Initialized
INFO - 2022-06-17 09:21:47 --> Language Class Initialized
INFO - 2022-06-17 09:21:47 --> Language Class Initialized
INFO - 2022-06-17 09:21:47 --> Config Class Initialized
INFO - 2022-06-17 09:21:47 --> Loader Class Initialized
INFO - 2022-06-17 09:21:47 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:47 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:47 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:47 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:47 --> Controller Class Initialized
INFO - 2022-06-17 09:21:47 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:47 --> Total execution time: 0.0901
INFO - 2022-06-17 09:21:47 --> Config Class Initialized
INFO - 2022-06-17 09:21:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:47 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:47 --> URI Class Initialized
INFO - 2022-06-17 09:21:47 --> Router Class Initialized
INFO - 2022-06-17 09:21:47 --> Output Class Initialized
INFO - 2022-06-17 09:21:47 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:47 --> Input Class Initialized
INFO - 2022-06-17 09:21:47 --> Language Class Initialized
INFO - 2022-06-17 09:21:47 --> Language Class Initialized
INFO - 2022-06-17 09:21:47 --> Config Class Initialized
INFO - 2022-06-17 09:21:47 --> Loader Class Initialized
INFO - 2022-06-17 09:21:47 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:47 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:47 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:47 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:47 --> Controller Class Initialized
INFO - 2022-06-17 09:21:48 --> Config Class Initialized
INFO - 2022-06-17 09:21:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:48 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:48 --> URI Class Initialized
INFO - 2022-06-17 09:21:48 --> Router Class Initialized
INFO - 2022-06-17 09:21:48 --> Output Class Initialized
INFO - 2022-06-17 09:21:48 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:48 --> Input Class Initialized
INFO - 2022-06-17 09:21:48 --> Language Class Initialized
INFO - 2022-06-17 09:21:48 --> Language Class Initialized
INFO - 2022-06-17 09:21:48 --> Config Class Initialized
INFO - 2022-06-17 09:21:48 --> Loader Class Initialized
INFO - 2022-06-17 09:21:48 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:48 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:48 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:48 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:48 --> Controller Class Initialized
DEBUG - 2022-06-17 09:21:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:21:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:21:48 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:48 --> Total execution time: 0.0522
INFO - 2022-06-17 09:21:49 --> Config Class Initialized
INFO - 2022-06-17 09:21:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:49 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:49 --> URI Class Initialized
INFO - 2022-06-17 09:21:49 --> Router Class Initialized
INFO - 2022-06-17 09:21:49 --> Output Class Initialized
INFO - 2022-06-17 09:21:49 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:49 --> Input Class Initialized
INFO - 2022-06-17 09:21:49 --> Language Class Initialized
INFO - 2022-06-17 09:21:49 --> Language Class Initialized
INFO - 2022-06-17 09:21:49 --> Config Class Initialized
INFO - 2022-06-17 09:21:49 --> Loader Class Initialized
INFO - 2022-06-17 09:21:49 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:49 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:49 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:49 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:49 --> Controller Class Initialized
DEBUG - 2022-06-17 09:21:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 09:21:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:21:49 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:49 --> Total execution time: 0.0559
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:53 --> URI Class Initialized
INFO - 2022-06-17 09:21:53 --> Router Class Initialized
INFO - 2022-06-17 09:21:53 --> Output Class Initialized
INFO - 2022-06-17 09:21:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:53 --> Input Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Loader Class Initialized
INFO - 2022-06-17 09:21:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:53 --> Controller Class Initialized
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:53 --> URI Class Initialized
INFO - 2022-06-17 09:21:53 --> Router Class Initialized
INFO - 2022-06-17 09:21:53 --> Output Class Initialized
INFO - 2022-06-17 09:21:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:53 --> Input Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Loader Class Initialized
INFO - 2022-06-17 09:21:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:53 --> Controller Class Initialized
INFO - 2022-06-17 09:21:53 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:53 --> Total execution time: 0.0451
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:53 --> URI Class Initialized
INFO - 2022-06-17 09:21:53 --> Router Class Initialized
INFO - 2022-06-17 09:21:53 --> Output Class Initialized
INFO - 2022-06-17 09:21:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:53 --> Input Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Loader Class Initialized
INFO - 2022-06-17 09:21:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:53 --> Hooks Class Initialized
INFO - 2022-06-17 09:21:53 --> Helper loaded: my_helper
DEBUG - 2022-06-17 09:21:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:53 --> URI Class Initialized
INFO - 2022-06-17 09:21:53 --> Database Driver Class Initialized
INFO - 2022-06-17 09:21:53 --> Router Class Initialized
INFO - 2022-06-17 09:21:53 --> Output Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:53 --> Controller Class Initialized
INFO - 2022-06-17 09:21:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:53 --> Input Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
DEBUG - 2022-06-17 09:21:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:21:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:21:53 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:53 --> Total execution time: 0.0475
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Loader Class Initialized
INFO - 2022-06-17 09:21:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:53 --> Controller Class Initialized
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:53 --> URI Class Initialized
INFO - 2022-06-17 09:21:53 --> Router Class Initialized
INFO - 2022-06-17 09:21:53 --> Output Class Initialized
INFO - 2022-06-17 09:21:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:53 --> Input Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Language Class Initialized
INFO - 2022-06-17 09:21:53 --> Config Class Initialized
INFO - 2022-06-17 09:21:53 --> Loader Class Initialized
INFO - 2022-06-17 09:21:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:53 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:53 --> Controller Class Initialized
INFO - 2022-06-17 09:21:54 --> Config Class Initialized
INFO - 2022-06-17 09:21:54 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:54 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:54 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:54 --> URI Class Initialized
INFO - 2022-06-17 09:21:54 --> Router Class Initialized
INFO - 2022-06-17 09:21:54 --> Output Class Initialized
INFO - 2022-06-17 09:21:54 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:54 --> Input Class Initialized
INFO - 2022-06-17 09:21:54 --> Language Class Initialized
INFO - 2022-06-17 09:21:54 --> Language Class Initialized
INFO - 2022-06-17 09:21:54 --> Config Class Initialized
INFO - 2022-06-17 09:21:54 --> Loader Class Initialized
INFO - 2022-06-17 09:21:54 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:54 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:54 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:54 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:54 --> Controller Class Initialized
INFO - 2022-06-17 09:21:54 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:54 --> Total execution time: 0.0519
INFO - 2022-06-17 09:21:54 --> Config Class Initialized
INFO - 2022-06-17 09:21:54 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:54 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:54 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:54 --> URI Class Initialized
INFO - 2022-06-17 09:21:54 --> Router Class Initialized
INFO - 2022-06-17 09:21:54 --> Output Class Initialized
INFO - 2022-06-17 09:21:54 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:54 --> Input Class Initialized
INFO - 2022-06-17 09:21:54 --> Language Class Initialized
INFO - 2022-06-17 09:21:54 --> Language Class Initialized
INFO - 2022-06-17 09:21:54 --> Config Class Initialized
INFO - 2022-06-17 09:21:54 --> Loader Class Initialized
INFO - 2022-06-17 09:21:54 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:54 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:54 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:54 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:54 --> Controller Class Initialized
INFO - 2022-06-17 09:21:54 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:54 --> Total execution time: 0.0398
INFO - 2022-06-17 09:21:57 --> Config Class Initialized
INFO - 2022-06-17 09:21:57 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:57 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:57 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:57 --> URI Class Initialized
INFO - 2022-06-17 09:21:57 --> Router Class Initialized
INFO - 2022-06-17 09:21:57 --> Output Class Initialized
INFO - 2022-06-17 09:21:57 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:57 --> Input Class Initialized
INFO - 2022-06-17 09:21:57 --> Language Class Initialized
INFO - 2022-06-17 09:21:57 --> Language Class Initialized
INFO - 2022-06-17 09:21:57 --> Config Class Initialized
INFO - 2022-06-17 09:21:57 --> Loader Class Initialized
INFO - 2022-06-17 09:21:57 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:57 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:57 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:57 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:57 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:57 --> Controller Class Initialized
INFO - 2022-06-17 09:21:57 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:57 --> Total execution time: 0.0514
INFO - 2022-06-17 09:21:57 --> Config Class Initialized
INFO - 2022-06-17 09:21:57 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:57 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:57 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:57 --> URI Class Initialized
INFO - 2022-06-17 09:21:57 --> Router Class Initialized
INFO - 2022-06-17 09:21:57 --> Output Class Initialized
INFO - 2022-06-17 09:21:57 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:57 --> Input Class Initialized
INFO - 2022-06-17 09:21:57 --> Language Class Initialized
INFO - 2022-06-17 09:21:57 --> Language Class Initialized
INFO - 2022-06-17 09:21:57 --> Config Class Initialized
INFO - 2022-06-17 09:21:57 --> Loader Class Initialized
INFO - 2022-06-17 09:21:57 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:57 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:57 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:57 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:57 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:57 --> Controller Class Initialized
INFO - 2022-06-17 09:21:58 --> Config Class Initialized
INFO - 2022-06-17 09:21:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:58 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:58 --> URI Class Initialized
INFO - 2022-06-17 09:21:58 --> Router Class Initialized
INFO - 2022-06-17 09:21:58 --> Output Class Initialized
INFO - 2022-06-17 09:21:58 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:58 --> Input Class Initialized
INFO - 2022-06-17 09:21:58 --> Language Class Initialized
INFO - 2022-06-17 09:21:58 --> Language Class Initialized
INFO - 2022-06-17 09:21:58 --> Config Class Initialized
INFO - 2022-06-17 09:21:58 --> Loader Class Initialized
INFO - 2022-06-17 09:21:58 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:58 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:58 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:58 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:58 --> Controller Class Initialized
DEBUG - 2022-06-17 09:21:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 09:21:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:21:58 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:58 --> Total execution time: 0.0535
INFO - 2022-06-17 09:21:59 --> Config Class Initialized
INFO - 2022-06-17 09:21:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:21:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:21:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:21:59 --> URI Class Initialized
INFO - 2022-06-17 09:21:59 --> Router Class Initialized
INFO - 2022-06-17 09:21:59 --> Output Class Initialized
INFO - 2022-06-17 09:21:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:21:59 --> Input Class Initialized
INFO - 2022-06-17 09:21:59 --> Language Class Initialized
INFO - 2022-06-17 09:21:59 --> Language Class Initialized
INFO - 2022-06-17 09:21:59 --> Config Class Initialized
INFO - 2022-06-17 09:21:59 --> Loader Class Initialized
INFO - 2022-06-17 09:21:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:21:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:21:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:21:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:21:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:21:59 --> Controller Class Initialized
INFO - 2022-06-17 09:21:59 --> Final output sent to browser
DEBUG - 2022-06-17 09:21:59 --> Total execution time: 0.0397
INFO - 2022-06-17 09:22:01 --> Config Class Initialized
INFO - 2022-06-17 09:22:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:01 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:01 --> URI Class Initialized
INFO - 2022-06-17 09:22:01 --> Router Class Initialized
INFO - 2022-06-17 09:22:01 --> Output Class Initialized
INFO - 2022-06-17 09:22:01 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:01 --> Input Class Initialized
INFO - 2022-06-17 09:22:01 --> Language Class Initialized
INFO - 2022-06-17 09:22:01 --> Language Class Initialized
INFO - 2022-06-17 09:22:01 --> Config Class Initialized
INFO - 2022-06-17 09:22:01 --> Loader Class Initialized
INFO - 2022-06-17 09:22:01 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:01 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:01 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:01 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:01 --> Controller Class Initialized
INFO - 2022-06-17 09:22:02 --> Config Class Initialized
INFO - 2022-06-17 09:22:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:02 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:02 --> URI Class Initialized
INFO - 2022-06-17 09:22:02 --> Router Class Initialized
INFO - 2022-06-17 09:22:02 --> Output Class Initialized
INFO - 2022-06-17 09:22:02 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:02 --> Input Class Initialized
INFO - 2022-06-17 09:22:02 --> Language Class Initialized
INFO - 2022-06-17 09:22:02 --> Language Class Initialized
INFO - 2022-06-17 09:22:02 --> Config Class Initialized
INFO - 2022-06-17 09:22:02 --> Loader Class Initialized
INFO - 2022-06-17 09:22:02 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:02 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:02 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:02 --> Total execution time: 0.0475
INFO - 2022-06-17 09:22:02 --> Config Class Initialized
INFO - 2022-06-17 09:22:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:02 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:02 --> URI Class Initialized
INFO - 2022-06-17 09:22:02 --> Router Class Initialized
INFO - 2022-06-17 09:22:02 --> Output Class Initialized
INFO - 2022-06-17 09:22:02 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:02 --> Input Class Initialized
INFO - 2022-06-17 09:22:02 --> Language Class Initialized
INFO - 2022-06-17 09:22:02 --> Language Class Initialized
INFO - 2022-06-17 09:22:02 --> Config Class Initialized
INFO - 2022-06-17 09:22:02 --> Loader Class Initialized
INFO - 2022-06-17 09:22:02 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:02 --> Controller Class Initialized
INFO - 2022-06-17 09:22:02 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:02 --> Total execution time: 0.0403
INFO - 2022-06-17 09:22:02 --> Config Class Initialized
INFO - 2022-06-17 09:22:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:02 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:02 --> URI Class Initialized
INFO - 2022-06-17 09:22:02 --> Router Class Initialized
INFO - 2022-06-17 09:22:02 --> Output Class Initialized
INFO - 2022-06-17 09:22:02 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:02 --> Input Class Initialized
INFO - 2022-06-17 09:22:02 --> Language Class Initialized
INFO - 2022-06-17 09:22:02 --> Language Class Initialized
INFO - 2022-06-17 09:22:02 --> Config Class Initialized
INFO - 2022-06-17 09:22:02 --> Loader Class Initialized
INFO - 2022-06-17 09:22:02 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:02 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:02 --> Controller Class Initialized
INFO - 2022-06-17 09:22:03 --> Config Class Initialized
INFO - 2022-06-17 09:22:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:03 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:03 --> URI Class Initialized
INFO - 2022-06-17 09:22:03 --> Router Class Initialized
INFO - 2022-06-17 09:22:03 --> Output Class Initialized
INFO - 2022-06-17 09:22:03 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:03 --> Input Class Initialized
INFO - 2022-06-17 09:22:03 --> Language Class Initialized
INFO - 2022-06-17 09:22:03 --> Language Class Initialized
INFO - 2022-06-17 09:22:03 --> Config Class Initialized
INFO - 2022-06-17 09:22:03 --> Loader Class Initialized
INFO - 2022-06-17 09:22:03 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:03 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:03 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:03 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:03 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 09:22:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:03 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:03 --> Total execution time: 0.0461
INFO - 2022-06-17 09:22:03 --> Config Class Initialized
INFO - 2022-06-17 09:22:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:03 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:03 --> URI Class Initialized
INFO - 2022-06-17 09:22:03 --> Router Class Initialized
INFO - 2022-06-17 09:22:03 --> Output Class Initialized
INFO - 2022-06-17 09:22:03 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:03 --> Input Class Initialized
INFO - 2022-06-17 09:22:03 --> Language Class Initialized
INFO - 2022-06-17 09:22:03 --> Language Class Initialized
INFO - 2022-06-17 09:22:03 --> Config Class Initialized
INFO - 2022-06-17 09:22:03 --> Loader Class Initialized
INFO - 2022-06-17 09:22:03 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:03 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:03 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:03 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:03 --> Controller Class Initialized
INFO - 2022-06-17 09:22:03 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:03 --> Total execution time: 0.0382
INFO - 2022-06-17 09:22:07 --> Config Class Initialized
INFO - 2022-06-17 09:22:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:07 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:07 --> URI Class Initialized
INFO - 2022-06-17 09:22:07 --> Router Class Initialized
INFO - 2022-06-17 09:22:07 --> Output Class Initialized
INFO - 2022-06-17 09:22:07 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:07 --> Input Class Initialized
INFO - 2022-06-17 09:22:07 --> Language Class Initialized
INFO - 2022-06-17 09:22:07 --> Language Class Initialized
INFO - 2022-06-17 09:22:07 --> Config Class Initialized
INFO - 2022-06-17 09:22:07 --> Loader Class Initialized
INFO - 2022-06-17 09:22:07 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:07 --> Controller Class Initialized
INFO - 2022-06-17 09:22:07 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:07 --> Total execution time: 0.0421
INFO - 2022-06-17 09:22:07 --> Config Class Initialized
INFO - 2022-06-17 09:22:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:07 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:07 --> URI Class Initialized
INFO - 2022-06-17 09:22:07 --> Router Class Initialized
INFO - 2022-06-17 09:22:07 --> Output Class Initialized
INFO - 2022-06-17 09:22:07 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:07 --> Input Class Initialized
INFO - 2022-06-17 09:22:07 --> Language Class Initialized
INFO - 2022-06-17 09:22:07 --> Language Class Initialized
INFO - 2022-06-17 09:22:07 --> Config Class Initialized
INFO - 2022-06-17 09:22:07 --> Loader Class Initialized
INFO - 2022-06-17 09:22:07 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:07 --> Controller Class Initialized
INFO - 2022-06-17 09:22:07 --> Config Class Initialized
INFO - 2022-06-17 09:22:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:07 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:07 --> URI Class Initialized
INFO - 2022-06-17 09:22:07 --> Router Class Initialized
INFO - 2022-06-17 09:22:07 --> Output Class Initialized
INFO - 2022-06-17 09:22:07 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:07 --> Input Class Initialized
INFO - 2022-06-17 09:22:07 --> Language Class Initialized
INFO - 2022-06-17 09:22:07 --> Language Class Initialized
INFO - 2022-06-17 09:22:07 --> Config Class Initialized
INFO - 2022-06-17 09:22:07 --> Loader Class Initialized
INFO - 2022-06-17 09:22:07 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:07 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:07 --> Controller Class Initialized
INFO - 2022-06-17 09:22:08 --> Config Class Initialized
INFO - 2022-06-17 09:22:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:08 --> URI Class Initialized
INFO - 2022-06-17 09:22:08 --> Router Class Initialized
INFO - 2022-06-17 09:22:08 --> Output Class Initialized
INFO - 2022-06-17 09:22:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:08 --> Input Class Initialized
INFO - 2022-06-17 09:22:08 --> Language Class Initialized
INFO - 2022-06-17 09:22:08 --> Language Class Initialized
INFO - 2022-06-17 09:22:08 --> Config Class Initialized
INFO - 2022-06-17 09:22:08 --> Loader Class Initialized
INFO - 2022-06-17 09:22:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:08 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:22:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:08 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:08 --> Total execution time: 0.0467
INFO - 2022-06-17 09:22:08 --> Config Class Initialized
INFO - 2022-06-17 09:22:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:08 --> URI Class Initialized
INFO - 2022-06-17 09:22:08 --> Router Class Initialized
INFO - 2022-06-17 09:22:08 --> Output Class Initialized
INFO - 2022-06-17 09:22:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:08 --> Input Class Initialized
INFO - 2022-06-17 09:22:08 --> Language Class Initialized
INFO - 2022-06-17 09:22:08 --> Language Class Initialized
INFO - 2022-06-17 09:22:08 --> Config Class Initialized
INFO - 2022-06-17 09:22:08 --> Loader Class Initialized
INFO - 2022-06-17 09:22:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:08 --> Controller Class Initialized
INFO - 2022-06-17 09:22:08 --> Config Class Initialized
INFO - 2022-06-17 09:22:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:08 --> URI Class Initialized
INFO - 2022-06-17 09:22:08 --> Router Class Initialized
INFO - 2022-06-17 09:22:08 --> Output Class Initialized
INFO - 2022-06-17 09:22:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:08 --> Input Class Initialized
INFO - 2022-06-17 09:22:08 --> Language Class Initialized
INFO - 2022-06-17 09:22:08 --> Language Class Initialized
INFO - 2022-06-17 09:22:08 --> Config Class Initialized
INFO - 2022-06-17 09:22:08 --> Loader Class Initialized
INFO - 2022-06-17 09:22:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:08 --> Controller Class Initialized
INFO - 2022-06-17 09:22:08 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:08 --> Total execution time: 0.0392
INFO - 2022-06-17 09:22:09 --> Config Class Initialized
INFO - 2022-06-17 09:22:09 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:09 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:09 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:09 --> URI Class Initialized
INFO - 2022-06-17 09:22:09 --> Router Class Initialized
INFO - 2022-06-17 09:22:09 --> Output Class Initialized
INFO - 2022-06-17 09:22:09 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:09 --> Input Class Initialized
INFO - 2022-06-17 09:22:09 --> Language Class Initialized
INFO - 2022-06-17 09:22:09 --> Language Class Initialized
INFO - 2022-06-17 09:22:09 --> Config Class Initialized
INFO - 2022-06-17 09:22:09 --> Loader Class Initialized
INFO - 2022-06-17 09:22:09 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:09 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:09 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:09 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:09 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:09 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 09:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:09 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:09 --> Total execution time: 0.0467
INFO - 2022-06-17 09:22:12 --> Config Class Initialized
INFO - 2022-06-17 09:22:12 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:12 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:12 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:12 --> URI Class Initialized
INFO - 2022-06-17 09:22:12 --> Router Class Initialized
INFO - 2022-06-17 09:22:12 --> Output Class Initialized
INFO - 2022-06-17 09:22:12 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:12 --> Input Class Initialized
INFO - 2022-06-17 09:22:12 --> Language Class Initialized
INFO - 2022-06-17 09:22:12 --> Language Class Initialized
INFO - 2022-06-17 09:22:12 --> Config Class Initialized
INFO - 2022-06-17 09:22:12 --> Loader Class Initialized
INFO - 2022-06-17 09:22:12 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:12 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:12 --> Controller Class Initialized
INFO - 2022-06-17 09:22:12 --> Config Class Initialized
INFO - 2022-06-17 09:22:12 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:12 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:12 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:12 --> URI Class Initialized
INFO - 2022-06-17 09:22:12 --> Router Class Initialized
INFO - 2022-06-17 09:22:12 --> Output Class Initialized
INFO - 2022-06-17 09:22:12 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:12 --> Input Class Initialized
INFO - 2022-06-17 09:22:12 --> Language Class Initialized
INFO - 2022-06-17 09:22:12 --> Language Class Initialized
INFO - 2022-06-17 09:22:12 --> Config Class Initialized
INFO - 2022-06-17 09:22:12 --> Loader Class Initialized
INFO - 2022-06-17 09:22:12 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:12 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:12 --> Controller Class Initialized
INFO - 2022-06-17 09:22:12 --> Config Class Initialized
INFO - 2022-06-17 09:22:12 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:12 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:12 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:12 --> URI Class Initialized
INFO - 2022-06-17 09:22:12 --> Router Class Initialized
INFO - 2022-06-17 09:22:12 --> Output Class Initialized
INFO - 2022-06-17 09:22:12 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:12 --> Input Class Initialized
INFO - 2022-06-17 09:22:12 --> Language Class Initialized
INFO - 2022-06-17 09:22:12 --> Language Class Initialized
INFO - 2022-06-17 09:22:12 --> Config Class Initialized
INFO - 2022-06-17 09:22:12 --> Loader Class Initialized
INFO - 2022-06-17 09:22:12 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:12 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:12 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:12 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:22:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:12 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:12 --> Total execution time: 0.0444
INFO - 2022-06-17 09:22:14 --> Config Class Initialized
INFO - 2022-06-17 09:22:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:14 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:14 --> URI Class Initialized
INFO - 2022-06-17 09:22:14 --> Router Class Initialized
INFO - 2022-06-17 09:22:14 --> Output Class Initialized
INFO - 2022-06-17 09:22:14 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:14 --> Input Class Initialized
INFO - 2022-06-17 09:22:14 --> Language Class Initialized
INFO - 2022-06-17 09:22:14 --> Language Class Initialized
INFO - 2022-06-17 09:22:14 --> Config Class Initialized
INFO - 2022-06-17 09:22:14 --> Loader Class Initialized
INFO - 2022-06-17 09:22:14 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:14 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:14 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:14 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:14 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 09:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:14 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:14 --> Total execution time: 0.0502
INFO - 2022-06-17 09:22:17 --> Config Class Initialized
INFO - 2022-06-17 09:22:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:17 --> URI Class Initialized
INFO - 2022-06-17 09:22:17 --> Router Class Initialized
INFO - 2022-06-17 09:22:17 --> Output Class Initialized
INFO - 2022-06-17 09:22:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:17 --> Input Class Initialized
INFO - 2022-06-17 09:22:17 --> Language Class Initialized
INFO - 2022-06-17 09:22:17 --> Language Class Initialized
INFO - 2022-06-17 09:22:17 --> Config Class Initialized
INFO - 2022-06-17 09:22:17 --> Loader Class Initialized
INFO - 2022-06-17 09:22:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:17 --> Controller Class Initialized
INFO - 2022-06-17 09:22:17 --> Config Class Initialized
INFO - 2022-06-17 09:22:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:17 --> URI Class Initialized
INFO - 2022-06-17 09:22:17 --> Router Class Initialized
INFO - 2022-06-17 09:22:17 --> Output Class Initialized
INFO - 2022-06-17 09:22:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:17 --> Input Class Initialized
INFO - 2022-06-17 09:22:17 --> Language Class Initialized
INFO - 2022-06-17 09:22:17 --> Language Class Initialized
INFO - 2022-06-17 09:22:17 --> Config Class Initialized
INFO - 2022-06-17 09:22:17 --> Loader Class Initialized
INFO - 2022-06-17 09:22:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:17 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:17 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:17 --> Total execution time: 0.1101
INFO - 2022-06-17 09:22:17 --> Config Class Initialized
INFO - 2022-06-17 09:22:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:17 --> URI Class Initialized
INFO - 2022-06-17 09:22:17 --> Router Class Initialized
INFO - 2022-06-17 09:22:17 --> Output Class Initialized
INFO - 2022-06-17 09:22:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:17 --> Input Class Initialized
INFO - 2022-06-17 09:22:17 --> Language Class Initialized
INFO - 2022-06-17 09:22:17 --> Language Class Initialized
INFO - 2022-06-17 09:22:17 --> Config Class Initialized
INFO - 2022-06-17 09:22:17 --> Loader Class Initialized
INFO - 2022-06-17 09:22:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:17 --> Controller Class Initialized
INFO - 2022-06-17 09:22:18 --> Config Class Initialized
INFO - 2022-06-17 09:22:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:18 --> URI Class Initialized
INFO - 2022-06-17 09:22:18 --> Router Class Initialized
INFO - 2022-06-17 09:22:18 --> Output Class Initialized
INFO - 2022-06-17 09:22:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:18 --> Input Class Initialized
INFO - 2022-06-17 09:22:18 --> Language Class Initialized
INFO - 2022-06-17 09:22:18 --> Language Class Initialized
INFO - 2022-06-17 09:22:18 --> Config Class Initialized
INFO - 2022-06-17 09:22:18 --> Loader Class Initialized
INFO - 2022-06-17 09:22:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:19 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 09:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:19 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:19 --> Total execution time: 0.0554
INFO - 2022-06-17 09:22:22 --> Config Class Initialized
INFO - 2022-06-17 09:22:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:22 --> URI Class Initialized
INFO - 2022-06-17 09:22:22 --> Router Class Initialized
INFO - 2022-06-17 09:22:22 --> Output Class Initialized
INFO - 2022-06-17 09:22:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:22 --> Input Class Initialized
INFO - 2022-06-17 09:22:22 --> Language Class Initialized
INFO - 2022-06-17 09:22:22 --> Language Class Initialized
INFO - 2022-06-17 09:22:22 --> Config Class Initialized
INFO - 2022-06-17 09:22:22 --> Loader Class Initialized
INFO - 2022-06-17 09:22:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:22 --> Controller Class Initialized
INFO - 2022-06-17 09:22:22 --> Config Class Initialized
INFO - 2022-06-17 09:22:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:22 --> URI Class Initialized
INFO - 2022-06-17 09:22:22 --> Router Class Initialized
INFO - 2022-06-17 09:22:22 --> Output Class Initialized
INFO - 2022-06-17 09:22:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:22 --> Input Class Initialized
INFO - 2022-06-17 09:22:22 --> Language Class Initialized
INFO - 2022-06-17 09:22:22 --> Language Class Initialized
INFO - 2022-06-17 09:22:22 --> Config Class Initialized
INFO - 2022-06-17 09:22:22 --> Loader Class Initialized
INFO - 2022-06-17 09:22:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:22 --> Controller Class Initialized
DEBUG - 2022-06-17 09:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:22:23 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:23 --> Total execution time: 0.0470
INFO - 2022-06-17 09:22:56 --> Config Class Initialized
INFO - 2022-06-17 09:22:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:56 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:56 --> URI Class Initialized
INFO - 2022-06-17 09:22:56 --> Router Class Initialized
INFO - 2022-06-17 09:22:56 --> Output Class Initialized
INFO - 2022-06-17 09:22:56 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:56 --> Input Class Initialized
INFO - 2022-06-17 09:22:56 --> Language Class Initialized
INFO - 2022-06-17 09:22:56 --> Language Class Initialized
INFO - 2022-06-17 09:22:56 --> Config Class Initialized
INFO - 2022-06-17 09:22:56 --> Loader Class Initialized
INFO - 2022-06-17 09:22:56 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:56 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:56 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:56 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:56 --> Controller Class Initialized
INFO - 2022-06-17 09:22:56 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:56 --> Total execution time: 0.0501
INFO - 2022-06-17 09:22:56 --> Config Class Initialized
INFO - 2022-06-17 09:22:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:56 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:56 --> URI Class Initialized
INFO - 2022-06-17 09:22:56 --> Router Class Initialized
INFO - 2022-06-17 09:22:56 --> Output Class Initialized
INFO - 2022-06-17 09:22:56 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:56 --> Input Class Initialized
INFO - 2022-06-17 09:22:56 --> Language Class Initialized
INFO - 2022-06-17 09:22:56 --> Language Class Initialized
INFO - 2022-06-17 09:22:56 --> Config Class Initialized
INFO - 2022-06-17 09:22:56 --> Loader Class Initialized
INFO - 2022-06-17 09:22:56 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:56 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:56 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:56 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:56 --> Controller Class Initialized
INFO - 2022-06-17 09:22:58 --> Config Class Initialized
INFO - 2022-06-17 09:22:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:22:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:22:58 --> Utf8 Class Initialized
INFO - 2022-06-17 09:22:58 --> URI Class Initialized
INFO - 2022-06-17 09:22:58 --> Router Class Initialized
INFO - 2022-06-17 09:22:58 --> Output Class Initialized
INFO - 2022-06-17 09:22:58 --> Security Class Initialized
DEBUG - 2022-06-17 09:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:22:58 --> Input Class Initialized
INFO - 2022-06-17 09:22:58 --> Language Class Initialized
INFO - 2022-06-17 09:22:58 --> Language Class Initialized
INFO - 2022-06-17 09:22:58 --> Config Class Initialized
INFO - 2022-06-17 09:22:58 --> Loader Class Initialized
INFO - 2022-06-17 09:22:58 --> Helper loaded: url_helper
INFO - 2022-06-17 09:22:58 --> Helper loaded: file_helper
INFO - 2022-06-17 09:22:58 --> Helper loaded: form_helper
INFO - 2022-06-17 09:22:58 --> Helper loaded: my_helper
INFO - 2022-06-17 09:22:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:22:59 --> Controller Class Initialized
INFO - 2022-06-17 09:22:59 --> Final output sent to browser
DEBUG - 2022-06-17 09:22:59 --> Total execution time: 0.0464
INFO - 2022-06-17 09:23:03 --> Config Class Initialized
INFO - 2022-06-17 09:23:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:03 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:03 --> URI Class Initialized
INFO - 2022-06-17 09:23:03 --> Router Class Initialized
INFO - 2022-06-17 09:23:03 --> Output Class Initialized
INFO - 2022-06-17 09:23:03 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:03 --> Input Class Initialized
INFO - 2022-06-17 09:23:03 --> Language Class Initialized
INFO - 2022-06-17 09:23:03 --> Language Class Initialized
INFO - 2022-06-17 09:23:03 --> Config Class Initialized
INFO - 2022-06-17 09:23:03 --> Loader Class Initialized
INFO - 2022-06-17 09:23:03 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:03 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:03 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:03 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:03 --> Controller Class Initialized
INFO - 2022-06-17 09:23:03 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:03 --> Total execution time: 0.2340
INFO - 2022-06-17 09:23:03 --> Config Class Initialized
INFO - 2022-06-17 09:23:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:03 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:03 --> URI Class Initialized
INFO - 2022-06-17 09:23:03 --> Router Class Initialized
INFO - 2022-06-17 09:23:03 --> Output Class Initialized
INFO - 2022-06-17 09:23:03 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:03 --> Input Class Initialized
INFO - 2022-06-17 09:23:03 --> Language Class Initialized
INFO - 2022-06-17 09:23:03 --> Language Class Initialized
INFO - 2022-06-17 09:23:03 --> Config Class Initialized
INFO - 2022-06-17 09:23:03 --> Loader Class Initialized
INFO - 2022-06-17 09:23:03 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:03 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:03 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:03 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:03 --> Controller Class Initialized
INFO - 2022-06-17 09:23:04 --> Config Class Initialized
INFO - 2022-06-17 09:23:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:04 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:04 --> URI Class Initialized
INFO - 2022-06-17 09:23:04 --> Router Class Initialized
INFO - 2022-06-17 09:23:04 --> Output Class Initialized
INFO - 2022-06-17 09:23:04 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:04 --> Input Class Initialized
INFO - 2022-06-17 09:23:04 --> Language Class Initialized
INFO - 2022-06-17 09:23:04 --> Language Class Initialized
INFO - 2022-06-17 09:23:04 --> Config Class Initialized
INFO - 2022-06-17 09:23:04 --> Loader Class Initialized
INFO - 2022-06-17 09:23:04 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:04 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:04 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:04 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:04 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:23:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:04 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:04 --> Total execution time: 0.0518
INFO - 2022-06-17 09:23:05 --> Config Class Initialized
INFO - 2022-06-17 09:23:05 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:05 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:05 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:05 --> URI Class Initialized
INFO - 2022-06-17 09:23:05 --> Router Class Initialized
INFO - 2022-06-17 09:23:05 --> Output Class Initialized
INFO - 2022-06-17 09:23:05 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:05 --> Input Class Initialized
INFO - 2022-06-17 09:23:05 --> Language Class Initialized
INFO - 2022-06-17 09:23:05 --> Language Class Initialized
INFO - 2022-06-17 09:23:05 --> Config Class Initialized
INFO - 2022-06-17 09:23:05 --> Loader Class Initialized
INFO - 2022-06-17 09:23:05 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:05 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:05 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:05 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:05 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:05 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:23:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:05 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:05 --> Total execution time: 0.0513
INFO - 2022-06-17 09:23:07 --> Config Class Initialized
INFO - 2022-06-17 09:23:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:07 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:07 --> URI Class Initialized
INFO - 2022-06-17 09:23:07 --> Router Class Initialized
INFO - 2022-06-17 09:23:07 --> Output Class Initialized
INFO - 2022-06-17 09:23:07 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:07 --> Input Class Initialized
INFO - 2022-06-17 09:23:07 --> Language Class Initialized
INFO - 2022-06-17 09:23:07 --> Language Class Initialized
INFO - 2022-06-17 09:23:07 --> Config Class Initialized
INFO - 2022-06-17 09:23:07 --> Loader Class Initialized
INFO - 2022-06-17 09:23:07 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:07 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:07 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:07 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:07 --> Controller Class Initialized
INFO - 2022-06-17 09:23:07 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:07 --> Total execution time: 0.0435
INFO - 2022-06-17 09:23:29 --> Config Class Initialized
INFO - 2022-06-17 09:23:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:29 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:29 --> URI Class Initialized
INFO - 2022-06-17 09:23:29 --> Router Class Initialized
INFO - 2022-06-17 09:23:29 --> Output Class Initialized
INFO - 2022-06-17 09:23:29 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:29 --> Input Class Initialized
INFO - 2022-06-17 09:23:29 --> Language Class Initialized
INFO - 2022-06-17 09:23:29 --> Language Class Initialized
INFO - 2022-06-17 09:23:29 --> Config Class Initialized
INFO - 2022-06-17 09:23:29 --> Loader Class Initialized
INFO - 2022-06-17 09:23:29 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:29 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:29 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:29 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:29 --> Controller Class Initialized
INFO - 2022-06-17 09:23:29 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:29 --> Total execution time: 0.0540
INFO - 2022-06-17 09:23:29 --> Config Class Initialized
INFO - 2022-06-17 09:23:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:29 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:29 --> URI Class Initialized
INFO - 2022-06-17 09:23:29 --> Router Class Initialized
INFO - 2022-06-17 09:23:29 --> Output Class Initialized
INFO - 2022-06-17 09:23:29 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:29 --> Input Class Initialized
INFO - 2022-06-17 09:23:29 --> Language Class Initialized
INFO - 2022-06-17 09:23:29 --> Language Class Initialized
INFO - 2022-06-17 09:23:29 --> Config Class Initialized
INFO - 2022-06-17 09:23:29 --> Loader Class Initialized
INFO - 2022-06-17 09:23:29 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:29 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:29 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:29 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:29 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:29 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:29 --> Total execution time: 0.0476
INFO - 2022-06-17 09:23:31 --> Config Class Initialized
INFO - 2022-06-17 09:23:31 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:31 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:31 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:31 --> URI Class Initialized
INFO - 2022-06-17 09:23:31 --> Router Class Initialized
INFO - 2022-06-17 09:23:31 --> Output Class Initialized
INFO - 2022-06-17 09:23:31 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:31 --> Input Class Initialized
INFO - 2022-06-17 09:23:31 --> Language Class Initialized
INFO - 2022-06-17 09:23:31 --> Language Class Initialized
INFO - 2022-06-17 09:23:31 --> Config Class Initialized
INFO - 2022-06-17 09:23:31 --> Loader Class Initialized
INFO - 2022-06-17 09:23:31 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:31 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:31 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:31 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:31 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:31 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:31 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:31 --> Total execution time: 0.0446
INFO - 2022-06-17 09:23:33 --> Config Class Initialized
INFO - 2022-06-17 09:23:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:33 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:33 --> URI Class Initialized
INFO - 2022-06-17 09:23:33 --> Router Class Initialized
INFO - 2022-06-17 09:23:33 --> Output Class Initialized
INFO - 2022-06-17 09:23:33 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:33 --> Input Class Initialized
INFO - 2022-06-17 09:23:33 --> Language Class Initialized
INFO - 2022-06-17 09:23:33 --> Language Class Initialized
INFO - 2022-06-17 09:23:33 --> Config Class Initialized
INFO - 2022-06-17 09:23:33 --> Loader Class Initialized
INFO - 2022-06-17 09:23:33 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:33 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:33 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:33 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:33 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:33 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:33 --> Total execution time: 0.0500
INFO - 2022-06-17 09:23:36 --> Config Class Initialized
INFO - 2022-06-17 09:23:36 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:36 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:36 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:36 --> URI Class Initialized
INFO - 2022-06-17 09:23:36 --> Router Class Initialized
INFO - 2022-06-17 09:23:36 --> Output Class Initialized
INFO - 2022-06-17 09:23:36 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:36 --> Input Class Initialized
INFO - 2022-06-17 09:23:36 --> Language Class Initialized
INFO - 2022-06-17 09:23:36 --> Language Class Initialized
INFO - 2022-06-17 09:23:36 --> Config Class Initialized
INFO - 2022-06-17 09:23:36 --> Loader Class Initialized
INFO - 2022-06-17 09:23:36 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:36 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:36 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:36 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:36 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:36 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:23:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:36 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:36 --> Total execution time: 0.0597
INFO - 2022-06-17 09:23:38 --> Config Class Initialized
INFO - 2022-06-17 09:23:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:38 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:38 --> URI Class Initialized
INFO - 2022-06-17 09:23:38 --> Router Class Initialized
INFO - 2022-06-17 09:23:38 --> Output Class Initialized
INFO - 2022-06-17 09:23:38 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:38 --> Input Class Initialized
INFO - 2022-06-17 09:23:38 --> Language Class Initialized
INFO - 2022-06-17 09:23:38 --> Language Class Initialized
INFO - 2022-06-17 09:23:38 --> Config Class Initialized
INFO - 2022-06-17 09:23:38 --> Loader Class Initialized
INFO - 2022-06-17 09:23:38 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:38 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:38 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:38 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:38 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:38 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:38 --> Total execution time: 0.0558
INFO - 2022-06-17 09:23:38 --> Config Class Initialized
INFO - 2022-06-17 09:23:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:38 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:38 --> URI Class Initialized
INFO - 2022-06-17 09:23:38 --> Router Class Initialized
INFO - 2022-06-17 09:23:38 --> Output Class Initialized
INFO - 2022-06-17 09:23:38 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:38 --> Input Class Initialized
INFO - 2022-06-17 09:23:38 --> Language Class Initialized
INFO - 2022-06-17 09:23:38 --> Language Class Initialized
INFO - 2022-06-17 09:23:38 --> Config Class Initialized
INFO - 2022-06-17 09:23:38 --> Loader Class Initialized
INFO - 2022-06-17 09:23:38 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:38 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:38 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:38 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:38 --> Controller Class Initialized
INFO - 2022-06-17 09:23:46 --> Config Class Initialized
INFO - 2022-06-17 09:23:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:46 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:46 --> URI Class Initialized
INFO - 2022-06-17 09:23:46 --> Router Class Initialized
INFO - 2022-06-17 09:23:46 --> Output Class Initialized
INFO - 2022-06-17 09:23:46 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:46 --> Input Class Initialized
INFO - 2022-06-17 09:23:46 --> Language Class Initialized
INFO - 2022-06-17 09:23:46 --> Language Class Initialized
INFO - 2022-06-17 09:23:46 --> Config Class Initialized
INFO - 2022-06-17 09:23:46 --> Loader Class Initialized
INFO - 2022-06-17 09:23:46 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:46 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:46 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:46 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:46 --> Controller Class Initialized
INFO - 2022-06-17 09:23:46 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:46 --> Total execution time: 0.0534
INFO - 2022-06-17 09:23:55 --> Config Class Initialized
INFO - 2022-06-17 09:23:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:55 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:55 --> URI Class Initialized
INFO - 2022-06-17 09:23:55 --> Router Class Initialized
INFO - 2022-06-17 09:23:55 --> Output Class Initialized
INFO - 2022-06-17 09:23:55 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:55 --> Input Class Initialized
INFO - 2022-06-17 09:23:55 --> Language Class Initialized
INFO - 2022-06-17 09:23:55 --> Language Class Initialized
INFO - 2022-06-17 09:23:55 --> Config Class Initialized
INFO - 2022-06-17 09:23:55 --> Loader Class Initialized
INFO - 2022-06-17 09:23:55 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:55 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:55 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:55 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:55 --> Controller Class Initialized
INFO - 2022-06-17 09:23:55 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:55 --> Total execution time: 0.0456
INFO - 2022-06-17 09:23:55 --> Config Class Initialized
INFO - 2022-06-17 09:23:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:55 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:55 --> URI Class Initialized
INFO - 2022-06-17 09:23:55 --> Router Class Initialized
INFO - 2022-06-17 09:23:55 --> Output Class Initialized
INFO - 2022-06-17 09:23:55 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:55 --> Input Class Initialized
INFO - 2022-06-17 09:23:55 --> Language Class Initialized
INFO - 2022-06-17 09:23:55 --> Language Class Initialized
INFO - 2022-06-17 09:23:55 --> Config Class Initialized
INFO - 2022-06-17 09:23:55 --> Loader Class Initialized
INFO - 2022-06-17 09:23:55 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:55 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:55 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:55 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:55 --> Controller Class Initialized
INFO - 2022-06-17 09:23:56 --> Config Class Initialized
INFO - 2022-06-17 09:23:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:56 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:56 --> URI Class Initialized
INFO - 2022-06-17 09:23:56 --> Router Class Initialized
INFO - 2022-06-17 09:23:56 --> Output Class Initialized
INFO - 2022-06-17 09:23:56 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:56 --> Input Class Initialized
INFO - 2022-06-17 09:23:56 --> Language Class Initialized
INFO - 2022-06-17 09:23:56 --> Language Class Initialized
INFO - 2022-06-17 09:23:56 --> Config Class Initialized
INFO - 2022-06-17 09:23:56 --> Loader Class Initialized
INFO - 2022-06-17 09:23:56 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:56 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:56 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:56 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:56 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:56 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:56 --> Total execution time: 0.0438
INFO - 2022-06-17 09:23:59 --> Config Class Initialized
INFO - 2022-06-17 09:23:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:23:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:23:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:23:59 --> URI Class Initialized
INFO - 2022-06-17 09:23:59 --> Router Class Initialized
INFO - 2022-06-17 09:23:59 --> Output Class Initialized
INFO - 2022-06-17 09:23:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:23:59 --> Input Class Initialized
INFO - 2022-06-17 09:23:59 --> Language Class Initialized
INFO - 2022-06-17 09:23:59 --> Language Class Initialized
INFO - 2022-06-17 09:23:59 --> Config Class Initialized
INFO - 2022-06-17 09:23:59 --> Loader Class Initialized
INFO - 2022-06-17 09:23:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:23:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:23:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:23:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:23:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:23:59 --> Controller Class Initialized
DEBUG - 2022-06-17 09:23:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:23:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:23:59 --> Final output sent to browser
DEBUG - 2022-06-17 09:23:59 --> Total execution time: 0.0583
INFO - 2022-06-17 09:24:00 --> Config Class Initialized
INFO - 2022-06-17 09:24:00 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:00 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:00 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:00 --> URI Class Initialized
INFO - 2022-06-17 09:24:00 --> Router Class Initialized
INFO - 2022-06-17 09:24:00 --> Output Class Initialized
INFO - 2022-06-17 09:24:00 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:00 --> Input Class Initialized
INFO - 2022-06-17 09:24:00 --> Language Class Initialized
INFO - 2022-06-17 09:24:00 --> Language Class Initialized
INFO - 2022-06-17 09:24:00 --> Config Class Initialized
INFO - 2022-06-17 09:24:00 --> Loader Class Initialized
INFO - 2022-06-17 09:24:00 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:00 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:00 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:00 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:00 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:00 --> Controller Class Initialized
INFO - 2022-06-17 09:24:00 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:00 --> Total execution time: 0.0496
INFO - 2022-06-17 09:24:08 --> Config Class Initialized
INFO - 2022-06-17 09:24:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:08 --> URI Class Initialized
INFO - 2022-06-17 09:24:08 --> Router Class Initialized
INFO - 2022-06-17 09:24:08 --> Output Class Initialized
INFO - 2022-06-17 09:24:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:08 --> Input Class Initialized
INFO - 2022-06-17 09:24:08 --> Language Class Initialized
INFO - 2022-06-17 09:24:08 --> Language Class Initialized
INFO - 2022-06-17 09:24:08 --> Config Class Initialized
INFO - 2022-06-17 09:24:08 --> Loader Class Initialized
INFO - 2022-06-17 09:24:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:08 --> Controller Class Initialized
INFO - 2022-06-17 09:24:08 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:08 --> Total execution time: 0.0440
INFO - 2022-06-17 09:24:09 --> Config Class Initialized
INFO - 2022-06-17 09:24:09 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:09 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:09 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:09 --> URI Class Initialized
INFO - 2022-06-17 09:24:09 --> Router Class Initialized
INFO - 2022-06-17 09:24:09 --> Output Class Initialized
INFO - 2022-06-17 09:24:09 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:09 --> Input Class Initialized
INFO - 2022-06-17 09:24:09 --> Language Class Initialized
INFO - 2022-06-17 09:24:09 --> Language Class Initialized
INFO - 2022-06-17 09:24:09 --> Config Class Initialized
INFO - 2022-06-17 09:24:09 --> Loader Class Initialized
INFO - 2022-06-17 09:24:09 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:09 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:09 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:09 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:09 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:09 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 09:24:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:09 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:09 --> Total execution time: 0.0534
INFO - 2022-06-17 09:24:13 --> Config Class Initialized
INFO - 2022-06-17 09:24:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:13 --> URI Class Initialized
INFO - 2022-06-17 09:24:13 --> Router Class Initialized
INFO - 2022-06-17 09:24:13 --> Output Class Initialized
INFO - 2022-06-17 09:24:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:13 --> Input Class Initialized
INFO - 2022-06-17 09:24:13 --> Language Class Initialized
INFO - 2022-06-17 09:24:13 --> Language Class Initialized
INFO - 2022-06-17 09:24:13 --> Config Class Initialized
INFO - 2022-06-17 09:24:13 --> Loader Class Initialized
INFO - 2022-06-17 09:24:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:13 --> Controller Class Initialized
INFO - 2022-06-17 09:24:13 --> Config Class Initialized
INFO - 2022-06-17 09:24:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:13 --> URI Class Initialized
INFO - 2022-06-17 09:24:13 --> Router Class Initialized
INFO - 2022-06-17 09:24:13 --> Output Class Initialized
INFO - 2022-06-17 09:24:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:13 --> Input Class Initialized
INFO - 2022-06-17 09:24:13 --> Language Class Initialized
INFO - 2022-06-17 09:24:13 --> Language Class Initialized
INFO - 2022-06-17 09:24:13 --> Config Class Initialized
INFO - 2022-06-17 09:24:13 --> Loader Class Initialized
INFO - 2022-06-17 09:24:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:13 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:24:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:13 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:13 --> Total execution time: 0.0631
INFO - 2022-06-17 09:24:14 --> Config Class Initialized
INFO - 2022-06-17 09:24:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:14 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:14 --> URI Class Initialized
INFO - 2022-06-17 09:24:14 --> Router Class Initialized
INFO - 2022-06-17 09:24:14 --> Output Class Initialized
INFO - 2022-06-17 09:24:14 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:14 --> Input Class Initialized
INFO - 2022-06-17 09:24:14 --> Language Class Initialized
INFO - 2022-06-17 09:24:14 --> Language Class Initialized
INFO - 2022-06-17 09:24:14 --> Config Class Initialized
INFO - 2022-06-17 09:24:14 --> Loader Class Initialized
INFO - 2022-06-17 09:24:14 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:14 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:14 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:14 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:14 --> Controller Class Initialized
INFO - 2022-06-17 09:24:14 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:14 --> Total execution time: 0.0403
INFO - 2022-06-17 09:24:14 --> Config Class Initialized
INFO - 2022-06-17 09:24:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:14 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:14 --> URI Class Initialized
INFO - 2022-06-17 09:24:14 --> Router Class Initialized
INFO - 2022-06-17 09:24:14 --> Output Class Initialized
INFO - 2022-06-17 09:24:14 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:14 --> Input Class Initialized
INFO - 2022-06-17 09:24:14 --> Language Class Initialized
INFO - 2022-06-17 09:24:14 --> Language Class Initialized
INFO - 2022-06-17 09:24:14 --> Config Class Initialized
INFO - 2022-06-17 09:24:14 --> Loader Class Initialized
INFO - 2022-06-17 09:24:14 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:14 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:14 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:14 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:14 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:24:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:15 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:15 --> Total execution time: 0.0495
INFO - 2022-06-17 09:24:15 --> Config Class Initialized
INFO - 2022-06-17 09:24:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:15 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:15 --> URI Class Initialized
INFO - 2022-06-17 09:24:15 --> Router Class Initialized
INFO - 2022-06-17 09:24:15 --> Output Class Initialized
INFO - 2022-06-17 09:24:15 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:15 --> Input Class Initialized
INFO - 2022-06-17 09:24:15 --> Language Class Initialized
INFO - 2022-06-17 09:24:15 --> Language Class Initialized
INFO - 2022-06-17 09:24:15 --> Config Class Initialized
INFO - 2022-06-17 09:24:15 --> Loader Class Initialized
INFO - 2022-06-17 09:24:15 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:15 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:15 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:15 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:15 --> Controller Class Initialized
INFO - 2022-06-17 09:24:15 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:15 --> Total execution time: 0.0514
INFO - 2022-06-17 09:24:16 --> Config Class Initialized
INFO - 2022-06-17 09:24:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:16 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:16 --> URI Class Initialized
INFO - 2022-06-17 09:24:16 --> Router Class Initialized
INFO - 2022-06-17 09:24:16 --> Output Class Initialized
INFO - 2022-06-17 09:24:16 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:16 --> Input Class Initialized
INFO - 2022-06-17 09:24:16 --> Language Class Initialized
INFO - 2022-06-17 09:24:16 --> Language Class Initialized
INFO - 2022-06-17 09:24:16 --> Config Class Initialized
INFO - 2022-06-17 09:24:16 --> Loader Class Initialized
INFO - 2022-06-17 09:24:16 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:16 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:16 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:16 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:16 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:16 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:16 --> Total execution time: 0.0465
INFO - 2022-06-17 09:24:17 --> Config Class Initialized
INFO - 2022-06-17 09:24:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:17 --> URI Class Initialized
INFO - 2022-06-17 09:24:17 --> Router Class Initialized
INFO - 2022-06-17 09:24:17 --> Output Class Initialized
INFO - 2022-06-17 09:24:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:17 --> Input Class Initialized
INFO - 2022-06-17 09:24:17 --> Language Class Initialized
INFO - 2022-06-17 09:24:18 --> Language Class Initialized
INFO - 2022-06-17 09:24:18 --> Config Class Initialized
INFO - 2022-06-17 09:24:18 --> Loader Class Initialized
INFO - 2022-06-17 09:24:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:18 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:24:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:18 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:18 --> Total execution time: 0.0507
INFO - 2022-06-17 09:24:18 --> Config Class Initialized
INFO - 2022-06-17 09:24:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:18 --> URI Class Initialized
INFO - 2022-06-17 09:24:18 --> Router Class Initialized
INFO - 2022-06-17 09:24:18 --> Output Class Initialized
INFO - 2022-06-17 09:24:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:18 --> Input Class Initialized
INFO - 2022-06-17 09:24:18 --> Language Class Initialized
INFO - 2022-06-17 09:24:18 --> Language Class Initialized
INFO - 2022-06-17 09:24:18 --> Config Class Initialized
INFO - 2022-06-17 09:24:18 --> Loader Class Initialized
INFO - 2022-06-17 09:24:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:18 --> Controller Class Initialized
INFO - 2022-06-17 09:24:18 --> Config Class Initialized
INFO - 2022-06-17 09:24:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:18 --> URI Class Initialized
INFO - 2022-06-17 09:24:18 --> Router Class Initialized
INFO - 2022-06-17 09:24:18 --> Output Class Initialized
INFO - 2022-06-17 09:24:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:18 --> Input Class Initialized
INFO - 2022-06-17 09:24:18 --> Language Class Initialized
INFO - 2022-06-17 09:24:18 --> Language Class Initialized
INFO - 2022-06-17 09:24:18 --> Config Class Initialized
INFO - 2022-06-17 09:24:18 --> Loader Class Initialized
INFO - 2022-06-17 09:24:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:18 --> Controller Class Initialized
INFO - 2022-06-17 09:24:18 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:18 --> Total execution time: 0.0522
INFO - 2022-06-17 09:24:21 --> Config Class Initialized
INFO - 2022-06-17 09:24:21 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:21 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:21 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:21 --> URI Class Initialized
INFO - 2022-06-17 09:24:21 --> Router Class Initialized
INFO - 2022-06-17 09:24:21 --> Output Class Initialized
INFO - 2022-06-17 09:24:21 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:21 --> Input Class Initialized
INFO - 2022-06-17 09:24:21 --> Language Class Initialized
INFO - 2022-06-17 09:24:21 --> Language Class Initialized
INFO - 2022-06-17 09:24:21 --> Config Class Initialized
INFO - 2022-06-17 09:24:21 --> Loader Class Initialized
INFO - 2022-06-17 09:24:21 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:21 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:21 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:21 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:21 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:21 --> Controller Class Initialized
INFO - 2022-06-17 09:24:21 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:21 --> Total execution time: 0.0429
INFO - 2022-06-17 09:24:23 --> Config Class Initialized
INFO - 2022-06-17 09:24:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:23 --> URI Class Initialized
INFO - 2022-06-17 09:24:23 --> Router Class Initialized
INFO - 2022-06-17 09:24:23 --> Output Class Initialized
INFO - 2022-06-17 09:24:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:23 --> Input Class Initialized
INFO - 2022-06-17 09:24:23 --> Language Class Initialized
INFO - 2022-06-17 09:24:23 --> Language Class Initialized
INFO - 2022-06-17 09:24:23 --> Config Class Initialized
INFO - 2022-06-17 09:24:23 --> Loader Class Initialized
INFO - 2022-06-17 09:24:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:23 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-17 09:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:23 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:23 --> Total execution time: 0.1081
INFO - 2022-06-17 09:24:23 --> Config Class Initialized
INFO - 2022-06-17 09:24:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:23 --> URI Class Initialized
DEBUG - 2022-06-17 09:24:23 --> No URI present. Default controller set.
INFO - 2022-06-17 09:24:23 --> Router Class Initialized
INFO - 2022-06-17 09:24:23 --> Output Class Initialized
INFO - 2022-06-17 09:24:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:23 --> Input Class Initialized
INFO - 2022-06-17 09:24:23 --> Language Class Initialized
INFO - 2022-06-17 09:24:23 --> Language Class Initialized
INFO - 2022-06-17 09:24:23 --> Config Class Initialized
INFO - 2022-06-17 09:24:23 --> Loader Class Initialized
INFO - 2022-06-17 09:24:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:23 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 09:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:24 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:24 --> Total execution time: 0.1025
INFO - 2022-06-17 09:24:25 --> Config Class Initialized
INFO - 2022-06-17 09:24:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:25 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:25 --> URI Class Initialized
INFO - 2022-06-17 09:24:25 --> Router Class Initialized
INFO - 2022-06-17 09:24:25 --> Output Class Initialized
INFO - 2022-06-17 09:24:25 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:25 --> Input Class Initialized
INFO - 2022-06-17 09:24:25 --> Language Class Initialized
INFO - 2022-06-17 09:24:25 --> Language Class Initialized
INFO - 2022-06-17 09:24:25 --> Config Class Initialized
INFO - 2022-06-17 09:24:25 --> Loader Class Initialized
INFO - 2022-06-17 09:24:25 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:25 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:25 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:25 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:25 --> Controller Class Initialized
INFO - 2022-06-17 09:24:25 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:25 --> Total execution time: 0.0408
INFO - 2022-06-17 09:24:25 --> Config Class Initialized
INFO - 2022-06-17 09:24:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:25 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:25 --> URI Class Initialized
INFO - 2022-06-17 09:24:25 --> Router Class Initialized
INFO - 2022-06-17 09:24:25 --> Output Class Initialized
INFO - 2022-06-17 09:24:25 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:25 --> Input Class Initialized
INFO - 2022-06-17 09:24:25 --> Language Class Initialized
INFO - 2022-06-17 09:24:25 --> Language Class Initialized
INFO - 2022-06-17 09:24:25 --> Config Class Initialized
INFO - 2022-06-17 09:24:25 --> Loader Class Initialized
INFO - 2022-06-17 09:24:25 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:25 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:25 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:25 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:25 --> Controller Class Initialized
INFO - 2022-06-17 09:24:27 --> Config Class Initialized
INFO - 2022-06-17 09:24:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:27 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:27 --> URI Class Initialized
INFO - 2022-06-17 09:24:27 --> Router Class Initialized
INFO - 2022-06-17 09:24:27 --> Output Class Initialized
INFO - 2022-06-17 09:24:27 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:27 --> Input Class Initialized
INFO - 2022-06-17 09:24:27 --> Language Class Initialized
INFO - 2022-06-17 09:24:27 --> Language Class Initialized
INFO - 2022-06-17 09:24:27 --> Config Class Initialized
INFO - 2022-06-17 09:24:27 --> Loader Class Initialized
INFO - 2022-06-17 09:24:27 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:27 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:27 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:27 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:27 --> Controller Class Initialized
INFO - 2022-06-17 09:24:27 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:24:27 --> Config Class Initialized
INFO - 2022-06-17 09:24:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:27 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:27 --> URI Class Initialized
INFO - 2022-06-17 09:24:27 --> Router Class Initialized
INFO - 2022-06-17 09:24:27 --> Output Class Initialized
INFO - 2022-06-17 09:24:27 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:27 --> Input Class Initialized
INFO - 2022-06-17 09:24:27 --> Language Class Initialized
INFO - 2022-06-17 09:24:27 --> Language Class Initialized
INFO - 2022-06-17 09:24:27 --> Config Class Initialized
INFO - 2022-06-17 09:24:27 --> Loader Class Initialized
INFO - 2022-06-17 09:24:27 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:27 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:27 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:27 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:27 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 09:24:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:27 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:27 --> Total execution time: 0.0413
INFO - 2022-06-17 09:24:28 --> Config Class Initialized
INFO - 2022-06-17 09:24:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:28 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:28 --> URI Class Initialized
INFO - 2022-06-17 09:24:28 --> Router Class Initialized
INFO - 2022-06-17 09:24:28 --> Output Class Initialized
INFO - 2022-06-17 09:24:28 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:28 --> Input Class Initialized
INFO - 2022-06-17 09:24:28 --> Language Class Initialized
INFO - 2022-06-17 09:24:28 --> Language Class Initialized
INFO - 2022-06-17 09:24:28 --> Config Class Initialized
INFO - 2022-06-17 09:24:28 --> Loader Class Initialized
INFO - 2022-06-17 09:24:28 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:28 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:28 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:28 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:28 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:28 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:28 --> Total execution time: 0.0494
INFO - 2022-06-17 09:24:30 --> Config Class Initialized
INFO - 2022-06-17 09:24:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:30 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:30 --> URI Class Initialized
INFO - 2022-06-17 09:24:30 --> Router Class Initialized
INFO - 2022-06-17 09:24:30 --> Output Class Initialized
INFO - 2022-06-17 09:24:30 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:30 --> Input Class Initialized
INFO - 2022-06-17 09:24:30 --> Language Class Initialized
INFO - 2022-06-17 09:24:30 --> Language Class Initialized
INFO - 2022-06-17 09:24:30 --> Config Class Initialized
INFO - 2022-06-17 09:24:30 --> Loader Class Initialized
INFO - 2022-06-17 09:24:30 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:30 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:30 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:30 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:30 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:24:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:30 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:30 --> Total execution time: 0.0497
INFO - 2022-06-17 09:24:32 --> Config Class Initialized
INFO - 2022-06-17 09:24:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:32 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:32 --> URI Class Initialized
INFO - 2022-06-17 09:24:32 --> Router Class Initialized
INFO - 2022-06-17 09:24:32 --> Output Class Initialized
INFO - 2022-06-17 09:24:32 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:32 --> Input Class Initialized
INFO - 2022-06-17 09:24:32 --> Language Class Initialized
INFO - 2022-06-17 09:24:32 --> Language Class Initialized
INFO - 2022-06-17 09:24:32 --> Config Class Initialized
INFO - 2022-06-17 09:24:32 --> Loader Class Initialized
INFO - 2022-06-17 09:24:32 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:32 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:32 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:32 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:32 --> Controller Class Initialized
INFO - 2022-06-17 09:24:32 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:32 --> Total execution time: 0.0470
INFO - 2022-06-17 09:24:35 --> Config Class Initialized
INFO - 2022-06-17 09:24:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:35 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:35 --> URI Class Initialized
INFO - 2022-06-17 09:24:35 --> Router Class Initialized
INFO - 2022-06-17 09:24:35 --> Output Class Initialized
INFO - 2022-06-17 09:24:35 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:35 --> Input Class Initialized
INFO - 2022-06-17 09:24:35 --> Language Class Initialized
INFO - 2022-06-17 09:24:35 --> Language Class Initialized
INFO - 2022-06-17 09:24:35 --> Config Class Initialized
INFO - 2022-06-17 09:24:35 --> Loader Class Initialized
INFO - 2022-06-17 09:24:35 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:35 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:35 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:35 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:35 --> Controller Class Initialized
INFO - 2022-06-17 09:24:35 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:24:35 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:35 --> Total execution time: 0.0535
INFO - 2022-06-17 09:24:35 --> Config Class Initialized
INFO - 2022-06-17 09:24:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:35 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:35 --> URI Class Initialized
INFO - 2022-06-17 09:24:35 --> Router Class Initialized
INFO - 2022-06-17 09:24:35 --> Output Class Initialized
INFO - 2022-06-17 09:24:35 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:35 --> Input Class Initialized
INFO - 2022-06-17 09:24:35 --> Language Class Initialized
INFO - 2022-06-17 09:24:35 --> Language Class Initialized
INFO - 2022-06-17 09:24:35 --> Config Class Initialized
INFO - 2022-06-17 09:24:35 --> Loader Class Initialized
INFO - 2022-06-17 09:24:35 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:35 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:35 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:35 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:35 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 09:24:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:35 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:35 --> Total execution time: 0.1037
INFO - 2022-06-17 09:24:37 --> Config Class Initialized
INFO - 2022-06-17 09:24:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:37 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:37 --> URI Class Initialized
INFO - 2022-06-17 09:24:37 --> Router Class Initialized
INFO - 2022-06-17 09:24:37 --> Output Class Initialized
INFO - 2022-06-17 09:24:37 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:37 --> Input Class Initialized
INFO - 2022-06-17 09:24:37 --> Language Class Initialized
INFO - 2022-06-17 09:24:37 --> Language Class Initialized
INFO - 2022-06-17 09:24:37 --> Config Class Initialized
INFO - 2022-06-17 09:24:37 --> Loader Class Initialized
INFO - 2022-06-17 09:24:37 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:37 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-17 09:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:37 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:37 --> Total execution time: 0.0663
INFO - 2022-06-17 09:24:37 --> Config Class Initialized
INFO - 2022-06-17 09:24:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:37 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:37 --> URI Class Initialized
INFO - 2022-06-17 09:24:37 --> Router Class Initialized
INFO - 2022-06-17 09:24:37 --> Output Class Initialized
INFO - 2022-06-17 09:24:37 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:37 --> Input Class Initialized
INFO - 2022-06-17 09:24:37 --> Language Class Initialized
INFO - 2022-06-17 09:24:37 --> Language Class Initialized
INFO - 2022-06-17 09:24:37 --> Config Class Initialized
INFO - 2022-06-17 09:24:37 --> Loader Class Initialized
INFO - 2022-06-17 09:24:37 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:37 --> Controller Class Initialized
INFO - 2022-06-17 09:24:37 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:37 --> Total execution time: 0.0495
INFO - 2022-06-17 09:24:37 --> Config Class Initialized
INFO - 2022-06-17 09:24:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:37 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:37 --> URI Class Initialized
INFO - 2022-06-17 09:24:37 --> Router Class Initialized
INFO - 2022-06-17 09:24:37 --> Output Class Initialized
INFO - 2022-06-17 09:24:37 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:37 --> Input Class Initialized
INFO - 2022-06-17 09:24:37 --> Language Class Initialized
INFO - 2022-06-17 09:24:37 --> Language Class Initialized
INFO - 2022-06-17 09:24:37 --> Config Class Initialized
INFO - 2022-06-17 09:24:37 --> Loader Class Initialized
INFO - 2022-06-17 09:24:37 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:37 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:37 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:37 --> Total execution time: 0.0516
INFO - 2022-06-17 09:24:37 --> Config Class Initialized
INFO - 2022-06-17 09:24:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:37 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:37 --> URI Class Initialized
INFO - 2022-06-17 09:24:37 --> Router Class Initialized
INFO - 2022-06-17 09:24:37 --> Output Class Initialized
INFO - 2022-06-17 09:24:37 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:37 --> Input Class Initialized
INFO - 2022-06-17 09:24:37 --> Language Class Initialized
INFO - 2022-06-17 09:24:37 --> Language Class Initialized
INFO - 2022-06-17 09:24:37 --> Config Class Initialized
INFO - 2022-06-17 09:24:37 --> Loader Class Initialized
INFO - 2022-06-17 09:24:37 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:37 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:38 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-06-17 09:24:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:38 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:38 --> Total execution time: 0.0843
INFO - 2022-06-17 09:24:39 --> Config Class Initialized
INFO - 2022-06-17 09:24:39 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:39 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:39 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:39 --> URI Class Initialized
INFO - 2022-06-17 09:24:39 --> Router Class Initialized
INFO - 2022-06-17 09:24:39 --> Output Class Initialized
INFO - 2022-06-17 09:24:39 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:39 --> Input Class Initialized
INFO - 2022-06-17 09:24:39 --> Language Class Initialized
INFO - 2022-06-17 09:24:39 --> Language Class Initialized
INFO - 2022-06-17 09:24:39 --> Config Class Initialized
INFO - 2022-06-17 09:24:39 --> Loader Class Initialized
INFO - 2022-06-17 09:24:39 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:39 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:39 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:39 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:39 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:39 --> Controller Class Initialized
INFO - 2022-06-17 09:24:39 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:39 --> Total execution time: 0.0390
INFO - 2022-06-17 09:24:40 --> Config Class Initialized
INFO - 2022-06-17 09:24:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:40 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:40 --> URI Class Initialized
INFO - 2022-06-17 09:24:40 --> Router Class Initialized
INFO - 2022-06-17 09:24:40 --> Output Class Initialized
INFO - 2022-06-17 09:24:40 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:40 --> Input Class Initialized
INFO - 2022-06-17 09:24:40 --> Language Class Initialized
INFO - 2022-06-17 09:24:40 --> Language Class Initialized
INFO - 2022-06-17 09:24:40 --> Config Class Initialized
INFO - 2022-06-17 09:24:40 --> Loader Class Initialized
INFO - 2022-06-17 09:24:40 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:40 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:40 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:40 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:40 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2022-06-17 09:24:40 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:40 --> Total execution time: 0.0902
INFO - 2022-06-17 09:24:48 --> Config Class Initialized
INFO - 2022-06-17 09:24:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:48 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:48 --> URI Class Initialized
INFO - 2022-06-17 09:24:48 --> Router Class Initialized
INFO - 2022-06-17 09:24:48 --> Output Class Initialized
INFO - 2022-06-17 09:24:48 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:48 --> Input Class Initialized
INFO - 2022-06-17 09:24:48 --> Language Class Initialized
INFO - 2022-06-17 09:24:48 --> Language Class Initialized
INFO - 2022-06-17 09:24:48 --> Config Class Initialized
INFO - 2022-06-17 09:24:48 --> Loader Class Initialized
INFO - 2022-06-17 09:24:48 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:48 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:48 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:48 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:48 --> Controller Class Initialized
INFO - 2022-06-17 09:24:48 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:48 --> Total execution time: 0.0498
INFO - 2022-06-17 09:24:48 --> Config Class Initialized
INFO - 2022-06-17 09:24:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:48 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:48 --> URI Class Initialized
INFO - 2022-06-17 09:24:48 --> Router Class Initialized
INFO - 2022-06-17 09:24:48 --> Output Class Initialized
INFO - 2022-06-17 09:24:48 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:48 --> Input Class Initialized
INFO - 2022-06-17 09:24:48 --> Language Class Initialized
INFO - 2022-06-17 09:24:48 --> Language Class Initialized
INFO - 2022-06-17 09:24:48 --> Config Class Initialized
INFO - 2022-06-17 09:24:48 --> Loader Class Initialized
INFO - 2022-06-17 09:24:48 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:48 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:48 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:48 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:48 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:48 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:48 --> Total execution time: 0.0507
INFO - 2022-06-17 09:24:51 --> Config Class Initialized
INFO - 2022-06-17 09:24:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:24:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:24:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:24:51 --> URI Class Initialized
INFO - 2022-06-17 09:24:51 --> Router Class Initialized
INFO - 2022-06-17 09:24:51 --> Output Class Initialized
INFO - 2022-06-17 09:24:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:24:51 --> Input Class Initialized
INFO - 2022-06-17 09:24:51 --> Language Class Initialized
INFO - 2022-06-17 09:24:51 --> Language Class Initialized
INFO - 2022-06-17 09:24:51 --> Config Class Initialized
INFO - 2022-06-17 09:24:51 --> Loader Class Initialized
INFO - 2022-06-17 09:24:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:24:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:24:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:24:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:24:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:24:51 --> Controller Class Initialized
DEBUG - 2022-06-17 09:24:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-17 09:24:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:24:51 --> Final output sent to browser
DEBUG - 2022-06-17 09:24:51 --> Total execution time: 0.0978
INFO - 2022-06-17 09:27:57 --> Config Class Initialized
INFO - 2022-06-17 09:27:57 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:27:57 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:27:57 --> Utf8 Class Initialized
INFO - 2022-06-17 09:27:57 --> URI Class Initialized
INFO - 2022-06-17 09:27:57 --> Router Class Initialized
INFO - 2022-06-17 09:27:57 --> Output Class Initialized
INFO - 2022-06-17 09:27:57 --> Security Class Initialized
DEBUG - 2022-06-17 09:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:27:57 --> Input Class Initialized
INFO - 2022-06-17 09:27:57 --> Language Class Initialized
INFO - 2022-06-17 09:27:57 --> Language Class Initialized
INFO - 2022-06-17 09:27:57 --> Config Class Initialized
INFO - 2022-06-17 09:27:57 --> Loader Class Initialized
INFO - 2022-06-17 09:27:57 --> Helper loaded: url_helper
INFO - 2022-06-17 09:27:57 --> Helper loaded: file_helper
INFO - 2022-06-17 09:27:57 --> Helper loaded: form_helper
INFO - 2022-06-17 09:27:57 --> Helper loaded: my_helper
INFO - 2022-06-17 09:27:57 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:27:57 --> Controller Class Initialized
INFO - 2022-06-17 09:27:57 --> Final output sent to browser
DEBUG - 2022-06-17 09:27:57 --> Total execution time: 0.1098
INFO - 2022-06-17 09:28:14 --> Config Class Initialized
INFO - 2022-06-17 09:28:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:28:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:28:14 --> Utf8 Class Initialized
INFO - 2022-06-17 09:28:14 --> URI Class Initialized
INFO - 2022-06-17 09:28:14 --> Router Class Initialized
INFO - 2022-06-17 09:28:14 --> Output Class Initialized
INFO - 2022-06-17 09:28:14 --> Security Class Initialized
DEBUG - 2022-06-17 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:28:14 --> Input Class Initialized
INFO - 2022-06-17 09:28:14 --> Language Class Initialized
INFO - 2022-06-17 09:28:14 --> Language Class Initialized
INFO - 2022-06-17 09:28:14 --> Config Class Initialized
INFO - 2022-06-17 09:28:14 --> Loader Class Initialized
INFO - 2022-06-17 09:28:14 --> Helper loaded: url_helper
INFO - 2022-06-17 09:28:14 --> Helper loaded: file_helper
INFO - 2022-06-17 09:28:14 --> Helper loaded: form_helper
INFO - 2022-06-17 09:28:14 --> Helper loaded: my_helper
INFO - 2022-06-17 09:28:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:28:14 --> Controller Class Initialized
INFO - 2022-06-17 09:28:14 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:28:14 --> Config Class Initialized
INFO - 2022-06-17 09:28:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:28:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:28:14 --> Utf8 Class Initialized
INFO - 2022-06-17 09:28:14 --> URI Class Initialized
INFO - 2022-06-17 09:28:14 --> Router Class Initialized
INFO - 2022-06-17 09:28:14 --> Output Class Initialized
INFO - 2022-06-17 09:28:14 --> Security Class Initialized
DEBUG - 2022-06-17 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:28:14 --> Input Class Initialized
INFO - 2022-06-17 09:28:14 --> Language Class Initialized
INFO - 2022-06-17 09:28:14 --> Language Class Initialized
INFO - 2022-06-17 09:28:14 --> Config Class Initialized
INFO - 2022-06-17 09:28:14 --> Loader Class Initialized
INFO - 2022-06-17 09:28:14 --> Helper loaded: url_helper
INFO - 2022-06-17 09:28:14 --> Helper loaded: file_helper
INFO - 2022-06-17 09:28:14 --> Helper loaded: form_helper
INFO - 2022-06-17 09:28:14 --> Helper loaded: my_helper
INFO - 2022-06-17 09:28:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:28:14 --> Controller Class Initialized
DEBUG - 2022-06-17 09:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 09:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:28:14 --> Final output sent to browser
DEBUG - 2022-06-17 09:28:14 --> Total execution time: 0.0476
INFO - 2022-06-17 09:30:15 --> Config Class Initialized
INFO - 2022-06-17 09:30:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:30:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:30:15 --> Utf8 Class Initialized
INFO - 2022-06-17 09:30:15 --> URI Class Initialized
DEBUG - 2022-06-17 09:30:15 --> No URI present. Default controller set.
INFO - 2022-06-17 09:30:15 --> Router Class Initialized
INFO - 2022-06-17 09:30:15 --> Output Class Initialized
INFO - 2022-06-17 09:30:15 --> Security Class Initialized
DEBUG - 2022-06-17 09:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:30:15 --> Input Class Initialized
INFO - 2022-06-17 09:30:15 --> Language Class Initialized
INFO - 2022-06-17 09:30:15 --> Language Class Initialized
INFO - 2022-06-17 09:30:15 --> Config Class Initialized
INFO - 2022-06-17 09:30:15 --> Loader Class Initialized
INFO - 2022-06-17 09:30:15 --> Helper loaded: url_helper
INFO - 2022-06-17 09:30:15 --> Helper loaded: file_helper
INFO - 2022-06-17 09:30:15 --> Helper loaded: form_helper
INFO - 2022-06-17 09:30:15 --> Helper loaded: my_helper
INFO - 2022-06-17 09:30:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:30:15 --> Controller Class Initialized
INFO - 2022-06-17 09:30:15 --> Config Class Initialized
INFO - 2022-06-17 09:30:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:30:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:30:15 --> Utf8 Class Initialized
INFO - 2022-06-17 09:30:15 --> URI Class Initialized
INFO - 2022-06-17 09:30:15 --> Router Class Initialized
INFO - 2022-06-17 09:30:15 --> Output Class Initialized
INFO - 2022-06-17 09:30:15 --> Security Class Initialized
DEBUG - 2022-06-17 09:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:30:15 --> Input Class Initialized
INFO - 2022-06-17 09:30:15 --> Language Class Initialized
INFO - 2022-06-17 09:30:15 --> Language Class Initialized
INFO - 2022-06-17 09:30:15 --> Config Class Initialized
INFO - 2022-06-17 09:30:15 --> Loader Class Initialized
INFO - 2022-06-17 09:30:15 --> Helper loaded: url_helper
INFO - 2022-06-17 09:30:15 --> Helper loaded: file_helper
INFO - 2022-06-17 09:30:15 --> Helper loaded: form_helper
INFO - 2022-06-17 09:30:15 --> Helper loaded: my_helper
INFO - 2022-06-17 09:30:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:30:16 --> Controller Class Initialized
DEBUG - 2022-06-17 09:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 09:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:30:16 --> Final output sent to browser
DEBUG - 2022-06-17 09:30:16 --> Total execution time: 0.0490
INFO - 2022-06-17 09:30:18 --> Config Class Initialized
INFO - 2022-06-17 09:30:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:30:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:30:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:30:18 --> URI Class Initialized
DEBUG - 2022-06-17 09:30:18 --> No URI present. Default controller set.
INFO - 2022-06-17 09:30:18 --> Router Class Initialized
INFO - 2022-06-17 09:30:18 --> Output Class Initialized
INFO - 2022-06-17 09:30:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:30:18 --> Input Class Initialized
INFO - 2022-06-17 09:30:18 --> Language Class Initialized
INFO - 2022-06-17 09:30:18 --> Language Class Initialized
INFO - 2022-06-17 09:30:18 --> Config Class Initialized
INFO - 2022-06-17 09:30:18 --> Loader Class Initialized
INFO - 2022-06-17 09:30:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:30:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:30:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:30:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:30:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:30:18 --> Controller Class Initialized
INFO - 2022-06-17 09:30:18 --> Config Class Initialized
INFO - 2022-06-17 09:30:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:30:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:30:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:30:18 --> URI Class Initialized
INFO - 2022-06-17 09:30:18 --> Router Class Initialized
INFO - 2022-06-17 09:30:18 --> Output Class Initialized
INFO - 2022-06-17 09:30:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:30:18 --> Input Class Initialized
INFO - 2022-06-17 09:30:18 --> Language Class Initialized
INFO - 2022-06-17 09:30:18 --> Language Class Initialized
INFO - 2022-06-17 09:30:18 --> Config Class Initialized
INFO - 2022-06-17 09:30:18 --> Loader Class Initialized
INFO - 2022-06-17 09:30:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:30:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:30:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:30:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:30:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:30:18 --> Controller Class Initialized
DEBUG - 2022-06-17 09:30:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 09:30:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:30:18 --> Final output sent to browser
DEBUG - 2022-06-17 09:30:18 --> Total execution time: 0.0513
INFO - 2022-06-17 09:30:28 --> Config Class Initialized
INFO - 2022-06-17 09:30:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:30:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:30:28 --> Utf8 Class Initialized
INFO - 2022-06-17 09:30:28 --> URI Class Initialized
INFO - 2022-06-17 09:30:28 --> Router Class Initialized
INFO - 2022-06-17 09:30:28 --> Output Class Initialized
INFO - 2022-06-17 09:30:28 --> Security Class Initialized
DEBUG - 2022-06-17 09:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:30:28 --> Input Class Initialized
INFO - 2022-06-17 09:30:28 --> Language Class Initialized
INFO - 2022-06-17 09:30:28 --> Language Class Initialized
INFO - 2022-06-17 09:30:28 --> Config Class Initialized
INFO - 2022-06-17 09:30:28 --> Loader Class Initialized
INFO - 2022-06-17 09:30:28 --> Helper loaded: url_helper
INFO - 2022-06-17 09:30:28 --> Helper loaded: file_helper
INFO - 2022-06-17 09:30:28 --> Helper loaded: form_helper
INFO - 2022-06-17 09:30:28 --> Helper loaded: my_helper
INFO - 2022-06-17 09:30:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:30:28 --> Controller Class Initialized
INFO - 2022-06-17 09:30:28 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:30:28 --> Final output sent to browser
DEBUG - 2022-06-17 09:30:28 --> Total execution time: 0.0486
INFO - 2022-06-17 09:30:37 --> Config Class Initialized
INFO - 2022-06-17 09:30:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:30:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:30:37 --> Utf8 Class Initialized
INFO - 2022-06-17 09:30:37 --> URI Class Initialized
INFO - 2022-06-17 09:30:37 --> Router Class Initialized
INFO - 2022-06-17 09:30:37 --> Output Class Initialized
INFO - 2022-06-17 09:30:37 --> Security Class Initialized
DEBUG - 2022-06-17 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:30:37 --> Input Class Initialized
INFO - 2022-06-17 09:30:37 --> Language Class Initialized
INFO - 2022-06-17 09:30:37 --> Language Class Initialized
INFO - 2022-06-17 09:30:37 --> Config Class Initialized
INFO - 2022-06-17 09:30:37 --> Loader Class Initialized
INFO - 2022-06-17 09:30:37 --> Helper loaded: url_helper
INFO - 2022-06-17 09:30:37 --> Helper loaded: file_helper
INFO - 2022-06-17 09:30:37 --> Helper loaded: form_helper
INFO - 2022-06-17 09:30:37 --> Helper loaded: my_helper
INFO - 2022-06-17 09:30:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:30:37 --> Controller Class Initialized
DEBUG - 2022-06-17 09:30:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 09:30:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:30:37 --> Final output sent to browser
DEBUG - 2022-06-17 09:30:37 --> Total execution time: 0.0988
INFO - 2022-06-17 09:31:40 --> Config Class Initialized
INFO - 2022-06-17 09:31:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:31:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:31:40 --> Utf8 Class Initialized
INFO - 2022-06-17 09:31:40 --> URI Class Initialized
INFO - 2022-06-17 09:31:40 --> Router Class Initialized
INFO - 2022-06-17 09:31:40 --> Output Class Initialized
INFO - 2022-06-17 09:31:40 --> Security Class Initialized
DEBUG - 2022-06-17 09:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:31:40 --> Input Class Initialized
INFO - 2022-06-17 09:31:40 --> Language Class Initialized
INFO - 2022-06-17 09:31:40 --> Language Class Initialized
INFO - 2022-06-17 09:31:40 --> Config Class Initialized
INFO - 2022-06-17 09:31:40 --> Loader Class Initialized
INFO - 2022-06-17 09:31:40 --> Helper loaded: url_helper
INFO - 2022-06-17 09:31:40 --> Helper loaded: file_helper
INFO - 2022-06-17 09:31:40 --> Helper loaded: form_helper
INFO - 2022-06-17 09:31:40 --> Helper loaded: my_helper
INFO - 2022-06-17 09:31:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:31:40 --> Controller Class Initialized
DEBUG - 2022-06-17 09:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-17 09:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:31:40 --> Final output sent to browser
DEBUG - 2022-06-17 09:31:40 --> Total execution time: 0.0546
INFO - 2022-06-17 09:35:03 --> Config Class Initialized
INFO - 2022-06-17 09:35:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:35:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:35:03 --> Utf8 Class Initialized
INFO - 2022-06-17 09:35:03 --> URI Class Initialized
INFO - 2022-06-17 09:35:03 --> Router Class Initialized
INFO - 2022-06-17 09:35:03 --> Output Class Initialized
INFO - 2022-06-17 09:35:03 --> Security Class Initialized
DEBUG - 2022-06-17 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:35:03 --> Input Class Initialized
INFO - 2022-06-17 09:35:03 --> Language Class Initialized
INFO - 2022-06-17 09:35:03 --> Language Class Initialized
INFO - 2022-06-17 09:35:03 --> Config Class Initialized
INFO - 2022-06-17 09:35:03 --> Loader Class Initialized
INFO - 2022-06-17 09:35:03 --> Helper loaded: url_helper
INFO - 2022-06-17 09:35:03 --> Helper loaded: file_helper
INFO - 2022-06-17 09:35:03 --> Helper loaded: form_helper
INFO - 2022-06-17 09:35:03 --> Helper loaded: my_helper
INFO - 2022-06-17 09:35:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:35:03 --> Controller Class Initialized
INFO - 2022-06-17 09:35:03 --> Final output sent to browser
DEBUG - 2022-06-17 09:35:03 --> Total execution time: 0.1155
INFO - 2022-06-17 09:38:53 --> Config Class Initialized
INFO - 2022-06-17 09:38:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:38:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:38:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:38:53 --> URI Class Initialized
INFO - 2022-06-17 09:38:53 --> Router Class Initialized
INFO - 2022-06-17 09:38:53 --> Output Class Initialized
INFO - 2022-06-17 09:38:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:38:53 --> Input Class Initialized
INFO - 2022-06-17 09:38:53 --> Language Class Initialized
INFO - 2022-06-17 09:38:53 --> Language Class Initialized
INFO - 2022-06-17 09:38:53 --> Config Class Initialized
INFO - 2022-06-17 09:38:53 --> Loader Class Initialized
INFO - 2022-06-17 09:38:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:38:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:38:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:38:53 --> Helper loaded: my_helper
INFO - 2022-06-17 09:38:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:38:53 --> Controller Class Initialized
INFO - 2022-06-17 09:38:53 --> Final output sent to browser
DEBUG - 2022-06-17 09:38:53 --> Total execution time: 0.1073
INFO - 2022-06-17 09:39:41 --> Config Class Initialized
INFO - 2022-06-17 09:39:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:39:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:39:41 --> Utf8 Class Initialized
INFO - 2022-06-17 09:39:41 --> URI Class Initialized
INFO - 2022-06-17 09:39:41 --> Router Class Initialized
INFO - 2022-06-17 09:39:41 --> Output Class Initialized
INFO - 2022-06-17 09:39:41 --> Security Class Initialized
DEBUG - 2022-06-17 09:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:39:41 --> Input Class Initialized
INFO - 2022-06-17 09:39:41 --> Language Class Initialized
INFO - 2022-06-17 09:39:41 --> Language Class Initialized
INFO - 2022-06-17 09:39:41 --> Config Class Initialized
INFO - 2022-06-17 09:39:41 --> Loader Class Initialized
INFO - 2022-06-17 09:39:41 --> Helper loaded: url_helper
INFO - 2022-06-17 09:39:41 --> Helper loaded: file_helper
INFO - 2022-06-17 09:39:41 --> Helper loaded: form_helper
INFO - 2022-06-17 09:39:41 --> Helper loaded: my_helper
INFO - 2022-06-17 09:39:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:39:41 --> Controller Class Initialized
INFO - 2022-06-17 09:39:41 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:39:41 --> Config Class Initialized
INFO - 2022-06-17 09:39:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:39:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:39:41 --> Utf8 Class Initialized
INFO - 2022-06-17 09:39:41 --> URI Class Initialized
INFO - 2022-06-17 09:39:41 --> Router Class Initialized
INFO - 2022-06-17 09:39:41 --> Output Class Initialized
INFO - 2022-06-17 09:39:41 --> Security Class Initialized
DEBUG - 2022-06-17 09:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:39:41 --> Input Class Initialized
INFO - 2022-06-17 09:39:41 --> Language Class Initialized
INFO - 2022-06-17 09:39:41 --> Language Class Initialized
INFO - 2022-06-17 09:39:41 --> Config Class Initialized
INFO - 2022-06-17 09:39:41 --> Loader Class Initialized
INFO - 2022-06-17 09:39:41 --> Helper loaded: url_helper
INFO - 2022-06-17 09:39:41 --> Helper loaded: file_helper
INFO - 2022-06-17 09:39:41 --> Helper loaded: form_helper
INFO - 2022-06-17 09:39:41 --> Helper loaded: my_helper
INFO - 2022-06-17 09:39:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:39:41 --> Controller Class Initialized
DEBUG - 2022-06-17 09:39:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 09:39:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:39:41 --> Final output sent to browser
DEBUG - 2022-06-17 09:39:41 --> Total execution time: 0.0396
INFO - 2022-06-17 09:39:49 --> Config Class Initialized
INFO - 2022-06-17 09:39:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:39:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:39:49 --> Utf8 Class Initialized
INFO - 2022-06-17 09:39:49 --> URI Class Initialized
INFO - 2022-06-17 09:39:49 --> Router Class Initialized
INFO - 2022-06-17 09:39:49 --> Output Class Initialized
INFO - 2022-06-17 09:39:49 --> Security Class Initialized
DEBUG - 2022-06-17 09:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:39:49 --> Input Class Initialized
INFO - 2022-06-17 09:39:49 --> Language Class Initialized
INFO - 2022-06-17 09:39:49 --> Language Class Initialized
INFO - 2022-06-17 09:39:49 --> Config Class Initialized
INFO - 2022-06-17 09:39:49 --> Loader Class Initialized
INFO - 2022-06-17 09:39:49 --> Helper loaded: url_helper
INFO - 2022-06-17 09:39:49 --> Helper loaded: file_helper
INFO - 2022-06-17 09:39:49 --> Helper loaded: form_helper
INFO - 2022-06-17 09:39:49 --> Helper loaded: my_helper
INFO - 2022-06-17 09:39:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:39:49 --> Controller Class Initialized
INFO - 2022-06-17 09:39:49 --> Helper loaded: cookie_helper
INFO - 2022-06-17 09:39:49 --> Final output sent to browser
DEBUG - 2022-06-17 09:39:49 --> Total execution time: 0.0473
INFO - 2022-06-17 09:39:49 --> Config Class Initialized
INFO - 2022-06-17 09:39:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:39:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:39:49 --> Utf8 Class Initialized
INFO - 2022-06-17 09:39:49 --> URI Class Initialized
INFO - 2022-06-17 09:39:49 --> Router Class Initialized
INFO - 2022-06-17 09:39:49 --> Output Class Initialized
INFO - 2022-06-17 09:39:49 --> Security Class Initialized
DEBUG - 2022-06-17 09:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:39:49 --> Input Class Initialized
INFO - 2022-06-17 09:39:49 --> Language Class Initialized
INFO - 2022-06-17 09:39:49 --> Language Class Initialized
INFO - 2022-06-17 09:39:49 --> Config Class Initialized
INFO - 2022-06-17 09:39:49 --> Loader Class Initialized
INFO - 2022-06-17 09:39:49 --> Helper loaded: url_helper
INFO - 2022-06-17 09:39:49 --> Helper loaded: file_helper
INFO - 2022-06-17 09:39:49 --> Helper loaded: form_helper
INFO - 2022-06-17 09:39:49 --> Helper loaded: my_helper
INFO - 2022-06-17 09:39:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:39:49 --> Controller Class Initialized
DEBUG - 2022-06-17 09:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 09:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:39:49 --> Final output sent to browser
DEBUG - 2022-06-17 09:39:49 --> Total execution time: 0.1008
INFO - 2022-06-17 09:39:52 --> Config Class Initialized
INFO - 2022-06-17 09:39:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:39:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:39:52 --> Utf8 Class Initialized
INFO - 2022-06-17 09:39:52 --> URI Class Initialized
INFO - 2022-06-17 09:39:52 --> Router Class Initialized
INFO - 2022-06-17 09:39:52 --> Output Class Initialized
INFO - 2022-06-17 09:39:52 --> Security Class Initialized
DEBUG - 2022-06-17 09:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:39:52 --> Input Class Initialized
INFO - 2022-06-17 09:39:52 --> Language Class Initialized
INFO - 2022-06-17 09:39:52 --> Language Class Initialized
INFO - 2022-06-17 09:39:52 --> Config Class Initialized
INFO - 2022-06-17 09:39:52 --> Loader Class Initialized
INFO - 2022-06-17 09:39:52 --> Helper loaded: url_helper
INFO - 2022-06-17 09:39:52 --> Helper loaded: file_helper
INFO - 2022-06-17 09:39:52 --> Helper loaded: form_helper
INFO - 2022-06-17 09:39:52 --> Helper loaded: my_helper
INFO - 2022-06-17 09:39:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:39:52 --> Controller Class Initialized
DEBUG - 2022-06-17 09:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 09:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:39:52 --> Final output sent to browser
DEBUG - 2022-06-17 09:39:52 --> Total execution time: 0.0545
INFO - 2022-06-17 09:40:07 --> Config Class Initialized
INFO - 2022-06-17 09:40:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:07 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:07 --> URI Class Initialized
INFO - 2022-06-17 09:40:07 --> Router Class Initialized
INFO - 2022-06-17 09:40:07 --> Output Class Initialized
INFO - 2022-06-17 09:40:07 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:07 --> Input Class Initialized
INFO - 2022-06-17 09:40:07 --> Language Class Initialized
INFO - 2022-06-17 09:40:08 --> Language Class Initialized
INFO - 2022-06-17 09:40:08 --> Config Class Initialized
INFO - 2022-06-17 09:40:08 --> Loader Class Initialized
INFO - 2022-06-17 09:40:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:08 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:08 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:08 --> Total execution time: 0.0506
INFO - 2022-06-17 09:40:08 --> Config Class Initialized
INFO - 2022-06-17 09:40:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:08 --> URI Class Initialized
INFO - 2022-06-17 09:40:08 --> Router Class Initialized
INFO - 2022-06-17 09:40:08 --> Output Class Initialized
INFO - 2022-06-17 09:40:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:08 --> Input Class Initialized
INFO - 2022-06-17 09:40:08 --> Language Class Initialized
INFO - 2022-06-17 09:40:08 --> Language Class Initialized
INFO - 2022-06-17 09:40:08 --> Config Class Initialized
INFO - 2022-06-17 09:40:08 --> Loader Class Initialized
INFO - 2022-06-17 09:40:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:08 --> Controller Class Initialized
INFO - 2022-06-17 09:40:09 --> Config Class Initialized
INFO - 2022-06-17 09:40:09 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:09 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:09 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:09 --> URI Class Initialized
INFO - 2022-06-17 09:40:09 --> Router Class Initialized
INFO - 2022-06-17 09:40:09 --> Output Class Initialized
INFO - 2022-06-17 09:40:09 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:09 --> Input Class Initialized
INFO - 2022-06-17 09:40:09 --> Language Class Initialized
INFO - 2022-06-17 09:40:09 --> Language Class Initialized
INFO - 2022-06-17 09:40:09 --> Config Class Initialized
INFO - 2022-06-17 09:40:09 --> Loader Class Initialized
INFO - 2022-06-17 09:40:09 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:09 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:09 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:09 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:09 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:09 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:09 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:09 --> Total execution time: 0.0446
INFO - 2022-06-17 09:40:12 --> Config Class Initialized
INFO - 2022-06-17 09:40:12 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:12 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:12 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:12 --> URI Class Initialized
INFO - 2022-06-17 09:40:12 --> Router Class Initialized
INFO - 2022-06-17 09:40:12 --> Output Class Initialized
INFO - 2022-06-17 09:40:12 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:12 --> Input Class Initialized
INFO - 2022-06-17 09:40:12 --> Language Class Initialized
INFO - 2022-06-17 09:40:12 --> Language Class Initialized
INFO - 2022-06-17 09:40:12 --> Config Class Initialized
INFO - 2022-06-17 09:40:12 --> Loader Class Initialized
INFO - 2022-06-17 09:40:12 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:12 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:12 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:12 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:12 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:12 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:12 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:12 --> Total execution time: 0.0455
INFO - 2022-06-17 09:40:12 --> Config Class Initialized
INFO - 2022-06-17 09:40:12 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:12 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:12 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:12 --> URI Class Initialized
INFO - 2022-06-17 09:40:12 --> Router Class Initialized
INFO - 2022-06-17 09:40:12 --> Output Class Initialized
INFO - 2022-06-17 09:40:12 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:12 --> Input Class Initialized
INFO - 2022-06-17 09:40:12 --> Language Class Initialized
INFO - 2022-06-17 09:40:12 --> Language Class Initialized
INFO - 2022-06-17 09:40:12 --> Config Class Initialized
INFO - 2022-06-17 09:40:12 --> Loader Class Initialized
INFO - 2022-06-17 09:40:12 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:12 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:12 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:12 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:12 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:12 --> Controller Class Initialized
INFO - 2022-06-17 09:40:13 --> Config Class Initialized
INFO - 2022-06-17 09:40:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:13 --> URI Class Initialized
INFO - 2022-06-17 09:40:13 --> Router Class Initialized
INFO - 2022-06-17 09:40:13 --> Output Class Initialized
INFO - 2022-06-17 09:40:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:13 --> Input Class Initialized
INFO - 2022-06-17 09:40:13 --> Language Class Initialized
INFO - 2022-06-17 09:40:13 --> Language Class Initialized
INFO - 2022-06-17 09:40:13 --> Config Class Initialized
INFO - 2022-06-17 09:40:13 --> Loader Class Initialized
INFO - 2022-06-17 09:40:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:13 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:13 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:13 --> Total execution time: 0.0452
INFO - 2022-06-17 09:40:15 --> Config Class Initialized
INFO - 2022-06-17 09:40:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:15 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:15 --> URI Class Initialized
INFO - 2022-06-17 09:40:15 --> Router Class Initialized
INFO - 2022-06-17 09:40:15 --> Output Class Initialized
INFO - 2022-06-17 09:40:15 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:15 --> Input Class Initialized
INFO - 2022-06-17 09:40:15 --> Language Class Initialized
INFO - 2022-06-17 09:40:15 --> Language Class Initialized
INFO - 2022-06-17 09:40:15 --> Config Class Initialized
INFO - 2022-06-17 09:40:15 --> Loader Class Initialized
INFO - 2022-06-17 09:40:15 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:15 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:15 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:15 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:15 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:15 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:15 --> Total execution time: 0.0460
INFO - 2022-06-17 09:40:15 --> Config Class Initialized
INFO - 2022-06-17 09:40:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:15 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:15 --> URI Class Initialized
INFO - 2022-06-17 09:40:15 --> Router Class Initialized
INFO - 2022-06-17 09:40:15 --> Output Class Initialized
INFO - 2022-06-17 09:40:15 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:15 --> Input Class Initialized
INFO - 2022-06-17 09:40:15 --> Language Class Initialized
INFO - 2022-06-17 09:40:15 --> Language Class Initialized
INFO - 2022-06-17 09:40:15 --> Config Class Initialized
INFO - 2022-06-17 09:40:15 --> Loader Class Initialized
INFO - 2022-06-17 09:40:15 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:15 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:15 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:15 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:15 --> Controller Class Initialized
INFO - 2022-06-17 09:40:16 --> Config Class Initialized
INFO - 2022-06-17 09:40:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:16 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:16 --> URI Class Initialized
INFO - 2022-06-17 09:40:16 --> Router Class Initialized
INFO - 2022-06-17 09:40:16 --> Output Class Initialized
INFO - 2022-06-17 09:40:16 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:16 --> Input Class Initialized
INFO - 2022-06-17 09:40:16 --> Language Class Initialized
INFO - 2022-06-17 09:40:16 --> Language Class Initialized
INFO - 2022-06-17 09:40:16 --> Config Class Initialized
INFO - 2022-06-17 09:40:16 --> Loader Class Initialized
INFO - 2022-06-17 09:40:16 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:16 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:16 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:16 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:16 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:16 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:16 --> Total execution time: 0.0434
INFO - 2022-06-17 09:40:18 --> Config Class Initialized
INFO - 2022-06-17 09:40:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:18 --> URI Class Initialized
INFO - 2022-06-17 09:40:18 --> Router Class Initialized
INFO - 2022-06-17 09:40:18 --> Output Class Initialized
INFO - 2022-06-17 09:40:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:18 --> Input Class Initialized
INFO - 2022-06-17 09:40:18 --> Language Class Initialized
INFO - 2022-06-17 09:40:18 --> Language Class Initialized
INFO - 2022-06-17 09:40:18 --> Config Class Initialized
INFO - 2022-06-17 09:40:18 --> Loader Class Initialized
INFO - 2022-06-17 09:40:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:18 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:18 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:18 --> Total execution time: 0.0439
INFO - 2022-06-17 09:40:18 --> Config Class Initialized
INFO - 2022-06-17 09:40:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:18 --> URI Class Initialized
INFO - 2022-06-17 09:40:18 --> Router Class Initialized
INFO - 2022-06-17 09:40:18 --> Output Class Initialized
INFO - 2022-06-17 09:40:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:18 --> Input Class Initialized
INFO - 2022-06-17 09:40:18 --> Language Class Initialized
INFO - 2022-06-17 09:40:18 --> Language Class Initialized
INFO - 2022-06-17 09:40:18 --> Config Class Initialized
INFO - 2022-06-17 09:40:18 --> Loader Class Initialized
INFO - 2022-06-17 09:40:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:18 --> Controller Class Initialized
INFO - 2022-06-17 09:40:19 --> Config Class Initialized
INFO - 2022-06-17 09:40:19 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:19 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:19 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:19 --> URI Class Initialized
INFO - 2022-06-17 09:40:19 --> Router Class Initialized
INFO - 2022-06-17 09:40:19 --> Output Class Initialized
INFO - 2022-06-17 09:40:19 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:19 --> Input Class Initialized
INFO - 2022-06-17 09:40:19 --> Language Class Initialized
INFO - 2022-06-17 09:40:19 --> Language Class Initialized
INFO - 2022-06-17 09:40:19 --> Config Class Initialized
INFO - 2022-06-17 09:40:19 --> Loader Class Initialized
INFO - 2022-06-17 09:40:19 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:19 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:19 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:19 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:19 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:19 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:19 --> Total execution time: 0.0453
INFO - 2022-06-17 09:40:22 --> Config Class Initialized
INFO - 2022-06-17 09:40:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:22 --> URI Class Initialized
INFO - 2022-06-17 09:40:22 --> Router Class Initialized
INFO - 2022-06-17 09:40:22 --> Output Class Initialized
INFO - 2022-06-17 09:40:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:22 --> Input Class Initialized
INFO - 2022-06-17 09:40:22 --> Language Class Initialized
INFO - 2022-06-17 09:40:22 --> Language Class Initialized
INFO - 2022-06-17 09:40:22 --> Config Class Initialized
INFO - 2022-06-17 09:40:22 --> Loader Class Initialized
INFO - 2022-06-17 09:40:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:22 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:22 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:22 --> Total execution time: 0.0478
INFO - 2022-06-17 09:40:22 --> Config Class Initialized
INFO - 2022-06-17 09:40:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:22 --> URI Class Initialized
INFO - 2022-06-17 09:40:22 --> Router Class Initialized
INFO - 2022-06-17 09:40:22 --> Output Class Initialized
INFO - 2022-06-17 09:40:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:22 --> Input Class Initialized
INFO - 2022-06-17 09:40:22 --> Language Class Initialized
INFO - 2022-06-17 09:40:22 --> Language Class Initialized
INFO - 2022-06-17 09:40:22 --> Config Class Initialized
INFO - 2022-06-17 09:40:22 --> Loader Class Initialized
INFO - 2022-06-17 09:40:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:22 --> Controller Class Initialized
INFO - 2022-06-17 09:40:23 --> Config Class Initialized
INFO - 2022-06-17 09:40:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:23 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:23 --> URI Class Initialized
INFO - 2022-06-17 09:40:23 --> Router Class Initialized
INFO - 2022-06-17 09:40:23 --> Output Class Initialized
INFO - 2022-06-17 09:40:23 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:23 --> Input Class Initialized
INFO - 2022-06-17 09:40:23 --> Language Class Initialized
INFO - 2022-06-17 09:40:23 --> Language Class Initialized
INFO - 2022-06-17 09:40:23 --> Config Class Initialized
INFO - 2022-06-17 09:40:23 --> Loader Class Initialized
INFO - 2022-06-17 09:40:23 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:23 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:23 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:23 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:23 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:23 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:23 --> Total execution time: 0.0452
INFO - 2022-06-17 09:40:24 --> Config Class Initialized
INFO - 2022-06-17 09:40:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:24 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:24 --> URI Class Initialized
INFO - 2022-06-17 09:40:24 --> Router Class Initialized
INFO - 2022-06-17 09:40:24 --> Output Class Initialized
INFO - 2022-06-17 09:40:24 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:24 --> Input Class Initialized
INFO - 2022-06-17 09:40:24 --> Language Class Initialized
INFO - 2022-06-17 09:40:24 --> Language Class Initialized
INFO - 2022-06-17 09:40:24 --> Config Class Initialized
INFO - 2022-06-17 09:40:24 --> Loader Class Initialized
INFO - 2022-06-17 09:40:24 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:24 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:24 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:24 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:24 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:24 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:24 --> Total execution time: 0.0487
INFO - 2022-06-17 09:40:24 --> Config Class Initialized
INFO - 2022-06-17 09:40:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:24 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:24 --> URI Class Initialized
INFO - 2022-06-17 09:40:24 --> Router Class Initialized
INFO - 2022-06-17 09:40:24 --> Output Class Initialized
INFO - 2022-06-17 09:40:24 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:24 --> Input Class Initialized
INFO - 2022-06-17 09:40:24 --> Language Class Initialized
INFO - 2022-06-17 09:40:24 --> Language Class Initialized
INFO - 2022-06-17 09:40:24 --> Config Class Initialized
INFO - 2022-06-17 09:40:24 --> Loader Class Initialized
INFO - 2022-06-17 09:40:24 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:24 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:24 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:24 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:24 --> Controller Class Initialized
INFO - 2022-06-17 09:40:26 --> Config Class Initialized
INFO - 2022-06-17 09:40:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:26 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:26 --> URI Class Initialized
INFO - 2022-06-17 09:40:26 --> Router Class Initialized
INFO - 2022-06-17 09:40:26 --> Output Class Initialized
INFO - 2022-06-17 09:40:26 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:26 --> Input Class Initialized
INFO - 2022-06-17 09:40:26 --> Language Class Initialized
INFO - 2022-06-17 09:40:26 --> Language Class Initialized
INFO - 2022-06-17 09:40:26 --> Config Class Initialized
INFO - 2022-06-17 09:40:26 --> Loader Class Initialized
INFO - 2022-06-17 09:40:26 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:26 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:26 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:26 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:26 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:26 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:26 --> Total execution time: 0.0474
INFO - 2022-06-17 09:40:30 --> Config Class Initialized
INFO - 2022-06-17 09:40:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:30 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:30 --> URI Class Initialized
INFO - 2022-06-17 09:40:30 --> Router Class Initialized
INFO - 2022-06-17 09:40:30 --> Output Class Initialized
INFO - 2022-06-17 09:40:30 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:30 --> Input Class Initialized
INFO - 2022-06-17 09:40:30 --> Language Class Initialized
INFO - 2022-06-17 09:40:30 --> Language Class Initialized
INFO - 2022-06-17 09:40:30 --> Config Class Initialized
INFO - 2022-06-17 09:40:30 --> Loader Class Initialized
INFO - 2022-06-17 09:40:30 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:30 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:30 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:30 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:30 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:30 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:30 --> Total execution time: 0.0453
INFO - 2022-06-17 09:40:30 --> Config Class Initialized
INFO - 2022-06-17 09:40:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:30 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:30 --> URI Class Initialized
INFO - 2022-06-17 09:40:30 --> Router Class Initialized
INFO - 2022-06-17 09:40:30 --> Output Class Initialized
INFO - 2022-06-17 09:40:30 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:30 --> Input Class Initialized
INFO - 2022-06-17 09:40:30 --> Language Class Initialized
INFO - 2022-06-17 09:40:30 --> Language Class Initialized
INFO - 2022-06-17 09:40:30 --> Config Class Initialized
INFO - 2022-06-17 09:40:30 --> Loader Class Initialized
INFO - 2022-06-17 09:40:30 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:30 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:30 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:30 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:30 --> Controller Class Initialized
INFO - 2022-06-17 09:40:46 --> Config Class Initialized
INFO - 2022-06-17 09:40:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:46 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:46 --> URI Class Initialized
INFO - 2022-06-17 09:40:46 --> Router Class Initialized
INFO - 2022-06-17 09:40:46 --> Output Class Initialized
INFO - 2022-06-17 09:40:46 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:46 --> Input Class Initialized
INFO - 2022-06-17 09:40:46 --> Language Class Initialized
INFO - 2022-06-17 09:40:46 --> Language Class Initialized
INFO - 2022-06-17 09:40:46 --> Config Class Initialized
INFO - 2022-06-17 09:40:46 --> Loader Class Initialized
INFO - 2022-06-17 09:40:46 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:46 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:46 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:46 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:46 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:46 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:46 --> Total execution time: 0.0474
INFO - 2022-06-17 09:40:46 --> Config Class Initialized
INFO - 2022-06-17 09:40:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:46 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:46 --> URI Class Initialized
INFO - 2022-06-17 09:40:46 --> Router Class Initialized
INFO - 2022-06-17 09:40:46 --> Output Class Initialized
INFO - 2022-06-17 09:40:46 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:46 --> Input Class Initialized
INFO - 2022-06-17 09:40:46 --> Language Class Initialized
INFO - 2022-06-17 09:40:46 --> Language Class Initialized
INFO - 2022-06-17 09:40:46 --> Config Class Initialized
INFO - 2022-06-17 09:40:46 --> Loader Class Initialized
INFO - 2022-06-17 09:40:46 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:46 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:46 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:46 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:46 --> Controller Class Initialized
INFO - 2022-06-17 09:40:47 --> Config Class Initialized
INFO - 2022-06-17 09:40:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:47 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:47 --> URI Class Initialized
INFO - 2022-06-17 09:40:47 --> Router Class Initialized
INFO - 2022-06-17 09:40:47 --> Output Class Initialized
INFO - 2022-06-17 09:40:47 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:47 --> Input Class Initialized
INFO - 2022-06-17 09:40:47 --> Language Class Initialized
INFO - 2022-06-17 09:40:47 --> Language Class Initialized
INFO - 2022-06-17 09:40:47 --> Config Class Initialized
INFO - 2022-06-17 09:40:47 --> Loader Class Initialized
INFO - 2022-06-17 09:40:47 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:47 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:47 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:47 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:47 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:47 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:47 --> Total execution time: 0.0471
INFO - 2022-06-17 09:40:49 --> Config Class Initialized
INFO - 2022-06-17 09:40:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:49 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:49 --> URI Class Initialized
INFO - 2022-06-17 09:40:49 --> Router Class Initialized
INFO - 2022-06-17 09:40:49 --> Output Class Initialized
INFO - 2022-06-17 09:40:49 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:49 --> Input Class Initialized
INFO - 2022-06-17 09:40:49 --> Language Class Initialized
INFO - 2022-06-17 09:40:49 --> Language Class Initialized
INFO - 2022-06-17 09:40:49 --> Config Class Initialized
INFO - 2022-06-17 09:40:49 --> Loader Class Initialized
INFO - 2022-06-17 09:40:49 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:49 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:49 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:49 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:49 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:49 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:49 --> Total execution time: 0.0459
INFO - 2022-06-17 09:40:49 --> Config Class Initialized
INFO - 2022-06-17 09:40:49 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:49 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:49 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:49 --> URI Class Initialized
INFO - 2022-06-17 09:40:49 --> Router Class Initialized
INFO - 2022-06-17 09:40:49 --> Output Class Initialized
INFO - 2022-06-17 09:40:49 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:49 --> Input Class Initialized
INFO - 2022-06-17 09:40:49 --> Language Class Initialized
INFO - 2022-06-17 09:40:49 --> Language Class Initialized
INFO - 2022-06-17 09:40:49 --> Config Class Initialized
INFO - 2022-06-17 09:40:49 --> Loader Class Initialized
INFO - 2022-06-17 09:40:49 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:49 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:49 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:49 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:49 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:49 --> Controller Class Initialized
INFO - 2022-06-17 09:40:50 --> Config Class Initialized
INFO - 2022-06-17 09:40:50 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:50 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:50 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:50 --> URI Class Initialized
INFO - 2022-06-17 09:40:50 --> Router Class Initialized
INFO - 2022-06-17 09:40:50 --> Output Class Initialized
INFO - 2022-06-17 09:40:50 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:50 --> Input Class Initialized
INFO - 2022-06-17 09:40:50 --> Language Class Initialized
INFO - 2022-06-17 09:40:50 --> Language Class Initialized
INFO - 2022-06-17 09:40:50 --> Config Class Initialized
INFO - 2022-06-17 09:40:50 --> Loader Class Initialized
INFO - 2022-06-17 09:40:50 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:50 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:50 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:50 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:50 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:50 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:50 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:50 --> Total execution time: 0.0483
INFO - 2022-06-17 09:40:51 --> Config Class Initialized
INFO - 2022-06-17 09:40:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:51 --> URI Class Initialized
INFO - 2022-06-17 09:40:51 --> Router Class Initialized
INFO - 2022-06-17 09:40:51 --> Output Class Initialized
INFO - 2022-06-17 09:40:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:51 --> Input Class Initialized
INFO - 2022-06-17 09:40:51 --> Language Class Initialized
INFO - 2022-06-17 09:40:51 --> Language Class Initialized
INFO - 2022-06-17 09:40:51 --> Config Class Initialized
INFO - 2022-06-17 09:40:51 --> Loader Class Initialized
INFO - 2022-06-17 09:40:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:51 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:51 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:51 --> Total execution time: 0.0465
INFO - 2022-06-17 09:40:51 --> Config Class Initialized
INFO - 2022-06-17 09:40:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:51 --> URI Class Initialized
INFO - 2022-06-17 09:40:51 --> Router Class Initialized
INFO - 2022-06-17 09:40:51 --> Output Class Initialized
INFO - 2022-06-17 09:40:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:51 --> Input Class Initialized
INFO - 2022-06-17 09:40:51 --> Language Class Initialized
INFO - 2022-06-17 09:40:51 --> Language Class Initialized
INFO - 2022-06-17 09:40:51 --> Config Class Initialized
INFO - 2022-06-17 09:40:51 --> Loader Class Initialized
INFO - 2022-06-17 09:40:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:51 --> Controller Class Initialized
INFO - 2022-06-17 09:40:52 --> Config Class Initialized
INFO - 2022-06-17 09:40:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:52 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:52 --> URI Class Initialized
INFO - 2022-06-17 09:40:52 --> Router Class Initialized
INFO - 2022-06-17 09:40:52 --> Output Class Initialized
INFO - 2022-06-17 09:40:52 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:52 --> Input Class Initialized
INFO - 2022-06-17 09:40:52 --> Language Class Initialized
INFO - 2022-06-17 09:40:52 --> Language Class Initialized
INFO - 2022-06-17 09:40:52 --> Config Class Initialized
INFO - 2022-06-17 09:40:52 --> Loader Class Initialized
INFO - 2022-06-17 09:40:52 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:52 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:52 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:52 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:52 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:52 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:52 --> Total execution time: 0.0482
INFO - 2022-06-17 09:40:54 --> Config Class Initialized
INFO - 2022-06-17 09:40:54 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:54 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:54 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:54 --> URI Class Initialized
INFO - 2022-06-17 09:40:54 --> Router Class Initialized
INFO - 2022-06-17 09:40:54 --> Output Class Initialized
INFO - 2022-06-17 09:40:54 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:54 --> Input Class Initialized
INFO - 2022-06-17 09:40:54 --> Language Class Initialized
INFO - 2022-06-17 09:40:54 --> Language Class Initialized
INFO - 2022-06-17 09:40:54 --> Config Class Initialized
INFO - 2022-06-17 09:40:54 --> Loader Class Initialized
INFO - 2022-06-17 09:40:54 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:54 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:54 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:54 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:54 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:54 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:54 --> Total execution time: 0.0629
INFO - 2022-06-17 09:40:54 --> Config Class Initialized
INFO - 2022-06-17 09:40:54 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:54 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:54 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:54 --> URI Class Initialized
INFO - 2022-06-17 09:40:54 --> Router Class Initialized
INFO - 2022-06-17 09:40:54 --> Output Class Initialized
INFO - 2022-06-17 09:40:54 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:54 --> Input Class Initialized
INFO - 2022-06-17 09:40:54 --> Language Class Initialized
INFO - 2022-06-17 09:40:54 --> Language Class Initialized
INFO - 2022-06-17 09:40:54 --> Config Class Initialized
INFO - 2022-06-17 09:40:54 --> Loader Class Initialized
INFO - 2022-06-17 09:40:54 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:54 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:54 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:54 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:54 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:54 --> Controller Class Initialized
INFO - 2022-06-17 09:40:55 --> Config Class Initialized
INFO - 2022-06-17 09:40:55 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:55 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:55 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:55 --> URI Class Initialized
INFO - 2022-06-17 09:40:55 --> Router Class Initialized
INFO - 2022-06-17 09:40:55 --> Output Class Initialized
INFO - 2022-06-17 09:40:55 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:55 --> Input Class Initialized
INFO - 2022-06-17 09:40:55 --> Language Class Initialized
INFO - 2022-06-17 09:40:55 --> Language Class Initialized
INFO - 2022-06-17 09:40:55 --> Config Class Initialized
INFO - 2022-06-17 09:40:55 --> Loader Class Initialized
INFO - 2022-06-17 09:40:55 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:55 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:55 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:55 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:55 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:55 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:55 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:55 --> Total execution time: 0.0459
INFO - 2022-06-17 09:40:56 --> Config Class Initialized
INFO - 2022-06-17 09:40:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:56 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:56 --> URI Class Initialized
INFO - 2022-06-17 09:40:56 --> Router Class Initialized
INFO - 2022-06-17 09:40:56 --> Output Class Initialized
INFO - 2022-06-17 09:40:56 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:56 --> Input Class Initialized
INFO - 2022-06-17 09:40:56 --> Language Class Initialized
INFO - 2022-06-17 09:40:56 --> Language Class Initialized
INFO - 2022-06-17 09:40:56 --> Config Class Initialized
INFO - 2022-06-17 09:40:56 --> Loader Class Initialized
INFO - 2022-06-17 09:40:56 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:56 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:56 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:56 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:56 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:56 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:56 --> Total execution time: 0.0466
INFO - 2022-06-17 09:40:57 --> Config Class Initialized
INFO - 2022-06-17 09:40:57 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:57 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:57 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:57 --> URI Class Initialized
INFO - 2022-06-17 09:40:57 --> Router Class Initialized
INFO - 2022-06-17 09:40:57 --> Output Class Initialized
INFO - 2022-06-17 09:40:57 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:57 --> Input Class Initialized
INFO - 2022-06-17 09:40:57 --> Language Class Initialized
INFO - 2022-06-17 09:40:57 --> Language Class Initialized
INFO - 2022-06-17 09:40:57 --> Config Class Initialized
INFO - 2022-06-17 09:40:57 --> Loader Class Initialized
INFO - 2022-06-17 09:40:57 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:57 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:57 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:57 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:57 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:57 --> Controller Class Initialized
INFO - 2022-06-17 09:40:58 --> Config Class Initialized
INFO - 2022-06-17 09:40:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:58 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:58 --> URI Class Initialized
INFO - 2022-06-17 09:40:58 --> Router Class Initialized
INFO - 2022-06-17 09:40:58 --> Output Class Initialized
INFO - 2022-06-17 09:40:58 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:58 --> Input Class Initialized
INFO - 2022-06-17 09:40:58 --> Language Class Initialized
INFO - 2022-06-17 09:40:58 --> Language Class Initialized
INFO - 2022-06-17 09:40:58 --> Config Class Initialized
INFO - 2022-06-17 09:40:58 --> Loader Class Initialized
INFO - 2022-06-17 09:40:58 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:58 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:58 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:58 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:58 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:40:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:58 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:58 --> Total execution time: 0.0467
INFO - 2022-06-17 09:40:59 --> Config Class Initialized
INFO - 2022-06-17 09:40:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:59 --> URI Class Initialized
INFO - 2022-06-17 09:40:59 --> Router Class Initialized
INFO - 2022-06-17 09:40:59 --> Output Class Initialized
INFO - 2022-06-17 09:40:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:59 --> Input Class Initialized
INFO - 2022-06-17 09:40:59 --> Language Class Initialized
INFO - 2022-06-17 09:40:59 --> Language Class Initialized
INFO - 2022-06-17 09:40:59 --> Config Class Initialized
INFO - 2022-06-17 09:40:59 --> Loader Class Initialized
INFO - 2022-06-17 09:40:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:59 --> Controller Class Initialized
DEBUG - 2022-06-17 09:40:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:40:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:40:59 --> Final output sent to browser
DEBUG - 2022-06-17 09:40:59 --> Total execution time: 0.0474
INFO - 2022-06-17 09:40:59 --> Config Class Initialized
INFO - 2022-06-17 09:40:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:40:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:40:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:40:59 --> URI Class Initialized
INFO - 2022-06-17 09:40:59 --> Router Class Initialized
INFO - 2022-06-17 09:40:59 --> Output Class Initialized
INFO - 2022-06-17 09:40:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:40:59 --> Input Class Initialized
INFO - 2022-06-17 09:40:59 --> Language Class Initialized
INFO - 2022-06-17 09:40:59 --> Language Class Initialized
INFO - 2022-06-17 09:40:59 --> Config Class Initialized
INFO - 2022-06-17 09:40:59 --> Loader Class Initialized
INFO - 2022-06-17 09:40:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:40:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:40:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:40:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:40:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:40:59 --> Controller Class Initialized
INFO - 2022-06-17 09:41:00 --> Config Class Initialized
INFO - 2022-06-17 09:41:00 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:00 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:00 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:00 --> URI Class Initialized
INFO - 2022-06-17 09:41:00 --> Router Class Initialized
INFO - 2022-06-17 09:41:00 --> Output Class Initialized
INFO - 2022-06-17 09:41:00 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:00 --> Input Class Initialized
INFO - 2022-06-17 09:41:00 --> Language Class Initialized
INFO - 2022-06-17 09:41:00 --> Language Class Initialized
INFO - 2022-06-17 09:41:00 --> Config Class Initialized
INFO - 2022-06-17 09:41:00 --> Loader Class Initialized
INFO - 2022-06-17 09:41:00 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:00 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:00 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:00 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:00 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:00 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:00 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:00 --> Total execution time: 0.0467
INFO - 2022-06-17 09:41:02 --> Config Class Initialized
INFO - 2022-06-17 09:41:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:02 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:02 --> URI Class Initialized
INFO - 2022-06-17 09:41:02 --> Router Class Initialized
INFO - 2022-06-17 09:41:02 --> Output Class Initialized
INFO - 2022-06-17 09:41:02 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:02 --> Input Class Initialized
INFO - 2022-06-17 09:41:02 --> Language Class Initialized
INFO - 2022-06-17 09:41:02 --> Language Class Initialized
INFO - 2022-06-17 09:41:02 --> Config Class Initialized
INFO - 2022-06-17 09:41:02 --> Loader Class Initialized
INFO - 2022-06-17 09:41:02 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:02 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:02 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:02 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:02 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:02 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:02 --> Total execution time: 0.0484
INFO - 2022-06-17 09:41:02 --> Config Class Initialized
INFO - 2022-06-17 09:41:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:02 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:02 --> URI Class Initialized
INFO - 2022-06-17 09:41:02 --> Router Class Initialized
INFO - 2022-06-17 09:41:02 --> Output Class Initialized
INFO - 2022-06-17 09:41:02 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:02 --> Input Class Initialized
INFO - 2022-06-17 09:41:02 --> Language Class Initialized
INFO - 2022-06-17 09:41:02 --> Language Class Initialized
INFO - 2022-06-17 09:41:02 --> Config Class Initialized
INFO - 2022-06-17 09:41:02 --> Loader Class Initialized
INFO - 2022-06-17 09:41:02 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:02 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:02 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:02 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:02 --> Controller Class Initialized
INFO - 2022-06-17 09:41:03 --> Config Class Initialized
INFO - 2022-06-17 09:41:03 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:03 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:03 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:03 --> URI Class Initialized
INFO - 2022-06-17 09:41:03 --> Router Class Initialized
INFO - 2022-06-17 09:41:03 --> Output Class Initialized
INFO - 2022-06-17 09:41:03 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:03 --> Input Class Initialized
INFO - 2022-06-17 09:41:03 --> Language Class Initialized
INFO - 2022-06-17 09:41:03 --> Language Class Initialized
INFO - 2022-06-17 09:41:03 --> Config Class Initialized
INFO - 2022-06-17 09:41:03 --> Loader Class Initialized
INFO - 2022-06-17 09:41:03 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:03 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:03 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:03 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:03 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:03 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:03 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:03 --> Total execution time: 0.0485
INFO - 2022-06-17 09:41:04 --> Config Class Initialized
INFO - 2022-06-17 09:41:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:04 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:04 --> URI Class Initialized
INFO - 2022-06-17 09:41:04 --> Router Class Initialized
INFO - 2022-06-17 09:41:04 --> Output Class Initialized
INFO - 2022-06-17 09:41:04 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:04 --> Input Class Initialized
INFO - 2022-06-17 09:41:04 --> Language Class Initialized
INFO - 2022-06-17 09:41:04 --> Language Class Initialized
INFO - 2022-06-17 09:41:04 --> Config Class Initialized
INFO - 2022-06-17 09:41:04 --> Loader Class Initialized
INFO - 2022-06-17 09:41:04 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:04 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:04 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:04 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:04 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:04 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:04 --> Total execution time: 0.0478
INFO - 2022-06-17 09:41:04 --> Config Class Initialized
INFO - 2022-06-17 09:41:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:04 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:04 --> URI Class Initialized
INFO - 2022-06-17 09:41:04 --> Router Class Initialized
INFO - 2022-06-17 09:41:04 --> Output Class Initialized
INFO - 2022-06-17 09:41:04 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:04 --> Input Class Initialized
INFO - 2022-06-17 09:41:04 --> Language Class Initialized
INFO - 2022-06-17 09:41:04 --> Language Class Initialized
INFO - 2022-06-17 09:41:04 --> Config Class Initialized
INFO - 2022-06-17 09:41:04 --> Loader Class Initialized
INFO - 2022-06-17 09:41:04 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:04 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:04 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:04 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:04 --> Controller Class Initialized
INFO - 2022-06-17 09:41:05 --> Config Class Initialized
INFO - 2022-06-17 09:41:05 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:05 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:05 --> URI Class Initialized
INFO - 2022-06-17 09:41:05 --> Router Class Initialized
INFO - 2022-06-17 09:41:05 --> Output Class Initialized
INFO - 2022-06-17 09:41:05 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:05 --> Input Class Initialized
INFO - 2022-06-17 09:41:05 --> Language Class Initialized
INFO - 2022-06-17 09:41:05 --> Language Class Initialized
INFO - 2022-06-17 09:41:05 --> Config Class Initialized
INFO - 2022-06-17 09:41:05 --> Loader Class Initialized
INFO - 2022-06-17 09:41:05 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:05 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:05 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:05 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:05 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:05 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:05 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:05 --> Total execution time: 0.0466
INFO - 2022-06-17 09:41:06 --> Config Class Initialized
INFO - 2022-06-17 09:41:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:06 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:06 --> URI Class Initialized
INFO - 2022-06-17 09:41:06 --> Router Class Initialized
INFO - 2022-06-17 09:41:06 --> Output Class Initialized
INFO - 2022-06-17 09:41:06 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:06 --> Input Class Initialized
INFO - 2022-06-17 09:41:06 --> Language Class Initialized
INFO - 2022-06-17 09:41:06 --> Language Class Initialized
INFO - 2022-06-17 09:41:06 --> Config Class Initialized
INFO - 2022-06-17 09:41:06 --> Loader Class Initialized
INFO - 2022-06-17 09:41:06 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:06 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:06 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:06 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:06 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:06 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:06 --> Total execution time: 0.0482
INFO - 2022-06-17 09:41:07 --> Config Class Initialized
INFO - 2022-06-17 09:41:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:07 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:07 --> URI Class Initialized
INFO - 2022-06-17 09:41:07 --> Router Class Initialized
INFO - 2022-06-17 09:41:07 --> Output Class Initialized
INFO - 2022-06-17 09:41:07 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:07 --> Input Class Initialized
INFO - 2022-06-17 09:41:07 --> Language Class Initialized
INFO - 2022-06-17 09:41:07 --> Language Class Initialized
INFO - 2022-06-17 09:41:07 --> Config Class Initialized
INFO - 2022-06-17 09:41:07 --> Loader Class Initialized
INFO - 2022-06-17 09:41:07 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:07 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:07 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:07 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:07 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:07 --> Controller Class Initialized
INFO - 2022-06-17 09:41:08 --> Config Class Initialized
INFO - 2022-06-17 09:41:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:08 --> URI Class Initialized
INFO - 2022-06-17 09:41:08 --> Router Class Initialized
INFO - 2022-06-17 09:41:08 --> Output Class Initialized
INFO - 2022-06-17 09:41:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:08 --> Input Class Initialized
INFO - 2022-06-17 09:41:08 --> Language Class Initialized
INFO - 2022-06-17 09:41:08 --> Language Class Initialized
INFO - 2022-06-17 09:41:08 --> Config Class Initialized
INFO - 2022-06-17 09:41:08 --> Loader Class Initialized
INFO - 2022-06-17 09:41:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:08 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:08 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:08 --> Total execution time: 0.0455
INFO - 2022-06-17 09:41:10 --> Config Class Initialized
INFO - 2022-06-17 09:41:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:10 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:10 --> URI Class Initialized
INFO - 2022-06-17 09:41:10 --> Router Class Initialized
INFO - 2022-06-17 09:41:10 --> Output Class Initialized
INFO - 2022-06-17 09:41:10 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:10 --> Input Class Initialized
INFO - 2022-06-17 09:41:10 --> Language Class Initialized
INFO - 2022-06-17 09:41:10 --> Language Class Initialized
INFO - 2022-06-17 09:41:10 --> Config Class Initialized
INFO - 2022-06-17 09:41:10 --> Loader Class Initialized
INFO - 2022-06-17 09:41:10 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:10 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:10 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:10 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:10 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:10 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:10 --> Total execution time: 0.0471
INFO - 2022-06-17 09:41:10 --> Config Class Initialized
INFO - 2022-06-17 09:41:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:10 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:10 --> URI Class Initialized
INFO - 2022-06-17 09:41:10 --> Router Class Initialized
INFO - 2022-06-17 09:41:10 --> Output Class Initialized
INFO - 2022-06-17 09:41:10 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:10 --> Input Class Initialized
INFO - 2022-06-17 09:41:10 --> Language Class Initialized
INFO - 2022-06-17 09:41:10 --> Language Class Initialized
INFO - 2022-06-17 09:41:10 --> Config Class Initialized
INFO - 2022-06-17 09:41:10 --> Loader Class Initialized
INFO - 2022-06-17 09:41:10 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:10 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:10 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:10 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:10 --> Controller Class Initialized
INFO - 2022-06-17 09:41:11 --> Config Class Initialized
INFO - 2022-06-17 09:41:11 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:11 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:11 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:11 --> URI Class Initialized
INFO - 2022-06-17 09:41:11 --> Router Class Initialized
INFO - 2022-06-17 09:41:11 --> Output Class Initialized
INFO - 2022-06-17 09:41:11 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:11 --> Input Class Initialized
INFO - 2022-06-17 09:41:11 --> Language Class Initialized
INFO - 2022-06-17 09:41:11 --> Language Class Initialized
INFO - 2022-06-17 09:41:11 --> Config Class Initialized
INFO - 2022-06-17 09:41:11 --> Loader Class Initialized
INFO - 2022-06-17 09:41:11 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:11 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:11 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:11 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:11 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:11 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:11 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:11 --> Total execution time: 0.0463
INFO - 2022-06-17 09:41:13 --> Config Class Initialized
INFO - 2022-06-17 09:41:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:13 --> URI Class Initialized
INFO - 2022-06-17 09:41:13 --> Router Class Initialized
INFO - 2022-06-17 09:41:13 --> Output Class Initialized
INFO - 2022-06-17 09:41:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:13 --> Input Class Initialized
INFO - 2022-06-17 09:41:13 --> Language Class Initialized
INFO - 2022-06-17 09:41:13 --> Language Class Initialized
INFO - 2022-06-17 09:41:13 --> Config Class Initialized
INFO - 2022-06-17 09:41:13 --> Loader Class Initialized
INFO - 2022-06-17 09:41:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:13 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:13 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:13 --> Total execution time: 0.0462
INFO - 2022-06-17 09:41:13 --> Config Class Initialized
INFO - 2022-06-17 09:41:13 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:13 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:13 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:13 --> URI Class Initialized
INFO - 2022-06-17 09:41:13 --> Router Class Initialized
INFO - 2022-06-17 09:41:13 --> Output Class Initialized
INFO - 2022-06-17 09:41:13 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:13 --> Input Class Initialized
INFO - 2022-06-17 09:41:13 --> Language Class Initialized
INFO - 2022-06-17 09:41:13 --> Language Class Initialized
INFO - 2022-06-17 09:41:13 --> Config Class Initialized
INFO - 2022-06-17 09:41:13 --> Loader Class Initialized
INFO - 2022-06-17 09:41:13 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:13 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:13 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:13 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:13 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:13 --> Controller Class Initialized
INFO - 2022-06-17 09:41:14 --> Config Class Initialized
INFO - 2022-06-17 09:41:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:14 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:14 --> URI Class Initialized
INFO - 2022-06-17 09:41:14 --> Router Class Initialized
INFO - 2022-06-17 09:41:14 --> Output Class Initialized
INFO - 2022-06-17 09:41:14 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:14 --> Input Class Initialized
INFO - 2022-06-17 09:41:14 --> Language Class Initialized
INFO - 2022-06-17 09:41:14 --> Language Class Initialized
INFO - 2022-06-17 09:41:14 --> Config Class Initialized
INFO - 2022-06-17 09:41:14 --> Loader Class Initialized
INFO - 2022-06-17 09:41:14 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:14 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:14 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:14 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:14 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:14 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:14 --> Total execution time: 0.0469
INFO - 2022-06-17 09:41:15 --> Config Class Initialized
INFO - 2022-06-17 09:41:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:15 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:15 --> URI Class Initialized
INFO - 2022-06-17 09:41:15 --> Router Class Initialized
INFO - 2022-06-17 09:41:15 --> Output Class Initialized
INFO - 2022-06-17 09:41:15 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:15 --> Input Class Initialized
INFO - 2022-06-17 09:41:15 --> Language Class Initialized
INFO - 2022-06-17 09:41:15 --> Language Class Initialized
INFO - 2022-06-17 09:41:15 --> Config Class Initialized
INFO - 2022-06-17 09:41:15 --> Loader Class Initialized
INFO - 2022-06-17 09:41:15 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:15 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:15 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:15 --> Total execution time: 0.0458
INFO - 2022-06-17 09:41:15 --> Config Class Initialized
INFO - 2022-06-17 09:41:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:15 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:15 --> URI Class Initialized
INFO - 2022-06-17 09:41:15 --> Router Class Initialized
INFO - 2022-06-17 09:41:15 --> Output Class Initialized
INFO - 2022-06-17 09:41:15 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:15 --> Input Class Initialized
INFO - 2022-06-17 09:41:15 --> Language Class Initialized
INFO - 2022-06-17 09:41:15 --> Language Class Initialized
INFO - 2022-06-17 09:41:15 --> Config Class Initialized
INFO - 2022-06-17 09:41:15 --> Loader Class Initialized
INFO - 2022-06-17 09:41:15 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:15 --> Controller Class Initialized
INFO - 2022-06-17 09:41:15 --> Config Class Initialized
INFO - 2022-06-17 09:41:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:15 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:15 --> URI Class Initialized
INFO - 2022-06-17 09:41:15 --> Router Class Initialized
INFO - 2022-06-17 09:41:15 --> Output Class Initialized
INFO - 2022-06-17 09:41:15 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:15 --> Input Class Initialized
INFO - 2022-06-17 09:41:15 --> Language Class Initialized
INFO - 2022-06-17 09:41:15 --> Language Class Initialized
INFO - 2022-06-17 09:41:15 --> Config Class Initialized
INFO - 2022-06-17 09:41:15 --> Loader Class Initialized
INFO - 2022-06-17 09:41:15 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:15 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:15 --> Controller Class Initialized
INFO - 2022-06-17 09:41:15 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:15 --> Total execution time: 0.0959
INFO - 2022-06-17 09:41:16 --> Config Class Initialized
INFO - 2022-06-17 09:41:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:16 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:16 --> URI Class Initialized
INFO - 2022-06-17 09:41:16 --> Router Class Initialized
INFO - 2022-06-17 09:41:16 --> Output Class Initialized
INFO - 2022-06-17 09:41:16 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:16 --> Input Class Initialized
INFO - 2022-06-17 09:41:16 --> Language Class Initialized
INFO - 2022-06-17 09:41:16 --> Language Class Initialized
INFO - 2022-06-17 09:41:16 --> Config Class Initialized
INFO - 2022-06-17 09:41:16 --> Loader Class Initialized
INFO - 2022-06-17 09:41:16 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:16 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:16 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:16 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:16 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:16 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:16 --> Total execution time: 0.0481
INFO - 2022-06-17 09:41:18 --> Config Class Initialized
INFO - 2022-06-17 09:41:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:18 --> URI Class Initialized
INFO - 2022-06-17 09:41:18 --> Router Class Initialized
INFO - 2022-06-17 09:41:18 --> Output Class Initialized
INFO - 2022-06-17 09:41:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:18 --> Input Class Initialized
INFO - 2022-06-17 09:41:18 --> Language Class Initialized
INFO - 2022-06-17 09:41:18 --> Language Class Initialized
INFO - 2022-06-17 09:41:18 --> Config Class Initialized
INFO - 2022-06-17 09:41:18 --> Loader Class Initialized
INFO - 2022-06-17 09:41:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:18 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:18 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:18 --> Total execution time: 0.0448
INFO - 2022-06-17 09:41:18 --> Config Class Initialized
INFO - 2022-06-17 09:41:18 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:18 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:18 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:18 --> URI Class Initialized
INFO - 2022-06-17 09:41:18 --> Router Class Initialized
INFO - 2022-06-17 09:41:18 --> Output Class Initialized
INFO - 2022-06-17 09:41:18 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:18 --> Input Class Initialized
INFO - 2022-06-17 09:41:18 --> Language Class Initialized
INFO - 2022-06-17 09:41:18 --> Language Class Initialized
INFO - 2022-06-17 09:41:18 --> Config Class Initialized
INFO - 2022-06-17 09:41:18 --> Loader Class Initialized
INFO - 2022-06-17 09:41:18 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:18 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:18 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:18 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:18 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:18 --> Controller Class Initialized
INFO - 2022-06-17 09:41:20 --> Config Class Initialized
INFO - 2022-06-17 09:41:20 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:20 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:20 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:20 --> URI Class Initialized
INFO - 2022-06-17 09:41:20 --> Router Class Initialized
INFO - 2022-06-17 09:41:20 --> Output Class Initialized
INFO - 2022-06-17 09:41:20 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:20 --> Input Class Initialized
INFO - 2022-06-17 09:41:20 --> Language Class Initialized
INFO - 2022-06-17 09:41:20 --> Language Class Initialized
INFO - 2022-06-17 09:41:20 --> Config Class Initialized
INFO - 2022-06-17 09:41:20 --> Loader Class Initialized
INFO - 2022-06-17 09:41:20 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:20 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:20 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:20 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:20 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:20 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:20 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:20 --> Total execution time: 0.0463
INFO - 2022-06-17 09:41:22 --> Config Class Initialized
INFO - 2022-06-17 09:41:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:22 --> URI Class Initialized
INFO - 2022-06-17 09:41:22 --> Router Class Initialized
INFO - 2022-06-17 09:41:22 --> Output Class Initialized
INFO - 2022-06-17 09:41:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:22 --> Input Class Initialized
INFO - 2022-06-17 09:41:22 --> Language Class Initialized
INFO - 2022-06-17 09:41:22 --> Language Class Initialized
INFO - 2022-06-17 09:41:22 --> Config Class Initialized
INFO - 2022-06-17 09:41:22 --> Loader Class Initialized
INFO - 2022-06-17 09:41:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:22 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:22 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:22 --> Total execution time: 0.0469
INFO - 2022-06-17 09:41:22 --> Config Class Initialized
INFO - 2022-06-17 09:41:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:22 --> URI Class Initialized
INFO - 2022-06-17 09:41:22 --> Router Class Initialized
INFO - 2022-06-17 09:41:22 --> Output Class Initialized
INFO - 2022-06-17 09:41:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:22 --> Input Class Initialized
INFO - 2022-06-17 09:41:22 --> Language Class Initialized
INFO - 2022-06-17 09:41:22 --> Language Class Initialized
INFO - 2022-06-17 09:41:22 --> Config Class Initialized
INFO - 2022-06-17 09:41:22 --> Loader Class Initialized
INFO - 2022-06-17 09:41:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:22 --> Controller Class Initialized
INFO - 2022-06-17 09:41:24 --> Config Class Initialized
INFO - 2022-06-17 09:41:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:24 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:24 --> URI Class Initialized
INFO - 2022-06-17 09:41:24 --> Router Class Initialized
INFO - 2022-06-17 09:41:24 --> Output Class Initialized
INFO - 2022-06-17 09:41:24 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:24 --> Input Class Initialized
INFO - 2022-06-17 09:41:24 --> Language Class Initialized
INFO - 2022-06-17 09:41:24 --> Language Class Initialized
INFO - 2022-06-17 09:41:24 --> Config Class Initialized
INFO - 2022-06-17 09:41:24 --> Loader Class Initialized
INFO - 2022-06-17 09:41:24 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:24 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:24 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:24 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:24 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:24 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:24 --> Total execution time: 0.0477
INFO - 2022-06-17 09:41:25 --> Config Class Initialized
INFO - 2022-06-17 09:41:25 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:25 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:25 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:25 --> URI Class Initialized
INFO - 2022-06-17 09:41:25 --> Router Class Initialized
INFO - 2022-06-17 09:41:25 --> Output Class Initialized
INFO - 2022-06-17 09:41:25 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:25 --> Input Class Initialized
INFO - 2022-06-17 09:41:25 --> Language Class Initialized
INFO - 2022-06-17 09:41:25 --> Language Class Initialized
INFO - 2022-06-17 09:41:25 --> Config Class Initialized
INFO - 2022-06-17 09:41:25 --> Loader Class Initialized
INFO - 2022-06-17 09:41:25 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:25 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:25 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:25 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:25 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:25 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:25 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:26 --> Total execution time: 0.0467
INFO - 2022-06-17 09:41:26 --> Config Class Initialized
INFO - 2022-06-17 09:41:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:26 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:26 --> URI Class Initialized
INFO - 2022-06-17 09:41:26 --> Router Class Initialized
INFO - 2022-06-17 09:41:26 --> Output Class Initialized
INFO - 2022-06-17 09:41:26 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:26 --> Input Class Initialized
INFO - 2022-06-17 09:41:26 --> Language Class Initialized
INFO - 2022-06-17 09:41:26 --> Language Class Initialized
INFO - 2022-06-17 09:41:26 --> Config Class Initialized
INFO - 2022-06-17 09:41:26 --> Loader Class Initialized
INFO - 2022-06-17 09:41:26 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:26 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:26 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:26 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:26 --> Controller Class Initialized
INFO - 2022-06-17 09:41:27 --> Config Class Initialized
INFO - 2022-06-17 09:41:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:27 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:27 --> URI Class Initialized
INFO - 2022-06-17 09:41:27 --> Router Class Initialized
INFO - 2022-06-17 09:41:27 --> Output Class Initialized
INFO - 2022-06-17 09:41:27 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:27 --> Input Class Initialized
INFO - 2022-06-17 09:41:27 --> Language Class Initialized
INFO - 2022-06-17 09:41:27 --> Language Class Initialized
INFO - 2022-06-17 09:41:27 --> Config Class Initialized
INFO - 2022-06-17 09:41:27 --> Loader Class Initialized
INFO - 2022-06-17 09:41:27 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:27 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:27 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:27 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:27 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:27 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:27 --> Total execution time: 0.0472
INFO - 2022-06-17 09:41:29 --> Config Class Initialized
INFO - 2022-06-17 09:41:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:29 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:29 --> URI Class Initialized
INFO - 2022-06-17 09:41:29 --> Router Class Initialized
INFO - 2022-06-17 09:41:29 --> Output Class Initialized
INFO - 2022-06-17 09:41:29 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:29 --> Input Class Initialized
INFO - 2022-06-17 09:41:29 --> Language Class Initialized
INFO - 2022-06-17 09:41:29 --> Language Class Initialized
INFO - 2022-06-17 09:41:29 --> Config Class Initialized
INFO - 2022-06-17 09:41:29 --> Loader Class Initialized
INFO - 2022-06-17 09:41:29 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:29 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:29 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:29 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:29 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 09:41:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:29 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:29 --> Total execution time: 0.0467
INFO - 2022-06-17 09:41:29 --> Config Class Initialized
INFO - 2022-06-17 09:41:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:29 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:29 --> URI Class Initialized
INFO - 2022-06-17 09:41:29 --> Router Class Initialized
INFO - 2022-06-17 09:41:29 --> Output Class Initialized
INFO - 2022-06-17 09:41:29 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:29 --> Input Class Initialized
INFO - 2022-06-17 09:41:29 --> Language Class Initialized
INFO - 2022-06-17 09:41:29 --> Language Class Initialized
INFO - 2022-06-17 09:41:29 --> Config Class Initialized
INFO - 2022-06-17 09:41:29 --> Loader Class Initialized
INFO - 2022-06-17 09:41:29 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:29 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:29 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:29 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:29 --> Controller Class Initialized
INFO - 2022-06-17 09:41:31 --> Config Class Initialized
INFO - 2022-06-17 09:41:31 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:31 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:31 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:31 --> URI Class Initialized
INFO - 2022-06-17 09:41:31 --> Router Class Initialized
INFO - 2022-06-17 09:41:31 --> Output Class Initialized
INFO - 2022-06-17 09:41:31 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:31 --> Input Class Initialized
INFO - 2022-06-17 09:41:31 --> Language Class Initialized
INFO - 2022-06-17 09:41:31 --> Language Class Initialized
INFO - 2022-06-17 09:41:31 --> Config Class Initialized
INFO - 2022-06-17 09:41:31 --> Loader Class Initialized
INFO - 2022-06-17 09:41:31 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:31 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:31 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:31 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:31 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:31 --> Controller Class Initialized
DEBUG - 2022-06-17 09:41:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 09:41:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:41:31 --> Final output sent to browser
DEBUG - 2022-06-17 09:41:31 --> Total execution time: 0.0457
INFO - 2022-06-17 09:41:33 --> Config Class Initialized
INFO - 2022-06-17 09:41:33 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:33 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:33 --> URI Class Initialized
INFO - 2022-06-17 09:41:33 --> Router Class Initialized
INFO - 2022-06-17 09:41:33 --> Output Class Initialized
INFO - 2022-06-17 09:41:33 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:33 --> Input Class Initialized
INFO - 2022-06-17 09:41:33 --> Language Class Initialized
INFO - 2022-06-17 09:41:33 --> Language Class Initialized
INFO - 2022-06-17 09:41:33 --> Config Class Initialized
INFO - 2022-06-17 09:41:33 --> Loader Class Initialized
INFO - 2022-06-17 09:41:33 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:33 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:33 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:33 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:33 --> Controller Class Initialized
INFO - 2022-06-17 09:41:35 --> Config Class Initialized
INFO - 2022-06-17 09:41:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:35 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:35 --> URI Class Initialized
INFO - 2022-06-17 09:41:35 --> Router Class Initialized
INFO - 2022-06-17 09:41:35 --> Output Class Initialized
INFO - 2022-06-17 09:41:35 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:35 --> Input Class Initialized
INFO - 2022-06-17 09:41:35 --> Language Class Initialized
INFO - 2022-06-17 09:41:35 --> Language Class Initialized
INFO - 2022-06-17 09:41:35 --> Config Class Initialized
INFO - 2022-06-17 09:41:35 --> Loader Class Initialized
INFO - 2022-06-17 09:41:35 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:35 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:35 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:35 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:35 --> Controller Class Initialized
INFO - 2022-06-17 09:41:37 --> Config Class Initialized
INFO - 2022-06-17 09:41:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:37 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:37 --> URI Class Initialized
INFO - 2022-06-17 09:41:37 --> Router Class Initialized
INFO - 2022-06-17 09:41:37 --> Output Class Initialized
INFO - 2022-06-17 09:41:37 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:37 --> Input Class Initialized
INFO - 2022-06-17 09:41:37 --> Language Class Initialized
INFO - 2022-06-17 09:41:37 --> Language Class Initialized
INFO - 2022-06-17 09:41:37 --> Config Class Initialized
INFO - 2022-06-17 09:41:37 --> Loader Class Initialized
INFO - 2022-06-17 09:41:37 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:37 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:37 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:37 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:37 --> Controller Class Initialized
INFO - 2022-06-17 09:41:39 --> Config Class Initialized
INFO - 2022-06-17 09:41:39 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:39 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:39 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:39 --> URI Class Initialized
INFO - 2022-06-17 09:41:39 --> Router Class Initialized
INFO - 2022-06-17 09:41:39 --> Output Class Initialized
INFO - 2022-06-17 09:41:39 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:39 --> Input Class Initialized
INFO - 2022-06-17 09:41:39 --> Language Class Initialized
INFO - 2022-06-17 09:41:39 --> Language Class Initialized
INFO - 2022-06-17 09:41:39 --> Config Class Initialized
INFO - 2022-06-17 09:41:39 --> Loader Class Initialized
INFO - 2022-06-17 09:41:39 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:39 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:39 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:39 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:39 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:39 --> Controller Class Initialized
INFO - 2022-06-17 09:41:41 --> Config Class Initialized
INFO - 2022-06-17 09:41:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:41 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:41 --> URI Class Initialized
INFO - 2022-06-17 09:41:41 --> Router Class Initialized
INFO - 2022-06-17 09:41:41 --> Output Class Initialized
INFO - 2022-06-17 09:41:41 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:41 --> Input Class Initialized
INFO - 2022-06-17 09:41:41 --> Language Class Initialized
INFO - 2022-06-17 09:41:41 --> Language Class Initialized
INFO - 2022-06-17 09:41:41 --> Config Class Initialized
INFO - 2022-06-17 09:41:41 --> Loader Class Initialized
INFO - 2022-06-17 09:41:41 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:41 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:41 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:41 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:41 --> Controller Class Initialized
INFO - 2022-06-17 09:41:43 --> Config Class Initialized
INFO - 2022-06-17 09:41:43 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:43 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:43 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:43 --> URI Class Initialized
INFO - 2022-06-17 09:41:43 --> Router Class Initialized
INFO - 2022-06-17 09:41:43 --> Output Class Initialized
INFO - 2022-06-17 09:41:43 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:43 --> Input Class Initialized
INFO - 2022-06-17 09:41:43 --> Language Class Initialized
INFO - 2022-06-17 09:41:43 --> Language Class Initialized
INFO - 2022-06-17 09:41:43 --> Config Class Initialized
INFO - 2022-06-17 09:41:43 --> Loader Class Initialized
INFO - 2022-06-17 09:41:43 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:43 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:43 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:43 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:43 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:43 --> Controller Class Initialized
INFO - 2022-06-17 09:41:45 --> Config Class Initialized
INFO - 2022-06-17 09:41:45 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:45 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:45 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:45 --> URI Class Initialized
INFO - 2022-06-17 09:41:45 --> Router Class Initialized
INFO - 2022-06-17 09:41:45 --> Output Class Initialized
INFO - 2022-06-17 09:41:45 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:45 --> Input Class Initialized
INFO - 2022-06-17 09:41:45 --> Language Class Initialized
INFO - 2022-06-17 09:41:45 --> Language Class Initialized
INFO - 2022-06-17 09:41:45 --> Config Class Initialized
INFO - 2022-06-17 09:41:45 --> Loader Class Initialized
INFO - 2022-06-17 09:41:45 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:45 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:45 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:45 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:45 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:45 --> Controller Class Initialized
INFO - 2022-06-17 09:41:47 --> Config Class Initialized
INFO - 2022-06-17 09:41:47 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:47 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:47 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:47 --> URI Class Initialized
INFO - 2022-06-17 09:41:47 --> Router Class Initialized
INFO - 2022-06-17 09:41:47 --> Output Class Initialized
INFO - 2022-06-17 09:41:47 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:47 --> Input Class Initialized
INFO - 2022-06-17 09:41:47 --> Language Class Initialized
INFO - 2022-06-17 09:41:47 --> Language Class Initialized
INFO - 2022-06-17 09:41:47 --> Config Class Initialized
INFO - 2022-06-17 09:41:47 --> Loader Class Initialized
INFO - 2022-06-17 09:41:47 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:47 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:47 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:47 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:47 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:47 --> Controller Class Initialized
INFO - 2022-06-17 09:41:51 --> Config Class Initialized
INFO - 2022-06-17 09:41:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:51 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:51 --> URI Class Initialized
INFO - 2022-06-17 09:41:51 --> Router Class Initialized
INFO - 2022-06-17 09:41:51 --> Output Class Initialized
INFO - 2022-06-17 09:41:51 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:51 --> Input Class Initialized
INFO - 2022-06-17 09:41:51 --> Language Class Initialized
INFO - 2022-06-17 09:41:51 --> Language Class Initialized
INFO - 2022-06-17 09:41:51 --> Config Class Initialized
INFO - 2022-06-17 09:41:51 --> Loader Class Initialized
INFO - 2022-06-17 09:41:51 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:51 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:51 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:51 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:51 --> Controller Class Initialized
INFO - 2022-06-17 09:41:53 --> Config Class Initialized
INFO - 2022-06-17 09:41:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:53 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:53 --> URI Class Initialized
INFO - 2022-06-17 09:41:53 --> Router Class Initialized
INFO - 2022-06-17 09:41:53 --> Output Class Initialized
INFO - 2022-06-17 09:41:53 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:53 --> Input Class Initialized
INFO - 2022-06-17 09:41:53 --> Language Class Initialized
INFO - 2022-06-17 09:41:53 --> Language Class Initialized
INFO - 2022-06-17 09:41:53 --> Config Class Initialized
INFO - 2022-06-17 09:41:53 --> Loader Class Initialized
INFO - 2022-06-17 09:41:53 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:53 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:53 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:53 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:53 --> Controller Class Initialized
INFO - 2022-06-17 09:41:56 --> Config Class Initialized
INFO - 2022-06-17 09:41:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:56 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:56 --> URI Class Initialized
INFO - 2022-06-17 09:41:56 --> Router Class Initialized
INFO - 2022-06-17 09:41:56 --> Output Class Initialized
INFO - 2022-06-17 09:41:56 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:56 --> Input Class Initialized
INFO - 2022-06-17 09:41:56 --> Language Class Initialized
INFO - 2022-06-17 09:41:56 --> Language Class Initialized
INFO - 2022-06-17 09:41:56 --> Config Class Initialized
INFO - 2022-06-17 09:41:56 --> Loader Class Initialized
INFO - 2022-06-17 09:41:56 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:56 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:56 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:56 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:56 --> Controller Class Initialized
INFO - 2022-06-17 09:41:59 --> Config Class Initialized
INFO - 2022-06-17 09:41:59 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:41:59 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:41:59 --> Utf8 Class Initialized
INFO - 2022-06-17 09:41:59 --> URI Class Initialized
INFO - 2022-06-17 09:41:59 --> Router Class Initialized
INFO - 2022-06-17 09:41:59 --> Output Class Initialized
INFO - 2022-06-17 09:41:59 --> Security Class Initialized
DEBUG - 2022-06-17 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:41:59 --> Input Class Initialized
INFO - 2022-06-17 09:41:59 --> Language Class Initialized
INFO - 2022-06-17 09:41:59 --> Language Class Initialized
INFO - 2022-06-17 09:41:59 --> Config Class Initialized
INFO - 2022-06-17 09:41:59 --> Loader Class Initialized
INFO - 2022-06-17 09:41:59 --> Helper loaded: url_helper
INFO - 2022-06-17 09:41:59 --> Helper loaded: file_helper
INFO - 2022-06-17 09:41:59 --> Helper loaded: form_helper
INFO - 2022-06-17 09:41:59 --> Helper loaded: my_helper
INFO - 2022-06-17 09:41:59 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:41:59 --> Controller Class Initialized
INFO - 2022-06-17 09:42:01 --> Config Class Initialized
INFO - 2022-06-17 09:42:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:01 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:01 --> URI Class Initialized
INFO - 2022-06-17 09:42:01 --> Router Class Initialized
INFO - 2022-06-17 09:42:01 --> Output Class Initialized
INFO - 2022-06-17 09:42:01 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:01 --> Input Class Initialized
INFO - 2022-06-17 09:42:01 --> Language Class Initialized
INFO - 2022-06-17 09:42:01 --> Language Class Initialized
INFO - 2022-06-17 09:42:01 --> Config Class Initialized
INFO - 2022-06-17 09:42:01 --> Loader Class Initialized
INFO - 2022-06-17 09:42:01 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:01 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:01 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:01 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:01 --> Controller Class Initialized
INFO - 2022-06-17 09:42:04 --> Config Class Initialized
INFO - 2022-06-17 09:42:04 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:04 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:04 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:04 --> URI Class Initialized
INFO - 2022-06-17 09:42:04 --> Router Class Initialized
INFO - 2022-06-17 09:42:04 --> Output Class Initialized
INFO - 2022-06-17 09:42:04 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:04 --> Input Class Initialized
INFO - 2022-06-17 09:42:04 --> Language Class Initialized
INFO - 2022-06-17 09:42:04 --> Language Class Initialized
INFO - 2022-06-17 09:42:04 --> Config Class Initialized
INFO - 2022-06-17 09:42:04 --> Loader Class Initialized
INFO - 2022-06-17 09:42:04 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:04 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:04 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:04 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:04 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:04 --> Controller Class Initialized
INFO - 2022-06-17 09:42:06 --> Config Class Initialized
INFO - 2022-06-17 09:42:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:06 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:06 --> URI Class Initialized
INFO - 2022-06-17 09:42:06 --> Router Class Initialized
INFO - 2022-06-17 09:42:06 --> Output Class Initialized
INFO - 2022-06-17 09:42:06 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:06 --> Input Class Initialized
INFO - 2022-06-17 09:42:06 --> Language Class Initialized
INFO - 2022-06-17 09:42:06 --> Language Class Initialized
INFO - 2022-06-17 09:42:06 --> Config Class Initialized
INFO - 2022-06-17 09:42:06 --> Loader Class Initialized
INFO - 2022-06-17 09:42:06 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:06 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:06 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:06 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:06 --> Controller Class Initialized
INFO - 2022-06-17 09:42:08 --> Config Class Initialized
INFO - 2022-06-17 09:42:08 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:08 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:08 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:08 --> URI Class Initialized
INFO - 2022-06-17 09:42:08 --> Router Class Initialized
INFO - 2022-06-17 09:42:08 --> Output Class Initialized
INFO - 2022-06-17 09:42:08 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:08 --> Input Class Initialized
INFO - 2022-06-17 09:42:08 --> Language Class Initialized
INFO - 2022-06-17 09:42:08 --> Language Class Initialized
INFO - 2022-06-17 09:42:08 --> Config Class Initialized
INFO - 2022-06-17 09:42:08 --> Loader Class Initialized
INFO - 2022-06-17 09:42:08 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:08 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:08 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:08 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:08 --> Controller Class Initialized
INFO - 2022-06-17 09:42:10 --> Config Class Initialized
INFO - 2022-06-17 09:42:10 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:10 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:10 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:10 --> URI Class Initialized
INFO - 2022-06-17 09:42:10 --> Router Class Initialized
INFO - 2022-06-17 09:42:10 --> Output Class Initialized
INFO - 2022-06-17 09:42:10 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:10 --> Input Class Initialized
INFO - 2022-06-17 09:42:10 --> Language Class Initialized
INFO - 2022-06-17 09:42:10 --> Language Class Initialized
INFO - 2022-06-17 09:42:10 --> Config Class Initialized
INFO - 2022-06-17 09:42:10 --> Loader Class Initialized
INFO - 2022-06-17 09:42:10 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:10 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:10 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:10 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:10 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:10 --> Controller Class Initialized
INFO - 2022-06-17 09:42:12 --> Config Class Initialized
INFO - 2022-06-17 09:42:12 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:12 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:12 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:12 --> URI Class Initialized
INFO - 2022-06-17 09:42:12 --> Router Class Initialized
INFO - 2022-06-17 09:42:12 --> Output Class Initialized
INFO - 2022-06-17 09:42:12 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:12 --> Input Class Initialized
INFO - 2022-06-17 09:42:12 --> Language Class Initialized
INFO - 2022-06-17 09:42:12 --> Language Class Initialized
INFO - 2022-06-17 09:42:12 --> Config Class Initialized
INFO - 2022-06-17 09:42:12 --> Loader Class Initialized
INFO - 2022-06-17 09:42:12 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:12 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:12 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:12 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:12 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:12 --> Controller Class Initialized
INFO - 2022-06-17 09:42:14 --> Config Class Initialized
INFO - 2022-06-17 09:42:14 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:14 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:14 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:14 --> URI Class Initialized
INFO - 2022-06-17 09:42:14 --> Router Class Initialized
INFO - 2022-06-17 09:42:14 --> Output Class Initialized
INFO - 2022-06-17 09:42:14 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:14 --> Input Class Initialized
INFO - 2022-06-17 09:42:14 --> Language Class Initialized
INFO - 2022-06-17 09:42:14 --> Language Class Initialized
INFO - 2022-06-17 09:42:14 --> Config Class Initialized
INFO - 2022-06-17 09:42:14 --> Loader Class Initialized
INFO - 2022-06-17 09:42:14 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:14 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:14 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:14 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:14 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:14 --> Controller Class Initialized
INFO - 2022-06-17 09:42:16 --> Config Class Initialized
INFO - 2022-06-17 09:42:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:16 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:16 --> URI Class Initialized
INFO - 2022-06-17 09:42:16 --> Router Class Initialized
INFO - 2022-06-17 09:42:16 --> Output Class Initialized
INFO - 2022-06-17 09:42:16 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:16 --> Input Class Initialized
INFO - 2022-06-17 09:42:16 --> Language Class Initialized
INFO - 2022-06-17 09:42:16 --> Language Class Initialized
INFO - 2022-06-17 09:42:16 --> Config Class Initialized
INFO - 2022-06-17 09:42:16 --> Loader Class Initialized
INFO - 2022-06-17 09:42:16 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:16 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:16 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:16 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:16 --> Controller Class Initialized
INFO - 2022-06-17 09:42:17 --> Config Class Initialized
INFO - 2022-06-17 09:42:17 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:17 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:17 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:17 --> URI Class Initialized
INFO - 2022-06-17 09:42:17 --> Router Class Initialized
INFO - 2022-06-17 09:42:17 --> Output Class Initialized
INFO - 2022-06-17 09:42:17 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:17 --> Input Class Initialized
INFO - 2022-06-17 09:42:17 --> Language Class Initialized
INFO - 2022-06-17 09:42:17 --> Language Class Initialized
INFO - 2022-06-17 09:42:17 --> Config Class Initialized
INFO - 2022-06-17 09:42:17 --> Loader Class Initialized
INFO - 2022-06-17 09:42:17 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:17 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:17 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:17 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:17 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:17 --> Controller Class Initialized
INFO - 2022-06-17 09:42:19 --> Config Class Initialized
INFO - 2022-06-17 09:42:19 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:19 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:19 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:19 --> URI Class Initialized
INFO - 2022-06-17 09:42:19 --> Router Class Initialized
INFO - 2022-06-17 09:42:19 --> Output Class Initialized
INFO - 2022-06-17 09:42:19 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:19 --> Input Class Initialized
INFO - 2022-06-17 09:42:19 --> Language Class Initialized
INFO - 2022-06-17 09:42:19 --> Language Class Initialized
INFO - 2022-06-17 09:42:19 --> Config Class Initialized
INFO - 2022-06-17 09:42:19 --> Loader Class Initialized
INFO - 2022-06-17 09:42:19 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:19 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:19 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:19 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:19 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:19 --> Controller Class Initialized
INFO - 2022-06-17 09:42:21 --> Config Class Initialized
INFO - 2022-06-17 09:42:21 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:21 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:21 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:21 --> URI Class Initialized
INFO - 2022-06-17 09:42:21 --> Router Class Initialized
INFO - 2022-06-17 09:42:21 --> Output Class Initialized
INFO - 2022-06-17 09:42:21 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:21 --> Input Class Initialized
INFO - 2022-06-17 09:42:21 --> Language Class Initialized
INFO - 2022-06-17 09:42:21 --> Language Class Initialized
INFO - 2022-06-17 09:42:21 --> Config Class Initialized
INFO - 2022-06-17 09:42:21 --> Loader Class Initialized
INFO - 2022-06-17 09:42:21 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:21 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:21 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:21 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:21 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:21 --> Controller Class Initialized
INFO - 2022-06-17 09:42:22 --> Config Class Initialized
INFO - 2022-06-17 09:42:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:22 --> URI Class Initialized
INFO - 2022-06-17 09:42:22 --> Router Class Initialized
INFO - 2022-06-17 09:42:22 --> Output Class Initialized
INFO - 2022-06-17 09:42:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:22 --> Input Class Initialized
INFO - 2022-06-17 09:42:22 --> Language Class Initialized
INFO - 2022-06-17 09:42:22 --> Language Class Initialized
INFO - 2022-06-17 09:42:22 --> Config Class Initialized
INFO - 2022-06-17 09:42:22 --> Loader Class Initialized
INFO - 2022-06-17 09:42:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:22 --> Controller Class Initialized
INFO - 2022-06-17 09:42:24 --> Config Class Initialized
INFO - 2022-06-17 09:42:24 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:24 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:24 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:24 --> URI Class Initialized
INFO - 2022-06-17 09:42:24 --> Router Class Initialized
INFO - 2022-06-17 09:42:24 --> Output Class Initialized
INFO - 2022-06-17 09:42:24 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:24 --> Input Class Initialized
INFO - 2022-06-17 09:42:24 --> Language Class Initialized
INFO - 2022-06-17 09:42:24 --> Language Class Initialized
INFO - 2022-06-17 09:42:24 --> Config Class Initialized
INFO - 2022-06-17 09:42:24 --> Loader Class Initialized
INFO - 2022-06-17 09:42:24 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:24 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:24 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:24 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:24 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:24 --> Controller Class Initialized
INFO - 2022-06-17 09:42:26 --> Config Class Initialized
INFO - 2022-06-17 09:42:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:26 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:26 --> URI Class Initialized
INFO - 2022-06-17 09:42:26 --> Router Class Initialized
INFO - 2022-06-17 09:42:26 --> Output Class Initialized
INFO - 2022-06-17 09:42:26 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:26 --> Input Class Initialized
INFO - 2022-06-17 09:42:26 --> Language Class Initialized
INFO - 2022-06-17 09:42:26 --> Language Class Initialized
INFO - 2022-06-17 09:42:26 --> Config Class Initialized
INFO - 2022-06-17 09:42:26 --> Loader Class Initialized
INFO - 2022-06-17 09:42:26 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:26 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:26 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:26 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:26 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:26 --> Controller Class Initialized
INFO - 2022-06-17 09:42:27 --> Config Class Initialized
INFO - 2022-06-17 09:42:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:27 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:27 --> URI Class Initialized
INFO - 2022-06-17 09:42:27 --> Router Class Initialized
INFO - 2022-06-17 09:42:27 --> Output Class Initialized
INFO - 2022-06-17 09:42:27 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:27 --> Input Class Initialized
INFO - 2022-06-17 09:42:27 --> Language Class Initialized
INFO - 2022-06-17 09:42:27 --> Language Class Initialized
INFO - 2022-06-17 09:42:27 --> Config Class Initialized
INFO - 2022-06-17 09:42:27 --> Loader Class Initialized
INFO - 2022-06-17 09:42:27 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:27 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:27 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:27 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:27 --> Controller Class Initialized
INFO - 2022-06-17 09:42:29 --> Config Class Initialized
INFO - 2022-06-17 09:42:29 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:29 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:29 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:29 --> URI Class Initialized
INFO - 2022-06-17 09:42:29 --> Router Class Initialized
INFO - 2022-06-17 09:42:29 --> Output Class Initialized
INFO - 2022-06-17 09:42:29 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:29 --> Input Class Initialized
INFO - 2022-06-17 09:42:29 --> Language Class Initialized
INFO - 2022-06-17 09:42:29 --> Language Class Initialized
INFO - 2022-06-17 09:42:29 --> Config Class Initialized
INFO - 2022-06-17 09:42:29 --> Loader Class Initialized
INFO - 2022-06-17 09:42:29 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:29 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:29 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:29 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:29 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:29 --> Controller Class Initialized
INFO - 2022-06-17 09:42:30 --> Config Class Initialized
INFO - 2022-06-17 09:42:30 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:30 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:30 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:30 --> URI Class Initialized
INFO - 2022-06-17 09:42:30 --> Router Class Initialized
INFO - 2022-06-17 09:42:30 --> Output Class Initialized
INFO - 2022-06-17 09:42:30 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:30 --> Input Class Initialized
INFO - 2022-06-17 09:42:30 --> Language Class Initialized
INFO - 2022-06-17 09:42:30 --> Language Class Initialized
INFO - 2022-06-17 09:42:30 --> Config Class Initialized
INFO - 2022-06-17 09:42:30 --> Loader Class Initialized
INFO - 2022-06-17 09:42:30 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:30 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:30 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:30 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:30 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:31 --> Controller Class Initialized
INFO - 2022-06-17 09:42:32 --> Config Class Initialized
INFO - 2022-06-17 09:42:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:32 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:32 --> URI Class Initialized
INFO - 2022-06-17 09:42:32 --> Router Class Initialized
INFO - 2022-06-17 09:42:32 --> Output Class Initialized
INFO - 2022-06-17 09:42:32 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:32 --> Input Class Initialized
INFO - 2022-06-17 09:42:32 --> Language Class Initialized
INFO - 2022-06-17 09:42:32 --> Language Class Initialized
INFO - 2022-06-17 09:42:32 --> Config Class Initialized
INFO - 2022-06-17 09:42:32 --> Loader Class Initialized
INFO - 2022-06-17 09:42:32 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:32 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:32 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:32 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:32 --> Controller Class Initialized
INFO - 2022-06-17 09:42:34 --> Config Class Initialized
INFO - 2022-06-17 09:42:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:34 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:34 --> URI Class Initialized
INFO - 2022-06-17 09:42:34 --> Router Class Initialized
INFO - 2022-06-17 09:42:34 --> Output Class Initialized
INFO - 2022-06-17 09:42:34 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:34 --> Input Class Initialized
INFO - 2022-06-17 09:42:34 --> Language Class Initialized
INFO - 2022-06-17 09:42:34 --> Language Class Initialized
INFO - 2022-06-17 09:42:34 --> Config Class Initialized
INFO - 2022-06-17 09:42:34 --> Loader Class Initialized
INFO - 2022-06-17 09:42:34 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:34 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:34 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:34 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:34 --> Controller Class Initialized
INFO - 2022-06-17 09:42:36 --> Config Class Initialized
INFO - 2022-06-17 09:42:36 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:42:36 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:42:36 --> Utf8 Class Initialized
INFO - 2022-06-17 09:42:36 --> URI Class Initialized
INFO - 2022-06-17 09:42:36 --> Router Class Initialized
INFO - 2022-06-17 09:42:36 --> Output Class Initialized
INFO - 2022-06-17 09:42:36 --> Security Class Initialized
DEBUG - 2022-06-17 09:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:42:36 --> Input Class Initialized
INFO - 2022-06-17 09:42:36 --> Language Class Initialized
INFO - 2022-06-17 09:42:36 --> Language Class Initialized
INFO - 2022-06-17 09:42:36 --> Config Class Initialized
INFO - 2022-06-17 09:42:36 --> Loader Class Initialized
INFO - 2022-06-17 09:42:36 --> Helper loaded: url_helper
INFO - 2022-06-17 09:42:36 --> Helper loaded: file_helper
INFO - 2022-06-17 09:42:36 --> Helper loaded: form_helper
INFO - 2022-06-17 09:42:36 --> Helper loaded: my_helper
INFO - 2022-06-17 09:42:36 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:42:36 --> Controller Class Initialized
INFO - 2022-06-17 09:44:22 --> Config Class Initialized
INFO - 2022-06-17 09:44:22 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:44:22 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:44:22 --> Utf8 Class Initialized
INFO - 2022-06-17 09:44:22 --> URI Class Initialized
INFO - 2022-06-17 09:44:22 --> Router Class Initialized
INFO - 2022-06-17 09:44:22 --> Output Class Initialized
INFO - 2022-06-17 09:44:22 --> Security Class Initialized
DEBUG - 2022-06-17 09:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:44:22 --> Input Class Initialized
INFO - 2022-06-17 09:44:22 --> Language Class Initialized
INFO - 2022-06-17 09:44:22 --> Language Class Initialized
INFO - 2022-06-17 09:44:22 --> Config Class Initialized
INFO - 2022-06-17 09:44:22 --> Loader Class Initialized
INFO - 2022-06-17 09:44:22 --> Helper loaded: url_helper
INFO - 2022-06-17 09:44:22 --> Helper loaded: file_helper
INFO - 2022-06-17 09:44:22 --> Helper loaded: form_helper
INFO - 2022-06-17 09:44:22 --> Helper loaded: my_helper
INFO - 2022-06-17 09:44:22 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:44:22 --> Controller Class Initialized
INFO - 2022-06-17 09:44:22 --> Final output sent to browser
DEBUG - 2022-06-17 09:44:22 --> Total execution time: 0.1091
INFO - 2022-06-17 09:49:32 --> Config Class Initialized
INFO - 2022-06-17 09:49:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:49:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:49:32 --> Utf8 Class Initialized
INFO - 2022-06-17 09:49:32 --> URI Class Initialized
INFO - 2022-06-17 09:49:32 --> Router Class Initialized
INFO - 2022-06-17 09:49:32 --> Output Class Initialized
INFO - 2022-06-17 09:49:32 --> Security Class Initialized
DEBUG - 2022-06-17 09:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:49:32 --> Input Class Initialized
INFO - 2022-06-17 09:49:32 --> Language Class Initialized
INFO - 2022-06-17 09:49:32 --> Language Class Initialized
INFO - 2022-06-17 09:49:32 --> Config Class Initialized
INFO - 2022-06-17 09:49:32 --> Loader Class Initialized
INFO - 2022-06-17 09:49:32 --> Helper loaded: url_helper
INFO - 2022-06-17 09:49:32 --> Helper loaded: file_helper
INFO - 2022-06-17 09:49:32 --> Helper loaded: form_helper
INFO - 2022-06-17 09:49:32 --> Helper loaded: my_helper
INFO - 2022-06-17 09:49:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:49:32 --> Controller Class Initialized
INFO - 2022-06-17 09:49:32 --> Final output sent to browser
DEBUG - 2022-06-17 09:49:32 --> Total execution time: 0.1059
INFO - 2022-06-17 09:49:41 --> Config Class Initialized
INFO - 2022-06-17 09:49:41 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:49:41 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:49:41 --> Utf8 Class Initialized
INFO - 2022-06-17 09:49:41 --> URI Class Initialized
INFO - 2022-06-17 09:49:41 --> Router Class Initialized
INFO - 2022-06-17 09:49:41 --> Output Class Initialized
INFO - 2022-06-17 09:49:41 --> Security Class Initialized
DEBUG - 2022-06-17 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:49:41 --> Input Class Initialized
INFO - 2022-06-17 09:49:41 --> Language Class Initialized
INFO - 2022-06-17 09:49:41 --> Language Class Initialized
INFO - 2022-06-17 09:49:41 --> Config Class Initialized
INFO - 2022-06-17 09:49:41 --> Loader Class Initialized
INFO - 2022-06-17 09:49:41 --> Helper loaded: url_helper
INFO - 2022-06-17 09:49:41 --> Helper loaded: file_helper
INFO - 2022-06-17 09:49:41 --> Helper loaded: form_helper
INFO - 2022-06-17 09:49:41 --> Helper loaded: my_helper
INFO - 2022-06-17 09:49:41 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:49:41 --> Controller Class Initialized
DEBUG - 2022-06-17 09:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-06-17 09:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:49:41 --> Final output sent to browser
DEBUG - 2022-06-17 09:49:41 --> Total execution time: 0.0822
INFO - 2022-06-17 09:49:46 --> Config Class Initialized
INFO - 2022-06-17 09:49:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:49:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:49:46 --> Utf8 Class Initialized
INFO - 2022-06-17 09:49:46 --> URI Class Initialized
INFO - 2022-06-17 09:49:46 --> Router Class Initialized
INFO - 2022-06-17 09:49:46 --> Output Class Initialized
INFO - 2022-06-17 09:49:46 --> Security Class Initialized
DEBUG - 2022-06-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:49:46 --> Input Class Initialized
INFO - 2022-06-17 09:49:46 --> Language Class Initialized
INFO - 2022-06-17 09:49:46 --> Language Class Initialized
INFO - 2022-06-17 09:49:46 --> Config Class Initialized
INFO - 2022-06-17 09:49:46 --> Loader Class Initialized
INFO - 2022-06-17 09:49:46 --> Helper loaded: url_helper
INFO - 2022-06-17 09:49:46 --> Helper loaded: file_helper
INFO - 2022-06-17 09:49:46 --> Helper loaded: form_helper
INFO - 2022-06-17 09:49:46 --> Helper loaded: my_helper
INFO - 2022-06-17 09:49:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:49:46 --> Controller Class Initialized
DEBUG - 2022-06-17 09:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-06-17 09:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:49:46 --> Final output sent to browser
DEBUG - 2022-06-17 09:49:46 --> Total execution time: 0.1918
INFO - 2022-06-17 09:49:46 --> Config Class Initialized
INFO - 2022-06-17 09:49:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:49:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:49:46 --> Utf8 Class Initialized
INFO - 2022-06-17 09:49:46 --> URI Class Initialized
INFO - 2022-06-17 09:49:46 --> Router Class Initialized
INFO - 2022-06-17 09:49:46 --> Output Class Initialized
INFO - 2022-06-17 09:49:46 --> Security Class Initialized
DEBUG - 2022-06-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:49:46 --> Input Class Initialized
INFO - 2022-06-17 09:49:46 --> Language Class Initialized
INFO - 2022-06-17 09:49:46 --> Language Class Initialized
INFO - 2022-06-17 09:49:46 --> Config Class Initialized
INFO - 2022-06-17 09:49:46 --> Loader Class Initialized
INFO - 2022-06-17 09:49:46 --> Helper loaded: url_helper
INFO - 2022-06-17 09:49:46 --> Helper loaded: file_helper
INFO - 2022-06-17 09:49:46 --> Helper loaded: form_helper
INFO - 2022-06-17 09:49:46 --> Helper loaded: my_helper
INFO - 2022-06-17 09:49:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:49:46 --> Controller Class Initialized
DEBUG - 2022-06-17 09:49:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-06-17 09:49:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 09:49:47 --> Final output sent to browser
DEBUG - 2022-06-17 09:49:47 --> Total execution time: 0.1170
INFO - 2022-06-17 09:52:44 --> Config Class Initialized
INFO - 2022-06-17 09:52:44 --> Hooks Class Initialized
DEBUG - 2022-06-17 09:52:44 --> UTF-8 Support Enabled
INFO - 2022-06-17 09:52:44 --> Utf8 Class Initialized
INFO - 2022-06-17 09:52:44 --> URI Class Initialized
INFO - 2022-06-17 09:52:44 --> Router Class Initialized
INFO - 2022-06-17 09:52:44 --> Output Class Initialized
INFO - 2022-06-17 09:52:44 --> Security Class Initialized
DEBUG - 2022-06-17 09:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 09:52:44 --> Input Class Initialized
INFO - 2022-06-17 09:52:44 --> Language Class Initialized
INFO - 2022-06-17 09:52:44 --> Language Class Initialized
INFO - 2022-06-17 09:52:44 --> Config Class Initialized
INFO - 2022-06-17 09:52:44 --> Loader Class Initialized
INFO - 2022-06-17 09:52:44 --> Helper loaded: url_helper
INFO - 2022-06-17 09:52:44 --> Helper loaded: file_helper
INFO - 2022-06-17 09:52:44 --> Helper loaded: form_helper
INFO - 2022-06-17 09:52:44 --> Helper loaded: my_helper
INFO - 2022-06-17 09:52:44 --> Database Driver Class Initialized
DEBUG - 2022-06-17 09:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 09:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 09:52:44 --> Controller Class Initialized
INFO - 2022-06-17 09:52:44 --> Final output sent to browser
DEBUG - 2022-06-17 09:52:44 --> Total execution time: 0.0934
INFO - 2022-06-17 10:25:23 --> Config Class Initialized
INFO - 2022-06-17 10:25:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:23 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:23 --> URI Class Initialized
INFO - 2022-06-17 10:25:23 --> Router Class Initialized
INFO - 2022-06-17 10:25:23 --> Output Class Initialized
INFO - 2022-06-17 10:25:23 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:23 --> Input Class Initialized
INFO - 2022-06-17 10:25:23 --> Language Class Initialized
INFO - 2022-06-17 10:25:23 --> Language Class Initialized
INFO - 2022-06-17 10:25:23 --> Config Class Initialized
INFO - 2022-06-17 10:25:23 --> Loader Class Initialized
INFO - 2022-06-17 10:25:23 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:23 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:23 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:23 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:23 --> Controller Class Initialized
INFO - 2022-06-17 10:25:23 --> Helper loaded: cookie_helper
INFO - 2022-06-17 10:25:23 --> Config Class Initialized
INFO - 2022-06-17 10:25:23 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:23 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:23 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:23 --> URI Class Initialized
INFO - 2022-06-17 10:25:23 --> Router Class Initialized
INFO - 2022-06-17 10:25:23 --> Output Class Initialized
INFO - 2022-06-17 10:25:23 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:23 --> Input Class Initialized
INFO - 2022-06-17 10:25:23 --> Language Class Initialized
INFO - 2022-06-17 10:25:23 --> Language Class Initialized
INFO - 2022-06-17 10:25:23 --> Config Class Initialized
INFO - 2022-06-17 10:25:23 --> Loader Class Initialized
INFO - 2022-06-17 10:25:23 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:23 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:23 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:23 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:23 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:23 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-17 10:25:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:23 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:23 --> Total execution time: 0.0517
INFO - 2022-06-17 10:25:26 --> Config Class Initialized
INFO - 2022-06-17 10:25:26 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:26 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:26 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:26 --> URI Class Initialized
INFO - 2022-06-17 10:25:26 --> Router Class Initialized
INFO - 2022-06-17 10:25:26 --> Output Class Initialized
INFO - 2022-06-17 10:25:26 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:26 --> Input Class Initialized
INFO - 2022-06-17 10:25:26 --> Language Class Initialized
INFO - 2022-06-17 10:25:26 --> Language Class Initialized
INFO - 2022-06-17 10:25:26 --> Config Class Initialized
INFO - 2022-06-17 10:25:26 --> Loader Class Initialized
INFO - 2022-06-17 10:25:26 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:26 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:27 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:27 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:27 --> Controller Class Initialized
INFO - 2022-06-17 10:25:27 --> Helper loaded: cookie_helper
INFO - 2022-06-17 10:25:27 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:27 --> Total execution time: 0.0538
INFO - 2022-06-17 10:25:27 --> Config Class Initialized
INFO - 2022-06-17 10:25:27 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:27 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:27 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:27 --> URI Class Initialized
INFO - 2022-06-17 10:25:27 --> Router Class Initialized
INFO - 2022-06-17 10:25:27 --> Output Class Initialized
INFO - 2022-06-17 10:25:27 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:27 --> Input Class Initialized
INFO - 2022-06-17 10:25:27 --> Language Class Initialized
INFO - 2022-06-17 10:25:27 --> Language Class Initialized
INFO - 2022-06-17 10:25:27 --> Config Class Initialized
INFO - 2022-06-17 10:25:27 --> Loader Class Initialized
INFO - 2022-06-17 10:25:27 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:27 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:27 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:27 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:27 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:27 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-17 10:25:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:27 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:27 --> Total execution time: 0.1020
INFO - 2022-06-17 10:25:28 --> Config Class Initialized
INFO - 2022-06-17 10:25:28 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:28 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:28 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:28 --> URI Class Initialized
INFO - 2022-06-17 10:25:28 --> Router Class Initialized
INFO - 2022-06-17 10:25:28 --> Output Class Initialized
INFO - 2022-06-17 10:25:28 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:28 --> Input Class Initialized
INFO - 2022-06-17 10:25:28 --> Language Class Initialized
INFO - 2022-06-17 10:25:28 --> Language Class Initialized
INFO - 2022-06-17 10:25:28 --> Config Class Initialized
INFO - 2022-06-17 10:25:28 --> Loader Class Initialized
INFO - 2022-06-17 10:25:28 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:28 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:28 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:28 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:28 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:28 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-17 10:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:28 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:28 --> Total execution time: 0.0438
INFO - 2022-06-17 10:25:32 --> Config Class Initialized
INFO - 2022-06-17 10:25:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:32 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:32 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:32 --> URI Class Initialized
INFO - 2022-06-17 10:25:32 --> Router Class Initialized
INFO - 2022-06-17 10:25:32 --> Output Class Initialized
INFO - 2022-06-17 10:25:32 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:32 --> Input Class Initialized
INFO - 2022-06-17 10:25:32 --> Language Class Initialized
INFO - 2022-06-17 10:25:32 --> Language Class Initialized
INFO - 2022-06-17 10:25:32 --> Config Class Initialized
INFO - 2022-06-17 10:25:32 --> Loader Class Initialized
INFO - 2022-06-17 10:25:32 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:32 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:32 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:32 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:32 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:32 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 10:25:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:32 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:32 --> Total execution time: 0.0493
INFO - 2022-06-17 10:25:32 --> Config Class Initialized
INFO - 2022-06-17 10:25:32 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:33 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:33 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:33 --> URI Class Initialized
INFO - 2022-06-17 10:25:33 --> Router Class Initialized
INFO - 2022-06-17 10:25:33 --> Output Class Initialized
INFO - 2022-06-17 10:25:33 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:33 --> Input Class Initialized
INFO - 2022-06-17 10:25:33 --> Language Class Initialized
INFO - 2022-06-17 10:25:33 --> Language Class Initialized
INFO - 2022-06-17 10:25:33 --> Config Class Initialized
INFO - 2022-06-17 10:25:33 --> Loader Class Initialized
INFO - 2022-06-17 10:25:33 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:33 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:33 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:33 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:33 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:33 --> Controller Class Initialized
INFO - 2022-06-17 10:25:34 --> Config Class Initialized
INFO - 2022-06-17 10:25:34 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:34 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:34 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:34 --> URI Class Initialized
INFO - 2022-06-17 10:25:34 --> Router Class Initialized
INFO - 2022-06-17 10:25:34 --> Output Class Initialized
INFO - 2022-06-17 10:25:34 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:34 --> Input Class Initialized
INFO - 2022-06-17 10:25:34 --> Language Class Initialized
INFO - 2022-06-17 10:25:34 --> Language Class Initialized
INFO - 2022-06-17 10:25:34 --> Config Class Initialized
INFO - 2022-06-17 10:25:34 --> Loader Class Initialized
INFO - 2022-06-17 10:25:34 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:34 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:34 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:34 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:34 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:34 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 10:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:34 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:34 --> Total execution time: 0.0456
INFO - 2022-06-17 10:25:35 --> Config Class Initialized
INFO - 2022-06-17 10:25:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:35 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:35 --> URI Class Initialized
INFO - 2022-06-17 10:25:35 --> Router Class Initialized
INFO - 2022-06-17 10:25:35 --> Output Class Initialized
INFO - 2022-06-17 10:25:35 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:35 --> Input Class Initialized
INFO - 2022-06-17 10:25:35 --> Language Class Initialized
INFO - 2022-06-17 10:25:35 --> Language Class Initialized
INFO - 2022-06-17 10:25:35 --> Config Class Initialized
INFO - 2022-06-17 10:25:35 --> Loader Class Initialized
INFO - 2022-06-17 10:25:35 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:35 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:35 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:35 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:35 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 10:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:35 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:35 --> Total execution time: 0.0463
INFO - 2022-06-17 10:25:35 --> Config Class Initialized
INFO - 2022-06-17 10:25:35 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:35 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:35 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:35 --> URI Class Initialized
INFO - 2022-06-17 10:25:35 --> Router Class Initialized
INFO - 2022-06-17 10:25:35 --> Output Class Initialized
INFO - 2022-06-17 10:25:35 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:35 --> Input Class Initialized
INFO - 2022-06-17 10:25:35 --> Language Class Initialized
INFO - 2022-06-17 10:25:35 --> Language Class Initialized
INFO - 2022-06-17 10:25:35 --> Config Class Initialized
INFO - 2022-06-17 10:25:35 --> Loader Class Initialized
INFO - 2022-06-17 10:25:35 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:35 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:35 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:35 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:35 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:35 --> Controller Class Initialized
INFO - 2022-06-17 10:25:36 --> Config Class Initialized
INFO - 2022-06-17 10:25:36 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:36 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:36 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:36 --> URI Class Initialized
INFO - 2022-06-17 10:25:36 --> Router Class Initialized
INFO - 2022-06-17 10:25:36 --> Output Class Initialized
INFO - 2022-06-17 10:25:36 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:36 --> Input Class Initialized
INFO - 2022-06-17 10:25:36 --> Language Class Initialized
INFO - 2022-06-17 10:25:36 --> Language Class Initialized
INFO - 2022-06-17 10:25:36 --> Config Class Initialized
INFO - 2022-06-17 10:25:36 --> Loader Class Initialized
INFO - 2022-06-17 10:25:36 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:36 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:36 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:36 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:36 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:36 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 10:25:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:36 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:36 --> Total execution time: 0.0458
INFO - 2022-06-17 10:25:37 --> Config Class Initialized
INFO - 2022-06-17 10:25:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:37 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:37 --> URI Class Initialized
INFO - 2022-06-17 10:25:37 --> Router Class Initialized
INFO - 2022-06-17 10:25:37 --> Output Class Initialized
INFO - 2022-06-17 10:25:37 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:37 --> Input Class Initialized
INFO - 2022-06-17 10:25:37 --> Language Class Initialized
INFO - 2022-06-17 10:25:37 --> Language Class Initialized
INFO - 2022-06-17 10:25:37 --> Config Class Initialized
INFO - 2022-06-17 10:25:37 --> Loader Class Initialized
INFO - 2022-06-17 10:25:37 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:37 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:37 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:37 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:37 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 10:25:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:37 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:37 --> Total execution time: 0.0461
INFO - 2022-06-17 10:25:37 --> Config Class Initialized
INFO - 2022-06-17 10:25:37 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:37 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:37 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:37 --> URI Class Initialized
INFO - 2022-06-17 10:25:37 --> Router Class Initialized
INFO - 2022-06-17 10:25:37 --> Output Class Initialized
INFO - 2022-06-17 10:25:37 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:37 --> Input Class Initialized
INFO - 2022-06-17 10:25:37 --> Language Class Initialized
INFO - 2022-06-17 10:25:37 --> Language Class Initialized
INFO - 2022-06-17 10:25:37 --> Config Class Initialized
INFO - 2022-06-17 10:25:37 --> Loader Class Initialized
INFO - 2022-06-17 10:25:37 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:37 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:37 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:37 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:37 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:37 --> Controller Class Initialized
INFO - 2022-06-17 10:25:38 --> Config Class Initialized
INFO - 2022-06-17 10:25:38 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:38 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:38 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:38 --> URI Class Initialized
INFO - 2022-06-17 10:25:38 --> Router Class Initialized
INFO - 2022-06-17 10:25:38 --> Output Class Initialized
INFO - 2022-06-17 10:25:38 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:38 --> Input Class Initialized
INFO - 2022-06-17 10:25:38 --> Language Class Initialized
INFO - 2022-06-17 10:25:38 --> Language Class Initialized
INFO - 2022-06-17 10:25:38 --> Config Class Initialized
INFO - 2022-06-17 10:25:38 --> Loader Class Initialized
INFO - 2022-06-17 10:25:38 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:38 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:38 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:38 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:38 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:38 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 10:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:38 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:38 --> Total execution time: 0.0450
INFO - 2022-06-17 10:25:40 --> Config Class Initialized
INFO - 2022-06-17 10:25:40 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:40 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:40 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:40 --> URI Class Initialized
INFO - 2022-06-17 10:25:40 --> Router Class Initialized
INFO - 2022-06-17 10:25:40 --> Output Class Initialized
INFO - 2022-06-17 10:25:40 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:40 --> Input Class Initialized
INFO - 2022-06-17 10:25:40 --> Language Class Initialized
INFO - 2022-06-17 10:25:40 --> Language Class Initialized
INFO - 2022-06-17 10:25:40 --> Config Class Initialized
INFO - 2022-06-17 10:25:40 --> Loader Class Initialized
INFO - 2022-06-17 10:25:40 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:40 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:40 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:40 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:40 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:40 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 10:25:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:40 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:40 --> Total execution time: 0.0433
INFO - 2022-06-17 10:25:46 --> Config Class Initialized
INFO - 2022-06-17 10:25:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:46 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:46 --> URI Class Initialized
INFO - 2022-06-17 10:25:46 --> Router Class Initialized
INFO - 2022-06-17 10:25:46 --> Output Class Initialized
INFO - 2022-06-17 10:25:46 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:46 --> Input Class Initialized
INFO - 2022-06-17 10:25:46 --> Language Class Initialized
INFO - 2022-06-17 10:25:46 --> Language Class Initialized
INFO - 2022-06-17 10:25:46 --> Config Class Initialized
INFO - 2022-06-17 10:25:46 --> Loader Class Initialized
INFO - 2022-06-17 10:25:46 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:46 --> Controller Class Initialized
INFO - 2022-06-17 10:25:46 --> Config Class Initialized
INFO - 2022-06-17 10:25:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:46 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:46 --> URI Class Initialized
INFO - 2022-06-17 10:25:46 --> Router Class Initialized
INFO - 2022-06-17 10:25:46 --> Output Class Initialized
INFO - 2022-06-17 10:25:46 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:46 --> Input Class Initialized
INFO - 2022-06-17 10:25:46 --> Language Class Initialized
INFO - 2022-06-17 10:25:46 --> Language Class Initialized
INFO - 2022-06-17 10:25:46 --> Config Class Initialized
INFO - 2022-06-17 10:25:46 --> Loader Class Initialized
INFO - 2022-06-17 10:25:46 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:46 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 10:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:46 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:46 --> Total execution time: 0.0535
INFO - 2022-06-17 10:25:46 --> Config Class Initialized
INFO - 2022-06-17 10:25:46 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:46 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:46 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:46 --> URI Class Initialized
INFO - 2022-06-17 10:25:46 --> Router Class Initialized
INFO - 2022-06-17 10:25:46 --> Output Class Initialized
INFO - 2022-06-17 10:25:46 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:46 --> Input Class Initialized
INFO - 2022-06-17 10:25:46 --> Language Class Initialized
INFO - 2022-06-17 10:25:46 --> Language Class Initialized
INFO - 2022-06-17 10:25:46 --> Config Class Initialized
INFO - 2022-06-17 10:25:46 --> Loader Class Initialized
INFO - 2022-06-17 10:25:46 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:46 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:46 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:46 --> Controller Class Initialized
INFO - 2022-06-17 10:25:48 --> Config Class Initialized
INFO - 2022-06-17 10:25:48 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:48 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:48 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:48 --> URI Class Initialized
INFO - 2022-06-17 10:25:48 --> Router Class Initialized
INFO - 2022-06-17 10:25:48 --> Output Class Initialized
INFO - 2022-06-17 10:25:48 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:48 --> Input Class Initialized
INFO - 2022-06-17 10:25:48 --> Language Class Initialized
INFO - 2022-06-17 10:25:48 --> Language Class Initialized
INFO - 2022-06-17 10:25:48 --> Config Class Initialized
INFO - 2022-06-17 10:25:48 --> Loader Class Initialized
INFO - 2022-06-17 10:25:48 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:48 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:48 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:48 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:48 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:48 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 10:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:48 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:48 --> Total execution time: 0.0442
INFO - 2022-06-17 10:25:51 --> Config Class Initialized
INFO - 2022-06-17 10:25:51 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:51 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:51 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:51 --> URI Class Initialized
INFO - 2022-06-17 10:25:51 --> Router Class Initialized
INFO - 2022-06-17 10:25:51 --> Output Class Initialized
INFO - 2022-06-17 10:25:51 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:51 --> Input Class Initialized
INFO - 2022-06-17 10:25:51 --> Language Class Initialized
INFO - 2022-06-17 10:25:51 --> Language Class Initialized
INFO - 2022-06-17 10:25:51 --> Config Class Initialized
INFO - 2022-06-17 10:25:51 --> Loader Class Initialized
INFO - 2022-06-17 10:25:51 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:51 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:51 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:51 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:51 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:51 --> Controller Class Initialized
INFO - 2022-06-17 10:25:52 --> Config Class Initialized
INFO - 2022-06-17 10:25:52 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:52 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:52 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:52 --> URI Class Initialized
INFO - 2022-06-17 10:25:52 --> Router Class Initialized
INFO - 2022-06-17 10:25:52 --> Output Class Initialized
INFO - 2022-06-17 10:25:52 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:52 --> Input Class Initialized
INFO - 2022-06-17 10:25:52 --> Language Class Initialized
INFO - 2022-06-17 10:25:52 --> Language Class Initialized
INFO - 2022-06-17 10:25:52 --> Config Class Initialized
INFO - 2022-06-17 10:25:52 --> Loader Class Initialized
INFO - 2022-06-17 10:25:52 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:52 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:52 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:52 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:52 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:52 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 10:25:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:52 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:52 --> Total execution time: 0.0538
INFO - 2022-06-17 10:25:53 --> Config Class Initialized
INFO - 2022-06-17 10:25:53 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:53 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:53 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:53 --> URI Class Initialized
INFO - 2022-06-17 10:25:53 --> Router Class Initialized
INFO - 2022-06-17 10:25:53 --> Output Class Initialized
INFO - 2022-06-17 10:25:53 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:53 --> Input Class Initialized
INFO - 2022-06-17 10:25:53 --> Language Class Initialized
INFO - 2022-06-17 10:25:53 --> Language Class Initialized
INFO - 2022-06-17 10:25:53 --> Config Class Initialized
INFO - 2022-06-17 10:25:53 --> Loader Class Initialized
INFO - 2022-06-17 10:25:53 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:53 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:53 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:53 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:53 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:53 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 10:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:53 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:53 --> Total execution time: 0.0426
INFO - 2022-06-17 10:25:56 --> Config Class Initialized
INFO - 2022-06-17 10:25:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:56 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:56 --> URI Class Initialized
INFO - 2022-06-17 10:25:56 --> Router Class Initialized
INFO - 2022-06-17 10:25:56 --> Output Class Initialized
INFO - 2022-06-17 10:25:56 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:56 --> Input Class Initialized
INFO - 2022-06-17 10:25:56 --> Language Class Initialized
INFO - 2022-06-17 10:25:56 --> Language Class Initialized
INFO - 2022-06-17 10:25:56 --> Config Class Initialized
INFO - 2022-06-17 10:25:56 --> Loader Class Initialized
INFO - 2022-06-17 10:25:56 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:56 --> Controller Class Initialized
INFO - 2022-06-17 10:25:56 --> Config Class Initialized
INFO - 2022-06-17 10:25:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:56 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:56 --> URI Class Initialized
INFO - 2022-06-17 10:25:56 --> Router Class Initialized
INFO - 2022-06-17 10:25:56 --> Output Class Initialized
INFO - 2022-06-17 10:25:56 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:56 --> Input Class Initialized
INFO - 2022-06-17 10:25:56 --> Language Class Initialized
INFO - 2022-06-17 10:25:56 --> Language Class Initialized
INFO - 2022-06-17 10:25:56 --> Config Class Initialized
INFO - 2022-06-17 10:25:56 --> Loader Class Initialized
INFO - 2022-06-17 10:25:56 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:56 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 10:25:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:56 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:56 --> Total execution time: 0.0441
INFO - 2022-06-17 10:25:56 --> Config Class Initialized
INFO - 2022-06-17 10:25:56 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:56 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:56 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:56 --> URI Class Initialized
INFO - 2022-06-17 10:25:56 --> Router Class Initialized
INFO - 2022-06-17 10:25:56 --> Output Class Initialized
INFO - 2022-06-17 10:25:56 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:56 --> Input Class Initialized
INFO - 2022-06-17 10:25:56 --> Language Class Initialized
INFO - 2022-06-17 10:25:56 --> Language Class Initialized
INFO - 2022-06-17 10:25:56 --> Config Class Initialized
INFO - 2022-06-17 10:25:56 --> Loader Class Initialized
INFO - 2022-06-17 10:25:56 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:56 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:56 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:56 --> Controller Class Initialized
INFO - 2022-06-17 10:25:58 --> Config Class Initialized
INFO - 2022-06-17 10:25:58 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:25:58 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:25:58 --> Utf8 Class Initialized
INFO - 2022-06-17 10:25:58 --> URI Class Initialized
INFO - 2022-06-17 10:25:58 --> Router Class Initialized
INFO - 2022-06-17 10:25:58 --> Output Class Initialized
INFO - 2022-06-17 10:25:58 --> Security Class Initialized
DEBUG - 2022-06-17 10:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:25:58 --> Input Class Initialized
INFO - 2022-06-17 10:25:58 --> Language Class Initialized
INFO - 2022-06-17 10:25:58 --> Language Class Initialized
INFO - 2022-06-17 10:25:58 --> Config Class Initialized
INFO - 2022-06-17 10:25:58 --> Loader Class Initialized
INFO - 2022-06-17 10:25:58 --> Helper loaded: url_helper
INFO - 2022-06-17 10:25:58 --> Helper loaded: file_helper
INFO - 2022-06-17 10:25:58 --> Helper loaded: form_helper
INFO - 2022-06-17 10:25:58 --> Helper loaded: my_helper
INFO - 2022-06-17 10:25:58 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:25:58 --> Controller Class Initialized
DEBUG - 2022-06-17 10:25:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 10:25:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:25:58 --> Final output sent to browser
DEBUG - 2022-06-17 10:25:58 --> Total execution time: 0.0531
INFO - 2022-06-17 10:26:01 --> Config Class Initialized
INFO - 2022-06-17 10:26:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:01 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:01 --> URI Class Initialized
INFO - 2022-06-17 10:26:01 --> Router Class Initialized
INFO - 2022-06-17 10:26:01 --> Output Class Initialized
INFO - 2022-06-17 10:26:01 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:01 --> Input Class Initialized
INFO - 2022-06-17 10:26:01 --> Language Class Initialized
INFO - 2022-06-17 10:26:01 --> Language Class Initialized
INFO - 2022-06-17 10:26:01 --> Config Class Initialized
INFO - 2022-06-17 10:26:01 --> Loader Class Initialized
INFO - 2022-06-17 10:26:01 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:01 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:01 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:01 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:01 --> Controller Class Initialized
INFO - 2022-06-17 10:26:01 --> Config Class Initialized
INFO - 2022-06-17 10:26:01 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:01 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:01 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:01 --> URI Class Initialized
INFO - 2022-06-17 10:26:01 --> Router Class Initialized
INFO - 2022-06-17 10:26:01 --> Output Class Initialized
INFO - 2022-06-17 10:26:01 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:01 --> Input Class Initialized
INFO - 2022-06-17 10:26:01 --> Language Class Initialized
INFO - 2022-06-17 10:26:01 --> Language Class Initialized
INFO - 2022-06-17 10:26:01 --> Config Class Initialized
INFO - 2022-06-17 10:26:01 --> Loader Class Initialized
INFO - 2022-06-17 10:26:01 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:01 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:01 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:01 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:01 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:01 --> Controller Class Initialized
DEBUG - 2022-06-17 10:26:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 10:26:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:26:01 --> Final output sent to browser
DEBUG - 2022-06-17 10:26:01 --> Total execution time: 0.0441
INFO - 2022-06-17 10:26:02 --> Config Class Initialized
INFO - 2022-06-17 10:26:02 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:02 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:02 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:02 --> URI Class Initialized
INFO - 2022-06-17 10:26:02 --> Router Class Initialized
INFO - 2022-06-17 10:26:02 --> Output Class Initialized
INFO - 2022-06-17 10:26:02 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:02 --> Input Class Initialized
INFO - 2022-06-17 10:26:02 --> Language Class Initialized
INFO - 2022-06-17 10:26:02 --> Language Class Initialized
INFO - 2022-06-17 10:26:02 --> Config Class Initialized
INFO - 2022-06-17 10:26:02 --> Loader Class Initialized
INFO - 2022-06-17 10:26:02 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:02 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:02 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:02 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:02 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:02 --> Controller Class Initialized
DEBUG - 2022-06-17 10:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-17 10:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:26:02 --> Final output sent to browser
DEBUG - 2022-06-17 10:26:02 --> Total execution time: 0.0443
INFO - 2022-06-17 10:26:06 --> Config Class Initialized
INFO - 2022-06-17 10:26:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:06 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:06 --> URI Class Initialized
INFO - 2022-06-17 10:26:06 --> Router Class Initialized
INFO - 2022-06-17 10:26:06 --> Output Class Initialized
INFO - 2022-06-17 10:26:06 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:06 --> Input Class Initialized
INFO - 2022-06-17 10:26:06 --> Language Class Initialized
INFO - 2022-06-17 10:26:06 --> Language Class Initialized
INFO - 2022-06-17 10:26:06 --> Config Class Initialized
INFO - 2022-06-17 10:26:06 --> Loader Class Initialized
INFO - 2022-06-17 10:26:06 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:06 --> Controller Class Initialized
INFO - 2022-06-17 10:26:06 --> Config Class Initialized
INFO - 2022-06-17 10:26:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:06 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:06 --> URI Class Initialized
INFO - 2022-06-17 10:26:06 --> Router Class Initialized
INFO - 2022-06-17 10:26:06 --> Output Class Initialized
INFO - 2022-06-17 10:26:06 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:06 --> Input Class Initialized
INFO - 2022-06-17 10:26:06 --> Language Class Initialized
INFO - 2022-06-17 10:26:06 --> Language Class Initialized
INFO - 2022-06-17 10:26:06 --> Config Class Initialized
INFO - 2022-06-17 10:26:06 --> Loader Class Initialized
INFO - 2022-06-17 10:26:06 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:06 --> Controller Class Initialized
DEBUG - 2022-06-17 10:26:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 10:26:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:26:06 --> Final output sent to browser
DEBUG - 2022-06-17 10:26:06 --> Total execution time: 0.0427
INFO - 2022-06-17 10:26:06 --> Config Class Initialized
INFO - 2022-06-17 10:26:06 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:06 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:06 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:06 --> URI Class Initialized
INFO - 2022-06-17 10:26:06 --> Router Class Initialized
INFO - 2022-06-17 10:26:06 --> Output Class Initialized
INFO - 2022-06-17 10:26:06 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:06 --> Input Class Initialized
INFO - 2022-06-17 10:26:06 --> Language Class Initialized
INFO - 2022-06-17 10:26:06 --> Language Class Initialized
INFO - 2022-06-17 10:26:06 --> Config Class Initialized
INFO - 2022-06-17 10:26:06 --> Loader Class Initialized
INFO - 2022-06-17 10:26:06 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:06 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:06 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:06 --> Controller Class Initialized
INFO - 2022-06-17 10:26:07 --> Config Class Initialized
INFO - 2022-06-17 10:26:07 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:07 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:07 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:07 --> URI Class Initialized
INFO - 2022-06-17 10:26:07 --> Router Class Initialized
INFO - 2022-06-17 10:26:07 --> Output Class Initialized
INFO - 2022-06-17 10:26:07 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:07 --> Input Class Initialized
INFO - 2022-06-17 10:26:07 --> Language Class Initialized
INFO - 2022-06-17 10:26:07 --> Language Class Initialized
INFO - 2022-06-17 10:26:07 --> Config Class Initialized
INFO - 2022-06-17 10:26:07 --> Loader Class Initialized
INFO - 2022-06-17 10:26:07 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:07 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:07 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:07 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:08 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:08 --> Controller Class Initialized
DEBUG - 2022-06-17 10:26:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-06-17 10:26:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:26:08 --> Final output sent to browser
DEBUG - 2022-06-17 10:26:08 --> Total execution time: 0.0434
INFO - 2022-06-17 10:26:11 --> Config Class Initialized
INFO - 2022-06-17 10:26:11 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:11 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:11 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:11 --> URI Class Initialized
INFO - 2022-06-17 10:26:11 --> Router Class Initialized
INFO - 2022-06-17 10:26:11 --> Output Class Initialized
INFO - 2022-06-17 10:26:11 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:11 --> Input Class Initialized
INFO - 2022-06-17 10:26:11 --> Language Class Initialized
INFO - 2022-06-17 10:26:11 --> Language Class Initialized
INFO - 2022-06-17 10:26:11 --> Config Class Initialized
INFO - 2022-06-17 10:26:11 --> Loader Class Initialized
INFO - 2022-06-17 10:26:11 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:11 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:11 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:11 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:11 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:11 --> Controller Class Initialized
INFO - 2022-06-17 10:26:11 --> Config Class Initialized
INFO - 2022-06-17 10:26:11 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:11 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:11 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:11 --> URI Class Initialized
INFO - 2022-06-17 10:26:11 --> Router Class Initialized
INFO - 2022-06-17 10:26:11 --> Output Class Initialized
INFO - 2022-06-17 10:26:11 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:11 --> Input Class Initialized
INFO - 2022-06-17 10:26:11 --> Language Class Initialized
INFO - 2022-06-17 10:26:11 --> Language Class Initialized
INFO - 2022-06-17 10:26:11 --> Config Class Initialized
INFO - 2022-06-17 10:26:11 --> Loader Class Initialized
INFO - 2022-06-17 10:26:11 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:11 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:11 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:11 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:11 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:11 --> Controller Class Initialized
DEBUG - 2022-06-17 10:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-17 10:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:26:11 --> Final output sent to browser
DEBUG - 2022-06-17 10:26:11 --> Total execution time: 0.0451
INFO - 2022-06-17 10:26:15 --> Config Class Initialized
INFO - 2022-06-17 10:26:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:15 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:15 --> URI Class Initialized
INFO - 2022-06-17 10:26:15 --> Router Class Initialized
INFO - 2022-06-17 10:26:15 --> Output Class Initialized
INFO - 2022-06-17 10:26:15 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:15 --> Input Class Initialized
INFO - 2022-06-17 10:26:15 --> Language Class Initialized
INFO - 2022-06-17 10:26:15 --> Language Class Initialized
INFO - 2022-06-17 10:26:15 --> Config Class Initialized
INFO - 2022-06-17 10:26:15 --> Loader Class Initialized
INFO - 2022-06-17 10:26:15 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:15 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:15 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:15 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:15 --> Controller Class Initialized
DEBUG - 2022-06-17 10:26:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-17 10:26:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-17 10:26:15 --> Final output sent to browser
DEBUG - 2022-06-17 10:26:15 --> Total execution time: 0.0533
INFO - 2022-06-17 10:26:15 --> Config Class Initialized
INFO - 2022-06-17 10:26:15 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:15 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:15 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:15 --> URI Class Initialized
INFO - 2022-06-17 10:26:15 --> Router Class Initialized
INFO - 2022-06-17 10:26:15 --> Output Class Initialized
INFO - 2022-06-17 10:26:15 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:15 --> Input Class Initialized
INFO - 2022-06-17 10:26:15 --> Language Class Initialized
INFO - 2022-06-17 10:26:15 --> Language Class Initialized
INFO - 2022-06-17 10:26:15 --> Config Class Initialized
INFO - 2022-06-17 10:26:15 --> Loader Class Initialized
INFO - 2022-06-17 10:26:15 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:15 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:15 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:15 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:15 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:15 --> Controller Class Initialized
INFO - 2022-06-17 10:26:16 --> Config Class Initialized
INFO - 2022-06-17 10:26:16 --> Hooks Class Initialized
DEBUG - 2022-06-17 10:26:16 --> UTF-8 Support Enabled
INFO - 2022-06-17 10:26:16 --> Utf8 Class Initialized
INFO - 2022-06-17 10:26:16 --> URI Class Initialized
INFO - 2022-06-17 10:26:16 --> Router Class Initialized
INFO - 2022-06-17 10:26:16 --> Output Class Initialized
INFO - 2022-06-17 10:26:16 --> Security Class Initialized
DEBUG - 2022-06-17 10:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-17 10:26:16 --> Input Class Initialized
INFO - 2022-06-17 10:26:16 --> Language Class Initialized
INFO - 2022-06-17 10:26:16 --> Language Class Initialized
INFO - 2022-06-17 10:26:16 --> Config Class Initialized
INFO - 2022-06-17 10:26:16 --> Loader Class Initialized
INFO - 2022-06-17 10:26:16 --> Helper loaded: url_helper
INFO - 2022-06-17 10:26:16 --> Helper loaded: file_helper
INFO - 2022-06-17 10:26:16 --> Helper loaded: form_helper
INFO - 2022-06-17 10:26:16 --> Helper loaded: my_helper
INFO - 2022-06-17 10:26:16 --> Database Driver Class Initialized
DEBUG - 2022-06-17 10:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-17 10:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-17 10:26:16 --> Controller Class Initialized
INFO - 2022-06-17 10:26:16 --> Final output sent to browser
DEBUG - 2022-06-17 10:26:16 --> Total execution time: 0.0455
