<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-01 00:51:47 --> Config Class Initialized
INFO - 2021-01-01 00:51:47 --> Hooks Class Initialized
DEBUG - 2021-01-01 00:51:47 --> UTF-8 Support Enabled
INFO - 2021-01-01 00:51:47 --> Utf8 Class Initialized
INFO - 2021-01-01 00:51:47 --> URI Class Initialized
DEBUG - 2021-01-01 00:51:48 --> No URI present. Default controller set.
INFO - 2021-01-01 00:51:48 --> Router Class Initialized
INFO - 2021-01-01 00:51:48 --> Output Class Initialized
INFO - 2021-01-01 00:51:48 --> Security Class Initialized
DEBUG - 2021-01-01 00:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-01 00:51:48 --> Input Class Initialized
INFO - 2021-01-01 00:51:48 --> Language Class Initialized
INFO - 2021-01-01 00:51:49 --> Language Class Initialized
INFO - 2021-01-01 00:51:49 --> Config Class Initialized
INFO - 2021-01-01 00:51:49 --> Loader Class Initialized
INFO - 2021-01-01 00:51:49 --> Helper loaded: url_helper
INFO - 2021-01-01 00:51:49 --> Helper loaded: file_helper
INFO - 2021-01-01 00:51:49 --> Helper loaded: form_helper
INFO - 2021-01-01 00:51:49 --> Helper loaded: my_helper
INFO - 2021-01-01 00:51:49 --> Database Driver Class Initialized
DEBUG - 2021-01-01 00:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-01 00:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-01 00:51:49 --> Controller Class Initialized
INFO - 2021-01-01 00:51:50 --> Config Class Initialized
INFO - 2021-01-01 00:51:50 --> Hooks Class Initialized
DEBUG - 2021-01-01 00:51:50 --> UTF-8 Support Enabled
INFO - 2021-01-01 00:51:50 --> Utf8 Class Initialized
INFO - 2021-01-01 00:51:50 --> URI Class Initialized
INFO - 2021-01-01 00:51:50 --> Router Class Initialized
INFO - 2021-01-01 00:51:50 --> Output Class Initialized
INFO - 2021-01-01 00:51:50 --> Security Class Initialized
DEBUG - 2021-01-01 00:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-01 00:51:50 --> Input Class Initialized
INFO - 2021-01-01 00:51:50 --> Language Class Initialized
INFO - 2021-01-01 00:51:50 --> Language Class Initialized
INFO - 2021-01-01 00:51:50 --> Config Class Initialized
INFO - 2021-01-01 00:51:50 --> Loader Class Initialized
INFO - 2021-01-01 00:51:50 --> Helper loaded: url_helper
INFO - 2021-01-01 00:51:50 --> Helper loaded: file_helper
INFO - 2021-01-01 00:51:50 --> Helper loaded: form_helper
INFO - 2021-01-01 00:51:50 --> Helper loaded: my_helper
INFO - 2021-01-01 00:51:50 --> Database Driver Class Initialized
DEBUG - 2021-01-01 00:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-01 00:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-01 00:51:50 --> Controller Class Initialized
DEBUG - 2021-01-01 00:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-01 00:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-01 00:51:50 --> Final output sent to browser
DEBUG - 2021-01-01 00:51:50 --> Total execution time: 0.7812
INFO - 2021-01-01 00:51:58 --> Config Class Initialized
INFO - 2021-01-01 00:51:58 --> Hooks Class Initialized
DEBUG - 2021-01-01 00:51:58 --> UTF-8 Support Enabled
INFO - 2021-01-01 00:51:58 --> Utf8 Class Initialized
INFO - 2021-01-01 00:51:58 --> URI Class Initialized
INFO - 2021-01-01 00:51:58 --> Router Class Initialized
INFO - 2021-01-01 00:51:58 --> Output Class Initialized
INFO - 2021-01-01 00:51:58 --> Security Class Initialized
DEBUG - 2021-01-01 00:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-01 00:51:58 --> Input Class Initialized
INFO - 2021-01-01 00:51:58 --> Language Class Initialized
INFO - 2021-01-01 00:51:58 --> Language Class Initialized
INFO - 2021-01-01 00:51:59 --> Config Class Initialized
INFO - 2021-01-01 00:51:59 --> Loader Class Initialized
INFO - 2021-01-01 00:51:59 --> Helper loaded: url_helper
INFO - 2021-01-01 00:51:59 --> Helper loaded: file_helper
INFO - 2021-01-01 00:51:59 --> Helper loaded: form_helper
INFO - 2021-01-01 00:51:59 --> Helper loaded: my_helper
INFO - 2021-01-01 00:51:59 --> Database Driver Class Initialized
DEBUG - 2021-01-01 00:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-01 00:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-01 00:51:59 --> Controller Class Initialized
INFO - 2021-01-01 00:51:59 --> Helper loaded: cookie_helper
INFO - 2021-01-01 00:51:59 --> Final output sent to browser
DEBUG - 2021-01-01 00:51:59 --> Total execution time: 1.1326
INFO - 2021-01-01 00:52:00 --> Config Class Initialized
INFO - 2021-01-01 00:52:00 --> Hooks Class Initialized
DEBUG - 2021-01-01 00:52:00 --> UTF-8 Support Enabled
INFO - 2021-01-01 00:52:00 --> Utf8 Class Initialized
INFO - 2021-01-01 00:52:00 --> URI Class Initialized
INFO - 2021-01-01 00:52:00 --> Router Class Initialized
INFO - 2021-01-01 00:52:00 --> Output Class Initialized
INFO - 2021-01-01 00:52:00 --> Security Class Initialized
DEBUG - 2021-01-01 00:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-01 00:52:00 --> Input Class Initialized
INFO - 2021-01-01 00:52:00 --> Language Class Initialized
INFO - 2021-01-01 00:52:00 --> Language Class Initialized
INFO - 2021-01-01 00:52:00 --> Config Class Initialized
INFO - 2021-01-01 00:52:00 --> Loader Class Initialized
INFO - 2021-01-01 00:52:00 --> Helper loaded: url_helper
INFO - 2021-01-01 00:52:00 --> Helper loaded: file_helper
INFO - 2021-01-01 00:52:00 --> Helper loaded: form_helper
INFO - 2021-01-01 00:52:00 --> Helper loaded: my_helper
INFO - 2021-01-01 00:52:00 --> Database Driver Class Initialized
DEBUG - 2021-01-01 00:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-01 00:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-01 00:52:00 --> Controller Class Initialized
DEBUG - 2021-01-01 00:52:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-01 00:52:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-01 00:52:01 --> Final output sent to browser
DEBUG - 2021-01-01 00:52:01 --> Total execution time: 0.9733
INFO - 2021-01-01 00:53:35 --> Config Class Initialized
INFO - 2021-01-01 00:53:35 --> Hooks Class Initialized
DEBUG - 2021-01-01 00:53:35 --> UTF-8 Support Enabled
INFO - 2021-01-01 00:53:35 --> Utf8 Class Initialized
INFO - 2021-01-01 00:53:35 --> URI Class Initialized
INFO - 2021-01-01 00:53:35 --> Router Class Initialized
INFO - 2021-01-01 00:53:35 --> Output Class Initialized
INFO - 2021-01-01 00:53:35 --> Security Class Initialized
DEBUG - 2021-01-01 00:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-01 00:53:35 --> Input Class Initialized
INFO - 2021-01-01 00:53:35 --> Language Class Initialized
ERROR - 2021-01-01 00:53:35 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 394
