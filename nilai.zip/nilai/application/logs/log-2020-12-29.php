<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-29 01:33:29 --> Config Class Initialized
INFO - 2020-12-29 01:33:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:33:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:33:29 --> Utf8 Class Initialized
INFO - 2020-12-29 01:33:29 --> URI Class Initialized
DEBUG - 2020-12-29 01:33:29 --> No URI present. Default controller set.
INFO - 2020-12-29 01:33:29 --> Router Class Initialized
INFO - 2020-12-29 01:33:29 --> Output Class Initialized
INFO - 2020-12-29 01:33:29 --> Security Class Initialized
DEBUG - 2020-12-29 01:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:33:29 --> Input Class Initialized
INFO - 2020-12-29 01:33:29 --> Language Class Initialized
INFO - 2020-12-29 01:33:29 --> Language Class Initialized
INFO - 2020-12-29 01:33:29 --> Config Class Initialized
INFO - 2020-12-29 01:33:29 --> Loader Class Initialized
INFO - 2020-12-29 01:33:29 --> Helper loaded: url_helper
INFO - 2020-12-29 01:33:29 --> Helper loaded: file_helper
INFO - 2020-12-29 01:33:29 --> Helper loaded: form_helper
INFO - 2020-12-29 01:33:29 --> Helper loaded: my_helper
INFO - 2020-12-29 01:33:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:33:29 --> Controller Class Initialized
INFO - 2020-12-29 01:33:29 --> Config Class Initialized
INFO - 2020-12-29 01:33:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:33:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:33:29 --> Utf8 Class Initialized
INFO - 2020-12-29 01:33:30 --> URI Class Initialized
INFO - 2020-12-29 01:33:30 --> Router Class Initialized
INFO - 2020-12-29 01:33:30 --> Output Class Initialized
INFO - 2020-12-29 01:33:30 --> Security Class Initialized
DEBUG - 2020-12-29 01:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:33:30 --> Input Class Initialized
INFO - 2020-12-29 01:33:30 --> Language Class Initialized
INFO - 2020-12-29 01:33:30 --> Language Class Initialized
INFO - 2020-12-29 01:33:30 --> Config Class Initialized
INFO - 2020-12-29 01:33:30 --> Loader Class Initialized
INFO - 2020-12-29 01:33:30 --> Helper loaded: url_helper
INFO - 2020-12-29 01:33:30 --> Helper loaded: file_helper
INFO - 2020-12-29 01:33:30 --> Helper loaded: form_helper
INFO - 2020-12-29 01:33:30 --> Helper loaded: my_helper
INFO - 2020-12-29 01:33:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:33:30 --> Controller Class Initialized
DEBUG - 2020-12-29 01:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 01:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:33:30 --> Final output sent to browser
DEBUG - 2020-12-29 01:33:30 --> Total execution time: 0.4767
INFO - 2020-12-29 01:35:33 --> Config Class Initialized
INFO - 2020-12-29 01:35:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:35:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:35:33 --> Utf8 Class Initialized
INFO - 2020-12-29 01:35:33 --> URI Class Initialized
INFO - 2020-12-29 01:35:33 --> Router Class Initialized
INFO - 2020-12-29 01:35:33 --> Output Class Initialized
INFO - 2020-12-29 01:35:33 --> Security Class Initialized
DEBUG - 2020-12-29 01:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:35:33 --> Input Class Initialized
INFO - 2020-12-29 01:35:33 --> Language Class Initialized
INFO - 2020-12-29 01:35:33 --> Language Class Initialized
INFO - 2020-12-29 01:35:33 --> Config Class Initialized
INFO - 2020-12-29 01:35:33 --> Loader Class Initialized
INFO - 2020-12-29 01:35:33 --> Helper loaded: url_helper
INFO - 2020-12-29 01:35:33 --> Helper loaded: file_helper
INFO - 2020-12-29 01:35:33 --> Helper loaded: form_helper
INFO - 2020-12-29 01:35:33 --> Helper loaded: my_helper
INFO - 2020-12-29 01:35:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:35:33 --> Controller Class Initialized
INFO - 2020-12-29 01:35:33 --> Helper loaded: cookie_helper
INFO - 2020-12-29 01:35:33 --> Final output sent to browser
DEBUG - 2020-12-29 01:35:33 --> Total execution time: 0.3503
INFO - 2020-12-29 01:35:36 --> Config Class Initialized
INFO - 2020-12-29 01:35:36 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:35:36 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:35:36 --> Utf8 Class Initialized
INFO - 2020-12-29 01:35:36 --> URI Class Initialized
INFO - 2020-12-29 01:35:36 --> Router Class Initialized
INFO - 2020-12-29 01:35:36 --> Output Class Initialized
INFO - 2020-12-29 01:35:36 --> Security Class Initialized
DEBUG - 2020-12-29 01:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:35:36 --> Input Class Initialized
INFO - 2020-12-29 01:35:36 --> Language Class Initialized
INFO - 2020-12-29 01:35:36 --> Language Class Initialized
INFO - 2020-12-29 01:35:36 --> Config Class Initialized
INFO - 2020-12-29 01:35:36 --> Loader Class Initialized
INFO - 2020-12-29 01:35:36 --> Helper loaded: url_helper
INFO - 2020-12-29 01:35:36 --> Helper loaded: file_helper
INFO - 2020-12-29 01:35:36 --> Helper loaded: form_helper
INFO - 2020-12-29 01:35:36 --> Helper loaded: my_helper
INFO - 2020-12-29 01:35:36 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:35:36 --> Controller Class Initialized
DEBUG - 2020-12-29 01:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 01:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:35:37 --> Final output sent to browser
DEBUG - 2020-12-29 01:35:37 --> Total execution time: 0.3579
INFO - 2020-12-29 01:38:16 --> Config Class Initialized
INFO - 2020-12-29 01:38:16 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:38:16 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:38:16 --> Utf8 Class Initialized
INFO - 2020-12-29 01:38:16 --> URI Class Initialized
INFO - 2020-12-29 01:38:16 --> Router Class Initialized
INFO - 2020-12-29 01:38:16 --> Output Class Initialized
INFO - 2020-12-29 01:38:16 --> Security Class Initialized
DEBUG - 2020-12-29 01:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:38:16 --> Input Class Initialized
INFO - 2020-12-29 01:38:16 --> Language Class Initialized
INFO - 2020-12-29 01:38:16 --> Language Class Initialized
INFO - 2020-12-29 01:38:16 --> Config Class Initialized
INFO - 2020-12-29 01:38:16 --> Loader Class Initialized
INFO - 2020-12-29 01:38:16 --> Helper loaded: url_helper
INFO - 2020-12-29 01:38:16 --> Helper loaded: file_helper
INFO - 2020-12-29 01:38:16 --> Helper loaded: form_helper
INFO - 2020-12-29 01:38:16 --> Helper loaded: my_helper
INFO - 2020-12-29 01:38:16 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:38:17 --> Controller Class Initialized
DEBUG - 2020-12-29 01:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 01:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:38:17 --> Final output sent to browser
DEBUG - 2020-12-29 01:38:17 --> Total execution time: 0.3828
INFO - 2020-12-29 01:38:17 --> Config Class Initialized
INFO - 2020-12-29 01:38:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:38:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:38:17 --> Utf8 Class Initialized
INFO - 2020-12-29 01:38:17 --> URI Class Initialized
INFO - 2020-12-29 01:38:17 --> Router Class Initialized
INFO - 2020-12-29 01:38:17 --> Output Class Initialized
INFO - 2020-12-29 01:38:17 --> Security Class Initialized
DEBUG - 2020-12-29 01:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:38:17 --> Input Class Initialized
INFO - 2020-12-29 01:38:17 --> Language Class Initialized
INFO - 2020-12-29 01:38:17 --> Language Class Initialized
INFO - 2020-12-29 01:38:17 --> Config Class Initialized
INFO - 2020-12-29 01:38:17 --> Loader Class Initialized
INFO - 2020-12-29 01:38:17 --> Helper loaded: url_helper
INFO - 2020-12-29 01:38:17 --> Helper loaded: file_helper
INFO - 2020-12-29 01:38:17 --> Helper loaded: form_helper
INFO - 2020-12-29 01:38:17 --> Helper loaded: my_helper
INFO - 2020-12-29 01:38:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:38:17 --> Controller Class Initialized
INFO - 2020-12-29 01:39:02 --> Config Class Initialized
INFO - 2020-12-29 01:39:02 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:02 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:02 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:02 --> URI Class Initialized
INFO - 2020-12-29 01:39:02 --> Router Class Initialized
INFO - 2020-12-29 01:39:02 --> Output Class Initialized
INFO - 2020-12-29 01:39:02 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:02 --> Input Class Initialized
INFO - 2020-12-29 01:39:02 --> Language Class Initialized
INFO - 2020-12-29 01:39:02 --> Language Class Initialized
INFO - 2020-12-29 01:39:02 --> Config Class Initialized
INFO - 2020-12-29 01:39:02 --> Loader Class Initialized
INFO - 2020-12-29 01:39:02 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:02 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:02 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:02 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:02 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:02 --> Controller Class Initialized
INFO - 2020-12-29 01:39:02 --> Final output sent to browser
DEBUG - 2020-12-29 01:39:02 --> Total execution time: 0.2378
INFO - 2020-12-29 01:39:22 --> Config Class Initialized
INFO - 2020-12-29 01:39:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:22 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:22 --> URI Class Initialized
INFO - 2020-12-29 01:39:22 --> Router Class Initialized
INFO - 2020-12-29 01:39:22 --> Output Class Initialized
INFO - 2020-12-29 01:39:22 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:22 --> Input Class Initialized
INFO - 2020-12-29 01:39:22 --> Language Class Initialized
INFO - 2020-12-29 01:39:22 --> Language Class Initialized
INFO - 2020-12-29 01:39:22 --> Config Class Initialized
INFO - 2020-12-29 01:39:22 --> Loader Class Initialized
INFO - 2020-12-29 01:39:22 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:22 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:22 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:22 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:22 --> Controller Class Initialized
INFO - 2020-12-29 01:39:22 --> Helper loaded: cookie_helper
INFO - 2020-12-29 01:39:22 --> Config Class Initialized
INFO - 2020-12-29 01:39:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:22 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:22 --> URI Class Initialized
INFO - 2020-12-29 01:39:22 --> Router Class Initialized
INFO - 2020-12-29 01:39:22 --> Output Class Initialized
INFO - 2020-12-29 01:39:22 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:22 --> Input Class Initialized
INFO - 2020-12-29 01:39:22 --> Language Class Initialized
INFO - 2020-12-29 01:39:22 --> Language Class Initialized
INFO - 2020-12-29 01:39:22 --> Config Class Initialized
INFO - 2020-12-29 01:39:22 --> Loader Class Initialized
INFO - 2020-12-29 01:39:22 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:22 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:22 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:22 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:22 --> Controller Class Initialized
DEBUG - 2020-12-29 01:39:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 01:39:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:39:22 --> Final output sent to browser
DEBUG - 2020-12-29 01:39:22 --> Total execution time: 0.2505
INFO - 2020-12-29 01:39:37 --> Config Class Initialized
INFO - 2020-12-29 01:39:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:37 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:37 --> URI Class Initialized
INFO - 2020-12-29 01:39:37 --> Router Class Initialized
INFO - 2020-12-29 01:39:37 --> Output Class Initialized
INFO - 2020-12-29 01:39:37 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:38 --> Input Class Initialized
INFO - 2020-12-29 01:39:38 --> Language Class Initialized
INFO - 2020-12-29 01:39:38 --> Language Class Initialized
INFO - 2020-12-29 01:39:38 --> Config Class Initialized
INFO - 2020-12-29 01:39:38 --> Loader Class Initialized
INFO - 2020-12-29 01:39:38 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:38 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:38 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:38 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:38 --> Controller Class Initialized
DEBUG - 2020-12-29 01:39:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 01:39:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:39:38 --> Final output sent to browser
DEBUG - 2020-12-29 01:39:38 --> Total execution time: 0.2374
INFO - 2020-12-29 01:39:38 --> Config Class Initialized
INFO - 2020-12-29 01:39:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:38 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:38 --> URI Class Initialized
INFO - 2020-12-29 01:39:38 --> Router Class Initialized
INFO - 2020-12-29 01:39:38 --> Output Class Initialized
INFO - 2020-12-29 01:39:38 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:38 --> Input Class Initialized
INFO - 2020-12-29 01:39:38 --> Language Class Initialized
INFO - 2020-12-29 01:39:38 --> Language Class Initialized
INFO - 2020-12-29 01:39:38 --> Config Class Initialized
INFO - 2020-12-29 01:39:38 --> Loader Class Initialized
INFO - 2020-12-29 01:39:38 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:38 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:38 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:38 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:38 --> Controller Class Initialized
INFO - 2020-12-29 01:39:40 --> Config Class Initialized
INFO - 2020-12-29 01:39:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:40 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:40 --> URI Class Initialized
INFO - 2020-12-29 01:39:40 --> Router Class Initialized
INFO - 2020-12-29 01:39:40 --> Output Class Initialized
INFO - 2020-12-29 01:39:40 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:40 --> Input Class Initialized
INFO - 2020-12-29 01:39:40 --> Language Class Initialized
INFO - 2020-12-29 01:39:40 --> Language Class Initialized
INFO - 2020-12-29 01:39:40 --> Config Class Initialized
INFO - 2020-12-29 01:39:40 --> Loader Class Initialized
INFO - 2020-12-29 01:39:40 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:40 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:40 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:40 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:40 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:40 --> Controller Class Initialized
DEBUG - 2020-12-29 01:39:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 01:39:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:39:40 --> Final output sent to browser
DEBUG - 2020-12-29 01:39:40 --> Total execution time: 0.2560
INFO - 2020-12-29 01:39:47 --> Config Class Initialized
INFO - 2020-12-29 01:39:47 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:47 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:47 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:47 --> URI Class Initialized
INFO - 2020-12-29 01:39:47 --> Router Class Initialized
INFO - 2020-12-29 01:39:47 --> Output Class Initialized
INFO - 2020-12-29 01:39:47 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:47 --> Input Class Initialized
INFO - 2020-12-29 01:39:47 --> Language Class Initialized
INFO - 2020-12-29 01:39:48 --> Language Class Initialized
INFO - 2020-12-29 01:39:48 --> Config Class Initialized
INFO - 2020-12-29 01:39:48 --> Loader Class Initialized
INFO - 2020-12-29 01:39:48 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:48 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:48 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:48 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:48 --> Controller Class Initialized
INFO - 2020-12-29 01:39:48 --> Helper loaded: cookie_helper
INFO - 2020-12-29 01:39:48 --> Final output sent to browser
DEBUG - 2020-12-29 01:39:48 --> Total execution time: 0.3283
INFO - 2020-12-29 01:39:49 --> Config Class Initialized
INFO - 2020-12-29 01:39:49 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:49 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:49 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:49 --> URI Class Initialized
INFO - 2020-12-29 01:39:49 --> Router Class Initialized
INFO - 2020-12-29 01:39:49 --> Output Class Initialized
INFO - 2020-12-29 01:39:49 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:49 --> Input Class Initialized
INFO - 2020-12-29 01:39:49 --> Language Class Initialized
INFO - 2020-12-29 01:39:49 --> Language Class Initialized
INFO - 2020-12-29 01:39:49 --> Config Class Initialized
INFO - 2020-12-29 01:39:49 --> Loader Class Initialized
INFO - 2020-12-29 01:39:49 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:49 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:49 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:49 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:49 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:49 --> Controller Class Initialized
DEBUG - 2020-12-29 01:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 01:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:39:49 --> Final output sent to browser
DEBUG - 2020-12-29 01:39:49 --> Total execution time: 0.4143
INFO - 2020-12-29 01:39:53 --> Config Class Initialized
INFO - 2020-12-29 01:39:53 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:53 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:53 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:53 --> URI Class Initialized
INFO - 2020-12-29 01:39:53 --> Router Class Initialized
INFO - 2020-12-29 01:39:53 --> Output Class Initialized
INFO - 2020-12-29 01:39:53 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:53 --> Input Class Initialized
INFO - 2020-12-29 01:39:53 --> Language Class Initialized
INFO - 2020-12-29 01:39:53 --> Language Class Initialized
INFO - 2020-12-29 01:39:53 --> Config Class Initialized
INFO - 2020-12-29 01:39:53 --> Loader Class Initialized
INFO - 2020-12-29 01:39:53 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:53 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:53 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:53 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:53 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:53 --> Controller Class Initialized
DEBUG - 2020-12-29 01:39:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-12-29 01:39:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:39:53 --> Final output sent to browser
DEBUG - 2020-12-29 01:39:53 --> Total execution time: 0.3102
INFO - 2020-12-29 01:39:53 --> Config Class Initialized
INFO - 2020-12-29 01:39:53 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:39:53 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:39:53 --> Utf8 Class Initialized
INFO - 2020-12-29 01:39:53 --> URI Class Initialized
INFO - 2020-12-29 01:39:53 --> Router Class Initialized
INFO - 2020-12-29 01:39:53 --> Output Class Initialized
INFO - 2020-12-29 01:39:53 --> Security Class Initialized
DEBUG - 2020-12-29 01:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:39:54 --> Input Class Initialized
INFO - 2020-12-29 01:39:54 --> Language Class Initialized
INFO - 2020-12-29 01:39:54 --> Language Class Initialized
INFO - 2020-12-29 01:39:54 --> Config Class Initialized
INFO - 2020-12-29 01:39:54 --> Loader Class Initialized
INFO - 2020-12-29 01:39:54 --> Helper loaded: url_helper
INFO - 2020-12-29 01:39:54 --> Helper loaded: file_helper
INFO - 2020-12-29 01:39:54 --> Helper loaded: form_helper
INFO - 2020-12-29 01:39:54 --> Helper loaded: my_helper
INFO - 2020-12-29 01:39:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:39:54 --> Controller Class Initialized
INFO - 2020-12-29 01:40:00 --> Config Class Initialized
INFO - 2020-12-29 01:40:00 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:00 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:00 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:00 --> URI Class Initialized
INFO - 2020-12-29 01:40:00 --> Router Class Initialized
INFO - 2020-12-29 01:40:00 --> Output Class Initialized
INFO - 2020-12-29 01:40:00 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:00 --> Input Class Initialized
INFO - 2020-12-29 01:40:00 --> Language Class Initialized
INFO - 2020-12-29 01:40:00 --> Language Class Initialized
INFO - 2020-12-29 01:40:00 --> Config Class Initialized
INFO - 2020-12-29 01:40:00 --> Loader Class Initialized
INFO - 2020-12-29 01:40:00 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:00 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:00 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:00 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:00 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:00 --> Controller Class Initialized
DEBUG - 2020-12-29 01:40:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 01:40:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:40:00 --> Final output sent to browser
DEBUG - 2020-12-29 01:40:00 --> Total execution time: 0.2922
INFO - 2020-12-29 01:40:00 --> Config Class Initialized
INFO - 2020-12-29 01:40:00 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:00 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:00 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:00 --> URI Class Initialized
INFO - 2020-12-29 01:40:00 --> Router Class Initialized
INFO - 2020-12-29 01:40:00 --> Output Class Initialized
INFO - 2020-12-29 01:40:01 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:01 --> Input Class Initialized
INFO - 2020-12-29 01:40:01 --> Language Class Initialized
INFO - 2020-12-29 01:40:01 --> Language Class Initialized
INFO - 2020-12-29 01:40:01 --> Config Class Initialized
INFO - 2020-12-29 01:40:01 --> Loader Class Initialized
INFO - 2020-12-29 01:40:01 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:01 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:01 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:01 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:01 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:01 --> Controller Class Initialized
INFO - 2020-12-29 01:40:03 --> Config Class Initialized
INFO - 2020-12-29 01:40:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:03 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:03 --> URI Class Initialized
INFO - 2020-12-29 01:40:03 --> Router Class Initialized
INFO - 2020-12-29 01:40:03 --> Output Class Initialized
INFO - 2020-12-29 01:40:03 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:03 --> Input Class Initialized
INFO - 2020-12-29 01:40:03 --> Language Class Initialized
INFO - 2020-12-29 01:40:03 --> Language Class Initialized
INFO - 2020-12-29 01:40:03 --> Config Class Initialized
INFO - 2020-12-29 01:40:03 --> Loader Class Initialized
INFO - 2020-12-29 01:40:03 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:03 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:03 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:03 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:03 --> Controller Class Initialized
DEBUG - 2020-12-29 01:40:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 01:40:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:40:03 --> Final output sent to browser
DEBUG - 2020-12-29 01:40:03 --> Total execution time: 0.2918
INFO - 2020-12-29 01:40:21 --> Config Class Initialized
INFO - 2020-12-29 01:40:21 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:21 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:21 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:21 --> URI Class Initialized
INFO - 2020-12-29 01:40:21 --> Router Class Initialized
INFO - 2020-12-29 01:40:21 --> Output Class Initialized
INFO - 2020-12-29 01:40:21 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:21 --> Input Class Initialized
INFO - 2020-12-29 01:40:21 --> Language Class Initialized
ERROR - 2020-12-29 01:40:21 --> 404 Page Not Found: /index
INFO - 2020-12-29 01:40:23 --> Config Class Initialized
INFO - 2020-12-29 01:40:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:23 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:23 --> URI Class Initialized
INFO - 2020-12-29 01:40:23 --> Router Class Initialized
INFO - 2020-12-29 01:40:23 --> Output Class Initialized
INFO - 2020-12-29 01:40:23 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:23 --> Input Class Initialized
INFO - 2020-12-29 01:40:23 --> Language Class Initialized
INFO - 2020-12-29 01:40:23 --> Language Class Initialized
INFO - 2020-12-29 01:40:23 --> Config Class Initialized
INFO - 2020-12-29 01:40:23 --> Loader Class Initialized
INFO - 2020-12-29 01:40:23 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:23 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:23 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:23 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:23 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:23 --> Controller Class Initialized
DEBUG - 2020-12-29 01:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 01:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:40:24 --> Final output sent to browser
DEBUG - 2020-12-29 01:40:24 --> Total execution time: 0.2993
INFO - 2020-12-29 01:40:25 --> Config Class Initialized
INFO - 2020-12-29 01:40:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:25 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:25 --> URI Class Initialized
INFO - 2020-12-29 01:40:25 --> Router Class Initialized
INFO - 2020-12-29 01:40:25 --> Output Class Initialized
INFO - 2020-12-29 01:40:25 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:25 --> Input Class Initialized
INFO - 2020-12-29 01:40:25 --> Language Class Initialized
INFO - 2020-12-29 01:40:25 --> Language Class Initialized
INFO - 2020-12-29 01:40:25 --> Config Class Initialized
INFO - 2020-12-29 01:40:25 --> Loader Class Initialized
INFO - 2020-12-29 01:40:25 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:25 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:25 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:25 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:25 --> Controller Class Initialized
DEBUG - 2020-12-29 01:40:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-12-29 01:40:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:40:25 --> Final output sent to browser
DEBUG - 2020-12-29 01:40:25 --> Total execution time: 0.2647
INFO - 2020-12-29 01:40:25 --> Config Class Initialized
INFO - 2020-12-29 01:40:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:25 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:25 --> URI Class Initialized
INFO - 2020-12-29 01:40:25 --> Router Class Initialized
INFO - 2020-12-29 01:40:25 --> Output Class Initialized
INFO - 2020-12-29 01:40:25 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:25 --> Input Class Initialized
INFO - 2020-12-29 01:40:25 --> Language Class Initialized
INFO - 2020-12-29 01:40:25 --> Language Class Initialized
INFO - 2020-12-29 01:40:25 --> Config Class Initialized
INFO - 2020-12-29 01:40:25 --> Loader Class Initialized
INFO - 2020-12-29 01:40:25 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:25 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:25 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:25 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:25 --> Controller Class Initialized
INFO - 2020-12-29 01:40:28 --> Config Class Initialized
INFO - 2020-12-29 01:40:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:28 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:28 --> URI Class Initialized
INFO - 2020-12-29 01:40:28 --> Router Class Initialized
INFO - 2020-12-29 01:40:28 --> Output Class Initialized
INFO - 2020-12-29 01:40:28 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:28 --> Input Class Initialized
INFO - 2020-12-29 01:40:28 --> Language Class Initialized
INFO - 2020-12-29 01:40:28 --> Language Class Initialized
INFO - 2020-12-29 01:40:28 --> Config Class Initialized
INFO - 2020-12-29 01:40:28 --> Loader Class Initialized
INFO - 2020-12-29 01:40:28 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:28 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:28 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:28 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:28 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:28 --> Controller Class Initialized
DEBUG - 2020-12-29 01:40:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 01:40:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:40:28 --> Final output sent to browser
DEBUG - 2020-12-29 01:40:28 --> Total execution time: 0.3097
INFO - 2020-12-29 01:40:28 --> Config Class Initialized
INFO - 2020-12-29 01:40:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:28 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:28 --> URI Class Initialized
INFO - 2020-12-29 01:40:28 --> Router Class Initialized
INFO - 2020-12-29 01:40:28 --> Output Class Initialized
INFO - 2020-12-29 01:40:28 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:28 --> Input Class Initialized
INFO - 2020-12-29 01:40:28 --> Language Class Initialized
INFO - 2020-12-29 01:40:28 --> Language Class Initialized
INFO - 2020-12-29 01:40:28 --> Config Class Initialized
INFO - 2020-12-29 01:40:29 --> Loader Class Initialized
INFO - 2020-12-29 01:40:29 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:29 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:29 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:29 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:29 --> Controller Class Initialized
INFO - 2020-12-29 01:40:29 --> Config Class Initialized
INFO - 2020-12-29 01:40:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:40:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:40:29 --> Utf8 Class Initialized
INFO - 2020-12-29 01:40:29 --> URI Class Initialized
INFO - 2020-12-29 01:40:29 --> Router Class Initialized
INFO - 2020-12-29 01:40:30 --> Output Class Initialized
INFO - 2020-12-29 01:40:30 --> Security Class Initialized
DEBUG - 2020-12-29 01:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:40:30 --> Input Class Initialized
INFO - 2020-12-29 01:40:30 --> Language Class Initialized
INFO - 2020-12-29 01:40:30 --> Language Class Initialized
INFO - 2020-12-29 01:40:30 --> Config Class Initialized
INFO - 2020-12-29 01:40:30 --> Loader Class Initialized
INFO - 2020-12-29 01:40:30 --> Helper loaded: url_helper
INFO - 2020-12-29 01:40:30 --> Helper loaded: file_helper
INFO - 2020-12-29 01:40:30 --> Helper loaded: form_helper
INFO - 2020-12-29 01:40:30 --> Helper loaded: my_helper
INFO - 2020-12-29 01:40:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:40:30 --> Controller Class Initialized
DEBUG - 2020-12-29 01:40:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 01:40:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:40:30 --> Final output sent to browser
DEBUG - 2020-12-29 01:40:30 --> Total execution time: 0.3139
INFO - 2020-12-29 01:41:35 --> Config Class Initialized
INFO - 2020-12-29 01:41:35 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:41:35 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:41:36 --> Utf8 Class Initialized
INFO - 2020-12-29 01:41:36 --> URI Class Initialized
INFO - 2020-12-29 01:41:36 --> Router Class Initialized
INFO - 2020-12-29 01:41:36 --> Output Class Initialized
INFO - 2020-12-29 01:41:36 --> Security Class Initialized
DEBUG - 2020-12-29 01:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:41:36 --> Input Class Initialized
INFO - 2020-12-29 01:41:36 --> Language Class Initialized
INFO - 2020-12-29 01:41:36 --> Language Class Initialized
INFO - 2020-12-29 01:41:36 --> Config Class Initialized
INFO - 2020-12-29 01:41:36 --> Loader Class Initialized
INFO - 2020-12-29 01:41:36 --> Helper loaded: url_helper
INFO - 2020-12-29 01:41:36 --> Helper loaded: file_helper
INFO - 2020-12-29 01:41:36 --> Helper loaded: form_helper
INFO - 2020-12-29 01:41:36 --> Helper loaded: my_helper
INFO - 2020-12-29 01:41:36 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:41:36 --> Controller Class Initialized
DEBUG - 2020-12-29 01:41:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-12-29 01:41:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:41:36 --> Final output sent to browser
DEBUG - 2020-12-29 01:41:36 --> Total execution time: 0.3581
INFO - 2020-12-29 01:41:36 --> Config Class Initialized
INFO - 2020-12-29 01:41:36 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:41:36 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:41:36 --> Utf8 Class Initialized
INFO - 2020-12-29 01:41:36 --> URI Class Initialized
INFO - 2020-12-29 01:41:36 --> Router Class Initialized
INFO - 2020-12-29 01:41:36 --> Output Class Initialized
INFO - 2020-12-29 01:41:36 --> Security Class Initialized
DEBUG - 2020-12-29 01:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:41:36 --> Input Class Initialized
INFO - 2020-12-29 01:41:36 --> Language Class Initialized
INFO - 2020-12-29 01:41:36 --> Language Class Initialized
INFO - 2020-12-29 01:41:36 --> Config Class Initialized
INFO - 2020-12-29 01:41:36 --> Loader Class Initialized
INFO - 2020-12-29 01:41:36 --> Helper loaded: url_helper
INFO - 2020-12-29 01:41:36 --> Helper loaded: file_helper
INFO - 2020-12-29 01:41:36 --> Helper loaded: form_helper
INFO - 2020-12-29 01:41:36 --> Helper loaded: my_helper
INFO - 2020-12-29 01:41:36 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:41:36 --> Controller Class Initialized
INFO - 2020-12-29 01:41:41 --> Config Class Initialized
INFO - 2020-12-29 01:41:41 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:41:41 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:41:41 --> Utf8 Class Initialized
INFO - 2020-12-29 01:41:41 --> URI Class Initialized
INFO - 2020-12-29 01:41:41 --> Router Class Initialized
INFO - 2020-12-29 01:41:41 --> Output Class Initialized
INFO - 2020-12-29 01:41:41 --> Security Class Initialized
DEBUG - 2020-12-29 01:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:41:41 --> Input Class Initialized
INFO - 2020-12-29 01:41:41 --> Language Class Initialized
INFO - 2020-12-29 01:41:41 --> Language Class Initialized
INFO - 2020-12-29 01:41:41 --> Config Class Initialized
INFO - 2020-12-29 01:41:41 --> Loader Class Initialized
INFO - 2020-12-29 01:41:41 --> Helper loaded: url_helper
INFO - 2020-12-29 01:41:41 --> Helper loaded: file_helper
INFO - 2020-12-29 01:41:41 --> Helper loaded: form_helper
INFO - 2020-12-29 01:41:41 --> Helper loaded: my_helper
INFO - 2020-12-29 01:41:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:41:41 --> Controller Class Initialized
DEBUG - 2020-12-29 01:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 01:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:41:41 --> Final output sent to browser
DEBUG - 2020-12-29 01:41:41 --> Total execution time: 0.2606
INFO - 2020-12-29 01:41:42 --> Config Class Initialized
INFO - 2020-12-29 01:41:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:41:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:41:42 --> Utf8 Class Initialized
INFO - 2020-12-29 01:41:42 --> URI Class Initialized
INFO - 2020-12-29 01:41:42 --> Router Class Initialized
INFO - 2020-12-29 01:41:42 --> Output Class Initialized
INFO - 2020-12-29 01:41:42 --> Security Class Initialized
DEBUG - 2020-12-29 01:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:41:42 --> Input Class Initialized
INFO - 2020-12-29 01:41:42 --> Language Class Initialized
INFO - 2020-12-29 01:41:42 --> Language Class Initialized
INFO - 2020-12-29 01:41:42 --> Config Class Initialized
INFO - 2020-12-29 01:41:42 --> Loader Class Initialized
INFO - 2020-12-29 01:41:42 --> Helper loaded: url_helper
INFO - 2020-12-29 01:41:42 --> Helper loaded: file_helper
INFO - 2020-12-29 01:41:42 --> Helper loaded: form_helper
INFO - 2020-12-29 01:41:42 --> Helper loaded: my_helper
INFO - 2020-12-29 01:41:42 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:41:42 --> Controller Class Initialized
INFO - 2020-12-29 01:41:43 --> Config Class Initialized
INFO - 2020-12-29 01:41:43 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:41:43 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:41:43 --> Utf8 Class Initialized
INFO - 2020-12-29 01:41:43 --> URI Class Initialized
INFO - 2020-12-29 01:41:43 --> Router Class Initialized
INFO - 2020-12-29 01:41:43 --> Output Class Initialized
INFO - 2020-12-29 01:41:43 --> Security Class Initialized
DEBUG - 2020-12-29 01:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:41:43 --> Input Class Initialized
INFO - 2020-12-29 01:41:43 --> Language Class Initialized
INFO - 2020-12-29 01:41:43 --> Language Class Initialized
INFO - 2020-12-29 01:41:43 --> Config Class Initialized
INFO - 2020-12-29 01:41:43 --> Loader Class Initialized
INFO - 2020-12-29 01:41:43 --> Helper loaded: url_helper
INFO - 2020-12-29 01:41:43 --> Helper loaded: file_helper
INFO - 2020-12-29 01:41:43 --> Helper loaded: form_helper
INFO - 2020-12-29 01:41:43 --> Helper loaded: my_helper
INFO - 2020-12-29 01:41:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:41:43 --> Controller Class Initialized
DEBUG - 2020-12-29 01:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 01:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:41:43 --> Final output sent to browser
DEBUG - 2020-12-29 01:41:43 --> Total execution time: 0.3118
INFO - 2020-12-29 01:45:25 --> Config Class Initialized
INFO - 2020-12-29 01:45:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:45:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:45:25 --> Utf8 Class Initialized
INFO - 2020-12-29 01:45:25 --> URI Class Initialized
INFO - 2020-12-29 01:45:25 --> Router Class Initialized
INFO - 2020-12-29 01:45:25 --> Output Class Initialized
INFO - 2020-12-29 01:45:25 --> Security Class Initialized
DEBUG - 2020-12-29 01:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:45:25 --> Input Class Initialized
INFO - 2020-12-29 01:45:25 --> Language Class Initialized
INFO - 2020-12-29 01:45:25 --> Language Class Initialized
INFO - 2020-12-29 01:45:25 --> Config Class Initialized
INFO - 2020-12-29 01:45:25 --> Loader Class Initialized
INFO - 2020-12-29 01:45:25 --> Helper loaded: url_helper
INFO - 2020-12-29 01:45:25 --> Helper loaded: file_helper
INFO - 2020-12-29 01:45:25 --> Helper loaded: form_helper
INFO - 2020-12-29 01:45:25 --> Helper loaded: my_helper
INFO - 2020-12-29 01:45:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:45:25 --> Controller Class Initialized
INFO - 2020-12-29 01:45:25 --> Config Class Initialized
INFO - 2020-12-29 01:45:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:45:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:45:25 --> Utf8 Class Initialized
INFO - 2020-12-29 01:45:25 --> URI Class Initialized
INFO - 2020-12-29 01:45:25 --> Router Class Initialized
INFO - 2020-12-29 01:45:26 --> Output Class Initialized
INFO - 2020-12-29 01:45:26 --> Security Class Initialized
DEBUG - 2020-12-29 01:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:45:26 --> Input Class Initialized
INFO - 2020-12-29 01:45:26 --> Language Class Initialized
INFO - 2020-12-29 01:45:26 --> Language Class Initialized
INFO - 2020-12-29 01:45:26 --> Config Class Initialized
INFO - 2020-12-29 01:45:26 --> Loader Class Initialized
INFO - 2020-12-29 01:45:26 --> Helper loaded: url_helper
INFO - 2020-12-29 01:45:26 --> Helper loaded: file_helper
INFO - 2020-12-29 01:45:26 --> Helper loaded: form_helper
INFO - 2020-12-29 01:45:26 --> Helper loaded: my_helper
INFO - 2020-12-29 01:45:26 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:45:26 --> Controller Class Initialized
DEBUG - 2020-12-29 01:45:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 01:45:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:45:26 --> Final output sent to browser
DEBUG - 2020-12-29 01:45:26 --> Total execution time: 0.3363
INFO - 2020-12-29 01:45:26 --> Config Class Initialized
INFO - 2020-12-29 01:45:26 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:45:26 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:45:26 --> Utf8 Class Initialized
INFO - 2020-12-29 01:45:26 --> URI Class Initialized
INFO - 2020-12-29 01:45:26 --> Router Class Initialized
INFO - 2020-12-29 01:45:26 --> Output Class Initialized
INFO - 2020-12-29 01:45:26 --> Security Class Initialized
DEBUG - 2020-12-29 01:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:45:26 --> Input Class Initialized
INFO - 2020-12-29 01:45:26 --> Language Class Initialized
INFO - 2020-12-29 01:45:26 --> Language Class Initialized
INFO - 2020-12-29 01:45:26 --> Config Class Initialized
INFO - 2020-12-29 01:45:26 --> Loader Class Initialized
INFO - 2020-12-29 01:45:26 --> Helper loaded: url_helper
INFO - 2020-12-29 01:45:26 --> Helper loaded: file_helper
INFO - 2020-12-29 01:45:26 --> Helper loaded: form_helper
INFO - 2020-12-29 01:45:26 --> Helper loaded: my_helper
INFO - 2020-12-29 01:45:26 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:45:26 --> Controller Class Initialized
INFO - 2020-12-29 01:45:32 --> Config Class Initialized
INFO - 2020-12-29 01:45:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:45:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:45:32 --> Utf8 Class Initialized
INFO - 2020-12-29 01:45:32 --> URI Class Initialized
INFO - 2020-12-29 01:45:32 --> Router Class Initialized
INFO - 2020-12-29 01:45:32 --> Output Class Initialized
INFO - 2020-12-29 01:45:32 --> Security Class Initialized
DEBUG - 2020-12-29 01:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:45:33 --> Input Class Initialized
INFO - 2020-12-29 01:45:33 --> Language Class Initialized
INFO - 2020-12-29 01:45:33 --> Language Class Initialized
INFO - 2020-12-29 01:45:33 --> Config Class Initialized
INFO - 2020-12-29 01:45:33 --> Loader Class Initialized
INFO - 2020-12-29 01:45:33 --> Helper loaded: url_helper
INFO - 2020-12-29 01:45:33 --> Helper loaded: file_helper
INFO - 2020-12-29 01:45:33 --> Helper loaded: form_helper
INFO - 2020-12-29 01:45:33 --> Helper loaded: my_helper
INFO - 2020-12-29 01:45:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:45:33 --> Controller Class Initialized
DEBUG - 2020-12-29 01:45:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 01:45:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:45:33 --> Final output sent to browser
DEBUG - 2020-12-29 01:45:33 --> Total execution time: 0.2536
INFO - 2020-12-29 01:45:33 --> Config Class Initialized
INFO - 2020-12-29 01:45:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:45:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:45:33 --> Utf8 Class Initialized
INFO - 2020-12-29 01:45:33 --> URI Class Initialized
INFO - 2020-12-29 01:45:33 --> Router Class Initialized
INFO - 2020-12-29 01:45:33 --> Output Class Initialized
INFO - 2020-12-29 01:45:33 --> Security Class Initialized
DEBUG - 2020-12-29 01:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:45:33 --> Input Class Initialized
INFO - 2020-12-29 01:45:33 --> Language Class Initialized
INFO - 2020-12-29 01:45:33 --> Language Class Initialized
INFO - 2020-12-29 01:45:33 --> Config Class Initialized
INFO - 2020-12-29 01:45:33 --> Loader Class Initialized
INFO - 2020-12-29 01:45:33 --> Helper loaded: url_helper
INFO - 2020-12-29 01:45:33 --> Helper loaded: file_helper
INFO - 2020-12-29 01:45:33 --> Helper loaded: form_helper
INFO - 2020-12-29 01:45:33 --> Helper loaded: my_helper
INFO - 2020-12-29 01:45:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:45:33 --> Controller Class Initialized
INFO - 2020-12-29 01:45:54 --> Config Class Initialized
INFO - 2020-12-29 01:45:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:45:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:45:54 --> Utf8 Class Initialized
INFO - 2020-12-29 01:45:54 --> URI Class Initialized
INFO - 2020-12-29 01:45:54 --> Router Class Initialized
INFO - 2020-12-29 01:45:54 --> Output Class Initialized
INFO - 2020-12-29 01:45:54 --> Security Class Initialized
DEBUG - 2020-12-29 01:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:45:54 --> Input Class Initialized
INFO - 2020-12-29 01:45:54 --> Language Class Initialized
INFO - 2020-12-29 01:45:54 --> Language Class Initialized
INFO - 2020-12-29 01:45:54 --> Config Class Initialized
INFO - 2020-12-29 01:45:54 --> Loader Class Initialized
INFO - 2020-12-29 01:45:54 --> Helper loaded: url_helper
INFO - 2020-12-29 01:45:54 --> Helper loaded: file_helper
INFO - 2020-12-29 01:45:54 --> Helper loaded: form_helper
INFO - 2020-12-29 01:45:54 --> Helper loaded: my_helper
INFO - 2020-12-29 01:45:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:45:54 --> Controller Class Initialized
DEBUG - 2020-12-29 01:45:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 01:45:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:45:54 --> Final output sent to browser
DEBUG - 2020-12-29 01:45:54 --> Total execution time: 0.2799
INFO - 2020-12-29 01:46:03 --> Config Class Initialized
INFO - 2020-12-29 01:46:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:46:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:46:03 --> Utf8 Class Initialized
INFO - 2020-12-29 01:46:03 --> URI Class Initialized
INFO - 2020-12-29 01:46:03 --> Router Class Initialized
INFO - 2020-12-29 01:46:03 --> Output Class Initialized
INFO - 2020-12-29 01:46:03 --> Security Class Initialized
DEBUG - 2020-12-29 01:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:46:03 --> Input Class Initialized
INFO - 2020-12-29 01:46:03 --> Language Class Initialized
INFO - 2020-12-29 01:46:03 --> Language Class Initialized
INFO - 2020-12-29 01:46:03 --> Config Class Initialized
INFO - 2020-12-29 01:46:03 --> Loader Class Initialized
INFO - 2020-12-29 01:46:03 --> Helper loaded: url_helper
INFO - 2020-12-29 01:46:03 --> Helper loaded: file_helper
INFO - 2020-12-29 01:46:03 --> Helper loaded: form_helper
INFO - 2020-12-29 01:46:03 --> Helper loaded: my_helper
INFO - 2020-12-29 01:46:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:46:04 --> Controller Class Initialized
INFO - 2020-12-29 01:46:04 --> Config Class Initialized
INFO - 2020-12-29 01:46:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:46:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:46:04 --> Utf8 Class Initialized
INFO - 2020-12-29 01:46:04 --> URI Class Initialized
INFO - 2020-12-29 01:46:04 --> Router Class Initialized
INFO - 2020-12-29 01:46:04 --> Output Class Initialized
INFO - 2020-12-29 01:46:04 --> Security Class Initialized
DEBUG - 2020-12-29 01:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:46:04 --> Input Class Initialized
INFO - 2020-12-29 01:46:04 --> Language Class Initialized
INFO - 2020-12-29 01:46:04 --> Language Class Initialized
INFO - 2020-12-29 01:46:04 --> Config Class Initialized
INFO - 2020-12-29 01:46:04 --> Loader Class Initialized
INFO - 2020-12-29 01:46:04 --> Helper loaded: url_helper
INFO - 2020-12-29 01:46:04 --> Helper loaded: file_helper
INFO - 2020-12-29 01:46:04 --> Helper loaded: form_helper
INFO - 2020-12-29 01:46:04 --> Helper loaded: my_helper
INFO - 2020-12-29 01:46:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:46:04 --> Controller Class Initialized
DEBUG - 2020-12-29 01:46:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 01:46:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:46:04 --> Final output sent to browser
DEBUG - 2020-12-29 01:46:04 --> Total execution time: 0.3388
INFO - 2020-12-29 01:46:04 --> Config Class Initialized
INFO - 2020-12-29 01:46:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:46:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:46:04 --> Utf8 Class Initialized
INFO - 2020-12-29 01:46:04 --> URI Class Initialized
INFO - 2020-12-29 01:46:04 --> Router Class Initialized
INFO - 2020-12-29 01:46:04 --> Output Class Initialized
INFO - 2020-12-29 01:46:04 --> Security Class Initialized
DEBUG - 2020-12-29 01:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:46:04 --> Input Class Initialized
INFO - 2020-12-29 01:46:04 --> Language Class Initialized
INFO - 2020-12-29 01:46:04 --> Language Class Initialized
INFO - 2020-12-29 01:46:04 --> Config Class Initialized
INFO - 2020-12-29 01:46:04 --> Loader Class Initialized
INFO - 2020-12-29 01:46:04 --> Helper loaded: url_helper
INFO - 2020-12-29 01:46:04 --> Helper loaded: file_helper
INFO - 2020-12-29 01:46:04 --> Helper loaded: form_helper
INFO - 2020-12-29 01:46:04 --> Helper loaded: my_helper
INFO - 2020-12-29 01:46:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:46:04 --> Controller Class Initialized
INFO - 2020-12-29 01:46:23 --> Config Class Initialized
INFO - 2020-12-29 01:46:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:46:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:46:23 --> Utf8 Class Initialized
INFO - 2020-12-29 01:46:23 --> URI Class Initialized
INFO - 2020-12-29 01:46:23 --> Router Class Initialized
INFO - 2020-12-29 01:46:23 --> Output Class Initialized
INFO - 2020-12-29 01:46:23 --> Security Class Initialized
DEBUG - 2020-12-29 01:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:46:23 --> Input Class Initialized
INFO - 2020-12-29 01:46:23 --> Language Class Initialized
INFO - 2020-12-29 01:46:23 --> Language Class Initialized
INFO - 2020-12-29 01:46:23 --> Config Class Initialized
INFO - 2020-12-29 01:46:23 --> Loader Class Initialized
INFO - 2020-12-29 01:46:23 --> Helper loaded: url_helper
INFO - 2020-12-29 01:46:23 --> Helper loaded: file_helper
INFO - 2020-12-29 01:46:23 --> Helper loaded: form_helper
INFO - 2020-12-29 01:46:23 --> Helper loaded: my_helper
INFO - 2020-12-29 01:46:23 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:46:23 --> Controller Class Initialized
DEBUG - 2020-12-29 01:46:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 01:46:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:46:23 --> Final output sent to browser
DEBUG - 2020-12-29 01:46:23 --> Total execution time: 0.2746
INFO - 2020-12-29 01:46:40 --> Config Class Initialized
INFO - 2020-12-29 01:46:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:46:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:46:40 --> Utf8 Class Initialized
INFO - 2020-12-29 01:46:40 --> URI Class Initialized
INFO - 2020-12-29 01:46:40 --> Router Class Initialized
INFO - 2020-12-29 01:46:40 --> Output Class Initialized
INFO - 2020-12-29 01:46:40 --> Security Class Initialized
DEBUG - 2020-12-29 01:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:46:40 --> Input Class Initialized
INFO - 2020-12-29 01:46:40 --> Language Class Initialized
INFO - 2020-12-29 01:46:40 --> Language Class Initialized
INFO - 2020-12-29 01:46:40 --> Config Class Initialized
INFO - 2020-12-29 01:46:40 --> Loader Class Initialized
INFO - 2020-12-29 01:46:40 --> Helper loaded: url_helper
INFO - 2020-12-29 01:46:40 --> Helper loaded: file_helper
INFO - 2020-12-29 01:46:40 --> Helper loaded: form_helper
INFO - 2020-12-29 01:46:40 --> Helper loaded: my_helper
INFO - 2020-12-29 01:46:40 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:46:40 --> Controller Class Initialized
INFO - 2020-12-29 01:46:40 --> Config Class Initialized
INFO - 2020-12-29 01:46:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:46:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:46:40 --> Utf8 Class Initialized
INFO - 2020-12-29 01:46:40 --> URI Class Initialized
INFO - 2020-12-29 01:46:40 --> Router Class Initialized
INFO - 2020-12-29 01:46:40 --> Output Class Initialized
INFO - 2020-12-29 01:46:40 --> Security Class Initialized
DEBUG - 2020-12-29 01:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:46:40 --> Input Class Initialized
INFO - 2020-12-29 01:46:40 --> Language Class Initialized
INFO - 2020-12-29 01:46:40 --> Language Class Initialized
INFO - 2020-12-29 01:46:40 --> Config Class Initialized
INFO - 2020-12-29 01:46:40 --> Loader Class Initialized
INFO - 2020-12-29 01:46:40 --> Helper loaded: url_helper
INFO - 2020-12-29 01:46:40 --> Helper loaded: file_helper
INFO - 2020-12-29 01:46:40 --> Helper loaded: form_helper
INFO - 2020-12-29 01:46:40 --> Helper loaded: my_helper
INFO - 2020-12-29 01:46:40 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:46:40 --> Controller Class Initialized
DEBUG - 2020-12-29 01:46:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 01:46:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 01:46:40 --> Final output sent to browser
DEBUG - 2020-12-29 01:46:40 --> Total execution time: 0.2700
INFO - 2020-12-29 01:46:40 --> Config Class Initialized
INFO - 2020-12-29 01:46:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 01:46:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 01:46:40 --> Utf8 Class Initialized
INFO - 2020-12-29 01:46:40 --> URI Class Initialized
INFO - 2020-12-29 01:46:41 --> Router Class Initialized
INFO - 2020-12-29 01:46:41 --> Output Class Initialized
INFO - 2020-12-29 01:46:41 --> Security Class Initialized
DEBUG - 2020-12-29 01:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 01:46:41 --> Input Class Initialized
INFO - 2020-12-29 01:46:41 --> Language Class Initialized
INFO - 2020-12-29 01:46:41 --> Language Class Initialized
INFO - 2020-12-29 01:46:41 --> Config Class Initialized
INFO - 2020-12-29 01:46:41 --> Loader Class Initialized
INFO - 2020-12-29 01:46:41 --> Helper loaded: url_helper
INFO - 2020-12-29 01:46:41 --> Helper loaded: file_helper
INFO - 2020-12-29 01:46:41 --> Helper loaded: form_helper
INFO - 2020-12-29 01:46:41 --> Helper loaded: my_helper
INFO - 2020-12-29 01:46:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 01:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 01:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 01:46:41 --> Controller Class Initialized
INFO - 2020-12-29 02:02:50 --> Config Class Initialized
INFO - 2020-12-29 02:02:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:02:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:02:50 --> Utf8 Class Initialized
INFO - 2020-12-29 02:02:50 --> URI Class Initialized
INFO - 2020-12-29 02:02:50 --> Router Class Initialized
INFO - 2020-12-29 02:02:50 --> Output Class Initialized
INFO - 2020-12-29 02:02:50 --> Security Class Initialized
DEBUG - 2020-12-29 02:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:02:50 --> Input Class Initialized
INFO - 2020-12-29 02:02:50 --> Language Class Initialized
INFO - 2020-12-29 02:02:50 --> Language Class Initialized
INFO - 2020-12-29 02:02:50 --> Config Class Initialized
INFO - 2020-12-29 02:02:50 --> Loader Class Initialized
INFO - 2020-12-29 02:02:50 --> Helper loaded: url_helper
INFO - 2020-12-29 02:02:50 --> Helper loaded: file_helper
INFO - 2020-12-29 02:02:50 --> Helper loaded: form_helper
INFO - 2020-12-29 02:02:50 --> Helper loaded: my_helper
INFO - 2020-12-29 02:02:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:02:50 --> Controller Class Initialized
INFO - 2020-12-29 02:02:50 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:02:50 --> Config Class Initialized
INFO - 2020-12-29 02:02:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:02:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:02:50 --> Utf8 Class Initialized
INFO - 2020-12-29 02:02:50 --> URI Class Initialized
INFO - 2020-12-29 02:02:50 --> Router Class Initialized
INFO - 2020-12-29 02:02:50 --> Output Class Initialized
INFO - 2020-12-29 02:02:50 --> Security Class Initialized
DEBUG - 2020-12-29 02:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:02:50 --> Input Class Initialized
INFO - 2020-12-29 02:02:50 --> Language Class Initialized
INFO - 2020-12-29 02:02:50 --> Language Class Initialized
INFO - 2020-12-29 02:02:50 --> Config Class Initialized
INFO - 2020-12-29 02:02:50 --> Loader Class Initialized
INFO - 2020-12-29 02:02:50 --> Helper loaded: url_helper
INFO - 2020-12-29 02:02:50 --> Helper loaded: file_helper
INFO - 2020-12-29 02:02:50 --> Helper loaded: form_helper
INFO - 2020-12-29 02:02:50 --> Helper loaded: my_helper
INFO - 2020-12-29 02:02:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:02:50 --> Controller Class Initialized
DEBUG - 2020-12-29 02:02:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 02:02:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:02:50 --> Final output sent to browser
DEBUG - 2020-12-29 02:02:50 --> Total execution time: 0.2407
INFO - 2020-12-29 02:02:57 --> Config Class Initialized
INFO - 2020-12-29 02:02:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:02:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:02:57 --> Utf8 Class Initialized
INFO - 2020-12-29 02:02:57 --> URI Class Initialized
INFO - 2020-12-29 02:02:57 --> Router Class Initialized
INFO - 2020-12-29 02:02:57 --> Output Class Initialized
INFO - 2020-12-29 02:02:57 --> Security Class Initialized
DEBUG - 2020-12-29 02:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:02:57 --> Input Class Initialized
INFO - 2020-12-29 02:02:57 --> Language Class Initialized
INFO - 2020-12-29 02:02:57 --> Language Class Initialized
INFO - 2020-12-29 02:02:57 --> Config Class Initialized
INFO - 2020-12-29 02:02:57 --> Loader Class Initialized
INFO - 2020-12-29 02:02:57 --> Helper loaded: url_helper
INFO - 2020-12-29 02:02:57 --> Helper loaded: file_helper
INFO - 2020-12-29 02:02:57 --> Helper loaded: form_helper
INFO - 2020-12-29 02:02:57 --> Helper loaded: my_helper
INFO - 2020-12-29 02:02:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:02:57 --> Controller Class Initialized
INFO - 2020-12-29 02:02:57 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:02:57 --> Final output sent to browser
DEBUG - 2020-12-29 02:02:57 --> Total execution time: 0.3469
INFO - 2020-12-29 02:02:58 --> Config Class Initialized
INFO - 2020-12-29 02:02:58 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:02:58 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:02:58 --> Utf8 Class Initialized
INFO - 2020-12-29 02:02:58 --> URI Class Initialized
INFO - 2020-12-29 02:02:58 --> Router Class Initialized
INFO - 2020-12-29 02:02:58 --> Output Class Initialized
INFO - 2020-12-29 02:02:58 --> Security Class Initialized
DEBUG - 2020-12-29 02:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:02:58 --> Input Class Initialized
INFO - 2020-12-29 02:02:58 --> Language Class Initialized
INFO - 2020-12-29 02:02:58 --> Language Class Initialized
INFO - 2020-12-29 02:02:58 --> Config Class Initialized
INFO - 2020-12-29 02:02:58 --> Loader Class Initialized
INFO - 2020-12-29 02:02:58 --> Helper loaded: url_helper
INFO - 2020-12-29 02:02:58 --> Helper loaded: file_helper
INFO - 2020-12-29 02:02:58 --> Helper loaded: form_helper
INFO - 2020-12-29 02:02:58 --> Helper loaded: my_helper
INFO - 2020-12-29 02:02:58 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:02:58 --> Controller Class Initialized
DEBUG - 2020-12-29 02:02:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 02:02:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:02:58 --> Final output sent to browser
DEBUG - 2020-12-29 02:02:58 --> Total execution time: 0.4168
INFO - 2020-12-29 02:03:00 --> Config Class Initialized
INFO - 2020-12-29 02:03:00 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:03:00 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:03:00 --> Utf8 Class Initialized
INFO - 2020-12-29 02:03:00 --> URI Class Initialized
INFO - 2020-12-29 02:03:00 --> Router Class Initialized
INFO - 2020-12-29 02:03:00 --> Output Class Initialized
INFO - 2020-12-29 02:03:00 --> Security Class Initialized
DEBUG - 2020-12-29 02:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:03:00 --> Input Class Initialized
INFO - 2020-12-29 02:03:00 --> Language Class Initialized
INFO - 2020-12-29 02:03:00 --> Language Class Initialized
INFO - 2020-12-29 02:03:00 --> Config Class Initialized
INFO - 2020-12-29 02:03:00 --> Loader Class Initialized
INFO - 2020-12-29 02:03:00 --> Helper loaded: url_helper
INFO - 2020-12-29 02:03:00 --> Helper loaded: file_helper
INFO - 2020-12-29 02:03:00 --> Helper loaded: form_helper
INFO - 2020-12-29 02:03:00 --> Helper loaded: my_helper
INFO - 2020-12-29 02:03:00 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:03:00 --> Controller Class Initialized
ERROR - 2020-12-29 02:03:00 --> Query error: Unknown column 'b.is_sikap' in 'field list' - Invalid query: SELECT 
                                                a.id, b.kd_singkat nmmapel, a.id_mapel, a.id_kelas, c.nama nmkelas, b.is_sikap
                                                FROM t_guru_mapel a
                                                INNER JOIN m_mapel b ON a.id_mapel = b.id
                                                INNER JOIN m_kelas c ON a.id_kelas = c.id 
                                                WHERE a.id_guru = '35'
                                                AND a.tasm = '20201'
INFO - 2020-12-29 02:03:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-29 02:13:11 --> Config Class Initialized
INFO - 2020-12-29 02:13:11 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:11 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:11 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:11 --> URI Class Initialized
INFO - 2020-12-29 02:13:11 --> Router Class Initialized
INFO - 2020-12-29 02:13:11 --> Output Class Initialized
INFO - 2020-12-29 02:13:11 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:11 --> Input Class Initialized
INFO - 2020-12-29 02:13:12 --> Language Class Initialized
INFO - 2020-12-29 02:13:12 --> Language Class Initialized
INFO - 2020-12-29 02:13:12 --> Config Class Initialized
INFO - 2020-12-29 02:13:12 --> Loader Class Initialized
INFO - 2020-12-29 02:13:12 --> Helper loaded: url_helper
INFO - 2020-12-29 02:13:12 --> Helper loaded: file_helper
INFO - 2020-12-29 02:13:12 --> Helper loaded: form_helper
INFO - 2020-12-29 02:13:12 --> Helper loaded: my_helper
INFO - 2020-12-29 02:13:12 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:13:12 --> Controller Class Initialized
DEBUG - 2020-12-29 02:13:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-29 02:13:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:13:12 --> Final output sent to browser
DEBUG - 2020-12-29 02:13:12 --> Total execution time: 0.2977
INFO - 2020-12-29 02:13:24 --> Config Class Initialized
INFO - 2020-12-29 02:13:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:24 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:24 --> URI Class Initialized
INFO - 2020-12-29 02:13:24 --> Router Class Initialized
INFO - 2020-12-29 02:13:24 --> Output Class Initialized
INFO - 2020-12-29 02:13:24 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:24 --> Input Class Initialized
INFO - 2020-12-29 02:13:24 --> Language Class Initialized
INFO - 2020-12-29 02:13:24 --> Language Class Initialized
INFO - 2020-12-29 02:13:24 --> Config Class Initialized
INFO - 2020-12-29 02:13:24 --> Loader Class Initialized
INFO - 2020-12-29 02:13:24 --> Helper loaded: url_helper
INFO - 2020-12-29 02:13:24 --> Helper loaded: file_helper
INFO - 2020-12-29 02:13:24 --> Helper loaded: form_helper
INFO - 2020-12-29 02:13:24 --> Helper loaded: my_helper
INFO - 2020-12-29 02:13:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:13:24 --> Controller Class Initialized
DEBUG - 2020-12-29 02:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-12-29 02:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:13:24 --> Final output sent to browser
DEBUG - 2020-12-29 02:13:24 --> Total execution time: 0.2888
INFO - 2020-12-29 02:13:25 --> Config Class Initialized
INFO - 2020-12-29 02:13:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:25 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:25 --> URI Class Initialized
INFO - 2020-12-29 02:13:25 --> Router Class Initialized
INFO - 2020-12-29 02:13:25 --> Output Class Initialized
INFO - 2020-12-29 02:13:25 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:25 --> Input Class Initialized
INFO - 2020-12-29 02:13:25 --> Language Class Initialized
INFO - 2020-12-29 02:13:25 --> Language Class Initialized
INFO - 2020-12-29 02:13:25 --> Config Class Initialized
INFO - 2020-12-29 02:13:25 --> Loader Class Initialized
INFO - 2020-12-29 02:13:25 --> Helper loaded: url_helper
INFO - 2020-12-29 02:13:25 --> Helper loaded: file_helper
INFO - 2020-12-29 02:13:25 --> Helper loaded: form_helper
INFO - 2020-12-29 02:13:25 --> Helper loaded: my_helper
INFO - 2020-12-29 02:13:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:13:25 --> Controller Class Initialized
DEBUG - 2020-12-29 02:13:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-29 02:13:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:13:25 --> Final output sent to browser
DEBUG - 2020-12-29 02:13:25 --> Total execution time: 0.2909
INFO - 2020-12-29 02:13:33 --> Config Class Initialized
INFO - 2020-12-29 02:13:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:33 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:33 --> URI Class Initialized
INFO - 2020-12-29 02:13:33 --> Router Class Initialized
INFO - 2020-12-29 02:13:33 --> Output Class Initialized
INFO - 2020-12-29 02:13:33 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:33 --> Input Class Initialized
INFO - 2020-12-29 02:13:33 --> Language Class Initialized
INFO - 2020-12-29 02:13:33 --> Language Class Initialized
INFO - 2020-12-29 02:13:33 --> Config Class Initialized
INFO - 2020-12-29 02:13:33 --> Loader Class Initialized
INFO - 2020-12-29 02:13:33 --> Helper loaded: url_helper
INFO - 2020-12-29 02:13:33 --> Helper loaded: file_helper
INFO - 2020-12-29 02:13:33 --> Helper loaded: form_helper
INFO - 2020-12-29 02:13:33 --> Helper loaded: my_helper
INFO - 2020-12-29 02:13:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:13:34 --> Controller Class Initialized
INFO - 2020-12-29 02:13:34 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:13:34 --> Config Class Initialized
INFO - 2020-12-29 02:13:34 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:34 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:34 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:34 --> URI Class Initialized
INFO - 2020-12-29 02:13:34 --> Router Class Initialized
INFO - 2020-12-29 02:13:34 --> Output Class Initialized
INFO - 2020-12-29 02:13:34 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:34 --> Input Class Initialized
INFO - 2020-12-29 02:13:34 --> Language Class Initialized
INFO - 2020-12-29 02:13:34 --> Language Class Initialized
INFO - 2020-12-29 02:13:34 --> Config Class Initialized
INFO - 2020-12-29 02:13:34 --> Loader Class Initialized
INFO - 2020-12-29 02:13:34 --> Helper loaded: url_helper
INFO - 2020-12-29 02:13:34 --> Helper loaded: file_helper
INFO - 2020-12-29 02:13:34 --> Helper loaded: form_helper
INFO - 2020-12-29 02:13:34 --> Helper loaded: my_helper
INFO - 2020-12-29 02:13:34 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:13:34 --> Controller Class Initialized
DEBUG - 2020-12-29 02:13:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 02:13:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:13:34 --> Final output sent to browser
DEBUG - 2020-12-29 02:13:34 --> Total execution time: 0.2755
INFO - 2020-12-29 02:13:40 --> Config Class Initialized
INFO - 2020-12-29 02:13:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:40 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:40 --> URI Class Initialized
INFO - 2020-12-29 02:13:40 --> Router Class Initialized
INFO - 2020-12-29 02:13:41 --> Output Class Initialized
INFO - 2020-12-29 02:13:41 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:41 --> Input Class Initialized
INFO - 2020-12-29 02:13:41 --> Language Class Initialized
INFO - 2020-12-29 02:13:41 --> Language Class Initialized
INFO - 2020-12-29 02:13:41 --> Config Class Initialized
INFO - 2020-12-29 02:13:41 --> Loader Class Initialized
INFO - 2020-12-29 02:13:41 --> Helper loaded: url_helper
INFO - 2020-12-29 02:13:41 --> Helper loaded: file_helper
INFO - 2020-12-29 02:13:41 --> Helper loaded: form_helper
INFO - 2020-12-29 02:13:41 --> Helper loaded: my_helper
INFO - 2020-12-29 02:13:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:13:41 --> Controller Class Initialized
INFO - 2020-12-29 02:13:41 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:13:41 --> Final output sent to browser
DEBUG - 2020-12-29 02:13:41 --> Total execution time: 0.3267
INFO - 2020-12-29 02:13:42 --> Config Class Initialized
INFO - 2020-12-29 02:13:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:42 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:42 --> URI Class Initialized
INFO - 2020-12-29 02:13:42 --> Router Class Initialized
INFO - 2020-12-29 02:13:42 --> Output Class Initialized
INFO - 2020-12-29 02:13:42 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:42 --> Input Class Initialized
INFO - 2020-12-29 02:13:42 --> Language Class Initialized
INFO - 2020-12-29 02:13:42 --> Language Class Initialized
INFO - 2020-12-29 02:13:42 --> Config Class Initialized
INFO - 2020-12-29 02:13:42 --> Loader Class Initialized
INFO - 2020-12-29 02:13:42 --> Helper loaded: url_helper
INFO - 2020-12-29 02:13:42 --> Helper loaded: file_helper
INFO - 2020-12-29 02:13:42 --> Helper loaded: form_helper
INFO - 2020-12-29 02:13:42 --> Helper loaded: my_helper
INFO - 2020-12-29 02:13:42 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:13:42 --> Controller Class Initialized
DEBUG - 2020-12-29 02:13:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 02:13:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:13:42 --> Final output sent to browser
DEBUG - 2020-12-29 02:13:42 --> Total execution time: 0.3845
INFO - 2020-12-29 02:13:49 --> Config Class Initialized
INFO - 2020-12-29 02:13:49 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:49 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:49 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:49 --> URI Class Initialized
INFO - 2020-12-29 02:13:49 --> Router Class Initialized
INFO - 2020-12-29 02:13:49 --> Output Class Initialized
INFO - 2020-12-29 02:13:49 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:49 --> Input Class Initialized
INFO - 2020-12-29 02:13:50 --> Language Class Initialized
ERROR - 2020-12-29 02:13:50 --> 404 Page Not Found: /index
INFO - 2020-12-29 02:13:51 --> Config Class Initialized
INFO - 2020-12-29 02:13:51 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:13:51 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:13:51 --> Utf8 Class Initialized
INFO - 2020-12-29 02:13:51 --> URI Class Initialized
INFO - 2020-12-29 02:13:51 --> Router Class Initialized
INFO - 2020-12-29 02:13:51 --> Output Class Initialized
INFO - 2020-12-29 02:13:51 --> Security Class Initialized
DEBUG - 2020-12-29 02:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:13:51 --> Input Class Initialized
INFO - 2020-12-29 02:13:51 --> Language Class Initialized
INFO - 2020-12-29 02:13:51 --> Language Class Initialized
INFO - 2020-12-29 02:13:51 --> Config Class Initialized
INFO - 2020-12-29 02:13:51 --> Loader Class Initialized
INFO - 2020-12-29 02:13:51 --> Helper loaded: url_helper
INFO - 2020-12-29 02:13:51 --> Helper loaded: file_helper
INFO - 2020-12-29 02:13:51 --> Helper loaded: form_helper
INFO - 2020-12-29 02:13:51 --> Helper loaded: my_helper
INFO - 2020-12-29 02:13:51 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:13:51 --> Controller Class Initialized
DEBUG - 2020-12-29 02:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 02:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:13:51 --> Final output sent to browser
DEBUG - 2020-12-29 02:13:51 --> Total execution time: 0.3005
INFO - 2020-12-29 02:14:19 --> Config Class Initialized
INFO - 2020-12-29 02:14:19 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:14:19 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:14:19 --> Utf8 Class Initialized
INFO - 2020-12-29 02:14:19 --> URI Class Initialized
INFO - 2020-12-29 02:14:19 --> Router Class Initialized
INFO - 2020-12-29 02:14:19 --> Output Class Initialized
INFO - 2020-12-29 02:14:19 --> Security Class Initialized
DEBUG - 2020-12-29 02:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:14:19 --> Input Class Initialized
INFO - 2020-12-29 02:14:19 --> Language Class Initialized
INFO - 2020-12-29 02:14:19 --> Language Class Initialized
INFO - 2020-12-29 02:14:19 --> Config Class Initialized
INFO - 2020-12-29 02:14:19 --> Loader Class Initialized
INFO - 2020-12-29 02:14:19 --> Helper loaded: url_helper
INFO - 2020-12-29 02:14:19 --> Helper loaded: file_helper
INFO - 2020-12-29 02:14:19 --> Helper loaded: form_helper
INFO - 2020-12-29 02:14:19 --> Helper loaded: my_helper
INFO - 2020-12-29 02:14:19 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:14:19 --> Controller Class Initialized
DEBUG - 2020-12-29 02:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 02:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:14:19 --> Final output sent to browser
DEBUG - 2020-12-29 02:14:19 --> Total execution time: 0.2645
INFO - 2020-12-29 02:14:55 --> Config Class Initialized
INFO - 2020-12-29 02:14:55 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:14:55 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:14:55 --> Utf8 Class Initialized
INFO - 2020-12-29 02:14:55 --> URI Class Initialized
INFO - 2020-12-29 02:14:55 --> Router Class Initialized
INFO - 2020-12-29 02:14:55 --> Output Class Initialized
INFO - 2020-12-29 02:14:55 --> Security Class Initialized
DEBUG - 2020-12-29 02:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:14:55 --> Input Class Initialized
INFO - 2020-12-29 02:14:55 --> Language Class Initialized
INFO - 2020-12-29 02:14:55 --> Language Class Initialized
INFO - 2020-12-29 02:14:55 --> Config Class Initialized
INFO - 2020-12-29 02:14:55 --> Loader Class Initialized
INFO - 2020-12-29 02:14:55 --> Helper loaded: url_helper
INFO - 2020-12-29 02:14:55 --> Helper loaded: file_helper
INFO - 2020-12-29 02:14:55 --> Helper loaded: form_helper
INFO - 2020-12-29 02:14:55 --> Helper loaded: my_helper
INFO - 2020-12-29 02:14:55 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:14:55 --> Controller Class Initialized
DEBUG - 2020-12-29 02:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 02:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:14:55 --> Final output sent to browser
DEBUG - 2020-12-29 02:14:56 --> Total execution time: 0.3097
INFO - 2020-12-29 02:14:56 --> Config Class Initialized
INFO - 2020-12-29 02:14:56 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:14:56 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:14:56 --> Utf8 Class Initialized
INFO - 2020-12-29 02:14:56 --> URI Class Initialized
INFO - 2020-12-29 02:14:56 --> Router Class Initialized
INFO - 2020-12-29 02:14:56 --> Output Class Initialized
INFO - 2020-12-29 02:14:56 --> Security Class Initialized
DEBUG - 2020-12-29 02:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:14:56 --> Input Class Initialized
INFO - 2020-12-29 02:14:56 --> Language Class Initialized
INFO - 2020-12-29 02:14:56 --> Language Class Initialized
INFO - 2020-12-29 02:14:56 --> Config Class Initialized
INFO - 2020-12-29 02:14:56 --> Loader Class Initialized
INFO - 2020-12-29 02:14:56 --> Helper loaded: url_helper
INFO - 2020-12-29 02:14:56 --> Helper loaded: file_helper
INFO - 2020-12-29 02:14:56 --> Helper loaded: form_helper
INFO - 2020-12-29 02:14:56 --> Helper loaded: my_helper
INFO - 2020-12-29 02:14:56 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:14:56 --> Controller Class Initialized
INFO - 2020-12-29 02:14:57 --> Config Class Initialized
INFO - 2020-12-29 02:14:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:14:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:14:57 --> Utf8 Class Initialized
INFO - 2020-12-29 02:14:57 --> URI Class Initialized
INFO - 2020-12-29 02:14:57 --> Router Class Initialized
INFO - 2020-12-29 02:14:57 --> Output Class Initialized
INFO - 2020-12-29 02:14:57 --> Security Class Initialized
DEBUG - 2020-12-29 02:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:14:57 --> Input Class Initialized
INFO - 2020-12-29 02:14:57 --> Language Class Initialized
INFO - 2020-12-29 02:14:57 --> Language Class Initialized
INFO - 2020-12-29 02:14:57 --> Config Class Initialized
INFO - 2020-12-29 02:14:57 --> Loader Class Initialized
INFO - 2020-12-29 02:14:57 --> Helper loaded: url_helper
INFO - 2020-12-29 02:14:57 --> Helper loaded: file_helper
INFO - 2020-12-29 02:14:57 --> Helper loaded: form_helper
INFO - 2020-12-29 02:14:57 --> Helper loaded: my_helper
INFO - 2020-12-29 02:14:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:14:57 --> Controller Class Initialized
INFO - 2020-12-29 02:14:57 --> Final output sent to browser
DEBUG - 2020-12-29 02:14:57 --> Total execution time: 0.2714
INFO - 2020-12-29 02:15:36 --> Config Class Initialized
INFO - 2020-12-29 02:15:36 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:15:36 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:15:36 --> Utf8 Class Initialized
INFO - 2020-12-29 02:15:36 --> URI Class Initialized
INFO - 2020-12-29 02:15:36 --> Router Class Initialized
INFO - 2020-12-29 02:15:36 --> Output Class Initialized
INFO - 2020-12-29 02:15:36 --> Security Class Initialized
DEBUG - 2020-12-29 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:15:36 --> Input Class Initialized
INFO - 2020-12-29 02:15:36 --> Language Class Initialized
INFO - 2020-12-29 02:15:36 --> Language Class Initialized
INFO - 2020-12-29 02:15:36 --> Config Class Initialized
INFO - 2020-12-29 02:15:36 --> Loader Class Initialized
INFO - 2020-12-29 02:15:36 --> Helper loaded: url_helper
INFO - 2020-12-29 02:15:36 --> Helper loaded: file_helper
INFO - 2020-12-29 02:15:36 --> Helper loaded: form_helper
INFO - 2020-12-29 02:15:36 --> Helper loaded: my_helper
INFO - 2020-12-29 02:15:36 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:15:36 --> Controller Class Initialized
ERROR - 2020-12-29 02:15:36 --> Severity: Notice --> Undefined index: is_sikap C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-12-29 02:15:36 --> Final output sent to browser
DEBUG - 2020-12-29 02:15:36 --> Total execution time: 0.3524
INFO - 2020-12-29 02:15:42 --> Config Class Initialized
INFO - 2020-12-29 02:15:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:15:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:15:42 --> Utf8 Class Initialized
INFO - 2020-12-29 02:15:42 --> URI Class Initialized
INFO - 2020-12-29 02:15:42 --> Router Class Initialized
INFO - 2020-12-29 02:15:42 --> Output Class Initialized
INFO - 2020-12-29 02:15:42 --> Security Class Initialized
DEBUG - 2020-12-29 02:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:15:42 --> Input Class Initialized
INFO - 2020-12-29 02:15:42 --> Language Class Initialized
INFO - 2020-12-29 02:15:42 --> Language Class Initialized
INFO - 2020-12-29 02:15:42 --> Config Class Initialized
INFO - 2020-12-29 02:15:42 --> Loader Class Initialized
INFO - 2020-12-29 02:15:42 --> Helper loaded: url_helper
INFO - 2020-12-29 02:15:42 --> Helper loaded: file_helper
INFO - 2020-12-29 02:15:42 --> Helper loaded: form_helper
INFO - 2020-12-29 02:15:42 --> Helper loaded: my_helper
INFO - 2020-12-29 02:15:42 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:15:42 --> Controller Class Initialized
ERROR - 2020-12-29 02:15:42 --> Severity: Notice --> Undefined index: is_sikap C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-12-29 02:15:42 --> Final output sent to browser
DEBUG - 2020-12-29 02:15:42 --> Total execution time: 0.2693
INFO - 2020-12-29 02:17:19 --> Config Class Initialized
INFO - 2020-12-29 02:17:19 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:17:19 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:17:19 --> Utf8 Class Initialized
INFO - 2020-12-29 02:17:19 --> URI Class Initialized
INFO - 2020-12-29 02:17:20 --> Router Class Initialized
INFO - 2020-12-29 02:17:20 --> Output Class Initialized
INFO - 2020-12-29 02:17:20 --> Security Class Initialized
DEBUG - 2020-12-29 02:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:17:20 --> Input Class Initialized
INFO - 2020-12-29 02:17:20 --> Language Class Initialized
INFO - 2020-12-29 02:17:20 --> Language Class Initialized
INFO - 2020-12-29 02:17:20 --> Config Class Initialized
INFO - 2020-12-29 02:17:20 --> Loader Class Initialized
INFO - 2020-12-29 02:17:20 --> Helper loaded: url_helper
INFO - 2020-12-29 02:17:20 --> Helper loaded: file_helper
INFO - 2020-12-29 02:17:20 --> Helper loaded: form_helper
INFO - 2020-12-29 02:17:20 --> Helper loaded: my_helper
INFO - 2020-12-29 02:17:20 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:17:20 --> Controller Class Initialized
DEBUG - 2020-12-29 02:17:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 02:17:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:17:20 --> Final output sent to browser
DEBUG - 2020-12-29 02:17:20 --> Total execution time: 0.3034
INFO - 2020-12-29 02:17:20 --> Config Class Initialized
INFO - 2020-12-29 02:17:20 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:17:20 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:17:20 --> Utf8 Class Initialized
INFO - 2020-12-29 02:17:20 --> URI Class Initialized
INFO - 2020-12-29 02:17:20 --> Router Class Initialized
INFO - 2020-12-29 02:17:20 --> Output Class Initialized
INFO - 2020-12-29 02:17:20 --> Security Class Initialized
DEBUG - 2020-12-29 02:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:17:20 --> Input Class Initialized
INFO - 2020-12-29 02:17:20 --> Language Class Initialized
INFO - 2020-12-29 02:17:20 --> Language Class Initialized
INFO - 2020-12-29 02:17:20 --> Config Class Initialized
INFO - 2020-12-29 02:17:20 --> Loader Class Initialized
INFO - 2020-12-29 02:17:20 --> Helper loaded: url_helper
INFO - 2020-12-29 02:17:20 --> Helper loaded: file_helper
INFO - 2020-12-29 02:17:20 --> Helper loaded: form_helper
INFO - 2020-12-29 02:17:20 --> Helper loaded: my_helper
INFO - 2020-12-29 02:17:20 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:17:20 --> Controller Class Initialized
INFO - 2020-12-29 02:17:21 --> Config Class Initialized
INFO - 2020-12-29 02:17:21 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:17:21 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:17:21 --> Utf8 Class Initialized
INFO - 2020-12-29 02:17:21 --> URI Class Initialized
INFO - 2020-12-29 02:17:21 --> Router Class Initialized
INFO - 2020-12-29 02:17:21 --> Output Class Initialized
INFO - 2020-12-29 02:17:21 --> Security Class Initialized
DEBUG - 2020-12-29 02:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:17:21 --> Input Class Initialized
INFO - 2020-12-29 02:17:21 --> Language Class Initialized
INFO - 2020-12-29 02:17:21 --> Language Class Initialized
INFO - 2020-12-29 02:17:21 --> Config Class Initialized
INFO - 2020-12-29 02:17:21 --> Loader Class Initialized
INFO - 2020-12-29 02:17:21 --> Helper loaded: url_helper
INFO - 2020-12-29 02:17:21 --> Helper loaded: file_helper
INFO - 2020-12-29 02:17:21 --> Helper loaded: form_helper
INFO - 2020-12-29 02:17:21 --> Helper loaded: my_helper
INFO - 2020-12-29 02:17:21 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:17:21 --> Controller Class Initialized
INFO - 2020-12-29 02:17:21 --> Final output sent to browser
DEBUG - 2020-12-29 02:17:21 --> Total execution time: 0.2621
INFO - 2020-12-29 02:17:38 --> Config Class Initialized
INFO - 2020-12-29 02:17:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:17:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:17:38 --> Utf8 Class Initialized
INFO - 2020-12-29 02:17:38 --> URI Class Initialized
INFO - 2020-12-29 02:17:38 --> Router Class Initialized
INFO - 2020-12-29 02:17:38 --> Output Class Initialized
INFO - 2020-12-29 02:17:38 --> Security Class Initialized
DEBUG - 2020-12-29 02:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:17:38 --> Input Class Initialized
INFO - 2020-12-29 02:17:39 --> Language Class Initialized
INFO - 2020-12-29 02:17:39 --> Language Class Initialized
INFO - 2020-12-29 02:17:39 --> Config Class Initialized
INFO - 2020-12-29 02:17:39 --> Loader Class Initialized
INFO - 2020-12-29 02:17:39 --> Helper loaded: url_helper
INFO - 2020-12-29 02:17:39 --> Helper loaded: file_helper
INFO - 2020-12-29 02:17:39 --> Helper loaded: form_helper
INFO - 2020-12-29 02:17:39 --> Helper loaded: my_helper
INFO - 2020-12-29 02:17:39 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:17:39 --> Controller Class Initialized
ERROR - 2020-12-29 02:17:39 --> Severity: Notice --> Undefined index: is_sikap C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-12-29 02:17:39 --> Final output sent to browser
DEBUG - 2020-12-29 02:17:39 --> Total execution time: 0.2778
INFO - 2020-12-29 02:17:43 --> Config Class Initialized
INFO - 2020-12-29 02:17:43 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:17:43 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:17:43 --> Utf8 Class Initialized
INFO - 2020-12-29 02:17:44 --> URI Class Initialized
INFO - 2020-12-29 02:17:44 --> Router Class Initialized
INFO - 2020-12-29 02:17:44 --> Output Class Initialized
INFO - 2020-12-29 02:17:44 --> Security Class Initialized
DEBUG - 2020-12-29 02:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:17:44 --> Input Class Initialized
INFO - 2020-12-29 02:17:44 --> Language Class Initialized
INFO - 2020-12-29 02:17:44 --> Language Class Initialized
INFO - 2020-12-29 02:17:44 --> Config Class Initialized
INFO - 2020-12-29 02:17:44 --> Loader Class Initialized
INFO - 2020-12-29 02:17:44 --> Helper loaded: url_helper
INFO - 2020-12-29 02:17:44 --> Helper loaded: file_helper
INFO - 2020-12-29 02:17:44 --> Helper loaded: form_helper
INFO - 2020-12-29 02:17:44 --> Helper loaded: my_helper
INFO - 2020-12-29 02:17:44 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:17:44 --> Controller Class Initialized
ERROR - 2020-12-29 02:17:44 --> Severity: Notice --> Undefined index: is_sikap C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-12-29 02:17:44 --> Final output sent to browser
DEBUG - 2020-12-29 02:17:44 --> Total execution time: 0.2599
INFO - 2020-12-29 02:27:15 --> Config Class Initialized
INFO - 2020-12-29 02:27:15 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:27:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:27:15 --> Utf8 Class Initialized
INFO - 2020-12-29 02:27:15 --> URI Class Initialized
INFO - 2020-12-29 02:27:15 --> Router Class Initialized
INFO - 2020-12-29 02:27:15 --> Output Class Initialized
INFO - 2020-12-29 02:27:15 --> Security Class Initialized
DEBUG - 2020-12-29 02:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:27:15 --> Input Class Initialized
INFO - 2020-12-29 02:27:15 --> Language Class Initialized
INFO - 2020-12-29 02:27:15 --> Language Class Initialized
INFO - 2020-12-29 02:27:15 --> Config Class Initialized
INFO - 2020-12-29 02:27:15 --> Loader Class Initialized
INFO - 2020-12-29 02:27:15 --> Helper loaded: url_helper
INFO - 2020-12-29 02:27:15 --> Helper loaded: file_helper
INFO - 2020-12-29 02:27:15 --> Helper loaded: form_helper
INFO - 2020-12-29 02:27:15 --> Helper loaded: my_helper
INFO - 2020-12-29 02:27:15 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:27:15 --> Controller Class Initialized
ERROR - 2020-12-29 02:27:15 --> Severity: Notice --> Undefined index: is_sikap C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-12-29 02:27:15 --> Final output sent to browser
DEBUG - 2020-12-29 02:27:15 --> Total execution time: 0.2887
INFO - 2020-12-29 02:28:28 --> Config Class Initialized
INFO - 2020-12-29 02:28:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:28:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:28:28 --> Utf8 Class Initialized
INFO - 2020-12-29 02:28:28 --> URI Class Initialized
INFO - 2020-12-29 02:28:28 --> Router Class Initialized
INFO - 2020-12-29 02:28:28 --> Output Class Initialized
INFO - 2020-12-29 02:28:28 --> Security Class Initialized
DEBUG - 2020-12-29 02:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:28:28 --> Input Class Initialized
INFO - 2020-12-29 02:28:28 --> Language Class Initialized
INFO - 2020-12-29 02:28:28 --> Language Class Initialized
INFO - 2020-12-29 02:28:28 --> Config Class Initialized
INFO - 2020-12-29 02:28:28 --> Loader Class Initialized
INFO - 2020-12-29 02:28:28 --> Helper loaded: url_helper
INFO - 2020-12-29 02:28:28 --> Helper loaded: file_helper
INFO - 2020-12-29 02:28:28 --> Helper loaded: form_helper
INFO - 2020-12-29 02:28:28 --> Helper loaded: my_helper
INFO - 2020-12-29 02:28:28 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:28:28 --> Controller Class Initialized
DEBUG - 2020-12-29 02:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 02:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:28:28 --> Final output sent to browser
DEBUG - 2020-12-29 02:28:28 --> Total execution time: 0.3470
INFO - 2020-12-29 02:28:29 --> Config Class Initialized
INFO - 2020-12-29 02:28:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:28:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:28:29 --> Utf8 Class Initialized
INFO - 2020-12-29 02:28:29 --> URI Class Initialized
INFO - 2020-12-29 02:28:29 --> Router Class Initialized
INFO - 2020-12-29 02:28:29 --> Output Class Initialized
INFO - 2020-12-29 02:28:29 --> Security Class Initialized
DEBUG - 2020-12-29 02:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:28:29 --> Input Class Initialized
INFO - 2020-12-29 02:28:29 --> Language Class Initialized
INFO - 2020-12-29 02:28:29 --> Language Class Initialized
INFO - 2020-12-29 02:28:29 --> Config Class Initialized
INFO - 2020-12-29 02:28:29 --> Loader Class Initialized
INFO - 2020-12-29 02:28:29 --> Helper loaded: url_helper
INFO - 2020-12-29 02:28:29 --> Helper loaded: file_helper
INFO - 2020-12-29 02:28:29 --> Helper loaded: form_helper
INFO - 2020-12-29 02:28:29 --> Helper loaded: my_helper
INFO - 2020-12-29 02:28:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:28:29 --> Controller Class Initialized
INFO - 2020-12-29 02:28:30 --> Config Class Initialized
INFO - 2020-12-29 02:28:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:28:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:28:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:28:30 --> URI Class Initialized
INFO - 2020-12-29 02:28:30 --> Router Class Initialized
INFO - 2020-12-29 02:28:30 --> Output Class Initialized
INFO - 2020-12-29 02:28:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:28:30 --> Input Class Initialized
INFO - 2020-12-29 02:28:30 --> Language Class Initialized
INFO - 2020-12-29 02:28:30 --> Language Class Initialized
INFO - 2020-12-29 02:28:30 --> Config Class Initialized
INFO - 2020-12-29 02:28:30 --> Loader Class Initialized
INFO - 2020-12-29 02:28:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:28:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:28:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:28:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:28:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:28:30 --> Controller Class Initialized
INFO - 2020-12-29 02:28:30 --> Final output sent to browser
DEBUG - 2020-12-29 02:28:30 --> Total execution time: 0.2778
INFO - 2020-12-29 02:28:39 --> Config Class Initialized
INFO - 2020-12-29 02:28:39 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:28:39 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:28:39 --> Utf8 Class Initialized
INFO - 2020-12-29 02:28:39 --> URI Class Initialized
INFO - 2020-12-29 02:28:39 --> Router Class Initialized
INFO - 2020-12-29 02:28:39 --> Output Class Initialized
INFO - 2020-12-29 02:28:39 --> Security Class Initialized
DEBUG - 2020-12-29 02:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:28:39 --> Input Class Initialized
INFO - 2020-12-29 02:28:39 --> Language Class Initialized
INFO - 2020-12-29 02:28:39 --> Language Class Initialized
INFO - 2020-12-29 02:28:39 --> Config Class Initialized
INFO - 2020-12-29 02:28:39 --> Loader Class Initialized
INFO - 2020-12-29 02:28:39 --> Helper loaded: url_helper
INFO - 2020-12-29 02:28:39 --> Helper loaded: file_helper
INFO - 2020-12-29 02:28:39 --> Helper loaded: form_helper
INFO - 2020-12-29 02:28:39 --> Helper loaded: my_helper
INFO - 2020-12-29 02:28:39 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:28:39 --> Controller Class Initialized
ERROR - 2020-12-29 02:28:39 --> Severity: Notice --> Undefined index: is_sikap C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-12-29 02:28:39 --> Final output sent to browser
DEBUG - 2020-12-29 02:28:39 --> Total execution time: 0.2887
INFO - 2020-12-29 02:33:24 --> Config Class Initialized
INFO - 2020-12-29 02:33:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:33:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:33:24 --> Utf8 Class Initialized
INFO - 2020-12-29 02:33:24 --> URI Class Initialized
INFO - 2020-12-29 02:33:24 --> Router Class Initialized
INFO - 2020-12-29 02:33:24 --> Output Class Initialized
INFO - 2020-12-29 02:33:24 --> Security Class Initialized
DEBUG - 2020-12-29 02:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:33:24 --> Input Class Initialized
INFO - 2020-12-29 02:33:24 --> Language Class Initialized
INFO - 2020-12-29 02:33:24 --> Language Class Initialized
INFO - 2020-12-29 02:33:24 --> Config Class Initialized
INFO - 2020-12-29 02:33:24 --> Loader Class Initialized
INFO - 2020-12-29 02:33:24 --> Helper loaded: url_helper
INFO - 2020-12-29 02:33:24 --> Helper loaded: file_helper
INFO - 2020-12-29 02:33:24 --> Helper loaded: form_helper
INFO - 2020-12-29 02:33:24 --> Helper loaded: my_helper
INFO - 2020-12-29 02:33:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:33:24 --> Controller Class Initialized
DEBUG - 2020-12-29 02:33:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 02:33:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:33:24 --> Final output sent to browser
DEBUG - 2020-12-29 02:33:25 --> Total execution time: 0.3307
INFO - 2020-12-29 02:33:25 --> Config Class Initialized
INFO - 2020-12-29 02:33:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:33:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:33:25 --> Utf8 Class Initialized
INFO - 2020-12-29 02:33:25 --> URI Class Initialized
INFO - 2020-12-29 02:33:25 --> Router Class Initialized
INFO - 2020-12-29 02:33:25 --> Output Class Initialized
INFO - 2020-12-29 02:33:25 --> Security Class Initialized
DEBUG - 2020-12-29 02:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:33:25 --> Input Class Initialized
INFO - 2020-12-29 02:33:25 --> Language Class Initialized
INFO - 2020-12-29 02:33:25 --> Language Class Initialized
INFO - 2020-12-29 02:33:25 --> Config Class Initialized
INFO - 2020-12-29 02:33:25 --> Loader Class Initialized
INFO - 2020-12-29 02:33:25 --> Helper loaded: url_helper
INFO - 2020-12-29 02:33:25 --> Helper loaded: file_helper
INFO - 2020-12-29 02:33:25 --> Helper loaded: form_helper
INFO - 2020-12-29 02:33:25 --> Helper loaded: my_helper
INFO - 2020-12-29 02:33:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:33:25 --> Controller Class Initialized
INFO - 2020-12-29 02:33:26 --> Config Class Initialized
INFO - 2020-12-29 02:33:26 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:33:26 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:33:26 --> Utf8 Class Initialized
INFO - 2020-12-29 02:33:26 --> URI Class Initialized
INFO - 2020-12-29 02:33:26 --> Router Class Initialized
INFO - 2020-12-29 02:33:26 --> Output Class Initialized
INFO - 2020-12-29 02:33:26 --> Security Class Initialized
DEBUG - 2020-12-29 02:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:33:26 --> Input Class Initialized
INFO - 2020-12-29 02:33:26 --> Language Class Initialized
INFO - 2020-12-29 02:33:26 --> Language Class Initialized
INFO - 2020-12-29 02:33:26 --> Config Class Initialized
INFO - 2020-12-29 02:33:26 --> Loader Class Initialized
INFO - 2020-12-29 02:33:26 --> Helper loaded: url_helper
INFO - 2020-12-29 02:33:26 --> Helper loaded: file_helper
INFO - 2020-12-29 02:33:26 --> Helper loaded: form_helper
INFO - 2020-12-29 02:33:26 --> Helper loaded: my_helper
INFO - 2020-12-29 02:33:26 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:33:26 --> Controller Class Initialized
INFO - 2020-12-29 02:33:26 --> Final output sent to browser
DEBUG - 2020-12-29 02:33:26 --> Total execution time: 0.2465
INFO - 2020-12-29 02:33:37 --> Config Class Initialized
INFO - 2020-12-29 02:33:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:33:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:33:37 --> Utf8 Class Initialized
INFO - 2020-12-29 02:33:37 --> URI Class Initialized
INFO - 2020-12-29 02:33:37 --> Router Class Initialized
INFO - 2020-12-29 02:33:37 --> Output Class Initialized
INFO - 2020-12-29 02:33:37 --> Security Class Initialized
DEBUG - 2020-12-29 02:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:33:37 --> Input Class Initialized
INFO - 2020-12-29 02:33:37 --> Language Class Initialized
INFO - 2020-12-29 02:33:37 --> Language Class Initialized
INFO - 2020-12-29 02:33:37 --> Config Class Initialized
INFO - 2020-12-29 02:33:37 --> Loader Class Initialized
INFO - 2020-12-29 02:33:37 --> Helper loaded: url_helper
INFO - 2020-12-29 02:33:37 --> Helper loaded: file_helper
INFO - 2020-12-29 02:33:37 --> Helper loaded: form_helper
INFO - 2020-12-29 02:33:37 --> Helper loaded: my_helper
INFO - 2020-12-29 02:33:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:33:37 --> Controller Class Initialized
ERROR - 2020-12-29 02:33:37 --> Severity: Notice --> Undefined index: is_sikap C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 76
INFO - 2020-12-29 02:33:37 --> Final output sent to browser
DEBUG - 2020-12-29 02:33:37 --> Total execution time: 0.3008
INFO - 2020-12-29 02:37:28 --> Config Class Initialized
INFO - 2020-12-29 02:37:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:37:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:37:28 --> Utf8 Class Initialized
INFO - 2020-12-29 02:37:28 --> URI Class Initialized
INFO - 2020-12-29 02:37:28 --> Router Class Initialized
INFO - 2020-12-29 02:37:28 --> Output Class Initialized
INFO - 2020-12-29 02:37:28 --> Security Class Initialized
DEBUG - 2020-12-29 02:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:37:28 --> Input Class Initialized
INFO - 2020-12-29 02:37:28 --> Language Class Initialized
INFO - 2020-12-29 02:37:28 --> Language Class Initialized
INFO - 2020-12-29 02:37:28 --> Config Class Initialized
INFO - 2020-12-29 02:37:28 --> Loader Class Initialized
INFO - 2020-12-29 02:37:28 --> Helper loaded: url_helper
INFO - 2020-12-29 02:37:28 --> Helper loaded: file_helper
INFO - 2020-12-29 02:37:28 --> Helper loaded: form_helper
INFO - 2020-12-29 02:37:28 --> Helper loaded: my_helper
INFO - 2020-12-29 02:37:28 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:37:28 --> Controller Class Initialized
DEBUG - 2020-12-29 02:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 02:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:37:28 --> Final output sent to browser
DEBUG - 2020-12-29 02:37:28 --> Total execution time: 0.3285
INFO - 2020-12-29 02:37:29 --> Config Class Initialized
INFO - 2020-12-29 02:37:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:37:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:37:29 --> Utf8 Class Initialized
INFO - 2020-12-29 02:37:29 --> URI Class Initialized
INFO - 2020-12-29 02:37:29 --> Router Class Initialized
INFO - 2020-12-29 02:37:29 --> Output Class Initialized
INFO - 2020-12-29 02:37:29 --> Security Class Initialized
DEBUG - 2020-12-29 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:37:29 --> Input Class Initialized
INFO - 2020-12-29 02:37:29 --> Language Class Initialized
INFO - 2020-12-29 02:37:29 --> Language Class Initialized
INFO - 2020-12-29 02:37:29 --> Config Class Initialized
INFO - 2020-12-29 02:37:29 --> Loader Class Initialized
INFO - 2020-12-29 02:37:29 --> Helper loaded: url_helper
INFO - 2020-12-29 02:37:29 --> Helper loaded: file_helper
INFO - 2020-12-29 02:37:29 --> Helper loaded: form_helper
INFO - 2020-12-29 02:37:29 --> Helper loaded: my_helper
INFO - 2020-12-29 02:37:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:37:29 --> Controller Class Initialized
INFO - 2020-12-29 02:37:29 --> Config Class Initialized
INFO - 2020-12-29 02:37:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:37:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:37:29 --> Utf8 Class Initialized
INFO - 2020-12-29 02:37:29 --> URI Class Initialized
INFO - 2020-12-29 02:37:30 --> Router Class Initialized
INFO - 2020-12-29 02:37:30 --> Output Class Initialized
INFO - 2020-12-29 02:37:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:37:30 --> Input Class Initialized
INFO - 2020-12-29 02:37:30 --> Language Class Initialized
INFO - 2020-12-29 02:37:30 --> Language Class Initialized
INFO - 2020-12-29 02:37:30 --> Config Class Initialized
INFO - 2020-12-29 02:37:30 --> Loader Class Initialized
INFO - 2020-12-29 02:37:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:37:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:37:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:37:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:37:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:37:30 --> Controller Class Initialized
INFO - 2020-12-29 02:37:30 --> Final output sent to browser
DEBUG - 2020-12-29 02:37:30 --> Total execution time: 0.2459
INFO - 2020-12-29 02:37:43 --> Config Class Initialized
INFO - 2020-12-29 02:37:43 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:37:43 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:37:43 --> Utf8 Class Initialized
INFO - 2020-12-29 02:37:43 --> URI Class Initialized
INFO - 2020-12-29 02:37:43 --> Router Class Initialized
INFO - 2020-12-29 02:37:43 --> Output Class Initialized
INFO - 2020-12-29 02:37:43 --> Security Class Initialized
DEBUG - 2020-12-29 02:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:37:43 --> Input Class Initialized
INFO - 2020-12-29 02:37:43 --> Language Class Initialized
INFO - 2020-12-29 02:37:43 --> Language Class Initialized
INFO - 2020-12-29 02:37:43 --> Config Class Initialized
INFO - 2020-12-29 02:37:43 --> Loader Class Initialized
INFO - 2020-12-29 02:37:43 --> Helper loaded: url_helper
INFO - 2020-12-29 02:37:43 --> Helper loaded: file_helper
INFO - 2020-12-29 02:37:43 --> Helper loaded: form_helper
INFO - 2020-12-29 02:37:43 --> Helper loaded: my_helper
INFO - 2020-12-29 02:37:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:37:43 --> Controller Class Initialized
ERROR - 2020-12-29 02:37:43 --> Severity: Notice --> Undefined index: is_sikap C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 76
INFO - 2020-12-29 02:37:43 --> Final output sent to browser
DEBUG - 2020-12-29 02:37:43 --> Total execution time: 0.2906
INFO - 2020-12-29 02:37:57 --> Config Class Initialized
INFO - 2020-12-29 02:37:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:37:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:37:57 --> Utf8 Class Initialized
INFO - 2020-12-29 02:37:57 --> URI Class Initialized
INFO - 2020-12-29 02:37:57 --> Router Class Initialized
INFO - 2020-12-29 02:37:57 --> Output Class Initialized
INFO - 2020-12-29 02:37:57 --> Security Class Initialized
DEBUG - 2020-12-29 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:37:57 --> Input Class Initialized
INFO - 2020-12-29 02:37:57 --> Language Class Initialized
INFO - 2020-12-29 02:37:57 --> Language Class Initialized
INFO - 2020-12-29 02:37:57 --> Config Class Initialized
INFO - 2020-12-29 02:37:57 --> Loader Class Initialized
INFO - 2020-12-29 02:37:57 --> Helper loaded: url_helper
INFO - 2020-12-29 02:37:57 --> Helper loaded: file_helper
INFO - 2020-12-29 02:37:57 --> Helper loaded: form_helper
INFO - 2020-12-29 02:37:57 --> Helper loaded: my_helper
INFO - 2020-12-29 02:37:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:37:58 --> Controller Class Initialized
DEBUG - 2020-12-29 02:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 02:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:37:58 --> Final output sent to browser
DEBUG - 2020-12-29 02:37:58 --> Total execution time: 0.3130
INFO - 2020-12-29 02:37:58 --> Config Class Initialized
INFO - 2020-12-29 02:37:58 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:37:58 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:37:58 --> Utf8 Class Initialized
INFO - 2020-12-29 02:37:58 --> URI Class Initialized
INFO - 2020-12-29 02:37:58 --> Router Class Initialized
INFO - 2020-12-29 02:37:58 --> Output Class Initialized
INFO - 2020-12-29 02:37:58 --> Security Class Initialized
DEBUG - 2020-12-29 02:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:37:58 --> Input Class Initialized
INFO - 2020-12-29 02:37:58 --> Language Class Initialized
INFO - 2020-12-29 02:37:58 --> Language Class Initialized
INFO - 2020-12-29 02:37:58 --> Config Class Initialized
INFO - 2020-12-29 02:37:58 --> Loader Class Initialized
INFO - 2020-12-29 02:37:58 --> Helper loaded: url_helper
INFO - 2020-12-29 02:37:58 --> Helper loaded: file_helper
INFO - 2020-12-29 02:37:58 --> Helper loaded: form_helper
INFO - 2020-12-29 02:37:58 --> Helper loaded: my_helper
INFO - 2020-12-29 02:37:58 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:37:58 --> Controller Class Initialized
INFO - 2020-12-29 02:40:32 --> Config Class Initialized
INFO - 2020-12-29 02:40:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:32 --> URI Class Initialized
INFO - 2020-12-29 02:40:32 --> Router Class Initialized
INFO - 2020-12-29 02:40:32 --> Output Class Initialized
INFO - 2020-12-29 02:40:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:32 --> Input Class Initialized
INFO - 2020-12-29 02:40:32 --> Language Class Initialized
INFO - 2020-12-29 02:40:32 --> Language Class Initialized
INFO - 2020-12-29 02:40:32 --> Config Class Initialized
INFO - 2020-12-29 02:40:32 --> Loader Class Initialized
INFO - 2020-12-29 02:40:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:32 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:32 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:32 --> Controller Class Initialized
DEBUG - 2020-12-29 02:40:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 02:40:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:40:32 --> Final output sent to browser
DEBUG - 2020-12-29 02:40:32 --> Total execution time: 0.3552
INFO - 2020-12-29 02:40:32 --> Config Class Initialized
INFO - 2020-12-29 02:40:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:32 --> URI Class Initialized
INFO - 2020-12-29 02:40:32 --> Router Class Initialized
INFO - 2020-12-29 02:40:32 --> Output Class Initialized
INFO - 2020-12-29 02:40:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:32 --> Input Class Initialized
INFO - 2020-12-29 02:40:32 --> Language Class Initialized
INFO - 2020-12-29 02:40:32 --> Language Class Initialized
INFO - 2020-12-29 02:40:32 --> Config Class Initialized
INFO - 2020-12-29 02:40:32 --> Loader Class Initialized
INFO - 2020-12-29 02:40:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:32 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:32 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:32 --> Controller Class Initialized
INFO - 2020-12-29 02:40:33 --> Config Class Initialized
INFO - 2020-12-29 02:40:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:33 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:33 --> URI Class Initialized
INFO - 2020-12-29 02:40:33 --> Router Class Initialized
INFO - 2020-12-29 02:40:33 --> Output Class Initialized
INFO - 2020-12-29 02:40:33 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:33 --> Input Class Initialized
INFO - 2020-12-29 02:40:33 --> Language Class Initialized
INFO - 2020-12-29 02:40:33 --> Language Class Initialized
INFO - 2020-12-29 02:40:33 --> Config Class Initialized
INFO - 2020-12-29 02:40:33 --> Loader Class Initialized
INFO - 2020-12-29 02:40:33 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:33 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:33 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:33 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:33 --> Controller Class Initialized
INFO - 2020-12-29 02:40:33 --> Final output sent to browser
DEBUG - 2020-12-29 02:40:33 --> Total execution time: 0.2555
INFO - 2020-12-29 02:40:41 --> Config Class Initialized
INFO - 2020-12-29 02:40:41 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:41 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:41 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:41 --> URI Class Initialized
INFO - 2020-12-29 02:40:41 --> Router Class Initialized
INFO - 2020-12-29 02:40:41 --> Output Class Initialized
INFO - 2020-12-29 02:40:41 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:41 --> Input Class Initialized
INFO - 2020-12-29 02:40:41 --> Language Class Initialized
INFO - 2020-12-29 02:40:41 --> Language Class Initialized
INFO - 2020-12-29 02:40:41 --> Config Class Initialized
INFO - 2020-12-29 02:40:41 --> Loader Class Initialized
INFO - 2020-12-29 02:40:41 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:41 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:41 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:41 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:42 --> Controller Class Initialized
INFO - 2020-12-29 02:40:42 --> Final output sent to browser
DEBUG - 2020-12-29 02:40:42 --> Total execution time: 0.2769
INFO - 2020-12-29 02:40:42 --> Config Class Initialized
INFO - 2020-12-29 02:40:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:42 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:42 --> URI Class Initialized
INFO - 2020-12-29 02:40:42 --> Router Class Initialized
INFO - 2020-12-29 02:40:42 --> Output Class Initialized
INFO - 2020-12-29 02:40:42 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:42 --> Input Class Initialized
INFO - 2020-12-29 02:40:42 --> Language Class Initialized
INFO - 2020-12-29 02:40:42 --> Language Class Initialized
INFO - 2020-12-29 02:40:42 --> Config Class Initialized
INFO - 2020-12-29 02:40:42 --> Loader Class Initialized
INFO - 2020-12-29 02:40:42 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:42 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:42 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:42 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:42 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:42 --> Controller Class Initialized
INFO - 2020-12-29 02:50:04 --> Config Class Initialized
INFO - 2020-12-29 02:50:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:50:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:50:04 --> Utf8 Class Initialized
INFO - 2020-12-29 02:50:04 --> URI Class Initialized
INFO - 2020-12-29 02:50:04 --> Router Class Initialized
INFO - 2020-12-29 02:50:04 --> Output Class Initialized
INFO - 2020-12-29 02:50:04 --> Security Class Initialized
DEBUG - 2020-12-29 02:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:50:04 --> Input Class Initialized
INFO - 2020-12-29 02:50:05 --> Language Class Initialized
INFO - 2020-12-29 02:50:05 --> Language Class Initialized
INFO - 2020-12-29 02:50:05 --> Config Class Initialized
INFO - 2020-12-29 02:50:05 --> Loader Class Initialized
INFO - 2020-12-29 02:50:05 --> Helper loaded: url_helper
INFO - 2020-12-29 02:50:05 --> Helper loaded: file_helper
INFO - 2020-12-29 02:50:05 --> Helper loaded: form_helper
INFO - 2020-12-29 02:50:05 --> Helper loaded: my_helper
INFO - 2020-12-29 02:50:05 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:50:05 --> Controller Class Initialized
DEBUG - 2020-12-29 02:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 02:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:50:05 --> Final output sent to browser
DEBUG - 2020-12-29 02:50:05 --> Total execution time: 0.2781
INFO - 2020-12-29 02:50:05 --> Config Class Initialized
INFO - 2020-12-29 02:50:05 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:50:05 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:50:05 --> Utf8 Class Initialized
INFO - 2020-12-29 02:50:05 --> URI Class Initialized
INFO - 2020-12-29 02:50:05 --> Router Class Initialized
INFO - 2020-12-29 02:50:05 --> Output Class Initialized
INFO - 2020-12-29 02:50:05 --> Security Class Initialized
DEBUG - 2020-12-29 02:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:50:05 --> Input Class Initialized
INFO - 2020-12-29 02:50:05 --> Language Class Initialized
INFO - 2020-12-29 02:50:05 --> Language Class Initialized
INFO - 2020-12-29 02:50:05 --> Config Class Initialized
INFO - 2020-12-29 02:50:05 --> Loader Class Initialized
INFO - 2020-12-29 02:50:05 --> Helper loaded: url_helper
INFO - 2020-12-29 02:50:05 --> Helper loaded: file_helper
INFO - 2020-12-29 02:50:05 --> Helper loaded: form_helper
INFO - 2020-12-29 02:50:05 --> Helper loaded: my_helper
INFO - 2020-12-29 02:50:05 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:50:05 --> Controller Class Initialized
INFO - 2020-12-29 02:50:06 --> Config Class Initialized
INFO - 2020-12-29 02:50:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:50:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:50:06 --> Utf8 Class Initialized
INFO - 2020-12-29 02:50:06 --> URI Class Initialized
INFO - 2020-12-29 02:50:06 --> Router Class Initialized
INFO - 2020-12-29 02:50:06 --> Output Class Initialized
INFO - 2020-12-29 02:50:06 --> Security Class Initialized
DEBUG - 2020-12-29 02:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:50:06 --> Input Class Initialized
INFO - 2020-12-29 02:50:06 --> Language Class Initialized
INFO - 2020-12-29 02:50:06 --> Language Class Initialized
INFO - 2020-12-29 02:50:06 --> Config Class Initialized
INFO - 2020-12-29 02:50:06 --> Loader Class Initialized
INFO - 2020-12-29 02:50:06 --> Helper loaded: url_helper
INFO - 2020-12-29 02:50:06 --> Helper loaded: file_helper
INFO - 2020-12-29 02:50:06 --> Helper loaded: form_helper
INFO - 2020-12-29 02:50:06 --> Helper loaded: my_helper
INFO - 2020-12-29 02:50:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:50:06 --> Controller Class Initialized
DEBUG - 2020-12-29 02:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 02:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:50:06 --> Final output sent to browser
DEBUG - 2020-12-29 02:50:06 --> Total execution time: 0.3109
INFO - 2020-12-29 02:50:20 --> Config Class Initialized
INFO - 2020-12-29 02:50:20 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:50:20 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:50:20 --> Utf8 Class Initialized
INFO - 2020-12-29 02:50:20 --> URI Class Initialized
INFO - 2020-12-29 02:50:20 --> Router Class Initialized
INFO - 2020-12-29 02:50:20 --> Output Class Initialized
INFO - 2020-12-29 02:50:20 --> Security Class Initialized
DEBUG - 2020-12-29 02:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:50:20 --> Input Class Initialized
INFO - 2020-12-29 02:50:20 --> Language Class Initialized
INFO - 2020-12-29 02:50:20 --> Language Class Initialized
INFO - 2020-12-29 02:50:20 --> Config Class Initialized
INFO - 2020-12-29 02:50:20 --> Loader Class Initialized
INFO - 2020-12-29 02:50:20 --> Helper loaded: url_helper
INFO - 2020-12-29 02:50:20 --> Helper loaded: file_helper
INFO - 2020-12-29 02:50:20 --> Helper loaded: form_helper
INFO - 2020-12-29 02:50:20 --> Helper loaded: my_helper
INFO - 2020-12-29 02:50:20 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:50:20 --> Controller Class Initialized
INFO - 2020-12-29 02:50:20 --> Config Class Initialized
INFO - 2020-12-29 02:50:20 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:50:20 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:50:20 --> Utf8 Class Initialized
INFO - 2020-12-29 02:50:20 --> URI Class Initialized
INFO - 2020-12-29 02:50:20 --> Router Class Initialized
INFO - 2020-12-29 02:50:20 --> Output Class Initialized
INFO - 2020-12-29 02:50:20 --> Security Class Initialized
DEBUG - 2020-12-29 02:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:50:20 --> Input Class Initialized
INFO - 2020-12-29 02:50:20 --> Language Class Initialized
INFO - 2020-12-29 02:50:20 --> Language Class Initialized
INFO - 2020-12-29 02:50:21 --> Config Class Initialized
INFO - 2020-12-29 02:50:21 --> Loader Class Initialized
INFO - 2020-12-29 02:50:21 --> Helper loaded: url_helper
INFO - 2020-12-29 02:50:21 --> Helper loaded: file_helper
INFO - 2020-12-29 02:50:21 --> Helper loaded: form_helper
INFO - 2020-12-29 02:50:21 --> Helper loaded: my_helper
INFO - 2020-12-29 02:50:21 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:50:21 --> Controller Class Initialized
DEBUG - 2020-12-29 02:50:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 02:50:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:50:21 --> Final output sent to browser
DEBUG - 2020-12-29 02:50:21 --> Total execution time: 0.2797
INFO - 2020-12-29 02:50:21 --> Config Class Initialized
INFO - 2020-12-29 02:50:21 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:50:21 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:50:21 --> Utf8 Class Initialized
INFO - 2020-12-29 02:50:21 --> URI Class Initialized
INFO - 2020-12-29 02:50:21 --> Router Class Initialized
INFO - 2020-12-29 02:50:21 --> Output Class Initialized
INFO - 2020-12-29 02:50:21 --> Security Class Initialized
DEBUG - 2020-12-29 02:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:50:21 --> Input Class Initialized
INFO - 2020-12-29 02:50:21 --> Language Class Initialized
INFO - 2020-12-29 02:50:21 --> Language Class Initialized
INFO - 2020-12-29 02:50:21 --> Config Class Initialized
INFO - 2020-12-29 02:50:21 --> Loader Class Initialized
INFO - 2020-12-29 02:50:21 --> Helper loaded: url_helper
INFO - 2020-12-29 02:50:21 --> Helper loaded: file_helper
INFO - 2020-12-29 02:50:21 --> Helper loaded: form_helper
INFO - 2020-12-29 02:50:21 --> Helper loaded: my_helper
INFO - 2020-12-29 02:50:21 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:50:21 --> Controller Class Initialized
INFO - 2020-12-29 02:51:14 --> Config Class Initialized
INFO - 2020-12-29 02:51:14 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:51:14 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:51:14 --> Utf8 Class Initialized
INFO - 2020-12-29 02:51:14 --> URI Class Initialized
INFO - 2020-12-29 02:51:14 --> Router Class Initialized
INFO - 2020-12-29 02:51:14 --> Output Class Initialized
INFO - 2020-12-29 02:51:14 --> Security Class Initialized
DEBUG - 2020-12-29 02:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:51:14 --> Input Class Initialized
INFO - 2020-12-29 02:51:14 --> Language Class Initialized
INFO - 2020-12-29 02:51:14 --> Language Class Initialized
INFO - 2020-12-29 02:51:14 --> Config Class Initialized
INFO - 2020-12-29 02:51:14 --> Loader Class Initialized
INFO - 2020-12-29 02:51:14 --> Helper loaded: url_helper
INFO - 2020-12-29 02:51:14 --> Helper loaded: file_helper
INFO - 2020-12-29 02:51:14 --> Helper loaded: form_helper
INFO - 2020-12-29 02:51:14 --> Helper loaded: my_helper
INFO - 2020-12-29 02:51:14 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:51:14 --> Controller Class Initialized
DEBUG - 2020-12-29 02:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 02:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:51:14 --> Final output sent to browser
DEBUG - 2020-12-29 02:51:14 --> Total execution time: 0.3142
INFO - 2020-12-29 02:51:21 --> Config Class Initialized
INFO - 2020-12-29 02:51:21 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:51:21 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:51:21 --> Utf8 Class Initialized
INFO - 2020-12-29 02:51:21 --> URI Class Initialized
INFO - 2020-12-29 02:51:21 --> Router Class Initialized
INFO - 2020-12-29 02:51:21 --> Output Class Initialized
INFO - 2020-12-29 02:51:21 --> Security Class Initialized
DEBUG - 2020-12-29 02:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:51:21 --> Input Class Initialized
INFO - 2020-12-29 02:51:21 --> Language Class Initialized
INFO - 2020-12-29 02:51:21 --> Language Class Initialized
INFO - 2020-12-29 02:51:21 --> Config Class Initialized
INFO - 2020-12-29 02:51:21 --> Loader Class Initialized
INFO - 2020-12-29 02:51:21 --> Helper loaded: url_helper
INFO - 2020-12-29 02:51:21 --> Helper loaded: file_helper
INFO - 2020-12-29 02:51:21 --> Helper loaded: form_helper
INFO - 2020-12-29 02:51:21 --> Helper loaded: my_helper
INFO - 2020-12-29 02:51:21 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:51:21 --> Controller Class Initialized
INFO - 2020-12-29 02:51:21 --> Config Class Initialized
INFO - 2020-12-29 02:51:21 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:51:21 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:51:21 --> Utf8 Class Initialized
INFO - 2020-12-29 02:51:21 --> URI Class Initialized
INFO - 2020-12-29 02:51:21 --> Router Class Initialized
INFO - 2020-12-29 02:51:21 --> Output Class Initialized
INFO - 2020-12-29 02:51:21 --> Security Class Initialized
DEBUG - 2020-12-29 02:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:51:21 --> Input Class Initialized
INFO - 2020-12-29 02:51:21 --> Language Class Initialized
INFO - 2020-12-29 02:51:21 --> Language Class Initialized
INFO - 2020-12-29 02:51:21 --> Config Class Initialized
INFO - 2020-12-29 02:51:21 --> Loader Class Initialized
INFO - 2020-12-29 02:51:21 --> Helper loaded: url_helper
INFO - 2020-12-29 02:51:21 --> Helper loaded: file_helper
INFO - 2020-12-29 02:51:21 --> Helper loaded: form_helper
INFO - 2020-12-29 02:51:21 --> Helper loaded: my_helper
INFO - 2020-12-29 02:51:21 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:51:21 --> Controller Class Initialized
DEBUG - 2020-12-29 02:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 02:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:51:21 --> Final output sent to browser
DEBUG - 2020-12-29 02:51:21 --> Total execution time: 0.2917
INFO - 2020-12-29 02:51:22 --> Config Class Initialized
INFO - 2020-12-29 02:51:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:51:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:51:22 --> Utf8 Class Initialized
INFO - 2020-12-29 02:51:22 --> URI Class Initialized
INFO - 2020-12-29 02:51:22 --> Router Class Initialized
INFO - 2020-12-29 02:51:22 --> Output Class Initialized
INFO - 2020-12-29 02:51:22 --> Security Class Initialized
DEBUG - 2020-12-29 02:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:51:22 --> Input Class Initialized
INFO - 2020-12-29 02:51:22 --> Language Class Initialized
INFO - 2020-12-29 02:51:22 --> Language Class Initialized
INFO - 2020-12-29 02:51:22 --> Config Class Initialized
INFO - 2020-12-29 02:51:22 --> Loader Class Initialized
INFO - 2020-12-29 02:51:22 --> Helper loaded: url_helper
INFO - 2020-12-29 02:51:22 --> Helper loaded: file_helper
INFO - 2020-12-29 02:51:22 --> Helper loaded: form_helper
INFO - 2020-12-29 02:51:22 --> Helper loaded: my_helper
INFO - 2020-12-29 02:51:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:51:22 --> Controller Class Initialized
INFO - 2020-12-29 02:51:45 --> Config Class Initialized
INFO - 2020-12-29 02:51:45 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:51:45 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:51:45 --> Utf8 Class Initialized
INFO - 2020-12-29 02:51:45 --> URI Class Initialized
INFO - 2020-12-29 02:51:45 --> Router Class Initialized
INFO - 2020-12-29 02:51:45 --> Output Class Initialized
INFO - 2020-12-29 02:51:45 --> Security Class Initialized
DEBUG - 2020-12-29 02:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:51:45 --> Input Class Initialized
INFO - 2020-12-29 02:51:45 --> Language Class Initialized
INFO - 2020-12-29 02:51:45 --> Language Class Initialized
INFO - 2020-12-29 02:51:45 --> Config Class Initialized
INFO - 2020-12-29 02:51:45 --> Loader Class Initialized
INFO - 2020-12-29 02:51:45 --> Helper loaded: url_helper
INFO - 2020-12-29 02:51:45 --> Helper loaded: file_helper
INFO - 2020-12-29 02:51:45 --> Helper loaded: form_helper
INFO - 2020-12-29 02:51:45 --> Helper loaded: my_helper
INFO - 2020-12-29 02:51:45 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:51:45 --> Controller Class Initialized
DEBUG - 2020-12-29 02:51:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 02:51:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:51:45 --> Final output sent to browser
DEBUG - 2020-12-29 02:51:45 --> Total execution time: 0.2594
INFO - 2020-12-29 02:51:45 --> Config Class Initialized
INFO - 2020-12-29 02:51:45 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:51:45 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:51:45 --> Utf8 Class Initialized
INFO - 2020-12-29 02:51:45 --> URI Class Initialized
INFO - 2020-12-29 02:51:45 --> Router Class Initialized
INFO - 2020-12-29 02:51:45 --> Output Class Initialized
INFO - 2020-12-29 02:51:45 --> Security Class Initialized
DEBUG - 2020-12-29 02:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:51:45 --> Input Class Initialized
INFO - 2020-12-29 02:51:45 --> Language Class Initialized
INFO - 2020-12-29 02:51:45 --> Language Class Initialized
INFO - 2020-12-29 02:51:45 --> Config Class Initialized
INFO - 2020-12-29 02:51:45 --> Loader Class Initialized
INFO - 2020-12-29 02:51:45 --> Helper loaded: url_helper
INFO - 2020-12-29 02:51:45 --> Helper loaded: file_helper
INFO - 2020-12-29 02:51:45 --> Helper loaded: form_helper
INFO - 2020-12-29 02:51:45 --> Helper loaded: my_helper
INFO - 2020-12-29 02:51:45 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:51:45 --> Controller Class Initialized
INFO - 2020-12-29 02:52:23 --> Config Class Initialized
INFO - 2020-12-29 02:52:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:52:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:52:23 --> Utf8 Class Initialized
INFO - 2020-12-29 02:52:23 --> URI Class Initialized
INFO - 2020-12-29 02:52:23 --> Router Class Initialized
INFO - 2020-12-29 02:52:23 --> Output Class Initialized
INFO - 2020-12-29 02:52:23 --> Security Class Initialized
DEBUG - 2020-12-29 02:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:52:23 --> Input Class Initialized
INFO - 2020-12-29 02:52:23 --> Language Class Initialized
ERROR - 2020-12-29 02:52:23 --> Severity: Parsing Error --> syntax error, unexpected 'Data' (T_STRING) C:\xampp\htdocs\nilai\application\modules\set_mapel\controllers\Set_mapel.php 97
INFO - 2020-12-29 02:52:47 --> Config Class Initialized
INFO - 2020-12-29 02:52:47 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:52:47 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:52:47 --> Utf8 Class Initialized
INFO - 2020-12-29 02:52:47 --> URI Class Initialized
INFO - 2020-12-29 02:52:47 --> Router Class Initialized
INFO - 2020-12-29 02:52:47 --> Output Class Initialized
INFO - 2020-12-29 02:52:47 --> Security Class Initialized
DEBUG - 2020-12-29 02:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:52:47 --> Input Class Initialized
INFO - 2020-12-29 02:52:47 --> Language Class Initialized
INFO - 2020-12-29 02:52:47 --> Language Class Initialized
INFO - 2020-12-29 02:52:47 --> Config Class Initialized
INFO - 2020-12-29 02:52:47 --> Loader Class Initialized
INFO - 2020-12-29 02:52:47 --> Helper loaded: url_helper
INFO - 2020-12-29 02:52:47 --> Helper loaded: file_helper
INFO - 2020-12-29 02:52:47 --> Helper loaded: form_helper
INFO - 2020-12-29 02:52:47 --> Helper loaded: my_helper
INFO - 2020-12-29 02:52:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:52:48 --> Controller Class Initialized
DEBUG - 2020-12-29 02:52:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-29 02:52:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:52:48 --> Final output sent to browser
DEBUG - 2020-12-29 02:52:48 --> Total execution time: 0.3134
INFO - 2020-12-29 02:52:57 --> Config Class Initialized
INFO - 2020-12-29 02:52:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:52:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:52:57 --> Utf8 Class Initialized
INFO - 2020-12-29 02:52:57 --> URI Class Initialized
INFO - 2020-12-29 02:52:57 --> Router Class Initialized
INFO - 2020-12-29 02:52:57 --> Output Class Initialized
INFO - 2020-12-29 02:52:57 --> Security Class Initialized
DEBUG - 2020-12-29 02:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:52:57 --> Input Class Initialized
INFO - 2020-12-29 02:52:57 --> Language Class Initialized
INFO - 2020-12-29 02:52:57 --> Language Class Initialized
INFO - 2020-12-29 02:52:57 --> Config Class Initialized
INFO - 2020-12-29 02:52:57 --> Loader Class Initialized
INFO - 2020-12-29 02:52:57 --> Helper loaded: url_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: file_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: form_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: my_helper
INFO - 2020-12-29 02:52:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:52:57 --> Controller Class Initialized
INFO - 2020-12-29 02:52:57 --> Config Class Initialized
INFO - 2020-12-29 02:52:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:52:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:52:57 --> Utf8 Class Initialized
INFO - 2020-12-29 02:52:57 --> URI Class Initialized
INFO - 2020-12-29 02:52:57 --> Router Class Initialized
INFO - 2020-12-29 02:52:57 --> Output Class Initialized
INFO - 2020-12-29 02:52:57 --> Security Class Initialized
DEBUG - 2020-12-29 02:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:52:57 --> Input Class Initialized
INFO - 2020-12-29 02:52:57 --> Language Class Initialized
INFO - 2020-12-29 02:52:57 --> Language Class Initialized
INFO - 2020-12-29 02:52:57 --> Config Class Initialized
INFO - 2020-12-29 02:52:57 --> Loader Class Initialized
INFO - 2020-12-29 02:52:57 --> Helper loaded: url_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: file_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: form_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: my_helper
INFO - 2020-12-29 02:52:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:52:57 --> Controller Class Initialized
DEBUG - 2020-12-29 02:52:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 02:52:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:52:57 --> Final output sent to browser
DEBUG - 2020-12-29 02:52:57 --> Total execution time: 0.2813
INFO - 2020-12-29 02:52:57 --> Config Class Initialized
INFO - 2020-12-29 02:52:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:52:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:52:57 --> Utf8 Class Initialized
INFO - 2020-12-29 02:52:57 --> URI Class Initialized
INFO - 2020-12-29 02:52:57 --> Router Class Initialized
INFO - 2020-12-29 02:52:57 --> Output Class Initialized
INFO - 2020-12-29 02:52:57 --> Security Class Initialized
DEBUG - 2020-12-29 02:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:52:57 --> Input Class Initialized
INFO - 2020-12-29 02:52:57 --> Language Class Initialized
INFO - 2020-12-29 02:52:57 --> Language Class Initialized
INFO - 2020-12-29 02:52:57 --> Config Class Initialized
INFO - 2020-12-29 02:52:57 --> Loader Class Initialized
INFO - 2020-12-29 02:52:57 --> Helper loaded: url_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: file_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: form_helper
INFO - 2020-12-29 02:52:57 --> Helper loaded: my_helper
INFO - 2020-12-29 02:52:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:52:58 --> Controller Class Initialized
INFO - 2020-12-29 02:55:32 --> Config Class Initialized
INFO - 2020-12-29 02:55:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:32 --> URI Class Initialized
INFO - 2020-12-29 02:55:32 --> Router Class Initialized
INFO - 2020-12-29 02:55:33 --> Output Class Initialized
INFO - 2020-12-29 02:55:33 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:33 --> Input Class Initialized
INFO - 2020-12-29 02:55:33 --> Language Class Initialized
INFO - 2020-12-29 02:55:33 --> Language Class Initialized
INFO - 2020-12-29 02:55:33 --> Config Class Initialized
INFO - 2020-12-29 02:55:33 --> Loader Class Initialized
INFO - 2020-12-29 02:55:33 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:33 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:33 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:33 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:33 --> Controller Class Initialized
INFO - 2020-12-29 02:55:33 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:55:33 --> Config Class Initialized
INFO - 2020-12-29 02:55:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:33 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:33 --> URI Class Initialized
INFO - 2020-12-29 02:55:33 --> Router Class Initialized
INFO - 2020-12-29 02:55:33 --> Output Class Initialized
INFO - 2020-12-29 02:55:33 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:33 --> Input Class Initialized
INFO - 2020-12-29 02:55:33 --> Language Class Initialized
INFO - 2020-12-29 02:55:33 --> Language Class Initialized
INFO - 2020-12-29 02:55:33 --> Config Class Initialized
INFO - 2020-12-29 02:55:33 --> Loader Class Initialized
INFO - 2020-12-29 02:55:33 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:33 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:33 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:33 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:33 --> Controller Class Initialized
DEBUG - 2020-12-29 02:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 02:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:55:33 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:33 --> Total execution time: 0.3924
INFO - 2020-12-29 02:55:37 --> Config Class Initialized
INFO - 2020-12-29 02:55:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:37 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:37 --> URI Class Initialized
INFO - 2020-12-29 02:55:37 --> Router Class Initialized
INFO - 2020-12-29 02:55:37 --> Output Class Initialized
INFO - 2020-12-29 02:55:37 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:37 --> Input Class Initialized
INFO - 2020-12-29 02:55:37 --> Language Class Initialized
INFO - 2020-12-29 02:55:37 --> Language Class Initialized
INFO - 2020-12-29 02:55:38 --> Config Class Initialized
INFO - 2020-12-29 02:55:38 --> Loader Class Initialized
INFO - 2020-12-29 02:55:38 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:38 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:38 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:38 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:38 --> Controller Class Initialized
INFO - 2020-12-29 02:55:38 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:55:38 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:38 --> Total execution time: 0.4528
INFO - 2020-12-29 02:55:38 --> Config Class Initialized
INFO - 2020-12-29 02:55:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:38 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:38 --> URI Class Initialized
INFO - 2020-12-29 02:55:38 --> Router Class Initialized
INFO - 2020-12-29 02:55:38 --> Output Class Initialized
INFO - 2020-12-29 02:55:38 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:38 --> Input Class Initialized
INFO - 2020-12-29 02:55:38 --> Language Class Initialized
INFO - 2020-12-29 02:55:38 --> Language Class Initialized
INFO - 2020-12-29 02:55:38 --> Config Class Initialized
INFO - 2020-12-29 02:55:38 --> Loader Class Initialized
INFO - 2020-12-29 02:55:38 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:38 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:38 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:39 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:39 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:39 --> Controller Class Initialized
DEBUG - 2020-12-29 02:55:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 02:55:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:55:39 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:39 --> Total execution time: 0.5262
INFO - 2020-12-29 02:55:40 --> Config Class Initialized
INFO - 2020-12-29 02:55:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:40 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:40 --> URI Class Initialized
INFO - 2020-12-29 02:55:40 --> Router Class Initialized
INFO - 2020-12-29 02:55:40 --> Output Class Initialized
INFO - 2020-12-29 02:55:40 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:40 --> Input Class Initialized
INFO - 2020-12-29 02:55:40 --> Language Class Initialized
INFO - 2020-12-29 02:55:40 --> Language Class Initialized
INFO - 2020-12-29 02:55:40 --> Config Class Initialized
INFO - 2020-12-29 02:55:40 --> Loader Class Initialized
INFO - 2020-12-29 02:55:40 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:40 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:40 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:40 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:40 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:40 --> Controller Class Initialized
DEBUG - 2020-12-29 02:55:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-29 02:55:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:55:40 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:40 --> Total execution time: 0.4300
INFO - 2020-12-29 02:55:42 --> Config Class Initialized
INFO - 2020-12-29 02:55:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:42 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:42 --> URI Class Initialized
INFO - 2020-12-29 02:55:42 --> Router Class Initialized
INFO - 2020-12-29 02:55:42 --> Output Class Initialized
INFO - 2020-12-29 02:55:42 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:42 --> Input Class Initialized
INFO - 2020-12-29 02:55:42 --> Language Class Initialized
INFO - 2020-12-29 02:55:42 --> Language Class Initialized
INFO - 2020-12-29 02:55:42 --> Config Class Initialized
INFO - 2020-12-29 02:55:42 --> Loader Class Initialized
INFO - 2020-12-29 02:55:42 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:42 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:42 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:42 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:42 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:42 --> Controller Class Initialized
DEBUG - 2020-12-29 02:55:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-12-29 02:55:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:55:42 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:42 --> Total execution time: 0.3800
INFO - 2020-12-29 02:55:42 --> Config Class Initialized
INFO - 2020-12-29 02:55:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:42 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:42 --> URI Class Initialized
INFO - 2020-12-29 02:55:42 --> Router Class Initialized
INFO - 2020-12-29 02:55:42 --> Output Class Initialized
INFO - 2020-12-29 02:55:43 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:43 --> Input Class Initialized
INFO - 2020-12-29 02:55:43 --> Language Class Initialized
INFO - 2020-12-29 02:55:43 --> Language Class Initialized
INFO - 2020-12-29 02:55:43 --> Config Class Initialized
INFO - 2020-12-29 02:55:43 --> Loader Class Initialized
INFO - 2020-12-29 02:55:43 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:43 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:43 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:43 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:43 --> Controller Class Initialized
INFO - 2020-12-29 02:55:47 --> Config Class Initialized
INFO - 2020-12-29 02:55:47 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:47 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:47 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:47 --> URI Class Initialized
INFO - 2020-12-29 02:55:47 --> Router Class Initialized
INFO - 2020-12-29 02:55:47 --> Output Class Initialized
INFO - 2020-12-29 02:55:47 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:47 --> Input Class Initialized
INFO - 2020-12-29 02:55:47 --> Language Class Initialized
INFO - 2020-12-29 02:55:47 --> Language Class Initialized
INFO - 2020-12-29 02:55:47 --> Config Class Initialized
INFO - 2020-12-29 02:55:47 --> Loader Class Initialized
INFO - 2020-12-29 02:55:47 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:47 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:47 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:47 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:48 --> Controller Class Initialized
DEBUG - 2020-12-29 02:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-29 02:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:55:48 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:48 --> Total execution time: 0.4083
INFO - 2020-12-29 02:55:49 --> Config Class Initialized
INFO - 2020-12-29 02:55:49 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:49 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:49 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:49 --> URI Class Initialized
INFO - 2020-12-29 02:55:49 --> Router Class Initialized
INFO - 2020-12-29 02:55:49 --> Output Class Initialized
INFO - 2020-12-29 02:55:49 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:49 --> Input Class Initialized
INFO - 2020-12-29 02:55:49 --> Language Class Initialized
INFO - 2020-12-29 02:55:49 --> Language Class Initialized
INFO - 2020-12-29 02:55:49 --> Config Class Initialized
INFO - 2020-12-29 02:55:49 --> Loader Class Initialized
INFO - 2020-12-29 02:55:49 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:49 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:49 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:49 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:49 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:49 --> Controller Class Initialized
DEBUG - 2020-12-29 02:55:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-12-29 02:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:55:50 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:50 --> Total execution time: 0.4138
INFO - 2020-12-29 02:55:52 --> Config Class Initialized
INFO - 2020-12-29 02:55:52 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:53 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:53 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:53 --> URI Class Initialized
INFO - 2020-12-29 02:55:53 --> Router Class Initialized
INFO - 2020-12-29 02:55:53 --> Output Class Initialized
INFO - 2020-12-29 02:55:53 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:53 --> Input Class Initialized
INFO - 2020-12-29 02:55:53 --> Language Class Initialized
INFO - 2020-12-29 02:55:53 --> Language Class Initialized
INFO - 2020-12-29 02:55:53 --> Config Class Initialized
INFO - 2020-12-29 02:55:53 --> Loader Class Initialized
INFO - 2020-12-29 02:55:53 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:53 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:53 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:53 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:53 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:53 --> Controller Class Initialized
DEBUG - 2020-12-29 02:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-29 02:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:55:53 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:53 --> Total execution time: 0.4578
INFO - 2020-12-29 02:55:54 --> Config Class Initialized
INFO - 2020-12-29 02:55:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:54 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:54 --> URI Class Initialized
INFO - 2020-12-29 02:55:54 --> Router Class Initialized
INFO - 2020-12-29 02:55:54 --> Output Class Initialized
INFO - 2020-12-29 02:55:54 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:54 --> Input Class Initialized
INFO - 2020-12-29 02:55:54 --> Language Class Initialized
INFO - 2020-12-29 02:55:54 --> Language Class Initialized
INFO - 2020-12-29 02:55:54 --> Config Class Initialized
INFO - 2020-12-29 02:55:54 --> Loader Class Initialized
INFO - 2020-12-29 02:55:54 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:54 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:54 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:54 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:54 --> Controller Class Initialized
DEBUG - 2020-12-29 02:55:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-12-29 02:55:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:55:54 --> Final output sent to browser
DEBUG - 2020-12-29 02:55:54 --> Total execution time: 0.3295
INFO - 2020-12-29 02:55:54 --> Config Class Initialized
INFO - 2020-12-29 02:55:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:55:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:55:54 --> Utf8 Class Initialized
INFO - 2020-12-29 02:55:54 --> URI Class Initialized
INFO - 2020-12-29 02:55:54 --> Router Class Initialized
INFO - 2020-12-29 02:55:54 --> Output Class Initialized
INFO - 2020-12-29 02:55:54 --> Security Class Initialized
DEBUG - 2020-12-29 02:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:55:54 --> Input Class Initialized
INFO - 2020-12-29 02:55:54 --> Language Class Initialized
INFO - 2020-12-29 02:55:54 --> Language Class Initialized
INFO - 2020-12-29 02:55:54 --> Config Class Initialized
INFO - 2020-12-29 02:55:54 --> Loader Class Initialized
INFO - 2020-12-29 02:55:54 --> Helper loaded: url_helper
INFO - 2020-12-29 02:55:54 --> Helper loaded: file_helper
INFO - 2020-12-29 02:55:54 --> Helper loaded: form_helper
INFO - 2020-12-29 02:55:55 --> Helper loaded: my_helper
INFO - 2020-12-29 02:55:55 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:55:55 --> Controller Class Initialized
INFO - 2020-12-29 03:06:04 --> Config Class Initialized
INFO - 2020-12-29 03:06:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:04 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:04 --> URI Class Initialized
INFO - 2020-12-29 03:06:04 --> Router Class Initialized
INFO - 2020-12-29 03:06:04 --> Output Class Initialized
INFO - 2020-12-29 03:06:04 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:04 --> Input Class Initialized
INFO - 2020-12-29 03:06:04 --> Language Class Initialized
INFO - 2020-12-29 03:06:04 --> Language Class Initialized
INFO - 2020-12-29 03:06:04 --> Config Class Initialized
INFO - 2020-12-29 03:06:04 --> Loader Class Initialized
INFO - 2020-12-29 03:06:04 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:04 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:04 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:04 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:04 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-29 03:06:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:06:04 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:04 --> Total execution time: 0.4605
INFO - 2020-12-29 03:06:05 --> Config Class Initialized
INFO - 2020-12-29 03:06:05 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:05 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:05 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:05 --> URI Class Initialized
INFO - 2020-12-29 03:06:05 --> Router Class Initialized
INFO - 2020-12-29 03:06:05 --> Output Class Initialized
INFO - 2020-12-29 03:06:05 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:05 --> Input Class Initialized
INFO - 2020-12-29 03:06:05 --> Language Class Initialized
INFO - 2020-12-29 03:06:05 --> Language Class Initialized
INFO - 2020-12-29 03:06:05 --> Config Class Initialized
INFO - 2020-12-29 03:06:06 --> Loader Class Initialized
INFO - 2020-12-29 03:06:06 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:06 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:06 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:06 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:06 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-29 03:06:06 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:06 --> Total execution time: 0.3736
INFO - 2020-12-29 04:35:24 --> Config Class Initialized
INFO - 2020-12-29 04:35:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 04:35:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 04:35:24 --> Utf8 Class Initialized
INFO - 2020-12-29 04:35:24 --> URI Class Initialized
INFO - 2020-12-29 04:35:24 --> Router Class Initialized
INFO - 2020-12-29 04:35:24 --> Output Class Initialized
INFO - 2020-12-29 04:35:24 --> Security Class Initialized
DEBUG - 2020-12-29 04:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 04:35:24 --> Input Class Initialized
INFO - 2020-12-29 04:35:24 --> Language Class Initialized
INFO - 2020-12-29 04:35:24 --> Language Class Initialized
INFO - 2020-12-29 04:35:24 --> Config Class Initialized
INFO - 2020-12-29 04:35:24 --> Loader Class Initialized
INFO - 2020-12-29 04:35:24 --> Helper loaded: url_helper
INFO - 2020-12-29 04:35:24 --> Helper loaded: file_helper
INFO - 2020-12-29 04:35:24 --> Helper loaded: form_helper
INFO - 2020-12-29 04:35:24 --> Helper loaded: my_helper
INFO - 2020-12-29 04:35:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 04:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 04:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 04:35:24 --> Controller Class Initialized
DEBUG - 2020-12-29 04:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-29 04:35:24 --> Final output sent to browser
DEBUG - 2020-12-29 04:35:24 --> Total execution time: 0.3155
INFO - 2020-12-29 04:54:12 --> Config Class Initialized
INFO - 2020-12-29 04:54:12 --> Hooks Class Initialized
DEBUG - 2020-12-29 04:54:12 --> UTF-8 Support Enabled
INFO - 2020-12-29 04:54:13 --> Utf8 Class Initialized
INFO - 2020-12-29 04:54:13 --> URI Class Initialized
INFO - 2020-12-29 04:54:13 --> Router Class Initialized
INFO - 2020-12-29 04:54:13 --> Output Class Initialized
INFO - 2020-12-29 04:54:13 --> Security Class Initialized
DEBUG - 2020-12-29 04:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 04:54:13 --> Input Class Initialized
INFO - 2020-12-29 04:54:13 --> Language Class Initialized
INFO - 2020-12-29 04:54:13 --> Language Class Initialized
INFO - 2020-12-29 04:54:13 --> Config Class Initialized
INFO - 2020-12-29 04:54:13 --> Loader Class Initialized
INFO - 2020-12-29 04:54:13 --> Helper loaded: url_helper
INFO - 2020-12-29 04:54:13 --> Helper loaded: file_helper
INFO - 2020-12-29 04:54:13 --> Helper loaded: form_helper
INFO - 2020-12-29 04:54:13 --> Helper loaded: my_helper
INFO - 2020-12-29 04:54:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 04:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 04:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 04:54:13 --> Controller Class Initialized
INFO - 2020-12-29 04:54:13 --> Helper loaded: cookie_helper
INFO - 2020-12-29 04:54:13 --> Config Class Initialized
INFO - 2020-12-29 04:54:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 04:54:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 04:54:13 --> Utf8 Class Initialized
INFO - 2020-12-29 04:54:13 --> URI Class Initialized
INFO - 2020-12-29 04:54:13 --> Router Class Initialized
INFO - 2020-12-29 04:54:13 --> Output Class Initialized
INFO - 2020-12-29 04:54:13 --> Security Class Initialized
DEBUG - 2020-12-29 04:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 04:54:13 --> Input Class Initialized
INFO - 2020-12-29 04:54:13 --> Language Class Initialized
INFO - 2020-12-29 04:54:13 --> Language Class Initialized
INFO - 2020-12-29 04:54:13 --> Config Class Initialized
INFO - 2020-12-29 04:54:13 --> Loader Class Initialized
INFO - 2020-12-29 04:54:13 --> Helper loaded: url_helper
INFO - 2020-12-29 04:54:13 --> Helper loaded: file_helper
INFO - 2020-12-29 04:54:13 --> Helper loaded: form_helper
INFO - 2020-12-29 04:54:13 --> Helper loaded: my_helper
INFO - 2020-12-29 04:54:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 04:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 04:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 04:54:13 --> Controller Class Initialized
DEBUG - 2020-12-29 04:54:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 04:54:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 04:54:13 --> Final output sent to browser
DEBUG - 2020-12-29 04:54:13 --> Total execution time: 0.3382
INFO - 2020-12-29 04:54:21 --> Config Class Initialized
INFO - 2020-12-29 04:54:21 --> Hooks Class Initialized
DEBUG - 2020-12-29 04:54:21 --> UTF-8 Support Enabled
INFO - 2020-12-29 04:54:21 --> Utf8 Class Initialized
INFO - 2020-12-29 04:54:21 --> URI Class Initialized
INFO - 2020-12-29 04:54:21 --> Router Class Initialized
INFO - 2020-12-29 04:54:21 --> Output Class Initialized
INFO - 2020-12-29 04:54:21 --> Security Class Initialized
DEBUG - 2020-12-29 04:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 04:54:21 --> Input Class Initialized
INFO - 2020-12-29 04:54:21 --> Language Class Initialized
INFO - 2020-12-29 04:54:21 --> Language Class Initialized
INFO - 2020-12-29 04:54:21 --> Config Class Initialized
INFO - 2020-12-29 04:54:22 --> Loader Class Initialized
INFO - 2020-12-29 04:54:22 --> Helper loaded: url_helper
INFO - 2020-12-29 04:54:22 --> Helper loaded: file_helper
INFO - 2020-12-29 04:54:22 --> Helper loaded: form_helper
INFO - 2020-12-29 04:54:22 --> Helper loaded: my_helper
INFO - 2020-12-29 04:54:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 04:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 04:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 04:54:22 --> Controller Class Initialized
INFO - 2020-12-29 04:54:22 --> Helper loaded: cookie_helper
INFO - 2020-12-29 04:54:22 --> Final output sent to browser
DEBUG - 2020-12-29 04:54:22 --> Total execution time: 0.3905
INFO - 2020-12-29 04:54:23 --> Config Class Initialized
INFO - 2020-12-29 04:54:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 04:54:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 04:54:23 --> Utf8 Class Initialized
INFO - 2020-12-29 04:54:23 --> URI Class Initialized
INFO - 2020-12-29 04:54:23 --> Router Class Initialized
INFO - 2020-12-29 04:54:23 --> Output Class Initialized
INFO - 2020-12-29 04:54:23 --> Security Class Initialized
DEBUG - 2020-12-29 04:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 04:54:23 --> Input Class Initialized
INFO - 2020-12-29 04:54:23 --> Language Class Initialized
INFO - 2020-12-29 04:54:23 --> Language Class Initialized
INFO - 2020-12-29 04:54:23 --> Config Class Initialized
INFO - 2020-12-29 04:54:23 --> Loader Class Initialized
INFO - 2020-12-29 04:54:23 --> Helper loaded: url_helper
INFO - 2020-12-29 04:54:23 --> Helper loaded: file_helper
INFO - 2020-12-29 04:54:23 --> Helper loaded: form_helper
INFO - 2020-12-29 04:54:23 --> Helper loaded: my_helper
INFO - 2020-12-29 04:54:23 --> Database Driver Class Initialized
DEBUG - 2020-12-29 04:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 04:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 04:54:23 --> Controller Class Initialized
DEBUG - 2020-12-29 04:54:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 04:54:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 04:54:23 --> Final output sent to browser
DEBUG - 2020-12-29 04:54:23 --> Total execution time: 0.4872
INFO - 2020-12-29 04:55:33 --> Config Class Initialized
INFO - 2020-12-29 04:55:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 04:55:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 04:55:33 --> Utf8 Class Initialized
INFO - 2020-12-29 04:55:33 --> URI Class Initialized
INFO - 2020-12-29 04:55:33 --> Router Class Initialized
INFO - 2020-12-29 04:55:33 --> Output Class Initialized
INFO - 2020-12-29 04:55:33 --> Security Class Initialized
DEBUG - 2020-12-29 04:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 04:55:33 --> Input Class Initialized
INFO - 2020-12-29 04:55:33 --> Language Class Initialized
INFO - 2020-12-29 04:55:33 --> Language Class Initialized
INFO - 2020-12-29 04:55:33 --> Config Class Initialized
INFO - 2020-12-29 04:55:33 --> Loader Class Initialized
INFO - 2020-12-29 04:55:33 --> Helper loaded: url_helper
INFO - 2020-12-29 04:55:33 --> Helper loaded: file_helper
INFO - 2020-12-29 04:55:33 --> Helper loaded: form_helper
INFO - 2020-12-29 04:55:34 --> Helper loaded: my_helper
INFO - 2020-12-29 04:55:34 --> Database Driver Class Initialized
DEBUG - 2020-12-29 04:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 04:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 04:55:34 --> Controller Class Initialized
DEBUG - 2020-12-29 04:55:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-29 04:55:34 --> Final output sent to browser
DEBUG - 2020-12-29 04:55:34 --> Total execution time: 0.4013
INFO - 2020-12-29 05:07:07 --> Config Class Initialized
INFO - 2020-12-29 05:07:07 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:07:07 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:07:07 --> Utf8 Class Initialized
INFO - 2020-12-29 05:07:07 --> URI Class Initialized
INFO - 2020-12-29 05:07:07 --> Router Class Initialized
INFO - 2020-12-29 05:07:07 --> Output Class Initialized
INFO - 2020-12-29 05:07:07 --> Security Class Initialized
DEBUG - 2020-12-29 05:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:07:07 --> Input Class Initialized
INFO - 2020-12-29 05:07:07 --> Language Class Initialized
INFO - 2020-12-29 05:07:07 --> Language Class Initialized
INFO - 2020-12-29 05:07:07 --> Config Class Initialized
INFO - 2020-12-29 05:07:07 --> Loader Class Initialized
INFO - 2020-12-29 05:07:07 --> Helper loaded: url_helper
INFO - 2020-12-29 05:07:07 --> Helper loaded: file_helper
INFO - 2020-12-29 05:07:07 --> Helper loaded: form_helper
INFO - 2020-12-29 05:07:07 --> Helper loaded: my_helper
INFO - 2020-12-29 05:07:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:07:07 --> Controller Class Initialized
INFO - 2020-12-29 05:07:07 --> Helper loaded: cookie_helper
INFO - 2020-12-29 05:07:07 --> Config Class Initialized
INFO - 2020-12-29 05:07:07 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:07:07 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:07:07 --> Utf8 Class Initialized
INFO - 2020-12-29 05:07:07 --> URI Class Initialized
INFO - 2020-12-29 05:07:07 --> Router Class Initialized
INFO - 2020-12-29 05:07:07 --> Output Class Initialized
INFO - 2020-12-29 05:07:07 --> Security Class Initialized
DEBUG - 2020-12-29 05:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:07:07 --> Input Class Initialized
INFO - 2020-12-29 05:07:07 --> Language Class Initialized
INFO - 2020-12-29 05:07:07 --> Language Class Initialized
INFO - 2020-12-29 05:07:07 --> Config Class Initialized
INFO - 2020-12-29 05:07:07 --> Loader Class Initialized
INFO - 2020-12-29 05:07:07 --> Helper loaded: url_helper
INFO - 2020-12-29 05:07:07 --> Helper loaded: file_helper
INFO - 2020-12-29 05:07:07 --> Helper loaded: form_helper
INFO - 2020-12-29 05:07:07 --> Helper loaded: my_helper
INFO - 2020-12-29 05:07:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:07:07 --> Controller Class Initialized
DEBUG - 2020-12-29 05:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 05:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 05:07:07 --> Final output sent to browser
DEBUG - 2020-12-29 05:07:07 --> Total execution time: 0.3326
INFO - 2020-12-29 05:07:12 --> Config Class Initialized
INFO - 2020-12-29 05:07:12 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:07:12 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:07:13 --> Utf8 Class Initialized
INFO - 2020-12-29 05:07:13 --> URI Class Initialized
INFO - 2020-12-29 05:07:13 --> Router Class Initialized
INFO - 2020-12-29 05:07:13 --> Output Class Initialized
INFO - 2020-12-29 05:07:13 --> Security Class Initialized
DEBUG - 2020-12-29 05:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:07:13 --> Input Class Initialized
INFO - 2020-12-29 05:07:13 --> Language Class Initialized
INFO - 2020-12-29 05:07:13 --> Language Class Initialized
INFO - 2020-12-29 05:07:13 --> Config Class Initialized
INFO - 2020-12-29 05:07:13 --> Loader Class Initialized
INFO - 2020-12-29 05:07:13 --> Helper loaded: url_helper
INFO - 2020-12-29 05:07:13 --> Helper loaded: file_helper
INFO - 2020-12-29 05:07:13 --> Helper loaded: form_helper
INFO - 2020-12-29 05:07:13 --> Helper loaded: my_helper
INFO - 2020-12-29 05:07:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:07:13 --> Controller Class Initialized
INFO - 2020-12-29 05:07:13 --> Helper loaded: cookie_helper
INFO - 2020-12-29 05:07:13 --> Final output sent to browser
DEBUG - 2020-12-29 05:07:13 --> Total execution time: 0.4279
INFO - 2020-12-29 05:07:14 --> Config Class Initialized
INFO - 2020-12-29 05:07:14 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:07:14 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:07:14 --> Utf8 Class Initialized
INFO - 2020-12-29 05:07:14 --> URI Class Initialized
INFO - 2020-12-29 05:07:14 --> Router Class Initialized
INFO - 2020-12-29 05:07:14 --> Output Class Initialized
INFO - 2020-12-29 05:07:14 --> Security Class Initialized
DEBUG - 2020-12-29 05:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:07:14 --> Input Class Initialized
INFO - 2020-12-29 05:07:14 --> Language Class Initialized
INFO - 2020-12-29 05:07:14 --> Language Class Initialized
INFO - 2020-12-29 05:07:14 --> Config Class Initialized
INFO - 2020-12-29 05:07:14 --> Loader Class Initialized
INFO - 2020-12-29 05:07:14 --> Helper loaded: url_helper
INFO - 2020-12-29 05:07:14 --> Helper loaded: file_helper
INFO - 2020-12-29 05:07:14 --> Helper loaded: form_helper
INFO - 2020-12-29 05:07:14 --> Helper loaded: my_helper
INFO - 2020-12-29 05:07:14 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:07:14 --> Controller Class Initialized
DEBUG - 2020-12-29 05:07:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 05:07:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 05:07:14 --> Final output sent to browser
DEBUG - 2020-12-29 05:07:14 --> Total execution time: 0.4397
INFO - 2020-12-29 05:07:18 --> Config Class Initialized
INFO - 2020-12-29 05:07:18 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:07:18 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:07:18 --> Utf8 Class Initialized
INFO - 2020-12-29 05:07:19 --> URI Class Initialized
INFO - 2020-12-29 05:07:19 --> Router Class Initialized
INFO - 2020-12-29 05:07:19 --> Output Class Initialized
INFO - 2020-12-29 05:07:19 --> Security Class Initialized
DEBUG - 2020-12-29 05:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:07:19 --> Input Class Initialized
INFO - 2020-12-29 05:07:19 --> Language Class Initialized
INFO - 2020-12-29 05:07:19 --> Language Class Initialized
INFO - 2020-12-29 05:07:19 --> Config Class Initialized
INFO - 2020-12-29 05:07:19 --> Loader Class Initialized
INFO - 2020-12-29 05:07:19 --> Helper loaded: url_helper
INFO - 2020-12-29 05:07:19 --> Helper loaded: file_helper
INFO - 2020-12-29 05:07:19 --> Helper loaded: form_helper
INFO - 2020-12-29 05:07:19 --> Helper loaded: my_helper
INFO - 2020-12-29 05:07:19 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:07:19 --> Controller Class Initialized
DEBUG - 2020-12-29 05:07:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-29 05:07:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 05:07:19 --> Final output sent to browser
DEBUG - 2020-12-29 05:07:19 --> Total execution time: 0.3548
INFO - 2020-12-29 05:34:31 --> Config Class Initialized
INFO - 2020-12-29 05:34:31 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:34:31 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:34:31 --> Utf8 Class Initialized
INFO - 2020-12-29 05:34:31 --> URI Class Initialized
INFO - 2020-12-29 05:34:31 --> Router Class Initialized
INFO - 2020-12-29 05:34:31 --> Output Class Initialized
INFO - 2020-12-29 05:34:31 --> Security Class Initialized
DEBUG - 2020-12-29 05:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:34:31 --> Input Class Initialized
INFO - 2020-12-29 05:34:31 --> Language Class Initialized
INFO - 2020-12-29 05:34:31 --> Language Class Initialized
INFO - 2020-12-29 05:34:31 --> Config Class Initialized
INFO - 2020-12-29 05:34:31 --> Loader Class Initialized
INFO - 2020-12-29 05:34:31 --> Helper loaded: url_helper
INFO - 2020-12-29 05:34:31 --> Helper loaded: file_helper
INFO - 2020-12-29 05:34:31 --> Helper loaded: form_helper
INFO - 2020-12-29 05:34:31 --> Helper loaded: my_helper
INFO - 2020-12-29 05:34:31 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:34:31 --> Controller Class Initialized
DEBUG - 2020-12-29 05:34:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-29 05:34:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 05:34:31 --> Final output sent to browser
DEBUG - 2020-12-29 05:34:31 --> Total execution time: 0.4230
INFO - 2020-12-29 05:53:22 --> Config Class Initialized
INFO - 2020-12-29 05:53:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:53:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:53:22 --> Utf8 Class Initialized
INFO - 2020-12-29 05:53:22 --> URI Class Initialized
INFO - 2020-12-29 05:53:22 --> Router Class Initialized
INFO - 2020-12-29 05:53:22 --> Output Class Initialized
INFO - 2020-12-29 05:53:22 --> Security Class Initialized
DEBUG - 2020-12-29 05:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:53:22 --> Input Class Initialized
INFO - 2020-12-29 05:53:22 --> Language Class Initialized
INFO - 2020-12-29 05:53:22 --> Language Class Initialized
INFO - 2020-12-29 05:53:22 --> Config Class Initialized
INFO - 2020-12-29 05:53:22 --> Loader Class Initialized
INFO - 2020-12-29 05:53:22 --> Helper loaded: url_helper
INFO - 2020-12-29 05:53:22 --> Helper loaded: file_helper
INFO - 2020-12-29 05:53:22 --> Helper loaded: form_helper
INFO - 2020-12-29 05:53:22 --> Helper loaded: my_helper
INFO - 2020-12-29 05:53:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:53:22 --> Controller Class Initialized
INFO - 2020-12-29 05:53:22 --> Helper loaded: cookie_helper
INFO - 2020-12-29 05:53:22 --> Config Class Initialized
INFO - 2020-12-29 05:53:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:53:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:53:22 --> Utf8 Class Initialized
INFO - 2020-12-29 05:53:22 --> URI Class Initialized
INFO - 2020-12-29 05:53:22 --> Router Class Initialized
INFO - 2020-12-29 05:53:22 --> Output Class Initialized
INFO - 2020-12-29 05:53:22 --> Security Class Initialized
DEBUG - 2020-12-29 05:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:53:22 --> Input Class Initialized
INFO - 2020-12-29 05:53:22 --> Language Class Initialized
INFO - 2020-12-29 05:53:22 --> Language Class Initialized
INFO - 2020-12-29 05:53:22 --> Config Class Initialized
INFO - 2020-12-29 05:53:22 --> Loader Class Initialized
INFO - 2020-12-29 05:53:22 --> Helper loaded: url_helper
INFO - 2020-12-29 05:53:22 --> Helper loaded: file_helper
INFO - 2020-12-29 05:53:22 --> Helper loaded: form_helper
INFO - 2020-12-29 05:53:22 --> Helper loaded: my_helper
INFO - 2020-12-29 05:53:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:53:22 --> Controller Class Initialized
DEBUG - 2020-12-29 05:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 05:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 05:53:22 --> Final output sent to browser
DEBUG - 2020-12-29 05:53:22 --> Total execution time: 0.3033
INFO - 2020-12-29 05:53:29 --> Config Class Initialized
INFO - 2020-12-29 05:53:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:53:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:53:29 --> Utf8 Class Initialized
INFO - 2020-12-29 05:53:29 --> URI Class Initialized
INFO - 2020-12-29 05:53:29 --> Router Class Initialized
INFO - 2020-12-29 05:53:29 --> Output Class Initialized
INFO - 2020-12-29 05:53:29 --> Security Class Initialized
DEBUG - 2020-12-29 05:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:53:29 --> Input Class Initialized
INFO - 2020-12-29 05:53:29 --> Language Class Initialized
INFO - 2020-12-29 05:53:29 --> Language Class Initialized
INFO - 2020-12-29 05:53:29 --> Config Class Initialized
INFO - 2020-12-29 05:53:29 --> Loader Class Initialized
INFO - 2020-12-29 05:53:29 --> Helper loaded: url_helper
INFO - 2020-12-29 05:53:29 --> Helper loaded: file_helper
INFO - 2020-12-29 05:53:29 --> Helper loaded: form_helper
INFO - 2020-12-29 05:53:29 --> Helper loaded: my_helper
INFO - 2020-12-29 05:53:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:53:29 --> Controller Class Initialized
INFO - 2020-12-29 05:53:29 --> Helper loaded: cookie_helper
INFO - 2020-12-29 05:53:29 --> Final output sent to browser
DEBUG - 2020-12-29 05:53:29 --> Total execution time: 0.4195
INFO - 2020-12-29 05:53:30 --> Config Class Initialized
INFO - 2020-12-29 05:53:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:53:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:53:30 --> Utf8 Class Initialized
INFO - 2020-12-29 05:53:30 --> URI Class Initialized
INFO - 2020-12-29 05:53:30 --> Router Class Initialized
INFO - 2020-12-29 05:53:30 --> Output Class Initialized
INFO - 2020-12-29 05:53:30 --> Security Class Initialized
DEBUG - 2020-12-29 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:53:30 --> Input Class Initialized
INFO - 2020-12-29 05:53:30 --> Language Class Initialized
INFO - 2020-12-29 05:53:30 --> Language Class Initialized
INFO - 2020-12-29 05:53:30 --> Config Class Initialized
INFO - 2020-12-29 05:53:30 --> Loader Class Initialized
INFO - 2020-12-29 05:53:30 --> Helper loaded: url_helper
INFO - 2020-12-29 05:53:30 --> Helper loaded: file_helper
INFO - 2020-12-29 05:53:30 --> Helper loaded: form_helper
INFO - 2020-12-29 05:53:30 --> Helper loaded: my_helper
INFO - 2020-12-29 05:53:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:53:30 --> Controller Class Initialized
DEBUG - 2020-12-29 05:53:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 05:53:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 05:53:30 --> Final output sent to browser
DEBUG - 2020-12-29 05:53:30 --> Total execution time: 0.4665
INFO - 2020-12-29 05:53:33 --> Config Class Initialized
INFO - 2020-12-29 05:53:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:53:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:53:33 --> Utf8 Class Initialized
INFO - 2020-12-29 05:53:33 --> URI Class Initialized
INFO - 2020-12-29 05:53:33 --> Router Class Initialized
INFO - 2020-12-29 05:53:33 --> Output Class Initialized
INFO - 2020-12-29 05:53:33 --> Security Class Initialized
DEBUG - 2020-12-29 05:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:53:33 --> Input Class Initialized
INFO - 2020-12-29 05:53:33 --> Language Class Initialized
INFO - 2020-12-29 05:53:33 --> Language Class Initialized
INFO - 2020-12-29 05:53:33 --> Config Class Initialized
INFO - 2020-12-29 05:53:33 --> Loader Class Initialized
INFO - 2020-12-29 05:53:33 --> Helper loaded: url_helper
INFO - 2020-12-29 05:53:33 --> Helper loaded: file_helper
INFO - 2020-12-29 05:53:33 --> Helper loaded: form_helper
INFO - 2020-12-29 05:53:33 --> Helper loaded: my_helper
INFO - 2020-12-29 05:53:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:53:34 --> Controller Class Initialized
DEBUG - 2020-12-29 05:53:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 05:53:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 05:53:34 --> Final output sent to browser
DEBUG - 2020-12-29 05:53:34 --> Total execution time: 0.3226
INFO - 2020-12-29 05:53:34 --> Config Class Initialized
INFO - 2020-12-29 05:53:34 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:53:34 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:53:34 --> Utf8 Class Initialized
INFO - 2020-12-29 05:53:34 --> URI Class Initialized
INFO - 2020-12-29 05:53:34 --> Router Class Initialized
INFO - 2020-12-29 05:53:34 --> Output Class Initialized
INFO - 2020-12-29 05:53:34 --> Security Class Initialized
DEBUG - 2020-12-29 05:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:53:34 --> Input Class Initialized
INFO - 2020-12-29 05:53:34 --> Language Class Initialized
INFO - 2020-12-29 05:53:34 --> Language Class Initialized
INFO - 2020-12-29 05:53:34 --> Config Class Initialized
INFO - 2020-12-29 05:53:34 --> Loader Class Initialized
INFO - 2020-12-29 05:53:34 --> Helper loaded: url_helper
INFO - 2020-12-29 05:53:34 --> Helper loaded: file_helper
INFO - 2020-12-29 05:53:34 --> Helper loaded: form_helper
INFO - 2020-12-29 05:53:34 --> Helper loaded: my_helper
INFO - 2020-12-29 05:53:34 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:53:34 --> Controller Class Initialized
INFO - 2020-12-29 05:53:37 --> Config Class Initialized
INFO - 2020-12-29 05:53:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 05:53:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 05:53:37 --> Utf8 Class Initialized
INFO - 2020-12-29 05:53:37 --> URI Class Initialized
INFO - 2020-12-29 05:53:37 --> Router Class Initialized
INFO - 2020-12-29 05:53:37 --> Output Class Initialized
INFO - 2020-12-29 05:53:37 --> Security Class Initialized
DEBUG - 2020-12-29 05:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 05:53:37 --> Input Class Initialized
INFO - 2020-12-29 05:53:37 --> Language Class Initialized
INFO - 2020-12-29 05:53:37 --> Language Class Initialized
INFO - 2020-12-29 05:53:37 --> Config Class Initialized
INFO - 2020-12-29 05:53:37 --> Loader Class Initialized
INFO - 2020-12-29 05:53:37 --> Helper loaded: url_helper
INFO - 2020-12-29 05:53:37 --> Helper loaded: file_helper
INFO - 2020-12-29 05:53:37 --> Helper loaded: form_helper
INFO - 2020-12-29 05:53:37 --> Helper loaded: my_helper
INFO - 2020-12-29 05:53:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 05:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 05:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 05:53:37 --> Controller Class Initialized
INFO - 2020-12-29 05:53:37 --> Final output sent to browser
DEBUG - 2020-12-29 05:53:37 --> Total execution time: 0.2825
INFO - 2020-12-29 06:13:57 --> Config Class Initialized
INFO - 2020-12-29 06:13:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:13:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:13:57 --> Utf8 Class Initialized
INFO - 2020-12-29 06:13:57 --> URI Class Initialized
INFO - 2020-12-29 06:13:57 --> Router Class Initialized
INFO - 2020-12-29 06:13:57 --> Output Class Initialized
INFO - 2020-12-29 06:13:57 --> Security Class Initialized
DEBUG - 2020-12-29 06:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:13:57 --> Input Class Initialized
INFO - 2020-12-29 06:13:57 --> Language Class Initialized
INFO - 2020-12-29 06:13:57 --> Language Class Initialized
INFO - 2020-12-29 06:13:57 --> Config Class Initialized
INFO - 2020-12-29 06:13:57 --> Loader Class Initialized
INFO - 2020-12-29 06:13:57 --> Helper loaded: url_helper
INFO - 2020-12-29 06:13:57 --> Helper loaded: file_helper
INFO - 2020-12-29 06:13:57 --> Helper loaded: form_helper
INFO - 2020-12-29 06:13:57 --> Helper loaded: my_helper
INFO - 2020-12-29 06:13:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:13:57 --> Controller Class Initialized
DEBUG - 2020-12-29 06:13:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 06:13:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 06:13:57 --> Final output sent to browser
DEBUG - 2020-12-29 06:13:57 --> Total execution time: 0.3872
INFO - 2020-12-29 06:13:57 --> Config Class Initialized
INFO - 2020-12-29 06:13:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:13:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:13:57 --> Utf8 Class Initialized
INFO - 2020-12-29 06:13:57 --> URI Class Initialized
INFO - 2020-12-29 06:13:57 --> Router Class Initialized
INFO - 2020-12-29 06:13:57 --> Output Class Initialized
INFO - 2020-12-29 06:13:57 --> Security Class Initialized
DEBUG - 2020-12-29 06:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:13:57 --> Input Class Initialized
INFO - 2020-12-29 06:13:57 --> Language Class Initialized
INFO - 2020-12-29 06:13:57 --> Language Class Initialized
INFO - 2020-12-29 06:13:57 --> Config Class Initialized
INFO - 2020-12-29 06:13:57 --> Loader Class Initialized
INFO - 2020-12-29 06:13:57 --> Helper loaded: url_helper
INFO - 2020-12-29 06:13:57 --> Helper loaded: file_helper
INFO - 2020-12-29 06:13:57 --> Helper loaded: form_helper
INFO - 2020-12-29 06:13:57 --> Helper loaded: my_helper
INFO - 2020-12-29 06:13:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:13:57 --> Controller Class Initialized
INFO - 2020-12-29 06:13:58 --> Config Class Initialized
INFO - 2020-12-29 06:13:58 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:13:58 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:13:58 --> Utf8 Class Initialized
INFO - 2020-12-29 06:13:58 --> URI Class Initialized
INFO - 2020-12-29 06:13:58 --> Router Class Initialized
INFO - 2020-12-29 06:13:58 --> Output Class Initialized
INFO - 2020-12-29 06:13:58 --> Security Class Initialized
DEBUG - 2020-12-29 06:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:13:58 --> Input Class Initialized
INFO - 2020-12-29 06:13:58 --> Language Class Initialized
INFO - 2020-12-29 06:13:58 --> Language Class Initialized
INFO - 2020-12-29 06:13:58 --> Config Class Initialized
INFO - 2020-12-29 06:13:58 --> Loader Class Initialized
INFO - 2020-12-29 06:13:58 --> Helper loaded: url_helper
INFO - 2020-12-29 06:13:58 --> Helper loaded: file_helper
INFO - 2020-12-29 06:13:58 --> Helper loaded: form_helper
INFO - 2020-12-29 06:13:58 --> Helper loaded: my_helper
INFO - 2020-12-29 06:13:58 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:13:58 --> Controller Class Initialized
INFO - 2020-12-29 06:13:58 --> Final output sent to browser
DEBUG - 2020-12-29 06:13:58 --> Total execution time: 0.2934
INFO - 2020-12-29 06:14:24 --> Config Class Initialized
INFO - 2020-12-29 06:14:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:14:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:14:25 --> Utf8 Class Initialized
INFO - 2020-12-29 06:14:25 --> URI Class Initialized
INFO - 2020-12-29 06:14:25 --> Router Class Initialized
INFO - 2020-12-29 06:14:25 --> Output Class Initialized
INFO - 2020-12-29 06:14:25 --> Security Class Initialized
DEBUG - 2020-12-29 06:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:14:25 --> Input Class Initialized
INFO - 2020-12-29 06:14:25 --> Language Class Initialized
INFO - 2020-12-29 06:14:25 --> Language Class Initialized
INFO - 2020-12-29 06:14:25 --> Config Class Initialized
INFO - 2020-12-29 06:14:25 --> Loader Class Initialized
INFO - 2020-12-29 06:14:25 --> Helper loaded: url_helper
INFO - 2020-12-29 06:14:25 --> Helper loaded: file_helper
INFO - 2020-12-29 06:14:25 --> Helper loaded: form_helper
INFO - 2020-12-29 06:14:25 --> Helper loaded: my_helper
INFO - 2020-12-29 06:14:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:14:25 --> Controller Class Initialized
INFO - 2020-12-29 06:14:25 --> Final output sent to browser
DEBUG - 2020-12-29 06:14:25 --> Total execution time: 0.2941
INFO - 2020-12-29 06:14:25 --> Config Class Initialized
INFO - 2020-12-29 06:14:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:14:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:14:25 --> Utf8 Class Initialized
INFO - 2020-12-29 06:14:25 --> URI Class Initialized
INFO - 2020-12-29 06:14:25 --> Router Class Initialized
INFO - 2020-12-29 06:14:25 --> Output Class Initialized
INFO - 2020-12-29 06:14:25 --> Security Class Initialized
DEBUG - 2020-12-29 06:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:14:25 --> Input Class Initialized
INFO - 2020-12-29 06:14:25 --> Language Class Initialized
INFO - 2020-12-29 06:14:25 --> Language Class Initialized
INFO - 2020-12-29 06:14:25 --> Config Class Initialized
INFO - 2020-12-29 06:14:25 --> Loader Class Initialized
INFO - 2020-12-29 06:14:25 --> Helper loaded: url_helper
INFO - 2020-12-29 06:14:25 --> Helper loaded: file_helper
INFO - 2020-12-29 06:14:25 --> Helper loaded: form_helper
INFO - 2020-12-29 06:14:25 --> Helper loaded: my_helper
INFO - 2020-12-29 06:14:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:14:25 --> Controller Class Initialized
INFO - 2020-12-29 06:14:27 --> Config Class Initialized
INFO - 2020-12-29 06:14:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:14:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:14:27 --> Utf8 Class Initialized
INFO - 2020-12-29 06:14:27 --> URI Class Initialized
INFO - 2020-12-29 06:14:27 --> Router Class Initialized
INFO - 2020-12-29 06:14:27 --> Output Class Initialized
INFO - 2020-12-29 06:14:27 --> Security Class Initialized
DEBUG - 2020-12-29 06:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:14:27 --> Input Class Initialized
INFO - 2020-12-29 06:14:27 --> Language Class Initialized
INFO - 2020-12-29 06:14:27 --> Language Class Initialized
INFO - 2020-12-29 06:14:27 --> Config Class Initialized
INFO - 2020-12-29 06:14:27 --> Loader Class Initialized
INFO - 2020-12-29 06:14:27 --> Helper loaded: url_helper
INFO - 2020-12-29 06:14:27 --> Helper loaded: file_helper
INFO - 2020-12-29 06:14:27 --> Helper loaded: form_helper
INFO - 2020-12-29 06:14:27 --> Helper loaded: my_helper
INFO - 2020-12-29 06:14:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:14:27 --> Controller Class Initialized
INFO - 2020-12-29 06:14:27 --> Final output sent to browser
DEBUG - 2020-12-29 06:14:27 --> Total execution time: 0.3155
INFO - 2020-12-29 06:14:47 --> Config Class Initialized
INFO - 2020-12-29 06:14:47 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:14:47 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:14:47 --> Utf8 Class Initialized
INFO - 2020-12-29 06:14:47 --> URI Class Initialized
INFO - 2020-12-29 06:14:47 --> Router Class Initialized
INFO - 2020-12-29 06:14:47 --> Output Class Initialized
INFO - 2020-12-29 06:14:47 --> Security Class Initialized
DEBUG - 2020-12-29 06:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:14:47 --> Input Class Initialized
INFO - 2020-12-29 06:14:47 --> Language Class Initialized
INFO - 2020-12-29 06:14:47 --> Language Class Initialized
INFO - 2020-12-29 06:14:47 --> Config Class Initialized
INFO - 2020-12-29 06:14:47 --> Loader Class Initialized
INFO - 2020-12-29 06:14:47 --> Helper loaded: url_helper
INFO - 2020-12-29 06:14:47 --> Helper loaded: file_helper
INFO - 2020-12-29 06:14:47 --> Helper loaded: form_helper
INFO - 2020-12-29 06:14:47 --> Helper loaded: my_helper
INFO - 2020-12-29 06:14:47 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:14:47 --> Controller Class Initialized
INFO - 2020-12-29 06:14:47 --> Final output sent to browser
DEBUG - 2020-12-29 06:14:47 --> Total execution time: 0.3525
INFO - 2020-12-29 06:14:48 --> Config Class Initialized
INFO - 2020-12-29 06:14:48 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:14:48 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:14:48 --> Utf8 Class Initialized
INFO - 2020-12-29 06:14:48 --> URI Class Initialized
INFO - 2020-12-29 06:14:48 --> Router Class Initialized
INFO - 2020-12-29 06:14:48 --> Output Class Initialized
INFO - 2020-12-29 06:14:48 --> Security Class Initialized
DEBUG - 2020-12-29 06:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:14:48 --> Input Class Initialized
INFO - 2020-12-29 06:14:48 --> Language Class Initialized
INFO - 2020-12-29 06:14:48 --> Language Class Initialized
INFO - 2020-12-29 06:14:48 --> Config Class Initialized
INFO - 2020-12-29 06:14:48 --> Loader Class Initialized
INFO - 2020-12-29 06:14:48 --> Helper loaded: url_helper
INFO - 2020-12-29 06:14:48 --> Helper loaded: file_helper
INFO - 2020-12-29 06:14:48 --> Helper loaded: form_helper
INFO - 2020-12-29 06:14:48 --> Helper loaded: my_helper
INFO - 2020-12-29 06:14:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:14:48 --> Controller Class Initialized
INFO - 2020-12-29 06:14:50 --> Config Class Initialized
INFO - 2020-12-29 06:14:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:14:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:14:50 --> Utf8 Class Initialized
INFO - 2020-12-29 06:14:50 --> URI Class Initialized
INFO - 2020-12-29 06:14:50 --> Router Class Initialized
INFO - 2020-12-29 06:14:50 --> Output Class Initialized
INFO - 2020-12-29 06:14:50 --> Security Class Initialized
DEBUG - 2020-12-29 06:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:14:50 --> Input Class Initialized
INFO - 2020-12-29 06:14:50 --> Language Class Initialized
INFO - 2020-12-29 06:14:50 --> Language Class Initialized
INFO - 2020-12-29 06:14:50 --> Config Class Initialized
INFO - 2020-12-29 06:14:50 --> Loader Class Initialized
INFO - 2020-12-29 06:14:50 --> Helper loaded: url_helper
INFO - 2020-12-29 06:14:50 --> Helper loaded: file_helper
INFO - 2020-12-29 06:14:50 --> Helper loaded: form_helper
INFO - 2020-12-29 06:14:50 --> Helper loaded: my_helper
INFO - 2020-12-29 06:14:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:14:50 --> Controller Class Initialized
INFO - 2020-12-29 06:14:50 --> Final output sent to browser
DEBUG - 2020-12-29 06:14:50 --> Total execution time: 0.2869
INFO - 2020-12-29 06:15:13 --> Config Class Initialized
INFO - 2020-12-29 06:15:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:13 --> Utf8 Class Initialized
INFO - 2020-12-29 06:15:13 --> URI Class Initialized
INFO - 2020-12-29 06:15:13 --> Router Class Initialized
INFO - 2020-12-29 06:15:13 --> Output Class Initialized
INFO - 2020-12-29 06:15:13 --> Security Class Initialized
DEBUG - 2020-12-29 06:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:15:13 --> Input Class Initialized
INFO - 2020-12-29 06:15:13 --> Language Class Initialized
INFO - 2020-12-29 06:15:13 --> Language Class Initialized
INFO - 2020-12-29 06:15:13 --> Config Class Initialized
INFO - 2020-12-29 06:15:13 --> Loader Class Initialized
INFO - 2020-12-29 06:15:13 --> Helper loaded: url_helper
INFO - 2020-12-29 06:15:13 --> Helper loaded: file_helper
INFO - 2020-12-29 06:15:13 --> Helper loaded: form_helper
INFO - 2020-12-29 06:15:13 --> Helper loaded: my_helper
INFO - 2020-12-29 06:15:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:15:13 --> Controller Class Initialized
INFO - 2020-12-29 06:15:13 --> Final output sent to browser
DEBUG - 2020-12-29 06:15:13 --> Total execution time: 0.3266
INFO - 2020-12-29 06:15:13 --> Config Class Initialized
INFO - 2020-12-29 06:15:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:13 --> Utf8 Class Initialized
INFO - 2020-12-29 06:15:13 --> URI Class Initialized
INFO - 2020-12-29 06:15:13 --> Router Class Initialized
INFO - 2020-12-29 06:15:13 --> Output Class Initialized
INFO - 2020-12-29 06:15:13 --> Security Class Initialized
DEBUG - 2020-12-29 06:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:15:13 --> Input Class Initialized
INFO - 2020-12-29 06:15:13 --> Language Class Initialized
INFO - 2020-12-29 06:15:13 --> Language Class Initialized
INFO - 2020-12-29 06:15:13 --> Config Class Initialized
INFO - 2020-12-29 06:15:13 --> Loader Class Initialized
INFO - 2020-12-29 06:15:13 --> Helper loaded: url_helper
INFO - 2020-12-29 06:15:13 --> Helper loaded: file_helper
INFO - 2020-12-29 06:15:13 --> Helper loaded: form_helper
INFO - 2020-12-29 06:15:13 --> Helper loaded: my_helper
INFO - 2020-12-29 06:15:14 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:15:14 --> Controller Class Initialized
INFO - 2020-12-29 06:15:19 --> Config Class Initialized
INFO - 2020-12-29 06:15:19 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:19 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:19 --> Utf8 Class Initialized
INFO - 2020-12-29 06:15:19 --> URI Class Initialized
INFO - 2020-12-29 06:15:19 --> Router Class Initialized
INFO - 2020-12-29 06:15:19 --> Output Class Initialized
INFO - 2020-12-29 06:15:19 --> Security Class Initialized
DEBUG - 2020-12-29 06:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:15:19 --> Input Class Initialized
INFO - 2020-12-29 06:15:19 --> Language Class Initialized
INFO - 2020-12-29 06:15:19 --> Language Class Initialized
INFO - 2020-12-29 06:15:20 --> Config Class Initialized
INFO - 2020-12-29 06:15:20 --> Loader Class Initialized
INFO - 2020-12-29 06:15:20 --> Helper loaded: url_helper
INFO - 2020-12-29 06:15:20 --> Helper loaded: file_helper
INFO - 2020-12-29 06:15:20 --> Helper loaded: form_helper
INFO - 2020-12-29 06:15:20 --> Helper loaded: my_helper
INFO - 2020-12-29 06:15:20 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:15:20 --> Controller Class Initialized
INFO - 2020-12-29 06:15:20 --> Final output sent to browser
DEBUG - 2020-12-29 06:15:20 --> Total execution time: 0.4070
INFO - 2020-12-29 06:15:38 --> Config Class Initialized
INFO - 2020-12-29 06:15:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:38 --> Utf8 Class Initialized
INFO - 2020-12-29 06:15:38 --> URI Class Initialized
INFO - 2020-12-29 06:15:38 --> Router Class Initialized
INFO - 2020-12-29 06:15:38 --> Output Class Initialized
INFO - 2020-12-29 06:15:38 --> Security Class Initialized
DEBUG - 2020-12-29 06:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:15:38 --> Input Class Initialized
INFO - 2020-12-29 06:15:38 --> Language Class Initialized
INFO - 2020-12-29 06:15:38 --> Language Class Initialized
INFO - 2020-12-29 06:15:38 --> Config Class Initialized
INFO - 2020-12-29 06:15:38 --> Loader Class Initialized
INFO - 2020-12-29 06:15:38 --> Helper loaded: url_helper
INFO - 2020-12-29 06:15:38 --> Helper loaded: file_helper
INFO - 2020-12-29 06:15:38 --> Helper loaded: form_helper
INFO - 2020-12-29 06:15:38 --> Helper loaded: my_helper
INFO - 2020-12-29 06:15:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:15:38 --> Controller Class Initialized
INFO - 2020-12-29 06:15:39 --> Final output sent to browser
DEBUG - 2020-12-29 06:15:39 --> Total execution time: 0.3138
INFO - 2020-12-29 06:15:39 --> Config Class Initialized
INFO - 2020-12-29 06:15:39 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:39 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:39 --> Utf8 Class Initialized
INFO - 2020-12-29 06:15:39 --> URI Class Initialized
INFO - 2020-12-29 06:15:39 --> Router Class Initialized
INFO - 2020-12-29 06:15:39 --> Output Class Initialized
INFO - 2020-12-29 06:15:39 --> Security Class Initialized
DEBUG - 2020-12-29 06:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:15:39 --> Input Class Initialized
INFO - 2020-12-29 06:15:39 --> Language Class Initialized
INFO - 2020-12-29 06:15:39 --> Language Class Initialized
INFO - 2020-12-29 06:15:39 --> Config Class Initialized
INFO - 2020-12-29 06:15:39 --> Loader Class Initialized
INFO - 2020-12-29 06:15:39 --> Helper loaded: url_helper
INFO - 2020-12-29 06:15:39 --> Helper loaded: file_helper
INFO - 2020-12-29 06:15:39 --> Helper loaded: form_helper
INFO - 2020-12-29 06:15:39 --> Helper loaded: my_helper
INFO - 2020-12-29 06:15:39 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:15:39 --> Controller Class Initialized
INFO - 2020-12-29 06:15:43 --> Config Class Initialized
INFO - 2020-12-29 06:15:43 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:43 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:43 --> Utf8 Class Initialized
INFO - 2020-12-29 06:15:43 --> URI Class Initialized
INFO - 2020-12-29 06:15:43 --> Router Class Initialized
INFO - 2020-12-29 06:15:43 --> Output Class Initialized
INFO - 2020-12-29 06:15:43 --> Security Class Initialized
DEBUG - 2020-12-29 06:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:15:43 --> Input Class Initialized
INFO - 2020-12-29 06:15:43 --> Language Class Initialized
INFO - 2020-12-29 06:15:43 --> Language Class Initialized
INFO - 2020-12-29 06:15:43 --> Config Class Initialized
INFO - 2020-12-29 06:15:43 --> Loader Class Initialized
INFO - 2020-12-29 06:15:43 --> Helper loaded: url_helper
INFO - 2020-12-29 06:15:43 --> Helper loaded: file_helper
INFO - 2020-12-29 06:15:43 --> Helper loaded: form_helper
INFO - 2020-12-29 06:15:43 --> Helper loaded: my_helper
INFO - 2020-12-29 06:15:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:15:43 --> Controller Class Initialized
INFO - 2020-12-29 06:15:43 --> Final output sent to browser
DEBUG - 2020-12-29 06:15:43 --> Total execution time: 0.2779
INFO - 2020-12-29 06:15:57 --> Config Class Initialized
INFO - 2020-12-29 06:15:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:58 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:58 --> Utf8 Class Initialized
INFO - 2020-12-29 06:15:58 --> URI Class Initialized
INFO - 2020-12-29 06:15:58 --> Router Class Initialized
INFO - 2020-12-29 06:15:58 --> Output Class Initialized
INFO - 2020-12-29 06:15:58 --> Security Class Initialized
DEBUG - 2020-12-29 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:15:58 --> Input Class Initialized
INFO - 2020-12-29 06:15:58 --> Language Class Initialized
INFO - 2020-12-29 06:15:58 --> Language Class Initialized
INFO - 2020-12-29 06:15:58 --> Config Class Initialized
INFO - 2020-12-29 06:15:58 --> Loader Class Initialized
INFO - 2020-12-29 06:15:58 --> Helper loaded: url_helper
INFO - 2020-12-29 06:15:58 --> Helper loaded: file_helper
INFO - 2020-12-29 06:15:58 --> Helper loaded: form_helper
INFO - 2020-12-29 06:15:58 --> Helper loaded: my_helper
INFO - 2020-12-29 06:15:58 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:15:58 --> Controller Class Initialized
INFO - 2020-12-29 06:15:58 --> Final output sent to browser
DEBUG - 2020-12-29 06:15:58 --> Total execution time: 0.2913
INFO - 2020-12-29 06:15:58 --> Config Class Initialized
INFO - 2020-12-29 06:15:58 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:58 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:58 --> Utf8 Class Initialized
INFO - 2020-12-29 06:15:58 --> URI Class Initialized
INFO - 2020-12-29 06:15:58 --> Router Class Initialized
INFO - 2020-12-29 06:15:58 --> Output Class Initialized
INFO - 2020-12-29 06:15:58 --> Security Class Initialized
DEBUG - 2020-12-29 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:15:58 --> Input Class Initialized
INFO - 2020-12-29 06:15:58 --> Language Class Initialized
INFO - 2020-12-29 06:15:58 --> Language Class Initialized
INFO - 2020-12-29 06:15:58 --> Config Class Initialized
INFO - 2020-12-29 06:15:58 --> Loader Class Initialized
INFO - 2020-12-29 06:15:58 --> Helper loaded: url_helper
INFO - 2020-12-29 06:15:58 --> Helper loaded: file_helper
INFO - 2020-12-29 06:15:58 --> Helper loaded: form_helper
INFO - 2020-12-29 06:15:58 --> Helper loaded: my_helper
INFO - 2020-12-29 06:15:58 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:15:58 --> Controller Class Initialized
INFO - 2020-12-29 06:15:59 --> Config Class Initialized
INFO - 2020-12-29 06:15:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:15:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:15:59 --> Utf8 Class Initialized
INFO - 2020-12-29 06:16:00 --> URI Class Initialized
INFO - 2020-12-29 06:16:00 --> Router Class Initialized
INFO - 2020-12-29 06:16:00 --> Output Class Initialized
INFO - 2020-12-29 06:16:00 --> Security Class Initialized
DEBUG - 2020-12-29 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:16:00 --> Input Class Initialized
INFO - 2020-12-29 06:16:00 --> Language Class Initialized
INFO - 2020-12-29 06:16:00 --> Language Class Initialized
INFO - 2020-12-29 06:16:00 --> Config Class Initialized
INFO - 2020-12-29 06:16:00 --> Loader Class Initialized
INFO - 2020-12-29 06:16:00 --> Helper loaded: url_helper
INFO - 2020-12-29 06:16:00 --> Helper loaded: file_helper
INFO - 2020-12-29 06:16:00 --> Helper loaded: form_helper
INFO - 2020-12-29 06:16:00 --> Helper loaded: my_helper
INFO - 2020-12-29 06:16:00 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:16:00 --> Controller Class Initialized
INFO - 2020-12-29 06:16:00 --> Final output sent to browser
DEBUG - 2020-12-29 06:16:00 --> Total execution time: 0.2704
INFO - 2020-12-29 06:16:36 --> Config Class Initialized
INFO - 2020-12-29 06:16:36 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:16:36 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:16:36 --> Utf8 Class Initialized
INFO - 2020-12-29 06:16:36 --> URI Class Initialized
INFO - 2020-12-29 06:16:36 --> Router Class Initialized
INFO - 2020-12-29 06:16:36 --> Output Class Initialized
INFO - 2020-12-29 06:16:36 --> Security Class Initialized
DEBUG - 2020-12-29 06:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:16:36 --> Input Class Initialized
INFO - 2020-12-29 06:16:36 --> Language Class Initialized
INFO - 2020-12-29 06:16:36 --> Language Class Initialized
INFO - 2020-12-29 06:16:36 --> Config Class Initialized
INFO - 2020-12-29 06:16:36 --> Loader Class Initialized
INFO - 2020-12-29 06:16:36 --> Helper loaded: url_helper
INFO - 2020-12-29 06:16:36 --> Helper loaded: file_helper
INFO - 2020-12-29 06:16:36 --> Helper loaded: form_helper
INFO - 2020-12-29 06:16:36 --> Helper loaded: my_helper
INFO - 2020-12-29 06:16:36 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:16:36 --> Controller Class Initialized
INFO - 2020-12-29 06:16:36 --> Final output sent to browser
DEBUG - 2020-12-29 06:16:36 --> Total execution time: 0.3014
INFO - 2020-12-29 06:16:37 --> Config Class Initialized
INFO - 2020-12-29 06:16:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:16:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:16:37 --> Utf8 Class Initialized
INFO - 2020-12-29 06:16:37 --> URI Class Initialized
INFO - 2020-12-29 06:16:37 --> Router Class Initialized
INFO - 2020-12-29 06:16:37 --> Output Class Initialized
INFO - 2020-12-29 06:16:37 --> Security Class Initialized
DEBUG - 2020-12-29 06:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:16:37 --> Input Class Initialized
INFO - 2020-12-29 06:16:37 --> Language Class Initialized
INFO - 2020-12-29 06:16:37 --> Language Class Initialized
INFO - 2020-12-29 06:16:37 --> Config Class Initialized
INFO - 2020-12-29 06:16:37 --> Loader Class Initialized
INFO - 2020-12-29 06:16:37 --> Helper loaded: url_helper
INFO - 2020-12-29 06:16:37 --> Helper loaded: file_helper
INFO - 2020-12-29 06:16:37 --> Helper loaded: form_helper
INFO - 2020-12-29 06:16:37 --> Helper loaded: my_helper
INFO - 2020-12-29 06:16:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:16:37 --> Controller Class Initialized
INFO - 2020-12-29 06:16:38 --> Config Class Initialized
INFO - 2020-12-29 06:16:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:16:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:16:38 --> Utf8 Class Initialized
INFO - 2020-12-29 06:16:38 --> URI Class Initialized
INFO - 2020-12-29 06:16:38 --> Router Class Initialized
INFO - 2020-12-29 06:16:38 --> Output Class Initialized
INFO - 2020-12-29 06:16:38 --> Security Class Initialized
DEBUG - 2020-12-29 06:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:16:38 --> Input Class Initialized
INFO - 2020-12-29 06:16:38 --> Language Class Initialized
INFO - 2020-12-29 06:16:38 --> Language Class Initialized
INFO - 2020-12-29 06:16:38 --> Config Class Initialized
INFO - 2020-12-29 06:16:38 --> Loader Class Initialized
INFO - 2020-12-29 06:16:38 --> Helper loaded: url_helper
INFO - 2020-12-29 06:16:38 --> Helper loaded: file_helper
INFO - 2020-12-29 06:16:38 --> Helper loaded: form_helper
INFO - 2020-12-29 06:16:38 --> Helper loaded: my_helper
INFO - 2020-12-29 06:16:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:16:38 --> Controller Class Initialized
INFO - 2020-12-29 06:16:38 --> Final output sent to browser
DEBUG - 2020-12-29 06:16:38 --> Total execution time: 0.2729
INFO - 2020-12-29 06:16:57 --> Config Class Initialized
INFO - 2020-12-29 06:16:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:16:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:16:57 --> Utf8 Class Initialized
INFO - 2020-12-29 06:16:57 --> URI Class Initialized
INFO - 2020-12-29 06:16:57 --> Router Class Initialized
INFO - 2020-12-29 06:16:57 --> Output Class Initialized
INFO - 2020-12-29 06:16:57 --> Security Class Initialized
DEBUG - 2020-12-29 06:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:16:57 --> Input Class Initialized
INFO - 2020-12-29 06:16:57 --> Language Class Initialized
INFO - 2020-12-29 06:16:57 --> Language Class Initialized
INFO - 2020-12-29 06:16:57 --> Config Class Initialized
INFO - 2020-12-29 06:16:57 --> Loader Class Initialized
INFO - 2020-12-29 06:16:57 --> Helper loaded: url_helper
INFO - 2020-12-29 06:16:57 --> Helper loaded: file_helper
INFO - 2020-12-29 06:16:57 --> Helper loaded: form_helper
INFO - 2020-12-29 06:16:57 --> Helper loaded: my_helper
INFO - 2020-12-29 06:16:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:16:57 --> Controller Class Initialized
INFO - 2020-12-29 06:16:57 --> Final output sent to browser
DEBUG - 2020-12-29 06:16:57 --> Total execution time: 0.2995
INFO - 2020-12-29 06:16:57 --> Config Class Initialized
INFO - 2020-12-29 06:16:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:16:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:16:57 --> Utf8 Class Initialized
INFO - 2020-12-29 06:16:57 --> URI Class Initialized
INFO - 2020-12-29 06:16:57 --> Router Class Initialized
INFO - 2020-12-29 06:16:57 --> Output Class Initialized
INFO - 2020-12-29 06:16:57 --> Security Class Initialized
DEBUG - 2020-12-29 06:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:16:57 --> Input Class Initialized
INFO - 2020-12-29 06:16:57 --> Language Class Initialized
INFO - 2020-12-29 06:16:57 --> Language Class Initialized
INFO - 2020-12-29 06:16:57 --> Config Class Initialized
INFO - 2020-12-29 06:16:57 --> Loader Class Initialized
INFO - 2020-12-29 06:16:57 --> Helper loaded: url_helper
INFO - 2020-12-29 06:16:57 --> Helper loaded: file_helper
INFO - 2020-12-29 06:16:57 --> Helper loaded: form_helper
INFO - 2020-12-29 06:16:57 --> Helper loaded: my_helper
INFO - 2020-12-29 06:16:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:16:57 --> Controller Class Initialized
INFO - 2020-12-29 06:16:59 --> Config Class Initialized
INFO - 2020-12-29 06:16:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:16:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:16:59 --> Utf8 Class Initialized
INFO - 2020-12-29 06:16:59 --> URI Class Initialized
INFO - 2020-12-29 06:16:59 --> Router Class Initialized
INFO - 2020-12-29 06:16:59 --> Output Class Initialized
INFO - 2020-12-29 06:16:59 --> Security Class Initialized
DEBUG - 2020-12-29 06:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:16:59 --> Input Class Initialized
INFO - 2020-12-29 06:16:59 --> Language Class Initialized
INFO - 2020-12-29 06:16:59 --> Language Class Initialized
INFO - 2020-12-29 06:16:59 --> Config Class Initialized
INFO - 2020-12-29 06:16:59 --> Loader Class Initialized
INFO - 2020-12-29 06:16:59 --> Helper loaded: url_helper
INFO - 2020-12-29 06:16:59 --> Helper loaded: file_helper
INFO - 2020-12-29 06:16:59 --> Helper loaded: form_helper
INFO - 2020-12-29 06:16:59 --> Helper loaded: my_helper
INFO - 2020-12-29 06:16:59 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:16:59 --> Controller Class Initialized
INFO - 2020-12-29 06:16:59 --> Final output sent to browser
DEBUG - 2020-12-29 06:16:59 --> Total execution time: 0.2810
INFO - 2020-12-29 06:17:44 --> Config Class Initialized
INFO - 2020-12-29 06:17:44 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:17:44 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:17:44 --> Utf8 Class Initialized
INFO - 2020-12-29 06:17:44 --> URI Class Initialized
INFO - 2020-12-29 06:17:44 --> Router Class Initialized
INFO - 2020-12-29 06:17:44 --> Output Class Initialized
INFO - 2020-12-29 06:17:44 --> Security Class Initialized
DEBUG - 2020-12-29 06:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:17:44 --> Input Class Initialized
INFO - 2020-12-29 06:17:44 --> Language Class Initialized
INFO - 2020-12-29 06:17:44 --> Language Class Initialized
INFO - 2020-12-29 06:17:44 --> Config Class Initialized
INFO - 2020-12-29 06:17:44 --> Loader Class Initialized
INFO - 2020-12-29 06:17:44 --> Helper loaded: url_helper
INFO - 2020-12-29 06:17:44 --> Helper loaded: file_helper
INFO - 2020-12-29 06:17:44 --> Helper loaded: form_helper
INFO - 2020-12-29 06:17:44 --> Helper loaded: my_helper
INFO - 2020-12-29 06:17:44 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:17:44 --> Controller Class Initialized
INFO - 2020-12-29 06:17:44 --> Final output sent to browser
DEBUG - 2020-12-29 06:17:44 --> Total execution time: 0.3003
INFO - 2020-12-29 06:17:44 --> Config Class Initialized
INFO - 2020-12-29 06:17:44 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:17:44 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:17:44 --> Utf8 Class Initialized
INFO - 2020-12-29 06:17:44 --> URI Class Initialized
INFO - 2020-12-29 06:17:44 --> Router Class Initialized
INFO - 2020-12-29 06:17:44 --> Output Class Initialized
INFO - 2020-12-29 06:17:45 --> Security Class Initialized
DEBUG - 2020-12-29 06:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:17:45 --> Input Class Initialized
INFO - 2020-12-29 06:17:45 --> Language Class Initialized
INFO - 2020-12-29 06:17:45 --> Language Class Initialized
INFO - 2020-12-29 06:17:45 --> Config Class Initialized
INFO - 2020-12-29 06:17:45 --> Loader Class Initialized
INFO - 2020-12-29 06:17:45 --> Helper loaded: url_helper
INFO - 2020-12-29 06:17:45 --> Helper loaded: file_helper
INFO - 2020-12-29 06:17:45 --> Helper loaded: form_helper
INFO - 2020-12-29 06:17:45 --> Helper loaded: my_helper
INFO - 2020-12-29 06:17:45 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:17:45 --> Controller Class Initialized
INFO - 2020-12-29 06:36:49 --> Config Class Initialized
INFO - 2020-12-29 06:36:49 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:36:49 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:36:49 --> Utf8 Class Initialized
INFO - 2020-12-29 06:36:49 --> URI Class Initialized
INFO - 2020-12-29 06:36:49 --> Router Class Initialized
INFO - 2020-12-29 06:36:49 --> Output Class Initialized
INFO - 2020-12-29 06:36:49 --> Security Class Initialized
DEBUG - 2020-12-29 06:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:36:50 --> Input Class Initialized
INFO - 2020-12-29 06:36:50 --> Language Class Initialized
INFO - 2020-12-29 06:36:50 --> Language Class Initialized
INFO - 2020-12-29 06:36:50 --> Config Class Initialized
INFO - 2020-12-29 06:36:50 --> Loader Class Initialized
INFO - 2020-12-29 06:36:50 --> Helper loaded: url_helper
INFO - 2020-12-29 06:36:50 --> Helper loaded: file_helper
INFO - 2020-12-29 06:36:50 --> Helper loaded: form_helper
INFO - 2020-12-29 06:36:50 --> Helper loaded: my_helper
INFO - 2020-12-29 06:36:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:36:50 --> Controller Class Initialized
INFO - 2020-12-29 06:36:50 --> Final output sent to browser
DEBUG - 2020-12-29 06:36:50 --> Total execution time: 0.3626
INFO - 2020-12-29 06:37:29 --> Config Class Initialized
INFO - 2020-12-29 06:37:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:37:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:37:29 --> Utf8 Class Initialized
INFO - 2020-12-29 06:37:29 --> URI Class Initialized
INFO - 2020-12-29 06:37:29 --> Router Class Initialized
INFO - 2020-12-29 06:37:29 --> Output Class Initialized
INFO - 2020-12-29 06:37:29 --> Security Class Initialized
DEBUG - 2020-12-29 06:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:37:29 --> Input Class Initialized
INFO - 2020-12-29 06:37:29 --> Language Class Initialized
INFO - 2020-12-29 06:37:29 --> Language Class Initialized
INFO - 2020-12-29 06:37:29 --> Config Class Initialized
INFO - 2020-12-29 06:37:29 --> Loader Class Initialized
INFO - 2020-12-29 06:37:29 --> Helper loaded: url_helper
INFO - 2020-12-29 06:37:29 --> Helper loaded: file_helper
INFO - 2020-12-29 06:37:29 --> Helper loaded: form_helper
INFO - 2020-12-29 06:37:29 --> Helper loaded: my_helper
INFO - 2020-12-29 06:37:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:37:29 --> Controller Class Initialized
INFO - 2020-12-29 06:37:29 --> Final output sent to browser
DEBUG - 2020-12-29 06:37:29 --> Total execution time: 0.3661
INFO - 2020-12-29 06:37:29 --> Config Class Initialized
INFO - 2020-12-29 06:37:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:37:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:37:29 --> Utf8 Class Initialized
INFO - 2020-12-29 06:37:29 --> URI Class Initialized
INFO - 2020-12-29 06:37:29 --> Router Class Initialized
INFO - 2020-12-29 06:37:29 --> Output Class Initialized
INFO - 2020-12-29 06:37:29 --> Security Class Initialized
DEBUG - 2020-12-29 06:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:37:29 --> Input Class Initialized
INFO - 2020-12-29 06:37:29 --> Language Class Initialized
INFO - 2020-12-29 06:37:29 --> Language Class Initialized
INFO - 2020-12-29 06:37:29 --> Config Class Initialized
INFO - 2020-12-29 06:37:29 --> Loader Class Initialized
INFO - 2020-12-29 06:37:29 --> Helper loaded: url_helper
INFO - 2020-12-29 06:37:29 --> Helper loaded: file_helper
INFO - 2020-12-29 06:37:29 --> Helper loaded: form_helper
INFO - 2020-12-29 06:37:29 --> Helper loaded: my_helper
INFO - 2020-12-29 06:37:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:37:29 --> Controller Class Initialized
INFO - 2020-12-29 06:37:33 --> Config Class Initialized
INFO - 2020-12-29 06:37:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:37:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:37:33 --> Utf8 Class Initialized
INFO - 2020-12-29 06:37:33 --> URI Class Initialized
INFO - 2020-12-29 06:37:33 --> Router Class Initialized
INFO - 2020-12-29 06:37:33 --> Output Class Initialized
INFO - 2020-12-29 06:37:33 --> Security Class Initialized
DEBUG - 2020-12-29 06:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:37:33 --> Input Class Initialized
INFO - 2020-12-29 06:37:33 --> Language Class Initialized
INFO - 2020-12-29 06:37:33 --> Language Class Initialized
INFO - 2020-12-29 06:37:33 --> Config Class Initialized
INFO - 2020-12-29 06:37:33 --> Loader Class Initialized
INFO - 2020-12-29 06:37:33 --> Helper loaded: url_helper
INFO - 2020-12-29 06:37:33 --> Helper loaded: file_helper
INFO - 2020-12-29 06:37:33 --> Helper loaded: form_helper
INFO - 2020-12-29 06:37:33 --> Helper loaded: my_helper
INFO - 2020-12-29 06:37:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:37:33 --> Controller Class Initialized
INFO - 2020-12-29 06:37:33 --> Final output sent to browser
DEBUG - 2020-12-29 06:37:33 --> Total execution time: 0.3267
INFO - 2020-12-29 06:37:49 --> Config Class Initialized
INFO - 2020-12-29 06:37:49 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:37:49 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:37:49 --> Utf8 Class Initialized
INFO - 2020-12-29 06:37:49 --> URI Class Initialized
INFO - 2020-12-29 06:37:49 --> Router Class Initialized
INFO - 2020-12-29 06:37:49 --> Output Class Initialized
INFO - 2020-12-29 06:37:49 --> Security Class Initialized
DEBUG - 2020-12-29 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:37:49 --> Input Class Initialized
INFO - 2020-12-29 06:37:50 --> Language Class Initialized
INFO - 2020-12-29 06:37:50 --> Language Class Initialized
INFO - 2020-12-29 06:37:50 --> Config Class Initialized
INFO - 2020-12-29 06:37:50 --> Loader Class Initialized
INFO - 2020-12-29 06:37:50 --> Helper loaded: url_helper
INFO - 2020-12-29 06:37:50 --> Helper loaded: file_helper
INFO - 2020-12-29 06:37:50 --> Helper loaded: form_helper
INFO - 2020-12-29 06:37:50 --> Helper loaded: my_helper
INFO - 2020-12-29 06:37:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:37:50 --> Controller Class Initialized
INFO - 2020-12-29 06:37:50 --> Final output sent to browser
DEBUG - 2020-12-29 06:37:50 --> Total execution time: 0.3262
INFO - 2020-12-29 06:37:50 --> Config Class Initialized
INFO - 2020-12-29 06:37:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:37:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:37:50 --> Utf8 Class Initialized
INFO - 2020-12-29 06:37:50 --> URI Class Initialized
INFO - 2020-12-29 06:37:50 --> Router Class Initialized
INFO - 2020-12-29 06:37:50 --> Output Class Initialized
INFO - 2020-12-29 06:37:50 --> Security Class Initialized
DEBUG - 2020-12-29 06:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:37:50 --> Input Class Initialized
INFO - 2020-12-29 06:37:50 --> Language Class Initialized
INFO - 2020-12-29 06:37:50 --> Language Class Initialized
INFO - 2020-12-29 06:37:50 --> Config Class Initialized
INFO - 2020-12-29 06:37:50 --> Loader Class Initialized
INFO - 2020-12-29 06:37:50 --> Helper loaded: url_helper
INFO - 2020-12-29 06:37:50 --> Helper loaded: file_helper
INFO - 2020-12-29 06:37:50 --> Helper loaded: form_helper
INFO - 2020-12-29 06:37:50 --> Helper loaded: my_helper
INFO - 2020-12-29 06:37:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:37:50 --> Controller Class Initialized
INFO - 2020-12-29 06:37:52 --> Config Class Initialized
INFO - 2020-12-29 06:37:52 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:37:52 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:37:52 --> Utf8 Class Initialized
INFO - 2020-12-29 06:37:52 --> URI Class Initialized
INFO - 2020-12-29 06:37:52 --> Router Class Initialized
INFO - 2020-12-29 06:37:52 --> Output Class Initialized
INFO - 2020-12-29 06:37:52 --> Security Class Initialized
DEBUG - 2020-12-29 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:37:52 --> Input Class Initialized
INFO - 2020-12-29 06:37:52 --> Language Class Initialized
INFO - 2020-12-29 06:37:52 --> Language Class Initialized
INFO - 2020-12-29 06:37:52 --> Config Class Initialized
INFO - 2020-12-29 06:37:52 --> Loader Class Initialized
INFO - 2020-12-29 06:37:52 --> Helper loaded: url_helper
INFO - 2020-12-29 06:37:52 --> Helper loaded: file_helper
INFO - 2020-12-29 06:37:52 --> Helper loaded: form_helper
INFO - 2020-12-29 06:37:52 --> Helper loaded: my_helper
INFO - 2020-12-29 06:37:52 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:37:52 --> Controller Class Initialized
INFO - 2020-12-29 06:37:52 --> Final output sent to browser
DEBUG - 2020-12-29 06:37:52 --> Total execution time: 0.3185
INFO - 2020-12-29 06:38:33 --> Config Class Initialized
INFO - 2020-12-29 06:38:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:38:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:38:33 --> Utf8 Class Initialized
INFO - 2020-12-29 06:38:33 --> URI Class Initialized
INFO - 2020-12-29 06:38:33 --> Router Class Initialized
INFO - 2020-12-29 06:38:33 --> Output Class Initialized
INFO - 2020-12-29 06:38:33 --> Security Class Initialized
DEBUG - 2020-12-29 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:38:33 --> Input Class Initialized
INFO - 2020-12-29 06:38:33 --> Language Class Initialized
INFO - 2020-12-29 06:38:33 --> Language Class Initialized
INFO - 2020-12-29 06:38:33 --> Config Class Initialized
INFO - 2020-12-29 06:38:33 --> Loader Class Initialized
INFO - 2020-12-29 06:38:33 --> Helper loaded: url_helper
INFO - 2020-12-29 06:38:33 --> Helper loaded: file_helper
INFO - 2020-12-29 06:38:33 --> Helper loaded: form_helper
INFO - 2020-12-29 06:38:33 --> Helper loaded: my_helper
INFO - 2020-12-29 06:38:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:38:33 --> Controller Class Initialized
INFO - 2020-12-29 06:38:33 --> Final output sent to browser
DEBUG - 2020-12-29 06:38:33 --> Total execution time: 0.3527
INFO - 2020-12-29 06:38:33 --> Config Class Initialized
INFO - 2020-12-29 06:38:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:38:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:38:33 --> Utf8 Class Initialized
INFO - 2020-12-29 06:38:33 --> URI Class Initialized
INFO - 2020-12-29 06:38:33 --> Router Class Initialized
INFO - 2020-12-29 06:38:33 --> Output Class Initialized
INFO - 2020-12-29 06:38:33 --> Security Class Initialized
DEBUG - 2020-12-29 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:38:33 --> Input Class Initialized
INFO - 2020-12-29 06:38:33 --> Language Class Initialized
INFO - 2020-12-29 06:38:33 --> Language Class Initialized
INFO - 2020-12-29 06:38:33 --> Config Class Initialized
INFO - 2020-12-29 06:38:33 --> Loader Class Initialized
INFO - 2020-12-29 06:38:33 --> Helper loaded: url_helper
INFO - 2020-12-29 06:38:33 --> Helper loaded: file_helper
INFO - 2020-12-29 06:38:33 --> Helper loaded: form_helper
INFO - 2020-12-29 06:38:33 --> Helper loaded: my_helper
INFO - 2020-12-29 06:38:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:38:33 --> Controller Class Initialized
INFO - 2020-12-29 06:38:37 --> Config Class Initialized
INFO - 2020-12-29 06:38:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:38:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:38:37 --> Utf8 Class Initialized
INFO - 2020-12-29 06:38:37 --> URI Class Initialized
INFO - 2020-12-29 06:38:37 --> Router Class Initialized
INFO - 2020-12-29 06:38:37 --> Output Class Initialized
INFO - 2020-12-29 06:38:37 --> Security Class Initialized
DEBUG - 2020-12-29 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:38:37 --> Input Class Initialized
INFO - 2020-12-29 06:38:37 --> Language Class Initialized
INFO - 2020-12-29 06:38:37 --> Language Class Initialized
INFO - 2020-12-29 06:38:37 --> Config Class Initialized
INFO - 2020-12-29 06:38:37 --> Loader Class Initialized
INFO - 2020-12-29 06:38:37 --> Helper loaded: url_helper
INFO - 2020-12-29 06:38:37 --> Helper loaded: file_helper
INFO - 2020-12-29 06:38:37 --> Helper loaded: form_helper
INFO - 2020-12-29 06:38:37 --> Helper loaded: my_helper
INFO - 2020-12-29 06:38:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:38:37 --> Controller Class Initialized
INFO - 2020-12-29 06:38:37 --> Final output sent to browser
DEBUG - 2020-12-29 06:38:37 --> Total execution time: 0.2860
INFO - 2020-12-29 06:38:59 --> Config Class Initialized
INFO - 2020-12-29 06:38:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:38:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:38:59 --> Utf8 Class Initialized
INFO - 2020-12-29 06:38:59 --> URI Class Initialized
INFO - 2020-12-29 06:38:59 --> Router Class Initialized
INFO - 2020-12-29 06:39:00 --> Output Class Initialized
INFO - 2020-12-29 06:39:00 --> Security Class Initialized
DEBUG - 2020-12-29 06:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:39:00 --> Input Class Initialized
INFO - 2020-12-29 06:39:00 --> Language Class Initialized
INFO - 2020-12-29 06:39:00 --> Language Class Initialized
INFO - 2020-12-29 06:39:00 --> Config Class Initialized
INFO - 2020-12-29 06:39:00 --> Loader Class Initialized
INFO - 2020-12-29 06:39:00 --> Helper loaded: url_helper
INFO - 2020-12-29 06:39:00 --> Helper loaded: file_helper
INFO - 2020-12-29 06:39:00 --> Helper loaded: form_helper
INFO - 2020-12-29 06:39:00 --> Helper loaded: my_helper
INFO - 2020-12-29 06:39:00 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:39:00 --> Controller Class Initialized
INFO - 2020-12-29 06:39:00 --> Final output sent to browser
DEBUG - 2020-12-29 06:39:00 --> Total execution time: 0.3695
INFO - 2020-12-29 06:39:00 --> Config Class Initialized
INFO - 2020-12-29 06:39:00 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:39:00 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:39:00 --> Utf8 Class Initialized
INFO - 2020-12-29 06:39:00 --> URI Class Initialized
INFO - 2020-12-29 06:39:00 --> Router Class Initialized
INFO - 2020-12-29 06:39:00 --> Output Class Initialized
INFO - 2020-12-29 06:39:00 --> Security Class Initialized
DEBUG - 2020-12-29 06:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:39:00 --> Input Class Initialized
INFO - 2020-12-29 06:39:00 --> Language Class Initialized
INFO - 2020-12-29 06:39:00 --> Language Class Initialized
INFO - 2020-12-29 06:39:00 --> Config Class Initialized
INFO - 2020-12-29 06:39:00 --> Loader Class Initialized
INFO - 2020-12-29 06:39:00 --> Helper loaded: url_helper
INFO - 2020-12-29 06:39:00 --> Helper loaded: file_helper
INFO - 2020-12-29 06:39:00 --> Helper loaded: form_helper
INFO - 2020-12-29 06:39:00 --> Helper loaded: my_helper
INFO - 2020-12-29 06:39:00 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:39:00 --> Controller Class Initialized
INFO - 2020-12-29 06:39:01 --> Config Class Initialized
INFO - 2020-12-29 06:39:01 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:39:01 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:39:01 --> Utf8 Class Initialized
INFO - 2020-12-29 06:39:01 --> URI Class Initialized
INFO - 2020-12-29 06:39:01 --> Router Class Initialized
INFO - 2020-12-29 06:39:01 --> Output Class Initialized
INFO - 2020-12-29 06:39:01 --> Security Class Initialized
DEBUG - 2020-12-29 06:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:39:01 --> Input Class Initialized
INFO - 2020-12-29 06:39:02 --> Language Class Initialized
INFO - 2020-12-29 06:39:02 --> Language Class Initialized
INFO - 2020-12-29 06:39:02 --> Config Class Initialized
INFO - 2020-12-29 06:39:02 --> Loader Class Initialized
INFO - 2020-12-29 06:39:02 --> Helper loaded: url_helper
INFO - 2020-12-29 06:39:02 --> Helper loaded: file_helper
INFO - 2020-12-29 06:39:02 --> Helper loaded: form_helper
INFO - 2020-12-29 06:39:02 --> Helper loaded: my_helper
INFO - 2020-12-29 06:39:02 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:39:02 --> Controller Class Initialized
INFO - 2020-12-29 06:39:02 --> Final output sent to browser
DEBUG - 2020-12-29 06:39:02 --> Total execution time: 0.3511
INFO - 2020-12-29 06:39:40 --> Config Class Initialized
INFO - 2020-12-29 06:39:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:39:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:39:40 --> Utf8 Class Initialized
INFO - 2020-12-29 06:39:40 --> URI Class Initialized
INFO - 2020-12-29 06:39:40 --> Router Class Initialized
INFO - 2020-12-29 06:39:40 --> Output Class Initialized
INFO - 2020-12-29 06:39:40 --> Security Class Initialized
DEBUG - 2020-12-29 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:39:40 --> Input Class Initialized
INFO - 2020-12-29 06:39:40 --> Language Class Initialized
INFO - 2020-12-29 06:39:40 --> Language Class Initialized
INFO - 2020-12-29 06:39:40 --> Config Class Initialized
INFO - 2020-12-29 06:39:40 --> Loader Class Initialized
INFO - 2020-12-29 06:39:40 --> Helper loaded: url_helper
INFO - 2020-12-29 06:39:40 --> Helper loaded: file_helper
INFO - 2020-12-29 06:39:40 --> Helper loaded: form_helper
INFO - 2020-12-29 06:39:40 --> Helper loaded: my_helper
INFO - 2020-12-29 06:39:40 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:39:40 --> Controller Class Initialized
INFO - 2020-12-29 06:39:40 --> Final output sent to browser
DEBUG - 2020-12-29 06:39:40 --> Total execution time: 0.3205
INFO - 2020-12-29 06:39:40 --> Config Class Initialized
INFO - 2020-12-29 06:39:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:39:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:39:40 --> Utf8 Class Initialized
INFO - 2020-12-29 06:39:40 --> URI Class Initialized
INFO - 2020-12-29 06:39:40 --> Router Class Initialized
INFO - 2020-12-29 06:39:40 --> Output Class Initialized
INFO - 2020-12-29 06:39:40 --> Security Class Initialized
DEBUG - 2020-12-29 06:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:39:41 --> Input Class Initialized
INFO - 2020-12-29 06:39:41 --> Language Class Initialized
INFO - 2020-12-29 06:39:41 --> Language Class Initialized
INFO - 2020-12-29 06:39:41 --> Config Class Initialized
INFO - 2020-12-29 06:39:41 --> Loader Class Initialized
INFO - 2020-12-29 06:39:41 --> Helper loaded: url_helper
INFO - 2020-12-29 06:39:41 --> Helper loaded: file_helper
INFO - 2020-12-29 06:39:41 --> Helper loaded: form_helper
INFO - 2020-12-29 06:39:41 --> Helper loaded: my_helper
INFO - 2020-12-29 06:39:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:39:41 --> Controller Class Initialized
INFO - 2020-12-29 06:39:42 --> Config Class Initialized
INFO - 2020-12-29 06:39:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:39:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:39:42 --> Utf8 Class Initialized
INFO - 2020-12-29 06:39:42 --> URI Class Initialized
INFO - 2020-12-29 06:39:42 --> Router Class Initialized
INFO - 2020-12-29 06:39:42 --> Output Class Initialized
INFO - 2020-12-29 06:39:42 --> Security Class Initialized
DEBUG - 2020-12-29 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:39:42 --> Input Class Initialized
INFO - 2020-12-29 06:39:42 --> Language Class Initialized
INFO - 2020-12-29 06:39:42 --> Language Class Initialized
INFO - 2020-12-29 06:39:42 --> Config Class Initialized
INFO - 2020-12-29 06:39:43 --> Loader Class Initialized
INFO - 2020-12-29 06:39:43 --> Helper loaded: url_helper
INFO - 2020-12-29 06:39:43 --> Helper loaded: file_helper
INFO - 2020-12-29 06:39:43 --> Helper loaded: form_helper
INFO - 2020-12-29 06:39:43 --> Helper loaded: my_helper
INFO - 2020-12-29 06:39:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:39:43 --> Controller Class Initialized
INFO - 2020-12-29 06:39:43 --> Final output sent to browser
DEBUG - 2020-12-29 06:39:43 --> Total execution time: 0.3143
INFO - 2020-12-29 06:40:04 --> Config Class Initialized
INFO - 2020-12-29 06:40:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:40:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:40:04 --> Utf8 Class Initialized
INFO - 2020-12-29 06:40:04 --> URI Class Initialized
INFO - 2020-12-29 06:40:04 --> Router Class Initialized
INFO - 2020-12-29 06:40:04 --> Output Class Initialized
INFO - 2020-12-29 06:40:04 --> Security Class Initialized
DEBUG - 2020-12-29 06:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:40:04 --> Input Class Initialized
INFO - 2020-12-29 06:40:04 --> Language Class Initialized
INFO - 2020-12-29 06:40:04 --> Language Class Initialized
INFO - 2020-12-29 06:40:04 --> Config Class Initialized
INFO - 2020-12-29 06:40:04 --> Loader Class Initialized
INFO - 2020-12-29 06:40:04 --> Helper loaded: url_helper
INFO - 2020-12-29 06:40:04 --> Helper loaded: file_helper
INFO - 2020-12-29 06:40:04 --> Helper loaded: form_helper
INFO - 2020-12-29 06:40:04 --> Helper loaded: my_helper
INFO - 2020-12-29 06:40:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:40:04 --> Controller Class Initialized
INFO - 2020-12-29 06:40:04 --> Final output sent to browser
DEBUG - 2020-12-29 06:40:04 --> Total execution time: 0.3854
INFO - 2020-12-29 06:40:04 --> Config Class Initialized
INFO - 2020-12-29 06:40:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 06:40:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 06:40:04 --> Utf8 Class Initialized
INFO - 2020-12-29 06:40:04 --> URI Class Initialized
INFO - 2020-12-29 06:40:04 --> Router Class Initialized
INFO - 2020-12-29 06:40:04 --> Output Class Initialized
INFO - 2020-12-29 06:40:04 --> Security Class Initialized
DEBUG - 2020-12-29 06:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 06:40:04 --> Input Class Initialized
INFO - 2020-12-29 06:40:04 --> Language Class Initialized
INFO - 2020-12-29 06:40:04 --> Language Class Initialized
INFO - 2020-12-29 06:40:04 --> Config Class Initialized
INFO - 2020-12-29 06:40:04 --> Loader Class Initialized
INFO - 2020-12-29 06:40:04 --> Helper loaded: url_helper
INFO - 2020-12-29 06:40:04 --> Helper loaded: file_helper
INFO - 2020-12-29 06:40:04 --> Helper loaded: form_helper
INFO - 2020-12-29 06:40:04 --> Helper loaded: my_helper
INFO - 2020-12-29 06:40:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 06:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 06:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 06:40:04 --> Controller Class Initialized
INFO - 2020-12-29 08:49:03 --> Config Class Initialized
INFO - 2020-12-29 08:49:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:49:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:49:04 --> Utf8 Class Initialized
INFO - 2020-12-29 08:49:04 --> URI Class Initialized
INFO - 2020-12-29 08:49:04 --> Router Class Initialized
INFO - 2020-12-29 08:49:04 --> Output Class Initialized
INFO - 2020-12-29 08:49:04 --> Security Class Initialized
DEBUG - 2020-12-29 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:49:04 --> Input Class Initialized
INFO - 2020-12-29 08:49:04 --> Language Class Initialized
INFO - 2020-12-29 08:49:04 --> Language Class Initialized
INFO - 2020-12-29 08:49:04 --> Config Class Initialized
INFO - 2020-12-29 08:49:04 --> Loader Class Initialized
INFO - 2020-12-29 08:49:04 --> Helper loaded: url_helper
INFO - 2020-12-29 08:49:04 --> Helper loaded: file_helper
INFO - 2020-12-29 08:49:04 --> Helper loaded: form_helper
INFO - 2020-12-29 08:49:04 --> Helper loaded: my_helper
INFO - 2020-12-29 08:49:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:49:04 --> Controller Class Initialized
INFO - 2020-12-29 08:49:04 --> Final output sent to browser
DEBUG - 2020-12-29 08:49:04 --> Total execution time: 0.3436
INFO - 2020-12-29 08:49:16 --> Config Class Initialized
INFO - 2020-12-29 08:49:16 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:49:16 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:49:16 --> Utf8 Class Initialized
INFO - 2020-12-29 08:49:16 --> URI Class Initialized
INFO - 2020-12-29 08:49:16 --> Router Class Initialized
INFO - 2020-12-29 08:49:16 --> Output Class Initialized
INFO - 2020-12-29 08:49:16 --> Security Class Initialized
DEBUG - 2020-12-29 08:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:49:16 --> Input Class Initialized
INFO - 2020-12-29 08:49:16 --> Language Class Initialized
INFO - 2020-12-29 08:49:16 --> Language Class Initialized
INFO - 2020-12-29 08:49:16 --> Config Class Initialized
INFO - 2020-12-29 08:49:16 --> Loader Class Initialized
INFO - 2020-12-29 08:49:16 --> Helper loaded: url_helper
INFO - 2020-12-29 08:49:16 --> Helper loaded: file_helper
INFO - 2020-12-29 08:49:16 --> Helper loaded: form_helper
INFO - 2020-12-29 08:49:16 --> Helper loaded: my_helper
INFO - 2020-12-29 08:49:16 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:49:16 --> Controller Class Initialized
INFO - 2020-12-29 08:49:16 --> Final output sent to browser
DEBUG - 2020-12-29 08:49:16 --> Total execution time: 0.3236
INFO - 2020-12-29 08:50:28 --> Config Class Initialized
INFO - 2020-12-29 08:50:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:50:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:50:28 --> Utf8 Class Initialized
INFO - 2020-12-29 08:50:28 --> URI Class Initialized
INFO - 2020-12-29 08:50:28 --> Router Class Initialized
INFO - 2020-12-29 08:50:28 --> Output Class Initialized
INFO - 2020-12-29 08:50:28 --> Security Class Initialized
DEBUG - 2020-12-29 08:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:50:28 --> Input Class Initialized
INFO - 2020-12-29 08:50:28 --> Language Class Initialized
INFO - 2020-12-29 08:50:28 --> Language Class Initialized
INFO - 2020-12-29 08:50:28 --> Config Class Initialized
INFO - 2020-12-29 08:50:28 --> Loader Class Initialized
INFO - 2020-12-29 08:50:28 --> Helper loaded: url_helper
INFO - 2020-12-29 08:50:28 --> Helper loaded: file_helper
INFO - 2020-12-29 08:50:28 --> Helper loaded: form_helper
INFO - 2020-12-29 08:50:28 --> Helper loaded: my_helper
INFO - 2020-12-29 08:50:28 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:50:28 --> Controller Class Initialized
INFO - 2020-12-29 08:50:28 --> Final output sent to browser
DEBUG - 2020-12-29 08:50:28 --> Total execution time: 0.3117
INFO - 2020-12-29 08:50:28 --> Config Class Initialized
INFO - 2020-12-29 08:50:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:50:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:50:28 --> Utf8 Class Initialized
INFO - 2020-12-29 08:50:28 --> URI Class Initialized
INFO - 2020-12-29 08:50:28 --> Router Class Initialized
INFO - 2020-12-29 08:50:28 --> Output Class Initialized
INFO - 2020-12-29 08:50:28 --> Security Class Initialized
DEBUG - 2020-12-29 08:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:50:28 --> Input Class Initialized
INFO - 2020-12-29 08:50:28 --> Language Class Initialized
INFO - 2020-12-29 08:50:28 --> Language Class Initialized
INFO - 2020-12-29 08:50:28 --> Config Class Initialized
INFO - 2020-12-29 08:50:28 --> Loader Class Initialized
INFO - 2020-12-29 08:50:29 --> Helper loaded: url_helper
INFO - 2020-12-29 08:50:29 --> Helper loaded: file_helper
INFO - 2020-12-29 08:50:29 --> Helper loaded: form_helper
INFO - 2020-12-29 08:50:29 --> Helper loaded: my_helper
INFO - 2020-12-29 08:50:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:50:29 --> Controller Class Initialized
INFO - 2020-12-29 08:50:38 --> Config Class Initialized
INFO - 2020-12-29 08:50:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:50:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:50:38 --> Utf8 Class Initialized
INFO - 2020-12-29 08:50:38 --> URI Class Initialized
INFO - 2020-12-29 08:50:38 --> Router Class Initialized
INFO - 2020-12-29 08:50:38 --> Output Class Initialized
INFO - 2020-12-29 08:50:38 --> Security Class Initialized
DEBUG - 2020-12-29 08:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:50:38 --> Input Class Initialized
INFO - 2020-12-29 08:50:38 --> Language Class Initialized
INFO - 2020-12-29 08:50:38 --> Language Class Initialized
INFO - 2020-12-29 08:50:38 --> Config Class Initialized
INFO - 2020-12-29 08:50:38 --> Loader Class Initialized
INFO - 2020-12-29 08:50:38 --> Helper loaded: url_helper
INFO - 2020-12-29 08:50:38 --> Helper loaded: file_helper
INFO - 2020-12-29 08:50:38 --> Helper loaded: form_helper
INFO - 2020-12-29 08:50:38 --> Helper loaded: my_helper
INFO - 2020-12-29 08:50:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:50:38 --> Controller Class Initialized
INFO - 2020-12-29 08:50:38 --> Final output sent to browser
DEBUG - 2020-12-29 08:50:38 --> Total execution time: 0.3231
INFO - 2020-12-29 08:51:15 --> Config Class Initialized
INFO - 2020-12-29 08:51:15 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:51:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:51:15 --> Utf8 Class Initialized
INFO - 2020-12-29 08:51:15 --> URI Class Initialized
INFO - 2020-12-29 08:51:15 --> Router Class Initialized
INFO - 2020-12-29 08:51:15 --> Output Class Initialized
INFO - 2020-12-29 08:51:15 --> Security Class Initialized
DEBUG - 2020-12-29 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:51:15 --> Input Class Initialized
INFO - 2020-12-29 08:51:15 --> Language Class Initialized
INFO - 2020-12-29 08:51:15 --> Language Class Initialized
INFO - 2020-12-29 08:51:15 --> Config Class Initialized
INFO - 2020-12-29 08:51:15 --> Loader Class Initialized
INFO - 2020-12-29 08:51:15 --> Helper loaded: url_helper
INFO - 2020-12-29 08:51:15 --> Helper loaded: file_helper
INFO - 2020-12-29 08:51:15 --> Helper loaded: form_helper
INFO - 2020-12-29 08:51:15 --> Helper loaded: my_helper
INFO - 2020-12-29 08:51:15 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:51:15 --> Controller Class Initialized
INFO - 2020-12-29 08:51:15 --> Final output sent to browser
DEBUG - 2020-12-29 08:51:15 --> Total execution time: 0.3521
INFO - 2020-12-29 08:51:15 --> Config Class Initialized
INFO - 2020-12-29 08:51:15 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:51:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:51:15 --> Utf8 Class Initialized
INFO - 2020-12-29 08:51:15 --> URI Class Initialized
INFO - 2020-12-29 08:51:15 --> Router Class Initialized
INFO - 2020-12-29 08:51:15 --> Output Class Initialized
INFO - 2020-12-29 08:51:15 --> Security Class Initialized
DEBUG - 2020-12-29 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:51:15 --> Input Class Initialized
INFO - 2020-12-29 08:51:15 --> Language Class Initialized
INFO - 2020-12-29 08:51:15 --> Language Class Initialized
INFO - 2020-12-29 08:51:15 --> Config Class Initialized
INFO - 2020-12-29 08:51:15 --> Loader Class Initialized
INFO - 2020-12-29 08:51:16 --> Helper loaded: url_helper
INFO - 2020-12-29 08:51:16 --> Helper loaded: file_helper
INFO - 2020-12-29 08:51:16 --> Helper loaded: form_helper
INFO - 2020-12-29 08:51:16 --> Helper loaded: my_helper
INFO - 2020-12-29 08:51:16 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:51:16 --> Controller Class Initialized
INFO - 2020-12-29 08:51:17 --> Config Class Initialized
INFO - 2020-12-29 08:51:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:51:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:51:17 --> Utf8 Class Initialized
INFO - 2020-12-29 08:51:17 --> URI Class Initialized
INFO - 2020-12-29 08:51:17 --> Router Class Initialized
INFO - 2020-12-29 08:51:17 --> Output Class Initialized
INFO - 2020-12-29 08:51:17 --> Security Class Initialized
DEBUG - 2020-12-29 08:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:51:17 --> Input Class Initialized
INFO - 2020-12-29 08:51:17 --> Language Class Initialized
INFO - 2020-12-29 08:51:17 --> Language Class Initialized
INFO - 2020-12-29 08:51:17 --> Config Class Initialized
INFO - 2020-12-29 08:51:17 --> Loader Class Initialized
INFO - 2020-12-29 08:51:17 --> Helper loaded: url_helper
INFO - 2020-12-29 08:51:17 --> Helper loaded: file_helper
INFO - 2020-12-29 08:51:17 --> Helper loaded: form_helper
INFO - 2020-12-29 08:51:17 --> Helper loaded: my_helper
INFO - 2020-12-29 08:51:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:51:17 --> Controller Class Initialized
INFO - 2020-12-29 08:51:17 --> Final output sent to browser
DEBUG - 2020-12-29 08:51:17 --> Total execution time: 0.3518
INFO - 2020-12-29 08:51:20 --> Config Class Initialized
INFO - 2020-12-29 08:51:20 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:51:20 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:51:20 --> Utf8 Class Initialized
INFO - 2020-12-29 08:51:20 --> URI Class Initialized
INFO - 2020-12-29 08:51:20 --> Router Class Initialized
INFO - 2020-12-29 08:51:20 --> Output Class Initialized
INFO - 2020-12-29 08:51:20 --> Security Class Initialized
DEBUG - 2020-12-29 08:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:51:20 --> Input Class Initialized
INFO - 2020-12-29 08:51:20 --> Language Class Initialized
INFO - 2020-12-29 08:51:20 --> Language Class Initialized
INFO - 2020-12-29 08:51:20 --> Config Class Initialized
INFO - 2020-12-29 08:51:20 --> Loader Class Initialized
INFO - 2020-12-29 08:51:20 --> Helper loaded: url_helper
INFO - 2020-12-29 08:51:20 --> Helper loaded: file_helper
INFO - 2020-12-29 08:51:20 --> Helper loaded: form_helper
INFO - 2020-12-29 08:51:20 --> Helper loaded: my_helper
INFO - 2020-12-29 08:51:20 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:51:20 --> Controller Class Initialized
INFO - 2020-12-29 08:51:20 --> Final output sent to browser
DEBUG - 2020-12-29 08:51:20 --> Total execution time: 0.3195
INFO - 2020-12-29 08:51:22 --> Config Class Initialized
INFO - 2020-12-29 08:51:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:51:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:51:22 --> Utf8 Class Initialized
INFO - 2020-12-29 08:51:22 --> URI Class Initialized
INFO - 2020-12-29 08:51:22 --> Router Class Initialized
INFO - 2020-12-29 08:51:22 --> Output Class Initialized
INFO - 2020-12-29 08:51:22 --> Security Class Initialized
DEBUG - 2020-12-29 08:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:51:22 --> Input Class Initialized
INFO - 2020-12-29 08:51:22 --> Language Class Initialized
INFO - 2020-12-29 08:51:22 --> Language Class Initialized
INFO - 2020-12-29 08:51:22 --> Config Class Initialized
INFO - 2020-12-29 08:51:22 --> Loader Class Initialized
INFO - 2020-12-29 08:51:22 --> Helper loaded: url_helper
INFO - 2020-12-29 08:51:22 --> Helper loaded: file_helper
INFO - 2020-12-29 08:51:22 --> Helper loaded: form_helper
INFO - 2020-12-29 08:51:22 --> Helper loaded: my_helper
INFO - 2020-12-29 08:51:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:51:23 --> Controller Class Initialized
INFO - 2020-12-29 08:51:23 --> Final output sent to browser
DEBUG - 2020-12-29 08:51:23 --> Total execution time: 0.3420
INFO - 2020-12-29 08:52:26 --> Config Class Initialized
INFO - 2020-12-29 08:52:26 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:52:26 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:52:26 --> Utf8 Class Initialized
INFO - 2020-12-29 08:52:26 --> URI Class Initialized
INFO - 2020-12-29 08:52:26 --> Router Class Initialized
INFO - 2020-12-29 08:52:26 --> Output Class Initialized
INFO - 2020-12-29 08:52:26 --> Security Class Initialized
DEBUG - 2020-12-29 08:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:52:26 --> Input Class Initialized
INFO - 2020-12-29 08:52:26 --> Language Class Initialized
INFO - 2020-12-29 08:52:26 --> Language Class Initialized
INFO - 2020-12-29 08:52:26 --> Config Class Initialized
INFO - 2020-12-29 08:52:26 --> Loader Class Initialized
INFO - 2020-12-29 08:52:26 --> Helper loaded: url_helper
INFO - 2020-12-29 08:52:26 --> Helper loaded: file_helper
INFO - 2020-12-29 08:52:26 --> Helper loaded: form_helper
INFO - 2020-12-29 08:52:26 --> Helper loaded: my_helper
INFO - 2020-12-29 08:52:26 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:52:26 --> Controller Class Initialized
INFO - 2020-12-29 08:52:26 --> Final output sent to browser
DEBUG - 2020-12-29 08:52:26 --> Total execution time: 0.3488
INFO - 2020-12-29 08:52:26 --> Config Class Initialized
INFO - 2020-12-29 08:52:26 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:52:26 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:52:26 --> Utf8 Class Initialized
INFO - 2020-12-29 08:52:26 --> URI Class Initialized
INFO - 2020-12-29 08:52:26 --> Router Class Initialized
INFO - 2020-12-29 08:52:26 --> Output Class Initialized
INFO - 2020-12-29 08:52:26 --> Security Class Initialized
DEBUG - 2020-12-29 08:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:52:26 --> Input Class Initialized
INFO - 2020-12-29 08:52:26 --> Language Class Initialized
INFO - 2020-12-29 08:52:27 --> Language Class Initialized
INFO - 2020-12-29 08:52:27 --> Config Class Initialized
INFO - 2020-12-29 08:52:27 --> Loader Class Initialized
INFO - 2020-12-29 08:52:27 --> Helper loaded: url_helper
INFO - 2020-12-29 08:52:27 --> Helper loaded: file_helper
INFO - 2020-12-29 08:52:27 --> Helper loaded: form_helper
INFO - 2020-12-29 08:52:27 --> Helper loaded: my_helper
INFO - 2020-12-29 08:52:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:52:27 --> Controller Class Initialized
INFO - 2020-12-29 08:52:41 --> Config Class Initialized
INFO - 2020-12-29 08:52:41 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:52:41 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:52:41 --> Utf8 Class Initialized
INFO - 2020-12-29 08:52:41 --> URI Class Initialized
INFO - 2020-12-29 08:52:41 --> Router Class Initialized
INFO - 2020-12-29 08:52:41 --> Output Class Initialized
INFO - 2020-12-29 08:52:41 --> Security Class Initialized
DEBUG - 2020-12-29 08:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:52:41 --> Input Class Initialized
INFO - 2020-12-29 08:52:41 --> Language Class Initialized
INFO - 2020-12-29 08:52:41 --> Language Class Initialized
INFO - 2020-12-29 08:52:41 --> Config Class Initialized
INFO - 2020-12-29 08:52:41 --> Loader Class Initialized
INFO - 2020-12-29 08:52:41 --> Helper loaded: url_helper
INFO - 2020-12-29 08:52:41 --> Helper loaded: file_helper
INFO - 2020-12-29 08:52:41 --> Helper loaded: form_helper
INFO - 2020-12-29 08:52:41 --> Helper loaded: my_helper
INFO - 2020-12-29 08:52:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:52:41 --> Controller Class Initialized
INFO - 2020-12-29 08:52:41 --> Final output sent to browser
DEBUG - 2020-12-29 08:52:41 --> Total execution time: 0.3129
INFO - 2020-12-29 08:53:23 --> Config Class Initialized
INFO - 2020-12-29 08:53:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:53:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:53:23 --> Utf8 Class Initialized
INFO - 2020-12-29 08:53:23 --> URI Class Initialized
INFO - 2020-12-29 08:53:23 --> Router Class Initialized
INFO - 2020-12-29 08:53:23 --> Output Class Initialized
INFO - 2020-12-29 08:53:23 --> Security Class Initialized
DEBUG - 2020-12-29 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:53:23 --> Input Class Initialized
INFO - 2020-12-29 08:53:23 --> Language Class Initialized
INFO - 2020-12-29 08:53:23 --> Language Class Initialized
INFO - 2020-12-29 08:53:23 --> Config Class Initialized
INFO - 2020-12-29 08:53:23 --> Loader Class Initialized
INFO - 2020-12-29 08:53:23 --> Helper loaded: url_helper
INFO - 2020-12-29 08:53:23 --> Helper loaded: file_helper
INFO - 2020-12-29 08:53:23 --> Helper loaded: form_helper
INFO - 2020-12-29 08:53:23 --> Helper loaded: my_helper
INFO - 2020-12-29 08:53:23 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:53:24 --> Controller Class Initialized
INFO - 2020-12-29 08:53:24 --> Final output sent to browser
DEBUG - 2020-12-29 08:53:24 --> Total execution time: 0.3398
INFO - 2020-12-29 08:53:24 --> Config Class Initialized
INFO - 2020-12-29 08:53:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:53:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:53:24 --> Utf8 Class Initialized
INFO - 2020-12-29 08:53:24 --> URI Class Initialized
INFO - 2020-12-29 08:53:24 --> Router Class Initialized
INFO - 2020-12-29 08:53:24 --> Output Class Initialized
INFO - 2020-12-29 08:53:24 --> Security Class Initialized
DEBUG - 2020-12-29 08:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:53:24 --> Input Class Initialized
INFO - 2020-12-29 08:53:24 --> Language Class Initialized
INFO - 2020-12-29 08:53:24 --> Language Class Initialized
INFO - 2020-12-29 08:53:24 --> Config Class Initialized
INFO - 2020-12-29 08:53:24 --> Loader Class Initialized
INFO - 2020-12-29 08:53:24 --> Helper loaded: url_helper
INFO - 2020-12-29 08:53:24 --> Helper loaded: file_helper
INFO - 2020-12-29 08:53:24 --> Helper loaded: form_helper
INFO - 2020-12-29 08:53:24 --> Helper loaded: my_helper
INFO - 2020-12-29 08:53:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:53:24 --> Controller Class Initialized
INFO - 2020-12-29 08:53:33 --> Config Class Initialized
INFO - 2020-12-29 08:53:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:53:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:53:33 --> Utf8 Class Initialized
INFO - 2020-12-29 08:53:33 --> URI Class Initialized
INFO - 2020-12-29 08:53:33 --> Router Class Initialized
INFO - 2020-12-29 08:53:33 --> Output Class Initialized
INFO - 2020-12-29 08:53:33 --> Security Class Initialized
DEBUG - 2020-12-29 08:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:53:33 --> Input Class Initialized
INFO - 2020-12-29 08:53:33 --> Language Class Initialized
INFO - 2020-12-29 08:53:33 --> Language Class Initialized
INFO - 2020-12-29 08:53:33 --> Config Class Initialized
INFO - 2020-12-29 08:53:33 --> Loader Class Initialized
INFO - 2020-12-29 08:53:33 --> Helper loaded: url_helper
INFO - 2020-12-29 08:53:33 --> Helper loaded: file_helper
INFO - 2020-12-29 08:53:33 --> Helper loaded: form_helper
INFO - 2020-12-29 08:53:33 --> Helper loaded: my_helper
INFO - 2020-12-29 08:53:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:53:33 --> Controller Class Initialized
INFO - 2020-12-29 08:53:33 --> Final output sent to browser
DEBUG - 2020-12-29 08:53:33 --> Total execution time: 0.3312
INFO - 2020-12-29 08:54:32 --> Config Class Initialized
INFO - 2020-12-29 08:54:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:54:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:54:32 --> Utf8 Class Initialized
INFO - 2020-12-29 08:54:32 --> URI Class Initialized
INFO - 2020-12-29 08:54:32 --> Router Class Initialized
INFO - 2020-12-29 08:54:32 --> Output Class Initialized
INFO - 2020-12-29 08:54:32 --> Security Class Initialized
DEBUG - 2020-12-29 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:54:32 --> Input Class Initialized
INFO - 2020-12-29 08:54:32 --> Language Class Initialized
INFO - 2020-12-29 08:54:32 --> Language Class Initialized
INFO - 2020-12-29 08:54:32 --> Config Class Initialized
INFO - 2020-12-29 08:54:32 --> Loader Class Initialized
INFO - 2020-12-29 08:54:32 --> Helper loaded: url_helper
INFO - 2020-12-29 08:54:32 --> Helper loaded: file_helper
INFO - 2020-12-29 08:54:32 --> Helper loaded: form_helper
INFO - 2020-12-29 08:54:32 --> Helper loaded: my_helper
INFO - 2020-12-29 08:54:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:54:32 --> Controller Class Initialized
INFO - 2020-12-29 08:54:32 --> Final output sent to browser
DEBUG - 2020-12-29 08:54:32 --> Total execution time: 0.3489
INFO - 2020-12-29 08:54:32 --> Config Class Initialized
INFO - 2020-12-29 08:54:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:54:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:54:32 --> Utf8 Class Initialized
INFO - 2020-12-29 08:54:32 --> URI Class Initialized
INFO - 2020-12-29 08:54:32 --> Router Class Initialized
INFO - 2020-12-29 08:54:32 --> Output Class Initialized
INFO - 2020-12-29 08:54:32 --> Security Class Initialized
DEBUG - 2020-12-29 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:54:32 --> Input Class Initialized
INFO - 2020-12-29 08:54:32 --> Language Class Initialized
INFO - 2020-12-29 08:54:32 --> Language Class Initialized
INFO - 2020-12-29 08:54:32 --> Config Class Initialized
INFO - 2020-12-29 08:54:32 --> Loader Class Initialized
INFO - 2020-12-29 08:54:32 --> Helper loaded: url_helper
INFO - 2020-12-29 08:54:32 --> Helper loaded: file_helper
INFO - 2020-12-29 08:54:32 --> Helper loaded: form_helper
INFO - 2020-12-29 08:54:32 --> Helper loaded: my_helper
INFO - 2020-12-29 08:54:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:54:32 --> Controller Class Initialized
INFO - 2020-12-29 08:54:35 --> Config Class Initialized
INFO - 2020-12-29 08:54:35 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:54:35 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:54:35 --> Utf8 Class Initialized
INFO - 2020-12-29 08:54:35 --> URI Class Initialized
INFO - 2020-12-29 08:54:35 --> Router Class Initialized
INFO - 2020-12-29 08:54:35 --> Output Class Initialized
INFO - 2020-12-29 08:54:35 --> Security Class Initialized
DEBUG - 2020-12-29 08:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:54:35 --> Input Class Initialized
INFO - 2020-12-29 08:54:35 --> Language Class Initialized
INFO - 2020-12-29 08:54:35 --> Language Class Initialized
INFO - 2020-12-29 08:54:35 --> Config Class Initialized
INFO - 2020-12-29 08:54:35 --> Loader Class Initialized
INFO - 2020-12-29 08:54:35 --> Helper loaded: url_helper
INFO - 2020-12-29 08:54:35 --> Helper loaded: file_helper
INFO - 2020-12-29 08:54:35 --> Helper loaded: form_helper
INFO - 2020-12-29 08:54:35 --> Helper loaded: my_helper
INFO - 2020-12-29 08:54:35 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:54:35 --> Controller Class Initialized
INFO - 2020-12-29 08:54:35 --> Final output sent to browser
DEBUG - 2020-12-29 08:54:35 --> Total execution time: 0.3546
INFO - 2020-12-29 08:54:59 --> Config Class Initialized
INFO - 2020-12-29 08:54:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:54:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:54:59 --> Utf8 Class Initialized
INFO - 2020-12-29 08:54:59 --> URI Class Initialized
INFO - 2020-12-29 08:54:59 --> Router Class Initialized
INFO - 2020-12-29 08:54:59 --> Output Class Initialized
INFO - 2020-12-29 08:54:59 --> Security Class Initialized
DEBUG - 2020-12-29 08:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:54:59 --> Input Class Initialized
INFO - 2020-12-29 08:54:59 --> Language Class Initialized
INFO - 2020-12-29 08:54:59 --> Language Class Initialized
INFO - 2020-12-29 08:54:59 --> Config Class Initialized
INFO - 2020-12-29 08:54:59 --> Loader Class Initialized
INFO - 2020-12-29 08:54:59 --> Helper loaded: url_helper
INFO - 2020-12-29 08:54:59 --> Helper loaded: file_helper
INFO - 2020-12-29 08:54:59 --> Helper loaded: form_helper
INFO - 2020-12-29 08:54:59 --> Helper loaded: my_helper
INFO - 2020-12-29 08:54:59 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:54:59 --> Controller Class Initialized
INFO - 2020-12-29 08:54:59 --> Final output sent to browser
DEBUG - 2020-12-29 08:54:59 --> Total execution time: 0.3379
INFO - 2020-12-29 08:54:59 --> Config Class Initialized
INFO - 2020-12-29 08:54:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:54:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:54:59 --> Utf8 Class Initialized
INFO - 2020-12-29 08:54:59 --> URI Class Initialized
INFO - 2020-12-29 08:54:59 --> Router Class Initialized
INFO - 2020-12-29 08:54:59 --> Output Class Initialized
INFO - 2020-12-29 08:54:59 --> Security Class Initialized
DEBUG - 2020-12-29 08:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:54:59 --> Input Class Initialized
INFO - 2020-12-29 08:54:59 --> Language Class Initialized
INFO - 2020-12-29 08:54:59 --> Language Class Initialized
INFO - 2020-12-29 08:54:59 --> Config Class Initialized
INFO - 2020-12-29 08:54:59 --> Loader Class Initialized
INFO - 2020-12-29 08:54:59 --> Helper loaded: url_helper
INFO - 2020-12-29 08:54:59 --> Helper loaded: file_helper
INFO - 2020-12-29 08:54:59 --> Helper loaded: form_helper
INFO - 2020-12-29 08:54:59 --> Helper loaded: my_helper
INFO - 2020-12-29 08:54:59 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:55:00 --> Controller Class Initialized
INFO - 2020-12-29 08:55:02 --> Config Class Initialized
INFO - 2020-12-29 08:55:02 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:55:02 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:55:02 --> Utf8 Class Initialized
INFO - 2020-12-29 08:55:02 --> URI Class Initialized
INFO - 2020-12-29 08:55:02 --> Router Class Initialized
INFO - 2020-12-29 08:55:02 --> Output Class Initialized
INFO - 2020-12-29 08:55:02 --> Security Class Initialized
DEBUG - 2020-12-29 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:55:02 --> Input Class Initialized
INFO - 2020-12-29 08:55:02 --> Language Class Initialized
INFO - 2020-12-29 08:55:02 --> Language Class Initialized
INFO - 2020-12-29 08:55:02 --> Config Class Initialized
INFO - 2020-12-29 08:55:02 --> Loader Class Initialized
INFO - 2020-12-29 08:55:02 --> Helper loaded: url_helper
INFO - 2020-12-29 08:55:02 --> Helper loaded: file_helper
INFO - 2020-12-29 08:55:03 --> Helper loaded: form_helper
INFO - 2020-12-29 08:55:03 --> Helper loaded: my_helper
INFO - 2020-12-29 08:55:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:55:03 --> Controller Class Initialized
INFO - 2020-12-29 08:55:03 --> Final output sent to browser
DEBUG - 2020-12-29 08:55:03 --> Total execution time: 0.3069
INFO - 2020-12-29 08:56:03 --> Config Class Initialized
INFO - 2020-12-29 08:56:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:56:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:56:03 --> Utf8 Class Initialized
INFO - 2020-12-29 08:56:03 --> URI Class Initialized
INFO - 2020-12-29 08:56:03 --> Router Class Initialized
INFO - 2020-12-29 08:56:03 --> Output Class Initialized
INFO - 2020-12-29 08:56:03 --> Security Class Initialized
DEBUG - 2020-12-29 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:56:03 --> Input Class Initialized
INFO - 2020-12-29 08:56:03 --> Language Class Initialized
INFO - 2020-12-29 08:56:03 --> Language Class Initialized
INFO - 2020-12-29 08:56:03 --> Config Class Initialized
INFO - 2020-12-29 08:56:03 --> Loader Class Initialized
INFO - 2020-12-29 08:56:03 --> Helper loaded: url_helper
INFO - 2020-12-29 08:56:03 --> Helper loaded: file_helper
INFO - 2020-12-29 08:56:03 --> Helper loaded: form_helper
INFO - 2020-12-29 08:56:03 --> Helper loaded: my_helper
INFO - 2020-12-29 08:56:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:56:03 --> Controller Class Initialized
INFO - 2020-12-29 08:56:03 --> Final output sent to browser
DEBUG - 2020-12-29 08:56:03 --> Total execution time: 0.3324
INFO - 2020-12-29 08:56:04 --> Config Class Initialized
INFO - 2020-12-29 08:56:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:56:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:56:04 --> Utf8 Class Initialized
INFO - 2020-12-29 08:56:04 --> URI Class Initialized
INFO - 2020-12-29 08:56:04 --> Router Class Initialized
INFO - 2020-12-29 08:56:04 --> Output Class Initialized
INFO - 2020-12-29 08:56:04 --> Security Class Initialized
DEBUG - 2020-12-29 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:56:04 --> Input Class Initialized
INFO - 2020-12-29 08:56:04 --> Language Class Initialized
INFO - 2020-12-29 08:56:04 --> Language Class Initialized
INFO - 2020-12-29 08:56:04 --> Config Class Initialized
INFO - 2020-12-29 08:56:04 --> Loader Class Initialized
INFO - 2020-12-29 08:56:04 --> Helper loaded: url_helper
INFO - 2020-12-29 08:56:04 --> Helper loaded: file_helper
INFO - 2020-12-29 08:56:04 --> Helper loaded: form_helper
INFO - 2020-12-29 08:56:04 --> Helper loaded: my_helper
INFO - 2020-12-29 08:56:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:56:04 --> Controller Class Initialized
INFO - 2020-12-29 08:56:09 --> Config Class Initialized
INFO - 2020-12-29 08:56:09 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:56:09 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:56:09 --> Utf8 Class Initialized
INFO - 2020-12-29 08:56:09 --> URI Class Initialized
INFO - 2020-12-29 08:56:09 --> Router Class Initialized
INFO - 2020-12-29 08:56:09 --> Output Class Initialized
INFO - 2020-12-29 08:56:09 --> Security Class Initialized
DEBUG - 2020-12-29 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:56:09 --> Input Class Initialized
INFO - 2020-12-29 08:56:09 --> Language Class Initialized
INFO - 2020-12-29 08:56:09 --> Language Class Initialized
INFO - 2020-12-29 08:56:09 --> Config Class Initialized
INFO - 2020-12-29 08:56:09 --> Loader Class Initialized
INFO - 2020-12-29 08:56:09 --> Helper loaded: url_helper
INFO - 2020-12-29 08:56:09 --> Helper loaded: file_helper
INFO - 2020-12-29 08:56:09 --> Helper loaded: form_helper
INFO - 2020-12-29 08:56:09 --> Helper loaded: my_helper
INFO - 2020-12-29 08:56:10 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:56:10 --> Controller Class Initialized
INFO - 2020-12-29 08:56:10 --> Final output sent to browser
DEBUG - 2020-12-29 08:56:10 --> Total execution time: 0.3327
INFO - 2020-12-29 08:56:39 --> Config Class Initialized
INFO - 2020-12-29 08:56:39 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:56:39 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:56:39 --> Utf8 Class Initialized
INFO - 2020-12-29 08:56:39 --> URI Class Initialized
INFO - 2020-12-29 08:56:39 --> Router Class Initialized
INFO - 2020-12-29 08:56:39 --> Output Class Initialized
INFO - 2020-12-29 08:56:39 --> Security Class Initialized
DEBUG - 2020-12-29 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:56:39 --> Input Class Initialized
INFO - 2020-12-29 08:56:39 --> Language Class Initialized
INFO - 2020-12-29 08:56:39 --> Language Class Initialized
INFO - 2020-12-29 08:56:39 --> Config Class Initialized
INFO - 2020-12-29 08:56:39 --> Loader Class Initialized
INFO - 2020-12-29 08:56:39 --> Helper loaded: url_helper
INFO - 2020-12-29 08:56:39 --> Helper loaded: file_helper
INFO - 2020-12-29 08:56:39 --> Helper loaded: form_helper
INFO - 2020-12-29 08:56:39 --> Helper loaded: my_helper
INFO - 2020-12-29 08:56:39 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:56:39 --> Controller Class Initialized
INFO - 2020-12-29 08:56:39 --> Final output sent to browser
DEBUG - 2020-12-29 08:56:39 --> Total execution time: 0.3558
INFO - 2020-12-29 08:56:39 --> Config Class Initialized
INFO - 2020-12-29 08:56:39 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:56:39 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:56:39 --> Utf8 Class Initialized
INFO - 2020-12-29 08:56:39 --> URI Class Initialized
INFO - 2020-12-29 08:56:39 --> Router Class Initialized
INFO - 2020-12-29 08:56:40 --> Output Class Initialized
INFO - 2020-12-29 08:56:40 --> Security Class Initialized
DEBUG - 2020-12-29 08:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:56:40 --> Input Class Initialized
INFO - 2020-12-29 08:56:40 --> Language Class Initialized
INFO - 2020-12-29 08:56:40 --> Language Class Initialized
INFO - 2020-12-29 08:56:40 --> Config Class Initialized
INFO - 2020-12-29 08:56:40 --> Loader Class Initialized
INFO - 2020-12-29 08:56:40 --> Helper loaded: url_helper
INFO - 2020-12-29 08:56:40 --> Helper loaded: file_helper
INFO - 2020-12-29 08:56:40 --> Helper loaded: form_helper
INFO - 2020-12-29 08:56:40 --> Helper loaded: my_helper
INFO - 2020-12-29 08:56:40 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:56:40 --> Controller Class Initialized
INFO - 2020-12-29 08:57:19 --> Config Class Initialized
INFO - 2020-12-29 08:57:19 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:57:19 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:57:19 --> Utf8 Class Initialized
INFO - 2020-12-29 08:57:19 --> URI Class Initialized
INFO - 2020-12-29 08:57:19 --> Router Class Initialized
INFO - 2020-12-29 08:57:19 --> Output Class Initialized
INFO - 2020-12-29 08:57:19 --> Security Class Initialized
DEBUG - 2020-12-29 08:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:57:19 --> Input Class Initialized
INFO - 2020-12-29 08:57:19 --> Language Class Initialized
INFO - 2020-12-29 08:57:19 --> Language Class Initialized
INFO - 2020-12-29 08:57:19 --> Config Class Initialized
INFO - 2020-12-29 08:57:19 --> Loader Class Initialized
INFO - 2020-12-29 08:57:19 --> Helper loaded: url_helper
INFO - 2020-12-29 08:57:19 --> Helper loaded: file_helper
INFO - 2020-12-29 08:57:19 --> Helper loaded: form_helper
INFO - 2020-12-29 08:57:19 --> Helper loaded: my_helper
INFO - 2020-12-29 08:57:19 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:57:19 --> Controller Class Initialized
INFO - 2020-12-29 08:57:19 --> Final output sent to browser
DEBUG - 2020-12-29 08:57:19 --> Total execution time: 0.3367
INFO - 2020-12-29 08:57:36 --> Config Class Initialized
INFO - 2020-12-29 08:57:36 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:57:36 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:57:36 --> Utf8 Class Initialized
INFO - 2020-12-29 08:57:36 --> URI Class Initialized
INFO - 2020-12-29 08:57:36 --> Router Class Initialized
INFO - 2020-12-29 08:57:36 --> Output Class Initialized
INFO - 2020-12-29 08:57:36 --> Security Class Initialized
DEBUG - 2020-12-29 08:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:57:37 --> Input Class Initialized
INFO - 2020-12-29 08:57:37 --> Language Class Initialized
INFO - 2020-12-29 08:57:37 --> Language Class Initialized
INFO - 2020-12-29 08:57:37 --> Config Class Initialized
INFO - 2020-12-29 08:57:37 --> Loader Class Initialized
INFO - 2020-12-29 08:57:37 --> Helper loaded: url_helper
INFO - 2020-12-29 08:57:37 --> Helper loaded: file_helper
INFO - 2020-12-29 08:57:37 --> Helper loaded: form_helper
INFO - 2020-12-29 08:57:37 --> Helper loaded: my_helper
INFO - 2020-12-29 08:57:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:57:37 --> Controller Class Initialized
DEBUG - 2020-12-29 08:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 08:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 08:57:37 --> Final output sent to browser
DEBUG - 2020-12-29 08:57:37 --> Total execution time: 0.3402
INFO - 2020-12-29 08:57:37 --> Config Class Initialized
INFO - 2020-12-29 08:57:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:57:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:57:37 --> Utf8 Class Initialized
INFO - 2020-12-29 08:57:37 --> URI Class Initialized
INFO - 2020-12-29 08:57:37 --> Router Class Initialized
INFO - 2020-12-29 08:57:37 --> Output Class Initialized
INFO - 2020-12-29 08:57:37 --> Security Class Initialized
DEBUG - 2020-12-29 08:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:57:37 --> Input Class Initialized
INFO - 2020-12-29 08:57:37 --> Language Class Initialized
INFO - 2020-12-29 08:57:37 --> Language Class Initialized
INFO - 2020-12-29 08:57:37 --> Config Class Initialized
INFO - 2020-12-29 08:57:37 --> Loader Class Initialized
INFO - 2020-12-29 08:57:37 --> Helper loaded: url_helper
INFO - 2020-12-29 08:57:37 --> Helper loaded: file_helper
INFO - 2020-12-29 08:57:37 --> Helper loaded: form_helper
INFO - 2020-12-29 08:57:37 --> Helper loaded: my_helper
INFO - 2020-12-29 08:57:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:57:37 --> Controller Class Initialized
INFO - 2020-12-29 08:57:38 --> Config Class Initialized
INFO - 2020-12-29 08:57:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:57:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:57:38 --> Utf8 Class Initialized
INFO - 2020-12-29 08:57:38 --> URI Class Initialized
INFO - 2020-12-29 08:57:38 --> Router Class Initialized
INFO - 2020-12-29 08:57:38 --> Output Class Initialized
INFO - 2020-12-29 08:57:38 --> Security Class Initialized
DEBUG - 2020-12-29 08:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:57:38 --> Input Class Initialized
INFO - 2020-12-29 08:57:38 --> Language Class Initialized
INFO - 2020-12-29 08:57:38 --> Language Class Initialized
INFO - 2020-12-29 08:57:38 --> Config Class Initialized
INFO - 2020-12-29 08:57:38 --> Loader Class Initialized
INFO - 2020-12-29 08:57:38 --> Helper loaded: url_helper
INFO - 2020-12-29 08:57:38 --> Helper loaded: file_helper
INFO - 2020-12-29 08:57:38 --> Helper loaded: form_helper
INFO - 2020-12-29 08:57:38 --> Helper loaded: my_helper
INFO - 2020-12-29 08:57:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:57:38 --> Controller Class Initialized
INFO - 2020-12-29 08:57:38 --> Final output sent to browser
DEBUG - 2020-12-29 08:57:38 --> Total execution time: 0.3219
INFO - 2020-12-29 08:58:43 --> Config Class Initialized
INFO - 2020-12-29 08:58:43 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:58:43 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:58:43 --> Utf8 Class Initialized
INFO - 2020-12-29 08:58:43 --> URI Class Initialized
INFO - 2020-12-29 08:58:43 --> Router Class Initialized
INFO - 2020-12-29 08:58:43 --> Output Class Initialized
INFO - 2020-12-29 08:58:43 --> Security Class Initialized
DEBUG - 2020-12-29 08:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:58:43 --> Input Class Initialized
INFO - 2020-12-29 08:58:43 --> Language Class Initialized
INFO - 2020-12-29 08:58:43 --> Language Class Initialized
INFO - 2020-12-29 08:58:43 --> Config Class Initialized
INFO - 2020-12-29 08:58:43 --> Loader Class Initialized
INFO - 2020-12-29 08:58:43 --> Helper loaded: url_helper
INFO - 2020-12-29 08:58:43 --> Helper loaded: file_helper
INFO - 2020-12-29 08:58:43 --> Helper loaded: form_helper
INFO - 2020-12-29 08:58:43 --> Helper loaded: my_helper
INFO - 2020-12-29 08:58:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:58:43 --> Controller Class Initialized
INFO - 2020-12-29 08:58:43 --> Final output sent to browser
DEBUG - 2020-12-29 08:58:43 --> Total execution time: 0.3348
INFO - 2020-12-29 08:58:44 --> Config Class Initialized
INFO - 2020-12-29 08:58:44 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:58:44 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:58:44 --> Utf8 Class Initialized
INFO - 2020-12-29 08:58:44 --> URI Class Initialized
INFO - 2020-12-29 08:58:44 --> Router Class Initialized
INFO - 2020-12-29 08:58:44 --> Output Class Initialized
INFO - 2020-12-29 08:58:44 --> Security Class Initialized
DEBUG - 2020-12-29 08:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:58:44 --> Input Class Initialized
INFO - 2020-12-29 08:58:44 --> Language Class Initialized
INFO - 2020-12-29 08:58:44 --> Language Class Initialized
INFO - 2020-12-29 08:58:44 --> Config Class Initialized
INFO - 2020-12-29 08:58:44 --> Loader Class Initialized
INFO - 2020-12-29 08:58:44 --> Helper loaded: url_helper
INFO - 2020-12-29 08:58:44 --> Helper loaded: file_helper
INFO - 2020-12-29 08:58:44 --> Helper loaded: form_helper
INFO - 2020-12-29 08:58:44 --> Helper loaded: my_helper
INFO - 2020-12-29 08:58:44 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:58:44 --> Controller Class Initialized
INFO - 2020-12-29 08:58:55 --> Config Class Initialized
INFO - 2020-12-29 08:58:55 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:58:55 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:58:55 --> Utf8 Class Initialized
INFO - 2020-12-29 08:58:55 --> URI Class Initialized
INFO - 2020-12-29 08:58:55 --> Router Class Initialized
INFO - 2020-12-29 08:58:55 --> Output Class Initialized
INFO - 2020-12-29 08:58:55 --> Security Class Initialized
DEBUG - 2020-12-29 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:58:55 --> Input Class Initialized
INFO - 2020-12-29 08:58:55 --> Language Class Initialized
INFO - 2020-12-29 08:58:55 --> Language Class Initialized
INFO - 2020-12-29 08:58:55 --> Config Class Initialized
INFO - 2020-12-29 08:58:55 --> Loader Class Initialized
INFO - 2020-12-29 08:58:55 --> Helper loaded: url_helper
INFO - 2020-12-29 08:58:55 --> Helper loaded: file_helper
INFO - 2020-12-29 08:58:55 --> Helper loaded: form_helper
INFO - 2020-12-29 08:58:55 --> Helper loaded: my_helper
INFO - 2020-12-29 08:58:55 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:58:55 --> Controller Class Initialized
INFO - 2020-12-29 08:58:55 --> Final output sent to browser
DEBUG - 2020-12-29 08:58:55 --> Total execution time: 0.3312
INFO - 2020-12-29 08:59:30 --> Config Class Initialized
INFO - 2020-12-29 08:59:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:59:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:59:30 --> Utf8 Class Initialized
INFO - 2020-12-29 08:59:30 --> URI Class Initialized
INFO - 2020-12-29 08:59:30 --> Router Class Initialized
INFO - 2020-12-29 08:59:30 --> Output Class Initialized
INFO - 2020-12-29 08:59:30 --> Security Class Initialized
DEBUG - 2020-12-29 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:59:30 --> Input Class Initialized
INFO - 2020-12-29 08:59:30 --> Language Class Initialized
INFO - 2020-12-29 08:59:30 --> Language Class Initialized
INFO - 2020-12-29 08:59:30 --> Config Class Initialized
INFO - 2020-12-29 08:59:30 --> Loader Class Initialized
INFO - 2020-12-29 08:59:30 --> Helper loaded: url_helper
INFO - 2020-12-29 08:59:30 --> Helper loaded: file_helper
INFO - 2020-12-29 08:59:30 --> Helper loaded: form_helper
INFO - 2020-12-29 08:59:30 --> Helper loaded: my_helper
INFO - 2020-12-29 08:59:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:59:31 --> Controller Class Initialized
INFO - 2020-12-29 08:59:31 --> Final output sent to browser
DEBUG - 2020-12-29 08:59:31 --> Total execution time: 0.3560
INFO - 2020-12-29 08:59:31 --> Config Class Initialized
INFO - 2020-12-29 08:59:31 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:59:31 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:59:31 --> Utf8 Class Initialized
INFO - 2020-12-29 08:59:31 --> URI Class Initialized
INFO - 2020-12-29 08:59:31 --> Router Class Initialized
INFO - 2020-12-29 08:59:31 --> Output Class Initialized
INFO - 2020-12-29 08:59:31 --> Security Class Initialized
DEBUG - 2020-12-29 08:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:59:31 --> Input Class Initialized
INFO - 2020-12-29 08:59:31 --> Language Class Initialized
INFO - 2020-12-29 08:59:31 --> Language Class Initialized
INFO - 2020-12-29 08:59:31 --> Config Class Initialized
INFO - 2020-12-29 08:59:31 --> Loader Class Initialized
INFO - 2020-12-29 08:59:31 --> Helper loaded: url_helper
INFO - 2020-12-29 08:59:31 --> Helper loaded: file_helper
INFO - 2020-12-29 08:59:31 --> Helper loaded: form_helper
INFO - 2020-12-29 08:59:31 --> Helper loaded: my_helper
INFO - 2020-12-29 08:59:31 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:59:31 --> Controller Class Initialized
INFO - 2020-12-29 08:59:33 --> Config Class Initialized
INFO - 2020-12-29 08:59:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 08:59:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 08:59:33 --> Utf8 Class Initialized
INFO - 2020-12-29 08:59:33 --> URI Class Initialized
INFO - 2020-12-29 08:59:33 --> Router Class Initialized
INFO - 2020-12-29 08:59:33 --> Output Class Initialized
INFO - 2020-12-29 08:59:33 --> Security Class Initialized
DEBUG - 2020-12-29 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 08:59:33 --> Input Class Initialized
INFO - 2020-12-29 08:59:33 --> Language Class Initialized
INFO - 2020-12-29 08:59:33 --> Language Class Initialized
INFO - 2020-12-29 08:59:33 --> Config Class Initialized
INFO - 2020-12-29 08:59:33 --> Loader Class Initialized
INFO - 2020-12-29 08:59:33 --> Helper loaded: url_helper
INFO - 2020-12-29 08:59:33 --> Helper loaded: file_helper
INFO - 2020-12-29 08:59:33 --> Helper loaded: form_helper
INFO - 2020-12-29 08:59:33 --> Helper loaded: my_helper
INFO - 2020-12-29 08:59:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 08:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 08:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 08:59:33 --> Controller Class Initialized
INFO - 2020-12-29 08:59:33 --> Final output sent to browser
DEBUG - 2020-12-29 08:59:33 --> Total execution time: 0.3446
INFO - 2020-12-29 09:00:29 --> Config Class Initialized
INFO - 2020-12-29 09:00:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:00:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:00:29 --> Utf8 Class Initialized
INFO - 2020-12-29 09:00:29 --> URI Class Initialized
INFO - 2020-12-29 09:00:29 --> Router Class Initialized
INFO - 2020-12-29 09:00:29 --> Output Class Initialized
INFO - 2020-12-29 09:00:29 --> Security Class Initialized
DEBUG - 2020-12-29 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:00:29 --> Input Class Initialized
INFO - 2020-12-29 09:00:29 --> Language Class Initialized
INFO - 2020-12-29 09:00:29 --> Language Class Initialized
INFO - 2020-12-29 09:00:29 --> Config Class Initialized
INFO - 2020-12-29 09:00:29 --> Loader Class Initialized
INFO - 2020-12-29 09:00:29 --> Helper loaded: url_helper
INFO - 2020-12-29 09:00:29 --> Helper loaded: file_helper
INFO - 2020-12-29 09:00:29 --> Helper loaded: form_helper
INFO - 2020-12-29 09:00:29 --> Helper loaded: my_helper
INFO - 2020-12-29 09:00:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:00:29 --> Controller Class Initialized
INFO - 2020-12-29 09:00:29 --> Final output sent to browser
DEBUG - 2020-12-29 09:00:29 --> Total execution time: 0.3750
INFO - 2020-12-29 09:00:29 --> Config Class Initialized
INFO - 2020-12-29 09:00:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:00:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:00:29 --> Utf8 Class Initialized
INFO - 2020-12-29 09:00:29 --> URI Class Initialized
INFO - 2020-12-29 09:00:29 --> Router Class Initialized
INFO - 2020-12-29 09:00:29 --> Output Class Initialized
INFO - 2020-12-29 09:00:29 --> Security Class Initialized
DEBUG - 2020-12-29 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:00:29 --> Input Class Initialized
INFO - 2020-12-29 09:00:29 --> Language Class Initialized
INFO - 2020-12-29 09:00:29 --> Language Class Initialized
INFO - 2020-12-29 09:00:29 --> Config Class Initialized
INFO - 2020-12-29 09:00:29 --> Loader Class Initialized
INFO - 2020-12-29 09:00:29 --> Helper loaded: url_helper
INFO - 2020-12-29 09:00:29 --> Helper loaded: file_helper
INFO - 2020-12-29 09:00:29 --> Helper loaded: form_helper
INFO - 2020-12-29 09:00:29 --> Helper loaded: my_helper
INFO - 2020-12-29 09:00:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:00:30 --> Controller Class Initialized
INFO - 2020-12-29 09:00:32 --> Config Class Initialized
INFO - 2020-12-29 09:00:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:00:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:00:32 --> Utf8 Class Initialized
INFO - 2020-12-29 09:00:32 --> URI Class Initialized
INFO - 2020-12-29 09:00:32 --> Router Class Initialized
INFO - 2020-12-29 09:00:32 --> Output Class Initialized
INFO - 2020-12-29 09:00:32 --> Security Class Initialized
DEBUG - 2020-12-29 09:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:00:32 --> Input Class Initialized
INFO - 2020-12-29 09:00:32 --> Language Class Initialized
INFO - 2020-12-29 09:00:32 --> Language Class Initialized
INFO - 2020-12-29 09:00:32 --> Config Class Initialized
INFO - 2020-12-29 09:00:32 --> Loader Class Initialized
INFO - 2020-12-29 09:00:32 --> Helper loaded: url_helper
INFO - 2020-12-29 09:00:32 --> Helper loaded: file_helper
INFO - 2020-12-29 09:00:32 --> Helper loaded: form_helper
INFO - 2020-12-29 09:00:32 --> Helper loaded: my_helper
INFO - 2020-12-29 09:00:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:00:32 --> Controller Class Initialized
INFO - 2020-12-29 09:00:32 --> Final output sent to browser
DEBUG - 2020-12-29 09:00:32 --> Total execution time: 0.3155
INFO - 2020-12-29 09:01:24 --> Config Class Initialized
INFO - 2020-12-29 09:01:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:01:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:01:24 --> Utf8 Class Initialized
INFO - 2020-12-29 09:01:24 --> URI Class Initialized
INFO - 2020-12-29 09:01:24 --> Router Class Initialized
INFO - 2020-12-29 09:01:24 --> Output Class Initialized
INFO - 2020-12-29 09:01:24 --> Security Class Initialized
DEBUG - 2020-12-29 09:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:01:24 --> Input Class Initialized
INFO - 2020-12-29 09:01:24 --> Language Class Initialized
INFO - 2020-12-29 09:01:24 --> Language Class Initialized
INFO - 2020-12-29 09:01:24 --> Config Class Initialized
INFO - 2020-12-29 09:01:24 --> Loader Class Initialized
INFO - 2020-12-29 09:01:24 --> Helper loaded: url_helper
INFO - 2020-12-29 09:01:24 --> Helper loaded: file_helper
INFO - 2020-12-29 09:01:24 --> Helper loaded: form_helper
INFO - 2020-12-29 09:01:24 --> Helper loaded: my_helper
INFO - 2020-12-29 09:01:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:01:24 --> Controller Class Initialized
INFO - 2020-12-29 09:01:24 --> Final output sent to browser
DEBUG - 2020-12-29 09:01:25 --> Total execution time: 0.3763
INFO - 2020-12-29 09:01:25 --> Config Class Initialized
INFO - 2020-12-29 09:01:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:01:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:01:25 --> Utf8 Class Initialized
INFO - 2020-12-29 09:01:25 --> URI Class Initialized
INFO - 2020-12-29 09:01:25 --> Router Class Initialized
INFO - 2020-12-29 09:01:25 --> Output Class Initialized
INFO - 2020-12-29 09:01:25 --> Security Class Initialized
DEBUG - 2020-12-29 09:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:01:25 --> Input Class Initialized
INFO - 2020-12-29 09:01:25 --> Language Class Initialized
INFO - 2020-12-29 09:01:25 --> Language Class Initialized
INFO - 2020-12-29 09:01:25 --> Config Class Initialized
INFO - 2020-12-29 09:01:25 --> Loader Class Initialized
INFO - 2020-12-29 09:01:25 --> Helper loaded: url_helper
INFO - 2020-12-29 09:01:25 --> Helper loaded: file_helper
INFO - 2020-12-29 09:01:25 --> Helper loaded: form_helper
INFO - 2020-12-29 09:01:25 --> Helper loaded: my_helper
INFO - 2020-12-29 09:01:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:01:25 --> Controller Class Initialized
INFO - 2020-12-29 09:02:12 --> Config Class Initialized
INFO - 2020-12-29 09:02:12 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:02:12 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:02:12 --> Utf8 Class Initialized
INFO - 2020-12-29 09:02:12 --> URI Class Initialized
INFO - 2020-12-29 09:02:12 --> Router Class Initialized
INFO - 2020-12-29 09:02:12 --> Output Class Initialized
INFO - 2020-12-29 09:02:12 --> Security Class Initialized
DEBUG - 2020-12-29 09:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:02:12 --> Input Class Initialized
INFO - 2020-12-29 09:02:12 --> Language Class Initialized
INFO - 2020-12-29 09:02:12 --> Language Class Initialized
INFO - 2020-12-29 09:02:12 --> Config Class Initialized
INFO - 2020-12-29 09:02:12 --> Loader Class Initialized
INFO - 2020-12-29 09:02:12 --> Helper loaded: url_helper
INFO - 2020-12-29 09:02:12 --> Helper loaded: file_helper
INFO - 2020-12-29 09:02:12 --> Helper loaded: form_helper
INFO - 2020-12-29 09:02:12 --> Helper loaded: my_helper
INFO - 2020-12-29 09:02:12 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:02:12 --> Controller Class Initialized
INFO - 2020-12-29 09:02:12 --> Final output sent to browser
DEBUG - 2020-12-29 09:02:12 --> Total execution time: 0.3802
INFO - 2020-12-29 09:02:36 --> Config Class Initialized
INFO - 2020-12-29 09:02:36 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:02:36 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:02:36 --> Utf8 Class Initialized
INFO - 2020-12-29 09:02:36 --> URI Class Initialized
INFO - 2020-12-29 09:02:36 --> Router Class Initialized
INFO - 2020-12-29 09:02:36 --> Output Class Initialized
INFO - 2020-12-29 09:02:36 --> Security Class Initialized
DEBUG - 2020-12-29 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:02:37 --> Input Class Initialized
INFO - 2020-12-29 09:02:37 --> Language Class Initialized
INFO - 2020-12-29 09:02:37 --> Language Class Initialized
INFO - 2020-12-29 09:02:37 --> Config Class Initialized
INFO - 2020-12-29 09:02:37 --> Loader Class Initialized
INFO - 2020-12-29 09:02:37 --> Helper loaded: url_helper
INFO - 2020-12-29 09:02:37 --> Helper loaded: file_helper
INFO - 2020-12-29 09:02:37 --> Helper loaded: form_helper
INFO - 2020-12-29 09:02:37 --> Helper loaded: my_helper
INFO - 2020-12-29 09:02:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:02:37 --> Controller Class Initialized
INFO - 2020-12-29 09:02:37 --> Final output sent to browser
DEBUG - 2020-12-29 09:02:37 --> Total execution time: 0.3503
INFO - 2020-12-29 09:02:37 --> Config Class Initialized
INFO - 2020-12-29 09:02:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:02:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:02:37 --> Utf8 Class Initialized
INFO - 2020-12-29 09:02:37 --> URI Class Initialized
INFO - 2020-12-29 09:02:37 --> Router Class Initialized
INFO - 2020-12-29 09:02:37 --> Output Class Initialized
INFO - 2020-12-29 09:02:37 --> Security Class Initialized
DEBUG - 2020-12-29 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:02:37 --> Input Class Initialized
INFO - 2020-12-29 09:02:37 --> Language Class Initialized
INFO - 2020-12-29 09:02:37 --> Language Class Initialized
INFO - 2020-12-29 09:02:37 --> Config Class Initialized
INFO - 2020-12-29 09:02:37 --> Loader Class Initialized
INFO - 2020-12-29 09:02:37 --> Helper loaded: url_helper
INFO - 2020-12-29 09:02:37 --> Helper loaded: file_helper
INFO - 2020-12-29 09:02:37 --> Helper loaded: form_helper
INFO - 2020-12-29 09:02:37 --> Helper loaded: my_helper
INFO - 2020-12-29 09:02:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:02:37 --> Controller Class Initialized
INFO - 2020-12-29 09:02:41 --> Config Class Initialized
INFO - 2020-12-29 09:02:41 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:02:41 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:02:41 --> Utf8 Class Initialized
INFO - 2020-12-29 09:02:41 --> URI Class Initialized
INFO - 2020-12-29 09:02:41 --> Router Class Initialized
INFO - 2020-12-29 09:02:41 --> Output Class Initialized
INFO - 2020-12-29 09:02:41 --> Security Class Initialized
DEBUG - 2020-12-29 09:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:02:41 --> Input Class Initialized
INFO - 2020-12-29 09:02:41 --> Language Class Initialized
INFO - 2020-12-29 09:02:41 --> Language Class Initialized
INFO - 2020-12-29 09:02:41 --> Config Class Initialized
INFO - 2020-12-29 09:02:41 --> Loader Class Initialized
INFO - 2020-12-29 09:02:41 --> Helper loaded: url_helper
INFO - 2020-12-29 09:02:41 --> Helper loaded: file_helper
INFO - 2020-12-29 09:02:41 --> Helper loaded: form_helper
INFO - 2020-12-29 09:02:41 --> Helper loaded: my_helper
INFO - 2020-12-29 09:02:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:02:41 --> Controller Class Initialized
INFO - 2020-12-29 09:02:41 --> Final output sent to browser
DEBUG - 2020-12-29 09:02:41 --> Total execution time: 0.3092
INFO - 2020-12-29 09:02:49 --> Config Class Initialized
INFO - 2020-12-29 09:02:49 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:02:49 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:02:49 --> Utf8 Class Initialized
INFO - 2020-12-29 09:02:49 --> URI Class Initialized
INFO - 2020-12-29 09:02:49 --> Router Class Initialized
INFO - 2020-12-29 09:02:49 --> Output Class Initialized
INFO - 2020-12-29 09:02:49 --> Security Class Initialized
DEBUG - 2020-12-29 09:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:02:49 --> Input Class Initialized
INFO - 2020-12-29 09:02:49 --> Language Class Initialized
INFO - 2020-12-29 09:02:49 --> Language Class Initialized
INFO - 2020-12-29 09:02:49 --> Config Class Initialized
INFO - 2020-12-29 09:02:49 --> Loader Class Initialized
INFO - 2020-12-29 09:02:49 --> Helper loaded: url_helper
INFO - 2020-12-29 09:02:49 --> Helper loaded: file_helper
INFO - 2020-12-29 09:02:49 --> Helper loaded: form_helper
INFO - 2020-12-29 09:02:49 --> Helper loaded: my_helper
INFO - 2020-12-29 09:02:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:02:50 --> Controller Class Initialized
INFO - 2020-12-29 09:02:50 --> Final output sent to browser
DEBUG - 2020-12-29 09:02:50 --> Total execution time: 0.3517
INFO - 2020-12-29 09:03:17 --> Config Class Initialized
INFO - 2020-12-29 09:03:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:03:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:03:17 --> Utf8 Class Initialized
INFO - 2020-12-29 09:03:17 --> URI Class Initialized
INFO - 2020-12-29 09:03:17 --> Router Class Initialized
INFO - 2020-12-29 09:03:17 --> Output Class Initialized
INFO - 2020-12-29 09:03:17 --> Security Class Initialized
DEBUG - 2020-12-29 09:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:03:17 --> Input Class Initialized
INFO - 2020-12-29 09:03:17 --> Language Class Initialized
INFO - 2020-12-29 09:03:17 --> Language Class Initialized
INFO - 2020-12-29 09:03:17 --> Config Class Initialized
INFO - 2020-12-29 09:03:17 --> Loader Class Initialized
INFO - 2020-12-29 09:03:17 --> Helper loaded: url_helper
INFO - 2020-12-29 09:03:17 --> Helper loaded: file_helper
INFO - 2020-12-29 09:03:17 --> Helper loaded: form_helper
INFO - 2020-12-29 09:03:17 --> Helper loaded: my_helper
INFO - 2020-12-29 09:03:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:03:17 --> Controller Class Initialized
INFO - 2020-12-29 09:03:17 --> Final output sent to browser
DEBUG - 2020-12-29 09:03:17 --> Total execution time: 0.4553
INFO - 2020-12-29 09:03:17 --> Config Class Initialized
INFO - 2020-12-29 09:03:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:03:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:03:17 --> Utf8 Class Initialized
INFO - 2020-12-29 09:03:17 --> URI Class Initialized
INFO - 2020-12-29 09:03:17 --> Router Class Initialized
INFO - 2020-12-29 09:03:17 --> Output Class Initialized
INFO - 2020-12-29 09:03:17 --> Security Class Initialized
DEBUG - 2020-12-29 09:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:03:17 --> Input Class Initialized
INFO - 2020-12-29 09:03:17 --> Language Class Initialized
INFO - 2020-12-29 09:03:17 --> Language Class Initialized
INFO - 2020-12-29 09:03:17 --> Config Class Initialized
INFO - 2020-12-29 09:03:17 --> Loader Class Initialized
INFO - 2020-12-29 09:03:17 --> Helper loaded: url_helper
INFO - 2020-12-29 09:03:18 --> Helper loaded: file_helper
INFO - 2020-12-29 09:03:18 --> Helper loaded: form_helper
INFO - 2020-12-29 09:03:18 --> Helper loaded: my_helper
INFO - 2020-12-29 09:03:18 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:03:18 --> Controller Class Initialized
INFO - 2020-12-29 09:03:33 --> Config Class Initialized
INFO - 2020-12-29 09:03:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:03:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:03:33 --> Utf8 Class Initialized
INFO - 2020-12-29 09:03:33 --> URI Class Initialized
INFO - 2020-12-29 09:03:33 --> Router Class Initialized
INFO - 2020-12-29 09:03:33 --> Output Class Initialized
INFO - 2020-12-29 09:03:33 --> Security Class Initialized
DEBUG - 2020-12-29 09:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:03:33 --> Input Class Initialized
INFO - 2020-12-29 09:03:33 --> Language Class Initialized
INFO - 2020-12-29 09:03:33 --> Language Class Initialized
INFO - 2020-12-29 09:03:33 --> Config Class Initialized
INFO - 2020-12-29 09:03:33 --> Loader Class Initialized
INFO - 2020-12-29 09:03:33 --> Helper loaded: url_helper
INFO - 2020-12-29 09:03:33 --> Helper loaded: file_helper
INFO - 2020-12-29 09:03:34 --> Helper loaded: form_helper
INFO - 2020-12-29 09:03:34 --> Helper loaded: my_helper
INFO - 2020-12-29 09:03:34 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:03:34 --> Controller Class Initialized
INFO - 2020-12-29 09:03:34 --> Final output sent to browser
DEBUG - 2020-12-29 09:03:34 --> Total execution time: 0.3418
INFO - 2020-12-29 09:04:06 --> Config Class Initialized
INFO - 2020-12-29 09:04:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:04:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:04:06 --> Utf8 Class Initialized
INFO - 2020-12-29 09:04:06 --> URI Class Initialized
INFO - 2020-12-29 09:04:06 --> Router Class Initialized
INFO - 2020-12-29 09:04:06 --> Output Class Initialized
INFO - 2020-12-29 09:04:06 --> Security Class Initialized
DEBUG - 2020-12-29 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:04:06 --> Input Class Initialized
INFO - 2020-12-29 09:04:06 --> Language Class Initialized
INFO - 2020-12-29 09:04:06 --> Language Class Initialized
INFO - 2020-12-29 09:04:06 --> Config Class Initialized
INFO - 2020-12-29 09:04:06 --> Loader Class Initialized
INFO - 2020-12-29 09:04:06 --> Helper loaded: url_helper
INFO - 2020-12-29 09:04:06 --> Helper loaded: file_helper
INFO - 2020-12-29 09:04:06 --> Helper loaded: form_helper
INFO - 2020-12-29 09:04:06 --> Helper loaded: my_helper
INFO - 2020-12-29 09:04:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:04:06 --> Controller Class Initialized
INFO - 2020-12-29 09:04:06 --> Final output sent to browser
DEBUG - 2020-12-29 09:04:06 --> Total execution time: 0.3574
INFO - 2020-12-29 09:04:06 --> Config Class Initialized
INFO - 2020-12-29 09:04:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:04:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:04:06 --> Utf8 Class Initialized
INFO - 2020-12-29 09:04:06 --> URI Class Initialized
INFO - 2020-12-29 09:04:06 --> Router Class Initialized
INFO - 2020-12-29 09:04:06 --> Output Class Initialized
INFO - 2020-12-29 09:04:06 --> Security Class Initialized
DEBUG - 2020-12-29 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:04:06 --> Input Class Initialized
INFO - 2020-12-29 09:04:06 --> Language Class Initialized
INFO - 2020-12-29 09:04:06 --> Language Class Initialized
INFO - 2020-12-29 09:04:06 --> Config Class Initialized
INFO - 2020-12-29 09:04:07 --> Loader Class Initialized
INFO - 2020-12-29 09:04:07 --> Helper loaded: url_helper
INFO - 2020-12-29 09:04:07 --> Helper loaded: file_helper
INFO - 2020-12-29 09:04:07 --> Helper loaded: form_helper
INFO - 2020-12-29 09:04:07 --> Helper loaded: my_helper
INFO - 2020-12-29 09:04:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:04:07 --> Controller Class Initialized
INFO - 2020-12-29 09:04:08 --> Config Class Initialized
INFO - 2020-12-29 09:04:08 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:04:08 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:04:08 --> Utf8 Class Initialized
INFO - 2020-12-29 09:04:09 --> URI Class Initialized
INFO - 2020-12-29 09:04:09 --> Router Class Initialized
INFO - 2020-12-29 09:04:09 --> Output Class Initialized
INFO - 2020-12-29 09:04:09 --> Security Class Initialized
DEBUG - 2020-12-29 09:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:04:09 --> Input Class Initialized
INFO - 2020-12-29 09:04:09 --> Language Class Initialized
INFO - 2020-12-29 09:04:09 --> Language Class Initialized
INFO - 2020-12-29 09:04:09 --> Config Class Initialized
INFO - 2020-12-29 09:04:09 --> Loader Class Initialized
INFO - 2020-12-29 09:04:09 --> Helper loaded: url_helper
INFO - 2020-12-29 09:04:09 --> Helper loaded: file_helper
INFO - 2020-12-29 09:04:09 --> Helper loaded: form_helper
INFO - 2020-12-29 09:04:09 --> Helper loaded: my_helper
INFO - 2020-12-29 09:04:09 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:04:09 --> Controller Class Initialized
INFO - 2020-12-29 09:04:09 --> Final output sent to browser
DEBUG - 2020-12-29 09:04:09 --> Total execution time: 0.3439
INFO - 2020-12-29 09:04:28 --> Config Class Initialized
INFO - 2020-12-29 09:04:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:04:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:04:28 --> Utf8 Class Initialized
INFO - 2020-12-29 09:04:28 --> URI Class Initialized
INFO - 2020-12-29 09:04:28 --> Router Class Initialized
INFO - 2020-12-29 09:04:28 --> Output Class Initialized
INFO - 2020-12-29 09:04:28 --> Security Class Initialized
DEBUG - 2020-12-29 09:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:04:29 --> Input Class Initialized
INFO - 2020-12-29 09:04:29 --> Language Class Initialized
INFO - 2020-12-29 09:04:29 --> Language Class Initialized
INFO - 2020-12-29 09:04:29 --> Config Class Initialized
INFO - 2020-12-29 09:04:29 --> Loader Class Initialized
INFO - 2020-12-29 09:04:29 --> Helper loaded: url_helper
INFO - 2020-12-29 09:04:29 --> Helper loaded: file_helper
INFO - 2020-12-29 09:04:29 --> Helper loaded: form_helper
INFO - 2020-12-29 09:04:29 --> Helper loaded: my_helper
INFO - 2020-12-29 09:04:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:04:29 --> Controller Class Initialized
INFO - 2020-12-29 09:04:29 --> Final output sent to browser
DEBUG - 2020-12-29 09:04:29 --> Total execution time: 0.3422
INFO - 2020-12-29 09:04:29 --> Config Class Initialized
INFO - 2020-12-29 09:04:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:04:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:04:29 --> Utf8 Class Initialized
INFO - 2020-12-29 09:04:29 --> URI Class Initialized
INFO - 2020-12-29 09:04:29 --> Router Class Initialized
INFO - 2020-12-29 09:04:29 --> Output Class Initialized
INFO - 2020-12-29 09:04:29 --> Security Class Initialized
DEBUG - 2020-12-29 09:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:04:29 --> Input Class Initialized
INFO - 2020-12-29 09:04:29 --> Language Class Initialized
INFO - 2020-12-29 09:04:29 --> Language Class Initialized
INFO - 2020-12-29 09:04:29 --> Config Class Initialized
INFO - 2020-12-29 09:04:29 --> Loader Class Initialized
INFO - 2020-12-29 09:04:29 --> Helper loaded: url_helper
INFO - 2020-12-29 09:04:29 --> Helper loaded: file_helper
INFO - 2020-12-29 09:04:29 --> Helper loaded: form_helper
INFO - 2020-12-29 09:04:29 --> Helper loaded: my_helper
INFO - 2020-12-29 09:04:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:04:29 --> Controller Class Initialized
INFO - 2020-12-29 09:04:32 --> Config Class Initialized
INFO - 2020-12-29 09:04:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:04:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:04:32 --> Utf8 Class Initialized
INFO - 2020-12-29 09:04:32 --> URI Class Initialized
INFO - 2020-12-29 09:04:32 --> Router Class Initialized
INFO - 2020-12-29 09:04:32 --> Output Class Initialized
INFO - 2020-12-29 09:04:32 --> Security Class Initialized
DEBUG - 2020-12-29 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:04:32 --> Input Class Initialized
INFO - 2020-12-29 09:04:32 --> Language Class Initialized
INFO - 2020-12-29 09:04:32 --> Language Class Initialized
INFO - 2020-12-29 09:04:32 --> Config Class Initialized
INFO - 2020-12-29 09:04:32 --> Loader Class Initialized
INFO - 2020-12-29 09:04:32 --> Helper loaded: url_helper
INFO - 2020-12-29 09:04:32 --> Helper loaded: file_helper
INFO - 2020-12-29 09:04:32 --> Helper loaded: form_helper
INFO - 2020-12-29 09:04:32 --> Helper loaded: my_helper
INFO - 2020-12-29 09:04:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:04:32 --> Controller Class Initialized
INFO - 2020-12-29 09:04:32 --> Final output sent to browser
DEBUG - 2020-12-29 09:04:32 --> Total execution time: 0.3455
INFO - 2020-12-29 09:05:16 --> Config Class Initialized
INFO - 2020-12-29 09:05:16 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:05:16 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:05:16 --> Utf8 Class Initialized
INFO - 2020-12-29 09:05:16 --> URI Class Initialized
INFO - 2020-12-29 09:05:16 --> Router Class Initialized
INFO - 2020-12-29 09:05:16 --> Output Class Initialized
INFO - 2020-12-29 09:05:16 --> Security Class Initialized
DEBUG - 2020-12-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:05:16 --> Input Class Initialized
INFO - 2020-12-29 09:05:16 --> Language Class Initialized
INFO - 2020-12-29 09:05:16 --> Language Class Initialized
INFO - 2020-12-29 09:05:16 --> Config Class Initialized
INFO - 2020-12-29 09:05:16 --> Loader Class Initialized
INFO - 2020-12-29 09:05:16 --> Helper loaded: url_helper
INFO - 2020-12-29 09:05:16 --> Helper loaded: file_helper
INFO - 2020-12-29 09:05:16 --> Helper loaded: form_helper
INFO - 2020-12-29 09:05:16 --> Helper loaded: my_helper
INFO - 2020-12-29 09:05:16 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:05:16 --> Controller Class Initialized
INFO - 2020-12-29 09:05:16 --> Final output sent to browser
DEBUG - 2020-12-29 09:05:16 --> Total execution time: 0.3865
INFO - 2020-12-29 09:05:16 --> Config Class Initialized
INFO - 2020-12-29 09:05:16 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:05:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:05:17 --> Utf8 Class Initialized
INFO - 2020-12-29 09:05:17 --> URI Class Initialized
INFO - 2020-12-29 09:05:17 --> Router Class Initialized
INFO - 2020-12-29 09:05:17 --> Output Class Initialized
INFO - 2020-12-29 09:05:17 --> Security Class Initialized
DEBUG - 2020-12-29 09:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:05:17 --> Input Class Initialized
INFO - 2020-12-29 09:05:17 --> Language Class Initialized
INFO - 2020-12-29 09:05:17 --> Language Class Initialized
INFO - 2020-12-29 09:05:17 --> Config Class Initialized
INFO - 2020-12-29 09:05:17 --> Loader Class Initialized
INFO - 2020-12-29 09:05:17 --> Helper loaded: url_helper
INFO - 2020-12-29 09:05:17 --> Helper loaded: file_helper
INFO - 2020-12-29 09:05:17 --> Helper loaded: form_helper
INFO - 2020-12-29 09:05:17 --> Helper loaded: my_helper
INFO - 2020-12-29 09:05:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:05:17 --> Controller Class Initialized
INFO - 2020-12-29 09:05:20 --> Config Class Initialized
INFO - 2020-12-29 09:05:20 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:05:20 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:05:20 --> Utf8 Class Initialized
INFO - 2020-12-29 09:05:20 --> URI Class Initialized
INFO - 2020-12-29 09:05:20 --> Router Class Initialized
INFO - 2020-12-29 09:05:20 --> Output Class Initialized
INFO - 2020-12-29 09:05:20 --> Security Class Initialized
DEBUG - 2020-12-29 09:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:05:20 --> Input Class Initialized
INFO - 2020-12-29 09:05:20 --> Language Class Initialized
INFO - 2020-12-29 09:05:20 --> Language Class Initialized
INFO - 2020-12-29 09:05:20 --> Config Class Initialized
INFO - 2020-12-29 09:05:20 --> Loader Class Initialized
INFO - 2020-12-29 09:05:20 --> Helper loaded: url_helper
INFO - 2020-12-29 09:05:20 --> Helper loaded: file_helper
INFO - 2020-12-29 09:05:20 --> Helper loaded: form_helper
INFO - 2020-12-29 09:05:20 --> Helper loaded: my_helper
INFO - 2020-12-29 09:05:20 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:05:20 --> Controller Class Initialized
INFO - 2020-12-29 09:05:20 --> Final output sent to browser
DEBUG - 2020-12-29 09:05:20 --> Total execution time: 0.3375
INFO - 2020-12-29 09:06:11 --> Config Class Initialized
INFO - 2020-12-29 09:06:11 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:06:11 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:06:11 --> Utf8 Class Initialized
INFO - 2020-12-29 09:06:11 --> URI Class Initialized
INFO - 2020-12-29 09:06:11 --> Router Class Initialized
INFO - 2020-12-29 09:06:11 --> Output Class Initialized
INFO - 2020-12-29 09:06:11 --> Security Class Initialized
DEBUG - 2020-12-29 09:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:06:11 --> Input Class Initialized
INFO - 2020-12-29 09:06:11 --> Language Class Initialized
INFO - 2020-12-29 09:06:11 --> Language Class Initialized
INFO - 2020-12-29 09:06:11 --> Config Class Initialized
INFO - 2020-12-29 09:06:11 --> Loader Class Initialized
INFO - 2020-12-29 09:06:11 --> Helper loaded: url_helper
INFO - 2020-12-29 09:06:11 --> Helper loaded: file_helper
INFO - 2020-12-29 09:06:11 --> Helper loaded: form_helper
INFO - 2020-12-29 09:06:11 --> Helper loaded: my_helper
INFO - 2020-12-29 09:06:11 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:06:11 --> Controller Class Initialized
INFO - 2020-12-29 09:06:11 --> Final output sent to browser
DEBUG - 2020-12-29 09:06:11 --> Total execution time: 0.3511
INFO - 2020-12-29 09:06:11 --> Config Class Initialized
INFO - 2020-12-29 09:06:11 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:06:11 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:06:11 --> Utf8 Class Initialized
INFO - 2020-12-29 09:06:11 --> URI Class Initialized
INFO - 2020-12-29 09:06:11 --> Router Class Initialized
INFO - 2020-12-29 09:06:11 --> Output Class Initialized
INFO - 2020-12-29 09:06:11 --> Security Class Initialized
DEBUG - 2020-12-29 09:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:06:11 --> Input Class Initialized
INFO - 2020-12-29 09:06:11 --> Language Class Initialized
INFO - 2020-12-29 09:06:11 --> Language Class Initialized
INFO - 2020-12-29 09:06:11 --> Config Class Initialized
INFO - 2020-12-29 09:06:11 --> Loader Class Initialized
INFO - 2020-12-29 09:06:11 --> Helper loaded: url_helper
INFO - 2020-12-29 09:06:11 --> Helper loaded: file_helper
INFO - 2020-12-29 09:06:11 --> Helper loaded: form_helper
INFO - 2020-12-29 09:06:11 --> Helper loaded: my_helper
INFO - 2020-12-29 09:06:11 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:06:11 --> Controller Class Initialized
INFO - 2020-12-29 09:06:14 --> Config Class Initialized
INFO - 2020-12-29 09:06:14 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:06:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:06:15 --> Utf8 Class Initialized
INFO - 2020-12-29 09:06:15 --> URI Class Initialized
INFO - 2020-12-29 09:06:15 --> Router Class Initialized
INFO - 2020-12-29 09:06:15 --> Output Class Initialized
INFO - 2020-12-29 09:06:15 --> Security Class Initialized
DEBUG - 2020-12-29 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:06:15 --> Input Class Initialized
INFO - 2020-12-29 09:06:15 --> Language Class Initialized
INFO - 2020-12-29 09:06:15 --> Language Class Initialized
INFO - 2020-12-29 09:06:15 --> Config Class Initialized
INFO - 2020-12-29 09:06:15 --> Loader Class Initialized
INFO - 2020-12-29 09:06:15 --> Helper loaded: url_helper
INFO - 2020-12-29 09:06:15 --> Helper loaded: file_helper
INFO - 2020-12-29 09:06:15 --> Helper loaded: form_helper
INFO - 2020-12-29 09:06:15 --> Helper loaded: my_helper
INFO - 2020-12-29 09:06:15 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:06:15 --> Controller Class Initialized
INFO - 2020-12-29 09:06:15 --> Final output sent to browser
DEBUG - 2020-12-29 09:06:15 --> Total execution time: 0.3487
INFO - 2020-12-29 09:06:50 --> Config Class Initialized
INFO - 2020-12-29 09:06:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:06:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:06:50 --> Utf8 Class Initialized
INFO - 2020-12-29 09:06:50 --> URI Class Initialized
INFO - 2020-12-29 09:06:50 --> Router Class Initialized
INFO - 2020-12-29 09:06:50 --> Output Class Initialized
INFO - 2020-12-29 09:06:50 --> Security Class Initialized
DEBUG - 2020-12-29 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:06:50 --> Input Class Initialized
INFO - 2020-12-29 09:06:50 --> Language Class Initialized
INFO - 2020-12-29 09:06:50 --> Language Class Initialized
INFO - 2020-12-29 09:06:50 --> Config Class Initialized
INFO - 2020-12-29 09:06:50 --> Loader Class Initialized
INFO - 2020-12-29 09:06:50 --> Helper loaded: url_helper
INFO - 2020-12-29 09:06:50 --> Helper loaded: file_helper
INFO - 2020-12-29 09:06:50 --> Helper loaded: form_helper
INFO - 2020-12-29 09:06:50 --> Helper loaded: my_helper
INFO - 2020-12-29 09:06:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:06:50 --> Controller Class Initialized
INFO - 2020-12-29 09:06:50 --> Final output sent to browser
DEBUG - 2020-12-29 09:06:50 --> Total execution time: 0.3386
INFO - 2020-12-29 09:06:50 --> Config Class Initialized
INFO - 2020-12-29 09:06:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:06:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:06:50 --> Utf8 Class Initialized
INFO - 2020-12-29 09:06:50 --> URI Class Initialized
INFO - 2020-12-29 09:06:50 --> Router Class Initialized
INFO - 2020-12-29 09:06:50 --> Output Class Initialized
INFO - 2020-12-29 09:06:50 --> Security Class Initialized
DEBUG - 2020-12-29 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:06:50 --> Input Class Initialized
INFO - 2020-12-29 09:06:50 --> Language Class Initialized
INFO - 2020-12-29 09:06:50 --> Language Class Initialized
INFO - 2020-12-29 09:06:50 --> Config Class Initialized
INFO - 2020-12-29 09:06:50 --> Loader Class Initialized
INFO - 2020-12-29 09:06:50 --> Helper loaded: url_helper
INFO - 2020-12-29 09:06:50 --> Helper loaded: file_helper
INFO - 2020-12-29 09:06:50 --> Helper loaded: form_helper
INFO - 2020-12-29 09:06:50 --> Helper loaded: my_helper
INFO - 2020-12-29 09:06:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:06:50 --> Controller Class Initialized
INFO - 2020-12-29 09:06:52 --> Config Class Initialized
INFO - 2020-12-29 09:06:52 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:06:52 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:06:52 --> Utf8 Class Initialized
INFO - 2020-12-29 09:06:52 --> URI Class Initialized
INFO - 2020-12-29 09:06:53 --> Router Class Initialized
INFO - 2020-12-29 09:06:53 --> Output Class Initialized
INFO - 2020-12-29 09:06:53 --> Security Class Initialized
DEBUG - 2020-12-29 09:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:06:53 --> Input Class Initialized
INFO - 2020-12-29 09:06:53 --> Language Class Initialized
INFO - 2020-12-29 09:06:53 --> Language Class Initialized
INFO - 2020-12-29 09:06:53 --> Config Class Initialized
INFO - 2020-12-29 09:06:53 --> Loader Class Initialized
INFO - 2020-12-29 09:06:53 --> Helper loaded: url_helper
INFO - 2020-12-29 09:06:53 --> Helper loaded: file_helper
INFO - 2020-12-29 09:06:53 --> Helper loaded: form_helper
INFO - 2020-12-29 09:06:53 --> Helper loaded: my_helper
INFO - 2020-12-29 09:06:53 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:06:53 --> Controller Class Initialized
INFO - 2020-12-29 09:06:53 --> Final output sent to browser
DEBUG - 2020-12-29 09:06:53 --> Total execution time: 0.3630
INFO - 2020-12-29 09:07:23 --> Config Class Initialized
INFO - 2020-12-29 09:07:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:07:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:07:23 --> Utf8 Class Initialized
INFO - 2020-12-29 09:07:23 --> URI Class Initialized
INFO - 2020-12-29 09:07:23 --> Router Class Initialized
INFO - 2020-12-29 09:07:23 --> Output Class Initialized
INFO - 2020-12-29 09:07:23 --> Security Class Initialized
DEBUG - 2020-12-29 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:07:23 --> Input Class Initialized
INFO - 2020-12-29 09:07:23 --> Language Class Initialized
INFO - 2020-12-29 09:07:23 --> Language Class Initialized
INFO - 2020-12-29 09:07:23 --> Config Class Initialized
INFO - 2020-12-29 09:07:23 --> Loader Class Initialized
INFO - 2020-12-29 09:07:23 --> Helper loaded: url_helper
INFO - 2020-12-29 09:07:23 --> Helper loaded: file_helper
INFO - 2020-12-29 09:07:23 --> Helper loaded: form_helper
INFO - 2020-12-29 09:07:23 --> Helper loaded: my_helper
INFO - 2020-12-29 09:07:23 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:07:23 --> Controller Class Initialized
INFO - 2020-12-29 09:07:23 --> Final output sent to browser
DEBUG - 2020-12-29 09:07:23 --> Total execution time: 0.3828
INFO - 2020-12-29 09:07:23 --> Config Class Initialized
INFO - 2020-12-29 09:07:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:07:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:07:23 --> Utf8 Class Initialized
INFO - 2020-12-29 09:07:23 --> URI Class Initialized
INFO - 2020-12-29 09:07:23 --> Router Class Initialized
INFO - 2020-12-29 09:07:24 --> Output Class Initialized
INFO - 2020-12-29 09:07:24 --> Security Class Initialized
DEBUG - 2020-12-29 09:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:07:24 --> Input Class Initialized
INFO - 2020-12-29 09:07:24 --> Language Class Initialized
INFO - 2020-12-29 09:07:24 --> Language Class Initialized
INFO - 2020-12-29 09:07:24 --> Config Class Initialized
INFO - 2020-12-29 09:07:24 --> Loader Class Initialized
INFO - 2020-12-29 09:07:24 --> Helper loaded: url_helper
INFO - 2020-12-29 09:07:24 --> Helper loaded: file_helper
INFO - 2020-12-29 09:07:24 --> Helper loaded: form_helper
INFO - 2020-12-29 09:07:24 --> Helper loaded: my_helper
INFO - 2020-12-29 09:07:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:07:24 --> Controller Class Initialized
INFO - 2020-12-29 09:07:25 --> Config Class Initialized
INFO - 2020-12-29 09:07:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:07:26 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:07:26 --> Utf8 Class Initialized
INFO - 2020-12-29 09:07:26 --> URI Class Initialized
INFO - 2020-12-29 09:07:26 --> Router Class Initialized
INFO - 2020-12-29 09:07:26 --> Output Class Initialized
INFO - 2020-12-29 09:07:26 --> Security Class Initialized
DEBUG - 2020-12-29 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:07:26 --> Input Class Initialized
INFO - 2020-12-29 09:07:26 --> Language Class Initialized
INFO - 2020-12-29 09:07:26 --> Language Class Initialized
INFO - 2020-12-29 09:07:26 --> Config Class Initialized
INFO - 2020-12-29 09:07:26 --> Loader Class Initialized
INFO - 2020-12-29 09:07:26 --> Helper loaded: url_helper
INFO - 2020-12-29 09:07:26 --> Helper loaded: file_helper
INFO - 2020-12-29 09:07:26 --> Helper loaded: form_helper
INFO - 2020-12-29 09:07:26 --> Helper loaded: my_helper
INFO - 2020-12-29 09:07:26 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:07:26 --> Controller Class Initialized
INFO - 2020-12-29 09:07:26 --> Final output sent to browser
DEBUG - 2020-12-29 09:07:26 --> Total execution time: 0.3113
INFO - 2020-12-29 09:07:53 --> Config Class Initialized
INFO - 2020-12-29 09:07:53 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:07:53 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:07:53 --> Utf8 Class Initialized
INFO - 2020-12-29 09:07:53 --> URI Class Initialized
INFO - 2020-12-29 09:07:53 --> Router Class Initialized
INFO - 2020-12-29 09:07:53 --> Output Class Initialized
INFO - 2020-12-29 09:07:53 --> Security Class Initialized
DEBUG - 2020-12-29 09:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:07:53 --> Input Class Initialized
INFO - 2020-12-29 09:07:53 --> Language Class Initialized
INFO - 2020-12-29 09:07:53 --> Language Class Initialized
INFO - 2020-12-29 09:07:54 --> Config Class Initialized
INFO - 2020-12-29 09:07:54 --> Loader Class Initialized
INFO - 2020-12-29 09:07:54 --> Helper loaded: url_helper
INFO - 2020-12-29 09:07:54 --> Helper loaded: file_helper
INFO - 2020-12-29 09:07:54 --> Helper loaded: form_helper
INFO - 2020-12-29 09:07:54 --> Helper loaded: my_helper
INFO - 2020-12-29 09:07:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:07:54 --> Controller Class Initialized
INFO - 2020-12-29 09:07:54 --> Final output sent to browser
DEBUG - 2020-12-29 09:07:54 --> Total execution time: 0.3447
INFO - 2020-12-29 09:07:54 --> Config Class Initialized
INFO - 2020-12-29 09:07:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:07:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:07:54 --> Utf8 Class Initialized
INFO - 2020-12-29 09:07:54 --> URI Class Initialized
INFO - 2020-12-29 09:07:54 --> Router Class Initialized
INFO - 2020-12-29 09:07:54 --> Output Class Initialized
INFO - 2020-12-29 09:07:54 --> Security Class Initialized
DEBUG - 2020-12-29 09:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:07:54 --> Input Class Initialized
INFO - 2020-12-29 09:07:54 --> Language Class Initialized
INFO - 2020-12-29 09:07:54 --> Language Class Initialized
INFO - 2020-12-29 09:07:54 --> Config Class Initialized
INFO - 2020-12-29 09:07:54 --> Loader Class Initialized
INFO - 2020-12-29 09:07:54 --> Helper loaded: url_helper
INFO - 2020-12-29 09:07:54 --> Helper loaded: file_helper
INFO - 2020-12-29 09:07:54 --> Helper loaded: form_helper
INFO - 2020-12-29 09:07:54 --> Helper loaded: my_helper
INFO - 2020-12-29 09:07:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:07:54 --> Controller Class Initialized
INFO - 2020-12-29 09:07:55 --> Config Class Initialized
INFO - 2020-12-29 09:07:56 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:07:56 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:07:56 --> Utf8 Class Initialized
INFO - 2020-12-29 09:07:56 --> URI Class Initialized
INFO - 2020-12-29 09:07:56 --> Router Class Initialized
INFO - 2020-12-29 09:07:56 --> Output Class Initialized
INFO - 2020-12-29 09:07:56 --> Security Class Initialized
DEBUG - 2020-12-29 09:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:07:56 --> Input Class Initialized
INFO - 2020-12-29 09:07:56 --> Language Class Initialized
INFO - 2020-12-29 09:07:56 --> Language Class Initialized
INFO - 2020-12-29 09:07:56 --> Config Class Initialized
INFO - 2020-12-29 09:07:56 --> Loader Class Initialized
INFO - 2020-12-29 09:07:56 --> Helper loaded: url_helper
INFO - 2020-12-29 09:07:56 --> Helper loaded: file_helper
INFO - 2020-12-29 09:07:56 --> Helper loaded: form_helper
INFO - 2020-12-29 09:07:56 --> Helper loaded: my_helper
INFO - 2020-12-29 09:07:56 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:07:56 --> Controller Class Initialized
INFO - 2020-12-29 09:07:56 --> Final output sent to browser
DEBUG - 2020-12-29 09:07:56 --> Total execution time: 0.3374
INFO - 2020-12-29 09:08:26 --> Config Class Initialized
INFO - 2020-12-29 09:08:26 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:08:26 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:08:26 --> Utf8 Class Initialized
INFO - 2020-12-29 09:08:26 --> URI Class Initialized
INFO - 2020-12-29 09:08:26 --> Router Class Initialized
INFO - 2020-12-29 09:08:26 --> Output Class Initialized
INFO - 2020-12-29 09:08:26 --> Security Class Initialized
DEBUG - 2020-12-29 09:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:08:26 --> Input Class Initialized
INFO - 2020-12-29 09:08:26 --> Language Class Initialized
INFO - 2020-12-29 09:08:26 --> Language Class Initialized
INFO - 2020-12-29 09:08:26 --> Config Class Initialized
INFO - 2020-12-29 09:08:26 --> Loader Class Initialized
INFO - 2020-12-29 09:08:26 --> Helper loaded: url_helper
INFO - 2020-12-29 09:08:27 --> Helper loaded: file_helper
INFO - 2020-12-29 09:08:27 --> Helper loaded: form_helper
INFO - 2020-12-29 09:08:27 --> Helper loaded: my_helper
INFO - 2020-12-29 09:08:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:08:27 --> Controller Class Initialized
INFO - 2020-12-29 09:08:27 --> Final output sent to browser
DEBUG - 2020-12-29 09:08:27 --> Total execution time: 0.3970
INFO - 2020-12-29 09:08:27 --> Config Class Initialized
INFO - 2020-12-29 09:08:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:08:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:08:27 --> Utf8 Class Initialized
INFO - 2020-12-29 09:08:27 --> URI Class Initialized
INFO - 2020-12-29 09:08:27 --> Router Class Initialized
INFO - 2020-12-29 09:08:27 --> Output Class Initialized
INFO - 2020-12-29 09:08:27 --> Security Class Initialized
DEBUG - 2020-12-29 09:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:08:27 --> Input Class Initialized
INFO - 2020-12-29 09:08:27 --> Language Class Initialized
INFO - 2020-12-29 09:08:27 --> Language Class Initialized
INFO - 2020-12-29 09:08:27 --> Config Class Initialized
INFO - 2020-12-29 09:08:27 --> Loader Class Initialized
INFO - 2020-12-29 09:08:27 --> Helper loaded: url_helper
INFO - 2020-12-29 09:08:27 --> Helper loaded: file_helper
INFO - 2020-12-29 09:08:27 --> Helper loaded: form_helper
INFO - 2020-12-29 09:08:27 --> Helper loaded: my_helper
INFO - 2020-12-29 09:08:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:08:27 --> Controller Class Initialized
INFO - 2020-12-29 09:08:29 --> Config Class Initialized
INFO - 2020-12-29 09:08:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:08:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:08:29 --> Utf8 Class Initialized
INFO - 2020-12-29 09:08:29 --> URI Class Initialized
INFO - 2020-12-29 09:08:29 --> Router Class Initialized
INFO - 2020-12-29 09:08:29 --> Output Class Initialized
INFO - 2020-12-29 09:08:29 --> Security Class Initialized
DEBUG - 2020-12-29 09:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:08:29 --> Input Class Initialized
INFO - 2020-12-29 09:08:29 --> Language Class Initialized
INFO - 2020-12-29 09:08:29 --> Language Class Initialized
INFO - 2020-12-29 09:08:29 --> Config Class Initialized
INFO - 2020-12-29 09:08:29 --> Loader Class Initialized
INFO - 2020-12-29 09:08:29 --> Helper loaded: url_helper
INFO - 2020-12-29 09:08:29 --> Helper loaded: file_helper
INFO - 2020-12-29 09:08:29 --> Helper loaded: form_helper
INFO - 2020-12-29 09:08:29 --> Helper loaded: my_helper
INFO - 2020-12-29 09:08:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:08:29 --> Controller Class Initialized
INFO - 2020-12-29 09:08:29 --> Final output sent to browser
DEBUG - 2020-12-29 09:08:29 --> Total execution time: 0.3455
INFO - 2020-12-29 09:08:50 --> Config Class Initialized
INFO - 2020-12-29 09:08:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:08:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:08:50 --> Utf8 Class Initialized
INFO - 2020-12-29 09:08:50 --> URI Class Initialized
INFO - 2020-12-29 09:08:50 --> Router Class Initialized
INFO - 2020-12-29 09:08:50 --> Output Class Initialized
INFO - 2020-12-29 09:08:50 --> Security Class Initialized
DEBUG - 2020-12-29 09:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:08:50 --> Input Class Initialized
INFO - 2020-12-29 09:08:50 --> Language Class Initialized
INFO - 2020-12-29 09:08:50 --> Language Class Initialized
INFO - 2020-12-29 09:08:50 --> Config Class Initialized
INFO - 2020-12-29 09:08:50 --> Loader Class Initialized
INFO - 2020-12-29 09:08:50 --> Helper loaded: url_helper
INFO - 2020-12-29 09:08:50 --> Helper loaded: file_helper
INFO - 2020-12-29 09:08:50 --> Helper loaded: form_helper
INFO - 2020-12-29 09:08:50 --> Helper loaded: my_helper
INFO - 2020-12-29 09:08:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:08:50 --> Controller Class Initialized
INFO - 2020-12-29 09:08:50 --> Final output sent to browser
DEBUG - 2020-12-29 09:08:50 --> Total execution time: 0.3451
INFO - 2020-12-29 09:08:50 --> Config Class Initialized
INFO - 2020-12-29 09:08:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:08:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:08:51 --> Utf8 Class Initialized
INFO - 2020-12-29 09:08:51 --> URI Class Initialized
INFO - 2020-12-29 09:08:51 --> Router Class Initialized
INFO - 2020-12-29 09:08:51 --> Output Class Initialized
INFO - 2020-12-29 09:08:51 --> Security Class Initialized
DEBUG - 2020-12-29 09:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:08:51 --> Input Class Initialized
INFO - 2020-12-29 09:08:51 --> Language Class Initialized
INFO - 2020-12-29 09:08:51 --> Language Class Initialized
INFO - 2020-12-29 09:08:51 --> Config Class Initialized
INFO - 2020-12-29 09:08:51 --> Loader Class Initialized
INFO - 2020-12-29 09:08:51 --> Helper loaded: url_helper
INFO - 2020-12-29 09:08:51 --> Helper loaded: file_helper
INFO - 2020-12-29 09:08:51 --> Helper loaded: form_helper
INFO - 2020-12-29 09:08:51 --> Helper loaded: my_helper
INFO - 2020-12-29 09:08:51 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:08:51 --> Controller Class Initialized
INFO - 2020-12-29 09:08:52 --> Config Class Initialized
INFO - 2020-12-29 09:08:52 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:08:52 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:08:52 --> Utf8 Class Initialized
INFO - 2020-12-29 09:08:52 --> URI Class Initialized
INFO - 2020-12-29 09:08:52 --> Router Class Initialized
INFO - 2020-12-29 09:08:52 --> Output Class Initialized
INFO - 2020-12-29 09:08:52 --> Security Class Initialized
DEBUG - 2020-12-29 09:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:08:52 --> Input Class Initialized
INFO - 2020-12-29 09:08:52 --> Language Class Initialized
INFO - 2020-12-29 09:08:52 --> Language Class Initialized
INFO - 2020-12-29 09:08:52 --> Config Class Initialized
INFO - 2020-12-29 09:08:52 --> Loader Class Initialized
INFO - 2020-12-29 09:08:52 --> Helper loaded: url_helper
INFO - 2020-12-29 09:08:52 --> Helper loaded: file_helper
INFO - 2020-12-29 09:08:52 --> Helper loaded: form_helper
INFO - 2020-12-29 09:08:52 --> Helper loaded: my_helper
INFO - 2020-12-29 09:08:52 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:08:52 --> Controller Class Initialized
INFO - 2020-12-29 09:08:52 --> Final output sent to browser
DEBUG - 2020-12-29 09:08:52 --> Total execution time: 0.3348
INFO - 2020-12-29 09:09:18 --> Config Class Initialized
INFO - 2020-12-29 09:09:18 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:09:18 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:09:18 --> Utf8 Class Initialized
INFO - 2020-12-29 09:09:18 --> URI Class Initialized
INFO - 2020-12-29 09:09:18 --> Router Class Initialized
INFO - 2020-12-29 09:09:18 --> Output Class Initialized
INFO - 2020-12-29 09:09:18 --> Security Class Initialized
DEBUG - 2020-12-29 09:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:09:18 --> Input Class Initialized
INFO - 2020-12-29 09:09:18 --> Language Class Initialized
INFO - 2020-12-29 09:09:18 --> Language Class Initialized
INFO - 2020-12-29 09:09:18 --> Config Class Initialized
INFO - 2020-12-29 09:09:18 --> Loader Class Initialized
INFO - 2020-12-29 09:09:18 --> Helper loaded: url_helper
INFO - 2020-12-29 09:09:18 --> Helper loaded: file_helper
INFO - 2020-12-29 09:09:18 --> Helper loaded: form_helper
INFO - 2020-12-29 09:09:18 --> Helper loaded: my_helper
INFO - 2020-12-29 09:09:18 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:09:18 --> Controller Class Initialized
INFO - 2020-12-29 09:09:18 --> Final output sent to browser
DEBUG - 2020-12-29 09:09:18 --> Total execution time: 0.3714
INFO - 2020-12-29 09:09:18 --> Config Class Initialized
INFO - 2020-12-29 09:09:18 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:09:18 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:09:18 --> Utf8 Class Initialized
INFO - 2020-12-29 09:09:18 --> URI Class Initialized
INFO - 2020-12-29 09:09:18 --> Router Class Initialized
INFO - 2020-12-29 09:09:18 --> Output Class Initialized
INFO - 2020-12-29 09:09:18 --> Security Class Initialized
DEBUG - 2020-12-29 09:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:09:18 --> Input Class Initialized
INFO - 2020-12-29 09:09:18 --> Language Class Initialized
INFO - 2020-12-29 09:09:18 --> Language Class Initialized
INFO - 2020-12-29 09:09:18 --> Config Class Initialized
INFO - 2020-12-29 09:09:18 --> Loader Class Initialized
INFO - 2020-12-29 09:09:18 --> Helper loaded: url_helper
INFO - 2020-12-29 09:09:18 --> Helper loaded: file_helper
INFO - 2020-12-29 09:09:18 --> Helper loaded: form_helper
INFO - 2020-12-29 09:09:18 --> Helper loaded: my_helper
INFO - 2020-12-29 09:09:19 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:09:19 --> Controller Class Initialized
INFO - 2020-12-29 09:23:31 --> Config Class Initialized
INFO - 2020-12-29 09:23:31 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:23:31 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:23:31 --> Utf8 Class Initialized
INFO - 2020-12-29 09:23:31 --> URI Class Initialized
INFO - 2020-12-29 09:23:31 --> Router Class Initialized
INFO - 2020-12-29 09:23:31 --> Output Class Initialized
INFO - 2020-12-29 09:23:31 --> Security Class Initialized
DEBUG - 2020-12-29 09:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:23:31 --> Input Class Initialized
INFO - 2020-12-29 09:23:31 --> Language Class Initialized
INFO - 2020-12-29 09:23:31 --> Language Class Initialized
INFO - 2020-12-29 09:23:31 --> Config Class Initialized
INFO - 2020-12-29 09:23:31 --> Loader Class Initialized
INFO - 2020-12-29 09:23:32 --> Helper loaded: url_helper
INFO - 2020-12-29 09:23:32 --> Helper loaded: file_helper
INFO - 2020-12-29 09:23:32 --> Helper loaded: form_helper
INFO - 2020-12-29 09:23:32 --> Helper loaded: my_helper
INFO - 2020-12-29 09:23:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:23:32 --> Controller Class Initialized
INFO - 2020-12-29 09:23:32 --> Helper loaded: cookie_helper
INFO - 2020-12-29 09:23:32 --> Config Class Initialized
INFO - 2020-12-29 09:23:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:23:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:23:32 --> Utf8 Class Initialized
INFO - 2020-12-29 09:23:32 --> URI Class Initialized
INFO - 2020-12-29 09:23:32 --> Router Class Initialized
INFO - 2020-12-29 09:23:32 --> Output Class Initialized
INFO - 2020-12-29 09:23:32 --> Security Class Initialized
DEBUG - 2020-12-29 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:23:32 --> Input Class Initialized
INFO - 2020-12-29 09:23:32 --> Language Class Initialized
INFO - 2020-12-29 09:23:32 --> Language Class Initialized
INFO - 2020-12-29 09:23:32 --> Config Class Initialized
INFO - 2020-12-29 09:23:32 --> Loader Class Initialized
INFO - 2020-12-29 09:23:32 --> Helper loaded: url_helper
INFO - 2020-12-29 09:23:32 --> Helper loaded: file_helper
INFO - 2020-12-29 09:23:32 --> Helper loaded: form_helper
INFO - 2020-12-29 09:23:32 --> Helper loaded: my_helper
INFO - 2020-12-29 09:23:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:23:32 --> Controller Class Initialized
DEBUG - 2020-12-29 09:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 09:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 09:23:32 --> Final output sent to browser
DEBUG - 2020-12-29 09:23:32 --> Total execution time: 0.3865
INFO - 2020-12-29 09:23:36 --> Config Class Initialized
INFO - 2020-12-29 09:23:36 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:23:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:23:37 --> Utf8 Class Initialized
INFO - 2020-12-29 09:23:37 --> URI Class Initialized
INFO - 2020-12-29 09:23:37 --> Router Class Initialized
INFO - 2020-12-29 09:23:37 --> Output Class Initialized
INFO - 2020-12-29 09:23:37 --> Security Class Initialized
DEBUG - 2020-12-29 09:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:23:37 --> Input Class Initialized
INFO - 2020-12-29 09:23:37 --> Language Class Initialized
INFO - 2020-12-29 09:23:37 --> Language Class Initialized
INFO - 2020-12-29 09:23:37 --> Config Class Initialized
INFO - 2020-12-29 09:23:37 --> Loader Class Initialized
INFO - 2020-12-29 09:23:37 --> Helper loaded: url_helper
INFO - 2020-12-29 09:23:37 --> Helper loaded: file_helper
INFO - 2020-12-29 09:23:37 --> Helper loaded: form_helper
INFO - 2020-12-29 09:23:37 --> Helper loaded: my_helper
INFO - 2020-12-29 09:23:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:23:37 --> Controller Class Initialized
INFO - 2020-12-29 09:23:37 --> Helper loaded: cookie_helper
INFO - 2020-12-29 09:23:37 --> Final output sent to browser
DEBUG - 2020-12-29 09:23:37 --> Total execution time: 0.4791
INFO - 2020-12-29 09:23:37 --> Config Class Initialized
INFO - 2020-12-29 09:23:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:23:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:23:37 --> Utf8 Class Initialized
INFO - 2020-12-29 09:23:38 --> URI Class Initialized
INFO - 2020-12-29 09:23:38 --> Router Class Initialized
INFO - 2020-12-29 09:23:38 --> Output Class Initialized
INFO - 2020-12-29 09:23:38 --> Security Class Initialized
DEBUG - 2020-12-29 09:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:23:38 --> Input Class Initialized
INFO - 2020-12-29 09:23:38 --> Language Class Initialized
INFO - 2020-12-29 09:23:38 --> Language Class Initialized
INFO - 2020-12-29 09:23:38 --> Config Class Initialized
INFO - 2020-12-29 09:23:38 --> Loader Class Initialized
INFO - 2020-12-29 09:23:38 --> Helper loaded: url_helper
INFO - 2020-12-29 09:23:38 --> Helper loaded: file_helper
INFO - 2020-12-29 09:23:38 --> Helper loaded: form_helper
INFO - 2020-12-29 09:23:38 --> Helper loaded: my_helper
INFO - 2020-12-29 09:23:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:23:38 --> Controller Class Initialized
DEBUG - 2020-12-29 09:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 09:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 09:23:38 --> Final output sent to browser
DEBUG - 2020-12-29 09:23:38 --> Total execution time: 0.5382
INFO - 2020-12-29 09:23:40 --> Config Class Initialized
INFO - 2020-12-29 09:23:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:23:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:23:40 --> Utf8 Class Initialized
INFO - 2020-12-29 09:23:40 --> URI Class Initialized
INFO - 2020-12-29 09:23:40 --> Router Class Initialized
INFO - 2020-12-29 09:23:40 --> Output Class Initialized
INFO - 2020-12-29 09:23:40 --> Security Class Initialized
DEBUG - 2020-12-29 09:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:23:40 --> Input Class Initialized
INFO - 2020-12-29 09:23:40 --> Language Class Initialized
INFO - 2020-12-29 09:23:40 --> Language Class Initialized
INFO - 2020-12-29 09:23:40 --> Config Class Initialized
INFO - 2020-12-29 09:23:40 --> Loader Class Initialized
INFO - 2020-12-29 09:23:40 --> Helper loaded: url_helper
INFO - 2020-12-29 09:23:40 --> Helper loaded: file_helper
INFO - 2020-12-29 09:23:40 --> Helper loaded: form_helper
INFO - 2020-12-29 09:23:40 --> Helper loaded: my_helper
INFO - 2020-12-29 09:23:40 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:23:40 --> Controller Class Initialized
DEBUG - 2020-12-29 09:23:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-29 09:23:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 09:23:40 --> Final output sent to browser
DEBUG - 2020-12-29 09:23:40 --> Total execution time: 0.4417
INFO - 2020-12-29 09:24:59 --> Config Class Initialized
INFO - 2020-12-29 09:24:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:24:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:24:59 --> Utf8 Class Initialized
INFO - 2020-12-29 09:24:59 --> URI Class Initialized
INFO - 2020-12-29 09:24:59 --> Router Class Initialized
INFO - 2020-12-29 09:24:59 --> Output Class Initialized
INFO - 2020-12-29 09:24:59 --> Security Class Initialized
DEBUG - 2020-12-29 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:24:59 --> Input Class Initialized
INFO - 2020-12-29 09:24:59 --> Language Class Initialized
INFO - 2020-12-29 09:24:59 --> Language Class Initialized
INFO - 2020-12-29 09:24:59 --> Config Class Initialized
INFO - 2020-12-29 09:24:59 --> Loader Class Initialized
INFO - 2020-12-29 09:24:59 --> Helper loaded: url_helper
INFO - 2020-12-29 09:24:59 --> Helper loaded: file_helper
INFO - 2020-12-29 09:24:59 --> Helper loaded: form_helper
INFO - 2020-12-29 09:24:59 --> Helper loaded: my_helper
INFO - 2020-12-29 09:24:59 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:24:59 --> Controller Class Initialized
DEBUG - 2020-12-29 09:24:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-29 09:24:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 09:24:59 --> Final output sent to browser
DEBUG - 2020-12-29 09:24:59 --> Total execution time: 0.3755
INFO - 2020-12-29 09:25:40 --> Config Class Initialized
INFO - 2020-12-29 09:25:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:25:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:25:40 --> Utf8 Class Initialized
INFO - 2020-12-29 09:25:40 --> URI Class Initialized
INFO - 2020-12-29 09:25:40 --> Router Class Initialized
INFO - 2020-12-29 09:25:40 --> Output Class Initialized
INFO - 2020-12-29 09:25:40 --> Security Class Initialized
DEBUG - 2020-12-29 09:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:25:41 --> Input Class Initialized
INFO - 2020-12-29 09:25:41 --> Language Class Initialized
INFO - 2020-12-29 09:25:41 --> Language Class Initialized
INFO - 2020-12-29 09:25:41 --> Config Class Initialized
INFO - 2020-12-29 09:25:41 --> Loader Class Initialized
INFO - 2020-12-29 09:25:41 --> Helper loaded: url_helper
INFO - 2020-12-29 09:25:41 --> Helper loaded: file_helper
INFO - 2020-12-29 09:25:41 --> Helper loaded: form_helper
INFO - 2020-12-29 09:25:41 --> Helper loaded: my_helper
INFO - 2020-12-29 09:25:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:25:41 --> Controller Class Initialized
DEBUG - 2020-12-29 09:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-29 09:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 09:25:41 --> Final output sent to browser
DEBUG - 2020-12-29 09:25:41 --> Total execution time: 0.3607
INFO - 2020-12-29 09:25:42 --> Config Class Initialized
INFO - 2020-12-29 09:25:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 09:25:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 09:25:42 --> Utf8 Class Initialized
INFO - 2020-12-29 09:25:42 --> URI Class Initialized
INFO - 2020-12-29 09:25:42 --> Router Class Initialized
INFO - 2020-12-29 09:25:42 --> Output Class Initialized
INFO - 2020-12-29 09:25:42 --> Security Class Initialized
DEBUG - 2020-12-29 09:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 09:25:42 --> Input Class Initialized
INFO - 2020-12-29 09:25:42 --> Language Class Initialized
INFO - 2020-12-29 09:25:42 --> Language Class Initialized
INFO - 2020-12-29 09:25:42 --> Config Class Initialized
INFO - 2020-12-29 09:25:42 --> Loader Class Initialized
INFO - 2020-12-29 09:25:42 --> Helper loaded: url_helper
INFO - 2020-12-29 09:25:42 --> Helper loaded: file_helper
INFO - 2020-12-29 09:25:43 --> Helper loaded: form_helper
INFO - 2020-12-29 09:25:43 --> Helper loaded: my_helper
INFO - 2020-12-29 09:25:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 09:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 09:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 09:25:43 --> Controller Class Initialized
DEBUG - 2020-12-29 09:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-29 09:25:43 --> Final output sent to browser
DEBUG - 2020-12-29 09:25:43 --> Total execution time: 0.3905
INFO - 2020-12-29 02:23:17 --> Config Class Initialized
INFO - 2020-12-29 02:23:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:23:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:23:17 --> Utf8 Class Initialized
INFO - 2020-12-29 02:23:17 --> URI Class Initialized
DEBUG - 2020-12-29 02:23:17 --> No URI present. Default controller set.
INFO - 2020-12-29 02:23:17 --> Router Class Initialized
INFO - 2020-12-29 02:23:17 --> Output Class Initialized
INFO - 2020-12-29 02:23:17 --> Security Class Initialized
DEBUG - 2020-12-29 02:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:23:17 --> Input Class Initialized
INFO - 2020-12-29 02:23:17 --> Language Class Initialized
INFO - 2020-12-29 02:23:17 --> Language Class Initialized
INFO - 2020-12-29 02:23:17 --> Config Class Initialized
INFO - 2020-12-29 02:23:17 --> Loader Class Initialized
INFO - 2020-12-29 02:23:17 --> Helper loaded: url_helper
INFO - 2020-12-29 02:23:17 --> Helper loaded: file_helper
INFO - 2020-12-29 02:23:17 --> Helper loaded: form_helper
INFO - 2020-12-29 02:23:17 --> Helper loaded: my_helper
INFO - 2020-12-29 02:23:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:23:17 --> Controller Class Initialized
INFO - 2020-12-29 02:23:17 --> Config Class Initialized
INFO - 2020-12-29 02:23:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:23:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:23:17 --> Utf8 Class Initialized
INFO - 2020-12-29 02:23:17 --> URI Class Initialized
INFO - 2020-12-29 02:23:17 --> Router Class Initialized
INFO - 2020-12-29 02:23:17 --> Output Class Initialized
INFO - 2020-12-29 02:23:17 --> Security Class Initialized
DEBUG - 2020-12-29 02:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:23:17 --> Input Class Initialized
INFO - 2020-12-29 02:23:17 --> Language Class Initialized
INFO - 2020-12-29 02:23:17 --> Language Class Initialized
INFO - 2020-12-29 02:23:17 --> Config Class Initialized
INFO - 2020-12-29 02:23:17 --> Loader Class Initialized
INFO - 2020-12-29 02:23:17 --> Helper loaded: url_helper
INFO - 2020-12-29 02:23:17 --> Helper loaded: file_helper
INFO - 2020-12-29 02:23:17 --> Helper loaded: form_helper
INFO - 2020-12-29 02:23:17 --> Helper loaded: my_helper
INFO - 2020-12-29 02:23:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:23:17 --> Controller Class Initialized
DEBUG - 2020-12-29 02:23:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 02:23:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:23:17 --> Final output sent to browser
DEBUG - 2020-12-29 02:23:17 --> Total execution time: 0.1045
INFO - 2020-12-29 02:23:27 --> Config Class Initialized
INFO - 2020-12-29 02:23:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:23:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:23:27 --> Utf8 Class Initialized
INFO - 2020-12-29 02:23:27 --> URI Class Initialized
INFO - 2020-12-29 02:23:27 --> Router Class Initialized
INFO - 2020-12-29 02:23:27 --> Output Class Initialized
INFO - 2020-12-29 02:23:27 --> Security Class Initialized
DEBUG - 2020-12-29 02:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:23:27 --> Input Class Initialized
INFO - 2020-12-29 02:23:27 --> Language Class Initialized
INFO - 2020-12-29 02:23:27 --> Language Class Initialized
INFO - 2020-12-29 02:23:27 --> Config Class Initialized
INFO - 2020-12-29 02:23:27 --> Loader Class Initialized
INFO - 2020-12-29 02:23:27 --> Helper loaded: url_helper
INFO - 2020-12-29 02:23:27 --> Helper loaded: file_helper
INFO - 2020-12-29 02:23:27 --> Helper loaded: form_helper
INFO - 2020-12-29 02:23:27 --> Helper loaded: my_helper
INFO - 2020-12-29 02:23:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:23:27 --> Controller Class Initialized
INFO - 2020-12-29 02:23:27 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:23:27 --> Final output sent to browser
DEBUG - 2020-12-29 02:23:27 --> Total execution time: 0.1567
INFO - 2020-12-29 02:23:28 --> Config Class Initialized
INFO - 2020-12-29 02:23:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:23:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:23:28 --> Utf8 Class Initialized
INFO - 2020-12-29 02:23:28 --> URI Class Initialized
INFO - 2020-12-29 02:23:28 --> Router Class Initialized
INFO - 2020-12-29 02:23:28 --> Output Class Initialized
INFO - 2020-12-29 02:23:28 --> Security Class Initialized
DEBUG - 2020-12-29 02:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:23:28 --> Input Class Initialized
INFO - 2020-12-29 02:23:28 --> Language Class Initialized
INFO - 2020-12-29 02:23:28 --> Language Class Initialized
INFO - 2020-12-29 02:23:28 --> Config Class Initialized
INFO - 2020-12-29 02:23:28 --> Loader Class Initialized
INFO - 2020-12-29 02:23:28 --> Helper loaded: url_helper
INFO - 2020-12-29 02:23:28 --> Helper loaded: file_helper
INFO - 2020-12-29 02:23:28 --> Helper loaded: form_helper
INFO - 2020-12-29 02:23:28 --> Helper loaded: my_helper
INFO - 2020-12-29 02:23:28 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:23:28 --> Controller Class Initialized
DEBUG - 2020-12-29 02:23:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 02:23:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:23:28 --> Final output sent to browser
DEBUG - 2020-12-29 02:23:28 --> Total execution time: 0.1455
INFO - 2020-12-29 02:23:31 --> Config Class Initialized
INFO - 2020-12-29 02:23:31 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:23:31 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:23:31 --> Utf8 Class Initialized
INFO - 2020-12-29 02:23:31 --> URI Class Initialized
INFO - 2020-12-29 02:23:31 --> Router Class Initialized
INFO - 2020-12-29 02:23:31 --> Output Class Initialized
INFO - 2020-12-29 02:23:31 --> Security Class Initialized
DEBUG - 2020-12-29 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:23:31 --> Input Class Initialized
INFO - 2020-12-29 02:23:31 --> Language Class Initialized
INFO - 2020-12-29 02:23:31 --> Language Class Initialized
INFO - 2020-12-29 02:23:31 --> Config Class Initialized
INFO - 2020-12-29 02:23:31 --> Loader Class Initialized
INFO - 2020-12-29 02:23:31 --> Helper loaded: url_helper
INFO - 2020-12-29 02:23:31 --> Helper loaded: file_helper
INFO - 2020-12-29 02:23:31 --> Helper loaded: form_helper
INFO - 2020-12-29 02:23:31 --> Helper loaded: my_helper
INFO - 2020-12-29 02:23:31 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:23:31 --> Controller Class Initialized
DEBUG - 2020-12-29 02:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:23:31 --> Final output sent to browser
DEBUG - 2020-12-29 02:23:31 --> Total execution time: 0.1923
INFO - 2020-12-29 02:23:32 --> Config Class Initialized
INFO - 2020-12-29 02:23:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:23:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:23:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:23:32 --> URI Class Initialized
INFO - 2020-12-29 02:23:32 --> Router Class Initialized
INFO - 2020-12-29 02:23:32 --> Output Class Initialized
INFO - 2020-12-29 02:23:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:23:32 --> Input Class Initialized
INFO - 2020-12-29 02:23:32 --> Language Class Initialized
INFO - 2020-12-29 02:23:32 --> Language Class Initialized
INFO - 2020-12-29 02:23:32 --> Config Class Initialized
INFO - 2020-12-29 02:23:32 --> Loader Class Initialized
INFO - 2020-12-29 02:23:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:23:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:23:32 --> Helper loaded: form_helper
INFO - 2020-12-29 02:23:32 --> Helper loaded: my_helper
INFO - 2020-12-29 02:23:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:23:32 --> Controller Class Initialized
DEBUG - 2020-12-29 02:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:23:33 --> Final output sent to browser
DEBUG - 2020-12-29 02:23:33 --> Total execution time: 0.1892
INFO - 2020-12-29 02:23:36 --> Config Class Initialized
INFO - 2020-12-29 02:23:36 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:23:36 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:23:36 --> Utf8 Class Initialized
INFO - 2020-12-29 02:23:37 --> URI Class Initialized
INFO - 2020-12-29 02:23:37 --> Router Class Initialized
INFO - 2020-12-29 02:23:37 --> Output Class Initialized
INFO - 2020-12-29 02:23:37 --> Security Class Initialized
DEBUG - 2020-12-29 02:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:23:37 --> Input Class Initialized
INFO - 2020-12-29 02:23:37 --> Language Class Initialized
INFO - 2020-12-29 02:23:37 --> Language Class Initialized
INFO - 2020-12-29 02:23:37 --> Config Class Initialized
INFO - 2020-12-29 02:23:37 --> Loader Class Initialized
INFO - 2020-12-29 02:23:37 --> Helper loaded: url_helper
INFO - 2020-12-29 02:23:37 --> Helper loaded: file_helper
INFO - 2020-12-29 02:23:37 --> Helper loaded: form_helper
INFO - 2020-12-29 02:23:37 --> Helper loaded: my_helper
INFO - 2020-12-29 02:23:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:23:37 --> Controller Class Initialized
INFO - 2020-12-29 02:23:37 --> Config Class Initialized
INFO - 2020-12-29 02:23:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:23:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:23:37 --> Utf8 Class Initialized
INFO - 2020-12-29 02:23:37 --> URI Class Initialized
INFO - 2020-12-29 02:23:37 --> Router Class Initialized
INFO - 2020-12-29 02:23:37 --> Output Class Initialized
INFO - 2020-12-29 02:23:37 --> Security Class Initialized
DEBUG - 2020-12-29 02:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:23:37 --> Input Class Initialized
INFO - 2020-12-29 02:23:37 --> Language Class Initialized
INFO - 2020-12-29 02:23:37 --> Language Class Initialized
INFO - 2020-12-29 02:23:37 --> Config Class Initialized
INFO - 2020-12-29 02:23:37 --> Loader Class Initialized
INFO - 2020-12-29 02:23:37 --> Helper loaded: url_helper
INFO - 2020-12-29 02:23:37 --> Helper loaded: file_helper
INFO - 2020-12-29 02:23:37 --> Helper loaded: form_helper
INFO - 2020-12-29 02:23:37 --> Helper loaded: my_helper
INFO - 2020-12-29 02:23:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:23:37 --> Controller Class Initialized
DEBUG - 2020-12-29 02:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:23:37 --> Final output sent to browser
DEBUG - 2020-12-29 02:23:37 --> Total execution time: 0.1248
INFO - 2020-12-29 02:25:07 --> Config Class Initialized
INFO - 2020-12-29 02:25:07 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:07 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:07 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:07 --> URI Class Initialized
INFO - 2020-12-29 02:25:07 --> Router Class Initialized
INFO - 2020-12-29 02:25:07 --> Output Class Initialized
INFO - 2020-12-29 02:25:07 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:07 --> Input Class Initialized
INFO - 2020-12-29 02:25:07 --> Language Class Initialized
INFO - 2020-12-29 02:25:08 --> Language Class Initialized
INFO - 2020-12-29 02:25:08 --> Config Class Initialized
INFO - 2020-12-29 02:25:08 --> Loader Class Initialized
INFO - 2020-12-29 02:25:08 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:08 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:08 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:08 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:08 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:08 --> Controller Class Initialized
INFO - 2020-12-29 02:25:08 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:25:08 --> Config Class Initialized
INFO - 2020-12-29 02:25:08 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:08 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:08 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:08 --> URI Class Initialized
INFO - 2020-12-29 02:25:08 --> Router Class Initialized
INFO - 2020-12-29 02:25:08 --> Output Class Initialized
INFO - 2020-12-29 02:25:08 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:08 --> Input Class Initialized
INFO - 2020-12-29 02:25:08 --> Language Class Initialized
INFO - 2020-12-29 02:25:08 --> Language Class Initialized
INFO - 2020-12-29 02:25:08 --> Config Class Initialized
INFO - 2020-12-29 02:25:08 --> Loader Class Initialized
INFO - 2020-12-29 02:25:08 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:08 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:08 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:08 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:08 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:08 --> Controller Class Initialized
DEBUG - 2020-12-29 02:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 02:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:25:08 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:08 --> Total execution time: 0.1315
INFO - 2020-12-29 02:25:13 --> Config Class Initialized
INFO - 2020-12-29 02:25:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:13 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:13 --> URI Class Initialized
INFO - 2020-12-29 02:25:13 --> Router Class Initialized
INFO - 2020-12-29 02:25:13 --> Output Class Initialized
INFO - 2020-12-29 02:25:13 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:13 --> Input Class Initialized
INFO - 2020-12-29 02:25:13 --> Language Class Initialized
INFO - 2020-12-29 02:25:13 --> Language Class Initialized
INFO - 2020-12-29 02:25:13 --> Config Class Initialized
INFO - 2020-12-29 02:25:13 --> Loader Class Initialized
INFO - 2020-12-29 02:25:13 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:13 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:13 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:13 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:13 --> Controller Class Initialized
INFO - 2020-12-29 02:25:13 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:25:13 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:13 --> Total execution time: 0.1938
INFO - 2020-12-29 02:25:13 --> Config Class Initialized
INFO - 2020-12-29 02:25:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:13 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:13 --> URI Class Initialized
INFO - 2020-12-29 02:25:13 --> Router Class Initialized
INFO - 2020-12-29 02:25:13 --> Output Class Initialized
INFO - 2020-12-29 02:25:13 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:13 --> Input Class Initialized
INFO - 2020-12-29 02:25:13 --> Language Class Initialized
INFO - 2020-12-29 02:25:13 --> Language Class Initialized
INFO - 2020-12-29 02:25:13 --> Config Class Initialized
INFO - 2020-12-29 02:25:13 --> Loader Class Initialized
INFO - 2020-12-29 02:25:13 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:13 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:13 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:13 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:13 --> Controller Class Initialized
DEBUG - 2020-12-29 02:25:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 02:25:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:25:13 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:13 --> Total execution time: 0.1406
INFO - 2020-12-29 02:25:19 --> Config Class Initialized
INFO - 2020-12-29 02:25:19 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:19 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:19 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:19 --> URI Class Initialized
INFO - 2020-12-29 02:25:19 --> Router Class Initialized
INFO - 2020-12-29 02:25:19 --> Output Class Initialized
INFO - 2020-12-29 02:25:19 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:19 --> Input Class Initialized
INFO - 2020-12-29 02:25:19 --> Language Class Initialized
INFO - 2020-12-29 02:25:19 --> Language Class Initialized
INFO - 2020-12-29 02:25:19 --> Config Class Initialized
INFO - 2020-12-29 02:25:19 --> Loader Class Initialized
INFO - 2020-12-29 02:25:19 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:19 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:19 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:19 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:19 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:19 --> Controller Class Initialized
DEBUG - 2020-12-29 02:25:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-29 02:25:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:25:19 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:19 --> Total execution time: 0.1849
INFO - 2020-12-29 02:25:21 --> Config Class Initialized
INFO - 2020-12-29 02:25:21 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:21 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:21 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:21 --> URI Class Initialized
INFO - 2020-12-29 02:25:21 --> Router Class Initialized
INFO - 2020-12-29 02:25:21 --> Output Class Initialized
INFO - 2020-12-29 02:25:21 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:21 --> Input Class Initialized
INFO - 2020-12-29 02:25:21 --> Language Class Initialized
INFO - 2020-12-29 02:25:21 --> Language Class Initialized
INFO - 2020-12-29 02:25:21 --> Config Class Initialized
INFO - 2020-12-29 02:25:21 --> Loader Class Initialized
INFO - 2020-12-29 02:25:21 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:21 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:21 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:21 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:21 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:21 --> Controller Class Initialized
DEBUG - 2020-12-29 02:25:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-12-29 02:25:21 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:21 --> Total execution time: 0.2756
INFO - 2020-12-29 02:25:27 --> Config Class Initialized
INFO - 2020-12-29 02:25:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:27 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:27 --> URI Class Initialized
INFO - 2020-12-29 02:25:27 --> Router Class Initialized
INFO - 2020-12-29 02:25:27 --> Output Class Initialized
INFO - 2020-12-29 02:25:27 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:27 --> Input Class Initialized
INFO - 2020-12-29 02:25:27 --> Language Class Initialized
INFO - 2020-12-29 02:25:27 --> Language Class Initialized
INFO - 2020-12-29 02:25:27 --> Config Class Initialized
INFO - 2020-12-29 02:25:27 --> Loader Class Initialized
INFO - 2020-12-29 02:25:27 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:27 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:27 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:27 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:27 --> Controller Class Initialized
INFO - 2020-12-29 02:25:27 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:25:27 --> Config Class Initialized
INFO - 2020-12-29 02:25:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:27 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:27 --> URI Class Initialized
INFO - 2020-12-29 02:25:27 --> Router Class Initialized
INFO - 2020-12-29 02:25:27 --> Output Class Initialized
INFO - 2020-12-29 02:25:27 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:27 --> Input Class Initialized
INFO - 2020-12-29 02:25:27 --> Language Class Initialized
INFO - 2020-12-29 02:25:27 --> Language Class Initialized
INFO - 2020-12-29 02:25:27 --> Config Class Initialized
INFO - 2020-12-29 02:25:27 --> Loader Class Initialized
INFO - 2020-12-29 02:25:27 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:27 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:27 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:27 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:27 --> Controller Class Initialized
DEBUG - 2020-12-29 02:25:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-29 02:25:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:25:27 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:27 --> Total execution time: 0.1373
INFO - 2020-12-29 02:25:32 --> Config Class Initialized
INFO - 2020-12-29 02:25:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:32 --> URI Class Initialized
INFO - 2020-12-29 02:25:32 --> Router Class Initialized
INFO - 2020-12-29 02:25:32 --> Output Class Initialized
INFO - 2020-12-29 02:25:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:32 --> Input Class Initialized
INFO - 2020-12-29 02:25:32 --> Language Class Initialized
INFO - 2020-12-29 02:25:32 --> Language Class Initialized
INFO - 2020-12-29 02:25:32 --> Config Class Initialized
INFO - 2020-12-29 02:25:32 --> Loader Class Initialized
INFO - 2020-12-29 02:25:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:32 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:32 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:32 --> Controller Class Initialized
INFO - 2020-12-29 02:25:32 --> Helper loaded: cookie_helper
INFO - 2020-12-29 02:25:32 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:32 --> Total execution time: 0.2067
INFO - 2020-12-29 02:25:33 --> Config Class Initialized
INFO - 2020-12-29 02:25:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:33 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:33 --> URI Class Initialized
INFO - 2020-12-29 02:25:33 --> Router Class Initialized
INFO - 2020-12-29 02:25:33 --> Output Class Initialized
INFO - 2020-12-29 02:25:33 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:33 --> Input Class Initialized
INFO - 2020-12-29 02:25:33 --> Language Class Initialized
INFO - 2020-12-29 02:25:33 --> Language Class Initialized
INFO - 2020-12-29 02:25:33 --> Config Class Initialized
INFO - 2020-12-29 02:25:34 --> Loader Class Initialized
INFO - 2020-12-29 02:25:34 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:34 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:34 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:34 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:34 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:34 --> Controller Class Initialized
DEBUG - 2020-12-29 02:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-29 02:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:25:34 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:34 --> Total execution time: 0.1368
INFO - 2020-12-29 02:25:43 --> Config Class Initialized
INFO - 2020-12-29 02:25:43 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:43 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:43 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:43 --> URI Class Initialized
INFO - 2020-12-29 02:25:43 --> Router Class Initialized
INFO - 2020-12-29 02:25:43 --> Output Class Initialized
INFO - 2020-12-29 02:25:43 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:43 --> Input Class Initialized
INFO - 2020-12-29 02:25:43 --> Language Class Initialized
INFO - 2020-12-29 02:25:43 --> Language Class Initialized
INFO - 2020-12-29 02:25:43 --> Config Class Initialized
INFO - 2020-12-29 02:25:43 --> Loader Class Initialized
INFO - 2020-12-29 02:25:43 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:43 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:43 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:43 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:43 --> Controller Class Initialized
DEBUG - 2020-12-29 02:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-12-29 02:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:25:43 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:43 --> Total execution time: 0.1684
INFO - 2020-12-29 02:25:43 --> Config Class Initialized
INFO - 2020-12-29 02:25:43 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:43 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:43 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:43 --> URI Class Initialized
INFO - 2020-12-29 02:25:43 --> Router Class Initialized
INFO - 2020-12-29 02:25:43 --> Output Class Initialized
INFO - 2020-12-29 02:25:43 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:43 --> Input Class Initialized
INFO - 2020-12-29 02:25:43 --> Language Class Initialized
INFO - 2020-12-29 02:25:43 --> Language Class Initialized
INFO - 2020-12-29 02:25:43 --> Config Class Initialized
INFO - 2020-12-29 02:25:43 --> Loader Class Initialized
INFO - 2020-12-29 02:25:43 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:43 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:43 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:43 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:43 --> Controller Class Initialized
INFO - 2020-12-29 02:25:44 --> Config Class Initialized
INFO - 2020-12-29 02:25:44 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:25:44 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:25:44 --> Utf8 Class Initialized
INFO - 2020-12-29 02:25:44 --> URI Class Initialized
INFO - 2020-12-29 02:25:44 --> Router Class Initialized
INFO - 2020-12-29 02:25:44 --> Output Class Initialized
INFO - 2020-12-29 02:25:44 --> Security Class Initialized
DEBUG - 2020-12-29 02:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:25:45 --> Input Class Initialized
INFO - 2020-12-29 02:25:45 --> Language Class Initialized
INFO - 2020-12-29 02:25:45 --> Language Class Initialized
INFO - 2020-12-29 02:25:45 --> Config Class Initialized
INFO - 2020-12-29 02:25:45 --> Loader Class Initialized
INFO - 2020-12-29 02:25:45 --> Helper loaded: url_helper
INFO - 2020-12-29 02:25:45 --> Helper loaded: file_helper
INFO - 2020-12-29 02:25:45 --> Helper loaded: form_helper
INFO - 2020-12-29 02:25:45 --> Helper loaded: my_helper
INFO - 2020-12-29 02:25:45 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:25:45 --> Controller Class Initialized
INFO - 2020-12-29 02:25:45 --> Final output sent to browser
DEBUG - 2020-12-29 02:25:45 --> Total execution time: 0.1342
INFO - 2020-12-29 02:26:24 --> Config Class Initialized
INFO - 2020-12-29 02:26:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:26:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:26:24 --> Utf8 Class Initialized
INFO - 2020-12-29 02:26:24 --> URI Class Initialized
INFO - 2020-12-29 02:26:24 --> Router Class Initialized
INFO - 2020-12-29 02:26:24 --> Output Class Initialized
INFO - 2020-12-29 02:26:24 --> Security Class Initialized
DEBUG - 2020-12-29 02:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:26:24 --> Input Class Initialized
INFO - 2020-12-29 02:26:24 --> Language Class Initialized
INFO - 2020-12-29 02:26:24 --> Language Class Initialized
INFO - 2020-12-29 02:26:24 --> Config Class Initialized
INFO - 2020-12-29 02:26:24 --> Loader Class Initialized
INFO - 2020-12-29 02:26:24 --> Helper loaded: url_helper
INFO - 2020-12-29 02:26:24 --> Helper loaded: file_helper
INFO - 2020-12-29 02:26:24 --> Helper loaded: form_helper
INFO - 2020-12-29 02:26:24 --> Helper loaded: my_helper
INFO - 2020-12-29 02:26:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:26:24 --> Controller Class Initialized
INFO - 2020-12-29 02:26:24 --> Final output sent to browser
DEBUG - 2020-12-29 02:26:24 --> Total execution time: 0.1237
INFO - 2020-12-29 02:26:25 --> Config Class Initialized
INFO - 2020-12-29 02:26:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:26:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:26:25 --> Utf8 Class Initialized
INFO - 2020-12-29 02:26:25 --> URI Class Initialized
INFO - 2020-12-29 02:26:25 --> Router Class Initialized
INFO - 2020-12-29 02:26:25 --> Output Class Initialized
INFO - 2020-12-29 02:26:25 --> Security Class Initialized
DEBUG - 2020-12-29 02:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:26:25 --> Input Class Initialized
INFO - 2020-12-29 02:26:25 --> Language Class Initialized
INFO - 2020-12-29 02:26:25 --> Language Class Initialized
INFO - 2020-12-29 02:26:25 --> Config Class Initialized
INFO - 2020-12-29 02:26:25 --> Loader Class Initialized
INFO - 2020-12-29 02:26:25 --> Helper loaded: url_helper
INFO - 2020-12-29 02:26:25 --> Helper loaded: file_helper
INFO - 2020-12-29 02:26:25 --> Helper loaded: form_helper
INFO - 2020-12-29 02:26:25 --> Helper loaded: my_helper
INFO - 2020-12-29 02:26:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:26:25 --> Controller Class Initialized
INFO - 2020-12-29 02:26:29 --> Config Class Initialized
INFO - 2020-12-29 02:26:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:26:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:26:29 --> Utf8 Class Initialized
INFO - 2020-12-29 02:26:29 --> URI Class Initialized
INFO - 2020-12-29 02:26:29 --> Router Class Initialized
INFO - 2020-12-29 02:26:29 --> Output Class Initialized
INFO - 2020-12-29 02:26:29 --> Security Class Initialized
DEBUG - 2020-12-29 02:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:26:29 --> Input Class Initialized
INFO - 2020-12-29 02:26:29 --> Language Class Initialized
INFO - 2020-12-29 02:26:29 --> Language Class Initialized
INFO - 2020-12-29 02:26:29 --> Config Class Initialized
INFO - 2020-12-29 02:26:29 --> Loader Class Initialized
INFO - 2020-12-29 02:26:29 --> Helper loaded: url_helper
INFO - 2020-12-29 02:26:29 --> Helper loaded: file_helper
INFO - 2020-12-29 02:26:29 --> Helper loaded: form_helper
INFO - 2020-12-29 02:26:29 --> Helper loaded: my_helper
INFO - 2020-12-29 02:26:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:26:29 --> Controller Class Initialized
INFO - 2020-12-29 02:26:29 --> Final output sent to browser
DEBUG - 2020-12-29 02:26:29 --> Total execution time: 0.1346
INFO - 2020-12-29 02:26:29 --> Config Class Initialized
INFO - 2020-12-29 02:26:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:26:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:26:29 --> Utf8 Class Initialized
INFO - 2020-12-29 02:26:29 --> URI Class Initialized
INFO - 2020-12-29 02:26:29 --> Router Class Initialized
INFO - 2020-12-29 02:26:29 --> Output Class Initialized
INFO - 2020-12-29 02:26:29 --> Security Class Initialized
DEBUG - 2020-12-29 02:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:26:29 --> Input Class Initialized
INFO - 2020-12-29 02:26:29 --> Language Class Initialized
INFO - 2020-12-29 02:26:29 --> Language Class Initialized
INFO - 2020-12-29 02:26:29 --> Config Class Initialized
INFO - 2020-12-29 02:26:29 --> Loader Class Initialized
INFO - 2020-12-29 02:26:29 --> Helper loaded: url_helper
INFO - 2020-12-29 02:26:29 --> Helper loaded: file_helper
INFO - 2020-12-29 02:26:29 --> Helper loaded: form_helper
INFO - 2020-12-29 02:26:29 --> Helper loaded: my_helper
INFO - 2020-12-29 02:26:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:26:29 --> Controller Class Initialized
INFO - 2020-12-29 02:26:33 --> Config Class Initialized
INFO - 2020-12-29 02:26:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:26:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:26:33 --> Utf8 Class Initialized
INFO - 2020-12-29 02:26:33 --> URI Class Initialized
INFO - 2020-12-29 02:26:33 --> Router Class Initialized
INFO - 2020-12-29 02:26:33 --> Output Class Initialized
INFO - 2020-12-29 02:26:33 --> Security Class Initialized
DEBUG - 2020-12-29 02:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:26:33 --> Input Class Initialized
INFO - 2020-12-29 02:26:33 --> Language Class Initialized
INFO - 2020-12-29 02:26:33 --> Language Class Initialized
INFO - 2020-12-29 02:26:33 --> Config Class Initialized
INFO - 2020-12-29 02:26:33 --> Loader Class Initialized
INFO - 2020-12-29 02:26:33 --> Helper loaded: url_helper
INFO - 2020-12-29 02:26:33 --> Helper loaded: file_helper
INFO - 2020-12-29 02:26:33 --> Helper loaded: form_helper
INFO - 2020-12-29 02:26:33 --> Helper loaded: my_helper
INFO - 2020-12-29 02:26:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:26:33 --> Controller Class Initialized
DEBUG - 2020-12-29 02:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:26:33 --> Final output sent to browser
DEBUG - 2020-12-29 02:26:33 --> Total execution time: 0.1205
INFO - 2020-12-29 02:26:35 --> Config Class Initialized
INFO - 2020-12-29 02:26:35 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:26:35 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:26:35 --> Utf8 Class Initialized
INFO - 2020-12-29 02:26:35 --> URI Class Initialized
INFO - 2020-12-29 02:26:35 --> Router Class Initialized
INFO - 2020-12-29 02:26:35 --> Output Class Initialized
INFO - 2020-12-29 02:26:35 --> Security Class Initialized
DEBUG - 2020-12-29 02:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:26:35 --> Input Class Initialized
INFO - 2020-12-29 02:26:35 --> Language Class Initialized
INFO - 2020-12-29 02:26:35 --> Language Class Initialized
INFO - 2020-12-29 02:26:35 --> Config Class Initialized
INFO - 2020-12-29 02:26:35 --> Loader Class Initialized
INFO - 2020-12-29 02:26:35 --> Helper loaded: url_helper
INFO - 2020-12-29 02:26:35 --> Helper loaded: file_helper
INFO - 2020-12-29 02:26:35 --> Helper loaded: form_helper
INFO - 2020-12-29 02:26:35 --> Helper loaded: my_helper
INFO - 2020-12-29 02:26:35 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:26:35 --> Controller Class Initialized
DEBUG - 2020-12-29 02:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:26:35 --> Final output sent to browser
DEBUG - 2020-12-29 02:26:35 --> Total execution time: 0.1428
INFO - 2020-12-29 02:27:06 --> Config Class Initialized
INFO - 2020-12-29 02:27:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:27:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:27:06 --> Utf8 Class Initialized
INFO - 2020-12-29 02:27:06 --> URI Class Initialized
INFO - 2020-12-29 02:27:06 --> Router Class Initialized
INFO - 2020-12-29 02:27:06 --> Output Class Initialized
INFO - 2020-12-29 02:27:06 --> Security Class Initialized
DEBUG - 2020-12-29 02:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:27:06 --> Input Class Initialized
INFO - 2020-12-29 02:27:06 --> Language Class Initialized
INFO - 2020-12-29 02:27:06 --> Language Class Initialized
INFO - 2020-12-29 02:27:06 --> Config Class Initialized
INFO - 2020-12-29 02:27:06 --> Loader Class Initialized
INFO - 2020-12-29 02:27:06 --> Helper loaded: url_helper
INFO - 2020-12-29 02:27:06 --> Helper loaded: file_helper
INFO - 2020-12-29 02:27:06 --> Helper loaded: form_helper
INFO - 2020-12-29 02:27:06 --> Helper loaded: my_helper
INFO - 2020-12-29 02:27:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:27:07 --> Controller Class Initialized
INFO - 2020-12-29 02:27:07 --> Config Class Initialized
INFO - 2020-12-29 02:27:07 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:27:07 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:27:07 --> Utf8 Class Initialized
INFO - 2020-12-29 02:27:07 --> URI Class Initialized
INFO - 2020-12-29 02:27:07 --> Router Class Initialized
INFO - 2020-12-29 02:27:07 --> Output Class Initialized
INFO - 2020-12-29 02:27:07 --> Security Class Initialized
DEBUG - 2020-12-29 02:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:27:07 --> Input Class Initialized
INFO - 2020-12-29 02:27:07 --> Language Class Initialized
INFO - 2020-12-29 02:27:07 --> Language Class Initialized
INFO - 2020-12-29 02:27:07 --> Config Class Initialized
INFO - 2020-12-29 02:27:07 --> Loader Class Initialized
INFO - 2020-12-29 02:27:07 --> Helper loaded: url_helper
INFO - 2020-12-29 02:27:07 --> Helper loaded: file_helper
INFO - 2020-12-29 02:27:07 --> Helper loaded: form_helper
INFO - 2020-12-29 02:27:07 --> Helper loaded: my_helper
INFO - 2020-12-29 02:27:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:27:07 --> Controller Class Initialized
DEBUG - 2020-12-29 02:27:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:27:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:27:07 --> Final output sent to browser
DEBUG - 2020-12-29 02:27:07 --> Total execution time: 0.1360
INFO - 2020-12-29 02:34:17 --> Config Class Initialized
INFO - 2020-12-29 02:34:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:17 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:17 --> URI Class Initialized
INFO - 2020-12-29 02:34:17 --> Router Class Initialized
INFO - 2020-12-29 02:34:17 --> Output Class Initialized
INFO - 2020-12-29 02:34:17 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:17 --> Input Class Initialized
INFO - 2020-12-29 02:34:17 --> Language Class Initialized
INFO - 2020-12-29 02:34:17 --> Language Class Initialized
INFO - 2020-12-29 02:34:17 --> Config Class Initialized
INFO - 2020-12-29 02:34:17 --> Loader Class Initialized
INFO - 2020-12-29 02:34:17 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:17 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:17 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:17 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:17 --> Controller Class Initialized
DEBUG - 2020-12-29 02:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-12-29 02:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:34:17 --> Final output sent to browser
DEBUG - 2020-12-29 02:34:17 --> Total execution time: 0.2216
INFO - 2020-12-29 02:34:17 --> Config Class Initialized
INFO - 2020-12-29 02:34:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:17 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:17 --> URI Class Initialized
INFO - 2020-12-29 02:34:17 --> Router Class Initialized
INFO - 2020-12-29 02:34:17 --> Output Class Initialized
INFO - 2020-12-29 02:34:17 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:17 --> Input Class Initialized
INFO - 2020-12-29 02:34:17 --> Language Class Initialized
INFO - 2020-12-29 02:34:17 --> Language Class Initialized
INFO - 2020-12-29 02:34:17 --> Config Class Initialized
INFO - 2020-12-29 02:34:17 --> Loader Class Initialized
INFO - 2020-12-29 02:34:17 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:17 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:17 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:17 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:17 --> Controller Class Initialized
INFO - 2020-12-29 02:34:20 --> Config Class Initialized
INFO - 2020-12-29 02:34:20 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:20 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:20 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:20 --> URI Class Initialized
INFO - 2020-12-29 02:34:20 --> Router Class Initialized
INFO - 2020-12-29 02:34:20 --> Output Class Initialized
INFO - 2020-12-29 02:34:20 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:20 --> Input Class Initialized
INFO - 2020-12-29 02:34:20 --> Language Class Initialized
INFO - 2020-12-29 02:34:20 --> Language Class Initialized
INFO - 2020-12-29 02:34:21 --> Config Class Initialized
INFO - 2020-12-29 02:34:21 --> Loader Class Initialized
INFO - 2020-12-29 02:34:21 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:21 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:21 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:21 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:21 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:21 --> Controller Class Initialized
DEBUG - 2020-12-29 02:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-29 02:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:34:21 --> Final output sent to browser
DEBUG - 2020-12-29 02:34:21 --> Total execution time: 0.1766
INFO - 2020-12-29 02:34:21 --> Config Class Initialized
INFO - 2020-12-29 02:34:21 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:21 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:21 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:21 --> URI Class Initialized
INFO - 2020-12-29 02:34:21 --> Router Class Initialized
INFO - 2020-12-29 02:34:21 --> Output Class Initialized
INFO - 2020-12-29 02:34:21 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:21 --> Input Class Initialized
INFO - 2020-12-29 02:34:21 --> Language Class Initialized
INFO - 2020-12-29 02:34:21 --> Language Class Initialized
INFO - 2020-12-29 02:34:21 --> Config Class Initialized
INFO - 2020-12-29 02:34:21 --> Loader Class Initialized
INFO - 2020-12-29 02:34:21 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:21 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:21 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:21 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:21 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:21 --> Controller Class Initialized
INFO - 2020-12-29 02:34:23 --> Config Class Initialized
INFO - 2020-12-29 02:34:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:23 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:23 --> URI Class Initialized
INFO - 2020-12-29 02:34:23 --> Router Class Initialized
INFO - 2020-12-29 02:34:23 --> Output Class Initialized
INFO - 2020-12-29 02:34:23 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:23 --> Input Class Initialized
INFO - 2020-12-29 02:34:23 --> Language Class Initialized
INFO - 2020-12-29 02:34:23 --> Language Class Initialized
INFO - 2020-12-29 02:34:23 --> Config Class Initialized
INFO - 2020-12-29 02:34:23 --> Loader Class Initialized
INFO - 2020-12-29 02:34:23 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:23 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:23 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:23 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:23 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:23 --> Controller Class Initialized
DEBUG - 2020-12-29 02:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-12-29 02:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:34:23 --> Final output sent to browser
DEBUG - 2020-12-29 02:34:23 --> Total execution time: 0.2044
INFO - 2020-12-29 02:34:23 --> Config Class Initialized
INFO - 2020-12-29 02:34:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:23 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:23 --> URI Class Initialized
INFO - 2020-12-29 02:34:23 --> Router Class Initialized
INFO - 2020-12-29 02:34:23 --> Output Class Initialized
INFO - 2020-12-29 02:34:23 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:23 --> Input Class Initialized
INFO - 2020-12-29 02:34:23 --> Language Class Initialized
INFO - 2020-12-29 02:34:23 --> Language Class Initialized
INFO - 2020-12-29 02:34:23 --> Config Class Initialized
INFO - 2020-12-29 02:34:23 --> Loader Class Initialized
INFO - 2020-12-29 02:34:23 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:23 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:23 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:23 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:23 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:23 --> Controller Class Initialized
INFO - 2020-12-29 02:34:23 --> Config Class Initialized
INFO - 2020-12-29 02:34:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:23 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:23 --> URI Class Initialized
INFO - 2020-12-29 02:34:23 --> Router Class Initialized
INFO - 2020-12-29 02:34:23 --> Output Class Initialized
INFO - 2020-12-29 02:34:23 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:24 --> Input Class Initialized
INFO - 2020-12-29 02:34:24 --> Language Class Initialized
INFO - 2020-12-29 02:34:24 --> Language Class Initialized
INFO - 2020-12-29 02:34:24 --> Config Class Initialized
INFO - 2020-12-29 02:34:24 --> Loader Class Initialized
INFO - 2020-12-29 02:34:24 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:24 --> Controller Class Initialized
DEBUG - 2020-12-29 02:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-12-29 02:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:34:24 --> Final output sent to browser
DEBUG - 2020-12-29 02:34:24 --> Total execution time: 0.1049
INFO - 2020-12-29 02:34:24 --> Config Class Initialized
INFO - 2020-12-29 02:34:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:24 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:24 --> URI Class Initialized
INFO - 2020-12-29 02:34:24 --> Router Class Initialized
INFO - 2020-12-29 02:34:24 --> Output Class Initialized
INFO - 2020-12-29 02:34:24 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:24 --> Input Class Initialized
INFO - 2020-12-29 02:34:24 --> Language Class Initialized
INFO - 2020-12-29 02:34:24 --> Language Class Initialized
INFO - 2020-12-29 02:34:24 --> Config Class Initialized
INFO - 2020-12-29 02:34:24 --> Loader Class Initialized
INFO - 2020-12-29 02:34:24 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:24 --> Controller Class Initialized
INFO - 2020-12-29 02:34:24 --> Config Class Initialized
INFO - 2020-12-29 02:34:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:24 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:24 --> URI Class Initialized
INFO - 2020-12-29 02:34:24 --> Router Class Initialized
INFO - 2020-12-29 02:34:24 --> Output Class Initialized
INFO - 2020-12-29 02:34:24 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:24 --> Input Class Initialized
INFO - 2020-12-29 02:34:24 --> Language Class Initialized
INFO - 2020-12-29 02:34:24 --> Language Class Initialized
INFO - 2020-12-29 02:34:24 --> Config Class Initialized
INFO - 2020-12-29 02:34:24 --> Loader Class Initialized
INFO - 2020-12-29 02:34:24 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:24 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:24 --> Controller Class Initialized
DEBUG - 2020-12-29 02:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:34:24 --> Final output sent to browser
DEBUG - 2020-12-29 02:34:24 --> Total execution time: 0.1211
INFO - 2020-12-29 02:34:26 --> Config Class Initialized
INFO - 2020-12-29 02:34:26 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:26 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:26 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:26 --> URI Class Initialized
INFO - 2020-12-29 02:34:26 --> Router Class Initialized
INFO - 2020-12-29 02:34:26 --> Output Class Initialized
INFO - 2020-12-29 02:34:26 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:26 --> Input Class Initialized
INFO - 2020-12-29 02:34:26 --> Language Class Initialized
INFO - 2020-12-29 02:34:26 --> Language Class Initialized
INFO - 2020-12-29 02:34:26 --> Config Class Initialized
INFO - 2020-12-29 02:34:26 --> Loader Class Initialized
INFO - 2020-12-29 02:34:26 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:26 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:26 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:26 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:26 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:26 --> Controller Class Initialized
DEBUG - 2020-12-29 02:34:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-29 02:34:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:34:26 --> Final output sent to browser
DEBUG - 2020-12-29 02:34:26 --> Total execution time: 0.1783
INFO - 2020-12-29 02:34:26 --> Config Class Initialized
INFO - 2020-12-29 02:34:26 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:34:26 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:34:26 --> Utf8 Class Initialized
INFO - 2020-12-29 02:34:26 --> URI Class Initialized
INFO - 2020-12-29 02:34:26 --> Router Class Initialized
INFO - 2020-12-29 02:34:26 --> Output Class Initialized
INFO - 2020-12-29 02:34:26 --> Security Class Initialized
DEBUG - 2020-12-29 02:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:34:26 --> Input Class Initialized
INFO - 2020-12-29 02:34:26 --> Language Class Initialized
INFO - 2020-12-29 02:34:26 --> Language Class Initialized
INFO - 2020-12-29 02:34:26 --> Config Class Initialized
INFO - 2020-12-29 02:34:26 --> Loader Class Initialized
INFO - 2020-12-29 02:34:26 --> Helper loaded: url_helper
INFO - 2020-12-29 02:34:26 --> Helper loaded: file_helper
INFO - 2020-12-29 02:34:26 --> Helper loaded: form_helper
INFO - 2020-12-29 02:34:26 --> Helper loaded: my_helper
INFO - 2020-12-29 02:34:26 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:34:26 --> Controller Class Initialized
INFO - 2020-12-29 02:36:23 --> Config Class Initialized
INFO - 2020-12-29 02:36:23 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:36:23 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:36:23 --> Utf8 Class Initialized
INFO - 2020-12-29 02:36:23 --> URI Class Initialized
INFO - 2020-12-29 02:36:23 --> Router Class Initialized
INFO - 2020-12-29 02:36:23 --> Output Class Initialized
INFO - 2020-12-29 02:36:23 --> Security Class Initialized
DEBUG - 2020-12-29 02:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:36:23 --> Input Class Initialized
INFO - 2020-12-29 02:36:23 --> Language Class Initialized
INFO - 2020-12-29 02:36:23 --> Language Class Initialized
INFO - 2020-12-29 02:36:23 --> Config Class Initialized
INFO - 2020-12-29 02:36:23 --> Loader Class Initialized
INFO - 2020-12-29 02:36:23 --> Helper loaded: url_helper
INFO - 2020-12-29 02:36:23 --> Helper loaded: file_helper
INFO - 2020-12-29 02:36:23 --> Helper loaded: form_helper
INFO - 2020-12-29 02:36:23 --> Helper loaded: my_helper
INFO - 2020-12-29 02:36:23 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:36:23 --> Controller Class Initialized
DEBUG - 2020-12-29 02:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:36:23 --> Final output sent to browser
DEBUG - 2020-12-29 02:36:23 --> Total execution time: 0.1629
INFO - 2020-12-29 02:36:29 --> Config Class Initialized
INFO - 2020-12-29 02:36:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:36:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:36:29 --> Utf8 Class Initialized
INFO - 2020-12-29 02:36:29 --> URI Class Initialized
INFO - 2020-12-29 02:36:29 --> Router Class Initialized
INFO - 2020-12-29 02:36:29 --> Output Class Initialized
INFO - 2020-12-29 02:36:29 --> Security Class Initialized
DEBUG - 2020-12-29 02:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:36:29 --> Input Class Initialized
INFO - 2020-12-29 02:36:29 --> Language Class Initialized
INFO - 2020-12-29 02:36:29 --> Language Class Initialized
INFO - 2020-12-29 02:36:29 --> Config Class Initialized
INFO - 2020-12-29 02:36:29 --> Loader Class Initialized
INFO - 2020-12-29 02:36:29 --> Helper loaded: url_helper
INFO - 2020-12-29 02:36:29 --> Helper loaded: file_helper
INFO - 2020-12-29 02:36:29 --> Helper loaded: form_helper
INFO - 2020-12-29 02:36:29 --> Helper loaded: my_helper
INFO - 2020-12-29 02:36:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:36:29 --> Controller Class Initialized
DEBUG - 2020-12-29 02:36:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-12-29 02:36:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:36:29 --> Final output sent to browser
DEBUG - 2020-12-29 02:36:29 --> Total execution time: 0.1169
INFO - 2020-12-29 02:36:29 --> Config Class Initialized
INFO - 2020-12-29 02:36:29 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:36:29 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:36:29 --> Utf8 Class Initialized
INFO - 2020-12-29 02:36:29 --> URI Class Initialized
INFO - 2020-12-29 02:36:29 --> Router Class Initialized
INFO - 2020-12-29 02:36:29 --> Output Class Initialized
INFO - 2020-12-29 02:36:29 --> Security Class Initialized
DEBUG - 2020-12-29 02:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:36:29 --> Input Class Initialized
INFO - 2020-12-29 02:36:29 --> Language Class Initialized
INFO - 2020-12-29 02:36:29 --> Language Class Initialized
INFO - 2020-12-29 02:36:29 --> Config Class Initialized
INFO - 2020-12-29 02:36:29 --> Loader Class Initialized
INFO - 2020-12-29 02:36:29 --> Helper loaded: url_helper
INFO - 2020-12-29 02:36:29 --> Helper loaded: file_helper
INFO - 2020-12-29 02:36:29 --> Helper loaded: form_helper
INFO - 2020-12-29 02:36:29 --> Helper loaded: my_helper
INFO - 2020-12-29 02:36:29 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:36:29 --> Controller Class Initialized
INFO - 2020-12-29 02:37:51 --> Config Class Initialized
INFO - 2020-12-29 02:37:51 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:37:51 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:37:51 --> Utf8 Class Initialized
INFO - 2020-12-29 02:37:51 --> URI Class Initialized
INFO - 2020-12-29 02:37:52 --> Router Class Initialized
INFO - 2020-12-29 02:37:52 --> Output Class Initialized
INFO - 2020-12-29 02:37:52 --> Security Class Initialized
DEBUG - 2020-12-29 02:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:37:52 --> Input Class Initialized
INFO - 2020-12-29 02:37:52 --> Language Class Initialized
INFO - 2020-12-29 02:37:52 --> Language Class Initialized
INFO - 2020-12-29 02:37:52 --> Config Class Initialized
INFO - 2020-12-29 02:37:52 --> Loader Class Initialized
INFO - 2020-12-29 02:37:52 --> Helper loaded: url_helper
INFO - 2020-12-29 02:37:52 --> Helper loaded: file_helper
INFO - 2020-12-29 02:37:52 --> Helper loaded: form_helper
INFO - 2020-12-29 02:37:52 --> Helper loaded: my_helper
INFO - 2020-12-29 02:37:52 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:37:52 --> Controller Class Initialized
INFO - 2020-12-29 02:37:52 --> Final output sent to browser
DEBUG - 2020-12-29 02:37:52 --> Total execution time: 0.1334
INFO - 2020-12-29 02:38:01 --> Config Class Initialized
INFO - 2020-12-29 02:38:01 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:38:01 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:38:01 --> Utf8 Class Initialized
INFO - 2020-12-29 02:38:01 --> URI Class Initialized
INFO - 2020-12-29 02:38:01 --> Router Class Initialized
INFO - 2020-12-29 02:38:01 --> Output Class Initialized
INFO - 2020-12-29 02:38:01 --> Security Class Initialized
DEBUG - 2020-12-29 02:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:38:01 --> Input Class Initialized
INFO - 2020-12-29 02:38:01 --> Language Class Initialized
INFO - 2020-12-29 02:38:01 --> Language Class Initialized
INFO - 2020-12-29 02:38:01 --> Config Class Initialized
INFO - 2020-12-29 02:38:01 --> Loader Class Initialized
INFO - 2020-12-29 02:38:01 --> Helper loaded: url_helper
INFO - 2020-12-29 02:38:01 --> Helper loaded: file_helper
INFO - 2020-12-29 02:38:01 --> Helper loaded: form_helper
INFO - 2020-12-29 02:38:01 --> Helper loaded: my_helper
INFO - 2020-12-29 02:38:01 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:38:01 --> Controller Class Initialized
INFO - 2020-12-29 02:38:01 --> Final output sent to browser
DEBUG - 2020-12-29 02:38:01 --> Total execution time: 0.1115
INFO - 2020-12-29 02:38:02 --> Config Class Initialized
INFO - 2020-12-29 02:38:02 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:38:02 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:38:02 --> Utf8 Class Initialized
INFO - 2020-12-29 02:38:02 --> URI Class Initialized
INFO - 2020-12-29 02:38:02 --> Router Class Initialized
INFO - 2020-12-29 02:38:02 --> Output Class Initialized
INFO - 2020-12-29 02:38:02 --> Security Class Initialized
DEBUG - 2020-12-29 02:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:38:02 --> Input Class Initialized
INFO - 2020-12-29 02:38:02 --> Language Class Initialized
INFO - 2020-12-29 02:38:02 --> Language Class Initialized
INFO - 2020-12-29 02:38:02 --> Config Class Initialized
INFO - 2020-12-29 02:38:02 --> Loader Class Initialized
INFO - 2020-12-29 02:38:02 --> Helper loaded: url_helper
INFO - 2020-12-29 02:38:02 --> Helper loaded: file_helper
INFO - 2020-12-29 02:38:02 --> Helper loaded: form_helper
INFO - 2020-12-29 02:38:02 --> Helper loaded: my_helper
INFO - 2020-12-29 02:38:02 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:38:02 --> Controller Class Initialized
INFO - 2020-12-29 02:39:47 --> Config Class Initialized
INFO - 2020-12-29 02:39:47 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:39:47 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:39:47 --> Utf8 Class Initialized
INFO - 2020-12-29 02:39:47 --> URI Class Initialized
INFO - 2020-12-29 02:39:47 --> Router Class Initialized
INFO - 2020-12-29 02:39:47 --> Output Class Initialized
INFO - 2020-12-29 02:39:47 --> Security Class Initialized
DEBUG - 2020-12-29 02:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:39:47 --> Input Class Initialized
INFO - 2020-12-29 02:39:47 --> Language Class Initialized
INFO - 2020-12-29 02:39:47 --> Language Class Initialized
INFO - 2020-12-29 02:39:47 --> Config Class Initialized
INFO - 2020-12-29 02:39:47 --> Loader Class Initialized
INFO - 2020-12-29 02:39:47 --> Helper loaded: url_helper
INFO - 2020-12-29 02:39:47 --> Helper loaded: file_helper
INFO - 2020-12-29 02:39:47 --> Helper loaded: form_helper
INFO - 2020-12-29 02:39:47 --> Helper loaded: my_helper
INFO - 2020-12-29 02:39:47 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:39:47 --> Controller Class Initialized
INFO - 2020-12-29 02:39:47 --> Final output sent to browser
DEBUG - 2020-12-29 02:39:47 --> Total execution time: 0.1351
INFO - 2020-12-29 02:39:54 --> Config Class Initialized
INFO - 2020-12-29 02:39:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:39:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:39:54 --> Utf8 Class Initialized
INFO - 2020-12-29 02:39:54 --> URI Class Initialized
INFO - 2020-12-29 02:39:54 --> Router Class Initialized
INFO - 2020-12-29 02:39:54 --> Output Class Initialized
INFO - 2020-12-29 02:39:54 --> Security Class Initialized
DEBUG - 2020-12-29 02:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:39:54 --> Input Class Initialized
INFO - 2020-12-29 02:39:54 --> Language Class Initialized
INFO - 2020-12-29 02:39:54 --> Language Class Initialized
INFO - 2020-12-29 02:39:54 --> Config Class Initialized
INFO - 2020-12-29 02:39:54 --> Loader Class Initialized
INFO - 2020-12-29 02:39:54 --> Helper loaded: url_helper
INFO - 2020-12-29 02:39:54 --> Helper loaded: file_helper
INFO - 2020-12-29 02:39:54 --> Helper loaded: form_helper
INFO - 2020-12-29 02:39:54 --> Helper loaded: my_helper
INFO - 2020-12-29 02:39:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:39:54 --> Controller Class Initialized
INFO - 2020-12-29 02:39:54 --> Final output sent to browser
DEBUG - 2020-12-29 02:39:54 --> Total execution time: 0.1141
INFO - 2020-12-29 02:39:54 --> Config Class Initialized
INFO - 2020-12-29 02:39:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:39:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:39:54 --> Utf8 Class Initialized
INFO - 2020-12-29 02:39:54 --> URI Class Initialized
INFO - 2020-12-29 02:39:54 --> Router Class Initialized
INFO - 2020-12-29 02:39:54 --> Output Class Initialized
INFO - 2020-12-29 02:39:54 --> Security Class Initialized
DEBUG - 2020-12-29 02:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:39:54 --> Input Class Initialized
INFO - 2020-12-29 02:39:54 --> Language Class Initialized
INFO - 2020-12-29 02:39:54 --> Language Class Initialized
INFO - 2020-12-29 02:39:54 --> Config Class Initialized
INFO - 2020-12-29 02:39:54 --> Loader Class Initialized
INFO - 2020-12-29 02:39:54 --> Helper loaded: url_helper
INFO - 2020-12-29 02:39:54 --> Helper loaded: file_helper
INFO - 2020-12-29 02:39:54 --> Helper loaded: form_helper
INFO - 2020-12-29 02:39:54 --> Helper loaded: my_helper
INFO - 2020-12-29 02:39:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:39:54 --> Controller Class Initialized
INFO - 2020-12-29 02:40:27 --> Config Class Initialized
INFO - 2020-12-29 02:40:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:27 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:27 --> URI Class Initialized
INFO - 2020-12-29 02:40:27 --> Router Class Initialized
INFO - 2020-12-29 02:40:27 --> Output Class Initialized
INFO - 2020-12-29 02:40:27 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:27 --> Input Class Initialized
INFO - 2020-12-29 02:40:27 --> Language Class Initialized
INFO - 2020-12-29 02:40:27 --> Language Class Initialized
INFO - 2020-12-29 02:40:27 --> Config Class Initialized
INFO - 2020-12-29 02:40:27 --> Loader Class Initialized
INFO - 2020-12-29 02:40:27 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:27 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:27 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:27 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:27 --> Controller Class Initialized
INFO - 2020-12-29 02:40:27 --> Final output sent to browser
DEBUG - 2020-12-29 02:40:27 --> Total execution time: 0.1538
INFO - 2020-12-29 02:40:50 --> Config Class Initialized
INFO - 2020-12-29 02:40:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:50 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:50 --> URI Class Initialized
INFO - 2020-12-29 02:40:50 --> Router Class Initialized
INFO - 2020-12-29 02:40:50 --> Output Class Initialized
INFO - 2020-12-29 02:40:50 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:50 --> Input Class Initialized
INFO - 2020-12-29 02:40:50 --> Language Class Initialized
INFO - 2020-12-29 02:40:50 --> Language Class Initialized
INFO - 2020-12-29 02:40:50 --> Config Class Initialized
INFO - 2020-12-29 02:40:50 --> Loader Class Initialized
INFO - 2020-12-29 02:40:50 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:50 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:50 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:50 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:50 --> Controller Class Initialized
INFO - 2020-12-29 02:40:50 --> Final output sent to browser
DEBUG - 2020-12-29 02:40:50 --> Total execution time: 0.1389
INFO - 2020-12-29 02:40:51 --> Config Class Initialized
INFO - 2020-12-29 02:40:51 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:51 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:51 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:51 --> URI Class Initialized
INFO - 2020-12-29 02:40:51 --> Router Class Initialized
INFO - 2020-12-29 02:40:51 --> Output Class Initialized
INFO - 2020-12-29 02:40:51 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:51 --> Input Class Initialized
INFO - 2020-12-29 02:40:51 --> Language Class Initialized
INFO - 2020-12-29 02:40:51 --> Language Class Initialized
INFO - 2020-12-29 02:40:51 --> Config Class Initialized
INFO - 2020-12-29 02:40:51 --> Loader Class Initialized
INFO - 2020-12-29 02:40:51 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:51 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:51 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:51 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:51 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:51 --> Controller Class Initialized
INFO - 2020-12-29 02:40:54 --> Config Class Initialized
INFO - 2020-12-29 02:40:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:40:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:40:54 --> Utf8 Class Initialized
INFO - 2020-12-29 02:40:54 --> URI Class Initialized
INFO - 2020-12-29 02:40:54 --> Router Class Initialized
INFO - 2020-12-29 02:40:54 --> Output Class Initialized
INFO - 2020-12-29 02:40:54 --> Security Class Initialized
DEBUG - 2020-12-29 02:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:40:54 --> Input Class Initialized
INFO - 2020-12-29 02:40:54 --> Language Class Initialized
INFO - 2020-12-29 02:40:54 --> Language Class Initialized
INFO - 2020-12-29 02:40:54 --> Config Class Initialized
INFO - 2020-12-29 02:40:54 --> Loader Class Initialized
INFO - 2020-12-29 02:40:54 --> Helper loaded: url_helper
INFO - 2020-12-29 02:40:54 --> Helper loaded: file_helper
INFO - 2020-12-29 02:40:54 --> Helper loaded: form_helper
INFO - 2020-12-29 02:40:54 --> Helper loaded: my_helper
INFO - 2020-12-29 02:40:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:40:54 --> Controller Class Initialized
INFO - 2020-12-29 02:40:54 --> Final output sent to browser
DEBUG - 2020-12-29 02:40:54 --> Total execution time: 0.1337
INFO - 2020-12-29 02:41:01 --> Config Class Initialized
INFO - 2020-12-29 02:41:01 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:41:01 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:41:01 --> Utf8 Class Initialized
INFO - 2020-12-29 02:41:01 --> URI Class Initialized
INFO - 2020-12-29 02:41:01 --> Router Class Initialized
INFO - 2020-12-29 02:41:01 --> Output Class Initialized
INFO - 2020-12-29 02:41:01 --> Security Class Initialized
DEBUG - 2020-12-29 02:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:41:01 --> Input Class Initialized
INFO - 2020-12-29 02:41:01 --> Language Class Initialized
INFO - 2020-12-29 02:41:01 --> Language Class Initialized
INFO - 2020-12-29 02:41:01 --> Config Class Initialized
INFO - 2020-12-29 02:41:01 --> Loader Class Initialized
INFO - 2020-12-29 02:41:01 --> Helper loaded: url_helper
INFO - 2020-12-29 02:41:01 --> Helper loaded: file_helper
INFO - 2020-12-29 02:41:01 --> Helper loaded: form_helper
INFO - 2020-12-29 02:41:01 --> Helper loaded: my_helper
INFO - 2020-12-29 02:41:01 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:41:01 --> Controller Class Initialized
INFO - 2020-12-29 02:41:01 --> Final output sent to browser
DEBUG - 2020-12-29 02:41:01 --> Total execution time: 0.1412
INFO - 2020-12-29 02:41:01 --> Config Class Initialized
INFO - 2020-12-29 02:41:01 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:41:01 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:41:01 --> Utf8 Class Initialized
INFO - 2020-12-29 02:41:01 --> URI Class Initialized
INFO - 2020-12-29 02:41:01 --> Router Class Initialized
INFO - 2020-12-29 02:41:01 --> Output Class Initialized
INFO - 2020-12-29 02:41:01 --> Security Class Initialized
DEBUG - 2020-12-29 02:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:41:01 --> Input Class Initialized
INFO - 2020-12-29 02:41:01 --> Language Class Initialized
INFO - 2020-12-29 02:41:01 --> Language Class Initialized
INFO - 2020-12-29 02:41:01 --> Config Class Initialized
INFO - 2020-12-29 02:41:01 --> Loader Class Initialized
INFO - 2020-12-29 02:41:01 --> Helper loaded: url_helper
INFO - 2020-12-29 02:41:01 --> Helper loaded: file_helper
INFO - 2020-12-29 02:41:01 --> Helper loaded: form_helper
INFO - 2020-12-29 02:41:01 --> Helper loaded: my_helper
INFO - 2020-12-29 02:41:02 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:41:02 --> Controller Class Initialized
INFO - 2020-12-29 02:41:06 --> Config Class Initialized
INFO - 2020-12-29 02:41:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:41:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:41:06 --> Utf8 Class Initialized
INFO - 2020-12-29 02:41:06 --> URI Class Initialized
INFO - 2020-12-29 02:41:06 --> Router Class Initialized
INFO - 2020-12-29 02:41:06 --> Output Class Initialized
INFO - 2020-12-29 02:41:06 --> Security Class Initialized
DEBUG - 2020-12-29 02:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:41:07 --> Input Class Initialized
INFO - 2020-12-29 02:41:07 --> Language Class Initialized
INFO - 2020-12-29 02:41:07 --> Language Class Initialized
INFO - 2020-12-29 02:41:07 --> Config Class Initialized
INFO - 2020-12-29 02:41:07 --> Loader Class Initialized
INFO - 2020-12-29 02:41:07 --> Helper loaded: url_helper
INFO - 2020-12-29 02:41:07 --> Helper loaded: file_helper
INFO - 2020-12-29 02:41:07 --> Helper loaded: form_helper
INFO - 2020-12-29 02:41:07 --> Helper loaded: my_helper
INFO - 2020-12-29 02:41:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:41:07 --> Controller Class Initialized
INFO - 2020-12-29 02:41:07 --> Final output sent to browser
DEBUG - 2020-12-29 02:41:07 --> Total execution time: 0.1068
INFO - 2020-12-29 02:41:17 --> Config Class Initialized
INFO - 2020-12-29 02:41:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:41:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:41:17 --> Utf8 Class Initialized
INFO - 2020-12-29 02:41:17 --> URI Class Initialized
INFO - 2020-12-29 02:41:17 --> Router Class Initialized
INFO - 2020-12-29 02:41:17 --> Output Class Initialized
INFO - 2020-12-29 02:41:17 --> Security Class Initialized
DEBUG - 2020-12-29 02:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:41:17 --> Input Class Initialized
INFO - 2020-12-29 02:41:17 --> Language Class Initialized
INFO - 2020-12-29 02:41:17 --> Language Class Initialized
INFO - 2020-12-29 02:41:17 --> Config Class Initialized
INFO - 2020-12-29 02:41:17 --> Loader Class Initialized
INFO - 2020-12-29 02:41:17 --> Helper loaded: url_helper
INFO - 2020-12-29 02:41:17 --> Helper loaded: file_helper
INFO - 2020-12-29 02:41:17 --> Helper loaded: form_helper
INFO - 2020-12-29 02:41:17 --> Helper loaded: my_helper
INFO - 2020-12-29 02:41:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:41:17 --> Controller Class Initialized
INFO - 2020-12-29 02:41:17 --> Final output sent to browser
DEBUG - 2020-12-29 02:41:17 --> Total execution time: 0.1097
INFO - 2020-12-29 02:41:17 --> Config Class Initialized
INFO - 2020-12-29 02:41:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:41:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:41:17 --> Utf8 Class Initialized
INFO - 2020-12-29 02:41:17 --> URI Class Initialized
INFO - 2020-12-29 02:41:17 --> Router Class Initialized
INFO - 2020-12-29 02:41:17 --> Output Class Initialized
INFO - 2020-12-29 02:41:17 --> Security Class Initialized
DEBUG - 2020-12-29 02:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:41:17 --> Input Class Initialized
INFO - 2020-12-29 02:41:17 --> Language Class Initialized
INFO - 2020-12-29 02:41:17 --> Language Class Initialized
INFO - 2020-12-29 02:41:17 --> Config Class Initialized
INFO - 2020-12-29 02:41:17 --> Loader Class Initialized
INFO - 2020-12-29 02:41:17 --> Helper loaded: url_helper
INFO - 2020-12-29 02:41:17 --> Helper loaded: file_helper
INFO - 2020-12-29 02:41:17 --> Helper loaded: form_helper
INFO - 2020-12-29 02:41:17 --> Helper loaded: my_helper
INFO - 2020-12-29 02:41:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:41:17 --> Controller Class Initialized
INFO - 2020-12-29 02:41:19 --> Config Class Initialized
INFO - 2020-12-29 02:41:19 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:41:19 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:41:19 --> Utf8 Class Initialized
INFO - 2020-12-29 02:41:19 --> URI Class Initialized
INFO - 2020-12-29 02:41:19 --> Router Class Initialized
INFO - 2020-12-29 02:41:19 --> Output Class Initialized
INFO - 2020-12-29 02:41:19 --> Security Class Initialized
DEBUG - 2020-12-29 02:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:41:19 --> Input Class Initialized
INFO - 2020-12-29 02:41:19 --> Language Class Initialized
INFO - 2020-12-29 02:41:19 --> Language Class Initialized
INFO - 2020-12-29 02:41:19 --> Config Class Initialized
INFO - 2020-12-29 02:41:19 --> Loader Class Initialized
INFO - 2020-12-29 02:41:19 --> Helper loaded: url_helper
INFO - 2020-12-29 02:41:19 --> Helper loaded: file_helper
INFO - 2020-12-29 02:41:19 --> Helper loaded: form_helper
INFO - 2020-12-29 02:41:19 --> Helper loaded: my_helper
INFO - 2020-12-29 02:41:19 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:41:19 --> Controller Class Initialized
INFO - 2020-12-29 02:41:19 --> Final output sent to browser
DEBUG - 2020-12-29 02:41:19 --> Total execution time: 0.1254
INFO - 2020-12-29 02:42:18 --> Config Class Initialized
INFO - 2020-12-29 02:42:18 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:18 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:18 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:18 --> URI Class Initialized
INFO - 2020-12-29 02:42:18 --> Router Class Initialized
INFO - 2020-12-29 02:42:18 --> Output Class Initialized
INFO - 2020-12-29 02:42:18 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:18 --> Input Class Initialized
INFO - 2020-12-29 02:42:18 --> Language Class Initialized
INFO - 2020-12-29 02:42:18 --> Language Class Initialized
INFO - 2020-12-29 02:42:18 --> Config Class Initialized
INFO - 2020-12-29 02:42:18 --> Loader Class Initialized
INFO - 2020-12-29 02:42:18 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:18 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:18 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:18 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:18 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:18 --> Controller Class Initialized
INFO - 2020-12-29 02:42:18 --> Final output sent to browser
DEBUG - 2020-12-29 02:42:18 --> Total execution time: 0.0734
INFO - 2020-12-29 02:42:18 --> Config Class Initialized
INFO - 2020-12-29 02:42:18 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:18 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:18 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:18 --> URI Class Initialized
INFO - 2020-12-29 02:42:18 --> Router Class Initialized
INFO - 2020-12-29 02:42:18 --> Output Class Initialized
INFO - 2020-12-29 02:42:18 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:18 --> Input Class Initialized
INFO - 2020-12-29 02:42:18 --> Language Class Initialized
INFO - 2020-12-29 02:42:18 --> Language Class Initialized
INFO - 2020-12-29 02:42:18 --> Config Class Initialized
INFO - 2020-12-29 02:42:18 --> Loader Class Initialized
INFO - 2020-12-29 02:42:18 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:18 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:18 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:18 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:18 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:18 --> Controller Class Initialized
INFO - 2020-12-29 02:42:27 --> Config Class Initialized
INFO - 2020-12-29 02:42:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:27 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:27 --> URI Class Initialized
INFO - 2020-12-29 02:42:27 --> Router Class Initialized
INFO - 2020-12-29 02:42:27 --> Output Class Initialized
INFO - 2020-12-29 02:42:27 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:27 --> Input Class Initialized
INFO - 2020-12-29 02:42:27 --> Language Class Initialized
INFO - 2020-12-29 02:42:27 --> Language Class Initialized
INFO - 2020-12-29 02:42:27 --> Config Class Initialized
INFO - 2020-12-29 02:42:27 --> Loader Class Initialized
INFO - 2020-12-29 02:42:27 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:27 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:27 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:27 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:27 --> Controller Class Initialized
INFO - 2020-12-29 02:42:27 --> Final output sent to browser
DEBUG - 2020-12-29 02:42:27 --> Total execution time: 0.0849
INFO - 2020-12-29 02:42:33 --> Config Class Initialized
INFO - 2020-12-29 02:42:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:33 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:33 --> URI Class Initialized
INFO - 2020-12-29 02:42:33 --> Router Class Initialized
INFO - 2020-12-29 02:42:33 --> Output Class Initialized
INFO - 2020-12-29 02:42:33 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:33 --> Input Class Initialized
INFO - 2020-12-29 02:42:33 --> Language Class Initialized
INFO - 2020-12-29 02:42:33 --> Language Class Initialized
INFO - 2020-12-29 02:42:33 --> Config Class Initialized
INFO - 2020-12-29 02:42:33 --> Loader Class Initialized
INFO - 2020-12-29 02:42:33 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:33 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:33 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:33 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:33 --> Controller Class Initialized
INFO - 2020-12-29 02:42:33 --> Final output sent to browser
DEBUG - 2020-12-29 02:42:33 --> Total execution time: 0.0696
INFO - 2020-12-29 02:42:33 --> Config Class Initialized
INFO - 2020-12-29 02:42:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:33 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:33 --> URI Class Initialized
INFO - 2020-12-29 02:42:33 --> Router Class Initialized
INFO - 2020-12-29 02:42:34 --> Output Class Initialized
INFO - 2020-12-29 02:42:34 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:34 --> Input Class Initialized
INFO - 2020-12-29 02:42:34 --> Language Class Initialized
INFO - 2020-12-29 02:42:34 --> Language Class Initialized
INFO - 2020-12-29 02:42:34 --> Config Class Initialized
INFO - 2020-12-29 02:42:34 --> Loader Class Initialized
INFO - 2020-12-29 02:42:34 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:34 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:34 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:34 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:34 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:34 --> Controller Class Initialized
INFO - 2020-12-29 02:42:38 --> Config Class Initialized
INFO - 2020-12-29 02:42:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:38 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:38 --> URI Class Initialized
INFO - 2020-12-29 02:42:38 --> Router Class Initialized
INFO - 2020-12-29 02:42:38 --> Output Class Initialized
INFO - 2020-12-29 02:42:38 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:38 --> Input Class Initialized
INFO - 2020-12-29 02:42:38 --> Language Class Initialized
INFO - 2020-12-29 02:42:38 --> Language Class Initialized
INFO - 2020-12-29 02:42:38 --> Config Class Initialized
INFO - 2020-12-29 02:42:38 --> Loader Class Initialized
INFO - 2020-12-29 02:42:38 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:38 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:38 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:38 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:38 --> Controller Class Initialized
INFO - 2020-12-29 02:42:38 --> Final output sent to browser
DEBUG - 2020-12-29 02:42:38 --> Total execution time: 0.0675
INFO - 2020-12-29 02:42:52 --> Config Class Initialized
INFO - 2020-12-29 02:42:52 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:52 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:52 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:52 --> URI Class Initialized
INFO - 2020-12-29 02:42:52 --> Router Class Initialized
INFO - 2020-12-29 02:42:52 --> Output Class Initialized
INFO - 2020-12-29 02:42:52 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:52 --> Input Class Initialized
INFO - 2020-12-29 02:42:52 --> Language Class Initialized
INFO - 2020-12-29 02:42:52 --> Language Class Initialized
INFO - 2020-12-29 02:42:52 --> Config Class Initialized
INFO - 2020-12-29 02:42:52 --> Loader Class Initialized
INFO - 2020-12-29 02:42:52 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:52 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:52 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:52 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:52 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:52 --> Controller Class Initialized
INFO - 2020-12-29 02:42:52 --> Final output sent to browser
DEBUG - 2020-12-29 02:42:52 --> Total execution time: 0.0638
INFO - 2020-12-29 02:42:52 --> Config Class Initialized
INFO - 2020-12-29 02:42:52 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:52 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:52 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:52 --> URI Class Initialized
INFO - 2020-12-29 02:42:52 --> Router Class Initialized
INFO - 2020-12-29 02:42:52 --> Output Class Initialized
INFO - 2020-12-29 02:42:52 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:52 --> Input Class Initialized
INFO - 2020-12-29 02:42:52 --> Language Class Initialized
INFO - 2020-12-29 02:42:52 --> Language Class Initialized
INFO - 2020-12-29 02:42:52 --> Config Class Initialized
INFO - 2020-12-29 02:42:52 --> Loader Class Initialized
INFO - 2020-12-29 02:42:52 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:52 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:52 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:52 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:52 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:52 --> Controller Class Initialized
INFO - 2020-12-29 02:42:53 --> Config Class Initialized
INFO - 2020-12-29 02:42:53 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:53 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:53 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:53 --> URI Class Initialized
INFO - 2020-12-29 02:42:53 --> Router Class Initialized
INFO - 2020-12-29 02:42:53 --> Output Class Initialized
INFO - 2020-12-29 02:42:53 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:53 --> Input Class Initialized
INFO - 2020-12-29 02:42:53 --> Language Class Initialized
INFO - 2020-12-29 02:42:53 --> Language Class Initialized
INFO - 2020-12-29 02:42:53 --> Config Class Initialized
INFO - 2020-12-29 02:42:53 --> Loader Class Initialized
INFO - 2020-12-29 02:42:53 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:53 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:53 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:53 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:53 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:53 --> Controller Class Initialized
INFO - 2020-12-29 02:42:53 --> Final output sent to browser
DEBUG - 2020-12-29 02:42:53 --> Total execution time: 0.0911
INFO - 2020-12-29 02:42:57 --> Config Class Initialized
INFO - 2020-12-29 02:42:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:57 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:57 --> URI Class Initialized
INFO - 2020-12-29 02:42:57 --> Router Class Initialized
INFO - 2020-12-29 02:42:57 --> Output Class Initialized
INFO - 2020-12-29 02:42:57 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:57 --> Input Class Initialized
INFO - 2020-12-29 02:42:57 --> Language Class Initialized
INFO - 2020-12-29 02:42:57 --> Language Class Initialized
INFO - 2020-12-29 02:42:57 --> Config Class Initialized
INFO - 2020-12-29 02:42:57 --> Loader Class Initialized
INFO - 2020-12-29 02:42:57 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:57 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:57 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:57 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:57 --> Controller Class Initialized
INFO - 2020-12-29 02:42:57 --> Final output sent to browser
DEBUG - 2020-12-29 02:42:57 --> Total execution time: 0.0780
INFO - 2020-12-29 02:42:57 --> Config Class Initialized
INFO - 2020-12-29 02:42:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:57 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:57 --> URI Class Initialized
INFO - 2020-12-29 02:42:57 --> Router Class Initialized
INFO - 2020-12-29 02:42:57 --> Output Class Initialized
INFO - 2020-12-29 02:42:57 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:57 --> Input Class Initialized
INFO - 2020-12-29 02:42:57 --> Language Class Initialized
INFO - 2020-12-29 02:42:57 --> Language Class Initialized
INFO - 2020-12-29 02:42:57 --> Config Class Initialized
INFO - 2020-12-29 02:42:57 --> Loader Class Initialized
INFO - 2020-12-29 02:42:57 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:57 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:57 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:57 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:57 --> Controller Class Initialized
INFO - 2020-12-29 02:42:59 --> Config Class Initialized
INFO - 2020-12-29 02:42:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:42:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:42:59 --> Utf8 Class Initialized
INFO - 2020-12-29 02:42:59 --> URI Class Initialized
INFO - 2020-12-29 02:42:59 --> Router Class Initialized
INFO - 2020-12-29 02:42:59 --> Output Class Initialized
INFO - 2020-12-29 02:42:59 --> Security Class Initialized
DEBUG - 2020-12-29 02:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:42:59 --> Input Class Initialized
INFO - 2020-12-29 02:42:59 --> Language Class Initialized
INFO - 2020-12-29 02:42:59 --> Language Class Initialized
INFO - 2020-12-29 02:42:59 --> Config Class Initialized
INFO - 2020-12-29 02:42:59 --> Loader Class Initialized
INFO - 2020-12-29 02:42:59 --> Helper loaded: url_helper
INFO - 2020-12-29 02:42:59 --> Helper loaded: file_helper
INFO - 2020-12-29 02:42:59 --> Helper loaded: form_helper
INFO - 2020-12-29 02:42:59 --> Helper loaded: my_helper
INFO - 2020-12-29 02:42:59 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:42:59 --> Controller Class Initialized
INFO - 2020-12-29 02:42:59 --> Final output sent to browser
DEBUG - 2020-12-29 02:42:59 --> Total execution time: 0.0825
INFO - 2020-12-29 02:43:03 --> Config Class Initialized
INFO - 2020-12-29 02:43:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:03 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:03 --> URI Class Initialized
INFO - 2020-12-29 02:43:03 --> Router Class Initialized
INFO - 2020-12-29 02:43:03 --> Output Class Initialized
INFO - 2020-12-29 02:43:03 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:03 --> Input Class Initialized
INFO - 2020-12-29 02:43:03 --> Language Class Initialized
INFO - 2020-12-29 02:43:03 --> Language Class Initialized
INFO - 2020-12-29 02:43:03 --> Config Class Initialized
INFO - 2020-12-29 02:43:03 --> Loader Class Initialized
INFO - 2020-12-29 02:43:03 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:03 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:03 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:03 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:03 --> Controller Class Initialized
INFO - 2020-12-29 02:43:03 --> Final output sent to browser
DEBUG - 2020-12-29 02:43:03 --> Total execution time: 0.0739
INFO - 2020-12-29 02:43:03 --> Config Class Initialized
INFO - 2020-12-29 02:43:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:03 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:03 --> URI Class Initialized
INFO - 2020-12-29 02:43:03 --> Router Class Initialized
INFO - 2020-12-29 02:43:03 --> Output Class Initialized
INFO - 2020-12-29 02:43:03 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:03 --> Input Class Initialized
INFO - 2020-12-29 02:43:03 --> Language Class Initialized
INFO - 2020-12-29 02:43:03 --> Language Class Initialized
INFO - 2020-12-29 02:43:03 --> Config Class Initialized
INFO - 2020-12-29 02:43:03 --> Loader Class Initialized
INFO - 2020-12-29 02:43:03 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:03 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:03 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:03 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:03 --> Controller Class Initialized
INFO - 2020-12-29 02:43:05 --> Config Class Initialized
INFO - 2020-12-29 02:43:05 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:05 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:05 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:05 --> URI Class Initialized
INFO - 2020-12-29 02:43:05 --> Router Class Initialized
INFO - 2020-12-29 02:43:05 --> Output Class Initialized
INFO - 2020-12-29 02:43:05 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:05 --> Input Class Initialized
INFO - 2020-12-29 02:43:05 --> Language Class Initialized
INFO - 2020-12-29 02:43:05 --> Language Class Initialized
INFO - 2020-12-29 02:43:05 --> Config Class Initialized
INFO - 2020-12-29 02:43:05 --> Loader Class Initialized
INFO - 2020-12-29 02:43:05 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:05 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:05 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:05 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:05 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:05 --> Controller Class Initialized
INFO - 2020-12-29 02:43:05 --> Final output sent to browser
DEBUG - 2020-12-29 02:43:05 --> Total execution time: 0.0732
INFO - 2020-12-29 02:43:15 --> Config Class Initialized
INFO - 2020-12-29 02:43:15 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:15 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:15 --> URI Class Initialized
INFO - 2020-12-29 02:43:15 --> Router Class Initialized
INFO - 2020-12-29 02:43:15 --> Output Class Initialized
INFO - 2020-12-29 02:43:15 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:15 --> Input Class Initialized
INFO - 2020-12-29 02:43:15 --> Language Class Initialized
INFO - 2020-12-29 02:43:15 --> Language Class Initialized
INFO - 2020-12-29 02:43:15 --> Config Class Initialized
INFO - 2020-12-29 02:43:15 --> Loader Class Initialized
INFO - 2020-12-29 02:43:15 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:15 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:15 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:15 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:15 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:15 --> Controller Class Initialized
INFO - 2020-12-29 02:43:15 --> Final output sent to browser
DEBUG - 2020-12-29 02:43:15 --> Total execution time: 0.0835
INFO - 2020-12-29 02:43:15 --> Config Class Initialized
INFO - 2020-12-29 02:43:15 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:15 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:15 --> URI Class Initialized
INFO - 2020-12-29 02:43:15 --> Router Class Initialized
INFO - 2020-12-29 02:43:15 --> Output Class Initialized
INFO - 2020-12-29 02:43:15 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:15 --> Input Class Initialized
INFO - 2020-12-29 02:43:15 --> Language Class Initialized
INFO - 2020-12-29 02:43:15 --> Language Class Initialized
INFO - 2020-12-29 02:43:15 --> Config Class Initialized
INFO - 2020-12-29 02:43:15 --> Loader Class Initialized
INFO - 2020-12-29 02:43:15 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:15 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:15 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:15 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:15 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:15 --> Controller Class Initialized
INFO - 2020-12-29 02:43:16 --> Config Class Initialized
INFO - 2020-12-29 02:43:16 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:16 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:16 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:16 --> URI Class Initialized
INFO - 2020-12-29 02:43:16 --> Router Class Initialized
INFO - 2020-12-29 02:43:16 --> Output Class Initialized
INFO - 2020-12-29 02:43:16 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:16 --> Input Class Initialized
INFO - 2020-12-29 02:43:16 --> Language Class Initialized
INFO - 2020-12-29 02:43:16 --> Language Class Initialized
INFO - 2020-12-29 02:43:16 --> Config Class Initialized
INFO - 2020-12-29 02:43:16 --> Loader Class Initialized
INFO - 2020-12-29 02:43:16 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:16 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:16 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:16 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:16 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:16 --> Controller Class Initialized
INFO - 2020-12-29 02:43:16 --> Final output sent to browser
DEBUG - 2020-12-29 02:43:16 --> Total execution time: 0.0963
INFO - 2020-12-29 02:43:30 --> Config Class Initialized
INFO - 2020-12-29 02:43:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:30 --> URI Class Initialized
INFO - 2020-12-29 02:43:30 --> Router Class Initialized
INFO - 2020-12-29 02:43:30 --> Output Class Initialized
INFO - 2020-12-29 02:43:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:30 --> Input Class Initialized
INFO - 2020-12-29 02:43:30 --> Language Class Initialized
INFO - 2020-12-29 02:43:30 --> Language Class Initialized
INFO - 2020-12-29 02:43:30 --> Config Class Initialized
INFO - 2020-12-29 02:43:30 --> Loader Class Initialized
INFO - 2020-12-29 02:43:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:30 --> Controller Class Initialized
INFO - 2020-12-29 02:43:30 --> Final output sent to browser
DEBUG - 2020-12-29 02:43:30 --> Total execution time: 0.0753
INFO - 2020-12-29 02:43:30 --> Config Class Initialized
INFO - 2020-12-29 02:43:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:30 --> URI Class Initialized
INFO - 2020-12-29 02:43:30 --> Router Class Initialized
INFO - 2020-12-29 02:43:30 --> Output Class Initialized
INFO - 2020-12-29 02:43:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:30 --> Input Class Initialized
INFO - 2020-12-29 02:43:30 --> Language Class Initialized
INFO - 2020-12-29 02:43:30 --> Language Class Initialized
INFO - 2020-12-29 02:43:30 --> Config Class Initialized
INFO - 2020-12-29 02:43:30 --> Loader Class Initialized
INFO - 2020-12-29 02:43:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:30 --> Controller Class Initialized
INFO - 2020-12-29 02:43:32 --> Config Class Initialized
INFO - 2020-12-29 02:43:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:32 --> URI Class Initialized
INFO - 2020-12-29 02:43:32 --> Router Class Initialized
INFO - 2020-12-29 02:43:32 --> Output Class Initialized
INFO - 2020-12-29 02:43:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:32 --> Input Class Initialized
INFO - 2020-12-29 02:43:32 --> Language Class Initialized
INFO - 2020-12-29 02:43:32 --> Language Class Initialized
INFO - 2020-12-29 02:43:32 --> Config Class Initialized
INFO - 2020-12-29 02:43:32 --> Loader Class Initialized
INFO - 2020-12-29 02:43:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:32 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:32 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:32 --> Controller Class Initialized
INFO - 2020-12-29 02:43:32 --> Final output sent to browser
DEBUG - 2020-12-29 02:43:32 --> Total execution time: 0.0637
INFO - 2020-12-29 02:43:39 --> Config Class Initialized
INFO - 2020-12-29 02:43:39 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:39 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:39 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:39 --> URI Class Initialized
INFO - 2020-12-29 02:43:39 --> Router Class Initialized
INFO - 2020-12-29 02:43:39 --> Output Class Initialized
INFO - 2020-12-29 02:43:39 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:39 --> Input Class Initialized
INFO - 2020-12-29 02:43:39 --> Language Class Initialized
INFO - 2020-12-29 02:43:39 --> Language Class Initialized
INFO - 2020-12-29 02:43:39 --> Config Class Initialized
INFO - 2020-12-29 02:43:39 --> Loader Class Initialized
INFO - 2020-12-29 02:43:39 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:39 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:39 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:39 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:39 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:39 --> Controller Class Initialized
INFO - 2020-12-29 02:43:39 --> Final output sent to browser
DEBUG - 2020-12-29 02:43:39 --> Total execution time: 0.0729
INFO - 2020-12-29 02:43:39 --> Config Class Initialized
INFO - 2020-12-29 02:43:39 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:39 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:39 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:39 --> URI Class Initialized
INFO - 2020-12-29 02:43:39 --> Router Class Initialized
INFO - 2020-12-29 02:43:39 --> Output Class Initialized
INFO - 2020-12-29 02:43:39 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:39 --> Input Class Initialized
INFO - 2020-12-29 02:43:39 --> Language Class Initialized
INFO - 2020-12-29 02:43:39 --> Language Class Initialized
INFO - 2020-12-29 02:43:39 --> Config Class Initialized
INFO - 2020-12-29 02:43:39 --> Loader Class Initialized
INFO - 2020-12-29 02:43:39 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:39 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:39 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:39 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:39 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:39 --> Controller Class Initialized
INFO - 2020-12-29 02:43:59 --> Config Class Initialized
INFO - 2020-12-29 02:43:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:43:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:43:59 --> Utf8 Class Initialized
INFO - 2020-12-29 02:43:59 --> URI Class Initialized
INFO - 2020-12-29 02:43:59 --> Router Class Initialized
INFO - 2020-12-29 02:43:59 --> Output Class Initialized
INFO - 2020-12-29 02:43:59 --> Security Class Initialized
DEBUG - 2020-12-29 02:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:43:59 --> Input Class Initialized
INFO - 2020-12-29 02:43:59 --> Language Class Initialized
INFO - 2020-12-29 02:43:59 --> Language Class Initialized
INFO - 2020-12-29 02:43:59 --> Config Class Initialized
INFO - 2020-12-29 02:43:59 --> Loader Class Initialized
INFO - 2020-12-29 02:43:59 --> Helper loaded: url_helper
INFO - 2020-12-29 02:43:59 --> Helper loaded: file_helper
INFO - 2020-12-29 02:43:59 --> Helper loaded: form_helper
INFO - 2020-12-29 02:43:59 --> Helper loaded: my_helper
INFO - 2020-12-29 02:43:59 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:43:59 --> Controller Class Initialized
INFO - 2020-12-29 02:43:59 --> Final output sent to browser
DEBUG - 2020-12-29 02:43:59 --> Total execution time: 0.0405
INFO - 2020-12-29 02:44:13 --> Config Class Initialized
INFO - 2020-12-29 02:44:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:13 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:13 --> URI Class Initialized
INFO - 2020-12-29 02:44:13 --> Router Class Initialized
INFO - 2020-12-29 02:44:13 --> Output Class Initialized
INFO - 2020-12-29 02:44:13 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:13 --> Input Class Initialized
INFO - 2020-12-29 02:44:13 --> Language Class Initialized
INFO - 2020-12-29 02:44:13 --> Language Class Initialized
INFO - 2020-12-29 02:44:13 --> Config Class Initialized
INFO - 2020-12-29 02:44:13 --> Loader Class Initialized
INFO - 2020-12-29 02:44:13 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:13 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:13 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:13 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:13 --> Controller Class Initialized
INFO - 2020-12-29 02:44:13 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:13 --> Total execution time: 0.0493
INFO - 2020-12-29 02:44:13 --> Config Class Initialized
INFO - 2020-12-29 02:44:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:13 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:13 --> URI Class Initialized
INFO - 2020-12-29 02:44:13 --> Router Class Initialized
INFO - 2020-12-29 02:44:13 --> Output Class Initialized
INFO - 2020-12-29 02:44:13 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:13 --> Input Class Initialized
INFO - 2020-12-29 02:44:13 --> Language Class Initialized
INFO - 2020-12-29 02:44:13 --> Language Class Initialized
INFO - 2020-12-29 02:44:13 --> Config Class Initialized
INFO - 2020-12-29 02:44:13 --> Loader Class Initialized
INFO - 2020-12-29 02:44:13 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:13 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:13 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:13 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:13 --> Controller Class Initialized
INFO - 2020-12-29 02:44:14 --> Config Class Initialized
INFO - 2020-12-29 02:44:14 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:14 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:14 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:14 --> URI Class Initialized
INFO - 2020-12-29 02:44:14 --> Router Class Initialized
INFO - 2020-12-29 02:44:14 --> Output Class Initialized
INFO - 2020-12-29 02:44:14 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:14 --> Input Class Initialized
INFO - 2020-12-29 02:44:14 --> Language Class Initialized
INFO - 2020-12-29 02:44:14 --> Language Class Initialized
INFO - 2020-12-29 02:44:14 --> Config Class Initialized
INFO - 2020-12-29 02:44:14 --> Loader Class Initialized
INFO - 2020-12-29 02:44:14 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:14 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:14 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:14 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:14 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:14 --> Controller Class Initialized
INFO - 2020-12-29 02:44:14 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:14 --> Total execution time: 0.0574
INFO - 2020-12-29 02:44:20 --> Config Class Initialized
INFO - 2020-12-29 02:44:20 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:20 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:20 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:20 --> URI Class Initialized
INFO - 2020-12-29 02:44:20 --> Router Class Initialized
INFO - 2020-12-29 02:44:20 --> Output Class Initialized
INFO - 2020-12-29 02:44:20 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:20 --> Input Class Initialized
INFO - 2020-12-29 02:44:20 --> Language Class Initialized
INFO - 2020-12-29 02:44:20 --> Language Class Initialized
INFO - 2020-12-29 02:44:20 --> Config Class Initialized
INFO - 2020-12-29 02:44:20 --> Loader Class Initialized
INFO - 2020-12-29 02:44:20 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:20 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:20 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:20 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:20 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:20 --> Controller Class Initialized
INFO - 2020-12-29 02:44:20 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:20 --> Total execution time: 0.0549
INFO - 2020-12-29 02:44:20 --> Config Class Initialized
INFO - 2020-12-29 02:44:20 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:20 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:20 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:20 --> URI Class Initialized
INFO - 2020-12-29 02:44:20 --> Router Class Initialized
INFO - 2020-12-29 02:44:20 --> Output Class Initialized
INFO - 2020-12-29 02:44:20 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:20 --> Input Class Initialized
INFO - 2020-12-29 02:44:20 --> Language Class Initialized
INFO - 2020-12-29 02:44:20 --> Language Class Initialized
INFO - 2020-12-29 02:44:20 --> Config Class Initialized
INFO - 2020-12-29 02:44:20 --> Loader Class Initialized
INFO - 2020-12-29 02:44:20 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:20 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:20 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:20 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:20 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:20 --> Controller Class Initialized
INFO - 2020-12-29 02:44:30 --> Config Class Initialized
INFO - 2020-12-29 02:44:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:30 --> URI Class Initialized
INFO - 2020-12-29 02:44:30 --> Router Class Initialized
INFO - 2020-12-29 02:44:30 --> Output Class Initialized
INFO - 2020-12-29 02:44:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:30 --> Input Class Initialized
INFO - 2020-12-29 02:44:30 --> Language Class Initialized
INFO - 2020-12-29 02:44:30 --> Language Class Initialized
INFO - 2020-12-29 02:44:30 --> Config Class Initialized
INFO - 2020-12-29 02:44:30 --> Loader Class Initialized
INFO - 2020-12-29 02:44:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:30 --> Controller Class Initialized
INFO - 2020-12-29 02:44:30 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:30 --> Total execution time: 0.0979
INFO - 2020-12-29 02:44:30 --> Config Class Initialized
INFO - 2020-12-29 02:44:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:30 --> URI Class Initialized
INFO - 2020-12-29 02:44:30 --> Router Class Initialized
INFO - 2020-12-29 02:44:30 --> Output Class Initialized
INFO - 2020-12-29 02:44:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:30 --> Input Class Initialized
INFO - 2020-12-29 02:44:30 --> Language Class Initialized
INFO - 2020-12-29 02:44:30 --> Language Class Initialized
INFO - 2020-12-29 02:44:30 --> Config Class Initialized
INFO - 2020-12-29 02:44:30 --> Loader Class Initialized
INFO - 2020-12-29 02:44:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:30 --> Controller Class Initialized
INFO - 2020-12-29 02:44:32 --> Config Class Initialized
INFO - 2020-12-29 02:44:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:32 --> URI Class Initialized
INFO - 2020-12-29 02:44:32 --> Router Class Initialized
INFO - 2020-12-29 02:44:32 --> Output Class Initialized
INFO - 2020-12-29 02:44:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:32 --> Input Class Initialized
INFO - 2020-12-29 02:44:32 --> Language Class Initialized
INFO - 2020-12-29 02:44:32 --> Language Class Initialized
INFO - 2020-12-29 02:44:32 --> Config Class Initialized
INFO - 2020-12-29 02:44:32 --> Loader Class Initialized
INFO - 2020-12-29 02:44:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:32 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:32 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:32 --> Controller Class Initialized
INFO - 2020-12-29 02:44:32 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:32 --> Total execution time: 0.0911
INFO - 2020-12-29 02:44:32 --> Config Class Initialized
INFO - 2020-12-29 02:44:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:32 --> URI Class Initialized
INFO - 2020-12-29 02:44:32 --> Router Class Initialized
INFO - 2020-12-29 02:44:32 --> Output Class Initialized
INFO - 2020-12-29 02:44:33 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:33 --> Input Class Initialized
INFO - 2020-12-29 02:44:33 --> Language Class Initialized
INFO - 2020-12-29 02:44:33 --> Language Class Initialized
INFO - 2020-12-29 02:44:33 --> Config Class Initialized
INFO - 2020-12-29 02:44:33 --> Loader Class Initialized
INFO - 2020-12-29 02:44:33 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:33 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:33 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:33 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:33 --> Controller Class Initialized
INFO - 2020-12-29 02:44:41 --> Config Class Initialized
INFO - 2020-12-29 02:44:41 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:41 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:41 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:41 --> URI Class Initialized
INFO - 2020-12-29 02:44:41 --> Router Class Initialized
INFO - 2020-12-29 02:44:41 --> Output Class Initialized
INFO - 2020-12-29 02:44:41 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:41 --> Input Class Initialized
INFO - 2020-12-29 02:44:41 --> Language Class Initialized
INFO - 2020-12-29 02:44:41 --> Language Class Initialized
INFO - 2020-12-29 02:44:41 --> Config Class Initialized
INFO - 2020-12-29 02:44:41 --> Loader Class Initialized
INFO - 2020-12-29 02:44:41 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:41 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:41 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:41 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:41 --> Controller Class Initialized
INFO - 2020-12-29 02:44:41 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:41 --> Total execution time: 0.0575
INFO - 2020-12-29 02:44:45 --> Config Class Initialized
INFO - 2020-12-29 02:44:45 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:45 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:45 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:45 --> URI Class Initialized
INFO - 2020-12-29 02:44:45 --> Router Class Initialized
INFO - 2020-12-29 02:44:45 --> Output Class Initialized
INFO - 2020-12-29 02:44:45 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:45 --> Input Class Initialized
INFO - 2020-12-29 02:44:45 --> Language Class Initialized
INFO - 2020-12-29 02:44:45 --> Language Class Initialized
INFO - 2020-12-29 02:44:45 --> Config Class Initialized
INFO - 2020-12-29 02:44:45 --> Loader Class Initialized
INFO - 2020-12-29 02:44:45 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:45 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:45 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:45 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:45 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:45 --> Controller Class Initialized
INFO - 2020-12-29 02:44:45 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:45 --> Total execution time: 0.0763
INFO - 2020-12-29 02:44:45 --> Config Class Initialized
INFO - 2020-12-29 02:44:45 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:45 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:45 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:45 --> URI Class Initialized
INFO - 2020-12-29 02:44:45 --> Router Class Initialized
INFO - 2020-12-29 02:44:45 --> Output Class Initialized
INFO - 2020-12-29 02:44:45 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:45 --> Input Class Initialized
INFO - 2020-12-29 02:44:45 --> Language Class Initialized
INFO - 2020-12-29 02:44:45 --> Language Class Initialized
INFO - 2020-12-29 02:44:45 --> Config Class Initialized
INFO - 2020-12-29 02:44:45 --> Loader Class Initialized
INFO - 2020-12-29 02:44:45 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:45 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:45 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:45 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:46 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:46 --> Controller Class Initialized
INFO - 2020-12-29 02:44:46 --> Config Class Initialized
INFO - 2020-12-29 02:44:46 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:46 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:46 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:46 --> URI Class Initialized
INFO - 2020-12-29 02:44:46 --> Router Class Initialized
INFO - 2020-12-29 02:44:46 --> Output Class Initialized
INFO - 2020-12-29 02:44:46 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:46 --> Input Class Initialized
INFO - 2020-12-29 02:44:46 --> Language Class Initialized
INFO - 2020-12-29 02:44:46 --> Language Class Initialized
INFO - 2020-12-29 02:44:46 --> Config Class Initialized
INFO - 2020-12-29 02:44:46 --> Loader Class Initialized
INFO - 2020-12-29 02:44:46 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:46 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:46 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:46 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:46 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:46 --> Controller Class Initialized
INFO - 2020-12-29 02:44:46 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:46 --> Total execution time: 0.0655
INFO - 2020-12-29 02:44:50 --> Config Class Initialized
INFO - 2020-12-29 02:44:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:50 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:50 --> URI Class Initialized
INFO - 2020-12-29 02:44:50 --> Router Class Initialized
INFO - 2020-12-29 02:44:50 --> Output Class Initialized
INFO - 2020-12-29 02:44:50 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:50 --> Input Class Initialized
INFO - 2020-12-29 02:44:50 --> Language Class Initialized
INFO - 2020-12-29 02:44:50 --> Language Class Initialized
INFO - 2020-12-29 02:44:50 --> Config Class Initialized
INFO - 2020-12-29 02:44:50 --> Loader Class Initialized
INFO - 2020-12-29 02:44:50 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:50 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:50 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:50 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:50 --> Controller Class Initialized
INFO - 2020-12-29 02:44:50 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:50 --> Total execution time: 0.0583
INFO - 2020-12-29 02:44:50 --> Config Class Initialized
INFO - 2020-12-29 02:44:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:50 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:50 --> URI Class Initialized
INFO - 2020-12-29 02:44:50 --> Router Class Initialized
INFO - 2020-12-29 02:44:50 --> Output Class Initialized
INFO - 2020-12-29 02:44:50 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:50 --> Input Class Initialized
INFO - 2020-12-29 02:44:50 --> Language Class Initialized
INFO - 2020-12-29 02:44:50 --> Language Class Initialized
INFO - 2020-12-29 02:44:50 --> Config Class Initialized
INFO - 2020-12-29 02:44:50 --> Loader Class Initialized
INFO - 2020-12-29 02:44:50 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:50 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:50 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:50 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:50 --> Controller Class Initialized
INFO - 2020-12-29 02:44:52 --> Config Class Initialized
INFO - 2020-12-29 02:44:52 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:52 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:52 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:52 --> URI Class Initialized
INFO - 2020-12-29 02:44:52 --> Router Class Initialized
INFO - 2020-12-29 02:44:52 --> Output Class Initialized
INFO - 2020-12-29 02:44:52 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:52 --> Input Class Initialized
INFO - 2020-12-29 02:44:52 --> Language Class Initialized
INFO - 2020-12-29 02:44:52 --> Language Class Initialized
INFO - 2020-12-29 02:44:52 --> Config Class Initialized
INFO - 2020-12-29 02:44:52 --> Loader Class Initialized
INFO - 2020-12-29 02:44:52 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:52 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:52 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:52 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:52 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:52 --> Controller Class Initialized
INFO - 2020-12-29 02:44:52 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:52 --> Total execution time: 0.0834
INFO - 2020-12-29 02:44:55 --> Config Class Initialized
INFO - 2020-12-29 02:44:55 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:55 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:55 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:55 --> URI Class Initialized
INFO - 2020-12-29 02:44:55 --> Router Class Initialized
INFO - 2020-12-29 02:44:55 --> Output Class Initialized
INFO - 2020-12-29 02:44:55 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:55 --> Input Class Initialized
INFO - 2020-12-29 02:44:55 --> Language Class Initialized
INFO - 2020-12-29 02:44:55 --> Language Class Initialized
INFO - 2020-12-29 02:44:55 --> Config Class Initialized
INFO - 2020-12-29 02:44:55 --> Loader Class Initialized
INFO - 2020-12-29 02:44:55 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:55 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:55 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:55 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:55 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:55 --> Controller Class Initialized
INFO - 2020-12-29 02:44:55 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:55 --> Total execution time: 0.0747
INFO - 2020-12-29 02:44:55 --> Config Class Initialized
INFO - 2020-12-29 02:44:55 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:55 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:55 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:55 --> URI Class Initialized
INFO - 2020-12-29 02:44:55 --> Router Class Initialized
INFO - 2020-12-29 02:44:55 --> Output Class Initialized
INFO - 2020-12-29 02:44:55 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:55 --> Input Class Initialized
INFO - 2020-12-29 02:44:55 --> Language Class Initialized
INFO - 2020-12-29 02:44:55 --> Language Class Initialized
INFO - 2020-12-29 02:44:55 --> Config Class Initialized
INFO - 2020-12-29 02:44:55 --> Loader Class Initialized
INFO - 2020-12-29 02:44:55 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:55 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:55 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:55 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:55 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:55 --> Controller Class Initialized
INFO - 2020-12-29 02:44:56 --> Config Class Initialized
INFO - 2020-12-29 02:44:56 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:44:56 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:44:56 --> Utf8 Class Initialized
INFO - 2020-12-29 02:44:56 --> URI Class Initialized
INFO - 2020-12-29 02:44:56 --> Router Class Initialized
INFO - 2020-12-29 02:44:56 --> Output Class Initialized
INFO - 2020-12-29 02:44:56 --> Security Class Initialized
DEBUG - 2020-12-29 02:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:44:56 --> Input Class Initialized
INFO - 2020-12-29 02:44:56 --> Language Class Initialized
INFO - 2020-12-29 02:44:56 --> Language Class Initialized
INFO - 2020-12-29 02:44:56 --> Config Class Initialized
INFO - 2020-12-29 02:44:56 --> Loader Class Initialized
INFO - 2020-12-29 02:44:56 --> Helper loaded: url_helper
INFO - 2020-12-29 02:44:56 --> Helper loaded: file_helper
INFO - 2020-12-29 02:44:56 --> Helper loaded: form_helper
INFO - 2020-12-29 02:44:56 --> Helper loaded: my_helper
INFO - 2020-12-29 02:44:56 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:44:56 --> Controller Class Initialized
INFO - 2020-12-29 02:44:56 --> Final output sent to browser
DEBUG - 2020-12-29 02:44:56 --> Total execution time: 0.0615
INFO - 2020-12-29 02:45:02 --> Config Class Initialized
INFO - 2020-12-29 02:45:02 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:02 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:02 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:02 --> URI Class Initialized
INFO - 2020-12-29 02:45:02 --> Router Class Initialized
INFO - 2020-12-29 02:45:02 --> Output Class Initialized
INFO - 2020-12-29 02:45:02 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:02 --> Input Class Initialized
INFO - 2020-12-29 02:45:02 --> Language Class Initialized
INFO - 2020-12-29 02:45:02 --> Language Class Initialized
INFO - 2020-12-29 02:45:02 --> Config Class Initialized
INFO - 2020-12-29 02:45:02 --> Loader Class Initialized
INFO - 2020-12-29 02:45:02 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:02 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:02 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:02 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:02 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:02 --> Controller Class Initialized
INFO - 2020-12-29 02:45:02 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:02 --> Total execution time: 0.0847
INFO - 2020-12-29 02:45:02 --> Config Class Initialized
INFO - 2020-12-29 02:45:02 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:02 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:02 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:02 --> URI Class Initialized
INFO - 2020-12-29 02:45:02 --> Router Class Initialized
INFO - 2020-12-29 02:45:02 --> Output Class Initialized
INFO - 2020-12-29 02:45:02 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:02 --> Input Class Initialized
INFO - 2020-12-29 02:45:02 --> Language Class Initialized
INFO - 2020-12-29 02:45:02 --> Language Class Initialized
INFO - 2020-12-29 02:45:02 --> Config Class Initialized
INFO - 2020-12-29 02:45:02 --> Loader Class Initialized
INFO - 2020-12-29 02:45:02 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:02 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:02 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:02 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:02 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:02 --> Controller Class Initialized
INFO - 2020-12-29 02:45:25 --> Config Class Initialized
INFO - 2020-12-29 02:45:25 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:25 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:25 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:25 --> URI Class Initialized
INFO - 2020-12-29 02:45:25 --> Router Class Initialized
INFO - 2020-12-29 02:45:25 --> Output Class Initialized
INFO - 2020-12-29 02:45:25 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:25 --> Input Class Initialized
INFO - 2020-12-29 02:45:25 --> Language Class Initialized
INFO - 2020-12-29 02:45:25 --> Language Class Initialized
INFO - 2020-12-29 02:45:25 --> Config Class Initialized
INFO - 2020-12-29 02:45:25 --> Loader Class Initialized
INFO - 2020-12-29 02:45:25 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:25 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:25 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:25 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:25 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:25 --> Controller Class Initialized
INFO - 2020-12-29 02:45:25 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:25 --> Total execution time: 0.0714
INFO - 2020-12-29 02:45:31 --> Config Class Initialized
INFO - 2020-12-29 02:45:31 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:31 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:31 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:31 --> URI Class Initialized
INFO - 2020-12-29 02:45:31 --> Router Class Initialized
INFO - 2020-12-29 02:45:31 --> Output Class Initialized
INFO - 2020-12-29 02:45:31 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:31 --> Input Class Initialized
INFO - 2020-12-29 02:45:31 --> Language Class Initialized
INFO - 2020-12-29 02:45:31 --> Language Class Initialized
INFO - 2020-12-29 02:45:31 --> Config Class Initialized
INFO - 2020-12-29 02:45:31 --> Loader Class Initialized
INFO - 2020-12-29 02:45:31 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:31 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:31 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:31 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:31 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:31 --> Controller Class Initialized
INFO - 2020-12-29 02:45:31 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:31 --> Total execution time: 0.0623
INFO - 2020-12-29 02:45:31 --> Config Class Initialized
INFO - 2020-12-29 02:45:31 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:31 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:31 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:31 --> URI Class Initialized
INFO - 2020-12-29 02:45:31 --> Router Class Initialized
INFO - 2020-12-29 02:45:31 --> Output Class Initialized
INFO - 2020-12-29 02:45:31 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:31 --> Input Class Initialized
INFO - 2020-12-29 02:45:31 --> Language Class Initialized
INFO - 2020-12-29 02:45:31 --> Language Class Initialized
INFO - 2020-12-29 02:45:31 --> Config Class Initialized
INFO - 2020-12-29 02:45:31 --> Loader Class Initialized
INFO - 2020-12-29 02:45:31 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:31 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:31 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:31 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:31 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:31 --> Controller Class Initialized
INFO - 2020-12-29 02:45:32 --> Config Class Initialized
INFO - 2020-12-29 02:45:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:32 --> URI Class Initialized
INFO - 2020-12-29 02:45:32 --> Router Class Initialized
INFO - 2020-12-29 02:45:32 --> Output Class Initialized
INFO - 2020-12-29 02:45:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:32 --> Input Class Initialized
INFO - 2020-12-29 02:45:32 --> Language Class Initialized
INFO - 2020-12-29 02:45:32 --> Language Class Initialized
INFO - 2020-12-29 02:45:32 --> Config Class Initialized
INFO - 2020-12-29 02:45:32 --> Loader Class Initialized
INFO - 2020-12-29 02:45:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:32 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:32 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:32 --> Controller Class Initialized
INFO - 2020-12-29 02:45:32 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:32 --> Total execution time: 0.0632
INFO - 2020-12-29 02:45:38 --> Config Class Initialized
INFO - 2020-12-29 02:45:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:38 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:38 --> URI Class Initialized
INFO - 2020-12-29 02:45:38 --> Router Class Initialized
INFO - 2020-12-29 02:45:38 --> Output Class Initialized
INFO - 2020-12-29 02:45:38 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:38 --> Input Class Initialized
INFO - 2020-12-29 02:45:38 --> Language Class Initialized
INFO - 2020-12-29 02:45:38 --> Language Class Initialized
INFO - 2020-12-29 02:45:38 --> Config Class Initialized
INFO - 2020-12-29 02:45:38 --> Loader Class Initialized
INFO - 2020-12-29 02:45:38 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:38 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:38 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:38 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:38 --> Controller Class Initialized
INFO - 2020-12-29 02:45:38 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:38 --> Total execution time: 0.0804
INFO - 2020-12-29 02:45:38 --> Config Class Initialized
INFO - 2020-12-29 02:45:38 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:38 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:38 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:38 --> URI Class Initialized
INFO - 2020-12-29 02:45:38 --> Router Class Initialized
INFO - 2020-12-29 02:45:38 --> Output Class Initialized
INFO - 2020-12-29 02:45:38 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:38 --> Input Class Initialized
INFO - 2020-12-29 02:45:38 --> Language Class Initialized
INFO - 2020-12-29 02:45:38 --> Language Class Initialized
INFO - 2020-12-29 02:45:38 --> Config Class Initialized
INFO - 2020-12-29 02:45:38 --> Loader Class Initialized
INFO - 2020-12-29 02:45:38 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:38 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:38 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:38 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:38 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:38 --> Controller Class Initialized
INFO - 2020-12-29 02:45:41 --> Config Class Initialized
INFO - 2020-12-29 02:45:41 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:41 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:41 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:41 --> URI Class Initialized
INFO - 2020-12-29 02:45:41 --> Router Class Initialized
INFO - 2020-12-29 02:45:41 --> Output Class Initialized
INFO - 2020-12-29 02:45:41 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:41 --> Input Class Initialized
INFO - 2020-12-29 02:45:41 --> Language Class Initialized
INFO - 2020-12-29 02:45:41 --> Language Class Initialized
INFO - 2020-12-29 02:45:41 --> Config Class Initialized
INFO - 2020-12-29 02:45:41 --> Loader Class Initialized
INFO - 2020-12-29 02:45:41 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:41 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:41 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:41 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:41 --> Controller Class Initialized
INFO - 2020-12-29 02:45:41 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:41 --> Total execution time: 0.0552
INFO - 2020-12-29 02:45:48 --> Config Class Initialized
INFO - 2020-12-29 02:45:48 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:48 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:48 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:48 --> URI Class Initialized
INFO - 2020-12-29 02:45:48 --> Router Class Initialized
INFO - 2020-12-29 02:45:48 --> Output Class Initialized
INFO - 2020-12-29 02:45:48 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:48 --> Input Class Initialized
INFO - 2020-12-29 02:45:48 --> Language Class Initialized
INFO - 2020-12-29 02:45:48 --> Language Class Initialized
INFO - 2020-12-29 02:45:48 --> Config Class Initialized
INFO - 2020-12-29 02:45:48 --> Loader Class Initialized
INFO - 2020-12-29 02:45:48 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:48 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:48 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:48 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:48 --> Controller Class Initialized
INFO - 2020-12-29 02:45:48 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:48 --> Total execution time: 0.0735
INFO - 2020-12-29 02:45:48 --> Config Class Initialized
INFO - 2020-12-29 02:45:48 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:48 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:48 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:48 --> URI Class Initialized
INFO - 2020-12-29 02:45:48 --> Router Class Initialized
INFO - 2020-12-29 02:45:48 --> Output Class Initialized
INFO - 2020-12-29 02:45:48 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:48 --> Input Class Initialized
INFO - 2020-12-29 02:45:48 --> Language Class Initialized
INFO - 2020-12-29 02:45:48 --> Language Class Initialized
INFO - 2020-12-29 02:45:48 --> Config Class Initialized
INFO - 2020-12-29 02:45:48 --> Loader Class Initialized
INFO - 2020-12-29 02:45:48 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:48 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:48 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:48 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:49 --> Controller Class Initialized
INFO - 2020-12-29 02:45:49 --> Config Class Initialized
INFO - 2020-12-29 02:45:49 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:49 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:49 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:49 --> URI Class Initialized
INFO - 2020-12-29 02:45:49 --> Router Class Initialized
INFO - 2020-12-29 02:45:49 --> Output Class Initialized
INFO - 2020-12-29 02:45:49 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:49 --> Input Class Initialized
INFO - 2020-12-29 02:45:49 --> Language Class Initialized
INFO - 2020-12-29 02:45:49 --> Language Class Initialized
INFO - 2020-12-29 02:45:49 --> Config Class Initialized
INFO - 2020-12-29 02:45:49 --> Loader Class Initialized
INFO - 2020-12-29 02:45:49 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:49 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:49 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:49 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:49 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:49 --> Controller Class Initialized
INFO - 2020-12-29 02:45:49 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:49 --> Total execution time: 0.0639
INFO - 2020-12-29 02:45:53 --> Config Class Initialized
INFO - 2020-12-29 02:45:53 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:53 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:53 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:53 --> URI Class Initialized
INFO - 2020-12-29 02:45:53 --> Router Class Initialized
INFO - 2020-12-29 02:45:53 --> Output Class Initialized
INFO - 2020-12-29 02:45:53 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:53 --> Input Class Initialized
INFO - 2020-12-29 02:45:53 --> Language Class Initialized
INFO - 2020-12-29 02:45:53 --> Language Class Initialized
INFO - 2020-12-29 02:45:53 --> Config Class Initialized
INFO - 2020-12-29 02:45:53 --> Loader Class Initialized
INFO - 2020-12-29 02:45:53 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:53 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:53 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:53 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:53 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:54 --> Controller Class Initialized
INFO - 2020-12-29 02:45:54 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:54 --> Total execution time: 0.0858
INFO - 2020-12-29 02:45:54 --> Config Class Initialized
INFO - 2020-12-29 02:45:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:54 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:54 --> URI Class Initialized
INFO - 2020-12-29 02:45:54 --> Router Class Initialized
INFO - 2020-12-29 02:45:54 --> Output Class Initialized
INFO - 2020-12-29 02:45:54 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:54 --> Input Class Initialized
INFO - 2020-12-29 02:45:54 --> Language Class Initialized
INFO - 2020-12-29 02:45:54 --> Language Class Initialized
INFO - 2020-12-29 02:45:54 --> Config Class Initialized
INFO - 2020-12-29 02:45:54 --> Loader Class Initialized
INFO - 2020-12-29 02:45:54 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:54 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:54 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:54 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:54 --> Controller Class Initialized
INFO - 2020-12-29 02:45:54 --> Config Class Initialized
INFO - 2020-12-29 02:45:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:54 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:54 --> URI Class Initialized
INFO - 2020-12-29 02:45:54 --> Router Class Initialized
INFO - 2020-12-29 02:45:54 --> Output Class Initialized
INFO - 2020-12-29 02:45:54 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:54 --> Input Class Initialized
INFO - 2020-12-29 02:45:54 --> Language Class Initialized
INFO - 2020-12-29 02:45:54 --> Language Class Initialized
INFO - 2020-12-29 02:45:54 --> Config Class Initialized
INFO - 2020-12-29 02:45:54 --> Loader Class Initialized
INFO - 2020-12-29 02:45:54 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:54 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:54 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:54 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:54 --> Controller Class Initialized
INFO - 2020-12-29 02:45:54 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:54 --> Total execution time: 0.0615
INFO - 2020-12-29 02:45:59 --> Config Class Initialized
INFO - 2020-12-29 02:45:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:59 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:59 --> URI Class Initialized
INFO - 2020-12-29 02:45:59 --> Router Class Initialized
INFO - 2020-12-29 02:45:59 --> Output Class Initialized
INFO - 2020-12-29 02:45:59 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:59 --> Input Class Initialized
INFO - 2020-12-29 02:45:59 --> Language Class Initialized
INFO - 2020-12-29 02:45:59 --> Language Class Initialized
INFO - 2020-12-29 02:45:59 --> Config Class Initialized
INFO - 2020-12-29 02:45:59 --> Loader Class Initialized
INFO - 2020-12-29 02:45:59 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:59 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:59 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:59 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:59 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:59 --> Controller Class Initialized
INFO - 2020-12-29 02:45:59 --> Final output sent to browser
DEBUG - 2020-12-29 02:45:59 --> Total execution time: 0.0680
INFO - 2020-12-29 02:45:59 --> Config Class Initialized
INFO - 2020-12-29 02:45:59 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:45:59 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:45:59 --> Utf8 Class Initialized
INFO - 2020-12-29 02:45:59 --> URI Class Initialized
INFO - 2020-12-29 02:45:59 --> Router Class Initialized
INFO - 2020-12-29 02:45:59 --> Output Class Initialized
INFO - 2020-12-29 02:45:59 --> Security Class Initialized
DEBUG - 2020-12-29 02:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:45:59 --> Input Class Initialized
INFO - 2020-12-29 02:45:59 --> Language Class Initialized
INFO - 2020-12-29 02:45:59 --> Language Class Initialized
INFO - 2020-12-29 02:45:59 --> Config Class Initialized
INFO - 2020-12-29 02:45:59 --> Loader Class Initialized
INFO - 2020-12-29 02:45:59 --> Helper loaded: url_helper
INFO - 2020-12-29 02:45:59 --> Helper loaded: file_helper
INFO - 2020-12-29 02:45:59 --> Helper loaded: form_helper
INFO - 2020-12-29 02:45:59 --> Helper loaded: my_helper
INFO - 2020-12-29 02:45:59 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:45:59 --> Controller Class Initialized
INFO - 2020-12-29 02:46:01 --> Config Class Initialized
INFO - 2020-12-29 02:46:01 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:01 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:01 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:01 --> URI Class Initialized
INFO - 2020-12-29 02:46:01 --> Router Class Initialized
INFO - 2020-12-29 02:46:01 --> Output Class Initialized
INFO - 2020-12-29 02:46:01 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:01 --> Input Class Initialized
INFO - 2020-12-29 02:46:01 --> Language Class Initialized
INFO - 2020-12-29 02:46:01 --> Language Class Initialized
INFO - 2020-12-29 02:46:01 --> Config Class Initialized
INFO - 2020-12-29 02:46:01 --> Loader Class Initialized
INFO - 2020-12-29 02:46:01 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:01 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:01 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:01 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:01 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:01 --> Controller Class Initialized
INFO - 2020-12-29 02:46:01 --> Final output sent to browser
DEBUG - 2020-12-29 02:46:01 --> Total execution time: 0.0792
INFO - 2020-12-29 02:46:06 --> Config Class Initialized
INFO - 2020-12-29 02:46:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:06 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:06 --> URI Class Initialized
INFO - 2020-12-29 02:46:06 --> Router Class Initialized
INFO - 2020-12-29 02:46:06 --> Output Class Initialized
INFO - 2020-12-29 02:46:06 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:06 --> Input Class Initialized
INFO - 2020-12-29 02:46:06 --> Language Class Initialized
INFO - 2020-12-29 02:46:06 --> Language Class Initialized
INFO - 2020-12-29 02:46:06 --> Config Class Initialized
INFO - 2020-12-29 02:46:06 --> Loader Class Initialized
INFO - 2020-12-29 02:46:06 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:06 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:06 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:06 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:06 --> Controller Class Initialized
INFO - 2020-12-29 02:46:06 --> Final output sent to browser
DEBUG - 2020-12-29 02:46:06 --> Total execution time: 0.0822
INFO - 2020-12-29 02:46:06 --> Config Class Initialized
INFO - 2020-12-29 02:46:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:06 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:06 --> URI Class Initialized
INFO - 2020-12-29 02:46:06 --> Router Class Initialized
INFO - 2020-12-29 02:46:06 --> Output Class Initialized
INFO - 2020-12-29 02:46:06 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:06 --> Input Class Initialized
INFO - 2020-12-29 02:46:06 --> Language Class Initialized
INFO - 2020-12-29 02:46:06 --> Language Class Initialized
INFO - 2020-12-29 02:46:06 --> Config Class Initialized
INFO - 2020-12-29 02:46:06 --> Loader Class Initialized
INFO - 2020-12-29 02:46:06 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:06 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:06 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:06 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:06 --> Controller Class Initialized
INFO - 2020-12-29 02:46:07 --> Config Class Initialized
INFO - 2020-12-29 02:46:07 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:07 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:07 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:07 --> URI Class Initialized
INFO - 2020-12-29 02:46:07 --> Router Class Initialized
INFO - 2020-12-29 02:46:07 --> Output Class Initialized
INFO - 2020-12-29 02:46:07 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:07 --> Input Class Initialized
INFO - 2020-12-29 02:46:07 --> Language Class Initialized
INFO - 2020-12-29 02:46:07 --> Language Class Initialized
INFO - 2020-12-29 02:46:07 --> Config Class Initialized
INFO - 2020-12-29 02:46:07 --> Loader Class Initialized
INFO - 2020-12-29 02:46:07 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:07 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:07 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:07 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:07 --> Controller Class Initialized
INFO - 2020-12-29 02:46:07 --> Final output sent to browser
DEBUG - 2020-12-29 02:46:07 --> Total execution time: 0.0612
INFO - 2020-12-29 02:46:12 --> Config Class Initialized
INFO - 2020-12-29 02:46:12 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:12 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:12 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:12 --> URI Class Initialized
INFO - 2020-12-29 02:46:12 --> Router Class Initialized
INFO - 2020-12-29 02:46:12 --> Output Class Initialized
INFO - 2020-12-29 02:46:12 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:12 --> Input Class Initialized
INFO - 2020-12-29 02:46:12 --> Language Class Initialized
INFO - 2020-12-29 02:46:12 --> Language Class Initialized
INFO - 2020-12-29 02:46:12 --> Config Class Initialized
INFO - 2020-12-29 02:46:12 --> Loader Class Initialized
INFO - 2020-12-29 02:46:12 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:12 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:12 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:12 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:12 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:12 --> Controller Class Initialized
INFO - 2020-12-29 02:46:12 --> Final output sent to browser
DEBUG - 2020-12-29 02:46:12 --> Total execution time: 0.0498
INFO - 2020-12-29 02:46:12 --> Config Class Initialized
INFO - 2020-12-29 02:46:12 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:12 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:12 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:12 --> URI Class Initialized
INFO - 2020-12-29 02:46:12 --> Router Class Initialized
INFO - 2020-12-29 02:46:12 --> Output Class Initialized
INFO - 2020-12-29 02:46:12 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:12 --> Input Class Initialized
INFO - 2020-12-29 02:46:12 --> Language Class Initialized
INFO - 2020-12-29 02:46:12 --> Language Class Initialized
INFO - 2020-12-29 02:46:12 --> Config Class Initialized
INFO - 2020-12-29 02:46:12 --> Loader Class Initialized
INFO - 2020-12-29 02:46:12 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:12 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:12 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:12 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:12 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:12 --> Controller Class Initialized
INFO - 2020-12-29 02:46:19 --> Config Class Initialized
INFO - 2020-12-29 02:46:19 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:19 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:19 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:19 --> URI Class Initialized
INFO - 2020-12-29 02:46:19 --> Router Class Initialized
INFO - 2020-12-29 02:46:19 --> Output Class Initialized
INFO - 2020-12-29 02:46:19 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:19 --> Input Class Initialized
INFO - 2020-12-29 02:46:19 --> Language Class Initialized
INFO - 2020-12-29 02:46:19 --> Language Class Initialized
INFO - 2020-12-29 02:46:19 --> Config Class Initialized
INFO - 2020-12-29 02:46:19 --> Loader Class Initialized
INFO - 2020-12-29 02:46:19 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:19 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:19 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:19 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:19 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:19 --> Controller Class Initialized
INFO - 2020-12-29 02:46:19 --> Final output sent to browser
DEBUG - 2020-12-29 02:46:19 --> Total execution time: 0.0787
INFO - 2020-12-29 02:46:24 --> Config Class Initialized
INFO - 2020-12-29 02:46:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:24 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:24 --> URI Class Initialized
INFO - 2020-12-29 02:46:24 --> Router Class Initialized
INFO - 2020-12-29 02:46:24 --> Output Class Initialized
INFO - 2020-12-29 02:46:24 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:24 --> Input Class Initialized
INFO - 2020-12-29 02:46:24 --> Language Class Initialized
INFO - 2020-12-29 02:46:24 --> Language Class Initialized
INFO - 2020-12-29 02:46:24 --> Config Class Initialized
INFO - 2020-12-29 02:46:24 --> Loader Class Initialized
INFO - 2020-12-29 02:46:24 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:24 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:24 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:24 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:24 --> Controller Class Initialized
INFO - 2020-12-29 02:46:24 --> Final output sent to browser
DEBUG - 2020-12-29 02:46:24 --> Total execution time: 0.0820
INFO - 2020-12-29 02:46:24 --> Config Class Initialized
INFO - 2020-12-29 02:46:24 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:46:24 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:46:24 --> Utf8 Class Initialized
INFO - 2020-12-29 02:46:24 --> URI Class Initialized
INFO - 2020-12-29 02:46:24 --> Router Class Initialized
INFO - 2020-12-29 02:46:24 --> Output Class Initialized
INFO - 2020-12-29 02:46:24 --> Security Class Initialized
DEBUG - 2020-12-29 02:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:46:24 --> Input Class Initialized
INFO - 2020-12-29 02:46:24 --> Language Class Initialized
INFO - 2020-12-29 02:46:24 --> Language Class Initialized
INFO - 2020-12-29 02:46:24 --> Config Class Initialized
INFO - 2020-12-29 02:46:24 --> Loader Class Initialized
INFO - 2020-12-29 02:46:24 --> Helper loaded: url_helper
INFO - 2020-12-29 02:46:24 --> Helper loaded: file_helper
INFO - 2020-12-29 02:46:24 --> Helper loaded: form_helper
INFO - 2020-12-29 02:46:24 --> Helper loaded: my_helper
INFO - 2020-12-29 02:46:24 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:46:24 --> Controller Class Initialized
INFO - 2020-12-29 02:47:37 --> Config Class Initialized
INFO - 2020-12-29 02:47:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:47:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:47:37 --> Utf8 Class Initialized
INFO - 2020-12-29 02:47:37 --> URI Class Initialized
INFO - 2020-12-29 02:47:37 --> Router Class Initialized
INFO - 2020-12-29 02:47:37 --> Output Class Initialized
INFO - 2020-12-29 02:47:37 --> Security Class Initialized
DEBUG - 2020-12-29 02:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:47:37 --> Input Class Initialized
INFO - 2020-12-29 02:47:37 --> Language Class Initialized
INFO - 2020-12-29 02:47:37 --> Language Class Initialized
INFO - 2020-12-29 02:47:37 --> Config Class Initialized
INFO - 2020-12-29 02:47:37 --> Loader Class Initialized
INFO - 2020-12-29 02:47:37 --> Helper loaded: url_helper
INFO - 2020-12-29 02:47:37 --> Helper loaded: file_helper
INFO - 2020-12-29 02:47:37 --> Helper loaded: form_helper
INFO - 2020-12-29 02:47:37 --> Helper loaded: my_helper
INFO - 2020-12-29 02:47:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:47:37 --> Controller Class Initialized
DEBUG - 2020-12-29 02:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:47:37 --> Final output sent to browser
DEBUG - 2020-12-29 02:47:37 --> Total execution time: 0.0729
INFO - 2020-12-29 02:47:49 --> Config Class Initialized
INFO - 2020-12-29 02:47:49 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:47:49 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:47:49 --> Utf8 Class Initialized
INFO - 2020-12-29 02:47:49 --> URI Class Initialized
INFO - 2020-12-29 02:47:49 --> Router Class Initialized
INFO - 2020-12-29 02:47:49 --> Output Class Initialized
INFO - 2020-12-29 02:47:49 --> Security Class Initialized
DEBUG - 2020-12-29 02:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:47:49 --> Input Class Initialized
INFO - 2020-12-29 02:47:49 --> Language Class Initialized
INFO - 2020-12-29 02:47:49 --> Language Class Initialized
INFO - 2020-12-29 02:47:49 --> Config Class Initialized
INFO - 2020-12-29 02:47:49 --> Loader Class Initialized
INFO - 2020-12-29 02:47:49 --> Helper loaded: url_helper
INFO - 2020-12-29 02:47:49 --> Helper loaded: file_helper
INFO - 2020-12-29 02:47:49 --> Helper loaded: form_helper
INFO - 2020-12-29 02:47:49 --> Helper loaded: my_helper
INFO - 2020-12-29 02:47:49 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:47:49 --> Controller Class Initialized
DEBUG - 2020-12-29 02:47:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:47:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:47:49 --> Final output sent to browser
DEBUG - 2020-12-29 02:47:49 --> Total execution time: 0.0673
INFO - 2020-12-29 02:56:03 --> Config Class Initialized
INFO - 2020-12-29 02:56:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:56:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:56:03 --> Utf8 Class Initialized
INFO - 2020-12-29 02:56:03 --> URI Class Initialized
INFO - 2020-12-29 02:56:03 --> Router Class Initialized
INFO - 2020-12-29 02:56:03 --> Output Class Initialized
INFO - 2020-12-29 02:56:03 --> Security Class Initialized
DEBUG - 2020-12-29 02:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:56:03 --> Input Class Initialized
INFO - 2020-12-29 02:56:03 --> Language Class Initialized
INFO - 2020-12-29 02:56:03 --> Language Class Initialized
INFO - 2020-12-29 02:56:03 --> Config Class Initialized
INFO - 2020-12-29 02:56:03 --> Loader Class Initialized
INFO - 2020-12-29 02:56:03 --> Helper loaded: url_helper
INFO - 2020-12-29 02:56:03 --> Helper loaded: file_helper
INFO - 2020-12-29 02:56:03 --> Helper loaded: form_helper
INFO - 2020-12-29 02:56:03 --> Helper loaded: my_helper
INFO - 2020-12-29 02:56:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:56:03 --> Controller Class Initialized
INFO - 2020-12-29 02:56:03 --> Config Class Initialized
INFO - 2020-12-29 02:56:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:56:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:56:03 --> Utf8 Class Initialized
INFO - 2020-12-29 02:56:03 --> URI Class Initialized
INFO - 2020-12-29 02:56:03 --> Router Class Initialized
INFO - 2020-12-29 02:56:03 --> Output Class Initialized
INFO - 2020-12-29 02:56:03 --> Security Class Initialized
DEBUG - 2020-12-29 02:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:56:03 --> Input Class Initialized
INFO - 2020-12-29 02:56:03 --> Language Class Initialized
INFO - 2020-12-29 02:56:03 --> Language Class Initialized
INFO - 2020-12-29 02:56:03 --> Config Class Initialized
INFO - 2020-12-29 02:56:03 --> Loader Class Initialized
INFO - 2020-12-29 02:56:03 --> Helper loaded: url_helper
INFO - 2020-12-29 02:56:03 --> Helper loaded: file_helper
INFO - 2020-12-29 02:56:03 --> Helper loaded: form_helper
INFO - 2020-12-29 02:56:03 --> Helper loaded: my_helper
INFO - 2020-12-29 02:56:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:56:03 --> Controller Class Initialized
DEBUG - 2020-12-29 02:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:56:03 --> Final output sent to browser
DEBUG - 2020-12-29 02:56:03 --> Total execution time: 0.0649
INFO - 2020-12-29 02:56:22 --> Config Class Initialized
INFO - 2020-12-29 02:56:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:56:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:56:22 --> Utf8 Class Initialized
INFO - 2020-12-29 02:56:22 --> URI Class Initialized
INFO - 2020-12-29 02:56:22 --> Router Class Initialized
INFO - 2020-12-29 02:56:22 --> Output Class Initialized
INFO - 2020-12-29 02:56:22 --> Security Class Initialized
DEBUG - 2020-12-29 02:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:56:22 --> Input Class Initialized
INFO - 2020-12-29 02:56:22 --> Language Class Initialized
INFO - 2020-12-29 02:56:22 --> Language Class Initialized
INFO - 2020-12-29 02:56:22 --> Config Class Initialized
INFO - 2020-12-29 02:56:22 --> Loader Class Initialized
INFO - 2020-12-29 02:56:22 --> Helper loaded: url_helper
INFO - 2020-12-29 02:56:22 --> Helper loaded: file_helper
INFO - 2020-12-29 02:56:22 --> Helper loaded: form_helper
INFO - 2020-12-29 02:56:22 --> Helper loaded: my_helper
INFO - 2020-12-29 02:56:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:56:22 --> Controller Class Initialized
DEBUG - 2020-12-29 02:56:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:56:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:56:22 --> Final output sent to browser
DEBUG - 2020-12-29 02:56:22 --> Total execution time: 0.0774
INFO - 2020-12-29 02:56:30 --> Config Class Initialized
INFO - 2020-12-29 02:56:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:56:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:56:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:56:30 --> URI Class Initialized
INFO - 2020-12-29 02:56:30 --> Router Class Initialized
INFO - 2020-12-29 02:56:30 --> Output Class Initialized
INFO - 2020-12-29 02:56:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:56:30 --> Input Class Initialized
INFO - 2020-12-29 02:56:30 --> Language Class Initialized
INFO - 2020-12-29 02:56:30 --> Language Class Initialized
INFO - 2020-12-29 02:56:30 --> Config Class Initialized
INFO - 2020-12-29 02:56:30 --> Loader Class Initialized
INFO - 2020-12-29 02:56:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:56:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:56:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:56:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:56:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:56:30 --> Controller Class Initialized
INFO - 2020-12-29 02:56:30 --> Config Class Initialized
INFO - 2020-12-29 02:56:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:56:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:56:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:56:30 --> URI Class Initialized
INFO - 2020-12-29 02:56:30 --> Router Class Initialized
INFO - 2020-12-29 02:56:30 --> Output Class Initialized
INFO - 2020-12-29 02:56:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:56:30 --> Input Class Initialized
INFO - 2020-12-29 02:56:30 --> Language Class Initialized
INFO - 2020-12-29 02:56:30 --> Language Class Initialized
INFO - 2020-12-29 02:56:30 --> Config Class Initialized
INFO - 2020-12-29 02:56:30 --> Loader Class Initialized
INFO - 2020-12-29 02:56:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:56:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:56:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:56:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:56:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:56:30 --> Controller Class Initialized
DEBUG - 2020-12-29 02:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:56:30 --> Final output sent to browser
DEBUG - 2020-12-29 02:56:30 --> Total execution time: 0.0754
INFO - 2020-12-29 02:56:32 --> Config Class Initialized
INFO - 2020-12-29 02:56:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:56:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:56:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:56:32 --> URI Class Initialized
INFO - 2020-12-29 02:56:32 --> Router Class Initialized
INFO - 2020-12-29 02:56:32 --> Output Class Initialized
INFO - 2020-12-29 02:56:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:56:32 --> Input Class Initialized
INFO - 2020-12-29 02:56:32 --> Language Class Initialized
INFO - 2020-12-29 02:56:32 --> Language Class Initialized
INFO - 2020-12-29 02:56:32 --> Config Class Initialized
INFO - 2020-12-29 02:56:32 --> Loader Class Initialized
INFO - 2020-12-29 02:56:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:56:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:56:33 --> Helper loaded: form_helper
INFO - 2020-12-29 02:56:33 --> Helper loaded: my_helper
INFO - 2020-12-29 02:56:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:56:33 --> Controller Class Initialized
DEBUG - 2020-12-29 02:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:56:33 --> Final output sent to browser
DEBUG - 2020-12-29 02:56:33 --> Total execution time: 0.0664
INFO - 2020-12-29 02:57:06 --> Config Class Initialized
INFO - 2020-12-29 02:57:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:57:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:57:06 --> Utf8 Class Initialized
INFO - 2020-12-29 02:57:06 --> URI Class Initialized
INFO - 2020-12-29 02:57:06 --> Router Class Initialized
INFO - 2020-12-29 02:57:06 --> Output Class Initialized
INFO - 2020-12-29 02:57:06 --> Security Class Initialized
DEBUG - 2020-12-29 02:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:57:06 --> Input Class Initialized
INFO - 2020-12-29 02:57:06 --> Language Class Initialized
INFO - 2020-12-29 02:57:06 --> Language Class Initialized
INFO - 2020-12-29 02:57:06 --> Config Class Initialized
INFO - 2020-12-29 02:57:06 --> Loader Class Initialized
INFO - 2020-12-29 02:57:06 --> Helper loaded: url_helper
INFO - 2020-12-29 02:57:06 --> Helper loaded: file_helper
INFO - 2020-12-29 02:57:06 --> Helper loaded: form_helper
INFO - 2020-12-29 02:57:06 --> Helper loaded: my_helper
INFO - 2020-12-29 02:57:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:57:06 --> Controller Class Initialized
INFO - 2020-12-29 02:57:06 --> Config Class Initialized
INFO - 2020-12-29 02:57:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:57:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:57:06 --> Utf8 Class Initialized
INFO - 2020-12-29 02:57:06 --> URI Class Initialized
INFO - 2020-12-29 02:57:06 --> Router Class Initialized
INFO - 2020-12-29 02:57:06 --> Output Class Initialized
INFO - 2020-12-29 02:57:06 --> Security Class Initialized
DEBUG - 2020-12-29 02:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:57:06 --> Input Class Initialized
INFO - 2020-12-29 02:57:06 --> Language Class Initialized
INFO - 2020-12-29 02:57:06 --> Language Class Initialized
INFO - 2020-12-29 02:57:06 --> Config Class Initialized
INFO - 2020-12-29 02:57:06 --> Loader Class Initialized
INFO - 2020-12-29 02:57:06 --> Helper loaded: url_helper
INFO - 2020-12-29 02:57:06 --> Helper loaded: file_helper
INFO - 2020-12-29 02:57:06 --> Helper loaded: form_helper
INFO - 2020-12-29 02:57:06 --> Helper loaded: my_helper
INFO - 2020-12-29 02:57:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:57:06 --> Controller Class Initialized
DEBUG - 2020-12-29 02:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:57:06 --> Final output sent to browser
DEBUG - 2020-12-29 02:57:06 --> Total execution time: 0.0718
INFO - 2020-12-29 02:57:10 --> Config Class Initialized
INFO - 2020-12-29 02:57:10 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:57:10 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:57:10 --> Utf8 Class Initialized
INFO - 2020-12-29 02:57:10 --> URI Class Initialized
INFO - 2020-12-29 02:57:10 --> Router Class Initialized
INFO - 2020-12-29 02:57:10 --> Output Class Initialized
INFO - 2020-12-29 02:57:10 --> Security Class Initialized
DEBUG - 2020-12-29 02:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:57:10 --> Input Class Initialized
INFO - 2020-12-29 02:57:10 --> Language Class Initialized
INFO - 2020-12-29 02:57:10 --> Language Class Initialized
INFO - 2020-12-29 02:57:10 --> Config Class Initialized
INFO - 2020-12-29 02:57:10 --> Loader Class Initialized
INFO - 2020-12-29 02:57:10 --> Helper loaded: url_helper
INFO - 2020-12-29 02:57:10 --> Helper loaded: file_helper
INFO - 2020-12-29 02:57:10 --> Helper loaded: form_helper
INFO - 2020-12-29 02:57:10 --> Helper loaded: my_helper
INFO - 2020-12-29 02:57:10 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:57:10 --> Controller Class Initialized
DEBUG - 2020-12-29 02:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:57:10 --> Final output sent to browser
DEBUG - 2020-12-29 02:57:10 --> Total execution time: 0.0779
INFO - 2020-12-29 02:57:28 --> Config Class Initialized
INFO - 2020-12-29 02:57:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:57:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:57:28 --> Utf8 Class Initialized
INFO - 2020-12-29 02:57:28 --> URI Class Initialized
INFO - 2020-12-29 02:57:28 --> Router Class Initialized
INFO - 2020-12-29 02:57:28 --> Output Class Initialized
INFO - 2020-12-29 02:57:28 --> Security Class Initialized
DEBUG - 2020-12-29 02:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:57:28 --> Input Class Initialized
INFO - 2020-12-29 02:57:28 --> Language Class Initialized
INFO - 2020-12-29 02:57:28 --> Language Class Initialized
INFO - 2020-12-29 02:57:28 --> Config Class Initialized
INFO - 2020-12-29 02:57:28 --> Loader Class Initialized
INFO - 2020-12-29 02:57:28 --> Helper loaded: url_helper
INFO - 2020-12-29 02:57:28 --> Helper loaded: file_helper
INFO - 2020-12-29 02:57:28 --> Helper loaded: form_helper
INFO - 2020-12-29 02:57:28 --> Helper loaded: my_helper
INFO - 2020-12-29 02:57:28 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:57:28 --> Controller Class Initialized
INFO - 2020-12-29 02:57:28 --> Config Class Initialized
INFO - 2020-12-29 02:57:28 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:57:28 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:57:28 --> Utf8 Class Initialized
INFO - 2020-12-29 02:57:28 --> URI Class Initialized
INFO - 2020-12-29 02:57:28 --> Router Class Initialized
INFO - 2020-12-29 02:57:28 --> Output Class Initialized
INFO - 2020-12-29 02:57:28 --> Security Class Initialized
DEBUG - 2020-12-29 02:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:57:28 --> Input Class Initialized
INFO - 2020-12-29 02:57:28 --> Language Class Initialized
INFO - 2020-12-29 02:57:28 --> Language Class Initialized
INFO - 2020-12-29 02:57:28 --> Config Class Initialized
INFO - 2020-12-29 02:57:28 --> Loader Class Initialized
INFO - 2020-12-29 02:57:28 --> Helper loaded: url_helper
INFO - 2020-12-29 02:57:28 --> Helper loaded: file_helper
INFO - 2020-12-29 02:57:28 --> Helper loaded: form_helper
INFO - 2020-12-29 02:57:28 --> Helper loaded: my_helper
INFO - 2020-12-29 02:57:28 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:57:28 --> Controller Class Initialized
DEBUG - 2020-12-29 02:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:57:29 --> Final output sent to browser
DEBUG - 2020-12-29 02:57:29 --> Total execution time: 0.6925
INFO - 2020-12-29 02:57:32 --> Config Class Initialized
INFO - 2020-12-29 02:57:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:57:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:57:32 --> Utf8 Class Initialized
INFO - 2020-12-29 02:57:32 --> URI Class Initialized
INFO - 2020-12-29 02:57:32 --> Router Class Initialized
INFO - 2020-12-29 02:57:32 --> Output Class Initialized
INFO - 2020-12-29 02:57:32 --> Security Class Initialized
DEBUG - 2020-12-29 02:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:57:32 --> Input Class Initialized
INFO - 2020-12-29 02:57:32 --> Language Class Initialized
INFO - 2020-12-29 02:57:32 --> Language Class Initialized
INFO - 2020-12-29 02:57:32 --> Config Class Initialized
INFO - 2020-12-29 02:57:32 --> Loader Class Initialized
INFO - 2020-12-29 02:57:32 --> Helper loaded: url_helper
INFO - 2020-12-29 02:57:32 --> Helper loaded: file_helper
INFO - 2020-12-29 02:57:32 --> Helper loaded: form_helper
INFO - 2020-12-29 02:57:32 --> Helper loaded: my_helper
INFO - 2020-12-29 02:57:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:57:32 --> Controller Class Initialized
DEBUG - 2020-12-29 02:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:57:32 --> Final output sent to browser
DEBUG - 2020-12-29 02:57:32 --> Total execution time: 0.0767
INFO - 2020-12-29 02:58:07 --> Config Class Initialized
INFO - 2020-12-29 02:58:07 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:58:07 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:58:07 --> Utf8 Class Initialized
INFO - 2020-12-29 02:58:07 --> URI Class Initialized
INFO - 2020-12-29 02:58:07 --> Router Class Initialized
INFO - 2020-12-29 02:58:07 --> Output Class Initialized
INFO - 2020-12-29 02:58:07 --> Security Class Initialized
DEBUG - 2020-12-29 02:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:58:07 --> Input Class Initialized
INFO - 2020-12-29 02:58:07 --> Language Class Initialized
INFO - 2020-12-29 02:58:07 --> Language Class Initialized
INFO - 2020-12-29 02:58:07 --> Config Class Initialized
INFO - 2020-12-29 02:58:07 --> Loader Class Initialized
INFO - 2020-12-29 02:58:07 --> Helper loaded: url_helper
INFO - 2020-12-29 02:58:07 --> Helper loaded: file_helper
INFO - 2020-12-29 02:58:07 --> Helper loaded: form_helper
INFO - 2020-12-29 02:58:07 --> Helper loaded: my_helper
INFO - 2020-12-29 02:58:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:58:07 --> Controller Class Initialized
INFO - 2020-12-29 02:58:07 --> Config Class Initialized
INFO - 2020-12-29 02:58:07 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:58:07 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:58:07 --> Utf8 Class Initialized
INFO - 2020-12-29 02:58:07 --> URI Class Initialized
INFO - 2020-12-29 02:58:07 --> Router Class Initialized
INFO - 2020-12-29 02:58:07 --> Output Class Initialized
INFO - 2020-12-29 02:58:07 --> Security Class Initialized
DEBUG - 2020-12-29 02:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:58:07 --> Input Class Initialized
INFO - 2020-12-29 02:58:07 --> Language Class Initialized
INFO - 2020-12-29 02:58:07 --> Language Class Initialized
INFO - 2020-12-29 02:58:07 --> Config Class Initialized
INFO - 2020-12-29 02:58:07 --> Loader Class Initialized
INFO - 2020-12-29 02:58:07 --> Helper loaded: url_helper
INFO - 2020-12-29 02:58:07 --> Helper loaded: file_helper
INFO - 2020-12-29 02:58:07 --> Helper loaded: form_helper
INFO - 2020-12-29 02:58:07 --> Helper loaded: my_helper
INFO - 2020-12-29 02:58:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:58:07 --> Controller Class Initialized
DEBUG - 2020-12-29 02:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:58:07 --> Final output sent to browser
DEBUG - 2020-12-29 02:58:07 --> Total execution time: 0.0909
INFO - 2020-12-29 02:58:10 --> Config Class Initialized
INFO - 2020-12-29 02:58:10 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:58:10 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:58:10 --> Utf8 Class Initialized
INFO - 2020-12-29 02:58:10 --> URI Class Initialized
INFO - 2020-12-29 02:58:10 --> Router Class Initialized
INFO - 2020-12-29 02:58:10 --> Output Class Initialized
INFO - 2020-12-29 02:58:10 --> Security Class Initialized
DEBUG - 2020-12-29 02:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:58:10 --> Input Class Initialized
INFO - 2020-12-29 02:58:10 --> Language Class Initialized
INFO - 2020-12-29 02:58:10 --> Language Class Initialized
INFO - 2020-12-29 02:58:10 --> Config Class Initialized
INFO - 2020-12-29 02:58:10 --> Loader Class Initialized
INFO - 2020-12-29 02:58:10 --> Helper loaded: url_helper
INFO - 2020-12-29 02:58:10 --> Helper loaded: file_helper
INFO - 2020-12-29 02:58:10 --> Helper loaded: form_helper
INFO - 2020-12-29 02:58:10 --> Helper loaded: my_helper
INFO - 2020-12-29 02:58:10 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:58:10 --> Controller Class Initialized
DEBUG - 2020-12-29 02:58:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:58:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:58:10 --> Final output sent to browser
DEBUG - 2020-12-29 02:58:10 --> Total execution time: 0.0779
INFO - 2020-12-29 02:58:30 --> Config Class Initialized
INFO - 2020-12-29 02:58:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:58:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:58:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:58:30 --> URI Class Initialized
INFO - 2020-12-29 02:58:30 --> Router Class Initialized
INFO - 2020-12-29 02:58:30 --> Output Class Initialized
INFO - 2020-12-29 02:58:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:58:30 --> Input Class Initialized
INFO - 2020-12-29 02:58:30 --> Language Class Initialized
INFO - 2020-12-29 02:58:30 --> Language Class Initialized
INFO - 2020-12-29 02:58:30 --> Config Class Initialized
INFO - 2020-12-29 02:58:30 --> Loader Class Initialized
INFO - 2020-12-29 02:58:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:58:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:58:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:58:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:58:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:58:30 --> Controller Class Initialized
INFO - 2020-12-29 02:58:30 --> Config Class Initialized
INFO - 2020-12-29 02:58:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:58:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:58:30 --> Utf8 Class Initialized
INFO - 2020-12-29 02:58:30 --> URI Class Initialized
INFO - 2020-12-29 02:58:30 --> Router Class Initialized
INFO - 2020-12-29 02:58:30 --> Output Class Initialized
INFO - 2020-12-29 02:58:30 --> Security Class Initialized
DEBUG - 2020-12-29 02:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:58:30 --> Input Class Initialized
INFO - 2020-12-29 02:58:30 --> Language Class Initialized
INFO - 2020-12-29 02:58:30 --> Language Class Initialized
INFO - 2020-12-29 02:58:30 --> Config Class Initialized
INFO - 2020-12-29 02:58:30 --> Loader Class Initialized
INFO - 2020-12-29 02:58:30 --> Helper loaded: url_helper
INFO - 2020-12-29 02:58:30 --> Helper loaded: file_helper
INFO - 2020-12-29 02:58:30 --> Helper loaded: form_helper
INFO - 2020-12-29 02:58:30 --> Helper loaded: my_helper
INFO - 2020-12-29 02:58:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:58:30 --> Controller Class Initialized
DEBUG - 2020-12-29 02:58:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:58:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:58:30 --> Final output sent to browser
DEBUG - 2020-12-29 02:58:30 --> Total execution time: 0.0597
INFO - 2020-12-29 02:58:46 --> Config Class Initialized
INFO - 2020-12-29 02:58:46 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:58:46 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:58:46 --> Utf8 Class Initialized
INFO - 2020-12-29 02:58:46 --> URI Class Initialized
INFO - 2020-12-29 02:58:46 --> Router Class Initialized
INFO - 2020-12-29 02:58:46 --> Output Class Initialized
INFO - 2020-12-29 02:58:46 --> Security Class Initialized
DEBUG - 2020-12-29 02:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:58:46 --> Input Class Initialized
INFO - 2020-12-29 02:58:46 --> Language Class Initialized
INFO - 2020-12-29 02:58:46 --> Language Class Initialized
INFO - 2020-12-29 02:58:46 --> Config Class Initialized
INFO - 2020-12-29 02:58:46 --> Loader Class Initialized
INFO - 2020-12-29 02:58:46 --> Helper loaded: url_helper
INFO - 2020-12-29 02:58:46 --> Helper loaded: file_helper
INFO - 2020-12-29 02:58:46 --> Helper loaded: form_helper
INFO - 2020-12-29 02:58:46 --> Helper loaded: my_helper
INFO - 2020-12-29 02:58:46 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:58:46 --> Controller Class Initialized
DEBUG - 2020-12-29 02:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:58:46 --> Final output sent to browser
DEBUG - 2020-12-29 02:58:46 --> Total execution time: 0.0944
INFO - 2020-12-29 02:59:04 --> Config Class Initialized
INFO - 2020-12-29 02:59:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:59:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:59:04 --> Utf8 Class Initialized
INFO - 2020-12-29 02:59:04 --> URI Class Initialized
INFO - 2020-12-29 02:59:04 --> Router Class Initialized
INFO - 2020-12-29 02:59:04 --> Output Class Initialized
INFO - 2020-12-29 02:59:04 --> Security Class Initialized
DEBUG - 2020-12-29 02:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:59:04 --> Input Class Initialized
INFO - 2020-12-29 02:59:04 --> Language Class Initialized
INFO - 2020-12-29 02:59:04 --> Language Class Initialized
INFO - 2020-12-29 02:59:04 --> Config Class Initialized
INFO - 2020-12-29 02:59:04 --> Loader Class Initialized
INFO - 2020-12-29 02:59:04 --> Helper loaded: url_helper
INFO - 2020-12-29 02:59:04 --> Helper loaded: file_helper
INFO - 2020-12-29 02:59:04 --> Helper loaded: form_helper
INFO - 2020-12-29 02:59:04 --> Helper loaded: my_helper
INFO - 2020-12-29 02:59:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:59:04 --> Controller Class Initialized
INFO - 2020-12-29 02:59:04 --> Config Class Initialized
INFO - 2020-12-29 02:59:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:59:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:59:04 --> Utf8 Class Initialized
INFO - 2020-12-29 02:59:04 --> URI Class Initialized
INFO - 2020-12-29 02:59:04 --> Router Class Initialized
INFO - 2020-12-29 02:59:04 --> Output Class Initialized
INFO - 2020-12-29 02:59:04 --> Security Class Initialized
DEBUG - 2020-12-29 02:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:59:04 --> Input Class Initialized
INFO - 2020-12-29 02:59:04 --> Language Class Initialized
INFO - 2020-12-29 02:59:04 --> Language Class Initialized
INFO - 2020-12-29 02:59:04 --> Config Class Initialized
INFO - 2020-12-29 02:59:04 --> Loader Class Initialized
INFO - 2020-12-29 02:59:04 --> Helper loaded: url_helper
INFO - 2020-12-29 02:59:04 --> Helper loaded: file_helper
INFO - 2020-12-29 02:59:04 --> Helper loaded: form_helper
INFO - 2020-12-29 02:59:04 --> Helper loaded: my_helper
INFO - 2020-12-29 02:59:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:59:04 --> Controller Class Initialized
DEBUG - 2020-12-29 02:59:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:59:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:59:04 --> Final output sent to browser
DEBUG - 2020-12-29 02:59:04 --> Total execution time: 0.0800
INFO - 2020-12-29 02:59:22 --> Config Class Initialized
INFO - 2020-12-29 02:59:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:59:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:59:22 --> Utf8 Class Initialized
INFO - 2020-12-29 02:59:22 --> URI Class Initialized
INFO - 2020-12-29 02:59:22 --> Router Class Initialized
INFO - 2020-12-29 02:59:22 --> Output Class Initialized
INFO - 2020-12-29 02:59:22 --> Security Class Initialized
DEBUG - 2020-12-29 02:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:59:22 --> Input Class Initialized
INFO - 2020-12-29 02:59:22 --> Language Class Initialized
INFO - 2020-12-29 02:59:22 --> Language Class Initialized
INFO - 2020-12-29 02:59:22 --> Config Class Initialized
INFO - 2020-12-29 02:59:22 --> Loader Class Initialized
INFO - 2020-12-29 02:59:22 --> Helper loaded: url_helper
INFO - 2020-12-29 02:59:22 --> Helper loaded: file_helper
INFO - 2020-12-29 02:59:22 --> Helper loaded: form_helper
INFO - 2020-12-29 02:59:22 --> Helper loaded: my_helper
INFO - 2020-12-29 02:59:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:59:23 --> Controller Class Initialized
DEBUG - 2020-12-29 02:59:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:59:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:59:23 --> Final output sent to browser
DEBUG - 2020-12-29 02:59:23 --> Total execution time: 0.0844
INFO - 2020-12-29 02:59:35 --> Config Class Initialized
INFO - 2020-12-29 02:59:35 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:59:35 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:59:35 --> Utf8 Class Initialized
INFO - 2020-12-29 02:59:35 --> URI Class Initialized
INFO - 2020-12-29 02:59:35 --> Router Class Initialized
INFO - 2020-12-29 02:59:35 --> Output Class Initialized
INFO - 2020-12-29 02:59:35 --> Security Class Initialized
DEBUG - 2020-12-29 02:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:59:35 --> Input Class Initialized
INFO - 2020-12-29 02:59:35 --> Language Class Initialized
INFO - 2020-12-29 02:59:35 --> Language Class Initialized
INFO - 2020-12-29 02:59:35 --> Config Class Initialized
INFO - 2020-12-29 02:59:35 --> Loader Class Initialized
INFO - 2020-12-29 02:59:35 --> Helper loaded: url_helper
INFO - 2020-12-29 02:59:35 --> Helper loaded: file_helper
INFO - 2020-12-29 02:59:35 --> Helper loaded: form_helper
INFO - 2020-12-29 02:59:35 --> Helper loaded: my_helper
INFO - 2020-12-29 02:59:35 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:59:35 --> Controller Class Initialized
INFO - 2020-12-29 02:59:35 --> Config Class Initialized
INFO - 2020-12-29 02:59:35 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:59:35 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:59:35 --> Utf8 Class Initialized
INFO - 2020-12-29 02:59:35 --> URI Class Initialized
INFO - 2020-12-29 02:59:35 --> Router Class Initialized
INFO - 2020-12-29 02:59:35 --> Output Class Initialized
INFO - 2020-12-29 02:59:35 --> Security Class Initialized
DEBUG - 2020-12-29 02:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:59:35 --> Input Class Initialized
INFO - 2020-12-29 02:59:35 --> Language Class Initialized
INFO - 2020-12-29 02:59:35 --> Language Class Initialized
INFO - 2020-12-29 02:59:35 --> Config Class Initialized
INFO - 2020-12-29 02:59:35 --> Loader Class Initialized
INFO - 2020-12-29 02:59:35 --> Helper loaded: url_helper
INFO - 2020-12-29 02:59:35 --> Helper loaded: file_helper
INFO - 2020-12-29 02:59:35 --> Helper loaded: form_helper
INFO - 2020-12-29 02:59:35 --> Helper loaded: my_helper
INFO - 2020-12-29 02:59:35 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:59:35 --> Controller Class Initialized
DEBUG - 2020-12-29 02:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 02:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:59:35 --> Final output sent to browser
DEBUG - 2020-12-29 02:59:35 --> Total execution time: 0.0705
INFO - 2020-12-29 02:59:58 --> Config Class Initialized
INFO - 2020-12-29 02:59:58 --> Hooks Class Initialized
DEBUG - 2020-12-29 02:59:58 --> UTF-8 Support Enabled
INFO - 2020-12-29 02:59:58 --> Utf8 Class Initialized
INFO - 2020-12-29 02:59:58 --> URI Class Initialized
INFO - 2020-12-29 02:59:58 --> Router Class Initialized
INFO - 2020-12-29 02:59:58 --> Output Class Initialized
INFO - 2020-12-29 02:59:58 --> Security Class Initialized
DEBUG - 2020-12-29 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 02:59:58 --> Input Class Initialized
INFO - 2020-12-29 02:59:58 --> Language Class Initialized
INFO - 2020-12-29 02:59:58 --> Language Class Initialized
INFO - 2020-12-29 02:59:58 --> Config Class Initialized
INFO - 2020-12-29 02:59:58 --> Loader Class Initialized
INFO - 2020-12-29 02:59:58 --> Helper loaded: url_helper
INFO - 2020-12-29 02:59:58 --> Helper loaded: file_helper
INFO - 2020-12-29 02:59:58 --> Helper loaded: form_helper
INFO - 2020-12-29 02:59:58 --> Helper loaded: my_helper
INFO - 2020-12-29 02:59:58 --> Database Driver Class Initialized
DEBUG - 2020-12-29 02:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 02:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 02:59:58 --> Controller Class Initialized
DEBUG - 2020-12-29 02:59:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 02:59:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 02:59:58 --> Final output sent to browser
DEBUG - 2020-12-29 02:59:58 --> Total execution time: 0.0838
INFO - 2020-12-29 03:00:06 --> Config Class Initialized
INFO - 2020-12-29 03:00:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:00:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:00:06 --> Utf8 Class Initialized
INFO - 2020-12-29 03:00:06 --> URI Class Initialized
INFO - 2020-12-29 03:00:06 --> Router Class Initialized
INFO - 2020-12-29 03:00:06 --> Output Class Initialized
INFO - 2020-12-29 03:00:06 --> Security Class Initialized
DEBUG - 2020-12-29 03:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:00:06 --> Input Class Initialized
INFO - 2020-12-29 03:00:06 --> Language Class Initialized
INFO - 2020-12-29 03:00:06 --> Language Class Initialized
INFO - 2020-12-29 03:00:06 --> Config Class Initialized
INFO - 2020-12-29 03:00:06 --> Loader Class Initialized
INFO - 2020-12-29 03:00:06 --> Helper loaded: url_helper
INFO - 2020-12-29 03:00:06 --> Helper loaded: file_helper
INFO - 2020-12-29 03:00:06 --> Helper loaded: form_helper
INFO - 2020-12-29 03:00:06 --> Helper loaded: my_helper
INFO - 2020-12-29 03:00:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:00:06 --> Controller Class Initialized
INFO - 2020-12-29 03:00:06 --> Config Class Initialized
INFO - 2020-12-29 03:00:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:00:07 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:00:07 --> Utf8 Class Initialized
INFO - 2020-12-29 03:00:07 --> URI Class Initialized
INFO - 2020-12-29 03:00:07 --> Router Class Initialized
INFO - 2020-12-29 03:00:07 --> Output Class Initialized
INFO - 2020-12-29 03:00:07 --> Security Class Initialized
DEBUG - 2020-12-29 03:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:00:07 --> Input Class Initialized
INFO - 2020-12-29 03:00:07 --> Language Class Initialized
INFO - 2020-12-29 03:00:07 --> Language Class Initialized
INFO - 2020-12-29 03:00:07 --> Config Class Initialized
INFO - 2020-12-29 03:00:07 --> Loader Class Initialized
INFO - 2020-12-29 03:00:07 --> Helper loaded: url_helper
INFO - 2020-12-29 03:00:07 --> Helper loaded: file_helper
INFO - 2020-12-29 03:00:07 --> Helper loaded: form_helper
INFO - 2020-12-29 03:00:07 --> Helper loaded: my_helper
INFO - 2020-12-29 03:00:07 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:00:07 --> Controller Class Initialized
DEBUG - 2020-12-29 03:00:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:00:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:00:07 --> Final output sent to browser
DEBUG - 2020-12-29 03:00:07 --> Total execution time: 0.0685
INFO - 2020-12-29 03:00:08 --> Config Class Initialized
INFO - 2020-12-29 03:00:08 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:00:08 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:00:08 --> Utf8 Class Initialized
INFO - 2020-12-29 03:00:08 --> URI Class Initialized
INFO - 2020-12-29 03:00:08 --> Router Class Initialized
INFO - 2020-12-29 03:00:08 --> Output Class Initialized
INFO - 2020-12-29 03:00:08 --> Security Class Initialized
DEBUG - 2020-12-29 03:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:00:08 --> Input Class Initialized
INFO - 2020-12-29 03:00:08 --> Language Class Initialized
INFO - 2020-12-29 03:00:08 --> Language Class Initialized
INFO - 2020-12-29 03:00:08 --> Config Class Initialized
INFO - 2020-12-29 03:00:08 --> Loader Class Initialized
INFO - 2020-12-29 03:00:08 --> Helper loaded: url_helper
INFO - 2020-12-29 03:00:08 --> Helper loaded: file_helper
INFO - 2020-12-29 03:00:08 --> Helper loaded: form_helper
INFO - 2020-12-29 03:00:08 --> Helper loaded: my_helper
INFO - 2020-12-29 03:00:08 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:00:08 --> Controller Class Initialized
DEBUG - 2020-12-29 03:00:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:00:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:00:08 --> Final output sent to browser
DEBUG - 2020-12-29 03:00:08 --> Total execution time: 0.1098
INFO - 2020-12-29 03:00:34 --> Config Class Initialized
INFO - 2020-12-29 03:00:34 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:00:34 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:00:34 --> Utf8 Class Initialized
INFO - 2020-12-29 03:00:34 --> URI Class Initialized
INFO - 2020-12-29 03:00:34 --> Router Class Initialized
INFO - 2020-12-29 03:00:34 --> Output Class Initialized
INFO - 2020-12-29 03:00:34 --> Security Class Initialized
DEBUG - 2020-12-29 03:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:00:34 --> Input Class Initialized
INFO - 2020-12-29 03:00:34 --> Language Class Initialized
INFO - 2020-12-29 03:00:34 --> Language Class Initialized
INFO - 2020-12-29 03:00:34 --> Config Class Initialized
INFO - 2020-12-29 03:00:34 --> Loader Class Initialized
INFO - 2020-12-29 03:00:34 --> Helper loaded: url_helper
INFO - 2020-12-29 03:00:34 --> Helper loaded: file_helper
INFO - 2020-12-29 03:00:34 --> Helper loaded: form_helper
INFO - 2020-12-29 03:00:34 --> Helper loaded: my_helper
INFO - 2020-12-29 03:00:34 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:00:34 --> Controller Class Initialized
INFO - 2020-12-29 03:00:34 --> Config Class Initialized
INFO - 2020-12-29 03:00:34 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:00:34 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:00:34 --> Utf8 Class Initialized
INFO - 2020-12-29 03:00:34 --> URI Class Initialized
INFO - 2020-12-29 03:00:34 --> Router Class Initialized
INFO - 2020-12-29 03:00:34 --> Output Class Initialized
INFO - 2020-12-29 03:00:34 --> Security Class Initialized
DEBUG - 2020-12-29 03:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:00:34 --> Input Class Initialized
INFO - 2020-12-29 03:00:34 --> Language Class Initialized
INFO - 2020-12-29 03:00:34 --> Language Class Initialized
INFO - 2020-12-29 03:00:34 --> Config Class Initialized
INFO - 2020-12-29 03:00:34 --> Loader Class Initialized
INFO - 2020-12-29 03:00:34 --> Helper loaded: url_helper
INFO - 2020-12-29 03:00:34 --> Helper loaded: file_helper
INFO - 2020-12-29 03:00:34 --> Helper loaded: form_helper
INFO - 2020-12-29 03:00:34 --> Helper loaded: my_helper
INFO - 2020-12-29 03:00:35 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:00:35 --> Controller Class Initialized
DEBUG - 2020-12-29 03:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:00:35 --> Final output sent to browser
DEBUG - 2020-12-29 03:00:35 --> Total execution time: 0.0915
INFO - 2020-12-29 03:00:37 --> Config Class Initialized
INFO - 2020-12-29 03:00:37 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:00:37 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:00:37 --> Utf8 Class Initialized
INFO - 2020-12-29 03:00:37 --> URI Class Initialized
INFO - 2020-12-29 03:00:37 --> Router Class Initialized
INFO - 2020-12-29 03:00:37 --> Output Class Initialized
INFO - 2020-12-29 03:00:37 --> Security Class Initialized
DEBUG - 2020-12-29 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:00:37 --> Input Class Initialized
INFO - 2020-12-29 03:00:37 --> Language Class Initialized
INFO - 2020-12-29 03:00:37 --> Language Class Initialized
INFO - 2020-12-29 03:00:37 --> Config Class Initialized
INFO - 2020-12-29 03:00:37 --> Loader Class Initialized
INFO - 2020-12-29 03:00:37 --> Helper loaded: url_helper
INFO - 2020-12-29 03:00:37 --> Helper loaded: file_helper
INFO - 2020-12-29 03:00:37 --> Helper loaded: form_helper
INFO - 2020-12-29 03:00:37 --> Helper loaded: my_helper
INFO - 2020-12-29 03:00:37 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:00:37 --> Controller Class Initialized
DEBUG - 2020-12-29 03:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:00:37 --> Final output sent to browser
DEBUG - 2020-12-29 03:00:37 --> Total execution time: 0.0920
INFO - 2020-12-29 03:00:53 --> Config Class Initialized
INFO - 2020-12-29 03:00:53 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:00:53 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:00:53 --> Utf8 Class Initialized
INFO - 2020-12-29 03:00:53 --> URI Class Initialized
INFO - 2020-12-29 03:00:53 --> Router Class Initialized
INFO - 2020-12-29 03:00:53 --> Output Class Initialized
INFO - 2020-12-29 03:00:53 --> Security Class Initialized
DEBUG - 2020-12-29 03:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:00:53 --> Input Class Initialized
INFO - 2020-12-29 03:00:53 --> Language Class Initialized
INFO - 2020-12-29 03:00:53 --> Language Class Initialized
INFO - 2020-12-29 03:00:53 --> Config Class Initialized
INFO - 2020-12-29 03:00:53 --> Loader Class Initialized
INFO - 2020-12-29 03:00:53 --> Helper loaded: url_helper
INFO - 2020-12-29 03:00:53 --> Helper loaded: file_helper
INFO - 2020-12-29 03:00:53 --> Helper loaded: form_helper
INFO - 2020-12-29 03:00:53 --> Helper loaded: my_helper
INFO - 2020-12-29 03:00:53 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:00:53 --> Controller Class Initialized
INFO - 2020-12-29 03:00:53 --> Config Class Initialized
INFO - 2020-12-29 03:00:53 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:00:53 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:00:53 --> Utf8 Class Initialized
INFO - 2020-12-29 03:00:53 --> URI Class Initialized
INFO - 2020-12-29 03:00:53 --> Router Class Initialized
INFO - 2020-12-29 03:00:53 --> Output Class Initialized
INFO - 2020-12-29 03:00:53 --> Security Class Initialized
DEBUG - 2020-12-29 03:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:00:53 --> Input Class Initialized
INFO - 2020-12-29 03:00:53 --> Language Class Initialized
INFO - 2020-12-29 03:00:53 --> Language Class Initialized
INFO - 2020-12-29 03:00:53 --> Config Class Initialized
INFO - 2020-12-29 03:00:53 --> Loader Class Initialized
INFO - 2020-12-29 03:00:53 --> Helper loaded: url_helper
INFO - 2020-12-29 03:00:53 --> Helper loaded: file_helper
INFO - 2020-12-29 03:00:53 --> Helper loaded: form_helper
INFO - 2020-12-29 03:00:53 --> Helper loaded: my_helper
INFO - 2020-12-29 03:00:53 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:00:53 --> Controller Class Initialized
DEBUG - 2020-12-29 03:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:00:53 --> Final output sent to browser
DEBUG - 2020-12-29 03:00:53 --> Total execution time: 0.0979
INFO - 2020-12-29 03:01:01 --> Config Class Initialized
INFO - 2020-12-29 03:01:01 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:01:01 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:01:01 --> Utf8 Class Initialized
INFO - 2020-12-29 03:01:01 --> URI Class Initialized
INFO - 2020-12-29 03:01:01 --> Router Class Initialized
INFO - 2020-12-29 03:01:01 --> Output Class Initialized
INFO - 2020-12-29 03:01:01 --> Security Class Initialized
DEBUG - 2020-12-29 03:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:01:01 --> Input Class Initialized
INFO - 2020-12-29 03:01:01 --> Language Class Initialized
INFO - 2020-12-29 03:01:01 --> Language Class Initialized
INFO - 2020-12-29 03:01:01 --> Config Class Initialized
INFO - 2020-12-29 03:01:01 --> Loader Class Initialized
INFO - 2020-12-29 03:01:01 --> Helper loaded: url_helper
INFO - 2020-12-29 03:01:01 --> Helper loaded: file_helper
INFO - 2020-12-29 03:01:01 --> Helper loaded: form_helper
INFO - 2020-12-29 03:01:01 --> Helper loaded: my_helper
INFO - 2020-12-29 03:01:01 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:01:01 --> Controller Class Initialized
DEBUG - 2020-12-29 03:01:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:01:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:01:01 --> Final output sent to browser
DEBUG - 2020-12-29 03:01:01 --> Total execution time: 0.0839
INFO - 2020-12-29 03:01:32 --> Config Class Initialized
INFO - 2020-12-29 03:01:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:01:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:01:32 --> Utf8 Class Initialized
INFO - 2020-12-29 03:01:32 --> URI Class Initialized
INFO - 2020-12-29 03:01:32 --> Router Class Initialized
INFO - 2020-12-29 03:01:32 --> Output Class Initialized
INFO - 2020-12-29 03:01:32 --> Security Class Initialized
DEBUG - 2020-12-29 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:01:32 --> Input Class Initialized
INFO - 2020-12-29 03:01:32 --> Language Class Initialized
INFO - 2020-12-29 03:01:32 --> Language Class Initialized
INFO - 2020-12-29 03:01:32 --> Config Class Initialized
INFO - 2020-12-29 03:01:32 --> Loader Class Initialized
INFO - 2020-12-29 03:01:32 --> Helper loaded: url_helper
INFO - 2020-12-29 03:01:32 --> Helper loaded: file_helper
INFO - 2020-12-29 03:01:32 --> Helper loaded: form_helper
INFO - 2020-12-29 03:01:32 --> Helper loaded: my_helper
INFO - 2020-12-29 03:01:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:01:32 --> Controller Class Initialized
INFO - 2020-12-29 03:01:32 --> Config Class Initialized
INFO - 2020-12-29 03:01:32 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:01:32 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:01:32 --> Utf8 Class Initialized
INFO - 2020-12-29 03:01:32 --> URI Class Initialized
INFO - 2020-12-29 03:01:32 --> Router Class Initialized
INFO - 2020-12-29 03:01:32 --> Output Class Initialized
INFO - 2020-12-29 03:01:32 --> Security Class Initialized
DEBUG - 2020-12-29 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:01:32 --> Input Class Initialized
INFO - 2020-12-29 03:01:32 --> Language Class Initialized
INFO - 2020-12-29 03:01:32 --> Language Class Initialized
INFO - 2020-12-29 03:01:32 --> Config Class Initialized
INFO - 2020-12-29 03:01:32 --> Loader Class Initialized
INFO - 2020-12-29 03:01:32 --> Helper loaded: url_helper
INFO - 2020-12-29 03:01:32 --> Helper loaded: file_helper
INFO - 2020-12-29 03:01:32 --> Helper loaded: form_helper
INFO - 2020-12-29 03:01:32 --> Helper loaded: my_helper
INFO - 2020-12-29 03:01:32 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:01:32 --> Controller Class Initialized
DEBUG - 2020-12-29 03:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:01:32 --> Final output sent to browser
DEBUG - 2020-12-29 03:01:32 --> Total execution time: 0.0667
INFO - 2020-12-29 03:01:33 --> Config Class Initialized
INFO - 2020-12-29 03:01:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:01:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:01:33 --> Utf8 Class Initialized
INFO - 2020-12-29 03:01:33 --> URI Class Initialized
INFO - 2020-12-29 03:01:33 --> Router Class Initialized
INFO - 2020-12-29 03:01:33 --> Output Class Initialized
INFO - 2020-12-29 03:01:33 --> Security Class Initialized
DEBUG - 2020-12-29 03:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:01:33 --> Input Class Initialized
INFO - 2020-12-29 03:01:33 --> Language Class Initialized
INFO - 2020-12-29 03:01:33 --> Language Class Initialized
INFO - 2020-12-29 03:01:33 --> Config Class Initialized
INFO - 2020-12-29 03:01:33 --> Loader Class Initialized
INFO - 2020-12-29 03:01:33 --> Helper loaded: url_helper
INFO - 2020-12-29 03:01:33 --> Helper loaded: file_helper
INFO - 2020-12-29 03:01:33 --> Helper loaded: form_helper
INFO - 2020-12-29 03:01:33 --> Helper loaded: my_helper
INFO - 2020-12-29 03:01:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:01:33 --> Controller Class Initialized
DEBUG - 2020-12-29 03:01:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:01:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:01:33 --> Final output sent to browser
DEBUG - 2020-12-29 03:01:33 --> Total execution time: 0.0897
INFO - 2020-12-29 03:01:56 --> Config Class Initialized
INFO - 2020-12-29 03:01:56 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:01:56 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:01:56 --> Utf8 Class Initialized
INFO - 2020-12-29 03:01:56 --> URI Class Initialized
INFO - 2020-12-29 03:01:56 --> Router Class Initialized
INFO - 2020-12-29 03:01:56 --> Output Class Initialized
INFO - 2020-12-29 03:01:56 --> Security Class Initialized
DEBUG - 2020-12-29 03:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:01:56 --> Input Class Initialized
INFO - 2020-12-29 03:01:56 --> Language Class Initialized
INFO - 2020-12-29 03:01:56 --> Language Class Initialized
INFO - 2020-12-29 03:01:56 --> Config Class Initialized
INFO - 2020-12-29 03:01:56 --> Loader Class Initialized
INFO - 2020-12-29 03:01:56 --> Helper loaded: url_helper
INFO - 2020-12-29 03:01:56 --> Helper loaded: file_helper
INFO - 2020-12-29 03:01:56 --> Helper loaded: form_helper
INFO - 2020-12-29 03:01:56 --> Helper loaded: my_helper
INFO - 2020-12-29 03:01:56 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:01:57 --> Controller Class Initialized
INFO - 2020-12-29 03:01:57 --> Config Class Initialized
INFO - 2020-12-29 03:01:57 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:01:57 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:01:57 --> Utf8 Class Initialized
INFO - 2020-12-29 03:01:57 --> URI Class Initialized
INFO - 2020-12-29 03:01:57 --> Router Class Initialized
INFO - 2020-12-29 03:01:57 --> Output Class Initialized
INFO - 2020-12-29 03:01:57 --> Security Class Initialized
DEBUG - 2020-12-29 03:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:01:57 --> Input Class Initialized
INFO - 2020-12-29 03:01:57 --> Language Class Initialized
INFO - 2020-12-29 03:01:57 --> Language Class Initialized
INFO - 2020-12-29 03:01:57 --> Config Class Initialized
INFO - 2020-12-29 03:01:57 --> Loader Class Initialized
INFO - 2020-12-29 03:01:57 --> Helper loaded: url_helper
INFO - 2020-12-29 03:01:57 --> Helper loaded: file_helper
INFO - 2020-12-29 03:01:57 --> Helper loaded: form_helper
INFO - 2020-12-29 03:01:57 --> Helper loaded: my_helper
INFO - 2020-12-29 03:01:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:01:57 --> Controller Class Initialized
DEBUG - 2020-12-29 03:01:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:01:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:01:57 --> Final output sent to browser
DEBUG - 2020-12-29 03:01:57 --> Total execution time: 0.0839
INFO - 2020-12-29 03:02:05 --> Config Class Initialized
INFO - 2020-12-29 03:02:05 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:05 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:05 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:05 --> URI Class Initialized
INFO - 2020-12-29 03:02:05 --> Router Class Initialized
INFO - 2020-12-29 03:02:05 --> Output Class Initialized
INFO - 2020-12-29 03:02:05 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:05 --> Input Class Initialized
INFO - 2020-12-29 03:02:05 --> Language Class Initialized
INFO - 2020-12-29 03:02:05 --> Language Class Initialized
INFO - 2020-12-29 03:02:05 --> Config Class Initialized
INFO - 2020-12-29 03:02:05 --> Loader Class Initialized
INFO - 2020-12-29 03:02:05 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:05 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:05 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:05 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:05 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:05 --> Controller Class Initialized
DEBUG - 2020-12-29 03:02:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-12-29 03:02:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:02:05 --> Final output sent to browser
DEBUG - 2020-12-29 03:02:05 --> Total execution time: 0.0485
INFO - 2020-12-29 03:02:05 --> Config Class Initialized
INFO - 2020-12-29 03:02:05 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:05 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:05 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:05 --> URI Class Initialized
INFO - 2020-12-29 03:02:05 --> Router Class Initialized
INFO - 2020-12-29 03:02:05 --> Output Class Initialized
INFO - 2020-12-29 03:02:05 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:05 --> Input Class Initialized
INFO - 2020-12-29 03:02:05 --> Language Class Initialized
INFO - 2020-12-29 03:02:05 --> Language Class Initialized
INFO - 2020-12-29 03:02:05 --> Config Class Initialized
INFO - 2020-12-29 03:02:05 --> Loader Class Initialized
INFO - 2020-12-29 03:02:05 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:05 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:05 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:05 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:05 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:05 --> Controller Class Initialized
INFO - 2020-12-29 03:02:11 --> Config Class Initialized
INFO - 2020-12-29 03:02:11 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:11 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:11 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:11 --> URI Class Initialized
INFO - 2020-12-29 03:02:11 --> Router Class Initialized
INFO - 2020-12-29 03:02:11 --> Output Class Initialized
INFO - 2020-12-29 03:02:11 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:11 --> Input Class Initialized
INFO - 2020-12-29 03:02:11 --> Language Class Initialized
INFO - 2020-12-29 03:02:11 --> Language Class Initialized
INFO - 2020-12-29 03:02:11 --> Config Class Initialized
INFO - 2020-12-29 03:02:11 --> Loader Class Initialized
INFO - 2020-12-29 03:02:11 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:11 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:11 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:11 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:11 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:11 --> Controller Class Initialized
INFO - 2020-12-29 03:02:11 --> Final output sent to browser
DEBUG - 2020-12-29 03:02:11 --> Total execution time: 0.0862
INFO - 2020-12-29 03:02:11 --> Config Class Initialized
INFO - 2020-12-29 03:02:11 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:11 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:11 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:11 --> URI Class Initialized
INFO - 2020-12-29 03:02:11 --> Router Class Initialized
INFO - 2020-12-29 03:02:11 --> Output Class Initialized
INFO - 2020-12-29 03:02:11 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:11 --> Input Class Initialized
INFO - 2020-12-29 03:02:11 --> Language Class Initialized
INFO - 2020-12-29 03:02:11 --> Language Class Initialized
INFO - 2020-12-29 03:02:11 --> Config Class Initialized
INFO - 2020-12-29 03:02:11 --> Loader Class Initialized
INFO - 2020-12-29 03:02:11 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:11 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:11 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:11 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:11 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:11 --> Controller Class Initialized
INFO - 2020-12-29 03:02:14 --> Config Class Initialized
INFO - 2020-12-29 03:02:14 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:14 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:14 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:14 --> URI Class Initialized
INFO - 2020-12-29 03:02:14 --> Router Class Initialized
INFO - 2020-12-29 03:02:14 --> Output Class Initialized
INFO - 2020-12-29 03:02:14 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:14 --> Input Class Initialized
INFO - 2020-12-29 03:02:14 --> Language Class Initialized
INFO - 2020-12-29 03:02:14 --> Language Class Initialized
INFO - 2020-12-29 03:02:14 --> Config Class Initialized
INFO - 2020-12-29 03:02:14 --> Loader Class Initialized
INFO - 2020-12-29 03:02:14 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:14 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:14 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:14 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:14 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:14 --> Controller Class Initialized
DEBUG - 2020-12-29 03:02:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:02:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:02:14 --> Final output sent to browser
DEBUG - 2020-12-29 03:02:14 --> Total execution time: 0.0794
INFO - 2020-12-29 03:02:30 --> Config Class Initialized
INFO - 2020-12-29 03:02:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:30 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:30 --> URI Class Initialized
INFO - 2020-12-29 03:02:30 --> Router Class Initialized
INFO - 2020-12-29 03:02:30 --> Output Class Initialized
INFO - 2020-12-29 03:02:30 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:30 --> Input Class Initialized
INFO - 2020-12-29 03:02:30 --> Language Class Initialized
INFO - 2020-12-29 03:02:30 --> Language Class Initialized
INFO - 2020-12-29 03:02:30 --> Config Class Initialized
INFO - 2020-12-29 03:02:30 --> Loader Class Initialized
INFO - 2020-12-29 03:02:30 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:30 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:30 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:30 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:30 --> Controller Class Initialized
DEBUG - 2020-12-29 03:02:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:02:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:02:30 --> Final output sent to browser
DEBUG - 2020-12-29 03:02:30 --> Total execution time: 0.1107
INFO - 2020-12-29 03:02:54 --> Config Class Initialized
INFO - 2020-12-29 03:02:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:54 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:54 --> URI Class Initialized
INFO - 2020-12-29 03:02:54 --> Router Class Initialized
INFO - 2020-12-29 03:02:54 --> Output Class Initialized
INFO - 2020-12-29 03:02:54 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:54 --> Input Class Initialized
INFO - 2020-12-29 03:02:54 --> Language Class Initialized
INFO - 2020-12-29 03:02:54 --> Language Class Initialized
INFO - 2020-12-29 03:02:54 --> Config Class Initialized
INFO - 2020-12-29 03:02:54 --> Loader Class Initialized
INFO - 2020-12-29 03:02:54 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:54 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:54 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:54 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:54 --> Controller Class Initialized
INFO - 2020-12-29 03:02:54 --> Config Class Initialized
INFO - 2020-12-29 03:02:54 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:54 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:54 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:54 --> URI Class Initialized
INFO - 2020-12-29 03:02:54 --> Router Class Initialized
INFO - 2020-12-29 03:02:54 --> Output Class Initialized
INFO - 2020-12-29 03:02:54 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:54 --> Input Class Initialized
INFO - 2020-12-29 03:02:54 --> Language Class Initialized
INFO - 2020-12-29 03:02:54 --> Language Class Initialized
INFO - 2020-12-29 03:02:54 --> Config Class Initialized
INFO - 2020-12-29 03:02:54 --> Loader Class Initialized
INFO - 2020-12-29 03:02:54 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:54 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:54 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:54 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:54 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:54 --> Controller Class Initialized
DEBUG - 2020-12-29 03:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:02:54 --> Final output sent to browser
DEBUG - 2020-12-29 03:02:54 --> Total execution time: 0.0788
INFO - 2020-12-29 03:02:55 --> Config Class Initialized
INFO - 2020-12-29 03:02:55 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:02:55 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:02:55 --> Utf8 Class Initialized
INFO - 2020-12-29 03:02:55 --> URI Class Initialized
INFO - 2020-12-29 03:02:56 --> Router Class Initialized
INFO - 2020-12-29 03:02:56 --> Output Class Initialized
INFO - 2020-12-29 03:02:56 --> Security Class Initialized
DEBUG - 2020-12-29 03:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:02:56 --> Input Class Initialized
INFO - 2020-12-29 03:02:56 --> Language Class Initialized
INFO - 2020-12-29 03:02:56 --> Language Class Initialized
INFO - 2020-12-29 03:02:56 --> Config Class Initialized
INFO - 2020-12-29 03:02:56 --> Loader Class Initialized
INFO - 2020-12-29 03:02:56 --> Helper loaded: url_helper
INFO - 2020-12-29 03:02:56 --> Helper loaded: file_helper
INFO - 2020-12-29 03:02:56 --> Helper loaded: form_helper
INFO - 2020-12-29 03:02:56 --> Helper loaded: my_helper
INFO - 2020-12-29 03:02:56 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:02:56 --> Controller Class Initialized
DEBUG - 2020-12-29 03:02:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:02:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:02:56 --> Final output sent to browser
DEBUG - 2020-12-29 03:02:56 --> Total execution time: 0.0987
INFO - 2020-12-29 03:03:15 --> Config Class Initialized
INFO - 2020-12-29 03:03:15 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:03:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:03:15 --> Utf8 Class Initialized
INFO - 2020-12-29 03:03:15 --> URI Class Initialized
INFO - 2020-12-29 03:03:15 --> Router Class Initialized
INFO - 2020-12-29 03:03:15 --> Output Class Initialized
INFO - 2020-12-29 03:03:15 --> Security Class Initialized
DEBUG - 2020-12-29 03:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:03:15 --> Input Class Initialized
INFO - 2020-12-29 03:03:15 --> Language Class Initialized
INFO - 2020-12-29 03:03:15 --> Language Class Initialized
INFO - 2020-12-29 03:03:15 --> Config Class Initialized
INFO - 2020-12-29 03:03:15 --> Loader Class Initialized
INFO - 2020-12-29 03:03:15 --> Helper loaded: url_helper
INFO - 2020-12-29 03:03:15 --> Helper loaded: file_helper
INFO - 2020-12-29 03:03:15 --> Helper loaded: form_helper
INFO - 2020-12-29 03:03:15 --> Helper loaded: my_helper
INFO - 2020-12-29 03:03:15 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:03:15 --> Controller Class Initialized
INFO - 2020-12-29 03:03:15 --> Config Class Initialized
INFO - 2020-12-29 03:03:15 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:03:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:03:15 --> Utf8 Class Initialized
INFO - 2020-12-29 03:03:15 --> URI Class Initialized
INFO - 2020-12-29 03:03:15 --> Router Class Initialized
INFO - 2020-12-29 03:03:15 --> Output Class Initialized
INFO - 2020-12-29 03:03:15 --> Security Class Initialized
DEBUG - 2020-12-29 03:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:03:15 --> Input Class Initialized
INFO - 2020-12-29 03:03:15 --> Language Class Initialized
INFO - 2020-12-29 03:03:15 --> Language Class Initialized
INFO - 2020-12-29 03:03:15 --> Config Class Initialized
INFO - 2020-12-29 03:03:15 --> Loader Class Initialized
INFO - 2020-12-29 03:03:15 --> Helper loaded: url_helper
INFO - 2020-12-29 03:03:15 --> Helper loaded: file_helper
INFO - 2020-12-29 03:03:15 --> Helper loaded: form_helper
INFO - 2020-12-29 03:03:15 --> Helper loaded: my_helper
INFO - 2020-12-29 03:03:15 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:03:15 --> Controller Class Initialized
DEBUG - 2020-12-29 03:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:03:15 --> Final output sent to browser
DEBUG - 2020-12-29 03:03:15 --> Total execution time: 0.0745
INFO - 2020-12-29 03:03:22 --> Config Class Initialized
INFO - 2020-12-29 03:03:22 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:03:22 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:03:22 --> Utf8 Class Initialized
INFO - 2020-12-29 03:03:22 --> URI Class Initialized
INFO - 2020-12-29 03:03:22 --> Router Class Initialized
INFO - 2020-12-29 03:03:22 --> Output Class Initialized
INFO - 2020-12-29 03:03:22 --> Security Class Initialized
DEBUG - 2020-12-29 03:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:03:22 --> Input Class Initialized
INFO - 2020-12-29 03:03:22 --> Language Class Initialized
INFO - 2020-12-29 03:03:22 --> Language Class Initialized
INFO - 2020-12-29 03:03:22 --> Config Class Initialized
INFO - 2020-12-29 03:03:22 --> Loader Class Initialized
INFO - 2020-12-29 03:03:22 --> Helper loaded: url_helper
INFO - 2020-12-29 03:03:22 --> Helper loaded: file_helper
INFO - 2020-12-29 03:03:22 --> Helper loaded: form_helper
INFO - 2020-12-29 03:03:22 --> Helper loaded: my_helper
INFO - 2020-12-29 03:03:22 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:03:22 --> Controller Class Initialized
DEBUG - 2020-12-29 03:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:03:22 --> Final output sent to browser
DEBUG - 2020-12-29 03:03:22 --> Total execution time: 0.0762
INFO - 2020-12-29 03:03:48 --> Config Class Initialized
INFO - 2020-12-29 03:03:48 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:03:48 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:03:48 --> Utf8 Class Initialized
INFO - 2020-12-29 03:03:48 --> URI Class Initialized
INFO - 2020-12-29 03:03:48 --> Router Class Initialized
INFO - 2020-12-29 03:03:48 --> Output Class Initialized
INFO - 2020-12-29 03:03:48 --> Security Class Initialized
DEBUG - 2020-12-29 03:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:03:48 --> Input Class Initialized
INFO - 2020-12-29 03:03:48 --> Language Class Initialized
INFO - 2020-12-29 03:03:48 --> Language Class Initialized
INFO - 2020-12-29 03:03:48 --> Config Class Initialized
INFO - 2020-12-29 03:03:48 --> Loader Class Initialized
INFO - 2020-12-29 03:03:48 --> Helper loaded: url_helper
INFO - 2020-12-29 03:03:48 --> Helper loaded: file_helper
INFO - 2020-12-29 03:03:48 --> Helper loaded: form_helper
INFO - 2020-12-29 03:03:48 --> Helper loaded: my_helper
INFO - 2020-12-29 03:03:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:03:48 --> Controller Class Initialized
INFO - 2020-12-29 03:03:48 --> Config Class Initialized
INFO - 2020-12-29 03:03:48 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:03:48 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:03:48 --> Utf8 Class Initialized
INFO - 2020-12-29 03:03:48 --> URI Class Initialized
INFO - 2020-12-29 03:03:48 --> Router Class Initialized
INFO - 2020-12-29 03:03:48 --> Output Class Initialized
INFO - 2020-12-29 03:03:48 --> Security Class Initialized
DEBUG - 2020-12-29 03:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:03:48 --> Input Class Initialized
INFO - 2020-12-29 03:03:48 --> Language Class Initialized
INFO - 2020-12-29 03:03:48 --> Language Class Initialized
INFO - 2020-12-29 03:03:48 --> Config Class Initialized
INFO - 2020-12-29 03:03:48 --> Loader Class Initialized
INFO - 2020-12-29 03:03:48 --> Helper loaded: url_helper
INFO - 2020-12-29 03:03:48 --> Helper loaded: file_helper
INFO - 2020-12-29 03:03:48 --> Helper loaded: form_helper
INFO - 2020-12-29 03:03:48 --> Helper loaded: my_helper
INFO - 2020-12-29 03:03:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:03:48 --> Controller Class Initialized
DEBUG - 2020-12-29 03:03:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:03:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:03:48 --> Final output sent to browser
DEBUG - 2020-12-29 03:03:48 --> Total execution time: 0.0893
INFO - 2020-12-29 03:03:55 --> Config Class Initialized
INFO - 2020-12-29 03:03:55 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:03:55 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:03:55 --> Utf8 Class Initialized
INFO - 2020-12-29 03:03:55 --> URI Class Initialized
INFO - 2020-12-29 03:03:55 --> Router Class Initialized
INFO - 2020-12-29 03:03:55 --> Output Class Initialized
INFO - 2020-12-29 03:03:55 --> Security Class Initialized
DEBUG - 2020-12-29 03:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:03:55 --> Input Class Initialized
INFO - 2020-12-29 03:03:55 --> Language Class Initialized
INFO - 2020-12-29 03:03:55 --> Language Class Initialized
INFO - 2020-12-29 03:03:55 --> Config Class Initialized
INFO - 2020-12-29 03:03:55 --> Loader Class Initialized
INFO - 2020-12-29 03:03:55 --> Helper loaded: url_helper
INFO - 2020-12-29 03:03:55 --> Helper loaded: file_helper
INFO - 2020-12-29 03:03:55 --> Helper loaded: form_helper
INFO - 2020-12-29 03:03:55 --> Helper loaded: my_helper
INFO - 2020-12-29 03:03:55 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:03:55 --> Controller Class Initialized
DEBUG - 2020-12-29 03:03:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:03:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:03:55 --> Final output sent to browser
DEBUG - 2020-12-29 03:03:55 --> Total execution time: 0.0767
INFO - 2020-12-29 03:04:17 --> Config Class Initialized
INFO - 2020-12-29 03:04:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:04:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:04:17 --> Utf8 Class Initialized
INFO - 2020-12-29 03:04:17 --> URI Class Initialized
INFO - 2020-12-29 03:04:17 --> Router Class Initialized
INFO - 2020-12-29 03:04:17 --> Output Class Initialized
INFO - 2020-12-29 03:04:17 --> Security Class Initialized
DEBUG - 2020-12-29 03:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:04:17 --> Input Class Initialized
INFO - 2020-12-29 03:04:17 --> Language Class Initialized
INFO - 2020-12-29 03:04:17 --> Language Class Initialized
INFO - 2020-12-29 03:04:17 --> Config Class Initialized
INFO - 2020-12-29 03:04:17 --> Loader Class Initialized
INFO - 2020-12-29 03:04:17 --> Helper loaded: url_helper
INFO - 2020-12-29 03:04:17 --> Helper loaded: file_helper
INFO - 2020-12-29 03:04:17 --> Helper loaded: form_helper
INFO - 2020-12-29 03:04:17 --> Helper loaded: my_helper
INFO - 2020-12-29 03:04:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:04:17 --> Controller Class Initialized
INFO - 2020-12-29 03:04:17 --> Config Class Initialized
INFO - 2020-12-29 03:04:17 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:04:17 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:04:17 --> Utf8 Class Initialized
INFO - 2020-12-29 03:04:17 --> URI Class Initialized
INFO - 2020-12-29 03:04:17 --> Router Class Initialized
INFO - 2020-12-29 03:04:17 --> Output Class Initialized
INFO - 2020-12-29 03:04:17 --> Security Class Initialized
DEBUG - 2020-12-29 03:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:04:17 --> Input Class Initialized
INFO - 2020-12-29 03:04:17 --> Language Class Initialized
INFO - 2020-12-29 03:04:17 --> Language Class Initialized
INFO - 2020-12-29 03:04:17 --> Config Class Initialized
INFO - 2020-12-29 03:04:17 --> Loader Class Initialized
INFO - 2020-12-29 03:04:17 --> Helper loaded: url_helper
INFO - 2020-12-29 03:04:17 --> Helper loaded: file_helper
INFO - 2020-12-29 03:04:17 --> Helper loaded: form_helper
INFO - 2020-12-29 03:04:17 --> Helper loaded: my_helper
INFO - 2020-12-29 03:04:17 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:04:17 --> Controller Class Initialized
DEBUG - 2020-12-29 03:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:04:17 --> Final output sent to browser
DEBUG - 2020-12-29 03:04:17 --> Total execution time: 0.0582
INFO - 2020-12-29 03:04:18 --> Config Class Initialized
INFO - 2020-12-29 03:04:18 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:04:18 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:04:18 --> Utf8 Class Initialized
INFO - 2020-12-29 03:04:18 --> URI Class Initialized
INFO - 2020-12-29 03:04:18 --> Router Class Initialized
INFO - 2020-12-29 03:04:18 --> Output Class Initialized
INFO - 2020-12-29 03:04:18 --> Security Class Initialized
DEBUG - 2020-12-29 03:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:04:18 --> Input Class Initialized
INFO - 2020-12-29 03:04:18 --> Language Class Initialized
INFO - 2020-12-29 03:04:18 --> Language Class Initialized
INFO - 2020-12-29 03:04:18 --> Config Class Initialized
INFO - 2020-12-29 03:04:18 --> Loader Class Initialized
INFO - 2020-12-29 03:04:18 --> Helper loaded: url_helper
INFO - 2020-12-29 03:04:18 --> Helper loaded: file_helper
INFO - 2020-12-29 03:04:18 --> Helper loaded: form_helper
INFO - 2020-12-29 03:04:18 --> Helper loaded: my_helper
INFO - 2020-12-29 03:04:18 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:04:18 --> Controller Class Initialized
DEBUG - 2020-12-29 03:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:04:18 --> Final output sent to browser
DEBUG - 2020-12-29 03:04:18 --> Total execution time: 0.0867
INFO - 2020-12-29 03:04:42 --> Config Class Initialized
INFO - 2020-12-29 03:04:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:04:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:04:42 --> Utf8 Class Initialized
INFO - 2020-12-29 03:04:42 --> URI Class Initialized
INFO - 2020-12-29 03:04:42 --> Router Class Initialized
INFO - 2020-12-29 03:04:42 --> Output Class Initialized
INFO - 2020-12-29 03:04:42 --> Security Class Initialized
DEBUG - 2020-12-29 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:04:42 --> Input Class Initialized
INFO - 2020-12-29 03:04:42 --> Language Class Initialized
INFO - 2020-12-29 03:04:42 --> Language Class Initialized
INFO - 2020-12-29 03:04:42 --> Config Class Initialized
INFO - 2020-12-29 03:04:42 --> Loader Class Initialized
INFO - 2020-12-29 03:04:42 --> Helper loaded: url_helper
INFO - 2020-12-29 03:04:42 --> Helper loaded: file_helper
INFO - 2020-12-29 03:04:42 --> Helper loaded: form_helper
INFO - 2020-12-29 03:04:42 --> Helper loaded: my_helper
INFO - 2020-12-29 03:04:42 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:04:42 --> Controller Class Initialized
INFO - 2020-12-29 03:04:42 --> Config Class Initialized
INFO - 2020-12-29 03:04:42 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:04:42 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:04:42 --> Utf8 Class Initialized
INFO - 2020-12-29 03:04:42 --> URI Class Initialized
INFO - 2020-12-29 03:04:42 --> Router Class Initialized
INFO - 2020-12-29 03:04:42 --> Output Class Initialized
INFO - 2020-12-29 03:04:42 --> Security Class Initialized
DEBUG - 2020-12-29 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:04:42 --> Input Class Initialized
INFO - 2020-12-29 03:04:42 --> Language Class Initialized
INFO - 2020-12-29 03:04:42 --> Language Class Initialized
INFO - 2020-12-29 03:04:42 --> Config Class Initialized
INFO - 2020-12-29 03:04:42 --> Loader Class Initialized
INFO - 2020-12-29 03:04:42 --> Helper loaded: url_helper
INFO - 2020-12-29 03:04:42 --> Helper loaded: file_helper
INFO - 2020-12-29 03:04:42 --> Helper loaded: form_helper
INFO - 2020-12-29 03:04:42 --> Helper loaded: my_helper
INFO - 2020-12-29 03:04:42 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:04:42 --> Controller Class Initialized
DEBUG - 2020-12-29 03:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:04:42 --> Final output sent to browser
DEBUG - 2020-12-29 03:04:42 --> Total execution time: 0.0754
INFO - 2020-12-29 03:04:43 --> Config Class Initialized
INFO - 2020-12-29 03:04:43 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:04:43 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:04:43 --> Utf8 Class Initialized
INFO - 2020-12-29 03:04:43 --> URI Class Initialized
INFO - 2020-12-29 03:04:43 --> Router Class Initialized
INFO - 2020-12-29 03:04:43 --> Output Class Initialized
INFO - 2020-12-29 03:04:43 --> Security Class Initialized
DEBUG - 2020-12-29 03:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:04:43 --> Input Class Initialized
INFO - 2020-12-29 03:04:43 --> Language Class Initialized
INFO - 2020-12-29 03:04:43 --> Language Class Initialized
INFO - 2020-12-29 03:04:43 --> Config Class Initialized
INFO - 2020-12-29 03:04:43 --> Loader Class Initialized
INFO - 2020-12-29 03:04:43 --> Helper loaded: url_helper
INFO - 2020-12-29 03:04:43 --> Helper loaded: file_helper
INFO - 2020-12-29 03:04:43 --> Helper loaded: form_helper
INFO - 2020-12-29 03:04:43 --> Helper loaded: my_helper
INFO - 2020-12-29 03:04:43 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:04:43 --> Controller Class Initialized
DEBUG - 2020-12-29 03:04:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:04:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:04:43 --> Final output sent to browser
DEBUG - 2020-12-29 03:04:43 --> Total execution time: 0.0887
INFO - 2020-12-29 03:05:03 --> Config Class Initialized
INFO - 2020-12-29 03:05:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:05:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:05:03 --> Utf8 Class Initialized
INFO - 2020-12-29 03:05:03 --> URI Class Initialized
INFO - 2020-12-29 03:05:03 --> Router Class Initialized
INFO - 2020-12-29 03:05:03 --> Output Class Initialized
INFO - 2020-12-29 03:05:03 --> Security Class Initialized
DEBUG - 2020-12-29 03:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:05:03 --> Input Class Initialized
INFO - 2020-12-29 03:05:03 --> Language Class Initialized
INFO - 2020-12-29 03:05:03 --> Language Class Initialized
INFO - 2020-12-29 03:05:03 --> Config Class Initialized
INFO - 2020-12-29 03:05:03 --> Loader Class Initialized
INFO - 2020-12-29 03:05:03 --> Helper loaded: url_helper
INFO - 2020-12-29 03:05:03 --> Helper loaded: file_helper
INFO - 2020-12-29 03:05:03 --> Helper loaded: form_helper
INFO - 2020-12-29 03:05:03 --> Helper loaded: my_helper
INFO - 2020-12-29 03:05:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:05:03 --> Controller Class Initialized
INFO - 2020-12-29 03:05:03 --> Config Class Initialized
INFO - 2020-12-29 03:05:03 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:05:03 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:05:03 --> Utf8 Class Initialized
INFO - 2020-12-29 03:05:03 --> URI Class Initialized
INFO - 2020-12-29 03:05:03 --> Router Class Initialized
INFO - 2020-12-29 03:05:03 --> Output Class Initialized
INFO - 2020-12-29 03:05:03 --> Security Class Initialized
DEBUG - 2020-12-29 03:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:05:03 --> Input Class Initialized
INFO - 2020-12-29 03:05:03 --> Language Class Initialized
INFO - 2020-12-29 03:05:03 --> Language Class Initialized
INFO - 2020-12-29 03:05:03 --> Config Class Initialized
INFO - 2020-12-29 03:05:03 --> Loader Class Initialized
INFO - 2020-12-29 03:05:03 --> Helper loaded: url_helper
INFO - 2020-12-29 03:05:03 --> Helper loaded: file_helper
INFO - 2020-12-29 03:05:03 --> Helper loaded: form_helper
INFO - 2020-12-29 03:05:03 --> Helper loaded: my_helper
INFO - 2020-12-29 03:05:03 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:05:03 --> Controller Class Initialized
DEBUG - 2020-12-29 03:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:05:03 --> Final output sent to browser
DEBUG - 2020-12-29 03:05:03 --> Total execution time: 0.0578
INFO - 2020-12-29 03:05:40 --> Config Class Initialized
INFO - 2020-12-29 03:05:40 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:05:40 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:05:40 --> Utf8 Class Initialized
INFO - 2020-12-29 03:05:40 --> URI Class Initialized
INFO - 2020-12-29 03:05:40 --> Router Class Initialized
INFO - 2020-12-29 03:05:40 --> Output Class Initialized
INFO - 2020-12-29 03:05:40 --> Security Class Initialized
DEBUG - 2020-12-29 03:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:05:40 --> Input Class Initialized
INFO - 2020-12-29 03:05:40 --> Language Class Initialized
INFO - 2020-12-29 03:05:40 --> Language Class Initialized
INFO - 2020-12-29 03:05:40 --> Config Class Initialized
INFO - 2020-12-29 03:05:40 --> Loader Class Initialized
INFO - 2020-12-29 03:05:40 --> Helper loaded: url_helper
INFO - 2020-12-29 03:05:40 --> Helper loaded: file_helper
INFO - 2020-12-29 03:05:41 --> Helper loaded: form_helper
INFO - 2020-12-29 03:05:41 --> Helper loaded: my_helper
INFO - 2020-12-29 03:05:41 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:05:41 --> Controller Class Initialized
DEBUG - 2020-12-29 03:05:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:05:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:05:41 --> Final output sent to browser
DEBUG - 2020-12-29 03:05:41 --> Total execution time: 0.0831
INFO - 2020-12-29 03:06:08 --> Config Class Initialized
INFO - 2020-12-29 03:06:08 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:08 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:08 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:08 --> URI Class Initialized
INFO - 2020-12-29 03:06:08 --> Router Class Initialized
INFO - 2020-12-29 03:06:08 --> Output Class Initialized
INFO - 2020-12-29 03:06:08 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:08 --> Input Class Initialized
INFO - 2020-12-29 03:06:08 --> Language Class Initialized
INFO - 2020-12-29 03:06:08 --> Language Class Initialized
INFO - 2020-12-29 03:06:08 --> Config Class Initialized
INFO - 2020-12-29 03:06:08 --> Loader Class Initialized
INFO - 2020-12-29 03:06:08 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:08 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:08 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:08 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:08 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:08 --> Controller Class Initialized
INFO - 2020-12-29 03:06:08 --> Config Class Initialized
INFO - 2020-12-29 03:06:08 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:08 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:08 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:08 --> URI Class Initialized
INFO - 2020-12-29 03:06:08 --> Router Class Initialized
INFO - 2020-12-29 03:06:08 --> Output Class Initialized
INFO - 2020-12-29 03:06:08 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:08 --> Input Class Initialized
INFO - 2020-12-29 03:06:08 --> Language Class Initialized
INFO - 2020-12-29 03:06:08 --> Language Class Initialized
INFO - 2020-12-29 03:06:08 --> Config Class Initialized
INFO - 2020-12-29 03:06:08 --> Loader Class Initialized
INFO - 2020-12-29 03:06:08 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:08 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:08 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:08 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:08 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:08 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:06:08 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:08 --> Total execution time: 0.0861
INFO - 2020-12-29 03:06:13 --> Config Class Initialized
INFO - 2020-12-29 03:06:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:13 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:13 --> URI Class Initialized
INFO - 2020-12-29 03:06:13 --> Router Class Initialized
INFO - 2020-12-29 03:06:13 --> Output Class Initialized
INFO - 2020-12-29 03:06:13 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:13 --> Input Class Initialized
INFO - 2020-12-29 03:06:13 --> Language Class Initialized
INFO - 2020-12-29 03:06:13 --> Language Class Initialized
INFO - 2020-12-29 03:06:13 --> Config Class Initialized
INFO - 2020-12-29 03:06:13 --> Loader Class Initialized
INFO - 2020-12-29 03:06:13 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:13 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:13 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:13 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:13 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:06:13 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:13 --> Total execution time: 0.0918
INFO - 2020-12-29 03:06:27 --> Config Class Initialized
INFO - 2020-12-29 03:06:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:27 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:27 --> URI Class Initialized
INFO - 2020-12-29 03:06:27 --> Router Class Initialized
INFO - 2020-12-29 03:06:27 --> Output Class Initialized
INFO - 2020-12-29 03:06:27 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:27 --> Input Class Initialized
INFO - 2020-12-29 03:06:27 --> Language Class Initialized
INFO - 2020-12-29 03:06:27 --> Language Class Initialized
INFO - 2020-12-29 03:06:27 --> Config Class Initialized
INFO - 2020-12-29 03:06:27 --> Loader Class Initialized
INFO - 2020-12-29 03:06:27 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:27 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:27 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:27 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:27 --> Controller Class Initialized
INFO - 2020-12-29 03:06:27 --> Config Class Initialized
INFO - 2020-12-29 03:06:27 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:27 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:27 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:27 --> URI Class Initialized
INFO - 2020-12-29 03:06:27 --> Router Class Initialized
INFO - 2020-12-29 03:06:27 --> Output Class Initialized
INFO - 2020-12-29 03:06:27 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:27 --> Input Class Initialized
INFO - 2020-12-29 03:06:27 --> Language Class Initialized
INFO - 2020-12-29 03:06:27 --> Language Class Initialized
INFO - 2020-12-29 03:06:27 --> Config Class Initialized
INFO - 2020-12-29 03:06:27 --> Loader Class Initialized
INFO - 2020-12-29 03:06:27 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:27 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:27 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:27 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:27 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:27 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:06:27 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:27 --> Total execution time: 0.0853
INFO - 2020-12-29 03:06:33 --> Config Class Initialized
INFO - 2020-12-29 03:06:33 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:33 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:33 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:33 --> URI Class Initialized
INFO - 2020-12-29 03:06:33 --> Router Class Initialized
INFO - 2020-12-29 03:06:33 --> Output Class Initialized
INFO - 2020-12-29 03:06:33 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:33 --> Input Class Initialized
INFO - 2020-12-29 03:06:33 --> Language Class Initialized
INFO - 2020-12-29 03:06:33 --> Language Class Initialized
INFO - 2020-12-29 03:06:33 --> Config Class Initialized
INFO - 2020-12-29 03:06:33 --> Loader Class Initialized
INFO - 2020-12-29 03:06:33 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:33 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:33 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:33 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:33 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:33 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:06:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:06:33 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:33 --> Total execution time: 0.0890
INFO - 2020-12-29 03:06:44 --> Config Class Initialized
INFO - 2020-12-29 03:06:44 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:44 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:44 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:44 --> URI Class Initialized
INFO - 2020-12-29 03:06:44 --> Router Class Initialized
INFO - 2020-12-29 03:06:44 --> Output Class Initialized
INFO - 2020-12-29 03:06:44 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:44 --> Input Class Initialized
INFO - 2020-12-29 03:06:44 --> Language Class Initialized
INFO - 2020-12-29 03:06:44 --> Language Class Initialized
INFO - 2020-12-29 03:06:44 --> Config Class Initialized
INFO - 2020-12-29 03:06:44 --> Loader Class Initialized
INFO - 2020-12-29 03:06:44 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:44 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:44 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:44 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:44 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:44 --> Controller Class Initialized
INFO - 2020-12-29 03:06:44 --> Config Class Initialized
INFO - 2020-12-29 03:06:44 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:44 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:44 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:44 --> URI Class Initialized
INFO - 2020-12-29 03:06:44 --> Router Class Initialized
INFO - 2020-12-29 03:06:44 --> Output Class Initialized
INFO - 2020-12-29 03:06:44 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:44 --> Input Class Initialized
INFO - 2020-12-29 03:06:44 --> Language Class Initialized
INFO - 2020-12-29 03:06:44 --> Language Class Initialized
INFO - 2020-12-29 03:06:44 --> Config Class Initialized
INFO - 2020-12-29 03:06:44 --> Loader Class Initialized
INFO - 2020-12-29 03:06:44 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:44 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:44 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:44 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:44 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:44 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:06:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:06:44 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:44 --> Total execution time: 0.0600
INFO - 2020-12-29 03:06:45 --> Config Class Initialized
INFO - 2020-12-29 03:06:45 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:45 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:45 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:45 --> URI Class Initialized
INFO - 2020-12-29 03:06:45 --> Router Class Initialized
INFO - 2020-12-29 03:06:45 --> Output Class Initialized
INFO - 2020-12-29 03:06:45 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:45 --> Input Class Initialized
INFO - 2020-12-29 03:06:45 --> Language Class Initialized
INFO - 2020-12-29 03:06:45 --> Language Class Initialized
INFO - 2020-12-29 03:06:45 --> Config Class Initialized
INFO - 2020-12-29 03:06:45 --> Loader Class Initialized
INFO - 2020-12-29 03:06:45 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:45 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:45 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:45 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:45 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:45 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:06:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:06:45 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:45 --> Total execution time: 0.0671
INFO - 2020-12-29 03:06:56 --> Config Class Initialized
INFO - 2020-12-29 03:06:56 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:56 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:56 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:56 --> URI Class Initialized
INFO - 2020-12-29 03:06:56 --> Router Class Initialized
INFO - 2020-12-29 03:06:56 --> Output Class Initialized
INFO - 2020-12-29 03:06:56 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:56 --> Input Class Initialized
INFO - 2020-12-29 03:06:56 --> Language Class Initialized
INFO - 2020-12-29 03:06:56 --> Language Class Initialized
INFO - 2020-12-29 03:06:56 --> Config Class Initialized
INFO - 2020-12-29 03:06:56 --> Loader Class Initialized
INFO - 2020-12-29 03:06:56 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:56 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:56 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:56 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:56 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:56 --> Controller Class Initialized
INFO - 2020-12-29 03:06:56 --> Config Class Initialized
INFO - 2020-12-29 03:06:56 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:06:56 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:06:56 --> Utf8 Class Initialized
INFO - 2020-12-29 03:06:56 --> URI Class Initialized
INFO - 2020-12-29 03:06:56 --> Router Class Initialized
INFO - 2020-12-29 03:06:56 --> Output Class Initialized
INFO - 2020-12-29 03:06:56 --> Security Class Initialized
DEBUG - 2020-12-29 03:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:06:56 --> Input Class Initialized
INFO - 2020-12-29 03:06:56 --> Language Class Initialized
INFO - 2020-12-29 03:06:57 --> Language Class Initialized
INFO - 2020-12-29 03:06:57 --> Config Class Initialized
INFO - 2020-12-29 03:06:57 --> Loader Class Initialized
INFO - 2020-12-29 03:06:57 --> Helper loaded: url_helper
INFO - 2020-12-29 03:06:57 --> Helper loaded: file_helper
INFO - 2020-12-29 03:06:57 --> Helper loaded: form_helper
INFO - 2020-12-29 03:06:57 --> Helper loaded: my_helper
INFO - 2020-12-29 03:06:57 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:06:57 --> Controller Class Initialized
DEBUG - 2020-12-29 03:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:06:57 --> Final output sent to browser
DEBUG - 2020-12-29 03:06:57 --> Total execution time: 0.0806
INFO - 2020-12-29 03:07:13 --> Config Class Initialized
INFO - 2020-12-29 03:07:13 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:13 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:13 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:13 --> URI Class Initialized
INFO - 2020-12-29 03:07:13 --> Router Class Initialized
INFO - 2020-12-29 03:07:13 --> Output Class Initialized
INFO - 2020-12-29 03:07:13 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:13 --> Input Class Initialized
INFO - 2020-12-29 03:07:13 --> Language Class Initialized
INFO - 2020-12-29 03:07:13 --> Language Class Initialized
INFO - 2020-12-29 03:07:13 --> Config Class Initialized
INFO - 2020-12-29 03:07:13 --> Loader Class Initialized
INFO - 2020-12-29 03:07:13 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:13 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:13 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:13 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:13 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:13 --> Controller Class Initialized
DEBUG - 2020-12-29 03:07:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:07:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:07:13 --> Final output sent to browser
DEBUG - 2020-12-29 03:07:13 --> Total execution time: 0.0824
INFO - 2020-12-29 03:07:30 --> Config Class Initialized
INFO - 2020-12-29 03:07:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:30 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:30 --> URI Class Initialized
INFO - 2020-12-29 03:07:30 --> Router Class Initialized
INFO - 2020-12-29 03:07:30 --> Output Class Initialized
INFO - 2020-12-29 03:07:30 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:30 --> Input Class Initialized
INFO - 2020-12-29 03:07:30 --> Language Class Initialized
INFO - 2020-12-29 03:07:30 --> Language Class Initialized
INFO - 2020-12-29 03:07:30 --> Config Class Initialized
INFO - 2020-12-29 03:07:30 --> Loader Class Initialized
INFO - 2020-12-29 03:07:30 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:30 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:30 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:30 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:30 --> Controller Class Initialized
INFO - 2020-12-29 03:07:30 --> Config Class Initialized
INFO - 2020-12-29 03:07:30 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:30 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:30 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:30 --> URI Class Initialized
INFO - 2020-12-29 03:07:30 --> Router Class Initialized
INFO - 2020-12-29 03:07:30 --> Output Class Initialized
INFO - 2020-12-29 03:07:30 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:30 --> Input Class Initialized
INFO - 2020-12-29 03:07:30 --> Language Class Initialized
INFO - 2020-12-29 03:07:30 --> Language Class Initialized
INFO - 2020-12-29 03:07:30 --> Config Class Initialized
INFO - 2020-12-29 03:07:30 --> Loader Class Initialized
INFO - 2020-12-29 03:07:30 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:30 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:30 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:30 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:30 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:30 --> Controller Class Initialized
DEBUG - 2020-12-29 03:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:07:30 --> Final output sent to browser
DEBUG - 2020-12-29 03:07:30 --> Total execution time: 0.0830
INFO - 2020-12-29 03:07:34 --> Config Class Initialized
INFO - 2020-12-29 03:07:34 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:34 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:34 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:34 --> URI Class Initialized
INFO - 2020-12-29 03:07:34 --> Router Class Initialized
INFO - 2020-12-29 03:07:34 --> Output Class Initialized
INFO - 2020-12-29 03:07:34 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:34 --> Input Class Initialized
INFO - 2020-12-29 03:07:34 --> Language Class Initialized
INFO - 2020-12-29 03:07:34 --> Language Class Initialized
INFO - 2020-12-29 03:07:34 --> Config Class Initialized
INFO - 2020-12-29 03:07:34 --> Loader Class Initialized
INFO - 2020-12-29 03:07:34 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:34 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:34 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:34 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:34 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:34 --> Controller Class Initialized
DEBUG - 2020-12-29 03:07:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:07:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:07:34 --> Final output sent to browser
DEBUG - 2020-12-29 03:07:34 --> Total execution time: 0.0938
INFO - 2020-12-29 03:07:48 --> Config Class Initialized
INFO - 2020-12-29 03:07:48 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:48 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:48 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:48 --> URI Class Initialized
INFO - 2020-12-29 03:07:48 --> Router Class Initialized
INFO - 2020-12-29 03:07:48 --> Output Class Initialized
INFO - 2020-12-29 03:07:48 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:48 --> Input Class Initialized
INFO - 2020-12-29 03:07:48 --> Language Class Initialized
INFO - 2020-12-29 03:07:48 --> Language Class Initialized
INFO - 2020-12-29 03:07:48 --> Config Class Initialized
INFO - 2020-12-29 03:07:48 --> Loader Class Initialized
INFO - 2020-12-29 03:07:48 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:48 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:48 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:48 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:48 --> Controller Class Initialized
INFO - 2020-12-29 03:07:48 --> Config Class Initialized
INFO - 2020-12-29 03:07:48 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:48 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:48 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:48 --> URI Class Initialized
INFO - 2020-12-29 03:07:48 --> Router Class Initialized
INFO - 2020-12-29 03:07:48 --> Output Class Initialized
INFO - 2020-12-29 03:07:48 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:48 --> Input Class Initialized
INFO - 2020-12-29 03:07:48 --> Language Class Initialized
INFO - 2020-12-29 03:07:48 --> Language Class Initialized
INFO - 2020-12-29 03:07:48 --> Config Class Initialized
INFO - 2020-12-29 03:07:48 --> Loader Class Initialized
INFO - 2020-12-29 03:07:48 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:48 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:48 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:48 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:48 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:48 --> Controller Class Initialized
DEBUG - 2020-12-29 03:07:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:07:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:07:48 --> Final output sent to browser
DEBUG - 2020-12-29 03:07:48 --> Total execution time: 0.0836
INFO - 2020-12-29 03:07:50 --> Config Class Initialized
INFO - 2020-12-29 03:07:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:50 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:50 --> URI Class Initialized
INFO - 2020-12-29 03:07:50 --> Router Class Initialized
INFO - 2020-12-29 03:07:50 --> Output Class Initialized
INFO - 2020-12-29 03:07:50 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:50 --> Input Class Initialized
INFO - 2020-12-29 03:07:50 --> Language Class Initialized
INFO - 2020-12-29 03:07:50 --> Language Class Initialized
INFO - 2020-12-29 03:07:50 --> Config Class Initialized
INFO - 2020-12-29 03:07:50 --> Loader Class Initialized
INFO - 2020-12-29 03:07:50 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:50 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:50 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:50 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:50 --> Controller Class Initialized
DEBUG - 2020-12-29 03:07:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-29 03:07:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:07:50 --> Final output sent to browser
DEBUG - 2020-12-29 03:07:50 --> Total execution time: 0.1162
INFO - 2020-12-29 03:07:50 --> Config Class Initialized
INFO - 2020-12-29 03:07:50 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:50 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:50 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:50 --> URI Class Initialized
INFO - 2020-12-29 03:07:50 --> Router Class Initialized
INFO - 2020-12-29 03:07:50 --> Output Class Initialized
INFO - 2020-12-29 03:07:50 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:50 --> Input Class Initialized
INFO - 2020-12-29 03:07:50 --> Language Class Initialized
INFO - 2020-12-29 03:07:50 --> Language Class Initialized
INFO - 2020-12-29 03:07:50 --> Config Class Initialized
INFO - 2020-12-29 03:07:50 --> Loader Class Initialized
INFO - 2020-12-29 03:07:50 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:50 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:50 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:50 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:50 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:50 --> Controller Class Initialized
INFO - 2020-12-29 03:07:52 --> Config Class Initialized
INFO - 2020-12-29 03:07:52 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:07:52 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:07:52 --> Utf8 Class Initialized
INFO - 2020-12-29 03:07:52 --> URI Class Initialized
INFO - 2020-12-29 03:07:52 --> Router Class Initialized
INFO - 2020-12-29 03:07:52 --> Output Class Initialized
INFO - 2020-12-29 03:07:52 --> Security Class Initialized
DEBUG - 2020-12-29 03:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:07:52 --> Input Class Initialized
INFO - 2020-12-29 03:07:52 --> Language Class Initialized
INFO - 2020-12-29 03:07:52 --> Language Class Initialized
INFO - 2020-12-29 03:07:52 --> Config Class Initialized
INFO - 2020-12-29 03:07:52 --> Loader Class Initialized
INFO - 2020-12-29 03:07:52 --> Helper loaded: url_helper
INFO - 2020-12-29 03:07:52 --> Helper loaded: file_helper
INFO - 2020-12-29 03:07:52 --> Helper loaded: form_helper
INFO - 2020-12-29 03:07:52 --> Helper loaded: my_helper
INFO - 2020-12-29 03:07:52 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:07:53 --> Controller Class Initialized
INFO - 2020-12-29 03:08:01 --> Config Class Initialized
INFO - 2020-12-29 03:08:01 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:01 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:01 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:01 --> URI Class Initialized
INFO - 2020-12-29 03:08:01 --> Router Class Initialized
INFO - 2020-12-29 03:08:01 --> Output Class Initialized
INFO - 2020-12-29 03:08:01 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:01 --> Input Class Initialized
INFO - 2020-12-29 03:08:01 --> Language Class Initialized
INFO - 2020-12-29 03:08:01 --> Language Class Initialized
INFO - 2020-12-29 03:08:01 --> Config Class Initialized
INFO - 2020-12-29 03:08:01 --> Loader Class Initialized
INFO - 2020-12-29 03:08:01 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:01 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:01 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:01 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:01 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:01 --> Controller Class Initialized
INFO - 2020-12-29 03:08:01 --> Config Class Initialized
INFO - 2020-12-29 03:08:01 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:01 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:01 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:01 --> URI Class Initialized
INFO - 2020-12-29 03:08:01 --> Router Class Initialized
INFO - 2020-12-29 03:08:01 --> Output Class Initialized
INFO - 2020-12-29 03:08:01 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:01 --> Input Class Initialized
INFO - 2020-12-29 03:08:01 --> Language Class Initialized
INFO - 2020-12-29 03:08:01 --> Language Class Initialized
INFO - 2020-12-29 03:08:01 --> Config Class Initialized
INFO - 2020-12-29 03:08:01 --> Loader Class Initialized
INFO - 2020-12-29 03:08:01 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:01 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:01 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:01 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:01 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:02 --> Controller Class Initialized
DEBUG - 2020-12-29 03:08:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-29 03:08:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:08:02 --> Final output sent to browser
DEBUG - 2020-12-29 03:08:02 --> Total execution time: 0.0865
INFO - 2020-12-29 03:08:02 --> Config Class Initialized
INFO - 2020-12-29 03:08:02 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:02 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:02 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:02 --> URI Class Initialized
INFO - 2020-12-29 03:08:02 --> Router Class Initialized
INFO - 2020-12-29 03:08:02 --> Output Class Initialized
INFO - 2020-12-29 03:08:02 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:02 --> Input Class Initialized
INFO - 2020-12-29 03:08:02 --> Language Class Initialized
INFO - 2020-12-29 03:08:02 --> Language Class Initialized
INFO - 2020-12-29 03:08:02 --> Config Class Initialized
INFO - 2020-12-29 03:08:02 --> Loader Class Initialized
INFO - 2020-12-29 03:08:02 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:02 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:02 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:02 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:02 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:02 --> Controller Class Initialized
INFO - 2020-12-29 03:08:04 --> Config Class Initialized
INFO - 2020-12-29 03:08:04 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:04 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:04 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:04 --> URI Class Initialized
INFO - 2020-12-29 03:08:04 --> Router Class Initialized
INFO - 2020-12-29 03:08:04 --> Output Class Initialized
INFO - 2020-12-29 03:08:04 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:04 --> Input Class Initialized
INFO - 2020-12-29 03:08:04 --> Language Class Initialized
INFO - 2020-12-29 03:08:04 --> Language Class Initialized
INFO - 2020-12-29 03:08:04 --> Config Class Initialized
INFO - 2020-12-29 03:08:04 --> Loader Class Initialized
INFO - 2020-12-29 03:08:04 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:04 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:04 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:04 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:04 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:04 --> Controller Class Initialized
INFO - 2020-12-29 03:08:05 --> Config Class Initialized
INFO - 2020-12-29 03:08:05 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:05 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:05 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:05 --> URI Class Initialized
INFO - 2020-12-29 03:08:05 --> Router Class Initialized
INFO - 2020-12-29 03:08:05 --> Output Class Initialized
INFO - 2020-12-29 03:08:05 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:05 --> Input Class Initialized
INFO - 2020-12-29 03:08:05 --> Language Class Initialized
INFO - 2020-12-29 03:08:05 --> Language Class Initialized
INFO - 2020-12-29 03:08:05 --> Config Class Initialized
INFO - 2020-12-29 03:08:05 --> Loader Class Initialized
INFO - 2020-12-29 03:08:05 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:05 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:05 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:05 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:05 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:05 --> Controller Class Initialized
INFO - 2020-12-29 03:08:06 --> Config Class Initialized
INFO - 2020-12-29 03:08:06 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:06 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:06 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:06 --> URI Class Initialized
INFO - 2020-12-29 03:08:06 --> Router Class Initialized
INFO - 2020-12-29 03:08:06 --> Output Class Initialized
INFO - 2020-12-29 03:08:06 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:06 --> Input Class Initialized
INFO - 2020-12-29 03:08:06 --> Language Class Initialized
INFO - 2020-12-29 03:08:06 --> Language Class Initialized
INFO - 2020-12-29 03:08:06 --> Config Class Initialized
INFO - 2020-12-29 03:08:06 --> Loader Class Initialized
INFO - 2020-12-29 03:08:06 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:06 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:06 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:06 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:06 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:06 --> Controller Class Initialized
INFO - 2020-12-29 03:08:11 --> Config Class Initialized
INFO - 2020-12-29 03:08:11 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:11 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:11 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:11 --> URI Class Initialized
INFO - 2020-12-29 03:08:11 --> Router Class Initialized
INFO - 2020-12-29 03:08:11 --> Output Class Initialized
INFO - 2020-12-29 03:08:11 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:11 --> Input Class Initialized
INFO - 2020-12-29 03:08:11 --> Language Class Initialized
INFO - 2020-12-29 03:08:11 --> Language Class Initialized
INFO - 2020-12-29 03:08:11 --> Config Class Initialized
INFO - 2020-12-29 03:08:11 --> Loader Class Initialized
INFO - 2020-12-29 03:08:11 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:11 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:11 --> Controller Class Initialized
INFO - 2020-12-29 03:08:11 --> Config Class Initialized
INFO - 2020-12-29 03:08:11 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:11 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:11 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:11 --> URI Class Initialized
INFO - 2020-12-29 03:08:11 --> Router Class Initialized
INFO - 2020-12-29 03:08:11 --> Output Class Initialized
INFO - 2020-12-29 03:08:11 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:11 --> Input Class Initialized
INFO - 2020-12-29 03:08:11 --> Language Class Initialized
INFO - 2020-12-29 03:08:11 --> Language Class Initialized
INFO - 2020-12-29 03:08:11 --> Config Class Initialized
INFO - 2020-12-29 03:08:11 --> Loader Class Initialized
INFO - 2020-12-29 03:08:11 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:11 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:11 --> Controller Class Initialized
DEBUG - 2020-12-29 03:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-29 03:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:08:11 --> Final output sent to browser
DEBUG - 2020-12-29 03:08:11 --> Total execution time: 0.0817
INFO - 2020-12-29 03:08:11 --> Config Class Initialized
INFO - 2020-12-29 03:08:11 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:11 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:11 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:11 --> URI Class Initialized
INFO - 2020-12-29 03:08:11 --> Router Class Initialized
INFO - 2020-12-29 03:08:11 --> Output Class Initialized
INFO - 2020-12-29 03:08:11 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:11 --> Input Class Initialized
INFO - 2020-12-29 03:08:11 --> Language Class Initialized
INFO - 2020-12-29 03:08:11 --> Language Class Initialized
INFO - 2020-12-29 03:08:11 --> Config Class Initialized
INFO - 2020-12-29 03:08:11 --> Loader Class Initialized
INFO - 2020-12-29 03:08:11 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:11 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:11 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:11 --> Controller Class Initialized
INFO - 2020-12-29 03:08:14 --> Config Class Initialized
INFO - 2020-12-29 03:08:14 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:14 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:14 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:14 --> URI Class Initialized
INFO - 2020-12-29 03:08:14 --> Router Class Initialized
INFO - 2020-12-29 03:08:14 --> Output Class Initialized
INFO - 2020-12-29 03:08:14 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:14 --> Input Class Initialized
INFO - 2020-12-29 03:08:14 --> Language Class Initialized
INFO - 2020-12-29 03:08:14 --> Language Class Initialized
INFO - 2020-12-29 03:08:14 --> Config Class Initialized
INFO - 2020-12-29 03:08:14 --> Loader Class Initialized
INFO - 2020-12-29 03:08:14 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:14 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:14 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:14 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:14 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:14 --> Controller Class Initialized
DEBUG - 2020-12-29 03:08:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:08:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:08:14 --> Final output sent to browser
DEBUG - 2020-12-29 03:08:14 --> Total execution time: 0.1190
INFO - 2020-12-29 03:08:15 --> Config Class Initialized
INFO - 2020-12-29 03:08:15 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:15 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:15 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:15 --> URI Class Initialized
INFO - 2020-12-29 03:08:15 --> Router Class Initialized
INFO - 2020-12-29 03:08:15 --> Output Class Initialized
INFO - 2020-12-29 03:08:15 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:15 --> Input Class Initialized
INFO - 2020-12-29 03:08:15 --> Language Class Initialized
INFO - 2020-12-29 03:08:15 --> Language Class Initialized
INFO - 2020-12-29 03:08:15 --> Config Class Initialized
INFO - 2020-12-29 03:08:15 --> Loader Class Initialized
INFO - 2020-12-29 03:08:15 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:15 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:15 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:15 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:15 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:15 --> Controller Class Initialized
DEBUG - 2020-12-29 03:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-12-29 03:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:08:15 --> Final output sent to browser
DEBUG - 2020-12-29 03:08:15 --> Total execution time: 0.0884
INFO - 2020-12-29 03:08:16 --> Config Class Initialized
INFO - 2020-12-29 03:08:16 --> Hooks Class Initialized
DEBUG - 2020-12-29 03:08:16 --> UTF-8 Support Enabled
INFO - 2020-12-29 03:08:16 --> Utf8 Class Initialized
INFO - 2020-12-29 03:08:16 --> URI Class Initialized
INFO - 2020-12-29 03:08:16 --> Router Class Initialized
INFO - 2020-12-29 03:08:16 --> Output Class Initialized
INFO - 2020-12-29 03:08:16 --> Security Class Initialized
DEBUG - 2020-12-29 03:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-29 03:08:16 --> Input Class Initialized
INFO - 2020-12-29 03:08:16 --> Language Class Initialized
INFO - 2020-12-29 03:08:16 --> Language Class Initialized
INFO - 2020-12-29 03:08:16 --> Config Class Initialized
INFO - 2020-12-29 03:08:16 --> Loader Class Initialized
INFO - 2020-12-29 03:08:16 --> Helper loaded: url_helper
INFO - 2020-12-29 03:08:16 --> Helper loaded: file_helper
INFO - 2020-12-29 03:08:16 --> Helper loaded: form_helper
INFO - 2020-12-29 03:08:16 --> Helper loaded: my_helper
INFO - 2020-12-29 03:08:16 --> Database Driver Class Initialized
DEBUG - 2020-12-29 03:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-29 03:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-29 03:08:16 --> Controller Class Initialized
DEBUG - 2020-12-29 03:08:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-29 03:08:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-29 03:08:16 --> Final output sent to browser
DEBUG - 2020-12-29 03:08:16 --> Total execution time: 0.1031
