<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-02-17 02:28:24 --> Config Class Initialized
INFO - 2022-02-17 02:28:24 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:28:24 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:28:24 --> Utf8 Class Initialized
INFO - 2022-02-17 02:28:24 --> URI Class Initialized
DEBUG - 2022-02-17 02:28:24 --> No URI present. Default controller set.
INFO - 2022-02-17 02:28:24 --> Router Class Initialized
INFO - 2022-02-17 02:28:24 --> Output Class Initialized
INFO - 2022-02-17 02:28:24 --> Security Class Initialized
DEBUG - 2022-02-17 02:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:28:24 --> Input Class Initialized
INFO - 2022-02-17 02:28:24 --> Language Class Initialized
INFO - 2022-02-17 02:28:24 --> Language Class Initialized
INFO - 2022-02-17 02:28:24 --> Config Class Initialized
INFO - 2022-02-17 02:28:24 --> Loader Class Initialized
INFO - 2022-02-17 02:28:24 --> Helper loaded: url_helper
INFO - 2022-02-17 02:28:24 --> Helper loaded: file_helper
INFO - 2022-02-17 02:28:24 --> Helper loaded: form_helper
INFO - 2022-02-17 02:28:24 --> Helper loaded: my_helper
INFO - 2022-02-17 02:28:24 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:28:25 --> Controller Class Initialized
INFO - 2022-02-17 02:28:57 --> Config Class Initialized
INFO - 2022-02-17 02:28:57 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:28:57 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:28:57 --> Utf8 Class Initialized
INFO - 2022-02-17 02:28:57 --> URI Class Initialized
INFO - 2022-02-17 02:28:57 --> Router Class Initialized
INFO - 2022-02-17 02:28:57 --> Output Class Initialized
INFO - 2022-02-17 02:28:57 --> Security Class Initialized
DEBUG - 2022-02-17 02:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:28:57 --> Input Class Initialized
INFO - 2022-02-17 02:28:57 --> Language Class Initialized
INFO - 2022-02-17 02:28:57 --> Language Class Initialized
INFO - 2022-02-17 02:28:57 --> Config Class Initialized
INFO - 2022-02-17 02:28:57 --> Loader Class Initialized
INFO - 2022-02-17 02:28:57 --> Helper loaded: url_helper
INFO - 2022-02-17 02:28:57 --> Helper loaded: file_helper
INFO - 2022-02-17 02:28:57 --> Helper loaded: form_helper
INFO - 2022-02-17 02:28:57 --> Helper loaded: my_helper
INFO - 2022-02-17 02:28:57 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:28:57 --> Controller Class Initialized
DEBUG - 2022-02-17 02:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-02-17 02:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 02:28:57 --> Final output sent to browser
DEBUG - 2022-02-17 02:28:57 --> Total execution time: 0.2241
INFO - 2022-02-17 02:30:33 --> Config Class Initialized
INFO - 2022-02-17 02:30:33 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:30:33 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:30:33 --> Utf8 Class Initialized
INFO - 2022-02-17 02:30:33 --> URI Class Initialized
INFO - 2022-02-17 02:30:33 --> Router Class Initialized
INFO - 2022-02-17 02:30:33 --> Output Class Initialized
INFO - 2022-02-17 02:30:33 --> Security Class Initialized
DEBUG - 2022-02-17 02:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:30:33 --> Input Class Initialized
INFO - 2022-02-17 02:30:33 --> Language Class Initialized
INFO - 2022-02-17 02:30:33 --> Language Class Initialized
INFO - 2022-02-17 02:30:33 --> Config Class Initialized
INFO - 2022-02-17 02:30:33 --> Loader Class Initialized
INFO - 2022-02-17 02:30:33 --> Helper loaded: url_helper
INFO - 2022-02-17 02:30:33 --> Helper loaded: file_helper
INFO - 2022-02-17 02:30:33 --> Helper loaded: form_helper
INFO - 2022-02-17 02:30:34 --> Helper loaded: my_helper
INFO - 2022-02-17 02:30:34 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:30:34 --> Controller Class Initialized
DEBUG - 2022-02-17 02:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-02-17 02:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 02:30:34 --> Final output sent to browser
DEBUG - 2022-02-17 02:30:34 --> Total execution time: 0.1595
INFO - 2022-02-17 02:51:16 --> Config Class Initialized
INFO - 2022-02-17 02:51:16 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:51:16 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:51:16 --> Utf8 Class Initialized
INFO - 2022-02-17 02:51:16 --> URI Class Initialized
INFO - 2022-02-17 02:51:16 --> Router Class Initialized
INFO - 2022-02-17 02:51:16 --> Output Class Initialized
INFO - 2022-02-17 02:51:16 --> Security Class Initialized
DEBUG - 2022-02-17 02:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:51:16 --> Input Class Initialized
INFO - 2022-02-17 02:51:16 --> Language Class Initialized
INFO - 2022-02-17 02:51:16 --> Language Class Initialized
INFO - 2022-02-17 02:51:16 --> Config Class Initialized
INFO - 2022-02-17 02:51:16 --> Loader Class Initialized
INFO - 2022-02-17 02:51:16 --> Helper loaded: url_helper
INFO - 2022-02-17 02:51:16 --> Helper loaded: file_helper
INFO - 2022-02-17 02:51:16 --> Helper loaded: form_helper
INFO - 2022-02-17 02:51:16 --> Helper loaded: my_helper
INFO - 2022-02-17 02:51:16 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:51:16 --> Controller Class Initialized
INFO - 2022-02-17 02:51:16 --> Helper loaded: cookie_helper
INFO - 2022-02-17 02:51:16 --> Final output sent to browser
DEBUG - 2022-02-17 02:51:16 --> Total execution time: 0.1015
INFO - 2022-02-17 02:51:16 --> Config Class Initialized
INFO - 2022-02-17 02:51:16 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:51:16 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:51:16 --> Utf8 Class Initialized
INFO - 2022-02-17 02:51:16 --> URI Class Initialized
INFO - 2022-02-17 02:51:16 --> Router Class Initialized
INFO - 2022-02-17 02:51:16 --> Output Class Initialized
INFO - 2022-02-17 02:51:16 --> Security Class Initialized
DEBUG - 2022-02-17 02:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:51:16 --> Input Class Initialized
INFO - 2022-02-17 02:51:16 --> Language Class Initialized
INFO - 2022-02-17 02:51:16 --> Language Class Initialized
INFO - 2022-02-17 02:51:16 --> Config Class Initialized
INFO - 2022-02-17 02:51:16 --> Loader Class Initialized
INFO - 2022-02-17 02:51:16 --> Helper loaded: url_helper
INFO - 2022-02-17 02:51:16 --> Helper loaded: file_helper
INFO - 2022-02-17 02:51:16 --> Helper loaded: form_helper
INFO - 2022-02-17 02:51:16 --> Helper loaded: my_helper
INFO - 2022-02-17 02:51:16 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:51:16 --> Controller Class Initialized
DEBUG - 2022-02-17 02:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-02-17 02:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 02:51:17 --> Final output sent to browser
DEBUG - 2022-02-17 02:51:17 --> Total execution time: 1.1401
INFO - 2022-02-17 02:51:24 --> Config Class Initialized
INFO - 2022-02-17 02:51:24 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:51:24 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:51:24 --> Utf8 Class Initialized
INFO - 2022-02-17 02:51:24 --> URI Class Initialized
INFO - 2022-02-17 02:51:24 --> Router Class Initialized
INFO - 2022-02-17 02:51:24 --> Output Class Initialized
INFO - 2022-02-17 02:51:24 --> Security Class Initialized
DEBUG - 2022-02-17 02:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:51:24 --> Input Class Initialized
INFO - 2022-02-17 02:51:24 --> Language Class Initialized
INFO - 2022-02-17 02:51:24 --> Language Class Initialized
INFO - 2022-02-17 02:51:24 --> Config Class Initialized
INFO - 2022-02-17 02:51:24 --> Loader Class Initialized
INFO - 2022-02-17 02:51:24 --> Helper loaded: url_helper
INFO - 2022-02-17 02:51:24 --> Helper loaded: file_helper
INFO - 2022-02-17 02:51:24 --> Helper loaded: form_helper
INFO - 2022-02-17 02:51:24 --> Helper loaded: my_helper
INFO - 2022-02-17 02:51:24 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:51:24 --> Controller Class Initialized
DEBUG - 2022-02-17 02:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-02-17 02:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 02:51:24 --> Final output sent to browser
DEBUG - 2022-02-17 02:51:24 --> Total execution time: 0.1252
INFO - 2022-02-17 02:51:26 --> Config Class Initialized
INFO - 2022-02-17 02:51:26 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:51:26 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:51:26 --> Utf8 Class Initialized
INFO - 2022-02-17 02:51:26 --> URI Class Initialized
INFO - 2022-02-17 02:51:26 --> Router Class Initialized
INFO - 2022-02-17 02:51:26 --> Output Class Initialized
INFO - 2022-02-17 02:51:26 --> Security Class Initialized
DEBUG - 2022-02-17 02:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:51:26 --> Input Class Initialized
INFO - 2022-02-17 02:51:26 --> Language Class Initialized
INFO - 2022-02-17 02:51:26 --> Language Class Initialized
INFO - 2022-02-17 02:51:26 --> Config Class Initialized
INFO - 2022-02-17 02:51:26 --> Loader Class Initialized
INFO - 2022-02-17 02:51:26 --> Helper loaded: url_helper
INFO - 2022-02-17 02:51:26 --> Helper loaded: file_helper
INFO - 2022-02-17 02:51:26 --> Helper loaded: form_helper
INFO - 2022-02-17 02:51:26 --> Helper loaded: my_helper
INFO - 2022-02-17 02:51:26 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:51:26 --> Controller Class Initialized
DEBUG - 2022-02-17 02:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-02-17 02:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 02:51:26 --> Final output sent to browser
DEBUG - 2022-02-17 02:51:26 --> Total execution time: 0.0961
INFO - 2022-02-17 03:00:06 --> Config Class Initialized
INFO - 2022-02-17 03:00:06 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:00:06 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:00:06 --> Utf8 Class Initialized
INFO - 2022-02-17 03:00:06 --> URI Class Initialized
INFO - 2022-02-17 03:00:06 --> Router Class Initialized
INFO - 2022-02-17 03:00:06 --> Output Class Initialized
INFO - 2022-02-17 03:00:06 --> Security Class Initialized
DEBUG - 2022-02-17 03:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:00:06 --> Input Class Initialized
INFO - 2022-02-17 03:00:06 --> Language Class Initialized
INFO - 2022-02-17 03:00:06 --> Language Class Initialized
INFO - 2022-02-17 03:00:06 --> Config Class Initialized
INFO - 2022-02-17 03:00:06 --> Loader Class Initialized
INFO - 2022-02-17 03:00:06 --> Helper loaded: url_helper
INFO - 2022-02-17 03:00:06 --> Helper loaded: file_helper
INFO - 2022-02-17 03:00:06 --> Helper loaded: form_helper
INFO - 2022-02-17 03:00:06 --> Helper loaded: my_helper
INFO - 2022-02-17 03:00:06 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:00:06 --> Controller Class Initialized
DEBUG - 2022-02-17 03:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-17 03:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 03:00:06 --> Final output sent to browser
DEBUG - 2022-02-17 03:00:06 --> Total execution time: 0.1015
INFO - 2022-02-17 03:00:15 --> Config Class Initialized
INFO - 2022-02-17 03:00:15 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:00:15 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:00:15 --> Utf8 Class Initialized
INFO - 2022-02-17 03:00:15 --> URI Class Initialized
INFO - 2022-02-17 03:00:15 --> Router Class Initialized
INFO - 2022-02-17 03:00:15 --> Output Class Initialized
INFO - 2022-02-17 03:00:15 --> Security Class Initialized
DEBUG - 2022-02-17 03:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:00:15 --> Input Class Initialized
INFO - 2022-02-17 03:00:15 --> Language Class Initialized
INFO - 2022-02-17 03:00:15 --> Language Class Initialized
INFO - 2022-02-17 03:00:15 --> Config Class Initialized
INFO - 2022-02-17 03:00:15 --> Loader Class Initialized
INFO - 2022-02-17 03:00:15 --> Helper loaded: url_helper
INFO - 2022-02-17 03:00:15 --> Helper loaded: file_helper
INFO - 2022-02-17 03:00:15 --> Helper loaded: form_helper
INFO - 2022-02-17 03:00:15 --> Helper loaded: my_helper
INFO - 2022-02-17 03:00:15 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:00:15 --> Controller Class Initialized
DEBUG - 2022-02-17 03:00:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-02-17 03:00:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 03:00:15 --> Final output sent to browser
DEBUG - 2022-02-17 03:00:15 --> Total execution time: 0.0659
INFO - 2022-02-17 03:01:32 --> Config Class Initialized
INFO - 2022-02-17 03:01:32 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:01:32 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:01:32 --> Utf8 Class Initialized
INFO - 2022-02-17 03:01:32 --> URI Class Initialized
INFO - 2022-02-17 03:01:32 --> Router Class Initialized
INFO - 2022-02-17 03:01:32 --> Output Class Initialized
INFO - 2022-02-17 03:01:32 --> Security Class Initialized
DEBUG - 2022-02-17 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:01:32 --> Input Class Initialized
INFO - 2022-02-17 03:01:32 --> Language Class Initialized
INFO - 2022-02-17 03:01:32 --> Language Class Initialized
INFO - 2022-02-17 03:01:32 --> Config Class Initialized
INFO - 2022-02-17 03:01:32 --> Loader Class Initialized
INFO - 2022-02-17 03:01:32 --> Helper loaded: url_helper
INFO - 2022-02-17 03:01:32 --> Helper loaded: file_helper
INFO - 2022-02-17 03:01:32 --> Helper loaded: form_helper
INFO - 2022-02-17 03:01:32 --> Helper loaded: my_helper
INFO - 2022-02-17 03:01:32 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:01:32 --> Controller Class Initialized
DEBUG - 2022-02-17 03:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-17 03:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 03:01:32 --> Final output sent to browser
DEBUG - 2022-02-17 03:01:32 --> Total execution time: 0.0800
INFO - 2022-02-17 03:01:43 --> Config Class Initialized
INFO - 2022-02-17 03:01:43 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:01:43 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:01:43 --> Utf8 Class Initialized
INFO - 2022-02-17 03:01:43 --> URI Class Initialized
INFO - 2022-02-17 03:01:43 --> Router Class Initialized
INFO - 2022-02-17 03:01:43 --> Output Class Initialized
INFO - 2022-02-17 03:01:43 --> Security Class Initialized
DEBUG - 2022-02-17 03:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:01:43 --> Input Class Initialized
INFO - 2022-02-17 03:01:43 --> Language Class Initialized
INFO - 2022-02-17 03:01:43 --> Language Class Initialized
INFO - 2022-02-17 03:01:43 --> Config Class Initialized
INFO - 2022-02-17 03:01:43 --> Loader Class Initialized
INFO - 2022-02-17 03:01:43 --> Helper loaded: url_helper
INFO - 2022-02-17 03:01:43 --> Helper loaded: file_helper
INFO - 2022-02-17 03:01:43 --> Helper loaded: form_helper
INFO - 2022-02-17 03:01:43 --> Helper loaded: my_helper
INFO - 2022-02-17 03:01:43 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:01:43 --> Controller Class Initialized
DEBUG - 2022-02-17 03:01:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-02-17 03:01:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 03:01:43 --> Final output sent to browser
DEBUG - 2022-02-17 03:01:43 --> Total execution time: 0.1480
INFO - 2022-02-17 03:01:47 --> Config Class Initialized
INFO - 2022-02-17 03:01:47 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:01:47 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:01:47 --> Utf8 Class Initialized
INFO - 2022-02-17 03:01:47 --> URI Class Initialized
INFO - 2022-02-17 03:01:47 --> Router Class Initialized
INFO - 2022-02-17 03:01:47 --> Output Class Initialized
INFO - 2022-02-17 03:01:47 --> Security Class Initialized
DEBUG - 2022-02-17 03:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:01:47 --> Input Class Initialized
INFO - 2022-02-17 03:01:47 --> Language Class Initialized
INFO - 2022-02-17 03:01:47 --> Language Class Initialized
INFO - 2022-02-17 03:01:47 --> Config Class Initialized
INFO - 2022-02-17 03:01:47 --> Loader Class Initialized
INFO - 2022-02-17 03:01:47 --> Helper loaded: url_helper
INFO - 2022-02-17 03:01:47 --> Helper loaded: file_helper
INFO - 2022-02-17 03:01:47 --> Helper loaded: form_helper
INFO - 2022-02-17 03:01:47 --> Helper loaded: my_helper
INFO - 2022-02-17 03:01:47 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:01:47 --> Controller Class Initialized
DEBUG - 2022-02-17 03:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-02-17 03:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 03:01:47 --> Final output sent to browser
DEBUG - 2022-02-17 03:01:47 --> Total execution time: 0.1153
INFO - 2022-02-17 03:03:17 --> Config Class Initialized
INFO - 2022-02-17 03:03:17 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:03:17 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:03:17 --> Utf8 Class Initialized
INFO - 2022-02-17 03:03:17 --> URI Class Initialized
INFO - 2022-02-17 03:03:17 --> Router Class Initialized
INFO - 2022-02-17 03:03:17 --> Output Class Initialized
INFO - 2022-02-17 03:03:17 --> Security Class Initialized
DEBUG - 2022-02-17 03:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:03:17 --> Input Class Initialized
INFO - 2022-02-17 03:03:17 --> Language Class Initialized
INFO - 2022-02-17 03:03:17 --> Language Class Initialized
INFO - 2022-02-17 03:03:17 --> Config Class Initialized
INFO - 2022-02-17 03:03:17 --> Loader Class Initialized
INFO - 2022-02-17 03:03:17 --> Helper loaded: url_helper
INFO - 2022-02-17 03:03:17 --> Helper loaded: file_helper
INFO - 2022-02-17 03:03:17 --> Helper loaded: form_helper
INFO - 2022-02-17 03:03:17 --> Helper loaded: my_helper
INFO - 2022-02-17 03:03:17 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:03:17 --> Controller Class Initialized
DEBUG - 2022-02-17 03:03:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-02-17 03:03:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 03:03:17 --> Final output sent to browser
DEBUG - 2022-02-17 03:03:17 --> Total execution time: 0.0652
INFO - 2022-02-17 03:03:18 --> Config Class Initialized
INFO - 2022-02-17 03:03:18 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:03:18 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:03:18 --> Utf8 Class Initialized
INFO - 2022-02-17 03:03:18 --> URI Class Initialized
INFO - 2022-02-17 03:03:18 --> Router Class Initialized
INFO - 2022-02-17 03:03:18 --> Output Class Initialized
INFO - 2022-02-17 03:03:18 --> Security Class Initialized
DEBUG - 2022-02-17 03:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:03:18 --> Input Class Initialized
INFO - 2022-02-17 03:03:18 --> Language Class Initialized
INFO - 2022-02-17 03:03:18 --> Language Class Initialized
INFO - 2022-02-17 03:03:18 --> Config Class Initialized
INFO - 2022-02-17 03:03:18 --> Loader Class Initialized
INFO - 2022-02-17 03:03:18 --> Helper loaded: url_helper
INFO - 2022-02-17 03:03:18 --> Helper loaded: file_helper
INFO - 2022-02-17 03:03:18 --> Helper loaded: form_helper
INFO - 2022-02-17 03:03:18 --> Helper loaded: my_helper
INFO - 2022-02-17 03:03:18 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:03:18 --> Controller Class Initialized
DEBUG - 2022-02-17 03:03:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-17 03:03:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 03:03:18 --> Final output sent to browser
DEBUG - 2022-02-17 03:03:18 --> Total execution time: 0.1028
INFO - 2022-02-17 03:03:39 --> Config Class Initialized
INFO - 2022-02-17 03:03:39 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:03:39 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:03:39 --> Utf8 Class Initialized
INFO - 2022-02-17 03:03:39 --> URI Class Initialized
INFO - 2022-02-17 03:03:39 --> Router Class Initialized
INFO - 2022-02-17 03:03:39 --> Output Class Initialized
INFO - 2022-02-17 03:03:39 --> Security Class Initialized
DEBUG - 2022-02-17 03:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:03:39 --> Input Class Initialized
INFO - 2022-02-17 03:03:39 --> Language Class Initialized
INFO - 2022-02-17 03:03:39 --> Language Class Initialized
INFO - 2022-02-17 03:03:39 --> Config Class Initialized
INFO - 2022-02-17 03:03:39 --> Loader Class Initialized
INFO - 2022-02-17 03:03:39 --> Helper loaded: url_helper
INFO - 2022-02-17 03:03:39 --> Helper loaded: file_helper
INFO - 2022-02-17 03:03:39 --> Helper loaded: form_helper
INFO - 2022-02-17 03:03:39 --> Helper loaded: my_helper
INFO - 2022-02-17 03:03:39 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:03:39 --> Controller Class Initialized
DEBUG - 2022-02-17 03:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-02-17 03:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 03:03:39 --> Final output sent to browser
DEBUG - 2022-02-17 03:03:39 --> Total execution time: 0.1247
INFO - 2022-02-17 03:03:45 --> Config Class Initialized
INFO - 2022-02-17 03:03:45 --> Hooks Class Initialized
DEBUG - 2022-02-17 03:03:45 --> UTF-8 Support Enabled
INFO - 2022-02-17 03:03:45 --> Utf8 Class Initialized
INFO - 2022-02-17 03:03:45 --> URI Class Initialized
INFO - 2022-02-17 03:03:45 --> Router Class Initialized
INFO - 2022-02-17 03:03:45 --> Output Class Initialized
INFO - 2022-02-17 03:03:45 --> Security Class Initialized
DEBUG - 2022-02-17 03:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 03:03:45 --> Input Class Initialized
INFO - 2022-02-17 03:03:45 --> Language Class Initialized
INFO - 2022-02-17 03:03:45 --> Language Class Initialized
INFO - 2022-02-17 03:03:45 --> Config Class Initialized
INFO - 2022-02-17 03:03:45 --> Loader Class Initialized
INFO - 2022-02-17 03:03:45 --> Helper loaded: url_helper
INFO - 2022-02-17 03:03:45 --> Helper loaded: file_helper
INFO - 2022-02-17 03:03:45 --> Helper loaded: form_helper
INFO - 2022-02-17 03:03:45 --> Helper loaded: my_helper
INFO - 2022-02-17 03:03:45 --> Database Driver Class Initialized
DEBUG - 2022-02-17 03:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 03:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 03:03:45 --> Controller Class Initialized
DEBUG - 2022-02-17 03:03:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-02-17 03:03:45 --> Final output sent to browser
DEBUG - 2022-02-17 03:03:45 --> Total execution time: 0.2759
INFO - 2022-02-17 04:00:07 --> Config Class Initialized
INFO - 2022-02-17 04:00:07 --> Hooks Class Initialized
DEBUG - 2022-02-17 04:00:07 --> UTF-8 Support Enabled
INFO - 2022-02-17 04:00:07 --> Utf8 Class Initialized
INFO - 2022-02-17 04:00:07 --> URI Class Initialized
INFO - 2022-02-17 04:00:07 --> Router Class Initialized
INFO - 2022-02-17 04:00:07 --> Output Class Initialized
INFO - 2022-02-17 04:00:07 --> Security Class Initialized
DEBUG - 2022-02-17 04:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 04:00:07 --> Input Class Initialized
INFO - 2022-02-17 04:00:07 --> Language Class Initialized
INFO - 2022-02-17 04:00:07 --> Language Class Initialized
INFO - 2022-02-17 04:00:07 --> Config Class Initialized
INFO - 2022-02-17 04:00:07 --> Loader Class Initialized
INFO - 2022-02-17 04:00:07 --> Helper loaded: url_helper
INFO - 2022-02-17 04:00:07 --> Helper loaded: file_helper
INFO - 2022-02-17 04:00:07 --> Helper loaded: form_helper
INFO - 2022-02-17 04:00:07 --> Helper loaded: my_helper
INFO - 2022-02-17 04:00:07 --> Database Driver Class Initialized
DEBUG - 2022-02-17 04:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 04:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 04:00:07 --> Controller Class Initialized
DEBUG - 2022-02-17 04:00:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-17 04:00:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 04:00:07 --> Final output sent to browser
DEBUG - 2022-02-17 04:00:07 --> Total execution time: 0.0978
INFO - 2022-02-17 04:03:25 --> Config Class Initialized
INFO - 2022-02-17 04:03:25 --> Hooks Class Initialized
DEBUG - 2022-02-17 04:03:25 --> UTF-8 Support Enabled
INFO - 2022-02-17 04:03:25 --> Utf8 Class Initialized
INFO - 2022-02-17 04:03:25 --> URI Class Initialized
INFO - 2022-02-17 04:03:25 --> Router Class Initialized
INFO - 2022-02-17 04:03:25 --> Output Class Initialized
INFO - 2022-02-17 04:03:25 --> Security Class Initialized
DEBUG - 2022-02-17 04:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 04:03:25 --> Input Class Initialized
INFO - 2022-02-17 04:03:25 --> Language Class Initialized
INFO - 2022-02-17 04:03:25 --> Language Class Initialized
INFO - 2022-02-17 04:03:25 --> Config Class Initialized
INFO - 2022-02-17 04:03:25 --> Loader Class Initialized
INFO - 2022-02-17 04:03:25 --> Helper loaded: url_helper
INFO - 2022-02-17 04:03:25 --> Helper loaded: file_helper
INFO - 2022-02-17 04:03:25 --> Helper loaded: form_helper
INFO - 2022-02-17 04:03:25 --> Helper loaded: my_helper
INFO - 2022-02-17 04:03:25 --> Database Driver Class Initialized
DEBUG - 2022-02-17 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 04:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 04:03:25 --> Controller Class Initialized
DEBUG - 2022-02-17 04:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-17 04:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 04:03:25 --> Final output sent to browser
DEBUG - 2022-02-17 04:03:25 --> Total execution time: 0.0973
INFO - 2022-02-17 04:03:25 --> Config Class Initialized
INFO - 2022-02-17 04:03:25 --> Hooks Class Initialized
DEBUG - 2022-02-17 04:03:25 --> UTF-8 Support Enabled
INFO - 2022-02-17 04:03:25 --> Utf8 Class Initialized
INFO - 2022-02-17 04:03:25 --> URI Class Initialized
INFO - 2022-02-17 04:03:25 --> Router Class Initialized
INFO - 2022-02-17 04:03:25 --> Output Class Initialized
INFO - 2022-02-17 04:03:25 --> Security Class Initialized
DEBUG - 2022-02-17 04:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 04:03:25 --> Input Class Initialized
INFO - 2022-02-17 04:03:25 --> Language Class Initialized
INFO - 2022-02-17 04:03:25 --> Language Class Initialized
INFO - 2022-02-17 04:03:25 --> Config Class Initialized
INFO - 2022-02-17 04:03:25 --> Loader Class Initialized
INFO - 2022-02-17 04:03:25 --> Helper loaded: url_helper
INFO - 2022-02-17 04:03:25 --> Helper loaded: file_helper
INFO - 2022-02-17 04:03:25 --> Helper loaded: form_helper
INFO - 2022-02-17 04:03:25 --> Helper loaded: my_helper
INFO - 2022-02-17 04:03:25 --> Database Driver Class Initialized
DEBUG - 2022-02-17 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 04:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 04:03:25 --> Controller Class Initialized
DEBUG - 2022-02-17 04:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-02-17 04:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 04:03:25 --> Final output sent to browser
DEBUG - 2022-02-17 04:03:25 --> Total execution time: 0.0869
INFO - 2022-02-17 04:03:27 --> Config Class Initialized
INFO - 2022-02-17 04:03:27 --> Hooks Class Initialized
DEBUG - 2022-02-17 04:03:27 --> UTF-8 Support Enabled
INFO - 2022-02-17 04:03:27 --> Utf8 Class Initialized
INFO - 2022-02-17 04:03:27 --> URI Class Initialized
INFO - 2022-02-17 04:03:27 --> Router Class Initialized
INFO - 2022-02-17 04:03:27 --> Output Class Initialized
INFO - 2022-02-17 04:03:27 --> Security Class Initialized
DEBUG - 2022-02-17 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 04:03:27 --> Input Class Initialized
INFO - 2022-02-17 04:03:27 --> Language Class Initialized
INFO - 2022-02-17 04:03:27 --> Language Class Initialized
INFO - 2022-02-17 04:03:27 --> Config Class Initialized
INFO - 2022-02-17 04:03:27 --> Loader Class Initialized
INFO - 2022-02-17 04:03:27 --> Helper loaded: url_helper
INFO - 2022-02-17 04:03:27 --> Helper loaded: file_helper
INFO - 2022-02-17 04:03:27 --> Helper loaded: form_helper
INFO - 2022-02-17 04:03:27 --> Helper loaded: my_helper
INFO - 2022-02-17 04:03:27 --> Database Driver Class Initialized
DEBUG - 2022-02-17 04:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 04:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 04:03:27 --> Controller Class Initialized
ERROR - 2022-02-17 04:03:27 --> Query error: Unknown column 'a.desk' in 'field list' - Invalid query: select 
                a.id_siswa ids, c.nama nmsiswa, a.nilai, a.desk
                from t_nilai_ekstra a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join m_siswa c on b.id_siswa = c.id
                inner join m_ekstra d on a.id_ekstra = d.id
                where a.id_ekstra = '10' 
                and b.id_kelas = '18' 
                and a.tasm = '20202' 
                and b.ta = '2020'
INFO - 2022-02-17 04:03:27 --> Language file loaded: language/english/db_lang.php
INFO - 2022-02-17 04:03:30 --> Config Class Initialized
INFO - 2022-02-17 04:03:30 --> Hooks Class Initialized
DEBUG - 2022-02-17 04:03:30 --> UTF-8 Support Enabled
INFO - 2022-02-17 04:03:30 --> Utf8 Class Initialized
INFO - 2022-02-17 04:03:30 --> URI Class Initialized
INFO - 2022-02-17 04:03:30 --> Router Class Initialized
INFO - 2022-02-17 04:03:30 --> Output Class Initialized
INFO - 2022-02-17 04:03:30 --> Security Class Initialized
DEBUG - 2022-02-17 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 04:03:30 --> Input Class Initialized
INFO - 2022-02-17 04:03:30 --> Language Class Initialized
INFO - 2022-02-17 04:03:30 --> Language Class Initialized
INFO - 2022-02-17 04:03:30 --> Config Class Initialized
INFO - 2022-02-17 04:03:30 --> Loader Class Initialized
INFO - 2022-02-17 04:03:30 --> Helper loaded: url_helper
INFO - 2022-02-17 04:03:30 --> Helper loaded: file_helper
INFO - 2022-02-17 04:03:30 --> Helper loaded: form_helper
INFO - 2022-02-17 04:03:30 --> Helper loaded: my_helper
INFO - 2022-02-17 04:03:30 --> Database Driver Class Initialized
DEBUG - 2022-02-17 04:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 04:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 04:03:30 --> Controller Class Initialized
DEBUG - 2022-02-17 04:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-02-17 04:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 04:03:30 --> Final output sent to browser
DEBUG - 2022-02-17 04:03:30 --> Total execution time: 0.0617
INFO - 2022-02-17 04:03:32 --> Config Class Initialized
INFO - 2022-02-17 04:03:32 --> Hooks Class Initialized
DEBUG - 2022-02-17 04:03:32 --> UTF-8 Support Enabled
INFO - 2022-02-17 04:03:32 --> Utf8 Class Initialized
INFO - 2022-02-17 04:03:32 --> URI Class Initialized
INFO - 2022-02-17 04:03:32 --> Router Class Initialized
INFO - 2022-02-17 04:03:32 --> Output Class Initialized
INFO - 2022-02-17 04:03:32 --> Security Class Initialized
DEBUG - 2022-02-17 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 04:03:32 --> Input Class Initialized
INFO - 2022-02-17 04:03:32 --> Language Class Initialized
INFO - 2022-02-17 04:03:32 --> Language Class Initialized
INFO - 2022-02-17 04:03:32 --> Config Class Initialized
INFO - 2022-02-17 04:03:32 --> Loader Class Initialized
INFO - 2022-02-17 04:03:32 --> Helper loaded: url_helper
INFO - 2022-02-17 04:03:32 --> Helper loaded: file_helper
INFO - 2022-02-17 04:03:32 --> Helper loaded: form_helper
INFO - 2022-02-17 04:03:32 --> Helper loaded: my_helper
INFO - 2022-02-17 04:03:32 --> Database Driver Class Initialized
DEBUG - 2022-02-17 04:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 04:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 04:03:32 --> Controller Class Initialized
DEBUG - 2022-02-17 04:03:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-17 04:03:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-17 04:03:32 --> Final output sent to browser
DEBUG - 2022-02-17 04:03:32 --> Total execution time: 0.0812
INFO - 2022-02-17 04:03:36 --> Config Class Initialized
INFO - 2022-02-17 04:03:36 --> Hooks Class Initialized
DEBUG - 2022-02-17 04:03:36 --> UTF-8 Support Enabled
INFO - 2022-02-17 04:03:36 --> Utf8 Class Initialized
INFO - 2022-02-17 04:03:36 --> URI Class Initialized
INFO - 2022-02-17 04:03:36 --> Router Class Initialized
INFO - 2022-02-17 04:03:36 --> Output Class Initialized
INFO - 2022-02-17 04:03:36 --> Security Class Initialized
DEBUG - 2022-02-17 04:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 04:03:36 --> Input Class Initialized
INFO - 2022-02-17 04:03:36 --> Language Class Initialized
INFO - 2022-02-17 04:03:36 --> Language Class Initialized
INFO - 2022-02-17 04:03:36 --> Config Class Initialized
INFO - 2022-02-17 04:03:36 --> Loader Class Initialized
INFO - 2022-02-17 04:03:36 --> Helper loaded: url_helper
INFO - 2022-02-17 04:03:36 --> Helper loaded: file_helper
INFO - 2022-02-17 04:03:36 --> Helper loaded: form_helper
INFO - 2022-02-17 04:03:36 --> Helper loaded: my_helper
INFO - 2022-02-17 04:03:36 --> Database Driver Class Initialized
DEBUG - 2022-02-17 04:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 04:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 04:03:36 --> Controller Class Initialized
ERROR - 2022-02-17 04:03:37 --> Query error: Unknown column 'a.desk' in 'field list' - Invalid query: SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = 2428 AND a.nilai != '0' AND a.tasm = '20202'
INFO - 2022-02-17 04:03:37 --> Language file loaded: language/english/db_lang.php
