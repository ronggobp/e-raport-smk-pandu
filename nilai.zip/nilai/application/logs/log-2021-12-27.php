<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-27 02:21:05 --> Config Class Initialized
INFO - 2021-12-27 02:21:05 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:05 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:05 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:05 --> URI Class Initialized
DEBUG - 2021-12-27 02:21:05 --> No URI present. Default controller set.
INFO - 2021-12-27 02:21:05 --> Router Class Initialized
INFO - 2021-12-27 02:21:05 --> Output Class Initialized
INFO - 2021-12-27 02:21:05 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:05 --> Input Class Initialized
INFO - 2021-12-27 02:21:05 --> Language Class Initialized
INFO - 2021-12-27 02:21:05 --> Language Class Initialized
INFO - 2021-12-27 02:21:05 --> Config Class Initialized
INFO - 2021-12-27 02:21:05 --> Loader Class Initialized
INFO - 2021-12-27 02:21:05 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:05 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:05 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:05 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:05 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:05 --> Controller Class Initialized
INFO - 2021-12-27 02:21:05 --> Config Class Initialized
INFO - 2021-12-27 02:21:05 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:05 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:05 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:05 --> URI Class Initialized
INFO - 2021-12-27 02:21:05 --> Router Class Initialized
INFO - 2021-12-27 02:21:05 --> Output Class Initialized
INFO - 2021-12-27 02:21:05 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:05 --> Input Class Initialized
INFO - 2021-12-27 02:21:05 --> Language Class Initialized
INFO - 2021-12-27 02:21:05 --> Language Class Initialized
INFO - 2021-12-27 02:21:05 --> Config Class Initialized
INFO - 2021-12-27 02:21:05 --> Loader Class Initialized
INFO - 2021-12-27 02:21:05 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:05 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:05 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:05 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:05 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:05 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-27 02:21:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:21:05 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:05 --> Total execution time: 0.0370
INFO - 2021-12-27 02:21:13 --> Config Class Initialized
INFO - 2021-12-27 02:21:13 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:13 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:13 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:13 --> URI Class Initialized
INFO - 2021-12-27 02:21:13 --> Router Class Initialized
INFO - 2021-12-27 02:21:13 --> Output Class Initialized
INFO - 2021-12-27 02:21:13 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:13 --> Input Class Initialized
INFO - 2021-12-27 02:21:13 --> Language Class Initialized
INFO - 2021-12-27 02:21:13 --> Language Class Initialized
INFO - 2021-12-27 02:21:13 --> Config Class Initialized
INFO - 2021-12-27 02:21:13 --> Loader Class Initialized
INFO - 2021-12-27 02:21:13 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:13 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:13 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:13 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:13 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:13 --> Controller Class Initialized
INFO - 2021-12-27 02:21:13 --> Helper loaded: cookie_helper
INFO - 2021-12-27 02:21:13 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:13 --> Total execution time: 0.0606
INFO - 2021-12-27 02:21:13 --> Config Class Initialized
INFO - 2021-12-27 02:21:13 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:13 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:13 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:13 --> URI Class Initialized
INFO - 2021-12-27 02:21:13 --> Router Class Initialized
INFO - 2021-12-27 02:21:13 --> Output Class Initialized
INFO - 2021-12-27 02:21:13 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:13 --> Input Class Initialized
INFO - 2021-12-27 02:21:13 --> Language Class Initialized
INFO - 2021-12-27 02:21:13 --> Language Class Initialized
INFO - 2021-12-27 02:21:13 --> Config Class Initialized
INFO - 2021-12-27 02:21:13 --> Loader Class Initialized
INFO - 2021-12-27 02:21:13 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:13 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:13 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:13 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:13 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:13 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-27 02:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:21:14 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:14 --> Total execution time: 0.2550
INFO - 2021-12-27 02:21:16 --> Config Class Initialized
INFO - 2021-12-27 02:21:16 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:16 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:16 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:16 --> URI Class Initialized
INFO - 2021-12-27 02:21:16 --> Router Class Initialized
INFO - 2021-12-27 02:21:16 --> Output Class Initialized
INFO - 2021-12-27 02:21:16 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:16 --> Input Class Initialized
INFO - 2021-12-27 02:21:16 --> Language Class Initialized
INFO - 2021-12-27 02:21:16 --> Language Class Initialized
INFO - 2021-12-27 02:21:16 --> Config Class Initialized
INFO - 2021-12-27 02:21:16 --> Loader Class Initialized
INFO - 2021-12-27 02:21:16 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:16 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:16 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:16 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:16 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:16 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-12-27 02:21:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:21:16 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:16 --> Total execution time: 0.0620
INFO - 2021-12-27 02:21:19 --> Config Class Initialized
INFO - 2021-12-27 02:21:19 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:19 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:19 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:19 --> URI Class Initialized
INFO - 2021-12-27 02:21:19 --> Router Class Initialized
INFO - 2021-12-27 02:21:19 --> Output Class Initialized
INFO - 2021-12-27 02:21:19 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:19 --> Input Class Initialized
INFO - 2021-12-27 02:21:19 --> Language Class Initialized
INFO - 2021-12-27 02:21:19 --> Language Class Initialized
INFO - 2021-12-27 02:21:19 --> Config Class Initialized
INFO - 2021-12-27 02:21:19 --> Loader Class Initialized
INFO - 2021-12-27 02:21:19 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:19 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:19 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:19 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:19 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:19 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-27 02:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:21:20 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:20 --> Total execution time: 0.2100
INFO - 2021-12-27 02:21:21 --> Config Class Initialized
INFO - 2021-12-27 02:21:21 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:21 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:21 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:21 --> URI Class Initialized
INFO - 2021-12-27 02:21:21 --> Router Class Initialized
INFO - 2021-12-27 02:21:21 --> Output Class Initialized
INFO - 2021-12-27 02:21:21 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:21 --> Input Class Initialized
INFO - 2021-12-27 02:21:21 --> Language Class Initialized
INFO - 2021-12-27 02:21:21 --> Language Class Initialized
INFO - 2021-12-27 02:21:21 --> Config Class Initialized
INFO - 2021-12-27 02:21:21 --> Loader Class Initialized
INFO - 2021-12-27 02:21:21 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:21 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:21 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:21 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:21 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:21 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-27 02:21:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:21:21 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:21 --> Total execution time: 0.0580
INFO - 2021-12-27 02:21:25 --> Config Class Initialized
INFO - 2021-12-27 02:21:25 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:25 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:25 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:25 --> URI Class Initialized
INFO - 2021-12-27 02:21:25 --> Router Class Initialized
INFO - 2021-12-27 02:21:25 --> Output Class Initialized
INFO - 2021-12-27 02:21:25 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:25 --> Input Class Initialized
INFO - 2021-12-27 02:21:25 --> Language Class Initialized
INFO - 2021-12-27 02:21:25 --> Language Class Initialized
INFO - 2021-12-27 02:21:25 --> Config Class Initialized
INFO - 2021-12-27 02:21:25 --> Loader Class Initialized
INFO - 2021-12-27 02:21:25 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:25 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:25 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:25 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:25 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:25 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-12-27 02:21:25 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:25 --> Total execution time: 0.0920
INFO - 2021-12-27 02:21:40 --> Config Class Initialized
INFO - 2021-12-27 02:21:40 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:40 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:40 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:40 --> URI Class Initialized
INFO - 2021-12-27 02:21:40 --> Router Class Initialized
INFO - 2021-12-27 02:21:40 --> Output Class Initialized
INFO - 2021-12-27 02:21:40 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:40 --> Input Class Initialized
INFO - 2021-12-27 02:21:40 --> Language Class Initialized
INFO - 2021-12-27 02:21:40 --> Language Class Initialized
INFO - 2021-12-27 02:21:40 --> Config Class Initialized
INFO - 2021-12-27 02:21:40 --> Loader Class Initialized
INFO - 2021-12-27 02:21:40 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:40 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:40 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:40 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:40 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:40 --> Controller Class Initialized
INFO - 2021-12-27 02:21:40 --> Helper loaded: cookie_helper
INFO - 2021-12-27 02:21:40 --> Config Class Initialized
INFO - 2021-12-27 02:21:40 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:40 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:40 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:40 --> URI Class Initialized
INFO - 2021-12-27 02:21:40 --> Router Class Initialized
INFO - 2021-12-27 02:21:40 --> Output Class Initialized
INFO - 2021-12-27 02:21:40 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:40 --> Input Class Initialized
INFO - 2021-12-27 02:21:40 --> Language Class Initialized
INFO - 2021-12-27 02:21:40 --> Language Class Initialized
INFO - 2021-12-27 02:21:40 --> Config Class Initialized
INFO - 2021-12-27 02:21:40 --> Loader Class Initialized
INFO - 2021-12-27 02:21:40 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:40 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:40 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:40 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:40 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:40 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-27 02:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:21:40 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:40 --> Total execution time: 0.0360
INFO - 2021-12-27 02:21:45 --> Config Class Initialized
INFO - 2021-12-27 02:21:45 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:45 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:45 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:45 --> URI Class Initialized
INFO - 2021-12-27 02:21:45 --> Router Class Initialized
INFO - 2021-12-27 02:21:45 --> Output Class Initialized
INFO - 2021-12-27 02:21:45 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:45 --> Input Class Initialized
INFO - 2021-12-27 02:21:45 --> Language Class Initialized
INFO - 2021-12-27 02:21:45 --> Language Class Initialized
INFO - 2021-12-27 02:21:45 --> Config Class Initialized
INFO - 2021-12-27 02:21:45 --> Loader Class Initialized
INFO - 2021-12-27 02:21:45 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:45 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:45 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:45 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:45 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:45 --> Controller Class Initialized
INFO - 2021-12-27 02:21:45 --> Helper loaded: cookie_helper
INFO - 2021-12-27 02:21:45 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:45 --> Total execution time: 0.0526
INFO - 2021-12-27 02:21:45 --> Config Class Initialized
INFO - 2021-12-27 02:21:45 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:45 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:45 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:45 --> URI Class Initialized
INFO - 2021-12-27 02:21:45 --> Router Class Initialized
INFO - 2021-12-27 02:21:45 --> Output Class Initialized
INFO - 2021-12-27 02:21:45 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:45 --> Input Class Initialized
INFO - 2021-12-27 02:21:45 --> Language Class Initialized
INFO - 2021-12-27 02:21:45 --> Language Class Initialized
INFO - 2021-12-27 02:21:45 --> Config Class Initialized
INFO - 2021-12-27 02:21:45 --> Loader Class Initialized
INFO - 2021-12-27 02:21:45 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:45 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:45 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:45 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:45 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:45 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-27 02:21:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:21:45 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:45 --> Total execution time: 0.2420
INFO - 2021-12-27 02:21:51 --> Config Class Initialized
INFO - 2021-12-27 02:21:51 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:51 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:51 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:51 --> URI Class Initialized
INFO - 2021-12-27 02:21:51 --> Router Class Initialized
INFO - 2021-12-27 02:21:51 --> Output Class Initialized
INFO - 2021-12-27 02:21:51 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:51 --> Input Class Initialized
INFO - 2021-12-27 02:21:51 --> Language Class Initialized
INFO - 2021-12-27 02:21:51 --> Language Class Initialized
INFO - 2021-12-27 02:21:51 --> Config Class Initialized
INFO - 2021-12-27 02:21:51 --> Loader Class Initialized
INFO - 2021-12-27 02:21:51 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:51 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:51 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:51 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:51 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:51 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-27 02:21:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:21:51 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:51 --> Total execution time: 0.0550
INFO - 2021-12-27 02:21:56 --> Config Class Initialized
INFO - 2021-12-27 02:21:56 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:21:56 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:21:56 --> Utf8 Class Initialized
INFO - 2021-12-27 02:21:56 --> URI Class Initialized
INFO - 2021-12-27 02:21:56 --> Router Class Initialized
INFO - 2021-12-27 02:21:56 --> Output Class Initialized
INFO - 2021-12-27 02:21:56 --> Security Class Initialized
DEBUG - 2021-12-27 02:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:21:56 --> Input Class Initialized
INFO - 2021-12-27 02:21:56 --> Language Class Initialized
INFO - 2021-12-27 02:21:56 --> Language Class Initialized
INFO - 2021-12-27 02:21:56 --> Config Class Initialized
INFO - 2021-12-27 02:21:56 --> Loader Class Initialized
INFO - 2021-12-27 02:21:56 --> Helper loaded: url_helper
INFO - 2021-12-27 02:21:56 --> Helper loaded: file_helper
INFO - 2021-12-27 02:21:56 --> Helper loaded: form_helper
INFO - 2021-12-27 02:21:56 --> Helper loaded: my_helper
INFO - 2021-12-27 02:21:56 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:21:56 --> Controller Class Initialized
DEBUG - 2021-12-27 02:21:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-27 02:21:56 --> Final output sent to browser
DEBUG - 2021-12-27 02:21:56 --> Total execution time: 0.0970
INFO - 2021-12-27 02:22:09 --> Config Class Initialized
INFO - 2021-12-27 02:22:09 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:22:09 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:22:09 --> Utf8 Class Initialized
INFO - 2021-12-27 02:22:09 --> URI Class Initialized
INFO - 2021-12-27 02:22:09 --> Router Class Initialized
INFO - 2021-12-27 02:22:09 --> Output Class Initialized
INFO - 2021-12-27 02:22:09 --> Security Class Initialized
DEBUG - 2021-12-27 02:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:22:09 --> Input Class Initialized
INFO - 2021-12-27 02:22:09 --> Language Class Initialized
INFO - 2021-12-27 02:22:09 --> Language Class Initialized
INFO - 2021-12-27 02:22:09 --> Config Class Initialized
INFO - 2021-12-27 02:22:09 --> Loader Class Initialized
INFO - 2021-12-27 02:22:09 --> Helper loaded: url_helper
INFO - 2021-12-27 02:22:09 --> Helper loaded: file_helper
INFO - 2021-12-27 02:22:09 --> Helper loaded: form_helper
INFO - 2021-12-27 02:22:09 --> Helper loaded: my_helper
INFO - 2021-12-27 02:22:09 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:22:09 --> Controller Class Initialized
DEBUG - 2021-12-27 02:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-27 02:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:22:09 --> Final output sent to browser
DEBUG - 2021-12-27 02:22:09 --> Total execution time: 0.0850
INFO - 2021-12-27 02:22:39 --> Config Class Initialized
INFO - 2021-12-27 02:22:39 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:22:39 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:22:39 --> Utf8 Class Initialized
INFO - 2021-12-27 02:22:39 --> URI Class Initialized
INFO - 2021-12-27 02:22:39 --> Router Class Initialized
INFO - 2021-12-27 02:22:39 --> Output Class Initialized
INFO - 2021-12-27 02:22:39 --> Security Class Initialized
DEBUG - 2021-12-27 02:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:22:39 --> Input Class Initialized
INFO - 2021-12-27 02:22:39 --> Language Class Initialized
INFO - 2021-12-27 02:22:40 --> Language Class Initialized
INFO - 2021-12-27 02:22:40 --> Config Class Initialized
INFO - 2021-12-27 02:22:40 --> Loader Class Initialized
INFO - 2021-12-27 02:22:40 --> Helper loaded: url_helper
INFO - 2021-12-27 02:22:40 --> Helper loaded: file_helper
INFO - 2021-12-27 02:22:40 --> Helper loaded: form_helper
INFO - 2021-12-27 02:22:40 --> Helper loaded: my_helper
INFO - 2021-12-27 02:22:40 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:22:40 --> Controller Class Initialized
DEBUG - 2021-12-27 02:22:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-27 02:22:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:22:40 --> Final output sent to browser
DEBUG - 2021-12-27 02:22:40 --> Total execution time: 0.0500
INFO - 2021-12-27 02:29:54 --> Config Class Initialized
INFO - 2021-12-27 02:29:54 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:29:54 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:29:54 --> Utf8 Class Initialized
INFO - 2021-12-27 02:29:54 --> URI Class Initialized
INFO - 2021-12-27 02:29:54 --> Router Class Initialized
INFO - 2021-12-27 02:29:54 --> Output Class Initialized
INFO - 2021-12-27 02:29:54 --> Security Class Initialized
DEBUG - 2021-12-27 02:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:29:54 --> Input Class Initialized
INFO - 2021-12-27 02:29:54 --> Language Class Initialized
INFO - 2021-12-27 02:29:54 --> Language Class Initialized
INFO - 2021-12-27 02:29:54 --> Config Class Initialized
INFO - 2021-12-27 02:29:54 --> Loader Class Initialized
INFO - 2021-12-27 02:29:54 --> Helper loaded: url_helper
INFO - 2021-12-27 02:29:54 --> Helper loaded: file_helper
INFO - 2021-12-27 02:29:54 --> Helper loaded: form_helper
INFO - 2021-12-27 02:29:54 --> Helper loaded: my_helper
INFO - 2021-12-27 02:29:54 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:29:54 --> Controller Class Initialized
DEBUG - 2021-12-27 02:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-27 02:29:54 --> Final output sent to browser
DEBUG - 2021-12-27 02:29:54 --> Total execution time: 0.0840
INFO - 2021-12-27 02:29:54 --> Config Class Initialized
INFO - 2021-12-27 02:29:54 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:29:54 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:29:54 --> Utf8 Class Initialized
INFO - 2021-12-27 02:29:54 --> URI Class Initialized
INFO - 2021-12-27 02:29:54 --> Router Class Initialized
INFO - 2021-12-27 02:29:54 --> Output Class Initialized
INFO - 2021-12-27 02:29:54 --> Security Class Initialized
DEBUG - 2021-12-27 02:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:29:54 --> Input Class Initialized
INFO - 2021-12-27 02:29:54 --> Language Class Initialized
INFO - 2021-12-27 02:29:54 --> Language Class Initialized
INFO - 2021-12-27 02:29:54 --> Config Class Initialized
INFO - 2021-12-27 02:29:54 --> Loader Class Initialized
INFO - 2021-12-27 02:29:54 --> Helper loaded: url_helper
INFO - 2021-12-27 02:29:54 --> Helper loaded: file_helper
INFO - 2021-12-27 02:29:54 --> Helper loaded: form_helper
INFO - 2021-12-27 02:29:54 --> Helper loaded: my_helper
INFO - 2021-12-27 02:29:54 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:29:54 --> Controller Class Initialized
DEBUG - 2021-12-27 02:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-27 02:29:54 --> Final output sent to browser
DEBUG - 2021-12-27 02:29:54 --> Total execution time: 0.0700
INFO - 2021-12-27 02:30:44 --> Config Class Initialized
INFO - 2021-12-27 02:30:44 --> Hooks Class Initialized
DEBUG - 2021-12-27 02:30:44 --> UTF-8 Support Enabled
INFO - 2021-12-27 02:30:44 --> Utf8 Class Initialized
INFO - 2021-12-27 02:30:44 --> URI Class Initialized
INFO - 2021-12-27 02:30:44 --> Router Class Initialized
INFO - 2021-12-27 02:30:44 --> Output Class Initialized
INFO - 2021-12-27 02:30:44 --> Security Class Initialized
DEBUG - 2021-12-27 02:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 02:30:44 --> Input Class Initialized
INFO - 2021-12-27 02:30:44 --> Language Class Initialized
INFO - 2021-12-27 02:30:44 --> Language Class Initialized
INFO - 2021-12-27 02:30:44 --> Config Class Initialized
INFO - 2021-12-27 02:30:44 --> Loader Class Initialized
INFO - 2021-12-27 02:30:44 --> Helper loaded: url_helper
INFO - 2021-12-27 02:30:44 --> Helper loaded: file_helper
INFO - 2021-12-27 02:30:44 --> Helper loaded: form_helper
INFO - 2021-12-27 02:30:44 --> Helper loaded: my_helper
INFO - 2021-12-27 02:30:44 --> Database Driver Class Initialized
DEBUG - 2021-12-27 02:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 02:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 02:30:44 --> Controller Class Initialized
DEBUG - 2021-12-27 02:30:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-27 02:30:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 02:30:44 --> Final output sent to browser
DEBUG - 2021-12-27 02:30:44 --> Total execution time: 0.0910
INFO - 2021-12-27 03:49:24 --> Config Class Initialized
INFO - 2021-12-27 03:49:24 --> Hooks Class Initialized
DEBUG - 2021-12-27 03:49:24 --> UTF-8 Support Enabled
INFO - 2021-12-27 03:49:24 --> Utf8 Class Initialized
INFO - 2021-12-27 03:49:24 --> URI Class Initialized
INFO - 2021-12-27 03:49:24 --> Router Class Initialized
INFO - 2021-12-27 03:49:24 --> Output Class Initialized
INFO - 2021-12-27 03:49:24 --> Security Class Initialized
DEBUG - 2021-12-27 03:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 03:49:24 --> Input Class Initialized
INFO - 2021-12-27 03:49:24 --> Language Class Initialized
ERROR - 2021-12-27 03:49:24 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting ')' C:\xampp\htdocs\nilai\application\modules\n_ekstra\controllers\N_ekstra.php 60
INFO - 2021-12-27 03:49:57 --> Config Class Initialized
INFO - 2021-12-27 03:49:57 --> Hooks Class Initialized
DEBUG - 2021-12-27 03:49:57 --> UTF-8 Support Enabled
INFO - 2021-12-27 03:49:57 --> Utf8 Class Initialized
INFO - 2021-12-27 03:49:57 --> URI Class Initialized
INFO - 2021-12-27 03:49:57 --> Router Class Initialized
INFO - 2021-12-27 03:49:57 --> Output Class Initialized
INFO - 2021-12-27 03:49:57 --> Security Class Initialized
DEBUG - 2021-12-27 03:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 03:49:57 --> Input Class Initialized
INFO - 2021-12-27 03:49:57 --> Language Class Initialized
INFO - 2021-12-27 03:49:57 --> Language Class Initialized
INFO - 2021-12-27 03:49:57 --> Config Class Initialized
INFO - 2021-12-27 03:49:57 --> Loader Class Initialized
INFO - 2021-12-27 03:49:57 --> Helper loaded: url_helper
INFO - 2021-12-27 03:49:57 --> Helper loaded: file_helper
INFO - 2021-12-27 03:49:57 --> Helper loaded: form_helper
INFO - 2021-12-27 03:49:57 --> Helper loaded: my_helper
INFO - 2021-12-27 03:49:57 --> Database Driver Class Initialized
DEBUG - 2021-12-27 03:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 03:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 03:49:57 --> Controller Class Initialized
DEBUG - 2021-12-27 03:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-27 03:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 03:49:57 --> Final output sent to browser
DEBUG - 2021-12-27 03:49:57 --> Total execution time: 0.0470
INFO - 2021-12-27 03:50:00 --> Config Class Initialized
INFO - 2021-12-27 03:50:00 --> Hooks Class Initialized
DEBUG - 2021-12-27 03:50:00 --> UTF-8 Support Enabled
INFO - 2021-12-27 03:50:00 --> Utf8 Class Initialized
INFO - 2021-12-27 03:50:00 --> URI Class Initialized
INFO - 2021-12-27 03:50:00 --> Router Class Initialized
INFO - 2021-12-27 03:50:00 --> Output Class Initialized
INFO - 2021-12-27 03:50:00 --> Security Class Initialized
DEBUG - 2021-12-27 03:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 03:50:00 --> Input Class Initialized
INFO - 2021-12-27 03:50:00 --> Language Class Initialized
INFO - 2021-12-27 03:50:00 --> Language Class Initialized
INFO - 2021-12-27 03:50:00 --> Config Class Initialized
INFO - 2021-12-27 03:50:00 --> Loader Class Initialized
INFO - 2021-12-27 03:50:00 --> Helper loaded: url_helper
INFO - 2021-12-27 03:50:00 --> Helper loaded: file_helper
INFO - 2021-12-27 03:50:00 --> Helper loaded: form_helper
INFO - 2021-12-27 03:50:00 --> Helper loaded: my_helper
INFO - 2021-12-27 03:50:00 --> Database Driver Class Initialized
DEBUG - 2021-12-27 03:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 03:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 03:50:00 --> Controller Class Initialized
INFO - 2021-12-27 03:50:00 --> Final output sent to browser
DEBUG - 2021-12-27 03:50:00 --> Total execution time: 0.0460
INFO - 2021-12-27 05:26:54 --> Config Class Initialized
INFO - 2021-12-27 05:26:54 --> Hooks Class Initialized
DEBUG - 2021-12-27 05:26:54 --> UTF-8 Support Enabled
INFO - 2021-12-27 05:26:54 --> Utf8 Class Initialized
INFO - 2021-12-27 05:26:54 --> URI Class Initialized
INFO - 2021-12-27 05:26:54 --> Router Class Initialized
INFO - 2021-12-27 05:26:54 --> Output Class Initialized
INFO - 2021-12-27 05:26:54 --> Security Class Initialized
DEBUG - 2021-12-27 05:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 05:26:54 --> Input Class Initialized
INFO - 2021-12-27 05:26:54 --> Language Class Initialized
INFO - 2021-12-27 05:26:54 --> Language Class Initialized
INFO - 2021-12-27 05:26:54 --> Config Class Initialized
INFO - 2021-12-27 05:26:54 --> Loader Class Initialized
INFO - 2021-12-27 05:26:54 --> Helper loaded: url_helper
INFO - 2021-12-27 05:26:54 --> Helper loaded: file_helper
INFO - 2021-12-27 05:26:54 --> Helper loaded: form_helper
INFO - 2021-12-27 05:26:54 --> Helper loaded: my_helper
INFO - 2021-12-27 05:26:54 --> Database Driver Class Initialized
DEBUG - 2021-12-27 05:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 05:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 05:26:54 --> Controller Class Initialized
DEBUG - 2021-12-27 05:26:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-27 05:26:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 05:26:54 --> Final output sent to browser
DEBUG - 2021-12-27 05:26:54 --> Total execution time: 0.0460
INFO - 2021-12-27 05:27:53 --> Config Class Initialized
INFO - 2021-12-27 05:27:53 --> Hooks Class Initialized
DEBUG - 2021-12-27 05:27:53 --> UTF-8 Support Enabled
INFO - 2021-12-27 05:27:53 --> Utf8 Class Initialized
INFO - 2021-12-27 05:27:53 --> URI Class Initialized
INFO - 2021-12-27 05:27:53 --> Router Class Initialized
INFO - 2021-12-27 05:27:53 --> Output Class Initialized
INFO - 2021-12-27 05:27:53 --> Security Class Initialized
DEBUG - 2021-12-27 05:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 05:27:53 --> Input Class Initialized
INFO - 2021-12-27 05:27:53 --> Language Class Initialized
INFO - 2021-12-27 05:27:53 --> Language Class Initialized
INFO - 2021-12-27 05:27:53 --> Config Class Initialized
INFO - 2021-12-27 05:27:53 --> Loader Class Initialized
INFO - 2021-12-27 05:27:53 --> Helper loaded: url_helper
INFO - 2021-12-27 05:27:53 --> Helper loaded: file_helper
INFO - 2021-12-27 05:27:53 --> Helper loaded: form_helper
INFO - 2021-12-27 05:27:53 --> Helper loaded: my_helper
INFO - 2021-12-27 05:27:53 --> Database Driver Class Initialized
DEBUG - 2021-12-27 05:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 05:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 05:27:53 --> Controller Class Initialized
ERROR - 2021-12-27 05:27:53 --> Severity: Notice --> Undefined variable: mode_form C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 24
DEBUG - 2021-12-27 05:27:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-27 05:27:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-27 05:27:53 --> Final output sent to browser
DEBUG - 2021-12-27 05:27:53 --> Total execution time: 0.0460
