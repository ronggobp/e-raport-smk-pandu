<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-29 02:26:24 --> Config Class Initialized
INFO - 2021-04-29 02:26:24 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:26:24 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:26:24 --> Utf8 Class Initialized
INFO - 2021-04-29 02:26:24 --> URI Class Initialized
DEBUG - 2021-04-29 02:26:24 --> No URI present. Default controller set.
INFO - 2021-04-29 02:26:24 --> Router Class Initialized
INFO - 2021-04-29 02:26:24 --> Output Class Initialized
INFO - 2021-04-29 02:26:24 --> Security Class Initialized
DEBUG - 2021-04-29 02:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:26:24 --> Input Class Initialized
INFO - 2021-04-29 02:26:24 --> Language Class Initialized
INFO - 2021-04-29 02:26:24 --> Language Class Initialized
INFO - 2021-04-29 02:26:24 --> Config Class Initialized
INFO - 2021-04-29 02:26:24 --> Loader Class Initialized
INFO - 2021-04-29 02:26:24 --> Helper loaded: url_helper
INFO - 2021-04-29 02:26:24 --> Helper loaded: file_helper
INFO - 2021-04-29 02:26:24 --> Helper loaded: form_helper
INFO - 2021-04-29 02:26:24 --> Helper loaded: my_helper
INFO - 2021-04-29 02:26:24 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:26:24 --> Controller Class Initialized
INFO - 2021-04-29 02:26:24 --> Config Class Initialized
INFO - 2021-04-29 02:26:24 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:26:24 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:26:24 --> Utf8 Class Initialized
INFO - 2021-04-29 02:26:24 --> URI Class Initialized
INFO - 2021-04-29 02:26:24 --> Router Class Initialized
INFO - 2021-04-29 02:26:24 --> Output Class Initialized
INFO - 2021-04-29 02:26:24 --> Security Class Initialized
DEBUG - 2021-04-29 02:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:26:24 --> Input Class Initialized
INFO - 2021-04-29 02:26:24 --> Language Class Initialized
INFO - 2021-04-29 02:26:24 --> Language Class Initialized
INFO - 2021-04-29 02:26:24 --> Config Class Initialized
INFO - 2021-04-29 02:26:24 --> Loader Class Initialized
INFO - 2021-04-29 02:26:24 --> Helper loaded: url_helper
INFO - 2021-04-29 02:26:24 --> Helper loaded: file_helper
INFO - 2021-04-29 02:26:24 --> Helper loaded: form_helper
INFO - 2021-04-29 02:26:24 --> Helper loaded: my_helper
INFO - 2021-04-29 02:26:24 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:26:24 --> Controller Class Initialized
DEBUG - 2021-04-29 02:26:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 02:26:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 02:26:24 --> Final output sent to browser
DEBUG - 2021-04-29 02:26:24 --> Total execution time: 0.0979
INFO - 2021-04-29 02:36:33 --> Config Class Initialized
INFO - 2021-04-29 02:36:33 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:36:33 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:36:33 --> Utf8 Class Initialized
INFO - 2021-04-29 02:36:33 --> URI Class Initialized
INFO - 2021-04-29 02:36:33 --> Router Class Initialized
INFO - 2021-04-29 02:36:33 --> Output Class Initialized
INFO - 2021-04-29 02:36:33 --> Security Class Initialized
DEBUG - 2021-04-29 02:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:36:33 --> Input Class Initialized
INFO - 2021-04-29 02:36:33 --> Language Class Initialized
INFO - 2021-04-29 02:36:34 --> Language Class Initialized
INFO - 2021-04-29 02:36:34 --> Config Class Initialized
INFO - 2021-04-29 02:36:34 --> Loader Class Initialized
INFO - 2021-04-29 02:36:34 --> Helper loaded: url_helper
INFO - 2021-04-29 02:36:34 --> Helper loaded: file_helper
INFO - 2021-04-29 02:36:34 --> Helper loaded: form_helper
INFO - 2021-04-29 02:36:34 --> Helper loaded: my_helper
INFO - 2021-04-29 02:36:34 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:36:35 --> Controller Class Initialized
INFO - 2021-04-29 02:36:35 --> Helper loaded: cookie_helper
INFO - 2021-04-29 02:36:35 --> Final output sent to browser
DEBUG - 2021-04-29 02:36:35 --> Total execution time: 2.5823
INFO - 2021-04-29 02:36:43 --> Config Class Initialized
INFO - 2021-04-29 02:36:43 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:36:43 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:36:43 --> Utf8 Class Initialized
INFO - 2021-04-29 02:36:43 --> URI Class Initialized
INFO - 2021-04-29 02:36:43 --> Router Class Initialized
INFO - 2021-04-29 02:36:43 --> Output Class Initialized
INFO - 2021-04-29 02:36:43 --> Security Class Initialized
DEBUG - 2021-04-29 02:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:36:43 --> Input Class Initialized
INFO - 2021-04-29 02:36:43 --> Language Class Initialized
INFO - 2021-04-29 02:36:43 --> Language Class Initialized
INFO - 2021-04-29 02:36:43 --> Config Class Initialized
INFO - 2021-04-29 02:36:43 --> Loader Class Initialized
INFO - 2021-04-29 02:36:43 --> Helper loaded: url_helper
INFO - 2021-04-29 02:36:43 --> Helper loaded: file_helper
INFO - 2021-04-29 02:36:43 --> Helper loaded: form_helper
INFO - 2021-04-29 02:36:43 --> Helper loaded: my_helper
INFO - 2021-04-29 02:36:43 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:36:43 --> Controller Class Initialized
DEBUG - 2021-04-29 02:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 02:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 02:36:44 --> Final output sent to browser
DEBUG - 2021-04-29 02:36:44 --> Total execution time: 0.5949
INFO - 2021-04-29 02:37:17 --> Config Class Initialized
INFO - 2021-04-29 02:37:17 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:37:17 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:37:17 --> Utf8 Class Initialized
INFO - 2021-04-29 02:37:17 --> URI Class Initialized
INFO - 2021-04-29 02:37:17 --> Router Class Initialized
INFO - 2021-04-29 02:37:17 --> Output Class Initialized
INFO - 2021-04-29 02:37:17 --> Security Class Initialized
DEBUG - 2021-04-29 02:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:37:17 --> Input Class Initialized
INFO - 2021-04-29 02:37:17 --> Language Class Initialized
INFO - 2021-04-29 02:37:17 --> Language Class Initialized
INFO - 2021-04-29 02:37:17 --> Config Class Initialized
INFO - 2021-04-29 02:37:17 --> Loader Class Initialized
INFO - 2021-04-29 02:37:17 --> Helper loaded: url_helper
INFO - 2021-04-29 02:37:17 --> Helper loaded: file_helper
INFO - 2021-04-29 02:37:17 --> Helper loaded: form_helper
INFO - 2021-04-29 02:37:17 --> Helper loaded: my_helper
INFO - 2021-04-29 02:37:17 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:37:17 --> Controller Class Initialized
INFO - 2021-04-29 02:37:17 --> Helper loaded: cookie_helper
INFO - 2021-04-29 02:37:17 --> Config Class Initialized
INFO - 2021-04-29 02:37:17 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:37:17 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:37:17 --> Utf8 Class Initialized
INFO - 2021-04-29 02:37:17 --> URI Class Initialized
INFO - 2021-04-29 02:37:17 --> Router Class Initialized
INFO - 2021-04-29 02:37:17 --> Output Class Initialized
INFO - 2021-04-29 02:37:17 --> Security Class Initialized
DEBUG - 2021-04-29 02:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:37:17 --> Input Class Initialized
INFO - 2021-04-29 02:37:17 --> Language Class Initialized
INFO - 2021-04-29 02:37:17 --> Language Class Initialized
INFO - 2021-04-29 02:37:17 --> Config Class Initialized
INFO - 2021-04-29 02:37:17 --> Loader Class Initialized
INFO - 2021-04-29 02:37:17 --> Helper loaded: url_helper
INFO - 2021-04-29 02:37:17 --> Helper loaded: file_helper
INFO - 2021-04-29 02:37:17 --> Helper loaded: form_helper
INFO - 2021-04-29 02:37:17 --> Helper loaded: my_helper
INFO - 2021-04-29 02:37:17 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:37:17 --> Controller Class Initialized
DEBUG - 2021-04-29 02:37:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 02:37:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 02:37:17 --> Final output sent to browser
DEBUG - 2021-04-29 02:37:17 --> Total execution time: 0.1773
INFO - 2021-04-29 02:37:22 --> Config Class Initialized
INFO - 2021-04-29 02:37:22 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:37:22 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:37:22 --> Utf8 Class Initialized
INFO - 2021-04-29 02:37:22 --> URI Class Initialized
INFO - 2021-04-29 02:37:22 --> Router Class Initialized
INFO - 2021-04-29 02:37:22 --> Output Class Initialized
INFO - 2021-04-29 02:37:22 --> Security Class Initialized
DEBUG - 2021-04-29 02:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:37:22 --> Input Class Initialized
INFO - 2021-04-29 02:37:22 --> Language Class Initialized
INFO - 2021-04-29 02:37:23 --> Language Class Initialized
INFO - 2021-04-29 02:37:23 --> Config Class Initialized
INFO - 2021-04-29 02:37:23 --> Loader Class Initialized
INFO - 2021-04-29 02:37:23 --> Helper loaded: url_helper
INFO - 2021-04-29 02:37:23 --> Helper loaded: file_helper
INFO - 2021-04-29 02:37:23 --> Helper loaded: form_helper
INFO - 2021-04-29 02:37:23 --> Helper loaded: my_helper
INFO - 2021-04-29 02:37:23 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:37:23 --> Controller Class Initialized
INFO - 2021-04-29 02:37:23 --> Final output sent to browser
DEBUG - 2021-04-29 02:37:23 --> Total execution time: 0.5626
INFO - 2021-04-29 02:37:27 --> Config Class Initialized
INFO - 2021-04-29 02:37:27 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:37:27 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:37:27 --> Utf8 Class Initialized
INFO - 2021-04-29 02:37:27 --> URI Class Initialized
INFO - 2021-04-29 02:37:27 --> Router Class Initialized
INFO - 2021-04-29 02:37:27 --> Output Class Initialized
INFO - 2021-04-29 02:37:27 --> Security Class Initialized
DEBUG - 2021-04-29 02:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:37:27 --> Input Class Initialized
INFO - 2021-04-29 02:37:27 --> Language Class Initialized
INFO - 2021-04-29 02:37:27 --> Language Class Initialized
INFO - 2021-04-29 02:37:27 --> Config Class Initialized
INFO - 2021-04-29 02:37:27 --> Loader Class Initialized
INFO - 2021-04-29 02:37:27 --> Helper loaded: url_helper
INFO - 2021-04-29 02:37:27 --> Helper loaded: file_helper
INFO - 2021-04-29 02:37:27 --> Helper loaded: form_helper
INFO - 2021-04-29 02:37:27 --> Helper loaded: my_helper
INFO - 2021-04-29 02:37:27 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:37:27 --> Controller Class Initialized
INFO - 2021-04-29 02:37:27 --> Helper loaded: cookie_helper
INFO - 2021-04-29 02:37:27 --> Final output sent to browser
DEBUG - 2021-04-29 02:37:27 --> Total execution time: 0.1843
INFO - 2021-04-29 02:37:28 --> Config Class Initialized
INFO - 2021-04-29 02:37:28 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:37:28 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:37:28 --> Utf8 Class Initialized
INFO - 2021-04-29 02:37:28 --> URI Class Initialized
INFO - 2021-04-29 02:37:28 --> Router Class Initialized
INFO - 2021-04-29 02:37:28 --> Output Class Initialized
INFO - 2021-04-29 02:37:28 --> Security Class Initialized
DEBUG - 2021-04-29 02:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:37:28 --> Input Class Initialized
INFO - 2021-04-29 02:37:28 --> Language Class Initialized
INFO - 2021-04-29 02:37:28 --> Language Class Initialized
INFO - 2021-04-29 02:37:28 --> Config Class Initialized
INFO - 2021-04-29 02:37:28 --> Loader Class Initialized
INFO - 2021-04-29 02:37:28 --> Helper loaded: url_helper
INFO - 2021-04-29 02:37:28 --> Helper loaded: file_helper
INFO - 2021-04-29 02:37:28 --> Helper loaded: form_helper
INFO - 2021-04-29 02:37:28 --> Helper loaded: my_helper
INFO - 2021-04-29 02:37:28 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:37:28 --> Controller Class Initialized
DEBUG - 2021-04-29 02:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 02:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 02:37:28 --> Final output sent to browser
DEBUG - 2021-04-29 02:37:28 --> Total execution time: 0.1779
INFO - 2021-04-29 02:37:34 --> Config Class Initialized
INFO - 2021-04-29 02:37:34 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:37:34 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:37:34 --> Utf8 Class Initialized
INFO - 2021-04-29 02:37:34 --> URI Class Initialized
INFO - 2021-04-29 02:37:34 --> Router Class Initialized
INFO - 2021-04-29 02:37:34 --> Output Class Initialized
INFO - 2021-04-29 02:37:34 --> Security Class Initialized
DEBUG - 2021-04-29 02:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:37:34 --> Input Class Initialized
INFO - 2021-04-29 02:37:34 --> Language Class Initialized
INFO - 2021-04-29 02:37:34 --> Language Class Initialized
INFO - 2021-04-29 02:37:34 --> Config Class Initialized
INFO - 2021-04-29 02:37:34 --> Loader Class Initialized
INFO - 2021-04-29 02:37:34 --> Helper loaded: url_helper
INFO - 2021-04-29 02:37:34 --> Helper loaded: file_helper
INFO - 2021-04-29 02:37:34 --> Helper loaded: form_helper
INFO - 2021-04-29 02:37:34 --> Helper loaded: my_helper
INFO - 2021-04-29 02:37:34 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:37:34 --> Controller Class Initialized
DEBUG - 2021-04-29 02:37:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-04-29 02:37:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 02:37:34 --> Final output sent to browser
DEBUG - 2021-04-29 02:37:34 --> Total execution time: 0.5166
INFO - 2021-04-29 02:37:44 --> Config Class Initialized
INFO - 2021-04-29 02:37:44 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:37:44 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:37:44 --> Utf8 Class Initialized
INFO - 2021-04-29 02:37:44 --> URI Class Initialized
INFO - 2021-04-29 02:37:44 --> Router Class Initialized
INFO - 2021-04-29 02:37:44 --> Output Class Initialized
INFO - 2021-04-29 02:37:44 --> Security Class Initialized
DEBUG - 2021-04-29 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:37:44 --> Input Class Initialized
INFO - 2021-04-29 02:37:44 --> Language Class Initialized
INFO - 2021-04-29 02:37:44 --> Language Class Initialized
INFO - 2021-04-29 02:37:44 --> Config Class Initialized
INFO - 2021-04-29 02:37:44 --> Loader Class Initialized
INFO - 2021-04-29 02:37:44 --> Helper loaded: url_helper
INFO - 2021-04-29 02:37:44 --> Helper loaded: file_helper
INFO - 2021-04-29 02:37:44 --> Helper loaded: form_helper
INFO - 2021-04-29 02:37:44 --> Helper loaded: my_helper
INFO - 2021-04-29 02:37:44 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:37:44 --> Controller Class Initialized
INFO - 2021-04-29 02:37:44 --> Helper loaded: cookie_helper
INFO - 2021-04-29 02:37:44 --> Config Class Initialized
INFO - 2021-04-29 02:37:44 --> Hooks Class Initialized
DEBUG - 2021-04-29 02:37:44 --> UTF-8 Support Enabled
INFO - 2021-04-29 02:37:44 --> Utf8 Class Initialized
INFO - 2021-04-29 02:37:44 --> URI Class Initialized
INFO - 2021-04-29 02:37:44 --> Router Class Initialized
INFO - 2021-04-29 02:37:44 --> Output Class Initialized
INFO - 2021-04-29 02:37:44 --> Security Class Initialized
DEBUG - 2021-04-29 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 02:37:44 --> Input Class Initialized
INFO - 2021-04-29 02:37:44 --> Language Class Initialized
INFO - 2021-04-29 02:37:44 --> Language Class Initialized
INFO - 2021-04-29 02:37:44 --> Config Class Initialized
INFO - 2021-04-29 02:37:44 --> Loader Class Initialized
INFO - 2021-04-29 02:37:44 --> Helper loaded: url_helper
INFO - 2021-04-29 02:37:44 --> Helper loaded: file_helper
INFO - 2021-04-29 02:37:44 --> Helper loaded: form_helper
INFO - 2021-04-29 02:37:44 --> Helper loaded: my_helper
INFO - 2021-04-29 02:37:44 --> Database Driver Class Initialized
DEBUG - 2021-04-29 02:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 02:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 02:37:44 --> Controller Class Initialized
DEBUG - 2021-04-29 02:37:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 02:37:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 02:37:44 --> Final output sent to browser
DEBUG - 2021-04-29 02:37:44 --> Total execution time: 0.1131
INFO - 2021-04-29 03:27:31 --> Config Class Initialized
INFO - 2021-04-29 03:27:31 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:27:31 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:27:31 --> Utf8 Class Initialized
INFO - 2021-04-29 03:27:31 --> URI Class Initialized
INFO - 2021-04-29 03:27:31 --> Router Class Initialized
INFO - 2021-04-29 03:27:31 --> Output Class Initialized
INFO - 2021-04-29 03:27:31 --> Security Class Initialized
DEBUG - 2021-04-29 03:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:27:31 --> Input Class Initialized
INFO - 2021-04-29 03:27:31 --> Language Class Initialized
INFO - 2021-04-29 03:27:31 --> Language Class Initialized
INFO - 2021-04-29 03:27:31 --> Config Class Initialized
INFO - 2021-04-29 03:27:31 --> Loader Class Initialized
INFO - 2021-04-29 03:27:31 --> Helper loaded: url_helper
INFO - 2021-04-29 03:27:31 --> Helper loaded: file_helper
INFO - 2021-04-29 03:27:31 --> Helper loaded: form_helper
INFO - 2021-04-29 03:27:32 --> Helper loaded: my_helper
INFO - 2021-04-29 03:27:32 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:27:32 --> Controller Class Initialized
DEBUG - 2021-04-29 03:27:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:27:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:27:32 --> Final output sent to browser
DEBUG - 2021-04-29 03:27:32 --> Total execution time: 0.1322
INFO - 2021-04-29 03:27:33 --> Config Class Initialized
INFO - 2021-04-29 03:27:33 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:27:33 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:27:33 --> Utf8 Class Initialized
INFO - 2021-04-29 03:27:33 --> URI Class Initialized
INFO - 2021-04-29 03:27:33 --> Router Class Initialized
INFO - 2021-04-29 03:27:33 --> Output Class Initialized
INFO - 2021-04-29 03:27:33 --> Security Class Initialized
DEBUG - 2021-04-29 03:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:27:33 --> Input Class Initialized
INFO - 2021-04-29 03:27:33 --> Language Class Initialized
INFO - 2021-04-29 03:27:33 --> Language Class Initialized
INFO - 2021-04-29 03:27:33 --> Config Class Initialized
INFO - 2021-04-29 03:27:33 --> Loader Class Initialized
INFO - 2021-04-29 03:27:33 --> Helper loaded: url_helper
INFO - 2021-04-29 03:27:33 --> Helper loaded: file_helper
INFO - 2021-04-29 03:27:33 --> Helper loaded: form_helper
INFO - 2021-04-29 03:27:33 --> Helper loaded: my_helper
INFO - 2021-04-29 03:27:33 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:27:33 --> Controller Class Initialized
DEBUG - 2021-04-29 03:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:27:33 --> Final output sent to browser
DEBUG - 2021-04-29 03:27:33 --> Total execution time: 0.1463
INFO - 2021-04-29 03:28:28 --> Config Class Initialized
INFO - 2021-04-29 03:28:28 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:28 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:28 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:28 --> URI Class Initialized
DEBUG - 2021-04-29 03:28:28 --> No URI present. Default controller set.
INFO - 2021-04-29 03:28:28 --> Router Class Initialized
INFO - 2021-04-29 03:28:28 --> Output Class Initialized
INFO - 2021-04-29 03:28:28 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:28 --> Input Class Initialized
INFO - 2021-04-29 03:28:28 --> Language Class Initialized
INFO - 2021-04-29 03:28:28 --> Language Class Initialized
INFO - 2021-04-29 03:28:28 --> Config Class Initialized
INFO - 2021-04-29 03:28:28 --> Loader Class Initialized
INFO - 2021-04-29 03:28:28 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:28 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:28 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:28 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:28 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:28 --> Controller Class Initialized
INFO - 2021-04-29 03:28:28 --> Config Class Initialized
INFO - 2021-04-29 03:28:28 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:28 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:28 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:28 --> URI Class Initialized
INFO - 2021-04-29 03:28:28 --> Router Class Initialized
INFO - 2021-04-29 03:28:28 --> Output Class Initialized
INFO - 2021-04-29 03:28:28 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:28 --> Input Class Initialized
INFO - 2021-04-29 03:28:28 --> Language Class Initialized
INFO - 2021-04-29 03:28:28 --> Language Class Initialized
INFO - 2021-04-29 03:28:28 --> Config Class Initialized
INFO - 2021-04-29 03:28:28 --> Loader Class Initialized
INFO - 2021-04-29 03:28:28 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:28 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:28 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:28 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:28 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:28 --> Controller Class Initialized
DEBUG - 2021-04-29 03:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 03:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:28:28 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:28 --> Total execution time: 0.1060
INFO - 2021-04-29 03:28:33 --> Config Class Initialized
INFO - 2021-04-29 03:28:33 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:33 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:33 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:33 --> URI Class Initialized
INFO - 2021-04-29 03:28:33 --> Router Class Initialized
INFO - 2021-04-29 03:28:33 --> Output Class Initialized
INFO - 2021-04-29 03:28:33 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:33 --> Input Class Initialized
INFO - 2021-04-29 03:28:33 --> Language Class Initialized
INFO - 2021-04-29 03:28:33 --> Language Class Initialized
INFO - 2021-04-29 03:28:33 --> Config Class Initialized
INFO - 2021-04-29 03:28:33 --> Loader Class Initialized
INFO - 2021-04-29 03:28:33 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:33 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:33 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:33 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:33 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:33 --> Controller Class Initialized
INFO - 2021-04-29 03:28:33 --> Helper loaded: cookie_helper
INFO - 2021-04-29 03:28:33 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:33 --> Total execution time: 0.1243
INFO - 2021-04-29 03:28:34 --> Config Class Initialized
INFO - 2021-04-29 03:28:34 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:34 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:34 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:34 --> URI Class Initialized
INFO - 2021-04-29 03:28:34 --> Router Class Initialized
INFO - 2021-04-29 03:28:34 --> Output Class Initialized
INFO - 2021-04-29 03:28:34 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:34 --> Input Class Initialized
INFO - 2021-04-29 03:28:34 --> Language Class Initialized
INFO - 2021-04-29 03:28:34 --> Language Class Initialized
INFO - 2021-04-29 03:28:34 --> Config Class Initialized
INFO - 2021-04-29 03:28:34 --> Loader Class Initialized
INFO - 2021-04-29 03:28:34 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:34 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:34 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:34 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:34 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:34 --> Controller Class Initialized
DEBUG - 2021-04-29 03:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 03:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:28:34 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:34 --> Total execution time: 0.1996
INFO - 2021-04-29 03:28:36 --> Config Class Initialized
INFO - 2021-04-29 03:28:36 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:36 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:36 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:36 --> URI Class Initialized
INFO - 2021-04-29 03:28:36 --> Router Class Initialized
INFO - 2021-04-29 03:28:36 --> Output Class Initialized
INFO - 2021-04-29 03:28:36 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:36 --> Input Class Initialized
INFO - 2021-04-29 03:28:36 --> Language Class Initialized
INFO - 2021-04-29 03:28:36 --> Language Class Initialized
INFO - 2021-04-29 03:28:36 --> Config Class Initialized
INFO - 2021-04-29 03:28:36 --> Loader Class Initialized
INFO - 2021-04-29 03:28:36 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:36 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:36 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:36 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:36 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:36 --> Controller Class Initialized
DEBUG - 2021-04-29 03:28:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-29 03:28:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:28:36 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:36 --> Total execution time: 0.1143
INFO - 2021-04-29 03:28:36 --> Config Class Initialized
INFO - 2021-04-29 03:28:36 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:36 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:36 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:36 --> URI Class Initialized
INFO - 2021-04-29 03:28:36 --> Router Class Initialized
INFO - 2021-04-29 03:28:36 --> Output Class Initialized
INFO - 2021-04-29 03:28:36 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:36 --> Input Class Initialized
INFO - 2021-04-29 03:28:36 --> Language Class Initialized
INFO - 2021-04-29 03:28:36 --> Language Class Initialized
INFO - 2021-04-29 03:28:36 --> Config Class Initialized
INFO - 2021-04-29 03:28:36 --> Loader Class Initialized
INFO - 2021-04-29 03:28:36 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:36 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:36 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:36 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:36 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:36 --> Controller Class Initialized
INFO - 2021-04-29 03:28:39 --> Config Class Initialized
INFO - 2021-04-29 03:28:39 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:39 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:39 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:39 --> URI Class Initialized
INFO - 2021-04-29 03:28:39 --> Router Class Initialized
INFO - 2021-04-29 03:28:39 --> Output Class Initialized
INFO - 2021-04-29 03:28:39 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:39 --> Input Class Initialized
INFO - 2021-04-29 03:28:39 --> Language Class Initialized
INFO - 2021-04-29 03:28:39 --> Language Class Initialized
INFO - 2021-04-29 03:28:39 --> Config Class Initialized
INFO - 2021-04-29 03:28:39 --> Loader Class Initialized
INFO - 2021-04-29 03:28:39 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:39 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:39 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:39 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:39 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:39 --> Controller Class Initialized
DEBUG - 2021-04-29 03:28:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:28:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:28:39 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:39 --> Total execution time: 0.1373
INFO - 2021-04-29 03:28:41 --> Config Class Initialized
INFO - 2021-04-29 03:28:41 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:41 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:41 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:41 --> URI Class Initialized
INFO - 2021-04-29 03:28:41 --> Router Class Initialized
INFO - 2021-04-29 03:28:41 --> Output Class Initialized
INFO - 2021-04-29 03:28:41 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:41 --> Input Class Initialized
INFO - 2021-04-29 03:28:41 --> Language Class Initialized
INFO - 2021-04-29 03:28:41 --> Language Class Initialized
INFO - 2021-04-29 03:28:41 --> Config Class Initialized
INFO - 2021-04-29 03:28:41 --> Loader Class Initialized
INFO - 2021-04-29 03:28:41 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:41 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:41 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:41 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:41 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:41 --> Controller Class Initialized
DEBUG - 2021-04-29 03:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-29 03:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:28:41 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:41 --> Total execution time: 0.1429
INFO - 2021-04-29 03:28:48 --> Config Class Initialized
INFO - 2021-04-29 03:28:48 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:48 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:48 --> URI Class Initialized
INFO - 2021-04-29 03:28:48 --> Router Class Initialized
INFO - 2021-04-29 03:28:48 --> Output Class Initialized
INFO - 2021-04-29 03:28:48 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:48 --> Input Class Initialized
INFO - 2021-04-29 03:28:48 --> Language Class Initialized
INFO - 2021-04-29 03:28:48 --> Language Class Initialized
INFO - 2021-04-29 03:28:48 --> Config Class Initialized
INFO - 2021-04-29 03:28:48 --> Loader Class Initialized
INFO - 2021-04-29 03:28:48 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:48 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:48 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:48 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:48 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:48 --> Controller Class Initialized
INFO - 2021-04-29 03:28:48 --> Config Class Initialized
INFO - 2021-04-29 03:28:48 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:48 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:49 --> URI Class Initialized
INFO - 2021-04-29 03:28:49 --> Router Class Initialized
INFO - 2021-04-29 03:28:49 --> Output Class Initialized
INFO - 2021-04-29 03:28:49 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:49 --> Input Class Initialized
INFO - 2021-04-29 03:28:49 --> Language Class Initialized
INFO - 2021-04-29 03:28:49 --> Language Class Initialized
INFO - 2021-04-29 03:28:49 --> Config Class Initialized
INFO - 2021-04-29 03:28:49 --> Loader Class Initialized
INFO - 2021-04-29 03:28:49 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:49 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:49 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:49 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:49 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:49 --> Controller Class Initialized
DEBUG - 2021-04-29 03:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:28:49 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:49 --> Total execution time: 0.1503
INFO - 2021-04-29 03:28:52 --> Config Class Initialized
INFO - 2021-04-29 03:28:52 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:52 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:52 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:52 --> URI Class Initialized
INFO - 2021-04-29 03:28:52 --> Router Class Initialized
INFO - 2021-04-29 03:28:52 --> Output Class Initialized
INFO - 2021-04-29 03:28:52 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:52 --> Input Class Initialized
INFO - 2021-04-29 03:28:52 --> Language Class Initialized
INFO - 2021-04-29 03:28:52 --> Language Class Initialized
INFO - 2021-04-29 03:28:52 --> Config Class Initialized
INFO - 2021-04-29 03:28:52 --> Loader Class Initialized
INFO - 2021-04-29 03:28:52 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:52 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:52 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:52 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:52 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:52 --> Controller Class Initialized
DEBUG - 2021-04-29 03:28:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-29 03:28:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:28:52 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:52 --> Total execution time: 0.1270
INFO - 2021-04-29 03:28:57 --> Config Class Initialized
INFO - 2021-04-29 03:28:57 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:57 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:57 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:57 --> URI Class Initialized
INFO - 2021-04-29 03:28:57 --> Router Class Initialized
INFO - 2021-04-29 03:28:57 --> Output Class Initialized
INFO - 2021-04-29 03:28:57 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:57 --> Input Class Initialized
INFO - 2021-04-29 03:28:57 --> Language Class Initialized
INFO - 2021-04-29 03:28:57 --> Language Class Initialized
INFO - 2021-04-29 03:28:57 --> Config Class Initialized
INFO - 2021-04-29 03:28:57 --> Loader Class Initialized
INFO - 2021-04-29 03:28:57 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:57 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:57 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:57 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:57 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:57 --> Controller Class Initialized
INFO - 2021-04-29 03:28:57 --> Config Class Initialized
INFO - 2021-04-29 03:28:57 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:28:57 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:28:57 --> Utf8 Class Initialized
INFO - 2021-04-29 03:28:57 --> URI Class Initialized
INFO - 2021-04-29 03:28:57 --> Router Class Initialized
INFO - 2021-04-29 03:28:57 --> Output Class Initialized
INFO - 2021-04-29 03:28:57 --> Security Class Initialized
DEBUG - 2021-04-29 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:28:57 --> Input Class Initialized
INFO - 2021-04-29 03:28:57 --> Language Class Initialized
INFO - 2021-04-29 03:28:57 --> Language Class Initialized
INFO - 2021-04-29 03:28:57 --> Config Class Initialized
INFO - 2021-04-29 03:28:57 --> Loader Class Initialized
INFO - 2021-04-29 03:28:57 --> Helper loaded: url_helper
INFO - 2021-04-29 03:28:57 --> Helper loaded: file_helper
INFO - 2021-04-29 03:28:57 --> Helper loaded: form_helper
INFO - 2021-04-29 03:28:57 --> Helper loaded: my_helper
INFO - 2021-04-29 03:28:57 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:28:57 --> Controller Class Initialized
DEBUG - 2021-04-29 03:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:28:57 --> Final output sent to browser
DEBUG - 2021-04-29 03:28:57 --> Total execution time: 0.1475
INFO - 2021-04-29 03:29:20 --> Config Class Initialized
INFO - 2021-04-29 03:29:20 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:20 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:20 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:20 --> URI Class Initialized
DEBUG - 2021-04-29 03:29:20 --> No URI present. Default controller set.
INFO - 2021-04-29 03:29:20 --> Router Class Initialized
INFO - 2021-04-29 03:29:20 --> Output Class Initialized
INFO - 2021-04-29 03:29:20 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:20 --> Input Class Initialized
INFO - 2021-04-29 03:29:20 --> Language Class Initialized
INFO - 2021-04-29 03:29:20 --> Language Class Initialized
INFO - 2021-04-29 03:29:20 --> Config Class Initialized
INFO - 2021-04-29 03:29:20 --> Loader Class Initialized
INFO - 2021-04-29 03:29:20 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:20 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:20 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:20 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:20 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:20 --> Controller Class Initialized
INFO - 2021-04-29 03:29:20 --> Config Class Initialized
INFO - 2021-04-29 03:29:20 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:20 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:20 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:20 --> URI Class Initialized
INFO - 2021-04-29 03:29:21 --> Router Class Initialized
INFO - 2021-04-29 03:29:21 --> Output Class Initialized
INFO - 2021-04-29 03:29:21 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:21 --> Input Class Initialized
INFO - 2021-04-29 03:29:21 --> Language Class Initialized
INFO - 2021-04-29 03:29:21 --> Language Class Initialized
INFO - 2021-04-29 03:29:21 --> Config Class Initialized
INFO - 2021-04-29 03:29:21 --> Loader Class Initialized
INFO - 2021-04-29 03:29:21 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:21 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:21 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:21 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:21 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:21 --> Controller Class Initialized
DEBUG - 2021-04-29 03:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 03:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:29:21 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:21 --> Total execution time: 0.1233
INFO - 2021-04-29 03:29:26 --> Config Class Initialized
INFO - 2021-04-29 03:29:26 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:26 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:26 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:26 --> URI Class Initialized
INFO - 2021-04-29 03:29:26 --> Router Class Initialized
INFO - 2021-04-29 03:29:26 --> Output Class Initialized
INFO - 2021-04-29 03:29:26 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:26 --> Input Class Initialized
INFO - 2021-04-29 03:29:26 --> Language Class Initialized
INFO - 2021-04-29 03:29:26 --> Language Class Initialized
INFO - 2021-04-29 03:29:26 --> Config Class Initialized
INFO - 2021-04-29 03:29:26 --> Loader Class Initialized
INFO - 2021-04-29 03:29:26 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:26 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:26 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:26 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:26 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:26 --> Controller Class Initialized
INFO - 2021-04-29 03:29:26 --> Helper loaded: cookie_helper
INFO - 2021-04-29 03:29:26 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:26 --> Total execution time: 0.1253
INFO - 2021-04-29 03:29:27 --> Config Class Initialized
INFO - 2021-04-29 03:29:27 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:27 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:27 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:27 --> URI Class Initialized
INFO - 2021-04-29 03:29:27 --> Router Class Initialized
INFO - 2021-04-29 03:29:27 --> Output Class Initialized
INFO - 2021-04-29 03:29:27 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:27 --> Input Class Initialized
INFO - 2021-04-29 03:29:27 --> Language Class Initialized
INFO - 2021-04-29 03:29:27 --> Language Class Initialized
INFO - 2021-04-29 03:29:27 --> Config Class Initialized
INFO - 2021-04-29 03:29:27 --> Loader Class Initialized
INFO - 2021-04-29 03:29:27 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:27 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:27 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:27 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:27 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:27 --> Controller Class Initialized
DEBUG - 2021-04-29 03:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 03:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:29:27 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:27 --> Total execution time: 0.1901
INFO - 2021-04-29 03:29:28 --> Config Class Initialized
INFO - 2021-04-29 03:29:28 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:28 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:28 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:28 --> URI Class Initialized
INFO - 2021-04-29 03:29:28 --> Router Class Initialized
INFO - 2021-04-29 03:29:28 --> Output Class Initialized
INFO - 2021-04-29 03:29:28 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:29 --> Input Class Initialized
INFO - 2021-04-29 03:29:29 --> Language Class Initialized
INFO - 2021-04-29 03:29:29 --> Language Class Initialized
INFO - 2021-04-29 03:29:29 --> Config Class Initialized
INFO - 2021-04-29 03:29:29 --> Loader Class Initialized
INFO - 2021-04-29 03:29:29 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:29 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:29 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:29 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:29 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:29 --> Controller Class Initialized
DEBUG - 2021-04-29 03:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-29 03:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:29:29 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:29 --> Total execution time: 0.1272
INFO - 2021-04-29 03:29:29 --> Config Class Initialized
INFO - 2021-04-29 03:29:29 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:29 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:29 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:29 --> URI Class Initialized
INFO - 2021-04-29 03:29:29 --> Router Class Initialized
INFO - 2021-04-29 03:29:29 --> Output Class Initialized
INFO - 2021-04-29 03:29:29 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:29 --> Input Class Initialized
INFO - 2021-04-29 03:29:29 --> Language Class Initialized
INFO - 2021-04-29 03:29:29 --> Language Class Initialized
INFO - 2021-04-29 03:29:29 --> Config Class Initialized
INFO - 2021-04-29 03:29:29 --> Loader Class Initialized
INFO - 2021-04-29 03:29:29 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:29 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:29 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:29 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:29 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:29 --> Controller Class Initialized
INFO - 2021-04-29 03:29:33 --> Config Class Initialized
INFO - 2021-04-29 03:29:33 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:33 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:33 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:33 --> URI Class Initialized
INFO - 2021-04-29 03:29:33 --> Router Class Initialized
INFO - 2021-04-29 03:29:33 --> Output Class Initialized
INFO - 2021-04-29 03:29:33 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:33 --> Input Class Initialized
INFO - 2021-04-29 03:29:33 --> Language Class Initialized
INFO - 2021-04-29 03:29:33 --> Language Class Initialized
INFO - 2021-04-29 03:29:33 --> Config Class Initialized
INFO - 2021-04-29 03:29:33 --> Loader Class Initialized
INFO - 2021-04-29 03:29:33 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:33 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:33 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:33 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:33 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:33 --> Controller Class Initialized
INFO - 2021-04-29 03:29:33 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:33 --> Total execution time: 0.1027
INFO - 2021-04-29 03:29:36 --> Config Class Initialized
INFO - 2021-04-29 03:29:36 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:36 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:36 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:36 --> URI Class Initialized
INFO - 2021-04-29 03:29:36 --> Router Class Initialized
INFO - 2021-04-29 03:29:36 --> Output Class Initialized
INFO - 2021-04-29 03:29:36 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:36 --> Input Class Initialized
INFO - 2021-04-29 03:29:36 --> Language Class Initialized
INFO - 2021-04-29 03:29:36 --> Language Class Initialized
INFO - 2021-04-29 03:29:36 --> Config Class Initialized
INFO - 2021-04-29 03:29:36 --> Loader Class Initialized
INFO - 2021-04-29 03:29:36 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:36 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:36 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:36 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:36 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:36 --> Controller Class Initialized
INFO - 2021-04-29 03:29:36 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:36 --> Total execution time: 0.1411
INFO - 2021-04-29 03:29:36 --> Config Class Initialized
INFO - 2021-04-29 03:29:36 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:36 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:36 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:36 --> URI Class Initialized
INFO - 2021-04-29 03:29:36 --> Router Class Initialized
INFO - 2021-04-29 03:29:36 --> Output Class Initialized
INFO - 2021-04-29 03:29:36 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:36 --> Input Class Initialized
INFO - 2021-04-29 03:29:36 --> Language Class Initialized
INFO - 2021-04-29 03:29:36 --> Language Class Initialized
INFO - 2021-04-29 03:29:36 --> Config Class Initialized
INFO - 2021-04-29 03:29:36 --> Loader Class Initialized
INFO - 2021-04-29 03:29:36 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:36 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:36 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:36 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:36 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:36 --> Controller Class Initialized
INFO - 2021-04-29 03:29:51 --> Config Class Initialized
INFO - 2021-04-29 03:29:51 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:51 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:51 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:51 --> URI Class Initialized
DEBUG - 2021-04-29 03:29:51 --> No URI present. Default controller set.
INFO - 2021-04-29 03:29:51 --> Router Class Initialized
INFO - 2021-04-29 03:29:51 --> Output Class Initialized
INFO - 2021-04-29 03:29:51 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:51 --> Input Class Initialized
INFO - 2021-04-29 03:29:51 --> Language Class Initialized
INFO - 2021-04-29 03:29:51 --> Language Class Initialized
INFO - 2021-04-29 03:29:51 --> Config Class Initialized
INFO - 2021-04-29 03:29:51 --> Loader Class Initialized
INFO - 2021-04-29 03:29:51 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:51 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:51 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:51 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:51 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:51 --> Controller Class Initialized
INFO - 2021-04-29 03:29:51 --> Config Class Initialized
INFO - 2021-04-29 03:29:51 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:51 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:51 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:51 --> URI Class Initialized
INFO - 2021-04-29 03:29:51 --> Router Class Initialized
INFO - 2021-04-29 03:29:51 --> Output Class Initialized
INFO - 2021-04-29 03:29:51 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:51 --> Input Class Initialized
INFO - 2021-04-29 03:29:51 --> Language Class Initialized
INFO - 2021-04-29 03:29:51 --> Language Class Initialized
INFO - 2021-04-29 03:29:51 --> Config Class Initialized
INFO - 2021-04-29 03:29:51 --> Loader Class Initialized
INFO - 2021-04-29 03:29:51 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:51 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:51 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:51 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:51 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:51 --> Controller Class Initialized
DEBUG - 2021-04-29 03:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 03:29:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:29:52 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:52 --> Total execution time: 0.1771
INFO - 2021-04-29 03:29:56 --> Config Class Initialized
INFO - 2021-04-29 03:29:56 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:56 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:56 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:56 --> URI Class Initialized
INFO - 2021-04-29 03:29:56 --> Router Class Initialized
INFO - 2021-04-29 03:29:56 --> Output Class Initialized
INFO - 2021-04-29 03:29:56 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:56 --> Input Class Initialized
INFO - 2021-04-29 03:29:56 --> Language Class Initialized
INFO - 2021-04-29 03:29:56 --> Language Class Initialized
INFO - 2021-04-29 03:29:56 --> Config Class Initialized
INFO - 2021-04-29 03:29:56 --> Loader Class Initialized
INFO - 2021-04-29 03:29:56 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:57 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:57 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:57 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:57 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:57 --> Controller Class Initialized
INFO - 2021-04-29 03:29:57 --> Helper loaded: cookie_helper
INFO - 2021-04-29 03:29:57 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:57 --> Total execution time: 0.1183
INFO - 2021-04-29 03:29:57 --> Config Class Initialized
INFO - 2021-04-29 03:29:57 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:57 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:57 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:57 --> URI Class Initialized
INFO - 2021-04-29 03:29:57 --> Router Class Initialized
INFO - 2021-04-29 03:29:57 --> Output Class Initialized
INFO - 2021-04-29 03:29:57 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:57 --> Input Class Initialized
INFO - 2021-04-29 03:29:57 --> Language Class Initialized
INFO - 2021-04-29 03:29:57 --> Language Class Initialized
INFO - 2021-04-29 03:29:57 --> Config Class Initialized
INFO - 2021-04-29 03:29:57 --> Loader Class Initialized
INFO - 2021-04-29 03:29:57 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:57 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:57 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:57 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:57 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:57 --> Controller Class Initialized
DEBUG - 2021-04-29 03:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 03:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:29:57 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:57 --> Total execution time: 0.1622
INFO - 2021-04-29 03:29:59 --> Config Class Initialized
INFO - 2021-04-29 03:29:59 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:29:59 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:29:59 --> Utf8 Class Initialized
INFO - 2021-04-29 03:29:59 --> URI Class Initialized
INFO - 2021-04-29 03:29:59 --> Router Class Initialized
INFO - 2021-04-29 03:29:59 --> Output Class Initialized
INFO - 2021-04-29 03:29:59 --> Security Class Initialized
DEBUG - 2021-04-29 03:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:29:59 --> Input Class Initialized
INFO - 2021-04-29 03:29:59 --> Language Class Initialized
INFO - 2021-04-29 03:29:59 --> Language Class Initialized
INFO - 2021-04-29 03:29:59 --> Config Class Initialized
INFO - 2021-04-29 03:29:59 --> Loader Class Initialized
INFO - 2021-04-29 03:29:59 --> Helper loaded: url_helper
INFO - 2021-04-29 03:29:59 --> Helper loaded: file_helper
INFO - 2021-04-29 03:29:59 --> Helper loaded: form_helper
INFO - 2021-04-29 03:29:59 --> Helper loaded: my_helper
INFO - 2021-04-29 03:29:59 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:29:59 --> Controller Class Initialized
DEBUG - 2021-04-29 03:29:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-29 03:29:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:29:59 --> Final output sent to browser
DEBUG - 2021-04-29 03:29:59 --> Total execution time: 0.0940
INFO - 2021-04-29 03:30:00 --> Config Class Initialized
INFO - 2021-04-29 03:30:00 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:00 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:00 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:00 --> URI Class Initialized
INFO - 2021-04-29 03:30:00 --> Router Class Initialized
INFO - 2021-04-29 03:30:00 --> Output Class Initialized
INFO - 2021-04-29 03:30:00 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:00 --> Input Class Initialized
INFO - 2021-04-29 03:30:00 --> Language Class Initialized
INFO - 2021-04-29 03:30:00 --> Language Class Initialized
INFO - 2021-04-29 03:30:00 --> Config Class Initialized
INFO - 2021-04-29 03:30:00 --> Loader Class Initialized
INFO - 2021-04-29 03:30:00 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:00 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:00 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:00 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:00 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:00 --> Controller Class Initialized
INFO - 2021-04-29 03:30:02 --> Config Class Initialized
INFO - 2021-04-29 03:30:02 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:02 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:02 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:02 --> URI Class Initialized
INFO - 2021-04-29 03:30:02 --> Router Class Initialized
INFO - 2021-04-29 03:30:02 --> Output Class Initialized
INFO - 2021-04-29 03:30:02 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:02 --> Input Class Initialized
INFO - 2021-04-29 03:30:02 --> Language Class Initialized
INFO - 2021-04-29 03:30:02 --> Language Class Initialized
INFO - 2021-04-29 03:30:02 --> Config Class Initialized
INFO - 2021-04-29 03:30:02 --> Loader Class Initialized
INFO - 2021-04-29 03:30:02 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:02 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:02 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:02 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:02 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:02 --> Controller Class Initialized
DEBUG - 2021-04-29 03:30:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:30:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:30:02 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:02 --> Total execution time: 0.1465
INFO - 2021-04-29 03:30:23 --> Config Class Initialized
INFO - 2021-04-29 03:30:23 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:23 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:23 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:23 --> URI Class Initialized
INFO - 2021-04-29 03:30:23 --> Router Class Initialized
INFO - 2021-04-29 03:30:23 --> Output Class Initialized
INFO - 2021-04-29 03:30:23 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:23 --> Input Class Initialized
INFO - 2021-04-29 03:30:23 --> Language Class Initialized
INFO - 2021-04-29 03:30:23 --> Language Class Initialized
INFO - 2021-04-29 03:30:23 --> Config Class Initialized
INFO - 2021-04-29 03:30:23 --> Loader Class Initialized
INFO - 2021-04-29 03:30:23 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:23 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:23 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:23 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:23 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:23 --> Controller Class Initialized
INFO - 2021-04-29 03:30:23 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:23 --> Total execution time: 0.1439
INFO - 2021-04-29 03:30:26 --> Config Class Initialized
INFO - 2021-04-29 03:30:26 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:26 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:26 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:26 --> URI Class Initialized
INFO - 2021-04-29 03:30:26 --> Router Class Initialized
INFO - 2021-04-29 03:30:26 --> Output Class Initialized
INFO - 2021-04-29 03:30:26 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:26 --> Input Class Initialized
INFO - 2021-04-29 03:30:26 --> Language Class Initialized
INFO - 2021-04-29 03:30:27 --> Language Class Initialized
INFO - 2021-04-29 03:30:27 --> Config Class Initialized
INFO - 2021-04-29 03:30:27 --> Loader Class Initialized
INFO - 2021-04-29 03:30:27 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:27 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:27 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:27 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:27 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:27 --> Controller Class Initialized
INFO - 2021-04-29 03:30:27 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:27 --> Total execution time: 0.1335
INFO - 2021-04-29 03:30:27 --> Config Class Initialized
INFO - 2021-04-29 03:30:27 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:27 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:27 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:27 --> URI Class Initialized
INFO - 2021-04-29 03:30:28 --> Router Class Initialized
INFO - 2021-04-29 03:30:28 --> Output Class Initialized
INFO - 2021-04-29 03:30:28 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:28 --> Input Class Initialized
INFO - 2021-04-29 03:30:28 --> Language Class Initialized
INFO - 2021-04-29 03:30:28 --> Language Class Initialized
INFO - 2021-04-29 03:30:28 --> Config Class Initialized
INFO - 2021-04-29 03:30:28 --> Loader Class Initialized
INFO - 2021-04-29 03:30:28 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:28 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:28 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:28 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:28 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:28 --> Controller Class Initialized
DEBUG - 2021-04-29 03:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:30:28 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:28 --> Total execution time: 0.1638
INFO - 2021-04-29 03:30:29 --> Config Class Initialized
INFO - 2021-04-29 03:30:29 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:29 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:29 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:29 --> URI Class Initialized
INFO - 2021-04-29 03:30:29 --> Router Class Initialized
INFO - 2021-04-29 03:30:29 --> Output Class Initialized
INFO - 2021-04-29 03:30:29 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:29 --> Input Class Initialized
INFO - 2021-04-29 03:30:29 --> Language Class Initialized
INFO - 2021-04-29 03:30:29 --> Language Class Initialized
INFO - 2021-04-29 03:30:29 --> Config Class Initialized
INFO - 2021-04-29 03:30:29 --> Loader Class Initialized
INFO - 2021-04-29 03:30:29 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:29 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:29 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:29 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:29 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:29 --> Controller Class Initialized
DEBUG - 2021-04-29 03:30:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-29 03:30:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:30:29 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:29 --> Total execution time: 0.1291
INFO - 2021-04-29 03:30:30 --> Config Class Initialized
INFO - 2021-04-29 03:30:30 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:30 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:30 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:30 --> URI Class Initialized
INFO - 2021-04-29 03:30:30 --> Router Class Initialized
INFO - 2021-04-29 03:30:30 --> Output Class Initialized
INFO - 2021-04-29 03:30:30 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:30 --> Input Class Initialized
INFO - 2021-04-29 03:30:30 --> Language Class Initialized
INFO - 2021-04-29 03:30:30 --> Language Class Initialized
INFO - 2021-04-29 03:30:30 --> Config Class Initialized
INFO - 2021-04-29 03:30:30 --> Loader Class Initialized
INFO - 2021-04-29 03:30:30 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:30 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:30 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:30 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:30 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:31 --> Controller Class Initialized
DEBUG - 2021-04-29 03:30:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-29 03:30:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:30:31 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:31 --> Total execution time: 0.1128
INFO - 2021-04-29 03:30:31 --> Config Class Initialized
INFO - 2021-04-29 03:30:31 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:31 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:31 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:31 --> URI Class Initialized
INFO - 2021-04-29 03:30:31 --> Router Class Initialized
INFO - 2021-04-29 03:30:31 --> Output Class Initialized
INFO - 2021-04-29 03:30:31 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:31 --> Input Class Initialized
INFO - 2021-04-29 03:30:31 --> Language Class Initialized
INFO - 2021-04-29 03:30:31 --> Language Class Initialized
INFO - 2021-04-29 03:30:31 --> Config Class Initialized
INFO - 2021-04-29 03:30:31 --> Loader Class Initialized
INFO - 2021-04-29 03:30:31 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:31 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:31 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:31 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:31 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:31 --> Controller Class Initialized
INFO - 2021-04-29 03:30:33 --> Config Class Initialized
INFO - 2021-04-29 03:30:33 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:33 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:33 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:33 --> URI Class Initialized
INFO - 2021-04-29 03:30:33 --> Router Class Initialized
INFO - 2021-04-29 03:30:33 --> Output Class Initialized
INFO - 2021-04-29 03:30:33 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:33 --> Input Class Initialized
INFO - 2021-04-29 03:30:33 --> Language Class Initialized
INFO - 2021-04-29 03:30:33 --> Language Class Initialized
INFO - 2021-04-29 03:30:33 --> Config Class Initialized
INFO - 2021-04-29 03:30:33 --> Loader Class Initialized
INFO - 2021-04-29 03:30:33 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:33 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:33 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:33 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:33 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:33 --> Controller Class Initialized
DEBUG - 2021-04-29 03:30:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:30:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:30:33 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:33 --> Total execution time: 0.1601
INFO - 2021-04-29 03:30:34 --> Config Class Initialized
INFO - 2021-04-29 03:30:34 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:34 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:34 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:34 --> URI Class Initialized
INFO - 2021-04-29 03:30:34 --> Router Class Initialized
INFO - 2021-04-29 03:30:34 --> Output Class Initialized
INFO - 2021-04-29 03:30:34 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:34 --> Input Class Initialized
INFO - 2021-04-29 03:30:34 --> Language Class Initialized
INFO - 2021-04-29 03:30:34 --> Language Class Initialized
INFO - 2021-04-29 03:30:34 --> Config Class Initialized
INFO - 2021-04-29 03:30:34 --> Loader Class Initialized
INFO - 2021-04-29 03:30:34 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:34 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:34 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:34 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:34 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:34 --> Controller Class Initialized
DEBUG - 2021-04-29 03:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-29 03:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:30:34 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:34 --> Total execution time: 0.1395
INFO - 2021-04-29 03:30:39 --> Config Class Initialized
INFO - 2021-04-29 03:30:39 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:39 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:39 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:39 --> URI Class Initialized
INFO - 2021-04-29 03:30:39 --> Router Class Initialized
INFO - 2021-04-29 03:30:39 --> Output Class Initialized
INFO - 2021-04-29 03:30:39 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:39 --> Input Class Initialized
INFO - 2021-04-29 03:30:39 --> Language Class Initialized
INFO - 2021-04-29 03:30:39 --> Language Class Initialized
INFO - 2021-04-29 03:30:39 --> Config Class Initialized
INFO - 2021-04-29 03:30:39 --> Loader Class Initialized
INFO - 2021-04-29 03:30:39 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:39 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:39 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:39 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:39 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:39 --> Controller Class Initialized
INFO - 2021-04-29 03:30:39 --> Config Class Initialized
INFO - 2021-04-29 03:30:39 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:30:39 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:30:39 --> Utf8 Class Initialized
INFO - 2021-04-29 03:30:39 --> URI Class Initialized
INFO - 2021-04-29 03:30:39 --> Router Class Initialized
INFO - 2021-04-29 03:30:39 --> Output Class Initialized
INFO - 2021-04-29 03:30:39 --> Security Class Initialized
DEBUG - 2021-04-29 03:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:30:39 --> Input Class Initialized
INFO - 2021-04-29 03:30:39 --> Language Class Initialized
INFO - 2021-04-29 03:30:39 --> Language Class Initialized
INFO - 2021-04-29 03:30:39 --> Config Class Initialized
INFO - 2021-04-29 03:30:39 --> Loader Class Initialized
INFO - 2021-04-29 03:30:39 --> Helper loaded: url_helper
INFO - 2021-04-29 03:30:39 --> Helper loaded: file_helper
INFO - 2021-04-29 03:30:39 --> Helper loaded: form_helper
INFO - 2021-04-29 03:30:39 --> Helper loaded: my_helper
INFO - 2021-04-29 03:30:39 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:30:39 --> Controller Class Initialized
DEBUG - 2021-04-29 03:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 03:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:30:39 --> Final output sent to browser
DEBUG - 2021-04-29 03:30:39 --> Total execution time: 0.1350
INFO - 2021-04-29 03:33:58 --> Config Class Initialized
INFO - 2021-04-29 03:33:58 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:33:58 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:33:58 --> Utf8 Class Initialized
INFO - 2021-04-29 03:33:58 --> URI Class Initialized
DEBUG - 2021-04-29 03:33:58 --> No URI present. Default controller set.
INFO - 2021-04-29 03:33:58 --> Router Class Initialized
INFO - 2021-04-29 03:33:58 --> Output Class Initialized
INFO - 2021-04-29 03:33:58 --> Security Class Initialized
DEBUG - 2021-04-29 03:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:33:58 --> Input Class Initialized
INFO - 2021-04-29 03:33:58 --> Language Class Initialized
INFO - 2021-04-29 03:33:58 --> Language Class Initialized
INFO - 2021-04-29 03:33:58 --> Config Class Initialized
INFO - 2021-04-29 03:33:58 --> Loader Class Initialized
INFO - 2021-04-29 03:33:58 --> Helper loaded: url_helper
INFO - 2021-04-29 03:33:58 --> Helper loaded: file_helper
INFO - 2021-04-29 03:33:58 --> Helper loaded: form_helper
INFO - 2021-04-29 03:33:58 --> Helper loaded: my_helper
INFO - 2021-04-29 03:33:58 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:33:58 --> Controller Class Initialized
DEBUG - 2021-04-29 03:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 03:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:33:58 --> Final output sent to browser
DEBUG - 2021-04-29 03:33:58 --> Total execution time: 0.1392
INFO - 2021-04-29 03:34:01 --> Config Class Initialized
INFO - 2021-04-29 03:34:01 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:34:01 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:34:01 --> Utf8 Class Initialized
INFO - 2021-04-29 03:34:01 --> URI Class Initialized
INFO - 2021-04-29 03:34:01 --> Router Class Initialized
INFO - 2021-04-29 03:34:01 --> Output Class Initialized
INFO - 2021-04-29 03:34:01 --> Security Class Initialized
DEBUG - 2021-04-29 03:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:34:01 --> Input Class Initialized
INFO - 2021-04-29 03:34:01 --> Language Class Initialized
INFO - 2021-04-29 03:34:01 --> Language Class Initialized
INFO - 2021-04-29 03:34:01 --> Config Class Initialized
INFO - 2021-04-29 03:34:01 --> Loader Class Initialized
INFO - 2021-04-29 03:34:01 --> Helper loaded: url_helper
INFO - 2021-04-29 03:34:01 --> Helper loaded: file_helper
INFO - 2021-04-29 03:34:01 --> Helper loaded: form_helper
INFO - 2021-04-29 03:34:01 --> Helper loaded: my_helper
INFO - 2021-04-29 03:34:01 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:34:01 --> Controller Class Initialized
DEBUG - 2021-04-29 03:34:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-29 03:34:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 03:34:01 --> Final output sent to browser
DEBUG - 2021-04-29 03:34:01 --> Total execution time: 0.1475
INFO - 2021-04-29 03:34:01 --> Config Class Initialized
INFO - 2021-04-29 03:34:01 --> Hooks Class Initialized
DEBUG - 2021-04-29 03:34:01 --> UTF-8 Support Enabled
INFO - 2021-04-29 03:34:01 --> Utf8 Class Initialized
INFO - 2021-04-29 03:34:01 --> URI Class Initialized
INFO - 2021-04-29 03:34:02 --> Router Class Initialized
INFO - 2021-04-29 03:34:02 --> Output Class Initialized
INFO - 2021-04-29 03:34:02 --> Security Class Initialized
DEBUG - 2021-04-29 03:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 03:34:02 --> Input Class Initialized
INFO - 2021-04-29 03:34:02 --> Language Class Initialized
INFO - 2021-04-29 03:34:02 --> Language Class Initialized
INFO - 2021-04-29 03:34:02 --> Config Class Initialized
INFO - 2021-04-29 03:34:02 --> Loader Class Initialized
INFO - 2021-04-29 03:34:02 --> Helper loaded: url_helper
INFO - 2021-04-29 03:34:02 --> Helper loaded: file_helper
INFO - 2021-04-29 03:34:02 --> Helper loaded: form_helper
INFO - 2021-04-29 03:34:02 --> Helper loaded: my_helper
INFO - 2021-04-29 03:34:02 --> Database Driver Class Initialized
DEBUG - 2021-04-29 03:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 03:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 03:34:02 --> Controller Class Initialized
INFO - 2021-04-29 04:16:46 --> Config Class Initialized
INFO - 2021-04-29 04:16:46 --> Hooks Class Initialized
DEBUG - 2021-04-29 04:16:46 --> UTF-8 Support Enabled
INFO - 2021-04-29 04:16:46 --> Utf8 Class Initialized
INFO - 2021-04-29 04:16:46 --> URI Class Initialized
DEBUG - 2021-04-29 04:16:46 --> No URI present. Default controller set.
INFO - 2021-04-29 04:16:46 --> Router Class Initialized
INFO - 2021-04-29 04:16:46 --> Output Class Initialized
INFO - 2021-04-29 04:16:46 --> Security Class Initialized
DEBUG - 2021-04-29 04:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 04:16:46 --> Input Class Initialized
INFO - 2021-04-29 04:16:46 --> Language Class Initialized
INFO - 2021-04-29 04:16:46 --> Language Class Initialized
INFO - 2021-04-29 04:16:46 --> Config Class Initialized
INFO - 2021-04-29 04:16:46 --> Loader Class Initialized
INFO - 2021-04-29 04:16:46 --> Helper loaded: url_helper
INFO - 2021-04-29 04:16:46 --> Helper loaded: file_helper
INFO - 2021-04-29 04:16:46 --> Helper loaded: form_helper
INFO - 2021-04-29 04:16:46 --> Helper loaded: my_helper
INFO - 2021-04-29 04:16:46 --> Database Driver Class Initialized
ERROR - 2021-04-29 04:16:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\nilai\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-04-29 04:16:50 --> Unable to connect to the database
INFO - 2021-04-29 04:16:50 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-29 04:17:10 --> Config Class Initialized
INFO - 2021-04-29 04:17:10 --> Hooks Class Initialized
DEBUG - 2021-04-29 04:17:10 --> UTF-8 Support Enabled
INFO - 2021-04-29 04:17:10 --> Utf8 Class Initialized
INFO - 2021-04-29 04:17:10 --> URI Class Initialized
DEBUG - 2021-04-29 04:17:10 --> No URI present. Default controller set.
INFO - 2021-04-29 04:17:10 --> Router Class Initialized
INFO - 2021-04-29 04:17:10 --> Output Class Initialized
INFO - 2021-04-29 04:17:10 --> Security Class Initialized
DEBUG - 2021-04-29 04:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 04:17:10 --> Input Class Initialized
INFO - 2021-04-29 04:17:10 --> Language Class Initialized
INFO - 2021-04-29 04:17:10 --> Language Class Initialized
INFO - 2021-04-29 04:17:10 --> Config Class Initialized
INFO - 2021-04-29 04:17:10 --> Loader Class Initialized
INFO - 2021-04-29 04:17:10 --> Helper loaded: url_helper
INFO - 2021-04-29 04:17:10 --> Helper loaded: file_helper
INFO - 2021-04-29 04:17:10 --> Helper loaded: form_helper
INFO - 2021-04-29 04:17:10 --> Helper loaded: my_helper
INFO - 2021-04-29 04:17:10 --> Database Driver Class Initialized
DEBUG - 2021-04-29 04:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 04:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 04:17:10 --> Controller Class Initialized
INFO - 2021-04-29 04:17:10 --> Config Class Initialized
INFO - 2021-04-29 04:17:10 --> Hooks Class Initialized
DEBUG - 2021-04-29 04:17:10 --> UTF-8 Support Enabled
INFO - 2021-04-29 04:17:10 --> Utf8 Class Initialized
INFO - 2021-04-29 04:17:10 --> URI Class Initialized
INFO - 2021-04-29 04:17:10 --> Router Class Initialized
INFO - 2021-04-29 04:17:10 --> Output Class Initialized
INFO - 2021-04-29 04:17:10 --> Security Class Initialized
DEBUG - 2021-04-29 04:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 04:17:10 --> Input Class Initialized
INFO - 2021-04-29 04:17:10 --> Language Class Initialized
INFO - 2021-04-29 04:17:10 --> Language Class Initialized
INFO - 2021-04-29 04:17:10 --> Config Class Initialized
INFO - 2021-04-29 04:17:10 --> Loader Class Initialized
INFO - 2021-04-29 04:17:10 --> Helper loaded: url_helper
INFO - 2021-04-29 04:17:10 --> Helper loaded: file_helper
INFO - 2021-04-29 04:17:10 --> Helper loaded: form_helper
INFO - 2021-04-29 04:17:10 --> Helper loaded: my_helper
INFO - 2021-04-29 04:17:10 --> Database Driver Class Initialized
DEBUG - 2021-04-29 04:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 04:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 04:17:10 --> Controller Class Initialized
DEBUG - 2021-04-29 04:17:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 04:17:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 04:17:10 --> Final output sent to browser
DEBUG - 2021-04-29 04:17:10 --> Total execution time: 0.0541
INFO - 2021-04-29 04:17:38 --> Config Class Initialized
INFO - 2021-04-29 04:17:38 --> Hooks Class Initialized
DEBUG - 2021-04-29 04:17:38 --> UTF-8 Support Enabled
INFO - 2021-04-29 04:17:38 --> Utf8 Class Initialized
INFO - 2021-04-29 04:17:38 --> URI Class Initialized
INFO - 2021-04-29 04:17:38 --> Router Class Initialized
INFO - 2021-04-29 04:17:38 --> Output Class Initialized
INFO - 2021-04-29 04:17:38 --> Security Class Initialized
DEBUG - 2021-04-29 04:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 04:17:38 --> Input Class Initialized
INFO - 2021-04-29 04:17:38 --> Language Class Initialized
INFO - 2021-04-29 04:17:38 --> Language Class Initialized
INFO - 2021-04-29 04:17:38 --> Config Class Initialized
INFO - 2021-04-29 04:17:38 --> Loader Class Initialized
INFO - 2021-04-29 04:17:38 --> Helper loaded: url_helper
INFO - 2021-04-29 04:17:38 --> Helper loaded: file_helper
INFO - 2021-04-29 04:17:38 --> Helper loaded: form_helper
INFO - 2021-04-29 04:17:38 --> Helper loaded: my_helper
INFO - 2021-04-29 04:17:38 --> Database Driver Class Initialized
DEBUG - 2021-04-29 04:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 04:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 04:17:38 --> Controller Class Initialized
INFO - 2021-04-29 04:17:38 --> Helper loaded: cookie_helper
INFO - 2021-04-29 04:17:38 --> Final output sent to browser
DEBUG - 2021-04-29 04:17:38 --> Total execution time: 0.0863
INFO - 2021-04-29 04:17:39 --> Config Class Initialized
INFO - 2021-04-29 04:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-29 04:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-29 04:17:39 --> Utf8 Class Initialized
INFO - 2021-04-29 04:17:39 --> URI Class Initialized
INFO - 2021-04-29 04:17:39 --> Router Class Initialized
INFO - 2021-04-29 04:17:39 --> Output Class Initialized
INFO - 2021-04-29 04:17:39 --> Security Class Initialized
DEBUG - 2021-04-29 04:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 04:17:39 --> Input Class Initialized
INFO - 2021-04-29 04:17:39 --> Language Class Initialized
INFO - 2021-04-29 04:17:39 --> Language Class Initialized
INFO - 2021-04-29 04:17:39 --> Config Class Initialized
INFO - 2021-04-29 04:17:39 --> Loader Class Initialized
INFO - 2021-04-29 04:17:39 --> Helper loaded: url_helper
INFO - 2021-04-29 04:17:39 --> Helper loaded: file_helper
INFO - 2021-04-29 04:17:39 --> Helper loaded: form_helper
INFO - 2021-04-29 04:17:39 --> Helper loaded: my_helper
INFO - 2021-04-29 04:17:39 --> Database Driver Class Initialized
DEBUG - 2021-04-29 04:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 04:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 04:17:39 --> Controller Class Initialized
DEBUG - 2021-04-29 04:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 04:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 04:17:39 --> Final output sent to browser
DEBUG - 2021-04-29 04:17:39 --> Total execution time: 0.0727
INFO - 2021-04-29 04:17:41 --> Config Class Initialized
INFO - 2021-04-29 04:17:41 --> Hooks Class Initialized
DEBUG - 2021-04-29 04:17:41 --> UTF-8 Support Enabled
INFO - 2021-04-29 04:17:41 --> Utf8 Class Initialized
INFO - 2021-04-29 04:17:41 --> URI Class Initialized
INFO - 2021-04-29 04:17:41 --> Router Class Initialized
INFO - 2021-04-29 04:17:41 --> Output Class Initialized
INFO - 2021-04-29 04:17:41 --> Security Class Initialized
DEBUG - 2021-04-29 04:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 04:17:41 --> Input Class Initialized
INFO - 2021-04-29 04:17:41 --> Language Class Initialized
INFO - 2021-04-29 04:17:41 --> Language Class Initialized
INFO - 2021-04-29 04:17:41 --> Config Class Initialized
INFO - 2021-04-29 04:17:41 --> Loader Class Initialized
INFO - 2021-04-29 04:17:41 --> Helper loaded: url_helper
INFO - 2021-04-29 04:17:41 --> Helper loaded: file_helper
INFO - 2021-04-29 04:17:41 --> Helper loaded: form_helper
INFO - 2021-04-29 04:17:41 --> Helper loaded: my_helper
INFO - 2021-04-29 04:17:41 --> Database Driver Class Initialized
DEBUG - 2021-04-29 04:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 04:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 04:17:41 --> Controller Class Initialized
DEBUG - 2021-04-29 04:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 04:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 04:17:41 --> Final output sent to browser
DEBUG - 2021-04-29 04:17:41 --> Total execution time: 0.0971
INFO - 2021-04-29 05:49:24 --> Config Class Initialized
INFO - 2021-04-29 05:49:24 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:49:24 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:49:24 --> Utf8 Class Initialized
INFO - 2021-04-29 05:49:24 --> URI Class Initialized
DEBUG - 2021-04-29 05:49:24 --> No URI present. Default controller set.
INFO - 2021-04-29 05:49:24 --> Router Class Initialized
INFO - 2021-04-29 05:49:24 --> Output Class Initialized
INFO - 2021-04-29 05:49:24 --> Security Class Initialized
DEBUG - 2021-04-29 05:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:49:24 --> Input Class Initialized
INFO - 2021-04-29 05:49:24 --> Language Class Initialized
INFO - 2021-04-29 05:49:24 --> Language Class Initialized
INFO - 2021-04-29 05:49:24 --> Config Class Initialized
INFO - 2021-04-29 05:49:24 --> Loader Class Initialized
INFO - 2021-04-29 05:49:24 --> Helper loaded: url_helper
INFO - 2021-04-29 05:49:24 --> Helper loaded: file_helper
INFO - 2021-04-29 05:49:24 --> Helper loaded: form_helper
INFO - 2021-04-29 05:49:24 --> Helper loaded: my_helper
INFO - 2021-04-29 05:49:24 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:49:24 --> Controller Class Initialized
INFO - 2021-04-29 05:49:24 --> Config Class Initialized
INFO - 2021-04-29 05:49:24 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:49:24 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:49:24 --> Utf8 Class Initialized
INFO - 2021-04-29 05:49:24 --> URI Class Initialized
INFO - 2021-04-29 05:49:24 --> Router Class Initialized
INFO - 2021-04-29 05:49:24 --> Output Class Initialized
INFO - 2021-04-29 05:49:24 --> Security Class Initialized
DEBUG - 2021-04-29 05:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:49:24 --> Input Class Initialized
INFO - 2021-04-29 05:49:24 --> Language Class Initialized
INFO - 2021-04-29 05:49:24 --> Language Class Initialized
INFO - 2021-04-29 05:49:24 --> Config Class Initialized
INFO - 2021-04-29 05:49:24 --> Loader Class Initialized
INFO - 2021-04-29 05:49:24 --> Helper loaded: url_helper
INFO - 2021-04-29 05:49:24 --> Helper loaded: file_helper
INFO - 2021-04-29 05:49:24 --> Helper loaded: form_helper
INFO - 2021-04-29 05:49:24 --> Helper loaded: my_helper
INFO - 2021-04-29 05:49:24 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:49:24 --> Controller Class Initialized
DEBUG - 2021-04-29 05:49:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 05:49:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:49:24 --> Final output sent to browser
DEBUG - 2021-04-29 05:49:24 --> Total execution time: 0.0816
INFO - 2021-04-29 05:49:40 --> Config Class Initialized
INFO - 2021-04-29 05:49:40 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:49:40 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:49:40 --> Utf8 Class Initialized
INFO - 2021-04-29 05:49:40 --> URI Class Initialized
INFO - 2021-04-29 05:49:40 --> Router Class Initialized
INFO - 2021-04-29 05:49:40 --> Output Class Initialized
INFO - 2021-04-29 05:49:40 --> Security Class Initialized
DEBUG - 2021-04-29 05:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:49:40 --> Input Class Initialized
INFO - 2021-04-29 05:49:40 --> Language Class Initialized
INFO - 2021-04-29 05:49:40 --> Language Class Initialized
INFO - 2021-04-29 05:49:40 --> Config Class Initialized
INFO - 2021-04-29 05:49:40 --> Loader Class Initialized
INFO - 2021-04-29 05:49:40 --> Helper loaded: url_helper
INFO - 2021-04-29 05:49:40 --> Helper loaded: file_helper
INFO - 2021-04-29 05:49:40 --> Helper loaded: form_helper
INFO - 2021-04-29 05:49:40 --> Helper loaded: my_helper
INFO - 2021-04-29 05:49:40 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:49:40 --> Controller Class Initialized
INFO - 2021-04-29 05:49:40 --> Helper loaded: cookie_helper
INFO - 2021-04-29 05:49:40 --> Final output sent to browser
DEBUG - 2021-04-29 05:49:40 --> Total execution time: 0.0924
INFO - 2021-04-29 05:49:45 --> Config Class Initialized
INFO - 2021-04-29 05:49:45 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:49:45 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:49:45 --> Utf8 Class Initialized
INFO - 2021-04-29 05:49:45 --> URI Class Initialized
INFO - 2021-04-29 05:49:45 --> Router Class Initialized
INFO - 2021-04-29 05:49:45 --> Output Class Initialized
INFO - 2021-04-29 05:49:45 --> Security Class Initialized
DEBUG - 2021-04-29 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:49:45 --> Input Class Initialized
INFO - 2021-04-29 05:49:45 --> Language Class Initialized
INFO - 2021-04-29 05:49:45 --> Language Class Initialized
INFO - 2021-04-29 05:49:45 --> Config Class Initialized
INFO - 2021-04-29 05:49:45 --> Loader Class Initialized
INFO - 2021-04-29 05:49:45 --> Helper loaded: url_helper
INFO - 2021-04-29 05:49:45 --> Helper loaded: file_helper
INFO - 2021-04-29 05:49:45 --> Helper loaded: form_helper
INFO - 2021-04-29 05:49:45 --> Helper loaded: my_helper
INFO - 2021-04-29 05:49:45 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:49:45 --> Controller Class Initialized
DEBUG - 2021-04-29 05:49:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 05:49:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:49:45 --> Final output sent to browser
DEBUG - 2021-04-29 05:49:45 --> Total execution time: 0.0811
INFO - 2021-04-29 05:49:50 --> Config Class Initialized
INFO - 2021-04-29 05:49:50 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:49:50 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:49:50 --> Utf8 Class Initialized
INFO - 2021-04-29 05:49:50 --> URI Class Initialized
INFO - 2021-04-29 05:49:50 --> Router Class Initialized
INFO - 2021-04-29 05:49:50 --> Output Class Initialized
INFO - 2021-04-29 05:49:50 --> Security Class Initialized
DEBUG - 2021-04-29 05:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:49:50 --> Input Class Initialized
INFO - 2021-04-29 05:49:50 --> Language Class Initialized
INFO - 2021-04-29 05:49:50 --> Language Class Initialized
INFO - 2021-04-29 05:49:50 --> Config Class Initialized
INFO - 2021-04-29 05:49:50 --> Loader Class Initialized
INFO - 2021-04-29 05:49:51 --> Helper loaded: url_helper
INFO - 2021-04-29 05:49:51 --> Helper loaded: file_helper
INFO - 2021-04-29 05:49:51 --> Helper loaded: form_helper
INFO - 2021-04-29 05:49:51 --> Helper loaded: my_helper
INFO - 2021-04-29 05:49:51 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:49:51 --> Controller Class Initialized
DEBUG - 2021-04-29 05:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-29 05:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:49:51 --> Final output sent to browser
DEBUG - 2021-04-29 05:49:51 --> Total execution time: 0.1075
INFO - 2021-04-29 05:49:55 --> Config Class Initialized
INFO - 2021-04-29 05:49:55 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:49:55 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:49:55 --> Utf8 Class Initialized
INFO - 2021-04-29 05:49:55 --> URI Class Initialized
INFO - 2021-04-29 05:49:55 --> Router Class Initialized
INFO - 2021-04-29 05:49:55 --> Output Class Initialized
INFO - 2021-04-29 05:49:55 --> Security Class Initialized
DEBUG - 2021-04-29 05:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:49:55 --> Input Class Initialized
INFO - 2021-04-29 05:49:55 --> Language Class Initialized
INFO - 2021-04-29 05:49:55 --> Language Class Initialized
INFO - 2021-04-29 05:49:55 --> Config Class Initialized
INFO - 2021-04-29 05:49:55 --> Loader Class Initialized
INFO - 2021-04-29 05:49:55 --> Helper loaded: url_helper
INFO - 2021-04-29 05:49:55 --> Helper loaded: file_helper
INFO - 2021-04-29 05:49:55 --> Helper loaded: form_helper
INFO - 2021-04-29 05:49:55 --> Helper loaded: my_helper
INFO - 2021-04-29 05:49:55 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:49:55 --> Controller Class Initialized
DEBUG - 2021-04-29 05:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-29 05:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:49:55 --> Final output sent to browser
DEBUG - 2021-04-29 05:49:55 --> Total execution time: 0.0699
INFO - 2021-04-29 05:49:56 --> Config Class Initialized
INFO - 2021-04-29 05:49:56 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:49:56 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:49:56 --> Utf8 Class Initialized
INFO - 2021-04-29 05:49:56 --> URI Class Initialized
INFO - 2021-04-29 05:49:56 --> Router Class Initialized
INFO - 2021-04-29 05:49:56 --> Output Class Initialized
INFO - 2021-04-29 05:49:56 --> Security Class Initialized
DEBUG - 2021-04-29 05:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:49:56 --> Input Class Initialized
INFO - 2021-04-29 05:49:56 --> Language Class Initialized
INFO - 2021-04-29 05:49:56 --> Language Class Initialized
INFO - 2021-04-29 05:49:56 --> Config Class Initialized
INFO - 2021-04-29 05:49:56 --> Loader Class Initialized
INFO - 2021-04-29 05:49:56 --> Helper loaded: url_helper
INFO - 2021-04-29 05:49:56 --> Helper loaded: file_helper
INFO - 2021-04-29 05:49:56 --> Helper loaded: form_helper
INFO - 2021-04-29 05:49:56 --> Helper loaded: my_helper
INFO - 2021-04-29 05:49:56 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:49:56 --> Controller Class Initialized
INFO - 2021-04-29 05:50:03 --> Config Class Initialized
INFO - 2021-04-29 05:50:03 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:50:03 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:50:03 --> Utf8 Class Initialized
INFO - 2021-04-29 05:50:03 --> URI Class Initialized
INFO - 2021-04-29 05:50:03 --> Router Class Initialized
INFO - 2021-04-29 05:50:03 --> Output Class Initialized
INFO - 2021-04-29 05:50:03 --> Security Class Initialized
DEBUG - 2021-04-29 05:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:50:03 --> Input Class Initialized
INFO - 2021-04-29 05:50:03 --> Language Class Initialized
INFO - 2021-04-29 05:50:03 --> Language Class Initialized
INFO - 2021-04-29 05:50:03 --> Config Class Initialized
INFO - 2021-04-29 05:50:03 --> Loader Class Initialized
INFO - 2021-04-29 05:50:03 --> Helper loaded: url_helper
INFO - 2021-04-29 05:50:03 --> Helper loaded: file_helper
INFO - 2021-04-29 05:50:03 --> Helper loaded: form_helper
INFO - 2021-04-29 05:50:03 --> Helper loaded: my_helper
INFO - 2021-04-29 05:50:03 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:50:03 --> Controller Class Initialized
INFO - 2021-04-29 05:50:03 --> Final output sent to browser
DEBUG - 2021-04-29 05:50:03 --> Total execution time: 0.0995
INFO - 2021-04-29 05:50:03 --> Config Class Initialized
INFO - 2021-04-29 05:50:03 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:50:03 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:50:03 --> Utf8 Class Initialized
INFO - 2021-04-29 05:50:03 --> URI Class Initialized
INFO - 2021-04-29 05:50:03 --> Router Class Initialized
INFO - 2021-04-29 05:50:03 --> Output Class Initialized
INFO - 2021-04-29 05:50:03 --> Security Class Initialized
DEBUG - 2021-04-29 05:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:50:03 --> Input Class Initialized
INFO - 2021-04-29 05:50:03 --> Language Class Initialized
INFO - 2021-04-29 05:50:03 --> Language Class Initialized
INFO - 2021-04-29 05:50:03 --> Config Class Initialized
INFO - 2021-04-29 05:50:03 --> Loader Class Initialized
INFO - 2021-04-29 05:50:03 --> Helper loaded: url_helper
INFO - 2021-04-29 05:50:03 --> Helper loaded: file_helper
INFO - 2021-04-29 05:50:03 --> Helper loaded: form_helper
INFO - 2021-04-29 05:50:03 --> Helper loaded: my_helper
INFO - 2021-04-29 05:50:03 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:50:03 --> Controller Class Initialized
INFO - 2021-04-29 05:50:05 --> Config Class Initialized
INFO - 2021-04-29 05:50:05 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:50:05 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:50:05 --> Utf8 Class Initialized
INFO - 2021-04-29 05:50:05 --> URI Class Initialized
INFO - 2021-04-29 05:50:05 --> Router Class Initialized
INFO - 2021-04-29 05:50:05 --> Output Class Initialized
INFO - 2021-04-29 05:50:05 --> Security Class Initialized
DEBUG - 2021-04-29 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:50:05 --> Input Class Initialized
INFO - 2021-04-29 05:50:05 --> Language Class Initialized
INFO - 2021-04-29 05:50:05 --> Language Class Initialized
INFO - 2021-04-29 05:50:05 --> Config Class Initialized
INFO - 2021-04-29 05:50:05 --> Loader Class Initialized
INFO - 2021-04-29 05:50:05 --> Helper loaded: url_helper
INFO - 2021-04-29 05:50:05 --> Helper loaded: file_helper
INFO - 2021-04-29 05:50:05 --> Helper loaded: form_helper
INFO - 2021-04-29 05:50:05 --> Helper loaded: my_helper
INFO - 2021-04-29 05:50:05 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:50:05 --> Controller Class Initialized
DEBUG - 2021-04-29 05:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-04-29 05:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:50:05 --> Final output sent to browser
DEBUG - 2021-04-29 05:50:05 --> Total execution time: 0.0944
INFO - 2021-04-29 05:51:04 --> Config Class Initialized
INFO - 2021-04-29 05:51:04 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:04 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:04 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:04 --> URI Class Initialized
INFO - 2021-04-29 05:51:04 --> Router Class Initialized
INFO - 2021-04-29 05:51:04 --> Output Class Initialized
INFO - 2021-04-29 05:51:04 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:04 --> Input Class Initialized
INFO - 2021-04-29 05:51:04 --> Language Class Initialized
INFO - 2021-04-29 05:51:04 --> Language Class Initialized
INFO - 2021-04-29 05:51:04 --> Config Class Initialized
INFO - 2021-04-29 05:51:04 --> Loader Class Initialized
INFO - 2021-04-29 05:51:04 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:04 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:04 --> Controller Class Initialized
INFO - 2021-04-29 05:51:04 --> Config Class Initialized
INFO - 2021-04-29 05:51:04 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:04 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:04 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:04 --> URI Class Initialized
INFO - 2021-04-29 05:51:04 --> Router Class Initialized
INFO - 2021-04-29 05:51:04 --> Output Class Initialized
INFO - 2021-04-29 05:51:04 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:04 --> Input Class Initialized
INFO - 2021-04-29 05:51:04 --> Language Class Initialized
INFO - 2021-04-29 05:51:04 --> Language Class Initialized
INFO - 2021-04-29 05:51:04 --> Config Class Initialized
INFO - 2021-04-29 05:51:04 --> Loader Class Initialized
INFO - 2021-04-29 05:51:04 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:04 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:04 --> Controller Class Initialized
DEBUG - 2021-04-29 05:51:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-29 05:51:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:51:04 --> Final output sent to browser
DEBUG - 2021-04-29 05:51:04 --> Total execution time: 0.1440
INFO - 2021-04-29 05:51:04 --> Config Class Initialized
INFO - 2021-04-29 05:51:04 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:04 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:04 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:04 --> URI Class Initialized
INFO - 2021-04-29 05:51:04 --> Router Class Initialized
INFO - 2021-04-29 05:51:04 --> Output Class Initialized
INFO - 2021-04-29 05:51:04 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:04 --> Input Class Initialized
INFO - 2021-04-29 05:51:04 --> Language Class Initialized
INFO - 2021-04-29 05:51:04 --> Language Class Initialized
INFO - 2021-04-29 05:51:04 --> Config Class Initialized
INFO - 2021-04-29 05:51:04 --> Loader Class Initialized
INFO - 2021-04-29 05:51:04 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:04 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:04 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:04 --> Controller Class Initialized
INFO - 2021-04-29 05:51:11 --> Config Class Initialized
INFO - 2021-04-29 05:51:11 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:11 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:11 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:11 --> URI Class Initialized
INFO - 2021-04-29 05:51:11 --> Router Class Initialized
INFO - 2021-04-29 05:51:11 --> Output Class Initialized
INFO - 2021-04-29 05:51:11 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:11 --> Input Class Initialized
INFO - 2021-04-29 05:51:11 --> Language Class Initialized
INFO - 2021-04-29 05:51:11 --> Language Class Initialized
INFO - 2021-04-29 05:51:11 --> Config Class Initialized
INFO - 2021-04-29 05:51:11 --> Loader Class Initialized
INFO - 2021-04-29 05:51:11 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:11 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:11 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:11 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:11 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:11 --> Controller Class Initialized
DEBUG - 2021-04-29 05:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-04-29 05:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:51:11 --> Final output sent to browser
DEBUG - 2021-04-29 05:51:11 --> Total execution time: 0.1521
INFO - 2021-04-29 05:51:26 --> Config Class Initialized
INFO - 2021-04-29 05:51:26 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:26 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:26 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:26 --> URI Class Initialized
INFO - 2021-04-29 05:51:26 --> Router Class Initialized
INFO - 2021-04-29 05:51:26 --> Output Class Initialized
INFO - 2021-04-29 05:51:26 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:26 --> Input Class Initialized
INFO - 2021-04-29 05:51:26 --> Language Class Initialized
INFO - 2021-04-29 05:51:26 --> Language Class Initialized
INFO - 2021-04-29 05:51:26 --> Config Class Initialized
INFO - 2021-04-29 05:51:26 --> Loader Class Initialized
INFO - 2021-04-29 05:51:26 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:26 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:26 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:26 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:26 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:26 --> Controller Class Initialized
INFO - 2021-04-29 05:51:26 --> Config Class Initialized
INFO - 2021-04-29 05:51:26 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:26 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:26 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:26 --> URI Class Initialized
INFO - 2021-04-29 05:51:26 --> Router Class Initialized
INFO - 2021-04-29 05:51:26 --> Output Class Initialized
INFO - 2021-04-29 05:51:26 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:26 --> Input Class Initialized
INFO - 2021-04-29 05:51:26 --> Language Class Initialized
INFO - 2021-04-29 05:51:26 --> Language Class Initialized
INFO - 2021-04-29 05:51:26 --> Config Class Initialized
INFO - 2021-04-29 05:51:26 --> Loader Class Initialized
INFO - 2021-04-29 05:51:26 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:26 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:26 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:26 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:26 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:26 --> Controller Class Initialized
DEBUG - 2021-04-29 05:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-29 05:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:51:26 --> Final output sent to browser
DEBUG - 2021-04-29 05:51:26 --> Total execution time: 0.1617
INFO - 2021-04-29 05:51:27 --> Config Class Initialized
INFO - 2021-04-29 05:51:27 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:27 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:27 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:27 --> URI Class Initialized
INFO - 2021-04-29 05:51:27 --> Router Class Initialized
INFO - 2021-04-29 05:51:27 --> Output Class Initialized
INFO - 2021-04-29 05:51:27 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:27 --> Input Class Initialized
INFO - 2021-04-29 05:51:27 --> Language Class Initialized
INFO - 2021-04-29 05:51:27 --> Language Class Initialized
INFO - 2021-04-29 05:51:27 --> Config Class Initialized
INFO - 2021-04-29 05:51:27 --> Loader Class Initialized
INFO - 2021-04-29 05:51:27 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:27 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:27 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:27 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:27 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:27 --> Controller Class Initialized
INFO - 2021-04-29 05:51:34 --> Config Class Initialized
INFO - 2021-04-29 05:51:34 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:34 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:34 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:34 --> URI Class Initialized
INFO - 2021-04-29 05:51:34 --> Router Class Initialized
INFO - 2021-04-29 05:51:34 --> Output Class Initialized
INFO - 2021-04-29 05:51:34 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:34 --> Input Class Initialized
INFO - 2021-04-29 05:51:34 --> Language Class Initialized
INFO - 2021-04-29 05:51:34 --> Language Class Initialized
INFO - 2021-04-29 05:51:34 --> Config Class Initialized
INFO - 2021-04-29 05:51:34 --> Loader Class Initialized
INFO - 2021-04-29 05:51:34 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:34 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:34 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:34 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:34 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:34 --> Controller Class Initialized
DEBUG - 2021-04-29 05:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-29 05:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:51:34 --> Final output sent to browser
DEBUG - 2021-04-29 05:51:34 --> Total execution time: 0.1291
INFO - 2021-04-29 05:51:35 --> Config Class Initialized
INFO - 2021-04-29 05:51:35 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:35 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:35 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:35 --> URI Class Initialized
INFO - 2021-04-29 05:51:35 --> Router Class Initialized
INFO - 2021-04-29 05:51:35 --> Output Class Initialized
INFO - 2021-04-29 05:51:35 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:35 --> Input Class Initialized
INFO - 2021-04-29 05:51:35 --> Language Class Initialized
INFO - 2021-04-29 05:51:35 --> Language Class Initialized
INFO - 2021-04-29 05:51:35 --> Config Class Initialized
INFO - 2021-04-29 05:51:35 --> Loader Class Initialized
INFO - 2021-04-29 05:51:35 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:35 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:35 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:35 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:35 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:35 --> Controller Class Initialized
INFO - 2021-04-29 05:51:41 --> Config Class Initialized
INFO - 2021-04-29 05:51:41 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:41 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:41 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:41 --> URI Class Initialized
INFO - 2021-04-29 05:51:41 --> Router Class Initialized
INFO - 2021-04-29 05:51:41 --> Output Class Initialized
INFO - 2021-04-29 05:51:41 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:41 --> Input Class Initialized
INFO - 2021-04-29 05:51:41 --> Language Class Initialized
INFO - 2021-04-29 05:51:41 --> Language Class Initialized
INFO - 2021-04-29 05:51:41 --> Config Class Initialized
INFO - 2021-04-29 05:51:41 --> Loader Class Initialized
INFO - 2021-04-29 05:51:41 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:41 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:41 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:41 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:41 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:41 --> Controller Class Initialized
INFO - 2021-04-29 05:51:41 --> Final output sent to browser
DEBUG - 2021-04-29 05:51:41 --> Total execution time: 0.1446
INFO - 2021-04-29 05:51:42 --> Config Class Initialized
INFO - 2021-04-29 05:51:42 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:42 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:42 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:42 --> URI Class Initialized
INFO - 2021-04-29 05:51:42 --> Router Class Initialized
INFO - 2021-04-29 05:51:42 --> Output Class Initialized
INFO - 2021-04-29 05:51:42 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:42 --> Input Class Initialized
INFO - 2021-04-29 05:51:42 --> Language Class Initialized
INFO - 2021-04-29 05:51:42 --> Language Class Initialized
INFO - 2021-04-29 05:51:42 --> Config Class Initialized
INFO - 2021-04-29 05:51:42 --> Loader Class Initialized
INFO - 2021-04-29 05:51:42 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:42 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:42 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:42 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:42 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:42 --> Controller Class Initialized
INFO - 2021-04-29 05:51:43 --> Config Class Initialized
INFO - 2021-04-29 05:51:43 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:43 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:43 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:43 --> URI Class Initialized
INFO - 2021-04-29 05:51:43 --> Router Class Initialized
INFO - 2021-04-29 05:51:43 --> Output Class Initialized
INFO - 2021-04-29 05:51:43 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:43 --> Input Class Initialized
INFO - 2021-04-29 05:51:43 --> Language Class Initialized
INFO - 2021-04-29 05:51:43 --> Language Class Initialized
INFO - 2021-04-29 05:51:43 --> Config Class Initialized
INFO - 2021-04-29 05:51:43 --> Loader Class Initialized
INFO - 2021-04-29 05:51:43 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:43 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:43 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:43 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:43 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:43 --> Controller Class Initialized
INFO - 2021-04-29 05:51:43 --> Final output sent to browser
DEBUG - 2021-04-29 05:51:43 --> Total execution time: 0.1600
INFO - 2021-04-29 05:51:53 --> Config Class Initialized
INFO - 2021-04-29 05:51:53 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:53 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:53 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:53 --> URI Class Initialized
INFO - 2021-04-29 05:51:53 --> Router Class Initialized
INFO - 2021-04-29 05:51:53 --> Output Class Initialized
INFO - 2021-04-29 05:51:53 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:53 --> Input Class Initialized
INFO - 2021-04-29 05:51:53 --> Language Class Initialized
INFO - 2021-04-29 05:51:54 --> Language Class Initialized
INFO - 2021-04-29 05:51:54 --> Config Class Initialized
INFO - 2021-04-29 05:51:54 --> Loader Class Initialized
INFO - 2021-04-29 05:51:54 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:54 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:54 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:54 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:54 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:54 --> Controller Class Initialized
INFO - 2021-04-29 05:51:54 --> Final output sent to browser
DEBUG - 2021-04-29 05:51:54 --> Total execution time: 0.1847
INFO - 2021-04-29 05:51:54 --> Config Class Initialized
INFO - 2021-04-29 05:51:54 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:51:54 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:51:54 --> Utf8 Class Initialized
INFO - 2021-04-29 05:51:54 --> URI Class Initialized
INFO - 2021-04-29 05:51:54 --> Router Class Initialized
INFO - 2021-04-29 05:51:54 --> Output Class Initialized
INFO - 2021-04-29 05:51:54 --> Security Class Initialized
DEBUG - 2021-04-29 05:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:51:54 --> Input Class Initialized
INFO - 2021-04-29 05:51:54 --> Language Class Initialized
INFO - 2021-04-29 05:51:54 --> Language Class Initialized
INFO - 2021-04-29 05:51:54 --> Config Class Initialized
INFO - 2021-04-29 05:51:54 --> Loader Class Initialized
INFO - 2021-04-29 05:51:54 --> Helper loaded: url_helper
INFO - 2021-04-29 05:51:54 --> Helper loaded: file_helper
INFO - 2021-04-29 05:51:54 --> Helper loaded: form_helper
INFO - 2021-04-29 05:51:54 --> Helper loaded: my_helper
INFO - 2021-04-29 05:51:54 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:51:54 --> Controller Class Initialized
INFO - 2021-04-29 05:52:02 --> Config Class Initialized
INFO - 2021-04-29 05:52:02 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:02 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:02 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:02 --> URI Class Initialized
INFO - 2021-04-29 05:52:02 --> Router Class Initialized
INFO - 2021-04-29 05:52:02 --> Output Class Initialized
INFO - 2021-04-29 05:52:02 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:02 --> Input Class Initialized
INFO - 2021-04-29 05:52:02 --> Language Class Initialized
INFO - 2021-04-29 05:52:02 --> Language Class Initialized
INFO - 2021-04-29 05:52:02 --> Config Class Initialized
INFO - 2021-04-29 05:52:02 --> Loader Class Initialized
INFO - 2021-04-29 05:52:02 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:02 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:02 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:02 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:02 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:02 --> Controller Class Initialized
DEBUG - 2021-04-29 05:52:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-29 05:52:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:52:02 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:02 --> Total execution time: 0.1272
INFO - 2021-04-29 05:52:02 --> Config Class Initialized
INFO - 2021-04-29 05:52:02 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:02 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:02 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:02 --> URI Class Initialized
INFO - 2021-04-29 05:52:02 --> Router Class Initialized
INFO - 2021-04-29 05:52:02 --> Output Class Initialized
INFO - 2021-04-29 05:52:02 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:02 --> Input Class Initialized
INFO - 2021-04-29 05:52:02 --> Language Class Initialized
INFO - 2021-04-29 05:52:02 --> Language Class Initialized
INFO - 2021-04-29 05:52:02 --> Config Class Initialized
INFO - 2021-04-29 05:52:02 --> Loader Class Initialized
INFO - 2021-04-29 05:52:02 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:02 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:02 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:02 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:02 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:02 --> Controller Class Initialized
INFO - 2021-04-29 05:52:04 --> Config Class Initialized
INFO - 2021-04-29 05:52:04 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:04 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:04 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:04 --> URI Class Initialized
INFO - 2021-04-29 05:52:04 --> Router Class Initialized
INFO - 2021-04-29 05:52:04 --> Output Class Initialized
INFO - 2021-04-29 05:52:04 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:04 --> Input Class Initialized
INFO - 2021-04-29 05:52:04 --> Language Class Initialized
INFO - 2021-04-29 05:52:04 --> Language Class Initialized
INFO - 2021-04-29 05:52:04 --> Config Class Initialized
INFO - 2021-04-29 05:52:04 --> Loader Class Initialized
INFO - 2021-04-29 05:52:04 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:04 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:04 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:04 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:04 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:04 --> Controller Class Initialized
DEBUG - 2021-04-29 05:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-04-29 05:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:52:04 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:04 --> Total execution time: 0.1436
INFO - 2021-04-29 05:52:19 --> Config Class Initialized
INFO - 2021-04-29 05:52:19 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:19 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:19 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:19 --> URI Class Initialized
INFO - 2021-04-29 05:52:19 --> Router Class Initialized
INFO - 2021-04-29 05:52:19 --> Output Class Initialized
INFO - 2021-04-29 05:52:19 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:19 --> Input Class Initialized
INFO - 2021-04-29 05:52:19 --> Language Class Initialized
INFO - 2021-04-29 05:52:19 --> Language Class Initialized
INFO - 2021-04-29 05:52:19 --> Config Class Initialized
INFO - 2021-04-29 05:52:19 --> Loader Class Initialized
INFO - 2021-04-29 05:52:19 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:19 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:19 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:19 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:19 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:19 --> Controller Class Initialized
INFO - 2021-04-29 05:52:19 --> Config Class Initialized
INFO - 2021-04-29 05:52:19 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:19 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:19 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:19 --> URI Class Initialized
INFO - 2021-04-29 05:52:19 --> Router Class Initialized
INFO - 2021-04-29 05:52:19 --> Output Class Initialized
INFO - 2021-04-29 05:52:19 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:19 --> Input Class Initialized
INFO - 2021-04-29 05:52:19 --> Language Class Initialized
INFO - 2021-04-29 05:52:19 --> Language Class Initialized
INFO - 2021-04-29 05:52:19 --> Config Class Initialized
INFO - 2021-04-29 05:52:19 --> Loader Class Initialized
INFO - 2021-04-29 05:52:19 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:19 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:19 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:19 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:19 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:19 --> Controller Class Initialized
DEBUG - 2021-04-29 05:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-29 05:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:52:19 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:19 --> Total execution time: 0.1725
INFO - 2021-04-29 05:52:20 --> Config Class Initialized
INFO - 2021-04-29 05:52:20 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:20 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:20 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:20 --> URI Class Initialized
INFO - 2021-04-29 05:52:20 --> Router Class Initialized
INFO - 2021-04-29 05:52:20 --> Output Class Initialized
INFO - 2021-04-29 05:52:20 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:20 --> Input Class Initialized
INFO - 2021-04-29 05:52:20 --> Language Class Initialized
INFO - 2021-04-29 05:52:20 --> Language Class Initialized
INFO - 2021-04-29 05:52:20 --> Config Class Initialized
INFO - 2021-04-29 05:52:20 --> Loader Class Initialized
INFO - 2021-04-29 05:52:20 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:20 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:20 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:20 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:20 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:20 --> Controller Class Initialized
INFO - 2021-04-29 05:52:26 --> Config Class Initialized
INFO - 2021-04-29 05:52:26 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:26 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:26 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:26 --> URI Class Initialized
INFO - 2021-04-29 05:52:26 --> Router Class Initialized
INFO - 2021-04-29 05:52:26 --> Output Class Initialized
INFO - 2021-04-29 05:52:26 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:26 --> Input Class Initialized
INFO - 2021-04-29 05:52:26 --> Language Class Initialized
INFO - 2021-04-29 05:52:26 --> Language Class Initialized
INFO - 2021-04-29 05:52:26 --> Config Class Initialized
INFO - 2021-04-29 05:52:26 --> Loader Class Initialized
INFO - 2021-04-29 05:52:26 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:26 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:26 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:26 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:26 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:26 --> Controller Class Initialized
INFO - 2021-04-29 05:52:26 --> Helper loaded: cookie_helper
INFO - 2021-04-29 05:52:26 --> Config Class Initialized
INFO - 2021-04-29 05:52:26 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:26 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:26 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:26 --> URI Class Initialized
INFO - 2021-04-29 05:52:26 --> Router Class Initialized
INFO - 2021-04-29 05:52:26 --> Output Class Initialized
INFO - 2021-04-29 05:52:26 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:26 --> Input Class Initialized
INFO - 2021-04-29 05:52:26 --> Language Class Initialized
INFO - 2021-04-29 05:52:26 --> Language Class Initialized
INFO - 2021-04-29 05:52:26 --> Config Class Initialized
INFO - 2021-04-29 05:52:26 --> Loader Class Initialized
INFO - 2021-04-29 05:52:26 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:26 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:26 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:26 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:26 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:26 --> Controller Class Initialized
DEBUG - 2021-04-29 05:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 05:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:52:26 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:26 --> Total execution time: 0.1949
INFO - 2021-04-29 05:52:37 --> Config Class Initialized
INFO - 2021-04-29 05:52:37 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:37 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:37 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:37 --> URI Class Initialized
INFO - 2021-04-29 05:52:37 --> Router Class Initialized
INFO - 2021-04-29 05:52:37 --> Output Class Initialized
INFO - 2021-04-29 05:52:37 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:37 --> Input Class Initialized
INFO - 2021-04-29 05:52:37 --> Language Class Initialized
INFO - 2021-04-29 05:52:37 --> Language Class Initialized
INFO - 2021-04-29 05:52:37 --> Config Class Initialized
INFO - 2021-04-29 05:52:37 --> Loader Class Initialized
INFO - 2021-04-29 05:52:37 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:37 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:37 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:37 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:37 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:37 --> Controller Class Initialized
INFO - 2021-04-29 05:52:37 --> Helper loaded: cookie_helper
INFO - 2021-04-29 05:52:37 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:37 --> Total execution time: 0.1602
INFO - 2021-04-29 05:52:39 --> Config Class Initialized
INFO - 2021-04-29 05:52:39 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:39 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:39 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:39 --> URI Class Initialized
INFO - 2021-04-29 05:52:39 --> Router Class Initialized
INFO - 2021-04-29 05:52:39 --> Output Class Initialized
INFO - 2021-04-29 05:52:39 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:39 --> Input Class Initialized
INFO - 2021-04-29 05:52:39 --> Language Class Initialized
INFO - 2021-04-29 05:52:39 --> Language Class Initialized
INFO - 2021-04-29 05:52:39 --> Config Class Initialized
INFO - 2021-04-29 05:52:39 --> Loader Class Initialized
INFO - 2021-04-29 05:52:39 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:39 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:39 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:39 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:39 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:39 --> Controller Class Initialized
DEBUG - 2021-04-29 05:52:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 05:52:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:52:39 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:39 --> Total execution time: 0.1664
INFO - 2021-04-29 05:52:49 --> Config Class Initialized
INFO - 2021-04-29 05:52:49 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:49 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:49 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:49 --> URI Class Initialized
INFO - 2021-04-29 05:52:49 --> Router Class Initialized
INFO - 2021-04-29 05:52:49 --> Output Class Initialized
INFO - 2021-04-29 05:52:49 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:49 --> Input Class Initialized
INFO - 2021-04-29 05:52:49 --> Language Class Initialized
INFO - 2021-04-29 05:52:49 --> Language Class Initialized
INFO - 2021-04-29 05:52:49 --> Config Class Initialized
INFO - 2021-04-29 05:52:49 --> Loader Class Initialized
INFO - 2021-04-29 05:52:49 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:49 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:49 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:49 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:49 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:49 --> Controller Class Initialized
DEBUG - 2021-04-29 05:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-29 05:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:52:49 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:49 --> Total execution time: 0.1113
INFO - 2021-04-29 05:52:53 --> Config Class Initialized
INFO - 2021-04-29 05:52:53 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:53 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:53 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:53 --> URI Class Initialized
INFO - 2021-04-29 05:52:53 --> Router Class Initialized
INFO - 2021-04-29 05:52:53 --> Output Class Initialized
INFO - 2021-04-29 05:52:53 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:53 --> Input Class Initialized
INFO - 2021-04-29 05:52:53 --> Language Class Initialized
INFO - 2021-04-29 05:52:53 --> Language Class Initialized
INFO - 2021-04-29 05:52:53 --> Config Class Initialized
INFO - 2021-04-29 05:52:53 --> Loader Class Initialized
INFO - 2021-04-29 05:52:53 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:53 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:53 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:53 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:53 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:53 --> Controller Class Initialized
DEBUG - 2021-04-29 05:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-04-29 05:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:52:53 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:53 --> Total execution time: 0.1384
INFO - 2021-04-29 05:52:54 --> Config Class Initialized
INFO - 2021-04-29 05:52:54 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:52:54 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:52:54 --> Utf8 Class Initialized
INFO - 2021-04-29 05:52:54 --> URI Class Initialized
INFO - 2021-04-29 05:52:54 --> Router Class Initialized
INFO - 2021-04-29 05:52:54 --> Output Class Initialized
INFO - 2021-04-29 05:52:54 --> Security Class Initialized
DEBUG - 2021-04-29 05:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:52:54 --> Input Class Initialized
INFO - 2021-04-29 05:52:54 --> Language Class Initialized
INFO - 2021-04-29 05:52:54 --> Language Class Initialized
INFO - 2021-04-29 05:52:54 --> Config Class Initialized
INFO - 2021-04-29 05:52:54 --> Loader Class Initialized
INFO - 2021-04-29 05:52:54 --> Helper loaded: url_helper
INFO - 2021-04-29 05:52:54 --> Helper loaded: file_helper
INFO - 2021-04-29 05:52:54 --> Helper loaded: form_helper
INFO - 2021-04-29 05:52:54 --> Helper loaded: my_helper
INFO - 2021-04-29 05:52:54 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:52:54 --> Controller Class Initialized
DEBUG - 2021-04-29 05:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-29 05:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:52:54 --> Final output sent to browser
DEBUG - 2021-04-29 05:52:54 --> Total execution time: 0.1437
INFO - 2021-04-29 05:53:10 --> Config Class Initialized
INFO - 2021-04-29 05:53:10 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:10 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:10 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:10 --> URI Class Initialized
INFO - 2021-04-29 05:53:10 --> Router Class Initialized
INFO - 2021-04-29 05:53:10 --> Output Class Initialized
INFO - 2021-04-29 05:53:10 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:10 --> Input Class Initialized
INFO - 2021-04-29 05:53:10 --> Language Class Initialized
INFO - 2021-04-29 05:53:10 --> Language Class Initialized
INFO - 2021-04-29 05:53:10 --> Config Class Initialized
INFO - 2021-04-29 05:53:10 --> Loader Class Initialized
INFO - 2021-04-29 05:53:10 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:10 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:10 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:10 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:10 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:10 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-29 05:53:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:10 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:10 --> Total execution time: 0.1056
INFO - 2021-04-29 05:53:13 --> Config Class Initialized
INFO - 2021-04-29 05:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:13 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:13 --> URI Class Initialized
INFO - 2021-04-29 05:53:13 --> Router Class Initialized
INFO - 2021-04-29 05:53:13 --> Output Class Initialized
INFO - 2021-04-29 05:53:13 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:13 --> Input Class Initialized
INFO - 2021-04-29 05:53:13 --> Language Class Initialized
INFO - 2021-04-29 05:53:13 --> Language Class Initialized
INFO - 2021-04-29 05:53:13 --> Config Class Initialized
INFO - 2021-04-29 05:53:13 --> Loader Class Initialized
INFO - 2021-04-29 05:53:13 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:13 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:13 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:13 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:13 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:13 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-04-29 05:53:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:13 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:13 --> Total execution time: 0.1550
INFO - 2021-04-29 05:53:13 --> Config Class Initialized
INFO - 2021-04-29 05:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:13 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:13 --> URI Class Initialized
INFO - 2021-04-29 05:53:13 --> Router Class Initialized
INFO - 2021-04-29 05:53:13 --> Output Class Initialized
INFO - 2021-04-29 05:53:13 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:13 --> Input Class Initialized
INFO - 2021-04-29 05:53:13 --> Language Class Initialized
INFO - 2021-04-29 05:53:13 --> Language Class Initialized
INFO - 2021-04-29 05:53:13 --> Config Class Initialized
INFO - 2021-04-29 05:53:13 --> Loader Class Initialized
INFO - 2021-04-29 05:53:13 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:13 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:13 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:13 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:13 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:13 --> Controller Class Initialized
INFO - 2021-04-29 05:53:15 --> Config Class Initialized
INFO - 2021-04-29 05:53:15 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:15 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:15 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:15 --> URI Class Initialized
INFO - 2021-04-29 05:53:15 --> Router Class Initialized
INFO - 2021-04-29 05:53:15 --> Output Class Initialized
INFO - 2021-04-29 05:53:15 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:15 --> Input Class Initialized
INFO - 2021-04-29 05:53:15 --> Language Class Initialized
INFO - 2021-04-29 05:53:15 --> Language Class Initialized
INFO - 2021-04-29 05:53:15 --> Config Class Initialized
INFO - 2021-04-29 05:53:15 --> Loader Class Initialized
INFO - 2021-04-29 05:53:15 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:15 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:16 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:16 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:16 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:16 --> Controller Class Initialized
INFO - 2021-04-29 05:53:16 --> Helper loaded: cookie_helper
INFO - 2021-04-29 05:53:16 --> Config Class Initialized
INFO - 2021-04-29 05:53:16 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:16 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:16 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:16 --> URI Class Initialized
INFO - 2021-04-29 05:53:16 --> Router Class Initialized
INFO - 2021-04-29 05:53:16 --> Output Class Initialized
INFO - 2021-04-29 05:53:16 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:16 --> Input Class Initialized
INFO - 2021-04-29 05:53:16 --> Language Class Initialized
INFO - 2021-04-29 05:53:16 --> Language Class Initialized
INFO - 2021-04-29 05:53:16 --> Config Class Initialized
INFO - 2021-04-29 05:53:16 --> Loader Class Initialized
INFO - 2021-04-29 05:53:16 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:16 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:16 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:16 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:16 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:16 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-29 05:53:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:16 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:16 --> Total execution time: 0.1965
INFO - 2021-04-29 05:53:25 --> Config Class Initialized
INFO - 2021-04-29 05:53:25 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:25 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:25 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:25 --> URI Class Initialized
INFO - 2021-04-29 05:53:25 --> Router Class Initialized
INFO - 2021-04-29 05:53:25 --> Output Class Initialized
INFO - 2021-04-29 05:53:25 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:25 --> Input Class Initialized
INFO - 2021-04-29 05:53:25 --> Language Class Initialized
INFO - 2021-04-29 05:53:25 --> Language Class Initialized
INFO - 2021-04-29 05:53:25 --> Config Class Initialized
INFO - 2021-04-29 05:53:25 --> Loader Class Initialized
INFO - 2021-04-29 05:53:25 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:25 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:25 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:25 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:25 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:25 --> Controller Class Initialized
INFO - 2021-04-29 05:53:25 --> Helper loaded: cookie_helper
INFO - 2021-04-29 05:53:25 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:25 --> Total execution time: 0.1316
INFO - 2021-04-29 05:53:26 --> Config Class Initialized
INFO - 2021-04-29 05:53:26 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:26 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:26 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:26 --> URI Class Initialized
INFO - 2021-04-29 05:53:26 --> Router Class Initialized
INFO - 2021-04-29 05:53:26 --> Output Class Initialized
INFO - 2021-04-29 05:53:26 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:26 --> Input Class Initialized
INFO - 2021-04-29 05:53:26 --> Language Class Initialized
INFO - 2021-04-29 05:53:26 --> Language Class Initialized
INFO - 2021-04-29 05:53:26 --> Config Class Initialized
INFO - 2021-04-29 05:53:26 --> Loader Class Initialized
INFO - 2021-04-29 05:53:26 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:26 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:26 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:26 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:26 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:26 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 05:53:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:26 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:26 --> Total execution time: 0.2346
INFO - 2021-04-29 05:53:40 --> Config Class Initialized
INFO - 2021-04-29 05:53:40 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:40 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:40 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:40 --> URI Class Initialized
DEBUG - 2021-04-29 05:53:40 --> No URI present. Default controller set.
INFO - 2021-04-29 05:53:40 --> Router Class Initialized
INFO - 2021-04-29 05:53:40 --> Output Class Initialized
INFO - 2021-04-29 05:53:40 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:40 --> Input Class Initialized
INFO - 2021-04-29 05:53:40 --> Language Class Initialized
INFO - 2021-04-29 05:53:40 --> Language Class Initialized
INFO - 2021-04-29 05:53:40 --> Config Class Initialized
INFO - 2021-04-29 05:53:40 --> Loader Class Initialized
INFO - 2021-04-29 05:53:40 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:40 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:40 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:40 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:40 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:40 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-29 05:53:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:40 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:40 --> Total execution time: 0.1533
INFO - 2021-04-29 05:53:41 --> Config Class Initialized
INFO - 2021-04-29 05:53:41 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:41 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:41 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:41 --> URI Class Initialized
INFO - 2021-04-29 05:53:41 --> Router Class Initialized
INFO - 2021-04-29 05:53:41 --> Output Class Initialized
INFO - 2021-04-29 05:53:41 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:41 --> Input Class Initialized
INFO - 2021-04-29 05:53:41 --> Language Class Initialized
INFO - 2021-04-29 05:53:41 --> Language Class Initialized
INFO - 2021-04-29 05:53:41 --> Config Class Initialized
INFO - 2021-04-29 05:53:41 --> Loader Class Initialized
INFO - 2021-04-29 05:53:41 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:41 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:41 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:41 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:41 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:41 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-29 05:53:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:41 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:41 --> Total execution time: 0.1365
INFO - 2021-04-29 05:53:42 --> Config Class Initialized
INFO - 2021-04-29 05:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:42 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:42 --> URI Class Initialized
INFO - 2021-04-29 05:53:42 --> Router Class Initialized
INFO - 2021-04-29 05:53:42 --> Output Class Initialized
INFO - 2021-04-29 05:53:42 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:42 --> Input Class Initialized
INFO - 2021-04-29 05:53:42 --> Language Class Initialized
INFO - 2021-04-29 05:53:42 --> Language Class Initialized
INFO - 2021-04-29 05:53:42 --> Config Class Initialized
INFO - 2021-04-29 05:53:42 --> Loader Class Initialized
INFO - 2021-04-29 05:53:42 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:42 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:42 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:42 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:42 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:42 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-04-29 05:53:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:42 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:42 --> Total execution time: 0.1209
INFO - 2021-04-29 05:53:44 --> Config Class Initialized
INFO - 2021-04-29 05:53:44 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:44 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:44 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:44 --> URI Class Initialized
INFO - 2021-04-29 05:53:44 --> Router Class Initialized
INFO - 2021-04-29 05:53:44 --> Output Class Initialized
INFO - 2021-04-29 05:53:44 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:44 --> Input Class Initialized
INFO - 2021-04-29 05:53:44 --> Language Class Initialized
INFO - 2021-04-29 05:53:44 --> Language Class Initialized
INFO - 2021-04-29 05:53:44 --> Config Class Initialized
INFO - 2021-04-29 05:53:44 --> Loader Class Initialized
INFO - 2021-04-29 05:53:44 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:44 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:44 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:44 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:44 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:45 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2021-04-29 05:53:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:45 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:45 --> Total execution time: 0.1344
INFO - 2021-04-29 05:53:48 --> Config Class Initialized
INFO - 2021-04-29 05:53:48 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:48 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:48 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:48 --> URI Class Initialized
INFO - 2021-04-29 05:53:48 --> Router Class Initialized
INFO - 2021-04-29 05:53:48 --> Output Class Initialized
INFO - 2021-04-29 05:53:48 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:48 --> Input Class Initialized
INFO - 2021-04-29 05:53:48 --> Language Class Initialized
INFO - 2021-04-29 05:53:48 --> Language Class Initialized
INFO - 2021-04-29 05:53:48 --> Config Class Initialized
INFO - 2021-04-29 05:53:48 --> Loader Class Initialized
INFO - 2021-04-29 05:53:48 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:48 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:48 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:48 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:48 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:48 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-04-29 05:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:48 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:48 --> Total execution time: 0.1889
INFO - 2021-04-29 05:53:49 --> Config Class Initialized
INFO - 2021-04-29 05:53:49 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:49 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:49 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:49 --> URI Class Initialized
INFO - 2021-04-29 05:53:49 --> Router Class Initialized
INFO - 2021-04-29 05:53:49 --> Output Class Initialized
INFO - 2021-04-29 05:53:49 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:49 --> Input Class Initialized
INFO - 2021-04-29 05:53:49 --> Language Class Initialized
INFO - 2021-04-29 05:53:49 --> Language Class Initialized
INFO - 2021-04-29 05:53:49 --> Config Class Initialized
INFO - 2021-04-29 05:53:49 --> Loader Class Initialized
INFO - 2021-04-29 05:53:49 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:49 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:49 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:49 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:49 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:49 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-04-29 05:53:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:49 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:49 --> Total execution time: 0.1528
INFO - 2021-04-29 05:53:49 --> Config Class Initialized
INFO - 2021-04-29 05:53:49 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:49 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:49 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:49 --> URI Class Initialized
INFO - 2021-04-29 05:53:49 --> Router Class Initialized
INFO - 2021-04-29 05:53:49 --> Output Class Initialized
INFO - 2021-04-29 05:53:49 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:49 --> Input Class Initialized
INFO - 2021-04-29 05:53:49 --> Language Class Initialized
INFO - 2021-04-29 05:53:49 --> Language Class Initialized
INFO - 2021-04-29 05:53:49 --> Config Class Initialized
INFO - 2021-04-29 05:53:49 --> Loader Class Initialized
INFO - 2021-04-29 05:53:49 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:49 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:49 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:49 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:49 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:50 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-04-29 05:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:50 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:50 --> Total execution time: 0.1672
INFO - 2021-04-29 05:53:52 --> Config Class Initialized
INFO - 2021-04-29 05:53:52 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:52 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:52 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:52 --> URI Class Initialized
INFO - 2021-04-29 05:53:52 --> Router Class Initialized
INFO - 2021-04-29 05:53:52 --> Output Class Initialized
INFO - 2021-04-29 05:53:52 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:52 --> Input Class Initialized
INFO - 2021-04-29 05:53:52 --> Language Class Initialized
INFO - 2021-04-29 05:53:52 --> Language Class Initialized
INFO - 2021-04-29 05:53:52 --> Config Class Initialized
INFO - 2021-04-29 05:53:52 --> Loader Class Initialized
INFO - 2021-04-29 05:53:52 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:52 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:52 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:52 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:52 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:52 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-29 05:53:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:52 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:52 --> Total execution time: 0.1606
INFO - 2021-04-29 05:53:58 --> Config Class Initialized
INFO - 2021-04-29 05:53:58 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:58 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:58 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:58 --> URI Class Initialized
INFO - 2021-04-29 05:53:58 --> Router Class Initialized
INFO - 2021-04-29 05:53:58 --> Output Class Initialized
INFO - 2021-04-29 05:53:58 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:58 --> Input Class Initialized
INFO - 2021-04-29 05:53:58 --> Language Class Initialized
INFO - 2021-04-29 05:53:58 --> Language Class Initialized
INFO - 2021-04-29 05:53:58 --> Config Class Initialized
INFO - 2021-04-29 05:53:58 --> Loader Class Initialized
INFO - 2021-04-29 05:53:58 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:58 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:58 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:58 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:58 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:58 --> Controller Class Initialized
DEBUG - 2021-04-29 05:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-04-29 05:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:53:58 --> Final output sent to browser
DEBUG - 2021-04-29 05:53:58 --> Total execution time: 0.1399
INFO - 2021-04-29 05:53:58 --> Config Class Initialized
INFO - 2021-04-29 05:53:58 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:53:58 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:53:58 --> Utf8 Class Initialized
INFO - 2021-04-29 05:53:58 --> URI Class Initialized
INFO - 2021-04-29 05:53:58 --> Router Class Initialized
INFO - 2021-04-29 05:53:58 --> Output Class Initialized
INFO - 2021-04-29 05:53:58 --> Security Class Initialized
DEBUG - 2021-04-29 05:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:53:58 --> Input Class Initialized
INFO - 2021-04-29 05:53:58 --> Language Class Initialized
INFO - 2021-04-29 05:53:58 --> Language Class Initialized
INFO - 2021-04-29 05:53:58 --> Config Class Initialized
INFO - 2021-04-29 05:53:58 --> Loader Class Initialized
INFO - 2021-04-29 05:53:58 --> Helper loaded: url_helper
INFO - 2021-04-29 05:53:58 --> Helper loaded: file_helper
INFO - 2021-04-29 05:53:58 --> Helper loaded: form_helper
INFO - 2021-04-29 05:53:58 --> Helper loaded: my_helper
INFO - 2021-04-29 05:53:58 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:53:58 --> Controller Class Initialized
INFO - 2021-04-29 05:54:00 --> Config Class Initialized
INFO - 2021-04-29 05:54:00 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:54:00 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:54:00 --> Utf8 Class Initialized
INFO - 2021-04-29 05:54:00 --> URI Class Initialized
INFO - 2021-04-29 05:54:00 --> Router Class Initialized
INFO - 2021-04-29 05:54:00 --> Output Class Initialized
INFO - 2021-04-29 05:54:00 --> Security Class Initialized
DEBUG - 2021-04-29 05:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:54:00 --> Input Class Initialized
INFO - 2021-04-29 05:54:00 --> Language Class Initialized
INFO - 2021-04-29 05:54:00 --> Language Class Initialized
INFO - 2021-04-29 05:54:00 --> Config Class Initialized
INFO - 2021-04-29 05:54:00 --> Loader Class Initialized
INFO - 2021-04-29 05:54:00 --> Helper loaded: url_helper
INFO - 2021-04-29 05:54:00 --> Helper loaded: file_helper
INFO - 2021-04-29 05:54:00 --> Helper loaded: form_helper
INFO - 2021-04-29 05:54:00 --> Helper loaded: my_helper
INFO - 2021-04-29 05:54:00 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:54:00 --> Controller Class Initialized
INFO - 2021-04-29 05:54:00 --> Final output sent to browser
DEBUG - 2021-04-29 05:54:00 --> Total execution time: 0.1292
INFO - 2021-04-29 05:54:32 --> Config Class Initialized
INFO - 2021-04-29 05:54:32 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:54:32 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:54:32 --> Utf8 Class Initialized
INFO - 2021-04-29 05:54:32 --> URI Class Initialized
INFO - 2021-04-29 05:54:32 --> Router Class Initialized
INFO - 2021-04-29 05:54:32 --> Output Class Initialized
INFO - 2021-04-29 05:54:32 --> Security Class Initialized
DEBUG - 2021-04-29 05:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:54:32 --> Input Class Initialized
INFO - 2021-04-29 05:54:32 --> Language Class Initialized
INFO - 2021-04-29 05:54:32 --> Language Class Initialized
INFO - 2021-04-29 05:54:32 --> Config Class Initialized
INFO - 2021-04-29 05:54:32 --> Loader Class Initialized
INFO - 2021-04-29 05:54:32 --> Helper loaded: url_helper
INFO - 2021-04-29 05:54:32 --> Helper loaded: file_helper
INFO - 2021-04-29 05:54:32 --> Helper loaded: form_helper
INFO - 2021-04-29 05:54:32 --> Helper loaded: my_helper
INFO - 2021-04-29 05:54:32 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:54:32 --> Controller Class Initialized
INFO - 2021-04-29 05:54:32 --> Final output sent to browser
DEBUG - 2021-04-29 05:54:32 --> Total execution time: 0.1484
INFO - 2021-04-29 05:54:32 --> Config Class Initialized
INFO - 2021-04-29 05:54:32 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:54:32 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:54:32 --> Utf8 Class Initialized
INFO - 2021-04-29 05:54:32 --> URI Class Initialized
INFO - 2021-04-29 05:54:32 --> Router Class Initialized
INFO - 2021-04-29 05:54:32 --> Output Class Initialized
INFO - 2021-04-29 05:54:32 --> Security Class Initialized
DEBUG - 2021-04-29 05:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:54:32 --> Input Class Initialized
INFO - 2021-04-29 05:54:32 --> Language Class Initialized
INFO - 2021-04-29 05:54:32 --> Language Class Initialized
INFO - 2021-04-29 05:54:32 --> Config Class Initialized
INFO - 2021-04-29 05:54:32 --> Loader Class Initialized
INFO - 2021-04-29 05:54:32 --> Helper loaded: url_helper
INFO - 2021-04-29 05:54:32 --> Helper loaded: file_helper
INFO - 2021-04-29 05:54:32 --> Helper loaded: form_helper
INFO - 2021-04-29 05:54:32 --> Helper loaded: my_helper
INFO - 2021-04-29 05:54:32 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:54:32 --> Controller Class Initialized
INFO - 2021-04-29 05:54:36 --> Config Class Initialized
INFO - 2021-04-29 05:54:36 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:54:36 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:54:36 --> Utf8 Class Initialized
INFO - 2021-04-29 05:54:36 --> URI Class Initialized
INFO - 2021-04-29 05:54:36 --> Router Class Initialized
INFO - 2021-04-29 05:54:36 --> Output Class Initialized
INFO - 2021-04-29 05:54:36 --> Security Class Initialized
DEBUG - 2021-04-29 05:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:54:36 --> Input Class Initialized
INFO - 2021-04-29 05:54:36 --> Language Class Initialized
INFO - 2021-04-29 05:54:36 --> Language Class Initialized
INFO - 2021-04-29 05:54:36 --> Config Class Initialized
INFO - 2021-04-29 05:54:36 --> Loader Class Initialized
INFO - 2021-04-29 05:54:36 --> Helper loaded: url_helper
INFO - 2021-04-29 05:54:36 --> Helper loaded: file_helper
INFO - 2021-04-29 05:54:36 --> Helper loaded: form_helper
INFO - 2021-04-29 05:54:36 --> Helper loaded: my_helper
INFO - 2021-04-29 05:54:36 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:54:36 --> Controller Class Initialized
INFO - 2021-04-29 05:54:36 --> Final output sent to browser
DEBUG - 2021-04-29 05:54:36 --> Total execution time: 0.1401
INFO - 2021-04-29 05:54:45 --> Config Class Initialized
INFO - 2021-04-29 05:54:45 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:54:45 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:54:45 --> Utf8 Class Initialized
INFO - 2021-04-29 05:54:45 --> URI Class Initialized
INFO - 2021-04-29 05:54:45 --> Router Class Initialized
INFO - 2021-04-29 05:54:45 --> Output Class Initialized
INFO - 2021-04-29 05:54:45 --> Security Class Initialized
DEBUG - 2021-04-29 05:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:54:45 --> Input Class Initialized
INFO - 2021-04-29 05:54:45 --> Language Class Initialized
INFO - 2021-04-29 05:54:45 --> Language Class Initialized
INFO - 2021-04-29 05:54:45 --> Config Class Initialized
INFO - 2021-04-29 05:54:45 --> Loader Class Initialized
INFO - 2021-04-29 05:54:45 --> Helper loaded: url_helper
INFO - 2021-04-29 05:54:45 --> Helper loaded: file_helper
INFO - 2021-04-29 05:54:45 --> Helper loaded: form_helper
INFO - 2021-04-29 05:54:45 --> Helper loaded: my_helper
INFO - 2021-04-29 05:54:45 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:54:45 --> Controller Class Initialized
INFO - 2021-04-29 05:54:45 --> Final output sent to browser
DEBUG - 2021-04-29 05:54:45 --> Total execution time: 0.1248
INFO - 2021-04-29 05:55:03 --> Config Class Initialized
INFO - 2021-04-29 05:55:03 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:55:03 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:55:03 --> Utf8 Class Initialized
INFO - 2021-04-29 05:55:03 --> URI Class Initialized
INFO - 2021-04-29 05:55:03 --> Router Class Initialized
INFO - 2021-04-29 05:55:03 --> Output Class Initialized
INFO - 2021-04-29 05:55:03 --> Security Class Initialized
DEBUG - 2021-04-29 05:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:55:03 --> Input Class Initialized
INFO - 2021-04-29 05:55:03 --> Language Class Initialized
INFO - 2021-04-29 05:55:03 --> Language Class Initialized
INFO - 2021-04-29 05:55:03 --> Config Class Initialized
INFO - 2021-04-29 05:55:03 --> Loader Class Initialized
INFO - 2021-04-29 05:55:03 --> Helper loaded: url_helper
INFO - 2021-04-29 05:55:03 --> Helper loaded: file_helper
INFO - 2021-04-29 05:55:03 --> Helper loaded: form_helper
INFO - 2021-04-29 05:55:03 --> Helper loaded: my_helper
INFO - 2021-04-29 05:55:03 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:55:03 --> Controller Class Initialized
INFO - 2021-04-29 05:55:03 --> Final output sent to browser
DEBUG - 2021-04-29 05:55:03 --> Total execution time: 0.1450
INFO - 2021-04-29 05:55:03 --> Config Class Initialized
INFO - 2021-04-29 05:55:03 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:55:03 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:55:03 --> Utf8 Class Initialized
INFO - 2021-04-29 05:55:03 --> URI Class Initialized
INFO - 2021-04-29 05:55:03 --> Router Class Initialized
INFO - 2021-04-29 05:55:03 --> Output Class Initialized
INFO - 2021-04-29 05:55:03 --> Security Class Initialized
DEBUG - 2021-04-29 05:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:55:03 --> Input Class Initialized
INFO - 2021-04-29 05:55:03 --> Language Class Initialized
INFO - 2021-04-29 05:55:03 --> Language Class Initialized
INFO - 2021-04-29 05:55:03 --> Config Class Initialized
INFO - 2021-04-29 05:55:03 --> Loader Class Initialized
INFO - 2021-04-29 05:55:03 --> Helper loaded: url_helper
INFO - 2021-04-29 05:55:03 --> Helper loaded: file_helper
INFO - 2021-04-29 05:55:03 --> Helper loaded: form_helper
INFO - 2021-04-29 05:55:03 --> Helper loaded: my_helper
INFO - 2021-04-29 05:55:03 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:55:03 --> Controller Class Initialized
INFO - 2021-04-29 05:55:05 --> Config Class Initialized
INFO - 2021-04-29 05:55:05 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:55:05 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:55:05 --> Utf8 Class Initialized
INFO - 2021-04-29 05:55:05 --> URI Class Initialized
INFO - 2021-04-29 05:55:05 --> Router Class Initialized
INFO - 2021-04-29 05:55:05 --> Output Class Initialized
INFO - 2021-04-29 05:55:05 --> Security Class Initialized
DEBUG - 2021-04-29 05:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:55:05 --> Input Class Initialized
INFO - 2021-04-29 05:55:05 --> Language Class Initialized
INFO - 2021-04-29 05:55:05 --> Language Class Initialized
INFO - 2021-04-29 05:55:05 --> Config Class Initialized
INFO - 2021-04-29 05:55:05 --> Loader Class Initialized
INFO - 2021-04-29 05:55:05 --> Helper loaded: url_helper
INFO - 2021-04-29 05:55:05 --> Helper loaded: file_helper
INFO - 2021-04-29 05:55:05 --> Helper loaded: form_helper
INFO - 2021-04-29 05:55:05 --> Helper loaded: my_helper
INFO - 2021-04-29 05:55:05 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:55:05 --> Controller Class Initialized
INFO - 2021-04-29 05:55:13 --> Config Class Initialized
INFO - 2021-04-29 05:55:13 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:55:13 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:55:13 --> Utf8 Class Initialized
INFO - 2021-04-29 05:55:13 --> URI Class Initialized
INFO - 2021-04-29 05:55:13 --> Router Class Initialized
INFO - 2021-04-29 05:55:13 --> Output Class Initialized
INFO - 2021-04-29 05:55:13 --> Security Class Initialized
DEBUG - 2021-04-29 05:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:55:13 --> Input Class Initialized
INFO - 2021-04-29 05:55:13 --> Language Class Initialized
INFO - 2021-04-29 05:55:13 --> Language Class Initialized
INFO - 2021-04-29 05:55:13 --> Config Class Initialized
INFO - 2021-04-29 05:55:13 --> Loader Class Initialized
INFO - 2021-04-29 05:55:13 --> Helper loaded: url_helper
INFO - 2021-04-29 05:55:13 --> Helper loaded: file_helper
INFO - 2021-04-29 05:55:13 --> Helper loaded: form_helper
INFO - 2021-04-29 05:55:13 --> Helper loaded: my_helper
INFO - 2021-04-29 05:55:13 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:55:13 --> Controller Class Initialized
INFO - 2021-04-29 05:56:31 --> Config Class Initialized
INFO - 2021-04-29 05:56:31 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:31 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:31 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:31 --> URI Class Initialized
INFO - 2021-04-29 05:56:31 --> Router Class Initialized
INFO - 2021-04-29 05:56:31 --> Output Class Initialized
INFO - 2021-04-29 05:56:31 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:31 --> Input Class Initialized
INFO - 2021-04-29 05:56:31 --> Language Class Initialized
INFO - 2021-04-29 05:56:31 --> Language Class Initialized
INFO - 2021-04-29 05:56:31 --> Config Class Initialized
INFO - 2021-04-29 05:56:31 --> Loader Class Initialized
INFO - 2021-04-29 05:56:31 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:31 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:31 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:31 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:31 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:31 --> Controller Class Initialized
DEBUG - 2021-04-29 05:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-04-29 05:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:56:31 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:31 --> Total execution time: 0.1478
INFO - 2021-04-29 05:56:40 --> Config Class Initialized
INFO - 2021-04-29 05:56:40 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:40 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:40 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:40 --> URI Class Initialized
INFO - 2021-04-29 05:56:40 --> Router Class Initialized
INFO - 2021-04-29 05:56:40 --> Output Class Initialized
INFO - 2021-04-29 05:56:40 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:40 --> Input Class Initialized
INFO - 2021-04-29 05:56:40 --> Language Class Initialized
INFO - 2021-04-29 05:56:40 --> Language Class Initialized
INFO - 2021-04-29 05:56:40 --> Config Class Initialized
INFO - 2021-04-29 05:56:40 --> Loader Class Initialized
INFO - 2021-04-29 05:56:40 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:40 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:40 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:40 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:40 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:40 --> Controller Class Initialized
INFO - 2021-04-29 05:56:41 --> Config Class Initialized
INFO - 2021-04-29 05:56:41 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:41 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:41 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:41 --> URI Class Initialized
INFO - 2021-04-29 05:56:41 --> Router Class Initialized
INFO - 2021-04-29 05:56:41 --> Output Class Initialized
INFO - 2021-04-29 05:56:41 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:41 --> Input Class Initialized
INFO - 2021-04-29 05:56:41 --> Language Class Initialized
INFO - 2021-04-29 05:56:41 --> Language Class Initialized
INFO - 2021-04-29 05:56:41 --> Config Class Initialized
INFO - 2021-04-29 05:56:41 --> Loader Class Initialized
INFO - 2021-04-29 05:56:41 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:41 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:41 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:41 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:41 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:41 --> Controller Class Initialized
DEBUG - 2021-04-29 05:56:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-04-29 05:56:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:56:41 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:41 --> Total execution time: 0.1550
INFO - 2021-04-29 05:56:41 --> Config Class Initialized
INFO - 2021-04-29 05:56:41 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:41 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:41 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:41 --> URI Class Initialized
INFO - 2021-04-29 05:56:41 --> Router Class Initialized
INFO - 2021-04-29 05:56:41 --> Output Class Initialized
INFO - 2021-04-29 05:56:41 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:41 --> Input Class Initialized
INFO - 2021-04-29 05:56:41 --> Language Class Initialized
INFO - 2021-04-29 05:56:41 --> Language Class Initialized
INFO - 2021-04-29 05:56:41 --> Config Class Initialized
INFO - 2021-04-29 05:56:41 --> Loader Class Initialized
INFO - 2021-04-29 05:56:41 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:41 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:41 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:41 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:41 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:41 --> Controller Class Initialized
INFO - 2021-04-29 05:56:43 --> Config Class Initialized
INFO - 2021-04-29 05:56:43 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:43 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:43 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:43 --> URI Class Initialized
INFO - 2021-04-29 05:56:43 --> Router Class Initialized
INFO - 2021-04-29 05:56:43 --> Output Class Initialized
INFO - 2021-04-29 05:56:43 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:43 --> Input Class Initialized
INFO - 2021-04-29 05:56:43 --> Language Class Initialized
INFO - 2021-04-29 05:56:43 --> Language Class Initialized
INFO - 2021-04-29 05:56:43 --> Config Class Initialized
INFO - 2021-04-29 05:56:43 --> Loader Class Initialized
INFO - 2021-04-29 05:56:43 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:43 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:43 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:43 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:43 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:43 --> Controller Class Initialized
INFO - 2021-04-29 05:56:43 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:43 --> Total execution time: 0.1464
INFO - 2021-04-29 05:56:45 --> Config Class Initialized
INFO - 2021-04-29 05:56:45 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:45 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:45 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:45 --> URI Class Initialized
INFO - 2021-04-29 05:56:46 --> Router Class Initialized
INFO - 2021-04-29 05:56:46 --> Output Class Initialized
INFO - 2021-04-29 05:56:46 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:46 --> Input Class Initialized
INFO - 2021-04-29 05:56:46 --> Language Class Initialized
INFO - 2021-04-29 05:56:46 --> Language Class Initialized
INFO - 2021-04-29 05:56:46 --> Config Class Initialized
INFO - 2021-04-29 05:56:46 --> Loader Class Initialized
INFO - 2021-04-29 05:56:46 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:46 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:46 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:46 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:46 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:46 --> Controller Class Initialized
INFO - 2021-04-29 05:56:46 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:46 --> Total execution time: 0.1103
INFO - 2021-04-29 05:56:47 --> Config Class Initialized
INFO - 2021-04-29 05:56:47 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:47 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:47 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:47 --> URI Class Initialized
INFO - 2021-04-29 05:56:47 --> Router Class Initialized
INFO - 2021-04-29 05:56:47 --> Output Class Initialized
INFO - 2021-04-29 05:56:47 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:47 --> Input Class Initialized
INFO - 2021-04-29 05:56:47 --> Language Class Initialized
INFO - 2021-04-29 05:56:47 --> Language Class Initialized
INFO - 2021-04-29 05:56:47 --> Config Class Initialized
INFO - 2021-04-29 05:56:47 --> Loader Class Initialized
INFO - 2021-04-29 05:56:47 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:47 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:47 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:47 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:47 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:47 --> Controller Class Initialized
INFO - 2021-04-29 05:56:47 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:47 --> Total execution time: 0.1723
INFO - 2021-04-29 05:56:48 --> Config Class Initialized
INFO - 2021-04-29 05:56:48 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:48 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:48 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:48 --> URI Class Initialized
INFO - 2021-04-29 05:56:48 --> Router Class Initialized
INFO - 2021-04-29 05:56:48 --> Output Class Initialized
INFO - 2021-04-29 05:56:48 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:48 --> Input Class Initialized
INFO - 2021-04-29 05:56:48 --> Language Class Initialized
INFO - 2021-04-29 05:56:48 --> Language Class Initialized
INFO - 2021-04-29 05:56:48 --> Config Class Initialized
INFO - 2021-04-29 05:56:48 --> Loader Class Initialized
INFO - 2021-04-29 05:56:48 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:48 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:48 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:48 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:48 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:48 --> Controller Class Initialized
INFO - 2021-04-29 05:56:48 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:48 --> Total execution time: 0.1203
INFO - 2021-04-29 05:56:53 --> Config Class Initialized
INFO - 2021-04-29 05:56:53 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:53 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:53 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:53 --> URI Class Initialized
INFO - 2021-04-29 05:56:53 --> Router Class Initialized
INFO - 2021-04-29 05:56:53 --> Output Class Initialized
INFO - 2021-04-29 05:56:53 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:53 --> Input Class Initialized
INFO - 2021-04-29 05:56:53 --> Language Class Initialized
INFO - 2021-04-29 05:56:53 --> Language Class Initialized
INFO - 2021-04-29 05:56:53 --> Config Class Initialized
INFO - 2021-04-29 05:56:53 --> Loader Class Initialized
INFO - 2021-04-29 05:56:53 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:53 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:53 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:53 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:53 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:53 --> Controller Class Initialized
DEBUG - 2021-04-29 05:56:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-29 05:56:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:56:53 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:53 --> Total execution time: 0.1136
INFO - 2021-04-29 05:56:55 --> Config Class Initialized
INFO - 2021-04-29 05:56:55 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:55 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:55 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:55 --> URI Class Initialized
INFO - 2021-04-29 05:56:55 --> Router Class Initialized
INFO - 2021-04-29 05:56:55 --> Output Class Initialized
INFO - 2021-04-29 05:56:55 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:55 --> Input Class Initialized
INFO - 2021-04-29 05:56:55 --> Language Class Initialized
INFO - 2021-04-29 05:56:55 --> Language Class Initialized
INFO - 2021-04-29 05:56:55 --> Config Class Initialized
INFO - 2021-04-29 05:56:55 --> Loader Class Initialized
INFO - 2021-04-29 05:56:55 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:55 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:55 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:55 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:55 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:55 --> Controller Class Initialized
DEBUG - 2021-04-29 05:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-04-29 05:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:56:55 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:55 --> Total execution time: 0.1508
INFO - 2021-04-29 05:56:57 --> Config Class Initialized
INFO - 2021-04-29 05:56:57 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:56:57 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:56:57 --> Utf8 Class Initialized
INFO - 2021-04-29 05:56:57 --> URI Class Initialized
INFO - 2021-04-29 05:56:57 --> Router Class Initialized
INFO - 2021-04-29 05:56:57 --> Output Class Initialized
INFO - 2021-04-29 05:56:57 --> Security Class Initialized
DEBUG - 2021-04-29 05:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:56:57 --> Input Class Initialized
INFO - 2021-04-29 05:56:57 --> Language Class Initialized
INFO - 2021-04-29 05:56:57 --> Language Class Initialized
INFO - 2021-04-29 05:56:57 --> Config Class Initialized
INFO - 2021-04-29 05:56:57 --> Loader Class Initialized
INFO - 2021-04-29 05:56:57 --> Helper loaded: url_helper
INFO - 2021-04-29 05:56:57 --> Helper loaded: file_helper
INFO - 2021-04-29 05:56:57 --> Helper loaded: form_helper
INFO - 2021-04-29 05:56:57 --> Helper loaded: my_helper
INFO - 2021-04-29 05:56:57 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:56:57 --> Controller Class Initialized
INFO - 2021-04-29 05:56:57 --> Final output sent to browser
DEBUG - 2021-04-29 05:56:57 --> Total execution time: 0.1468
INFO - 2021-04-29 05:57:09 --> Config Class Initialized
INFO - 2021-04-29 05:57:09 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:57:09 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:57:09 --> Utf8 Class Initialized
INFO - 2021-04-29 05:57:09 --> URI Class Initialized
INFO - 2021-04-29 05:57:09 --> Router Class Initialized
INFO - 2021-04-29 05:57:09 --> Output Class Initialized
INFO - 2021-04-29 05:57:09 --> Security Class Initialized
DEBUG - 2021-04-29 05:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:57:09 --> Input Class Initialized
INFO - 2021-04-29 05:57:09 --> Language Class Initialized
INFO - 2021-04-29 05:57:09 --> Language Class Initialized
INFO - 2021-04-29 05:57:09 --> Config Class Initialized
INFO - 2021-04-29 05:57:09 --> Loader Class Initialized
INFO - 2021-04-29 05:57:09 --> Helper loaded: url_helper
INFO - 2021-04-29 05:57:09 --> Helper loaded: file_helper
INFO - 2021-04-29 05:57:09 --> Helper loaded: form_helper
INFO - 2021-04-29 05:57:09 --> Helper loaded: my_helper
INFO - 2021-04-29 05:57:09 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:57:09 --> Controller Class Initialized
INFO - 2021-04-29 05:57:09 --> Final output sent to browser
DEBUG - 2021-04-29 05:57:09 --> Total execution time: 0.1359
INFO - 2021-04-29 05:57:10 --> Config Class Initialized
INFO - 2021-04-29 05:57:10 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:57:10 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:57:10 --> Utf8 Class Initialized
INFO - 2021-04-29 05:57:10 --> URI Class Initialized
INFO - 2021-04-29 05:57:10 --> Router Class Initialized
INFO - 2021-04-29 05:57:10 --> Output Class Initialized
INFO - 2021-04-29 05:57:10 --> Security Class Initialized
DEBUG - 2021-04-29 05:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:57:10 --> Input Class Initialized
INFO - 2021-04-29 05:57:10 --> Language Class Initialized
INFO - 2021-04-29 05:57:10 --> Language Class Initialized
INFO - 2021-04-29 05:57:10 --> Config Class Initialized
INFO - 2021-04-29 05:57:10 --> Loader Class Initialized
INFO - 2021-04-29 05:57:10 --> Helper loaded: url_helper
INFO - 2021-04-29 05:57:10 --> Helper loaded: file_helper
INFO - 2021-04-29 05:57:10 --> Helper loaded: form_helper
INFO - 2021-04-29 05:57:10 --> Helper loaded: my_helper
INFO - 2021-04-29 05:57:10 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:57:10 --> Controller Class Initialized
DEBUG - 2021-04-29 05:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-04-29 05:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:57:10 --> Final output sent to browser
DEBUG - 2021-04-29 05:57:10 --> Total execution time: 0.1658
INFO - 2021-04-29 05:57:12 --> Config Class Initialized
INFO - 2021-04-29 05:57:12 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:57:12 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:57:12 --> Utf8 Class Initialized
INFO - 2021-04-29 05:57:12 --> URI Class Initialized
INFO - 2021-04-29 05:57:12 --> Router Class Initialized
INFO - 2021-04-29 05:57:12 --> Output Class Initialized
INFO - 2021-04-29 05:57:12 --> Security Class Initialized
DEBUG - 2021-04-29 05:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:57:12 --> Input Class Initialized
INFO - 2021-04-29 05:57:12 --> Language Class Initialized
INFO - 2021-04-29 05:57:13 --> Language Class Initialized
INFO - 2021-04-29 05:57:13 --> Config Class Initialized
INFO - 2021-04-29 05:57:13 --> Loader Class Initialized
INFO - 2021-04-29 05:57:13 --> Helper loaded: url_helper
INFO - 2021-04-29 05:57:13 --> Helper loaded: file_helper
INFO - 2021-04-29 05:57:13 --> Helper loaded: form_helper
INFO - 2021-04-29 05:57:13 --> Helper loaded: my_helper
INFO - 2021-04-29 05:57:13 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:57:13 --> Controller Class Initialized
INFO - 2021-04-29 05:57:13 --> Final output sent to browser
DEBUG - 2021-04-29 05:57:13 --> Total execution time: 0.1298
INFO - 2021-04-29 05:57:20 --> Config Class Initialized
INFO - 2021-04-29 05:57:20 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:57:20 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:57:20 --> Utf8 Class Initialized
INFO - 2021-04-29 05:57:20 --> URI Class Initialized
INFO - 2021-04-29 05:57:20 --> Router Class Initialized
INFO - 2021-04-29 05:57:20 --> Output Class Initialized
INFO - 2021-04-29 05:57:20 --> Security Class Initialized
DEBUG - 2021-04-29 05:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:57:20 --> Input Class Initialized
INFO - 2021-04-29 05:57:20 --> Language Class Initialized
INFO - 2021-04-29 05:57:20 --> Language Class Initialized
INFO - 2021-04-29 05:57:20 --> Config Class Initialized
INFO - 2021-04-29 05:57:20 --> Loader Class Initialized
INFO - 2021-04-29 05:57:20 --> Helper loaded: url_helper
INFO - 2021-04-29 05:57:20 --> Helper loaded: file_helper
INFO - 2021-04-29 05:57:20 --> Helper loaded: form_helper
INFO - 2021-04-29 05:57:20 --> Helper loaded: my_helper
INFO - 2021-04-29 05:57:20 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:57:20 --> Controller Class Initialized
INFO - 2021-04-29 05:57:20 --> Final output sent to browser
DEBUG - 2021-04-29 05:57:20 --> Total execution time: 0.2106
INFO - 2021-04-29 05:57:23 --> Config Class Initialized
INFO - 2021-04-29 05:57:23 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:57:23 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:57:23 --> Utf8 Class Initialized
INFO - 2021-04-29 05:57:23 --> URI Class Initialized
INFO - 2021-04-29 05:57:23 --> Router Class Initialized
INFO - 2021-04-29 05:57:23 --> Output Class Initialized
INFO - 2021-04-29 05:57:23 --> Security Class Initialized
DEBUG - 2021-04-29 05:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:57:23 --> Input Class Initialized
INFO - 2021-04-29 05:57:23 --> Language Class Initialized
INFO - 2021-04-29 05:57:23 --> Language Class Initialized
INFO - 2021-04-29 05:57:23 --> Config Class Initialized
INFO - 2021-04-29 05:57:23 --> Loader Class Initialized
INFO - 2021-04-29 05:57:23 --> Helper loaded: url_helper
INFO - 2021-04-29 05:57:23 --> Helper loaded: file_helper
INFO - 2021-04-29 05:57:23 --> Helper loaded: form_helper
INFO - 2021-04-29 05:57:23 --> Helper loaded: my_helper
INFO - 2021-04-29 05:57:23 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:57:23 --> Controller Class Initialized
DEBUG - 2021-04-29 05:57:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-04-29 05:57:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:57:23 --> Final output sent to browser
DEBUG - 2021-04-29 05:57:23 --> Total execution time: 0.1664
INFO - 2021-04-29 05:57:24 --> Config Class Initialized
INFO - 2021-04-29 05:57:24 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:57:24 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:57:24 --> Utf8 Class Initialized
INFO - 2021-04-29 05:57:24 --> URI Class Initialized
INFO - 2021-04-29 05:57:24 --> Router Class Initialized
INFO - 2021-04-29 05:57:24 --> Output Class Initialized
INFO - 2021-04-29 05:57:24 --> Security Class Initialized
DEBUG - 2021-04-29 05:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:57:24 --> Input Class Initialized
INFO - 2021-04-29 05:57:24 --> Language Class Initialized
INFO - 2021-04-29 05:57:24 --> Language Class Initialized
INFO - 2021-04-29 05:57:24 --> Config Class Initialized
INFO - 2021-04-29 05:57:24 --> Loader Class Initialized
INFO - 2021-04-29 05:57:24 --> Helper loaded: url_helper
INFO - 2021-04-29 05:57:24 --> Helper loaded: file_helper
INFO - 2021-04-29 05:57:24 --> Helper loaded: form_helper
INFO - 2021-04-29 05:57:24 --> Helper loaded: my_helper
INFO - 2021-04-29 05:57:24 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:57:24 --> Controller Class Initialized
INFO - 2021-04-29 05:57:24 --> Final output sent to browser
DEBUG - 2021-04-29 05:57:24 --> Total execution time: 0.1320
INFO - 2021-04-29 05:57:34 --> Config Class Initialized
INFO - 2021-04-29 05:57:34 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:57:34 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:57:34 --> Utf8 Class Initialized
INFO - 2021-04-29 05:57:34 --> URI Class Initialized
INFO - 2021-04-29 05:57:34 --> Router Class Initialized
INFO - 2021-04-29 05:57:34 --> Output Class Initialized
INFO - 2021-04-29 05:57:34 --> Security Class Initialized
DEBUG - 2021-04-29 05:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:57:34 --> Input Class Initialized
INFO - 2021-04-29 05:57:34 --> Language Class Initialized
INFO - 2021-04-29 05:57:34 --> Language Class Initialized
INFO - 2021-04-29 05:57:34 --> Config Class Initialized
INFO - 2021-04-29 05:57:34 --> Loader Class Initialized
INFO - 2021-04-29 05:57:34 --> Helper loaded: url_helper
INFO - 2021-04-29 05:57:34 --> Helper loaded: file_helper
INFO - 2021-04-29 05:57:34 --> Helper loaded: form_helper
INFO - 2021-04-29 05:57:34 --> Helper loaded: my_helper
INFO - 2021-04-29 05:57:34 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:57:34 --> Controller Class Initialized
INFO - 2021-04-29 05:57:57 --> Config Class Initialized
INFO - 2021-04-29 05:57:57 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:57:57 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:57:57 --> Utf8 Class Initialized
INFO - 2021-04-29 05:57:57 --> URI Class Initialized
INFO - 2021-04-29 05:57:57 --> Router Class Initialized
INFO - 2021-04-29 05:57:57 --> Output Class Initialized
INFO - 2021-04-29 05:57:57 --> Security Class Initialized
DEBUG - 2021-04-29 05:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:57:57 --> Input Class Initialized
INFO - 2021-04-29 05:57:57 --> Language Class Initialized
INFO - 2021-04-29 05:57:57 --> Language Class Initialized
INFO - 2021-04-29 05:57:57 --> Config Class Initialized
INFO - 2021-04-29 05:57:57 --> Loader Class Initialized
INFO - 2021-04-29 05:57:57 --> Helper loaded: url_helper
INFO - 2021-04-29 05:57:57 --> Helper loaded: file_helper
INFO - 2021-04-29 05:57:57 --> Helper loaded: form_helper
INFO - 2021-04-29 05:57:57 --> Helper loaded: my_helper
INFO - 2021-04-29 05:57:57 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:57:57 --> Controller Class Initialized
DEBUG - 2021-04-29 05:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-04-29 05:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:57:57 --> Final output sent to browser
DEBUG - 2021-04-29 05:57:57 --> Total execution time: 0.1265
INFO - 2021-04-29 05:58:50 --> Config Class Initialized
INFO - 2021-04-29 05:58:50 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:58:50 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:58:50 --> Utf8 Class Initialized
INFO - 2021-04-29 05:58:50 --> URI Class Initialized
INFO - 2021-04-29 05:58:50 --> Router Class Initialized
INFO - 2021-04-29 05:58:50 --> Output Class Initialized
INFO - 2021-04-29 05:58:50 --> Security Class Initialized
DEBUG - 2021-04-29 05:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:58:50 --> Input Class Initialized
INFO - 2021-04-29 05:58:50 --> Language Class Initialized
INFO - 2021-04-29 05:58:50 --> Language Class Initialized
INFO - 2021-04-29 05:58:50 --> Config Class Initialized
INFO - 2021-04-29 05:58:50 --> Loader Class Initialized
INFO - 2021-04-29 05:58:50 --> Helper loaded: url_helper
INFO - 2021-04-29 05:58:50 --> Helper loaded: file_helper
INFO - 2021-04-29 05:58:50 --> Helper loaded: form_helper
INFO - 2021-04-29 05:58:50 --> Helper loaded: my_helper
INFO - 2021-04-29 05:58:50 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:58:50 --> Controller Class Initialized
INFO - 2021-04-29 05:58:50 --> Final output sent to browser
DEBUG - 2021-04-29 05:58:50 --> Total execution time: 0.1616
INFO - 2021-04-29 05:58:54 --> Config Class Initialized
INFO - 2021-04-29 05:58:54 --> Hooks Class Initialized
DEBUG - 2021-04-29 05:58:54 --> UTF-8 Support Enabled
INFO - 2021-04-29 05:58:54 --> Utf8 Class Initialized
INFO - 2021-04-29 05:58:54 --> URI Class Initialized
INFO - 2021-04-29 05:58:54 --> Router Class Initialized
INFO - 2021-04-29 05:58:54 --> Output Class Initialized
INFO - 2021-04-29 05:58:54 --> Security Class Initialized
DEBUG - 2021-04-29 05:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 05:58:54 --> Input Class Initialized
INFO - 2021-04-29 05:58:54 --> Language Class Initialized
INFO - 2021-04-29 05:58:54 --> Language Class Initialized
INFO - 2021-04-29 05:58:54 --> Config Class Initialized
INFO - 2021-04-29 05:58:54 --> Loader Class Initialized
INFO - 2021-04-29 05:58:54 --> Helper loaded: url_helper
INFO - 2021-04-29 05:58:54 --> Helper loaded: file_helper
INFO - 2021-04-29 05:58:54 --> Helper loaded: form_helper
INFO - 2021-04-29 05:58:54 --> Helper loaded: my_helper
INFO - 2021-04-29 05:58:54 --> Database Driver Class Initialized
DEBUG - 2021-04-29 05:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 05:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 05:58:54 --> Controller Class Initialized
DEBUG - 2021-04-29 05:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-04-29 05:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 05:58:54 --> Final output sent to browser
DEBUG - 2021-04-29 05:58:54 --> Total execution time: 0.1488
INFO - 2021-04-29 06:00:49 --> Config Class Initialized
INFO - 2021-04-29 06:00:49 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:00:49 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:00:49 --> Utf8 Class Initialized
INFO - 2021-04-29 06:00:49 --> URI Class Initialized
INFO - 2021-04-29 06:00:49 --> Router Class Initialized
INFO - 2021-04-29 06:00:49 --> Output Class Initialized
INFO - 2021-04-29 06:00:49 --> Security Class Initialized
DEBUG - 2021-04-29 06:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:00:49 --> Input Class Initialized
INFO - 2021-04-29 06:00:49 --> Language Class Initialized
INFO - 2021-04-29 06:00:49 --> Language Class Initialized
INFO - 2021-04-29 06:00:49 --> Config Class Initialized
INFO - 2021-04-29 06:00:49 --> Loader Class Initialized
INFO - 2021-04-29 06:00:49 --> Helper loaded: url_helper
INFO - 2021-04-29 06:00:49 --> Helper loaded: file_helper
INFO - 2021-04-29 06:00:49 --> Helper loaded: form_helper
INFO - 2021-04-29 06:00:49 --> Helper loaded: my_helper
INFO - 2021-04-29 06:00:49 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:00:49 --> Controller Class Initialized
INFO - 2021-04-29 06:00:49 --> Final output sent to browser
DEBUG - 2021-04-29 06:00:49 --> Total execution time: 0.1417
INFO - 2021-04-29 06:00:52 --> Config Class Initialized
INFO - 2021-04-29 06:00:52 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:00:52 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:00:52 --> Utf8 Class Initialized
INFO - 2021-04-29 06:00:52 --> URI Class Initialized
INFO - 2021-04-29 06:00:52 --> Router Class Initialized
INFO - 2021-04-29 06:00:52 --> Output Class Initialized
INFO - 2021-04-29 06:00:52 --> Security Class Initialized
DEBUG - 2021-04-29 06:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:00:52 --> Input Class Initialized
INFO - 2021-04-29 06:00:52 --> Language Class Initialized
INFO - 2021-04-29 06:00:52 --> Language Class Initialized
INFO - 2021-04-29 06:00:52 --> Config Class Initialized
INFO - 2021-04-29 06:00:52 --> Loader Class Initialized
INFO - 2021-04-29 06:00:52 --> Helper loaded: url_helper
INFO - 2021-04-29 06:00:52 --> Helper loaded: file_helper
INFO - 2021-04-29 06:00:52 --> Helper loaded: form_helper
INFO - 2021-04-29 06:00:52 --> Helper loaded: my_helper
INFO - 2021-04-29 06:00:52 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:00:52 --> Controller Class Initialized
DEBUG - 2021-04-29 06:00:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-04-29 06:00:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 06:00:52 --> Final output sent to browser
DEBUG - 2021-04-29 06:00:52 --> Total execution time: 0.0817
INFO - 2021-04-29 06:00:55 --> Config Class Initialized
INFO - 2021-04-29 06:00:55 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:00:55 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:00:55 --> Utf8 Class Initialized
INFO - 2021-04-29 06:00:55 --> URI Class Initialized
INFO - 2021-04-29 06:00:55 --> Router Class Initialized
INFO - 2021-04-29 06:00:55 --> Output Class Initialized
INFO - 2021-04-29 06:00:55 --> Security Class Initialized
DEBUG - 2021-04-29 06:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:00:55 --> Input Class Initialized
INFO - 2021-04-29 06:00:55 --> Language Class Initialized
INFO - 2021-04-29 06:00:55 --> Language Class Initialized
INFO - 2021-04-29 06:00:55 --> Config Class Initialized
INFO - 2021-04-29 06:00:55 --> Loader Class Initialized
INFO - 2021-04-29 06:00:55 --> Helper loaded: url_helper
INFO - 2021-04-29 06:00:55 --> Helper loaded: file_helper
INFO - 2021-04-29 06:00:55 --> Helper loaded: form_helper
INFO - 2021-04-29 06:00:55 --> Helper loaded: my_helper
INFO - 2021-04-29 06:00:55 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:00:55 --> Controller Class Initialized
DEBUG - 2021-04-29 06:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-04-29 06:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 06:00:55 --> Final output sent to browser
DEBUG - 2021-04-29 06:00:55 --> Total execution time: 0.1408
INFO - 2021-04-29 06:00:57 --> Config Class Initialized
INFO - 2021-04-29 06:00:57 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:00:57 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:00:57 --> Utf8 Class Initialized
INFO - 2021-04-29 06:00:57 --> URI Class Initialized
INFO - 2021-04-29 06:00:57 --> Router Class Initialized
INFO - 2021-04-29 06:00:57 --> Output Class Initialized
INFO - 2021-04-29 06:00:57 --> Security Class Initialized
DEBUG - 2021-04-29 06:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:00:57 --> Input Class Initialized
INFO - 2021-04-29 06:00:57 --> Language Class Initialized
INFO - 2021-04-29 06:00:57 --> Language Class Initialized
INFO - 2021-04-29 06:00:57 --> Config Class Initialized
INFO - 2021-04-29 06:00:57 --> Loader Class Initialized
INFO - 2021-04-29 06:00:57 --> Helper loaded: url_helper
INFO - 2021-04-29 06:00:57 --> Helper loaded: file_helper
INFO - 2021-04-29 06:00:57 --> Helper loaded: form_helper
INFO - 2021-04-29 06:00:57 --> Helper loaded: my_helper
INFO - 2021-04-29 06:00:57 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:00:57 --> Controller Class Initialized
INFO - 2021-04-29 06:00:57 --> Final output sent to browser
DEBUG - 2021-04-29 06:00:57 --> Total execution time: 0.1369
INFO - 2021-04-29 06:01:09 --> Config Class Initialized
INFO - 2021-04-29 06:01:09 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:01:09 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:01:09 --> Utf8 Class Initialized
INFO - 2021-04-29 06:01:09 --> URI Class Initialized
INFO - 2021-04-29 06:01:09 --> Router Class Initialized
INFO - 2021-04-29 06:01:09 --> Output Class Initialized
INFO - 2021-04-29 06:01:09 --> Security Class Initialized
DEBUG - 2021-04-29 06:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:01:09 --> Input Class Initialized
INFO - 2021-04-29 06:01:09 --> Language Class Initialized
INFO - 2021-04-29 06:01:09 --> Language Class Initialized
INFO - 2021-04-29 06:01:09 --> Config Class Initialized
INFO - 2021-04-29 06:01:09 --> Loader Class Initialized
INFO - 2021-04-29 06:01:09 --> Helper loaded: url_helper
INFO - 2021-04-29 06:01:09 --> Helper loaded: file_helper
INFO - 2021-04-29 06:01:09 --> Helper loaded: form_helper
INFO - 2021-04-29 06:01:09 --> Helper loaded: my_helper
INFO - 2021-04-29 06:01:09 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:01:09 --> Controller Class Initialized
INFO - 2021-04-29 06:01:09 --> Final output sent to browser
DEBUG - 2021-04-29 06:01:09 --> Total execution time: 0.2015
INFO - 2021-04-29 06:01:13 --> Config Class Initialized
INFO - 2021-04-29 06:01:13 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:01:13 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:01:13 --> Utf8 Class Initialized
INFO - 2021-04-29 06:01:13 --> URI Class Initialized
INFO - 2021-04-29 06:01:13 --> Router Class Initialized
INFO - 2021-04-29 06:01:13 --> Output Class Initialized
INFO - 2021-04-29 06:01:13 --> Security Class Initialized
DEBUG - 2021-04-29 06:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:01:13 --> Input Class Initialized
INFO - 2021-04-29 06:01:13 --> Language Class Initialized
INFO - 2021-04-29 06:01:13 --> Language Class Initialized
INFO - 2021-04-29 06:01:13 --> Config Class Initialized
INFO - 2021-04-29 06:01:13 --> Loader Class Initialized
INFO - 2021-04-29 06:01:13 --> Helper loaded: url_helper
INFO - 2021-04-29 06:01:13 --> Helper loaded: file_helper
INFO - 2021-04-29 06:01:13 --> Helper loaded: form_helper
INFO - 2021-04-29 06:01:13 --> Helper loaded: my_helper
INFO - 2021-04-29 06:01:13 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:01:13 --> Controller Class Initialized
DEBUG - 2021-04-29 06:01:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-04-29 06:01:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 06:01:13 --> Final output sent to browser
DEBUG - 2021-04-29 06:01:13 --> Total execution time: 0.1566
INFO - 2021-04-29 06:01:15 --> Config Class Initialized
INFO - 2021-04-29 06:01:15 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:01:15 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:01:15 --> Utf8 Class Initialized
INFO - 2021-04-29 06:01:15 --> URI Class Initialized
INFO - 2021-04-29 06:01:15 --> Router Class Initialized
INFO - 2021-04-29 06:01:15 --> Output Class Initialized
INFO - 2021-04-29 06:01:15 --> Security Class Initialized
DEBUG - 2021-04-29 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:01:15 --> Input Class Initialized
INFO - 2021-04-29 06:01:15 --> Language Class Initialized
INFO - 2021-04-29 06:01:15 --> Language Class Initialized
INFO - 2021-04-29 06:01:15 --> Config Class Initialized
INFO - 2021-04-29 06:01:15 --> Loader Class Initialized
INFO - 2021-04-29 06:01:15 --> Helper loaded: url_helper
INFO - 2021-04-29 06:01:15 --> Helper loaded: file_helper
INFO - 2021-04-29 06:01:15 --> Helper loaded: form_helper
INFO - 2021-04-29 06:01:15 --> Helper loaded: my_helper
INFO - 2021-04-29 06:01:15 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:01:15 --> Controller Class Initialized
DEBUG - 2021-04-29 06:01:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-04-29 06:01:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 06:01:15 --> Final output sent to browser
DEBUG - 2021-04-29 06:01:15 --> Total execution time: 0.1694
INFO - 2021-04-29 06:01:29 --> Config Class Initialized
INFO - 2021-04-29 06:01:29 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:01:29 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:01:29 --> Utf8 Class Initialized
INFO - 2021-04-29 06:01:29 --> URI Class Initialized
INFO - 2021-04-29 06:01:29 --> Router Class Initialized
INFO - 2021-04-29 06:01:29 --> Output Class Initialized
INFO - 2021-04-29 06:01:29 --> Security Class Initialized
DEBUG - 2021-04-29 06:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:01:29 --> Input Class Initialized
INFO - 2021-04-29 06:01:29 --> Language Class Initialized
INFO - 2021-04-29 06:01:29 --> Language Class Initialized
INFO - 2021-04-29 06:01:29 --> Config Class Initialized
INFO - 2021-04-29 06:01:29 --> Loader Class Initialized
INFO - 2021-04-29 06:01:29 --> Helper loaded: url_helper
INFO - 2021-04-29 06:01:29 --> Helper loaded: file_helper
INFO - 2021-04-29 06:01:29 --> Helper loaded: form_helper
INFO - 2021-04-29 06:01:29 --> Helper loaded: my_helper
INFO - 2021-04-29 06:01:29 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:01:29 --> Controller Class Initialized
INFO - 2021-04-29 06:01:29 --> Final output sent to browser
DEBUG - 2021-04-29 06:01:29 --> Total execution time: 0.1805
INFO - 2021-04-29 06:01:33 --> Config Class Initialized
INFO - 2021-04-29 06:01:33 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:01:33 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:01:33 --> Utf8 Class Initialized
INFO - 2021-04-29 06:01:33 --> URI Class Initialized
INFO - 2021-04-29 06:01:33 --> Router Class Initialized
INFO - 2021-04-29 06:01:33 --> Output Class Initialized
INFO - 2021-04-29 06:01:33 --> Security Class Initialized
DEBUG - 2021-04-29 06:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:01:33 --> Input Class Initialized
INFO - 2021-04-29 06:01:33 --> Language Class Initialized
INFO - 2021-04-29 06:01:33 --> Language Class Initialized
INFO - 2021-04-29 06:01:33 --> Config Class Initialized
INFO - 2021-04-29 06:01:33 --> Loader Class Initialized
INFO - 2021-04-29 06:01:33 --> Helper loaded: url_helper
INFO - 2021-04-29 06:01:33 --> Helper loaded: file_helper
INFO - 2021-04-29 06:01:33 --> Helper loaded: form_helper
INFO - 2021-04-29 06:01:33 --> Helper loaded: my_helper
INFO - 2021-04-29 06:01:33 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:01:33 --> Controller Class Initialized
DEBUG - 2021-04-29 06:01:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-04-29 06:01:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-29 06:01:33 --> Final output sent to browser
DEBUG - 2021-04-29 06:01:33 --> Total execution time: 0.1776
INFO - 2021-04-29 06:01:36 --> Config Class Initialized
INFO - 2021-04-29 06:01:36 --> Hooks Class Initialized
DEBUG - 2021-04-29 06:01:36 --> UTF-8 Support Enabled
INFO - 2021-04-29 06:01:36 --> Utf8 Class Initialized
INFO - 2021-04-29 06:01:36 --> URI Class Initialized
INFO - 2021-04-29 06:01:36 --> Router Class Initialized
INFO - 2021-04-29 06:01:36 --> Output Class Initialized
INFO - 2021-04-29 06:01:36 --> Security Class Initialized
DEBUG - 2021-04-29 06:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-29 06:01:36 --> Input Class Initialized
INFO - 2021-04-29 06:01:36 --> Language Class Initialized
INFO - 2021-04-29 06:01:37 --> Language Class Initialized
INFO - 2021-04-29 06:01:37 --> Config Class Initialized
INFO - 2021-04-29 06:01:37 --> Loader Class Initialized
INFO - 2021-04-29 06:01:37 --> Helper loaded: url_helper
INFO - 2021-04-29 06:01:37 --> Helper loaded: file_helper
INFO - 2021-04-29 06:01:37 --> Helper loaded: form_helper
INFO - 2021-04-29 06:01:37 --> Helper loaded: my_helper
INFO - 2021-04-29 06:01:37 --> Database Driver Class Initialized
DEBUG - 2021-04-29 06:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-29 06:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-29 06:01:37 --> Controller Class Initialized
DEBUG - 2021-04-29 06:01:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-04-29 06:01:37 --> Final output sent to browser
DEBUG - 2021-04-29 06:01:37 --> Total execution time: 0.1419
