<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-29 01:49:41 --> Config Class Initialized
INFO - 2021-12-29 01:49:41 --> Hooks Class Initialized
DEBUG - 2021-12-29 01:49:41 --> UTF-8 Support Enabled
INFO - 2021-12-29 01:49:41 --> Utf8 Class Initialized
INFO - 2021-12-29 01:49:41 --> URI Class Initialized
DEBUG - 2021-12-29 01:49:41 --> No URI present. Default controller set.
INFO - 2021-12-29 01:49:41 --> Router Class Initialized
INFO - 2021-12-29 01:49:41 --> Output Class Initialized
INFO - 2021-12-29 01:49:41 --> Security Class Initialized
DEBUG - 2021-12-29 01:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 01:49:41 --> Input Class Initialized
INFO - 2021-12-29 01:49:41 --> Language Class Initialized
INFO - 2021-12-29 01:49:41 --> Language Class Initialized
INFO - 2021-12-29 01:49:41 --> Config Class Initialized
INFO - 2021-12-29 01:49:41 --> Loader Class Initialized
INFO - 2021-12-29 01:49:41 --> Helper loaded: url_helper
INFO - 2021-12-29 01:49:41 --> Helper loaded: file_helper
INFO - 2021-12-29 01:49:41 --> Helper loaded: form_helper
INFO - 2021-12-29 01:49:41 --> Helper loaded: my_helper
INFO - 2021-12-29 01:49:41 --> Database Driver Class Initialized
DEBUG - 2021-12-29 01:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 01:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 01:49:41 --> Controller Class Initialized
INFO - 2021-12-29 01:49:41 --> Config Class Initialized
INFO - 2021-12-29 01:49:41 --> Hooks Class Initialized
DEBUG - 2021-12-29 01:49:41 --> UTF-8 Support Enabled
INFO - 2021-12-29 01:49:41 --> Utf8 Class Initialized
INFO - 2021-12-29 01:49:41 --> URI Class Initialized
INFO - 2021-12-29 01:49:41 --> Router Class Initialized
INFO - 2021-12-29 01:49:41 --> Output Class Initialized
INFO - 2021-12-29 01:49:41 --> Security Class Initialized
DEBUG - 2021-12-29 01:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 01:49:41 --> Input Class Initialized
INFO - 2021-12-29 01:49:41 --> Language Class Initialized
INFO - 2021-12-29 01:49:41 --> Language Class Initialized
INFO - 2021-12-29 01:49:41 --> Config Class Initialized
INFO - 2021-12-29 01:49:41 --> Loader Class Initialized
INFO - 2021-12-29 01:49:41 --> Helper loaded: url_helper
INFO - 2021-12-29 01:49:41 --> Helper loaded: file_helper
INFO - 2021-12-29 01:49:41 --> Helper loaded: form_helper
INFO - 2021-12-29 01:49:41 --> Helper loaded: my_helper
INFO - 2021-12-29 01:49:41 --> Database Driver Class Initialized
DEBUG - 2021-12-29 01:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 01:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 01:49:41 --> Controller Class Initialized
DEBUG - 2021-12-29 01:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-29 01:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 01:49:41 --> Final output sent to browser
DEBUG - 2021-12-29 01:49:41 --> Total execution time: 0.0420
INFO - 2021-12-29 01:50:45 --> Config Class Initialized
INFO - 2021-12-29 01:50:45 --> Hooks Class Initialized
DEBUG - 2021-12-29 01:50:45 --> UTF-8 Support Enabled
INFO - 2021-12-29 01:50:45 --> Utf8 Class Initialized
INFO - 2021-12-29 01:50:45 --> URI Class Initialized
INFO - 2021-12-29 01:50:45 --> Router Class Initialized
INFO - 2021-12-29 01:50:45 --> Output Class Initialized
INFO - 2021-12-29 01:50:45 --> Security Class Initialized
DEBUG - 2021-12-29 01:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 01:50:45 --> Input Class Initialized
INFO - 2021-12-29 01:50:45 --> Language Class Initialized
INFO - 2021-12-29 01:50:45 --> Language Class Initialized
INFO - 2021-12-29 01:50:45 --> Config Class Initialized
INFO - 2021-12-29 01:50:45 --> Loader Class Initialized
INFO - 2021-12-29 01:50:45 --> Helper loaded: url_helper
INFO - 2021-12-29 01:50:45 --> Helper loaded: file_helper
INFO - 2021-12-29 01:50:45 --> Helper loaded: form_helper
INFO - 2021-12-29 01:50:45 --> Helper loaded: my_helper
INFO - 2021-12-29 01:50:45 --> Database Driver Class Initialized
DEBUG - 2021-12-29 01:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 01:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 01:50:45 --> Controller Class Initialized
INFO - 2021-12-29 01:50:45 --> Helper loaded: cookie_helper
INFO - 2021-12-29 01:50:45 --> Final output sent to browser
DEBUG - 2021-12-29 01:50:45 --> Total execution time: 0.0620
INFO - 2021-12-29 01:50:45 --> Config Class Initialized
INFO - 2021-12-29 01:50:45 --> Hooks Class Initialized
DEBUG - 2021-12-29 01:50:45 --> UTF-8 Support Enabled
INFO - 2021-12-29 01:50:45 --> Utf8 Class Initialized
INFO - 2021-12-29 01:50:45 --> URI Class Initialized
INFO - 2021-12-29 01:50:45 --> Router Class Initialized
INFO - 2021-12-29 01:50:45 --> Output Class Initialized
INFO - 2021-12-29 01:50:45 --> Security Class Initialized
DEBUG - 2021-12-29 01:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 01:50:45 --> Input Class Initialized
INFO - 2021-12-29 01:50:45 --> Language Class Initialized
INFO - 2021-12-29 01:50:45 --> Language Class Initialized
INFO - 2021-12-29 01:50:45 --> Config Class Initialized
INFO - 2021-12-29 01:50:45 --> Loader Class Initialized
INFO - 2021-12-29 01:50:45 --> Helper loaded: url_helper
INFO - 2021-12-29 01:50:45 --> Helper loaded: file_helper
INFO - 2021-12-29 01:50:45 --> Helper loaded: form_helper
INFO - 2021-12-29 01:50:45 --> Helper loaded: my_helper
INFO - 2021-12-29 01:50:45 --> Database Driver Class Initialized
DEBUG - 2021-12-29 01:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 01:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 01:50:45 --> Controller Class Initialized
DEBUG - 2021-12-29 01:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-29 01:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 01:50:45 --> Final output sent to browser
DEBUG - 2021-12-29 01:50:45 --> Total execution time: 0.2580
INFO - 2021-12-29 01:50:51 --> Config Class Initialized
INFO - 2021-12-29 01:50:51 --> Hooks Class Initialized
DEBUG - 2021-12-29 01:50:51 --> UTF-8 Support Enabled
INFO - 2021-12-29 01:50:51 --> Utf8 Class Initialized
INFO - 2021-12-29 01:50:51 --> URI Class Initialized
INFO - 2021-12-29 01:50:51 --> Router Class Initialized
INFO - 2021-12-29 01:50:51 --> Output Class Initialized
INFO - 2021-12-29 01:50:51 --> Security Class Initialized
DEBUG - 2021-12-29 01:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 01:50:51 --> Input Class Initialized
INFO - 2021-12-29 01:50:51 --> Language Class Initialized
INFO - 2021-12-29 01:50:51 --> Language Class Initialized
INFO - 2021-12-29 01:50:51 --> Config Class Initialized
INFO - 2021-12-29 01:50:51 --> Loader Class Initialized
INFO - 2021-12-29 01:50:51 --> Helper loaded: url_helper
INFO - 2021-12-29 01:50:51 --> Helper loaded: file_helper
INFO - 2021-12-29 01:50:51 --> Helper loaded: form_helper
INFO - 2021-12-29 01:50:51 --> Helper loaded: my_helper
INFO - 2021-12-29 01:50:51 --> Database Driver Class Initialized
DEBUG - 2021-12-29 01:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 01:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 01:50:51 --> Controller Class Initialized
DEBUG - 2021-12-29 01:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-29 01:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 01:50:51 --> Final output sent to browser
DEBUG - 2021-12-29 01:50:51 --> Total execution time: 0.1270
INFO - 2021-12-29 01:50:57 --> Config Class Initialized
INFO - 2021-12-29 01:50:57 --> Hooks Class Initialized
DEBUG - 2021-12-29 01:50:57 --> UTF-8 Support Enabled
INFO - 2021-12-29 01:50:57 --> Utf8 Class Initialized
INFO - 2021-12-29 01:50:57 --> URI Class Initialized
INFO - 2021-12-29 01:50:57 --> Router Class Initialized
INFO - 2021-12-29 01:50:57 --> Output Class Initialized
INFO - 2021-12-29 01:50:57 --> Security Class Initialized
DEBUG - 2021-12-29 01:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 01:50:57 --> Input Class Initialized
INFO - 2021-12-29 01:50:57 --> Language Class Initialized
INFO - 2021-12-29 01:50:57 --> Language Class Initialized
INFO - 2021-12-29 01:50:57 --> Config Class Initialized
INFO - 2021-12-29 01:50:57 --> Loader Class Initialized
INFO - 2021-12-29 01:50:57 --> Helper loaded: url_helper
INFO - 2021-12-29 01:50:57 --> Helper loaded: file_helper
INFO - 2021-12-29 01:50:57 --> Helper loaded: form_helper
INFO - 2021-12-29 01:50:57 --> Helper loaded: my_helper
INFO - 2021-12-29 01:50:57 --> Database Driver Class Initialized
DEBUG - 2021-12-29 01:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 01:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 01:50:57 --> Controller Class Initialized
DEBUG - 2021-12-29 01:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-29 01:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 01:50:58 --> Final output sent to browser
DEBUG - 2021-12-29 01:50:58 --> Total execution time: 0.0770
INFO - 2021-12-29 01:51:02 --> Config Class Initialized
INFO - 2021-12-29 01:51:02 --> Hooks Class Initialized
DEBUG - 2021-12-29 01:51:02 --> UTF-8 Support Enabled
INFO - 2021-12-29 01:51:02 --> Utf8 Class Initialized
INFO - 2021-12-29 01:51:02 --> URI Class Initialized
INFO - 2021-12-29 01:51:02 --> Router Class Initialized
INFO - 2021-12-29 01:51:02 --> Output Class Initialized
INFO - 2021-12-29 01:51:02 --> Security Class Initialized
DEBUG - 2021-12-29 01:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 01:51:02 --> Input Class Initialized
INFO - 2021-12-29 01:51:02 --> Language Class Initialized
INFO - 2021-12-29 01:51:02 --> Language Class Initialized
INFO - 2021-12-29 01:51:02 --> Config Class Initialized
INFO - 2021-12-29 01:51:02 --> Loader Class Initialized
INFO - 2021-12-29 01:51:02 --> Helper loaded: url_helper
INFO - 2021-12-29 01:51:02 --> Helper loaded: file_helper
INFO - 2021-12-29 01:51:02 --> Helper loaded: form_helper
INFO - 2021-12-29 01:51:02 --> Helper loaded: my_helper
INFO - 2021-12-29 01:51:02 --> Database Driver Class Initialized
DEBUG - 2021-12-29 01:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 01:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 01:51:02 --> Controller Class Initialized
DEBUG - 2021-12-29 01:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-29 01:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 01:51:02 --> Final output sent to browser
DEBUG - 2021-12-29 01:51:02 --> Total execution time: 0.0760
INFO - 2021-12-29 01:58:44 --> Config Class Initialized
INFO - 2021-12-29 01:58:44 --> Hooks Class Initialized
DEBUG - 2021-12-29 01:58:44 --> UTF-8 Support Enabled
INFO - 2021-12-29 01:58:44 --> Utf8 Class Initialized
INFO - 2021-12-29 01:58:44 --> URI Class Initialized
INFO - 2021-12-29 01:58:44 --> Router Class Initialized
INFO - 2021-12-29 01:58:44 --> Output Class Initialized
INFO - 2021-12-29 01:58:44 --> Security Class Initialized
DEBUG - 2021-12-29 01:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 01:58:44 --> Input Class Initialized
INFO - 2021-12-29 01:58:44 --> Language Class Initialized
INFO - 2021-12-29 01:58:44 --> Language Class Initialized
INFO - 2021-12-29 01:58:44 --> Config Class Initialized
INFO - 2021-12-29 01:58:44 --> Loader Class Initialized
INFO - 2021-12-29 01:58:44 --> Helper loaded: url_helper
INFO - 2021-12-29 01:58:44 --> Helper loaded: file_helper
INFO - 2021-12-29 01:58:44 --> Helper loaded: form_helper
INFO - 2021-12-29 01:58:44 --> Helper loaded: my_helper
INFO - 2021-12-29 01:58:44 --> Database Driver Class Initialized
DEBUG - 2021-12-29 01:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 01:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 01:58:44 --> Controller Class Initialized
DEBUG - 2021-12-29 01:58:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-29 01:58:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 01:58:44 --> Final output sent to browser
DEBUG - 2021-12-29 01:58:44 --> Total execution time: 0.0790
INFO - 2021-12-29 02:12:34 --> Config Class Initialized
INFO - 2021-12-29 02:12:34 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:34 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:34 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:34 --> URI Class Initialized
INFO - 2021-12-29 02:12:34 --> Router Class Initialized
INFO - 2021-12-29 02:12:34 --> Output Class Initialized
INFO - 2021-12-29 02:12:34 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:34 --> Input Class Initialized
INFO - 2021-12-29 02:12:34 --> Language Class Initialized
INFO - 2021-12-29 02:12:34 --> Language Class Initialized
INFO - 2021-12-29 02:12:34 --> Config Class Initialized
INFO - 2021-12-29 02:12:34 --> Loader Class Initialized
INFO - 2021-12-29 02:12:34 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:34 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:34 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:34 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:34 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:34 --> Controller Class Initialized
INFO - 2021-12-29 02:12:34 --> Helper loaded: cookie_helper
INFO - 2021-12-29 02:12:34 --> Config Class Initialized
INFO - 2021-12-29 02:12:34 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:34 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:34 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:34 --> URI Class Initialized
INFO - 2021-12-29 02:12:34 --> Router Class Initialized
INFO - 2021-12-29 02:12:34 --> Output Class Initialized
INFO - 2021-12-29 02:12:34 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:34 --> Input Class Initialized
INFO - 2021-12-29 02:12:34 --> Language Class Initialized
INFO - 2021-12-29 02:12:34 --> Language Class Initialized
INFO - 2021-12-29 02:12:34 --> Config Class Initialized
INFO - 2021-12-29 02:12:34 --> Loader Class Initialized
INFO - 2021-12-29 02:12:34 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:34 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:34 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:34 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:34 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:34 --> Controller Class Initialized
DEBUG - 2021-12-29 02:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-29 02:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:12:34 --> Final output sent to browser
DEBUG - 2021-12-29 02:12:34 --> Total execution time: 0.0350
INFO - 2021-12-29 02:12:38 --> Config Class Initialized
INFO - 2021-12-29 02:12:38 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:38 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:38 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:38 --> URI Class Initialized
INFO - 2021-12-29 02:12:38 --> Router Class Initialized
INFO - 2021-12-29 02:12:38 --> Output Class Initialized
INFO - 2021-12-29 02:12:38 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:38 --> Input Class Initialized
INFO - 2021-12-29 02:12:38 --> Language Class Initialized
INFO - 2021-12-29 02:12:38 --> Language Class Initialized
INFO - 2021-12-29 02:12:38 --> Config Class Initialized
INFO - 2021-12-29 02:12:38 --> Loader Class Initialized
INFO - 2021-12-29 02:12:38 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:38 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:38 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:38 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:38 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:38 --> Controller Class Initialized
INFO - 2021-12-29 02:12:38 --> Helper loaded: cookie_helper
INFO - 2021-12-29 02:12:38 --> Final output sent to browser
DEBUG - 2021-12-29 02:12:38 --> Total execution time: 0.0440
INFO - 2021-12-29 02:12:38 --> Config Class Initialized
INFO - 2021-12-29 02:12:38 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:38 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:38 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:38 --> URI Class Initialized
INFO - 2021-12-29 02:12:38 --> Router Class Initialized
INFO - 2021-12-29 02:12:38 --> Output Class Initialized
INFO - 2021-12-29 02:12:38 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:38 --> Input Class Initialized
INFO - 2021-12-29 02:12:38 --> Language Class Initialized
INFO - 2021-12-29 02:12:38 --> Language Class Initialized
INFO - 2021-12-29 02:12:38 --> Config Class Initialized
INFO - 2021-12-29 02:12:38 --> Loader Class Initialized
INFO - 2021-12-29 02:12:38 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:38 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:38 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:38 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:38 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:38 --> Controller Class Initialized
DEBUG - 2021-12-29 02:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-29 02:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:12:38 --> Final output sent to browser
DEBUG - 2021-12-29 02:12:38 --> Total execution time: 0.2530
INFO - 2021-12-29 02:12:40 --> Config Class Initialized
INFO - 2021-12-29 02:12:40 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:40 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:40 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:40 --> URI Class Initialized
INFO - 2021-12-29 02:12:40 --> Router Class Initialized
INFO - 2021-12-29 02:12:40 --> Output Class Initialized
INFO - 2021-12-29 02:12:40 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:40 --> Input Class Initialized
INFO - 2021-12-29 02:12:40 --> Language Class Initialized
INFO - 2021-12-29 02:12:40 --> Language Class Initialized
INFO - 2021-12-29 02:12:40 --> Config Class Initialized
INFO - 2021-12-29 02:12:40 --> Loader Class Initialized
INFO - 2021-12-29 02:12:40 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:40 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:40 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:40 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:40 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:40 --> Controller Class Initialized
DEBUG - 2021-12-29 02:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-12-29 02:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:12:40 --> Final output sent to browser
DEBUG - 2021-12-29 02:12:40 --> Total execution time: 0.0470
INFO - 2021-12-29 02:12:40 --> Config Class Initialized
INFO - 2021-12-29 02:12:40 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:40 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:40 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:40 --> URI Class Initialized
INFO - 2021-12-29 02:12:40 --> Router Class Initialized
INFO - 2021-12-29 02:12:40 --> Output Class Initialized
INFO - 2021-12-29 02:12:40 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:40 --> Input Class Initialized
INFO - 2021-12-29 02:12:40 --> Language Class Initialized
INFO - 2021-12-29 02:12:40 --> Language Class Initialized
INFO - 2021-12-29 02:12:40 --> Config Class Initialized
INFO - 2021-12-29 02:12:40 --> Loader Class Initialized
INFO - 2021-12-29 02:12:40 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:40 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:40 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:40 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:40 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:40 --> Controller Class Initialized
INFO - 2021-12-29 02:12:43 --> Config Class Initialized
INFO - 2021-12-29 02:12:43 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:43 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:43 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:43 --> URI Class Initialized
INFO - 2021-12-29 02:12:43 --> Router Class Initialized
INFO - 2021-12-29 02:12:43 --> Output Class Initialized
INFO - 2021-12-29 02:12:43 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:43 --> Input Class Initialized
INFO - 2021-12-29 02:12:43 --> Language Class Initialized
INFO - 2021-12-29 02:12:43 --> Language Class Initialized
INFO - 2021-12-29 02:12:43 --> Config Class Initialized
INFO - 2021-12-29 02:12:43 --> Loader Class Initialized
INFO - 2021-12-29 02:12:43 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:43 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:43 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:43 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:43 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:44 --> Controller Class Initialized
INFO - 2021-12-29 02:12:44 --> Helper loaded: cookie_helper
INFO - 2021-12-29 02:12:44 --> Config Class Initialized
INFO - 2021-12-29 02:12:44 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:44 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:44 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:44 --> URI Class Initialized
INFO - 2021-12-29 02:12:44 --> Router Class Initialized
INFO - 2021-12-29 02:12:44 --> Output Class Initialized
INFO - 2021-12-29 02:12:44 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:44 --> Input Class Initialized
INFO - 2021-12-29 02:12:44 --> Language Class Initialized
INFO - 2021-12-29 02:12:44 --> Language Class Initialized
INFO - 2021-12-29 02:12:44 --> Config Class Initialized
INFO - 2021-12-29 02:12:44 --> Loader Class Initialized
INFO - 2021-12-29 02:12:44 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:44 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:44 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:44 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:44 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:44 --> Controller Class Initialized
DEBUG - 2021-12-29 02:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-29 02:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:12:44 --> Final output sent to browser
DEBUG - 2021-12-29 02:12:44 --> Total execution time: 0.0440
INFO - 2021-12-29 02:12:47 --> Config Class Initialized
INFO - 2021-12-29 02:12:47 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:47 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:47 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:47 --> URI Class Initialized
INFO - 2021-12-29 02:12:47 --> Router Class Initialized
INFO - 2021-12-29 02:12:47 --> Output Class Initialized
INFO - 2021-12-29 02:12:47 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:47 --> Input Class Initialized
INFO - 2021-12-29 02:12:47 --> Language Class Initialized
INFO - 2021-12-29 02:12:47 --> Language Class Initialized
INFO - 2021-12-29 02:12:47 --> Config Class Initialized
INFO - 2021-12-29 02:12:47 --> Loader Class Initialized
INFO - 2021-12-29 02:12:47 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:47 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:47 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:47 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:47 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:47 --> Controller Class Initialized
INFO - 2021-12-29 02:12:47 --> Helper loaded: cookie_helper
INFO - 2021-12-29 02:12:47 --> Final output sent to browser
DEBUG - 2021-12-29 02:12:47 --> Total execution time: 0.0600
INFO - 2021-12-29 02:12:47 --> Config Class Initialized
INFO - 2021-12-29 02:12:47 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:12:47 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:12:47 --> Utf8 Class Initialized
INFO - 2021-12-29 02:12:47 --> URI Class Initialized
INFO - 2021-12-29 02:12:47 --> Router Class Initialized
INFO - 2021-12-29 02:12:47 --> Output Class Initialized
INFO - 2021-12-29 02:12:47 --> Security Class Initialized
DEBUG - 2021-12-29 02:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:12:47 --> Input Class Initialized
INFO - 2021-12-29 02:12:47 --> Language Class Initialized
INFO - 2021-12-29 02:12:47 --> Language Class Initialized
INFO - 2021-12-29 02:12:47 --> Config Class Initialized
INFO - 2021-12-29 02:12:47 --> Loader Class Initialized
INFO - 2021-12-29 02:12:47 --> Helper loaded: url_helper
INFO - 2021-12-29 02:12:47 --> Helper loaded: file_helper
INFO - 2021-12-29 02:12:47 --> Helper loaded: form_helper
INFO - 2021-12-29 02:12:47 --> Helper loaded: my_helper
INFO - 2021-12-29 02:12:47 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:12:47 --> Controller Class Initialized
DEBUG - 2021-12-29 02:12:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-29 02:12:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:12:47 --> Final output sent to browser
DEBUG - 2021-12-29 02:12:47 --> Total execution time: 0.1420
INFO - 2021-12-29 02:15:21 --> Config Class Initialized
INFO - 2021-12-29 02:15:21 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:21 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:21 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:21 --> URI Class Initialized
INFO - 2021-12-29 02:15:21 --> Router Class Initialized
INFO - 2021-12-29 02:15:21 --> Output Class Initialized
INFO - 2021-12-29 02:15:21 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:21 --> Input Class Initialized
INFO - 2021-12-29 02:15:21 --> Language Class Initialized
INFO - 2021-12-29 02:15:21 --> Language Class Initialized
INFO - 2021-12-29 02:15:21 --> Config Class Initialized
INFO - 2021-12-29 02:15:21 --> Loader Class Initialized
INFO - 2021-12-29 02:15:21 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:21 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:21 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:21 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:21 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:21 --> Controller Class Initialized
DEBUG - 2021-12-29 02:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-29 02:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:15:21 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:21 --> Total execution time: 0.0460
INFO - 2021-12-29 02:15:22 --> Config Class Initialized
INFO - 2021-12-29 02:15:22 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:22 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:22 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:22 --> URI Class Initialized
INFO - 2021-12-29 02:15:22 --> Router Class Initialized
INFO - 2021-12-29 02:15:22 --> Output Class Initialized
INFO - 2021-12-29 02:15:22 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:22 --> Input Class Initialized
INFO - 2021-12-29 02:15:22 --> Language Class Initialized
INFO - 2021-12-29 02:15:22 --> Language Class Initialized
INFO - 2021-12-29 02:15:22 --> Config Class Initialized
INFO - 2021-12-29 02:15:22 --> Loader Class Initialized
INFO - 2021-12-29 02:15:22 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:22 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:22 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:22 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:22 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:22 --> Controller Class Initialized
INFO - 2021-12-29 02:15:22 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:22 --> Total execution time: 0.0560
INFO - 2021-12-29 02:15:23 --> Config Class Initialized
INFO - 2021-12-29 02:15:23 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:23 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:23 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:23 --> URI Class Initialized
INFO - 2021-12-29 02:15:23 --> Router Class Initialized
INFO - 2021-12-29 02:15:23 --> Output Class Initialized
INFO - 2021-12-29 02:15:23 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:23 --> Input Class Initialized
INFO - 2021-12-29 02:15:23 --> Language Class Initialized
INFO - 2021-12-29 02:15:23 --> Language Class Initialized
INFO - 2021-12-29 02:15:23 --> Config Class Initialized
INFO - 2021-12-29 02:15:23 --> Loader Class Initialized
INFO - 2021-12-29 02:15:23 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:23 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:23 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:23 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:23 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:23 --> Controller Class Initialized
INFO - 2021-12-29 02:15:23 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:23 --> Total execution time: 0.0450
INFO - 2021-12-29 02:15:32 --> Config Class Initialized
INFO - 2021-12-29 02:15:32 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:32 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:32 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:32 --> URI Class Initialized
INFO - 2021-12-29 02:15:32 --> Router Class Initialized
INFO - 2021-12-29 02:15:32 --> Output Class Initialized
INFO - 2021-12-29 02:15:32 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:32 --> Input Class Initialized
INFO - 2021-12-29 02:15:32 --> Language Class Initialized
INFO - 2021-12-29 02:15:32 --> Language Class Initialized
INFO - 2021-12-29 02:15:32 --> Config Class Initialized
INFO - 2021-12-29 02:15:32 --> Loader Class Initialized
INFO - 2021-12-29 02:15:32 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:32 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:32 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:32 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:32 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:32 --> Controller Class Initialized
INFO - 2021-12-29 02:15:32 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:32 --> Total execution time: 0.0520
INFO - 2021-12-29 02:15:36 --> Config Class Initialized
INFO - 2021-12-29 02:15:36 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:36 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:36 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:36 --> URI Class Initialized
INFO - 2021-12-29 02:15:36 --> Router Class Initialized
INFO - 2021-12-29 02:15:36 --> Output Class Initialized
INFO - 2021-12-29 02:15:36 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:36 --> Input Class Initialized
INFO - 2021-12-29 02:15:36 --> Language Class Initialized
INFO - 2021-12-29 02:15:36 --> Language Class Initialized
INFO - 2021-12-29 02:15:36 --> Config Class Initialized
INFO - 2021-12-29 02:15:36 --> Loader Class Initialized
INFO - 2021-12-29 02:15:36 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:36 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:36 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:36 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:36 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:36 --> Controller Class Initialized
INFO - 2021-12-29 02:15:36 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:36 --> Total execution time: 0.0720
INFO - 2021-12-29 02:15:38 --> Config Class Initialized
INFO - 2021-12-29 02:15:38 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:38 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:38 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:38 --> URI Class Initialized
INFO - 2021-12-29 02:15:38 --> Router Class Initialized
INFO - 2021-12-29 02:15:38 --> Output Class Initialized
INFO - 2021-12-29 02:15:38 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:38 --> Input Class Initialized
INFO - 2021-12-29 02:15:38 --> Language Class Initialized
INFO - 2021-12-29 02:15:38 --> Language Class Initialized
INFO - 2021-12-29 02:15:38 --> Config Class Initialized
INFO - 2021-12-29 02:15:38 --> Loader Class Initialized
INFO - 2021-12-29 02:15:38 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:38 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:38 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:38 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:38 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:38 --> Controller Class Initialized
INFO - 2021-12-29 02:15:38 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:38 --> Total execution time: 0.0510
INFO - 2021-12-29 02:15:42 --> Config Class Initialized
INFO - 2021-12-29 02:15:42 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:42 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:42 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:42 --> URI Class Initialized
INFO - 2021-12-29 02:15:42 --> Router Class Initialized
INFO - 2021-12-29 02:15:42 --> Output Class Initialized
INFO - 2021-12-29 02:15:42 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:42 --> Input Class Initialized
INFO - 2021-12-29 02:15:42 --> Language Class Initialized
INFO - 2021-12-29 02:15:42 --> Language Class Initialized
INFO - 2021-12-29 02:15:42 --> Config Class Initialized
INFO - 2021-12-29 02:15:42 --> Loader Class Initialized
INFO - 2021-12-29 02:15:42 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:42 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:42 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:42 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:42 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:42 --> Controller Class Initialized
INFO - 2021-12-29 02:15:42 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:42 --> Total execution time: 0.0700
INFO - 2021-12-29 02:15:44 --> Config Class Initialized
INFO - 2021-12-29 02:15:44 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:44 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:44 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:44 --> URI Class Initialized
INFO - 2021-12-29 02:15:44 --> Router Class Initialized
INFO - 2021-12-29 02:15:44 --> Output Class Initialized
INFO - 2021-12-29 02:15:44 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:44 --> Input Class Initialized
INFO - 2021-12-29 02:15:44 --> Language Class Initialized
INFO - 2021-12-29 02:15:44 --> Language Class Initialized
INFO - 2021-12-29 02:15:44 --> Config Class Initialized
INFO - 2021-12-29 02:15:44 --> Loader Class Initialized
INFO - 2021-12-29 02:15:44 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:44 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:44 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:44 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:44 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:44 --> Controller Class Initialized
DEBUG - 2021-12-29 02:15:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-29 02:15:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:15:44 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:44 --> Total execution time: 0.0650
INFO - 2021-12-29 02:15:47 --> Config Class Initialized
INFO - 2021-12-29 02:15:47 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:47 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:47 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:47 --> URI Class Initialized
DEBUG - 2021-12-29 02:15:47 --> No URI present. Default controller set.
INFO - 2021-12-29 02:15:47 --> Router Class Initialized
INFO - 2021-12-29 02:15:47 --> Output Class Initialized
INFO - 2021-12-29 02:15:47 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:47 --> Input Class Initialized
INFO - 2021-12-29 02:15:47 --> Language Class Initialized
INFO - 2021-12-29 02:15:47 --> Language Class Initialized
INFO - 2021-12-29 02:15:47 --> Config Class Initialized
INFO - 2021-12-29 02:15:47 --> Loader Class Initialized
INFO - 2021-12-29 02:15:47 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:47 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:47 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:47 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:47 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:47 --> Controller Class Initialized
DEBUG - 2021-12-29 02:15:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-29 02:15:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:15:47 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:47 --> Total execution time: 0.1740
INFO - 2021-12-29 02:15:49 --> Config Class Initialized
INFO - 2021-12-29 02:15:49 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:49 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:49 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:49 --> URI Class Initialized
INFO - 2021-12-29 02:15:49 --> Router Class Initialized
INFO - 2021-12-29 02:15:49 --> Output Class Initialized
INFO - 2021-12-29 02:15:49 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:49 --> Input Class Initialized
INFO - 2021-12-29 02:15:49 --> Language Class Initialized
INFO - 2021-12-29 02:15:49 --> Language Class Initialized
INFO - 2021-12-29 02:15:49 --> Config Class Initialized
INFO - 2021-12-29 02:15:49 --> Loader Class Initialized
INFO - 2021-12-29 02:15:49 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:49 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:49 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:49 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:49 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:49 --> Controller Class Initialized
DEBUG - 2021-12-29 02:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-29 02:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:15:49 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:49 --> Total execution time: 0.0520
INFO - 2021-12-29 02:15:51 --> Config Class Initialized
INFO - 2021-12-29 02:15:51 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:15:51 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:15:51 --> Utf8 Class Initialized
INFO - 2021-12-29 02:15:51 --> URI Class Initialized
INFO - 2021-12-29 02:15:51 --> Router Class Initialized
INFO - 2021-12-29 02:15:51 --> Output Class Initialized
INFO - 2021-12-29 02:15:51 --> Security Class Initialized
DEBUG - 2021-12-29 02:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:15:51 --> Input Class Initialized
INFO - 2021-12-29 02:15:51 --> Language Class Initialized
INFO - 2021-12-29 02:15:51 --> Language Class Initialized
INFO - 2021-12-29 02:15:51 --> Config Class Initialized
INFO - 2021-12-29 02:15:51 --> Loader Class Initialized
INFO - 2021-12-29 02:15:51 --> Helper loaded: url_helper
INFO - 2021-12-29 02:15:51 --> Helper loaded: file_helper
INFO - 2021-12-29 02:15:51 --> Helper loaded: form_helper
INFO - 2021-12-29 02:15:51 --> Helper loaded: my_helper
INFO - 2021-12-29 02:15:51 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:15:51 --> Controller Class Initialized
DEBUG - 2021-12-29 02:15:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-29 02:15:51 --> Final output sent to browser
DEBUG - 2021-12-29 02:15:51 --> Total execution time: 0.0970
INFO - 2021-12-29 02:16:02 --> Config Class Initialized
INFO - 2021-12-29 02:16:02 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:16:02 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:16:02 --> Utf8 Class Initialized
INFO - 2021-12-29 02:16:02 --> URI Class Initialized
INFO - 2021-12-29 02:16:02 --> Router Class Initialized
INFO - 2021-12-29 02:16:02 --> Output Class Initialized
INFO - 2021-12-29 02:16:02 --> Security Class Initialized
DEBUG - 2021-12-29 02:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:16:02 --> Input Class Initialized
INFO - 2021-12-29 02:16:02 --> Language Class Initialized
INFO - 2021-12-29 02:16:02 --> Language Class Initialized
INFO - 2021-12-29 02:16:02 --> Config Class Initialized
INFO - 2021-12-29 02:16:02 --> Loader Class Initialized
INFO - 2021-12-29 02:16:02 --> Helper loaded: url_helper
INFO - 2021-12-29 02:16:02 --> Helper loaded: file_helper
INFO - 2021-12-29 02:16:02 --> Helper loaded: form_helper
INFO - 2021-12-29 02:16:02 --> Helper loaded: my_helper
INFO - 2021-12-29 02:16:02 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:16:02 --> Controller Class Initialized
DEBUG - 2021-12-29 02:16:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-29 02:16:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:16:02 --> Final output sent to browser
DEBUG - 2021-12-29 02:16:02 --> Total execution time: 0.0510
INFO - 2021-12-29 02:16:03 --> Config Class Initialized
INFO - 2021-12-29 02:16:03 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:16:03 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:16:03 --> Utf8 Class Initialized
INFO - 2021-12-29 02:16:03 --> URI Class Initialized
INFO - 2021-12-29 02:16:03 --> Router Class Initialized
INFO - 2021-12-29 02:16:03 --> Output Class Initialized
INFO - 2021-12-29 02:16:03 --> Security Class Initialized
DEBUG - 2021-12-29 02:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:16:03 --> Input Class Initialized
INFO - 2021-12-29 02:16:03 --> Language Class Initialized
INFO - 2021-12-29 02:16:03 --> Language Class Initialized
INFO - 2021-12-29 02:16:03 --> Config Class Initialized
INFO - 2021-12-29 02:16:03 --> Loader Class Initialized
INFO - 2021-12-29 02:16:03 --> Helper loaded: url_helper
INFO - 2021-12-29 02:16:03 --> Helper loaded: file_helper
INFO - 2021-12-29 02:16:03 --> Helper loaded: form_helper
INFO - 2021-12-29 02:16:03 --> Helper loaded: my_helper
INFO - 2021-12-29 02:16:03 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:16:03 --> Controller Class Initialized
INFO - 2021-12-29 02:16:03 --> Final output sent to browser
DEBUG - 2021-12-29 02:16:03 --> Total execution time: 0.0520
INFO - 2021-12-29 02:16:04 --> Config Class Initialized
INFO - 2021-12-29 02:16:04 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:16:04 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:16:04 --> Utf8 Class Initialized
INFO - 2021-12-29 02:16:04 --> URI Class Initialized
INFO - 2021-12-29 02:16:04 --> Router Class Initialized
INFO - 2021-12-29 02:16:04 --> Output Class Initialized
INFO - 2021-12-29 02:16:04 --> Security Class Initialized
DEBUG - 2021-12-29 02:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:16:04 --> Input Class Initialized
INFO - 2021-12-29 02:16:04 --> Language Class Initialized
INFO - 2021-12-29 02:16:04 --> Language Class Initialized
INFO - 2021-12-29 02:16:04 --> Config Class Initialized
INFO - 2021-12-29 02:16:04 --> Loader Class Initialized
INFO - 2021-12-29 02:16:04 --> Helper loaded: url_helper
INFO - 2021-12-29 02:16:04 --> Helper loaded: file_helper
INFO - 2021-12-29 02:16:04 --> Helper loaded: form_helper
INFO - 2021-12-29 02:16:04 --> Helper loaded: my_helper
INFO - 2021-12-29 02:16:04 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:16:04 --> Controller Class Initialized
INFO - 2021-12-29 02:16:04 --> Final output sent to browser
DEBUG - 2021-12-29 02:16:04 --> Total execution time: 0.0450
INFO - 2021-12-29 02:19:28 --> Config Class Initialized
INFO - 2021-12-29 02:19:28 --> Hooks Class Initialized
DEBUG - 2021-12-29 02:19:28 --> UTF-8 Support Enabled
INFO - 2021-12-29 02:19:28 --> Utf8 Class Initialized
INFO - 2021-12-29 02:19:28 --> URI Class Initialized
INFO - 2021-12-29 02:19:28 --> Router Class Initialized
INFO - 2021-12-29 02:19:28 --> Output Class Initialized
INFO - 2021-12-29 02:19:28 --> Security Class Initialized
DEBUG - 2021-12-29 02:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 02:19:28 --> Input Class Initialized
INFO - 2021-12-29 02:19:28 --> Language Class Initialized
INFO - 2021-12-29 02:19:28 --> Language Class Initialized
INFO - 2021-12-29 02:19:28 --> Config Class Initialized
INFO - 2021-12-29 02:19:28 --> Loader Class Initialized
INFO - 2021-12-29 02:19:28 --> Helper loaded: url_helper
INFO - 2021-12-29 02:19:28 --> Helper loaded: file_helper
INFO - 2021-12-29 02:19:28 --> Helper loaded: form_helper
INFO - 2021-12-29 02:19:28 --> Helper loaded: my_helper
INFO - 2021-12-29 02:19:28 --> Database Driver Class Initialized
DEBUG - 2021-12-29 02:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 02:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 02:19:28 --> Controller Class Initialized
DEBUG - 2021-12-29 02:19:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-29 02:19:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-29 02:19:28 --> Final output sent to browser
DEBUG - 2021-12-29 02:19:28 --> Total execution time: 0.0820
