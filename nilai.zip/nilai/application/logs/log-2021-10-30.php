<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-30 05:28:50 --> Config Class Initialized
INFO - 2021-10-30 05:28:50 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:28:50 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:28:50 --> Utf8 Class Initialized
INFO - 2021-10-30 05:28:50 --> URI Class Initialized
DEBUG - 2021-10-30 05:28:51 --> No URI present. Default controller set.
INFO - 2021-10-30 05:28:51 --> Router Class Initialized
INFO - 2021-10-30 05:28:51 --> Output Class Initialized
INFO - 2021-10-30 05:28:51 --> Security Class Initialized
DEBUG - 2021-10-30 05:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:28:51 --> Input Class Initialized
INFO - 2021-10-30 05:28:51 --> Language Class Initialized
INFO - 2021-10-30 05:28:51 --> Language Class Initialized
INFO - 2021-10-30 05:28:51 --> Config Class Initialized
INFO - 2021-10-30 05:28:51 --> Loader Class Initialized
INFO - 2021-10-30 05:28:51 --> Helper loaded: url_helper
INFO - 2021-10-30 05:28:51 --> Helper loaded: file_helper
INFO - 2021-10-30 05:28:51 --> Helper loaded: form_helper
INFO - 2021-10-30 05:28:51 --> Helper loaded: my_helper
INFO - 2021-10-30 05:28:51 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:28:51 --> Controller Class Initialized
INFO - 2021-10-30 05:28:51 --> Config Class Initialized
INFO - 2021-10-30 05:28:51 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:28:51 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:28:51 --> Utf8 Class Initialized
INFO - 2021-10-30 05:28:51 --> URI Class Initialized
INFO - 2021-10-30 05:28:51 --> Router Class Initialized
INFO - 2021-10-30 05:28:51 --> Output Class Initialized
INFO - 2021-10-30 05:28:51 --> Security Class Initialized
DEBUG - 2021-10-30 05:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:28:51 --> Input Class Initialized
INFO - 2021-10-30 05:28:51 --> Language Class Initialized
INFO - 2021-10-30 05:28:51 --> Language Class Initialized
INFO - 2021-10-30 05:28:51 --> Config Class Initialized
INFO - 2021-10-30 05:28:51 --> Loader Class Initialized
INFO - 2021-10-30 05:28:51 --> Helper loaded: url_helper
INFO - 2021-10-30 05:28:51 --> Helper loaded: file_helper
INFO - 2021-10-30 05:28:51 --> Helper loaded: form_helper
INFO - 2021-10-30 05:28:51 --> Helper loaded: my_helper
INFO - 2021-10-30 05:28:51 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:28:51 --> Controller Class Initialized
DEBUG - 2021-10-30 05:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 05:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 05:28:51 --> Final output sent to browser
DEBUG - 2021-10-30 05:28:51 --> Total execution time: 0.0923
INFO - 2021-10-30 05:28:58 --> Config Class Initialized
INFO - 2021-10-30 05:28:58 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:28:58 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:28:58 --> Utf8 Class Initialized
INFO - 2021-10-30 05:28:58 --> URI Class Initialized
INFO - 2021-10-30 05:28:58 --> Router Class Initialized
INFO - 2021-10-30 05:28:58 --> Output Class Initialized
INFO - 2021-10-30 05:28:58 --> Security Class Initialized
DEBUG - 2021-10-30 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:28:58 --> Input Class Initialized
INFO - 2021-10-30 05:28:58 --> Language Class Initialized
INFO - 2021-10-30 05:28:58 --> Language Class Initialized
INFO - 2021-10-30 05:28:58 --> Config Class Initialized
INFO - 2021-10-30 05:28:58 --> Loader Class Initialized
INFO - 2021-10-30 05:28:58 --> Helper loaded: url_helper
INFO - 2021-10-30 05:28:58 --> Helper loaded: file_helper
INFO - 2021-10-30 05:28:58 --> Helper loaded: form_helper
INFO - 2021-10-30 05:28:58 --> Helper loaded: my_helper
INFO - 2021-10-30 05:28:58 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:28:58 --> Controller Class Initialized
INFO - 2021-10-30 05:28:58 --> Helper loaded: cookie_helper
INFO - 2021-10-30 05:28:58 --> Final output sent to browser
DEBUG - 2021-10-30 05:28:58 --> Total execution time: 0.0671
INFO - 2021-10-30 05:28:58 --> Config Class Initialized
INFO - 2021-10-30 05:28:58 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:28:58 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:28:58 --> Utf8 Class Initialized
INFO - 2021-10-30 05:28:58 --> URI Class Initialized
INFO - 2021-10-30 05:28:58 --> Router Class Initialized
INFO - 2021-10-30 05:28:58 --> Output Class Initialized
INFO - 2021-10-30 05:28:58 --> Security Class Initialized
DEBUG - 2021-10-30 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:28:58 --> Input Class Initialized
INFO - 2021-10-30 05:28:58 --> Language Class Initialized
INFO - 2021-10-30 05:28:58 --> Language Class Initialized
INFO - 2021-10-30 05:28:58 --> Config Class Initialized
INFO - 2021-10-30 05:28:58 --> Loader Class Initialized
INFO - 2021-10-30 05:28:58 --> Helper loaded: url_helper
INFO - 2021-10-30 05:28:58 --> Helper loaded: file_helper
INFO - 2021-10-30 05:28:58 --> Helper loaded: form_helper
INFO - 2021-10-30 05:28:58 --> Helper loaded: my_helper
INFO - 2021-10-30 05:28:58 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:28:58 --> Controller Class Initialized
DEBUG - 2021-10-30 05:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 05:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 05:28:59 --> Final output sent to browser
DEBUG - 2021-10-30 05:28:59 --> Total execution time: 0.8043
INFO - 2021-10-30 05:29:16 --> Config Class Initialized
INFO - 2021-10-30 05:29:16 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:29:16 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:29:16 --> Utf8 Class Initialized
INFO - 2021-10-30 05:29:16 --> URI Class Initialized
INFO - 2021-10-30 05:29:16 --> Router Class Initialized
INFO - 2021-10-30 05:29:16 --> Output Class Initialized
INFO - 2021-10-30 05:29:16 --> Security Class Initialized
DEBUG - 2021-10-30 05:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:29:16 --> Input Class Initialized
INFO - 2021-10-30 05:29:16 --> Language Class Initialized
INFO - 2021-10-30 05:29:16 --> Language Class Initialized
INFO - 2021-10-30 05:29:16 --> Config Class Initialized
INFO - 2021-10-30 05:29:16 --> Loader Class Initialized
INFO - 2021-10-30 05:29:16 --> Helper loaded: url_helper
INFO - 2021-10-30 05:29:16 --> Helper loaded: file_helper
INFO - 2021-10-30 05:29:16 --> Helper loaded: form_helper
INFO - 2021-10-30 05:29:16 --> Helper loaded: my_helper
INFO - 2021-10-30 05:29:16 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:29:16 --> Controller Class Initialized
DEBUG - 2021-10-30 05:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-10-30 05:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 05:29:16 --> Final output sent to browser
DEBUG - 2021-10-30 05:29:16 --> Total execution time: 0.0733
INFO - 2021-10-30 05:29:16 --> Config Class Initialized
INFO - 2021-10-30 05:29:16 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:29:16 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:29:16 --> Utf8 Class Initialized
INFO - 2021-10-30 05:29:16 --> URI Class Initialized
INFO - 2021-10-30 05:29:16 --> Router Class Initialized
INFO - 2021-10-30 05:29:16 --> Output Class Initialized
INFO - 2021-10-30 05:29:16 --> Security Class Initialized
DEBUG - 2021-10-30 05:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:29:16 --> Input Class Initialized
INFO - 2021-10-30 05:29:16 --> Language Class Initialized
INFO - 2021-10-30 05:29:16 --> Language Class Initialized
INFO - 2021-10-30 05:29:16 --> Config Class Initialized
INFO - 2021-10-30 05:29:16 --> Loader Class Initialized
INFO - 2021-10-30 05:29:16 --> Helper loaded: url_helper
INFO - 2021-10-30 05:29:16 --> Helper loaded: file_helper
INFO - 2021-10-30 05:29:16 --> Helper loaded: form_helper
INFO - 2021-10-30 05:29:16 --> Helper loaded: my_helper
INFO - 2021-10-30 05:29:16 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:29:16 --> Controller Class Initialized
INFO - 2021-10-30 05:33:17 --> Config Class Initialized
INFO - 2021-10-30 05:33:17 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:33:17 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:33:18 --> Utf8 Class Initialized
INFO - 2021-10-30 05:33:18 --> URI Class Initialized
INFO - 2021-10-30 05:33:18 --> Router Class Initialized
INFO - 2021-10-30 05:33:18 --> Output Class Initialized
INFO - 2021-10-30 05:33:18 --> Security Class Initialized
DEBUG - 2021-10-30 05:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:33:18 --> Input Class Initialized
INFO - 2021-10-30 05:33:18 --> Language Class Initialized
INFO - 2021-10-30 05:33:18 --> Language Class Initialized
INFO - 2021-10-30 05:33:18 --> Config Class Initialized
INFO - 2021-10-30 05:33:18 --> Loader Class Initialized
INFO - 2021-10-30 05:33:18 --> Helper loaded: url_helper
INFO - 2021-10-30 05:33:18 --> Helper loaded: file_helper
INFO - 2021-10-30 05:33:18 --> Helper loaded: form_helper
INFO - 2021-10-30 05:33:18 --> Helper loaded: my_helper
INFO - 2021-10-30 05:33:18 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:33:18 --> Controller Class Initialized
DEBUG - 2021-10-30 05:33:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-10-30 05:33:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 05:33:18 --> Final output sent to browser
DEBUG - 2021-10-30 05:33:18 --> Total execution time: 0.0686
INFO - 2021-10-30 05:33:18 --> Config Class Initialized
INFO - 2021-10-30 05:33:18 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:33:18 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:33:18 --> Utf8 Class Initialized
INFO - 2021-10-30 05:33:18 --> URI Class Initialized
INFO - 2021-10-30 05:33:18 --> Router Class Initialized
INFO - 2021-10-30 05:33:18 --> Output Class Initialized
INFO - 2021-10-30 05:33:18 --> Security Class Initialized
DEBUG - 2021-10-30 05:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:33:18 --> Input Class Initialized
INFO - 2021-10-30 05:33:18 --> Language Class Initialized
INFO - 2021-10-30 05:33:18 --> Language Class Initialized
INFO - 2021-10-30 05:33:18 --> Config Class Initialized
INFO - 2021-10-30 05:33:18 --> Loader Class Initialized
INFO - 2021-10-30 05:33:18 --> Helper loaded: url_helper
INFO - 2021-10-30 05:33:18 --> Helper loaded: file_helper
INFO - 2021-10-30 05:33:18 --> Helper loaded: form_helper
INFO - 2021-10-30 05:33:18 --> Helper loaded: my_helper
INFO - 2021-10-30 05:33:18 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:33:18 --> Controller Class Initialized
INFO - 2021-10-30 05:33:22 --> Config Class Initialized
INFO - 2021-10-30 05:33:22 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:33:22 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:33:22 --> Utf8 Class Initialized
INFO - 2021-10-30 05:33:22 --> URI Class Initialized
INFO - 2021-10-30 05:33:22 --> Router Class Initialized
INFO - 2021-10-30 05:33:22 --> Output Class Initialized
INFO - 2021-10-30 05:33:22 --> Security Class Initialized
DEBUG - 2021-10-30 05:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:33:22 --> Input Class Initialized
INFO - 2021-10-30 05:33:22 --> Language Class Initialized
INFO - 2021-10-30 05:33:22 --> Language Class Initialized
INFO - 2021-10-30 05:33:22 --> Config Class Initialized
INFO - 2021-10-30 05:33:22 --> Loader Class Initialized
INFO - 2021-10-30 05:33:22 --> Helper loaded: url_helper
INFO - 2021-10-30 05:33:22 --> Helper loaded: file_helper
INFO - 2021-10-30 05:33:22 --> Helper loaded: form_helper
INFO - 2021-10-30 05:33:22 --> Helper loaded: my_helper
INFO - 2021-10-30 05:33:22 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:33:22 --> Controller Class Initialized
INFO - 2021-10-30 05:33:22 --> Final output sent to browser
DEBUG - 2021-10-30 05:33:22 --> Total execution time: 0.0456
INFO - 2021-10-30 05:34:09 --> Config Class Initialized
INFO - 2021-10-30 05:34:09 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:09 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:09 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:09 --> URI Class Initialized
INFO - 2021-10-30 05:34:09 --> Router Class Initialized
INFO - 2021-10-30 05:34:09 --> Output Class Initialized
INFO - 2021-10-30 05:34:09 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:09 --> Input Class Initialized
INFO - 2021-10-30 05:34:09 --> Language Class Initialized
INFO - 2021-10-30 05:34:09 --> Language Class Initialized
INFO - 2021-10-30 05:34:09 --> Config Class Initialized
INFO - 2021-10-30 05:34:09 --> Loader Class Initialized
INFO - 2021-10-30 05:34:09 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:09 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:09 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:09 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:09 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:09 --> Controller Class Initialized
INFO - 2021-10-30 05:34:09 --> Final output sent to browser
DEBUG - 2021-10-30 05:34:09 --> Total execution time: 0.0470
INFO - 2021-10-30 05:34:09 --> Config Class Initialized
INFO - 2021-10-30 05:34:09 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:09 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:09 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:09 --> URI Class Initialized
INFO - 2021-10-30 05:34:09 --> Router Class Initialized
INFO - 2021-10-30 05:34:09 --> Output Class Initialized
INFO - 2021-10-30 05:34:09 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:09 --> Input Class Initialized
INFO - 2021-10-30 05:34:09 --> Language Class Initialized
INFO - 2021-10-30 05:34:09 --> Language Class Initialized
INFO - 2021-10-30 05:34:09 --> Config Class Initialized
INFO - 2021-10-30 05:34:09 --> Loader Class Initialized
INFO - 2021-10-30 05:34:09 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:09 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:09 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:09 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:09 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:09 --> Controller Class Initialized
INFO - 2021-10-30 05:34:42 --> Config Class Initialized
INFO - 2021-10-30 05:34:42 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:42 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:42 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:42 --> URI Class Initialized
INFO - 2021-10-30 05:34:42 --> Router Class Initialized
INFO - 2021-10-30 05:34:42 --> Output Class Initialized
INFO - 2021-10-30 05:34:42 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:42 --> Input Class Initialized
INFO - 2021-10-30 05:34:42 --> Language Class Initialized
INFO - 2021-10-30 05:34:42 --> Language Class Initialized
INFO - 2021-10-30 05:34:42 --> Config Class Initialized
INFO - 2021-10-30 05:34:42 --> Loader Class Initialized
INFO - 2021-10-30 05:34:42 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:42 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:42 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:42 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:42 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:42 --> Controller Class Initialized
INFO - 2021-10-30 05:34:42 --> Final output sent to browser
DEBUG - 2021-10-30 05:34:42 --> Total execution time: 0.0484
INFO - 2021-10-30 05:34:42 --> Config Class Initialized
INFO - 2021-10-30 05:34:42 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:42 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:42 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:42 --> URI Class Initialized
INFO - 2021-10-30 05:34:42 --> Router Class Initialized
INFO - 2021-10-30 05:34:42 --> Output Class Initialized
INFO - 2021-10-30 05:34:42 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:42 --> Input Class Initialized
INFO - 2021-10-30 05:34:42 --> Language Class Initialized
INFO - 2021-10-30 05:34:42 --> Language Class Initialized
INFO - 2021-10-30 05:34:42 --> Config Class Initialized
INFO - 2021-10-30 05:34:42 --> Loader Class Initialized
INFO - 2021-10-30 05:34:42 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:42 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:42 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:42 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:42 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:42 --> Controller Class Initialized
INFO - 2021-10-30 05:34:45 --> Config Class Initialized
INFO - 2021-10-30 05:34:45 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:45 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:45 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:45 --> URI Class Initialized
INFO - 2021-10-30 05:34:45 --> Router Class Initialized
INFO - 2021-10-30 05:34:45 --> Output Class Initialized
INFO - 2021-10-30 05:34:45 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:45 --> Input Class Initialized
INFO - 2021-10-30 05:34:45 --> Language Class Initialized
INFO - 2021-10-30 05:34:45 --> Language Class Initialized
INFO - 2021-10-30 05:34:45 --> Config Class Initialized
INFO - 2021-10-30 05:34:45 --> Loader Class Initialized
INFO - 2021-10-30 05:34:45 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:45 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:45 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:45 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:45 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:45 --> Controller Class Initialized
INFO - 2021-10-30 05:34:45 --> Final output sent to browser
DEBUG - 2021-10-30 05:34:45 --> Total execution time: 0.0480
INFO - 2021-10-30 05:34:45 --> Config Class Initialized
INFO - 2021-10-30 05:34:45 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:45 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:45 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:45 --> URI Class Initialized
INFO - 2021-10-30 05:34:45 --> Router Class Initialized
INFO - 2021-10-30 05:34:45 --> Output Class Initialized
INFO - 2021-10-30 05:34:45 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:45 --> Input Class Initialized
INFO - 2021-10-30 05:34:45 --> Language Class Initialized
INFO - 2021-10-30 05:34:45 --> Language Class Initialized
INFO - 2021-10-30 05:34:45 --> Config Class Initialized
INFO - 2021-10-30 05:34:45 --> Loader Class Initialized
INFO - 2021-10-30 05:34:45 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:45 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:45 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:45 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:45 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:45 --> Controller Class Initialized
INFO - 2021-10-30 05:34:57 --> Config Class Initialized
INFO - 2021-10-30 05:34:57 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:57 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:57 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:57 --> URI Class Initialized
INFO - 2021-10-30 05:34:57 --> Router Class Initialized
INFO - 2021-10-30 05:34:57 --> Output Class Initialized
INFO - 2021-10-30 05:34:57 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:57 --> Input Class Initialized
INFO - 2021-10-30 05:34:57 --> Language Class Initialized
INFO - 2021-10-30 05:34:57 --> Language Class Initialized
INFO - 2021-10-30 05:34:57 --> Config Class Initialized
INFO - 2021-10-30 05:34:57 --> Loader Class Initialized
INFO - 2021-10-30 05:34:57 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:57 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:57 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:57 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:57 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:57 --> Controller Class Initialized
DEBUG - 2021-10-30 05:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-10-30 05:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 05:34:57 --> Final output sent to browser
DEBUG - 2021-10-30 05:34:57 --> Total execution time: 0.0919
INFO - 2021-10-30 05:34:57 --> Config Class Initialized
INFO - 2021-10-30 05:34:57 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:57 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:57 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:57 --> URI Class Initialized
INFO - 2021-10-30 05:34:57 --> Router Class Initialized
INFO - 2021-10-30 05:34:57 --> Output Class Initialized
INFO - 2021-10-30 05:34:57 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:57 --> Input Class Initialized
INFO - 2021-10-30 05:34:57 --> Language Class Initialized
INFO - 2021-10-30 05:34:57 --> Language Class Initialized
INFO - 2021-10-30 05:34:57 --> Config Class Initialized
INFO - 2021-10-30 05:34:57 --> Loader Class Initialized
INFO - 2021-10-30 05:34:57 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:57 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:57 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:57 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:57 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:57 --> Controller Class Initialized
DEBUG - 2021-10-30 05:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-10-30 05:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 05:34:57 --> Final output sent to browser
DEBUG - 2021-10-30 05:34:57 --> Total execution time: 0.0525
INFO - 2021-10-30 05:34:59 --> Config Class Initialized
INFO - 2021-10-30 05:34:59 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:34:59 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:34:59 --> Utf8 Class Initialized
INFO - 2021-10-30 05:34:59 --> URI Class Initialized
INFO - 2021-10-30 05:34:59 --> Router Class Initialized
INFO - 2021-10-30 05:34:59 --> Output Class Initialized
INFO - 2021-10-30 05:34:59 --> Security Class Initialized
DEBUG - 2021-10-30 05:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:34:59 --> Input Class Initialized
INFO - 2021-10-30 05:34:59 --> Language Class Initialized
INFO - 2021-10-30 05:34:59 --> Language Class Initialized
INFO - 2021-10-30 05:34:59 --> Config Class Initialized
INFO - 2021-10-30 05:34:59 --> Loader Class Initialized
INFO - 2021-10-30 05:34:59 --> Helper loaded: url_helper
INFO - 2021-10-30 05:34:59 --> Helper loaded: file_helper
INFO - 2021-10-30 05:34:59 --> Helper loaded: form_helper
INFO - 2021-10-30 05:34:59 --> Helper loaded: my_helper
INFO - 2021-10-30 05:34:59 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:34:59 --> Controller Class Initialized
DEBUG - 2021-10-30 05:34:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-10-30 05:34:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 05:34:59 --> Final output sent to browser
DEBUG - 2021-10-30 05:34:59 --> Total execution time: 0.0815
INFO - 2021-10-30 05:47:38 --> Config Class Initialized
INFO - 2021-10-30 05:47:38 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:47:38 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:47:38 --> Utf8 Class Initialized
INFO - 2021-10-30 05:47:38 --> URI Class Initialized
INFO - 2021-10-30 05:47:38 --> Router Class Initialized
INFO - 2021-10-30 05:47:38 --> Output Class Initialized
INFO - 2021-10-30 05:47:38 --> Security Class Initialized
DEBUG - 2021-10-30 05:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:47:38 --> Input Class Initialized
INFO - 2021-10-30 05:47:38 --> Language Class Initialized
INFO - 2021-10-30 05:47:38 --> Language Class Initialized
INFO - 2021-10-30 05:47:38 --> Config Class Initialized
INFO - 2021-10-30 05:47:38 --> Loader Class Initialized
INFO - 2021-10-30 05:47:38 --> Helper loaded: url_helper
INFO - 2021-10-30 05:47:38 --> Helper loaded: file_helper
INFO - 2021-10-30 05:47:38 --> Helper loaded: form_helper
INFO - 2021-10-30 05:47:38 --> Helper loaded: my_helper
INFO - 2021-10-30 05:47:38 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:47:38 --> Controller Class Initialized
DEBUG - 2021-10-30 05:47:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-10-30 05:47:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 05:47:38 --> Final output sent to browser
DEBUG - 2021-10-30 05:47:38 --> Total execution time: 0.0466
INFO - 2021-10-30 05:47:38 --> Config Class Initialized
INFO - 2021-10-30 05:47:38 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:47:38 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:47:38 --> Utf8 Class Initialized
INFO - 2021-10-30 05:47:38 --> URI Class Initialized
INFO - 2021-10-30 05:47:38 --> Router Class Initialized
INFO - 2021-10-30 05:47:38 --> Output Class Initialized
INFO - 2021-10-30 05:47:38 --> Security Class Initialized
DEBUG - 2021-10-30 05:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:47:38 --> Input Class Initialized
INFO - 2021-10-30 05:47:38 --> Language Class Initialized
INFO - 2021-10-30 05:47:38 --> Language Class Initialized
INFO - 2021-10-30 05:47:38 --> Config Class Initialized
INFO - 2021-10-30 05:47:38 --> Loader Class Initialized
INFO - 2021-10-30 05:47:38 --> Helper loaded: url_helper
INFO - 2021-10-30 05:47:38 --> Helper loaded: file_helper
INFO - 2021-10-30 05:47:38 --> Helper loaded: form_helper
INFO - 2021-10-30 05:47:38 --> Helper loaded: my_helper
INFO - 2021-10-30 05:47:38 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:47:38 --> Controller Class Initialized
INFO - 2021-10-30 05:47:42 --> Config Class Initialized
INFO - 2021-10-30 05:47:42 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:47:42 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:47:42 --> Utf8 Class Initialized
INFO - 2021-10-30 05:47:42 --> URI Class Initialized
INFO - 2021-10-30 05:47:42 --> Router Class Initialized
INFO - 2021-10-30 05:47:42 --> Output Class Initialized
INFO - 2021-10-30 05:47:42 --> Security Class Initialized
DEBUG - 2021-10-30 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:47:42 --> Input Class Initialized
INFO - 2021-10-30 05:47:42 --> Language Class Initialized
INFO - 2021-10-30 05:47:42 --> Language Class Initialized
INFO - 2021-10-30 05:47:42 --> Config Class Initialized
INFO - 2021-10-30 05:47:42 --> Loader Class Initialized
INFO - 2021-10-30 05:47:42 --> Helper loaded: url_helper
INFO - 2021-10-30 05:47:42 --> Helper loaded: file_helper
INFO - 2021-10-30 05:47:42 --> Helper loaded: form_helper
INFO - 2021-10-30 05:47:42 --> Helper loaded: my_helper
INFO - 2021-10-30 05:47:42 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:47:42 --> Controller Class Initialized
INFO - 2021-10-30 05:47:42 --> Final output sent to browser
DEBUG - 2021-10-30 05:47:42 --> Total execution time: 0.0669
INFO - 2021-10-30 05:48:21 --> Config Class Initialized
INFO - 2021-10-30 05:48:21 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:48:21 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:48:21 --> Utf8 Class Initialized
INFO - 2021-10-30 05:48:21 --> URI Class Initialized
INFO - 2021-10-30 05:48:21 --> Router Class Initialized
INFO - 2021-10-30 05:48:21 --> Output Class Initialized
INFO - 2021-10-30 05:48:21 --> Security Class Initialized
DEBUG - 2021-10-30 05:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:48:21 --> Input Class Initialized
INFO - 2021-10-30 05:48:21 --> Language Class Initialized
INFO - 2021-10-30 05:48:21 --> Language Class Initialized
INFO - 2021-10-30 05:48:21 --> Config Class Initialized
INFO - 2021-10-30 05:48:21 --> Loader Class Initialized
INFO - 2021-10-30 05:48:21 --> Helper loaded: url_helper
INFO - 2021-10-30 05:48:21 --> Helper loaded: file_helper
INFO - 2021-10-30 05:48:21 --> Helper loaded: form_helper
INFO - 2021-10-30 05:48:21 --> Helper loaded: my_helper
INFO - 2021-10-30 05:48:21 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:48:21 --> Controller Class Initialized
INFO - 2021-10-30 05:48:21 --> Final output sent to browser
DEBUG - 2021-10-30 05:48:21 --> Total execution time: 0.0501
INFO - 2021-10-30 05:48:21 --> Config Class Initialized
INFO - 2021-10-30 05:48:21 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:48:21 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:48:21 --> Utf8 Class Initialized
INFO - 2021-10-30 05:48:21 --> URI Class Initialized
INFO - 2021-10-30 05:48:21 --> Router Class Initialized
INFO - 2021-10-30 05:48:21 --> Output Class Initialized
INFO - 2021-10-30 05:48:21 --> Security Class Initialized
DEBUG - 2021-10-30 05:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:48:21 --> Input Class Initialized
INFO - 2021-10-30 05:48:21 --> Language Class Initialized
INFO - 2021-10-30 05:48:21 --> Language Class Initialized
INFO - 2021-10-30 05:48:21 --> Config Class Initialized
INFO - 2021-10-30 05:48:21 --> Loader Class Initialized
INFO - 2021-10-30 05:48:21 --> Helper loaded: url_helper
INFO - 2021-10-30 05:48:21 --> Helper loaded: file_helper
INFO - 2021-10-30 05:48:21 --> Helper loaded: form_helper
INFO - 2021-10-30 05:48:21 --> Helper loaded: my_helper
INFO - 2021-10-30 05:48:21 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:48:21 --> Controller Class Initialized
INFO - 2021-10-30 05:48:40 --> Config Class Initialized
INFO - 2021-10-30 05:48:40 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:48:40 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:48:40 --> Utf8 Class Initialized
INFO - 2021-10-30 05:48:40 --> URI Class Initialized
INFO - 2021-10-30 05:48:40 --> Router Class Initialized
INFO - 2021-10-30 05:48:40 --> Output Class Initialized
INFO - 2021-10-30 05:48:40 --> Security Class Initialized
DEBUG - 2021-10-30 05:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:48:40 --> Input Class Initialized
INFO - 2021-10-30 05:48:40 --> Language Class Initialized
INFO - 2021-10-30 05:48:40 --> Language Class Initialized
INFO - 2021-10-30 05:48:40 --> Config Class Initialized
INFO - 2021-10-30 05:48:40 --> Loader Class Initialized
INFO - 2021-10-30 05:48:40 --> Helper loaded: url_helper
INFO - 2021-10-30 05:48:40 --> Helper loaded: file_helper
INFO - 2021-10-30 05:48:40 --> Helper loaded: form_helper
INFO - 2021-10-30 05:48:40 --> Helper loaded: my_helper
INFO - 2021-10-30 05:48:40 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:48:40 --> Controller Class Initialized
INFO - 2021-10-30 05:48:40 --> Final output sent to browser
DEBUG - 2021-10-30 05:48:40 --> Total execution time: 0.0534
INFO - 2021-10-30 05:54:32 --> Config Class Initialized
INFO - 2021-10-30 05:54:32 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:54:32 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:54:32 --> Utf8 Class Initialized
INFO - 2021-10-30 05:54:32 --> URI Class Initialized
INFO - 2021-10-30 05:54:32 --> Router Class Initialized
INFO - 2021-10-30 05:54:32 --> Output Class Initialized
INFO - 2021-10-30 05:54:32 --> Security Class Initialized
DEBUG - 2021-10-30 05:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:54:32 --> Input Class Initialized
INFO - 2021-10-30 05:54:32 --> Language Class Initialized
INFO - 2021-10-30 05:54:32 --> Language Class Initialized
INFO - 2021-10-30 05:54:32 --> Config Class Initialized
INFO - 2021-10-30 05:54:32 --> Loader Class Initialized
INFO - 2021-10-30 05:54:32 --> Helper loaded: url_helper
INFO - 2021-10-30 05:54:32 --> Helper loaded: file_helper
INFO - 2021-10-30 05:54:32 --> Helper loaded: form_helper
INFO - 2021-10-30 05:54:32 --> Helper loaded: my_helper
INFO - 2021-10-30 05:54:32 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:54:32 --> Controller Class Initialized
INFO - 2021-10-30 05:54:32 --> Final output sent to browser
DEBUG - 2021-10-30 05:54:32 --> Total execution time: 0.0514
INFO - 2021-10-30 05:54:32 --> Config Class Initialized
INFO - 2021-10-30 05:54:32 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:54:32 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:54:32 --> Utf8 Class Initialized
INFO - 2021-10-30 05:54:32 --> URI Class Initialized
INFO - 2021-10-30 05:54:32 --> Router Class Initialized
INFO - 2021-10-30 05:54:32 --> Output Class Initialized
INFO - 2021-10-30 05:54:32 --> Security Class Initialized
DEBUG - 2021-10-30 05:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:54:32 --> Input Class Initialized
INFO - 2021-10-30 05:54:32 --> Language Class Initialized
INFO - 2021-10-30 05:54:32 --> Language Class Initialized
INFO - 2021-10-30 05:54:32 --> Config Class Initialized
INFO - 2021-10-30 05:54:32 --> Loader Class Initialized
INFO - 2021-10-30 05:54:32 --> Helper loaded: url_helper
INFO - 2021-10-30 05:54:32 --> Helper loaded: file_helper
INFO - 2021-10-30 05:54:32 --> Helper loaded: form_helper
INFO - 2021-10-30 05:54:32 --> Helper loaded: my_helper
INFO - 2021-10-30 05:54:32 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:54:32 --> Controller Class Initialized
INFO - 2021-10-30 05:54:56 --> Config Class Initialized
INFO - 2021-10-30 05:54:56 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:54:56 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:54:56 --> Utf8 Class Initialized
INFO - 2021-10-30 05:54:56 --> URI Class Initialized
INFO - 2021-10-30 05:54:56 --> Router Class Initialized
INFO - 2021-10-30 05:54:56 --> Output Class Initialized
INFO - 2021-10-30 05:54:56 --> Security Class Initialized
DEBUG - 2021-10-30 05:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:54:56 --> Input Class Initialized
INFO - 2021-10-30 05:54:56 --> Language Class Initialized
INFO - 2021-10-30 05:54:56 --> Language Class Initialized
INFO - 2021-10-30 05:54:56 --> Config Class Initialized
INFO - 2021-10-30 05:54:56 --> Loader Class Initialized
INFO - 2021-10-30 05:54:56 --> Helper loaded: url_helper
INFO - 2021-10-30 05:54:56 --> Helper loaded: file_helper
INFO - 2021-10-30 05:54:56 --> Helper loaded: form_helper
INFO - 2021-10-30 05:54:56 --> Helper loaded: my_helper
INFO - 2021-10-30 05:54:56 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:54:56 --> Controller Class Initialized
INFO - 2021-10-30 05:54:56 --> Final output sent to browser
DEBUG - 2021-10-30 05:54:56 --> Total execution time: 0.0463
INFO - 2021-10-30 05:54:56 --> Config Class Initialized
INFO - 2021-10-30 05:54:56 --> Hooks Class Initialized
DEBUG - 2021-10-30 05:54:56 --> UTF-8 Support Enabled
INFO - 2021-10-30 05:54:56 --> Utf8 Class Initialized
INFO - 2021-10-30 05:54:56 --> URI Class Initialized
INFO - 2021-10-30 05:54:56 --> Router Class Initialized
INFO - 2021-10-30 05:54:56 --> Output Class Initialized
INFO - 2021-10-30 05:54:56 --> Security Class Initialized
DEBUG - 2021-10-30 05:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 05:54:56 --> Input Class Initialized
INFO - 2021-10-30 05:54:56 --> Language Class Initialized
INFO - 2021-10-30 05:54:56 --> Language Class Initialized
INFO - 2021-10-30 05:54:56 --> Config Class Initialized
INFO - 2021-10-30 05:54:56 --> Loader Class Initialized
INFO - 2021-10-30 05:54:56 --> Helper loaded: url_helper
INFO - 2021-10-30 05:54:56 --> Helper loaded: file_helper
INFO - 2021-10-30 05:54:56 --> Helper loaded: form_helper
INFO - 2021-10-30 05:54:56 --> Helper loaded: my_helper
INFO - 2021-10-30 05:54:56 --> Database Driver Class Initialized
DEBUG - 2021-10-30 05:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 05:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 05:54:56 --> Controller Class Initialized
INFO - 2021-10-30 05:54:56 --> Final output sent to browser
DEBUG - 2021-10-30 05:54:56 --> Total execution time: 0.0462
INFO - 2021-10-30 06:01:58 --> Config Class Initialized
INFO - 2021-10-30 06:01:58 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:01:58 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:01:58 --> Utf8 Class Initialized
INFO - 2021-10-30 06:01:58 --> URI Class Initialized
INFO - 2021-10-30 06:01:58 --> Router Class Initialized
INFO - 2021-10-30 06:01:58 --> Output Class Initialized
INFO - 2021-10-30 06:01:58 --> Security Class Initialized
DEBUG - 2021-10-30 06:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:01:58 --> Input Class Initialized
INFO - 2021-10-30 06:01:58 --> Language Class Initialized
INFO - 2021-10-30 06:01:58 --> Language Class Initialized
INFO - 2021-10-30 06:01:58 --> Config Class Initialized
INFO - 2021-10-30 06:01:58 --> Loader Class Initialized
INFO - 2021-10-30 06:01:58 --> Helper loaded: url_helper
INFO - 2021-10-30 06:01:58 --> Helper loaded: file_helper
INFO - 2021-10-30 06:01:58 --> Helper loaded: form_helper
INFO - 2021-10-30 06:01:58 --> Helper loaded: my_helper
INFO - 2021-10-30 06:01:58 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:01:58 --> Controller Class Initialized
INFO - 2021-10-30 06:01:58 --> Final output sent to browser
DEBUG - 2021-10-30 06:01:58 --> Total execution time: 0.0598
INFO - 2021-10-30 06:01:58 --> Config Class Initialized
INFO - 2021-10-30 06:01:58 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:01:58 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:01:58 --> Utf8 Class Initialized
INFO - 2021-10-30 06:01:58 --> URI Class Initialized
INFO - 2021-10-30 06:01:58 --> Router Class Initialized
INFO - 2021-10-30 06:01:58 --> Output Class Initialized
INFO - 2021-10-30 06:01:58 --> Security Class Initialized
DEBUG - 2021-10-30 06:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:01:58 --> Input Class Initialized
INFO - 2021-10-30 06:01:58 --> Language Class Initialized
INFO - 2021-10-30 06:01:58 --> Language Class Initialized
INFO - 2021-10-30 06:01:58 --> Config Class Initialized
INFO - 2021-10-30 06:01:58 --> Loader Class Initialized
INFO - 2021-10-30 06:01:58 --> Helper loaded: url_helper
INFO - 2021-10-30 06:01:58 --> Helper loaded: file_helper
INFO - 2021-10-30 06:01:58 --> Helper loaded: form_helper
INFO - 2021-10-30 06:01:58 --> Helper loaded: my_helper
INFO - 2021-10-30 06:01:58 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:01:58 --> Controller Class Initialized
INFO - 2021-10-30 06:02:05 --> Config Class Initialized
INFO - 2021-10-30 06:02:05 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:02:05 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:02:05 --> Utf8 Class Initialized
INFO - 2021-10-30 06:02:05 --> URI Class Initialized
INFO - 2021-10-30 06:02:05 --> Router Class Initialized
INFO - 2021-10-30 06:02:05 --> Output Class Initialized
INFO - 2021-10-30 06:02:05 --> Security Class Initialized
DEBUG - 2021-10-30 06:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:02:05 --> Input Class Initialized
INFO - 2021-10-30 06:02:05 --> Language Class Initialized
INFO - 2021-10-30 06:02:05 --> Language Class Initialized
INFO - 2021-10-30 06:02:05 --> Config Class Initialized
INFO - 2021-10-30 06:02:05 --> Loader Class Initialized
INFO - 2021-10-30 06:02:05 --> Helper loaded: url_helper
INFO - 2021-10-30 06:02:05 --> Helper loaded: file_helper
INFO - 2021-10-30 06:02:05 --> Helper loaded: form_helper
INFO - 2021-10-30 06:02:05 --> Helper loaded: my_helper
INFO - 2021-10-30 06:02:05 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:02:05 --> Controller Class Initialized
INFO - 2021-10-30 06:02:05 --> Final output sent to browser
DEBUG - 2021-10-30 06:02:05 --> Total execution time: 0.0469
INFO - 2021-10-30 06:02:43 --> Config Class Initialized
INFO - 2021-10-30 06:02:43 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:02:43 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:02:43 --> Utf8 Class Initialized
INFO - 2021-10-30 06:02:43 --> URI Class Initialized
INFO - 2021-10-30 06:02:43 --> Router Class Initialized
INFO - 2021-10-30 06:02:43 --> Output Class Initialized
INFO - 2021-10-30 06:02:43 --> Security Class Initialized
DEBUG - 2021-10-30 06:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:02:43 --> Input Class Initialized
INFO - 2021-10-30 06:02:43 --> Language Class Initialized
INFO - 2021-10-30 06:02:43 --> Language Class Initialized
INFO - 2021-10-30 06:02:43 --> Config Class Initialized
INFO - 2021-10-30 06:02:43 --> Loader Class Initialized
INFO - 2021-10-30 06:02:43 --> Helper loaded: url_helper
INFO - 2021-10-30 06:02:43 --> Helper loaded: file_helper
INFO - 2021-10-30 06:02:43 --> Helper loaded: form_helper
INFO - 2021-10-30 06:02:43 --> Helper loaded: my_helper
INFO - 2021-10-30 06:02:43 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:02:43 --> Controller Class Initialized
INFO - 2021-10-30 06:02:43 --> Final output sent to browser
DEBUG - 2021-10-30 06:02:43 --> Total execution time: 0.0500
INFO - 2021-10-30 06:02:43 --> Config Class Initialized
INFO - 2021-10-30 06:02:43 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:02:43 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:02:43 --> Utf8 Class Initialized
INFO - 2021-10-30 06:02:43 --> URI Class Initialized
INFO - 2021-10-30 06:02:43 --> Router Class Initialized
INFO - 2021-10-30 06:02:43 --> Output Class Initialized
INFO - 2021-10-30 06:02:43 --> Security Class Initialized
DEBUG - 2021-10-30 06:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:02:43 --> Input Class Initialized
INFO - 2021-10-30 06:02:43 --> Language Class Initialized
INFO - 2021-10-30 06:02:43 --> Language Class Initialized
INFO - 2021-10-30 06:02:43 --> Config Class Initialized
INFO - 2021-10-30 06:02:43 --> Loader Class Initialized
INFO - 2021-10-30 06:02:43 --> Helper loaded: url_helper
INFO - 2021-10-30 06:02:43 --> Helper loaded: file_helper
INFO - 2021-10-30 06:02:43 --> Helper loaded: form_helper
INFO - 2021-10-30 06:02:43 --> Helper loaded: my_helper
INFO - 2021-10-30 06:02:43 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:02:43 --> Controller Class Initialized
INFO - 2021-10-30 06:02:48 --> Config Class Initialized
INFO - 2021-10-30 06:02:48 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:02:48 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:02:48 --> Utf8 Class Initialized
INFO - 2021-10-30 06:02:48 --> URI Class Initialized
INFO - 2021-10-30 06:02:48 --> Router Class Initialized
INFO - 2021-10-30 06:02:48 --> Output Class Initialized
INFO - 2021-10-30 06:02:48 --> Security Class Initialized
DEBUG - 2021-10-30 06:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:02:48 --> Input Class Initialized
INFO - 2021-10-30 06:02:48 --> Language Class Initialized
INFO - 2021-10-30 06:02:48 --> Language Class Initialized
INFO - 2021-10-30 06:02:48 --> Config Class Initialized
INFO - 2021-10-30 06:02:48 --> Loader Class Initialized
INFO - 2021-10-30 06:02:48 --> Helper loaded: url_helper
INFO - 2021-10-30 06:02:48 --> Helper loaded: file_helper
INFO - 2021-10-30 06:02:48 --> Helper loaded: form_helper
INFO - 2021-10-30 06:02:48 --> Helper loaded: my_helper
INFO - 2021-10-30 06:02:48 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:02:48 --> Controller Class Initialized
INFO - 2021-10-30 06:02:48 --> Final output sent to browser
DEBUG - 2021-10-30 06:02:48 --> Total execution time: 0.0447
INFO - 2021-10-30 06:03:16 --> Config Class Initialized
INFO - 2021-10-30 06:03:16 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:03:16 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:03:16 --> Utf8 Class Initialized
INFO - 2021-10-30 06:03:16 --> URI Class Initialized
INFO - 2021-10-30 06:03:16 --> Router Class Initialized
INFO - 2021-10-30 06:03:16 --> Output Class Initialized
INFO - 2021-10-30 06:03:16 --> Security Class Initialized
DEBUG - 2021-10-30 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:03:16 --> Input Class Initialized
INFO - 2021-10-30 06:03:16 --> Language Class Initialized
INFO - 2021-10-30 06:03:16 --> Language Class Initialized
INFO - 2021-10-30 06:03:16 --> Config Class Initialized
INFO - 2021-10-30 06:03:16 --> Loader Class Initialized
INFO - 2021-10-30 06:03:16 --> Helper loaded: url_helper
INFO - 2021-10-30 06:03:16 --> Helper loaded: file_helper
INFO - 2021-10-30 06:03:16 --> Helper loaded: form_helper
INFO - 2021-10-30 06:03:16 --> Helper loaded: my_helper
INFO - 2021-10-30 06:03:16 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:03:16 --> Controller Class Initialized
INFO - 2021-10-30 06:03:16 --> Final output sent to browser
DEBUG - 2021-10-30 06:03:16 --> Total execution time: 0.0501
INFO - 2021-10-30 06:03:16 --> Config Class Initialized
INFO - 2021-10-30 06:03:16 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:03:16 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:03:16 --> Utf8 Class Initialized
INFO - 2021-10-30 06:03:16 --> URI Class Initialized
INFO - 2021-10-30 06:03:16 --> Router Class Initialized
INFO - 2021-10-30 06:03:16 --> Output Class Initialized
INFO - 2021-10-30 06:03:16 --> Security Class Initialized
DEBUG - 2021-10-30 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:03:16 --> Input Class Initialized
INFO - 2021-10-30 06:03:16 --> Language Class Initialized
INFO - 2021-10-30 06:03:16 --> Language Class Initialized
INFO - 2021-10-30 06:03:16 --> Config Class Initialized
INFO - 2021-10-30 06:03:16 --> Loader Class Initialized
INFO - 2021-10-30 06:03:16 --> Helper loaded: url_helper
INFO - 2021-10-30 06:03:16 --> Helper loaded: file_helper
INFO - 2021-10-30 06:03:16 --> Helper loaded: form_helper
INFO - 2021-10-30 06:03:16 --> Helper loaded: my_helper
INFO - 2021-10-30 06:03:16 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:03:16 --> Controller Class Initialized
INFO - 2021-10-30 06:07:29 --> Config Class Initialized
INFO - 2021-10-30 06:07:29 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:07:29 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:07:29 --> Utf8 Class Initialized
INFO - 2021-10-30 06:07:29 --> URI Class Initialized
INFO - 2021-10-30 06:07:29 --> Router Class Initialized
INFO - 2021-10-30 06:07:29 --> Output Class Initialized
INFO - 2021-10-30 06:07:29 --> Security Class Initialized
DEBUG - 2021-10-30 06:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:07:29 --> Input Class Initialized
INFO - 2021-10-30 06:07:29 --> Language Class Initialized
INFO - 2021-10-30 06:07:29 --> Language Class Initialized
INFO - 2021-10-30 06:07:29 --> Config Class Initialized
INFO - 2021-10-30 06:07:29 --> Loader Class Initialized
INFO - 2021-10-30 06:07:29 --> Helper loaded: url_helper
INFO - 2021-10-30 06:07:29 --> Helper loaded: file_helper
INFO - 2021-10-30 06:07:29 --> Helper loaded: form_helper
INFO - 2021-10-30 06:07:29 --> Helper loaded: my_helper
INFO - 2021-10-30 06:07:29 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:07:29 --> Controller Class Initialized
INFO - 2021-10-30 06:07:29 --> Final output sent to browser
DEBUG - 2021-10-30 06:07:29 --> Total execution time: 0.0483
INFO - 2021-10-30 06:07:45 --> Config Class Initialized
INFO - 2021-10-30 06:07:45 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:07:45 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:07:45 --> Utf8 Class Initialized
INFO - 2021-10-30 06:07:45 --> URI Class Initialized
INFO - 2021-10-30 06:07:45 --> Router Class Initialized
INFO - 2021-10-30 06:07:45 --> Output Class Initialized
INFO - 2021-10-30 06:07:45 --> Security Class Initialized
DEBUG - 2021-10-30 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:07:45 --> Input Class Initialized
INFO - 2021-10-30 06:07:45 --> Language Class Initialized
INFO - 2021-10-30 06:07:45 --> Language Class Initialized
INFO - 2021-10-30 06:07:45 --> Config Class Initialized
INFO - 2021-10-30 06:07:45 --> Loader Class Initialized
INFO - 2021-10-30 06:07:45 --> Helper loaded: url_helper
INFO - 2021-10-30 06:07:45 --> Helper loaded: file_helper
INFO - 2021-10-30 06:07:45 --> Helper loaded: form_helper
INFO - 2021-10-30 06:07:45 --> Helper loaded: my_helper
INFO - 2021-10-30 06:07:45 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:07:45 --> Controller Class Initialized
INFO - 2021-10-30 06:07:45 --> Final output sent to browser
DEBUG - 2021-10-30 06:07:45 --> Total execution time: 0.0479
INFO - 2021-10-30 06:07:45 --> Config Class Initialized
INFO - 2021-10-30 06:07:45 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:07:45 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:07:45 --> Utf8 Class Initialized
INFO - 2021-10-30 06:07:45 --> URI Class Initialized
INFO - 2021-10-30 06:07:45 --> Router Class Initialized
INFO - 2021-10-30 06:07:45 --> Output Class Initialized
INFO - 2021-10-30 06:07:45 --> Security Class Initialized
DEBUG - 2021-10-30 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:07:45 --> Input Class Initialized
INFO - 2021-10-30 06:07:45 --> Language Class Initialized
INFO - 2021-10-30 06:07:45 --> Language Class Initialized
INFO - 2021-10-30 06:07:45 --> Config Class Initialized
INFO - 2021-10-30 06:07:45 --> Loader Class Initialized
INFO - 2021-10-30 06:07:45 --> Helper loaded: url_helper
INFO - 2021-10-30 06:07:45 --> Helper loaded: file_helper
INFO - 2021-10-30 06:07:45 --> Helper loaded: form_helper
INFO - 2021-10-30 06:07:45 --> Helper loaded: my_helper
INFO - 2021-10-30 06:07:45 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:07:45 --> Controller Class Initialized
INFO - 2021-10-30 06:08:32 --> Config Class Initialized
INFO - 2021-10-30 06:08:32 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:08:32 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:08:32 --> Utf8 Class Initialized
INFO - 2021-10-30 06:08:32 --> URI Class Initialized
INFO - 2021-10-30 06:08:32 --> Router Class Initialized
INFO - 2021-10-30 06:08:32 --> Output Class Initialized
INFO - 2021-10-30 06:08:32 --> Security Class Initialized
DEBUG - 2021-10-30 06:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:08:32 --> Input Class Initialized
INFO - 2021-10-30 06:08:32 --> Language Class Initialized
INFO - 2021-10-30 06:08:32 --> Language Class Initialized
INFO - 2021-10-30 06:08:32 --> Config Class Initialized
INFO - 2021-10-30 06:08:32 --> Loader Class Initialized
INFO - 2021-10-30 06:08:32 --> Helper loaded: url_helper
INFO - 2021-10-30 06:08:32 --> Helper loaded: file_helper
INFO - 2021-10-30 06:08:32 --> Helper loaded: form_helper
INFO - 2021-10-30 06:08:32 --> Helper loaded: my_helper
INFO - 2021-10-30 06:08:32 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:08:32 --> Controller Class Initialized
INFO - 2021-10-30 06:08:32 --> Final output sent to browser
DEBUG - 2021-10-30 06:08:32 --> Total execution time: 0.0478
INFO - 2021-10-30 06:08:40 --> Config Class Initialized
INFO - 2021-10-30 06:08:40 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:08:40 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:08:40 --> Utf8 Class Initialized
INFO - 2021-10-30 06:08:40 --> URI Class Initialized
INFO - 2021-10-30 06:08:40 --> Router Class Initialized
INFO - 2021-10-30 06:08:40 --> Output Class Initialized
INFO - 2021-10-30 06:08:40 --> Security Class Initialized
DEBUG - 2021-10-30 06:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:08:40 --> Input Class Initialized
INFO - 2021-10-30 06:08:40 --> Language Class Initialized
INFO - 2021-10-30 06:08:40 --> Language Class Initialized
INFO - 2021-10-30 06:08:40 --> Config Class Initialized
INFO - 2021-10-30 06:08:40 --> Loader Class Initialized
INFO - 2021-10-30 06:08:40 --> Helper loaded: url_helper
INFO - 2021-10-30 06:08:40 --> Helper loaded: file_helper
INFO - 2021-10-30 06:08:40 --> Helper loaded: form_helper
INFO - 2021-10-30 06:08:40 --> Helper loaded: my_helper
INFO - 2021-10-30 06:08:40 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:08:40 --> Controller Class Initialized
INFO - 2021-10-30 06:08:40 --> Final output sent to browser
DEBUG - 2021-10-30 06:08:40 --> Total execution time: 0.0474
INFO - 2021-10-30 06:08:40 --> Config Class Initialized
INFO - 2021-10-30 06:08:40 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:08:40 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:08:40 --> Utf8 Class Initialized
INFO - 2021-10-30 06:08:40 --> URI Class Initialized
INFO - 2021-10-30 06:08:40 --> Router Class Initialized
INFO - 2021-10-30 06:08:40 --> Output Class Initialized
INFO - 2021-10-30 06:08:40 --> Security Class Initialized
DEBUG - 2021-10-30 06:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:08:40 --> Input Class Initialized
INFO - 2021-10-30 06:08:40 --> Language Class Initialized
INFO - 2021-10-30 06:08:40 --> Language Class Initialized
INFO - 2021-10-30 06:08:40 --> Config Class Initialized
INFO - 2021-10-30 06:08:40 --> Loader Class Initialized
INFO - 2021-10-30 06:08:40 --> Helper loaded: url_helper
INFO - 2021-10-30 06:08:40 --> Helper loaded: file_helper
INFO - 2021-10-30 06:08:40 --> Helper loaded: form_helper
INFO - 2021-10-30 06:08:40 --> Helper loaded: my_helper
INFO - 2021-10-30 06:08:40 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:08:40 --> Controller Class Initialized
INFO - 2021-10-30 06:27:03 --> Config Class Initialized
INFO - 2021-10-30 06:27:03 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:03 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:03 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:03 --> URI Class Initialized
INFO - 2021-10-30 06:27:03 --> Router Class Initialized
INFO - 2021-10-30 06:27:03 --> Output Class Initialized
INFO - 2021-10-30 06:27:03 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:03 --> Input Class Initialized
INFO - 2021-10-30 06:27:03 --> Language Class Initialized
INFO - 2021-10-30 06:27:03 --> Language Class Initialized
INFO - 2021-10-30 06:27:03 --> Config Class Initialized
INFO - 2021-10-30 06:27:03 --> Loader Class Initialized
INFO - 2021-10-30 06:27:03 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:03 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:03 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:03 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:03 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:03 --> Controller Class Initialized
DEBUG - 2021-10-30 06:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-10-30 06:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 06:27:03 --> Final output sent to browser
DEBUG - 2021-10-30 06:27:03 --> Total execution time: 0.0629
INFO - 2021-10-30 06:27:03 --> Config Class Initialized
INFO - 2021-10-30 06:27:03 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:03 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:03 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:03 --> URI Class Initialized
INFO - 2021-10-30 06:27:03 --> Router Class Initialized
INFO - 2021-10-30 06:27:03 --> Output Class Initialized
INFO - 2021-10-30 06:27:03 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:03 --> Input Class Initialized
INFO - 2021-10-30 06:27:03 --> Language Class Initialized
INFO - 2021-10-30 06:27:03 --> Language Class Initialized
INFO - 2021-10-30 06:27:03 --> Config Class Initialized
INFO - 2021-10-30 06:27:03 --> Loader Class Initialized
INFO - 2021-10-30 06:27:03 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:03 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:03 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:03 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:03 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:03 --> Controller Class Initialized
INFO - 2021-10-30 06:27:43 --> Config Class Initialized
INFO - 2021-10-30 06:27:43 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:43 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:43 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:43 --> URI Class Initialized
INFO - 2021-10-30 06:27:43 --> Router Class Initialized
INFO - 2021-10-30 06:27:43 --> Output Class Initialized
INFO - 2021-10-30 06:27:43 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:43 --> Input Class Initialized
INFO - 2021-10-30 06:27:43 --> Language Class Initialized
INFO - 2021-10-30 06:27:43 --> Language Class Initialized
INFO - 2021-10-30 06:27:43 --> Config Class Initialized
INFO - 2021-10-30 06:27:43 --> Loader Class Initialized
INFO - 2021-10-30 06:27:43 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:43 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:43 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:43 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:43 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:43 --> Controller Class Initialized
INFO - 2021-10-30 06:27:43 --> Final output sent to browser
DEBUG - 2021-10-30 06:27:43 --> Total execution time: 0.0654
INFO - 2021-10-30 06:27:43 --> Config Class Initialized
INFO - 2021-10-30 06:27:43 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:43 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:43 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:43 --> URI Class Initialized
INFO - 2021-10-30 06:27:43 --> Router Class Initialized
INFO - 2021-10-30 06:27:43 --> Output Class Initialized
INFO - 2021-10-30 06:27:43 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:43 --> Input Class Initialized
INFO - 2021-10-30 06:27:43 --> Language Class Initialized
INFO - 2021-10-30 06:27:43 --> Language Class Initialized
INFO - 2021-10-30 06:27:43 --> Config Class Initialized
INFO - 2021-10-30 06:27:43 --> Loader Class Initialized
INFO - 2021-10-30 06:27:43 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:43 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:43 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:43 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:43 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:43 --> Controller Class Initialized
INFO - 2021-10-30 06:27:48 --> Config Class Initialized
INFO - 2021-10-30 06:27:48 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:48 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:48 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:48 --> URI Class Initialized
INFO - 2021-10-30 06:27:48 --> Router Class Initialized
INFO - 2021-10-30 06:27:48 --> Output Class Initialized
INFO - 2021-10-30 06:27:48 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:48 --> Input Class Initialized
INFO - 2021-10-30 06:27:48 --> Language Class Initialized
INFO - 2021-10-30 06:27:48 --> Language Class Initialized
INFO - 2021-10-30 06:27:48 --> Config Class Initialized
INFO - 2021-10-30 06:27:48 --> Loader Class Initialized
INFO - 2021-10-30 06:27:48 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:48 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:48 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:48 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:48 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:49 --> Controller Class Initialized
DEBUG - 2021-10-30 06:27:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-10-30 06:27:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 06:27:49 --> Final output sent to browser
DEBUG - 2021-10-30 06:27:49 --> Total execution time: 0.0654
INFO - 2021-10-30 06:27:49 --> Config Class Initialized
INFO - 2021-10-30 06:27:49 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:49 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:49 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:49 --> URI Class Initialized
INFO - 2021-10-30 06:27:49 --> Router Class Initialized
INFO - 2021-10-30 06:27:49 --> Output Class Initialized
INFO - 2021-10-30 06:27:49 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:49 --> Input Class Initialized
INFO - 2021-10-30 06:27:49 --> Language Class Initialized
INFO - 2021-10-30 06:27:49 --> Language Class Initialized
INFO - 2021-10-30 06:27:49 --> Config Class Initialized
INFO - 2021-10-30 06:27:49 --> Loader Class Initialized
INFO - 2021-10-30 06:27:49 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:49 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:49 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:49 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:49 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:49 --> Controller Class Initialized
INFO - 2021-10-30 06:27:51 --> Config Class Initialized
INFO - 2021-10-30 06:27:51 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:51 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:51 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:51 --> URI Class Initialized
INFO - 2021-10-30 06:27:51 --> Router Class Initialized
INFO - 2021-10-30 06:27:51 --> Output Class Initialized
INFO - 2021-10-30 06:27:51 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:51 --> Input Class Initialized
INFO - 2021-10-30 06:27:51 --> Language Class Initialized
INFO - 2021-10-30 06:27:52 --> Language Class Initialized
INFO - 2021-10-30 06:27:52 --> Config Class Initialized
INFO - 2021-10-30 06:27:52 --> Loader Class Initialized
INFO - 2021-10-30 06:27:52 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:52 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:52 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:52 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:52 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:52 --> Controller Class Initialized
INFO - 2021-10-30 06:27:52 --> Config Class Initialized
INFO - 2021-10-30 06:27:52 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:52 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:52 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:52 --> URI Class Initialized
INFO - 2021-10-30 06:27:52 --> Router Class Initialized
INFO - 2021-10-30 06:27:52 --> Output Class Initialized
INFO - 2021-10-30 06:27:52 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:52 --> Input Class Initialized
INFO - 2021-10-30 06:27:52 --> Language Class Initialized
INFO - 2021-10-30 06:27:52 --> Language Class Initialized
INFO - 2021-10-30 06:27:52 --> Config Class Initialized
INFO - 2021-10-30 06:27:52 --> Loader Class Initialized
INFO - 2021-10-30 06:27:52 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:52 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:52 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:52 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:52 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:52 --> Controller Class Initialized
INFO - 2021-10-30 06:27:54 --> Config Class Initialized
INFO - 2021-10-30 06:27:54 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:27:54 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:27:54 --> Utf8 Class Initialized
INFO - 2021-10-30 06:27:54 --> URI Class Initialized
INFO - 2021-10-30 06:27:54 --> Router Class Initialized
INFO - 2021-10-30 06:27:54 --> Output Class Initialized
INFO - 2021-10-30 06:27:54 --> Security Class Initialized
DEBUG - 2021-10-30 06:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:27:54 --> Input Class Initialized
INFO - 2021-10-30 06:27:54 --> Language Class Initialized
INFO - 2021-10-30 06:27:54 --> Language Class Initialized
INFO - 2021-10-30 06:27:54 --> Config Class Initialized
INFO - 2021-10-30 06:27:54 --> Loader Class Initialized
INFO - 2021-10-30 06:27:54 --> Helper loaded: url_helper
INFO - 2021-10-30 06:27:54 --> Helper loaded: file_helper
INFO - 2021-10-30 06:27:54 --> Helper loaded: form_helper
INFO - 2021-10-30 06:27:54 --> Helper loaded: my_helper
INFO - 2021-10-30 06:27:54 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:27:54 --> Controller Class Initialized
ERROR - 2021-10-30 06:27:54 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-10-30 06:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-10-30 06:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 06:27:54 --> Final output sent to browser
DEBUG - 2021-10-30 06:27:54 --> Total execution time: 0.1231
INFO - 2021-10-30 06:28:09 --> Config Class Initialized
INFO - 2021-10-30 06:28:09 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:28:09 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:28:09 --> Utf8 Class Initialized
INFO - 2021-10-30 06:28:09 --> URI Class Initialized
INFO - 2021-10-30 06:28:09 --> Router Class Initialized
INFO - 2021-10-30 06:28:09 --> Output Class Initialized
INFO - 2021-10-30 06:28:09 --> Security Class Initialized
DEBUG - 2021-10-30 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:28:09 --> Input Class Initialized
INFO - 2021-10-30 06:28:09 --> Language Class Initialized
INFO - 2021-10-30 06:28:09 --> Language Class Initialized
INFO - 2021-10-30 06:28:09 --> Config Class Initialized
INFO - 2021-10-30 06:28:09 --> Loader Class Initialized
INFO - 2021-10-30 06:28:09 --> Helper loaded: url_helper
INFO - 2021-10-30 06:28:09 --> Helper loaded: file_helper
INFO - 2021-10-30 06:28:09 --> Helper loaded: form_helper
INFO - 2021-10-30 06:28:09 --> Helper loaded: my_helper
INFO - 2021-10-30 06:28:09 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:28:09 --> Controller Class Initialized
DEBUG - 2021-10-30 06:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-10-30 06:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 06:28:09 --> Final output sent to browser
DEBUG - 2021-10-30 06:28:09 --> Total execution time: 0.0722
INFO - 2021-10-30 06:28:09 --> Config Class Initialized
INFO - 2021-10-30 06:28:09 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:28:09 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:28:09 --> Utf8 Class Initialized
INFO - 2021-10-30 06:28:09 --> URI Class Initialized
INFO - 2021-10-30 06:28:09 --> Router Class Initialized
INFO - 2021-10-30 06:28:09 --> Output Class Initialized
INFO - 2021-10-30 06:28:09 --> Security Class Initialized
DEBUG - 2021-10-30 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:28:09 --> Input Class Initialized
INFO - 2021-10-30 06:28:09 --> Language Class Initialized
INFO - 2021-10-30 06:28:09 --> Language Class Initialized
INFO - 2021-10-30 06:28:09 --> Config Class Initialized
INFO - 2021-10-30 06:28:09 --> Loader Class Initialized
INFO - 2021-10-30 06:28:09 --> Helper loaded: url_helper
INFO - 2021-10-30 06:28:09 --> Helper loaded: file_helper
INFO - 2021-10-30 06:28:09 --> Helper loaded: form_helper
INFO - 2021-10-30 06:28:09 --> Helper loaded: my_helper
INFO - 2021-10-30 06:28:09 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:28:09 --> Controller Class Initialized
INFO - 2021-10-30 06:38:00 --> Config Class Initialized
INFO - 2021-10-30 06:38:00 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:38:00 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:38:00 --> Utf8 Class Initialized
INFO - 2021-10-30 06:38:00 --> URI Class Initialized
INFO - 2021-10-30 06:38:00 --> Router Class Initialized
INFO - 2021-10-30 06:38:00 --> Output Class Initialized
INFO - 2021-10-30 06:38:00 --> Security Class Initialized
DEBUG - 2021-10-30 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:38:00 --> Input Class Initialized
INFO - 2021-10-30 06:38:00 --> Language Class Initialized
INFO - 2021-10-30 06:38:00 --> Language Class Initialized
INFO - 2021-10-30 06:38:00 --> Config Class Initialized
INFO - 2021-10-30 06:38:00 --> Loader Class Initialized
INFO - 2021-10-30 06:38:00 --> Helper loaded: url_helper
INFO - 2021-10-30 06:38:00 --> Helper loaded: file_helper
INFO - 2021-10-30 06:38:00 --> Helper loaded: form_helper
INFO - 2021-10-30 06:38:00 --> Helper loaded: my_helper
INFO - 2021-10-30 06:38:00 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:38:00 --> Controller Class Initialized
DEBUG - 2021-10-30 06:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-10-30 06:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 06:38:01 --> Final output sent to browser
DEBUG - 2021-10-30 06:38:01 --> Total execution time: 0.0811
INFO - 2021-10-30 06:38:11 --> Config Class Initialized
INFO - 2021-10-30 06:38:11 --> Hooks Class Initialized
DEBUG - 2021-10-30 06:38:11 --> UTF-8 Support Enabled
INFO - 2021-10-30 06:38:11 --> Utf8 Class Initialized
INFO - 2021-10-30 06:38:11 --> URI Class Initialized
INFO - 2021-10-30 06:38:11 --> Router Class Initialized
INFO - 2021-10-30 06:38:11 --> Output Class Initialized
INFO - 2021-10-30 06:38:11 --> Security Class Initialized
DEBUG - 2021-10-30 06:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 06:38:11 --> Input Class Initialized
INFO - 2021-10-30 06:38:11 --> Language Class Initialized
INFO - 2021-10-30 06:38:11 --> Language Class Initialized
INFO - 2021-10-30 06:38:11 --> Config Class Initialized
INFO - 2021-10-30 06:38:11 --> Loader Class Initialized
INFO - 2021-10-30 06:38:11 --> Helper loaded: url_helper
INFO - 2021-10-30 06:38:11 --> Helper loaded: file_helper
INFO - 2021-10-30 06:38:11 --> Helper loaded: form_helper
INFO - 2021-10-30 06:38:11 --> Helper loaded: my_helper
INFO - 2021-10-30 06:38:11 --> Database Driver Class Initialized
DEBUG - 2021-10-30 06:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 06:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 06:38:11 --> Controller Class Initialized
DEBUG - 2021-10-30 06:38:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-10-30 06:38:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 06:38:11 --> Final output sent to browser
DEBUG - 2021-10-30 06:38:11 --> Total execution time: 0.0748
INFO - 2021-10-30 10:14:11 --> Config Class Initialized
INFO - 2021-10-30 10:14:11 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:11 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:11 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:11 --> URI Class Initialized
DEBUG - 2021-10-30 10:14:11 --> No URI present. Default controller set.
INFO - 2021-10-30 10:14:11 --> Router Class Initialized
INFO - 2021-10-30 10:14:11 --> Output Class Initialized
INFO - 2021-10-30 10:14:11 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:11 --> Input Class Initialized
INFO - 2021-10-30 10:14:11 --> Language Class Initialized
INFO - 2021-10-30 10:14:11 --> Language Class Initialized
INFO - 2021-10-30 10:14:11 --> Config Class Initialized
INFO - 2021-10-30 10:14:11 --> Loader Class Initialized
INFO - 2021-10-30 10:14:11 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:11 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:11 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:11 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:11 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:12 --> Controller Class Initialized
INFO - 2021-10-30 10:14:12 --> Config Class Initialized
INFO - 2021-10-30 10:14:12 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:12 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:12 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:12 --> URI Class Initialized
INFO - 2021-10-30 10:14:12 --> Router Class Initialized
INFO - 2021-10-30 10:14:12 --> Output Class Initialized
INFO - 2021-10-30 10:14:12 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:12 --> Input Class Initialized
INFO - 2021-10-30 10:14:12 --> Language Class Initialized
INFO - 2021-10-30 10:14:12 --> Language Class Initialized
INFO - 2021-10-30 10:14:12 --> Config Class Initialized
INFO - 2021-10-30 10:14:12 --> Loader Class Initialized
INFO - 2021-10-30 10:14:12 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:12 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:12 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:12 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:12 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:12 --> Controller Class Initialized
DEBUG - 2021-10-30 10:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:14:12 --> Final output sent to browser
DEBUG - 2021-10-30 10:14:12 --> Total execution time: 0.0983
INFO - 2021-10-30 10:14:23 --> Config Class Initialized
INFO - 2021-10-30 10:14:23 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:23 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:23 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:23 --> URI Class Initialized
INFO - 2021-10-30 10:14:23 --> Router Class Initialized
INFO - 2021-10-30 10:14:23 --> Output Class Initialized
INFO - 2021-10-30 10:14:23 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:23 --> Input Class Initialized
INFO - 2021-10-30 10:14:23 --> Language Class Initialized
INFO - 2021-10-30 10:14:23 --> Language Class Initialized
INFO - 2021-10-30 10:14:23 --> Config Class Initialized
INFO - 2021-10-30 10:14:23 --> Loader Class Initialized
INFO - 2021-10-30 10:14:23 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:23 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:23 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:23 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:23 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:23 --> Controller Class Initialized
INFO - 2021-10-30 10:14:23 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:14:23 --> Final output sent to browser
DEBUG - 2021-10-30 10:14:23 --> Total execution time: 0.0934
INFO - 2021-10-30 10:14:23 --> Config Class Initialized
INFO - 2021-10-30 10:14:23 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:23 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:23 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:23 --> URI Class Initialized
INFO - 2021-10-30 10:14:23 --> Router Class Initialized
INFO - 2021-10-30 10:14:23 --> Output Class Initialized
INFO - 2021-10-30 10:14:23 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:23 --> Input Class Initialized
INFO - 2021-10-30 10:14:23 --> Language Class Initialized
INFO - 2021-10-30 10:14:23 --> Language Class Initialized
INFO - 2021-10-30 10:14:23 --> Config Class Initialized
INFO - 2021-10-30 10:14:23 --> Loader Class Initialized
INFO - 2021-10-30 10:14:23 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:23 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:23 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:23 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:23 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:23 --> Controller Class Initialized
DEBUG - 2021-10-30 10:14:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:14:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:14:24 --> Final output sent to browser
DEBUG - 2021-10-30 10:14:24 --> Total execution time: 0.2343
INFO - 2021-10-30 10:14:29 --> Config Class Initialized
INFO - 2021-10-30 10:14:29 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:29 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:29 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:29 --> URI Class Initialized
INFO - 2021-10-30 10:14:29 --> Router Class Initialized
INFO - 2021-10-30 10:14:29 --> Output Class Initialized
INFO - 2021-10-30 10:14:29 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:29 --> Input Class Initialized
INFO - 2021-10-30 10:14:29 --> Language Class Initialized
INFO - 2021-10-30 10:14:29 --> Language Class Initialized
INFO - 2021-10-30 10:14:29 --> Config Class Initialized
INFO - 2021-10-30 10:14:29 --> Loader Class Initialized
INFO - 2021-10-30 10:14:29 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:29 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:29 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:29 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:29 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:29 --> Controller Class Initialized
DEBUG - 2021-10-30 10:14:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-10-30 10:14:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:14:29 --> Final output sent to browser
DEBUG - 2021-10-30 10:14:29 --> Total execution time: 0.0767
INFO - 2021-10-30 10:14:37 --> Config Class Initialized
INFO - 2021-10-30 10:14:37 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:37 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:37 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:37 --> URI Class Initialized
INFO - 2021-10-30 10:14:37 --> Router Class Initialized
INFO - 2021-10-30 10:14:37 --> Output Class Initialized
INFO - 2021-10-30 10:14:37 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:37 --> Input Class Initialized
INFO - 2021-10-30 10:14:37 --> Language Class Initialized
INFO - 2021-10-30 10:14:37 --> Language Class Initialized
INFO - 2021-10-30 10:14:37 --> Config Class Initialized
INFO - 2021-10-30 10:14:37 --> Loader Class Initialized
INFO - 2021-10-30 10:14:37 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:37 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:37 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:37 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:37 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:37 --> Controller Class Initialized
DEBUG - 2021-10-30 10:14:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xi.php
INFO - 2021-10-30 10:14:37 --> Final output sent to browser
DEBUG - 2021-10-30 10:14:37 --> Total execution time: 0.0965
INFO - 2021-10-30 10:14:53 --> Config Class Initialized
INFO - 2021-10-30 10:14:53 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:53 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:53 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:53 --> URI Class Initialized
INFO - 2021-10-30 10:14:53 --> Router Class Initialized
INFO - 2021-10-30 10:14:53 --> Output Class Initialized
INFO - 2021-10-30 10:14:53 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:53 --> Input Class Initialized
INFO - 2021-10-30 10:14:53 --> Language Class Initialized
INFO - 2021-10-30 10:14:53 --> Language Class Initialized
INFO - 2021-10-30 10:14:53 --> Config Class Initialized
INFO - 2021-10-30 10:14:53 --> Loader Class Initialized
INFO - 2021-10-30 10:14:53 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:53 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:53 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:53 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:53 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:53 --> Controller Class Initialized
INFO - 2021-10-30 10:14:53 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:14:53 --> Config Class Initialized
INFO - 2021-10-30 10:14:53 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:53 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:53 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:53 --> URI Class Initialized
INFO - 2021-10-30 10:14:53 --> Router Class Initialized
INFO - 2021-10-30 10:14:53 --> Output Class Initialized
INFO - 2021-10-30 10:14:53 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:53 --> Input Class Initialized
INFO - 2021-10-30 10:14:53 --> Language Class Initialized
INFO - 2021-10-30 10:14:53 --> Language Class Initialized
INFO - 2021-10-30 10:14:53 --> Config Class Initialized
INFO - 2021-10-30 10:14:53 --> Loader Class Initialized
INFO - 2021-10-30 10:14:53 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:53 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:53 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:53 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:53 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:53 --> Controller Class Initialized
DEBUG - 2021-10-30 10:14:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:14:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:14:53 --> Final output sent to browser
DEBUG - 2021-10-30 10:14:53 --> Total execution time: 0.0427
INFO - 2021-10-30 10:14:57 --> Config Class Initialized
INFO - 2021-10-30 10:14:57 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:57 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:57 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:57 --> URI Class Initialized
INFO - 2021-10-30 10:14:57 --> Router Class Initialized
INFO - 2021-10-30 10:14:57 --> Output Class Initialized
INFO - 2021-10-30 10:14:57 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:57 --> Input Class Initialized
INFO - 2021-10-30 10:14:57 --> Language Class Initialized
INFO - 2021-10-30 10:14:57 --> Language Class Initialized
INFO - 2021-10-30 10:14:57 --> Config Class Initialized
INFO - 2021-10-30 10:14:57 --> Loader Class Initialized
INFO - 2021-10-30 10:14:57 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:57 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:57 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:57 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:57 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:57 --> Controller Class Initialized
INFO - 2021-10-30 10:14:57 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:14:57 --> Final output sent to browser
DEBUG - 2021-10-30 10:14:57 --> Total execution time: 0.0542
INFO - 2021-10-30 10:14:58 --> Config Class Initialized
INFO - 2021-10-30 10:14:58 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:14:58 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:14:58 --> Utf8 Class Initialized
INFO - 2021-10-30 10:14:58 --> URI Class Initialized
INFO - 2021-10-30 10:14:58 --> Router Class Initialized
INFO - 2021-10-30 10:14:58 --> Output Class Initialized
INFO - 2021-10-30 10:14:58 --> Security Class Initialized
DEBUG - 2021-10-30 10:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:14:58 --> Input Class Initialized
INFO - 2021-10-30 10:14:58 --> Language Class Initialized
INFO - 2021-10-30 10:14:58 --> Language Class Initialized
INFO - 2021-10-30 10:14:58 --> Config Class Initialized
INFO - 2021-10-30 10:14:58 --> Loader Class Initialized
INFO - 2021-10-30 10:14:58 --> Helper loaded: url_helper
INFO - 2021-10-30 10:14:58 --> Helper loaded: file_helper
INFO - 2021-10-30 10:14:58 --> Helper loaded: form_helper
INFO - 2021-10-30 10:14:58 --> Helper loaded: my_helper
INFO - 2021-10-30 10:14:58 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:14:58 --> Controller Class Initialized
DEBUG - 2021-10-30 10:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:14:58 --> Final output sent to browser
DEBUG - 2021-10-30 10:14:58 --> Total execution time: 0.0838
INFO - 2021-10-30 10:15:00 --> Config Class Initialized
INFO - 2021-10-30 10:15:00 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:00 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:00 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:00 --> URI Class Initialized
INFO - 2021-10-30 10:15:00 --> Router Class Initialized
INFO - 2021-10-30 10:15:00 --> Output Class Initialized
INFO - 2021-10-30 10:15:00 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:00 --> Input Class Initialized
INFO - 2021-10-30 10:15:00 --> Language Class Initialized
INFO - 2021-10-30 10:15:00 --> Language Class Initialized
INFO - 2021-10-30 10:15:00 --> Config Class Initialized
INFO - 2021-10-30 10:15:00 --> Loader Class Initialized
INFO - 2021-10-30 10:15:00 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:00 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:00 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:00 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:00 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:00 --> Controller Class Initialized
DEBUG - 2021-10-30 10:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-10-30 10:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:15:00 --> Final output sent to browser
DEBUG - 2021-10-30 10:15:00 --> Total execution time: 0.0637
INFO - 2021-10-30 10:15:00 --> Config Class Initialized
INFO - 2021-10-30 10:15:00 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:00 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:00 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:00 --> URI Class Initialized
INFO - 2021-10-30 10:15:00 --> Router Class Initialized
INFO - 2021-10-30 10:15:00 --> Output Class Initialized
INFO - 2021-10-30 10:15:00 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:00 --> Input Class Initialized
INFO - 2021-10-30 10:15:00 --> Language Class Initialized
INFO - 2021-10-30 10:15:00 --> Language Class Initialized
INFO - 2021-10-30 10:15:00 --> Config Class Initialized
INFO - 2021-10-30 10:15:00 --> Loader Class Initialized
INFO - 2021-10-30 10:15:00 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:00 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:00 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:00 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:00 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:00 --> Controller Class Initialized
INFO - 2021-10-30 10:15:02 --> Config Class Initialized
INFO - 2021-10-30 10:15:02 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:02 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:02 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:02 --> URI Class Initialized
INFO - 2021-10-30 10:15:02 --> Router Class Initialized
INFO - 2021-10-30 10:15:02 --> Output Class Initialized
INFO - 2021-10-30 10:15:02 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:02 --> Input Class Initialized
INFO - 2021-10-30 10:15:02 --> Language Class Initialized
INFO - 2021-10-30 10:15:02 --> Language Class Initialized
INFO - 2021-10-30 10:15:02 --> Config Class Initialized
INFO - 2021-10-30 10:15:02 --> Loader Class Initialized
INFO - 2021-10-30 10:15:02 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:02 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:02 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:02 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:02 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:02 --> Controller Class Initialized
INFO - 2021-10-30 10:15:02 --> Final output sent to browser
DEBUG - 2021-10-30 10:15:02 --> Total execution time: 0.0668
INFO - 2021-10-30 10:15:03 --> Config Class Initialized
INFO - 2021-10-30 10:15:03 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:03 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:03 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:03 --> URI Class Initialized
INFO - 2021-10-30 10:15:03 --> Router Class Initialized
INFO - 2021-10-30 10:15:03 --> Output Class Initialized
INFO - 2021-10-30 10:15:03 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:03 --> Input Class Initialized
INFO - 2021-10-30 10:15:03 --> Language Class Initialized
INFO - 2021-10-30 10:15:03 --> Language Class Initialized
INFO - 2021-10-30 10:15:03 --> Config Class Initialized
INFO - 2021-10-30 10:15:03 --> Loader Class Initialized
INFO - 2021-10-30 10:15:03 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:03 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:03 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:03 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:03 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:03 --> Controller Class Initialized
INFO - 2021-10-30 10:15:05 --> Config Class Initialized
INFO - 2021-10-30 10:15:05 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:05 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:05 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:05 --> URI Class Initialized
INFO - 2021-10-30 10:15:05 --> Router Class Initialized
INFO - 2021-10-30 10:15:05 --> Output Class Initialized
INFO - 2021-10-30 10:15:05 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:05 --> Input Class Initialized
INFO - 2021-10-30 10:15:05 --> Language Class Initialized
INFO - 2021-10-30 10:15:05 --> Language Class Initialized
INFO - 2021-10-30 10:15:05 --> Config Class Initialized
INFO - 2021-10-30 10:15:05 --> Loader Class Initialized
INFO - 2021-10-30 10:15:05 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:05 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:05 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:05 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:05 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:05 --> Controller Class Initialized
INFO - 2021-10-30 10:15:05 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:15:05 --> Config Class Initialized
INFO - 2021-10-30 10:15:05 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:05 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:05 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:05 --> URI Class Initialized
INFO - 2021-10-30 10:15:05 --> Router Class Initialized
INFO - 2021-10-30 10:15:05 --> Output Class Initialized
INFO - 2021-10-30 10:15:05 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:05 --> Input Class Initialized
INFO - 2021-10-30 10:15:05 --> Language Class Initialized
INFO - 2021-10-30 10:15:05 --> Language Class Initialized
INFO - 2021-10-30 10:15:05 --> Config Class Initialized
INFO - 2021-10-30 10:15:05 --> Loader Class Initialized
INFO - 2021-10-30 10:15:05 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:05 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:05 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:05 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:05 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:05 --> Controller Class Initialized
DEBUG - 2021-10-30 10:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:15:05 --> Final output sent to browser
DEBUG - 2021-10-30 10:15:05 --> Total execution time: 0.0441
INFO - 2021-10-30 10:15:11 --> Config Class Initialized
INFO - 2021-10-30 10:15:11 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:11 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:11 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:11 --> URI Class Initialized
INFO - 2021-10-30 10:15:11 --> Router Class Initialized
INFO - 2021-10-30 10:15:11 --> Output Class Initialized
INFO - 2021-10-30 10:15:11 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:11 --> Input Class Initialized
INFO - 2021-10-30 10:15:11 --> Language Class Initialized
INFO - 2021-10-30 10:15:11 --> Language Class Initialized
INFO - 2021-10-30 10:15:11 --> Config Class Initialized
INFO - 2021-10-30 10:15:11 --> Loader Class Initialized
INFO - 2021-10-30 10:15:11 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:11 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:11 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:11 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:11 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:11 --> Controller Class Initialized
INFO - 2021-10-30 10:15:11 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:15:11 --> Final output sent to browser
DEBUG - 2021-10-30 10:15:11 --> Total execution time: 0.0459
INFO - 2021-10-30 10:15:12 --> Config Class Initialized
INFO - 2021-10-30 10:15:12 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:12 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:12 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:12 --> URI Class Initialized
INFO - 2021-10-30 10:15:12 --> Router Class Initialized
INFO - 2021-10-30 10:15:12 --> Output Class Initialized
INFO - 2021-10-30 10:15:12 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:12 --> Input Class Initialized
INFO - 2021-10-30 10:15:12 --> Language Class Initialized
INFO - 2021-10-30 10:15:12 --> Language Class Initialized
INFO - 2021-10-30 10:15:12 --> Config Class Initialized
INFO - 2021-10-30 10:15:12 --> Loader Class Initialized
INFO - 2021-10-30 10:15:12 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:12 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:12 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:12 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:12 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:12 --> Controller Class Initialized
DEBUG - 2021-10-30 10:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:15:12 --> Final output sent to browser
DEBUG - 2021-10-30 10:15:12 --> Total execution time: 0.6657
INFO - 2021-10-30 10:15:15 --> Config Class Initialized
INFO - 2021-10-30 10:15:15 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:15 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:15 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:15 --> URI Class Initialized
INFO - 2021-10-30 10:15:15 --> Router Class Initialized
INFO - 2021-10-30 10:15:15 --> Output Class Initialized
INFO - 2021-10-30 10:15:15 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:15 --> Input Class Initialized
INFO - 2021-10-30 10:15:15 --> Language Class Initialized
INFO - 2021-10-30 10:15:15 --> Language Class Initialized
INFO - 2021-10-30 10:15:15 --> Config Class Initialized
INFO - 2021-10-30 10:15:15 --> Loader Class Initialized
INFO - 2021-10-30 10:15:15 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:15 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:15 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:15 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:15 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:15 --> Controller Class Initialized
DEBUG - 2021-10-30 10:15:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-10-30 10:15:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:15:15 --> Final output sent to browser
DEBUG - 2021-10-30 10:15:15 --> Total execution time: 0.0664
INFO - 2021-10-30 10:15:16 --> Config Class Initialized
INFO - 2021-10-30 10:15:16 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:15:16 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:15:16 --> Utf8 Class Initialized
INFO - 2021-10-30 10:15:16 --> URI Class Initialized
INFO - 2021-10-30 10:15:16 --> Router Class Initialized
INFO - 2021-10-30 10:15:16 --> Output Class Initialized
INFO - 2021-10-30 10:15:16 --> Security Class Initialized
DEBUG - 2021-10-30 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:15:16 --> Input Class Initialized
INFO - 2021-10-30 10:15:16 --> Language Class Initialized
INFO - 2021-10-30 10:15:16 --> Language Class Initialized
INFO - 2021-10-30 10:15:16 --> Config Class Initialized
INFO - 2021-10-30 10:15:16 --> Loader Class Initialized
INFO - 2021-10-30 10:15:16 --> Helper loaded: url_helper
INFO - 2021-10-30 10:15:16 --> Helper loaded: file_helper
INFO - 2021-10-30 10:15:16 --> Helper loaded: form_helper
INFO - 2021-10-30 10:15:16 --> Helper loaded: my_helper
INFO - 2021-10-30 10:15:16 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:15:16 --> Controller Class Initialized
DEBUG - 2021-10-30 10:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xi.php
INFO - 2021-10-30 10:15:16 --> Final output sent to browser
DEBUG - 2021-10-30 10:15:16 --> Total execution time: 0.2665
INFO - 2021-10-30 10:16:08 --> Config Class Initialized
INFO - 2021-10-30 10:16:08 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:16:08 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:16:08 --> Utf8 Class Initialized
INFO - 2021-10-30 10:16:08 --> URI Class Initialized
INFO - 2021-10-30 10:16:08 --> Router Class Initialized
INFO - 2021-10-30 10:16:08 --> Output Class Initialized
INFO - 2021-10-30 10:16:08 --> Security Class Initialized
DEBUG - 2021-10-30 10:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:16:08 --> Input Class Initialized
INFO - 2021-10-30 10:16:08 --> Language Class Initialized
INFO - 2021-10-30 10:16:08 --> Language Class Initialized
INFO - 2021-10-30 10:16:08 --> Config Class Initialized
INFO - 2021-10-30 10:16:08 --> Loader Class Initialized
INFO - 2021-10-30 10:16:08 --> Helper loaded: url_helper
INFO - 2021-10-30 10:16:08 --> Helper loaded: file_helper
INFO - 2021-10-30 10:16:08 --> Helper loaded: form_helper
INFO - 2021-10-30 10:16:08 --> Helper loaded: my_helper
INFO - 2021-10-30 10:16:08 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:16:08 --> Controller Class Initialized
INFO - 2021-10-30 10:16:08 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:16:08 --> Config Class Initialized
INFO - 2021-10-30 10:16:08 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:16:08 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:16:08 --> Utf8 Class Initialized
INFO - 2021-10-30 10:16:08 --> URI Class Initialized
INFO - 2021-10-30 10:16:08 --> Router Class Initialized
INFO - 2021-10-30 10:16:08 --> Output Class Initialized
INFO - 2021-10-30 10:16:08 --> Security Class Initialized
DEBUG - 2021-10-30 10:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:16:08 --> Input Class Initialized
INFO - 2021-10-30 10:16:08 --> Language Class Initialized
INFO - 2021-10-30 10:16:08 --> Language Class Initialized
INFO - 2021-10-30 10:16:08 --> Config Class Initialized
INFO - 2021-10-30 10:16:08 --> Loader Class Initialized
INFO - 2021-10-30 10:16:08 --> Helper loaded: url_helper
INFO - 2021-10-30 10:16:08 --> Helper loaded: file_helper
INFO - 2021-10-30 10:16:08 --> Helper loaded: form_helper
INFO - 2021-10-30 10:16:08 --> Helper loaded: my_helper
INFO - 2021-10-30 10:16:08 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:16:08 --> Controller Class Initialized
DEBUG - 2021-10-30 10:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:16:08 --> Final output sent to browser
DEBUG - 2021-10-30 10:16:08 --> Total execution time: 0.0407
INFO - 2021-10-30 10:16:13 --> Config Class Initialized
INFO - 2021-10-30 10:16:13 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:16:13 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:16:13 --> Utf8 Class Initialized
INFO - 2021-10-30 10:16:13 --> URI Class Initialized
INFO - 2021-10-30 10:16:13 --> Router Class Initialized
INFO - 2021-10-30 10:16:13 --> Output Class Initialized
INFO - 2021-10-30 10:16:13 --> Security Class Initialized
DEBUG - 2021-10-30 10:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:16:13 --> Input Class Initialized
INFO - 2021-10-30 10:16:13 --> Language Class Initialized
INFO - 2021-10-30 10:16:13 --> Language Class Initialized
INFO - 2021-10-30 10:16:13 --> Config Class Initialized
INFO - 2021-10-30 10:16:13 --> Loader Class Initialized
INFO - 2021-10-30 10:16:13 --> Helper loaded: url_helper
INFO - 2021-10-30 10:16:13 --> Helper loaded: file_helper
INFO - 2021-10-30 10:16:13 --> Helper loaded: form_helper
INFO - 2021-10-30 10:16:13 --> Helper loaded: my_helper
INFO - 2021-10-30 10:16:13 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:16:13 --> Controller Class Initialized
INFO - 2021-10-30 10:16:13 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:16:13 --> Final output sent to browser
DEBUG - 2021-10-30 10:16:13 --> Total execution time: 0.0574
INFO - 2021-10-30 10:16:13 --> Config Class Initialized
INFO - 2021-10-30 10:16:13 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:16:13 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:16:13 --> Utf8 Class Initialized
INFO - 2021-10-30 10:16:13 --> URI Class Initialized
INFO - 2021-10-30 10:16:13 --> Router Class Initialized
INFO - 2021-10-30 10:16:13 --> Output Class Initialized
INFO - 2021-10-30 10:16:13 --> Security Class Initialized
DEBUG - 2021-10-30 10:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:16:13 --> Input Class Initialized
INFO - 2021-10-30 10:16:13 --> Language Class Initialized
INFO - 2021-10-30 10:16:13 --> Language Class Initialized
INFO - 2021-10-30 10:16:13 --> Config Class Initialized
INFO - 2021-10-30 10:16:13 --> Loader Class Initialized
INFO - 2021-10-30 10:16:13 --> Helper loaded: url_helper
INFO - 2021-10-30 10:16:13 --> Helper loaded: file_helper
INFO - 2021-10-30 10:16:13 --> Helper loaded: form_helper
INFO - 2021-10-30 10:16:13 --> Helper loaded: my_helper
INFO - 2021-10-30 10:16:13 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:16:13 --> Controller Class Initialized
DEBUG - 2021-10-30 10:16:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:16:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:16:14 --> Final output sent to browser
DEBUG - 2021-10-30 10:16:14 --> Total execution time: 0.7613
INFO - 2021-10-30 10:16:16 --> Config Class Initialized
INFO - 2021-10-30 10:16:16 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:16:16 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:16:16 --> Utf8 Class Initialized
INFO - 2021-10-30 10:16:16 --> URI Class Initialized
INFO - 2021-10-30 10:16:16 --> Router Class Initialized
INFO - 2021-10-30 10:16:16 --> Output Class Initialized
INFO - 2021-10-30 10:16:16 --> Security Class Initialized
DEBUG - 2021-10-30 10:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:16:16 --> Input Class Initialized
INFO - 2021-10-30 10:16:16 --> Language Class Initialized
INFO - 2021-10-30 10:16:16 --> Language Class Initialized
INFO - 2021-10-30 10:16:16 --> Config Class Initialized
INFO - 2021-10-30 10:16:16 --> Loader Class Initialized
INFO - 2021-10-30 10:16:16 --> Helper loaded: url_helper
INFO - 2021-10-30 10:16:16 --> Helper loaded: file_helper
INFO - 2021-10-30 10:16:16 --> Helper loaded: form_helper
INFO - 2021-10-30 10:16:16 --> Helper loaded: my_helper
INFO - 2021-10-30 10:16:16 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:16:16 --> Controller Class Initialized
DEBUG - 2021-10-30 10:16:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-10-30 10:16:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:16:16 --> Final output sent to browser
DEBUG - 2021-10-30 10:16:16 --> Total execution time: 0.0512
INFO - 2021-10-30 10:16:20 --> Config Class Initialized
INFO - 2021-10-30 10:16:20 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:16:20 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:16:20 --> Utf8 Class Initialized
INFO - 2021-10-30 10:16:20 --> URI Class Initialized
INFO - 2021-10-30 10:16:20 --> Router Class Initialized
INFO - 2021-10-30 10:16:20 --> Output Class Initialized
INFO - 2021-10-30 10:16:20 --> Security Class Initialized
DEBUG - 2021-10-30 10:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:16:20 --> Input Class Initialized
INFO - 2021-10-30 10:16:20 --> Language Class Initialized
INFO - 2021-10-30 10:16:20 --> Language Class Initialized
INFO - 2021-10-30 10:16:20 --> Config Class Initialized
INFO - 2021-10-30 10:16:20 --> Loader Class Initialized
INFO - 2021-10-30 10:16:20 --> Helper loaded: url_helper
INFO - 2021-10-30 10:16:20 --> Helper loaded: file_helper
INFO - 2021-10-30 10:16:20 --> Helper loaded: form_helper
INFO - 2021-10-30 10:16:20 --> Helper loaded: my_helper
INFO - 2021-10-30 10:16:20 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:16:20 --> Controller Class Initialized
DEBUG - 2021-10-30 10:16:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-10-30 10:16:20 --> Final output sent to browser
DEBUG - 2021-10-30 10:16:20 --> Total execution time: 0.2704
INFO - 2021-10-30 10:17:30 --> Config Class Initialized
INFO - 2021-10-30 10:17:30 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:17:30 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:17:30 --> Utf8 Class Initialized
INFO - 2021-10-30 10:17:30 --> URI Class Initialized
INFO - 2021-10-30 10:17:30 --> Router Class Initialized
INFO - 2021-10-30 10:17:30 --> Output Class Initialized
INFO - 2021-10-30 10:17:30 --> Security Class Initialized
DEBUG - 2021-10-30 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:17:30 --> Input Class Initialized
INFO - 2021-10-30 10:17:30 --> Language Class Initialized
INFO - 2021-10-30 10:17:30 --> Language Class Initialized
INFO - 2021-10-30 10:17:30 --> Config Class Initialized
INFO - 2021-10-30 10:17:30 --> Loader Class Initialized
INFO - 2021-10-30 10:17:30 --> Helper loaded: url_helper
INFO - 2021-10-30 10:17:30 --> Helper loaded: file_helper
INFO - 2021-10-30 10:17:30 --> Helper loaded: form_helper
INFO - 2021-10-30 10:17:30 --> Helper loaded: my_helper
INFO - 2021-10-30 10:17:30 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:17:30 --> Controller Class Initialized
INFO - 2021-10-30 10:17:30 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:17:30 --> Config Class Initialized
INFO - 2021-10-30 10:17:30 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:17:30 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:17:30 --> Utf8 Class Initialized
INFO - 2021-10-30 10:17:30 --> URI Class Initialized
INFO - 2021-10-30 10:17:30 --> Router Class Initialized
INFO - 2021-10-30 10:17:30 --> Output Class Initialized
INFO - 2021-10-30 10:17:30 --> Security Class Initialized
DEBUG - 2021-10-30 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:17:30 --> Input Class Initialized
INFO - 2021-10-30 10:17:30 --> Language Class Initialized
INFO - 2021-10-30 10:17:30 --> Language Class Initialized
INFO - 2021-10-30 10:17:30 --> Config Class Initialized
INFO - 2021-10-30 10:17:30 --> Loader Class Initialized
INFO - 2021-10-30 10:17:30 --> Helper loaded: url_helper
INFO - 2021-10-30 10:17:30 --> Helper loaded: file_helper
INFO - 2021-10-30 10:17:30 --> Helper loaded: form_helper
INFO - 2021-10-30 10:17:30 --> Helper loaded: my_helper
INFO - 2021-10-30 10:17:30 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:17:30 --> Controller Class Initialized
DEBUG - 2021-10-30 10:17:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:17:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:17:30 --> Final output sent to browser
DEBUG - 2021-10-30 10:17:30 --> Total execution time: 0.0646
INFO - 2021-10-30 10:51:00 --> Config Class Initialized
INFO - 2021-10-30 10:51:00 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:00 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:00 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:00 --> URI Class Initialized
INFO - 2021-10-30 10:51:00 --> Router Class Initialized
INFO - 2021-10-30 10:51:00 --> Output Class Initialized
INFO - 2021-10-30 10:51:00 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:00 --> Input Class Initialized
INFO - 2021-10-30 10:51:00 --> Language Class Initialized
INFO - 2021-10-30 10:51:00 --> Language Class Initialized
INFO - 2021-10-30 10:51:00 --> Config Class Initialized
INFO - 2021-10-30 10:51:00 --> Loader Class Initialized
INFO - 2021-10-30 10:51:00 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:00 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:00 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:00 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:00 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:01 --> Controller Class Initialized
DEBUG - 2021-10-30 10:51:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:51:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:51:01 --> Final output sent to browser
DEBUG - 2021-10-30 10:51:01 --> Total execution time: 0.7246
INFO - 2021-10-30 10:51:08 --> Config Class Initialized
INFO - 2021-10-30 10:51:08 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:08 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:08 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:08 --> URI Class Initialized
INFO - 2021-10-30 10:51:08 --> Router Class Initialized
INFO - 2021-10-30 10:51:08 --> Output Class Initialized
INFO - 2021-10-30 10:51:08 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:08 --> Input Class Initialized
INFO - 2021-10-30 10:51:08 --> Language Class Initialized
INFO - 2021-10-30 10:51:08 --> Language Class Initialized
INFO - 2021-10-30 10:51:08 --> Config Class Initialized
INFO - 2021-10-30 10:51:08 --> Loader Class Initialized
INFO - 2021-10-30 10:51:08 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:08 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:08 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:08 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:08 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:08 --> Controller Class Initialized
INFO - 2021-10-30 10:51:08 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:51:08 --> Final output sent to browser
DEBUG - 2021-10-30 10:51:08 --> Total execution time: 0.0877
INFO - 2021-10-30 10:51:08 --> Config Class Initialized
INFO - 2021-10-30 10:51:08 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:08 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:08 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:08 --> URI Class Initialized
INFO - 2021-10-30 10:51:08 --> Router Class Initialized
INFO - 2021-10-30 10:51:08 --> Output Class Initialized
INFO - 2021-10-30 10:51:08 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:08 --> Input Class Initialized
INFO - 2021-10-30 10:51:08 --> Language Class Initialized
INFO - 2021-10-30 10:51:08 --> Language Class Initialized
INFO - 2021-10-30 10:51:08 --> Config Class Initialized
INFO - 2021-10-30 10:51:08 --> Loader Class Initialized
INFO - 2021-10-30 10:51:08 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:08 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:08 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:08 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:08 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:08 --> Controller Class Initialized
DEBUG - 2021-10-30 10:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:51:09 --> Final output sent to browser
DEBUG - 2021-10-30 10:51:09 --> Total execution time: 0.8700
INFO - 2021-10-30 10:51:10 --> Config Class Initialized
INFO - 2021-10-30 10:51:10 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:10 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:10 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:10 --> URI Class Initialized
INFO - 2021-10-30 10:51:10 --> Router Class Initialized
INFO - 2021-10-30 10:51:10 --> Output Class Initialized
INFO - 2021-10-30 10:51:10 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:10 --> Input Class Initialized
INFO - 2021-10-30 10:51:10 --> Language Class Initialized
INFO - 2021-10-30 10:51:10 --> Language Class Initialized
INFO - 2021-10-30 10:51:10 --> Config Class Initialized
INFO - 2021-10-30 10:51:10 --> Loader Class Initialized
INFO - 2021-10-30 10:51:10 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:10 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:10 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:10 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:10 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:10 --> Controller Class Initialized
DEBUG - 2021-10-30 10:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-10-30 10:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:51:10 --> Final output sent to browser
DEBUG - 2021-10-30 10:51:10 --> Total execution time: 0.0876
INFO - 2021-10-30 10:51:10 --> Config Class Initialized
INFO - 2021-10-30 10:51:10 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:10 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:10 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:10 --> URI Class Initialized
INFO - 2021-10-30 10:51:10 --> Router Class Initialized
INFO - 2021-10-30 10:51:10 --> Output Class Initialized
INFO - 2021-10-30 10:51:10 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:10 --> Input Class Initialized
INFO - 2021-10-30 10:51:10 --> Language Class Initialized
INFO - 2021-10-30 10:51:10 --> Language Class Initialized
INFO - 2021-10-30 10:51:10 --> Config Class Initialized
INFO - 2021-10-30 10:51:10 --> Loader Class Initialized
INFO - 2021-10-30 10:51:10 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:10 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:10 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:10 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:10 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:11 --> Controller Class Initialized
INFO - 2021-10-30 10:51:21 --> Config Class Initialized
INFO - 2021-10-30 10:51:21 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:21 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:21 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:21 --> URI Class Initialized
INFO - 2021-10-30 10:51:21 --> Router Class Initialized
INFO - 2021-10-30 10:51:21 --> Output Class Initialized
INFO - 2021-10-30 10:51:21 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:21 --> Input Class Initialized
INFO - 2021-10-30 10:51:21 --> Language Class Initialized
INFO - 2021-10-30 10:51:21 --> Language Class Initialized
INFO - 2021-10-30 10:51:21 --> Config Class Initialized
INFO - 2021-10-30 10:51:21 --> Loader Class Initialized
INFO - 2021-10-30 10:51:21 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:21 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:21 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:21 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:21 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:21 --> Controller Class Initialized
INFO - 2021-10-30 10:51:21 --> Config Class Initialized
INFO - 2021-10-30 10:51:21 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:21 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:21 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:21 --> URI Class Initialized
INFO - 2021-10-30 10:51:21 --> Router Class Initialized
INFO - 2021-10-30 10:51:21 --> Output Class Initialized
INFO - 2021-10-30 10:51:21 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:21 --> Input Class Initialized
INFO - 2021-10-30 10:51:21 --> Language Class Initialized
INFO - 2021-10-30 10:51:21 --> Language Class Initialized
INFO - 2021-10-30 10:51:21 --> Config Class Initialized
INFO - 2021-10-30 10:51:21 --> Loader Class Initialized
INFO - 2021-10-30 10:51:21 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:21 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:21 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:21 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:21 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:21 --> Controller Class Initialized
INFO - 2021-10-30 10:51:25 --> Config Class Initialized
INFO - 2021-10-30 10:51:25 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:25 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:25 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:25 --> URI Class Initialized
INFO - 2021-10-30 10:51:25 --> Router Class Initialized
INFO - 2021-10-30 10:51:25 --> Output Class Initialized
INFO - 2021-10-30 10:51:25 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:25 --> Input Class Initialized
INFO - 2021-10-30 10:51:25 --> Language Class Initialized
INFO - 2021-10-30 10:51:25 --> Language Class Initialized
INFO - 2021-10-30 10:51:25 --> Config Class Initialized
INFO - 2021-10-30 10:51:25 --> Loader Class Initialized
INFO - 2021-10-30 10:51:25 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:25 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:25 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:25 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:26 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:26 --> Controller Class Initialized
INFO - 2021-10-30 10:51:26 --> Final output sent to browser
DEBUG - 2021-10-30 10:51:26 --> Total execution time: 0.0541
INFO - 2021-10-30 10:51:26 --> Config Class Initialized
INFO - 2021-10-30 10:51:26 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:26 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:26 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:26 --> URI Class Initialized
INFO - 2021-10-30 10:51:26 --> Router Class Initialized
INFO - 2021-10-30 10:51:26 --> Output Class Initialized
INFO - 2021-10-30 10:51:26 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:26 --> Input Class Initialized
INFO - 2021-10-30 10:51:26 --> Language Class Initialized
INFO - 2021-10-30 10:51:26 --> Language Class Initialized
INFO - 2021-10-30 10:51:26 --> Config Class Initialized
INFO - 2021-10-30 10:51:26 --> Loader Class Initialized
INFO - 2021-10-30 10:51:26 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:26 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:26 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:26 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:26 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:26 --> Controller Class Initialized
INFO - 2021-10-30 10:51:27 --> Config Class Initialized
INFO - 2021-10-30 10:51:27 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:27 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:27 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:27 --> URI Class Initialized
INFO - 2021-10-30 10:51:27 --> Router Class Initialized
INFO - 2021-10-30 10:51:27 --> Output Class Initialized
INFO - 2021-10-30 10:51:27 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:27 --> Input Class Initialized
INFO - 2021-10-30 10:51:27 --> Language Class Initialized
INFO - 2021-10-30 10:51:27 --> Language Class Initialized
INFO - 2021-10-30 10:51:27 --> Config Class Initialized
INFO - 2021-10-30 10:51:27 --> Loader Class Initialized
INFO - 2021-10-30 10:51:27 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:27 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:27 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:27 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:27 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:27 --> Controller Class Initialized
INFO - 2021-10-30 10:51:27 --> Config Class Initialized
INFO - 2021-10-30 10:51:27 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:27 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:27 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:27 --> URI Class Initialized
INFO - 2021-10-30 10:51:27 --> Router Class Initialized
INFO - 2021-10-30 10:51:27 --> Output Class Initialized
INFO - 2021-10-30 10:51:27 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:27 --> Input Class Initialized
INFO - 2021-10-30 10:51:27 --> Language Class Initialized
INFO - 2021-10-30 10:51:27 --> Language Class Initialized
INFO - 2021-10-30 10:51:27 --> Config Class Initialized
INFO - 2021-10-30 10:51:27 --> Loader Class Initialized
INFO - 2021-10-30 10:51:27 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:27 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:27 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:27 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:27 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:27 --> Controller Class Initialized
INFO - 2021-10-30 10:51:28 --> Config Class Initialized
INFO - 2021-10-30 10:51:28 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:28 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:28 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:28 --> URI Class Initialized
INFO - 2021-10-30 10:51:28 --> Router Class Initialized
INFO - 2021-10-30 10:51:28 --> Output Class Initialized
INFO - 2021-10-30 10:51:28 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:28 --> Input Class Initialized
INFO - 2021-10-30 10:51:28 --> Language Class Initialized
INFO - 2021-10-30 10:51:28 --> Language Class Initialized
INFO - 2021-10-30 10:51:28 --> Config Class Initialized
INFO - 2021-10-30 10:51:28 --> Loader Class Initialized
INFO - 2021-10-30 10:51:28 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:28 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:28 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:28 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:28 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:28 --> Controller Class Initialized
INFO - 2021-10-30 10:51:39 --> Config Class Initialized
INFO - 2021-10-30 10:51:39 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:39 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:39 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:39 --> URI Class Initialized
INFO - 2021-10-30 10:51:39 --> Router Class Initialized
INFO - 2021-10-30 10:51:39 --> Output Class Initialized
INFO - 2021-10-30 10:51:39 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:39 --> Input Class Initialized
INFO - 2021-10-30 10:51:39 --> Language Class Initialized
INFO - 2021-10-30 10:51:39 --> Language Class Initialized
INFO - 2021-10-30 10:51:39 --> Config Class Initialized
INFO - 2021-10-30 10:51:39 --> Loader Class Initialized
INFO - 2021-10-30 10:51:39 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:39 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:39 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:39 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:39 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:39 --> Controller Class Initialized
INFO - 2021-10-30 10:51:39 --> Final output sent to browser
DEBUG - 2021-10-30 10:51:39 --> Total execution time: 0.0620
INFO - 2021-10-30 10:51:39 --> Config Class Initialized
INFO - 2021-10-30 10:51:39 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:39 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:39 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:39 --> URI Class Initialized
INFO - 2021-10-30 10:51:39 --> Router Class Initialized
INFO - 2021-10-30 10:51:39 --> Output Class Initialized
INFO - 2021-10-30 10:51:39 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:39 --> Input Class Initialized
INFO - 2021-10-30 10:51:39 --> Language Class Initialized
INFO - 2021-10-30 10:51:39 --> Language Class Initialized
INFO - 2021-10-30 10:51:39 --> Config Class Initialized
INFO - 2021-10-30 10:51:39 --> Loader Class Initialized
INFO - 2021-10-30 10:51:39 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:39 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:39 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:39 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:39 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:39 --> Controller Class Initialized
INFO - 2021-10-30 10:51:55 --> Config Class Initialized
INFO - 2021-10-30 10:51:55 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:55 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:55 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:55 --> URI Class Initialized
INFO - 2021-10-30 10:51:55 --> Router Class Initialized
INFO - 2021-10-30 10:51:55 --> Output Class Initialized
INFO - 2021-10-30 10:51:55 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:55 --> Input Class Initialized
INFO - 2021-10-30 10:51:55 --> Language Class Initialized
INFO - 2021-10-30 10:51:55 --> Language Class Initialized
INFO - 2021-10-30 10:51:55 --> Config Class Initialized
INFO - 2021-10-30 10:51:55 --> Loader Class Initialized
INFO - 2021-10-30 10:51:55 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:55 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:55 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:55 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:55 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:55 --> Controller Class Initialized
INFO - 2021-10-30 10:51:55 --> Config Class Initialized
INFO - 2021-10-30 10:51:55 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:55 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:55 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:55 --> URI Class Initialized
INFO - 2021-10-30 10:51:55 --> Router Class Initialized
INFO - 2021-10-30 10:51:55 --> Output Class Initialized
INFO - 2021-10-30 10:51:55 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:55 --> Input Class Initialized
INFO - 2021-10-30 10:51:55 --> Language Class Initialized
INFO - 2021-10-30 10:51:55 --> Language Class Initialized
INFO - 2021-10-30 10:51:55 --> Config Class Initialized
INFO - 2021-10-30 10:51:55 --> Loader Class Initialized
INFO - 2021-10-30 10:51:55 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:55 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:55 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:55 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:55 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:55 --> Controller Class Initialized
INFO - 2021-10-30 10:51:56 --> Config Class Initialized
INFO - 2021-10-30 10:51:56 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:56 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:56 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:56 --> URI Class Initialized
INFO - 2021-10-30 10:51:56 --> Router Class Initialized
INFO - 2021-10-30 10:51:56 --> Output Class Initialized
INFO - 2021-10-30 10:51:56 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:56 --> Input Class Initialized
INFO - 2021-10-30 10:51:56 --> Language Class Initialized
INFO - 2021-10-30 10:51:56 --> Language Class Initialized
INFO - 2021-10-30 10:51:56 --> Config Class Initialized
INFO - 2021-10-30 10:51:56 --> Loader Class Initialized
INFO - 2021-10-30 10:51:56 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:56 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:56 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:56 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:56 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:56 --> Controller Class Initialized
INFO - 2021-10-30 10:51:58 --> Config Class Initialized
INFO - 2021-10-30 10:51:58 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:58 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:58 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:58 --> URI Class Initialized
INFO - 2021-10-30 10:51:58 --> Router Class Initialized
INFO - 2021-10-30 10:51:58 --> Output Class Initialized
INFO - 2021-10-30 10:51:58 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:58 --> Input Class Initialized
INFO - 2021-10-30 10:51:58 --> Language Class Initialized
INFO - 2021-10-30 10:51:58 --> Language Class Initialized
INFO - 2021-10-30 10:51:58 --> Config Class Initialized
INFO - 2021-10-30 10:51:58 --> Loader Class Initialized
INFO - 2021-10-30 10:51:58 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:58 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:58 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:58 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:58 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:59 --> Controller Class Initialized
INFO - 2021-10-30 10:51:59 --> Final output sent to browser
DEBUG - 2021-10-30 10:51:59 --> Total execution time: 0.0726
INFO - 2021-10-30 10:51:59 --> Config Class Initialized
INFO - 2021-10-30 10:51:59 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:51:59 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:51:59 --> Utf8 Class Initialized
INFO - 2021-10-30 10:51:59 --> URI Class Initialized
INFO - 2021-10-30 10:51:59 --> Router Class Initialized
INFO - 2021-10-30 10:51:59 --> Output Class Initialized
INFO - 2021-10-30 10:51:59 --> Security Class Initialized
DEBUG - 2021-10-30 10:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:51:59 --> Input Class Initialized
INFO - 2021-10-30 10:51:59 --> Language Class Initialized
INFO - 2021-10-30 10:51:59 --> Language Class Initialized
INFO - 2021-10-30 10:51:59 --> Config Class Initialized
INFO - 2021-10-30 10:51:59 --> Loader Class Initialized
INFO - 2021-10-30 10:51:59 --> Helper loaded: url_helper
INFO - 2021-10-30 10:51:59 --> Helper loaded: file_helper
INFO - 2021-10-30 10:51:59 --> Helper loaded: form_helper
INFO - 2021-10-30 10:51:59 --> Helper loaded: my_helper
INFO - 2021-10-30 10:51:59 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:51:59 --> Controller Class Initialized
INFO - 2021-10-30 10:52:02 --> Config Class Initialized
INFO - 2021-10-30 10:52:02 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:02 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:02 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:02 --> URI Class Initialized
INFO - 2021-10-30 10:52:02 --> Router Class Initialized
INFO - 2021-10-30 10:52:02 --> Output Class Initialized
INFO - 2021-10-30 10:52:02 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:02 --> Input Class Initialized
INFO - 2021-10-30 10:52:02 --> Language Class Initialized
INFO - 2021-10-30 10:52:02 --> Language Class Initialized
INFO - 2021-10-30 10:52:02 --> Config Class Initialized
INFO - 2021-10-30 10:52:02 --> Loader Class Initialized
INFO - 2021-10-30 10:52:02 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:02 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:02 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:02 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:02 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:02 --> Controller Class Initialized
INFO - 2021-10-30 10:52:02 --> Config Class Initialized
INFO - 2021-10-30 10:52:02 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:02 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:02 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:02 --> URI Class Initialized
INFO - 2021-10-30 10:52:02 --> Router Class Initialized
INFO - 2021-10-30 10:52:02 --> Output Class Initialized
INFO - 2021-10-30 10:52:02 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:02 --> Input Class Initialized
INFO - 2021-10-30 10:52:02 --> Language Class Initialized
INFO - 2021-10-30 10:52:02 --> Language Class Initialized
INFO - 2021-10-30 10:52:02 --> Config Class Initialized
INFO - 2021-10-30 10:52:02 --> Loader Class Initialized
INFO - 2021-10-30 10:52:02 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:02 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:02 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:02 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:02 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:02 --> Controller Class Initialized
INFO - 2021-10-30 10:52:03 --> Config Class Initialized
INFO - 2021-10-30 10:52:03 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:03 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:03 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:03 --> URI Class Initialized
INFO - 2021-10-30 10:52:03 --> Router Class Initialized
INFO - 2021-10-30 10:52:03 --> Output Class Initialized
INFO - 2021-10-30 10:52:03 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:03 --> Input Class Initialized
INFO - 2021-10-30 10:52:03 --> Language Class Initialized
INFO - 2021-10-30 10:52:03 --> Language Class Initialized
INFO - 2021-10-30 10:52:03 --> Config Class Initialized
INFO - 2021-10-30 10:52:03 --> Loader Class Initialized
INFO - 2021-10-30 10:52:03 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:03 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:03 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:03 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:03 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:03 --> Controller Class Initialized
INFO - 2021-10-30 10:52:05 --> Config Class Initialized
INFO - 2021-10-30 10:52:05 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:05 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:05 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:05 --> URI Class Initialized
INFO - 2021-10-30 10:52:05 --> Router Class Initialized
INFO - 2021-10-30 10:52:05 --> Output Class Initialized
INFO - 2021-10-30 10:52:05 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:05 --> Input Class Initialized
INFO - 2021-10-30 10:52:05 --> Language Class Initialized
INFO - 2021-10-30 10:52:05 --> Language Class Initialized
INFO - 2021-10-30 10:52:05 --> Config Class Initialized
INFO - 2021-10-30 10:52:05 --> Loader Class Initialized
INFO - 2021-10-30 10:52:05 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:05 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:05 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:05 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:05 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:05 --> Controller Class Initialized
INFO - 2021-10-30 10:52:05 --> Final output sent to browser
DEBUG - 2021-10-30 10:52:05 --> Total execution time: 0.0607
INFO - 2021-10-30 10:52:05 --> Config Class Initialized
INFO - 2021-10-30 10:52:05 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:05 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:05 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:05 --> URI Class Initialized
INFO - 2021-10-30 10:52:05 --> Router Class Initialized
INFO - 2021-10-30 10:52:05 --> Output Class Initialized
INFO - 2021-10-30 10:52:05 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:05 --> Input Class Initialized
INFO - 2021-10-30 10:52:05 --> Language Class Initialized
INFO - 2021-10-30 10:52:05 --> Language Class Initialized
INFO - 2021-10-30 10:52:05 --> Config Class Initialized
INFO - 2021-10-30 10:52:05 --> Loader Class Initialized
INFO - 2021-10-30 10:52:05 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:05 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:05 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:05 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:05 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:05 --> Controller Class Initialized
INFO - 2021-10-30 10:52:06 --> Config Class Initialized
INFO - 2021-10-30 10:52:06 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:06 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:06 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:06 --> URI Class Initialized
INFO - 2021-10-30 10:52:06 --> Router Class Initialized
INFO - 2021-10-30 10:52:06 --> Output Class Initialized
INFO - 2021-10-30 10:52:06 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:06 --> Input Class Initialized
INFO - 2021-10-30 10:52:06 --> Language Class Initialized
INFO - 2021-10-30 10:52:06 --> Language Class Initialized
INFO - 2021-10-30 10:52:06 --> Config Class Initialized
INFO - 2021-10-30 10:52:06 --> Loader Class Initialized
INFO - 2021-10-30 10:52:06 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:06 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:06 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:06 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:06 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:06 --> Controller Class Initialized
INFO - 2021-10-30 10:52:06 --> Final output sent to browser
DEBUG - 2021-10-30 10:52:06 --> Total execution time: 0.0468
INFO - 2021-10-30 10:52:18 --> Config Class Initialized
INFO - 2021-10-30 10:52:18 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:18 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:18 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:18 --> URI Class Initialized
INFO - 2021-10-30 10:52:18 --> Router Class Initialized
INFO - 2021-10-30 10:52:18 --> Output Class Initialized
INFO - 2021-10-30 10:52:18 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:18 --> Input Class Initialized
INFO - 2021-10-30 10:52:18 --> Language Class Initialized
INFO - 2021-10-30 10:52:18 --> Language Class Initialized
INFO - 2021-10-30 10:52:18 --> Config Class Initialized
INFO - 2021-10-30 10:52:18 --> Loader Class Initialized
INFO - 2021-10-30 10:52:18 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:18 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:18 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:18 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:18 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:18 --> Controller Class Initialized
INFO - 2021-10-30 10:52:18 --> Final output sent to browser
DEBUG - 2021-10-30 10:52:18 --> Total execution time: 0.0487
INFO - 2021-10-30 10:52:18 --> Config Class Initialized
INFO - 2021-10-30 10:52:18 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:18 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:18 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:18 --> URI Class Initialized
INFO - 2021-10-30 10:52:18 --> Router Class Initialized
INFO - 2021-10-30 10:52:18 --> Output Class Initialized
INFO - 2021-10-30 10:52:18 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:18 --> Input Class Initialized
INFO - 2021-10-30 10:52:18 --> Language Class Initialized
INFO - 2021-10-30 10:52:18 --> Language Class Initialized
INFO - 2021-10-30 10:52:18 --> Config Class Initialized
INFO - 2021-10-30 10:52:18 --> Loader Class Initialized
INFO - 2021-10-30 10:52:18 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:18 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:18 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:18 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:18 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:18 --> Controller Class Initialized
INFO - 2021-10-30 10:52:22 --> Config Class Initialized
INFO - 2021-10-30 10:52:22 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:22 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:22 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:22 --> URI Class Initialized
INFO - 2021-10-30 10:52:22 --> Router Class Initialized
INFO - 2021-10-30 10:52:22 --> Output Class Initialized
INFO - 2021-10-30 10:52:22 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:22 --> Input Class Initialized
INFO - 2021-10-30 10:52:22 --> Language Class Initialized
INFO - 2021-10-30 10:52:22 --> Language Class Initialized
INFO - 2021-10-30 10:52:22 --> Config Class Initialized
INFO - 2021-10-30 10:52:22 --> Loader Class Initialized
INFO - 2021-10-30 10:52:22 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:22 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:22 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:22 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:22 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:22 --> Controller Class Initialized
INFO - 2021-10-30 10:52:22 --> Final output sent to browser
DEBUG - 2021-10-30 10:52:22 --> Total execution time: 0.0453
INFO - 2021-10-30 10:52:35 --> Config Class Initialized
INFO - 2021-10-30 10:52:35 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:35 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:35 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:35 --> URI Class Initialized
INFO - 2021-10-30 10:52:35 --> Router Class Initialized
INFO - 2021-10-30 10:52:35 --> Output Class Initialized
INFO - 2021-10-30 10:52:35 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:35 --> Input Class Initialized
INFO - 2021-10-30 10:52:35 --> Language Class Initialized
INFO - 2021-10-30 10:52:35 --> Language Class Initialized
INFO - 2021-10-30 10:52:35 --> Config Class Initialized
INFO - 2021-10-30 10:52:35 --> Loader Class Initialized
INFO - 2021-10-30 10:52:35 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:35 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:35 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:35 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:35 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:35 --> Controller Class Initialized
INFO - 2021-10-30 10:52:35 --> Final output sent to browser
DEBUG - 2021-10-30 10:52:35 --> Total execution time: 0.0579
INFO - 2021-10-30 10:52:35 --> Config Class Initialized
INFO - 2021-10-30 10:52:35 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:35 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:35 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:35 --> URI Class Initialized
INFO - 2021-10-30 10:52:35 --> Router Class Initialized
INFO - 2021-10-30 10:52:35 --> Output Class Initialized
INFO - 2021-10-30 10:52:35 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:35 --> Input Class Initialized
INFO - 2021-10-30 10:52:35 --> Language Class Initialized
INFO - 2021-10-30 10:52:35 --> Language Class Initialized
INFO - 2021-10-30 10:52:35 --> Config Class Initialized
INFO - 2021-10-30 10:52:35 --> Loader Class Initialized
INFO - 2021-10-30 10:52:35 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:35 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:35 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:35 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:35 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:35 --> Controller Class Initialized
INFO - 2021-10-30 10:52:40 --> Config Class Initialized
INFO - 2021-10-30 10:52:40 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:40 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:40 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:40 --> URI Class Initialized
INFO - 2021-10-30 10:52:40 --> Router Class Initialized
INFO - 2021-10-30 10:52:40 --> Output Class Initialized
INFO - 2021-10-30 10:52:40 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:40 --> Input Class Initialized
INFO - 2021-10-30 10:52:40 --> Language Class Initialized
INFO - 2021-10-30 10:52:40 --> Language Class Initialized
INFO - 2021-10-30 10:52:40 --> Config Class Initialized
INFO - 2021-10-30 10:52:40 --> Loader Class Initialized
INFO - 2021-10-30 10:52:40 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:40 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:40 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:40 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:40 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:40 --> Controller Class Initialized
INFO - 2021-10-30 10:52:40 --> Final output sent to browser
DEBUG - 2021-10-30 10:52:40 --> Total execution time: 0.0466
INFO - 2021-10-30 10:52:54 --> Config Class Initialized
INFO - 2021-10-30 10:52:54 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:54 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:54 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:54 --> URI Class Initialized
INFO - 2021-10-30 10:52:54 --> Router Class Initialized
INFO - 2021-10-30 10:52:54 --> Output Class Initialized
INFO - 2021-10-30 10:52:54 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:54 --> Input Class Initialized
INFO - 2021-10-30 10:52:54 --> Language Class Initialized
INFO - 2021-10-30 10:52:54 --> Language Class Initialized
INFO - 2021-10-30 10:52:54 --> Config Class Initialized
INFO - 2021-10-30 10:52:54 --> Loader Class Initialized
INFO - 2021-10-30 10:52:54 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:54 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:54 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:54 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:54 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:54 --> Controller Class Initialized
INFO - 2021-10-30 10:52:54 --> Final output sent to browser
DEBUG - 2021-10-30 10:52:54 --> Total execution time: 0.0585
INFO - 2021-10-30 10:52:54 --> Config Class Initialized
INFO - 2021-10-30 10:52:54 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:54 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:54 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:54 --> URI Class Initialized
INFO - 2021-10-30 10:52:54 --> Router Class Initialized
INFO - 2021-10-30 10:52:54 --> Output Class Initialized
INFO - 2021-10-30 10:52:54 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:54 --> Input Class Initialized
INFO - 2021-10-30 10:52:54 --> Language Class Initialized
INFO - 2021-10-30 10:52:54 --> Language Class Initialized
INFO - 2021-10-30 10:52:54 --> Config Class Initialized
INFO - 2021-10-30 10:52:54 --> Loader Class Initialized
INFO - 2021-10-30 10:52:54 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:54 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:54 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:54 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:54 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:54 --> Controller Class Initialized
INFO - 2021-10-30 10:52:57 --> Config Class Initialized
INFO - 2021-10-30 10:52:57 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:52:57 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:52:57 --> Utf8 Class Initialized
INFO - 2021-10-30 10:52:57 --> URI Class Initialized
INFO - 2021-10-30 10:52:57 --> Router Class Initialized
INFO - 2021-10-30 10:52:57 --> Output Class Initialized
INFO - 2021-10-30 10:52:57 --> Security Class Initialized
DEBUG - 2021-10-30 10:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:52:57 --> Input Class Initialized
INFO - 2021-10-30 10:52:57 --> Language Class Initialized
INFO - 2021-10-30 10:52:57 --> Language Class Initialized
INFO - 2021-10-30 10:52:57 --> Config Class Initialized
INFO - 2021-10-30 10:52:57 --> Loader Class Initialized
INFO - 2021-10-30 10:52:57 --> Helper loaded: url_helper
INFO - 2021-10-30 10:52:57 --> Helper loaded: file_helper
INFO - 2021-10-30 10:52:57 --> Helper loaded: form_helper
INFO - 2021-10-30 10:52:57 --> Helper loaded: my_helper
INFO - 2021-10-30 10:52:57 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:52:57 --> Controller Class Initialized
INFO - 2021-10-30 10:52:57 --> Final output sent to browser
DEBUG - 2021-10-30 10:52:57 --> Total execution time: 0.0675
INFO - 2021-10-30 10:53:05 --> Config Class Initialized
INFO - 2021-10-30 10:53:05 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:53:05 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:53:05 --> Utf8 Class Initialized
INFO - 2021-10-30 10:53:05 --> URI Class Initialized
INFO - 2021-10-30 10:53:05 --> Router Class Initialized
INFO - 2021-10-30 10:53:05 --> Output Class Initialized
INFO - 2021-10-30 10:53:05 --> Security Class Initialized
DEBUG - 2021-10-30 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:53:05 --> Input Class Initialized
INFO - 2021-10-30 10:53:05 --> Language Class Initialized
INFO - 2021-10-30 10:53:05 --> Language Class Initialized
INFO - 2021-10-30 10:53:05 --> Config Class Initialized
INFO - 2021-10-30 10:53:05 --> Loader Class Initialized
INFO - 2021-10-30 10:53:05 --> Helper loaded: url_helper
INFO - 2021-10-30 10:53:05 --> Helper loaded: file_helper
INFO - 2021-10-30 10:53:05 --> Helper loaded: form_helper
INFO - 2021-10-30 10:53:05 --> Helper loaded: my_helper
INFO - 2021-10-30 10:53:05 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:53:05 --> Controller Class Initialized
INFO - 2021-10-30 10:53:05 --> Final output sent to browser
DEBUG - 2021-10-30 10:53:05 --> Total execution time: 0.0664
INFO - 2021-10-30 10:53:05 --> Config Class Initialized
INFO - 2021-10-30 10:53:05 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:53:05 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:53:05 --> Utf8 Class Initialized
INFO - 2021-10-30 10:53:05 --> URI Class Initialized
INFO - 2021-10-30 10:53:05 --> Router Class Initialized
INFO - 2021-10-30 10:53:05 --> Output Class Initialized
INFO - 2021-10-30 10:53:05 --> Security Class Initialized
DEBUG - 2021-10-30 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:53:05 --> Input Class Initialized
INFO - 2021-10-30 10:53:05 --> Language Class Initialized
INFO - 2021-10-30 10:53:05 --> Language Class Initialized
INFO - 2021-10-30 10:53:05 --> Config Class Initialized
INFO - 2021-10-30 10:53:05 --> Loader Class Initialized
INFO - 2021-10-30 10:53:05 --> Helper loaded: url_helper
INFO - 2021-10-30 10:53:05 --> Helper loaded: file_helper
INFO - 2021-10-30 10:53:05 --> Helper loaded: form_helper
INFO - 2021-10-30 10:53:05 --> Helper loaded: my_helper
INFO - 2021-10-30 10:53:05 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:53:05 --> Controller Class Initialized
INFO - 2021-10-30 10:54:16 --> Config Class Initialized
INFO - 2021-10-30 10:54:16 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:16 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:16 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:16 --> URI Class Initialized
INFO - 2021-10-30 10:54:16 --> Router Class Initialized
INFO - 2021-10-30 10:54:16 --> Output Class Initialized
INFO - 2021-10-30 10:54:16 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:16 --> Input Class Initialized
INFO - 2021-10-30 10:54:16 --> Language Class Initialized
INFO - 2021-10-30 10:54:16 --> Language Class Initialized
INFO - 2021-10-30 10:54:16 --> Config Class Initialized
INFO - 2021-10-30 10:54:16 --> Loader Class Initialized
INFO - 2021-10-30 10:54:16 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:16 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:16 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:16 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:16 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:16 --> Controller Class Initialized
INFO - 2021-10-30 10:54:16 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:54:16 --> Config Class Initialized
INFO - 2021-10-30 10:54:16 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:16 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:16 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:16 --> URI Class Initialized
INFO - 2021-10-30 10:54:16 --> Router Class Initialized
INFO - 2021-10-30 10:54:16 --> Output Class Initialized
INFO - 2021-10-30 10:54:16 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:16 --> Input Class Initialized
INFO - 2021-10-30 10:54:16 --> Language Class Initialized
INFO - 2021-10-30 10:54:16 --> Language Class Initialized
INFO - 2021-10-30 10:54:16 --> Config Class Initialized
INFO - 2021-10-30 10:54:16 --> Loader Class Initialized
INFO - 2021-10-30 10:54:16 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:16 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:16 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:16 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:16 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:16 --> Controller Class Initialized
DEBUG - 2021-10-30 10:54:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:54:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:54:16 --> Final output sent to browser
DEBUG - 2021-10-30 10:54:16 --> Total execution time: 0.0448
INFO - 2021-10-30 10:54:26 --> Config Class Initialized
INFO - 2021-10-30 10:54:26 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:26 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:26 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:26 --> URI Class Initialized
INFO - 2021-10-30 10:54:26 --> Router Class Initialized
INFO - 2021-10-30 10:54:26 --> Output Class Initialized
INFO - 2021-10-30 10:54:26 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:26 --> Input Class Initialized
INFO - 2021-10-30 10:54:26 --> Language Class Initialized
INFO - 2021-10-30 10:54:26 --> Language Class Initialized
INFO - 2021-10-30 10:54:26 --> Config Class Initialized
INFO - 2021-10-30 10:54:26 --> Loader Class Initialized
INFO - 2021-10-30 10:54:26 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:26 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:26 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:26 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:26 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:26 --> Controller Class Initialized
INFO - 2021-10-30 10:54:26 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:54:26 --> Final output sent to browser
DEBUG - 2021-10-30 10:54:26 --> Total execution time: 0.0747
INFO - 2021-10-30 10:54:26 --> Config Class Initialized
INFO - 2021-10-30 10:54:26 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:26 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:26 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:26 --> URI Class Initialized
INFO - 2021-10-30 10:54:26 --> Router Class Initialized
INFO - 2021-10-30 10:54:26 --> Output Class Initialized
INFO - 2021-10-30 10:54:26 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:26 --> Input Class Initialized
INFO - 2021-10-30 10:54:26 --> Language Class Initialized
INFO - 2021-10-30 10:54:26 --> Language Class Initialized
INFO - 2021-10-30 10:54:26 --> Config Class Initialized
INFO - 2021-10-30 10:54:26 --> Loader Class Initialized
INFO - 2021-10-30 10:54:26 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:26 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:26 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:26 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:26 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:26 --> Controller Class Initialized
DEBUG - 2021-10-30 10:54:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:54:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:54:27 --> Final output sent to browser
DEBUG - 2021-10-30 10:54:27 --> Total execution time: 0.6841
INFO - 2021-10-30 10:54:30 --> Config Class Initialized
INFO - 2021-10-30 10:54:30 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:30 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:30 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:30 --> URI Class Initialized
INFO - 2021-10-30 10:54:30 --> Router Class Initialized
INFO - 2021-10-30 10:54:30 --> Output Class Initialized
INFO - 2021-10-30 10:54:30 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:30 --> Input Class Initialized
INFO - 2021-10-30 10:54:30 --> Language Class Initialized
INFO - 2021-10-30 10:54:30 --> Language Class Initialized
INFO - 2021-10-30 10:54:30 --> Config Class Initialized
INFO - 2021-10-30 10:54:30 --> Loader Class Initialized
INFO - 2021-10-30 10:54:30 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:30 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:30 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:30 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:30 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:30 --> Controller Class Initialized
INFO - 2021-10-30 10:54:30 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:54:30 --> Config Class Initialized
INFO - 2021-10-30 10:54:30 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:30 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:30 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:30 --> URI Class Initialized
INFO - 2021-10-30 10:54:30 --> Router Class Initialized
INFO - 2021-10-30 10:54:30 --> Output Class Initialized
INFO - 2021-10-30 10:54:30 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:30 --> Input Class Initialized
INFO - 2021-10-30 10:54:30 --> Language Class Initialized
INFO - 2021-10-30 10:54:30 --> Language Class Initialized
INFO - 2021-10-30 10:54:30 --> Config Class Initialized
INFO - 2021-10-30 10:54:30 --> Loader Class Initialized
INFO - 2021-10-30 10:54:30 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:30 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:30 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:30 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:30 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:30 --> Controller Class Initialized
DEBUG - 2021-10-30 10:54:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:54:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:54:30 --> Final output sent to browser
DEBUG - 2021-10-30 10:54:30 --> Total execution time: 0.0651
INFO - 2021-10-30 10:54:36 --> Config Class Initialized
INFO - 2021-10-30 10:54:36 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:36 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:36 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:36 --> URI Class Initialized
INFO - 2021-10-30 10:54:36 --> Router Class Initialized
INFO - 2021-10-30 10:54:36 --> Output Class Initialized
INFO - 2021-10-30 10:54:36 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:36 --> Input Class Initialized
INFO - 2021-10-30 10:54:36 --> Language Class Initialized
INFO - 2021-10-30 10:54:36 --> Language Class Initialized
INFO - 2021-10-30 10:54:36 --> Config Class Initialized
INFO - 2021-10-30 10:54:36 --> Loader Class Initialized
INFO - 2021-10-30 10:54:36 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:36 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:36 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:36 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:36 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:36 --> Controller Class Initialized
INFO - 2021-10-30 10:54:36 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:54:36 --> Final output sent to browser
DEBUG - 2021-10-30 10:54:36 --> Total execution time: 0.0616
INFO - 2021-10-30 10:54:36 --> Config Class Initialized
INFO - 2021-10-30 10:54:36 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:36 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:36 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:36 --> URI Class Initialized
INFO - 2021-10-30 10:54:36 --> Router Class Initialized
INFO - 2021-10-30 10:54:36 --> Output Class Initialized
INFO - 2021-10-30 10:54:36 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:36 --> Input Class Initialized
INFO - 2021-10-30 10:54:36 --> Language Class Initialized
INFO - 2021-10-30 10:54:36 --> Language Class Initialized
INFO - 2021-10-30 10:54:36 --> Config Class Initialized
INFO - 2021-10-30 10:54:36 --> Loader Class Initialized
INFO - 2021-10-30 10:54:36 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:36 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:36 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:36 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:36 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:36 --> Controller Class Initialized
DEBUG - 2021-10-30 10:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:54:37 --> Final output sent to browser
DEBUG - 2021-10-30 10:54:37 --> Total execution time: 0.6694
INFO - 2021-10-30 10:54:43 --> Config Class Initialized
INFO - 2021-10-30 10:54:43 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:43 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:43 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:43 --> URI Class Initialized
INFO - 2021-10-30 10:54:43 --> Router Class Initialized
INFO - 2021-10-30 10:54:43 --> Output Class Initialized
INFO - 2021-10-30 10:54:43 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:43 --> Input Class Initialized
INFO - 2021-10-30 10:54:43 --> Language Class Initialized
INFO - 2021-10-30 10:54:43 --> Language Class Initialized
INFO - 2021-10-30 10:54:43 --> Config Class Initialized
INFO - 2021-10-30 10:54:43 --> Loader Class Initialized
INFO - 2021-10-30 10:54:43 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:43 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:43 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:43 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:43 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:43 --> Controller Class Initialized
DEBUG - 2021-10-30 10:54:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-10-30 10:54:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:54:43 --> Final output sent to browser
DEBUG - 2021-10-30 10:54:43 --> Total execution time: 0.0819
INFO - 2021-10-30 10:54:47 --> Config Class Initialized
INFO - 2021-10-30 10:54:47 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:54:47 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:54:47 --> Utf8 Class Initialized
INFO - 2021-10-30 10:54:47 --> URI Class Initialized
INFO - 2021-10-30 10:54:47 --> Router Class Initialized
INFO - 2021-10-30 10:54:47 --> Output Class Initialized
INFO - 2021-10-30 10:54:47 --> Security Class Initialized
DEBUG - 2021-10-30 10:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:54:47 --> Input Class Initialized
INFO - 2021-10-30 10:54:47 --> Language Class Initialized
INFO - 2021-10-30 10:54:47 --> Language Class Initialized
INFO - 2021-10-30 10:54:47 --> Config Class Initialized
INFO - 2021-10-30 10:54:47 --> Loader Class Initialized
INFO - 2021-10-30 10:54:47 --> Helper loaded: url_helper
INFO - 2021-10-30 10:54:47 --> Helper loaded: file_helper
INFO - 2021-10-30 10:54:47 --> Helper loaded: form_helper
INFO - 2021-10-30 10:54:47 --> Helper loaded: my_helper
INFO - 2021-10-30 10:54:47 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:54:47 --> Controller Class Initialized
DEBUG - 2021-10-30 10:54:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-10-30 10:54:47 --> Final output sent to browser
DEBUG - 2021-10-30 10:54:47 --> Total execution time: 0.2877
INFO - 2021-10-30 10:55:30 --> Config Class Initialized
INFO - 2021-10-30 10:55:30 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:55:30 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:55:30 --> Utf8 Class Initialized
INFO - 2021-10-30 10:55:30 --> URI Class Initialized
INFO - 2021-10-30 10:55:30 --> Router Class Initialized
INFO - 2021-10-30 10:55:30 --> Output Class Initialized
INFO - 2021-10-30 10:55:30 --> Security Class Initialized
DEBUG - 2021-10-30 10:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:55:30 --> Input Class Initialized
INFO - 2021-10-30 10:55:30 --> Language Class Initialized
INFO - 2021-10-30 10:55:30 --> Language Class Initialized
INFO - 2021-10-30 10:55:30 --> Config Class Initialized
INFO - 2021-10-30 10:55:30 --> Loader Class Initialized
INFO - 2021-10-30 10:55:30 --> Helper loaded: url_helper
INFO - 2021-10-30 10:55:30 --> Helper loaded: file_helper
INFO - 2021-10-30 10:55:30 --> Helper loaded: form_helper
INFO - 2021-10-30 10:55:30 --> Helper loaded: my_helper
INFO - 2021-10-30 10:55:30 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:55:30 --> Controller Class Initialized
INFO - 2021-10-30 10:55:30 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:55:30 --> Config Class Initialized
INFO - 2021-10-30 10:55:30 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:55:30 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:55:30 --> Utf8 Class Initialized
INFO - 2021-10-30 10:55:30 --> URI Class Initialized
INFO - 2021-10-30 10:55:30 --> Router Class Initialized
INFO - 2021-10-30 10:55:30 --> Output Class Initialized
INFO - 2021-10-30 10:55:30 --> Security Class Initialized
DEBUG - 2021-10-30 10:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:55:30 --> Input Class Initialized
INFO - 2021-10-30 10:55:30 --> Language Class Initialized
INFO - 2021-10-30 10:55:30 --> Language Class Initialized
INFO - 2021-10-30 10:55:30 --> Config Class Initialized
INFO - 2021-10-30 10:55:30 --> Loader Class Initialized
INFO - 2021-10-30 10:55:30 --> Helper loaded: url_helper
INFO - 2021-10-30 10:55:30 --> Helper loaded: file_helper
INFO - 2021-10-30 10:55:30 --> Helper loaded: form_helper
INFO - 2021-10-30 10:55:30 --> Helper loaded: my_helper
INFO - 2021-10-30 10:55:30 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:55:30 --> Controller Class Initialized
DEBUG - 2021-10-30 10:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:55:31 --> Final output sent to browser
DEBUG - 2021-10-30 10:55:31 --> Total execution time: 0.0515
INFO - 2021-10-30 10:55:35 --> Config Class Initialized
INFO - 2021-10-30 10:55:35 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:55:35 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:55:35 --> Utf8 Class Initialized
INFO - 2021-10-30 10:55:35 --> URI Class Initialized
INFO - 2021-10-30 10:55:35 --> Router Class Initialized
INFO - 2021-10-30 10:55:35 --> Output Class Initialized
INFO - 2021-10-30 10:55:35 --> Security Class Initialized
DEBUG - 2021-10-30 10:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:55:35 --> Input Class Initialized
INFO - 2021-10-30 10:55:35 --> Language Class Initialized
INFO - 2021-10-30 10:55:35 --> Language Class Initialized
INFO - 2021-10-30 10:55:35 --> Config Class Initialized
INFO - 2021-10-30 10:55:35 --> Loader Class Initialized
INFO - 2021-10-30 10:55:35 --> Helper loaded: url_helper
INFO - 2021-10-30 10:55:35 --> Helper loaded: file_helper
INFO - 2021-10-30 10:55:35 --> Helper loaded: form_helper
INFO - 2021-10-30 10:55:35 --> Helper loaded: my_helper
INFO - 2021-10-30 10:55:35 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:55:35 --> Controller Class Initialized
INFO - 2021-10-30 10:55:35 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:55:35 --> Final output sent to browser
DEBUG - 2021-10-30 10:55:35 --> Total execution time: 0.0615
INFO - 2021-10-30 10:55:37 --> Config Class Initialized
INFO - 2021-10-30 10:55:37 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:55:37 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:55:37 --> Utf8 Class Initialized
INFO - 2021-10-30 10:55:37 --> URI Class Initialized
INFO - 2021-10-30 10:55:37 --> Router Class Initialized
INFO - 2021-10-30 10:55:37 --> Output Class Initialized
INFO - 2021-10-30 10:55:37 --> Security Class Initialized
DEBUG - 2021-10-30 10:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:55:37 --> Input Class Initialized
INFO - 2021-10-30 10:55:37 --> Language Class Initialized
INFO - 2021-10-30 10:55:37 --> Language Class Initialized
INFO - 2021-10-30 10:55:37 --> Config Class Initialized
INFO - 2021-10-30 10:55:37 --> Loader Class Initialized
INFO - 2021-10-30 10:55:37 --> Helper loaded: url_helper
INFO - 2021-10-30 10:55:37 --> Helper loaded: file_helper
INFO - 2021-10-30 10:55:37 --> Helper loaded: form_helper
INFO - 2021-10-30 10:55:37 --> Helper loaded: my_helper
INFO - 2021-10-30 10:55:37 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:55:37 --> Controller Class Initialized
DEBUG - 2021-10-30 10:55:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:55:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:55:38 --> Final output sent to browser
DEBUG - 2021-10-30 10:55:38 --> Total execution time: 0.7831
INFO - 2021-10-30 10:55:40 --> Config Class Initialized
INFO - 2021-10-30 10:55:40 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:55:40 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:55:40 --> Utf8 Class Initialized
INFO - 2021-10-30 10:55:40 --> URI Class Initialized
INFO - 2021-10-30 10:55:40 --> Router Class Initialized
INFO - 2021-10-30 10:55:40 --> Output Class Initialized
INFO - 2021-10-30 10:55:40 --> Security Class Initialized
DEBUG - 2021-10-30 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:55:40 --> Input Class Initialized
INFO - 2021-10-30 10:55:40 --> Language Class Initialized
INFO - 2021-10-30 10:55:40 --> Language Class Initialized
INFO - 2021-10-30 10:55:40 --> Config Class Initialized
INFO - 2021-10-30 10:55:40 --> Loader Class Initialized
INFO - 2021-10-30 10:55:40 --> Helper loaded: url_helper
INFO - 2021-10-30 10:55:40 --> Helper loaded: file_helper
INFO - 2021-10-30 10:55:40 --> Helper loaded: form_helper
INFO - 2021-10-30 10:55:40 --> Helper loaded: my_helper
INFO - 2021-10-30 10:55:40 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:55:40 --> Controller Class Initialized
DEBUG - 2021-10-30 10:55:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-10-30 10:55:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:55:40 --> Final output sent to browser
DEBUG - 2021-10-30 10:55:40 --> Total execution time: 0.0931
INFO - 2021-10-30 10:56:57 --> Config Class Initialized
INFO - 2021-10-30 10:56:57 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:56:57 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:56:57 --> Utf8 Class Initialized
INFO - 2021-10-30 10:56:57 --> URI Class Initialized
INFO - 2021-10-30 10:56:57 --> Router Class Initialized
INFO - 2021-10-30 10:56:57 --> Output Class Initialized
INFO - 2021-10-30 10:56:57 --> Security Class Initialized
DEBUG - 2021-10-30 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:56:57 --> Input Class Initialized
INFO - 2021-10-30 10:56:57 --> Language Class Initialized
INFO - 2021-10-30 10:56:57 --> Language Class Initialized
INFO - 2021-10-30 10:56:57 --> Config Class Initialized
INFO - 2021-10-30 10:56:57 --> Loader Class Initialized
INFO - 2021-10-30 10:56:57 --> Helper loaded: url_helper
INFO - 2021-10-30 10:56:57 --> Helper loaded: file_helper
INFO - 2021-10-30 10:56:57 --> Helper loaded: form_helper
INFO - 2021-10-30 10:56:57 --> Helper loaded: my_helper
INFO - 2021-10-30 10:56:57 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:56:57 --> Controller Class Initialized
INFO - 2021-10-30 10:56:57 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:56:57 --> Config Class Initialized
INFO - 2021-10-30 10:56:57 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:56:57 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:56:57 --> Utf8 Class Initialized
INFO - 2021-10-30 10:56:57 --> URI Class Initialized
INFO - 2021-10-30 10:56:57 --> Router Class Initialized
INFO - 2021-10-30 10:56:57 --> Output Class Initialized
INFO - 2021-10-30 10:56:57 --> Security Class Initialized
DEBUG - 2021-10-30 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:56:57 --> Input Class Initialized
INFO - 2021-10-30 10:56:57 --> Language Class Initialized
INFO - 2021-10-30 10:56:57 --> Language Class Initialized
INFO - 2021-10-30 10:56:57 --> Config Class Initialized
INFO - 2021-10-30 10:56:57 --> Loader Class Initialized
INFO - 2021-10-30 10:56:57 --> Helper loaded: url_helper
INFO - 2021-10-30 10:56:57 --> Helper loaded: file_helper
INFO - 2021-10-30 10:56:57 --> Helper loaded: form_helper
INFO - 2021-10-30 10:56:57 --> Helper loaded: my_helper
INFO - 2021-10-30 10:56:57 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:56:57 --> Controller Class Initialized
DEBUG - 2021-10-30 10:56:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-30 10:56:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:56:57 --> Final output sent to browser
DEBUG - 2021-10-30 10:56:57 --> Total execution time: 0.0451
INFO - 2021-10-30 10:57:06 --> Config Class Initialized
INFO - 2021-10-30 10:57:06 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:57:06 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:57:06 --> Utf8 Class Initialized
INFO - 2021-10-30 10:57:06 --> URI Class Initialized
INFO - 2021-10-30 10:57:06 --> Router Class Initialized
INFO - 2021-10-30 10:57:06 --> Output Class Initialized
INFO - 2021-10-30 10:57:06 --> Security Class Initialized
DEBUG - 2021-10-30 10:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:57:06 --> Input Class Initialized
INFO - 2021-10-30 10:57:06 --> Language Class Initialized
INFO - 2021-10-30 10:57:06 --> Language Class Initialized
INFO - 2021-10-30 10:57:06 --> Config Class Initialized
INFO - 2021-10-30 10:57:06 --> Loader Class Initialized
INFO - 2021-10-30 10:57:06 --> Helper loaded: url_helper
INFO - 2021-10-30 10:57:06 --> Helper loaded: file_helper
INFO - 2021-10-30 10:57:06 --> Helper loaded: form_helper
INFO - 2021-10-30 10:57:06 --> Helper loaded: my_helper
INFO - 2021-10-30 10:57:06 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:57:06 --> Controller Class Initialized
INFO - 2021-10-30 10:57:06 --> Helper loaded: cookie_helper
INFO - 2021-10-30 10:57:06 --> Final output sent to browser
DEBUG - 2021-10-30 10:57:06 --> Total execution time: 0.0626
INFO - 2021-10-30 10:57:07 --> Config Class Initialized
INFO - 2021-10-30 10:57:07 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:57:07 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:57:07 --> Utf8 Class Initialized
INFO - 2021-10-30 10:57:07 --> URI Class Initialized
INFO - 2021-10-30 10:57:07 --> Router Class Initialized
INFO - 2021-10-30 10:57:07 --> Output Class Initialized
INFO - 2021-10-30 10:57:07 --> Security Class Initialized
DEBUG - 2021-10-30 10:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:57:07 --> Input Class Initialized
INFO - 2021-10-30 10:57:07 --> Language Class Initialized
INFO - 2021-10-30 10:57:07 --> Language Class Initialized
INFO - 2021-10-30 10:57:07 --> Config Class Initialized
INFO - 2021-10-30 10:57:07 --> Loader Class Initialized
INFO - 2021-10-30 10:57:07 --> Helper loaded: url_helper
INFO - 2021-10-30 10:57:07 --> Helper loaded: file_helper
INFO - 2021-10-30 10:57:07 --> Helper loaded: form_helper
INFO - 2021-10-30 10:57:07 --> Helper loaded: my_helper
INFO - 2021-10-30 10:57:07 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:57:07 --> Controller Class Initialized
DEBUG - 2021-10-30 10:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-10-30 10:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:57:07 --> Final output sent to browser
DEBUG - 2021-10-30 10:57:07 --> Total execution time: 0.6879
INFO - 2021-10-30 10:57:11 --> Config Class Initialized
INFO - 2021-10-30 10:57:11 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:57:11 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:57:11 --> Utf8 Class Initialized
INFO - 2021-10-30 10:57:11 --> URI Class Initialized
INFO - 2021-10-30 10:57:11 --> Router Class Initialized
INFO - 2021-10-30 10:57:11 --> Output Class Initialized
INFO - 2021-10-30 10:57:11 --> Security Class Initialized
DEBUG - 2021-10-30 10:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:57:11 --> Input Class Initialized
INFO - 2021-10-30 10:57:11 --> Language Class Initialized
INFO - 2021-10-30 10:57:11 --> Language Class Initialized
INFO - 2021-10-30 10:57:11 --> Config Class Initialized
INFO - 2021-10-30 10:57:11 --> Loader Class Initialized
INFO - 2021-10-30 10:57:11 --> Helper loaded: url_helper
INFO - 2021-10-30 10:57:11 --> Helper loaded: file_helper
INFO - 2021-10-30 10:57:11 --> Helper loaded: form_helper
INFO - 2021-10-30 10:57:11 --> Helper loaded: my_helper
INFO - 2021-10-30 10:57:11 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:57:11 --> Controller Class Initialized
DEBUG - 2021-10-30 10:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-10-30 10:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:57:11 --> Final output sent to browser
DEBUG - 2021-10-30 10:57:11 --> Total execution time: 0.1278
INFO - 2021-10-30 10:57:11 --> Config Class Initialized
INFO - 2021-10-30 10:57:11 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:57:11 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:57:11 --> Utf8 Class Initialized
INFO - 2021-10-30 10:57:11 --> URI Class Initialized
INFO - 2021-10-30 10:57:11 --> Router Class Initialized
INFO - 2021-10-30 10:57:11 --> Output Class Initialized
INFO - 2021-10-30 10:57:11 --> Security Class Initialized
DEBUG - 2021-10-30 10:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:57:11 --> Input Class Initialized
INFO - 2021-10-30 10:57:11 --> Language Class Initialized
INFO - 2021-10-30 10:57:11 --> Language Class Initialized
INFO - 2021-10-30 10:57:11 --> Config Class Initialized
INFO - 2021-10-30 10:57:11 --> Loader Class Initialized
INFO - 2021-10-30 10:57:11 --> Helper loaded: url_helper
INFO - 2021-10-30 10:57:11 --> Helper loaded: file_helper
INFO - 2021-10-30 10:57:11 --> Helper loaded: form_helper
INFO - 2021-10-30 10:57:11 --> Helper loaded: my_helper
INFO - 2021-10-30 10:57:11 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:57:12 --> Controller Class Initialized
DEBUG - 2021-10-30 10:57:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-10-30 10:57:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-30 10:57:12 --> Final output sent to browser
DEBUG - 2021-10-30 10:57:12 --> Total execution time: 0.0711
INFO - 2021-10-30 10:57:13 --> Config Class Initialized
INFO - 2021-10-30 10:57:13 --> Hooks Class Initialized
DEBUG - 2021-10-30 10:57:13 --> UTF-8 Support Enabled
INFO - 2021-10-30 10:57:13 --> Utf8 Class Initialized
INFO - 2021-10-30 10:57:13 --> URI Class Initialized
INFO - 2021-10-30 10:57:13 --> Router Class Initialized
INFO - 2021-10-30 10:57:13 --> Output Class Initialized
INFO - 2021-10-30 10:57:13 --> Security Class Initialized
DEBUG - 2021-10-30 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-30 10:57:13 --> Input Class Initialized
INFO - 2021-10-30 10:57:13 --> Language Class Initialized
INFO - 2021-10-30 10:57:13 --> Language Class Initialized
INFO - 2021-10-30 10:57:13 --> Config Class Initialized
INFO - 2021-10-30 10:57:13 --> Loader Class Initialized
INFO - 2021-10-30 10:57:13 --> Helper loaded: url_helper
INFO - 2021-10-30 10:57:13 --> Helper loaded: file_helper
INFO - 2021-10-30 10:57:13 --> Helper loaded: form_helper
INFO - 2021-10-30 10:57:13 --> Helper loaded: my_helper
INFO - 2021-10-30 10:57:13 --> Database Driver Class Initialized
DEBUG - 2021-10-30 10:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-30 10:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-30 10:57:13 --> Controller Class Initialized
DEBUG - 2021-10-30 10:57:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-10-30 10:57:13 --> Final output sent to browser
DEBUG - 2021-10-30 10:57:13 --> Total execution time: 0.2751
