<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-24 09:37:28 --> Config Class Initialized
INFO - 2021-07-24 09:37:28 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:37:28 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:37:28 --> Utf8 Class Initialized
INFO - 2021-07-24 09:37:28 --> URI Class Initialized
DEBUG - 2021-07-24 09:37:28 --> No URI present. Default controller set.
INFO - 2021-07-24 09:37:28 --> Router Class Initialized
INFO - 2021-07-24 09:37:28 --> Output Class Initialized
INFO - 2021-07-24 09:37:28 --> Security Class Initialized
DEBUG - 2021-07-24 09:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:37:28 --> Input Class Initialized
INFO - 2021-07-24 09:37:28 --> Language Class Initialized
INFO - 2021-07-24 09:37:29 --> Language Class Initialized
INFO - 2021-07-24 09:37:29 --> Config Class Initialized
INFO - 2021-07-24 09:37:29 --> Loader Class Initialized
INFO - 2021-07-24 09:37:29 --> Helper loaded: url_helper
INFO - 2021-07-24 09:37:29 --> Helper loaded: file_helper
INFO - 2021-07-24 09:37:29 --> Helper loaded: form_helper
INFO - 2021-07-24 09:37:29 --> Helper loaded: my_helper
INFO - 2021-07-24 09:37:29 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:37:29 --> Controller Class Initialized
INFO - 2021-07-24 09:37:29 --> Config Class Initialized
INFO - 2021-07-24 09:37:29 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:37:29 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:37:29 --> Utf8 Class Initialized
INFO - 2021-07-24 09:37:29 --> URI Class Initialized
INFO - 2021-07-24 09:37:29 --> Router Class Initialized
INFO - 2021-07-24 09:37:29 --> Output Class Initialized
INFO - 2021-07-24 09:37:29 --> Security Class Initialized
DEBUG - 2021-07-24 09:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:37:29 --> Input Class Initialized
INFO - 2021-07-24 09:37:29 --> Language Class Initialized
INFO - 2021-07-24 09:37:29 --> Language Class Initialized
INFO - 2021-07-24 09:37:29 --> Config Class Initialized
INFO - 2021-07-24 09:37:29 --> Loader Class Initialized
INFO - 2021-07-24 09:37:29 --> Helper loaded: url_helper
INFO - 2021-07-24 09:37:29 --> Helper loaded: file_helper
INFO - 2021-07-24 09:37:29 --> Helper loaded: form_helper
INFO - 2021-07-24 09:37:29 --> Helper loaded: my_helper
INFO - 2021-07-24 09:37:29 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:37:29 --> Controller Class Initialized
DEBUG - 2021-07-24 09:37:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-24 09:37:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:37:29 --> Final output sent to browser
DEBUG - 2021-07-24 09:37:29 --> Total execution time: 0.0910
INFO - 2021-07-24 09:37:34 --> Config Class Initialized
INFO - 2021-07-24 09:37:34 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:37:34 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:37:34 --> Utf8 Class Initialized
INFO - 2021-07-24 09:37:34 --> URI Class Initialized
INFO - 2021-07-24 09:37:34 --> Router Class Initialized
INFO - 2021-07-24 09:37:34 --> Output Class Initialized
INFO - 2021-07-24 09:37:34 --> Security Class Initialized
DEBUG - 2021-07-24 09:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:37:34 --> Input Class Initialized
INFO - 2021-07-24 09:37:34 --> Language Class Initialized
INFO - 2021-07-24 09:37:34 --> Language Class Initialized
INFO - 2021-07-24 09:37:34 --> Config Class Initialized
INFO - 2021-07-24 09:37:34 --> Loader Class Initialized
INFO - 2021-07-24 09:37:34 --> Helper loaded: url_helper
INFO - 2021-07-24 09:37:34 --> Helper loaded: file_helper
INFO - 2021-07-24 09:37:34 --> Helper loaded: form_helper
INFO - 2021-07-24 09:37:34 --> Helper loaded: my_helper
INFO - 2021-07-24 09:37:34 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:37:34 --> Controller Class Initialized
INFO - 2021-07-24 09:37:34 --> Helper loaded: cookie_helper
INFO - 2021-07-24 09:37:34 --> Final output sent to browser
DEBUG - 2021-07-24 09:37:34 --> Total execution time: 0.0846
INFO - 2021-07-24 09:37:34 --> Config Class Initialized
INFO - 2021-07-24 09:37:34 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:37:34 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:37:34 --> Utf8 Class Initialized
INFO - 2021-07-24 09:37:34 --> URI Class Initialized
INFO - 2021-07-24 09:37:34 --> Router Class Initialized
INFO - 2021-07-24 09:37:34 --> Output Class Initialized
INFO - 2021-07-24 09:37:34 --> Security Class Initialized
DEBUG - 2021-07-24 09:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:37:34 --> Input Class Initialized
INFO - 2021-07-24 09:37:34 --> Language Class Initialized
INFO - 2021-07-24 09:37:34 --> Language Class Initialized
INFO - 2021-07-24 09:37:34 --> Config Class Initialized
INFO - 2021-07-24 09:37:34 --> Loader Class Initialized
INFO - 2021-07-24 09:37:34 --> Helper loaded: url_helper
INFO - 2021-07-24 09:37:34 --> Helper loaded: file_helper
INFO - 2021-07-24 09:37:34 --> Helper loaded: form_helper
INFO - 2021-07-24 09:37:34 --> Helper loaded: my_helper
INFO - 2021-07-24 09:37:34 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:37:34 --> Controller Class Initialized
DEBUG - 2021-07-24 09:37:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-24 09:37:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:37:35 --> Final output sent to browser
DEBUG - 2021-07-24 09:37:35 --> Total execution time: 0.7955
INFO - 2021-07-24 09:37:38 --> Config Class Initialized
INFO - 2021-07-24 09:37:38 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:37:38 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:37:38 --> Utf8 Class Initialized
INFO - 2021-07-24 09:37:38 --> URI Class Initialized
INFO - 2021-07-24 09:37:38 --> Router Class Initialized
INFO - 2021-07-24 09:37:38 --> Output Class Initialized
INFO - 2021-07-24 09:37:38 --> Security Class Initialized
DEBUG - 2021-07-24 09:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:37:38 --> Input Class Initialized
INFO - 2021-07-24 09:37:38 --> Language Class Initialized
INFO - 2021-07-24 09:37:38 --> Language Class Initialized
INFO - 2021-07-24 09:37:38 --> Config Class Initialized
INFO - 2021-07-24 09:37:38 --> Loader Class Initialized
INFO - 2021-07-24 09:37:38 --> Helper loaded: url_helper
INFO - 2021-07-24 09:37:38 --> Helper loaded: file_helper
INFO - 2021-07-24 09:37:38 --> Helper loaded: form_helper
INFO - 2021-07-24 09:37:38 --> Helper loaded: my_helper
INFO - 2021-07-24 09:37:38 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:37:38 --> Controller Class Initialized
DEBUG - 2021-07-24 09:37:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 09:37:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:37:38 --> Final output sent to browser
DEBUG - 2021-07-24 09:37:38 --> Total execution time: 0.0801
INFO - 2021-07-24 09:37:39 --> Config Class Initialized
INFO - 2021-07-24 09:37:39 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:37:39 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:37:39 --> Utf8 Class Initialized
INFO - 2021-07-24 09:37:39 --> URI Class Initialized
INFO - 2021-07-24 09:37:39 --> Router Class Initialized
INFO - 2021-07-24 09:37:39 --> Output Class Initialized
INFO - 2021-07-24 09:37:39 --> Security Class Initialized
DEBUG - 2021-07-24 09:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:37:39 --> Input Class Initialized
INFO - 2021-07-24 09:37:39 --> Language Class Initialized
INFO - 2021-07-24 09:37:39 --> Language Class Initialized
INFO - 2021-07-24 09:37:39 --> Config Class Initialized
INFO - 2021-07-24 09:37:39 --> Loader Class Initialized
INFO - 2021-07-24 09:37:39 --> Helper loaded: url_helper
INFO - 2021-07-24 09:37:39 --> Helper loaded: file_helper
INFO - 2021-07-24 09:37:39 --> Helper loaded: form_helper
INFO - 2021-07-24 09:37:39 --> Helper loaded: my_helper
INFO - 2021-07-24 09:37:39 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:37:39 --> Controller Class Initialized
INFO - 2021-07-24 09:42:19 --> Config Class Initialized
INFO - 2021-07-24 09:42:19 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:42:19 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:42:19 --> Utf8 Class Initialized
INFO - 2021-07-24 09:42:19 --> URI Class Initialized
INFO - 2021-07-24 09:42:19 --> Router Class Initialized
INFO - 2021-07-24 09:42:19 --> Output Class Initialized
INFO - 2021-07-24 09:42:19 --> Security Class Initialized
DEBUG - 2021-07-24 09:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:42:19 --> Input Class Initialized
INFO - 2021-07-24 09:42:19 --> Language Class Initialized
INFO - 2021-07-24 09:42:19 --> Language Class Initialized
INFO - 2021-07-24 09:42:19 --> Config Class Initialized
INFO - 2021-07-24 09:42:19 --> Loader Class Initialized
INFO - 2021-07-24 09:42:19 --> Helper loaded: url_helper
INFO - 2021-07-24 09:42:19 --> Helper loaded: file_helper
INFO - 2021-07-24 09:42:19 --> Helper loaded: form_helper
INFO - 2021-07-24 09:42:19 --> Helper loaded: my_helper
INFO - 2021-07-24 09:42:19 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:42:19 --> Controller Class Initialized
DEBUG - 2021-07-24 09:42:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-07-24 09:42:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:42:20 --> Final output sent to browser
DEBUG - 2021-07-24 09:42:20 --> Total execution time: 0.0696
INFO - 2021-07-24 09:43:21 --> Config Class Initialized
INFO - 2021-07-24 09:43:21 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:43:21 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:43:21 --> Utf8 Class Initialized
INFO - 2021-07-24 09:43:21 --> URI Class Initialized
INFO - 2021-07-24 09:43:21 --> Router Class Initialized
INFO - 2021-07-24 09:43:21 --> Output Class Initialized
INFO - 2021-07-24 09:43:21 --> Security Class Initialized
DEBUG - 2021-07-24 09:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:43:21 --> Input Class Initialized
INFO - 2021-07-24 09:43:21 --> Language Class Initialized
INFO - 2021-07-24 09:43:21 --> Language Class Initialized
INFO - 2021-07-24 09:43:21 --> Config Class Initialized
INFO - 2021-07-24 09:43:21 --> Loader Class Initialized
INFO - 2021-07-24 09:43:21 --> Helper loaded: url_helper
INFO - 2021-07-24 09:43:21 --> Helper loaded: file_helper
INFO - 2021-07-24 09:43:21 --> Helper loaded: form_helper
INFO - 2021-07-24 09:43:21 --> Helper loaded: my_helper
INFO - 2021-07-24 09:43:21 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:43:21 --> Controller Class Initialized
INFO - 2021-07-24 09:43:25 --> Config Class Initialized
INFO - 2021-07-24 09:43:25 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:43:25 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:43:25 --> Utf8 Class Initialized
INFO - 2021-07-24 09:43:25 --> URI Class Initialized
INFO - 2021-07-24 09:43:25 --> Router Class Initialized
INFO - 2021-07-24 09:43:25 --> Output Class Initialized
INFO - 2021-07-24 09:43:25 --> Security Class Initialized
DEBUG - 2021-07-24 09:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:43:25 --> Input Class Initialized
INFO - 2021-07-24 09:43:25 --> Language Class Initialized
INFO - 2021-07-24 09:43:25 --> Language Class Initialized
INFO - 2021-07-24 09:43:25 --> Config Class Initialized
INFO - 2021-07-24 09:43:25 --> Loader Class Initialized
INFO - 2021-07-24 09:43:25 --> Helper loaded: url_helper
INFO - 2021-07-24 09:43:25 --> Helper loaded: file_helper
INFO - 2021-07-24 09:43:25 --> Helper loaded: form_helper
INFO - 2021-07-24 09:43:25 --> Helper loaded: my_helper
INFO - 2021-07-24 09:43:25 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:43:25 --> Controller Class Initialized
DEBUG - 2021-07-24 09:43:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-07-24 09:43:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:43:25 --> Final output sent to browser
DEBUG - 2021-07-24 09:43:25 --> Total execution time: 0.0583
INFO - 2021-07-24 09:43:27 --> Config Class Initialized
INFO - 2021-07-24 09:43:27 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:43:27 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:43:27 --> Utf8 Class Initialized
INFO - 2021-07-24 09:43:27 --> URI Class Initialized
INFO - 2021-07-24 09:43:27 --> Router Class Initialized
INFO - 2021-07-24 09:43:27 --> Output Class Initialized
INFO - 2021-07-24 09:43:27 --> Security Class Initialized
DEBUG - 2021-07-24 09:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:43:27 --> Input Class Initialized
INFO - 2021-07-24 09:43:27 --> Language Class Initialized
INFO - 2021-07-24 09:43:27 --> Language Class Initialized
INFO - 2021-07-24 09:43:27 --> Config Class Initialized
INFO - 2021-07-24 09:43:27 --> Loader Class Initialized
INFO - 2021-07-24 09:43:27 --> Helper loaded: url_helper
INFO - 2021-07-24 09:43:27 --> Helper loaded: file_helper
INFO - 2021-07-24 09:43:27 --> Helper loaded: form_helper
INFO - 2021-07-24 09:43:27 --> Helper loaded: my_helper
INFO - 2021-07-24 09:43:27 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:43:27 --> Controller Class Initialized
DEBUG - 2021-07-24 09:43:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 09:43:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:43:27 --> Final output sent to browser
DEBUG - 2021-07-24 09:43:27 --> Total execution time: 0.0601
INFO - 2021-07-24 09:43:27 --> Config Class Initialized
INFO - 2021-07-24 09:43:27 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:43:27 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:43:27 --> Utf8 Class Initialized
INFO - 2021-07-24 09:43:27 --> URI Class Initialized
INFO - 2021-07-24 09:43:27 --> Router Class Initialized
INFO - 2021-07-24 09:43:27 --> Output Class Initialized
INFO - 2021-07-24 09:43:27 --> Security Class Initialized
DEBUG - 2021-07-24 09:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:43:27 --> Input Class Initialized
INFO - 2021-07-24 09:43:27 --> Language Class Initialized
INFO - 2021-07-24 09:43:27 --> Language Class Initialized
INFO - 2021-07-24 09:43:27 --> Config Class Initialized
INFO - 2021-07-24 09:43:27 --> Loader Class Initialized
INFO - 2021-07-24 09:43:27 --> Helper loaded: url_helper
INFO - 2021-07-24 09:43:27 --> Helper loaded: file_helper
INFO - 2021-07-24 09:43:27 --> Helper loaded: form_helper
INFO - 2021-07-24 09:43:27 --> Helper loaded: my_helper
INFO - 2021-07-24 09:43:27 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:43:27 --> Controller Class Initialized
INFO - 2021-07-24 09:43:28 --> Config Class Initialized
INFO - 2021-07-24 09:43:28 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:43:28 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:43:28 --> Utf8 Class Initialized
INFO - 2021-07-24 09:43:28 --> URI Class Initialized
INFO - 2021-07-24 09:43:28 --> Router Class Initialized
INFO - 2021-07-24 09:43:28 --> Output Class Initialized
INFO - 2021-07-24 09:43:28 --> Security Class Initialized
DEBUG - 2021-07-24 09:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:43:28 --> Input Class Initialized
INFO - 2021-07-24 09:43:28 --> Language Class Initialized
INFO - 2021-07-24 09:43:28 --> Language Class Initialized
INFO - 2021-07-24 09:43:28 --> Config Class Initialized
INFO - 2021-07-24 09:43:28 --> Loader Class Initialized
INFO - 2021-07-24 09:43:28 --> Helper loaded: url_helper
INFO - 2021-07-24 09:43:28 --> Helper loaded: file_helper
INFO - 2021-07-24 09:43:28 --> Helper loaded: form_helper
INFO - 2021-07-24 09:43:28 --> Helper loaded: my_helper
INFO - 2021-07-24 09:43:28 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:43:28 --> Controller Class Initialized
ERROR - 2021-07-24 09:43:28 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-24 09:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-24 09:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:43:29 --> Final output sent to browser
DEBUG - 2021-07-24 09:43:29 --> Total execution time: 0.1280
INFO - 2021-07-24 09:53:36 --> Config Class Initialized
INFO - 2021-07-24 09:53:36 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:53:36 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:53:36 --> Utf8 Class Initialized
INFO - 2021-07-24 09:53:36 --> URI Class Initialized
INFO - 2021-07-24 09:53:36 --> Router Class Initialized
INFO - 2021-07-24 09:53:36 --> Output Class Initialized
INFO - 2021-07-24 09:53:36 --> Security Class Initialized
DEBUG - 2021-07-24 09:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:53:36 --> Input Class Initialized
INFO - 2021-07-24 09:53:36 --> Language Class Initialized
INFO - 2021-07-24 09:53:36 --> Language Class Initialized
INFO - 2021-07-24 09:53:36 --> Config Class Initialized
INFO - 2021-07-24 09:53:36 --> Loader Class Initialized
INFO - 2021-07-24 09:53:36 --> Helper loaded: url_helper
INFO - 2021-07-24 09:53:36 --> Helper loaded: file_helper
INFO - 2021-07-24 09:53:36 --> Helper loaded: form_helper
INFO - 2021-07-24 09:53:36 --> Helper loaded: my_helper
INFO - 2021-07-24 09:53:36 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:53:36 --> Controller Class Initialized
DEBUG - 2021-07-24 09:53:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 09:53:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:53:36 --> Final output sent to browser
DEBUG - 2021-07-24 09:53:36 --> Total execution time: 0.0654
INFO - 2021-07-24 09:53:37 --> Config Class Initialized
INFO - 2021-07-24 09:53:37 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:53:37 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:53:37 --> Utf8 Class Initialized
INFO - 2021-07-24 09:53:37 --> URI Class Initialized
INFO - 2021-07-24 09:53:37 --> Router Class Initialized
INFO - 2021-07-24 09:53:37 --> Output Class Initialized
INFO - 2021-07-24 09:53:37 --> Security Class Initialized
DEBUG - 2021-07-24 09:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:53:37 --> Input Class Initialized
INFO - 2021-07-24 09:53:37 --> Language Class Initialized
INFO - 2021-07-24 09:53:37 --> Language Class Initialized
INFO - 2021-07-24 09:53:37 --> Config Class Initialized
INFO - 2021-07-24 09:53:37 --> Loader Class Initialized
INFO - 2021-07-24 09:53:37 --> Helper loaded: url_helper
INFO - 2021-07-24 09:53:37 --> Helper loaded: file_helper
INFO - 2021-07-24 09:53:37 --> Helper loaded: form_helper
INFO - 2021-07-24 09:53:37 --> Helper loaded: my_helper
INFO - 2021-07-24 09:53:37 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:53:37 --> Controller Class Initialized
INFO - 2021-07-24 09:58:19 --> Config Class Initialized
INFO - 2021-07-24 09:58:19 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:58:19 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:58:19 --> Utf8 Class Initialized
INFO - 2021-07-24 09:58:19 --> URI Class Initialized
INFO - 2021-07-24 09:58:19 --> Router Class Initialized
INFO - 2021-07-24 09:58:19 --> Output Class Initialized
INFO - 2021-07-24 09:58:19 --> Security Class Initialized
DEBUG - 2021-07-24 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:58:19 --> Input Class Initialized
INFO - 2021-07-24 09:58:19 --> Language Class Initialized
INFO - 2021-07-24 09:58:19 --> Language Class Initialized
INFO - 2021-07-24 09:58:19 --> Config Class Initialized
INFO - 2021-07-24 09:58:19 --> Loader Class Initialized
INFO - 2021-07-24 09:58:19 --> Helper loaded: url_helper
INFO - 2021-07-24 09:58:19 --> Helper loaded: file_helper
INFO - 2021-07-24 09:58:19 --> Helper loaded: form_helper
INFO - 2021-07-24 09:58:19 --> Helper loaded: my_helper
INFO - 2021-07-24 09:58:19 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:58:19 --> Controller Class Initialized
DEBUG - 2021-07-24 09:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 09:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:58:19 --> Final output sent to browser
DEBUG - 2021-07-24 09:58:19 --> Total execution time: 0.0464
INFO - 2021-07-24 09:58:20 --> Config Class Initialized
INFO - 2021-07-24 09:58:20 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:58:20 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:58:20 --> Utf8 Class Initialized
INFO - 2021-07-24 09:58:20 --> URI Class Initialized
INFO - 2021-07-24 09:58:20 --> Router Class Initialized
INFO - 2021-07-24 09:58:20 --> Output Class Initialized
INFO - 2021-07-24 09:58:20 --> Security Class Initialized
DEBUG - 2021-07-24 09:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:58:20 --> Input Class Initialized
INFO - 2021-07-24 09:58:20 --> Language Class Initialized
INFO - 2021-07-24 09:58:20 --> Language Class Initialized
INFO - 2021-07-24 09:58:20 --> Config Class Initialized
INFO - 2021-07-24 09:58:20 --> Loader Class Initialized
INFO - 2021-07-24 09:58:20 --> Helper loaded: url_helper
INFO - 2021-07-24 09:58:20 --> Helper loaded: file_helper
INFO - 2021-07-24 09:58:20 --> Helper loaded: form_helper
INFO - 2021-07-24 09:58:20 --> Helper loaded: my_helper
INFO - 2021-07-24 09:58:20 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:58:20 --> Controller Class Initialized
INFO - 2021-07-24 09:59:23 --> Config Class Initialized
INFO - 2021-07-24 09:59:23 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:59:23 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:59:23 --> Utf8 Class Initialized
INFO - 2021-07-24 09:59:23 --> URI Class Initialized
INFO - 2021-07-24 09:59:23 --> Router Class Initialized
INFO - 2021-07-24 09:59:23 --> Output Class Initialized
INFO - 2021-07-24 09:59:23 --> Security Class Initialized
DEBUG - 2021-07-24 09:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:59:23 --> Input Class Initialized
INFO - 2021-07-24 09:59:23 --> Language Class Initialized
INFO - 2021-07-24 09:59:23 --> Language Class Initialized
INFO - 2021-07-24 09:59:23 --> Config Class Initialized
INFO - 2021-07-24 09:59:23 --> Loader Class Initialized
INFO - 2021-07-24 09:59:23 --> Helper loaded: url_helper
INFO - 2021-07-24 09:59:23 --> Helper loaded: file_helper
INFO - 2021-07-24 09:59:23 --> Helper loaded: form_helper
INFO - 2021-07-24 09:59:23 --> Helper loaded: my_helper
INFO - 2021-07-24 09:59:23 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:59:23 --> Controller Class Initialized
INFO - 2021-07-24 09:59:23 --> Helper loaded: cookie_helper
INFO - 2021-07-24 09:59:23 --> Config Class Initialized
INFO - 2021-07-24 09:59:23 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:59:23 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:59:23 --> Utf8 Class Initialized
INFO - 2021-07-24 09:59:23 --> URI Class Initialized
INFO - 2021-07-24 09:59:23 --> Router Class Initialized
INFO - 2021-07-24 09:59:23 --> Output Class Initialized
INFO - 2021-07-24 09:59:23 --> Security Class Initialized
DEBUG - 2021-07-24 09:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:59:23 --> Input Class Initialized
INFO - 2021-07-24 09:59:23 --> Language Class Initialized
INFO - 2021-07-24 09:59:23 --> Language Class Initialized
INFO - 2021-07-24 09:59:23 --> Config Class Initialized
INFO - 2021-07-24 09:59:23 --> Loader Class Initialized
INFO - 2021-07-24 09:59:23 --> Helper loaded: url_helper
INFO - 2021-07-24 09:59:23 --> Helper loaded: file_helper
INFO - 2021-07-24 09:59:23 --> Helper loaded: form_helper
INFO - 2021-07-24 09:59:23 --> Helper loaded: my_helper
INFO - 2021-07-24 09:59:23 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:59:23 --> Controller Class Initialized
DEBUG - 2021-07-24 09:59:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-24 09:59:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:59:23 --> Final output sent to browser
DEBUG - 2021-07-24 09:59:23 --> Total execution time: 0.0683
INFO - 2021-07-24 09:59:48 --> Config Class Initialized
INFO - 2021-07-24 09:59:48 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:59:48 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:59:48 --> Utf8 Class Initialized
INFO - 2021-07-24 09:59:48 --> URI Class Initialized
DEBUG - 2021-07-24 09:59:48 --> No URI present. Default controller set.
INFO - 2021-07-24 09:59:48 --> Router Class Initialized
INFO - 2021-07-24 09:59:48 --> Output Class Initialized
INFO - 2021-07-24 09:59:48 --> Security Class Initialized
DEBUG - 2021-07-24 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:59:48 --> Input Class Initialized
INFO - 2021-07-24 09:59:48 --> Language Class Initialized
INFO - 2021-07-24 09:59:48 --> Language Class Initialized
INFO - 2021-07-24 09:59:48 --> Config Class Initialized
INFO - 2021-07-24 09:59:48 --> Loader Class Initialized
INFO - 2021-07-24 09:59:48 --> Helper loaded: url_helper
INFO - 2021-07-24 09:59:48 --> Helper loaded: file_helper
INFO - 2021-07-24 09:59:48 --> Helper loaded: form_helper
INFO - 2021-07-24 09:59:48 --> Helper loaded: my_helper
INFO - 2021-07-24 09:59:48 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:59:48 --> Controller Class Initialized
INFO - 2021-07-24 09:59:48 --> Config Class Initialized
INFO - 2021-07-24 09:59:48 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:59:48 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:59:48 --> Utf8 Class Initialized
INFO - 2021-07-24 09:59:48 --> URI Class Initialized
INFO - 2021-07-24 09:59:48 --> Router Class Initialized
INFO - 2021-07-24 09:59:48 --> Output Class Initialized
INFO - 2021-07-24 09:59:48 --> Security Class Initialized
DEBUG - 2021-07-24 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:59:48 --> Input Class Initialized
INFO - 2021-07-24 09:59:48 --> Language Class Initialized
INFO - 2021-07-24 09:59:48 --> Language Class Initialized
INFO - 2021-07-24 09:59:48 --> Config Class Initialized
INFO - 2021-07-24 09:59:48 --> Loader Class Initialized
INFO - 2021-07-24 09:59:48 --> Helper loaded: url_helper
INFO - 2021-07-24 09:59:48 --> Helper loaded: file_helper
INFO - 2021-07-24 09:59:48 --> Helper loaded: form_helper
INFO - 2021-07-24 09:59:48 --> Helper loaded: my_helper
INFO - 2021-07-24 09:59:48 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:59:48 --> Controller Class Initialized
DEBUG - 2021-07-24 09:59:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-24 09:59:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:59:48 --> Final output sent to browser
DEBUG - 2021-07-24 09:59:48 --> Total execution time: 0.0445
INFO - 2021-07-24 09:59:53 --> Config Class Initialized
INFO - 2021-07-24 09:59:53 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:59:53 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:59:53 --> Utf8 Class Initialized
INFO - 2021-07-24 09:59:53 --> URI Class Initialized
INFO - 2021-07-24 09:59:53 --> Router Class Initialized
INFO - 2021-07-24 09:59:53 --> Output Class Initialized
INFO - 2021-07-24 09:59:53 --> Security Class Initialized
DEBUG - 2021-07-24 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:59:53 --> Input Class Initialized
INFO - 2021-07-24 09:59:53 --> Language Class Initialized
INFO - 2021-07-24 09:59:53 --> Language Class Initialized
INFO - 2021-07-24 09:59:53 --> Config Class Initialized
INFO - 2021-07-24 09:59:53 --> Loader Class Initialized
INFO - 2021-07-24 09:59:53 --> Helper loaded: url_helper
INFO - 2021-07-24 09:59:53 --> Helper loaded: file_helper
INFO - 2021-07-24 09:59:53 --> Helper loaded: form_helper
INFO - 2021-07-24 09:59:53 --> Helper loaded: my_helper
INFO - 2021-07-24 09:59:53 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:59:53 --> Controller Class Initialized
INFO - 2021-07-24 09:59:53 --> Helper loaded: cookie_helper
INFO - 2021-07-24 09:59:53 --> Final output sent to browser
DEBUG - 2021-07-24 09:59:53 --> Total execution time: 0.0487
INFO - 2021-07-24 09:59:53 --> Config Class Initialized
INFO - 2021-07-24 09:59:53 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:59:53 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:59:53 --> Utf8 Class Initialized
INFO - 2021-07-24 09:59:53 --> URI Class Initialized
INFO - 2021-07-24 09:59:53 --> Router Class Initialized
INFO - 2021-07-24 09:59:53 --> Output Class Initialized
INFO - 2021-07-24 09:59:53 --> Security Class Initialized
DEBUG - 2021-07-24 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:59:53 --> Input Class Initialized
INFO - 2021-07-24 09:59:53 --> Language Class Initialized
INFO - 2021-07-24 09:59:53 --> Language Class Initialized
INFO - 2021-07-24 09:59:53 --> Config Class Initialized
INFO - 2021-07-24 09:59:53 --> Loader Class Initialized
INFO - 2021-07-24 09:59:53 --> Helper loaded: url_helper
INFO - 2021-07-24 09:59:53 --> Helper loaded: file_helper
INFO - 2021-07-24 09:59:53 --> Helper loaded: form_helper
INFO - 2021-07-24 09:59:53 --> Helper loaded: my_helper
INFO - 2021-07-24 09:59:53 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:59:53 --> Controller Class Initialized
DEBUG - 2021-07-24 09:59:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-24 09:59:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:59:54 --> Final output sent to browser
DEBUG - 2021-07-24 09:59:54 --> Total execution time: 0.7480
INFO - 2021-07-24 09:59:55 --> Config Class Initialized
INFO - 2021-07-24 09:59:55 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:59:55 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:59:55 --> Utf8 Class Initialized
INFO - 2021-07-24 09:59:55 --> URI Class Initialized
INFO - 2021-07-24 09:59:55 --> Router Class Initialized
INFO - 2021-07-24 09:59:55 --> Output Class Initialized
INFO - 2021-07-24 09:59:55 --> Security Class Initialized
DEBUG - 2021-07-24 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:59:55 --> Input Class Initialized
INFO - 2021-07-24 09:59:55 --> Language Class Initialized
INFO - 2021-07-24 09:59:55 --> Language Class Initialized
INFO - 2021-07-24 09:59:55 --> Config Class Initialized
INFO - 2021-07-24 09:59:55 --> Loader Class Initialized
INFO - 2021-07-24 09:59:55 --> Helper loaded: url_helper
INFO - 2021-07-24 09:59:55 --> Helper loaded: file_helper
INFO - 2021-07-24 09:59:55 --> Helper loaded: form_helper
INFO - 2021-07-24 09:59:55 --> Helper loaded: my_helper
INFO - 2021-07-24 09:59:55 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:59:55 --> Controller Class Initialized
DEBUG - 2021-07-24 09:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 09:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 09:59:55 --> Final output sent to browser
DEBUG - 2021-07-24 09:59:55 --> Total execution time: 0.0627
INFO - 2021-07-24 09:59:55 --> Config Class Initialized
INFO - 2021-07-24 09:59:55 --> Hooks Class Initialized
DEBUG - 2021-07-24 09:59:55 --> UTF-8 Support Enabled
INFO - 2021-07-24 09:59:55 --> Utf8 Class Initialized
INFO - 2021-07-24 09:59:55 --> URI Class Initialized
INFO - 2021-07-24 09:59:55 --> Router Class Initialized
INFO - 2021-07-24 09:59:55 --> Output Class Initialized
INFO - 2021-07-24 09:59:55 --> Security Class Initialized
DEBUG - 2021-07-24 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 09:59:55 --> Input Class Initialized
INFO - 2021-07-24 09:59:55 --> Language Class Initialized
INFO - 2021-07-24 09:59:55 --> Language Class Initialized
INFO - 2021-07-24 09:59:55 --> Config Class Initialized
INFO - 2021-07-24 09:59:55 --> Loader Class Initialized
INFO - 2021-07-24 09:59:55 --> Helper loaded: url_helper
INFO - 2021-07-24 09:59:55 --> Helper loaded: file_helper
INFO - 2021-07-24 09:59:55 --> Helper loaded: form_helper
INFO - 2021-07-24 09:59:55 --> Helper loaded: my_helper
INFO - 2021-07-24 09:59:55 --> Database Driver Class Initialized
DEBUG - 2021-07-24 09:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 09:59:55 --> Controller Class Initialized
INFO - 2021-07-24 10:30:10 --> Config Class Initialized
INFO - 2021-07-24 10:30:10 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:30:10 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:30:10 --> Utf8 Class Initialized
INFO - 2021-07-24 10:30:10 --> URI Class Initialized
INFO - 2021-07-24 10:30:10 --> Router Class Initialized
INFO - 2021-07-24 10:30:10 --> Output Class Initialized
INFO - 2021-07-24 10:30:10 --> Security Class Initialized
DEBUG - 2021-07-24 10:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:30:10 --> Input Class Initialized
INFO - 2021-07-24 10:30:10 --> Language Class Initialized
INFO - 2021-07-24 10:30:10 --> Language Class Initialized
INFO - 2021-07-24 10:30:10 --> Config Class Initialized
INFO - 2021-07-24 10:30:10 --> Loader Class Initialized
INFO - 2021-07-24 10:30:10 --> Helper loaded: url_helper
INFO - 2021-07-24 10:30:10 --> Helper loaded: file_helper
INFO - 2021-07-24 10:30:10 --> Helper loaded: form_helper
INFO - 2021-07-24 10:30:10 --> Helper loaded: my_helper
INFO - 2021-07-24 10:30:10 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:30:10 --> Controller Class Initialized
DEBUG - 2021-07-24 10:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:30:10 --> Final output sent to browser
DEBUG - 2021-07-24 10:30:10 --> Total execution time: 0.0604
INFO - 2021-07-24 10:30:10 --> Config Class Initialized
INFO - 2021-07-24 10:30:10 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:30:10 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:30:10 --> Utf8 Class Initialized
INFO - 2021-07-24 10:30:10 --> URI Class Initialized
INFO - 2021-07-24 10:30:10 --> Router Class Initialized
INFO - 2021-07-24 10:30:10 --> Output Class Initialized
INFO - 2021-07-24 10:30:10 --> Security Class Initialized
DEBUG - 2021-07-24 10:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:30:10 --> Input Class Initialized
INFO - 2021-07-24 10:30:10 --> Language Class Initialized
INFO - 2021-07-24 10:30:10 --> Language Class Initialized
INFO - 2021-07-24 10:30:10 --> Config Class Initialized
INFO - 2021-07-24 10:30:10 --> Loader Class Initialized
INFO - 2021-07-24 10:30:10 --> Helper loaded: url_helper
INFO - 2021-07-24 10:30:10 --> Helper loaded: file_helper
INFO - 2021-07-24 10:30:10 --> Helper loaded: form_helper
INFO - 2021-07-24 10:30:10 --> Helper loaded: my_helper
INFO - 2021-07-24 10:30:10 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:30:10 --> Controller Class Initialized
INFO - 2021-07-24 10:30:28 --> Config Class Initialized
INFO - 2021-07-24 10:30:28 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:30:28 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:30:28 --> Utf8 Class Initialized
INFO - 2021-07-24 10:30:28 --> URI Class Initialized
INFO - 2021-07-24 10:30:28 --> Router Class Initialized
INFO - 2021-07-24 10:30:28 --> Output Class Initialized
INFO - 2021-07-24 10:30:28 --> Security Class Initialized
DEBUG - 2021-07-24 10:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:30:28 --> Input Class Initialized
INFO - 2021-07-24 10:30:28 --> Language Class Initialized
INFO - 2021-07-24 10:30:28 --> Language Class Initialized
INFO - 2021-07-24 10:30:28 --> Config Class Initialized
INFO - 2021-07-24 10:30:28 --> Loader Class Initialized
INFO - 2021-07-24 10:30:28 --> Helper loaded: url_helper
INFO - 2021-07-24 10:30:28 --> Helper loaded: file_helper
INFO - 2021-07-24 10:30:28 --> Helper loaded: form_helper
INFO - 2021-07-24 10:30:28 --> Helper loaded: my_helper
INFO - 2021-07-24 10:30:28 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:30:28 --> Controller Class Initialized
DEBUG - 2021-07-24 10:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:30:28 --> Final output sent to browser
DEBUG - 2021-07-24 10:30:28 --> Total execution time: 0.0620
INFO - 2021-07-24 10:30:29 --> Config Class Initialized
INFO - 2021-07-24 10:30:29 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:30:29 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:30:29 --> Utf8 Class Initialized
INFO - 2021-07-24 10:30:29 --> URI Class Initialized
INFO - 2021-07-24 10:30:29 --> Router Class Initialized
INFO - 2021-07-24 10:30:29 --> Output Class Initialized
INFO - 2021-07-24 10:30:29 --> Security Class Initialized
DEBUG - 2021-07-24 10:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:30:29 --> Input Class Initialized
INFO - 2021-07-24 10:30:29 --> Language Class Initialized
INFO - 2021-07-24 10:30:29 --> Language Class Initialized
INFO - 2021-07-24 10:30:29 --> Config Class Initialized
INFO - 2021-07-24 10:30:29 --> Loader Class Initialized
INFO - 2021-07-24 10:30:29 --> Helper loaded: url_helper
INFO - 2021-07-24 10:30:29 --> Helper loaded: file_helper
INFO - 2021-07-24 10:30:29 --> Helper loaded: form_helper
INFO - 2021-07-24 10:30:29 --> Helper loaded: my_helper
INFO - 2021-07-24 10:30:29 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:30:29 --> Controller Class Initialized
INFO - 2021-07-24 10:33:21 --> Config Class Initialized
INFO - 2021-07-24 10:33:21 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:21 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:21 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:21 --> URI Class Initialized
INFO - 2021-07-24 10:33:21 --> Router Class Initialized
INFO - 2021-07-24 10:33:21 --> Output Class Initialized
INFO - 2021-07-24 10:33:21 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:21 --> Input Class Initialized
INFO - 2021-07-24 10:33:21 --> Language Class Initialized
INFO - 2021-07-24 10:33:21 --> Language Class Initialized
INFO - 2021-07-24 10:33:21 --> Config Class Initialized
INFO - 2021-07-24 10:33:21 --> Loader Class Initialized
INFO - 2021-07-24 10:33:21 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:21 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:21 --> Controller Class Initialized
INFO - 2021-07-24 10:33:21 --> Config Class Initialized
INFO - 2021-07-24 10:33:21 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:21 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:21 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:21 --> URI Class Initialized
INFO - 2021-07-24 10:33:21 --> Router Class Initialized
INFO - 2021-07-24 10:33:21 --> Output Class Initialized
INFO - 2021-07-24 10:33:21 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:21 --> Input Class Initialized
INFO - 2021-07-24 10:33:21 --> Language Class Initialized
INFO - 2021-07-24 10:33:21 --> Language Class Initialized
INFO - 2021-07-24 10:33:21 --> Config Class Initialized
INFO - 2021-07-24 10:33:21 --> Loader Class Initialized
INFO - 2021-07-24 10:33:21 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:21 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:21 --> Controller Class Initialized
DEBUG - 2021-07-24 10:33:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:33:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:33:21 --> Final output sent to browser
DEBUG - 2021-07-24 10:33:21 --> Total execution time: 0.0436
INFO - 2021-07-24 10:33:21 --> Config Class Initialized
INFO - 2021-07-24 10:33:21 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:21 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:21 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:21 --> URI Class Initialized
INFO - 2021-07-24 10:33:21 --> Router Class Initialized
INFO - 2021-07-24 10:33:21 --> Output Class Initialized
INFO - 2021-07-24 10:33:21 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:21 --> Input Class Initialized
INFO - 2021-07-24 10:33:21 --> Language Class Initialized
INFO - 2021-07-24 10:33:21 --> Language Class Initialized
INFO - 2021-07-24 10:33:21 --> Config Class Initialized
INFO - 2021-07-24 10:33:21 --> Loader Class Initialized
INFO - 2021-07-24 10:33:21 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:21 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:21 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:21 --> Controller Class Initialized
INFO - 2021-07-24 10:33:22 --> Config Class Initialized
INFO - 2021-07-24 10:33:22 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:22 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:22 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:22 --> URI Class Initialized
INFO - 2021-07-24 10:33:22 --> Router Class Initialized
INFO - 2021-07-24 10:33:22 --> Output Class Initialized
INFO - 2021-07-24 10:33:22 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:22 --> Input Class Initialized
INFO - 2021-07-24 10:33:22 --> Language Class Initialized
INFO - 2021-07-24 10:33:22 --> Language Class Initialized
INFO - 2021-07-24 10:33:22 --> Config Class Initialized
INFO - 2021-07-24 10:33:22 --> Loader Class Initialized
INFO - 2021-07-24 10:33:22 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:22 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:22 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:22 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:22 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:22 --> Controller Class Initialized
DEBUG - 2021-07-24 10:33:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-07-24 10:33:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:33:22 --> Final output sent to browser
DEBUG - 2021-07-24 10:33:22 --> Total execution time: 0.0471
INFO - 2021-07-24 10:33:26 --> Config Class Initialized
INFO - 2021-07-24 10:33:26 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:26 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:26 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:26 --> URI Class Initialized
INFO - 2021-07-24 10:33:26 --> Router Class Initialized
INFO - 2021-07-24 10:33:26 --> Output Class Initialized
INFO - 2021-07-24 10:33:26 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:26 --> Input Class Initialized
INFO - 2021-07-24 10:33:26 --> Language Class Initialized
INFO - 2021-07-24 10:33:26 --> Language Class Initialized
INFO - 2021-07-24 10:33:26 --> Config Class Initialized
INFO - 2021-07-24 10:33:26 --> Loader Class Initialized
INFO - 2021-07-24 10:33:26 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:26 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:26 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:26 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:26 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:26 --> Controller Class Initialized
INFO - 2021-07-24 10:33:29 --> Config Class Initialized
INFO - 2021-07-24 10:33:29 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:29 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:29 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:29 --> URI Class Initialized
INFO - 2021-07-24 10:33:29 --> Router Class Initialized
INFO - 2021-07-24 10:33:29 --> Output Class Initialized
INFO - 2021-07-24 10:33:29 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:29 --> Input Class Initialized
INFO - 2021-07-24 10:33:29 --> Language Class Initialized
INFO - 2021-07-24 10:33:29 --> Language Class Initialized
INFO - 2021-07-24 10:33:29 --> Config Class Initialized
INFO - 2021-07-24 10:33:29 --> Loader Class Initialized
INFO - 2021-07-24 10:33:29 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:29 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:29 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:29 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:29 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:29 --> Controller Class Initialized
DEBUG - 2021-07-24 10:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-07-24 10:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:33:29 --> Final output sent to browser
DEBUG - 2021-07-24 10:33:29 --> Total execution time: 0.0542
INFO - 2021-07-24 10:33:30 --> Config Class Initialized
INFO - 2021-07-24 10:33:30 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:30 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:30 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:30 --> URI Class Initialized
INFO - 2021-07-24 10:33:30 --> Router Class Initialized
INFO - 2021-07-24 10:33:30 --> Output Class Initialized
INFO - 2021-07-24 10:33:30 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:30 --> Input Class Initialized
INFO - 2021-07-24 10:33:30 --> Language Class Initialized
INFO - 2021-07-24 10:33:30 --> Language Class Initialized
INFO - 2021-07-24 10:33:30 --> Config Class Initialized
INFO - 2021-07-24 10:33:30 --> Loader Class Initialized
INFO - 2021-07-24 10:33:30 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:30 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:30 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:30 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:30 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:30 --> Controller Class Initialized
DEBUG - 2021-07-24 10:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:33:30 --> Final output sent to browser
DEBUG - 2021-07-24 10:33:30 --> Total execution time: 0.0453
INFO - 2021-07-24 10:33:30 --> Config Class Initialized
INFO - 2021-07-24 10:33:30 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:30 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:30 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:30 --> URI Class Initialized
INFO - 2021-07-24 10:33:30 --> Router Class Initialized
INFO - 2021-07-24 10:33:30 --> Output Class Initialized
INFO - 2021-07-24 10:33:30 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:30 --> Input Class Initialized
INFO - 2021-07-24 10:33:30 --> Language Class Initialized
INFO - 2021-07-24 10:33:30 --> Language Class Initialized
INFO - 2021-07-24 10:33:30 --> Config Class Initialized
INFO - 2021-07-24 10:33:30 --> Loader Class Initialized
INFO - 2021-07-24 10:33:30 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:30 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:30 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:30 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:30 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:30 --> Controller Class Initialized
INFO - 2021-07-24 10:33:32 --> Config Class Initialized
INFO - 2021-07-24 10:33:32 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:33:32 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:33:32 --> Utf8 Class Initialized
INFO - 2021-07-24 10:33:32 --> URI Class Initialized
INFO - 2021-07-24 10:33:32 --> Router Class Initialized
INFO - 2021-07-24 10:33:32 --> Output Class Initialized
INFO - 2021-07-24 10:33:32 --> Security Class Initialized
DEBUG - 2021-07-24 10:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:33:32 --> Input Class Initialized
INFO - 2021-07-24 10:33:32 --> Language Class Initialized
INFO - 2021-07-24 10:33:32 --> Language Class Initialized
INFO - 2021-07-24 10:33:32 --> Config Class Initialized
INFO - 2021-07-24 10:33:32 --> Loader Class Initialized
INFO - 2021-07-24 10:33:32 --> Helper loaded: url_helper
INFO - 2021-07-24 10:33:32 --> Helper loaded: file_helper
INFO - 2021-07-24 10:33:32 --> Helper loaded: form_helper
INFO - 2021-07-24 10:33:32 --> Helper loaded: my_helper
INFO - 2021-07-24 10:33:32 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:33:32 --> Controller Class Initialized
ERROR - 2021-07-24 10:33:32 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-24 10:33:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-24 10:33:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:33:32 --> Final output sent to browser
DEBUG - 2021-07-24 10:33:32 --> Total execution time: 0.0617
INFO - 2021-07-24 10:38:08 --> Config Class Initialized
INFO - 2021-07-24 10:38:08 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:38:08 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:38:08 --> Utf8 Class Initialized
INFO - 2021-07-24 10:38:08 --> URI Class Initialized
INFO - 2021-07-24 10:38:08 --> Router Class Initialized
INFO - 2021-07-24 10:38:08 --> Output Class Initialized
INFO - 2021-07-24 10:38:08 --> Security Class Initialized
DEBUG - 2021-07-24 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:38:08 --> Input Class Initialized
INFO - 2021-07-24 10:38:08 --> Language Class Initialized
INFO - 2021-07-24 10:38:08 --> Language Class Initialized
INFO - 2021-07-24 10:38:08 --> Config Class Initialized
INFO - 2021-07-24 10:38:08 --> Loader Class Initialized
INFO - 2021-07-24 10:38:08 --> Helper loaded: url_helper
INFO - 2021-07-24 10:38:08 --> Helper loaded: file_helper
INFO - 2021-07-24 10:38:08 --> Helper loaded: form_helper
INFO - 2021-07-24 10:38:08 --> Helper loaded: my_helper
INFO - 2021-07-24 10:38:08 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:38:08 --> Controller Class Initialized
DEBUG - 2021-07-24 10:38:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:38:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:38:08 --> Final output sent to browser
DEBUG - 2021-07-24 10:38:08 --> Total execution time: 0.0635
INFO - 2021-07-24 10:38:08 --> Config Class Initialized
INFO - 2021-07-24 10:38:08 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:38:08 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:38:08 --> Utf8 Class Initialized
INFO - 2021-07-24 10:38:08 --> URI Class Initialized
INFO - 2021-07-24 10:38:08 --> Router Class Initialized
INFO - 2021-07-24 10:38:08 --> Output Class Initialized
INFO - 2021-07-24 10:38:08 --> Security Class Initialized
DEBUG - 2021-07-24 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:38:08 --> Input Class Initialized
INFO - 2021-07-24 10:38:08 --> Language Class Initialized
INFO - 2021-07-24 10:38:08 --> Language Class Initialized
INFO - 2021-07-24 10:38:08 --> Config Class Initialized
INFO - 2021-07-24 10:38:08 --> Loader Class Initialized
INFO - 2021-07-24 10:38:08 --> Helper loaded: url_helper
INFO - 2021-07-24 10:38:08 --> Helper loaded: file_helper
INFO - 2021-07-24 10:38:08 --> Helper loaded: form_helper
INFO - 2021-07-24 10:38:08 --> Helper loaded: my_helper
INFO - 2021-07-24 10:38:08 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:38:08 --> Controller Class Initialized
INFO - 2021-07-24 10:38:42 --> Config Class Initialized
INFO - 2021-07-24 10:38:42 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:38:42 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:38:42 --> Utf8 Class Initialized
INFO - 2021-07-24 10:38:42 --> URI Class Initialized
INFO - 2021-07-24 10:38:42 --> Router Class Initialized
INFO - 2021-07-24 10:38:42 --> Output Class Initialized
INFO - 2021-07-24 10:38:42 --> Security Class Initialized
DEBUG - 2021-07-24 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:38:42 --> Input Class Initialized
INFO - 2021-07-24 10:38:42 --> Language Class Initialized
INFO - 2021-07-24 10:38:42 --> Language Class Initialized
INFO - 2021-07-24 10:38:42 --> Config Class Initialized
INFO - 2021-07-24 10:38:42 --> Loader Class Initialized
INFO - 2021-07-24 10:38:42 --> Helper loaded: url_helper
INFO - 2021-07-24 10:38:42 --> Helper loaded: file_helper
INFO - 2021-07-24 10:38:42 --> Helper loaded: form_helper
INFO - 2021-07-24 10:38:42 --> Helper loaded: my_helper
INFO - 2021-07-24 10:38:42 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:38:42 --> Controller Class Initialized
ERROR - 2021-07-24 10:38:42 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-24 10:38:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-24 10:38:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:38:42 --> Final output sent to browser
DEBUG - 2021-07-24 10:38:42 --> Total execution time: 0.0498
INFO - 2021-07-24 10:38:55 --> Config Class Initialized
INFO - 2021-07-24 10:38:55 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:38:55 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:38:55 --> Utf8 Class Initialized
INFO - 2021-07-24 10:38:55 --> URI Class Initialized
INFO - 2021-07-24 10:38:55 --> Router Class Initialized
INFO - 2021-07-24 10:38:55 --> Output Class Initialized
INFO - 2021-07-24 10:38:55 --> Security Class Initialized
DEBUG - 2021-07-24 10:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:38:55 --> Input Class Initialized
INFO - 2021-07-24 10:38:55 --> Language Class Initialized
INFO - 2021-07-24 10:38:55 --> Language Class Initialized
INFO - 2021-07-24 10:38:55 --> Config Class Initialized
INFO - 2021-07-24 10:38:55 --> Loader Class Initialized
INFO - 2021-07-24 10:38:55 --> Helper loaded: url_helper
INFO - 2021-07-24 10:38:55 --> Helper loaded: file_helper
INFO - 2021-07-24 10:38:55 --> Helper loaded: form_helper
INFO - 2021-07-24 10:38:55 --> Helper loaded: my_helper
INFO - 2021-07-24 10:38:55 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:38:55 --> Controller Class Initialized
DEBUG - 2021-07-24 10:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:38:55 --> Final output sent to browser
DEBUG - 2021-07-24 10:38:55 --> Total execution time: 0.0561
INFO - 2021-07-24 10:38:55 --> Config Class Initialized
INFO - 2021-07-24 10:38:55 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:38:55 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:38:55 --> Utf8 Class Initialized
INFO - 2021-07-24 10:38:55 --> URI Class Initialized
INFO - 2021-07-24 10:38:55 --> Router Class Initialized
INFO - 2021-07-24 10:38:55 --> Output Class Initialized
INFO - 2021-07-24 10:38:55 --> Security Class Initialized
DEBUG - 2021-07-24 10:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:38:55 --> Input Class Initialized
INFO - 2021-07-24 10:38:55 --> Language Class Initialized
INFO - 2021-07-24 10:38:55 --> Language Class Initialized
INFO - 2021-07-24 10:38:55 --> Config Class Initialized
INFO - 2021-07-24 10:38:55 --> Loader Class Initialized
INFO - 2021-07-24 10:38:55 --> Helper loaded: url_helper
INFO - 2021-07-24 10:38:55 --> Helper loaded: file_helper
INFO - 2021-07-24 10:38:55 --> Helper loaded: form_helper
INFO - 2021-07-24 10:38:55 --> Helper loaded: my_helper
INFO - 2021-07-24 10:38:55 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:38:55 --> Controller Class Initialized
INFO - 2021-07-24 10:39:13 --> Config Class Initialized
INFO - 2021-07-24 10:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:13 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:13 --> URI Class Initialized
INFO - 2021-07-24 10:39:13 --> Router Class Initialized
INFO - 2021-07-24 10:39:13 --> Output Class Initialized
INFO - 2021-07-24 10:39:13 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:13 --> Input Class Initialized
INFO - 2021-07-24 10:39:13 --> Language Class Initialized
INFO - 2021-07-24 10:39:13 --> Language Class Initialized
INFO - 2021-07-24 10:39:13 --> Config Class Initialized
INFO - 2021-07-24 10:39:13 --> Loader Class Initialized
INFO - 2021-07-24 10:39:13 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:13 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:13 --> Controller Class Initialized
INFO - 2021-07-24 10:39:13 --> Config Class Initialized
INFO - 2021-07-24 10:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:13 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:13 --> URI Class Initialized
INFO - 2021-07-24 10:39:13 --> Router Class Initialized
INFO - 2021-07-24 10:39:13 --> Output Class Initialized
INFO - 2021-07-24 10:39:13 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:13 --> Input Class Initialized
INFO - 2021-07-24 10:39:13 --> Language Class Initialized
INFO - 2021-07-24 10:39:13 --> Language Class Initialized
INFO - 2021-07-24 10:39:13 --> Config Class Initialized
INFO - 2021-07-24 10:39:13 --> Loader Class Initialized
INFO - 2021-07-24 10:39:13 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:13 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:13 --> Controller Class Initialized
DEBUG - 2021-07-24 10:39:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:39:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:39:13 --> Final output sent to browser
DEBUG - 2021-07-24 10:39:13 --> Total execution time: 0.0461
INFO - 2021-07-24 10:39:13 --> Config Class Initialized
INFO - 2021-07-24 10:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:13 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:13 --> URI Class Initialized
INFO - 2021-07-24 10:39:13 --> Router Class Initialized
INFO - 2021-07-24 10:39:13 --> Output Class Initialized
INFO - 2021-07-24 10:39:13 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:13 --> Input Class Initialized
INFO - 2021-07-24 10:39:13 --> Language Class Initialized
INFO - 2021-07-24 10:39:13 --> Language Class Initialized
INFO - 2021-07-24 10:39:13 --> Config Class Initialized
INFO - 2021-07-24 10:39:13 --> Loader Class Initialized
INFO - 2021-07-24 10:39:13 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:13 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:13 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:13 --> Controller Class Initialized
INFO - 2021-07-24 10:39:14 --> Config Class Initialized
INFO - 2021-07-24 10:39:14 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:14 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:14 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:14 --> URI Class Initialized
INFO - 2021-07-24 10:39:14 --> Router Class Initialized
INFO - 2021-07-24 10:39:14 --> Output Class Initialized
INFO - 2021-07-24 10:39:14 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:14 --> Input Class Initialized
INFO - 2021-07-24 10:39:14 --> Language Class Initialized
INFO - 2021-07-24 10:39:14 --> Language Class Initialized
INFO - 2021-07-24 10:39:14 --> Config Class Initialized
INFO - 2021-07-24 10:39:14 --> Loader Class Initialized
INFO - 2021-07-24 10:39:14 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:14 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:14 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:14 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:14 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:15 --> Controller Class Initialized
DEBUG - 2021-07-24 10:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-07-24 10:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:39:15 --> Final output sent to browser
DEBUG - 2021-07-24 10:39:15 --> Total execution time: 0.0641
INFO - 2021-07-24 10:39:18 --> Config Class Initialized
INFO - 2021-07-24 10:39:18 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:18 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:18 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:18 --> URI Class Initialized
INFO - 2021-07-24 10:39:18 --> Router Class Initialized
INFO - 2021-07-24 10:39:18 --> Output Class Initialized
INFO - 2021-07-24 10:39:18 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:18 --> Input Class Initialized
INFO - 2021-07-24 10:39:18 --> Language Class Initialized
INFO - 2021-07-24 10:39:18 --> Language Class Initialized
INFO - 2021-07-24 10:39:18 --> Config Class Initialized
INFO - 2021-07-24 10:39:18 --> Loader Class Initialized
INFO - 2021-07-24 10:39:18 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:18 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:18 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:18 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:18 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:18 --> Controller Class Initialized
INFO - 2021-07-24 10:39:21 --> Config Class Initialized
INFO - 2021-07-24 10:39:21 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:21 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:21 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:21 --> URI Class Initialized
INFO - 2021-07-24 10:39:21 --> Router Class Initialized
INFO - 2021-07-24 10:39:21 --> Output Class Initialized
INFO - 2021-07-24 10:39:21 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:21 --> Input Class Initialized
INFO - 2021-07-24 10:39:21 --> Language Class Initialized
INFO - 2021-07-24 10:39:21 --> Language Class Initialized
INFO - 2021-07-24 10:39:21 --> Config Class Initialized
INFO - 2021-07-24 10:39:21 --> Loader Class Initialized
INFO - 2021-07-24 10:39:21 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:21 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:21 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:21 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:21 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:21 --> Controller Class Initialized
DEBUG - 2021-07-24 10:39:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-07-24 10:39:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:39:21 --> Final output sent to browser
DEBUG - 2021-07-24 10:39:21 --> Total execution time: 0.0611
INFO - 2021-07-24 10:39:22 --> Config Class Initialized
INFO - 2021-07-24 10:39:22 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:22 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:22 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:22 --> URI Class Initialized
INFO - 2021-07-24 10:39:22 --> Router Class Initialized
INFO - 2021-07-24 10:39:22 --> Output Class Initialized
INFO - 2021-07-24 10:39:22 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:22 --> Input Class Initialized
INFO - 2021-07-24 10:39:22 --> Language Class Initialized
INFO - 2021-07-24 10:39:22 --> Language Class Initialized
INFO - 2021-07-24 10:39:22 --> Config Class Initialized
INFO - 2021-07-24 10:39:22 --> Loader Class Initialized
INFO - 2021-07-24 10:39:22 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:22 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:22 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:22 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:22 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:22 --> Controller Class Initialized
DEBUG - 2021-07-24 10:39:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:39:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:39:22 --> Final output sent to browser
DEBUG - 2021-07-24 10:39:22 --> Total execution time: 0.0597
INFO - 2021-07-24 10:39:22 --> Config Class Initialized
INFO - 2021-07-24 10:39:22 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:22 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:22 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:22 --> URI Class Initialized
INFO - 2021-07-24 10:39:22 --> Router Class Initialized
INFO - 2021-07-24 10:39:22 --> Output Class Initialized
INFO - 2021-07-24 10:39:22 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:22 --> Input Class Initialized
INFO - 2021-07-24 10:39:22 --> Language Class Initialized
INFO - 2021-07-24 10:39:22 --> Language Class Initialized
INFO - 2021-07-24 10:39:22 --> Config Class Initialized
INFO - 2021-07-24 10:39:22 --> Loader Class Initialized
INFO - 2021-07-24 10:39:22 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:22 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:22 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:22 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:22 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:22 --> Controller Class Initialized
INFO - 2021-07-24 10:39:24 --> Config Class Initialized
INFO - 2021-07-24 10:39:24 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:24 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:24 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:24 --> URI Class Initialized
INFO - 2021-07-24 10:39:24 --> Router Class Initialized
INFO - 2021-07-24 10:39:24 --> Output Class Initialized
INFO - 2021-07-24 10:39:24 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:24 --> Input Class Initialized
INFO - 2021-07-24 10:39:24 --> Language Class Initialized
INFO - 2021-07-24 10:39:24 --> Language Class Initialized
INFO - 2021-07-24 10:39:24 --> Config Class Initialized
INFO - 2021-07-24 10:39:24 --> Loader Class Initialized
INFO - 2021-07-24 10:39:24 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:24 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:24 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:24 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:24 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:24 --> Controller Class Initialized
ERROR - 2021-07-24 10:39:24 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-24 10:39:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-24 10:39:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:39:24 --> Final output sent to browser
DEBUG - 2021-07-24 10:39:24 --> Total execution time: 0.0692
INFO - 2021-07-24 10:39:49 --> Config Class Initialized
INFO - 2021-07-24 10:39:49 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:49 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:49 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:49 --> URI Class Initialized
INFO - 2021-07-24 10:39:49 --> Router Class Initialized
INFO - 2021-07-24 10:39:49 --> Output Class Initialized
INFO - 2021-07-24 10:39:49 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:49 --> Input Class Initialized
INFO - 2021-07-24 10:39:49 --> Language Class Initialized
INFO - 2021-07-24 10:39:49 --> Language Class Initialized
INFO - 2021-07-24 10:39:49 --> Config Class Initialized
INFO - 2021-07-24 10:39:49 --> Loader Class Initialized
INFO - 2021-07-24 10:39:49 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:49 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:49 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:49 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:49 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:49 --> Controller Class Initialized
DEBUG - 2021-07-24 10:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-24 10:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-24 10:39:49 --> Final output sent to browser
DEBUG - 2021-07-24 10:39:49 --> Total execution time: 0.0671
INFO - 2021-07-24 10:39:49 --> Config Class Initialized
INFO - 2021-07-24 10:39:49 --> Hooks Class Initialized
DEBUG - 2021-07-24 10:39:49 --> UTF-8 Support Enabled
INFO - 2021-07-24 10:39:49 --> Utf8 Class Initialized
INFO - 2021-07-24 10:39:49 --> URI Class Initialized
INFO - 2021-07-24 10:39:49 --> Router Class Initialized
INFO - 2021-07-24 10:39:49 --> Output Class Initialized
INFO - 2021-07-24 10:39:49 --> Security Class Initialized
DEBUG - 2021-07-24 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 10:39:49 --> Input Class Initialized
INFO - 2021-07-24 10:39:49 --> Language Class Initialized
INFO - 2021-07-24 10:39:49 --> Language Class Initialized
INFO - 2021-07-24 10:39:49 --> Config Class Initialized
INFO - 2021-07-24 10:39:49 --> Loader Class Initialized
INFO - 2021-07-24 10:39:49 --> Helper loaded: url_helper
INFO - 2021-07-24 10:39:49 --> Helper loaded: file_helper
INFO - 2021-07-24 10:39:49 --> Helper loaded: form_helper
INFO - 2021-07-24 10:39:49 --> Helper loaded: my_helper
INFO - 2021-07-24 10:39:49 --> Database Driver Class Initialized
DEBUG - 2021-07-24 10:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 10:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 10:39:49 --> Controller Class Initialized
