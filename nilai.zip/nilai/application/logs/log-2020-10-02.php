<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-02 02:43:57 --> Config Class Initialized
INFO - 2020-10-02 02:43:57 --> Hooks Class Initialized
DEBUG - 2020-10-02 02:43:57 --> UTF-8 Support Enabled
INFO - 2020-10-02 02:43:57 --> Utf8 Class Initialized
INFO - 2020-10-02 02:43:57 --> URI Class Initialized
DEBUG - 2020-10-02 02:43:57 --> No URI present. Default controller set.
INFO - 2020-10-02 02:43:57 --> Router Class Initialized
INFO - 2020-10-02 02:43:57 --> Output Class Initialized
INFO - 2020-10-02 02:43:57 --> Security Class Initialized
DEBUG - 2020-10-02 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 02:43:57 --> Input Class Initialized
INFO - 2020-10-02 02:43:57 --> Language Class Initialized
INFO - 2020-10-02 02:43:57 --> Language Class Initialized
INFO - 2020-10-02 02:43:58 --> Config Class Initialized
INFO - 2020-10-02 02:43:58 --> Loader Class Initialized
INFO - 2020-10-02 02:43:58 --> Helper loaded: url_helper
INFO - 2020-10-02 02:43:58 --> Helper loaded: file_helper
INFO - 2020-10-02 02:43:58 --> Helper loaded: form_helper
INFO - 2020-10-02 02:43:58 --> Helper loaded: my_helper
INFO - 2020-10-02 02:43:58 --> Database Driver Class Initialized
DEBUG - 2020-10-02 02:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-02 02:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 02:43:58 --> Controller Class Initialized
INFO - 2020-10-02 02:43:58 --> Config Class Initialized
INFO - 2020-10-02 02:43:58 --> Hooks Class Initialized
DEBUG - 2020-10-02 02:43:58 --> UTF-8 Support Enabled
INFO - 2020-10-02 02:43:58 --> Utf8 Class Initialized
INFO - 2020-10-02 02:43:58 --> URI Class Initialized
INFO - 2020-10-02 02:43:58 --> Router Class Initialized
INFO - 2020-10-02 02:43:58 --> Output Class Initialized
INFO - 2020-10-02 02:43:58 --> Security Class Initialized
DEBUG - 2020-10-02 02:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 02:43:58 --> Input Class Initialized
INFO - 2020-10-02 02:43:58 --> Language Class Initialized
INFO - 2020-10-02 02:43:58 --> Language Class Initialized
INFO - 2020-10-02 02:43:58 --> Config Class Initialized
INFO - 2020-10-02 02:43:58 --> Loader Class Initialized
INFO - 2020-10-02 02:43:58 --> Helper loaded: url_helper
INFO - 2020-10-02 02:43:58 --> Helper loaded: file_helper
INFO - 2020-10-02 02:43:58 --> Helper loaded: form_helper
INFO - 2020-10-02 02:43:58 --> Helper loaded: my_helper
INFO - 2020-10-02 02:43:58 --> Database Driver Class Initialized
DEBUG - 2020-10-02 02:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-02 02:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 02:43:58 --> Controller Class Initialized
DEBUG - 2020-10-02 02:43:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-02 02:43:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-02 02:43:58 --> Final output sent to browser
DEBUG - 2020-10-02 02:43:58 --> Total execution time: 0.2543
INFO - 2020-10-02 03:50:16 --> Config Class Initialized
INFO - 2020-10-02 03:50:16 --> Hooks Class Initialized
DEBUG - 2020-10-02 03:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-02 03:50:16 --> Utf8 Class Initialized
INFO - 2020-10-02 03:50:16 --> URI Class Initialized
INFO - 2020-10-02 03:50:16 --> Router Class Initialized
INFO - 2020-10-02 03:50:16 --> Output Class Initialized
INFO - 2020-10-02 03:50:16 --> Security Class Initialized
DEBUG - 2020-10-02 03:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 03:50:16 --> Input Class Initialized
INFO - 2020-10-02 03:50:16 --> Language Class Initialized
INFO - 2020-10-02 03:50:16 --> Language Class Initialized
INFO - 2020-10-02 03:50:16 --> Config Class Initialized
INFO - 2020-10-02 03:50:16 --> Loader Class Initialized
INFO - 2020-10-02 03:50:16 --> Helper loaded: url_helper
INFO - 2020-10-02 03:50:16 --> Helper loaded: file_helper
INFO - 2020-10-02 03:50:16 --> Helper loaded: form_helper
INFO - 2020-10-02 03:50:16 --> Helper loaded: my_helper
INFO - 2020-10-02 03:50:16 --> Database Driver Class Initialized
DEBUG - 2020-10-02 03:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-02 03:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 03:50:16 --> Controller Class Initialized
INFO - 2020-10-02 03:50:16 --> Helper loaded: cookie_helper
INFO - 2020-10-02 03:50:16 --> Final output sent to browser
DEBUG - 2020-10-02 03:50:16 --> Total execution time: 0.9243
INFO - 2020-10-02 03:50:18 --> Config Class Initialized
INFO - 2020-10-02 03:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-02 03:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-02 03:50:18 --> Utf8 Class Initialized
INFO - 2020-10-02 03:50:18 --> URI Class Initialized
INFO - 2020-10-02 03:50:18 --> Router Class Initialized
INFO - 2020-10-02 03:50:18 --> Output Class Initialized
INFO - 2020-10-02 03:50:18 --> Security Class Initialized
DEBUG - 2020-10-02 03:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 03:50:18 --> Input Class Initialized
INFO - 2020-10-02 03:50:18 --> Language Class Initialized
INFO - 2020-10-02 03:50:18 --> Language Class Initialized
INFO - 2020-10-02 03:50:18 --> Config Class Initialized
INFO - 2020-10-02 03:50:18 --> Loader Class Initialized
INFO - 2020-10-02 03:50:18 --> Helper loaded: url_helper
INFO - 2020-10-02 03:50:18 --> Helper loaded: file_helper
INFO - 2020-10-02 03:50:18 --> Helper loaded: form_helper
INFO - 2020-10-02 03:50:18 --> Helper loaded: my_helper
INFO - 2020-10-02 03:50:18 --> Database Driver Class Initialized
DEBUG - 2020-10-02 03:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-02 03:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 03:50:18 --> Controller Class Initialized
DEBUG - 2020-10-02 03:50:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-02 03:50:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-02 03:50:18 --> Final output sent to browser
DEBUG - 2020-10-02 03:50:18 --> Total execution time: 0.4381
INFO - 2020-10-02 03:50:35 --> Config Class Initialized
INFO - 2020-10-02 03:50:35 --> Hooks Class Initialized
DEBUG - 2020-10-02 03:50:35 --> UTF-8 Support Enabled
INFO - 2020-10-02 03:50:35 --> Utf8 Class Initialized
INFO - 2020-10-02 03:50:35 --> URI Class Initialized
INFO - 2020-10-02 03:50:35 --> Router Class Initialized
INFO - 2020-10-02 03:50:35 --> Output Class Initialized
INFO - 2020-10-02 03:50:35 --> Security Class Initialized
DEBUG - 2020-10-02 03:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 03:50:36 --> Input Class Initialized
INFO - 2020-10-02 03:50:36 --> Language Class Initialized
INFO - 2020-10-02 03:50:36 --> Language Class Initialized
INFO - 2020-10-02 03:50:36 --> Config Class Initialized
INFO - 2020-10-02 03:50:36 --> Loader Class Initialized
INFO - 2020-10-02 03:50:36 --> Helper loaded: url_helper
INFO - 2020-10-02 03:50:36 --> Helper loaded: file_helper
INFO - 2020-10-02 03:50:36 --> Helper loaded: form_helper
INFO - 2020-10-02 03:50:36 --> Helper loaded: my_helper
INFO - 2020-10-02 03:50:36 --> Database Driver Class Initialized
DEBUG - 2020-10-02 03:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-02 03:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 03:50:36 --> Controller Class Initialized
INFO - 2020-10-02 03:50:36 --> Helper loaded: cookie_helper
INFO - 2020-10-02 03:50:36 --> Config Class Initialized
INFO - 2020-10-02 03:50:36 --> Hooks Class Initialized
DEBUG - 2020-10-02 03:50:36 --> UTF-8 Support Enabled
INFO - 2020-10-02 03:50:36 --> Utf8 Class Initialized
INFO - 2020-10-02 03:50:36 --> URI Class Initialized
INFO - 2020-10-02 03:50:36 --> Router Class Initialized
INFO - 2020-10-02 03:50:36 --> Output Class Initialized
INFO - 2020-10-02 03:50:36 --> Security Class Initialized
DEBUG - 2020-10-02 03:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 03:50:36 --> Input Class Initialized
INFO - 2020-10-02 03:50:36 --> Language Class Initialized
INFO - 2020-10-02 03:50:36 --> Language Class Initialized
INFO - 2020-10-02 03:50:36 --> Config Class Initialized
INFO - 2020-10-02 03:50:36 --> Loader Class Initialized
INFO - 2020-10-02 03:50:36 --> Helper loaded: url_helper
INFO - 2020-10-02 03:50:36 --> Helper loaded: file_helper
INFO - 2020-10-02 03:50:36 --> Helper loaded: form_helper
INFO - 2020-10-02 03:50:36 --> Helper loaded: my_helper
INFO - 2020-10-02 03:50:36 --> Database Driver Class Initialized
DEBUG - 2020-10-02 03:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-02 03:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 03:50:36 --> Controller Class Initialized
DEBUG - 2020-10-02 03:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-02 03:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-02 03:50:36 --> Final output sent to browser
DEBUG - 2020-10-02 03:50:36 --> Total execution time: 0.2261
