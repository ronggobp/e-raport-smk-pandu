<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-10-01 03:29:47 --> Config Class Initialized
INFO - 2022-10-01 03:29:47 --> Hooks Class Initialized
DEBUG - 2022-10-01 03:29:47 --> UTF-8 Support Enabled
INFO - 2022-10-01 03:29:47 --> Utf8 Class Initialized
INFO - 2022-10-01 03:29:47 --> URI Class Initialized
INFO - 2022-10-01 03:29:47 --> Router Class Initialized
INFO - 2022-10-01 03:29:47 --> Output Class Initialized
INFO - 2022-10-01 03:29:47 --> Security Class Initialized
DEBUG - 2022-10-01 03:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-01 03:29:47 --> Input Class Initialized
INFO - 2022-10-01 03:29:47 --> Language Class Initialized
INFO - 2022-10-01 03:29:47 --> Language Class Initialized
INFO - 2022-10-01 03:29:47 --> Config Class Initialized
INFO - 2022-10-01 03:29:47 --> Loader Class Initialized
INFO - 2022-10-01 03:29:47 --> Helper loaded: url_helper
INFO - 2022-10-01 03:29:48 --> Helper loaded: file_helper
INFO - 2022-10-01 03:29:48 --> Helper loaded: form_helper
INFO - 2022-10-01 03:29:48 --> Helper loaded: my_helper
INFO - 2022-10-01 03:29:48 --> Database Driver Class Initialized
INFO - 2022-10-01 03:29:48 --> Config Class Initialized
INFO - 2022-10-01 03:29:48 --> Hooks Class Initialized
DEBUG - 2022-10-01 03:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-01 03:29:48 --> UTF-8 Support Enabled
INFO - 2022-10-01 03:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-01 03:29:48 --> Utf8 Class Initialized
INFO - 2022-10-01 03:29:48 --> Controller Class Initialized
INFO - 2022-10-01 03:29:48 --> URI Class Initialized
INFO - 2022-10-01 03:29:48 --> Router Class Initialized
INFO - 2022-10-01 03:29:48 --> Output Class Initialized
INFO - 2022-10-01 03:29:48 --> Security Class Initialized
DEBUG - 2022-10-01 03:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-01 03:29:48 --> Input Class Initialized
INFO - 2022-10-01 03:29:48 --> Language Class Initialized
INFO - 2022-10-01 03:29:48 --> Language Class Initialized
INFO - 2022-10-01 03:29:48 --> Config Class Initialized
INFO - 2022-10-01 03:29:48 --> Loader Class Initialized
INFO - 2022-10-01 03:29:48 --> Helper loaded: url_helper
INFO - 2022-10-01 03:29:48 --> Helper loaded: file_helper
INFO - 2022-10-01 03:29:48 --> Helper loaded: form_helper
INFO - 2022-10-01 03:29:48 --> Helper loaded: my_helper
INFO - 2022-10-01 03:29:48 --> Database Driver Class Initialized
DEBUG - 2022-10-01 03:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-01 03:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-01 03:29:48 --> Controller Class Initialized
DEBUG - 2022-10-01 03:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-01 03:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-01 03:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
DEBUG - 2022-10-01 03:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-01 03:29:48 --> Final output sent to browser
INFO - 2022-10-01 03:29:48 --> Final output sent to browser
DEBUG - 2022-10-01 03:29:48 --> Total execution time: 0.1527
DEBUG - 2022-10-01 03:29:48 --> Total execution time: 0.8101
INFO - 2022-10-01 08:35:46 --> Config Class Initialized
INFO - 2022-10-01 08:35:46 --> Hooks Class Initialized
DEBUG - 2022-10-01 08:35:46 --> UTF-8 Support Enabled
INFO - 2022-10-01 08:35:46 --> Utf8 Class Initialized
INFO - 2022-10-01 08:35:46 --> URI Class Initialized
DEBUG - 2022-10-01 08:35:46 --> No URI present. Default controller set.
INFO - 2022-10-01 08:35:46 --> Router Class Initialized
INFO - 2022-10-01 08:35:46 --> Output Class Initialized
INFO - 2022-10-01 08:35:47 --> Security Class Initialized
DEBUG - 2022-10-01 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-01 08:35:47 --> Input Class Initialized
INFO - 2022-10-01 08:35:47 --> Language Class Initialized
INFO - 2022-10-01 08:35:47 --> Language Class Initialized
INFO - 2022-10-01 08:35:47 --> Config Class Initialized
INFO - 2022-10-01 08:35:47 --> Loader Class Initialized
INFO - 2022-10-01 08:35:47 --> Helper loaded: url_helper
INFO - 2022-10-01 08:35:47 --> Helper loaded: file_helper
INFO - 2022-10-01 08:35:47 --> Helper loaded: form_helper
INFO - 2022-10-01 08:35:47 --> Helper loaded: my_helper
INFO - 2022-10-01 08:35:47 --> Database Driver Class Initialized
DEBUG - 2022-10-01 08:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-01 08:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-01 08:35:47 --> Controller Class Initialized
INFO - 2022-10-01 08:35:47 --> Config Class Initialized
INFO - 2022-10-01 08:35:47 --> Hooks Class Initialized
DEBUG - 2022-10-01 08:35:47 --> UTF-8 Support Enabled
INFO - 2022-10-01 08:35:47 --> Utf8 Class Initialized
INFO - 2022-10-01 08:35:47 --> URI Class Initialized
INFO - 2022-10-01 08:35:47 --> Router Class Initialized
INFO - 2022-10-01 08:35:47 --> Output Class Initialized
INFO - 2022-10-01 08:35:47 --> Security Class Initialized
DEBUG - 2022-10-01 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-01 08:35:47 --> Input Class Initialized
INFO - 2022-10-01 08:35:47 --> Language Class Initialized
INFO - 2022-10-01 08:35:47 --> Language Class Initialized
INFO - 2022-10-01 08:35:47 --> Config Class Initialized
INFO - 2022-10-01 08:35:47 --> Loader Class Initialized
INFO - 2022-10-01 08:35:47 --> Helper loaded: url_helper
INFO - 2022-10-01 08:35:47 --> Helper loaded: file_helper
INFO - 2022-10-01 08:35:47 --> Helper loaded: form_helper
INFO - 2022-10-01 08:35:47 --> Helper loaded: my_helper
INFO - 2022-10-01 08:35:47 --> Database Driver Class Initialized
DEBUG - 2022-10-01 08:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-01 08:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-01 08:35:47 --> Controller Class Initialized
DEBUG - 2022-10-01 08:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-01 08:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-01 08:35:47 --> Final output sent to browser
DEBUG - 2022-10-01 08:35:47 --> Total execution time: 0.1000
INFO - 2022-10-01 08:35:51 --> Config Class Initialized
INFO - 2022-10-01 08:35:51 --> Hooks Class Initialized
DEBUG - 2022-10-01 08:35:51 --> UTF-8 Support Enabled
INFO - 2022-10-01 08:35:51 --> Utf8 Class Initialized
INFO - 2022-10-01 08:35:51 --> URI Class Initialized
INFO - 2022-10-01 08:35:51 --> Router Class Initialized
INFO - 2022-10-01 08:35:51 --> Output Class Initialized
INFO - 2022-10-01 08:35:51 --> Security Class Initialized
DEBUG - 2022-10-01 08:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-01 08:35:51 --> Input Class Initialized
INFO - 2022-10-01 08:35:51 --> Language Class Initialized
INFO - 2022-10-01 08:35:51 --> Language Class Initialized
INFO - 2022-10-01 08:35:51 --> Config Class Initialized
INFO - 2022-10-01 08:35:51 --> Loader Class Initialized
INFO - 2022-10-01 08:35:51 --> Helper loaded: url_helper
INFO - 2022-10-01 08:35:51 --> Helper loaded: file_helper
INFO - 2022-10-01 08:35:51 --> Helper loaded: form_helper
INFO - 2022-10-01 08:35:51 --> Helper loaded: my_helper
INFO - 2022-10-01 08:35:51 --> Database Driver Class Initialized
DEBUG - 2022-10-01 08:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-01 08:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-01 08:35:51 --> Controller Class Initialized
DEBUG - 2022-10-01 08:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-01 08:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-01 08:35:51 --> Final output sent to browser
DEBUG - 2022-10-01 08:35:51 --> Total execution time: 0.0541
