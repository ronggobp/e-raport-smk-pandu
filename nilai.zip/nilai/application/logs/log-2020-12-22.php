<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-22 02:08:02 --> Config Class Initialized
INFO - 2020-12-22 02:08:02 --> Hooks Class Initialized
DEBUG - 2020-12-22 02:08:02 --> UTF-8 Support Enabled
INFO - 2020-12-22 02:08:02 --> Utf8 Class Initialized
INFO - 2020-12-22 02:08:02 --> URI Class Initialized
DEBUG - 2020-12-22 02:08:03 --> No URI present. Default controller set.
INFO - 2020-12-22 02:08:03 --> Router Class Initialized
INFO - 2020-12-22 02:08:03 --> Output Class Initialized
INFO - 2020-12-22 02:08:03 --> Security Class Initialized
DEBUG - 2020-12-22 02:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 02:08:03 --> Input Class Initialized
INFO - 2020-12-22 02:08:03 --> Language Class Initialized
INFO - 2020-12-22 02:08:03 --> Language Class Initialized
INFO - 2020-12-22 02:08:03 --> Config Class Initialized
INFO - 2020-12-22 02:08:03 --> Loader Class Initialized
INFO - 2020-12-22 02:08:03 --> Helper loaded: url_helper
INFO - 2020-12-22 02:08:03 --> Helper loaded: file_helper
INFO - 2020-12-22 02:08:04 --> Helper loaded: form_helper
INFO - 2020-12-22 02:08:04 --> Helper loaded: my_helper
INFO - 2020-12-22 02:08:04 --> Database Driver Class Initialized
DEBUG - 2020-12-22 02:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 02:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 02:08:04 --> Controller Class Initialized
INFO - 2020-12-22 02:08:04 --> Config Class Initialized
INFO - 2020-12-22 02:08:04 --> Hooks Class Initialized
DEBUG - 2020-12-22 02:08:04 --> UTF-8 Support Enabled
INFO - 2020-12-22 02:08:04 --> Utf8 Class Initialized
INFO - 2020-12-22 02:08:04 --> URI Class Initialized
INFO - 2020-12-22 02:08:04 --> Router Class Initialized
INFO - 2020-12-22 02:08:04 --> Output Class Initialized
INFO - 2020-12-22 02:08:04 --> Security Class Initialized
DEBUG - 2020-12-22 02:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 02:08:04 --> Input Class Initialized
INFO - 2020-12-22 02:08:04 --> Language Class Initialized
INFO - 2020-12-22 02:08:05 --> Language Class Initialized
INFO - 2020-12-22 02:08:05 --> Config Class Initialized
INFO - 2020-12-22 02:08:05 --> Loader Class Initialized
INFO - 2020-12-22 02:08:05 --> Helper loaded: url_helper
INFO - 2020-12-22 02:08:05 --> Helper loaded: file_helper
INFO - 2020-12-22 02:08:05 --> Helper loaded: form_helper
INFO - 2020-12-22 02:08:05 --> Helper loaded: my_helper
INFO - 2020-12-22 02:08:05 --> Database Driver Class Initialized
DEBUG - 2020-12-22 02:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 02:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 02:08:05 --> Controller Class Initialized
DEBUG - 2020-12-22 02:08:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-22 02:08:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-22 02:08:05 --> Final output sent to browser
DEBUG - 2020-12-22 02:08:05 --> Total execution time: 0.4719
INFO - 2020-12-22 02:08:32 --> Config Class Initialized
INFO - 2020-12-22 02:08:32 --> Hooks Class Initialized
DEBUG - 2020-12-22 02:08:32 --> UTF-8 Support Enabled
INFO - 2020-12-22 02:08:32 --> Utf8 Class Initialized
INFO - 2020-12-22 02:08:32 --> URI Class Initialized
INFO - 2020-12-22 02:08:32 --> Router Class Initialized
INFO - 2020-12-22 02:08:32 --> Output Class Initialized
INFO - 2020-12-22 02:08:32 --> Security Class Initialized
DEBUG - 2020-12-22 02:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 02:08:32 --> Input Class Initialized
INFO - 2020-12-22 02:08:32 --> Language Class Initialized
INFO - 2020-12-22 02:08:32 --> Language Class Initialized
INFO - 2020-12-22 02:08:32 --> Config Class Initialized
INFO - 2020-12-22 02:08:32 --> Loader Class Initialized
INFO - 2020-12-22 02:08:32 --> Helper loaded: url_helper
INFO - 2020-12-22 02:08:32 --> Helper loaded: file_helper
INFO - 2020-12-22 02:08:33 --> Helper loaded: form_helper
INFO - 2020-12-22 02:08:33 --> Helper loaded: my_helper
INFO - 2020-12-22 02:08:33 --> Database Driver Class Initialized
DEBUG - 2020-12-22 02:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 02:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 02:08:33 --> Controller Class Initialized
INFO - 2020-12-22 02:08:33 --> Helper loaded: cookie_helper
INFO - 2020-12-22 02:08:33 --> Final output sent to browser
DEBUG - 2020-12-22 02:08:33 --> Total execution time: 0.6297
INFO - 2020-12-22 02:09:18 --> Config Class Initialized
INFO - 2020-12-22 02:09:18 --> Hooks Class Initialized
DEBUG - 2020-12-22 02:09:18 --> UTF-8 Support Enabled
INFO - 2020-12-22 02:09:18 --> Utf8 Class Initialized
INFO - 2020-12-22 02:09:18 --> URI Class Initialized
INFO - 2020-12-22 02:09:18 --> Router Class Initialized
INFO - 2020-12-22 02:09:18 --> Output Class Initialized
INFO - 2020-12-22 02:09:18 --> Security Class Initialized
DEBUG - 2020-12-22 02:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 02:09:18 --> Input Class Initialized
INFO - 2020-12-22 02:09:18 --> Language Class Initialized
INFO - 2020-12-22 02:09:18 --> Language Class Initialized
INFO - 2020-12-22 02:09:18 --> Config Class Initialized
INFO - 2020-12-22 02:09:18 --> Loader Class Initialized
INFO - 2020-12-22 02:09:18 --> Helper loaded: url_helper
INFO - 2020-12-22 02:09:18 --> Helper loaded: file_helper
INFO - 2020-12-22 02:09:18 --> Helper loaded: form_helper
INFO - 2020-12-22 02:09:18 --> Helper loaded: my_helper
INFO - 2020-12-22 02:09:18 --> Database Driver Class Initialized
DEBUG - 2020-12-22 02:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 02:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 02:09:19 --> Controller Class Initialized
DEBUG - 2020-12-22 02:09:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-22 02:09:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-22 02:09:19 --> Final output sent to browser
DEBUG - 2020-12-22 02:09:19 --> Total execution time: 0.5355
INFO - 2020-12-22 02:10:45 --> Config Class Initialized
INFO - 2020-12-22 02:10:45 --> Hooks Class Initialized
DEBUG - 2020-12-22 02:10:45 --> UTF-8 Support Enabled
INFO - 2020-12-22 02:10:45 --> Utf8 Class Initialized
INFO - 2020-12-22 02:10:45 --> URI Class Initialized
INFO - 2020-12-22 02:10:45 --> Router Class Initialized
INFO - 2020-12-22 02:10:46 --> Output Class Initialized
INFO - 2020-12-22 02:10:46 --> Security Class Initialized
DEBUG - 2020-12-22 02:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 02:10:46 --> Input Class Initialized
INFO - 2020-12-22 02:10:46 --> Language Class Initialized
INFO - 2020-12-22 02:10:46 --> Language Class Initialized
INFO - 2020-12-22 02:10:46 --> Config Class Initialized
INFO - 2020-12-22 02:10:46 --> Loader Class Initialized
INFO - 2020-12-22 02:10:46 --> Helper loaded: url_helper
INFO - 2020-12-22 02:10:46 --> Helper loaded: file_helper
INFO - 2020-12-22 02:10:46 --> Helper loaded: form_helper
INFO - 2020-12-22 02:10:46 --> Helper loaded: my_helper
INFO - 2020-12-22 02:10:46 --> Database Driver Class Initialized
DEBUG - 2020-12-22 02:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 02:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 02:10:46 --> Controller Class Initialized
ERROR - 2020-12-22 02:10:46 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-22 07:32:01 --> Config Class Initialized
INFO - 2020-12-22 07:32:01 --> Hooks Class Initialized
DEBUG - 2020-12-22 07:32:01 --> UTF-8 Support Enabled
INFO - 2020-12-22 07:32:01 --> Utf8 Class Initialized
INFO - 2020-12-22 07:32:01 --> URI Class Initialized
DEBUG - 2020-12-22 07:32:01 --> No URI present. Default controller set.
INFO - 2020-12-22 07:32:01 --> Router Class Initialized
INFO - 2020-12-22 07:32:01 --> Output Class Initialized
INFO - 2020-12-22 07:32:01 --> Security Class Initialized
DEBUG - 2020-12-22 07:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 07:32:02 --> Input Class Initialized
INFO - 2020-12-22 07:32:02 --> Language Class Initialized
INFO - 2020-12-22 07:32:02 --> Language Class Initialized
INFO - 2020-12-22 07:32:02 --> Config Class Initialized
INFO - 2020-12-22 07:32:02 --> Loader Class Initialized
INFO - 2020-12-22 07:32:02 --> Helper loaded: url_helper
INFO - 2020-12-22 07:32:02 --> Helper loaded: file_helper
INFO - 2020-12-22 07:32:02 --> Helper loaded: form_helper
INFO - 2020-12-22 07:32:02 --> Helper loaded: my_helper
INFO - 2020-12-22 07:32:02 --> Database Driver Class Initialized
DEBUG - 2020-12-22 07:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 07:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 07:32:02 --> Controller Class Initialized
INFO - 2020-12-22 07:32:02 --> Config Class Initialized
INFO - 2020-12-22 07:32:02 --> Hooks Class Initialized
DEBUG - 2020-12-22 07:32:02 --> UTF-8 Support Enabled
INFO - 2020-12-22 07:32:02 --> Utf8 Class Initialized
INFO - 2020-12-22 07:32:02 --> URI Class Initialized
INFO - 2020-12-22 07:32:02 --> Router Class Initialized
INFO - 2020-12-22 07:32:02 --> Output Class Initialized
INFO - 2020-12-22 07:32:02 --> Security Class Initialized
DEBUG - 2020-12-22 07:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 07:32:02 --> Input Class Initialized
INFO - 2020-12-22 07:32:02 --> Language Class Initialized
INFO - 2020-12-22 07:32:02 --> Language Class Initialized
INFO - 2020-12-22 07:32:02 --> Config Class Initialized
INFO - 2020-12-22 07:32:02 --> Loader Class Initialized
INFO - 2020-12-22 07:32:02 --> Helper loaded: url_helper
INFO - 2020-12-22 07:32:02 --> Helper loaded: file_helper
INFO - 2020-12-22 07:32:02 --> Helper loaded: form_helper
INFO - 2020-12-22 07:32:02 --> Helper loaded: my_helper
INFO - 2020-12-22 07:32:02 --> Database Driver Class Initialized
DEBUG - 2020-12-22 07:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 07:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 07:32:02 --> Controller Class Initialized
DEBUG - 2020-12-22 07:32:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-22 07:32:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-22 07:32:02 --> Final output sent to browser
DEBUG - 2020-12-22 07:32:02 --> Total execution time: 0.2736
INFO - 2020-12-22 07:32:07 --> Config Class Initialized
INFO - 2020-12-22 07:32:07 --> Hooks Class Initialized
DEBUG - 2020-12-22 07:32:07 --> UTF-8 Support Enabled
INFO - 2020-12-22 07:32:07 --> Utf8 Class Initialized
INFO - 2020-12-22 07:32:07 --> URI Class Initialized
INFO - 2020-12-22 07:32:07 --> Router Class Initialized
INFO - 2020-12-22 07:32:07 --> Output Class Initialized
INFO - 2020-12-22 07:32:07 --> Security Class Initialized
DEBUG - 2020-12-22 07:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 07:32:07 --> Input Class Initialized
INFO - 2020-12-22 07:32:07 --> Language Class Initialized
INFO - 2020-12-22 07:32:07 --> Language Class Initialized
INFO - 2020-12-22 07:32:07 --> Config Class Initialized
INFO - 2020-12-22 07:32:07 --> Loader Class Initialized
INFO - 2020-12-22 07:32:07 --> Helper loaded: url_helper
INFO - 2020-12-22 07:32:07 --> Helper loaded: file_helper
INFO - 2020-12-22 07:32:07 --> Helper loaded: form_helper
INFO - 2020-12-22 07:32:07 --> Helper loaded: my_helper
INFO - 2020-12-22 07:32:07 --> Database Driver Class Initialized
DEBUG - 2020-12-22 07:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 07:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 07:32:07 --> Controller Class Initialized
INFO - 2020-12-22 07:32:07 --> Helper loaded: cookie_helper
INFO - 2020-12-22 07:32:07 --> Final output sent to browser
DEBUG - 2020-12-22 07:32:07 --> Total execution time: 0.2679
INFO - 2020-12-22 07:32:09 --> Config Class Initialized
INFO - 2020-12-22 07:32:09 --> Hooks Class Initialized
DEBUG - 2020-12-22 07:32:09 --> UTF-8 Support Enabled
INFO - 2020-12-22 07:32:09 --> Utf8 Class Initialized
INFO - 2020-12-22 07:32:09 --> URI Class Initialized
INFO - 2020-12-22 07:32:09 --> Router Class Initialized
INFO - 2020-12-22 07:32:09 --> Output Class Initialized
INFO - 2020-12-22 07:32:09 --> Security Class Initialized
DEBUG - 2020-12-22 07:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 07:32:09 --> Input Class Initialized
INFO - 2020-12-22 07:32:09 --> Language Class Initialized
INFO - 2020-12-22 07:32:09 --> Language Class Initialized
INFO - 2020-12-22 07:32:09 --> Config Class Initialized
INFO - 2020-12-22 07:32:09 --> Loader Class Initialized
INFO - 2020-12-22 07:32:09 --> Helper loaded: url_helper
INFO - 2020-12-22 07:32:09 --> Helper loaded: file_helper
INFO - 2020-12-22 07:32:09 --> Helper loaded: form_helper
INFO - 2020-12-22 07:32:09 --> Helper loaded: my_helper
INFO - 2020-12-22 07:32:09 --> Database Driver Class Initialized
DEBUG - 2020-12-22 07:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 07:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 07:32:09 --> Controller Class Initialized
DEBUG - 2020-12-22 07:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-22 07:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-22 07:32:09 --> Final output sent to browser
DEBUG - 2020-12-22 07:32:09 --> Total execution time: 0.3331
INFO - 2020-12-22 07:38:30 --> Config Class Initialized
INFO - 2020-12-22 07:38:30 --> Hooks Class Initialized
DEBUG - 2020-12-22 07:38:30 --> UTF-8 Support Enabled
INFO - 2020-12-22 07:38:30 --> Utf8 Class Initialized
INFO - 2020-12-22 07:38:30 --> URI Class Initialized
INFO - 2020-12-22 07:38:30 --> Router Class Initialized
INFO - 2020-12-22 07:38:30 --> Output Class Initialized
INFO - 2020-12-22 07:38:30 --> Security Class Initialized
DEBUG - 2020-12-22 07:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-22 07:38:30 --> Input Class Initialized
INFO - 2020-12-22 07:38:30 --> Language Class Initialized
INFO - 2020-12-22 07:38:30 --> Language Class Initialized
INFO - 2020-12-22 07:38:30 --> Config Class Initialized
INFO - 2020-12-22 07:38:30 --> Loader Class Initialized
INFO - 2020-12-22 07:38:30 --> Helper loaded: url_helper
INFO - 2020-12-22 07:38:30 --> Helper loaded: file_helper
INFO - 2020-12-22 07:38:30 --> Helper loaded: form_helper
INFO - 2020-12-22 07:38:30 --> Helper loaded: my_helper
INFO - 2020-12-22 07:38:30 --> Database Driver Class Initialized
DEBUG - 2020-12-22 07:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-22 07:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-22 07:38:30 --> Controller Class Initialized
ERROR - 2020-12-22 07:38:30 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
