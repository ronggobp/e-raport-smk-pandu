<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-07 04:14:06 --> Config Class Initialized
INFO - 2022-06-07 04:14:06 --> Hooks Class Initialized
DEBUG - 2022-06-07 04:14:06 --> UTF-8 Support Enabled
INFO - 2022-06-07 04:14:06 --> Utf8 Class Initialized
INFO - 2022-06-07 04:14:06 --> URI Class Initialized
DEBUG - 2022-06-07 04:14:06 --> No URI present. Default controller set.
INFO - 2022-06-07 04:14:06 --> Router Class Initialized
INFO - 2022-06-07 04:14:06 --> Output Class Initialized
INFO - 2022-06-07 04:14:06 --> Security Class Initialized
DEBUG - 2022-06-07 04:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 04:14:06 --> Input Class Initialized
INFO - 2022-06-07 04:14:06 --> Language Class Initialized
INFO - 2022-06-07 04:14:06 --> Language Class Initialized
INFO - 2022-06-07 04:14:06 --> Config Class Initialized
INFO - 2022-06-07 04:14:06 --> Loader Class Initialized
INFO - 2022-06-07 04:14:06 --> Helper loaded: url_helper
INFO - 2022-06-07 04:14:06 --> Helper loaded: file_helper
INFO - 2022-06-07 04:14:06 --> Helper loaded: form_helper
INFO - 2022-06-07 04:14:06 --> Helper loaded: my_helper
INFO - 2022-06-07 04:14:06 --> Database Driver Class Initialized
DEBUG - 2022-06-07 04:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 04:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 04:14:06 --> Controller Class Initialized
INFO - 2022-06-07 04:14:06 --> Config Class Initialized
INFO - 2022-06-07 04:14:06 --> Hooks Class Initialized
DEBUG - 2022-06-07 04:14:06 --> UTF-8 Support Enabled
INFO - 2022-06-07 04:14:06 --> Utf8 Class Initialized
INFO - 2022-06-07 04:14:06 --> URI Class Initialized
INFO - 2022-06-07 04:14:06 --> Router Class Initialized
INFO - 2022-06-07 04:14:06 --> Output Class Initialized
INFO - 2022-06-07 04:14:06 --> Security Class Initialized
DEBUG - 2022-06-07 04:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 04:14:06 --> Input Class Initialized
INFO - 2022-06-07 04:14:06 --> Language Class Initialized
INFO - 2022-06-07 04:14:06 --> Language Class Initialized
INFO - 2022-06-07 04:14:06 --> Config Class Initialized
INFO - 2022-06-07 04:14:06 --> Loader Class Initialized
INFO - 2022-06-07 04:14:06 --> Helper loaded: url_helper
INFO - 2022-06-07 04:14:06 --> Helper loaded: file_helper
INFO - 2022-06-07 04:14:06 --> Helper loaded: form_helper
INFO - 2022-06-07 04:14:06 --> Helper loaded: my_helper
INFO - 2022-06-07 04:14:06 --> Database Driver Class Initialized
DEBUG - 2022-06-07 04:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 04:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 04:14:06 --> Controller Class Initialized
DEBUG - 2022-06-07 04:14:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-07 04:14:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-07 04:14:06 --> Final output sent to browser
DEBUG - 2022-06-07 04:14:06 --> Total execution time: 0.1376
INFO - 2022-06-07 04:14:11 --> Config Class Initialized
INFO - 2022-06-07 04:14:11 --> Hooks Class Initialized
DEBUG - 2022-06-07 04:14:11 --> UTF-8 Support Enabled
INFO - 2022-06-07 04:14:11 --> Utf8 Class Initialized
INFO - 2022-06-07 04:14:11 --> URI Class Initialized
INFO - 2022-06-07 04:14:11 --> Router Class Initialized
INFO - 2022-06-07 04:14:11 --> Output Class Initialized
INFO - 2022-06-07 04:14:11 --> Security Class Initialized
DEBUG - 2022-06-07 04:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 04:14:11 --> Input Class Initialized
INFO - 2022-06-07 04:14:11 --> Language Class Initialized
INFO - 2022-06-07 04:14:11 --> Language Class Initialized
INFO - 2022-06-07 04:14:11 --> Config Class Initialized
INFO - 2022-06-07 04:14:11 --> Loader Class Initialized
INFO - 2022-06-07 04:14:11 --> Helper loaded: url_helper
INFO - 2022-06-07 04:14:11 --> Helper loaded: file_helper
INFO - 2022-06-07 04:14:11 --> Helper loaded: form_helper
INFO - 2022-06-07 04:14:11 --> Helper loaded: my_helper
INFO - 2022-06-07 04:14:11 --> Database Driver Class Initialized
DEBUG - 2022-06-07 04:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 04:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 04:14:11 --> Controller Class Initialized
INFO - 2022-06-07 04:14:11 --> Helper loaded: cookie_helper
INFO - 2022-06-07 04:14:11 --> Final output sent to browser
DEBUG - 2022-06-07 04:14:11 --> Total execution time: 0.1149
INFO - 2022-06-07 04:14:12 --> Config Class Initialized
INFO - 2022-06-07 04:14:12 --> Hooks Class Initialized
DEBUG - 2022-06-07 04:14:12 --> UTF-8 Support Enabled
INFO - 2022-06-07 04:14:12 --> Utf8 Class Initialized
INFO - 2022-06-07 04:14:12 --> URI Class Initialized
INFO - 2022-06-07 04:14:12 --> Router Class Initialized
INFO - 2022-06-07 04:14:12 --> Output Class Initialized
INFO - 2022-06-07 04:14:12 --> Security Class Initialized
DEBUG - 2022-06-07 04:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 04:14:12 --> Input Class Initialized
INFO - 2022-06-07 04:14:12 --> Language Class Initialized
INFO - 2022-06-07 04:14:12 --> Language Class Initialized
INFO - 2022-06-07 04:14:12 --> Config Class Initialized
INFO - 2022-06-07 04:14:12 --> Loader Class Initialized
INFO - 2022-06-07 04:14:12 --> Helper loaded: url_helper
INFO - 2022-06-07 04:14:12 --> Helper loaded: file_helper
INFO - 2022-06-07 04:14:12 --> Helper loaded: form_helper
INFO - 2022-06-07 04:14:12 --> Helper loaded: my_helper
INFO - 2022-06-07 04:14:12 --> Database Driver Class Initialized
DEBUG - 2022-06-07 04:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 04:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 04:14:12 --> Controller Class Initialized
DEBUG - 2022-06-07 04:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-07 04:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-07 04:14:12 --> Final output sent to browser
DEBUG - 2022-06-07 04:14:12 --> Total execution time: 0.2178
INFO - 2022-06-07 04:34:28 --> Config Class Initialized
INFO - 2022-06-07 04:34:28 --> Hooks Class Initialized
DEBUG - 2022-06-07 04:34:28 --> UTF-8 Support Enabled
INFO - 2022-06-07 04:34:28 --> Utf8 Class Initialized
INFO - 2022-06-07 04:34:28 --> URI Class Initialized
INFO - 2022-06-07 04:34:28 --> Router Class Initialized
INFO - 2022-06-07 04:34:28 --> Output Class Initialized
INFO - 2022-06-07 04:34:28 --> Security Class Initialized
DEBUG - 2022-06-07 04:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 04:34:28 --> Input Class Initialized
INFO - 2022-06-07 04:34:28 --> Language Class Initialized
INFO - 2022-06-07 04:34:28 --> Language Class Initialized
INFO - 2022-06-07 04:34:28 --> Config Class Initialized
INFO - 2022-06-07 04:34:28 --> Loader Class Initialized
INFO - 2022-06-07 04:34:28 --> Helper loaded: url_helper
INFO - 2022-06-07 04:34:28 --> Helper loaded: file_helper
INFO - 2022-06-07 04:34:28 --> Helper loaded: form_helper
INFO - 2022-06-07 04:34:28 --> Helper loaded: my_helper
INFO - 2022-06-07 04:34:28 --> Database Driver Class Initialized
DEBUG - 2022-06-07 04:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 04:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 04:34:29 --> Controller Class Initialized
DEBUG - 2022-06-07 04:34:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-07 04:34:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-07 04:34:29 --> Final output sent to browser
DEBUG - 2022-06-07 04:34:29 --> Total execution time: 0.1299
INFO - 2022-06-07 04:37:29 --> Config Class Initialized
INFO - 2022-06-07 04:37:29 --> Hooks Class Initialized
DEBUG - 2022-06-07 04:37:29 --> UTF-8 Support Enabled
INFO - 2022-06-07 04:37:29 --> Utf8 Class Initialized
INFO - 2022-06-07 04:37:29 --> URI Class Initialized
INFO - 2022-06-07 04:37:29 --> Router Class Initialized
INFO - 2022-06-07 04:37:29 --> Output Class Initialized
INFO - 2022-06-07 04:37:29 --> Security Class Initialized
DEBUG - 2022-06-07 04:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 04:37:29 --> Input Class Initialized
INFO - 2022-06-07 04:37:29 --> Language Class Initialized
INFO - 2022-06-07 04:37:29 --> Language Class Initialized
INFO - 2022-06-07 04:37:29 --> Config Class Initialized
INFO - 2022-06-07 04:37:29 --> Loader Class Initialized
INFO - 2022-06-07 04:37:29 --> Helper loaded: url_helper
INFO - 2022-06-07 04:37:29 --> Helper loaded: file_helper
INFO - 2022-06-07 04:37:29 --> Helper loaded: form_helper
INFO - 2022-06-07 04:37:29 --> Helper loaded: my_helper
INFO - 2022-06-07 04:37:29 --> Database Driver Class Initialized
DEBUG - 2022-06-07 04:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 04:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 04:37:29 --> Controller Class Initialized
DEBUG - 2022-06-07 04:37:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-07 04:37:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-07 04:37:29 --> Final output sent to browser
DEBUG - 2022-06-07 04:37:29 --> Total execution time: 0.1558
INFO - 2022-06-07 04:37:30 --> Config Class Initialized
INFO - 2022-06-07 04:37:30 --> Hooks Class Initialized
DEBUG - 2022-06-07 04:37:30 --> UTF-8 Support Enabled
INFO - 2022-06-07 04:37:30 --> Utf8 Class Initialized
INFO - 2022-06-07 04:37:30 --> URI Class Initialized
INFO - 2022-06-07 04:37:30 --> Router Class Initialized
INFO - 2022-06-07 04:37:30 --> Output Class Initialized
INFO - 2022-06-07 04:37:30 --> Security Class Initialized
DEBUG - 2022-06-07 04:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 04:37:30 --> Input Class Initialized
INFO - 2022-06-07 04:37:30 --> Language Class Initialized
INFO - 2022-06-07 04:37:30 --> Language Class Initialized
INFO - 2022-06-07 04:37:30 --> Config Class Initialized
INFO - 2022-06-07 04:37:30 --> Loader Class Initialized
INFO - 2022-06-07 04:37:30 --> Helper loaded: url_helper
INFO - 2022-06-07 04:37:30 --> Helper loaded: file_helper
INFO - 2022-06-07 04:37:30 --> Helper loaded: form_helper
INFO - 2022-06-07 04:37:30 --> Helper loaded: my_helper
INFO - 2022-06-07 04:37:31 --> Database Driver Class Initialized
DEBUG - 2022-06-07 04:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 04:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 04:37:31 --> Controller Class Initialized
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 04:37:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-07 04:37:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 04:37:31 --> Final output sent to browser
DEBUG - 2022-06-07 04:37:31 --> Total execution time: 0.2946
INFO - 2022-06-07 05:30:10 --> Config Class Initialized
INFO - 2022-06-07 05:30:10 --> Hooks Class Initialized
DEBUG - 2022-06-07 05:30:10 --> UTF-8 Support Enabled
INFO - 2022-06-07 05:30:10 --> Utf8 Class Initialized
INFO - 2022-06-07 05:30:10 --> URI Class Initialized
INFO - 2022-06-07 05:30:10 --> Router Class Initialized
INFO - 2022-06-07 05:30:10 --> Output Class Initialized
INFO - 2022-06-07 05:30:10 --> Security Class Initialized
DEBUG - 2022-06-07 05:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 05:30:10 --> Input Class Initialized
INFO - 2022-06-07 05:30:10 --> Language Class Initialized
INFO - 2022-06-07 05:30:10 --> Language Class Initialized
INFO - 2022-06-07 05:30:10 --> Config Class Initialized
INFO - 2022-06-07 05:30:10 --> Loader Class Initialized
INFO - 2022-06-07 05:30:10 --> Helper loaded: url_helper
INFO - 2022-06-07 05:30:10 --> Helper loaded: file_helper
INFO - 2022-06-07 05:30:10 --> Helper loaded: form_helper
INFO - 2022-06-07 05:30:10 --> Helper loaded: my_helper
INFO - 2022-06-07 05:30:10 --> Database Driver Class Initialized
DEBUG - 2022-06-07 05:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 05:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 05:30:10 --> Controller Class Initialized
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 05:30:10 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-07 05:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 05:30:10 --> Final output sent to browser
DEBUG - 2022-06-07 05:30:10 --> Total execution time: 0.0923
INFO - 2022-06-07 05:30:11 --> Config Class Initialized
INFO - 2022-06-07 05:30:11 --> Hooks Class Initialized
DEBUG - 2022-06-07 05:30:11 --> UTF-8 Support Enabled
INFO - 2022-06-07 05:30:11 --> Utf8 Class Initialized
INFO - 2022-06-07 05:30:11 --> URI Class Initialized
INFO - 2022-06-07 05:30:11 --> Router Class Initialized
INFO - 2022-06-07 05:30:11 --> Output Class Initialized
INFO - 2022-06-07 05:30:11 --> Security Class Initialized
DEBUG - 2022-06-07 05:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 05:30:11 --> Input Class Initialized
INFO - 2022-06-07 05:30:11 --> Language Class Initialized
INFO - 2022-06-07 05:30:11 --> Language Class Initialized
INFO - 2022-06-07 05:30:11 --> Config Class Initialized
INFO - 2022-06-07 05:30:11 --> Loader Class Initialized
INFO - 2022-06-07 05:30:11 --> Helper loaded: url_helper
INFO - 2022-06-07 05:30:11 --> Helper loaded: file_helper
INFO - 2022-06-07 05:30:11 --> Helper loaded: form_helper
INFO - 2022-06-07 05:30:11 --> Helper loaded: my_helper
INFO - 2022-06-07 05:30:11 --> Database Driver Class Initialized
DEBUG - 2022-06-07 05:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 05:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 05:30:11 --> Controller Class Initialized
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 05:30:11 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-07 05:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 05:30:11 --> Final output sent to browser
DEBUG - 2022-06-07 05:30:11 --> Total execution time: 0.0921
INFO - 2022-06-07 06:24:43 --> Config Class Initialized
INFO - 2022-06-07 06:24:43 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:24:43 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:24:43 --> Utf8 Class Initialized
INFO - 2022-06-07 06:24:43 --> URI Class Initialized
INFO - 2022-06-07 06:24:43 --> Router Class Initialized
INFO - 2022-06-07 06:24:43 --> Output Class Initialized
INFO - 2022-06-07 06:24:43 --> Security Class Initialized
DEBUG - 2022-06-07 06:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:24:43 --> Input Class Initialized
INFO - 2022-06-07 06:24:43 --> Language Class Initialized
INFO - 2022-06-07 06:24:43 --> Language Class Initialized
INFO - 2022-06-07 06:24:43 --> Config Class Initialized
INFO - 2022-06-07 06:24:43 --> Loader Class Initialized
INFO - 2022-06-07 06:24:43 --> Helper loaded: url_helper
INFO - 2022-06-07 06:24:43 --> Helper loaded: file_helper
INFO - 2022-06-07 06:24:43 --> Helper loaded: form_helper
INFO - 2022-06-07 06:24:43 --> Helper loaded: my_helper
INFO - 2022-06-07 06:24:43 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:24:43 --> Controller Class Initialized
ERROR - 2022-06-07 06:24:43 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:26:00 --> Config Class Initialized
INFO - 2022-06-07 06:26:00 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:26:00 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:26:00 --> Utf8 Class Initialized
INFO - 2022-06-07 06:26:00 --> URI Class Initialized
INFO - 2022-06-07 06:26:00 --> Router Class Initialized
INFO - 2022-06-07 06:26:00 --> Output Class Initialized
INFO - 2022-06-07 06:26:00 --> Security Class Initialized
DEBUG - 2022-06-07 06:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:26:00 --> Input Class Initialized
INFO - 2022-06-07 06:26:00 --> Language Class Initialized
INFO - 2022-06-07 06:26:00 --> Language Class Initialized
INFO - 2022-06-07 06:26:00 --> Config Class Initialized
INFO - 2022-06-07 06:26:00 --> Loader Class Initialized
INFO - 2022-06-07 06:26:00 --> Helper loaded: url_helper
INFO - 2022-06-07 06:26:00 --> Helper loaded: file_helper
INFO - 2022-06-07 06:26:00 --> Helper loaded: form_helper
INFO - 2022-06-07 06:26:00 --> Helper loaded: my_helper
INFO - 2022-06-07 06:26:00 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:26:00 --> Controller Class Initialized
ERROR - 2022-06-07 06:26:00 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:26:01 --> Config Class Initialized
INFO - 2022-06-07 06:26:01 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:26:01 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:26:01 --> Utf8 Class Initialized
INFO - 2022-06-07 06:26:01 --> URI Class Initialized
INFO - 2022-06-07 06:26:01 --> Router Class Initialized
INFO - 2022-06-07 06:26:01 --> Output Class Initialized
INFO - 2022-06-07 06:26:01 --> Security Class Initialized
DEBUG - 2022-06-07 06:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:26:01 --> Input Class Initialized
INFO - 2022-06-07 06:26:01 --> Language Class Initialized
INFO - 2022-06-07 06:26:01 --> Language Class Initialized
INFO - 2022-06-07 06:26:01 --> Config Class Initialized
INFO - 2022-06-07 06:26:01 --> Loader Class Initialized
INFO - 2022-06-07 06:26:01 --> Helper loaded: url_helper
INFO - 2022-06-07 06:26:01 --> Helper loaded: file_helper
INFO - 2022-06-07 06:26:01 --> Helper loaded: form_helper
INFO - 2022-06-07 06:26:01 --> Helper loaded: my_helper
INFO - 2022-06-07 06:26:01 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:26:01 --> Controller Class Initialized
ERROR - 2022-06-07 06:26:01 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:26:01 --> Config Class Initialized
INFO - 2022-06-07 06:26:01 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:26:01 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:26:01 --> Utf8 Class Initialized
INFO - 2022-06-07 06:26:01 --> URI Class Initialized
INFO - 2022-06-07 06:26:01 --> Router Class Initialized
INFO - 2022-06-07 06:26:01 --> Output Class Initialized
INFO - 2022-06-07 06:26:01 --> Security Class Initialized
DEBUG - 2022-06-07 06:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:26:01 --> Input Class Initialized
INFO - 2022-06-07 06:26:01 --> Language Class Initialized
INFO - 2022-06-07 06:26:01 --> Language Class Initialized
INFO - 2022-06-07 06:26:01 --> Config Class Initialized
INFO - 2022-06-07 06:26:01 --> Loader Class Initialized
INFO - 2022-06-07 06:26:01 --> Helper loaded: url_helper
INFO - 2022-06-07 06:26:01 --> Helper loaded: file_helper
INFO - 2022-06-07 06:26:01 --> Helper loaded: form_helper
INFO - 2022-06-07 06:26:01 --> Helper loaded: my_helper
INFO - 2022-06-07 06:26:01 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:26:01 --> Controller Class Initialized
ERROR - 2022-06-07 06:26:01 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:26:42 --> Config Class Initialized
INFO - 2022-06-07 06:26:42 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:26:42 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:26:42 --> Utf8 Class Initialized
INFO - 2022-06-07 06:26:42 --> URI Class Initialized
INFO - 2022-06-07 06:26:42 --> Router Class Initialized
INFO - 2022-06-07 06:26:42 --> Output Class Initialized
INFO - 2022-06-07 06:26:42 --> Security Class Initialized
DEBUG - 2022-06-07 06:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:26:42 --> Input Class Initialized
INFO - 2022-06-07 06:26:42 --> Language Class Initialized
INFO - 2022-06-07 06:26:42 --> Language Class Initialized
INFO - 2022-06-07 06:26:42 --> Config Class Initialized
INFO - 2022-06-07 06:26:42 --> Loader Class Initialized
INFO - 2022-06-07 06:26:42 --> Helper loaded: url_helper
INFO - 2022-06-07 06:26:42 --> Helper loaded: file_helper
INFO - 2022-06-07 06:26:42 --> Helper loaded: form_helper
INFO - 2022-06-07 06:26:42 --> Helper loaded: my_helper
INFO - 2022-06-07 06:26:42 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:26:42 --> Controller Class Initialized
ERROR - 2022-06-07 06:26:42 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:26:47 --> Config Class Initialized
INFO - 2022-06-07 06:26:47 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:26:47 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:26:47 --> Utf8 Class Initialized
INFO - 2022-06-07 06:26:47 --> URI Class Initialized
INFO - 2022-06-07 06:26:47 --> Router Class Initialized
INFO - 2022-06-07 06:26:47 --> Output Class Initialized
INFO - 2022-06-07 06:26:47 --> Security Class Initialized
DEBUG - 2022-06-07 06:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:26:47 --> Input Class Initialized
INFO - 2022-06-07 06:26:47 --> Language Class Initialized
INFO - 2022-06-07 06:26:47 --> Language Class Initialized
INFO - 2022-06-07 06:26:47 --> Config Class Initialized
INFO - 2022-06-07 06:26:47 --> Loader Class Initialized
INFO - 2022-06-07 06:26:47 --> Helper loaded: url_helper
INFO - 2022-06-07 06:26:47 --> Helper loaded: file_helper
INFO - 2022-06-07 06:26:47 --> Helper loaded: form_helper
INFO - 2022-06-07 06:26:47 --> Helper loaded: my_helper
INFO - 2022-06-07 06:26:47 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:26:47 --> Controller Class Initialized
ERROR - 2022-06-07 06:26:47 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:26:57 --> Config Class Initialized
INFO - 2022-06-07 06:26:57 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:26:57 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:26:57 --> Utf8 Class Initialized
INFO - 2022-06-07 06:26:57 --> URI Class Initialized
INFO - 2022-06-07 06:26:57 --> Router Class Initialized
INFO - 2022-06-07 06:26:57 --> Output Class Initialized
INFO - 2022-06-07 06:26:57 --> Security Class Initialized
DEBUG - 2022-06-07 06:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:26:57 --> Input Class Initialized
INFO - 2022-06-07 06:26:57 --> Language Class Initialized
INFO - 2022-06-07 06:26:57 --> Language Class Initialized
INFO - 2022-06-07 06:26:57 --> Config Class Initialized
INFO - 2022-06-07 06:26:57 --> Loader Class Initialized
INFO - 2022-06-07 06:26:57 --> Helper loaded: url_helper
INFO - 2022-06-07 06:26:57 --> Helper loaded: file_helper
INFO - 2022-06-07 06:26:57 --> Helper loaded: form_helper
INFO - 2022-06-07 06:26:57 --> Helper loaded: my_helper
INFO - 2022-06-07 06:26:57 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:26:57 --> Controller Class Initialized
ERROR - 2022-06-07 06:26:57 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 171
INFO - 2022-06-07 06:27:04 --> Config Class Initialized
INFO - 2022-06-07 06:27:04 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:27:04 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:27:04 --> Utf8 Class Initialized
INFO - 2022-06-07 06:27:04 --> URI Class Initialized
INFO - 2022-06-07 06:27:04 --> Router Class Initialized
INFO - 2022-06-07 06:27:04 --> Output Class Initialized
INFO - 2022-06-07 06:27:04 --> Security Class Initialized
DEBUG - 2022-06-07 06:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:27:04 --> Input Class Initialized
INFO - 2022-06-07 06:27:04 --> Language Class Initialized
INFO - 2022-06-07 06:27:04 --> Language Class Initialized
INFO - 2022-06-07 06:27:04 --> Config Class Initialized
INFO - 2022-06-07 06:27:04 --> Loader Class Initialized
INFO - 2022-06-07 06:27:04 --> Helper loaded: url_helper
INFO - 2022-06-07 06:27:04 --> Helper loaded: file_helper
INFO - 2022-06-07 06:27:04 --> Helper loaded: form_helper
INFO - 2022-06-07 06:27:04 --> Helper loaded: my_helper
INFO - 2022-06-07 06:27:04 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:27:04 --> Controller Class Initialized
ERROR - 2022-06-07 06:27:04 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:27:14 --> Config Class Initialized
INFO - 2022-06-07 06:27:14 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:27:14 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:27:14 --> Utf8 Class Initialized
INFO - 2022-06-07 06:27:14 --> URI Class Initialized
INFO - 2022-06-07 06:27:14 --> Router Class Initialized
INFO - 2022-06-07 06:27:14 --> Output Class Initialized
INFO - 2022-06-07 06:27:14 --> Security Class Initialized
DEBUG - 2022-06-07 06:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:27:14 --> Input Class Initialized
INFO - 2022-06-07 06:27:14 --> Language Class Initialized
INFO - 2022-06-07 06:27:14 --> Language Class Initialized
INFO - 2022-06-07 06:27:14 --> Config Class Initialized
INFO - 2022-06-07 06:27:14 --> Loader Class Initialized
INFO - 2022-06-07 06:27:14 --> Helper loaded: url_helper
INFO - 2022-06-07 06:27:14 --> Helper loaded: file_helper
INFO - 2022-06-07 06:27:14 --> Helper loaded: form_helper
INFO - 2022-06-07 06:27:14 --> Helper loaded: my_helper
INFO - 2022-06-07 06:27:14 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:27:14 --> Controller Class Initialized
ERROR - 2022-06-07 06:27:14 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:27:29 --> Config Class Initialized
INFO - 2022-06-07 06:27:29 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:27:29 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:27:29 --> Utf8 Class Initialized
INFO - 2022-06-07 06:27:29 --> URI Class Initialized
INFO - 2022-06-07 06:27:29 --> Router Class Initialized
INFO - 2022-06-07 06:27:29 --> Output Class Initialized
INFO - 2022-06-07 06:27:29 --> Security Class Initialized
DEBUG - 2022-06-07 06:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:27:29 --> Input Class Initialized
INFO - 2022-06-07 06:27:29 --> Language Class Initialized
INFO - 2022-06-07 06:27:29 --> Language Class Initialized
INFO - 2022-06-07 06:27:29 --> Config Class Initialized
INFO - 2022-06-07 06:27:29 --> Loader Class Initialized
INFO - 2022-06-07 06:27:29 --> Helper loaded: url_helper
INFO - 2022-06-07 06:27:29 --> Helper loaded: file_helper
INFO - 2022-06-07 06:27:29 --> Helper loaded: form_helper
INFO - 2022-06-07 06:27:29 --> Helper loaded: my_helper
INFO - 2022-06-07 06:27:29 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:27:29 --> Controller Class Initialized
ERROR - 2022-06-07 06:27:29 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:27:46 --> Config Class Initialized
INFO - 2022-06-07 06:27:46 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:27:46 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:27:46 --> Utf8 Class Initialized
INFO - 2022-06-07 06:27:46 --> URI Class Initialized
INFO - 2022-06-07 06:27:46 --> Router Class Initialized
INFO - 2022-06-07 06:27:46 --> Output Class Initialized
INFO - 2022-06-07 06:27:46 --> Security Class Initialized
DEBUG - 2022-06-07 06:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:27:46 --> Input Class Initialized
INFO - 2022-06-07 06:27:46 --> Language Class Initialized
INFO - 2022-06-07 06:27:46 --> Language Class Initialized
INFO - 2022-06-07 06:27:46 --> Config Class Initialized
INFO - 2022-06-07 06:27:46 --> Loader Class Initialized
INFO - 2022-06-07 06:27:46 --> Helper loaded: url_helper
INFO - 2022-06-07 06:27:46 --> Helper loaded: file_helper
INFO - 2022-06-07 06:27:46 --> Helper loaded: form_helper
INFO - 2022-06-07 06:27:46 --> Helper loaded: my_helper
INFO - 2022-06-07 06:27:46 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:27:46 --> Controller Class Initialized
ERROR - 2022-06-07 06:27:46 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:28:04 --> Config Class Initialized
INFO - 2022-06-07 06:28:04 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:28:04 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:28:04 --> Utf8 Class Initialized
INFO - 2022-06-07 06:28:04 --> URI Class Initialized
INFO - 2022-06-07 06:28:04 --> Router Class Initialized
INFO - 2022-06-07 06:28:04 --> Output Class Initialized
INFO - 2022-06-07 06:28:04 --> Security Class Initialized
DEBUG - 2022-06-07 06:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:28:04 --> Input Class Initialized
INFO - 2022-06-07 06:28:04 --> Language Class Initialized
INFO - 2022-06-07 06:28:04 --> Language Class Initialized
INFO - 2022-06-07 06:28:04 --> Config Class Initialized
INFO - 2022-06-07 06:28:04 --> Loader Class Initialized
INFO - 2022-06-07 06:28:04 --> Helper loaded: url_helper
INFO - 2022-06-07 06:28:04 --> Helper loaded: file_helper
INFO - 2022-06-07 06:28:04 --> Helper loaded: form_helper
INFO - 2022-06-07 06:28:04 --> Helper loaded: my_helper
INFO - 2022-06-07 06:28:04 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:28:04 --> Controller Class Initialized
ERROR - 2022-06-07 06:28:04 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 170
INFO - 2022-06-07 06:28:18 --> Config Class Initialized
INFO - 2022-06-07 06:28:18 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:28:18 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:28:18 --> Utf8 Class Initialized
INFO - 2022-06-07 06:28:18 --> URI Class Initialized
INFO - 2022-06-07 06:28:18 --> Router Class Initialized
INFO - 2022-06-07 06:28:18 --> Output Class Initialized
INFO - 2022-06-07 06:28:18 --> Security Class Initialized
DEBUG - 2022-06-07 06:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:28:18 --> Input Class Initialized
INFO - 2022-06-07 06:28:18 --> Language Class Initialized
INFO - 2022-06-07 06:28:18 --> Language Class Initialized
INFO - 2022-06-07 06:28:18 --> Config Class Initialized
INFO - 2022-06-07 06:28:18 --> Loader Class Initialized
INFO - 2022-06-07 06:28:18 --> Helper loaded: url_helper
INFO - 2022-06-07 06:28:18 --> Helper loaded: file_helper
INFO - 2022-06-07 06:28:18 --> Helper loaded: form_helper
INFO - 2022-06-07 06:28:18 --> Helper loaded: my_helper
INFO - 2022-06-07 06:28:18 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:28:18 --> Controller Class Initialized
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:28:18 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
DEBUG - 2022-06-07 06:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 06:28:18 --> Final output sent to browser
DEBUG - 2022-06-07 06:28:18 --> Total execution time: 0.0922
INFO - 2022-06-07 06:40:01 --> Config Class Initialized
INFO - 2022-06-07 06:40:01 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:40:01 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:40:01 --> Utf8 Class Initialized
INFO - 2022-06-07 06:40:01 --> URI Class Initialized
INFO - 2022-06-07 06:40:01 --> Router Class Initialized
INFO - 2022-06-07 06:40:01 --> Output Class Initialized
INFO - 2022-06-07 06:40:01 --> Security Class Initialized
DEBUG - 2022-06-07 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:40:01 --> Input Class Initialized
INFO - 2022-06-07 06:40:01 --> Language Class Initialized
INFO - 2022-06-07 06:40:01 --> Language Class Initialized
INFO - 2022-06-07 06:40:01 --> Config Class Initialized
INFO - 2022-06-07 06:40:01 --> Loader Class Initialized
INFO - 2022-06-07 06:40:01 --> Helper loaded: url_helper
INFO - 2022-06-07 06:40:01 --> Helper loaded: file_helper
INFO - 2022-06-07 06:40:01 --> Helper loaded: form_helper
INFO - 2022-06-07 06:40:01 --> Helper loaded: my_helper
INFO - 2022-06-07 06:40:01 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:40:01 --> Controller Class Initialized
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:40:01 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
DEBUG - 2022-06-07 06:40:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 06:40:01 --> Final output sent to browser
DEBUG - 2022-06-07 06:40:01 --> Total execution time: 0.0918
INFO - 2022-06-07 06:40:22 --> Config Class Initialized
INFO - 2022-06-07 06:40:22 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:40:22 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:40:22 --> Utf8 Class Initialized
INFO - 2022-06-07 06:40:22 --> URI Class Initialized
INFO - 2022-06-07 06:40:22 --> Router Class Initialized
INFO - 2022-06-07 06:40:22 --> Output Class Initialized
INFO - 2022-06-07 06:40:22 --> Security Class Initialized
DEBUG - 2022-06-07 06:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:40:22 --> Input Class Initialized
INFO - 2022-06-07 06:40:22 --> Language Class Initialized
INFO - 2022-06-07 06:40:22 --> Language Class Initialized
INFO - 2022-06-07 06:40:22 --> Config Class Initialized
INFO - 2022-06-07 06:40:22 --> Loader Class Initialized
INFO - 2022-06-07 06:40:22 --> Helper loaded: url_helper
INFO - 2022-06-07 06:40:22 --> Helper loaded: file_helper
INFO - 2022-06-07 06:40:22 --> Helper loaded: form_helper
INFO - 2022-06-07 06:40:22 --> Helper loaded: my_helper
INFO - 2022-06-07 06:40:22 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:40:22 --> Controller Class Initialized
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 163
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 165
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 167
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 175
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 177
ERROR - 2022-06-07 06:40:22 --> Severity: Notice --> Undefined variable: desk2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 175
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 177
ERROR - 2022-06-07 06:40:22 --> Severity: Notice --> Undefined variable: desk2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 163
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 165
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 167
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 175
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 177
ERROR - 2022-06-07 06:40:22 --> Severity: Notice --> Undefined variable: desk2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 175
ERROR - 2022-06-07 06:40:22 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 177
ERROR - 2022-06-07 06:40:22 --> Severity: Notice --> Undefined variable: desk2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
DEBUG - 2022-06-07 06:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 06:40:22 --> Final output sent to browser
DEBUG - 2022-06-07 06:40:22 --> Total execution time: 0.1025
INFO - 2022-06-07 06:46:33 --> Config Class Initialized
INFO - 2022-06-07 06:46:33 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:46:33 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:46:33 --> Utf8 Class Initialized
INFO - 2022-06-07 06:46:33 --> URI Class Initialized
INFO - 2022-06-07 06:46:33 --> Router Class Initialized
INFO - 2022-06-07 06:46:33 --> Output Class Initialized
INFO - 2022-06-07 06:46:33 --> Security Class Initialized
DEBUG - 2022-06-07 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:46:33 --> Input Class Initialized
INFO - 2022-06-07 06:46:33 --> Language Class Initialized
INFO - 2022-06-07 06:46:33 --> Language Class Initialized
INFO - 2022-06-07 06:46:33 --> Config Class Initialized
INFO - 2022-06-07 06:46:33 --> Loader Class Initialized
INFO - 2022-06-07 06:46:33 --> Helper loaded: url_helper
INFO - 2022-06-07 06:46:33 --> Helper loaded: file_helper
INFO - 2022-06-07 06:46:33 --> Helper loaded: form_helper
INFO - 2022-06-07 06:46:33 --> Helper loaded: my_helper
INFO - 2022-06-07 06:46:33 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:46:33 --> Controller Class Initialized
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 163
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 165
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 167
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 175
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 177
ERROR - 2022-06-07 06:46:33 --> Severity: Notice --> Undefined variable: desk2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 175
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 177
ERROR - 2022-06-07 06:46:33 --> Severity: Notice --> Undefined variable: desk2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 163
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 165
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 167
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 175
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 177
ERROR - 2022-06-07 06:46:33 --> Severity: Notice --> Undefined variable: desk2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 175
ERROR - 2022-06-07 06:46:33 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 177
ERROR - 2022-06-07 06:46:33 --> Severity: Notice --> Undefined variable: desk2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
DEBUG - 2022-06-07 06:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 06:46:33 --> Final output sent to browser
DEBUG - 2022-06-07 06:46:33 --> Total execution time: 0.0977
INFO - 2022-06-07 06:47:30 --> Config Class Initialized
INFO - 2022-06-07 06:47:30 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:47:30 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:47:30 --> Utf8 Class Initialized
INFO - 2022-06-07 06:47:30 --> URI Class Initialized
INFO - 2022-06-07 06:47:30 --> Router Class Initialized
INFO - 2022-06-07 06:47:30 --> Output Class Initialized
INFO - 2022-06-07 06:47:30 --> Security Class Initialized
DEBUG - 2022-06-07 06:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:47:30 --> Input Class Initialized
INFO - 2022-06-07 06:47:30 --> Language Class Initialized
INFO - 2022-06-07 06:47:30 --> Language Class Initialized
INFO - 2022-06-07 06:47:30 --> Config Class Initialized
INFO - 2022-06-07 06:47:30 --> Loader Class Initialized
INFO - 2022-06-07 06:47:30 --> Helper loaded: url_helper
INFO - 2022-06-07 06:47:30 --> Helper loaded: file_helper
INFO - 2022-06-07 06:47:30 --> Helper loaded: form_helper
INFO - 2022-06-07 06:47:30 --> Helper loaded: my_helper
INFO - 2022-06-07 06:47:30 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:47:30 --> Controller Class Initialized
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:47:30 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:47:30 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:47:30 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:47:30 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:47:30 --> Severity: Warning --> Illegal string offset 'ekstra2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
DEBUG - 2022-06-07 06:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 06:47:30 --> Final output sent to browser
DEBUG - 2022-06-07 06:47:30 --> Total execution time: 0.0900
INFO - 2022-06-07 06:47:48 --> Config Class Initialized
INFO - 2022-06-07 06:47:48 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:47:48 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:47:48 --> Utf8 Class Initialized
INFO - 2022-06-07 06:47:48 --> URI Class Initialized
INFO - 2022-06-07 06:47:48 --> Router Class Initialized
INFO - 2022-06-07 06:47:48 --> Output Class Initialized
INFO - 2022-06-07 06:47:48 --> Security Class Initialized
DEBUG - 2022-06-07 06:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:47:48 --> Input Class Initialized
INFO - 2022-06-07 06:47:48 --> Language Class Initialized
INFO - 2022-06-07 06:47:48 --> Language Class Initialized
INFO - 2022-06-07 06:47:48 --> Config Class Initialized
INFO - 2022-06-07 06:47:48 --> Loader Class Initialized
INFO - 2022-06-07 06:47:48 --> Helper loaded: url_helper
INFO - 2022-06-07 06:47:48 --> Helper loaded: file_helper
INFO - 2022-06-07 06:47:48 --> Helper loaded: form_helper
INFO - 2022-06-07 06:47:48 --> Helper loaded: my_helper
INFO - 2022-06-07 06:47:49 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:47:49 --> Controller Class Initialized
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:47:49 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:47:49 --> Severity: Notice --> Undefined variable: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:47:49 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:47:49 --> Severity: Notice --> Undefined variable: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:47:49 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:47:49 --> Severity: Notice --> Undefined variable: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:47:49 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:47:49 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:47:49 --> Severity: Notice --> Undefined variable: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
DEBUG - 2022-06-07 06:47:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 06:47:49 --> Final output sent to browser
DEBUG - 2022-06-07 06:47:49 --> Total execution time: 0.0916
INFO - 2022-06-07 06:48:50 --> Config Class Initialized
INFO - 2022-06-07 06:48:50 --> Hooks Class Initialized
DEBUG - 2022-06-07 06:48:50 --> UTF-8 Support Enabled
INFO - 2022-06-07 06:48:50 --> Utf8 Class Initialized
INFO - 2022-06-07 06:48:50 --> URI Class Initialized
INFO - 2022-06-07 06:48:50 --> Router Class Initialized
INFO - 2022-06-07 06:48:50 --> Output Class Initialized
INFO - 2022-06-07 06:48:50 --> Security Class Initialized
DEBUG - 2022-06-07 06:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 06:48:50 --> Input Class Initialized
INFO - 2022-06-07 06:48:50 --> Language Class Initialized
INFO - 2022-06-07 06:48:50 --> Language Class Initialized
INFO - 2022-06-07 06:48:50 --> Config Class Initialized
INFO - 2022-06-07 06:48:50 --> Loader Class Initialized
INFO - 2022-06-07 06:48:50 --> Helper loaded: url_helper
INFO - 2022-06-07 06:48:50 --> Helper loaded: file_helper
INFO - 2022-06-07 06:48:50 --> Helper loaded: form_helper
INFO - 2022-06-07 06:48:50 --> Helper loaded: my_helper
INFO - 2022-06-07 06:48:50 --> Database Driver Class Initialized
DEBUG - 2022-06-07 06:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-07 06:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 06:48:50 --> Controller Class Initialized
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:48:50 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:48:50 --> Severity: Notice --> Undefined variable: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-07 06:48:50 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:48:50 --> Severity: Notice --> Undefined variable: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 162
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 164
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 166
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai2' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 168
ERROR - 2022-06-07 06:48:50 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:48:50 --> Severity: Notice --> Undefined variable: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-07 06:48:50 --> Severity: Warning --> Illegal string offset 'ekstra' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-07 06:48:50 --> Severity: Notice --> Undefined variable: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 176
ERROR - 2022-06-07 06:48:50 --> Severity: Notice --> Undefined variable: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 178
DEBUG - 2022-06-07 06:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-07 06:48:50 --> Final output sent to browser
DEBUG - 2022-06-07 06:48:50 --> Total execution time: 0.0959
