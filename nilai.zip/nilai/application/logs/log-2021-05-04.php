<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-04 02:22:53 --> Config Class Initialized
INFO - 2021-05-04 02:22:53 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:22:53 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:22:53 --> Utf8 Class Initialized
INFO - 2021-05-04 02:22:53 --> URI Class Initialized
DEBUG - 2021-05-04 02:22:54 --> No URI present. Default controller set.
INFO - 2021-05-04 02:22:54 --> Router Class Initialized
INFO - 2021-05-04 02:22:54 --> Output Class Initialized
INFO - 2021-05-04 02:22:54 --> Security Class Initialized
DEBUG - 2021-05-04 02:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:22:54 --> Input Class Initialized
INFO - 2021-05-04 02:22:54 --> Language Class Initialized
INFO - 2021-05-04 02:22:54 --> Language Class Initialized
INFO - 2021-05-04 02:22:54 --> Config Class Initialized
INFO - 2021-05-04 02:22:54 --> Loader Class Initialized
INFO - 2021-05-04 02:22:54 --> Helper loaded: url_helper
INFO - 2021-05-04 02:22:54 --> Helper loaded: file_helper
INFO - 2021-05-04 02:22:54 --> Helper loaded: form_helper
INFO - 2021-05-04 02:22:54 --> Helper loaded: my_helper
INFO - 2021-05-04 02:22:54 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:22:55 --> Controller Class Initialized
INFO - 2021-05-04 02:22:55 --> Config Class Initialized
INFO - 2021-05-04 02:22:55 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:22:55 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:22:55 --> Utf8 Class Initialized
INFO - 2021-05-04 02:22:55 --> URI Class Initialized
INFO - 2021-05-04 02:22:55 --> Router Class Initialized
INFO - 2021-05-04 02:22:55 --> Output Class Initialized
INFO - 2021-05-04 02:22:55 --> Security Class Initialized
DEBUG - 2021-05-04 02:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:22:55 --> Input Class Initialized
INFO - 2021-05-04 02:22:55 --> Language Class Initialized
INFO - 2021-05-04 02:22:55 --> Language Class Initialized
INFO - 2021-05-04 02:22:55 --> Config Class Initialized
INFO - 2021-05-04 02:22:55 --> Loader Class Initialized
INFO - 2021-05-04 02:22:55 --> Helper loaded: url_helper
INFO - 2021-05-04 02:22:55 --> Helper loaded: file_helper
INFO - 2021-05-04 02:22:55 --> Helper loaded: form_helper
INFO - 2021-05-04 02:22:55 --> Helper loaded: my_helper
INFO - 2021-05-04 02:22:55 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:22:55 --> Controller Class Initialized
DEBUG - 2021-05-04 02:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 02:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:22:55 --> Final output sent to browser
DEBUG - 2021-05-04 02:22:55 --> Total execution time: 0.2605
INFO - 2021-05-04 02:23:47 --> Config Class Initialized
INFO - 2021-05-04 02:23:47 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:23:47 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:23:47 --> Utf8 Class Initialized
INFO - 2021-05-04 02:23:47 --> URI Class Initialized
INFO - 2021-05-04 02:23:47 --> Router Class Initialized
INFO - 2021-05-04 02:23:47 --> Output Class Initialized
INFO - 2021-05-04 02:23:47 --> Security Class Initialized
DEBUG - 2021-05-04 02:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:23:47 --> Input Class Initialized
INFO - 2021-05-04 02:23:47 --> Language Class Initialized
INFO - 2021-05-04 02:23:47 --> Language Class Initialized
INFO - 2021-05-04 02:23:47 --> Config Class Initialized
INFO - 2021-05-04 02:23:47 --> Loader Class Initialized
INFO - 2021-05-04 02:23:47 --> Helper loaded: url_helper
INFO - 2021-05-04 02:23:47 --> Helper loaded: file_helper
INFO - 2021-05-04 02:23:47 --> Helper loaded: form_helper
INFO - 2021-05-04 02:23:47 --> Helper loaded: my_helper
INFO - 2021-05-04 02:23:47 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:23:47 --> Controller Class Initialized
INFO - 2021-05-04 02:23:47 --> Helper loaded: cookie_helper
INFO - 2021-05-04 02:23:47 --> Final output sent to browser
DEBUG - 2021-05-04 02:23:47 --> Total execution time: 0.3584
INFO - 2021-05-04 02:23:48 --> Config Class Initialized
INFO - 2021-05-04 02:23:48 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:23:48 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:23:48 --> Utf8 Class Initialized
INFO - 2021-05-04 02:23:48 --> URI Class Initialized
INFO - 2021-05-04 02:23:48 --> Router Class Initialized
INFO - 2021-05-04 02:23:48 --> Output Class Initialized
INFO - 2021-05-04 02:23:48 --> Security Class Initialized
DEBUG - 2021-05-04 02:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:23:48 --> Input Class Initialized
INFO - 2021-05-04 02:23:48 --> Language Class Initialized
INFO - 2021-05-04 02:23:48 --> Language Class Initialized
INFO - 2021-05-04 02:23:48 --> Config Class Initialized
INFO - 2021-05-04 02:23:48 --> Loader Class Initialized
INFO - 2021-05-04 02:23:48 --> Helper loaded: url_helper
INFO - 2021-05-04 02:23:48 --> Helper loaded: file_helper
INFO - 2021-05-04 02:23:48 --> Helper loaded: form_helper
INFO - 2021-05-04 02:23:48 --> Helper loaded: my_helper
INFO - 2021-05-04 02:23:48 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:23:48 --> Controller Class Initialized
DEBUG - 2021-05-04 02:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 02:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:23:48 --> Final output sent to browser
DEBUG - 2021-05-04 02:23:48 --> Total execution time: 0.2574
INFO - 2021-05-04 02:23:50 --> Config Class Initialized
INFO - 2021-05-04 02:23:50 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:23:51 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:23:51 --> Utf8 Class Initialized
INFO - 2021-05-04 02:23:51 --> URI Class Initialized
INFO - 2021-05-04 02:23:51 --> Router Class Initialized
INFO - 2021-05-04 02:23:51 --> Output Class Initialized
INFO - 2021-05-04 02:23:51 --> Security Class Initialized
DEBUG - 2021-05-04 02:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:23:51 --> Input Class Initialized
INFO - 2021-05-04 02:23:51 --> Language Class Initialized
INFO - 2021-05-04 02:23:51 --> Language Class Initialized
INFO - 2021-05-04 02:23:51 --> Config Class Initialized
INFO - 2021-05-04 02:23:51 --> Loader Class Initialized
INFO - 2021-05-04 02:23:51 --> Helper loaded: url_helper
INFO - 2021-05-04 02:23:51 --> Helper loaded: file_helper
INFO - 2021-05-04 02:23:51 --> Helper loaded: form_helper
INFO - 2021-05-04 02:23:51 --> Helper loaded: my_helper
INFO - 2021-05-04 02:23:51 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:23:51 --> Controller Class Initialized
DEBUG - 2021-05-04 02:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 02:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:23:51 --> Final output sent to browser
DEBUG - 2021-05-04 02:23:51 --> Total execution time: 0.3611
INFO - 2021-05-04 02:23:53 --> Config Class Initialized
INFO - 2021-05-04 02:23:53 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:23:53 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:23:53 --> Utf8 Class Initialized
INFO - 2021-05-04 02:23:53 --> URI Class Initialized
INFO - 2021-05-04 02:23:53 --> Router Class Initialized
INFO - 2021-05-04 02:23:53 --> Output Class Initialized
INFO - 2021-05-04 02:23:53 --> Security Class Initialized
DEBUG - 2021-05-04 02:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:23:53 --> Input Class Initialized
INFO - 2021-05-04 02:23:53 --> Language Class Initialized
INFO - 2021-05-04 02:23:53 --> Language Class Initialized
INFO - 2021-05-04 02:23:53 --> Config Class Initialized
INFO - 2021-05-04 02:23:53 --> Loader Class Initialized
INFO - 2021-05-04 02:23:53 --> Helper loaded: url_helper
INFO - 2021-05-04 02:23:53 --> Helper loaded: file_helper
INFO - 2021-05-04 02:23:53 --> Helper loaded: form_helper
INFO - 2021-05-04 02:23:53 --> Helper loaded: my_helper
INFO - 2021-05-04 02:23:53 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:23:53 --> Controller Class Initialized
DEBUG - 2021-05-04 02:23:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-05-04 02:23:53 --> Final output sent to browser
DEBUG - 2021-05-04 02:23:53 --> Total execution time: 0.4347
INFO - 2021-05-04 02:25:17 --> Config Class Initialized
INFO - 2021-05-04 02:25:17 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:25:17 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:25:17 --> Utf8 Class Initialized
INFO - 2021-05-04 02:25:17 --> URI Class Initialized
DEBUG - 2021-05-04 02:25:17 --> No URI present. Default controller set.
INFO - 2021-05-04 02:25:17 --> Router Class Initialized
INFO - 2021-05-04 02:25:17 --> Output Class Initialized
INFO - 2021-05-04 02:25:17 --> Security Class Initialized
DEBUG - 2021-05-04 02:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:25:17 --> Input Class Initialized
INFO - 2021-05-04 02:25:17 --> Language Class Initialized
INFO - 2021-05-04 02:25:17 --> Language Class Initialized
INFO - 2021-05-04 02:25:17 --> Config Class Initialized
INFO - 2021-05-04 02:25:17 --> Loader Class Initialized
INFO - 2021-05-04 02:25:17 --> Helper loaded: url_helper
INFO - 2021-05-04 02:25:17 --> Helper loaded: file_helper
INFO - 2021-05-04 02:25:17 --> Helper loaded: form_helper
INFO - 2021-05-04 02:25:17 --> Helper loaded: my_helper
INFO - 2021-05-04 02:25:17 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:25:17 --> Controller Class Initialized
DEBUG - 2021-05-04 02:25:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 02:25:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:25:17 --> Final output sent to browser
DEBUG - 2021-05-04 02:25:17 --> Total execution time: 0.1574
INFO - 2021-05-04 02:25:53 --> Config Class Initialized
INFO - 2021-05-04 02:25:53 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:25:53 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:25:53 --> Utf8 Class Initialized
INFO - 2021-05-04 02:25:53 --> URI Class Initialized
INFO - 2021-05-04 02:25:53 --> Router Class Initialized
INFO - 2021-05-04 02:25:53 --> Output Class Initialized
INFO - 2021-05-04 02:25:53 --> Security Class Initialized
DEBUG - 2021-05-04 02:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:25:53 --> Input Class Initialized
INFO - 2021-05-04 02:25:53 --> Language Class Initialized
INFO - 2021-05-04 02:25:53 --> Language Class Initialized
INFO - 2021-05-04 02:25:53 --> Config Class Initialized
INFO - 2021-05-04 02:25:53 --> Loader Class Initialized
INFO - 2021-05-04 02:25:53 --> Helper loaded: url_helper
INFO - 2021-05-04 02:25:53 --> Helper loaded: file_helper
INFO - 2021-05-04 02:25:53 --> Helper loaded: form_helper
INFO - 2021-05-04 02:25:53 --> Helper loaded: my_helper
INFO - 2021-05-04 02:25:53 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:25:53 --> Controller Class Initialized
ERROR - 2021-05-04 02:25:53 --> Severity: Notice --> Use of undefined constant XII - assumed 'XII' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_mm_xii.php 339
DEBUG - 2021-05-04 02:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-05-04 02:25:53 --> Final output sent to browser
DEBUG - 2021-05-04 02:25:53 --> Total execution time: 0.2434
INFO - 2021-05-04 02:32:24 --> Config Class Initialized
INFO - 2021-05-04 02:32:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:32:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:32:24 --> Utf8 Class Initialized
INFO - 2021-05-04 02:32:24 --> URI Class Initialized
INFO - 2021-05-04 02:32:24 --> Router Class Initialized
INFO - 2021-05-04 02:32:24 --> Output Class Initialized
INFO - 2021-05-04 02:32:24 --> Security Class Initialized
DEBUG - 2021-05-04 02:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:32:24 --> Input Class Initialized
INFO - 2021-05-04 02:32:24 --> Language Class Initialized
INFO - 2021-05-04 02:32:24 --> Language Class Initialized
INFO - 2021-05-04 02:32:24 --> Config Class Initialized
INFO - 2021-05-04 02:32:24 --> Loader Class Initialized
INFO - 2021-05-04 02:32:24 --> Helper loaded: url_helper
INFO - 2021-05-04 02:32:24 --> Helper loaded: file_helper
INFO - 2021-05-04 02:32:24 --> Helper loaded: form_helper
INFO - 2021-05-04 02:32:24 --> Helper loaded: my_helper
INFO - 2021-05-04 02:32:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:32:24 --> Controller Class Initialized
DEBUG - 2021-05-04 02:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-05-04 02:32:24 --> Final output sent to browser
DEBUG - 2021-05-04 02:32:24 --> Total execution time: 0.1893
INFO - 2021-05-04 02:34:00 --> Config Class Initialized
INFO - 2021-05-04 02:34:00 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:34:00 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:34:00 --> Utf8 Class Initialized
INFO - 2021-05-04 02:34:00 --> URI Class Initialized
INFO - 2021-05-04 02:34:00 --> Router Class Initialized
INFO - 2021-05-04 02:34:00 --> Output Class Initialized
INFO - 2021-05-04 02:34:00 --> Security Class Initialized
DEBUG - 2021-05-04 02:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:34:00 --> Input Class Initialized
INFO - 2021-05-04 02:34:00 --> Language Class Initialized
INFO - 2021-05-04 02:34:00 --> Language Class Initialized
INFO - 2021-05-04 02:34:00 --> Config Class Initialized
INFO - 2021-05-04 02:34:00 --> Loader Class Initialized
INFO - 2021-05-04 02:34:00 --> Helper loaded: url_helper
INFO - 2021-05-04 02:34:00 --> Helper loaded: file_helper
INFO - 2021-05-04 02:34:00 --> Helper loaded: form_helper
INFO - 2021-05-04 02:34:00 --> Helper loaded: my_helper
INFO - 2021-05-04 02:34:00 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:34:00 --> Controller Class Initialized
DEBUG - 2021-05-04 02:34:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-05-04 02:34:00 --> Final output sent to browser
DEBUG - 2021-05-04 02:34:00 --> Total execution time: 0.1348
INFO - 2021-05-04 02:35:17 --> Config Class Initialized
INFO - 2021-05-04 02:35:17 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:35:17 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:35:17 --> Utf8 Class Initialized
INFO - 2021-05-04 02:35:17 --> URI Class Initialized
INFO - 2021-05-04 02:35:17 --> Router Class Initialized
INFO - 2021-05-04 02:35:17 --> Output Class Initialized
INFO - 2021-05-04 02:35:17 --> Security Class Initialized
DEBUG - 2021-05-04 02:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:35:17 --> Input Class Initialized
INFO - 2021-05-04 02:35:17 --> Language Class Initialized
INFO - 2021-05-04 02:35:17 --> Language Class Initialized
INFO - 2021-05-04 02:35:17 --> Config Class Initialized
INFO - 2021-05-04 02:35:17 --> Loader Class Initialized
INFO - 2021-05-04 02:35:17 --> Helper loaded: url_helper
INFO - 2021-05-04 02:35:17 --> Helper loaded: file_helper
INFO - 2021-05-04 02:35:17 --> Helper loaded: form_helper
INFO - 2021-05-04 02:35:17 --> Helper loaded: my_helper
INFO - 2021-05-04 02:35:17 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:35:17 --> Controller Class Initialized
DEBUG - 2021-05-04 02:35:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-05-04 02:35:17 --> Final output sent to browser
DEBUG - 2021-05-04 02:35:17 --> Total execution time: 0.0952
INFO - 2021-05-04 02:35:44 --> Config Class Initialized
INFO - 2021-05-04 02:35:44 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:35:44 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:35:44 --> Utf8 Class Initialized
INFO - 2021-05-04 02:35:44 --> URI Class Initialized
INFO - 2021-05-04 02:35:44 --> Router Class Initialized
INFO - 2021-05-04 02:35:44 --> Output Class Initialized
INFO - 2021-05-04 02:35:44 --> Security Class Initialized
DEBUG - 2021-05-04 02:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:35:44 --> Input Class Initialized
INFO - 2021-05-04 02:35:44 --> Language Class Initialized
INFO - 2021-05-04 02:35:45 --> Language Class Initialized
INFO - 2021-05-04 02:35:45 --> Config Class Initialized
INFO - 2021-05-04 02:35:45 --> Loader Class Initialized
INFO - 2021-05-04 02:35:45 --> Helper loaded: url_helper
INFO - 2021-05-04 02:35:45 --> Helper loaded: file_helper
INFO - 2021-05-04 02:35:45 --> Helper loaded: form_helper
INFO - 2021-05-04 02:35:45 --> Helper loaded: my_helper
INFO - 2021-05-04 02:35:45 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:35:45 --> Controller Class Initialized
DEBUG - 2021-05-04 02:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 02:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:35:45 --> Final output sent to browser
DEBUG - 2021-05-04 02:35:46 --> Total execution time: 2.0433
INFO - 2021-05-04 02:35:48 --> Config Class Initialized
INFO - 2021-05-04 02:35:48 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:35:48 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:35:48 --> Utf8 Class Initialized
INFO - 2021-05-04 02:35:48 --> URI Class Initialized
INFO - 2021-05-04 02:35:48 --> Router Class Initialized
INFO - 2021-05-04 02:35:48 --> Output Class Initialized
INFO - 2021-05-04 02:35:48 --> Security Class Initialized
DEBUG - 2021-05-04 02:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:35:48 --> Input Class Initialized
INFO - 2021-05-04 02:35:48 --> Language Class Initialized
INFO - 2021-05-04 02:35:48 --> Language Class Initialized
INFO - 2021-05-04 02:35:48 --> Config Class Initialized
INFO - 2021-05-04 02:35:48 --> Loader Class Initialized
INFO - 2021-05-04 02:35:48 --> Helper loaded: url_helper
INFO - 2021-05-04 02:35:48 --> Helper loaded: file_helper
INFO - 2021-05-04 02:35:48 --> Helper loaded: form_helper
INFO - 2021-05-04 02:35:48 --> Helper loaded: my_helper
INFO - 2021-05-04 02:35:48 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:35:48 --> Controller Class Initialized
DEBUG - 2021-05-04 02:35:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 02:35:48 --> Final output sent to browser
DEBUG - 2021-05-04 02:35:48 --> Total execution time: 0.4478
INFO - 2021-05-04 02:36:10 --> Config Class Initialized
INFO - 2021-05-04 02:36:10 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:10 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:10 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:10 --> URI Class Initialized
INFO - 2021-05-04 02:36:10 --> Router Class Initialized
INFO - 2021-05-04 02:36:10 --> Output Class Initialized
INFO - 2021-05-04 02:36:10 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:10 --> Input Class Initialized
INFO - 2021-05-04 02:36:10 --> Language Class Initialized
INFO - 2021-05-04 02:36:10 --> Language Class Initialized
INFO - 2021-05-04 02:36:10 --> Config Class Initialized
INFO - 2021-05-04 02:36:10 --> Loader Class Initialized
INFO - 2021-05-04 02:36:10 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:10 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:10 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:10 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:10 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:10 --> Controller Class Initialized
INFO - 2021-05-04 02:36:10 --> Helper loaded: cookie_helper
INFO - 2021-05-04 02:36:10 --> Config Class Initialized
INFO - 2021-05-04 02:36:10 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:10 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:10 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:10 --> URI Class Initialized
INFO - 2021-05-04 02:36:10 --> Router Class Initialized
INFO - 2021-05-04 02:36:10 --> Output Class Initialized
INFO - 2021-05-04 02:36:10 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:10 --> Input Class Initialized
INFO - 2021-05-04 02:36:10 --> Language Class Initialized
INFO - 2021-05-04 02:36:10 --> Language Class Initialized
INFO - 2021-05-04 02:36:10 --> Config Class Initialized
INFO - 2021-05-04 02:36:10 --> Loader Class Initialized
INFO - 2021-05-04 02:36:10 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:10 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:10 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:10 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:10 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:10 --> Controller Class Initialized
DEBUG - 2021-05-04 02:36:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 02:36:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:36:10 --> Final output sent to browser
DEBUG - 2021-05-04 02:36:10 --> Total execution time: 0.1983
INFO - 2021-05-04 02:36:16 --> Config Class Initialized
INFO - 2021-05-04 02:36:16 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:16 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:16 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:16 --> URI Class Initialized
INFO - 2021-05-04 02:36:16 --> Router Class Initialized
INFO - 2021-05-04 02:36:16 --> Output Class Initialized
INFO - 2021-05-04 02:36:16 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:16 --> Input Class Initialized
INFO - 2021-05-04 02:36:16 --> Language Class Initialized
INFO - 2021-05-04 02:36:16 --> Language Class Initialized
INFO - 2021-05-04 02:36:16 --> Config Class Initialized
INFO - 2021-05-04 02:36:16 --> Loader Class Initialized
INFO - 2021-05-04 02:36:16 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:16 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:16 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:16 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:16 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:16 --> Controller Class Initialized
INFO - 2021-05-04 02:36:16 --> Final output sent to browser
DEBUG - 2021-05-04 02:36:16 --> Total execution time: 0.1034
INFO - 2021-05-04 02:36:20 --> Config Class Initialized
INFO - 2021-05-04 02:36:20 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:20 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:20 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:20 --> URI Class Initialized
INFO - 2021-05-04 02:36:20 --> Router Class Initialized
INFO - 2021-05-04 02:36:20 --> Output Class Initialized
INFO - 2021-05-04 02:36:20 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:20 --> Input Class Initialized
INFO - 2021-05-04 02:36:20 --> Language Class Initialized
INFO - 2021-05-04 02:36:20 --> Language Class Initialized
INFO - 2021-05-04 02:36:20 --> Config Class Initialized
INFO - 2021-05-04 02:36:20 --> Loader Class Initialized
INFO - 2021-05-04 02:36:20 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:20 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:20 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:20 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:21 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:21 --> Controller Class Initialized
INFO - 2021-05-04 02:36:21 --> Helper loaded: cookie_helper
INFO - 2021-05-04 02:36:21 --> Final output sent to browser
DEBUG - 2021-05-04 02:36:21 --> Total execution time: 0.1412
INFO - 2021-05-04 02:36:21 --> Config Class Initialized
INFO - 2021-05-04 02:36:21 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:21 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:21 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:21 --> URI Class Initialized
INFO - 2021-05-04 02:36:21 --> Router Class Initialized
INFO - 2021-05-04 02:36:21 --> Output Class Initialized
INFO - 2021-05-04 02:36:21 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:21 --> Input Class Initialized
INFO - 2021-05-04 02:36:21 --> Language Class Initialized
INFO - 2021-05-04 02:36:21 --> Language Class Initialized
INFO - 2021-05-04 02:36:21 --> Config Class Initialized
INFO - 2021-05-04 02:36:21 --> Loader Class Initialized
INFO - 2021-05-04 02:36:21 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:21 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:21 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:21 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:21 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:21 --> Controller Class Initialized
DEBUG - 2021-05-04 02:36:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 02:36:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:36:21 --> Final output sent to browser
DEBUG - 2021-05-04 02:36:21 --> Total execution time: 0.3688
INFO - 2021-05-04 02:36:24 --> Config Class Initialized
INFO - 2021-05-04 02:36:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:24 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:24 --> URI Class Initialized
INFO - 2021-05-04 02:36:24 --> Router Class Initialized
INFO - 2021-05-04 02:36:24 --> Output Class Initialized
INFO - 2021-05-04 02:36:24 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:24 --> Input Class Initialized
INFO - 2021-05-04 02:36:24 --> Language Class Initialized
INFO - 2021-05-04 02:36:24 --> Language Class Initialized
INFO - 2021-05-04 02:36:24 --> Config Class Initialized
INFO - 2021-05-04 02:36:24 --> Loader Class Initialized
INFO - 2021-05-04 02:36:24 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:24 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:24 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:24 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:24 --> Controller Class Initialized
DEBUG - 2021-05-04 02:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-05-04 02:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:36:24 --> Final output sent to browser
DEBUG - 2021-05-04 02:36:24 --> Total execution time: 0.2064
INFO - 2021-05-04 02:36:25 --> Config Class Initialized
INFO - 2021-05-04 02:36:25 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:25 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:25 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:25 --> URI Class Initialized
INFO - 2021-05-04 02:36:25 --> Router Class Initialized
INFO - 2021-05-04 02:36:25 --> Output Class Initialized
INFO - 2021-05-04 02:36:25 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:25 --> Input Class Initialized
INFO - 2021-05-04 02:36:25 --> Language Class Initialized
INFO - 2021-05-04 02:36:25 --> Language Class Initialized
INFO - 2021-05-04 02:36:25 --> Config Class Initialized
INFO - 2021-05-04 02:36:25 --> Loader Class Initialized
INFO - 2021-05-04 02:36:25 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:25 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:25 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:25 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:25 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:25 --> Controller Class Initialized
INFO - 2021-05-04 02:36:35 --> Config Class Initialized
INFO - 2021-05-04 02:36:35 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:35 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:35 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:35 --> URI Class Initialized
INFO - 2021-05-04 02:36:35 --> Router Class Initialized
INFO - 2021-05-04 02:36:35 --> Output Class Initialized
INFO - 2021-05-04 02:36:35 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:35 --> Input Class Initialized
INFO - 2021-05-04 02:36:35 --> Language Class Initialized
INFO - 2021-05-04 02:36:35 --> Language Class Initialized
INFO - 2021-05-04 02:36:35 --> Config Class Initialized
INFO - 2021-05-04 02:36:35 --> Loader Class Initialized
INFO - 2021-05-04 02:36:35 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:35 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:35 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:35 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:35 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:35 --> Controller Class Initialized
INFO - 2021-05-04 02:36:35 --> Final output sent to browser
DEBUG - 2021-05-04 02:36:35 --> Total execution time: 0.1153
INFO - 2021-05-04 02:36:57 --> Config Class Initialized
INFO - 2021-05-04 02:36:57 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:57 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:57 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:57 --> URI Class Initialized
INFO - 2021-05-04 02:36:57 --> Router Class Initialized
INFO - 2021-05-04 02:36:57 --> Output Class Initialized
INFO - 2021-05-04 02:36:57 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:57 --> Input Class Initialized
INFO - 2021-05-04 02:36:57 --> Language Class Initialized
INFO - 2021-05-04 02:36:57 --> Language Class Initialized
INFO - 2021-05-04 02:36:57 --> Config Class Initialized
INFO - 2021-05-04 02:36:57 --> Loader Class Initialized
INFO - 2021-05-04 02:36:57 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:57 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:57 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:57 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:57 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:57 --> Controller Class Initialized
INFO - 2021-05-04 02:36:57 --> Final output sent to browser
DEBUG - 2021-05-04 02:36:57 --> Total execution time: 0.1254
INFO - 2021-05-04 02:36:57 --> Config Class Initialized
INFO - 2021-05-04 02:36:57 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:36:57 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:36:57 --> Utf8 Class Initialized
INFO - 2021-05-04 02:36:57 --> URI Class Initialized
INFO - 2021-05-04 02:36:57 --> Router Class Initialized
INFO - 2021-05-04 02:36:57 --> Output Class Initialized
INFO - 2021-05-04 02:36:57 --> Security Class Initialized
DEBUG - 2021-05-04 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:36:57 --> Input Class Initialized
INFO - 2021-05-04 02:36:57 --> Language Class Initialized
INFO - 2021-05-04 02:36:57 --> Language Class Initialized
INFO - 2021-05-04 02:36:57 --> Config Class Initialized
INFO - 2021-05-04 02:36:57 --> Loader Class Initialized
INFO - 2021-05-04 02:36:57 --> Helper loaded: url_helper
INFO - 2021-05-04 02:36:57 --> Helper loaded: file_helper
INFO - 2021-05-04 02:36:57 --> Helper loaded: form_helper
INFO - 2021-05-04 02:36:57 --> Helper loaded: my_helper
INFO - 2021-05-04 02:36:57 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:36:57 --> Controller Class Initialized
INFO - 2021-05-04 02:37:00 --> Config Class Initialized
INFO - 2021-05-04 02:37:00 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:37:00 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:37:00 --> Utf8 Class Initialized
INFO - 2021-05-04 02:37:00 --> URI Class Initialized
INFO - 2021-05-04 02:37:00 --> Router Class Initialized
INFO - 2021-05-04 02:37:00 --> Output Class Initialized
INFO - 2021-05-04 02:37:00 --> Security Class Initialized
DEBUG - 2021-05-04 02:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:37:00 --> Input Class Initialized
INFO - 2021-05-04 02:37:00 --> Language Class Initialized
INFO - 2021-05-04 02:37:00 --> Language Class Initialized
INFO - 2021-05-04 02:37:00 --> Config Class Initialized
INFO - 2021-05-04 02:37:00 --> Loader Class Initialized
INFO - 2021-05-04 02:37:00 --> Helper loaded: url_helper
INFO - 2021-05-04 02:37:00 --> Helper loaded: file_helper
INFO - 2021-05-04 02:37:00 --> Helper loaded: form_helper
INFO - 2021-05-04 02:37:00 --> Helper loaded: my_helper
INFO - 2021-05-04 02:37:00 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:37:00 --> Controller Class Initialized
INFO - 2021-05-04 02:37:00 --> Final output sent to browser
DEBUG - 2021-05-04 02:37:00 --> Total execution time: 0.1482
INFO - 2021-05-04 02:37:37 --> Config Class Initialized
INFO - 2021-05-04 02:37:37 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:37:37 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:37:37 --> Utf8 Class Initialized
INFO - 2021-05-04 02:37:37 --> URI Class Initialized
INFO - 2021-05-04 02:37:37 --> Router Class Initialized
INFO - 2021-05-04 02:37:37 --> Output Class Initialized
INFO - 2021-05-04 02:37:37 --> Security Class Initialized
DEBUG - 2021-05-04 02:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:37:37 --> Input Class Initialized
INFO - 2021-05-04 02:37:37 --> Language Class Initialized
INFO - 2021-05-04 02:37:37 --> Language Class Initialized
INFO - 2021-05-04 02:37:37 --> Config Class Initialized
INFO - 2021-05-04 02:37:37 --> Loader Class Initialized
INFO - 2021-05-04 02:37:37 --> Helper loaded: url_helper
INFO - 2021-05-04 02:37:37 --> Helper loaded: file_helper
INFO - 2021-05-04 02:37:37 --> Helper loaded: form_helper
INFO - 2021-05-04 02:37:37 --> Helper loaded: my_helper
INFO - 2021-05-04 02:37:37 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:37:37 --> Controller Class Initialized
INFO - 2021-05-04 02:37:37 --> Final output sent to browser
DEBUG - 2021-05-04 02:37:37 --> Total execution time: 0.1412
INFO - 2021-05-04 02:37:37 --> Config Class Initialized
INFO - 2021-05-04 02:37:37 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:37:37 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:37:37 --> Utf8 Class Initialized
INFO - 2021-05-04 02:37:37 --> URI Class Initialized
INFO - 2021-05-04 02:37:37 --> Router Class Initialized
INFO - 2021-05-04 02:37:37 --> Output Class Initialized
INFO - 2021-05-04 02:37:37 --> Security Class Initialized
DEBUG - 2021-05-04 02:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:37:37 --> Input Class Initialized
INFO - 2021-05-04 02:37:37 --> Language Class Initialized
INFO - 2021-05-04 02:37:38 --> Language Class Initialized
INFO - 2021-05-04 02:37:38 --> Config Class Initialized
INFO - 2021-05-04 02:37:38 --> Loader Class Initialized
INFO - 2021-05-04 02:37:38 --> Helper loaded: url_helper
INFO - 2021-05-04 02:37:38 --> Helper loaded: file_helper
INFO - 2021-05-04 02:37:38 --> Helper loaded: form_helper
INFO - 2021-05-04 02:37:38 --> Helper loaded: my_helper
INFO - 2021-05-04 02:37:38 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:37:38 --> Controller Class Initialized
INFO - 2021-05-04 02:37:42 --> Config Class Initialized
INFO - 2021-05-04 02:37:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:37:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:37:42 --> Utf8 Class Initialized
INFO - 2021-05-04 02:37:42 --> URI Class Initialized
INFO - 2021-05-04 02:37:42 --> Router Class Initialized
INFO - 2021-05-04 02:37:42 --> Output Class Initialized
INFO - 2021-05-04 02:37:42 --> Security Class Initialized
DEBUG - 2021-05-04 02:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:37:42 --> Input Class Initialized
INFO - 2021-05-04 02:37:42 --> Language Class Initialized
INFO - 2021-05-04 02:37:42 --> Language Class Initialized
INFO - 2021-05-04 02:37:42 --> Config Class Initialized
INFO - 2021-05-04 02:37:42 --> Loader Class Initialized
INFO - 2021-05-04 02:37:42 --> Helper loaded: url_helper
INFO - 2021-05-04 02:37:42 --> Helper loaded: file_helper
INFO - 2021-05-04 02:37:42 --> Helper loaded: form_helper
INFO - 2021-05-04 02:37:42 --> Helper loaded: my_helper
INFO - 2021-05-04 02:37:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:37:42 --> Controller Class Initialized
INFO - 2021-05-04 02:37:42 --> Final output sent to browser
DEBUG - 2021-05-04 02:37:42 --> Total execution time: 0.1258
INFO - 2021-05-04 02:38:00 --> Config Class Initialized
INFO - 2021-05-04 02:38:00 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:38:00 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:38:00 --> Utf8 Class Initialized
INFO - 2021-05-04 02:38:00 --> URI Class Initialized
INFO - 2021-05-04 02:38:00 --> Router Class Initialized
INFO - 2021-05-04 02:38:00 --> Output Class Initialized
INFO - 2021-05-04 02:38:00 --> Security Class Initialized
DEBUG - 2021-05-04 02:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:38:00 --> Input Class Initialized
INFO - 2021-05-04 02:38:00 --> Language Class Initialized
INFO - 2021-05-04 02:38:00 --> Language Class Initialized
INFO - 2021-05-04 02:38:00 --> Config Class Initialized
INFO - 2021-05-04 02:38:00 --> Loader Class Initialized
INFO - 2021-05-04 02:38:00 --> Helper loaded: url_helper
INFO - 2021-05-04 02:38:00 --> Helper loaded: file_helper
INFO - 2021-05-04 02:38:00 --> Helper loaded: form_helper
INFO - 2021-05-04 02:38:00 --> Helper loaded: my_helper
INFO - 2021-05-04 02:38:00 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:38:00 --> Controller Class Initialized
INFO - 2021-05-04 02:38:00 --> Final output sent to browser
DEBUG - 2021-05-04 02:38:00 --> Total execution time: 0.1301
INFO - 2021-05-04 02:38:01 --> Config Class Initialized
INFO - 2021-05-04 02:38:01 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:38:01 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:38:01 --> Utf8 Class Initialized
INFO - 2021-05-04 02:38:01 --> URI Class Initialized
INFO - 2021-05-04 02:38:01 --> Router Class Initialized
INFO - 2021-05-04 02:38:01 --> Output Class Initialized
INFO - 2021-05-04 02:38:01 --> Security Class Initialized
DEBUG - 2021-05-04 02:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:38:01 --> Input Class Initialized
INFO - 2021-05-04 02:38:01 --> Language Class Initialized
INFO - 2021-05-04 02:38:01 --> Language Class Initialized
INFO - 2021-05-04 02:38:01 --> Config Class Initialized
INFO - 2021-05-04 02:38:01 --> Loader Class Initialized
INFO - 2021-05-04 02:38:01 --> Helper loaded: url_helper
INFO - 2021-05-04 02:38:01 --> Helper loaded: file_helper
INFO - 2021-05-04 02:38:01 --> Helper loaded: form_helper
INFO - 2021-05-04 02:38:01 --> Helper loaded: my_helper
INFO - 2021-05-04 02:38:01 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:38:01 --> Controller Class Initialized
INFO - 2021-05-04 02:38:05 --> Config Class Initialized
INFO - 2021-05-04 02:38:05 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:38:05 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:38:05 --> Utf8 Class Initialized
INFO - 2021-05-04 02:38:05 --> URI Class Initialized
INFO - 2021-05-04 02:38:05 --> Router Class Initialized
INFO - 2021-05-04 02:38:05 --> Output Class Initialized
INFO - 2021-05-04 02:38:05 --> Security Class Initialized
DEBUG - 2021-05-04 02:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:38:05 --> Input Class Initialized
INFO - 2021-05-04 02:38:05 --> Language Class Initialized
INFO - 2021-05-04 02:38:05 --> Language Class Initialized
INFO - 2021-05-04 02:38:05 --> Config Class Initialized
INFO - 2021-05-04 02:38:05 --> Loader Class Initialized
INFO - 2021-05-04 02:38:05 --> Helper loaded: url_helper
INFO - 2021-05-04 02:38:05 --> Helper loaded: file_helper
INFO - 2021-05-04 02:38:05 --> Helper loaded: form_helper
INFO - 2021-05-04 02:38:05 --> Helper loaded: my_helper
INFO - 2021-05-04 02:38:05 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:38:05 --> Controller Class Initialized
INFO - 2021-05-04 02:38:05 --> Final output sent to browser
DEBUG - 2021-05-04 02:38:05 --> Total execution time: 0.1444
INFO - 2021-05-04 02:38:12 --> Config Class Initialized
INFO - 2021-05-04 02:38:12 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:38:12 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:38:12 --> Utf8 Class Initialized
INFO - 2021-05-04 02:38:12 --> URI Class Initialized
INFO - 2021-05-04 02:38:12 --> Router Class Initialized
INFO - 2021-05-04 02:38:12 --> Output Class Initialized
INFO - 2021-05-04 02:38:12 --> Security Class Initialized
DEBUG - 2021-05-04 02:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:38:12 --> Input Class Initialized
INFO - 2021-05-04 02:38:12 --> Language Class Initialized
INFO - 2021-05-04 02:38:12 --> Language Class Initialized
INFO - 2021-05-04 02:38:12 --> Config Class Initialized
INFO - 2021-05-04 02:38:12 --> Loader Class Initialized
INFO - 2021-05-04 02:38:12 --> Helper loaded: url_helper
INFO - 2021-05-04 02:38:12 --> Helper loaded: file_helper
INFO - 2021-05-04 02:38:12 --> Helper loaded: form_helper
INFO - 2021-05-04 02:38:12 --> Helper loaded: my_helper
INFO - 2021-05-04 02:38:12 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:38:12 --> Controller Class Initialized
INFO - 2021-05-04 02:38:12 --> Final output sent to browser
DEBUG - 2021-05-04 02:38:12 --> Total execution time: 0.1514
INFO - 2021-05-04 02:38:12 --> Config Class Initialized
INFO - 2021-05-04 02:38:12 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:38:12 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:38:12 --> Utf8 Class Initialized
INFO - 2021-05-04 02:38:12 --> URI Class Initialized
INFO - 2021-05-04 02:38:12 --> Router Class Initialized
INFO - 2021-05-04 02:38:12 --> Output Class Initialized
INFO - 2021-05-04 02:38:12 --> Security Class Initialized
DEBUG - 2021-05-04 02:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:38:12 --> Input Class Initialized
INFO - 2021-05-04 02:38:12 --> Language Class Initialized
INFO - 2021-05-04 02:38:12 --> Language Class Initialized
INFO - 2021-05-04 02:38:12 --> Config Class Initialized
INFO - 2021-05-04 02:38:12 --> Loader Class Initialized
INFO - 2021-05-04 02:38:12 --> Helper loaded: url_helper
INFO - 2021-05-04 02:38:12 --> Helper loaded: file_helper
INFO - 2021-05-04 02:38:12 --> Helper loaded: form_helper
INFO - 2021-05-04 02:38:12 --> Helper loaded: my_helper
INFO - 2021-05-04 02:38:12 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:38:12 --> Controller Class Initialized
INFO - 2021-05-04 02:39:10 --> Config Class Initialized
INFO - 2021-05-04 02:39:10 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:39:10 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:39:10 --> Utf8 Class Initialized
INFO - 2021-05-04 02:39:10 --> URI Class Initialized
INFO - 2021-05-04 02:39:10 --> Router Class Initialized
INFO - 2021-05-04 02:39:10 --> Output Class Initialized
INFO - 2021-05-04 02:39:10 --> Security Class Initialized
DEBUG - 2021-05-04 02:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:39:10 --> Input Class Initialized
INFO - 2021-05-04 02:39:10 --> Language Class Initialized
INFO - 2021-05-04 02:39:10 --> Language Class Initialized
INFO - 2021-05-04 02:39:10 --> Config Class Initialized
INFO - 2021-05-04 02:39:10 --> Loader Class Initialized
INFO - 2021-05-04 02:39:10 --> Helper loaded: url_helper
INFO - 2021-05-04 02:39:10 --> Helper loaded: file_helper
INFO - 2021-05-04 02:39:10 --> Helper loaded: form_helper
INFO - 2021-05-04 02:39:10 --> Helper loaded: my_helper
INFO - 2021-05-04 02:39:10 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:39:10 --> Controller Class Initialized
INFO - 2021-05-04 02:39:10 --> Final output sent to browser
DEBUG - 2021-05-04 02:39:10 --> Total execution time: 0.1260
INFO - 2021-05-04 02:47:28 --> Config Class Initialized
INFO - 2021-05-04 02:47:28 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:47:28 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:47:28 --> Utf8 Class Initialized
INFO - 2021-05-04 02:47:28 --> URI Class Initialized
INFO - 2021-05-04 02:47:28 --> Router Class Initialized
INFO - 2021-05-04 02:47:28 --> Output Class Initialized
INFO - 2021-05-04 02:47:28 --> Security Class Initialized
DEBUG - 2021-05-04 02:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:47:28 --> Input Class Initialized
INFO - 2021-05-04 02:47:28 --> Language Class Initialized
INFO - 2021-05-04 02:47:28 --> Language Class Initialized
INFO - 2021-05-04 02:47:28 --> Config Class Initialized
INFO - 2021-05-04 02:47:28 --> Loader Class Initialized
INFO - 2021-05-04 02:47:28 --> Helper loaded: url_helper
INFO - 2021-05-04 02:47:28 --> Helper loaded: file_helper
INFO - 2021-05-04 02:47:28 --> Helper loaded: form_helper
INFO - 2021-05-04 02:47:28 --> Helper loaded: my_helper
INFO - 2021-05-04 02:47:28 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:47:28 --> Controller Class Initialized
INFO - 2021-05-04 02:47:28 --> Final output sent to browser
DEBUG - 2021-05-04 02:47:28 --> Total execution time: 0.1354
INFO - 2021-05-04 02:47:36 --> Config Class Initialized
INFO - 2021-05-04 02:47:36 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:47:36 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:47:36 --> Utf8 Class Initialized
INFO - 2021-05-04 02:47:36 --> URI Class Initialized
INFO - 2021-05-04 02:47:36 --> Router Class Initialized
INFO - 2021-05-04 02:47:36 --> Output Class Initialized
INFO - 2021-05-04 02:47:36 --> Security Class Initialized
DEBUG - 2021-05-04 02:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:47:36 --> Input Class Initialized
INFO - 2021-05-04 02:47:36 --> Language Class Initialized
INFO - 2021-05-04 02:47:36 --> Language Class Initialized
INFO - 2021-05-04 02:47:36 --> Config Class Initialized
INFO - 2021-05-04 02:47:37 --> Loader Class Initialized
INFO - 2021-05-04 02:47:37 --> Helper loaded: url_helper
INFO - 2021-05-04 02:47:37 --> Helper loaded: file_helper
INFO - 2021-05-04 02:47:37 --> Helper loaded: form_helper
INFO - 2021-05-04 02:47:37 --> Helper loaded: my_helper
INFO - 2021-05-04 02:47:37 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:47:37 --> Controller Class Initialized
INFO - 2021-05-04 02:47:37 --> Final output sent to browser
DEBUG - 2021-05-04 02:47:37 --> Total execution time: 0.1832
INFO - 2021-05-04 02:47:37 --> Config Class Initialized
INFO - 2021-05-04 02:47:37 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:47:37 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:47:37 --> Utf8 Class Initialized
INFO - 2021-05-04 02:47:37 --> URI Class Initialized
INFO - 2021-05-04 02:47:37 --> Router Class Initialized
INFO - 2021-05-04 02:47:37 --> Output Class Initialized
INFO - 2021-05-04 02:47:37 --> Security Class Initialized
DEBUG - 2021-05-04 02:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:47:37 --> Input Class Initialized
INFO - 2021-05-04 02:47:37 --> Language Class Initialized
INFO - 2021-05-04 02:47:37 --> Language Class Initialized
INFO - 2021-05-04 02:47:37 --> Config Class Initialized
INFO - 2021-05-04 02:47:37 --> Loader Class Initialized
INFO - 2021-05-04 02:47:37 --> Helper loaded: url_helper
INFO - 2021-05-04 02:47:37 --> Helper loaded: file_helper
INFO - 2021-05-04 02:47:37 --> Helper loaded: form_helper
INFO - 2021-05-04 02:47:37 --> Helper loaded: my_helper
INFO - 2021-05-04 02:47:37 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:47:37 --> Controller Class Initialized
INFO - 2021-05-04 02:47:41 --> Config Class Initialized
INFO - 2021-05-04 02:47:41 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:47:41 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:47:41 --> Utf8 Class Initialized
INFO - 2021-05-04 02:47:41 --> URI Class Initialized
INFO - 2021-05-04 02:47:41 --> Router Class Initialized
INFO - 2021-05-04 02:47:41 --> Output Class Initialized
INFO - 2021-05-04 02:47:41 --> Security Class Initialized
DEBUG - 2021-05-04 02:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:47:42 --> Input Class Initialized
INFO - 2021-05-04 02:47:42 --> Language Class Initialized
INFO - 2021-05-04 02:47:42 --> Language Class Initialized
INFO - 2021-05-04 02:47:42 --> Config Class Initialized
INFO - 2021-05-04 02:47:42 --> Loader Class Initialized
INFO - 2021-05-04 02:47:42 --> Helper loaded: url_helper
INFO - 2021-05-04 02:47:42 --> Helper loaded: file_helper
INFO - 2021-05-04 02:47:42 --> Helper loaded: form_helper
INFO - 2021-05-04 02:47:42 --> Helper loaded: my_helper
INFO - 2021-05-04 02:47:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:47:42 --> Controller Class Initialized
INFO - 2021-05-04 02:47:42 --> Final output sent to browser
DEBUG - 2021-05-04 02:47:42 --> Total execution time: 0.1180
INFO - 2021-05-04 02:48:01 --> Config Class Initialized
INFO - 2021-05-04 02:48:01 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:48:01 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:48:01 --> Utf8 Class Initialized
INFO - 2021-05-04 02:48:01 --> URI Class Initialized
INFO - 2021-05-04 02:48:01 --> Router Class Initialized
INFO - 2021-05-04 02:48:01 --> Output Class Initialized
INFO - 2021-05-04 02:48:01 --> Security Class Initialized
DEBUG - 2021-05-04 02:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:48:01 --> Input Class Initialized
INFO - 2021-05-04 02:48:01 --> Language Class Initialized
INFO - 2021-05-04 02:48:01 --> Language Class Initialized
INFO - 2021-05-04 02:48:01 --> Config Class Initialized
INFO - 2021-05-04 02:48:01 --> Loader Class Initialized
INFO - 2021-05-04 02:48:01 --> Helper loaded: url_helper
INFO - 2021-05-04 02:48:01 --> Helper loaded: file_helper
INFO - 2021-05-04 02:48:01 --> Helper loaded: form_helper
INFO - 2021-05-04 02:48:01 --> Helper loaded: my_helper
INFO - 2021-05-04 02:48:01 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:48:01 --> Controller Class Initialized
INFO - 2021-05-04 02:48:01 --> Final output sent to browser
DEBUG - 2021-05-04 02:48:01 --> Total execution time: 0.1513
INFO - 2021-05-04 02:48:01 --> Config Class Initialized
INFO - 2021-05-04 02:48:01 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:48:01 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:48:01 --> Utf8 Class Initialized
INFO - 2021-05-04 02:48:01 --> URI Class Initialized
INFO - 2021-05-04 02:48:01 --> Router Class Initialized
INFO - 2021-05-04 02:48:01 --> Output Class Initialized
INFO - 2021-05-04 02:48:01 --> Security Class Initialized
DEBUG - 2021-05-04 02:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:48:01 --> Input Class Initialized
INFO - 2021-05-04 02:48:01 --> Language Class Initialized
INFO - 2021-05-04 02:48:01 --> Language Class Initialized
INFO - 2021-05-04 02:48:01 --> Config Class Initialized
INFO - 2021-05-04 02:48:01 --> Loader Class Initialized
INFO - 2021-05-04 02:48:01 --> Helper loaded: url_helper
INFO - 2021-05-04 02:48:01 --> Helper loaded: file_helper
INFO - 2021-05-04 02:48:01 --> Helper loaded: form_helper
INFO - 2021-05-04 02:48:01 --> Helper loaded: my_helper
INFO - 2021-05-04 02:48:01 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:48:01 --> Controller Class Initialized
INFO - 2021-05-04 02:48:04 --> Config Class Initialized
INFO - 2021-05-04 02:48:04 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:48:04 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:48:04 --> Utf8 Class Initialized
INFO - 2021-05-04 02:48:04 --> URI Class Initialized
INFO - 2021-05-04 02:48:04 --> Router Class Initialized
INFO - 2021-05-04 02:48:04 --> Output Class Initialized
INFO - 2021-05-04 02:48:04 --> Security Class Initialized
DEBUG - 2021-05-04 02:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:48:04 --> Input Class Initialized
INFO - 2021-05-04 02:48:04 --> Language Class Initialized
INFO - 2021-05-04 02:48:04 --> Language Class Initialized
INFO - 2021-05-04 02:48:04 --> Config Class Initialized
INFO - 2021-05-04 02:48:04 --> Loader Class Initialized
INFO - 2021-05-04 02:48:04 --> Helper loaded: url_helper
INFO - 2021-05-04 02:48:04 --> Helper loaded: file_helper
INFO - 2021-05-04 02:48:04 --> Helper loaded: form_helper
INFO - 2021-05-04 02:48:04 --> Helper loaded: my_helper
INFO - 2021-05-04 02:48:04 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:48:04 --> Controller Class Initialized
INFO - 2021-05-04 02:48:04 --> Final output sent to browser
DEBUG - 2021-05-04 02:48:04 --> Total execution time: 0.1098
INFO - 2021-05-04 02:48:15 --> Config Class Initialized
INFO - 2021-05-04 02:48:15 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:48:15 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:48:15 --> Utf8 Class Initialized
INFO - 2021-05-04 02:48:15 --> URI Class Initialized
INFO - 2021-05-04 02:48:15 --> Router Class Initialized
INFO - 2021-05-04 02:48:15 --> Output Class Initialized
INFO - 2021-05-04 02:48:15 --> Security Class Initialized
DEBUG - 2021-05-04 02:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:48:15 --> Input Class Initialized
INFO - 2021-05-04 02:48:15 --> Language Class Initialized
INFO - 2021-05-04 02:48:15 --> Language Class Initialized
INFO - 2021-05-04 02:48:15 --> Config Class Initialized
INFO - 2021-05-04 02:48:15 --> Loader Class Initialized
INFO - 2021-05-04 02:48:15 --> Helper loaded: url_helper
INFO - 2021-05-04 02:48:15 --> Helper loaded: file_helper
INFO - 2021-05-04 02:48:15 --> Helper loaded: form_helper
INFO - 2021-05-04 02:48:15 --> Helper loaded: my_helper
INFO - 2021-05-04 02:48:15 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:48:15 --> Controller Class Initialized
INFO - 2021-05-04 02:48:15 --> Final output sent to browser
DEBUG - 2021-05-04 02:48:15 --> Total execution time: 0.1415
INFO - 2021-05-04 02:48:15 --> Config Class Initialized
INFO - 2021-05-04 02:48:15 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:48:15 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:48:15 --> Utf8 Class Initialized
INFO - 2021-05-04 02:48:15 --> URI Class Initialized
INFO - 2021-05-04 02:48:15 --> Router Class Initialized
INFO - 2021-05-04 02:48:15 --> Output Class Initialized
INFO - 2021-05-04 02:48:15 --> Security Class Initialized
DEBUG - 2021-05-04 02:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:48:15 --> Input Class Initialized
INFO - 2021-05-04 02:48:15 --> Language Class Initialized
INFO - 2021-05-04 02:48:15 --> Language Class Initialized
INFO - 2021-05-04 02:48:15 --> Config Class Initialized
INFO - 2021-05-04 02:48:15 --> Loader Class Initialized
INFO - 2021-05-04 02:48:15 --> Helper loaded: url_helper
INFO - 2021-05-04 02:48:15 --> Helper loaded: file_helper
INFO - 2021-05-04 02:48:15 --> Helper loaded: form_helper
INFO - 2021-05-04 02:48:15 --> Helper loaded: my_helper
INFO - 2021-05-04 02:48:15 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:48:15 --> Controller Class Initialized
INFO - 2021-05-04 02:48:18 --> Config Class Initialized
INFO - 2021-05-04 02:48:18 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:48:18 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:48:18 --> Utf8 Class Initialized
INFO - 2021-05-04 02:48:18 --> URI Class Initialized
INFO - 2021-05-04 02:48:18 --> Router Class Initialized
INFO - 2021-05-04 02:48:18 --> Output Class Initialized
INFO - 2021-05-04 02:48:18 --> Security Class Initialized
DEBUG - 2021-05-04 02:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:48:18 --> Input Class Initialized
INFO - 2021-05-04 02:48:18 --> Language Class Initialized
INFO - 2021-05-04 02:48:18 --> Language Class Initialized
INFO - 2021-05-04 02:48:18 --> Config Class Initialized
INFO - 2021-05-04 02:48:18 --> Loader Class Initialized
INFO - 2021-05-04 02:48:18 --> Helper loaded: url_helper
INFO - 2021-05-04 02:48:18 --> Helper loaded: file_helper
INFO - 2021-05-04 02:48:18 --> Helper loaded: form_helper
INFO - 2021-05-04 02:48:18 --> Helper loaded: my_helper
INFO - 2021-05-04 02:48:18 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:48:18 --> Controller Class Initialized
INFO - 2021-05-04 02:48:18 --> Final output sent to browser
DEBUG - 2021-05-04 02:48:18 --> Total execution time: 0.1254
INFO - 2021-05-04 02:49:00 --> Config Class Initialized
INFO - 2021-05-04 02:49:00 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:00 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:00 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:00 --> URI Class Initialized
INFO - 2021-05-04 02:49:00 --> Router Class Initialized
INFO - 2021-05-04 02:49:00 --> Output Class Initialized
INFO - 2021-05-04 02:49:00 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:00 --> Input Class Initialized
INFO - 2021-05-04 02:49:00 --> Language Class Initialized
INFO - 2021-05-04 02:49:00 --> Language Class Initialized
INFO - 2021-05-04 02:49:00 --> Config Class Initialized
INFO - 2021-05-04 02:49:00 --> Loader Class Initialized
INFO - 2021-05-04 02:49:00 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:00 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:00 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:00 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:00 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:00 --> Controller Class Initialized
INFO - 2021-05-04 02:49:01 --> Final output sent to browser
DEBUG - 2021-05-04 02:49:01 --> Total execution time: 0.1123
INFO - 2021-05-04 02:49:01 --> Config Class Initialized
INFO - 2021-05-04 02:49:01 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:01 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:01 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:01 --> URI Class Initialized
INFO - 2021-05-04 02:49:01 --> Router Class Initialized
INFO - 2021-05-04 02:49:01 --> Output Class Initialized
INFO - 2021-05-04 02:49:01 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:01 --> Input Class Initialized
INFO - 2021-05-04 02:49:01 --> Language Class Initialized
INFO - 2021-05-04 02:49:01 --> Language Class Initialized
INFO - 2021-05-04 02:49:01 --> Config Class Initialized
INFO - 2021-05-04 02:49:01 --> Loader Class Initialized
INFO - 2021-05-04 02:49:01 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:01 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:01 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:01 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:01 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:01 --> Controller Class Initialized
INFO - 2021-05-04 02:49:05 --> Config Class Initialized
INFO - 2021-05-04 02:49:05 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:05 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:05 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:05 --> URI Class Initialized
INFO - 2021-05-04 02:49:05 --> Router Class Initialized
INFO - 2021-05-04 02:49:05 --> Output Class Initialized
INFO - 2021-05-04 02:49:05 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:05 --> Input Class Initialized
INFO - 2021-05-04 02:49:05 --> Language Class Initialized
INFO - 2021-05-04 02:49:05 --> Language Class Initialized
INFO - 2021-05-04 02:49:05 --> Config Class Initialized
INFO - 2021-05-04 02:49:05 --> Loader Class Initialized
INFO - 2021-05-04 02:49:05 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:05 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:05 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:05 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:05 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:05 --> Controller Class Initialized
INFO - 2021-05-04 02:49:05 --> Final output sent to browser
DEBUG - 2021-05-04 02:49:05 --> Total execution time: 0.1168
INFO - 2021-05-04 02:49:05 --> Config Class Initialized
INFO - 2021-05-04 02:49:05 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:05 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:05 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:05 --> URI Class Initialized
INFO - 2021-05-04 02:49:05 --> Router Class Initialized
INFO - 2021-05-04 02:49:05 --> Output Class Initialized
INFO - 2021-05-04 02:49:05 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:05 --> Input Class Initialized
INFO - 2021-05-04 02:49:05 --> Language Class Initialized
INFO - 2021-05-04 02:49:05 --> Language Class Initialized
INFO - 2021-05-04 02:49:05 --> Config Class Initialized
INFO - 2021-05-04 02:49:05 --> Loader Class Initialized
INFO - 2021-05-04 02:49:05 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:05 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:05 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:05 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:05 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:05 --> Controller Class Initialized
INFO - 2021-05-04 02:49:07 --> Config Class Initialized
INFO - 2021-05-04 02:49:07 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:07 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:07 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:07 --> URI Class Initialized
INFO - 2021-05-04 02:49:07 --> Router Class Initialized
INFO - 2021-05-04 02:49:07 --> Output Class Initialized
INFO - 2021-05-04 02:49:07 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:07 --> Input Class Initialized
INFO - 2021-05-04 02:49:07 --> Language Class Initialized
INFO - 2021-05-04 02:49:07 --> Language Class Initialized
INFO - 2021-05-04 02:49:07 --> Config Class Initialized
INFO - 2021-05-04 02:49:07 --> Loader Class Initialized
INFO - 2021-05-04 02:49:07 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:07 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:07 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:07 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:07 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:07 --> Controller Class Initialized
INFO - 2021-05-04 02:49:07 --> Final output sent to browser
DEBUG - 2021-05-04 02:49:07 --> Total execution time: 0.1505
INFO - 2021-05-04 02:49:21 --> Config Class Initialized
INFO - 2021-05-04 02:49:21 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:21 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:21 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:21 --> URI Class Initialized
INFO - 2021-05-04 02:49:21 --> Router Class Initialized
INFO - 2021-05-04 02:49:21 --> Output Class Initialized
INFO - 2021-05-04 02:49:21 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:21 --> Input Class Initialized
INFO - 2021-05-04 02:49:21 --> Language Class Initialized
INFO - 2021-05-04 02:49:21 --> Language Class Initialized
INFO - 2021-05-04 02:49:21 --> Config Class Initialized
INFO - 2021-05-04 02:49:21 --> Loader Class Initialized
INFO - 2021-05-04 02:49:21 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:21 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:21 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:21 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:21 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:21 --> Controller Class Initialized
INFO - 2021-05-04 02:49:21 --> Final output sent to browser
DEBUG - 2021-05-04 02:49:21 --> Total execution time: 0.1327
INFO - 2021-05-04 02:49:22 --> Config Class Initialized
INFO - 2021-05-04 02:49:22 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:22 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:22 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:22 --> URI Class Initialized
INFO - 2021-05-04 02:49:22 --> Router Class Initialized
INFO - 2021-05-04 02:49:22 --> Output Class Initialized
INFO - 2021-05-04 02:49:22 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:22 --> Input Class Initialized
INFO - 2021-05-04 02:49:22 --> Language Class Initialized
INFO - 2021-05-04 02:49:22 --> Language Class Initialized
INFO - 2021-05-04 02:49:22 --> Config Class Initialized
INFO - 2021-05-04 02:49:22 --> Loader Class Initialized
INFO - 2021-05-04 02:49:22 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:22 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:22 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:22 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:22 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:22 --> Controller Class Initialized
INFO - 2021-05-04 02:49:24 --> Config Class Initialized
INFO - 2021-05-04 02:49:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:24 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:24 --> URI Class Initialized
INFO - 2021-05-04 02:49:24 --> Router Class Initialized
INFO - 2021-05-04 02:49:24 --> Output Class Initialized
INFO - 2021-05-04 02:49:24 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:24 --> Input Class Initialized
INFO - 2021-05-04 02:49:24 --> Language Class Initialized
INFO - 2021-05-04 02:49:24 --> Language Class Initialized
INFO - 2021-05-04 02:49:24 --> Config Class Initialized
INFO - 2021-05-04 02:49:24 --> Loader Class Initialized
INFO - 2021-05-04 02:49:24 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:24 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:24 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:24 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:24 --> Controller Class Initialized
INFO - 2021-05-04 02:49:24 --> Final output sent to browser
DEBUG - 2021-05-04 02:49:24 --> Total execution time: 0.1166
INFO - 2021-05-04 02:49:40 --> Config Class Initialized
INFO - 2021-05-04 02:49:40 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:40 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:40 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:40 --> URI Class Initialized
INFO - 2021-05-04 02:49:40 --> Router Class Initialized
INFO - 2021-05-04 02:49:40 --> Output Class Initialized
INFO - 2021-05-04 02:49:40 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:40 --> Input Class Initialized
INFO - 2021-05-04 02:49:40 --> Language Class Initialized
INFO - 2021-05-04 02:49:40 --> Language Class Initialized
INFO - 2021-05-04 02:49:40 --> Config Class Initialized
INFO - 2021-05-04 02:49:40 --> Loader Class Initialized
INFO - 2021-05-04 02:49:40 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:40 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:40 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:40 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:40 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:40 --> Controller Class Initialized
INFO - 2021-05-04 02:49:40 --> Final output sent to browser
DEBUG - 2021-05-04 02:49:40 --> Total execution time: 0.1147
INFO - 2021-05-04 02:49:40 --> Config Class Initialized
INFO - 2021-05-04 02:49:40 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:40 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:40 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:40 --> URI Class Initialized
INFO - 2021-05-04 02:49:40 --> Router Class Initialized
INFO - 2021-05-04 02:49:40 --> Output Class Initialized
INFO - 2021-05-04 02:49:40 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:40 --> Input Class Initialized
INFO - 2021-05-04 02:49:40 --> Language Class Initialized
INFO - 2021-05-04 02:49:40 --> Language Class Initialized
INFO - 2021-05-04 02:49:40 --> Config Class Initialized
INFO - 2021-05-04 02:49:40 --> Loader Class Initialized
INFO - 2021-05-04 02:49:40 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:40 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:40 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:40 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:40 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:40 --> Controller Class Initialized
INFO - 2021-05-04 02:49:44 --> Config Class Initialized
INFO - 2021-05-04 02:49:44 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:49:44 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:49:44 --> Utf8 Class Initialized
INFO - 2021-05-04 02:49:44 --> URI Class Initialized
INFO - 2021-05-04 02:49:44 --> Router Class Initialized
INFO - 2021-05-04 02:49:44 --> Output Class Initialized
INFO - 2021-05-04 02:49:44 --> Security Class Initialized
DEBUG - 2021-05-04 02:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:49:44 --> Input Class Initialized
INFO - 2021-05-04 02:49:44 --> Language Class Initialized
INFO - 2021-05-04 02:49:44 --> Language Class Initialized
INFO - 2021-05-04 02:49:44 --> Config Class Initialized
INFO - 2021-05-04 02:49:44 --> Loader Class Initialized
INFO - 2021-05-04 02:49:44 --> Helper loaded: url_helper
INFO - 2021-05-04 02:49:44 --> Helper loaded: file_helper
INFO - 2021-05-04 02:49:44 --> Helper loaded: form_helper
INFO - 2021-05-04 02:49:44 --> Helper loaded: my_helper
INFO - 2021-05-04 02:49:44 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:49:44 --> Controller Class Initialized
INFO - 2021-05-04 02:49:44 --> Final output sent to browser
DEBUG - 2021-05-04 02:49:44 --> Total execution time: 0.1431
INFO - 2021-05-04 02:50:05 --> Config Class Initialized
INFO - 2021-05-04 02:50:05 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:05 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:05 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:05 --> URI Class Initialized
INFO - 2021-05-04 02:50:05 --> Router Class Initialized
INFO - 2021-05-04 02:50:05 --> Output Class Initialized
INFO - 2021-05-04 02:50:05 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:05 --> Input Class Initialized
INFO - 2021-05-04 02:50:05 --> Language Class Initialized
INFO - 2021-05-04 02:50:05 --> Language Class Initialized
INFO - 2021-05-04 02:50:05 --> Config Class Initialized
INFO - 2021-05-04 02:50:05 --> Loader Class Initialized
INFO - 2021-05-04 02:50:05 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:05 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:05 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:05 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:05 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:05 --> Controller Class Initialized
INFO - 2021-05-04 02:50:05 --> Final output sent to browser
DEBUG - 2021-05-04 02:50:05 --> Total execution time: 0.1355
INFO - 2021-05-04 02:50:05 --> Config Class Initialized
INFO - 2021-05-04 02:50:05 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:05 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:05 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:05 --> URI Class Initialized
INFO - 2021-05-04 02:50:05 --> Router Class Initialized
INFO - 2021-05-04 02:50:05 --> Output Class Initialized
INFO - 2021-05-04 02:50:05 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:05 --> Input Class Initialized
INFO - 2021-05-04 02:50:05 --> Language Class Initialized
INFO - 2021-05-04 02:50:05 --> Language Class Initialized
INFO - 2021-05-04 02:50:05 --> Config Class Initialized
INFO - 2021-05-04 02:50:05 --> Loader Class Initialized
INFO - 2021-05-04 02:50:05 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:05 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:05 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:05 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:05 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:05 --> Controller Class Initialized
INFO - 2021-05-04 02:50:07 --> Config Class Initialized
INFO - 2021-05-04 02:50:07 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:08 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:08 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:08 --> URI Class Initialized
INFO - 2021-05-04 02:50:08 --> Router Class Initialized
INFO - 2021-05-04 02:50:08 --> Output Class Initialized
INFO - 2021-05-04 02:50:08 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:08 --> Input Class Initialized
INFO - 2021-05-04 02:50:08 --> Language Class Initialized
INFO - 2021-05-04 02:50:08 --> Language Class Initialized
INFO - 2021-05-04 02:50:08 --> Config Class Initialized
INFO - 2021-05-04 02:50:08 --> Loader Class Initialized
INFO - 2021-05-04 02:50:08 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:08 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:08 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:08 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:08 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:08 --> Controller Class Initialized
INFO - 2021-05-04 02:50:08 --> Final output sent to browser
DEBUG - 2021-05-04 02:50:08 --> Total execution time: 0.1319
INFO - 2021-05-04 02:50:22 --> Config Class Initialized
INFO - 2021-05-04 02:50:22 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:22 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:22 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:22 --> URI Class Initialized
INFO - 2021-05-04 02:50:22 --> Router Class Initialized
INFO - 2021-05-04 02:50:22 --> Output Class Initialized
INFO - 2021-05-04 02:50:22 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:22 --> Input Class Initialized
INFO - 2021-05-04 02:50:22 --> Language Class Initialized
INFO - 2021-05-04 02:50:22 --> Language Class Initialized
INFO - 2021-05-04 02:50:22 --> Config Class Initialized
INFO - 2021-05-04 02:50:22 --> Loader Class Initialized
INFO - 2021-05-04 02:50:22 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:22 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:22 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:22 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:22 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:22 --> Controller Class Initialized
INFO - 2021-05-04 02:50:22 --> Final output sent to browser
DEBUG - 2021-05-04 02:50:22 --> Total execution time: 0.1355
INFO - 2021-05-04 02:50:22 --> Config Class Initialized
INFO - 2021-05-04 02:50:22 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:22 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:22 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:22 --> URI Class Initialized
INFO - 2021-05-04 02:50:22 --> Router Class Initialized
INFO - 2021-05-04 02:50:22 --> Output Class Initialized
INFO - 2021-05-04 02:50:22 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:22 --> Input Class Initialized
INFO - 2021-05-04 02:50:22 --> Language Class Initialized
INFO - 2021-05-04 02:50:22 --> Language Class Initialized
INFO - 2021-05-04 02:50:22 --> Config Class Initialized
INFO - 2021-05-04 02:50:22 --> Loader Class Initialized
INFO - 2021-05-04 02:50:22 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:22 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:22 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:22 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:22 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:22 --> Controller Class Initialized
INFO - 2021-05-04 02:50:28 --> Config Class Initialized
INFO - 2021-05-04 02:50:28 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:28 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:28 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:28 --> URI Class Initialized
INFO - 2021-05-04 02:50:28 --> Router Class Initialized
INFO - 2021-05-04 02:50:28 --> Output Class Initialized
INFO - 2021-05-04 02:50:28 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:28 --> Input Class Initialized
INFO - 2021-05-04 02:50:28 --> Language Class Initialized
INFO - 2021-05-04 02:50:28 --> Language Class Initialized
INFO - 2021-05-04 02:50:28 --> Config Class Initialized
INFO - 2021-05-04 02:50:28 --> Loader Class Initialized
INFO - 2021-05-04 02:50:28 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:28 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:28 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:28 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:28 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:28 --> Controller Class Initialized
INFO - 2021-05-04 02:50:28 --> Final output sent to browser
DEBUG - 2021-05-04 02:50:28 --> Total execution time: 0.1267
INFO - 2021-05-04 02:50:42 --> Config Class Initialized
INFO - 2021-05-04 02:50:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:42 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:42 --> URI Class Initialized
INFO - 2021-05-04 02:50:42 --> Router Class Initialized
INFO - 2021-05-04 02:50:42 --> Output Class Initialized
INFO - 2021-05-04 02:50:42 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:42 --> Input Class Initialized
INFO - 2021-05-04 02:50:42 --> Language Class Initialized
INFO - 2021-05-04 02:50:42 --> Language Class Initialized
INFO - 2021-05-04 02:50:42 --> Config Class Initialized
INFO - 2021-05-04 02:50:42 --> Loader Class Initialized
INFO - 2021-05-04 02:50:42 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:42 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:42 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:42 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:42 --> Controller Class Initialized
INFO - 2021-05-04 02:50:42 --> Final output sent to browser
DEBUG - 2021-05-04 02:50:42 --> Total execution time: 0.1408
INFO - 2021-05-04 02:50:42 --> Config Class Initialized
INFO - 2021-05-04 02:50:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:42 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:42 --> URI Class Initialized
INFO - 2021-05-04 02:50:42 --> Router Class Initialized
INFO - 2021-05-04 02:50:42 --> Output Class Initialized
INFO - 2021-05-04 02:50:42 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:42 --> Input Class Initialized
INFO - 2021-05-04 02:50:42 --> Language Class Initialized
INFO - 2021-05-04 02:50:42 --> Language Class Initialized
INFO - 2021-05-04 02:50:42 --> Config Class Initialized
INFO - 2021-05-04 02:50:42 --> Loader Class Initialized
INFO - 2021-05-04 02:50:42 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:42 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:42 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:42 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:42 --> Controller Class Initialized
INFO - 2021-05-04 02:50:44 --> Config Class Initialized
INFO - 2021-05-04 02:50:44 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:44 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:44 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:44 --> URI Class Initialized
INFO - 2021-05-04 02:50:44 --> Router Class Initialized
INFO - 2021-05-04 02:50:44 --> Output Class Initialized
INFO - 2021-05-04 02:50:44 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:44 --> Input Class Initialized
INFO - 2021-05-04 02:50:44 --> Language Class Initialized
INFO - 2021-05-04 02:50:44 --> Language Class Initialized
INFO - 2021-05-04 02:50:44 --> Config Class Initialized
INFO - 2021-05-04 02:50:44 --> Loader Class Initialized
INFO - 2021-05-04 02:50:44 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:44 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:44 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:44 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:44 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:44 --> Controller Class Initialized
INFO - 2021-05-04 02:50:44 --> Final output sent to browser
DEBUG - 2021-05-04 02:50:44 --> Total execution time: 0.1376
INFO - 2021-05-04 02:50:54 --> Config Class Initialized
INFO - 2021-05-04 02:50:54 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:54 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:54 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:54 --> URI Class Initialized
INFO - 2021-05-04 02:50:54 --> Router Class Initialized
INFO - 2021-05-04 02:50:54 --> Output Class Initialized
INFO - 2021-05-04 02:50:54 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:54 --> Input Class Initialized
INFO - 2021-05-04 02:50:54 --> Language Class Initialized
INFO - 2021-05-04 02:50:54 --> Language Class Initialized
INFO - 2021-05-04 02:50:54 --> Config Class Initialized
INFO - 2021-05-04 02:50:54 --> Loader Class Initialized
INFO - 2021-05-04 02:50:54 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:54 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:54 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:54 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:54 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:54 --> Controller Class Initialized
INFO - 2021-05-04 02:50:54 --> Final output sent to browser
DEBUG - 2021-05-04 02:50:54 --> Total execution time: 0.1342
INFO - 2021-05-04 02:50:54 --> Config Class Initialized
INFO - 2021-05-04 02:50:54 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:54 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:54 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:54 --> URI Class Initialized
INFO - 2021-05-04 02:50:54 --> Router Class Initialized
INFO - 2021-05-04 02:50:54 --> Output Class Initialized
INFO - 2021-05-04 02:50:54 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:54 --> Input Class Initialized
INFO - 2021-05-04 02:50:54 --> Language Class Initialized
INFO - 2021-05-04 02:50:54 --> Language Class Initialized
INFO - 2021-05-04 02:50:54 --> Config Class Initialized
INFO - 2021-05-04 02:50:54 --> Loader Class Initialized
INFO - 2021-05-04 02:50:54 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:54 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:54 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:54 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:54 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:54 --> Controller Class Initialized
INFO - 2021-05-04 02:50:57 --> Config Class Initialized
INFO - 2021-05-04 02:50:57 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:50:57 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:50:57 --> Utf8 Class Initialized
INFO - 2021-05-04 02:50:57 --> URI Class Initialized
INFO - 2021-05-04 02:50:57 --> Router Class Initialized
INFO - 2021-05-04 02:50:57 --> Output Class Initialized
INFO - 2021-05-04 02:50:57 --> Security Class Initialized
DEBUG - 2021-05-04 02:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:50:57 --> Input Class Initialized
INFO - 2021-05-04 02:50:57 --> Language Class Initialized
INFO - 2021-05-04 02:50:57 --> Language Class Initialized
INFO - 2021-05-04 02:50:57 --> Config Class Initialized
INFO - 2021-05-04 02:50:57 --> Loader Class Initialized
INFO - 2021-05-04 02:50:57 --> Helper loaded: url_helper
INFO - 2021-05-04 02:50:57 --> Helper loaded: file_helper
INFO - 2021-05-04 02:50:57 --> Helper loaded: form_helper
INFO - 2021-05-04 02:50:57 --> Helper loaded: my_helper
INFO - 2021-05-04 02:50:57 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:50:57 --> Controller Class Initialized
INFO - 2021-05-04 02:50:57 --> Final output sent to browser
DEBUG - 2021-05-04 02:50:57 --> Total execution time: 0.1473
INFO - 2021-05-04 02:51:08 --> Config Class Initialized
INFO - 2021-05-04 02:51:08 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:51:08 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:51:08 --> Utf8 Class Initialized
INFO - 2021-05-04 02:51:08 --> URI Class Initialized
INFO - 2021-05-04 02:51:08 --> Router Class Initialized
INFO - 2021-05-04 02:51:08 --> Output Class Initialized
INFO - 2021-05-04 02:51:08 --> Security Class Initialized
DEBUG - 2021-05-04 02:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:51:08 --> Input Class Initialized
INFO - 2021-05-04 02:51:08 --> Language Class Initialized
INFO - 2021-05-04 02:51:08 --> Language Class Initialized
INFO - 2021-05-04 02:51:08 --> Config Class Initialized
INFO - 2021-05-04 02:51:08 --> Loader Class Initialized
INFO - 2021-05-04 02:51:08 --> Helper loaded: url_helper
INFO - 2021-05-04 02:51:08 --> Helper loaded: file_helper
INFO - 2021-05-04 02:51:08 --> Helper loaded: form_helper
INFO - 2021-05-04 02:51:08 --> Helper loaded: my_helper
INFO - 2021-05-04 02:51:08 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:51:08 --> Controller Class Initialized
INFO - 2021-05-04 02:51:08 --> Final output sent to browser
DEBUG - 2021-05-04 02:51:08 --> Total execution time: 0.1265
INFO - 2021-05-04 02:51:08 --> Config Class Initialized
INFO - 2021-05-04 02:51:08 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:51:08 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:51:08 --> Utf8 Class Initialized
INFO - 2021-05-04 02:51:08 --> URI Class Initialized
INFO - 2021-05-04 02:51:08 --> Router Class Initialized
INFO - 2021-05-04 02:51:08 --> Output Class Initialized
INFO - 2021-05-04 02:51:08 --> Security Class Initialized
DEBUG - 2021-05-04 02:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:51:08 --> Input Class Initialized
INFO - 2021-05-04 02:51:08 --> Language Class Initialized
INFO - 2021-05-04 02:51:08 --> Language Class Initialized
INFO - 2021-05-04 02:51:08 --> Config Class Initialized
INFO - 2021-05-04 02:51:08 --> Loader Class Initialized
INFO - 2021-05-04 02:51:08 --> Helper loaded: url_helper
INFO - 2021-05-04 02:51:08 --> Helper loaded: file_helper
INFO - 2021-05-04 02:51:08 --> Helper loaded: form_helper
INFO - 2021-05-04 02:51:08 --> Helper loaded: my_helper
INFO - 2021-05-04 02:51:08 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:51:08 --> Controller Class Initialized
INFO - 2021-05-04 02:51:25 --> Config Class Initialized
INFO - 2021-05-04 02:51:25 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:51:25 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:51:25 --> Utf8 Class Initialized
INFO - 2021-05-04 02:51:25 --> URI Class Initialized
INFO - 2021-05-04 02:51:25 --> Router Class Initialized
INFO - 2021-05-04 02:51:25 --> Output Class Initialized
INFO - 2021-05-04 02:51:25 --> Security Class Initialized
DEBUG - 2021-05-04 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:51:25 --> Input Class Initialized
INFO - 2021-05-04 02:51:25 --> Language Class Initialized
INFO - 2021-05-04 02:51:25 --> Language Class Initialized
INFO - 2021-05-04 02:51:25 --> Config Class Initialized
INFO - 2021-05-04 02:51:25 --> Loader Class Initialized
INFO - 2021-05-04 02:51:25 --> Helper loaded: url_helper
INFO - 2021-05-04 02:51:25 --> Helper loaded: file_helper
INFO - 2021-05-04 02:51:25 --> Helper loaded: form_helper
INFO - 2021-05-04 02:51:25 --> Helper loaded: my_helper
INFO - 2021-05-04 02:51:25 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:51:25 --> Controller Class Initialized
INFO - 2021-05-04 02:51:25 --> Helper loaded: cookie_helper
INFO - 2021-05-04 02:51:25 --> Config Class Initialized
INFO - 2021-05-04 02:51:25 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:51:25 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:51:25 --> Utf8 Class Initialized
INFO - 2021-05-04 02:51:25 --> URI Class Initialized
INFO - 2021-05-04 02:51:25 --> Router Class Initialized
INFO - 2021-05-04 02:51:25 --> Output Class Initialized
INFO - 2021-05-04 02:51:25 --> Security Class Initialized
DEBUG - 2021-05-04 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:51:25 --> Input Class Initialized
INFO - 2021-05-04 02:51:25 --> Language Class Initialized
INFO - 2021-05-04 02:51:25 --> Language Class Initialized
INFO - 2021-05-04 02:51:25 --> Config Class Initialized
INFO - 2021-05-04 02:51:25 --> Loader Class Initialized
INFO - 2021-05-04 02:51:25 --> Helper loaded: url_helper
INFO - 2021-05-04 02:51:25 --> Helper loaded: file_helper
INFO - 2021-05-04 02:51:25 --> Helper loaded: form_helper
INFO - 2021-05-04 02:51:25 --> Helper loaded: my_helper
INFO - 2021-05-04 02:51:25 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:51:25 --> Controller Class Initialized
DEBUG - 2021-05-04 02:51:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 02:51:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:51:25 --> Final output sent to browser
DEBUG - 2021-05-04 02:51:25 --> Total execution time: 0.1494
INFO - 2021-05-04 02:51:35 --> Config Class Initialized
INFO - 2021-05-04 02:51:35 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:51:35 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:51:35 --> Utf8 Class Initialized
INFO - 2021-05-04 02:51:35 --> URI Class Initialized
INFO - 2021-05-04 02:51:35 --> Router Class Initialized
INFO - 2021-05-04 02:51:35 --> Output Class Initialized
INFO - 2021-05-04 02:51:35 --> Security Class Initialized
DEBUG - 2021-05-04 02:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:51:35 --> Input Class Initialized
INFO - 2021-05-04 02:51:35 --> Language Class Initialized
INFO - 2021-05-04 02:51:35 --> Language Class Initialized
INFO - 2021-05-04 02:51:35 --> Config Class Initialized
INFO - 2021-05-04 02:51:35 --> Loader Class Initialized
INFO - 2021-05-04 02:51:35 --> Helper loaded: url_helper
INFO - 2021-05-04 02:51:35 --> Helper loaded: file_helper
INFO - 2021-05-04 02:51:35 --> Helper loaded: form_helper
INFO - 2021-05-04 02:51:35 --> Helper loaded: my_helper
INFO - 2021-05-04 02:51:35 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:51:35 --> Controller Class Initialized
INFO - 2021-05-04 02:51:35 --> Helper loaded: cookie_helper
INFO - 2021-05-04 02:51:35 --> Final output sent to browser
DEBUG - 2021-05-04 02:51:35 --> Total execution time: 0.1741
INFO - 2021-05-04 02:51:36 --> Config Class Initialized
INFO - 2021-05-04 02:51:36 --> Hooks Class Initialized
DEBUG - 2021-05-04 02:51:36 --> UTF-8 Support Enabled
INFO - 2021-05-04 02:51:36 --> Utf8 Class Initialized
INFO - 2021-05-04 02:51:36 --> URI Class Initialized
INFO - 2021-05-04 02:51:36 --> Router Class Initialized
INFO - 2021-05-04 02:51:36 --> Output Class Initialized
INFO - 2021-05-04 02:51:36 --> Security Class Initialized
DEBUG - 2021-05-04 02:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 02:51:36 --> Input Class Initialized
INFO - 2021-05-04 02:51:36 --> Language Class Initialized
INFO - 2021-05-04 02:51:36 --> Language Class Initialized
INFO - 2021-05-04 02:51:36 --> Config Class Initialized
INFO - 2021-05-04 02:51:36 --> Loader Class Initialized
INFO - 2021-05-04 02:51:36 --> Helper loaded: url_helper
INFO - 2021-05-04 02:51:36 --> Helper loaded: file_helper
INFO - 2021-05-04 02:51:36 --> Helper loaded: form_helper
INFO - 2021-05-04 02:51:36 --> Helper loaded: my_helper
INFO - 2021-05-04 02:51:36 --> Database Driver Class Initialized
DEBUG - 2021-05-04 02:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 02:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 02:51:36 --> Controller Class Initialized
DEBUG - 2021-05-04 02:51:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 02:51:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 02:51:36 --> Final output sent to browser
DEBUG - 2021-05-04 02:51:36 --> Total execution time: 0.1544
INFO - 2021-05-04 03:00:41 --> Config Class Initialized
INFO - 2021-05-04 03:00:41 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:00:41 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:00:41 --> Utf8 Class Initialized
INFO - 2021-05-04 03:00:41 --> URI Class Initialized
INFO - 2021-05-04 03:00:41 --> Router Class Initialized
INFO - 2021-05-04 03:00:41 --> Output Class Initialized
INFO - 2021-05-04 03:00:41 --> Security Class Initialized
DEBUG - 2021-05-04 03:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:00:41 --> Input Class Initialized
INFO - 2021-05-04 03:00:41 --> Language Class Initialized
INFO - 2021-05-04 03:00:41 --> Language Class Initialized
INFO - 2021-05-04 03:00:41 --> Config Class Initialized
INFO - 2021-05-04 03:00:41 --> Loader Class Initialized
INFO - 2021-05-04 03:00:41 --> Helper loaded: url_helper
INFO - 2021-05-04 03:00:41 --> Helper loaded: file_helper
INFO - 2021-05-04 03:00:41 --> Helper loaded: form_helper
INFO - 2021-05-04 03:00:41 --> Helper loaded: my_helper
INFO - 2021-05-04 03:00:41 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:00:41 --> Controller Class Initialized
DEBUG - 2021-05-04 03:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-05-04 03:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:00:41 --> Final output sent to browser
DEBUG - 2021-05-04 03:00:41 --> Total execution time: 0.1078
INFO - 2021-05-04 03:00:47 --> Config Class Initialized
INFO - 2021-05-04 03:00:47 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:00:47 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:00:47 --> Utf8 Class Initialized
INFO - 2021-05-04 03:00:47 --> URI Class Initialized
INFO - 2021-05-04 03:00:47 --> Router Class Initialized
INFO - 2021-05-04 03:00:47 --> Output Class Initialized
INFO - 2021-05-04 03:00:47 --> Security Class Initialized
DEBUG - 2021-05-04 03:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:00:47 --> Input Class Initialized
INFO - 2021-05-04 03:00:47 --> Language Class Initialized
INFO - 2021-05-04 03:00:47 --> Language Class Initialized
INFO - 2021-05-04 03:00:47 --> Config Class Initialized
INFO - 2021-05-04 03:00:47 --> Loader Class Initialized
INFO - 2021-05-04 03:00:47 --> Helper loaded: url_helper
INFO - 2021-05-04 03:00:47 --> Helper loaded: file_helper
INFO - 2021-05-04 03:00:47 --> Helper loaded: form_helper
INFO - 2021-05-04 03:00:47 --> Helper loaded: my_helper
INFO - 2021-05-04 03:00:47 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:00:47 --> Controller Class Initialized
DEBUG - 2021-05-04 03:00:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-05-04 03:00:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:00:47 --> Final output sent to browser
DEBUG - 2021-05-04 03:00:47 --> Total execution time: 0.0976
INFO - 2021-05-04 03:00:48 --> Config Class Initialized
INFO - 2021-05-04 03:00:48 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:00:48 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:00:48 --> Utf8 Class Initialized
INFO - 2021-05-04 03:00:48 --> URI Class Initialized
INFO - 2021-05-04 03:00:48 --> Router Class Initialized
INFO - 2021-05-04 03:00:48 --> Output Class Initialized
INFO - 2021-05-04 03:00:48 --> Security Class Initialized
DEBUG - 2021-05-04 03:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:00:48 --> Input Class Initialized
INFO - 2021-05-04 03:00:48 --> Language Class Initialized
INFO - 2021-05-04 03:00:48 --> Language Class Initialized
INFO - 2021-05-04 03:00:48 --> Config Class Initialized
INFO - 2021-05-04 03:00:48 --> Loader Class Initialized
INFO - 2021-05-04 03:00:48 --> Helper loaded: url_helper
INFO - 2021-05-04 03:00:48 --> Helper loaded: file_helper
INFO - 2021-05-04 03:00:48 --> Helper loaded: form_helper
INFO - 2021-05-04 03:00:48 --> Helper loaded: my_helper
INFO - 2021-05-04 03:00:48 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:00:48 --> Controller Class Initialized
DEBUG - 2021-05-04 03:00:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-05-04 03:00:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:00:48 --> Final output sent to browser
DEBUG - 2021-05-04 03:00:48 --> Total execution time: 0.1290
INFO - 2021-05-04 03:00:50 --> Config Class Initialized
INFO - 2021-05-04 03:00:50 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:00:50 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:00:50 --> Utf8 Class Initialized
INFO - 2021-05-04 03:00:50 --> URI Class Initialized
INFO - 2021-05-04 03:00:50 --> Router Class Initialized
INFO - 2021-05-04 03:00:50 --> Output Class Initialized
INFO - 2021-05-04 03:00:50 --> Security Class Initialized
DEBUG - 2021-05-04 03:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:00:50 --> Input Class Initialized
INFO - 2021-05-04 03:00:50 --> Language Class Initialized
INFO - 2021-05-04 03:00:50 --> Language Class Initialized
INFO - 2021-05-04 03:00:50 --> Config Class Initialized
INFO - 2021-05-04 03:00:50 --> Loader Class Initialized
INFO - 2021-05-04 03:00:50 --> Helper loaded: url_helper
INFO - 2021-05-04 03:00:50 --> Helper loaded: file_helper
INFO - 2021-05-04 03:00:50 --> Helper loaded: form_helper
INFO - 2021-05-04 03:00:50 --> Helper loaded: my_helper
INFO - 2021-05-04 03:00:50 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:00:50 --> Controller Class Initialized
INFO - 2021-05-04 03:00:50 --> Final output sent to browser
DEBUG - 2021-05-04 03:00:50 --> Total execution time: 0.0596
INFO - 2021-05-04 03:00:54 --> Config Class Initialized
INFO - 2021-05-04 03:00:54 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:00:54 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:00:54 --> Utf8 Class Initialized
INFO - 2021-05-04 03:00:54 --> URI Class Initialized
INFO - 2021-05-04 03:00:54 --> Router Class Initialized
INFO - 2021-05-04 03:00:54 --> Output Class Initialized
INFO - 2021-05-04 03:00:54 --> Security Class Initialized
DEBUG - 2021-05-04 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:00:54 --> Input Class Initialized
INFO - 2021-05-04 03:00:54 --> Language Class Initialized
INFO - 2021-05-04 03:00:54 --> Language Class Initialized
INFO - 2021-05-04 03:00:54 --> Config Class Initialized
INFO - 2021-05-04 03:00:54 --> Loader Class Initialized
INFO - 2021-05-04 03:00:54 --> Helper loaded: url_helper
INFO - 2021-05-04 03:00:54 --> Helper loaded: file_helper
INFO - 2021-05-04 03:00:54 --> Helper loaded: form_helper
INFO - 2021-05-04 03:00:54 --> Helper loaded: my_helper
INFO - 2021-05-04 03:00:54 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:00:54 --> Controller Class Initialized
INFO - 2021-05-04 03:00:54 --> Final output sent to browser
DEBUG - 2021-05-04 03:00:54 --> Total execution time: 0.1208
INFO - 2021-05-04 03:00:59 --> Config Class Initialized
INFO - 2021-05-04 03:00:59 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:00:59 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:00:59 --> Utf8 Class Initialized
INFO - 2021-05-04 03:00:59 --> URI Class Initialized
INFO - 2021-05-04 03:00:59 --> Router Class Initialized
INFO - 2021-05-04 03:00:59 --> Output Class Initialized
INFO - 2021-05-04 03:00:59 --> Security Class Initialized
DEBUG - 2021-05-04 03:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:00:59 --> Input Class Initialized
INFO - 2021-05-04 03:00:59 --> Language Class Initialized
INFO - 2021-05-04 03:00:59 --> Language Class Initialized
INFO - 2021-05-04 03:00:59 --> Config Class Initialized
INFO - 2021-05-04 03:00:59 --> Loader Class Initialized
INFO - 2021-05-04 03:00:59 --> Helper loaded: url_helper
INFO - 2021-05-04 03:00:59 --> Helper loaded: file_helper
INFO - 2021-05-04 03:00:59 --> Helper loaded: form_helper
INFO - 2021-05-04 03:00:59 --> Helper loaded: my_helper
INFO - 2021-05-04 03:00:59 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:00:59 --> Controller Class Initialized
DEBUG - 2021-05-04 03:00:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-05-04 03:00:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:00:59 --> Final output sent to browser
DEBUG - 2021-05-04 03:00:59 --> Total execution time: 0.1189
INFO - 2021-05-04 03:01:05 --> Config Class Initialized
INFO - 2021-05-04 03:01:05 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:01:05 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:01:05 --> Utf8 Class Initialized
INFO - 2021-05-04 03:01:05 --> URI Class Initialized
INFO - 2021-05-04 03:01:05 --> Router Class Initialized
INFO - 2021-05-04 03:01:05 --> Output Class Initialized
INFO - 2021-05-04 03:01:05 --> Security Class Initialized
DEBUG - 2021-05-04 03:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:01:05 --> Input Class Initialized
INFO - 2021-05-04 03:01:05 --> Language Class Initialized
INFO - 2021-05-04 03:01:05 --> Language Class Initialized
INFO - 2021-05-04 03:01:05 --> Config Class Initialized
INFO - 2021-05-04 03:01:05 --> Loader Class Initialized
INFO - 2021-05-04 03:01:05 --> Helper loaded: url_helper
INFO - 2021-05-04 03:01:05 --> Helper loaded: file_helper
INFO - 2021-05-04 03:01:05 --> Helper loaded: form_helper
INFO - 2021-05-04 03:01:05 --> Helper loaded: my_helper
INFO - 2021-05-04 03:01:05 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:01:05 --> Controller Class Initialized
INFO - 2021-05-04 03:01:05 --> Final output sent to browser
DEBUG - 2021-05-04 03:01:05 --> Total execution time: 0.0841
INFO - 2021-05-04 03:01:14 --> Config Class Initialized
INFO - 2021-05-04 03:01:14 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:01:14 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:01:14 --> Utf8 Class Initialized
INFO - 2021-05-04 03:01:14 --> URI Class Initialized
INFO - 2021-05-04 03:01:14 --> Router Class Initialized
INFO - 2021-05-04 03:01:14 --> Output Class Initialized
INFO - 2021-05-04 03:01:14 --> Security Class Initialized
DEBUG - 2021-05-04 03:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:01:14 --> Input Class Initialized
INFO - 2021-05-04 03:01:14 --> Language Class Initialized
INFO - 2021-05-04 03:01:14 --> Language Class Initialized
INFO - 2021-05-04 03:01:14 --> Config Class Initialized
INFO - 2021-05-04 03:01:14 --> Loader Class Initialized
INFO - 2021-05-04 03:01:14 --> Helper loaded: url_helper
INFO - 2021-05-04 03:01:14 --> Helper loaded: file_helper
INFO - 2021-05-04 03:01:14 --> Helper loaded: form_helper
INFO - 2021-05-04 03:01:14 --> Helper loaded: my_helper
INFO - 2021-05-04 03:01:14 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:01:14 --> Controller Class Initialized
DEBUG - 2021-05-04 03:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:01:14 --> Final output sent to browser
DEBUG - 2021-05-04 03:01:14 --> Total execution time: 0.0616
INFO - 2021-05-04 03:01:24 --> Config Class Initialized
INFO - 2021-05-04 03:01:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:01:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:01:24 --> Utf8 Class Initialized
INFO - 2021-05-04 03:01:24 --> URI Class Initialized
INFO - 2021-05-04 03:01:24 --> Router Class Initialized
INFO - 2021-05-04 03:01:24 --> Output Class Initialized
INFO - 2021-05-04 03:01:24 --> Security Class Initialized
DEBUG - 2021-05-04 03:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:01:24 --> Input Class Initialized
INFO - 2021-05-04 03:01:24 --> Language Class Initialized
INFO - 2021-05-04 03:01:24 --> Language Class Initialized
INFO - 2021-05-04 03:01:24 --> Config Class Initialized
INFO - 2021-05-04 03:01:24 --> Loader Class Initialized
INFO - 2021-05-04 03:01:24 --> Helper loaded: url_helper
INFO - 2021-05-04 03:01:24 --> Helper loaded: file_helper
INFO - 2021-05-04 03:01:24 --> Helper loaded: form_helper
INFO - 2021-05-04 03:01:24 --> Helper loaded: my_helper
INFO - 2021-05-04 03:01:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:01:24 --> Controller Class Initialized
DEBUG - 2021-05-04 03:01:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:01:24 --> Final output sent to browser
DEBUG - 2021-05-04 03:01:24 --> Total execution time: 0.1639
INFO - 2021-05-04 03:01:58 --> Config Class Initialized
INFO - 2021-05-04 03:01:58 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:01:58 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:01:58 --> Utf8 Class Initialized
INFO - 2021-05-04 03:01:58 --> URI Class Initialized
INFO - 2021-05-04 03:01:58 --> Router Class Initialized
INFO - 2021-05-04 03:01:58 --> Output Class Initialized
INFO - 2021-05-04 03:01:58 --> Security Class Initialized
DEBUG - 2021-05-04 03:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:01:58 --> Input Class Initialized
INFO - 2021-05-04 03:01:58 --> Language Class Initialized
INFO - 2021-05-04 03:01:58 --> Language Class Initialized
INFO - 2021-05-04 03:01:58 --> Config Class Initialized
INFO - 2021-05-04 03:01:58 --> Loader Class Initialized
INFO - 2021-05-04 03:01:58 --> Helper loaded: url_helper
INFO - 2021-05-04 03:01:58 --> Helper loaded: file_helper
INFO - 2021-05-04 03:01:58 --> Helper loaded: form_helper
INFO - 2021-05-04 03:01:58 --> Helper loaded: my_helper
INFO - 2021-05-04 03:01:58 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:01:58 --> Controller Class Initialized
DEBUG - 2021-05-04 03:01:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 03:01:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:01:58 --> Final output sent to browser
DEBUG - 2021-05-04 03:01:58 --> Total execution time: 0.1370
INFO - 2021-05-04 03:02:17 --> Config Class Initialized
INFO - 2021-05-04 03:02:17 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:02:17 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:02:17 --> Utf8 Class Initialized
INFO - 2021-05-04 03:02:17 --> URI Class Initialized
INFO - 2021-05-04 03:02:17 --> Router Class Initialized
INFO - 2021-05-04 03:02:17 --> Output Class Initialized
INFO - 2021-05-04 03:02:17 --> Security Class Initialized
DEBUG - 2021-05-04 03:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:02:17 --> Input Class Initialized
INFO - 2021-05-04 03:02:17 --> Language Class Initialized
INFO - 2021-05-04 03:02:17 --> Language Class Initialized
INFO - 2021-05-04 03:02:17 --> Config Class Initialized
INFO - 2021-05-04 03:02:17 --> Loader Class Initialized
INFO - 2021-05-04 03:02:17 --> Helper loaded: url_helper
INFO - 2021-05-04 03:02:17 --> Helper loaded: file_helper
INFO - 2021-05-04 03:02:17 --> Helper loaded: form_helper
INFO - 2021-05-04 03:02:17 --> Helper loaded: my_helper
INFO - 2021-05-04 03:02:17 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:02:17 --> Controller Class Initialized
INFO - 2021-05-04 03:02:17 --> Final output sent to browser
DEBUG - 2021-05-04 03:02:17 --> Total execution time: 0.0978
INFO - 2021-05-04 03:02:20 --> Config Class Initialized
INFO - 2021-05-04 03:02:20 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:02:20 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:02:20 --> Utf8 Class Initialized
INFO - 2021-05-04 03:02:20 --> URI Class Initialized
INFO - 2021-05-04 03:02:20 --> Router Class Initialized
INFO - 2021-05-04 03:02:20 --> Output Class Initialized
INFO - 2021-05-04 03:02:20 --> Security Class Initialized
DEBUG - 2021-05-04 03:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:02:20 --> Input Class Initialized
INFO - 2021-05-04 03:02:20 --> Language Class Initialized
INFO - 2021-05-04 03:02:20 --> Language Class Initialized
INFO - 2021-05-04 03:02:20 --> Config Class Initialized
INFO - 2021-05-04 03:02:20 --> Loader Class Initialized
INFO - 2021-05-04 03:02:20 --> Helper loaded: url_helper
INFO - 2021-05-04 03:02:20 --> Helper loaded: file_helper
INFO - 2021-05-04 03:02:20 --> Helper loaded: form_helper
INFO - 2021-05-04 03:02:20 --> Helper loaded: my_helper
INFO - 2021-05-04 03:02:20 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:02:20 --> Controller Class Initialized
DEBUG - 2021-05-04 03:02:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:02:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:02:20 --> Final output sent to browser
DEBUG - 2021-05-04 03:02:20 --> Total execution time: 0.0760
INFO - 2021-05-04 03:02:22 --> Config Class Initialized
INFO - 2021-05-04 03:02:22 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:02:22 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:02:22 --> Utf8 Class Initialized
INFO - 2021-05-04 03:02:22 --> URI Class Initialized
INFO - 2021-05-04 03:02:22 --> Router Class Initialized
INFO - 2021-05-04 03:02:22 --> Output Class Initialized
INFO - 2021-05-04 03:02:22 --> Security Class Initialized
DEBUG - 2021-05-04 03:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:02:22 --> Input Class Initialized
INFO - 2021-05-04 03:02:22 --> Language Class Initialized
INFO - 2021-05-04 03:02:22 --> Language Class Initialized
INFO - 2021-05-04 03:02:22 --> Config Class Initialized
INFO - 2021-05-04 03:02:22 --> Loader Class Initialized
INFO - 2021-05-04 03:02:22 --> Helper loaded: url_helper
INFO - 2021-05-04 03:02:22 --> Helper loaded: file_helper
INFO - 2021-05-04 03:02:22 --> Helper loaded: form_helper
INFO - 2021-05-04 03:02:22 --> Helper loaded: my_helper
INFO - 2021-05-04 03:02:22 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:02:22 --> Controller Class Initialized
DEBUG - 2021-05-04 03:02:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:02:22 --> Final output sent to browser
DEBUG - 2021-05-04 03:02:22 --> Total execution time: 0.0775
INFO - 2021-05-04 03:04:51 --> Config Class Initialized
INFO - 2021-05-04 03:04:51 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:04:51 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:04:51 --> Utf8 Class Initialized
INFO - 2021-05-04 03:04:51 --> URI Class Initialized
INFO - 2021-05-04 03:04:51 --> Router Class Initialized
INFO - 2021-05-04 03:04:51 --> Output Class Initialized
INFO - 2021-05-04 03:04:51 --> Security Class Initialized
DEBUG - 2021-05-04 03:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:04:51 --> Input Class Initialized
INFO - 2021-05-04 03:04:51 --> Language Class Initialized
INFO - 2021-05-04 03:04:51 --> Language Class Initialized
INFO - 2021-05-04 03:04:51 --> Config Class Initialized
INFO - 2021-05-04 03:04:51 --> Loader Class Initialized
INFO - 2021-05-04 03:04:51 --> Helper loaded: url_helper
INFO - 2021-05-04 03:04:51 --> Helper loaded: file_helper
INFO - 2021-05-04 03:04:51 --> Helper loaded: form_helper
INFO - 2021-05-04 03:04:51 --> Helper loaded: my_helper
INFO - 2021-05-04 03:04:51 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:04:51 --> Controller Class Initialized
DEBUG - 2021-05-04 03:04:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:04:51 --> Final output sent to browser
DEBUG - 2021-05-04 03:04:51 --> Total execution time: 0.0813
INFO - 2021-05-04 03:05:18 --> Config Class Initialized
INFO - 2021-05-04 03:05:18 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:05:18 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:05:18 --> Utf8 Class Initialized
INFO - 2021-05-04 03:05:18 --> URI Class Initialized
INFO - 2021-05-04 03:05:18 --> Router Class Initialized
INFO - 2021-05-04 03:05:18 --> Output Class Initialized
INFO - 2021-05-04 03:05:18 --> Security Class Initialized
DEBUG - 2021-05-04 03:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:05:18 --> Input Class Initialized
INFO - 2021-05-04 03:05:18 --> Language Class Initialized
INFO - 2021-05-04 03:05:18 --> Language Class Initialized
INFO - 2021-05-04 03:05:18 --> Config Class Initialized
INFO - 2021-05-04 03:05:18 --> Loader Class Initialized
INFO - 2021-05-04 03:05:18 --> Helper loaded: url_helper
INFO - 2021-05-04 03:05:18 --> Helper loaded: file_helper
INFO - 2021-05-04 03:05:18 --> Helper loaded: form_helper
INFO - 2021-05-04 03:05:18 --> Helper loaded: my_helper
INFO - 2021-05-04 03:05:18 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:05:18 --> Controller Class Initialized
DEBUG - 2021-05-04 03:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:05:18 --> Final output sent to browser
DEBUG - 2021-05-04 03:05:18 --> Total execution time: 0.0756
INFO - 2021-05-04 03:05:50 --> Config Class Initialized
INFO - 2021-05-04 03:05:50 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:05:50 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:05:50 --> Utf8 Class Initialized
INFO - 2021-05-04 03:05:50 --> URI Class Initialized
INFO - 2021-05-04 03:05:50 --> Router Class Initialized
INFO - 2021-05-04 03:05:50 --> Output Class Initialized
INFO - 2021-05-04 03:05:50 --> Security Class Initialized
DEBUG - 2021-05-04 03:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:05:50 --> Input Class Initialized
INFO - 2021-05-04 03:05:50 --> Language Class Initialized
INFO - 2021-05-04 03:05:50 --> Language Class Initialized
INFO - 2021-05-04 03:05:50 --> Config Class Initialized
INFO - 2021-05-04 03:05:50 --> Loader Class Initialized
INFO - 2021-05-04 03:05:50 --> Helper loaded: url_helper
INFO - 2021-05-04 03:05:50 --> Helper loaded: file_helper
INFO - 2021-05-04 03:05:50 --> Helper loaded: form_helper
INFO - 2021-05-04 03:05:50 --> Helper loaded: my_helper
INFO - 2021-05-04 03:05:50 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:05:50 --> Controller Class Initialized
DEBUG - 2021-05-04 03:05:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:05:50 --> Final output sent to browser
DEBUG - 2021-05-04 03:05:50 --> Total execution time: 0.0701
INFO - 2021-05-04 03:06:04 --> Config Class Initialized
INFO - 2021-05-04 03:06:04 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:06:04 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:06:04 --> Utf8 Class Initialized
INFO - 2021-05-04 03:06:04 --> URI Class Initialized
INFO - 2021-05-04 03:06:04 --> Router Class Initialized
INFO - 2021-05-04 03:06:04 --> Output Class Initialized
INFO - 2021-05-04 03:06:04 --> Security Class Initialized
DEBUG - 2021-05-04 03:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:06:04 --> Input Class Initialized
INFO - 2021-05-04 03:06:04 --> Language Class Initialized
INFO - 2021-05-04 03:06:04 --> Language Class Initialized
INFO - 2021-05-04 03:06:04 --> Config Class Initialized
INFO - 2021-05-04 03:06:04 --> Loader Class Initialized
INFO - 2021-05-04 03:06:04 --> Helper loaded: url_helper
INFO - 2021-05-04 03:06:04 --> Helper loaded: file_helper
INFO - 2021-05-04 03:06:04 --> Helper loaded: form_helper
INFO - 2021-05-04 03:06:04 --> Helper loaded: my_helper
INFO - 2021-05-04 03:06:04 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:06:04 --> Controller Class Initialized
DEBUG - 2021-05-04 03:06:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:06:04 --> Final output sent to browser
DEBUG - 2021-05-04 03:06:04 --> Total execution time: 0.0617
INFO - 2021-05-04 03:06:17 --> Config Class Initialized
INFO - 2021-05-04 03:06:17 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:06:17 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:06:17 --> Utf8 Class Initialized
INFO - 2021-05-04 03:06:17 --> URI Class Initialized
INFO - 2021-05-04 03:06:17 --> Router Class Initialized
INFO - 2021-05-04 03:06:17 --> Output Class Initialized
INFO - 2021-05-04 03:06:17 --> Security Class Initialized
DEBUG - 2021-05-04 03:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:06:17 --> Input Class Initialized
INFO - 2021-05-04 03:06:17 --> Language Class Initialized
INFO - 2021-05-04 03:06:17 --> Language Class Initialized
INFO - 2021-05-04 03:06:17 --> Config Class Initialized
INFO - 2021-05-04 03:06:17 --> Loader Class Initialized
INFO - 2021-05-04 03:06:17 --> Helper loaded: url_helper
INFO - 2021-05-04 03:06:17 --> Helper loaded: file_helper
INFO - 2021-05-04 03:06:17 --> Helper loaded: form_helper
INFO - 2021-05-04 03:06:17 --> Helper loaded: my_helper
INFO - 2021-05-04 03:06:17 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:06:17 --> Controller Class Initialized
DEBUG - 2021-05-04 03:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:06:17 --> Final output sent to browser
DEBUG - 2021-05-04 03:06:17 --> Total execution time: 0.0673
INFO - 2021-05-04 03:06:30 --> Config Class Initialized
INFO - 2021-05-04 03:06:30 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:06:30 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:06:30 --> Utf8 Class Initialized
INFO - 2021-05-04 03:06:30 --> URI Class Initialized
INFO - 2021-05-04 03:06:30 --> Router Class Initialized
INFO - 2021-05-04 03:06:30 --> Output Class Initialized
INFO - 2021-05-04 03:06:30 --> Security Class Initialized
DEBUG - 2021-05-04 03:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:06:30 --> Input Class Initialized
INFO - 2021-05-04 03:06:30 --> Language Class Initialized
INFO - 2021-05-04 03:06:30 --> Language Class Initialized
INFO - 2021-05-04 03:06:30 --> Config Class Initialized
INFO - 2021-05-04 03:06:30 --> Loader Class Initialized
INFO - 2021-05-04 03:06:30 --> Helper loaded: url_helper
INFO - 2021-05-04 03:06:30 --> Helper loaded: file_helper
INFO - 2021-05-04 03:06:30 --> Helper loaded: form_helper
INFO - 2021-05-04 03:06:30 --> Helper loaded: my_helper
INFO - 2021-05-04 03:06:30 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:06:30 --> Controller Class Initialized
DEBUG - 2021-05-04 03:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:06:30 --> Final output sent to browser
DEBUG - 2021-05-04 03:06:30 --> Total execution time: 0.0849
INFO - 2021-05-04 03:07:13 --> Config Class Initialized
INFO - 2021-05-04 03:07:13 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:07:13 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:07:13 --> Utf8 Class Initialized
INFO - 2021-05-04 03:07:13 --> URI Class Initialized
INFO - 2021-05-04 03:07:13 --> Router Class Initialized
INFO - 2021-05-04 03:07:13 --> Output Class Initialized
INFO - 2021-05-04 03:07:13 --> Security Class Initialized
DEBUG - 2021-05-04 03:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:07:13 --> Input Class Initialized
INFO - 2021-05-04 03:07:13 --> Language Class Initialized
INFO - 2021-05-04 03:07:13 --> Language Class Initialized
INFO - 2021-05-04 03:07:13 --> Config Class Initialized
INFO - 2021-05-04 03:07:13 --> Loader Class Initialized
INFO - 2021-05-04 03:07:13 --> Helper loaded: url_helper
INFO - 2021-05-04 03:07:13 --> Helper loaded: file_helper
INFO - 2021-05-04 03:07:13 --> Helper loaded: form_helper
INFO - 2021-05-04 03:07:13 --> Helper loaded: my_helper
INFO - 2021-05-04 03:07:13 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:07:13 --> Controller Class Initialized
DEBUG - 2021-05-04 03:07:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:07:13 --> Final output sent to browser
DEBUG - 2021-05-04 03:07:13 --> Total execution time: 0.0715
INFO - 2021-05-04 03:07:26 --> Config Class Initialized
INFO - 2021-05-04 03:07:26 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:07:26 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:07:26 --> Utf8 Class Initialized
INFO - 2021-05-04 03:07:26 --> URI Class Initialized
INFO - 2021-05-04 03:07:26 --> Router Class Initialized
INFO - 2021-05-04 03:07:26 --> Output Class Initialized
INFO - 2021-05-04 03:07:26 --> Security Class Initialized
DEBUG - 2021-05-04 03:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:07:26 --> Input Class Initialized
INFO - 2021-05-04 03:07:26 --> Language Class Initialized
INFO - 2021-05-04 03:07:26 --> Language Class Initialized
INFO - 2021-05-04 03:07:26 --> Config Class Initialized
INFO - 2021-05-04 03:07:26 --> Loader Class Initialized
INFO - 2021-05-04 03:07:26 --> Helper loaded: url_helper
INFO - 2021-05-04 03:07:26 --> Helper loaded: file_helper
INFO - 2021-05-04 03:07:26 --> Helper loaded: form_helper
INFO - 2021-05-04 03:07:26 --> Helper loaded: my_helper
INFO - 2021-05-04 03:07:26 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:07:26 --> Controller Class Initialized
DEBUG - 2021-05-04 03:07:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:07:26 --> Final output sent to browser
DEBUG - 2021-05-04 03:07:26 --> Total execution time: 0.0704
INFO - 2021-05-04 03:07:47 --> Config Class Initialized
INFO - 2021-05-04 03:07:47 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:07:47 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:07:47 --> Utf8 Class Initialized
INFO - 2021-05-04 03:07:47 --> URI Class Initialized
INFO - 2021-05-04 03:07:47 --> Router Class Initialized
INFO - 2021-05-04 03:07:47 --> Output Class Initialized
INFO - 2021-05-04 03:07:47 --> Security Class Initialized
DEBUG - 2021-05-04 03:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:07:47 --> Input Class Initialized
INFO - 2021-05-04 03:07:47 --> Language Class Initialized
INFO - 2021-05-04 03:07:47 --> Language Class Initialized
INFO - 2021-05-04 03:07:47 --> Config Class Initialized
INFO - 2021-05-04 03:07:47 --> Loader Class Initialized
INFO - 2021-05-04 03:07:47 --> Helper loaded: url_helper
INFO - 2021-05-04 03:07:47 --> Helper loaded: file_helper
INFO - 2021-05-04 03:07:47 --> Helper loaded: form_helper
INFO - 2021-05-04 03:07:47 --> Helper loaded: my_helper
INFO - 2021-05-04 03:07:47 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:07:47 --> Controller Class Initialized
DEBUG - 2021-05-04 03:07:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:07:47 --> Final output sent to browser
DEBUG - 2021-05-04 03:07:47 --> Total execution time: 0.0737
INFO - 2021-05-04 03:10:42 --> Config Class Initialized
INFO - 2021-05-04 03:10:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:10:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:10:42 --> Utf8 Class Initialized
INFO - 2021-05-04 03:10:42 --> URI Class Initialized
INFO - 2021-05-04 03:10:42 --> Router Class Initialized
INFO - 2021-05-04 03:10:42 --> Output Class Initialized
INFO - 2021-05-04 03:10:42 --> Security Class Initialized
DEBUG - 2021-05-04 03:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:10:42 --> Input Class Initialized
INFO - 2021-05-04 03:10:42 --> Language Class Initialized
INFO - 2021-05-04 03:10:42 --> Language Class Initialized
INFO - 2021-05-04 03:10:42 --> Config Class Initialized
INFO - 2021-05-04 03:10:42 --> Loader Class Initialized
INFO - 2021-05-04 03:10:42 --> Helper loaded: url_helper
INFO - 2021-05-04 03:10:42 --> Helper loaded: file_helper
INFO - 2021-05-04 03:10:42 --> Helper loaded: form_helper
INFO - 2021-05-04 03:10:42 --> Helper loaded: my_helper
INFO - 2021-05-04 03:10:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:10:42 --> Controller Class Initialized
DEBUG - 2021-05-04 03:10:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:10:42 --> Final output sent to browser
DEBUG - 2021-05-04 03:10:42 --> Total execution time: 0.0673
INFO - 2021-05-04 03:11:18 --> Config Class Initialized
INFO - 2021-05-04 03:11:18 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:11:18 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:11:18 --> Utf8 Class Initialized
INFO - 2021-05-04 03:11:18 --> URI Class Initialized
INFO - 2021-05-04 03:11:18 --> Router Class Initialized
INFO - 2021-05-04 03:11:18 --> Output Class Initialized
INFO - 2021-05-04 03:11:18 --> Security Class Initialized
DEBUG - 2021-05-04 03:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:11:18 --> Input Class Initialized
INFO - 2021-05-04 03:11:18 --> Language Class Initialized
INFO - 2021-05-04 03:11:18 --> Language Class Initialized
INFO - 2021-05-04 03:11:18 --> Config Class Initialized
INFO - 2021-05-04 03:11:18 --> Loader Class Initialized
INFO - 2021-05-04 03:11:18 --> Helper loaded: url_helper
INFO - 2021-05-04 03:11:18 --> Helper loaded: file_helper
INFO - 2021-05-04 03:11:18 --> Helper loaded: form_helper
INFO - 2021-05-04 03:11:18 --> Helper loaded: my_helper
INFO - 2021-05-04 03:11:18 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:11:18 --> Controller Class Initialized
DEBUG - 2021-05-04 03:11:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:11:18 --> Final output sent to browser
DEBUG - 2021-05-04 03:11:18 --> Total execution time: 0.0562
INFO - 2021-05-04 03:11:32 --> Config Class Initialized
INFO - 2021-05-04 03:11:32 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:11:32 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:11:32 --> Utf8 Class Initialized
INFO - 2021-05-04 03:11:32 --> URI Class Initialized
INFO - 2021-05-04 03:11:32 --> Router Class Initialized
INFO - 2021-05-04 03:11:32 --> Output Class Initialized
INFO - 2021-05-04 03:11:32 --> Security Class Initialized
DEBUG - 2021-05-04 03:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:11:32 --> Input Class Initialized
INFO - 2021-05-04 03:11:32 --> Language Class Initialized
INFO - 2021-05-04 03:11:32 --> Language Class Initialized
INFO - 2021-05-04 03:11:32 --> Config Class Initialized
INFO - 2021-05-04 03:11:32 --> Loader Class Initialized
INFO - 2021-05-04 03:11:32 --> Helper loaded: url_helper
INFO - 2021-05-04 03:11:32 --> Helper loaded: file_helper
INFO - 2021-05-04 03:11:32 --> Helper loaded: form_helper
INFO - 2021-05-04 03:11:32 --> Helper loaded: my_helper
INFO - 2021-05-04 03:11:32 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:11:32 --> Controller Class Initialized
INFO - 2021-05-04 03:11:32 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:11:32 --> Config Class Initialized
INFO - 2021-05-04 03:11:32 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:11:32 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:11:32 --> Utf8 Class Initialized
INFO - 2021-05-04 03:11:32 --> URI Class Initialized
INFO - 2021-05-04 03:11:32 --> Router Class Initialized
INFO - 2021-05-04 03:11:32 --> Output Class Initialized
INFO - 2021-05-04 03:11:32 --> Security Class Initialized
DEBUG - 2021-05-04 03:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:11:32 --> Input Class Initialized
INFO - 2021-05-04 03:11:32 --> Language Class Initialized
INFO - 2021-05-04 03:11:32 --> Language Class Initialized
INFO - 2021-05-04 03:11:32 --> Config Class Initialized
INFO - 2021-05-04 03:11:32 --> Loader Class Initialized
INFO - 2021-05-04 03:11:32 --> Helper loaded: url_helper
INFO - 2021-05-04 03:11:32 --> Helper loaded: file_helper
INFO - 2021-05-04 03:11:32 --> Helper loaded: form_helper
INFO - 2021-05-04 03:11:32 --> Helper loaded: my_helper
INFO - 2021-05-04 03:11:32 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:11:32 --> Controller Class Initialized
DEBUG - 2021-05-04 03:11:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:11:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:11:32 --> Final output sent to browser
DEBUG - 2021-05-04 03:11:32 --> Total execution time: 0.0658
INFO - 2021-05-04 03:11:38 --> Config Class Initialized
INFO - 2021-05-04 03:11:38 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:11:38 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:11:38 --> Utf8 Class Initialized
INFO - 2021-05-04 03:11:38 --> URI Class Initialized
INFO - 2021-05-04 03:11:38 --> Router Class Initialized
INFO - 2021-05-04 03:11:38 --> Output Class Initialized
INFO - 2021-05-04 03:11:38 --> Security Class Initialized
DEBUG - 2021-05-04 03:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:11:38 --> Input Class Initialized
INFO - 2021-05-04 03:11:38 --> Language Class Initialized
INFO - 2021-05-04 03:11:38 --> Language Class Initialized
INFO - 2021-05-04 03:11:38 --> Config Class Initialized
INFO - 2021-05-04 03:11:38 --> Loader Class Initialized
INFO - 2021-05-04 03:11:38 --> Helper loaded: url_helper
INFO - 2021-05-04 03:11:38 --> Helper loaded: file_helper
INFO - 2021-05-04 03:11:38 --> Helper loaded: form_helper
INFO - 2021-05-04 03:11:38 --> Helper loaded: my_helper
INFO - 2021-05-04 03:11:38 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:11:38 --> Controller Class Initialized
INFO - 2021-05-04 03:11:38 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:11:38 --> Final output sent to browser
DEBUG - 2021-05-04 03:11:38 --> Total execution time: 0.0725
INFO - 2021-05-04 03:11:39 --> Config Class Initialized
INFO - 2021-05-04 03:11:39 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:11:39 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:11:39 --> Utf8 Class Initialized
INFO - 2021-05-04 03:11:39 --> URI Class Initialized
INFO - 2021-05-04 03:11:39 --> Router Class Initialized
INFO - 2021-05-04 03:11:39 --> Output Class Initialized
INFO - 2021-05-04 03:11:39 --> Security Class Initialized
DEBUG - 2021-05-04 03:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:11:39 --> Input Class Initialized
INFO - 2021-05-04 03:11:39 --> Language Class Initialized
INFO - 2021-05-04 03:11:39 --> Language Class Initialized
INFO - 2021-05-04 03:11:39 --> Config Class Initialized
INFO - 2021-05-04 03:11:39 --> Loader Class Initialized
INFO - 2021-05-04 03:11:39 --> Helper loaded: url_helper
INFO - 2021-05-04 03:11:39 --> Helper loaded: file_helper
INFO - 2021-05-04 03:11:39 --> Helper loaded: form_helper
INFO - 2021-05-04 03:11:39 --> Helper loaded: my_helper
INFO - 2021-05-04 03:11:39 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:11:39 --> Controller Class Initialized
DEBUG - 2021-05-04 03:11:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:11:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:11:39 --> Final output sent to browser
DEBUG - 2021-05-04 03:11:39 --> Total execution time: 0.1024
INFO - 2021-05-04 03:11:58 --> Config Class Initialized
INFO - 2021-05-04 03:11:58 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:11:58 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:11:58 --> Utf8 Class Initialized
INFO - 2021-05-04 03:11:58 --> URI Class Initialized
INFO - 2021-05-04 03:11:58 --> Router Class Initialized
INFO - 2021-05-04 03:11:58 --> Output Class Initialized
INFO - 2021-05-04 03:11:58 --> Security Class Initialized
DEBUG - 2021-05-04 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:11:58 --> Input Class Initialized
INFO - 2021-05-04 03:11:58 --> Language Class Initialized
INFO - 2021-05-04 03:11:58 --> Language Class Initialized
INFO - 2021-05-04 03:11:58 --> Config Class Initialized
INFO - 2021-05-04 03:11:58 --> Loader Class Initialized
INFO - 2021-05-04 03:11:58 --> Helper loaded: url_helper
INFO - 2021-05-04 03:11:58 --> Helper loaded: file_helper
INFO - 2021-05-04 03:11:58 --> Helper loaded: form_helper
INFO - 2021-05-04 03:11:58 --> Helper loaded: my_helper
INFO - 2021-05-04 03:11:58 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:11:58 --> Controller Class Initialized
DEBUG - 2021-05-04 03:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 03:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:11:58 --> Final output sent to browser
DEBUG - 2021-05-04 03:11:58 --> Total execution time: 0.0872
INFO - 2021-05-04 03:12:07 --> Config Class Initialized
INFO - 2021-05-04 03:12:07 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:07 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:07 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:07 --> URI Class Initialized
INFO - 2021-05-04 03:12:07 --> Router Class Initialized
INFO - 2021-05-04 03:12:07 --> Output Class Initialized
INFO - 2021-05-04 03:12:07 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:07 --> Input Class Initialized
INFO - 2021-05-04 03:12:07 --> Language Class Initialized
INFO - 2021-05-04 03:12:07 --> Language Class Initialized
INFO - 2021-05-04 03:12:07 --> Config Class Initialized
INFO - 2021-05-04 03:12:07 --> Loader Class Initialized
INFO - 2021-05-04 03:12:07 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:07 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:07 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:07 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:07 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:07 --> Controller Class Initialized
INFO - 2021-05-04 03:12:08 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:08 --> Total execution time: 0.1290
INFO - 2021-05-04 03:12:11 --> Config Class Initialized
INFO - 2021-05-04 03:12:11 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:11 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:11 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:11 --> URI Class Initialized
INFO - 2021-05-04 03:12:11 --> Router Class Initialized
INFO - 2021-05-04 03:12:11 --> Output Class Initialized
INFO - 2021-05-04 03:12:11 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:11 --> Input Class Initialized
INFO - 2021-05-04 03:12:11 --> Language Class Initialized
INFO - 2021-05-04 03:12:11 --> Language Class Initialized
INFO - 2021-05-04 03:12:11 --> Config Class Initialized
INFO - 2021-05-04 03:12:11 --> Loader Class Initialized
INFO - 2021-05-04 03:12:11 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:11 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:11 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:11 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:11 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:11 --> Controller Class Initialized
DEBUG - 2021-05-04 03:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-05-04 03:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:12:11 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:11 --> Total execution time: 0.0760
INFO - 2021-05-04 03:12:12 --> Config Class Initialized
INFO - 2021-05-04 03:12:12 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:12 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:12 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:12 --> URI Class Initialized
INFO - 2021-05-04 03:12:12 --> Router Class Initialized
INFO - 2021-05-04 03:12:12 --> Output Class Initialized
INFO - 2021-05-04 03:12:12 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:12 --> Input Class Initialized
INFO - 2021-05-04 03:12:12 --> Language Class Initialized
INFO - 2021-05-04 03:12:12 --> Language Class Initialized
INFO - 2021-05-04 03:12:12 --> Config Class Initialized
INFO - 2021-05-04 03:12:12 --> Loader Class Initialized
INFO - 2021-05-04 03:12:12 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:12 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:12 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:12 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:12 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:12 --> Controller Class Initialized
DEBUG - 2021-05-04 03:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-05-04 03:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:12:12 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:12 --> Total execution time: 0.0650
INFO - 2021-05-04 03:12:19 --> Config Class Initialized
INFO - 2021-05-04 03:12:19 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:19 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:19 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:19 --> URI Class Initialized
INFO - 2021-05-04 03:12:19 --> Router Class Initialized
INFO - 2021-05-04 03:12:19 --> Output Class Initialized
INFO - 2021-05-04 03:12:19 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:19 --> Input Class Initialized
INFO - 2021-05-04 03:12:19 --> Language Class Initialized
INFO - 2021-05-04 03:12:19 --> Language Class Initialized
INFO - 2021-05-04 03:12:19 --> Config Class Initialized
INFO - 2021-05-04 03:12:19 --> Loader Class Initialized
INFO - 2021-05-04 03:12:19 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:19 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:19 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:19 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:19 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:19 --> Controller Class Initialized
INFO - 2021-05-04 03:12:19 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:19 --> Total execution time: 0.0762
INFO - 2021-05-04 03:12:24 --> Config Class Initialized
INFO - 2021-05-04 03:12:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:24 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:24 --> URI Class Initialized
INFO - 2021-05-04 03:12:24 --> Router Class Initialized
INFO - 2021-05-04 03:12:24 --> Output Class Initialized
INFO - 2021-05-04 03:12:24 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:24 --> Input Class Initialized
INFO - 2021-05-04 03:12:24 --> Language Class Initialized
INFO - 2021-05-04 03:12:24 --> Language Class Initialized
INFO - 2021-05-04 03:12:24 --> Config Class Initialized
INFO - 2021-05-04 03:12:24 --> Loader Class Initialized
INFO - 2021-05-04 03:12:24 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:24 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:24 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:24 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:24 --> Controller Class Initialized
INFO - 2021-05-04 03:12:24 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:24 --> Total execution time: 0.1167
INFO - 2021-05-04 03:12:28 --> Config Class Initialized
INFO - 2021-05-04 03:12:28 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:28 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:28 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:28 --> URI Class Initialized
INFO - 2021-05-04 03:12:28 --> Router Class Initialized
INFO - 2021-05-04 03:12:28 --> Output Class Initialized
INFO - 2021-05-04 03:12:28 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:28 --> Input Class Initialized
INFO - 2021-05-04 03:12:28 --> Language Class Initialized
INFO - 2021-05-04 03:12:28 --> Language Class Initialized
INFO - 2021-05-04 03:12:28 --> Config Class Initialized
INFO - 2021-05-04 03:12:28 --> Loader Class Initialized
INFO - 2021-05-04 03:12:28 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:28 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:28 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:28 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:28 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:28 --> Controller Class Initialized
DEBUG - 2021-05-04 03:12:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-05-04 03:12:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:12:28 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:28 --> Total execution time: 0.0787
INFO - 2021-05-04 03:12:37 --> Config Class Initialized
INFO - 2021-05-04 03:12:37 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:37 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:37 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:37 --> URI Class Initialized
INFO - 2021-05-04 03:12:37 --> Router Class Initialized
INFO - 2021-05-04 03:12:37 --> Output Class Initialized
INFO - 2021-05-04 03:12:37 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:37 --> Input Class Initialized
INFO - 2021-05-04 03:12:37 --> Language Class Initialized
INFO - 2021-05-04 03:12:37 --> Language Class Initialized
INFO - 2021-05-04 03:12:37 --> Config Class Initialized
INFO - 2021-05-04 03:12:37 --> Loader Class Initialized
INFO - 2021-05-04 03:12:37 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:37 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:37 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:37 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:37 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:37 --> Controller Class Initialized
INFO - 2021-05-04 03:12:37 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:37 --> Total execution time: 0.1359
INFO - 2021-05-04 03:12:40 --> Config Class Initialized
INFO - 2021-05-04 03:12:40 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:40 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:40 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:40 --> URI Class Initialized
INFO - 2021-05-04 03:12:40 --> Router Class Initialized
INFO - 2021-05-04 03:12:40 --> Output Class Initialized
INFO - 2021-05-04 03:12:40 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:40 --> Input Class Initialized
INFO - 2021-05-04 03:12:40 --> Language Class Initialized
INFO - 2021-05-04 03:12:40 --> Language Class Initialized
INFO - 2021-05-04 03:12:40 --> Config Class Initialized
INFO - 2021-05-04 03:12:40 --> Loader Class Initialized
INFO - 2021-05-04 03:12:40 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:40 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:40 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:40 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:40 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:40 --> Controller Class Initialized
DEBUG - 2021-05-04 03:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:12:40 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:40 --> Total execution time: 0.0896
INFO - 2021-05-04 03:12:49 --> Config Class Initialized
INFO - 2021-05-04 03:12:49 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:12:49 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:12:49 --> Utf8 Class Initialized
INFO - 2021-05-04 03:12:49 --> URI Class Initialized
INFO - 2021-05-04 03:12:49 --> Router Class Initialized
INFO - 2021-05-04 03:12:49 --> Output Class Initialized
INFO - 2021-05-04 03:12:49 --> Security Class Initialized
DEBUG - 2021-05-04 03:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:12:49 --> Input Class Initialized
INFO - 2021-05-04 03:12:49 --> Language Class Initialized
INFO - 2021-05-04 03:12:49 --> Language Class Initialized
INFO - 2021-05-04 03:12:49 --> Config Class Initialized
INFO - 2021-05-04 03:12:49 --> Loader Class Initialized
INFO - 2021-05-04 03:12:49 --> Helper loaded: url_helper
INFO - 2021-05-04 03:12:49 --> Helper loaded: file_helper
INFO - 2021-05-04 03:12:49 --> Helper loaded: form_helper
INFO - 2021-05-04 03:12:49 --> Helper loaded: my_helper
INFO - 2021-05-04 03:12:49 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:12:49 --> Controller Class Initialized
DEBUG - 2021-05-04 03:12:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-05-04 03:12:49 --> Final output sent to browser
DEBUG - 2021-05-04 03:12:49 --> Total execution time: 0.1861
INFO - 2021-05-04 03:13:24 --> Config Class Initialized
INFO - 2021-05-04 03:13:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:13:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:13:24 --> Utf8 Class Initialized
INFO - 2021-05-04 03:13:24 --> URI Class Initialized
INFO - 2021-05-04 03:13:24 --> Router Class Initialized
INFO - 2021-05-04 03:13:24 --> Output Class Initialized
INFO - 2021-05-04 03:13:24 --> Security Class Initialized
DEBUG - 2021-05-04 03:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:13:24 --> Input Class Initialized
INFO - 2021-05-04 03:13:24 --> Language Class Initialized
INFO - 2021-05-04 03:13:24 --> Language Class Initialized
INFO - 2021-05-04 03:13:24 --> Config Class Initialized
INFO - 2021-05-04 03:13:24 --> Loader Class Initialized
INFO - 2021-05-04 03:13:24 --> Helper loaded: url_helper
INFO - 2021-05-04 03:13:24 --> Helper loaded: file_helper
INFO - 2021-05-04 03:13:24 --> Helper loaded: form_helper
INFO - 2021-05-04 03:13:24 --> Helper loaded: my_helper
INFO - 2021-05-04 03:13:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:13:24 --> Controller Class Initialized
INFO - 2021-05-04 03:13:24 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:13:24 --> Config Class Initialized
INFO - 2021-05-04 03:13:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:13:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:13:24 --> Utf8 Class Initialized
INFO - 2021-05-04 03:13:24 --> URI Class Initialized
INFO - 2021-05-04 03:13:24 --> Router Class Initialized
INFO - 2021-05-04 03:13:24 --> Output Class Initialized
INFO - 2021-05-04 03:13:24 --> Security Class Initialized
DEBUG - 2021-05-04 03:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:13:24 --> Input Class Initialized
INFO - 2021-05-04 03:13:24 --> Language Class Initialized
INFO - 2021-05-04 03:13:24 --> Language Class Initialized
INFO - 2021-05-04 03:13:24 --> Config Class Initialized
INFO - 2021-05-04 03:13:24 --> Loader Class Initialized
INFO - 2021-05-04 03:13:24 --> Helper loaded: url_helper
INFO - 2021-05-04 03:13:24 --> Helper loaded: file_helper
INFO - 2021-05-04 03:13:24 --> Helper loaded: form_helper
INFO - 2021-05-04 03:13:24 --> Helper loaded: my_helper
INFO - 2021-05-04 03:13:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:13:24 --> Controller Class Initialized
DEBUG - 2021-05-04 03:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:13:24 --> Final output sent to browser
DEBUG - 2021-05-04 03:13:24 --> Total execution time: 0.0652
INFO - 2021-05-04 03:13:29 --> Config Class Initialized
INFO - 2021-05-04 03:13:29 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:13:29 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:13:29 --> Utf8 Class Initialized
INFO - 2021-05-04 03:13:29 --> URI Class Initialized
INFO - 2021-05-04 03:13:29 --> Router Class Initialized
INFO - 2021-05-04 03:13:29 --> Output Class Initialized
INFO - 2021-05-04 03:13:29 --> Security Class Initialized
DEBUG - 2021-05-04 03:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:13:29 --> Input Class Initialized
INFO - 2021-05-04 03:13:29 --> Language Class Initialized
INFO - 2021-05-04 03:13:29 --> Language Class Initialized
INFO - 2021-05-04 03:13:29 --> Config Class Initialized
INFO - 2021-05-04 03:13:29 --> Loader Class Initialized
INFO - 2021-05-04 03:13:29 --> Helper loaded: url_helper
INFO - 2021-05-04 03:13:29 --> Helper loaded: file_helper
INFO - 2021-05-04 03:13:29 --> Helper loaded: form_helper
INFO - 2021-05-04 03:13:29 --> Helper loaded: my_helper
INFO - 2021-05-04 03:13:29 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:13:29 --> Controller Class Initialized
INFO - 2021-05-04 03:13:29 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:13:29 --> Final output sent to browser
DEBUG - 2021-05-04 03:13:29 --> Total execution time: 0.0762
INFO - 2021-05-04 03:13:30 --> Config Class Initialized
INFO - 2021-05-04 03:13:30 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:13:30 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:13:30 --> Utf8 Class Initialized
INFO - 2021-05-04 03:13:30 --> URI Class Initialized
INFO - 2021-05-04 03:13:30 --> Router Class Initialized
INFO - 2021-05-04 03:13:30 --> Output Class Initialized
INFO - 2021-05-04 03:13:30 --> Security Class Initialized
DEBUG - 2021-05-04 03:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:13:30 --> Input Class Initialized
INFO - 2021-05-04 03:13:30 --> Language Class Initialized
INFO - 2021-05-04 03:13:30 --> Language Class Initialized
INFO - 2021-05-04 03:13:30 --> Config Class Initialized
INFO - 2021-05-04 03:13:30 --> Loader Class Initialized
INFO - 2021-05-04 03:13:30 --> Helper loaded: url_helper
INFO - 2021-05-04 03:13:30 --> Helper loaded: file_helper
INFO - 2021-05-04 03:13:30 --> Helper loaded: form_helper
INFO - 2021-05-04 03:13:30 --> Helper loaded: my_helper
INFO - 2021-05-04 03:13:30 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:13:30 --> Controller Class Initialized
DEBUG - 2021-05-04 03:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:13:30 --> Final output sent to browser
DEBUG - 2021-05-04 03:13:30 --> Total execution time: 0.0918
INFO - 2021-05-04 03:13:32 --> Config Class Initialized
INFO - 2021-05-04 03:13:32 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:13:32 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:13:32 --> Utf8 Class Initialized
INFO - 2021-05-04 03:13:32 --> URI Class Initialized
INFO - 2021-05-04 03:13:32 --> Router Class Initialized
INFO - 2021-05-04 03:13:32 --> Output Class Initialized
INFO - 2021-05-04 03:13:32 --> Security Class Initialized
DEBUG - 2021-05-04 03:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:13:32 --> Input Class Initialized
INFO - 2021-05-04 03:13:32 --> Language Class Initialized
INFO - 2021-05-04 03:13:32 --> Language Class Initialized
INFO - 2021-05-04 03:13:32 --> Config Class Initialized
INFO - 2021-05-04 03:13:32 --> Loader Class Initialized
INFO - 2021-05-04 03:13:32 --> Helper loaded: url_helper
INFO - 2021-05-04 03:13:32 --> Helper loaded: file_helper
INFO - 2021-05-04 03:13:32 --> Helper loaded: form_helper
INFO - 2021-05-04 03:13:32 --> Helper loaded: my_helper
INFO - 2021-05-04 03:13:32 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:13:32 --> Controller Class Initialized
DEBUG - 2021-05-04 03:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:13:32 --> Final output sent to browser
DEBUG - 2021-05-04 03:13:32 --> Total execution time: 0.0793
INFO - 2021-05-04 03:13:36 --> Config Class Initialized
INFO - 2021-05-04 03:13:36 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:13:36 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:13:36 --> Utf8 Class Initialized
INFO - 2021-05-04 03:13:36 --> URI Class Initialized
INFO - 2021-05-04 03:13:36 --> Router Class Initialized
INFO - 2021-05-04 03:13:36 --> Output Class Initialized
INFO - 2021-05-04 03:13:36 --> Security Class Initialized
DEBUG - 2021-05-04 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:13:36 --> Input Class Initialized
INFO - 2021-05-04 03:13:36 --> Language Class Initialized
INFO - 2021-05-04 03:13:36 --> Language Class Initialized
INFO - 2021-05-04 03:13:36 --> Config Class Initialized
INFO - 2021-05-04 03:13:36 --> Loader Class Initialized
INFO - 2021-05-04 03:13:37 --> Helper loaded: url_helper
INFO - 2021-05-04 03:13:37 --> Helper loaded: file_helper
INFO - 2021-05-04 03:13:37 --> Helper loaded: form_helper
INFO - 2021-05-04 03:13:37 --> Helper loaded: my_helper
INFO - 2021-05-04 03:13:37 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:13:37 --> Controller Class Initialized
DEBUG - 2021-05-04 03:13:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:13:37 --> Final output sent to browser
DEBUG - 2021-05-04 03:13:37 --> Total execution time: 0.1042
INFO - 2021-05-04 03:15:08 --> Config Class Initialized
INFO - 2021-05-04 03:15:08 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:15:08 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:15:08 --> Utf8 Class Initialized
INFO - 2021-05-04 03:15:08 --> URI Class Initialized
INFO - 2021-05-04 03:15:08 --> Router Class Initialized
INFO - 2021-05-04 03:15:08 --> Output Class Initialized
INFO - 2021-05-04 03:15:08 --> Security Class Initialized
DEBUG - 2021-05-04 03:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:15:08 --> Input Class Initialized
INFO - 2021-05-04 03:15:08 --> Language Class Initialized
INFO - 2021-05-04 03:15:08 --> Language Class Initialized
INFO - 2021-05-04 03:15:08 --> Config Class Initialized
INFO - 2021-05-04 03:15:08 --> Loader Class Initialized
INFO - 2021-05-04 03:15:08 --> Helper loaded: url_helper
INFO - 2021-05-04 03:15:08 --> Helper loaded: file_helper
INFO - 2021-05-04 03:15:08 --> Helper loaded: form_helper
INFO - 2021-05-04 03:15:08 --> Helper loaded: my_helper
INFO - 2021-05-04 03:15:08 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:15:08 --> Controller Class Initialized
DEBUG - 2021-05-04 03:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:15:08 --> Final output sent to browser
DEBUG - 2021-05-04 03:15:08 --> Total execution time: 0.0547
INFO - 2021-05-04 03:15:34 --> Config Class Initialized
INFO - 2021-05-04 03:15:34 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:15:34 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:15:34 --> Utf8 Class Initialized
INFO - 2021-05-04 03:15:34 --> URI Class Initialized
INFO - 2021-05-04 03:15:34 --> Router Class Initialized
INFO - 2021-05-04 03:15:34 --> Output Class Initialized
INFO - 2021-05-04 03:15:34 --> Security Class Initialized
DEBUG - 2021-05-04 03:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:15:34 --> Input Class Initialized
INFO - 2021-05-04 03:15:34 --> Language Class Initialized
INFO - 2021-05-04 03:15:34 --> Language Class Initialized
INFO - 2021-05-04 03:15:34 --> Config Class Initialized
INFO - 2021-05-04 03:15:34 --> Loader Class Initialized
INFO - 2021-05-04 03:15:34 --> Helper loaded: url_helper
INFO - 2021-05-04 03:15:34 --> Helper loaded: file_helper
INFO - 2021-05-04 03:15:34 --> Helper loaded: form_helper
INFO - 2021-05-04 03:15:34 --> Helper loaded: my_helper
INFO - 2021-05-04 03:15:34 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:15:34 --> Controller Class Initialized
DEBUG - 2021-05-04 03:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:15:34 --> Final output sent to browser
DEBUG - 2021-05-04 03:15:34 --> Total execution time: 0.0538
INFO - 2021-05-04 03:15:49 --> Config Class Initialized
INFO - 2021-05-04 03:15:49 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:15:49 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:15:49 --> Utf8 Class Initialized
INFO - 2021-05-04 03:15:49 --> URI Class Initialized
INFO - 2021-05-04 03:15:49 --> Router Class Initialized
INFO - 2021-05-04 03:15:49 --> Output Class Initialized
INFO - 2021-05-04 03:15:49 --> Security Class Initialized
DEBUG - 2021-05-04 03:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:15:49 --> Input Class Initialized
INFO - 2021-05-04 03:15:49 --> Language Class Initialized
INFO - 2021-05-04 03:15:49 --> Language Class Initialized
INFO - 2021-05-04 03:15:49 --> Config Class Initialized
INFO - 2021-05-04 03:15:49 --> Loader Class Initialized
INFO - 2021-05-04 03:15:49 --> Helper loaded: url_helper
INFO - 2021-05-04 03:15:49 --> Helper loaded: file_helper
INFO - 2021-05-04 03:15:49 --> Helper loaded: form_helper
INFO - 2021-05-04 03:15:49 --> Helper loaded: my_helper
INFO - 2021-05-04 03:15:49 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:15:49 --> Controller Class Initialized
DEBUG - 2021-05-04 03:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:15:49 --> Final output sent to browser
DEBUG - 2021-05-04 03:15:49 --> Total execution time: 0.0779
INFO - 2021-05-04 03:16:06 --> Config Class Initialized
INFO - 2021-05-04 03:16:06 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:16:06 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:16:06 --> Utf8 Class Initialized
INFO - 2021-05-04 03:16:06 --> URI Class Initialized
INFO - 2021-05-04 03:16:06 --> Router Class Initialized
INFO - 2021-05-04 03:16:06 --> Output Class Initialized
INFO - 2021-05-04 03:16:06 --> Security Class Initialized
DEBUG - 2021-05-04 03:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:16:06 --> Input Class Initialized
INFO - 2021-05-04 03:16:06 --> Language Class Initialized
INFO - 2021-05-04 03:16:06 --> Language Class Initialized
INFO - 2021-05-04 03:16:06 --> Config Class Initialized
INFO - 2021-05-04 03:16:06 --> Loader Class Initialized
INFO - 2021-05-04 03:16:06 --> Helper loaded: url_helper
INFO - 2021-05-04 03:16:06 --> Helper loaded: file_helper
INFO - 2021-05-04 03:16:06 --> Helper loaded: form_helper
INFO - 2021-05-04 03:16:06 --> Helper loaded: my_helper
INFO - 2021-05-04 03:16:06 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:16:06 --> Controller Class Initialized
DEBUG - 2021-05-04 03:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:16:07 --> Final output sent to browser
DEBUG - 2021-05-04 03:16:07 --> Total execution time: 0.0621
INFO - 2021-05-04 03:16:13 --> Config Class Initialized
INFO - 2021-05-04 03:16:13 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:16:13 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:16:13 --> Utf8 Class Initialized
INFO - 2021-05-04 03:16:13 --> URI Class Initialized
INFO - 2021-05-04 03:16:13 --> Router Class Initialized
INFO - 2021-05-04 03:16:13 --> Output Class Initialized
INFO - 2021-05-04 03:16:13 --> Security Class Initialized
DEBUG - 2021-05-04 03:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:16:13 --> Input Class Initialized
INFO - 2021-05-04 03:16:13 --> Language Class Initialized
INFO - 2021-05-04 03:16:13 --> Language Class Initialized
INFO - 2021-05-04 03:16:13 --> Config Class Initialized
INFO - 2021-05-04 03:16:13 --> Loader Class Initialized
INFO - 2021-05-04 03:16:13 --> Helper loaded: url_helper
INFO - 2021-05-04 03:16:13 --> Helper loaded: file_helper
INFO - 2021-05-04 03:16:13 --> Helper loaded: form_helper
INFO - 2021-05-04 03:16:13 --> Helper loaded: my_helper
INFO - 2021-05-04 03:16:13 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:16:13 --> Controller Class Initialized
DEBUG - 2021-05-04 03:16:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:16:13 --> Final output sent to browser
DEBUG - 2021-05-04 03:16:13 --> Total execution time: 0.0562
INFO - 2021-05-04 03:16:35 --> Config Class Initialized
INFO - 2021-05-04 03:16:35 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:16:35 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:16:35 --> Utf8 Class Initialized
INFO - 2021-05-04 03:16:35 --> URI Class Initialized
INFO - 2021-05-04 03:16:35 --> Router Class Initialized
INFO - 2021-05-04 03:16:35 --> Output Class Initialized
INFO - 2021-05-04 03:16:35 --> Security Class Initialized
DEBUG - 2021-05-04 03:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:16:35 --> Input Class Initialized
INFO - 2021-05-04 03:16:35 --> Language Class Initialized
INFO - 2021-05-04 03:16:35 --> Language Class Initialized
INFO - 2021-05-04 03:16:35 --> Config Class Initialized
INFO - 2021-05-04 03:16:35 --> Loader Class Initialized
INFO - 2021-05-04 03:16:35 --> Helper loaded: url_helper
INFO - 2021-05-04 03:16:35 --> Helper loaded: file_helper
INFO - 2021-05-04 03:16:35 --> Helper loaded: form_helper
INFO - 2021-05-04 03:16:35 --> Helper loaded: my_helper
INFO - 2021-05-04 03:16:35 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:16:35 --> Controller Class Initialized
INFO - 2021-05-04 03:16:35 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:16:35 --> Config Class Initialized
INFO - 2021-05-04 03:16:35 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:16:35 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:16:35 --> Utf8 Class Initialized
INFO - 2021-05-04 03:16:35 --> URI Class Initialized
INFO - 2021-05-04 03:16:35 --> Router Class Initialized
INFO - 2021-05-04 03:16:35 --> Output Class Initialized
INFO - 2021-05-04 03:16:35 --> Security Class Initialized
DEBUG - 2021-05-04 03:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:16:35 --> Input Class Initialized
INFO - 2021-05-04 03:16:35 --> Language Class Initialized
INFO - 2021-05-04 03:16:35 --> Language Class Initialized
INFO - 2021-05-04 03:16:35 --> Config Class Initialized
INFO - 2021-05-04 03:16:35 --> Loader Class Initialized
INFO - 2021-05-04 03:16:35 --> Helper loaded: url_helper
INFO - 2021-05-04 03:16:35 --> Helper loaded: file_helper
INFO - 2021-05-04 03:16:35 --> Helper loaded: form_helper
INFO - 2021-05-04 03:16:35 --> Helper loaded: my_helper
INFO - 2021-05-04 03:16:35 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:16:35 --> Controller Class Initialized
DEBUG - 2021-05-04 03:16:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:16:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:16:35 --> Final output sent to browser
DEBUG - 2021-05-04 03:16:35 --> Total execution time: 0.0664
INFO - 2021-05-04 03:16:39 --> Config Class Initialized
INFO - 2021-05-04 03:16:39 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:16:39 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:16:39 --> Utf8 Class Initialized
INFO - 2021-05-04 03:16:39 --> URI Class Initialized
INFO - 2021-05-04 03:16:39 --> Router Class Initialized
INFO - 2021-05-04 03:16:39 --> Output Class Initialized
INFO - 2021-05-04 03:16:39 --> Security Class Initialized
DEBUG - 2021-05-04 03:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:16:39 --> Input Class Initialized
INFO - 2021-05-04 03:16:39 --> Language Class Initialized
INFO - 2021-05-04 03:16:39 --> Language Class Initialized
INFO - 2021-05-04 03:16:39 --> Config Class Initialized
INFO - 2021-05-04 03:16:39 --> Loader Class Initialized
INFO - 2021-05-04 03:16:39 --> Helper loaded: url_helper
INFO - 2021-05-04 03:16:39 --> Helper loaded: file_helper
INFO - 2021-05-04 03:16:39 --> Helper loaded: form_helper
INFO - 2021-05-04 03:16:39 --> Helper loaded: my_helper
INFO - 2021-05-04 03:16:39 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:16:39 --> Controller Class Initialized
INFO - 2021-05-04 03:16:39 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:16:39 --> Final output sent to browser
DEBUG - 2021-05-04 03:16:39 --> Total execution time: 0.0636
INFO - 2021-05-04 03:16:40 --> Config Class Initialized
INFO - 2021-05-04 03:16:40 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:16:40 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:16:40 --> Utf8 Class Initialized
INFO - 2021-05-04 03:16:40 --> URI Class Initialized
INFO - 2021-05-04 03:16:40 --> Router Class Initialized
INFO - 2021-05-04 03:16:40 --> Output Class Initialized
INFO - 2021-05-04 03:16:40 --> Security Class Initialized
DEBUG - 2021-05-04 03:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:16:40 --> Input Class Initialized
INFO - 2021-05-04 03:16:40 --> Language Class Initialized
INFO - 2021-05-04 03:16:40 --> Language Class Initialized
INFO - 2021-05-04 03:16:40 --> Config Class Initialized
INFO - 2021-05-04 03:16:40 --> Loader Class Initialized
INFO - 2021-05-04 03:16:40 --> Helper loaded: url_helper
INFO - 2021-05-04 03:16:40 --> Helper loaded: file_helper
INFO - 2021-05-04 03:16:40 --> Helper loaded: form_helper
INFO - 2021-05-04 03:16:40 --> Helper loaded: my_helper
INFO - 2021-05-04 03:16:40 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:16:40 --> Controller Class Initialized
DEBUG - 2021-05-04 03:16:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:16:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:16:40 --> Final output sent to browser
DEBUG - 2021-05-04 03:16:40 --> Total execution time: 0.0864
INFO - 2021-05-04 03:16:42 --> Config Class Initialized
INFO - 2021-05-04 03:16:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:16:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:16:42 --> Utf8 Class Initialized
INFO - 2021-05-04 03:16:42 --> URI Class Initialized
INFO - 2021-05-04 03:16:42 --> Router Class Initialized
INFO - 2021-05-04 03:16:42 --> Output Class Initialized
INFO - 2021-05-04 03:16:42 --> Security Class Initialized
DEBUG - 2021-05-04 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:16:42 --> Input Class Initialized
INFO - 2021-05-04 03:16:42 --> Language Class Initialized
INFO - 2021-05-04 03:16:42 --> Language Class Initialized
INFO - 2021-05-04 03:16:42 --> Config Class Initialized
INFO - 2021-05-04 03:16:42 --> Loader Class Initialized
INFO - 2021-05-04 03:16:42 --> Helper loaded: url_helper
INFO - 2021-05-04 03:16:42 --> Helper loaded: file_helper
INFO - 2021-05-04 03:16:42 --> Helper loaded: form_helper
INFO - 2021-05-04 03:16:42 --> Helper loaded: my_helper
INFO - 2021-05-04 03:16:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:16:42 --> Controller Class Initialized
DEBUG - 2021-05-04 03:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:16:42 --> Final output sent to browser
DEBUG - 2021-05-04 03:16:42 --> Total execution time: 0.0822
INFO - 2021-05-04 03:16:44 --> Config Class Initialized
INFO - 2021-05-04 03:16:44 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:16:44 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:16:44 --> Utf8 Class Initialized
INFO - 2021-05-04 03:16:44 --> URI Class Initialized
INFO - 2021-05-04 03:16:44 --> Router Class Initialized
INFO - 2021-05-04 03:16:44 --> Output Class Initialized
INFO - 2021-05-04 03:16:44 --> Security Class Initialized
DEBUG - 2021-05-04 03:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:16:44 --> Input Class Initialized
INFO - 2021-05-04 03:16:44 --> Language Class Initialized
INFO - 2021-05-04 03:16:44 --> Language Class Initialized
INFO - 2021-05-04 03:16:44 --> Config Class Initialized
INFO - 2021-05-04 03:16:44 --> Loader Class Initialized
INFO - 2021-05-04 03:16:44 --> Helper loaded: url_helper
INFO - 2021-05-04 03:16:44 --> Helper loaded: file_helper
INFO - 2021-05-04 03:16:44 --> Helper loaded: form_helper
INFO - 2021-05-04 03:16:44 --> Helper loaded: my_helper
INFO - 2021-05-04 03:16:44 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:16:44 --> Controller Class Initialized
DEBUG - 2021-05-04 03:16:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-05-04 03:16:44 --> Final output sent to browser
DEBUG - 2021-05-04 03:16:44 --> Total execution time: 0.0920
INFO - 2021-05-04 03:17:21 --> Config Class Initialized
INFO - 2021-05-04 03:17:21 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:17:21 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:17:21 --> Utf8 Class Initialized
INFO - 2021-05-04 03:17:21 --> URI Class Initialized
INFO - 2021-05-04 03:17:21 --> Router Class Initialized
INFO - 2021-05-04 03:17:21 --> Output Class Initialized
INFO - 2021-05-04 03:17:21 --> Security Class Initialized
DEBUG - 2021-05-04 03:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:17:21 --> Input Class Initialized
INFO - 2021-05-04 03:17:21 --> Language Class Initialized
INFO - 2021-05-04 03:17:21 --> Language Class Initialized
INFO - 2021-05-04 03:17:21 --> Config Class Initialized
INFO - 2021-05-04 03:17:21 --> Loader Class Initialized
INFO - 2021-05-04 03:17:21 --> Helper loaded: url_helper
INFO - 2021-05-04 03:17:21 --> Helper loaded: file_helper
INFO - 2021-05-04 03:17:21 --> Helper loaded: form_helper
INFO - 2021-05-04 03:17:21 --> Helper loaded: my_helper
INFO - 2021-05-04 03:17:21 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:17:21 --> Controller Class Initialized
DEBUG - 2021-05-04 03:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-05-04 03:17:21 --> Final output sent to browser
DEBUG - 2021-05-04 03:17:21 --> Total execution time: 0.0824
INFO - 2021-05-04 03:18:24 --> Config Class Initialized
INFO - 2021-05-04 03:18:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:18:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:18:24 --> Utf8 Class Initialized
INFO - 2021-05-04 03:18:24 --> URI Class Initialized
INFO - 2021-05-04 03:18:24 --> Router Class Initialized
INFO - 2021-05-04 03:18:24 --> Output Class Initialized
INFO - 2021-05-04 03:18:24 --> Security Class Initialized
DEBUG - 2021-05-04 03:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:18:24 --> Input Class Initialized
INFO - 2021-05-04 03:18:24 --> Language Class Initialized
INFO - 2021-05-04 03:18:24 --> Language Class Initialized
INFO - 2021-05-04 03:18:24 --> Config Class Initialized
INFO - 2021-05-04 03:18:24 --> Loader Class Initialized
INFO - 2021-05-04 03:18:24 --> Helper loaded: url_helper
INFO - 2021-05-04 03:18:24 --> Helper loaded: file_helper
INFO - 2021-05-04 03:18:24 --> Helper loaded: form_helper
INFO - 2021-05-04 03:18:24 --> Helper loaded: my_helper
INFO - 2021-05-04 03:18:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:18:24 --> Controller Class Initialized
DEBUG - 2021-05-04 03:18:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-05-04 03:18:24 --> Final output sent to browser
DEBUG - 2021-05-04 03:18:24 --> Total execution time: 0.0786
INFO - 2021-05-04 03:18:57 --> Config Class Initialized
INFO - 2021-05-04 03:18:57 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:18:58 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:18:58 --> Utf8 Class Initialized
INFO - 2021-05-04 03:18:58 --> URI Class Initialized
INFO - 2021-05-04 03:18:58 --> Router Class Initialized
INFO - 2021-05-04 03:18:58 --> Output Class Initialized
INFO - 2021-05-04 03:18:58 --> Security Class Initialized
DEBUG - 2021-05-04 03:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:18:58 --> Input Class Initialized
INFO - 2021-05-04 03:18:58 --> Language Class Initialized
INFO - 2021-05-04 03:18:58 --> Language Class Initialized
INFO - 2021-05-04 03:18:58 --> Config Class Initialized
INFO - 2021-05-04 03:18:58 --> Loader Class Initialized
INFO - 2021-05-04 03:18:58 --> Helper loaded: url_helper
INFO - 2021-05-04 03:18:58 --> Helper loaded: file_helper
INFO - 2021-05-04 03:18:58 --> Helper loaded: form_helper
INFO - 2021-05-04 03:18:58 --> Helper loaded: my_helper
INFO - 2021-05-04 03:18:58 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:18:58 --> Controller Class Initialized
INFO - 2021-05-04 03:18:58 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:18:58 --> Config Class Initialized
INFO - 2021-05-04 03:18:58 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:18:58 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:18:58 --> Utf8 Class Initialized
INFO - 2021-05-04 03:18:58 --> URI Class Initialized
INFO - 2021-05-04 03:18:58 --> Router Class Initialized
INFO - 2021-05-04 03:18:58 --> Output Class Initialized
INFO - 2021-05-04 03:18:58 --> Security Class Initialized
DEBUG - 2021-05-04 03:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:18:58 --> Input Class Initialized
INFO - 2021-05-04 03:18:58 --> Language Class Initialized
INFO - 2021-05-04 03:18:58 --> Language Class Initialized
INFO - 2021-05-04 03:18:58 --> Config Class Initialized
INFO - 2021-05-04 03:18:58 --> Loader Class Initialized
INFO - 2021-05-04 03:18:58 --> Helper loaded: url_helper
INFO - 2021-05-04 03:18:58 --> Helper loaded: file_helper
INFO - 2021-05-04 03:18:58 --> Helper loaded: form_helper
INFO - 2021-05-04 03:18:58 --> Helper loaded: my_helper
INFO - 2021-05-04 03:18:58 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:18:58 --> Controller Class Initialized
DEBUG - 2021-05-04 03:18:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:18:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:18:58 --> Final output sent to browser
DEBUG - 2021-05-04 03:18:58 --> Total execution time: 0.0647
INFO - 2021-05-04 03:19:03 --> Config Class Initialized
INFO - 2021-05-04 03:19:03 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:19:03 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:19:03 --> Utf8 Class Initialized
INFO - 2021-05-04 03:19:03 --> URI Class Initialized
INFO - 2021-05-04 03:19:03 --> Router Class Initialized
INFO - 2021-05-04 03:19:03 --> Output Class Initialized
INFO - 2021-05-04 03:19:03 --> Security Class Initialized
DEBUG - 2021-05-04 03:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:19:03 --> Input Class Initialized
INFO - 2021-05-04 03:19:03 --> Language Class Initialized
INFO - 2021-05-04 03:19:03 --> Language Class Initialized
INFO - 2021-05-04 03:19:03 --> Config Class Initialized
INFO - 2021-05-04 03:19:03 --> Loader Class Initialized
INFO - 2021-05-04 03:19:03 --> Helper loaded: url_helper
INFO - 2021-05-04 03:19:03 --> Helper loaded: file_helper
INFO - 2021-05-04 03:19:03 --> Helper loaded: form_helper
INFO - 2021-05-04 03:19:03 --> Helper loaded: my_helper
INFO - 2021-05-04 03:19:03 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:19:03 --> Controller Class Initialized
INFO - 2021-05-04 03:19:03 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:19:03 --> Final output sent to browser
DEBUG - 2021-05-04 03:19:03 --> Total execution time: 0.0827
INFO - 2021-05-04 03:19:04 --> Config Class Initialized
INFO - 2021-05-04 03:19:04 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:19:04 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:19:04 --> Utf8 Class Initialized
INFO - 2021-05-04 03:19:04 --> URI Class Initialized
INFO - 2021-05-04 03:19:04 --> Router Class Initialized
INFO - 2021-05-04 03:19:04 --> Output Class Initialized
INFO - 2021-05-04 03:19:04 --> Security Class Initialized
DEBUG - 2021-05-04 03:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:19:04 --> Input Class Initialized
INFO - 2021-05-04 03:19:04 --> Language Class Initialized
INFO - 2021-05-04 03:19:04 --> Language Class Initialized
INFO - 2021-05-04 03:19:04 --> Config Class Initialized
INFO - 2021-05-04 03:19:04 --> Loader Class Initialized
INFO - 2021-05-04 03:19:04 --> Helper loaded: url_helper
INFO - 2021-05-04 03:19:04 --> Helper loaded: file_helper
INFO - 2021-05-04 03:19:04 --> Helper loaded: form_helper
INFO - 2021-05-04 03:19:04 --> Helper loaded: my_helper
INFO - 2021-05-04 03:19:04 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:19:04 --> Controller Class Initialized
DEBUG - 2021-05-04 03:19:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:19:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:19:04 --> Final output sent to browser
DEBUG - 2021-05-04 03:19:04 --> Total execution time: 0.0908
INFO - 2021-05-04 03:19:06 --> Config Class Initialized
INFO - 2021-05-04 03:19:06 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:19:06 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:19:06 --> Utf8 Class Initialized
INFO - 2021-05-04 03:19:06 --> URI Class Initialized
INFO - 2021-05-04 03:19:06 --> Router Class Initialized
INFO - 2021-05-04 03:19:06 --> Output Class Initialized
INFO - 2021-05-04 03:19:06 --> Security Class Initialized
DEBUG - 2021-05-04 03:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:19:06 --> Input Class Initialized
INFO - 2021-05-04 03:19:06 --> Language Class Initialized
INFO - 2021-05-04 03:19:06 --> Language Class Initialized
INFO - 2021-05-04 03:19:06 --> Config Class Initialized
INFO - 2021-05-04 03:19:06 --> Loader Class Initialized
INFO - 2021-05-04 03:19:06 --> Helper loaded: url_helper
INFO - 2021-05-04 03:19:06 --> Helper loaded: file_helper
INFO - 2021-05-04 03:19:06 --> Helper loaded: form_helper
INFO - 2021-05-04 03:19:06 --> Helper loaded: my_helper
INFO - 2021-05-04 03:19:06 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:19:07 --> Controller Class Initialized
DEBUG - 2021-05-04 03:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:19:07 --> Final output sent to browser
DEBUG - 2021-05-04 03:19:07 --> Total execution time: 0.0954
INFO - 2021-05-04 03:19:10 --> Config Class Initialized
INFO - 2021-05-04 03:19:10 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:19:10 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:19:10 --> Utf8 Class Initialized
INFO - 2021-05-04 03:19:10 --> URI Class Initialized
INFO - 2021-05-04 03:19:10 --> Router Class Initialized
INFO - 2021-05-04 03:19:10 --> Output Class Initialized
INFO - 2021-05-04 03:19:10 --> Security Class Initialized
DEBUG - 2021-05-04 03:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:19:10 --> Input Class Initialized
INFO - 2021-05-04 03:19:10 --> Language Class Initialized
INFO - 2021-05-04 03:19:10 --> Language Class Initialized
INFO - 2021-05-04 03:19:10 --> Config Class Initialized
INFO - 2021-05-04 03:19:10 --> Loader Class Initialized
INFO - 2021-05-04 03:19:10 --> Helper loaded: url_helper
INFO - 2021-05-04 03:19:10 --> Helper loaded: file_helper
INFO - 2021-05-04 03:19:10 --> Helper loaded: form_helper
INFO - 2021-05-04 03:19:10 --> Helper loaded: my_helper
INFO - 2021-05-04 03:19:10 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:19:10 --> Controller Class Initialized
DEBUG - 2021-05-04 03:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:19:10 --> Final output sent to browser
DEBUG - 2021-05-04 03:19:10 --> Total execution time: 0.1067
INFO - 2021-05-04 03:20:23 --> Config Class Initialized
INFO - 2021-05-04 03:20:23 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:20:23 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:20:23 --> Utf8 Class Initialized
INFO - 2021-05-04 03:20:23 --> URI Class Initialized
INFO - 2021-05-04 03:20:23 --> Router Class Initialized
INFO - 2021-05-04 03:20:23 --> Output Class Initialized
INFO - 2021-05-04 03:20:23 --> Security Class Initialized
DEBUG - 2021-05-04 03:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:20:23 --> Input Class Initialized
INFO - 2021-05-04 03:20:23 --> Language Class Initialized
INFO - 2021-05-04 03:20:23 --> Language Class Initialized
INFO - 2021-05-04 03:20:23 --> Config Class Initialized
INFO - 2021-05-04 03:20:23 --> Loader Class Initialized
INFO - 2021-05-04 03:20:23 --> Helper loaded: url_helper
INFO - 2021-05-04 03:20:23 --> Helper loaded: file_helper
INFO - 2021-05-04 03:20:23 --> Helper loaded: form_helper
INFO - 2021-05-04 03:20:23 --> Helper loaded: my_helper
INFO - 2021-05-04 03:20:23 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:20:23 --> Controller Class Initialized
DEBUG - 2021-05-04 03:20:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:20:23 --> Final output sent to browser
DEBUG - 2021-05-04 03:20:23 --> Total execution time: 0.0767
INFO - 2021-05-04 03:20:24 --> Config Class Initialized
INFO - 2021-05-04 03:20:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:20:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:20:24 --> Utf8 Class Initialized
INFO - 2021-05-04 03:20:24 --> URI Class Initialized
INFO - 2021-05-04 03:20:24 --> Router Class Initialized
INFO - 2021-05-04 03:20:24 --> Output Class Initialized
INFO - 2021-05-04 03:20:24 --> Security Class Initialized
DEBUG - 2021-05-04 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:20:24 --> Input Class Initialized
INFO - 2021-05-04 03:20:24 --> Language Class Initialized
INFO - 2021-05-04 03:20:24 --> Language Class Initialized
INFO - 2021-05-04 03:20:24 --> Config Class Initialized
INFO - 2021-05-04 03:20:24 --> Loader Class Initialized
INFO - 2021-05-04 03:20:24 --> Helper loaded: url_helper
INFO - 2021-05-04 03:20:24 --> Helper loaded: file_helper
INFO - 2021-05-04 03:20:24 --> Helper loaded: form_helper
INFO - 2021-05-04 03:20:24 --> Helper loaded: my_helper
INFO - 2021-05-04 03:20:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:20:24 --> Controller Class Initialized
DEBUG - 2021-05-04 03:20:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:20:24 --> Final output sent to browser
DEBUG - 2021-05-04 03:20:24 --> Total execution time: 0.0542
INFO - 2021-05-04 03:20:51 --> Config Class Initialized
INFO - 2021-05-04 03:20:51 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:20:51 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:20:51 --> Utf8 Class Initialized
INFO - 2021-05-04 03:20:51 --> URI Class Initialized
INFO - 2021-05-04 03:20:51 --> Router Class Initialized
INFO - 2021-05-04 03:20:51 --> Output Class Initialized
INFO - 2021-05-04 03:20:51 --> Security Class Initialized
DEBUG - 2021-05-04 03:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:20:51 --> Input Class Initialized
INFO - 2021-05-04 03:20:51 --> Language Class Initialized
INFO - 2021-05-04 03:20:51 --> Language Class Initialized
INFO - 2021-05-04 03:20:51 --> Config Class Initialized
INFO - 2021-05-04 03:20:51 --> Loader Class Initialized
INFO - 2021-05-04 03:20:51 --> Helper loaded: url_helper
INFO - 2021-05-04 03:20:51 --> Helper loaded: file_helper
INFO - 2021-05-04 03:20:51 --> Helper loaded: form_helper
INFO - 2021-05-04 03:20:51 --> Helper loaded: my_helper
INFO - 2021-05-04 03:20:51 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:20:51 --> Controller Class Initialized
DEBUG - 2021-05-04 03:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:20:51 --> Final output sent to browser
DEBUG - 2021-05-04 03:20:51 --> Total execution time: 0.0786
INFO - 2021-05-04 03:20:52 --> Config Class Initialized
INFO - 2021-05-04 03:20:52 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:20:52 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:20:52 --> Utf8 Class Initialized
INFO - 2021-05-04 03:20:52 --> URI Class Initialized
INFO - 2021-05-04 03:20:52 --> Router Class Initialized
INFO - 2021-05-04 03:20:52 --> Output Class Initialized
INFO - 2021-05-04 03:20:52 --> Security Class Initialized
DEBUG - 2021-05-04 03:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:20:52 --> Input Class Initialized
INFO - 2021-05-04 03:20:52 --> Language Class Initialized
INFO - 2021-05-04 03:20:52 --> Language Class Initialized
INFO - 2021-05-04 03:20:52 --> Config Class Initialized
INFO - 2021-05-04 03:20:52 --> Loader Class Initialized
INFO - 2021-05-04 03:20:52 --> Helper loaded: url_helper
INFO - 2021-05-04 03:20:52 --> Helper loaded: file_helper
INFO - 2021-05-04 03:20:52 --> Helper loaded: form_helper
INFO - 2021-05-04 03:20:52 --> Helper loaded: my_helper
INFO - 2021-05-04 03:20:52 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:20:52 --> Controller Class Initialized
DEBUG - 2021-05-04 03:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:20:52 --> Final output sent to browser
DEBUG - 2021-05-04 03:20:52 --> Total execution time: 0.0748
INFO - 2021-05-04 03:21:55 --> Config Class Initialized
INFO - 2021-05-04 03:21:55 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:21:55 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:21:55 --> Utf8 Class Initialized
INFO - 2021-05-04 03:21:55 --> URI Class Initialized
INFO - 2021-05-04 03:21:55 --> Router Class Initialized
INFO - 2021-05-04 03:21:55 --> Output Class Initialized
INFO - 2021-05-04 03:21:55 --> Security Class Initialized
DEBUG - 2021-05-04 03:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:21:55 --> Input Class Initialized
INFO - 2021-05-04 03:21:55 --> Language Class Initialized
INFO - 2021-05-04 03:21:55 --> Language Class Initialized
INFO - 2021-05-04 03:21:55 --> Config Class Initialized
INFO - 2021-05-04 03:21:55 --> Loader Class Initialized
INFO - 2021-05-04 03:21:55 --> Helper loaded: url_helper
INFO - 2021-05-04 03:21:55 --> Helper loaded: file_helper
INFO - 2021-05-04 03:21:55 --> Helper loaded: form_helper
INFO - 2021-05-04 03:21:55 --> Helper loaded: my_helper
INFO - 2021-05-04 03:21:55 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:21:56 --> Controller Class Initialized
DEBUG - 2021-05-04 03:21:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:21:56 --> Final output sent to browser
DEBUG - 2021-05-04 03:21:56 --> Total execution time: 0.0652
INFO - 2021-05-04 03:22:16 --> Config Class Initialized
INFO - 2021-05-04 03:22:16 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:22:16 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:22:16 --> Utf8 Class Initialized
INFO - 2021-05-04 03:22:16 --> URI Class Initialized
INFO - 2021-05-04 03:22:16 --> Router Class Initialized
INFO - 2021-05-04 03:22:16 --> Output Class Initialized
INFO - 2021-05-04 03:22:16 --> Security Class Initialized
DEBUG - 2021-05-04 03:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:22:16 --> Input Class Initialized
INFO - 2021-05-04 03:22:16 --> Language Class Initialized
INFO - 2021-05-04 03:22:16 --> Language Class Initialized
INFO - 2021-05-04 03:22:16 --> Config Class Initialized
INFO - 2021-05-04 03:22:16 --> Loader Class Initialized
INFO - 2021-05-04 03:22:16 --> Helper loaded: url_helper
INFO - 2021-05-04 03:22:16 --> Helper loaded: file_helper
INFO - 2021-05-04 03:22:16 --> Helper loaded: form_helper
INFO - 2021-05-04 03:22:16 --> Helper loaded: my_helper
INFO - 2021-05-04 03:22:16 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:22:16 --> Controller Class Initialized
DEBUG - 2021-05-04 03:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:22:16 --> Final output sent to browser
DEBUG - 2021-05-04 03:22:16 --> Total execution time: 0.0601
INFO - 2021-05-04 03:22:45 --> Config Class Initialized
INFO - 2021-05-04 03:22:45 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:22:45 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:22:45 --> Utf8 Class Initialized
INFO - 2021-05-04 03:22:45 --> URI Class Initialized
INFO - 2021-05-04 03:22:45 --> Router Class Initialized
INFO - 2021-05-04 03:22:45 --> Output Class Initialized
INFO - 2021-05-04 03:22:45 --> Security Class Initialized
DEBUG - 2021-05-04 03:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:22:45 --> Input Class Initialized
INFO - 2021-05-04 03:22:45 --> Language Class Initialized
INFO - 2021-05-04 03:22:45 --> Language Class Initialized
INFO - 2021-05-04 03:22:45 --> Config Class Initialized
INFO - 2021-05-04 03:22:45 --> Loader Class Initialized
INFO - 2021-05-04 03:22:45 --> Helper loaded: url_helper
INFO - 2021-05-04 03:22:45 --> Helper loaded: file_helper
INFO - 2021-05-04 03:22:45 --> Helper loaded: form_helper
INFO - 2021-05-04 03:22:45 --> Helper loaded: my_helper
INFO - 2021-05-04 03:22:45 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:22:45 --> Controller Class Initialized
DEBUG - 2021-05-04 03:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-05-04 03:22:45 --> Final output sent to browser
DEBUG - 2021-05-04 03:22:45 --> Total execution time: 0.0768
INFO - 2021-05-04 03:23:03 --> Config Class Initialized
INFO - 2021-05-04 03:23:03 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:23:03 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:23:03 --> Utf8 Class Initialized
INFO - 2021-05-04 03:23:03 --> URI Class Initialized
INFO - 2021-05-04 03:23:03 --> Router Class Initialized
INFO - 2021-05-04 03:23:03 --> Output Class Initialized
INFO - 2021-05-04 03:23:03 --> Security Class Initialized
DEBUG - 2021-05-04 03:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:23:03 --> Input Class Initialized
INFO - 2021-05-04 03:23:03 --> Language Class Initialized
INFO - 2021-05-04 03:23:03 --> Language Class Initialized
INFO - 2021-05-04 03:23:03 --> Config Class Initialized
INFO - 2021-05-04 03:23:03 --> Loader Class Initialized
INFO - 2021-05-04 03:23:03 --> Helper loaded: url_helper
INFO - 2021-05-04 03:23:03 --> Helper loaded: file_helper
INFO - 2021-05-04 03:23:03 --> Helper loaded: form_helper
INFO - 2021-05-04 03:23:03 --> Helper loaded: my_helper
INFO - 2021-05-04 03:23:03 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:23:03 --> Controller Class Initialized
INFO - 2021-05-04 03:23:03 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:23:03 --> Config Class Initialized
INFO - 2021-05-04 03:23:03 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:23:03 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:23:03 --> Utf8 Class Initialized
INFO - 2021-05-04 03:23:03 --> URI Class Initialized
INFO - 2021-05-04 03:23:03 --> Router Class Initialized
INFO - 2021-05-04 03:23:03 --> Output Class Initialized
INFO - 2021-05-04 03:23:03 --> Security Class Initialized
DEBUG - 2021-05-04 03:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:23:03 --> Input Class Initialized
INFO - 2021-05-04 03:23:03 --> Language Class Initialized
INFO - 2021-05-04 03:23:03 --> Language Class Initialized
INFO - 2021-05-04 03:23:03 --> Config Class Initialized
INFO - 2021-05-04 03:23:03 --> Loader Class Initialized
INFO - 2021-05-04 03:23:03 --> Helper loaded: url_helper
INFO - 2021-05-04 03:23:03 --> Helper loaded: file_helper
INFO - 2021-05-04 03:23:03 --> Helper loaded: form_helper
INFO - 2021-05-04 03:23:03 --> Helper loaded: my_helper
INFO - 2021-05-04 03:23:03 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:23:03 --> Controller Class Initialized
DEBUG - 2021-05-04 03:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:23:03 --> Final output sent to browser
DEBUG - 2021-05-04 03:23:03 --> Total execution time: 0.0642
INFO - 2021-05-04 03:23:09 --> Config Class Initialized
INFO - 2021-05-04 03:23:09 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:23:09 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:23:09 --> Utf8 Class Initialized
INFO - 2021-05-04 03:23:09 --> URI Class Initialized
INFO - 2021-05-04 03:23:09 --> Router Class Initialized
INFO - 2021-05-04 03:23:09 --> Output Class Initialized
INFO - 2021-05-04 03:23:09 --> Security Class Initialized
DEBUG - 2021-05-04 03:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:23:09 --> Input Class Initialized
INFO - 2021-05-04 03:23:09 --> Language Class Initialized
INFO - 2021-05-04 03:23:09 --> Language Class Initialized
INFO - 2021-05-04 03:23:09 --> Config Class Initialized
INFO - 2021-05-04 03:23:09 --> Loader Class Initialized
INFO - 2021-05-04 03:23:09 --> Helper loaded: url_helper
INFO - 2021-05-04 03:23:09 --> Helper loaded: file_helper
INFO - 2021-05-04 03:23:09 --> Helper loaded: form_helper
INFO - 2021-05-04 03:23:09 --> Helper loaded: my_helper
INFO - 2021-05-04 03:23:09 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:23:09 --> Controller Class Initialized
INFO - 2021-05-04 03:23:09 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:23:09 --> Final output sent to browser
DEBUG - 2021-05-04 03:23:09 --> Total execution time: 0.0914
INFO - 2021-05-04 03:23:10 --> Config Class Initialized
INFO - 2021-05-04 03:23:10 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:23:10 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:23:10 --> Utf8 Class Initialized
INFO - 2021-05-04 03:23:10 --> URI Class Initialized
INFO - 2021-05-04 03:23:10 --> Router Class Initialized
INFO - 2021-05-04 03:23:10 --> Output Class Initialized
INFO - 2021-05-04 03:23:10 --> Security Class Initialized
DEBUG - 2021-05-04 03:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:23:10 --> Input Class Initialized
INFO - 2021-05-04 03:23:10 --> Language Class Initialized
INFO - 2021-05-04 03:23:10 --> Language Class Initialized
INFO - 2021-05-04 03:23:10 --> Config Class Initialized
INFO - 2021-05-04 03:23:10 --> Loader Class Initialized
INFO - 2021-05-04 03:23:10 --> Helper loaded: url_helper
INFO - 2021-05-04 03:23:10 --> Helper loaded: file_helper
INFO - 2021-05-04 03:23:10 --> Helper loaded: form_helper
INFO - 2021-05-04 03:23:11 --> Helper loaded: my_helper
INFO - 2021-05-04 03:23:11 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:23:11 --> Controller Class Initialized
DEBUG - 2021-05-04 03:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:23:11 --> Final output sent to browser
DEBUG - 2021-05-04 03:23:11 --> Total execution time: 0.0902
INFO - 2021-05-04 03:23:14 --> Config Class Initialized
INFO - 2021-05-04 03:23:14 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:23:14 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:23:14 --> Utf8 Class Initialized
INFO - 2021-05-04 03:23:14 --> URI Class Initialized
INFO - 2021-05-04 03:23:14 --> Router Class Initialized
INFO - 2021-05-04 03:23:14 --> Output Class Initialized
INFO - 2021-05-04 03:23:14 --> Security Class Initialized
DEBUG - 2021-05-04 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:23:14 --> Input Class Initialized
INFO - 2021-05-04 03:23:14 --> Language Class Initialized
INFO - 2021-05-04 03:23:14 --> Language Class Initialized
INFO - 2021-05-04 03:23:14 --> Config Class Initialized
INFO - 2021-05-04 03:23:14 --> Loader Class Initialized
INFO - 2021-05-04 03:23:14 --> Helper loaded: url_helper
INFO - 2021-05-04 03:23:14 --> Helper loaded: file_helper
INFO - 2021-05-04 03:23:14 --> Helper loaded: form_helper
INFO - 2021-05-04 03:23:14 --> Helper loaded: my_helper
INFO - 2021-05-04 03:23:14 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:23:14 --> Controller Class Initialized
DEBUG - 2021-05-04 03:23:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:23:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:23:14 --> Final output sent to browser
DEBUG - 2021-05-04 03:23:14 --> Total execution time: 0.0813
INFO - 2021-05-04 03:23:19 --> Config Class Initialized
INFO - 2021-05-04 03:23:19 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:23:19 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:23:19 --> Utf8 Class Initialized
INFO - 2021-05-04 03:23:19 --> URI Class Initialized
INFO - 2021-05-04 03:23:19 --> Router Class Initialized
INFO - 2021-05-04 03:23:19 --> Output Class Initialized
INFO - 2021-05-04 03:23:19 --> Security Class Initialized
DEBUG - 2021-05-04 03:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:23:19 --> Input Class Initialized
INFO - 2021-05-04 03:23:19 --> Language Class Initialized
INFO - 2021-05-04 03:23:19 --> Language Class Initialized
INFO - 2021-05-04 03:23:19 --> Config Class Initialized
INFO - 2021-05-04 03:23:19 --> Loader Class Initialized
INFO - 2021-05-04 03:23:19 --> Helper loaded: url_helper
INFO - 2021-05-04 03:23:19 --> Helper loaded: file_helper
INFO - 2021-05-04 03:23:19 --> Helper loaded: form_helper
INFO - 2021-05-04 03:23:19 --> Helper loaded: my_helper
INFO - 2021-05-04 03:23:19 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:23:19 --> Controller Class Initialized
DEBUG - 2021-05-04 03:23:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-05-04 03:23:19 --> Final output sent to browser
DEBUG - 2021-05-04 03:23:19 --> Total execution time: 0.1005
INFO - 2021-05-04 03:24:06 --> Config Class Initialized
INFO - 2021-05-04 03:24:06 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:24:06 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:24:06 --> Utf8 Class Initialized
INFO - 2021-05-04 03:24:06 --> URI Class Initialized
INFO - 2021-05-04 03:24:06 --> Router Class Initialized
INFO - 2021-05-04 03:24:06 --> Output Class Initialized
INFO - 2021-05-04 03:24:06 --> Security Class Initialized
DEBUG - 2021-05-04 03:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:24:06 --> Input Class Initialized
INFO - 2021-05-04 03:24:06 --> Language Class Initialized
INFO - 2021-05-04 03:24:06 --> Language Class Initialized
INFO - 2021-05-04 03:24:06 --> Config Class Initialized
INFO - 2021-05-04 03:24:06 --> Loader Class Initialized
INFO - 2021-05-04 03:24:06 --> Helper loaded: url_helper
INFO - 2021-05-04 03:24:06 --> Helper loaded: file_helper
INFO - 2021-05-04 03:24:06 --> Helper loaded: form_helper
INFO - 2021-05-04 03:24:06 --> Helper loaded: my_helper
INFO - 2021-05-04 03:24:06 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:24:06 --> Controller Class Initialized
DEBUG - 2021-05-04 03:24:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-05-04 03:24:06 --> Final output sent to browser
DEBUG - 2021-05-04 03:24:06 --> Total execution time: 0.0598
INFO - 2021-05-04 03:24:54 --> Config Class Initialized
INFO - 2021-05-04 03:24:54 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:24:54 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:24:54 --> Utf8 Class Initialized
INFO - 2021-05-04 03:24:54 --> URI Class Initialized
INFO - 2021-05-04 03:24:54 --> Router Class Initialized
INFO - 2021-05-04 03:24:54 --> Output Class Initialized
INFO - 2021-05-04 03:24:54 --> Security Class Initialized
DEBUG - 2021-05-04 03:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:24:54 --> Input Class Initialized
INFO - 2021-05-04 03:24:54 --> Language Class Initialized
INFO - 2021-05-04 03:24:54 --> Language Class Initialized
INFO - 2021-05-04 03:24:54 --> Config Class Initialized
INFO - 2021-05-04 03:24:54 --> Loader Class Initialized
INFO - 2021-05-04 03:24:54 --> Helper loaded: url_helper
INFO - 2021-05-04 03:24:54 --> Helper loaded: file_helper
INFO - 2021-05-04 03:24:54 --> Helper loaded: form_helper
INFO - 2021-05-04 03:24:54 --> Helper loaded: my_helper
INFO - 2021-05-04 03:24:54 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:24:54 --> Controller Class Initialized
INFO - 2021-05-04 03:24:54 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:24:54 --> Config Class Initialized
INFO - 2021-05-04 03:24:54 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:24:54 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:24:54 --> Utf8 Class Initialized
INFO - 2021-05-04 03:24:54 --> URI Class Initialized
INFO - 2021-05-04 03:24:54 --> Router Class Initialized
INFO - 2021-05-04 03:24:54 --> Output Class Initialized
INFO - 2021-05-04 03:24:54 --> Security Class Initialized
DEBUG - 2021-05-04 03:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:24:54 --> Input Class Initialized
INFO - 2021-05-04 03:24:54 --> Language Class Initialized
INFO - 2021-05-04 03:24:54 --> Language Class Initialized
INFO - 2021-05-04 03:24:54 --> Config Class Initialized
INFO - 2021-05-04 03:24:54 --> Loader Class Initialized
INFO - 2021-05-04 03:24:54 --> Helper loaded: url_helper
INFO - 2021-05-04 03:24:54 --> Helper loaded: file_helper
INFO - 2021-05-04 03:24:54 --> Helper loaded: form_helper
INFO - 2021-05-04 03:24:54 --> Helper loaded: my_helper
INFO - 2021-05-04 03:24:54 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:24:54 --> Controller Class Initialized
DEBUG - 2021-05-04 03:24:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:24:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:24:54 --> Final output sent to browser
DEBUG - 2021-05-04 03:24:54 --> Total execution time: 0.0568
INFO - 2021-05-04 03:25:02 --> Config Class Initialized
INFO - 2021-05-04 03:25:02 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:25:02 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:25:02 --> Utf8 Class Initialized
INFO - 2021-05-04 03:25:02 --> URI Class Initialized
INFO - 2021-05-04 03:25:02 --> Router Class Initialized
INFO - 2021-05-04 03:25:02 --> Output Class Initialized
INFO - 2021-05-04 03:25:02 --> Security Class Initialized
DEBUG - 2021-05-04 03:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:25:02 --> Input Class Initialized
INFO - 2021-05-04 03:25:02 --> Language Class Initialized
INFO - 2021-05-04 03:25:02 --> Language Class Initialized
INFO - 2021-05-04 03:25:02 --> Config Class Initialized
INFO - 2021-05-04 03:25:02 --> Loader Class Initialized
INFO - 2021-05-04 03:25:02 --> Helper loaded: url_helper
INFO - 2021-05-04 03:25:02 --> Helper loaded: file_helper
INFO - 2021-05-04 03:25:02 --> Helper loaded: form_helper
INFO - 2021-05-04 03:25:02 --> Helper loaded: my_helper
INFO - 2021-05-04 03:25:02 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:25:02 --> Controller Class Initialized
INFO - 2021-05-04 03:25:02 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:25:02 --> Final output sent to browser
DEBUG - 2021-05-04 03:25:02 --> Total execution time: 0.0874
INFO - 2021-05-04 03:25:03 --> Config Class Initialized
INFO - 2021-05-04 03:25:03 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:25:03 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:25:03 --> Utf8 Class Initialized
INFO - 2021-05-04 03:25:03 --> URI Class Initialized
INFO - 2021-05-04 03:25:03 --> Router Class Initialized
INFO - 2021-05-04 03:25:03 --> Output Class Initialized
INFO - 2021-05-04 03:25:03 --> Security Class Initialized
DEBUG - 2021-05-04 03:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:25:03 --> Input Class Initialized
INFO - 2021-05-04 03:25:03 --> Language Class Initialized
INFO - 2021-05-04 03:25:03 --> Language Class Initialized
INFO - 2021-05-04 03:25:03 --> Config Class Initialized
INFO - 2021-05-04 03:25:03 --> Loader Class Initialized
INFO - 2021-05-04 03:25:03 --> Helper loaded: url_helper
INFO - 2021-05-04 03:25:03 --> Helper loaded: file_helper
INFO - 2021-05-04 03:25:03 --> Helper loaded: form_helper
INFO - 2021-05-04 03:25:03 --> Helper loaded: my_helper
INFO - 2021-05-04 03:25:03 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:25:03 --> Controller Class Initialized
DEBUG - 2021-05-04 03:25:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:25:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:25:03 --> Final output sent to browser
DEBUG - 2021-05-04 03:25:03 --> Total execution time: 0.0717
INFO - 2021-05-04 03:25:06 --> Config Class Initialized
INFO - 2021-05-04 03:25:06 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:25:06 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:25:06 --> Utf8 Class Initialized
INFO - 2021-05-04 03:25:06 --> URI Class Initialized
INFO - 2021-05-04 03:25:06 --> Router Class Initialized
INFO - 2021-05-04 03:25:06 --> Output Class Initialized
INFO - 2021-05-04 03:25:06 --> Security Class Initialized
DEBUG - 2021-05-04 03:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:25:06 --> Input Class Initialized
INFO - 2021-05-04 03:25:06 --> Language Class Initialized
INFO - 2021-05-04 03:25:06 --> Language Class Initialized
INFO - 2021-05-04 03:25:06 --> Config Class Initialized
INFO - 2021-05-04 03:25:06 --> Loader Class Initialized
INFO - 2021-05-04 03:25:06 --> Helper loaded: url_helper
INFO - 2021-05-04 03:25:06 --> Helper loaded: file_helper
INFO - 2021-05-04 03:25:06 --> Helper loaded: form_helper
INFO - 2021-05-04 03:25:06 --> Helper loaded: my_helper
INFO - 2021-05-04 03:25:06 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:25:06 --> Controller Class Initialized
INFO - 2021-05-04 03:25:06 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:25:06 --> Config Class Initialized
INFO - 2021-05-04 03:25:06 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:25:06 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:25:06 --> Utf8 Class Initialized
INFO - 2021-05-04 03:25:06 --> URI Class Initialized
INFO - 2021-05-04 03:25:06 --> Router Class Initialized
INFO - 2021-05-04 03:25:06 --> Output Class Initialized
INFO - 2021-05-04 03:25:06 --> Security Class Initialized
DEBUG - 2021-05-04 03:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:25:06 --> Input Class Initialized
INFO - 2021-05-04 03:25:06 --> Language Class Initialized
INFO - 2021-05-04 03:25:06 --> Language Class Initialized
INFO - 2021-05-04 03:25:06 --> Config Class Initialized
INFO - 2021-05-04 03:25:06 --> Loader Class Initialized
INFO - 2021-05-04 03:25:06 --> Helper loaded: url_helper
INFO - 2021-05-04 03:25:06 --> Helper loaded: file_helper
INFO - 2021-05-04 03:25:06 --> Helper loaded: form_helper
INFO - 2021-05-04 03:25:06 --> Helper loaded: my_helper
INFO - 2021-05-04 03:25:06 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:25:06 --> Controller Class Initialized
DEBUG - 2021-05-04 03:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:25:06 --> Final output sent to browser
DEBUG - 2021-05-04 03:25:06 --> Total execution time: 0.0602
INFO - 2021-05-04 03:25:46 --> Config Class Initialized
INFO - 2021-05-04 03:25:46 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:25:46 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:25:46 --> Utf8 Class Initialized
INFO - 2021-05-04 03:25:46 --> URI Class Initialized
INFO - 2021-05-04 03:25:46 --> Router Class Initialized
INFO - 2021-05-04 03:25:46 --> Output Class Initialized
INFO - 2021-05-04 03:25:46 --> Security Class Initialized
DEBUG - 2021-05-04 03:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:25:46 --> Input Class Initialized
INFO - 2021-05-04 03:25:46 --> Language Class Initialized
INFO - 2021-05-04 03:25:46 --> Language Class Initialized
INFO - 2021-05-04 03:25:46 --> Config Class Initialized
INFO - 2021-05-04 03:25:46 --> Loader Class Initialized
INFO - 2021-05-04 03:25:46 --> Helper loaded: url_helper
INFO - 2021-05-04 03:25:46 --> Helper loaded: file_helper
INFO - 2021-05-04 03:25:46 --> Helper loaded: form_helper
INFO - 2021-05-04 03:25:46 --> Helper loaded: my_helper
INFO - 2021-05-04 03:25:46 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:25:46 --> Controller Class Initialized
DEBUG - 2021-05-04 03:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:25:46 --> Final output sent to browser
DEBUG - 2021-05-04 03:25:46 --> Total execution time: 0.0683
INFO - 2021-05-04 03:25:51 --> Config Class Initialized
INFO - 2021-05-04 03:25:51 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:25:51 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:25:51 --> Utf8 Class Initialized
INFO - 2021-05-04 03:25:51 --> URI Class Initialized
INFO - 2021-05-04 03:25:51 --> Router Class Initialized
INFO - 2021-05-04 03:25:51 --> Output Class Initialized
INFO - 2021-05-04 03:25:51 --> Security Class Initialized
DEBUG - 2021-05-04 03:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:25:51 --> Input Class Initialized
INFO - 2021-05-04 03:25:51 --> Language Class Initialized
INFO - 2021-05-04 03:25:51 --> Language Class Initialized
INFO - 2021-05-04 03:25:51 --> Config Class Initialized
INFO - 2021-05-04 03:25:51 --> Loader Class Initialized
INFO - 2021-05-04 03:25:51 --> Helper loaded: url_helper
INFO - 2021-05-04 03:25:51 --> Helper loaded: file_helper
INFO - 2021-05-04 03:25:51 --> Helper loaded: form_helper
INFO - 2021-05-04 03:25:51 --> Helper loaded: my_helper
INFO - 2021-05-04 03:25:51 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:25:51 --> Controller Class Initialized
INFO - 2021-05-04 03:25:51 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:25:51 --> Final output sent to browser
DEBUG - 2021-05-04 03:25:51 --> Total execution time: 0.0855
INFO - 2021-05-04 03:25:54 --> Config Class Initialized
INFO - 2021-05-04 03:25:54 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:25:54 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:25:54 --> Utf8 Class Initialized
INFO - 2021-05-04 03:25:54 --> URI Class Initialized
INFO - 2021-05-04 03:25:54 --> Router Class Initialized
INFO - 2021-05-04 03:25:54 --> Output Class Initialized
INFO - 2021-05-04 03:25:54 --> Security Class Initialized
DEBUG - 2021-05-04 03:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:25:54 --> Input Class Initialized
INFO - 2021-05-04 03:25:54 --> Language Class Initialized
INFO - 2021-05-04 03:25:54 --> Language Class Initialized
INFO - 2021-05-04 03:25:54 --> Config Class Initialized
INFO - 2021-05-04 03:25:54 --> Loader Class Initialized
INFO - 2021-05-04 03:25:54 --> Helper loaded: url_helper
INFO - 2021-05-04 03:25:54 --> Helper loaded: file_helper
INFO - 2021-05-04 03:25:54 --> Helper loaded: form_helper
INFO - 2021-05-04 03:25:54 --> Helper loaded: my_helper
INFO - 2021-05-04 03:25:54 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:25:54 --> Controller Class Initialized
DEBUG - 2021-05-04 03:25:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:25:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:25:54 --> Final output sent to browser
DEBUG - 2021-05-04 03:25:54 --> Total execution time: 0.0716
INFO - 2021-05-04 03:26:03 --> Config Class Initialized
INFO - 2021-05-04 03:26:03 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:26:03 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:26:03 --> Utf8 Class Initialized
INFO - 2021-05-04 03:26:03 --> URI Class Initialized
INFO - 2021-05-04 03:26:03 --> Router Class Initialized
INFO - 2021-05-04 03:26:03 --> Output Class Initialized
INFO - 2021-05-04 03:26:03 --> Security Class Initialized
DEBUG - 2021-05-04 03:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:26:03 --> Input Class Initialized
INFO - 2021-05-04 03:26:03 --> Language Class Initialized
INFO - 2021-05-04 03:26:03 --> Language Class Initialized
INFO - 2021-05-04 03:26:03 --> Config Class Initialized
INFO - 2021-05-04 03:26:03 --> Loader Class Initialized
INFO - 2021-05-04 03:26:03 --> Helper loaded: url_helper
INFO - 2021-05-04 03:26:03 --> Helper loaded: file_helper
INFO - 2021-05-04 03:26:03 --> Helper loaded: form_helper
INFO - 2021-05-04 03:26:03 --> Helper loaded: my_helper
INFO - 2021-05-04 03:26:03 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:26:03 --> Controller Class Initialized
DEBUG - 2021-05-04 03:26:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 03:26:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:26:03 --> Final output sent to browser
DEBUG - 2021-05-04 03:26:03 --> Total execution time: 0.0948
INFO - 2021-05-04 03:26:32 --> Config Class Initialized
INFO - 2021-05-04 03:26:32 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:26:32 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:26:32 --> Utf8 Class Initialized
INFO - 2021-05-04 03:26:32 --> URI Class Initialized
INFO - 2021-05-04 03:26:33 --> Router Class Initialized
INFO - 2021-05-04 03:26:33 --> Output Class Initialized
INFO - 2021-05-04 03:26:33 --> Security Class Initialized
DEBUG - 2021-05-04 03:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:26:33 --> Input Class Initialized
INFO - 2021-05-04 03:26:33 --> Language Class Initialized
INFO - 2021-05-04 03:26:33 --> Language Class Initialized
INFO - 2021-05-04 03:26:33 --> Config Class Initialized
INFO - 2021-05-04 03:26:33 --> Loader Class Initialized
INFO - 2021-05-04 03:26:33 --> Helper loaded: url_helper
INFO - 2021-05-04 03:26:33 --> Helper loaded: file_helper
INFO - 2021-05-04 03:26:33 --> Helper loaded: form_helper
INFO - 2021-05-04 03:26:33 --> Helper loaded: my_helper
INFO - 2021-05-04 03:26:33 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:26:33 --> Controller Class Initialized
INFO - 2021-05-04 03:26:33 --> Final output sent to browser
DEBUG - 2021-05-04 03:26:33 --> Total execution time: 0.1443
INFO - 2021-05-04 03:26:46 --> Config Class Initialized
INFO - 2021-05-04 03:26:46 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:26:46 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:26:46 --> Utf8 Class Initialized
INFO - 2021-05-04 03:26:46 --> URI Class Initialized
INFO - 2021-05-04 03:26:46 --> Router Class Initialized
INFO - 2021-05-04 03:26:46 --> Output Class Initialized
INFO - 2021-05-04 03:26:46 --> Security Class Initialized
DEBUG - 2021-05-04 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:26:46 --> Input Class Initialized
INFO - 2021-05-04 03:26:46 --> Language Class Initialized
INFO - 2021-05-04 03:26:46 --> Language Class Initialized
INFO - 2021-05-04 03:26:46 --> Config Class Initialized
INFO - 2021-05-04 03:26:46 --> Loader Class Initialized
INFO - 2021-05-04 03:26:46 --> Helper loaded: url_helper
INFO - 2021-05-04 03:26:46 --> Helper loaded: file_helper
INFO - 2021-05-04 03:26:46 --> Helper loaded: form_helper
INFO - 2021-05-04 03:26:46 --> Helper loaded: my_helper
INFO - 2021-05-04 03:26:46 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:26:46 --> Controller Class Initialized
DEBUG - 2021-05-04 03:26:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-05-04 03:26:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:26:46 --> Final output sent to browser
DEBUG - 2021-05-04 03:26:46 --> Total execution time: 0.0839
INFO - 2021-05-04 03:26:47 --> Config Class Initialized
INFO - 2021-05-04 03:26:47 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:26:47 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:26:47 --> Utf8 Class Initialized
INFO - 2021-05-04 03:26:47 --> URI Class Initialized
INFO - 2021-05-04 03:26:47 --> Router Class Initialized
INFO - 2021-05-04 03:26:47 --> Output Class Initialized
INFO - 2021-05-04 03:26:47 --> Security Class Initialized
DEBUG - 2021-05-04 03:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:26:47 --> Input Class Initialized
INFO - 2021-05-04 03:26:47 --> Language Class Initialized
INFO - 2021-05-04 03:26:47 --> Language Class Initialized
INFO - 2021-05-04 03:26:47 --> Config Class Initialized
INFO - 2021-05-04 03:26:47 --> Loader Class Initialized
INFO - 2021-05-04 03:26:47 --> Helper loaded: url_helper
INFO - 2021-05-04 03:26:47 --> Helper loaded: file_helper
INFO - 2021-05-04 03:26:47 --> Helper loaded: form_helper
INFO - 2021-05-04 03:26:47 --> Helper loaded: my_helper
INFO - 2021-05-04 03:26:47 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:26:47 --> Controller Class Initialized
INFO - 2021-05-04 03:26:47 --> Final output sent to browser
DEBUG - 2021-05-04 03:26:47 --> Total execution time: 0.0643
INFO - 2021-05-04 03:26:52 --> Config Class Initialized
INFO - 2021-05-04 03:26:52 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:26:52 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:26:52 --> Utf8 Class Initialized
INFO - 2021-05-04 03:26:52 --> URI Class Initialized
INFO - 2021-05-04 03:26:52 --> Router Class Initialized
INFO - 2021-05-04 03:26:52 --> Output Class Initialized
INFO - 2021-05-04 03:26:52 --> Security Class Initialized
DEBUG - 2021-05-04 03:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:26:52 --> Input Class Initialized
INFO - 2021-05-04 03:26:52 --> Language Class Initialized
INFO - 2021-05-04 03:26:52 --> Language Class Initialized
INFO - 2021-05-04 03:26:52 --> Config Class Initialized
INFO - 2021-05-04 03:26:52 --> Loader Class Initialized
INFO - 2021-05-04 03:26:52 --> Helper loaded: url_helper
INFO - 2021-05-04 03:26:52 --> Helper loaded: file_helper
INFO - 2021-05-04 03:26:52 --> Helper loaded: form_helper
INFO - 2021-05-04 03:26:52 --> Helper loaded: my_helper
INFO - 2021-05-04 03:26:52 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:26:52 --> Controller Class Initialized
INFO - 2021-05-04 03:26:53 --> Final output sent to browser
DEBUG - 2021-05-04 03:26:53 --> Total execution time: 0.1413
INFO - 2021-05-04 03:27:00 --> Config Class Initialized
INFO - 2021-05-04 03:27:00 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:27:00 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:27:00 --> Utf8 Class Initialized
INFO - 2021-05-04 03:27:00 --> URI Class Initialized
INFO - 2021-05-04 03:27:00 --> Router Class Initialized
INFO - 2021-05-04 03:27:00 --> Output Class Initialized
INFO - 2021-05-04 03:27:00 --> Security Class Initialized
DEBUG - 2021-05-04 03:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:27:00 --> Input Class Initialized
INFO - 2021-05-04 03:27:00 --> Language Class Initialized
INFO - 2021-05-04 03:27:00 --> Language Class Initialized
INFO - 2021-05-04 03:27:00 --> Config Class Initialized
INFO - 2021-05-04 03:27:00 --> Loader Class Initialized
INFO - 2021-05-04 03:27:00 --> Helper loaded: url_helper
INFO - 2021-05-04 03:27:00 --> Helper loaded: file_helper
INFO - 2021-05-04 03:27:00 --> Helper loaded: form_helper
INFO - 2021-05-04 03:27:00 --> Helper loaded: my_helper
INFO - 2021-05-04 03:27:00 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:27:00 --> Controller Class Initialized
DEBUG - 2021-05-04 03:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-05-04 03:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:27:00 --> Final output sent to browser
DEBUG - 2021-05-04 03:27:00 --> Total execution time: 0.0697
INFO - 2021-05-04 03:27:05 --> Config Class Initialized
INFO - 2021-05-04 03:27:05 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:27:05 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:27:05 --> Utf8 Class Initialized
INFO - 2021-05-04 03:27:05 --> URI Class Initialized
INFO - 2021-05-04 03:27:05 --> Router Class Initialized
INFO - 2021-05-04 03:27:05 --> Output Class Initialized
INFO - 2021-05-04 03:27:05 --> Security Class Initialized
DEBUG - 2021-05-04 03:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:27:05 --> Input Class Initialized
INFO - 2021-05-04 03:27:05 --> Language Class Initialized
INFO - 2021-05-04 03:27:05 --> Language Class Initialized
INFO - 2021-05-04 03:27:05 --> Config Class Initialized
INFO - 2021-05-04 03:27:05 --> Loader Class Initialized
INFO - 2021-05-04 03:27:05 --> Helper loaded: url_helper
INFO - 2021-05-04 03:27:05 --> Helper loaded: file_helper
INFO - 2021-05-04 03:27:05 --> Helper loaded: form_helper
INFO - 2021-05-04 03:27:05 --> Helper loaded: my_helper
INFO - 2021-05-04 03:27:05 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:27:05 --> Controller Class Initialized
INFO - 2021-05-04 03:27:05 --> Final output sent to browser
DEBUG - 2021-05-04 03:27:05 --> Total execution time: 0.1230
INFO - 2021-05-04 03:27:12 --> Config Class Initialized
INFO - 2021-05-04 03:27:12 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:27:12 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:27:12 --> Utf8 Class Initialized
INFO - 2021-05-04 03:27:12 --> URI Class Initialized
INFO - 2021-05-04 03:27:12 --> Router Class Initialized
INFO - 2021-05-04 03:27:12 --> Output Class Initialized
INFO - 2021-05-04 03:27:12 --> Security Class Initialized
DEBUG - 2021-05-04 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:27:12 --> Input Class Initialized
INFO - 2021-05-04 03:27:12 --> Language Class Initialized
INFO - 2021-05-04 03:27:12 --> Language Class Initialized
INFO - 2021-05-04 03:27:12 --> Config Class Initialized
INFO - 2021-05-04 03:27:12 --> Loader Class Initialized
INFO - 2021-05-04 03:27:12 --> Helper loaded: url_helper
INFO - 2021-05-04 03:27:12 --> Helper loaded: file_helper
INFO - 2021-05-04 03:27:12 --> Helper loaded: form_helper
INFO - 2021-05-04 03:27:12 --> Helper loaded: my_helper
INFO - 2021-05-04 03:27:12 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:27:12 --> Controller Class Initialized
DEBUG - 2021-05-04 03:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:27:12 --> Final output sent to browser
DEBUG - 2021-05-04 03:27:12 --> Total execution time: 0.0635
INFO - 2021-05-04 03:27:21 --> Config Class Initialized
INFO - 2021-05-04 03:27:21 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:27:21 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:27:21 --> Utf8 Class Initialized
INFO - 2021-05-04 03:27:21 --> URI Class Initialized
INFO - 2021-05-04 03:27:21 --> Router Class Initialized
INFO - 2021-05-04 03:27:21 --> Output Class Initialized
INFO - 2021-05-04 03:27:21 --> Security Class Initialized
DEBUG - 2021-05-04 03:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:27:21 --> Input Class Initialized
INFO - 2021-05-04 03:27:21 --> Language Class Initialized
INFO - 2021-05-04 03:27:21 --> Language Class Initialized
INFO - 2021-05-04 03:27:21 --> Config Class Initialized
INFO - 2021-05-04 03:27:21 --> Loader Class Initialized
INFO - 2021-05-04 03:27:21 --> Helper loaded: url_helper
INFO - 2021-05-04 03:27:21 --> Helper loaded: file_helper
INFO - 2021-05-04 03:27:21 --> Helper loaded: form_helper
INFO - 2021-05-04 03:27:21 --> Helper loaded: my_helper
INFO - 2021-05-04 03:27:21 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:27:21 --> Controller Class Initialized
DEBUG - 2021-05-04 03:27:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:27:21 --> Final output sent to browser
DEBUG - 2021-05-04 03:27:21 --> Total execution time: 0.1755
INFO - 2021-05-04 03:27:59 --> Config Class Initialized
INFO - 2021-05-04 03:27:59 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:27:59 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:27:59 --> Utf8 Class Initialized
INFO - 2021-05-04 03:27:59 --> URI Class Initialized
INFO - 2021-05-04 03:27:59 --> Router Class Initialized
INFO - 2021-05-04 03:27:59 --> Output Class Initialized
INFO - 2021-05-04 03:27:59 --> Security Class Initialized
DEBUG - 2021-05-04 03:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:27:59 --> Input Class Initialized
INFO - 2021-05-04 03:27:59 --> Language Class Initialized
INFO - 2021-05-04 03:27:59 --> Language Class Initialized
INFO - 2021-05-04 03:27:59 --> Config Class Initialized
INFO - 2021-05-04 03:27:59 --> Loader Class Initialized
INFO - 2021-05-04 03:27:59 --> Helper loaded: url_helper
INFO - 2021-05-04 03:27:59 --> Helper loaded: file_helper
INFO - 2021-05-04 03:27:59 --> Helper loaded: form_helper
INFO - 2021-05-04 03:27:59 --> Helper loaded: my_helper
INFO - 2021-05-04 03:27:59 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:27:59 --> Controller Class Initialized
DEBUG - 2021-05-04 03:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:27:59 --> Final output sent to browser
DEBUG - 2021-05-04 03:27:59 --> Total execution time: 0.0744
INFO - 2021-05-04 03:29:34 --> Config Class Initialized
INFO - 2021-05-04 03:29:34 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:29:34 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:29:34 --> Utf8 Class Initialized
INFO - 2021-05-04 03:29:34 --> URI Class Initialized
INFO - 2021-05-04 03:29:34 --> Router Class Initialized
INFO - 2021-05-04 03:29:34 --> Output Class Initialized
INFO - 2021-05-04 03:29:34 --> Security Class Initialized
DEBUG - 2021-05-04 03:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:29:34 --> Input Class Initialized
INFO - 2021-05-04 03:29:34 --> Language Class Initialized
INFO - 2021-05-04 03:29:34 --> Language Class Initialized
INFO - 2021-05-04 03:29:34 --> Config Class Initialized
INFO - 2021-05-04 03:29:34 --> Loader Class Initialized
INFO - 2021-05-04 03:29:34 --> Helper loaded: url_helper
INFO - 2021-05-04 03:29:34 --> Helper loaded: file_helper
INFO - 2021-05-04 03:29:34 --> Helper loaded: form_helper
INFO - 2021-05-04 03:29:34 --> Helper loaded: my_helper
INFO - 2021-05-04 03:29:34 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:29:34 --> Controller Class Initialized
DEBUG - 2021-05-04 03:29:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:29:34 --> Final output sent to browser
DEBUG - 2021-05-04 03:29:34 --> Total execution time: 0.0753
INFO - 2021-05-04 03:30:09 --> Config Class Initialized
INFO - 2021-05-04 03:30:09 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:30:09 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:30:09 --> Utf8 Class Initialized
INFO - 2021-05-04 03:30:09 --> URI Class Initialized
INFO - 2021-05-04 03:30:09 --> Router Class Initialized
INFO - 2021-05-04 03:30:09 --> Output Class Initialized
INFO - 2021-05-04 03:30:09 --> Security Class Initialized
DEBUG - 2021-05-04 03:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:30:09 --> Input Class Initialized
INFO - 2021-05-04 03:30:09 --> Language Class Initialized
INFO - 2021-05-04 03:30:09 --> Language Class Initialized
INFO - 2021-05-04 03:30:09 --> Config Class Initialized
INFO - 2021-05-04 03:30:09 --> Loader Class Initialized
INFO - 2021-05-04 03:30:09 --> Helper loaded: url_helper
INFO - 2021-05-04 03:30:09 --> Helper loaded: file_helper
INFO - 2021-05-04 03:30:09 --> Helper loaded: form_helper
INFO - 2021-05-04 03:30:09 --> Helper loaded: my_helper
INFO - 2021-05-04 03:30:09 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:30:09 --> Controller Class Initialized
DEBUG - 2021-05-04 03:30:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:30:09 --> Final output sent to browser
DEBUG - 2021-05-04 03:30:09 --> Total execution time: 0.0615
INFO - 2021-05-04 03:30:12 --> Config Class Initialized
INFO - 2021-05-04 03:30:12 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:30:12 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:30:12 --> Utf8 Class Initialized
INFO - 2021-05-04 03:30:12 --> URI Class Initialized
INFO - 2021-05-04 03:30:12 --> Router Class Initialized
INFO - 2021-05-04 03:30:12 --> Output Class Initialized
INFO - 2021-05-04 03:30:12 --> Security Class Initialized
DEBUG - 2021-05-04 03:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:30:12 --> Input Class Initialized
INFO - 2021-05-04 03:30:12 --> Language Class Initialized
INFO - 2021-05-04 03:30:12 --> Language Class Initialized
INFO - 2021-05-04 03:30:12 --> Config Class Initialized
INFO - 2021-05-04 03:30:12 --> Loader Class Initialized
INFO - 2021-05-04 03:30:12 --> Helper loaded: url_helper
INFO - 2021-05-04 03:30:12 --> Helper loaded: file_helper
INFO - 2021-05-04 03:30:12 --> Helper loaded: form_helper
INFO - 2021-05-04 03:30:12 --> Helper loaded: my_helper
INFO - 2021-05-04 03:30:12 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:30:12 --> Controller Class Initialized
DEBUG - 2021-05-04 03:30:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:30:12 --> Final output sent to browser
DEBUG - 2021-05-04 03:30:12 --> Total execution time: 0.0653
INFO - 2021-05-04 03:30:30 --> Config Class Initialized
INFO - 2021-05-04 03:30:30 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:30:30 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:30:30 --> Utf8 Class Initialized
INFO - 2021-05-04 03:30:30 --> URI Class Initialized
INFO - 2021-05-04 03:30:30 --> Router Class Initialized
INFO - 2021-05-04 03:30:30 --> Output Class Initialized
INFO - 2021-05-04 03:30:30 --> Security Class Initialized
DEBUG - 2021-05-04 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:30:30 --> Input Class Initialized
INFO - 2021-05-04 03:30:30 --> Language Class Initialized
INFO - 2021-05-04 03:30:30 --> Language Class Initialized
INFO - 2021-05-04 03:30:30 --> Config Class Initialized
INFO - 2021-05-04 03:30:30 --> Loader Class Initialized
INFO - 2021-05-04 03:30:30 --> Helper loaded: url_helper
INFO - 2021-05-04 03:30:30 --> Helper loaded: file_helper
INFO - 2021-05-04 03:30:30 --> Helper loaded: form_helper
INFO - 2021-05-04 03:30:30 --> Helper loaded: my_helper
INFO - 2021-05-04 03:30:30 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:30:30 --> Controller Class Initialized
DEBUG - 2021-05-04 03:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:30:30 --> Final output sent to browser
DEBUG - 2021-05-04 03:30:30 --> Total execution time: 0.0774
INFO - 2021-05-04 03:30:42 --> Config Class Initialized
INFO - 2021-05-04 03:30:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:30:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:30:42 --> Utf8 Class Initialized
INFO - 2021-05-04 03:30:42 --> URI Class Initialized
INFO - 2021-05-04 03:30:42 --> Router Class Initialized
INFO - 2021-05-04 03:30:42 --> Output Class Initialized
INFO - 2021-05-04 03:30:42 --> Security Class Initialized
DEBUG - 2021-05-04 03:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:30:42 --> Input Class Initialized
INFO - 2021-05-04 03:30:42 --> Language Class Initialized
INFO - 2021-05-04 03:30:42 --> Language Class Initialized
INFO - 2021-05-04 03:30:42 --> Config Class Initialized
INFO - 2021-05-04 03:30:42 --> Loader Class Initialized
INFO - 2021-05-04 03:30:42 --> Helper loaded: url_helper
INFO - 2021-05-04 03:30:42 --> Helper loaded: file_helper
INFO - 2021-05-04 03:30:42 --> Helper loaded: form_helper
INFO - 2021-05-04 03:30:42 --> Helper loaded: my_helper
INFO - 2021-05-04 03:30:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:30:42 --> Controller Class Initialized
DEBUG - 2021-05-04 03:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:30:42 --> Final output sent to browser
DEBUG - 2021-05-04 03:30:42 --> Total execution time: 0.0691
INFO - 2021-05-04 03:30:50 --> Config Class Initialized
INFO - 2021-05-04 03:30:50 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:30:50 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:30:50 --> Utf8 Class Initialized
INFO - 2021-05-04 03:30:50 --> URI Class Initialized
INFO - 2021-05-04 03:30:50 --> Router Class Initialized
INFO - 2021-05-04 03:30:50 --> Output Class Initialized
INFO - 2021-05-04 03:30:50 --> Security Class Initialized
DEBUG - 2021-05-04 03:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:30:50 --> Input Class Initialized
INFO - 2021-05-04 03:30:50 --> Language Class Initialized
INFO - 2021-05-04 03:30:50 --> Language Class Initialized
INFO - 2021-05-04 03:30:50 --> Config Class Initialized
INFO - 2021-05-04 03:30:50 --> Loader Class Initialized
INFO - 2021-05-04 03:30:50 --> Helper loaded: url_helper
INFO - 2021-05-04 03:30:50 --> Helper loaded: file_helper
INFO - 2021-05-04 03:30:50 --> Helper loaded: form_helper
INFO - 2021-05-04 03:30:50 --> Helper loaded: my_helper
INFO - 2021-05-04 03:30:50 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:30:50 --> Controller Class Initialized
DEBUG - 2021-05-04 03:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:30:50 --> Final output sent to browser
DEBUG - 2021-05-04 03:30:50 --> Total execution time: 0.0818
INFO - 2021-05-04 03:31:29 --> Config Class Initialized
INFO - 2021-05-04 03:31:29 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:31:29 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:31:29 --> Utf8 Class Initialized
INFO - 2021-05-04 03:31:29 --> URI Class Initialized
INFO - 2021-05-04 03:31:29 --> Router Class Initialized
INFO - 2021-05-04 03:31:29 --> Output Class Initialized
INFO - 2021-05-04 03:31:29 --> Security Class Initialized
DEBUG - 2021-05-04 03:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:31:29 --> Input Class Initialized
INFO - 2021-05-04 03:31:29 --> Language Class Initialized
INFO - 2021-05-04 03:31:29 --> Language Class Initialized
INFO - 2021-05-04 03:31:29 --> Config Class Initialized
INFO - 2021-05-04 03:31:29 --> Loader Class Initialized
INFO - 2021-05-04 03:31:29 --> Helper loaded: url_helper
INFO - 2021-05-04 03:31:29 --> Helper loaded: file_helper
INFO - 2021-05-04 03:31:29 --> Helper loaded: form_helper
INFO - 2021-05-04 03:31:29 --> Helper loaded: my_helper
INFO - 2021-05-04 03:31:29 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:31:29 --> Controller Class Initialized
DEBUG - 2021-05-04 03:31:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:31:29 --> Final output sent to browser
DEBUG - 2021-05-04 03:31:29 --> Total execution time: 0.0769
INFO - 2021-05-04 03:32:06 --> Config Class Initialized
INFO - 2021-05-04 03:32:06 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:06 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:06 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:06 --> URI Class Initialized
INFO - 2021-05-04 03:32:06 --> Router Class Initialized
INFO - 2021-05-04 03:32:06 --> Output Class Initialized
INFO - 2021-05-04 03:32:06 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:06 --> Input Class Initialized
INFO - 2021-05-04 03:32:06 --> Language Class Initialized
INFO - 2021-05-04 03:32:06 --> Language Class Initialized
INFO - 2021-05-04 03:32:06 --> Config Class Initialized
INFO - 2021-05-04 03:32:06 --> Loader Class Initialized
INFO - 2021-05-04 03:32:06 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:06 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:06 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:06 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:06 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:06 --> Controller Class Initialized
DEBUG - 2021-05-04 03:32:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-05-04 03:32:06 --> Final output sent to browser
DEBUG - 2021-05-04 03:32:06 --> Total execution time: 0.0763
INFO - 2021-05-04 03:32:29 --> Config Class Initialized
INFO - 2021-05-04 03:32:29 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:29 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:29 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:29 --> URI Class Initialized
INFO - 2021-05-04 03:32:29 --> Router Class Initialized
INFO - 2021-05-04 03:32:29 --> Output Class Initialized
INFO - 2021-05-04 03:32:29 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:29 --> Input Class Initialized
INFO - 2021-05-04 03:32:29 --> Language Class Initialized
INFO - 2021-05-04 03:32:29 --> Language Class Initialized
INFO - 2021-05-04 03:32:29 --> Config Class Initialized
INFO - 2021-05-04 03:32:29 --> Loader Class Initialized
INFO - 2021-05-04 03:32:29 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:29 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:29 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:29 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:29 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:29 --> Controller Class Initialized
INFO - 2021-05-04 03:32:29 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:32:29 --> Config Class Initialized
INFO - 2021-05-04 03:32:29 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:29 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:29 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:29 --> URI Class Initialized
INFO - 2021-05-04 03:32:29 --> Router Class Initialized
INFO - 2021-05-04 03:32:29 --> Output Class Initialized
INFO - 2021-05-04 03:32:29 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:29 --> Input Class Initialized
INFO - 2021-05-04 03:32:29 --> Language Class Initialized
INFO - 2021-05-04 03:32:29 --> Language Class Initialized
INFO - 2021-05-04 03:32:29 --> Config Class Initialized
INFO - 2021-05-04 03:32:29 --> Loader Class Initialized
INFO - 2021-05-04 03:32:29 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:29 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:29 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:29 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:29 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:29 --> Controller Class Initialized
DEBUG - 2021-05-04 03:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:32:29 --> Final output sent to browser
DEBUG - 2021-05-04 03:32:29 --> Total execution time: 0.0714
INFO - 2021-05-04 03:32:35 --> Config Class Initialized
INFO - 2021-05-04 03:32:35 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:35 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:35 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:35 --> URI Class Initialized
INFO - 2021-05-04 03:32:35 --> Router Class Initialized
INFO - 2021-05-04 03:32:35 --> Output Class Initialized
INFO - 2021-05-04 03:32:35 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:35 --> Input Class Initialized
INFO - 2021-05-04 03:32:35 --> Language Class Initialized
INFO - 2021-05-04 03:32:35 --> Language Class Initialized
INFO - 2021-05-04 03:32:35 --> Config Class Initialized
INFO - 2021-05-04 03:32:35 --> Loader Class Initialized
INFO - 2021-05-04 03:32:35 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:35 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:35 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:35 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:35 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:35 --> Controller Class Initialized
INFO - 2021-05-04 03:32:35 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:32:35 --> Final output sent to browser
DEBUG - 2021-05-04 03:32:35 --> Total execution time: 0.0719
INFO - 2021-05-04 03:32:36 --> Config Class Initialized
INFO - 2021-05-04 03:32:36 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:36 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:36 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:36 --> URI Class Initialized
INFO - 2021-05-04 03:32:36 --> Router Class Initialized
INFO - 2021-05-04 03:32:36 --> Output Class Initialized
INFO - 2021-05-04 03:32:36 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:36 --> Input Class Initialized
INFO - 2021-05-04 03:32:36 --> Language Class Initialized
INFO - 2021-05-04 03:32:36 --> Language Class Initialized
INFO - 2021-05-04 03:32:36 --> Config Class Initialized
INFO - 2021-05-04 03:32:36 --> Loader Class Initialized
INFO - 2021-05-04 03:32:36 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:36 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:36 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:36 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:36 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:36 --> Controller Class Initialized
DEBUG - 2021-05-04 03:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:32:36 --> Final output sent to browser
DEBUG - 2021-05-04 03:32:36 --> Total execution time: 0.0892
INFO - 2021-05-04 03:32:39 --> Config Class Initialized
INFO - 2021-05-04 03:32:39 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:39 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:39 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:39 --> URI Class Initialized
INFO - 2021-05-04 03:32:39 --> Router Class Initialized
INFO - 2021-05-04 03:32:39 --> Output Class Initialized
INFO - 2021-05-04 03:32:39 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:39 --> Input Class Initialized
INFO - 2021-05-04 03:32:39 --> Language Class Initialized
INFO - 2021-05-04 03:32:39 --> Language Class Initialized
INFO - 2021-05-04 03:32:39 --> Config Class Initialized
INFO - 2021-05-04 03:32:39 --> Loader Class Initialized
INFO - 2021-05-04 03:32:39 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:39 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:39 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:39 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:39 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:39 --> Controller Class Initialized
INFO - 2021-05-04 03:32:39 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:32:39 --> Config Class Initialized
INFO - 2021-05-04 03:32:39 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:39 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:39 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:39 --> URI Class Initialized
INFO - 2021-05-04 03:32:39 --> Router Class Initialized
INFO - 2021-05-04 03:32:39 --> Output Class Initialized
INFO - 2021-05-04 03:32:39 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:39 --> Input Class Initialized
INFO - 2021-05-04 03:32:39 --> Language Class Initialized
INFO - 2021-05-04 03:32:39 --> Language Class Initialized
INFO - 2021-05-04 03:32:39 --> Config Class Initialized
INFO - 2021-05-04 03:32:39 --> Loader Class Initialized
INFO - 2021-05-04 03:32:39 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:39 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:39 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:39 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:39 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:39 --> Controller Class Initialized
DEBUG - 2021-05-04 03:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:32:39 --> Final output sent to browser
DEBUG - 2021-05-04 03:32:39 --> Total execution time: 0.0500
INFO - 2021-05-04 03:32:47 --> Config Class Initialized
INFO - 2021-05-04 03:32:47 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:47 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:47 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:47 --> URI Class Initialized
INFO - 2021-05-04 03:32:47 --> Router Class Initialized
INFO - 2021-05-04 03:32:47 --> Output Class Initialized
INFO - 2021-05-04 03:32:47 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:47 --> Input Class Initialized
INFO - 2021-05-04 03:32:47 --> Language Class Initialized
INFO - 2021-05-04 03:32:47 --> Language Class Initialized
INFO - 2021-05-04 03:32:47 --> Config Class Initialized
INFO - 2021-05-04 03:32:47 --> Loader Class Initialized
INFO - 2021-05-04 03:32:47 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:47 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:47 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:47 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:47 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:47 --> Controller Class Initialized
INFO - 2021-05-04 03:32:47 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:32:47 --> Final output sent to browser
DEBUG - 2021-05-04 03:32:47 --> Total execution time: 0.0590
INFO - 2021-05-04 03:32:47 --> Config Class Initialized
INFO - 2021-05-04 03:32:47 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:32:47 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:32:47 --> Utf8 Class Initialized
INFO - 2021-05-04 03:32:47 --> URI Class Initialized
INFO - 2021-05-04 03:32:47 --> Router Class Initialized
INFO - 2021-05-04 03:32:47 --> Output Class Initialized
INFO - 2021-05-04 03:32:47 --> Security Class Initialized
DEBUG - 2021-05-04 03:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:32:47 --> Input Class Initialized
INFO - 2021-05-04 03:32:47 --> Language Class Initialized
INFO - 2021-05-04 03:32:47 --> Language Class Initialized
INFO - 2021-05-04 03:32:47 --> Config Class Initialized
INFO - 2021-05-04 03:32:47 --> Loader Class Initialized
INFO - 2021-05-04 03:32:47 --> Helper loaded: url_helper
INFO - 2021-05-04 03:32:47 --> Helper loaded: file_helper
INFO - 2021-05-04 03:32:47 --> Helper loaded: form_helper
INFO - 2021-05-04 03:32:47 --> Helper loaded: my_helper
INFO - 2021-05-04 03:32:47 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:32:47 --> Controller Class Initialized
DEBUG - 2021-05-04 03:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:32:47 --> Final output sent to browser
DEBUG - 2021-05-04 03:32:47 --> Total execution time: 0.0914
INFO - 2021-05-04 03:34:42 --> Config Class Initialized
INFO - 2021-05-04 03:34:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:34:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:34:42 --> Utf8 Class Initialized
INFO - 2021-05-04 03:34:42 --> URI Class Initialized
INFO - 2021-05-04 03:34:42 --> Router Class Initialized
INFO - 2021-05-04 03:34:42 --> Output Class Initialized
INFO - 2021-05-04 03:34:42 --> Security Class Initialized
DEBUG - 2021-05-04 03:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:34:42 --> Input Class Initialized
INFO - 2021-05-04 03:34:42 --> Language Class Initialized
INFO - 2021-05-04 03:34:42 --> Language Class Initialized
INFO - 2021-05-04 03:34:42 --> Config Class Initialized
INFO - 2021-05-04 03:34:42 --> Loader Class Initialized
INFO - 2021-05-04 03:34:42 --> Helper loaded: url_helper
INFO - 2021-05-04 03:34:42 --> Helper loaded: file_helper
INFO - 2021-05-04 03:34:42 --> Helper loaded: form_helper
INFO - 2021-05-04 03:34:42 --> Helper loaded: my_helper
INFO - 2021-05-04 03:34:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:34:43 --> Controller Class Initialized
DEBUG - 2021-05-04 03:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 03:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:34:43 --> Final output sent to browser
DEBUG - 2021-05-04 03:34:43 --> Total execution time: 0.0738
INFO - 2021-05-04 03:35:09 --> Config Class Initialized
INFO - 2021-05-04 03:35:09 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:35:09 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:35:09 --> Utf8 Class Initialized
INFO - 2021-05-04 03:35:09 --> URI Class Initialized
INFO - 2021-05-04 03:35:09 --> Router Class Initialized
INFO - 2021-05-04 03:35:09 --> Output Class Initialized
INFO - 2021-05-04 03:35:09 --> Security Class Initialized
DEBUG - 2021-05-04 03:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:35:09 --> Input Class Initialized
INFO - 2021-05-04 03:35:10 --> Language Class Initialized
INFO - 2021-05-04 03:35:10 --> Language Class Initialized
INFO - 2021-05-04 03:35:10 --> Config Class Initialized
INFO - 2021-05-04 03:35:10 --> Loader Class Initialized
INFO - 2021-05-04 03:35:10 --> Helper loaded: url_helper
INFO - 2021-05-04 03:35:10 --> Helper loaded: file_helper
INFO - 2021-05-04 03:35:10 --> Helper loaded: form_helper
INFO - 2021-05-04 03:35:10 --> Helper loaded: my_helper
INFO - 2021-05-04 03:35:10 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:35:10 --> Controller Class Initialized
INFO - 2021-05-04 03:35:10 --> Final output sent to browser
DEBUG - 2021-05-04 03:35:10 --> Total execution time: 0.1005
INFO - 2021-05-04 03:35:33 --> Config Class Initialized
INFO - 2021-05-04 03:35:33 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:35:33 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:35:33 --> Utf8 Class Initialized
INFO - 2021-05-04 03:35:33 --> URI Class Initialized
INFO - 2021-05-04 03:35:33 --> Router Class Initialized
INFO - 2021-05-04 03:35:33 --> Output Class Initialized
INFO - 2021-05-04 03:35:33 --> Security Class Initialized
DEBUG - 2021-05-04 03:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:35:33 --> Input Class Initialized
INFO - 2021-05-04 03:35:33 --> Language Class Initialized
INFO - 2021-05-04 03:35:33 --> Language Class Initialized
INFO - 2021-05-04 03:35:33 --> Config Class Initialized
INFO - 2021-05-04 03:35:33 --> Loader Class Initialized
INFO - 2021-05-04 03:35:33 --> Helper loaded: url_helper
INFO - 2021-05-04 03:35:33 --> Helper loaded: file_helper
INFO - 2021-05-04 03:35:33 --> Helper loaded: form_helper
INFO - 2021-05-04 03:35:33 --> Helper loaded: my_helper
INFO - 2021-05-04 03:35:33 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:35:33 --> Controller Class Initialized
DEBUG - 2021-05-04 03:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-05-04 03:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:35:33 --> Final output sent to browser
DEBUG - 2021-05-04 03:35:33 --> Total execution time: 0.0672
INFO - 2021-05-04 03:35:41 --> Config Class Initialized
INFO - 2021-05-04 03:35:41 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:35:41 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:35:41 --> Utf8 Class Initialized
INFO - 2021-05-04 03:35:41 --> URI Class Initialized
INFO - 2021-05-04 03:35:41 --> Router Class Initialized
INFO - 2021-05-04 03:35:41 --> Output Class Initialized
INFO - 2021-05-04 03:35:41 --> Security Class Initialized
DEBUG - 2021-05-04 03:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:35:41 --> Input Class Initialized
INFO - 2021-05-04 03:35:41 --> Language Class Initialized
INFO - 2021-05-04 03:35:41 --> Language Class Initialized
INFO - 2021-05-04 03:35:41 --> Config Class Initialized
INFO - 2021-05-04 03:35:41 --> Loader Class Initialized
INFO - 2021-05-04 03:35:41 --> Helper loaded: url_helper
INFO - 2021-05-04 03:35:41 --> Helper loaded: file_helper
INFO - 2021-05-04 03:35:41 --> Helper loaded: form_helper
INFO - 2021-05-04 03:35:41 --> Helper loaded: my_helper
INFO - 2021-05-04 03:35:41 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:35:41 --> Controller Class Initialized
INFO - 2021-05-04 03:35:41 --> Final output sent to browser
DEBUG - 2021-05-04 03:35:41 --> Total execution time: 0.1015
INFO - 2021-05-04 03:35:42 --> Config Class Initialized
INFO - 2021-05-04 03:35:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:35:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:35:42 --> Utf8 Class Initialized
INFO - 2021-05-04 03:35:42 --> URI Class Initialized
INFO - 2021-05-04 03:35:42 --> Router Class Initialized
INFO - 2021-05-04 03:35:42 --> Output Class Initialized
INFO - 2021-05-04 03:35:42 --> Security Class Initialized
DEBUG - 2021-05-04 03:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:35:42 --> Input Class Initialized
INFO - 2021-05-04 03:35:42 --> Language Class Initialized
INFO - 2021-05-04 03:35:42 --> Language Class Initialized
INFO - 2021-05-04 03:35:42 --> Config Class Initialized
INFO - 2021-05-04 03:35:42 --> Loader Class Initialized
INFO - 2021-05-04 03:35:42 --> Helper loaded: url_helper
INFO - 2021-05-04 03:35:42 --> Helper loaded: file_helper
INFO - 2021-05-04 03:35:42 --> Helper loaded: form_helper
INFO - 2021-05-04 03:35:42 --> Helper loaded: my_helper
INFO - 2021-05-04 03:35:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:35:42 --> Controller Class Initialized
DEBUG - 2021-05-04 03:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 03:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:35:42 --> Final output sent to browser
DEBUG - 2021-05-04 03:35:42 --> Total execution time: 0.0889
INFO - 2021-05-04 03:35:46 --> Config Class Initialized
INFO - 2021-05-04 03:35:46 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:35:46 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:35:46 --> Utf8 Class Initialized
INFO - 2021-05-04 03:35:46 --> URI Class Initialized
INFO - 2021-05-04 03:35:46 --> Router Class Initialized
INFO - 2021-05-04 03:35:46 --> Output Class Initialized
INFO - 2021-05-04 03:35:46 --> Security Class Initialized
DEBUG - 2021-05-04 03:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:35:46 --> Input Class Initialized
INFO - 2021-05-04 03:35:46 --> Language Class Initialized
INFO - 2021-05-04 03:35:46 --> Language Class Initialized
INFO - 2021-05-04 03:35:46 --> Config Class Initialized
INFO - 2021-05-04 03:35:46 --> Loader Class Initialized
INFO - 2021-05-04 03:35:46 --> Helper loaded: url_helper
INFO - 2021-05-04 03:35:46 --> Helper loaded: file_helper
INFO - 2021-05-04 03:35:46 --> Helper loaded: form_helper
INFO - 2021-05-04 03:35:46 --> Helper loaded: my_helper
INFO - 2021-05-04 03:35:46 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:35:46 --> Controller Class Initialized
DEBUG - 2021-05-04 03:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 03:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:35:46 --> Final output sent to browser
DEBUG - 2021-05-04 03:35:46 --> Total execution time: 0.0530
INFO - 2021-05-04 03:35:51 --> Config Class Initialized
INFO - 2021-05-04 03:35:51 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:35:51 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:35:51 --> Utf8 Class Initialized
INFO - 2021-05-04 03:35:51 --> URI Class Initialized
INFO - 2021-05-04 03:35:51 --> Router Class Initialized
INFO - 2021-05-04 03:35:51 --> Output Class Initialized
INFO - 2021-05-04 03:35:51 --> Security Class Initialized
DEBUG - 2021-05-04 03:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:35:51 --> Input Class Initialized
INFO - 2021-05-04 03:35:51 --> Language Class Initialized
INFO - 2021-05-04 03:35:51 --> Language Class Initialized
INFO - 2021-05-04 03:35:51 --> Config Class Initialized
INFO - 2021-05-04 03:35:51 --> Loader Class Initialized
INFO - 2021-05-04 03:35:51 --> Helper loaded: url_helper
INFO - 2021-05-04 03:35:51 --> Helper loaded: file_helper
INFO - 2021-05-04 03:35:51 --> Helper loaded: form_helper
INFO - 2021-05-04 03:35:51 --> Helper loaded: my_helper
INFO - 2021-05-04 03:35:51 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:35:51 --> Controller Class Initialized
DEBUG - 2021-05-04 03:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-05-04 03:35:51 --> Final output sent to browser
DEBUG - 2021-05-04 03:35:51 --> Total execution time: 0.1885
INFO - 2021-05-04 03:38:53 --> Config Class Initialized
INFO - 2021-05-04 03:38:53 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:38:53 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:38:53 --> Utf8 Class Initialized
INFO - 2021-05-04 03:38:53 --> URI Class Initialized
INFO - 2021-05-04 03:38:53 --> Router Class Initialized
INFO - 2021-05-04 03:38:53 --> Output Class Initialized
INFO - 2021-05-04 03:38:53 --> Security Class Initialized
DEBUG - 2021-05-04 03:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:38:53 --> Input Class Initialized
INFO - 2021-05-04 03:38:53 --> Language Class Initialized
INFO - 2021-05-04 03:38:53 --> Language Class Initialized
INFO - 2021-05-04 03:38:53 --> Config Class Initialized
INFO - 2021-05-04 03:38:53 --> Loader Class Initialized
INFO - 2021-05-04 03:38:53 --> Helper loaded: url_helper
INFO - 2021-05-04 03:38:53 --> Helper loaded: file_helper
INFO - 2021-05-04 03:38:53 --> Helper loaded: form_helper
INFO - 2021-05-04 03:38:53 --> Helper loaded: my_helper
INFO - 2021-05-04 03:38:53 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:38:53 --> Controller Class Initialized
DEBUG - 2021-05-04 03:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-05-04 03:38:53 --> Final output sent to browser
DEBUG - 2021-05-04 03:38:53 --> Total execution time: 0.0740
INFO - 2021-05-04 03:39:32 --> Config Class Initialized
INFO - 2021-05-04 03:39:32 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:39:32 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:39:32 --> Utf8 Class Initialized
INFO - 2021-05-04 03:39:32 --> URI Class Initialized
INFO - 2021-05-04 03:39:32 --> Router Class Initialized
INFO - 2021-05-04 03:39:32 --> Output Class Initialized
INFO - 2021-05-04 03:39:32 --> Security Class Initialized
DEBUG - 2021-05-04 03:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:39:32 --> Input Class Initialized
INFO - 2021-05-04 03:39:32 --> Language Class Initialized
INFO - 2021-05-04 03:39:32 --> Language Class Initialized
INFO - 2021-05-04 03:39:32 --> Config Class Initialized
INFO - 2021-05-04 03:39:32 --> Loader Class Initialized
INFO - 2021-05-04 03:39:32 --> Helper loaded: url_helper
INFO - 2021-05-04 03:39:32 --> Helper loaded: file_helper
INFO - 2021-05-04 03:39:32 --> Helper loaded: form_helper
INFO - 2021-05-04 03:39:32 --> Helper loaded: my_helper
INFO - 2021-05-04 03:39:32 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:39:32 --> Controller Class Initialized
DEBUG - 2021-05-04 03:39:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-05-04 03:39:32 --> Final output sent to browser
DEBUG - 2021-05-04 03:39:32 --> Total execution time: 0.0793
INFO - 2021-05-04 03:39:58 --> Config Class Initialized
INFO - 2021-05-04 03:39:58 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:39:58 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:39:58 --> Utf8 Class Initialized
INFO - 2021-05-04 03:39:58 --> URI Class Initialized
INFO - 2021-05-04 03:39:58 --> Router Class Initialized
INFO - 2021-05-04 03:39:58 --> Output Class Initialized
INFO - 2021-05-04 03:39:58 --> Security Class Initialized
DEBUG - 2021-05-04 03:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:39:58 --> Input Class Initialized
INFO - 2021-05-04 03:39:58 --> Language Class Initialized
INFO - 2021-05-04 03:39:58 --> Language Class Initialized
INFO - 2021-05-04 03:39:58 --> Config Class Initialized
INFO - 2021-05-04 03:39:58 --> Loader Class Initialized
INFO - 2021-05-04 03:39:58 --> Helper loaded: url_helper
INFO - 2021-05-04 03:39:58 --> Helper loaded: file_helper
INFO - 2021-05-04 03:39:58 --> Helper loaded: form_helper
INFO - 2021-05-04 03:39:58 --> Helper loaded: my_helper
INFO - 2021-05-04 03:39:58 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:39:58 --> Controller Class Initialized
INFO - 2021-05-04 03:39:58 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:39:58 --> Config Class Initialized
INFO - 2021-05-04 03:39:58 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:39:58 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:39:58 --> Utf8 Class Initialized
INFO - 2021-05-04 03:39:58 --> URI Class Initialized
INFO - 2021-05-04 03:39:58 --> Router Class Initialized
INFO - 2021-05-04 03:39:58 --> Output Class Initialized
INFO - 2021-05-04 03:39:58 --> Security Class Initialized
DEBUG - 2021-05-04 03:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:39:58 --> Input Class Initialized
INFO - 2021-05-04 03:39:58 --> Language Class Initialized
INFO - 2021-05-04 03:39:58 --> Language Class Initialized
INFO - 2021-05-04 03:39:58 --> Config Class Initialized
INFO - 2021-05-04 03:39:58 --> Loader Class Initialized
INFO - 2021-05-04 03:39:58 --> Helper loaded: url_helper
INFO - 2021-05-04 03:39:58 --> Helper loaded: file_helper
INFO - 2021-05-04 03:39:58 --> Helper loaded: form_helper
INFO - 2021-05-04 03:39:58 --> Helper loaded: my_helper
INFO - 2021-05-04 03:39:58 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:39:58 --> Controller Class Initialized
DEBUG - 2021-05-04 03:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 03:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:39:58 --> Final output sent to browser
DEBUG - 2021-05-04 03:39:58 --> Total execution time: 0.0554
INFO - 2021-05-04 03:40:03 --> Config Class Initialized
INFO - 2021-05-04 03:40:03 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:40:03 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:40:03 --> Utf8 Class Initialized
INFO - 2021-05-04 03:40:03 --> URI Class Initialized
INFO - 2021-05-04 03:40:03 --> Router Class Initialized
INFO - 2021-05-04 03:40:03 --> Output Class Initialized
INFO - 2021-05-04 03:40:03 --> Security Class Initialized
DEBUG - 2021-05-04 03:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:40:03 --> Input Class Initialized
INFO - 2021-05-04 03:40:03 --> Language Class Initialized
INFO - 2021-05-04 03:40:03 --> Language Class Initialized
INFO - 2021-05-04 03:40:03 --> Config Class Initialized
INFO - 2021-05-04 03:40:03 --> Loader Class Initialized
INFO - 2021-05-04 03:40:03 --> Helper loaded: url_helper
INFO - 2021-05-04 03:40:03 --> Helper loaded: file_helper
INFO - 2021-05-04 03:40:03 --> Helper loaded: form_helper
INFO - 2021-05-04 03:40:03 --> Helper loaded: my_helper
INFO - 2021-05-04 03:40:03 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:40:03 --> Controller Class Initialized
INFO - 2021-05-04 03:40:03 --> Helper loaded: cookie_helper
INFO - 2021-05-04 03:40:03 --> Final output sent to browser
DEBUG - 2021-05-04 03:40:03 --> Total execution time: 0.0793
INFO - 2021-05-04 03:40:05 --> Config Class Initialized
INFO - 2021-05-04 03:40:05 --> Hooks Class Initialized
DEBUG - 2021-05-04 03:40:05 --> UTF-8 Support Enabled
INFO - 2021-05-04 03:40:05 --> Utf8 Class Initialized
INFO - 2021-05-04 03:40:05 --> URI Class Initialized
INFO - 2021-05-04 03:40:05 --> Router Class Initialized
INFO - 2021-05-04 03:40:05 --> Output Class Initialized
INFO - 2021-05-04 03:40:05 --> Security Class Initialized
DEBUG - 2021-05-04 03:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 03:40:05 --> Input Class Initialized
INFO - 2021-05-04 03:40:05 --> Language Class Initialized
INFO - 2021-05-04 03:40:05 --> Language Class Initialized
INFO - 2021-05-04 03:40:05 --> Config Class Initialized
INFO - 2021-05-04 03:40:05 --> Loader Class Initialized
INFO - 2021-05-04 03:40:05 --> Helper loaded: url_helper
INFO - 2021-05-04 03:40:05 --> Helper loaded: file_helper
INFO - 2021-05-04 03:40:05 --> Helper loaded: form_helper
INFO - 2021-05-04 03:40:05 --> Helper loaded: my_helper
INFO - 2021-05-04 03:40:05 --> Database Driver Class Initialized
DEBUG - 2021-05-04 03:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 03:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 03:40:05 --> Controller Class Initialized
DEBUG - 2021-05-04 03:40:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 03:40:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 03:40:05 --> Final output sent to browser
DEBUG - 2021-05-04 03:40:05 --> Total execution time: 0.0895
INFO - 2021-05-04 04:13:06 --> Config Class Initialized
INFO - 2021-05-04 04:13:06 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:13:06 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:13:06 --> Utf8 Class Initialized
INFO - 2021-05-04 04:13:06 --> URI Class Initialized
INFO - 2021-05-04 04:13:06 --> Router Class Initialized
INFO - 2021-05-04 04:13:06 --> Output Class Initialized
INFO - 2021-05-04 04:13:06 --> Security Class Initialized
DEBUG - 2021-05-04 04:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:13:06 --> Input Class Initialized
INFO - 2021-05-04 04:13:06 --> Language Class Initialized
INFO - 2021-05-04 04:13:06 --> Language Class Initialized
INFO - 2021-05-04 04:13:06 --> Config Class Initialized
INFO - 2021-05-04 04:13:06 --> Loader Class Initialized
INFO - 2021-05-04 04:13:06 --> Helper loaded: url_helper
INFO - 2021-05-04 04:13:06 --> Helper loaded: file_helper
INFO - 2021-05-04 04:13:06 --> Helper loaded: form_helper
INFO - 2021-05-04 04:13:06 --> Helper loaded: my_helper
INFO - 2021-05-04 04:13:06 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:13:06 --> Controller Class Initialized
DEBUG - 2021-05-04 04:13:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 04:13:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:13:07 --> Final output sent to browser
DEBUG - 2021-05-04 04:13:07 --> Total execution time: 0.1206
INFO - 2021-05-04 04:13:23 --> Config Class Initialized
INFO - 2021-05-04 04:13:23 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:13:23 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:13:23 --> Utf8 Class Initialized
INFO - 2021-05-04 04:13:23 --> URI Class Initialized
INFO - 2021-05-04 04:13:23 --> Router Class Initialized
INFO - 2021-05-04 04:13:23 --> Output Class Initialized
INFO - 2021-05-04 04:13:23 --> Security Class Initialized
DEBUG - 2021-05-04 04:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:13:23 --> Input Class Initialized
INFO - 2021-05-04 04:13:23 --> Language Class Initialized
INFO - 2021-05-04 04:13:23 --> Language Class Initialized
INFO - 2021-05-04 04:13:23 --> Config Class Initialized
INFO - 2021-05-04 04:13:23 --> Loader Class Initialized
INFO - 2021-05-04 04:13:23 --> Helper loaded: url_helper
INFO - 2021-05-04 04:13:23 --> Helper loaded: file_helper
INFO - 2021-05-04 04:13:23 --> Helper loaded: form_helper
INFO - 2021-05-04 04:13:23 --> Helper loaded: my_helper
INFO - 2021-05-04 04:13:23 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:13:23 --> Controller Class Initialized
INFO - 2021-05-04 04:13:23 --> Final output sent to browser
DEBUG - 2021-05-04 04:13:23 --> Total execution time: 0.1290
INFO - 2021-05-04 04:13:33 --> Config Class Initialized
INFO - 2021-05-04 04:13:33 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:13:33 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:13:33 --> Utf8 Class Initialized
INFO - 2021-05-04 04:13:33 --> URI Class Initialized
INFO - 2021-05-04 04:13:33 --> Router Class Initialized
INFO - 2021-05-04 04:13:33 --> Output Class Initialized
INFO - 2021-05-04 04:13:33 --> Security Class Initialized
DEBUG - 2021-05-04 04:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:13:33 --> Input Class Initialized
INFO - 2021-05-04 04:13:33 --> Language Class Initialized
INFO - 2021-05-04 04:13:33 --> Language Class Initialized
INFO - 2021-05-04 04:13:33 --> Config Class Initialized
INFO - 2021-05-04 04:13:33 --> Loader Class Initialized
INFO - 2021-05-04 04:13:33 --> Helper loaded: url_helper
INFO - 2021-05-04 04:13:33 --> Helper loaded: file_helper
INFO - 2021-05-04 04:13:33 --> Helper loaded: form_helper
INFO - 2021-05-04 04:13:33 --> Helper loaded: my_helper
INFO - 2021-05-04 04:13:33 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:13:33 --> Controller Class Initialized
DEBUG - 2021-05-04 04:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-05-04 04:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:13:33 --> Final output sent to browser
DEBUG - 2021-05-04 04:13:33 --> Total execution time: 0.0647
INFO - 2021-05-04 04:13:38 --> Config Class Initialized
INFO - 2021-05-04 04:13:38 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:13:38 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:13:38 --> Utf8 Class Initialized
INFO - 2021-05-04 04:13:38 --> URI Class Initialized
INFO - 2021-05-04 04:13:38 --> Router Class Initialized
INFO - 2021-05-04 04:13:38 --> Output Class Initialized
INFO - 2021-05-04 04:13:38 --> Security Class Initialized
DEBUG - 2021-05-04 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:13:38 --> Input Class Initialized
INFO - 2021-05-04 04:13:38 --> Language Class Initialized
INFO - 2021-05-04 04:13:38 --> Language Class Initialized
INFO - 2021-05-04 04:13:38 --> Config Class Initialized
INFO - 2021-05-04 04:13:38 --> Loader Class Initialized
INFO - 2021-05-04 04:13:38 --> Helper loaded: url_helper
INFO - 2021-05-04 04:13:38 --> Helper loaded: file_helper
INFO - 2021-05-04 04:13:38 --> Helper loaded: form_helper
INFO - 2021-05-04 04:13:38 --> Helper loaded: my_helper
INFO - 2021-05-04 04:13:38 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:13:38 --> Controller Class Initialized
INFO - 2021-05-04 04:13:38 --> Final output sent to browser
DEBUG - 2021-05-04 04:13:38 --> Total execution time: 0.1307
INFO - 2021-05-04 04:13:42 --> Config Class Initialized
INFO - 2021-05-04 04:13:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:13:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:13:42 --> Utf8 Class Initialized
INFO - 2021-05-04 04:13:42 --> URI Class Initialized
INFO - 2021-05-04 04:13:42 --> Router Class Initialized
INFO - 2021-05-04 04:13:42 --> Output Class Initialized
INFO - 2021-05-04 04:13:42 --> Security Class Initialized
DEBUG - 2021-05-04 04:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:13:42 --> Input Class Initialized
INFO - 2021-05-04 04:13:42 --> Language Class Initialized
INFO - 2021-05-04 04:13:42 --> Language Class Initialized
INFO - 2021-05-04 04:13:42 --> Config Class Initialized
INFO - 2021-05-04 04:13:42 --> Loader Class Initialized
INFO - 2021-05-04 04:13:42 --> Helper loaded: url_helper
INFO - 2021-05-04 04:13:42 --> Helper loaded: file_helper
INFO - 2021-05-04 04:13:42 --> Helper loaded: form_helper
INFO - 2021-05-04 04:13:42 --> Helper loaded: my_helper
INFO - 2021-05-04 04:13:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:13:42 --> Controller Class Initialized
DEBUG - 2021-05-04 04:13:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 04:13:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:13:42 --> Final output sent to browser
DEBUG - 2021-05-04 04:13:42 --> Total execution time: 0.0826
INFO - 2021-05-04 04:13:50 --> Config Class Initialized
INFO - 2021-05-04 04:13:50 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:13:50 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:13:50 --> Utf8 Class Initialized
INFO - 2021-05-04 04:13:50 --> URI Class Initialized
INFO - 2021-05-04 04:13:50 --> Router Class Initialized
INFO - 2021-05-04 04:13:50 --> Output Class Initialized
INFO - 2021-05-04 04:13:50 --> Security Class Initialized
DEBUG - 2021-05-04 04:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:13:50 --> Input Class Initialized
INFO - 2021-05-04 04:13:50 --> Language Class Initialized
INFO - 2021-05-04 04:13:50 --> Language Class Initialized
INFO - 2021-05-04 04:13:50 --> Config Class Initialized
INFO - 2021-05-04 04:13:50 --> Loader Class Initialized
INFO - 2021-05-04 04:13:50 --> Helper loaded: url_helper
INFO - 2021-05-04 04:13:50 --> Helper loaded: file_helper
INFO - 2021-05-04 04:13:50 --> Helper loaded: form_helper
INFO - 2021-05-04 04:13:50 --> Helper loaded: my_helper
INFO - 2021-05-04 04:13:50 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:13:50 --> Controller Class Initialized
DEBUG - 2021-05-04 04:13:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-05-04 04:13:50 --> Final output sent to browser
DEBUG - 2021-05-04 04:13:50 --> Total execution time: 0.0843
INFO - 2021-05-04 04:15:56 --> Config Class Initialized
INFO - 2021-05-04 04:15:56 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:15:56 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:15:56 --> Utf8 Class Initialized
INFO - 2021-05-04 04:15:56 --> URI Class Initialized
INFO - 2021-05-04 04:15:56 --> Router Class Initialized
INFO - 2021-05-04 04:15:56 --> Output Class Initialized
INFO - 2021-05-04 04:15:56 --> Security Class Initialized
DEBUG - 2021-05-04 04:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:15:56 --> Input Class Initialized
INFO - 2021-05-04 04:15:56 --> Language Class Initialized
INFO - 2021-05-04 04:15:56 --> Language Class Initialized
INFO - 2021-05-04 04:15:56 --> Config Class Initialized
INFO - 2021-05-04 04:15:56 --> Loader Class Initialized
INFO - 2021-05-04 04:15:56 --> Helper loaded: url_helper
INFO - 2021-05-04 04:15:56 --> Helper loaded: file_helper
INFO - 2021-05-04 04:15:56 --> Helper loaded: form_helper
INFO - 2021-05-04 04:15:56 --> Helper loaded: my_helper
INFO - 2021-05-04 04:15:56 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:15:56 --> Controller Class Initialized
DEBUG - 2021-05-04 04:15:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-05-04 04:15:56 --> Final output sent to browser
DEBUG - 2021-05-04 04:15:56 --> Total execution time: 0.0712
INFO - 2021-05-04 04:16:19 --> Config Class Initialized
INFO - 2021-05-04 04:16:19 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:16:19 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:16:19 --> Utf8 Class Initialized
INFO - 2021-05-04 04:16:19 --> URI Class Initialized
INFO - 2021-05-04 04:16:19 --> Router Class Initialized
INFO - 2021-05-04 04:16:19 --> Output Class Initialized
INFO - 2021-05-04 04:16:19 --> Security Class Initialized
DEBUG - 2021-05-04 04:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:16:19 --> Input Class Initialized
INFO - 2021-05-04 04:16:19 --> Language Class Initialized
INFO - 2021-05-04 04:16:19 --> Language Class Initialized
INFO - 2021-05-04 04:16:19 --> Config Class Initialized
INFO - 2021-05-04 04:16:19 --> Loader Class Initialized
INFO - 2021-05-04 04:16:19 --> Helper loaded: url_helper
INFO - 2021-05-04 04:16:19 --> Helper loaded: file_helper
INFO - 2021-05-04 04:16:19 --> Helper loaded: form_helper
INFO - 2021-05-04 04:16:19 --> Helper loaded: my_helper
INFO - 2021-05-04 04:16:19 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:16:19 --> Controller Class Initialized
DEBUG - 2021-05-04 04:16:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-05-04 04:16:19 --> Final output sent to browser
DEBUG - 2021-05-04 04:16:19 --> Total execution time: 0.0706
INFO - 2021-05-04 04:16:45 --> Config Class Initialized
INFO - 2021-05-04 04:16:45 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:16:45 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:16:45 --> Utf8 Class Initialized
INFO - 2021-05-04 04:16:45 --> URI Class Initialized
INFO - 2021-05-04 04:16:45 --> Router Class Initialized
INFO - 2021-05-04 04:16:45 --> Output Class Initialized
INFO - 2021-05-04 04:16:45 --> Security Class Initialized
DEBUG - 2021-05-04 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:16:45 --> Input Class Initialized
INFO - 2021-05-04 04:16:45 --> Language Class Initialized
INFO - 2021-05-04 04:16:45 --> Language Class Initialized
INFO - 2021-05-04 04:16:45 --> Config Class Initialized
INFO - 2021-05-04 04:16:45 --> Loader Class Initialized
INFO - 2021-05-04 04:16:45 --> Helper loaded: url_helper
INFO - 2021-05-04 04:16:45 --> Helper loaded: file_helper
INFO - 2021-05-04 04:16:45 --> Helper loaded: form_helper
INFO - 2021-05-04 04:16:45 --> Helper loaded: my_helper
INFO - 2021-05-04 04:16:45 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:16:45 --> Controller Class Initialized
DEBUG - 2021-05-04 04:16:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-05-04 04:16:45 --> Final output sent to browser
DEBUG - 2021-05-04 04:16:45 --> Total execution time: 0.0594
INFO - 2021-05-04 04:19:37 --> Config Class Initialized
INFO - 2021-05-04 04:19:37 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:19:37 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:19:37 --> Utf8 Class Initialized
INFO - 2021-05-04 04:19:37 --> URI Class Initialized
INFO - 2021-05-04 04:19:37 --> Router Class Initialized
INFO - 2021-05-04 04:19:37 --> Output Class Initialized
INFO - 2021-05-04 04:19:37 --> Security Class Initialized
DEBUG - 2021-05-04 04:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:19:37 --> Input Class Initialized
INFO - 2021-05-04 04:19:37 --> Language Class Initialized
INFO - 2021-05-04 04:19:37 --> Language Class Initialized
INFO - 2021-05-04 04:19:37 --> Config Class Initialized
INFO - 2021-05-04 04:19:37 --> Loader Class Initialized
INFO - 2021-05-04 04:19:37 --> Helper loaded: url_helper
INFO - 2021-05-04 04:19:37 --> Helper loaded: file_helper
INFO - 2021-05-04 04:19:37 --> Helper loaded: form_helper
INFO - 2021-05-04 04:19:37 --> Helper loaded: my_helper
INFO - 2021-05-04 04:19:37 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:19:37 --> Controller Class Initialized
INFO - 2021-05-04 04:19:37 --> Helper loaded: cookie_helper
INFO - 2021-05-04 04:19:37 --> Config Class Initialized
INFO - 2021-05-04 04:19:37 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:19:37 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:19:37 --> Utf8 Class Initialized
INFO - 2021-05-04 04:19:37 --> URI Class Initialized
INFO - 2021-05-04 04:19:37 --> Router Class Initialized
INFO - 2021-05-04 04:19:37 --> Output Class Initialized
INFO - 2021-05-04 04:19:37 --> Security Class Initialized
DEBUG - 2021-05-04 04:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:19:37 --> Input Class Initialized
INFO - 2021-05-04 04:19:37 --> Language Class Initialized
INFO - 2021-05-04 04:19:37 --> Language Class Initialized
INFO - 2021-05-04 04:19:37 --> Config Class Initialized
INFO - 2021-05-04 04:19:37 --> Loader Class Initialized
INFO - 2021-05-04 04:19:37 --> Helper loaded: url_helper
INFO - 2021-05-04 04:19:37 --> Helper loaded: file_helper
INFO - 2021-05-04 04:19:37 --> Helper loaded: form_helper
INFO - 2021-05-04 04:19:37 --> Helper loaded: my_helper
INFO - 2021-05-04 04:19:37 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:19:37 --> Controller Class Initialized
DEBUG - 2021-05-04 04:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 04:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:19:37 --> Final output sent to browser
DEBUG - 2021-05-04 04:19:37 --> Total execution time: 0.0639
INFO - 2021-05-04 04:19:42 --> Config Class Initialized
INFO - 2021-05-04 04:19:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:19:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:19:42 --> Utf8 Class Initialized
INFO - 2021-05-04 04:19:42 --> URI Class Initialized
INFO - 2021-05-04 04:19:42 --> Router Class Initialized
INFO - 2021-05-04 04:19:42 --> Output Class Initialized
INFO - 2021-05-04 04:19:42 --> Security Class Initialized
DEBUG - 2021-05-04 04:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:19:42 --> Input Class Initialized
INFO - 2021-05-04 04:19:42 --> Language Class Initialized
INFO - 2021-05-04 04:19:42 --> Language Class Initialized
INFO - 2021-05-04 04:19:42 --> Config Class Initialized
INFO - 2021-05-04 04:19:42 --> Loader Class Initialized
INFO - 2021-05-04 04:19:42 --> Helper loaded: url_helper
INFO - 2021-05-04 04:19:42 --> Helper loaded: file_helper
INFO - 2021-05-04 04:19:42 --> Helper loaded: form_helper
INFO - 2021-05-04 04:19:42 --> Helper loaded: my_helper
INFO - 2021-05-04 04:19:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:19:42 --> Controller Class Initialized
INFO - 2021-05-04 04:19:42 --> Helper loaded: cookie_helper
INFO - 2021-05-04 04:19:42 --> Final output sent to browser
DEBUG - 2021-05-04 04:19:42 --> Total execution time: 0.0666
INFO - 2021-05-04 04:19:43 --> Config Class Initialized
INFO - 2021-05-04 04:19:43 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:19:43 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:19:43 --> Utf8 Class Initialized
INFO - 2021-05-04 04:19:43 --> URI Class Initialized
INFO - 2021-05-04 04:19:43 --> Router Class Initialized
INFO - 2021-05-04 04:19:43 --> Output Class Initialized
INFO - 2021-05-04 04:19:43 --> Security Class Initialized
DEBUG - 2021-05-04 04:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:19:43 --> Input Class Initialized
INFO - 2021-05-04 04:19:43 --> Language Class Initialized
INFO - 2021-05-04 04:19:43 --> Language Class Initialized
INFO - 2021-05-04 04:19:43 --> Config Class Initialized
INFO - 2021-05-04 04:19:43 --> Loader Class Initialized
INFO - 2021-05-04 04:19:43 --> Helper loaded: url_helper
INFO - 2021-05-04 04:19:43 --> Helper loaded: file_helper
INFO - 2021-05-04 04:19:43 --> Helper loaded: form_helper
INFO - 2021-05-04 04:19:43 --> Helper loaded: my_helper
INFO - 2021-05-04 04:19:43 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:19:43 --> Controller Class Initialized
DEBUG - 2021-05-04 04:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 04:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:19:43 --> Final output sent to browser
DEBUG - 2021-05-04 04:19:43 --> Total execution time: 0.0693
INFO - 2021-05-04 04:20:04 --> Config Class Initialized
INFO - 2021-05-04 04:20:04 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:20:04 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:20:04 --> Utf8 Class Initialized
INFO - 2021-05-04 04:20:04 --> URI Class Initialized
INFO - 2021-05-04 04:20:04 --> Router Class Initialized
INFO - 2021-05-04 04:20:04 --> Output Class Initialized
INFO - 2021-05-04 04:20:04 --> Security Class Initialized
DEBUG - 2021-05-04 04:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:20:04 --> Input Class Initialized
INFO - 2021-05-04 04:20:04 --> Language Class Initialized
INFO - 2021-05-04 04:20:04 --> Language Class Initialized
INFO - 2021-05-04 04:20:04 --> Config Class Initialized
INFO - 2021-05-04 04:20:04 --> Loader Class Initialized
INFO - 2021-05-04 04:20:04 --> Helper loaded: url_helper
INFO - 2021-05-04 04:20:04 --> Helper loaded: file_helper
INFO - 2021-05-04 04:20:04 --> Helper loaded: form_helper
INFO - 2021-05-04 04:20:04 --> Helper loaded: my_helper
INFO - 2021-05-04 04:20:04 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:20:04 --> Controller Class Initialized
DEBUG - 2021-05-04 04:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 04:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:20:04 --> Final output sent to browser
DEBUG - 2021-05-04 04:20:04 --> Total execution time: 0.1022
INFO - 2021-05-04 04:20:14 --> Config Class Initialized
INFO - 2021-05-04 04:20:14 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:20:14 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:20:14 --> Utf8 Class Initialized
INFO - 2021-05-04 04:20:14 --> URI Class Initialized
INFO - 2021-05-04 04:20:14 --> Router Class Initialized
INFO - 2021-05-04 04:20:14 --> Output Class Initialized
INFO - 2021-05-04 04:20:14 --> Security Class Initialized
DEBUG - 2021-05-04 04:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:20:14 --> Input Class Initialized
INFO - 2021-05-04 04:20:14 --> Language Class Initialized
INFO - 2021-05-04 04:20:14 --> Language Class Initialized
INFO - 2021-05-04 04:20:14 --> Config Class Initialized
INFO - 2021-05-04 04:20:14 --> Loader Class Initialized
INFO - 2021-05-04 04:20:14 --> Helper loaded: url_helper
INFO - 2021-05-04 04:20:14 --> Helper loaded: file_helper
INFO - 2021-05-04 04:20:14 --> Helper loaded: form_helper
INFO - 2021-05-04 04:20:14 --> Helper loaded: my_helper
INFO - 2021-05-04 04:20:14 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:20:14 --> Controller Class Initialized
INFO - 2021-05-04 04:20:15 --> Final output sent to browser
DEBUG - 2021-05-04 04:20:15 --> Total execution time: 0.1261
INFO - 2021-05-04 04:20:20 --> Config Class Initialized
INFO - 2021-05-04 04:20:20 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:20:20 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:20:20 --> Utf8 Class Initialized
INFO - 2021-05-04 04:20:20 --> URI Class Initialized
INFO - 2021-05-04 04:20:20 --> Router Class Initialized
INFO - 2021-05-04 04:20:20 --> Output Class Initialized
INFO - 2021-05-04 04:20:20 --> Security Class Initialized
DEBUG - 2021-05-04 04:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:20:20 --> Input Class Initialized
INFO - 2021-05-04 04:20:20 --> Language Class Initialized
INFO - 2021-05-04 04:20:20 --> Language Class Initialized
INFO - 2021-05-04 04:20:20 --> Config Class Initialized
INFO - 2021-05-04 04:20:20 --> Loader Class Initialized
INFO - 2021-05-04 04:20:20 --> Helper loaded: url_helper
INFO - 2021-05-04 04:20:20 --> Helper loaded: file_helper
INFO - 2021-05-04 04:20:20 --> Helper loaded: form_helper
INFO - 2021-05-04 04:20:20 --> Helper loaded: my_helper
INFO - 2021-05-04 04:20:20 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:20:20 --> Controller Class Initialized
DEBUG - 2021-05-04 04:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-05-04 04:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:20:20 --> Final output sent to browser
DEBUG - 2021-05-04 04:20:20 --> Total execution time: 0.0574
INFO - 2021-05-04 04:20:24 --> Config Class Initialized
INFO - 2021-05-04 04:20:24 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:20:24 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:20:24 --> Utf8 Class Initialized
INFO - 2021-05-04 04:20:24 --> URI Class Initialized
INFO - 2021-05-04 04:20:24 --> Router Class Initialized
INFO - 2021-05-04 04:20:24 --> Output Class Initialized
INFO - 2021-05-04 04:20:24 --> Security Class Initialized
DEBUG - 2021-05-04 04:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:20:24 --> Input Class Initialized
INFO - 2021-05-04 04:20:24 --> Language Class Initialized
INFO - 2021-05-04 04:20:24 --> Language Class Initialized
INFO - 2021-05-04 04:20:24 --> Config Class Initialized
INFO - 2021-05-04 04:20:24 --> Loader Class Initialized
INFO - 2021-05-04 04:20:24 --> Helper loaded: url_helper
INFO - 2021-05-04 04:20:24 --> Helper loaded: file_helper
INFO - 2021-05-04 04:20:24 --> Helper loaded: form_helper
INFO - 2021-05-04 04:20:24 --> Helper loaded: my_helper
INFO - 2021-05-04 04:20:24 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:20:24 --> Controller Class Initialized
INFO - 2021-05-04 04:20:24 --> Final output sent to browser
DEBUG - 2021-05-04 04:20:24 --> Total execution time: 0.1041
INFO - 2021-05-04 04:20:27 --> Config Class Initialized
INFO - 2021-05-04 04:20:27 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:20:27 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:20:27 --> Utf8 Class Initialized
INFO - 2021-05-04 04:20:27 --> URI Class Initialized
INFO - 2021-05-04 04:20:27 --> Router Class Initialized
INFO - 2021-05-04 04:20:27 --> Output Class Initialized
INFO - 2021-05-04 04:20:27 --> Security Class Initialized
DEBUG - 2021-05-04 04:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:20:27 --> Input Class Initialized
INFO - 2021-05-04 04:20:27 --> Language Class Initialized
INFO - 2021-05-04 04:20:27 --> Language Class Initialized
INFO - 2021-05-04 04:20:27 --> Config Class Initialized
INFO - 2021-05-04 04:20:27 --> Loader Class Initialized
INFO - 2021-05-04 04:20:27 --> Helper loaded: url_helper
INFO - 2021-05-04 04:20:27 --> Helper loaded: file_helper
INFO - 2021-05-04 04:20:27 --> Helper loaded: form_helper
INFO - 2021-05-04 04:20:27 --> Helper loaded: my_helper
INFO - 2021-05-04 04:20:27 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:20:27 --> Controller Class Initialized
DEBUG - 2021-05-04 04:20:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 04:20:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:20:27 --> Final output sent to browser
DEBUG - 2021-05-04 04:20:27 --> Total execution time: 0.0834
INFO - 2021-05-04 04:20:29 --> Config Class Initialized
INFO - 2021-05-04 04:20:29 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:20:29 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:20:29 --> Utf8 Class Initialized
INFO - 2021-05-04 04:20:29 --> URI Class Initialized
INFO - 2021-05-04 04:20:29 --> Router Class Initialized
INFO - 2021-05-04 04:20:29 --> Output Class Initialized
INFO - 2021-05-04 04:20:29 --> Security Class Initialized
DEBUG - 2021-05-04 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:20:29 --> Input Class Initialized
INFO - 2021-05-04 04:20:29 --> Language Class Initialized
INFO - 2021-05-04 04:20:29 --> Language Class Initialized
INFO - 2021-05-04 04:20:29 --> Config Class Initialized
INFO - 2021-05-04 04:20:29 --> Loader Class Initialized
INFO - 2021-05-04 04:20:29 --> Helper loaded: url_helper
INFO - 2021-05-04 04:20:29 --> Helper loaded: file_helper
INFO - 2021-05-04 04:20:29 --> Helper loaded: form_helper
INFO - 2021-05-04 04:20:29 --> Helper loaded: my_helper
INFO - 2021-05-04 04:20:29 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:20:29 --> Controller Class Initialized
DEBUG - 2021-05-04 04:20:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-05-04 04:20:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:20:29 --> Final output sent to browser
DEBUG - 2021-05-04 04:20:29 --> Total execution time: 0.1138
INFO - 2021-05-04 04:20:30 --> Config Class Initialized
INFO - 2021-05-04 04:20:30 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:20:30 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:20:30 --> Utf8 Class Initialized
INFO - 2021-05-04 04:20:30 --> URI Class Initialized
INFO - 2021-05-04 04:20:30 --> Router Class Initialized
INFO - 2021-05-04 04:20:30 --> Output Class Initialized
INFO - 2021-05-04 04:20:30 --> Security Class Initialized
DEBUG - 2021-05-04 04:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:20:30 --> Input Class Initialized
INFO - 2021-05-04 04:20:30 --> Language Class Initialized
INFO - 2021-05-04 04:20:30 --> Language Class Initialized
INFO - 2021-05-04 04:20:30 --> Config Class Initialized
INFO - 2021-05-04 04:20:30 --> Loader Class Initialized
INFO - 2021-05-04 04:20:30 --> Helper loaded: url_helper
INFO - 2021-05-04 04:20:30 --> Helper loaded: file_helper
INFO - 2021-05-04 04:20:30 --> Helper loaded: form_helper
INFO - 2021-05-04 04:20:30 --> Helper loaded: my_helper
INFO - 2021-05-04 04:20:30 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:20:30 --> Controller Class Initialized
DEBUG - 2021-05-04 04:20:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-05-04 04:20:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:20:30 --> Final output sent to browser
DEBUG - 2021-05-04 04:20:30 --> Total execution time: 0.0652
INFO - 2021-05-04 04:20:32 --> Config Class Initialized
INFO - 2021-05-04 04:20:32 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:20:32 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:20:32 --> Utf8 Class Initialized
INFO - 2021-05-04 04:20:32 --> URI Class Initialized
INFO - 2021-05-04 04:20:32 --> Router Class Initialized
INFO - 2021-05-04 04:20:32 --> Output Class Initialized
INFO - 2021-05-04 04:20:32 --> Security Class Initialized
DEBUG - 2021-05-04 04:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:20:32 --> Input Class Initialized
INFO - 2021-05-04 04:20:32 --> Language Class Initialized
INFO - 2021-05-04 04:20:32 --> Language Class Initialized
INFO - 2021-05-04 04:20:32 --> Config Class Initialized
INFO - 2021-05-04 04:20:32 --> Loader Class Initialized
INFO - 2021-05-04 04:20:32 --> Helper loaded: url_helper
INFO - 2021-05-04 04:20:32 --> Helper loaded: file_helper
INFO - 2021-05-04 04:20:32 --> Helper loaded: form_helper
INFO - 2021-05-04 04:20:32 --> Helper loaded: my_helper
INFO - 2021-05-04 04:20:32 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:20:32 --> Controller Class Initialized
DEBUG - 2021-05-04 04:20:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 04:20:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:20:32 --> Final output sent to browser
DEBUG - 2021-05-04 04:20:32 --> Total execution time: 0.0579
INFO - 2021-05-04 04:23:33 --> Config Class Initialized
INFO - 2021-05-04 04:23:33 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:23:33 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:23:33 --> Utf8 Class Initialized
INFO - 2021-05-04 04:23:33 --> URI Class Initialized
INFO - 2021-05-04 04:23:33 --> Router Class Initialized
INFO - 2021-05-04 04:23:33 --> Output Class Initialized
INFO - 2021-05-04 04:23:33 --> Security Class Initialized
DEBUG - 2021-05-04 04:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:23:33 --> Input Class Initialized
INFO - 2021-05-04 04:23:33 --> Language Class Initialized
INFO - 2021-05-04 04:23:33 --> Language Class Initialized
INFO - 2021-05-04 04:23:33 --> Config Class Initialized
INFO - 2021-05-04 04:23:33 --> Loader Class Initialized
INFO - 2021-05-04 04:23:33 --> Helper loaded: url_helper
INFO - 2021-05-04 04:23:33 --> Helper loaded: file_helper
INFO - 2021-05-04 04:23:33 --> Helper loaded: form_helper
INFO - 2021-05-04 04:23:33 --> Helper loaded: my_helper
INFO - 2021-05-04 04:23:33 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:23:33 --> Controller Class Initialized
DEBUG - 2021-05-04 04:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-05-04 04:23:33 --> Final output sent to browser
DEBUG - 2021-05-04 04:23:33 --> Total execution time: 0.0827
INFO - 2021-05-04 04:24:58 --> Config Class Initialized
INFO - 2021-05-04 04:24:58 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:24:58 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:24:58 --> Utf8 Class Initialized
INFO - 2021-05-04 04:24:58 --> URI Class Initialized
INFO - 2021-05-04 04:24:58 --> Router Class Initialized
INFO - 2021-05-04 04:24:58 --> Output Class Initialized
INFO - 2021-05-04 04:24:58 --> Security Class Initialized
DEBUG - 2021-05-04 04:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:24:58 --> Input Class Initialized
INFO - 2021-05-04 04:24:58 --> Language Class Initialized
INFO - 2021-05-04 04:24:58 --> Language Class Initialized
INFO - 2021-05-04 04:24:58 --> Config Class Initialized
INFO - 2021-05-04 04:24:58 --> Loader Class Initialized
INFO - 2021-05-04 04:24:58 --> Helper loaded: url_helper
INFO - 2021-05-04 04:24:58 --> Helper loaded: file_helper
INFO - 2021-05-04 04:24:58 --> Helper loaded: form_helper
INFO - 2021-05-04 04:24:58 --> Helper loaded: my_helper
INFO - 2021-05-04 04:24:58 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:24:58 --> Controller Class Initialized
DEBUG - 2021-05-04 04:24:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-05-04 04:24:58 --> Final output sent to browser
DEBUG - 2021-05-04 04:24:58 --> Total execution time: 0.0687
INFO - 2021-05-04 04:25:19 --> Config Class Initialized
INFO - 2021-05-04 04:25:19 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:25:19 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:25:19 --> Utf8 Class Initialized
INFO - 2021-05-04 04:25:19 --> URI Class Initialized
INFO - 2021-05-04 04:25:19 --> Router Class Initialized
INFO - 2021-05-04 04:25:19 --> Output Class Initialized
INFO - 2021-05-04 04:25:19 --> Security Class Initialized
DEBUG - 2021-05-04 04:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:25:19 --> Input Class Initialized
INFO - 2021-05-04 04:25:19 --> Language Class Initialized
INFO - 2021-05-04 04:25:19 --> Language Class Initialized
INFO - 2021-05-04 04:25:19 --> Config Class Initialized
INFO - 2021-05-04 04:25:19 --> Loader Class Initialized
INFO - 2021-05-04 04:25:19 --> Helper loaded: url_helper
INFO - 2021-05-04 04:25:19 --> Helper loaded: file_helper
INFO - 2021-05-04 04:25:19 --> Helper loaded: form_helper
INFO - 2021-05-04 04:25:19 --> Helper loaded: my_helper
INFO - 2021-05-04 04:25:19 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:25:19 --> Controller Class Initialized
DEBUG - 2021-05-04 04:25:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-05-04 04:25:19 --> Final output sent to browser
DEBUG - 2021-05-04 04:25:19 --> Total execution time: 0.0683
INFO - 2021-05-04 04:25:42 --> Config Class Initialized
INFO - 2021-05-04 04:25:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:25:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:25:42 --> Utf8 Class Initialized
INFO - 2021-05-04 04:25:42 --> URI Class Initialized
INFO - 2021-05-04 04:25:42 --> Router Class Initialized
INFO - 2021-05-04 04:25:42 --> Output Class Initialized
INFO - 2021-05-04 04:25:42 --> Security Class Initialized
DEBUG - 2021-05-04 04:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:25:42 --> Input Class Initialized
INFO - 2021-05-04 04:25:42 --> Language Class Initialized
INFO - 2021-05-04 04:25:42 --> Language Class Initialized
INFO - 2021-05-04 04:25:42 --> Config Class Initialized
INFO - 2021-05-04 04:25:42 --> Loader Class Initialized
INFO - 2021-05-04 04:25:42 --> Helper loaded: url_helper
INFO - 2021-05-04 04:25:42 --> Helper loaded: file_helper
INFO - 2021-05-04 04:25:42 --> Helper loaded: form_helper
INFO - 2021-05-04 04:25:42 --> Helper loaded: my_helper
INFO - 2021-05-04 04:25:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:25:42 --> Controller Class Initialized
INFO - 2021-05-04 04:25:42 --> Helper loaded: cookie_helper
INFO - 2021-05-04 04:25:42 --> Config Class Initialized
INFO - 2021-05-04 04:25:42 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:25:42 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:25:42 --> Utf8 Class Initialized
INFO - 2021-05-04 04:25:42 --> URI Class Initialized
INFO - 2021-05-04 04:25:42 --> Router Class Initialized
INFO - 2021-05-04 04:25:42 --> Output Class Initialized
INFO - 2021-05-04 04:25:42 --> Security Class Initialized
DEBUG - 2021-05-04 04:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:25:42 --> Input Class Initialized
INFO - 2021-05-04 04:25:42 --> Language Class Initialized
INFO - 2021-05-04 04:25:42 --> Language Class Initialized
INFO - 2021-05-04 04:25:42 --> Config Class Initialized
INFO - 2021-05-04 04:25:42 --> Loader Class Initialized
INFO - 2021-05-04 04:25:42 --> Helper loaded: url_helper
INFO - 2021-05-04 04:25:42 --> Helper loaded: file_helper
INFO - 2021-05-04 04:25:42 --> Helper loaded: form_helper
INFO - 2021-05-04 04:25:42 --> Helper loaded: my_helper
INFO - 2021-05-04 04:25:42 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:25:42 --> Controller Class Initialized
DEBUG - 2021-05-04 04:25:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 04:25:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:25:42 --> Final output sent to browser
DEBUG - 2021-05-04 04:25:42 --> Total execution time: 0.0685
INFO - 2021-05-04 04:25:48 --> Config Class Initialized
INFO - 2021-05-04 04:25:48 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:25:48 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:25:48 --> Utf8 Class Initialized
INFO - 2021-05-04 04:25:48 --> URI Class Initialized
INFO - 2021-05-04 04:25:48 --> Router Class Initialized
INFO - 2021-05-04 04:25:48 --> Output Class Initialized
INFO - 2021-05-04 04:25:48 --> Security Class Initialized
DEBUG - 2021-05-04 04:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:25:48 --> Input Class Initialized
INFO - 2021-05-04 04:25:48 --> Language Class Initialized
INFO - 2021-05-04 04:25:48 --> Language Class Initialized
INFO - 2021-05-04 04:25:48 --> Config Class Initialized
INFO - 2021-05-04 04:25:48 --> Loader Class Initialized
INFO - 2021-05-04 04:25:48 --> Helper loaded: url_helper
INFO - 2021-05-04 04:25:48 --> Helper loaded: file_helper
INFO - 2021-05-04 04:25:48 --> Helper loaded: form_helper
INFO - 2021-05-04 04:25:48 --> Helper loaded: my_helper
INFO - 2021-05-04 04:25:48 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:25:48 --> Controller Class Initialized
INFO - 2021-05-04 04:25:48 --> Helper loaded: cookie_helper
INFO - 2021-05-04 04:25:48 --> Final output sent to browser
DEBUG - 2021-05-04 04:25:48 --> Total execution time: 0.0629
INFO - 2021-05-04 04:25:49 --> Config Class Initialized
INFO - 2021-05-04 04:25:49 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:25:49 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:25:49 --> Utf8 Class Initialized
INFO - 2021-05-04 04:25:49 --> URI Class Initialized
INFO - 2021-05-04 04:25:49 --> Router Class Initialized
INFO - 2021-05-04 04:25:49 --> Output Class Initialized
INFO - 2021-05-04 04:25:49 --> Security Class Initialized
DEBUG - 2021-05-04 04:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:25:49 --> Input Class Initialized
INFO - 2021-05-04 04:25:49 --> Language Class Initialized
INFO - 2021-05-04 04:25:49 --> Language Class Initialized
INFO - 2021-05-04 04:25:49 --> Config Class Initialized
INFO - 2021-05-04 04:25:49 --> Loader Class Initialized
INFO - 2021-05-04 04:25:49 --> Helper loaded: url_helper
INFO - 2021-05-04 04:25:49 --> Helper loaded: file_helper
INFO - 2021-05-04 04:25:49 --> Helper loaded: form_helper
INFO - 2021-05-04 04:25:49 --> Helper loaded: my_helper
INFO - 2021-05-04 04:25:49 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:25:49 --> Controller Class Initialized
DEBUG - 2021-05-04 04:25:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 04:25:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:25:49 --> Final output sent to browser
DEBUG - 2021-05-04 04:25:49 --> Total execution time: 0.0709
INFO - 2021-05-04 04:25:52 --> Config Class Initialized
INFO - 2021-05-04 04:25:52 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:25:52 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:25:52 --> Utf8 Class Initialized
INFO - 2021-05-04 04:25:52 --> URI Class Initialized
INFO - 2021-05-04 04:25:52 --> Router Class Initialized
INFO - 2021-05-04 04:25:52 --> Output Class Initialized
INFO - 2021-05-04 04:25:52 --> Security Class Initialized
DEBUG - 2021-05-04 04:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:25:52 --> Input Class Initialized
INFO - 2021-05-04 04:25:52 --> Language Class Initialized
INFO - 2021-05-04 04:25:52 --> Language Class Initialized
INFO - 2021-05-04 04:25:52 --> Config Class Initialized
INFO - 2021-05-04 04:25:52 --> Loader Class Initialized
INFO - 2021-05-04 04:25:52 --> Helper loaded: url_helper
INFO - 2021-05-04 04:25:52 --> Helper loaded: file_helper
INFO - 2021-05-04 04:25:52 --> Helper loaded: form_helper
INFO - 2021-05-04 04:25:52 --> Helper loaded: my_helper
INFO - 2021-05-04 04:25:52 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:25:52 --> Controller Class Initialized
DEBUG - 2021-05-04 04:25:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 04:25:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:25:52 --> Final output sent to browser
DEBUG - 2021-05-04 04:25:52 --> Total execution time: 0.1077
INFO - 2021-05-04 04:27:04 --> Config Class Initialized
INFO - 2021-05-04 04:27:04 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:27:04 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:27:04 --> Utf8 Class Initialized
INFO - 2021-05-04 04:27:04 --> URI Class Initialized
INFO - 2021-05-04 04:27:04 --> Router Class Initialized
INFO - 2021-05-04 04:27:04 --> Output Class Initialized
INFO - 2021-05-04 04:27:04 --> Security Class Initialized
DEBUG - 2021-05-04 04:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:27:04 --> Input Class Initialized
INFO - 2021-05-04 04:27:04 --> Language Class Initialized
INFO - 2021-05-04 04:27:04 --> Language Class Initialized
INFO - 2021-05-04 04:27:04 --> Config Class Initialized
INFO - 2021-05-04 04:27:04 --> Loader Class Initialized
INFO - 2021-05-04 04:27:04 --> Helper loaded: url_helper
INFO - 2021-05-04 04:27:04 --> Helper loaded: file_helper
INFO - 2021-05-04 04:27:04 --> Helper loaded: form_helper
INFO - 2021-05-04 04:27:04 --> Helper loaded: my_helper
INFO - 2021-05-04 04:27:04 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:27:04 --> Controller Class Initialized
INFO - 2021-05-04 04:27:04 --> Final output sent to browser
DEBUG - 2021-05-04 04:27:04 --> Total execution time: 0.1231
INFO - 2021-05-04 04:27:08 --> Config Class Initialized
INFO - 2021-05-04 04:27:08 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:27:08 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:27:08 --> Utf8 Class Initialized
INFO - 2021-05-04 04:27:08 --> URI Class Initialized
INFO - 2021-05-04 04:27:08 --> Router Class Initialized
INFO - 2021-05-04 04:27:08 --> Output Class Initialized
INFO - 2021-05-04 04:27:08 --> Security Class Initialized
DEBUG - 2021-05-04 04:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:27:08 --> Input Class Initialized
INFO - 2021-05-04 04:27:08 --> Language Class Initialized
INFO - 2021-05-04 04:27:08 --> Language Class Initialized
INFO - 2021-05-04 04:27:08 --> Config Class Initialized
INFO - 2021-05-04 04:27:08 --> Loader Class Initialized
INFO - 2021-05-04 04:27:08 --> Helper loaded: url_helper
INFO - 2021-05-04 04:27:08 --> Helper loaded: file_helper
INFO - 2021-05-04 04:27:08 --> Helper loaded: form_helper
INFO - 2021-05-04 04:27:08 --> Helper loaded: my_helper
INFO - 2021-05-04 04:27:08 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:27:08 --> Controller Class Initialized
DEBUG - 2021-05-04 04:27:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-05-04 04:27:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:27:08 --> Final output sent to browser
DEBUG - 2021-05-04 04:27:08 --> Total execution time: 0.0763
INFO - 2021-05-04 04:27:13 --> Config Class Initialized
INFO - 2021-05-04 04:27:13 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:27:13 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:27:13 --> Utf8 Class Initialized
INFO - 2021-05-04 04:27:13 --> URI Class Initialized
INFO - 2021-05-04 04:27:13 --> Router Class Initialized
INFO - 2021-05-04 04:27:13 --> Output Class Initialized
INFO - 2021-05-04 04:27:13 --> Security Class Initialized
DEBUG - 2021-05-04 04:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:27:13 --> Input Class Initialized
INFO - 2021-05-04 04:27:13 --> Language Class Initialized
INFO - 2021-05-04 04:27:13 --> Language Class Initialized
INFO - 2021-05-04 04:27:13 --> Config Class Initialized
INFO - 2021-05-04 04:27:13 --> Loader Class Initialized
INFO - 2021-05-04 04:27:13 --> Helper loaded: url_helper
INFO - 2021-05-04 04:27:13 --> Helper loaded: file_helper
INFO - 2021-05-04 04:27:13 --> Helper loaded: form_helper
INFO - 2021-05-04 04:27:13 --> Helper loaded: my_helper
INFO - 2021-05-04 04:27:13 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:27:13 --> Controller Class Initialized
INFO - 2021-05-04 04:27:13 --> Final output sent to browser
DEBUG - 2021-05-04 04:27:13 --> Total execution time: 0.1176
INFO - 2021-05-04 04:27:18 --> Config Class Initialized
INFO - 2021-05-04 04:27:18 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:27:18 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:27:18 --> Utf8 Class Initialized
INFO - 2021-05-04 04:27:18 --> URI Class Initialized
INFO - 2021-05-04 04:27:18 --> Router Class Initialized
INFO - 2021-05-04 04:27:18 --> Output Class Initialized
INFO - 2021-05-04 04:27:18 --> Security Class Initialized
DEBUG - 2021-05-04 04:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:27:18 --> Input Class Initialized
INFO - 2021-05-04 04:27:18 --> Language Class Initialized
INFO - 2021-05-04 04:27:18 --> Language Class Initialized
INFO - 2021-05-04 04:27:18 --> Config Class Initialized
INFO - 2021-05-04 04:27:18 --> Loader Class Initialized
INFO - 2021-05-04 04:27:18 --> Helper loaded: url_helper
INFO - 2021-05-04 04:27:18 --> Helper loaded: file_helper
INFO - 2021-05-04 04:27:18 --> Helper loaded: form_helper
INFO - 2021-05-04 04:27:18 --> Helper loaded: my_helper
INFO - 2021-05-04 04:27:18 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:27:18 --> Controller Class Initialized
DEBUG - 2021-05-04 04:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 04:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:27:18 --> Final output sent to browser
DEBUG - 2021-05-04 04:27:18 --> Total execution time: 0.0529
INFO - 2021-05-04 04:27:29 --> Config Class Initialized
INFO - 2021-05-04 04:27:29 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:27:29 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:27:29 --> Utf8 Class Initialized
INFO - 2021-05-04 04:27:29 --> URI Class Initialized
INFO - 2021-05-04 04:27:29 --> Router Class Initialized
INFO - 2021-05-04 04:27:29 --> Output Class Initialized
INFO - 2021-05-04 04:27:29 --> Security Class Initialized
DEBUG - 2021-05-04 04:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:27:29 --> Input Class Initialized
INFO - 2021-05-04 04:27:29 --> Language Class Initialized
INFO - 2021-05-04 04:27:29 --> Language Class Initialized
INFO - 2021-05-04 04:27:29 --> Config Class Initialized
INFO - 2021-05-04 04:27:29 --> Loader Class Initialized
INFO - 2021-05-04 04:27:29 --> Helper loaded: url_helper
INFO - 2021-05-04 04:27:29 --> Helper loaded: file_helper
INFO - 2021-05-04 04:27:29 --> Helper loaded: form_helper
INFO - 2021-05-04 04:27:29 --> Helper loaded: my_helper
INFO - 2021-05-04 04:27:29 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:27:29 --> Controller Class Initialized
DEBUG - 2021-05-04 04:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 04:27:29 --> Final output sent to browser
DEBUG - 2021-05-04 04:27:29 --> Total execution time: 0.0901
INFO - 2021-05-04 04:29:49 --> Config Class Initialized
INFO - 2021-05-04 04:29:49 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:29:49 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:29:49 --> Utf8 Class Initialized
INFO - 2021-05-04 04:29:49 --> URI Class Initialized
INFO - 2021-05-04 04:29:49 --> Router Class Initialized
INFO - 2021-05-04 04:29:49 --> Output Class Initialized
INFO - 2021-05-04 04:29:49 --> Security Class Initialized
DEBUG - 2021-05-04 04:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:29:49 --> Input Class Initialized
INFO - 2021-05-04 04:29:49 --> Language Class Initialized
INFO - 2021-05-04 04:29:49 --> Language Class Initialized
INFO - 2021-05-04 04:29:49 --> Config Class Initialized
INFO - 2021-05-04 04:29:49 --> Loader Class Initialized
INFO - 2021-05-04 04:29:49 --> Helper loaded: url_helper
INFO - 2021-05-04 04:29:49 --> Helper loaded: file_helper
INFO - 2021-05-04 04:29:49 --> Helper loaded: form_helper
INFO - 2021-05-04 04:29:49 --> Helper loaded: my_helper
INFO - 2021-05-04 04:29:49 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:29:49 --> Controller Class Initialized
DEBUG - 2021-05-04 04:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-05-04 04:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 04:29:49 --> Final output sent to browser
DEBUG - 2021-05-04 04:29:49 --> Total execution time: 0.0905
INFO - 2021-05-04 04:29:51 --> Config Class Initialized
INFO - 2021-05-04 04:29:51 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:29:51 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:29:51 --> Utf8 Class Initialized
INFO - 2021-05-04 04:29:51 --> URI Class Initialized
INFO - 2021-05-04 04:29:51 --> Router Class Initialized
INFO - 2021-05-04 04:29:51 --> Output Class Initialized
INFO - 2021-05-04 04:29:51 --> Security Class Initialized
DEBUG - 2021-05-04 04:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:29:51 --> Input Class Initialized
INFO - 2021-05-04 04:29:51 --> Language Class Initialized
INFO - 2021-05-04 04:29:51 --> Language Class Initialized
INFO - 2021-05-04 04:29:51 --> Config Class Initialized
INFO - 2021-05-04 04:29:51 --> Loader Class Initialized
INFO - 2021-05-04 04:29:51 --> Helper loaded: url_helper
INFO - 2021-05-04 04:29:51 --> Helper loaded: file_helper
INFO - 2021-05-04 04:29:51 --> Helper loaded: form_helper
INFO - 2021-05-04 04:29:51 --> Helper loaded: my_helper
INFO - 2021-05-04 04:29:51 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:29:51 --> Controller Class Initialized
DEBUG - 2021-05-04 04:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-05-04 04:29:51 --> Final output sent to browser
DEBUG - 2021-05-04 04:29:51 --> Total execution time: 0.0901
INFO - 2021-05-04 04:34:43 --> Config Class Initialized
INFO - 2021-05-04 04:34:43 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:34:43 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:34:43 --> Utf8 Class Initialized
INFO - 2021-05-04 04:34:43 --> URI Class Initialized
INFO - 2021-05-04 04:34:43 --> Router Class Initialized
INFO - 2021-05-04 04:34:43 --> Output Class Initialized
INFO - 2021-05-04 04:34:43 --> Security Class Initialized
DEBUG - 2021-05-04 04:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:34:43 --> Input Class Initialized
INFO - 2021-05-04 04:34:43 --> Language Class Initialized
INFO - 2021-05-04 04:34:43 --> Language Class Initialized
INFO - 2021-05-04 04:34:43 --> Config Class Initialized
INFO - 2021-05-04 04:34:43 --> Loader Class Initialized
INFO - 2021-05-04 04:34:43 --> Helper loaded: url_helper
INFO - 2021-05-04 04:34:43 --> Helper loaded: file_helper
INFO - 2021-05-04 04:34:43 --> Helper loaded: form_helper
INFO - 2021-05-04 04:34:43 --> Helper loaded: my_helper
INFO - 2021-05-04 04:34:43 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:34:43 --> Controller Class Initialized
DEBUG - 2021-05-04 04:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 04:34:43 --> Final output sent to browser
DEBUG - 2021-05-04 04:34:43 --> Total execution time: 0.0707
INFO - 2021-05-04 04:35:47 --> Config Class Initialized
INFO - 2021-05-04 04:35:47 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:35:47 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:35:47 --> Utf8 Class Initialized
INFO - 2021-05-04 04:35:47 --> URI Class Initialized
INFO - 2021-05-04 04:35:47 --> Router Class Initialized
INFO - 2021-05-04 04:35:47 --> Output Class Initialized
INFO - 2021-05-04 04:35:47 --> Security Class Initialized
DEBUG - 2021-05-04 04:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:35:47 --> Input Class Initialized
INFO - 2021-05-04 04:35:47 --> Language Class Initialized
INFO - 2021-05-04 04:35:47 --> Language Class Initialized
INFO - 2021-05-04 04:35:47 --> Config Class Initialized
INFO - 2021-05-04 04:35:47 --> Loader Class Initialized
INFO - 2021-05-04 04:35:47 --> Helper loaded: url_helper
INFO - 2021-05-04 04:35:47 --> Helper loaded: file_helper
INFO - 2021-05-04 04:35:47 --> Helper loaded: form_helper
INFO - 2021-05-04 04:35:48 --> Helper loaded: my_helper
INFO - 2021-05-04 04:35:48 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:35:48 --> Controller Class Initialized
DEBUG - 2021-05-04 04:35:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 04:35:48 --> Final output sent to browser
DEBUG - 2021-05-04 04:35:48 --> Total execution time: 0.0872
INFO - 2021-05-04 04:36:27 --> Config Class Initialized
INFO - 2021-05-04 04:36:27 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:36:27 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:36:27 --> Utf8 Class Initialized
INFO - 2021-05-04 04:36:27 --> URI Class Initialized
INFO - 2021-05-04 04:36:27 --> Router Class Initialized
INFO - 2021-05-04 04:36:27 --> Output Class Initialized
INFO - 2021-05-04 04:36:27 --> Security Class Initialized
DEBUG - 2021-05-04 04:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:36:27 --> Input Class Initialized
INFO - 2021-05-04 04:36:27 --> Language Class Initialized
INFO - 2021-05-04 04:36:27 --> Language Class Initialized
INFO - 2021-05-04 04:36:27 --> Config Class Initialized
INFO - 2021-05-04 04:36:27 --> Loader Class Initialized
INFO - 2021-05-04 04:36:27 --> Helper loaded: url_helper
INFO - 2021-05-04 04:36:27 --> Helper loaded: file_helper
INFO - 2021-05-04 04:36:27 --> Helper loaded: form_helper
INFO - 2021-05-04 04:36:27 --> Helper loaded: my_helper
INFO - 2021-05-04 04:36:27 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:36:27 --> Controller Class Initialized
DEBUG - 2021-05-04 04:36:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 04:36:27 --> Final output sent to browser
DEBUG - 2021-05-04 04:36:27 --> Total execution time: 0.0785
INFO - 2021-05-04 04:37:02 --> Config Class Initialized
INFO - 2021-05-04 04:37:02 --> Hooks Class Initialized
DEBUG - 2021-05-04 04:37:02 --> UTF-8 Support Enabled
INFO - 2021-05-04 04:37:02 --> Utf8 Class Initialized
INFO - 2021-05-04 04:37:02 --> URI Class Initialized
INFO - 2021-05-04 04:37:02 --> Router Class Initialized
INFO - 2021-05-04 04:37:02 --> Output Class Initialized
INFO - 2021-05-04 04:37:02 --> Security Class Initialized
DEBUG - 2021-05-04 04:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 04:37:02 --> Input Class Initialized
INFO - 2021-05-04 04:37:02 --> Language Class Initialized
INFO - 2021-05-04 04:37:02 --> Language Class Initialized
INFO - 2021-05-04 04:37:02 --> Config Class Initialized
INFO - 2021-05-04 04:37:02 --> Loader Class Initialized
INFO - 2021-05-04 04:37:02 --> Helper loaded: url_helper
INFO - 2021-05-04 04:37:02 --> Helper loaded: file_helper
INFO - 2021-05-04 04:37:02 --> Helper loaded: form_helper
INFO - 2021-05-04 04:37:02 --> Helper loaded: my_helper
INFO - 2021-05-04 04:37:02 --> Database Driver Class Initialized
DEBUG - 2021-05-04 04:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 04:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 04:37:02 --> Controller Class Initialized
DEBUG - 2021-05-04 04:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 04:37:02 --> Final output sent to browser
DEBUG - 2021-05-04 04:37:02 --> Total execution time: 0.0700
INFO - 2021-05-04 05:26:23 --> Config Class Initialized
INFO - 2021-05-04 05:26:23 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:26:23 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:26:23 --> Utf8 Class Initialized
INFO - 2021-05-04 05:26:23 --> URI Class Initialized
INFO - 2021-05-04 05:26:23 --> Router Class Initialized
INFO - 2021-05-04 05:26:23 --> Output Class Initialized
INFO - 2021-05-04 05:26:23 --> Security Class Initialized
DEBUG - 2021-05-04 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:26:23 --> Input Class Initialized
INFO - 2021-05-04 05:26:23 --> Language Class Initialized
INFO - 2021-05-04 05:26:23 --> Language Class Initialized
INFO - 2021-05-04 05:26:23 --> Config Class Initialized
INFO - 2021-05-04 05:26:23 --> Loader Class Initialized
INFO - 2021-05-04 05:26:23 --> Helper loaded: url_helper
INFO - 2021-05-04 05:26:23 --> Helper loaded: file_helper
INFO - 2021-05-04 05:26:23 --> Helper loaded: form_helper
INFO - 2021-05-04 05:26:23 --> Helper loaded: my_helper
INFO - 2021-05-04 05:26:23 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:26:23 --> Controller Class Initialized
DEBUG - 2021-05-04 05:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:26:23 --> Final output sent to browser
DEBUG - 2021-05-04 05:26:23 --> Total execution time: 0.0874
INFO - 2021-05-04 05:28:14 --> Config Class Initialized
INFO - 2021-05-04 05:28:14 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:28:14 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:28:14 --> Utf8 Class Initialized
INFO - 2021-05-04 05:28:14 --> URI Class Initialized
INFO - 2021-05-04 05:28:14 --> Router Class Initialized
INFO - 2021-05-04 05:28:14 --> Output Class Initialized
INFO - 2021-05-04 05:28:14 --> Security Class Initialized
DEBUG - 2021-05-04 05:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:28:14 --> Input Class Initialized
INFO - 2021-05-04 05:28:14 --> Language Class Initialized
INFO - 2021-05-04 05:28:14 --> Language Class Initialized
INFO - 2021-05-04 05:28:14 --> Config Class Initialized
INFO - 2021-05-04 05:28:14 --> Loader Class Initialized
INFO - 2021-05-04 05:28:14 --> Helper loaded: url_helper
INFO - 2021-05-04 05:28:14 --> Helper loaded: file_helper
INFO - 2021-05-04 05:28:14 --> Helper loaded: form_helper
INFO - 2021-05-04 05:28:14 --> Helper loaded: my_helper
INFO - 2021-05-04 05:28:14 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:28:14 --> Controller Class Initialized
DEBUG - 2021-05-04 05:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:28:14 --> Final output sent to browser
DEBUG - 2021-05-04 05:28:14 --> Total execution time: 0.0791
INFO - 2021-05-04 05:29:15 --> Config Class Initialized
INFO - 2021-05-04 05:29:15 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:29:15 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:29:15 --> Utf8 Class Initialized
INFO - 2021-05-04 05:29:15 --> URI Class Initialized
INFO - 2021-05-04 05:29:15 --> Router Class Initialized
INFO - 2021-05-04 05:29:15 --> Output Class Initialized
INFO - 2021-05-04 05:29:15 --> Security Class Initialized
DEBUG - 2021-05-04 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:29:15 --> Input Class Initialized
INFO - 2021-05-04 05:29:15 --> Language Class Initialized
INFO - 2021-05-04 05:29:15 --> Language Class Initialized
INFO - 2021-05-04 05:29:15 --> Config Class Initialized
INFO - 2021-05-04 05:29:15 --> Loader Class Initialized
INFO - 2021-05-04 05:29:15 --> Helper loaded: url_helper
INFO - 2021-05-04 05:29:15 --> Helper loaded: file_helper
INFO - 2021-05-04 05:29:15 --> Helper loaded: form_helper
INFO - 2021-05-04 05:29:15 --> Helper loaded: my_helper
INFO - 2021-05-04 05:29:15 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:29:15 --> Controller Class Initialized
DEBUG - 2021-05-04 05:29:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:29:15 --> Final output sent to browser
DEBUG - 2021-05-04 05:29:15 --> Total execution time: 0.0573
INFO - 2021-05-04 05:30:00 --> Config Class Initialized
INFO - 2021-05-04 05:30:00 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:30:00 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:30:00 --> Utf8 Class Initialized
INFO - 2021-05-04 05:30:00 --> URI Class Initialized
INFO - 2021-05-04 05:30:00 --> Router Class Initialized
INFO - 2021-05-04 05:30:00 --> Output Class Initialized
INFO - 2021-05-04 05:30:00 --> Security Class Initialized
DEBUG - 2021-05-04 05:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:30:00 --> Input Class Initialized
INFO - 2021-05-04 05:30:01 --> Language Class Initialized
INFO - 2021-05-04 05:30:01 --> Language Class Initialized
INFO - 2021-05-04 05:30:01 --> Config Class Initialized
INFO - 2021-05-04 05:30:01 --> Loader Class Initialized
INFO - 2021-05-04 05:30:01 --> Helper loaded: url_helper
INFO - 2021-05-04 05:30:01 --> Helper loaded: file_helper
INFO - 2021-05-04 05:30:01 --> Helper loaded: form_helper
INFO - 2021-05-04 05:30:01 --> Helper loaded: my_helper
INFO - 2021-05-04 05:30:01 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:30:01 --> Controller Class Initialized
DEBUG - 2021-05-04 05:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:30:01 --> Final output sent to browser
DEBUG - 2021-05-04 05:30:01 --> Total execution time: 0.0698
INFO - 2021-05-04 05:30:15 --> Config Class Initialized
INFO - 2021-05-04 05:30:15 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:30:15 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:30:15 --> Utf8 Class Initialized
INFO - 2021-05-04 05:30:15 --> URI Class Initialized
INFO - 2021-05-04 05:30:15 --> Router Class Initialized
INFO - 2021-05-04 05:30:15 --> Output Class Initialized
INFO - 2021-05-04 05:30:15 --> Security Class Initialized
DEBUG - 2021-05-04 05:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:30:15 --> Input Class Initialized
INFO - 2021-05-04 05:30:15 --> Language Class Initialized
INFO - 2021-05-04 05:30:15 --> Language Class Initialized
INFO - 2021-05-04 05:30:15 --> Config Class Initialized
INFO - 2021-05-04 05:30:15 --> Loader Class Initialized
INFO - 2021-05-04 05:30:15 --> Helper loaded: url_helper
INFO - 2021-05-04 05:30:15 --> Helper loaded: file_helper
INFO - 2021-05-04 05:30:15 --> Helper loaded: form_helper
INFO - 2021-05-04 05:30:15 --> Helper loaded: my_helper
INFO - 2021-05-04 05:30:15 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:30:15 --> Controller Class Initialized
DEBUG - 2021-05-04 05:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:30:15 --> Final output sent to browser
DEBUG - 2021-05-04 05:30:15 --> Total execution time: 0.0723
INFO - 2021-05-04 05:30:33 --> Config Class Initialized
INFO - 2021-05-04 05:30:33 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:30:33 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:30:33 --> Utf8 Class Initialized
INFO - 2021-05-04 05:30:33 --> URI Class Initialized
INFO - 2021-05-04 05:30:33 --> Router Class Initialized
INFO - 2021-05-04 05:30:33 --> Output Class Initialized
INFO - 2021-05-04 05:30:33 --> Security Class Initialized
DEBUG - 2021-05-04 05:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:30:33 --> Input Class Initialized
INFO - 2021-05-04 05:30:33 --> Language Class Initialized
INFO - 2021-05-04 05:30:33 --> Language Class Initialized
INFO - 2021-05-04 05:30:33 --> Config Class Initialized
INFO - 2021-05-04 05:30:33 --> Loader Class Initialized
INFO - 2021-05-04 05:30:33 --> Helper loaded: url_helper
INFO - 2021-05-04 05:30:33 --> Helper loaded: file_helper
INFO - 2021-05-04 05:30:33 --> Helper loaded: form_helper
INFO - 2021-05-04 05:30:33 --> Helper loaded: my_helper
INFO - 2021-05-04 05:30:33 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:30:33 --> Controller Class Initialized
DEBUG - 2021-05-04 05:30:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:30:33 --> Final output sent to browser
DEBUG - 2021-05-04 05:30:33 --> Total execution time: 0.0642
INFO - 2021-05-04 05:30:56 --> Config Class Initialized
INFO - 2021-05-04 05:30:56 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:30:56 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:30:56 --> Utf8 Class Initialized
INFO - 2021-05-04 05:30:56 --> URI Class Initialized
INFO - 2021-05-04 05:30:56 --> Router Class Initialized
INFO - 2021-05-04 05:30:56 --> Output Class Initialized
INFO - 2021-05-04 05:30:56 --> Security Class Initialized
DEBUG - 2021-05-04 05:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:30:56 --> Input Class Initialized
INFO - 2021-05-04 05:30:56 --> Language Class Initialized
INFO - 2021-05-04 05:30:56 --> Language Class Initialized
INFO - 2021-05-04 05:30:56 --> Config Class Initialized
INFO - 2021-05-04 05:30:56 --> Loader Class Initialized
INFO - 2021-05-04 05:30:56 --> Helper loaded: url_helper
INFO - 2021-05-04 05:30:56 --> Helper loaded: file_helper
INFO - 2021-05-04 05:30:56 --> Helper loaded: form_helper
INFO - 2021-05-04 05:30:56 --> Helper loaded: my_helper
INFO - 2021-05-04 05:30:56 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:30:56 --> Controller Class Initialized
DEBUG - 2021-05-04 05:30:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:30:56 --> Final output sent to browser
DEBUG - 2021-05-04 05:30:56 --> Total execution time: 0.0731
INFO - 2021-05-04 05:31:26 --> Config Class Initialized
INFO - 2021-05-04 05:31:26 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:31:26 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:31:26 --> Utf8 Class Initialized
INFO - 2021-05-04 05:31:26 --> URI Class Initialized
INFO - 2021-05-04 05:31:26 --> Router Class Initialized
INFO - 2021-05-04 05:31:26 --> Output Class Initialized
INFO - 2021-05-04 05:31:26 --> Security Class Initialized
DEBUG - 2021-05-04 05:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:31:26 --> Input Class Initialized
INFO - 2021-05-04 05:31:26 --> Language Class Initialized
INFO - 2021-05-04 05:31:26 --> Language Class Initialized
INFO - 2021-05-04 05:31:26 --> Config Class Initialized
INFO - 2021-05-04 05:31:26 --> Loader Class Initialized
INFO - 2021-05-04 05:31:26 --> Helper loaded: url_helper
INFO - 2021-05-04 05:31:26 --> Helper loaded: file_helper
INFO - 2021-05-04 05:31:26 --> Helper loaded: form_helper
INFO - 2021-05-04 05:31:26 --> Helper loaded: my_helper
INFO - 2021-05-04 05:31:26 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:31:26 --> Controller Class Initialized
DEBUG - 2021-05-04 05:31:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:31:26 --> Final output sent to browser
DEBUG - 2021-05-04 05:31:26 --> Total execution time: 0.0648
INFO - 2021-05-04 05:34:40 --> Config Class Initialized
INFO - 2021-05-04 05:34:40 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:34:40 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:34:40 --> Utf8 Class Initialized
INFO - 2021-05-04 05:34:40 --> URI Class Initialized
INFO - 2021-05-04 05:34:40 --> Router Class Initialized
INFO - 2021-05-04 05:34:40 --> Output Class Initialized
INFO - 2021-05-04 05:34:40 --> Security Class Initialized
DEBUG - 2021-05-04 05:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:34:40 --> Input Class Initialized
INFO - 2021-05-04 05:34:40 --> Language Class Initialized
INFO - 2021-05-04 05:34:40 --> Language Class Initialized
INFO - 2021-05-04 05:34:40 --> Config Class Initialized
INFO - 2021-05-04 05:34:40 --> Loader Class Initialized
INFO - 2021-05-04 05:34:40 --> Helper loaded: url_helper
INFO - 2021-05-04 05:34:40 --> Helper loaded: file_helper
INFO - 2021-05-04 05:34:40 --> Helper loaded: form_helper
INFO - 2021-05-04 05:34:40 --> Helper loaded: my_helper
INFO - 2021-05-04 05:34:40 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:34:40 --> Controller Class Initialized
DEBUG - 2021-05-04 05:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 05:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:34:40 --> Final output sent to browser
DEBUG - 2021-05-04 05:34:40 --> Total execution time: 0.0597
INFO - 2021-05-04 05:36:58 --> Config Class Initialized
INFO - 2021-05-04 05:36:58 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:36:58 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:36:58 --> Utf8 Class Initialized
INFO - 2021-05-04 05:36:58 --> URI Class Initialized
INFO - 2021-05-04 05:36:58 --> Router Class Initialized
INFO - 2021-05-04 05:36:58 --> Output Class Initialized
INFO - 2021-05-04 05:36:58 --> Security Class Initialized
DEBUG - 2021-05-04 05:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:36:58 --> Input Class Initialized
INFO - 2021-05-04 05:36:58 --> Language Class Initialized
INFO - 2021-05-04 05:36:58 --> Language Class Initialized
INFO - 2021-05-04 05:36:58 --> Config Class Initialized
INFO - 2021-05-04 05:36:58 --> Loader Class Initialized
INFO - 2021-05-04 05:36:58 --> Helper loaded: url_helper
INFO - 2021-05-04 05:36:58 --> Helper loaded: file_helper
INFO - 2021-05-04 05:36:58 --> Helper loaded: form_helper
INFO - 2021-05-04 05:36:58 --> Helper loaded: my_helper
INFO - 2021-05-04 05:36:58 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:36:58 --> Controller Class Initialized
DEBUG - 2021-05-04 05:36:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 05:36:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:36:58 --> Final output sent to browser
DEBUG - 2021-05-04 05:36:58 --> Total execution time: 0.0649
INFO - 2021-05-04 05:37:22 --> Config Class Initialized
INFO - 2021-05-04 05:37:22 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:37:22 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:37:22 --> Utf8 Class Initialized
INFO - 2021-05-04 05:37:22 --> URI Class Initialized
INFO - 2021-05-04 05:37:22 --> Router Class Initialized
INFO - 2021-05-04 05:37:22 --> Output Class Initialized
INFO - 2021-05-04 05:37:22 --> Security Class Initialized
DEBUG - 2021-05-04 05:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:37:22 --> Input Class Initialized
INFO - 2021-05-04 05:37:22 --> Language Class Initialized
INFO - 2021-05-04 05:37:22 --> Language Class Initialized
INFO - 2021-05-04 05:37:22 --> Config Class Initialized
INFO - 2021-05-04 05:37:22 --> Loader Class Initialized
INFO - 2021-05-04 05:37:22 --> Helper loaded: url_helper
INFO - 2021-05-04 05:37:22 --> Helper loaded: file_helper
INFO - 2021-05-04 05:37:22 --> Helper loaded: form_helper
INFO - 2021-05-04 05:37:22 --> Helper loaded: my_helper
INFO - 2021-05-04 05:37:22 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:37:22 --> Controller Class Initialized
DEBUG - 2021-05-04 05:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-05-04 05:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:37:22 --> Final output sent to browser
DEBUG - 2021-05-04 05:37:22 --> Total execution time: 0.0708
INFO - 2021-05-04 05:38:37 --> Config Class Initialized
INFO - 2021-05-04 05:38:37 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:38:37 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:38:37 --> Utf8 Class Initialized
INFO - 2021-05-04 05:38:37 --> URI Class Initialized
INFO - 2021-05-04 05:38:37 --> Router Class Initialized
INFO - 2021-05-04 05:38:37 --> Output Class Initialized
INFO - 2021-05-04 05:38:37 --> Security Class Initialized
DEBUG - 2021-05-04 05:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:38:37 --> Input Class Initialized
INFO - 2021-05-04 05:38:37 --> Language Class Initialized
INFO - 2021-05-04 05:38:37 --> Language Class Initialized
INFO - 2021-05-04 05:38:37 --> Config Class Initialized
INFO - 2021-05-04 05:38:37 --> Loader Class Initialized
INFO - 2021-05-04 05:38:37 --> Helper loaded: url_helper
INFO - 2021-05-04 05:38:37 --> Helper loaded: file_helper
INFO - 2021-05-04 05:38:37 --> Helper loaded: form_helper
INFO - 2021-05-04 05:38:37 --> Helper loaded: my_helper
INFO - 2021-05-04 05:38:37 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:38:37 --> Controller Class Initialized
DEBUG - 2021-05-04 05:38:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 05:38:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:38:37 --> Final output sent to browser
DEBUG - 2021-05-04 05:38:37 --> Total execution time: 0.0918
INFO - 2021-05-04 05:38:39 --> Config Class Initialized
INFO - 2021-05-04 05:38:39 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:38:39 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:38:39 --> Utf8 Class Initialized
INFO - 2021-05-04 05:38:39 --> URI Class Initialized
INFO - 2021-05-04 05:38:39 --> Router Class Initialized
INFO - 2021-05-04 05:38:39 --> Output Class Initialized
INFO - 2021-05-04 05:38:39 --> Security Class Initialized
DEBUG - 2021-05-04 05:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:38:39 --> Input Class Initialized
INFO - 2021-05-04 05:38:39 --> Language Class Initialized
INFO - 2021-05-04 05:38:39 --> Language Class Initialized
INFO - 2021-05-04 05:38:39 --> Config Class Initialized
INFO - 2021-05-04 05:38:39 --> Loader Class Initialized
INFO - 2021-05-04 05:38:39 --> Helper loaded: url_helper
INFO - 2021-05-04 05:38:39 --> Helper loaded: file_helper
INFO - 2021-05-04 05:38:39 --> Helper loaded: form_helper
INFO - 2021-05-04 05:38:39 --> Helper loaded: my_helper
INFO - 2021-05-04 05:38:39 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:38:39 --> Controller Class Initialized
DEBUG - 2021-05-04 05:38:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:38:39 --> Final output sent to browser
DEBUG - 2021-05-04 05:38:39 --> Total execution time: 0.1997
INFO - 2021-05-04 05:40:03 --> Config Class Initialized
INFO - 2021-05-04 05:40:03 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:03 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:03 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:03 --> URI Class Initialized
INFO - 2021-05-04 05:40:03 --> Router Class Initialized
INFO - 2021-05-04 05:40:03 --> Output Class Initialized
INFO - 2021-05-04 05:40:03 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:03 --> Input Class Initialized
INFO - 2021-05-04 05:40:03 --> Language Class Initialized
INFO - 2021-05-04 05:40:03 --> Language Class Initialized
INFO - 2021-05-04 05:40:03 --> Config Class Initialized
INFO - 2021-05-04 05:40:03 --> Loader Class Initialized
INFO - 2021-05-04 05:40:03 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:03 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:03 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:03 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:03 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:03 --> Controller Class Initialized
INFO - 2021-05-04 05:40:03 --> Helper loaded: cookie_helper
INFO - 2021-05-04 05:40:04 --> Config Class Initialized
INFO - 2021-05-04 05:40:04 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:04 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:04 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:04 --> URI Class Initialized
INFO - 2021-05-04 05:40:04 --> Router Class Initialized
INFO - 2021-05-04 05:40:04 --> Output Class Initialized
INFO - 2021-05-04 05:40:04 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:04 --> Input Class Initialized
INFO - 2021-05-04 05:40:04 --> Language Class Initialized
INFO - 2021-05-04 05:40:04 --> Language Class Initialized
INFO - 2021-05-04 05:40:04 --> Config Class Initialized
INFO - 2021-05-04 05:40:04 --> Loader Class Initialized
INFO - 2021-05-04 05:40:04 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:04 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:04 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:04 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:04 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:04 --> Controller Class Initialized
DEBUG - 2021-05-04 05:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 05:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:40:04 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:04 --> Total execution time: 0.0629
INFO - 2021-05-04 05:40:08 --> Config Class Initialized
INFO - 2021-05-04 05:40:08 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:08 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:08 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:08 --> URI Class Initialized
INFO - 2021-05-04 05:40:08 --> Router Class Initialized
INFO - 2021-05-04 05:40:08 --> Output Class Initialized
INFO - 2021-05-04 05:40:08 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:08 --> Input Class Initialized
INFO - 2021-05-04 05:40:08 --> Language Class Initialized
INFO - 2021-05-04 05:40:08 --> Language Class Initialized
INFO - 2021-05-04 05:40:08 --> Config Class Initialized
INFO - 2021-05-04 05:40:08 --> Loader Class Initialized
INFO - 2021-05-04 05:40:08 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:08 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:08 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:08 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:08 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:08 --> Controller Class Initialized
INFO - 2021-05-04 05:40:08 --> Helper loaded: cookie_helper
INFO - 2021-05-04 05:40:08 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:08 --> Total execution time: 0.0727
INFO - 2021-05-04 05:40:08 --> Config Class Initialized
INFO - 2021-05-04 05:40:08 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:08 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:08 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:08 --> URI Class Initialized
INFO - 2021-05-04 05:40:08 --> Router Class Initialized
INFO - 2021-05-04 05:40:08 --> Output Class Initialized
INFO - 2021-05-04 05:40:08 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:08 --> Input Class Initialized
INFO - 2021-05-04 05:40:08 --> Language Class Initialized
INFO - 2021-05-04 05:40:08 --> Language Class Initialized
INFO - 2021-05-04 05:40:08 --> Config Class Initialized
INFO - 2021-05-04 05:40:08 --> Loader Class Initialized
INFO - 2021-05-04 05:40:08 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:08 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:08 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:08 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:08 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:08 --> Controller Class Initialized
DEBUG - 2021-05-04 05:40:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 05:40:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:40:08 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:08 --> Total execution time: 0.0937
INFO - 2021-05-04 05:40:10 --> Config Class Initialized
INFO - 2021-05-04 05:40:10 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:10 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:10 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:10 --> URI Class Initialized
INFO - 2021-05-04 05:40:10 --> Router Class Initialized
INFO - 2021-05-04 05:40:10 --> Output Class Initialized
INFO - 2021-05-04 05:40:10 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:10 --> Input Class Initialized
INFO - 2021-05-04 05:40:10 --> Language Class Initialized
INFO - 2021-05-04 05:40:10 --> Language Class Initialized
INFO - 2021-05-04 05:40:10 --> Config Class Initialized
INFO - 2021-05-04 05:40:10 --> Loader Class Initialized
INFO - 2021-05-04 05:40:10 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:10 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:10 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:10 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:10 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:10 --> Controller Class Initialized
DEBUG - 2021-05-04 05:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-05-04 05:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:40:11 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:11 --> Total execution time: 0.1199
INFO - 2021-05-04 05:40:22 --> Config Class Initialized
INFO - 2021-05-04 05:40:22 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:22 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:22 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:22 --> URI Class Initialized
INFO - 2021-05-04 05:40:22 --> Router Class Initialized
INFO - 2021-05-04 05:40:22 --> Output Class Initialized
INFO - 2021-05-04 05:40:22 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:22 --> Input Class Initialized
INFO - 2021-05-04 05:40:22 --> Language Class Initialized
INFO - 2021-05-04 05:40:22 --> Language Class Initialized
INFO - 2021-05-04 05:40:22 --> Config Class Initialized
INFO - 2021-05-04 05:40:22 --> Loader Class Initialized
INFO - 2021-05-04 05:40:22 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:22 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:22 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:22 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:22 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:23 --> Controller Class Initialized
INFO - 2021-05-04 05:40:23 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:23 --> Total execution time: 0.1389
INFO - 2021-05-04 05:40:26 --> Config Class Initialized
INFO - 2021-05-04 05:40:26 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:26 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:26 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:26 --> URI Class Initialized
INFO - 2021-05-04 05:40:26 --> Router Class Initialized
INFO - 2021-05-04 05:40:26 --> Output Class Initialized
INFO - 2021-05-04 05:40:26 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:26 --> Input Class Initialized
INFO - 2021-05-04 05:40:26 --> Language Class Initialized
INFO - 2021-05-04 05:40:26 --> Language Class Initialized
INFO - 2021-05-04 05:40:26 --> Config Class Initialized
INFO - 2021-05-04 05:40:26 --> Loader Class Initialized
INFO - 2021-05-04 05:40:26 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:26 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:26 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:26 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:26 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:26 --> Controller Class Initialized
DEBUG - 2021-05-04 05:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-05-04 05:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:40:26 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:26 --> Total execution time: 0.0544
INFO - 2021-05-04 05:40:30 --> Config Class Initialized
INFO - 2021-05-04 05:40:30 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:30 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:30 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:30 --> URI Class Initialized
INFO - 2021-05-04 05:40:30 --> Router Class Initialized
INFO - 2021-05-04 05:40:30 --> Output Class Initialized
INFO - 2021-05-04 05:40:30 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:30 --> Input Class Initialized
INFO - 2021-05-04 05:40:30 --> Language Class Initialized
INFO - 2021-05-04 05:40:30 --> Language Class Initialized
INFO - 2021-05-04 05:40:30 --> Config Class Initialized
INFO - 2021-05-04 05:40:30 --> Loader Class Initialized
INFO - 2021-05-04 05:40:30 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:30 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:30 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:30 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:30 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:30 --> Controller Class Initialized
INFO - 2021-05-04 05:40:30 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:30 --> Total execution time: 0.1096
INFO - 2021-05-04 05:40:33 --> Config Class Initialized
INFO - 2021-05-04 05:40:33 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:33 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:33 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:33 --> URI Class Initialized
INFO - 2021-05-04 05:40:33 --> Router Class Initialized
INFO - 2021-05-04 05:40:33 --> Output Class Initialized
INFO - 2021-05-04 05:40:33 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:33 --> Input Class Initialized
INFO - 2021-05-04 05:40:33 --> Language Class Initialized
INFO - 2021-05-04 05:40:33 --> Language Class Initialized
INFO - 2021-05-04 05:40:33 --> Config Class Initialized
INFO - 2021-05-04 05:40:33 --> Loader Class Initialized
INFO - 2021-05-04 05:40:33 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:33 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:33 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:33 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:33 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:33 --> Controller Class Initialized
DEBUG - 2021-05-04 05:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 05:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:40:33 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:33 --> Total execution time: 0.0684
INFO - 2021-05-04 05:40:35 --> Config Class Initialized
INFO - 2021-05-04 05:40:35 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:40:35 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:40:35 --> Utf8 Class Initialized
INFO - 2021-05-04 05:40:35 --> URI Class Initialized
INFO - 2021-05-04 05:40:35 --> Router Class Initialized
INFO - 2021-05-04 05:40:35 --> Output Class Initialized
INFO - 2021-05-04 05:40:35 --> Security Class Initialized
DEBUG - 2021-05-04 05:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:40:35 --> Input Class Initialized
INFO - 2021-05-04 05:40:35 --> Language Class Initialized
INFO - 2021-05-04 05:40:35 --> Language Class Initialized
INFO - 2021-05-04 05:40:35 --> Config Class Initialized
INFO - 2021-05-04 05:40:35 --> Loader Class Initialized
INFO - 2021-05-04 05:40:35 --> Helper loaded: url_helper
INFO - 2021-05-04 05:40:35 --> Helper loaded: file_helper
INFO - 2021-05-04 05:40:35 --> Helper loaded: form_helper
INFO - 2021-05-04 05:40:35 --> Helper loaded: my_helper
INFO - 2021-05-04 05:40:35 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:40:35 --> Controller Class Initialized
DEBUG - 2021-05-04 05:40:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:40:35 --> Final output sent to browser
DEBUG - 2021-05-04 05:40:35 --> Total execution time: 0.1037
INFO - 2021-05-04 05:43:29 --> Config Class Initialized
INFO - 2021-05-04 05:43:29 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:43:29 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:43:29 --> Utf8 Class Initialized
INFO - 2021-05-04 05:43:29 --> URI Class Initialized
INFO - 2021-05-04 05:43:29 --> Router Class Initialized
INFO - 2021-05-04 05:43:29 --> Output Class Initialized
INFO - 2021-05-04 05:43:29 --> Security Class Initialized
DEBUG - 2021-05-04 05:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:43:29 --> Input Class Initialized
INFO - 2021-05-04 05:43:29 --> Language Class Initialized
ERROR - 2021-05-04 05:43:29 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3383
INFO - 2021-05-04 05:44:07 --> Config Class Initialized
INFO - 2021-05-04 05:44:07 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:44:07 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:44:07 --> Utf8 Class Initialized
INFO - 2021-05-04 05:44:07 --> URI Class Initialized
INFO - 2021-05-04 05:44:07 --> Router Class Initialized
INFO - 2021-05-04 05:44:07 --> Output Class Initialized
INFO - 2021-05-04 05:44:07 --> Security Class Initialized
DEBUG - 2021-05-04 05:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:44:07 --> Input Class Initialized
INFO - 2021-05-04 05:44:07 --> Language Class Initialized
INFO - 2021-05-04 05:44:07 --> Language Class Initialized
INFO - 2021-05-04 05:44:07 --> Config Class Initialized
INFO - 2021-05-04 05:44:07 --> Loader Class Initialized
INFO - 2021-05-04 05:44:07 --> Helper loaded: url_helper
INFO - 2021-05-04 05:44:07 --> Helper loaded: file_helper
INFO - 2021-05-04 05:44:07 --> Helper loaded: form_helper
INFO - 2021-05-04 05:44:07 --> Helper loaded: my_helper
INFO - 2021-05-04 05:44:07 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:44:07 --> Controller Class Initialized
DEBUG - 2021-05-04 05:44:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:44:07 --> Final output sent to browser
DEBUG - 2021-05-04 05:44:07 --> Total execution time: 0.0801
INFO - 2021-05-04 05:44:40 --> Config Class Initialized
INFO - 2021-05-04 05:44:40 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:44:40 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:44:40 --> Utf8 Class Initialized
INFO - 2021-05-04 05:44:40 --> URI Class Initialized
INFO - 2021-05-04 05:44:40 --> Router Class Initialized
INFO - 2021-05-04 05:44:40 --> Output Class Initialized
INFO - 2021-05-04 05:44:40 --> Security Class Initialized
DEBUG - 2021-05-04 05:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:44:40 --> Input Class Initialized
INFO - 2021-05-04 05:44:40 --> Language Class Initialized
INFO - 2021-05-04 05:44:40 --> Language Class Initialized
INFO - 2021-05-04 05:44:40 --> Config Class Initialized
INFO - 2021-05-04 05:44:40 --> Loader Class Initialized
INFO - 2021-05-04 05:44:40 --> Helper loaded: url_helper
INFO - 2021-05-04 05:44:40 --> Helper loaded: file_helper
INFO - 2021-05-04 05:44:40 --> Helper loaded: form_helper
INFO - 2021-05-04 05:44:40 --> Helper loaded: my_helper
INFO - 2021-05-04 05:44:40 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:44:40 --> Controller Class Initialized
DEBUG - 2021-05-04 05:44:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:44:40 --> Final output sent to browser
DEBUG - 2021-05-04 05:44:40 --> Total execution time: 0.0934
INFO - 2021-05-04 05:46:25 --> Config Class Initialized
INFO - 2021-05-04 05:46:25 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:46:25 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:46:25 --> Utf8 Class Initialized
INFO - 2021-05-04 05:46:25 --> URI Class Initialized
INFO - 2021-05-04 05:46:25 --> Router Class Initialized
INFO - 2021-05-04 05:46:25 --> Output Class Initialized
INFO - 2021-05-04 05:46:25 --> Security Class Initialized
DEBUG - 2021-05-04 05:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:46:25 --> Input Class Initialized
INFO - 2021-05-04 05:46:25 --> Language Class Initialized
INFO - 2021-05-04 05:46:25 --> Language Class Initialized
INFO - 2021-05-04 05:46:25 --> Config Class Initialized
INFO - 2021-05-04 05:46:25 --> Loader Class Initialized
INFO - 2021-05-04 05:46:25 --> Helper loaded: url_helper
INFO - 2021-05-04 05:46:25 --> Helper loaded: file_helper
INFO - 2021-05-04 05:46:25 --> Helper loaded: form_helper
INFO - 2021-05-04 05:46:25 --> Helper loaded: my_helper
INFO - 2021-05-04 05:46:25 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:46:25 --> Controller Class Initialized
DEBUG - 2021-05-04 05:46:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:46:25 --> Final output sent to browser
DEBUG - 2021-05-04 05:46:25 --> Total execution time: 0.0778
INFO - 2021-05-04 05:46:56 --> Config Class Initialized
INFO - 2021-05-04 05:46:56 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:46:56 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:46:56 --> Utf8 Class Initialized
INFO - 2021-05-04 05:46:56 --> URI Class Initialized
INFO - 2021-05-04 05:46:56 --> Router Class Initialized
INFO - 2021-05-04 05:46:56 --> Output Class Initialized
INFO - 2021-05-04 05:46:56 --> Security Class Initialized
DEBUG - 2021-05-04 05:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:46:56 --> Input Class Initialized
INFO - 2021-05-04 05:46:56 --> Language Class Initialized
INFO - 2021-05-04 05:46:56 --> Language Class Initialized
INFO - 2021-05-04 05:46:56 --> Config Class Initialized
INFO - 2021-05-04 05:46:56 --> Loader Class Initialized
INFO - 2021-05-04 05:46:56 --> Helper loaded: url_helper
INFO - 2021-05-04 05:46:56 --> Helper loaded: file_helper
INFO - 2021-05-04 05:46:56 --> Helper loaded: form_helper
INFO - 2021-05-04 05:46:56 --> Helper loaded: my_helper
INFO - 2021-05-04 05:46:56 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:46:56 --> Controller Class Initialized
DEBUG - 2021-05-04 05:46:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:46:56 --> Final output sent to browser
DEBUG - 2021-05-04 05:46:56 --> Total execution time: 0.0622
INFO - 2021-05-04 05:47:27 --> Config Class Initialized
INFO - 2021-05-04 05:47:27 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:47:27 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:47:27 --> Utf8 Class Initialized
INFO - 2021-05-04 05:47:27 --> URI Class Initialized
INFO - 2021-05-04 05:47:27 --> Router Class Initialized
INFO - 2021-05-04 05:47:27 --> Output Class Initialized
INFO - 2021-05-04 05:47:27 --> Security Class Initialized
DEBUG - 2021-05-04 05:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:47:27 --> Input Class Initialized
INFO - 2021-05-04 05:47:27 --> Language Class Initialized
INFO - 2021-05-04 05:47:27 --> Language Class Initialized
INFO - 2021-05-04 05:47:27 --> Config Class Initialized
INFO - 2021-05-04 05:47:27 --> Loader Class Initialized
INFO - 2021-05-04 05:47:27 --> Helper loaded: url_helper
INFO - 2021-05-04 05:47:27 --> Helper loaded: file_helper
INFO - 2021-05-04 05:47:27 --> Helper loaded: form_helper
INFO - 2021-05-04 05:47:27 --> Helper loaded: my_helper
INFO - 2021-05-04 05:47:27 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:47:27 --> Controller Class Initialized
DEBUG - 2021-05-04 05:47:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:47:27 --> Final output sent to browser
DEBUG - 2021-05-04 05:47:27 --> Total execution time: 0.0758
INFO - 2021-05-04 05:47:40 --> Config Class Initialized
INFO - 2021-05-04 05:47:40 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:47:40 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:47:40 --> Utf8 Class Initialized
INFO - 2021-05-04 05:47:40 --> URI Class Initialized
INFO - 2021-05-04 05:47:40 --> Router Class Initialized
INFO - 2021-05-04 05:47:40 --> Output Class Initialized
INFO - 2021-05-04 05:47:40 --> Security Class Initialized
DEBUG - 2021-05-04 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:47:40 --> Input Class Initialized
INFO - 2021-05-04 05:47:40 --> Language Class Initialized
INFO - 2021-05-04 05:47:40 --> Language Class Initialized
INFO - 2021-05-04 05:47:40 --> Config Class Initialized
INFO - 2021-05-04 05:47:40 --> Loader Class Initialized
INFO - 2021-05-04 05:47:40 --> Helper loaded: url_helper
INFO - 2021-05-04 05:47:40 --> Helper loaded: file_helper
INFO - 2021-05-04 05:47:40 --> Helper loaded: form_helper
INFO - 2021-05-04 05:47:40 --> Helper loaded: my_helper
INFO - 2021-05-04 05:47:40 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:47:40 --> Controller Class Initialized
INFO - 2021-05-04 05:47:40 --> Helper loaded: cookie_helper
INFO - 2021-05-04 05:47:40 --> Config Class Initialized
INFO - 2021-05-04 05:47:40 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:47:40 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:47:40 --> Utf8 Class Initialized
INFO - 2021-05-04 05:47:40 --> URI Class Initialized
INFO - 2021-05-04 05:47:40 --> Router Class Initialized
INFO - 2021-05-04 05:47:40 --> Output Class Initialized
INFO - 2021-05-04 05:47:40 --> Security Class Initialized
DEBUG - 2021-05-04 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:47:40 --> Input Class Initialized
INFO - 2021-05-04 05:47:40 --> Language Class Initialized
INFO - 2021-05-04 05:47:40 --> Language Class Initialized
INFO - 2021-05-04 05:47:40 --> Config Class Initialized
INFO - 2021-05-04 05:47:40 --> Loader Class Initialized
INFO - 2021-05-04 05:47:40 --> Helper loaded: url_helper
INFO - 2021-05-04 05:47:40 --> Helper loaded: file_helper
INFO - 2021-05-04 05:47:40 --> Helper loaded: form_helper
INFO - 2021-05-04 05:47:40 --> Helper loaded: my_helper
INFO - 2021-05-04 05:47:40 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:47:40 --> Controller Class Initialized
DEBUG - 2021-05-04 05:47:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 05:47:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:47:40 --> Final output sent to browser
DEBUG - 2021-05-04 05:47:40 --> Total execution time: 0.0469
INFO - 2021-05-04 05:47:48 --> Config Class Initialized
INFO - 2021-05-04 05:47:48 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:47:48 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:47:48 --> Utf8 Class Initialized
INFO - 2021-05-04 05:47:48 --> URI Class Initialized
INFO - 2021-05-04 05:47:48 --> Router Class Initialized
INFO - 2021-05-04 05:47:48 --> Output Class Initialized
INFO - 2021-05-04 05:47:48 --> Security Class Initialized
DEBUG - 2021-05-04 05:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:47:48 --> Input Class Initialized
INFO - 2021-05-04 05:47:48 --> Language Class Initialized
INFO - 2021-05-04 05:47:48 --> Language Class Initialized
INFO - 2021-05-04 05:47:48 --> Config Class Initialized
INFO - 2021-05-04 05:47:48 --> Loader Class Initialized
INFO - 2021-05-04 05:47:48 --> Helper loaded: url_helper
INFO - 2021-05-04 05:47:48 --> Helper loaded: file_helper
INFO - 2021-05-04 05:47:48 --> Helper loaded: form_helper
INFO - 2021-05-04 05:47:48 --> Helper loaded: my_helper
INFO - 2021-05-04 05:47:48 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:47:48 --> Controller Class Initialized
INFO - 2021-05-04 05:47:48 --> Helper loaded: cookie_helper
INFO - 2021-05-04 05:47:48 --> Final output sent to browser
DEBUG - 2021-05-04 05:47:48 --> Total execution time: 0.0681
INFO - 2021-05-04 05:47:48 --> Config Class Initialized
INFO - 2021-05-04 05:47:48 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:47:48 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:47:48 --> Utf8 Class Initialized
INFO - 2021-05-04 05:47:48 --> URI Class Initialized
INFO - 2021-05-04 05:47:48 --> Router Class Initialized
INFO - 2021-05-04 05:47:48 --> Output Class Initialized
INFO - 2021-05-04 05:47:48 --> Security Class Initialized
DEBUG - 2021-05-04 05:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:47:48 --> Input Class Initialized
INFO - 2021-05-04 05:47:48 --> Language Class Initialized
INFO - 2021-05-04 05:47:48 --> Language Class Initialized
INFO - 2021-05-04 05:47:48 --> Config Class Initialized
INFO - 2021-05-04 05:47:48 --> Loader Class Initialized
INFO - 2021-05-04 05:47:48 --> Helper loaded: url_helper
INFO - 2021-05-04 05:47:48 --> Helper loaded: file_helper
INFO - 2021-05-04 05:47:48 --> Helper loaded: form_helper
INFO - 2021-05-04 05:47:48 --> Helper loaded: my_helper
INFO - 2021-05-04 05:47:48 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:47:48 --> Controller Class Initialized
DEBUG - 2021-05-04 05:47:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 05:47:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:47:48 --> Final output sent to browser
DEBUG - 2021-05-04 05:47:49 --> Total execution time: 0.0923
INFO - 2021-05-04 05:47:50 --> Config Class Initialized
INFO - 2021-05-04 05:47:50 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:47:50 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:47:50 --> Utf8 Class Initialized
INFO - 2021-05-04 05:47:50 --> URI Class Initialized
INFO - 2021-05-04 05:47:50 --> Router Class Initialized
INFO - 2021-05-04 05:47:50 --> Output Class Initialized
INFO - 2021-05-04 05:47:50 --> Security Class Initialized
DEBUG - 2021-05-04 05:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:47:50 --> Input Class Initialized
INFO - 2021-05-04 05:47:50 --> Language Class Initialized
INFO - 2021-05-04 05:47:50 --> Language Class Initialized
INFO - 2021-05-04 05:47:50 --> Config Class Initialized
INFO - 2021-05-04 05:47:50 --> Loader Class Initialized
INFO - 2021-05-04 05:47:50 --> Helper loaded: url_helper
INFO - 2021-05-04 05:47:50 --> Helper loaded: file_helper
INFO - 2021-05-04 05:47:50 --> Helper loaded: form_helper
INFO - 2021-05-04 05:47:50 --> Helper loaded: my_helper
INFO - 2021-05-04 05:47:50 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:47:50 --> Controller Class Initialized
DEBUG - 2021-05-04 05:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-05-04 05:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:47:50 --> Final output sent to browser
DEBUG - 2021-05-04 05:47:50 --> Total execution time: 0.0913
INFO - 2021-05-04 05:47:51 --> Config Class Initialized
INFO - 2021-05-04 05:47:51 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:47:51 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:47:51 --> Utf8 Class Initialized
INFO - 2021-05-04 05:47:51 --> URI Class Initialized
INFO - 2021-05-04 05:47:51 --> Router Class Initialized
INFO - 2021-05-04 05:47:51 --> Output Class Initialized
INFO - 2021-05-04 05:47:51 --> Security Class Initialized
DEBUG - 2021-05-04 05:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:47:51 --> Input Class Initialized
INFO - 2021-05-04 05:47:51 --> Language Class Initialized
INFO - 2021-05-04 05:47:52 --> Language Class Initialized
INFO - 2021-05-04 05:47:52 --> Config Class Initialized
INFO - 2021-05-04 05:47:52 --> Loader Class Initialized
INFO - 2021-05-04 05:47:52 --> Helper loaded: url_helper
INFO - 2021-05-04 05:47:52 --> Helper loaded: file_helper
INFO - 2021-05-04 05:47:52 --> Helper loaded: form_helper
INFO - 2021-05-04 05:47:52 --> Helper loaded: my_helper
INFO - 2021-05-04 05:47:52 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:47:52 --> Controller Class Initialized
DEBUG - 2021-05-04 05:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-05-04 05:47:52 --> Final output sent to browser
DEBUG - 2021-05-04 05:47:52 --> Total execution time: 0.0776
INFO - 2021-05-04 05:48:02 --> Config Class Initialized
INFO - 2021-05-04 05:48:02 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:48:02 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:48:02 --> Utf8 Class Initialized
INFO - 2021-05-04 05:48:02 --> URI Class Initialized
INFO - 2021-05-04 05:48:02 --> Router Class Initialized
INFO - 2021-05-04 05:48:02 --> Output Class Initialized
INFO - 2021-05-04 05:48:02 --> Security Class Initialized
DEBUG - 2021-05-04 05:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:48:02 --> Input Class Initialized
INFO - 2021-05-04 05:48:02 --> Language Class Initialized
INFO - 2021-05-04 05:48:02 --> Language Class Initialized
INFO - 2021-05-04 05:48:02 --> Config Class Initialized
INFO - 2021-05-04 05:48:02 --> Loader Class Initialized
INFO - 2021-05-04 05:48:02 --> Helper loaded: url_helper
INFO - 2021-05-04 05:48:02 --> Helper loaded: file_helper
INFO - 2021-05-04 05:48:02 --> Helper loaded: form_helper
INFO - 2021-05-04 05:48:02 --> Helper loaded: my_helper
INFO - 2021-05-04 05:48:02 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:48:02 --> Controller Class Initialized
INFO - 2021-05-04 05:48:02 --> Helper loaded: cookie_helper
INFO - 2021-05-04 05:48:02 --> Config Class Initialized
INFO - 2021-05-04 05:48:02 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:48:02 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:48:02 --> Utf8 Class Initialized
INFO - 2021-05-04 05:48:02 --> URI Class Initialized
INFO - 2021-05-04 05:48:02 --> Router Class Initialized
INFO - 2021-05-04 05:48:02 --> Output Class Initialized
INFO - 2021-05-04 05:48:02 --> Security Class Initialized
DEBUG - 2021-05-04 05:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:48:02 --> Input Class Initialized
INFO - 2021-05-04 05:48:02 --> Language Class Initialized
INFO - 2021-05-04 05:48:02 --> Language Class Initialized
INFO - 2021-05-04 05:48:02 --> Config Class Initialized
INFO - 2021-05-04 05:48:02 --> Loader Class Initialized
INFO - 2021-05-04 05:48:02 --> Helper loaded: url_helper
INFO - 2021-05-04 05:48:02 --> Helper loaded: file_helper
INFO - 2021-05-04 05:48:02 --> Helper loaded: form_helper
INFO - 2021-05-04 05:48:02 --> Helper loaded: my_helper
INFO - 2021-05-04 05:48:02 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:48:02 --> Controller Class Initialized
DEBUG - 2021-05-04 05:48:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-04 05:48:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:48:02 --> Final output sent to browser
DEBUG - 2021-05-04 05:48:02 --> Total execution time: 0.0557
INFO - 2021-05-04 05:48:07 --> Config Class Initialized
INFO - 2021-05-04 05:48:07 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:48:07 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:48:07 --> Utf8 Class Initialized
INFO - 2021-05-04 05:48:07 --> URI Class Initialized
INFO - 2021-05-04 05:48:07 --> Router Class Initialized
INFO - 2021-05-04 05:48:07 --> Output Class Initialized
INFO - 2021-05-04 05:48:07 --> Security Class Initialized
DEBUG - 2021-05-04 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:48:07 --> Input Class Initialized
INFO - 2021-05-04 05:48:07 --> Language Class Initialized
INFO - 2021-05-04 05:48:07 --> Language Class Initialized
INFO - 2021-05-04 05:48:07 --> Config Class Initialized
INFO - 2021-05-04 05:48:07 --> Loader Class Initialized
INFO - 2021-05-04 05:48:07 --> Helper loaded: url_helper
INFO - 2021-05-04 05:48:07 --> Helper loaded: file_helper
INFO - 2021-05-04 05:48:07 --> Helper loaded: form_helper
INFO - 2021-05-04 05:48:07 --> Helper loaded: my_helper
INFO - 2021-05-04 05:48:07 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:48:07 --> Controller Class Initialized
INFO - 2021-05-04 05:48:07 --> Helper loaded: cookie_helper
INFO - 2021-05-04 05:48:07 --> Final output sent to browser
DEBUG - 2021-05-04 05:48:07 --> Total execution time: 0.0733
INFO - 2021-05-04 05:48:07 --> Config Class Initialized
INFO - 2021-05-04 05:48:07 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:48:07 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:48:07 --> Utf8 Class Initialized
INFO - 2021-05-04 05:48:07 --> URI Class Initialized
INFO - 2021-05-04 05:48:07 --> Router Class Initialized
INFO - 2021-05-04 05:48:07 --> Output Class Initialized
INFO - 2021-05-04 05:48:07 --> Security Class Initialized
DEBUG - 2021-05-04 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:48:07 --> Input Class Initialized
INFO - 2021-05-04 05:48:07 --> Language Class Initialized
INFO - 2021-05-04 05:48:07 --> Language Class Initialized
INFO - 2021-05-04 05:48:07 --> Config Class Initialized
INFO - 2021-05-04 05:48:07 --> Loader Class Initialized
INFO - 2021-05-04 05:48:07 --> Helper loaded: url_helper
INFO - 2021-05-04 05:48:07 --> Helper loaded: file_helper
INFO - 2021-05-04 05:48:07 --> Helper loaded: form_helper
INFO - 2021-05-04 05:48:07 --> Helper loaded: my_helper
INFO - 2021-05-04 05:48:07 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:48:07 --> Controller Class Initialized
DEBUG - 2021-05-04 05:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-05-04 05:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-04 05:48:07 --> Final output sent to browser
DEBUG - 2021-05-04 05:48:07 --> Total execution time: 0.0712
INFO - 2021-05-04 05:49:03 --> Config Class Initialized
INFO - 2021-05-04 05:49:03 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:49:03 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:49:03 --> Utf8 Class Initialized
INFO - 2021-05-04 05:49:03 --> URI Class Initialized
INFO - 2021-05-04 05:49:03 --> Router Class Initialized
INFO - 2021-05-04 05:49:03 --> Output Class Initialized
INFO - 2021-05-04 05:49:03 --> Security Class Initialized
DEBUG - 2021-05-04 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:49:03 --> Input Class Initialized
INFO - 2021-05-04 05:49:03 --> Language Class Initialized
INFO - 2021-05-04 05:49:03 --> Language Class Initialized
INFO - 2021-05-04 05:49:03 --> Config Class Initialized
INFO - 2021-05-04 05:49:03 --> Loader Class Initialized
INFO - 2021-05-04 05:49:03 --> Helper loaded: url_helper
INFO - 2021-05-04 05:49:03 --> Helper loaded: file_helper
INFO - 2021-05-04 05:49:03 --> Helper loaded: form_helper
INFO - 2021-05-04 05:49:03 --> Helper loaded: my_helper
INFO - 2021-05-04 05:49:03 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:49:03 --> Controller Class Initialized
DEBUG - 2021-05-04 05:49:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:49:03 --> Final output sent to browser
DEBUG - 2021-05-04 05:49:03 --> Total execution time: 0.0812
INFO - 2021-05-04 05:49:17 --> Config Class Initialized
INFO - 2021-05-04 05:49:17 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:49:17 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:49:17 --> Utf8 Class Initialized
INFO - 2021-05-04 05:49:17 --> URI Class Initialized
INFO - 2021-05-04 05:49:17 --> Router Class Initialized
INFO - 2021-05-04 05:49:18 --> Output Class Initialized
INFO - 2021-05-04 05:49:18 --> Security Class Initialized
DEBUG - 2021-05-04 05:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:49:18 --> Input Class Initialized
INFO - 2021-05-04 05:49:18 --> Language Class Initialized
INFO - 2021-05-04 05:49:18 --> Language Class Initialized
INFO - 2021-05-04 05:49:18 --> Config Class Initialized
INFO - 2021-05-04 05:49:18 --> Loader Class Initialized
INFO - 2021-05-04 05:49:18 --> Helper loaded: url_helper
INFO - 2021-05-04 05:49:18 --> Helper loaded: file_helper
INFO - 2021-05-04 05:49:18 --> Helper loaded: form_helper
INFO - 2021-05-04 05:49:18 --> Helper loaded: my_helper
INFO - 2021-05-04 05:49:18 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:49:18 --> Controller Class Initialized
DEBUG - 2021-05-04 05:49:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:49:18 --> Final output sent to browser
DEBUG - 2021-05-04 05:49:18 --> Total execution time: 0.0737
INFO - 2021-05-04 05:49:50 --> Config Class Initialized
INFO - 2021-05-04 05:49:50 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:49:50 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:49:50 --> Utf8 Class Initialized
INFO - 2021-05-04 05:49:50 --> URI Class Initialized
INFO - 2021-05-04 05:49:50 --> Router Class Initialized
INFO - 2021-05-04 05:49:50 --> Output Class Initialized
INFO - 2021-05-04 05:49:50 --> Security Class Initialized
DEBUG - 2021-05-04 05:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:49:50 --> Input Class Initialized
INFO - 2021-05-04 05:49:50 --> Language Class Initialized
INFO - 2021-05-04 05:49:50 --> Language Class Initialized
INFO - 2021-05-04 05:49:50 --> Config Class Initialized
INFO - 2021-05-04 05:49:50 --> Loader Class Initialized
INFO - 2021-05-04 05:49:50 --> Helper loaded: url_helper
INFO - 2021-05-04 05:49:50 --> Helper loaded: file_helper
INFO - 2021-05-04 05:49:50 --> Helper loaded: form_helper
INFO - 2021-05-04 05:49:50 --> Helper loaded: my_helper
INFO - 2021-05-04 05:49:50 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:49:50 --> Controller Class Initialized
DEBUG - 2021-05-04 05:49:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:49:50 --> Final output sent to browser
DEBUG - 2021-05-04 05:49:50 --> Total execution time: 0.0535
INFO - 2021-05-04 05:50:44 --> Config Class Initialized
INFO - 2021-05-04 05:50:44 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:50:44 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:50:44 --> Utf8 Class Initialized
INFO - 2021-05-04 05:50:44 --> URI Class Initialized
INFO - 2021-05-04 05:50:44 --> Router Class Initialized
INFO - 2021-05-04 05:50:44 --> Output Class Initialized
INFO - 2021-05-04 05:50:44 --> Security Class Initialized
DEBUG - 2021-05-04 05:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:50:44 --> Input Class Initialized
INFO - 2021-05-04 05:50:44 --> Language Class Initialized
INFO - 2021-05-04 05:50:44 --> Language Class Initialized
INFO - 2021-05-04 05:50:44 --> Config Class Initialized
INFO - 2021-05-04 05:50:44 --> Loader Class Initialized
INFO - 2021-05-04 05:50:44 --> Helper loaded: url_helper
INFO - 2021-05-04 05:50:44 --> Helper loaded: file_helper
INFO - 2021-05-04 05:50:44 --> Helper loaded: form_helper
INFO - 2021-05-04 05:50:44 --> Helper loaded: my_helper
INFO - 2021-05-04 05:50:44 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:50:44 --> Controller Class Initialized
DEBUG - 2021-05-04 05:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:50:44 --> Final output sent to browser
DEBUG - 2021-05-04 05:50:44 --> Total execution time: 0.0786
INFO - 2021-05-04 05:51:11 --> Config Class Initialized
INFO - 2021-05-04 05:51:11 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:51:11 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:51:11 --> Utf8 Class Initialized
INFO - 2021-05-04 05:51:11 --> URI Class Initialized
INFO - 2021-05-04 05:51:11 --> Router Class Initialized
INFO - 2021-05-04 05:51:11 --> Output Class Initialized
INFO - 2021-05-04 05:51:11 --> Security Class Initialized
DEBUG - 2021-05-04 05:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:51:11 --> Input Class Initialized
INFO - 2021-05-04 05:51:11 --> Language Class Initialized
INFO - 2021-05-04 05:51:11 --> Language Class Initialized
INFO - 2021-05-04 05:51:11 --> Config Class Initialized
INFO - 2021-05-04 05:51:11 --> Loader Class Initialized
INFO - 2021-05-04 05:51:11 --> Helper loaded: url_helper
INFO - 2021-05-04 05:51:11 --> Helper loaded: file_helper
INFO - 2021-05-04 05:51:11 --> Helper loaded: form_helper
INFO - 2021-05-04 05:51:11 --> Helper loaded: my_helper
INFO - 2021-05-04 05:51:11 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:51:11 --> Controller Class Initialized
DEBUG - 2021-05-04 05:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:51:11 --> Final output sent to browser
DEBUG - 2021-05-04 05:51:11 --> Total execution time: 0.0794
INFO - 2021-05-04 05:52:13 --> Config Class Initialized
INFO - 2021-05-04 05:52:13 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:52:13 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:52:13 --> Utf8 Class Initialized
INFO - 2021-05-04 05:52:13 --> URI Class Initialized
INFO - 2021-05-04 05:52:13 --> Router Class Initialized
INFO - 2021-05-04 05:52:13 --> Output Class Initialized
INFO - 2021-05-04 05:52:13 --> Security Class Initialized
DEBUG - 2021-05-04 05:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:52:13 --> Input Class Initialized
INFO - 2021-05-04 05:52:13 --> Language Class Initialized
INFO - 2021-05-04 05:52:13 --> Language Class Initialized
INFO - 2021-05-04 05:52:13 --> Config Class Initialized
INFO - 2021-05-04 05:52:13 --> Loader Class Initialized
INFO - 2021-05-04 05:52:13 --> Helper loaded: url_helper
INFO - 2021-05-04 05:52:13 --> Helper loaded: file_helper
INFO - 2021-05-04 05:52:13 --> Helper loaded: form_helper
INFO - 2021-05-04 05:52:13 --> Helper loaded: my_helper
INFO - 2021-05-04 05:52:13 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:52:13 --> Controller Class Initialized
DEBUG - 2021-05-04 05:52:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:52:13 --> Final output sent to browser
DEBUG - 2021-05-04 05:52:13 --> Total execution time: 0.0557
INFO - 2021-05-04 05:53:04 --> Config Class Initialized
INFO - 2021-05-04 05:53:04 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:53:04 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:53:04 --> Utf8 Class Initialized
INFO - 2021-05-04 05:53:04 --> URI Class Initialized
INFO - 2021-05-04 05:53:04 --> Router Class Initialized
INFO - 2021-05-04 05:53:04 --> Output Class Initialized
INFO - 2021-05-04 05:53:04 --> Security Class Initialized
DEBUG - 2021-05-04 05:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:53:04 --> Input Class Initialized
INFO - 2021-05-04 05:53:04 --> Language Class Initialized
INFO - 2021-05-04 05:53:04 --> Language Class Initialized
INFO - 2021-05-04 05:53:04 --> Config Class Initialized
INFO - 2021-05-04 05:53:04 --> Loader Class Initialized
INFO - 2021-05-04 05:53:04 --> Helper loaded: url_helper
INFO - 2021-05-04 05:53:04 --> Helper loaded: file_helper
INFO - 2021-05-04 05:53:04 --> Helper loaded: form_helper
INFO - 2021-05-04 05:53:04 --> Helper loaded: my_helper
INFO - 2021-05-04 05:53:04 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:53:04 --> Controller Class Initialized
DEBUG - 2021-05-04 05:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:53:04 --> Final output sent to browser
DEBUG - 2021-05-04 05:53:04 --> Total execution time: 0.0780
INFO - 2021-05-04 05:54:11 --> Config Class Initialized
INFO - 2021-05-04 05:54:11 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:54:11 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:54:11 --> Utf8 Class Initialized
INFO - 2021-05-04 05:54:11 --> URI Class Initialized
INFO - 2021-05-04 05:54:11 --> Router Class Initialized
INFO - 2021-05-04 05:54:11 --> Output Class Initialized
INFO - 2021-05-04 05:54:11 --> Security Class Initialized
DEBUG - 2021-05-04 05:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:54:11 --> Input Class Initialized
INFO - 2021-05-04 05:54:11 --> Language Class Initialized
INFO - 2021-05-04 05:54:11 --> Language Class Initialized
INFO - 2021-05-04 05:54:11 --> Config Class Initialized
INFO - 2021-05-04 05:54:11 --> Loader Class Initialized
INFO - 2021-05-04 05:54:11 --> Helper loaded: url_helper
INFO - 2021-05-04 05:54:11 --> Helper loaded: file_helper
INFO - 2021-05-04 05:54:11 --> Helper loaded: form_helper
INFO - 2021-05-04 05:54:11 --> Helper loaded: my_helper
INFO - 2021-05-04 05:54:11 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:54:11 --> Controller Class Initialized
DEBUG - 2021-05-04 05:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:54:11 --> Final output sent to browser
DEBUG - 2021-05-04 05:54:11 --> Total execution time: 0.0724
INFO - 2021-05-04 05:54:35 --> Config Class Initialized
INFO - 2021-05-04 05:54:35 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:54:35 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:54:35 --> Utf8 Class Initialized
INFO - 2021-05-04 05:54:35 --> URI Class Initialized
INFO - 2021-05-04 05:54:35 --> Router Class Initialized
INFO - 2021-05-04 05:54:35 --> Output Class Initialized
INFO - 2021-05-04 05:54:35 --> Security Class Initialized
DEBUG - 2021-05-04 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:54:35 --> Input Class Initialized
INFO - 2021-05-04 05:54:35 --> Language Class Initialized
INFO - 2021-05-04 05:54:35 --> Language Class Initialized
INFO - 2021-05-04 05:54:35 --> Config Class Initialized
INFO - 2021-05-04 05:54:35 --> Loader Class Initialized
INFO - 2021-05-04 05:54:35 --> Helper loaded: url_helper
INFO - 2021-05-04 05:54:35 --> Helper loaded: file_helper
INFO - 2021-05-04 05:54:35 --> Helper loaded: form_helper
INFO - 2021-05-04 05:54:35 --> Helper loaded: my_helper
INFO - 2021-05-04 05:54:35 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:54:35 --> Controller Class Initialized
DEBUG - 2021-05-04 05:54:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:54:35 --> Final output sent to browser
DEBUG - 2021-05-04 05:54:35 --> Total execution time: 0.0692
INFO - 2021-05-04 05:55:10 --> Config Class Initialized
INFO - 2021-05-04 05:55:10 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:55:10 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:55:10 --> Utf8 Class Initialized
INFO - 2021-05-04 05:55:10 --> URI Class Initialized
INFO - 2021-05-04 05:55:10 --> Router Class Initialized
INFO - 2021-05-04 05:55:10 --> Output Class Initialized
INFO - 2021-05-04 05:55:10 --> Security Class Initialized
DEBUG - 2021-05-04 05:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:55:10 --> Input Class Initialized
INFO - 2021-05-04 05:55:10 --> Language Class Initialized
INFO - 2021-05-04 05:55:10 --> Language Class Initialized
INFO - 2021-05-04 05:55:10 --> Config Class Initialized
INFO - 2021-05-04 05:55:10 --> Loader Class Initialized
INFO - 2021-05-04 05:55:10 --> Helper loaded: url_helper
INFO - 2021-05-04 05:55:10 --> Helper loaded: file_helper
INFO - 2021-05-04 05:55:10 --> Helper loaded: form_helper
INFO - 2021-05-04 05:55:10 --> Helper loaded: my_helper
INFO - 2021-05-04 05:55:10 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:55:10 --> Controller Class Initialized
DEBUG - 2021-05-04 05:55:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:55:10 --> Final output sent to browser
DEBUG - 2021-05-04 05:55:10 --> Total execution time: 0.0574
INFO - 2021-05-04 05:56:41 --> Config Class Initialized
INFO - 2021-05-04 05:56:41 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:56:41 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:56:41 --> Utf8 Class Initialized
INFO - 2021-05-04 05:56:41 --> URI Class Initialized
INFO - 2021-05-04 05:56:41 --> Router Class Initialized
INFO - 2021-05-04 05:56:41 --> Output Class Initialized
INFO - 2021-05-04 05:56:41 --> Security Class Initialized
DEBUG - 2021-05-04 05:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:56:41 --> Input Class Initialized
INFO - 2021-05-04 05:56:41 --> Language Class Initialized
INFO - 2021-05-04 05:56:41 --> Language Class Initialized
INFO - 2021-05-04 05:56:41 --> Config Class Initialized
INFO - 2021-05-04 05:56:41 --> Loader Class Initialized
INFO - 2021-05-04 05:56:41 --> Helper loaded: url_helper
INFO - 2021-05-04 05:56:41 --> Helper loaded: file_helper
INFO - 2021-05-04 05:56:41 --> Helper loaded: form_helper
INFO - 2021-05-04 05:56:41 --> Helper loaded: my_helper
INFO - 2021-05-04 05:56:41 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:56:41 --> Controller Class Initialized
DEBUG - 2021-05-04 05:56:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:56:41 --> Final output sent to browser
DEBUG - 2021-05-04 05:56:41 --> Total execution time: 0.0856
INFO - 2021-05-04 05:57:02 --> Config Class Initialized
INFO - 2021-05-04 05:57:02 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:57:02 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:57:02 --> Utf8 Class Initialized
INFO - 2021-05-04 05:57:02 --> URI Class Initialized
INFO - 2021-05-04 05:57:02 --> Router Class Initialized
INFO - 2021-05-04 05:57:02 --> Output Class Initialized
INFO - 2021-05-04 05:57:02 --> Security Class Initialized
DEBUG - 2021-05-04 05:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:57:02 --> Input Class Initialized
INFO - 2021-05-04 05:57:02 --> Language Class Initialized
INFO - 2021-05-04 05:57:02 --> Language Class Initialized
INFO - 2021-05-04 05:57:02 --> Config Class Initialized
INFO - 2021-05-04 05:57:02 --> Loader Class Initialized
INFO - 2021-05-04 05:57:02 --> Helper loaded: url_helper
INFO - 2021-05-04 05:57:02 --> Helper loaded: file_helper
INFO - 2021-05-04 05:57:02 --> Helper loaded: form_helper
INFO - 2021-05-04 05:57:02 --> Helper loaded: my_helper
INFO - 2021-05-04 05:57:02 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:57:02 --> Controller Class Initialized
DEBUG - 2021-05-04 05:57:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:57:02 --> Final output sent to browser
DEBUG - 2021-05-04 05:57:02 --> Total execution time: 0.0719
INFO - 2021-05-04 05:57:26 --> Config Class Initialized
INFO - 2021-05-04 05:57:26 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:57:26 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:57:26 --> Utf8 Class Initialized
INFO - 2021-05-04 05:57:26 --> URI Class Initialized
INFO - 2021-05-04 05:57:26 --> Router Class Initialized
INFO - 2021-05-04 05:57:26 --> Output Class Initialized
INFO - 2021-05-04 05:57:26 --> Security Class Initialized
DEBUG - 2021-05-04 05:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:57:26 --> Input Class Initialized
INFO - 2021-05-04 05:57:26 --> Language Class Initialized
INFO - 2021-05-04 05:57:26 --> Language Class Initialized
INFO - 2021-05-04 05:57:26 --> Config Class Initialized
INFO - 2021-05-04 05:57:26 --> Loader Class Initialized
INFO - 2021-05-04 05:57:26 --> Helper loaded: url_helper
INFO - 2021-05-04 05:57:26 --> Helper loaded: file_helper
INFO - 2021-05-04 05:57:26 --> Helper loaded: form_helper
INFO - 2021-05-04 05:57:26 --> Helper loaded: my_helper
INFO - 2021-05-04 05:57:26 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:57:26 --> Controller Class Initialized
DEBUG - 2021-05-04 05:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:57:26 --> Final output sent to browser
DEBUG - 2021-05-04 05:57:26 --> Total execution time: 0.0622
INFO - 2021-05-04 05:57:38 --> Config Class Initialized
INFO - 2021-05-04 05:57:38 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:57:38 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:57:38 --> Utf8 Class Initialized
INFO - 2021-05-04 05:57:38 --> URI Class Initialized
INFO - 2021-05-04 05:57:38 --> Router Class Initialized
INFO - 2021-05-04 05:57:38 --> Output Class Initialized
INFO - 2021-05-04 05:57:38 --> Security Class Initialized
DEBUG - 2021-05-04 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:57:38 --> Input Class Initialized
INFO - 2021-05-04 05:57:38 --> Language Class Initialized
INFO - 2021-05-04 05:57:38 --> Language Class Initialized
INFO - 2021-05-04 05:57:38 --> Config Class Initialized
INFO - 2021-05-04 05:57:38 --> Loader Class Initialized
INFO - 2021-05-04 05:57:38 --> Helper loaded: url_helper
INFO - 2021-05-04 05:57:38 --> Helper loaded: file_helper
INFO - 2021-05-04 05:57:38 --> Helper loaded: form_helper
INFO - 2021-05-04 05:57:38 --> Helper loaded: my_helper
INFO - 2021-05-04 05:57:38 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:57:38 --> Controller Class Initialized
DEBUG - 2021-05-04 05:57:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:57:38 --> Final output sent to browser
DEBUG - 2021-05-04 05:57:38 --> Total execution time: 0.0560
INFO - 2021-05-04 05:57:53 --> Config Class Initialized
INFO - 2021-05-04 05:57:53 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:57:53 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:57:53 --> Utf8 Class Initialized
INFO - 2021-05-04 05:57:53 --> URI Class Initialized
INFO - 2021-05-04 05:57:53 --> Router Class Initialized
INFO - 2021-05-04 05:57:53 --> Output Class Initialized
INFO - 2021-05-04 05:57:53 --> Security Class Initialized
DEBUG - 2021-05-04 05:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:57:53 --> Input Class Initialized
INFO - 2021-05-04 05:57:53 --> Language Class Initialized
INFO - 2021-05-04 05:57:53 --> Language Class Initialized
INFO - 2021-05-04 05:57:53 --> Config Class Initialized
INFO - 2021-05-04 05:57:53 --> Loader Class Initialized
INFO - 2021-05-04 05:57:53 --> Helper loaded: url_helper
INFO - 2021-05-04 05:57:53 --> Helper loaded: file_helper
INFO - 2021-05-04 05:57:53 --> Helper loaded: form_helper
INFO - 2021-05-04 05:57:53 --> Helper loaded: my_helper
INFO - 2021-05-04 05:57:53 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:57:53 --> Controller Class Initialized
DEBUG - 2021-05-04 05:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:57:53 --> Final output sent to browser
DEBUG - 2021-05-04 05:57:53 --> Total execution time: 0.0823
INFO - 2021-05-04 05:58:13 --> Config Class Initialized
INFO - 2021-05-04 05:58:13 --> Hooks Class Initialized
DEBUG - 2021-05-04 05:58:13 --> UTF-8 Support Enabled
INFO - 2021-05-04 05:58:13 --> Utf8 Class Initialized
INFO - 2021-05-04 05:58:13 --> URI Class Initialized
INFO - 2021-05-04 05:58:13 --> Router Class Initialized
INFO - 2021-05-04 05:58:13 --> Output Class Initialized
INFO - 2021-05-04 05:58:13 --> Security Class Initialized
DEBUG - 2021-05-04 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-04 05:58:13 --> Input Class Initialized
INFO - 2021-05-04 05:58:13 --> Language Class Initialized
INFO - 2021-05-04 05:58:13 --> Language Class Initialized
INFO - 2021-05-04 05:58:13 --> Config Class Initialized
INFO - 2021-05-04 05:58:13 --> Loader Class Initialized
INFO - 2021-05-04 05:58:13 --> Helper loaded: url_helper
INFO - 2021-05-04 05:58:13 --> Helper loaded: file_helper
INFO - 2021-05-04 05:58:13 --> Helper loaded: form_helper
INFO - 2021-05-04 05:58:13 --> Helper loaded: my_helper
INFO - 2021-05-04 05:58:13 --> Database Driver Class Initialized
DEBUG - 2021-05-04 05:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-04 05:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-04 05:58:13 --> Controller Class Initialized
DEBUG - 2021-05-04 05:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-05-04 05:58:13 --> Final output sent to browser
DEBUG - 2021-05-04 05:58:13 --> Total execution time: 0.0714
