<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-19 01:07:32 --> Config Class Initialized
INFO - 2020-12-19 01:07:32 --> Hooks Class Initialized
DEBUG - 2020-12-19 01:07:32 --> UTF-8 Support Enabled
INFO - 2020-12-19 01:07:32 --> Utf8 Class Initialized
INFO - 2020-12-19 01:07:32 --> URI Class Initialized
DEBUG - 2020-12-19 01:07:32 --> No URI present. Default controller set.
INFO - 2020-12-19 01:07:32 --> Router Class Initialized
INFO - 2020-12-19 01:07:32 --> Output Class Initialized
INFO - 2020-12-19 01:07:32 --> Security Class Initialized
DEBUG - 2020-12-19 01:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 01:07:32 --> Input Class Initialized
INFO - 2020-12-19 01:07:32 --> Language Class Initialized
INFO - 2020-12-19 01:07:33 --> Language Class Initialized
INFO - 2020-12-19 01:07:33 --> Config Class Initialized
INFO - 2020-12-19 01:07:33 --> Loader Class Initialized
INFO - 2020-12-19 01:07:33 --> Helper loaded: url_helper
INFO - 2020-12-19 01:07:33 --> Helper loaded: file_helper
INFO - 2020-12-19 01:07:33 --> Helper loaded: form_helper
INFO - 2020-12-19 01:07:33 --> Helper loaded: my_helper
INFO - 2020-12-19 01:07:33 --> Database Driver Class Initialized
DEBUG - 2020-12-19 01:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 01:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 01:07:33 --> Controller Class Initialized
INFO - 2020-12-19 01:07:33 --> Config Class Initialized
INFO - 2020-12-19 01:07:33 --> Hooks Class Initialized
DEBUG - 2020-12-19 01:07:33 --> UTF-8 Support Enabled
INFO - 2020-12-19 01:07:33 --> Utf8 Class Initialized
INFO - 2020-12-19 01:07:33 --> URI Class Initialized
INFO - 2020-12-19 01:07:33 --> Router Class Initialized
INFO - 2020-12-19 01:07:33 --> Output Class Initialized
INFO - 2020-12-19 01:07:33 --> Security Class Initialized
DEBUG - 2020-12-19 01:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 01:07:33 --> Input Class Initialized
INFO - 2020-12-19 01:07:33 --> Language Class Initialized
INFO - 2020-12-19 01:07:33 --> Language Class Initialized
INFO - 2020-12-19 01:07:33 --> Config Class Initialized
INFO - 2020-12-19 01:07:33 --> Loader Class Initialized
INFO - 2020-12-19 01:07:33 --> Helper loaded: url_helper
INFO - 2020-12-19 01:07:33 --> Helper loaded: file_helper
INFO - 2020-12-19 01:07:33 --> Helper loaded: form_helper
INFO - 2020-12-19 01:07:33 --> Helper loaded: my_helper
INFO - 2020-12-19 01:07:33 --> Database Driver Class Initialized
DEBUG - 2020-12-19 01:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 01:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 01:07:33 --> Controller Class Initialized
DEBUG - 2020-12-19 01:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-19 01:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 01:07:33 --> Final output sent to browser
DEBUG - 2020-12-19 01:07:33 --> Total execution time: 0.2429
INFO - 2020-12-19 01:19:46 --> Config Class Initialized
INFO - 2020-12-19 01:19:46 --> Hooks Class Initialized
DEBUG - 2020-12-19 01:19:46 --> UTF-8 Support Enabled
INFO - 2020-12-19 01:19:46 --> Utf8 Class Initialized
INFO - 2020-12-19 01:19:46 --> URI Class Initialized
INFO - 2020-12-19 01:19:46 --> Router Class Initialized
INFO - 2020-12-19 01:19:46 --> Output Class Initialized
INFO - 2020-12-19 01:19:46 --> Security Class Initialized
DEBUG - 2020-12-19 01:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 01:19:46 --> Input Class Initialized
INFO - 2020-12-19 01:19:46 --> Language Class Initialized
INFO - 2020-12-19 01:19:46 --> Language Class Initialized
INFO - 2020-12-19 01:19:46 --> Config Class Initialized
INFO - 2020-12-19 01:19:46 --> Loader Class Initialized
INFO - 2020-12-19 01:19:46 --> Helper loaded: url_helper
INFO - 2020-12-19 01:19:46 --> Helper loaded: file_helper
INFO - 2020-12-19 01:19:46 --> Helper loaded: form_helper
INFO - 2020-12-19 01:19:46 --> Helper loaded: my_helper
INFO - 2020-12-19 01:19:46 --> Database Driver Class Initialized
DEBUG - 2020-12-19 01:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 01:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 01:19:46 --> Controller Class Initialized
INFO - 2020-12-19 01:19:46 --> Helper loaded: cookie_helper
INFO - 2020-12-19 01:19:46 --> Final output sent to browser
DEBUG - 2020-12-19 01:19:46 --> Total execution time: 0.3241
INFO - 2020-12-19 01:19:50 --> Config Class Initialized
INFO - 2020-12-19 01:19:50 --> Hooks Class Initialized
DEBUG - 2020-12-19 01:19:50 --> UTF-8 Support Enabled
INFO - 2020-12-19 01:19:50 --> Utf8 Class Initialized
INFO - 2020-12-19 01:19:50 --> URI Class Initialized
INFO - 2020-12-19 01:19:50 --> Router Class Initialized
INFO - 2020-12-19 01:19:50 --> Output Class Initialized
INFO - 2020-12-19 01:19:50 --> Security Class Initialized
DEBUG - 2020-12-19 01:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 01:19:50 --> Input Class Initialized
INFO - 2020-12-19 01:19:50 --> Language Class Initialized
INFO - 2020-12-19 01:19:50 --> Language Class Initialized
INFO - 2020-12-19 01:19:50 --> Config Class Initialized
INFO - 2020-12-19 01:19:50 --> Loader Class Initialized
INFO - 2020-12-19 01:19:50 --> Helper loaded: url_helper
INFO - 2020-12-19 01:19:50 --> Helper loaded: file_helper
INFO - 2020-12-19 01:19:50 --> Helper loaded: form_helper
INFO - 2020-12-19 01:19:50 --> Helper loaded: my_helper
INFO - 2020-12-19 01:19:50 --> Database Driver Class Initialized
DEBUG - 2020-12-19 01:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 01:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 01:19:50 --> Controller Class Initialized
DEBUG - 2020-12-19 01:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-19 01:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 01:19:50 --> Final output sent to browser
DEBUG - 2020-12-19 01:19:50 --> Total execution time: 0.3544
INFO - 2020-12-19 01:19:57 --> Config Class Initialized
INFO - 2020-12-19 01:19:57 --> Hooks Class Initialized
DEBUG - 2020-12-19 01:19:57 --> UTF-8 Support Enabled
INFO - 2020-12-19 01:19:57 --> Utf8 Class Initialized
INFO - 2020-12-19 01:19:57 --> URI Class Initialized
INFO - 2020-12-19 01:19:57 --> Router Class Initialized
INFO - 2020-12-19 01:19:57 --> Output Class Initialized
INFO - 2020-12-19 01:19:57 --> Security Class Initialized
DEBUG - 2020-12-19 01:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 01:19:57 --> Input Class Initialized
INFO - 2020-12-19 01:19:57 --> Language Class Initialized
INFO - 2020-12-19 01:19:58 --> Language Class Initialized
INFO - 2020-12-19 01:19:58 --> Config Class Initialized
INFO - 2020-12-19 01:19:58 --> Loader Class Initialized
INFO - 2020-12-19 01:19:58 --> Helper loaded: url_helper
INFO - 2020-12-19 01:19:58 --> Helper loaded: file_helper
INFO - 2020-12-19 01:19:58 --> Helper loaded: form_helper
INFO - 2020-12-19 01:19:58 --> Helper loaded: my_helper
INFO - 2020-12-19 01:19:58 --> Database Driver Class Initialized
DEBUG - 2020-12-19 01:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 01:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 01:19:58 --> Controller Class Initialized
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:58 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 01:19:59 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
DEBUG - 2020-12-19 01:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 01:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 01:19:59 --> Final output sent to browser
DEBUG - 2020-12-19 01:19:59 --> Total execution time: 1.6359
INFO - 2020-12-19 02:51:44 --> Config Class Initialized
INFO - 2020-12-19 02:51:44 --> Hooks Class Initialized
DEBUG - 2020-12-19 02:51:44 --> UTF-8 Support Enabled
INFO - 2020-12-19 02:51:44 --> Utf8 Class Initialized
INFO - 2020-12-19 02:51:44 --> URI Class Initialized
INFO - 2020-12-19 02:51:44 --> Router Class Initialized
INFO - 2020-12-19 02:51:44 --> Output Class Initialized
INFO - 2020-12-19 02:51:44 --> Security Class Initialized
DEBUG - 2020-12-19 02:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 02:51:44 --> Input Class Initialized
INFO - 2020-12-19 02:51:44 --> Language Class Initialized
INFO - 2020-12-19 02:51:44 --> Language Class Initialized
INFO - 2020-12-19 02:51:44 --> Config Class Initialized
INFO - 2020-12-19 02:51:44 --> Loader Class Initialized
INFO - 2020-12-19 02:51:44 --> Helper loaded: url_helper
INFO - 2020-12-19 02:51:44 --> Helper loaded: file_helper
INFO - 2020-12-19 02:51:44 --> Helper loaded: form_helper
INFO - 2020-12-19 02:51:44 --> Helper loaded: my_helper
INFO - 2020-12-19 02:51:44 --> Database Driver Class Initialized
DEBUG - 2020-12-19 02:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 02:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 02:51:44 --> Controller Class Initialized
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:44 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:45 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 02:51:46 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
DEBUG - 2020-12-19 02:51:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 02:51:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 02:51:46 --> Final output sent to browser
DEBUG - 2020-12-19 02:51:46 --> Total execution time: 1.3694
INFO - 2020-12-19 03:13:31 --> Config Class Initialized
INFO - 2020-12-19 03:13:31 --> Hooks Class Initialized
DEBUG - 2020-12-19 03:13:31 --> UTF-8 Support Enabled
INFO - 2020-12-19 03:13:31 --> Utf8 Class Initialized
INFO - 2020-12-19 03:13:31 --> URI Class Initialized
INFO - 2020-12-19 03:13:31 --> Router Class Initialized
INFO - 2020-12-19 03:13:31 --> Output Class Initialized
INFO - 2020-12-19 03:13:31 --> Security Class Initialized
DEBUG - 2020-12-19 03:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 03:13:31 --> Input Class Initialized
INFO - 2020-12-19 03:13:31 --> Language Class Initialized
INFO - 2020-12-19 03:13:31 --> Language Class Initialized
INFO - 2020-12-19 03:13:31 --> Config Class Initialized
INFO - 2020-12-19 03:13:31 --> Loader Class Initialized
INFO - 2020-12-19 03:13:31 --> Helper loaded: url_helper
INFO - 2020-12-19 03:13:31 --> Helper loaded: file_helper
INFO - 2020-12-19 03:13:31 --> Helper loaded: form_helper
INFO - 2020-12-19 03:13:31 --> Helper loaded: my_helper
INFO - 2020-12-19 03:13:31 --> Database Driver Class Initialized
DEBUG - 2020-12-19 03:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 03:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 03:13:31 --> Controller Class Initialized
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:13:32 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
DEBUG - 2020-12-19 03:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 03:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 03:13:32 --> Final output sent to browser
DEBUG - 2020-12-19 03:13:32 --> Total execution time: 1.4647
INFO - 2020-12-19 03:16:29 --> Config Class Initialized
INFO - 2020-12-19 03:16:29 --> Hooks Class Initialized
DEBUG - 2020-12-19 03:16:29 --> UTF-8 Support Enabled
INFO - 2020-12-19 03:16:29 --> Utf8 Class Initialized
INFO - 2020-12-19 03:16:30 --> URI Class Initialized
INFO - 2020-12-19 03:16:30 --> Router Class Initialized
INFO - 2020-12-19 03:16:30 --> Output Class Initialized
INFO - 2020-12-19 03:16:30 --> Security Class Initialized
DEBUG - 2020-12-19 03:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 03:16:30 --> Input Class Initialized
INFO - 2020-12-19 03:16:30 --> Language Class Initialized
INFO - 2020-12-19 03:16:30 --> Language Class Initialized
INFO - 2020-12-19 03:16:30 --> Config Class Initialized
INFO - 2020-12-19 03:16:30 --> Loader Class Initialized
INFO - 2020-12-19 03:16:30 --> Helper loaded: url_helper
INFO - 2020-12-19 03:16:30 --> Helper loaded: file_helper
INFO - 2020-12-19 03:16:30 --> Helper loaded: form_helper
INFO - 2020-12-19 03:16:30 --> Helper loaded: my_helper
INFO - 2020-12-19 03:16:30 --> Database Driver Class Initialized
DEBUG - 2020-12-19 03:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 03:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 03:16:30 --> Controller Class Initialized
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-19 03:16:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
DEBUG - 2020-12-19 03:16:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 03:16:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 03:16:31 --> Final output sent to browser
DEBUG - 2020-12-19 03:16:31 --> Total execution time: 1.5606
INFO - 2020-12-19 03:50:17 --> Config Class Initialized
INFO - 2020-12-19 03:50:17 --> Hooks Class Initialized
DEBUG - 2020-12-19 03:50:17 --> UTF-8 Support Enabled
INFO - 2020-12-19 03:50:17 --> Utf8 Class Initialized
INFO - 2020-12-19 03:50:17 --> URI Class Initialized
INFO - 2020-12-19 03:50:17 --> Router Class Initialized
INFO - 2020-12-19 03:50:17 --> Output Class Initialized
INFO - 2020-12-19 03:50:17 --> Security Class Initialized
DEBUG - 2020-12-19 03:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 03:50:17 --> Input Class Initialized
INFO - 2020-12-19 03:50:17 --> Language Class Initialized
INFO - 2020-12-19 03:50:17 --> Language Class Initialized
INFO - 2020-12-19 03:50:17 --> Config Class Initialized
INFO - 2020-12-19 03:50:17 --> Loader Class Initialized
INFO - 2020-12-19 03:50:17 --> Helper loaded: url_helper
INFO - 2020-12-19 03:50:17 --> Helper loaded: file_helper
INFO - 2020-12-19 03:50:17 --> Helper loaded: form_helper
INFO - 2020-12-19 03:50:17 --> Helper loaded: my_helper
INFO - 2020-12-19 03:50:17 --> Database Driver Class Initialized
DEBUG - 2020-12-19 03:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 03:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 03:50:18 --> Controller Class Initialized
DEBUG - 2020-12-19 03:50:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 03:50:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 03:50:18 --> Final output sent to browser
DEBUG - 2020-12-19 03:50:18 --> Total execution time: 0.2329
INFO - 2020-12-19 03:56:18 --> Config Class Initialized
INFO - 2020-12-19 03:56:18 --> Hooks Class Initialized
DEBUG - 2020-12-19 03:56:18 --> UTF-8 Support Enabled
INFO - 2020-12-19 03:56:18 --> Utf8 Class Initialized
INFO - 2020-12-19 03:56:18 --> URI Class Initialized
INFO - 2020-12-19 03:56:18 --> Router Class Initialized
INFO - 2020-12-19 03:56:18 --> Output Class Initialized
INFO - 2020-12-19 03:56:18 --> Security Class Initialized
DEBUG - 2020-12-19 03:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 03:56:18 --> Input Class Initialized
INFO - 2020-12-19 03:56:18 --> Language Class Initialized
INFO - 2020-12-19 03:56:18 --> Language Class Initialized
INFO - 2020-12-19 03:56:18 --> Config Class Initialized
INFO - 2020-12-19 03:56:18 --> Loader Class Initialized
INFO - 2020-12-19 03:56:18 --> Helper loaded: url_helper
INFO - 2020-12-19 03:56:18 --> Helper loaded: file_helper
INFO - 2020-12-19 03:56:18 --> Helper loaded: form_helper
INFO - 2020-12-19 03:56:18 --> Helper loaded: my_helper
INFO - 2020-12-19 03:56:18 --> Database Driver Class Initialized
DEBUG - 2020-12-19 03:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 03:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 03:56:18 --> Controller Class Initialized
DEBUG - 2020-12-19 03:56:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 03:56:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 03:56:18 --> Final output sent to browser
DEBUG - 2020-12-19 03:56:18 --> Total execution time: 0.2382
INFO - 2020-12-19 04:02:27 --> Config Class Initialized
INFO - 2020-12-19 04:02:27 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:02:27 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:02:27 --> Utf8 Class Initialized
INFO - 2020-12-19 04:02:27 --> URI Class Initialized
INFO - 2020-12-19 04:02:27 --> Router Class Initialized
INFO - 2020-12-19 04:02:27 --> Output Class Initialized
INFO - 2020-12-19 04:02:27 --> Security Class Initialized
DEBUG - 2020-12-19 04:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:02:27 --> Input Class Initialized
INFO - 2020-12-19 04:02:27 --> Language Class Initialized
INFO - 2020-12-19 04:02:27 --> Language Class Initialized
INFO - 2020-12-19 04:02:27 --> Config Class Initialized
INFO - 2020-12-19 04:02:27 --> Loader Class Initialized
INFO - 2020-12-19 04:02:27 --> Helper loaded: url_helper
INFO - 2020-12-19 04:02:27 --> Helper loaded: file_helper
INFO - 2020-12-19 04:02:27 --> Helper loaded: form_helper
INFO - 2020-12-19 04:02:27 --> Helper loaded: my_helper
INFO - 2020-12-19 04:02:27 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:02:27 --> Controller Class Initialized
DEBUG - 2020-12-19 04:02:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 04:02:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:02:27 --> Final output sent to browser
DEBUG - 2020-12-19 04:02:27 --> Total execution time: 0.2288
INFO - 2020-12-19 04:02:32 --> Config Class Initialized
INFO - 2020-12-19 04:02:32 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:02:32 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:02:32 --> Utf8 Class Initialized
INFO - 2020-12-19 04:02:32 --> URI Class Initialized
INFO - 2020-12-19 04:02:32 --> Router Class Initialized
INFO - 2020-12-19 04:02:32 --> Output Class Initialized
INFO - 2020-12-19 04:02:32 --> Security Class Initialized
DEBUG - 2020-12-19 04:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:02:32 --> Input Class Initialized
INFO - 2020-12-19 04:02:32 --> Language Class Initialized
INFO - 2020-12-19 04:02:32 --> Language Class Initialized
INFO - 2020-12-19 04:02:32 --> Config Class Initialized
INFO - 2020-12-19 04:02:32 --> Loader Class Initialized
INFO - 2020-12-19 04:02:32 --> Helper loaded: url_helper
INFO - 2020-12-19 04:02:32 --> Helper loaded: file_helper
INFO - 2020-12-19 04:02:32 --> Helper loaded: form_helper
INFO - 2020-12-19 04:02:32 --> Helper loaded: my_helper
INFO - 2020-12-19 04:02:32 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:02:32 --> Controller Class Initialized
DEBUG - 2020-12-19 04:02:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 04:02:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:02:32 --> Final output sent to browser
DEBUG - 2020-12-19 04:02:32 --> Total execution time: 0.2228
INFO - 2020-12-19 04:02:33 --> Config Class Initialized
INFO - 2020-12-19 04:02:33 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:02:33 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:02:33 --> Utf8 Class Initialized
INFO - 2020-12-19 04:02:33 --> URI Class Initialized
INFO - 2020-12-19 04:02:33 --> Router Class Initialized
INFO - 2020-12-19 04:02:33 --> Output Class Initialized
INFO - 2020-12-19 04:02:33 --> Security Class Initialized
DEBUG - 2020-12-19 04:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:02:33 --> Input Class Initialized
INFO - 2020-12-19 04:02:33 --> Language Class Initialized
INFO - 2020-12-19 04:02:33 --> Language Class Initialized
INFO - 2020-12-19 04:02:33 --> Config Class Initialized
INFO - 2020-12-19 04:02:33 --> Loader Class Initialized
INFO - 2020-12-19 04:02:33 --> Helper loaded: url_helper
INFO - 2020-12-19 04:02:33 --> Helper loaded: file_helper
INFO - 2020-12-19 04:02:33 --> Helper loaded: form_helper
INFO - 2020-12-19 04:02:33 --> Helper loaded: my_helper
INFO - 2020-12-19 04:02:33 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:02:33 --> Controller Class Initialized
DEBUG - 2020-12-19 04:02:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 04:02:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:02:33 --> Final output sent to browser
DEBUG - 2020-12-19 04:02:33 --> Total execution time: 0.2349
INFO - 2020-12-19 04:02:53 --> Config Class Initialized
INFO - 2020-12-19 04:02:53 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:02:53 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:02:53 --> Utf8 Class Initialized
INFO - 2020-12-19 04:02:53 --> URI Class Initialized
DEBUG - 2020-12-19 04:02:53 --> No URI present. Default controller set.
INFO - 2020-12-19 04:02:53 --> Router Class Initialized
INFO - 2020-12-19 04:02:53 --> Output Class Initialized
INFO - 2020-12-19 04:02:53 --> Security Class Initialized
DEBUG - 2020-12-19 04:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:02:53 --> Input Class Initialized
INFO - 2020-12-19 04:02:53 --> Language Class Initialized
INFO - 2020-12-19 04:02:53 --> Language Class Initialized
INFO - 2020-12-19 04:02:53 --> Config Class Initialized
INFO - 2020-12-19 04:02:53 --> Loader Class Initialized
INFO - 2020-12-19 04:02:53 --> Helper loaded: url_helper
INFO - 2020-12-19 04:02:53 --> Helper loaded: file_helper
INFO - 2020-12-19 04:02:53 --> Helper loaded: form_helper
INFO - 2020-12-19 04:02:53 --> Helper loaded: my_helper
INFO - 2020-12-19 04:02:53 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:02:54 --> Controller Class Initialized
DEBUG - 2020-12-19 04:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-19 04:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:02:54 --> Final output sent to browser
DEBUG - 2020-12-19 04:02:54 --> Total execution time: 0.2632
INFO - 2020-12-19 04:02:56 --> Config Class Initialized
INFO - 2020-12-19 04:02:56 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:02:56 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:02:56 --> Utf8 Class Initialized
INFO - 2020-12-19 04:02:56 --> URI Class Initialized
INFO - 2020-12-19 04:02:56 --> Router Class Initialized
INFO - 2020-12-19 04:02:56 --> Output Class Initialized
INFO - 2020-12-19 04:02:56 --> Security Class Initialized
DEBUG - 2020-12-19 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:02:56 --> Input Class Initialized
INFO - 2020-12-19 04:02:56 --> Language Class Initialized
INFO - 2020-12-19 04:02:56 --> Language Class Initialized
INFO - 2020-12-19 04:02:56 --> Config Class Initialized
INFO - 2020-12-19 04:02:56 --> Loader Class Initialized
INFO - 2020-12-19 04:02:56 --> Helper loaded: url_helper
INFO - 2020-12-19 04:02:56 --> Helper loaded: file_helper
INFO - 2020-12-19 04:02:56 --> Helper loaded: form_helper
INFO - 2020-12-19 04:02:56 --> Helper loaded: my_helper
INFO - 2020-12-19 04:02:56 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:02:56 --> Controller Class Initialized
DEBUG - 2020-12-19 04:02:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 04:02:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:02:56 --> Final output sent to browser
DEBUG - 2020-12-19 04:02:56 --> Total execution time: 0.2210
INFO - 2020-12-19 04:03:21 --> Config Class Initialized
INFO - 2020-12-19 04:03:21 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:03:21 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:03:21 --> Utf8 Class Initialized
INFO - 2020-12-19 04:03:21 --> URI Class Initialized
DEBUG - 2020-12-19 04:03:21 --> No URI present. Default controller set.
INFO - 2020-12-19 04:03:21 --> Router Class Initialized
INFO - 2020-12-19 04:03:21 --> Output Class Initialized
INFO - 2020-12-19 04:03:21 --> Security Class Initialized
DEBUG - 2020-12-19 04:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:03:21 --> Input Class Initialized
INFO - 2020-12-19 04:03:21 --> Language Class Initialized
INFO - 2020-12-19 04:03:21 --> Language Class Initialized
INFO - 2020-12-19 04:03:21 --> Config Class Initialized
INFO - 2020-12-19 04:03:21 --> Loader Class Initialized
INFO - 2020-12-19 04:03:21 --> Helper loaded: url_helper
INFO - 2020-12-19 04:03:21 --> Helper loaded: file_helper
INFO - 2020-12-19 04:03:21 --> Helper loaded: form_helper
INFO - 2020-12-19 04:03:21 --> Helper loaded: my_helper
INFO - 2020-12-19 04:03:21 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:03:21 --> Controller Class Initialized
INFO - 2020-12-19 04:03:21 --> Config Class Initialized
INFO - 2020-12-19 04:03:22 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:03:22 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:03:22 --> Utf8 Class Initialized
INFO - 2020-12-19 04:03:22 --> URI Class Initialized
INFO - 2020-12-19 04:03:22 --> Router Class Initialized
INFO - 2020-12-19 04:03:22 --> Output Class Initialized
INFO - 2020-12-19 04:03:22 --> Security Class Initialized
DEBUG - 2020-12-19 04:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:03:22 --> Input Class Initialized
INFO - 2020-12-19 04:03:22 --> Language Class Initialized
INFO - 2020-12-19 04:03:22 --> Language Class Initialized
INFO - 2020-12-19 04:03:22 --> Config Class Initialized
INFO - 2020-12-19 04:03:22 --> Loader Class Initialized
INFO - 2020-12-19 04:03:22 --> Helper loaded: url_helper
INFO - 2020-12-19 04:03:22 --> Helper loaded: file_helper
INFO - 2020-12-19 04:03:22 --> Helper loaded: form_helper
INFO - 2020-12-19 04:03:22 --> Helper loaded: my_helper
INFO - 2020-12-19 04:03:22 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:03:22 --> Controller Class Initialized
DEBUG - 2020-12-19 04:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-19 04:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:03:22 --> Final output sent to browser
DEBUG - 2020-12-19 04:03:22 --> Total execution time: 0.1983
INFO - 2020-12-19 04:03:27 --> Config Class Initialized
INFO - 2020-12-19 04:03:27 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:03:27 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:03:27 --> Utf8 Class Initialized
INFO - 2020-12-19 04:03:27 --> URI Class Initialized
INFO - 2020-12-19 04:03:27 --> Router Class Initialized
INFO - 2020-12-19 04:03:27 --> Output Class Initialized
INFO - 2020-12-19 04:03:27 --> Security Class Initialized
DEBUG - 2020-12-19 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:03:27 --> Input Class Initialized
INFO - 2020-12-19 04:03:27 --> Language Class Initialized
INFO - 2020-12-19 04:03:27 --> Language Class Initialized
INFO - 2020-12-19 04:03:27 --> Config Class Initialized
INFO - 2020-12-19 04:03:27 --> Loader Class Initialized
INFO - 2020-12-19 04:03:27 --> Helper loaded: url_helper
INFO - 2020-12-19 04:03:27 --> Helper loaded: file_helper
INFO - 2020-12-19 04:03:27 --> Helper loaded: form_helper
INFO - 2020-12-19 04:03:27 --> Helper loaded: my_helper
INFO - 2020-12-19 04:03:27 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:03:27 --> Controller Class Initialized
INFO - 2020-12-19 04:03:27 --> Helper loaded: cookie_helper
INFO - 2020-12-19 04:03:27 --> Final output sent to browser
DEBUG - 2020-12-19 04:03:27 --> Total execution time: 0.2955
INFO - 2020-12-19 04:03:27 --> Config Class Initialized
INFO - 2020-12-19 04:03:27 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:03:27 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:03:27 --> Utf8 Class Initialized
INFO - 2020-12-19 04:03:27 --> URI Class Initialized
INFO - 2020-12-19 04:03:27 --> Router Class Initialized
INFO - 2020-12-19 04:03:28 --> Output Class Initialized
INFO - 2020-12-19 04:03:28 --> Security Class Initialized
DEBUG - 2020-12-19 04:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:03:28 --> Input Class Initialized
INFO - 2020-12-19 04:03:28 --> Language Class Initialized
INFO - 2020-12-19 04:03:28 --> Language Class Initialized
INFO - 2020-12-19 04:03:28 --> Config Class Initialized
INFO - 2020-12-19 04:03:28 --> Loader Class Initialized
INFO - 2020-12-19 04:03:28 --> Helper loaded: url_helper
INFO - 2020-12-19 04:03:28 --> Helper loaded: file_helper
INFO - 2020-12-19 04:03:28 --> Helper loaded: form_helper
INFO - 2020-12-19 04:03:28 --> Helper loaded: my_helper
INFO - 2020-12-19 04:03:28 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:03:28 --> Controller Class Initialized
DEBUG - 2020-12-19 04:03:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-19 04:03:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:03:28 --> Final output sent to browser
DEBUG - 2020-12-19 04:03:28 --> Total execution time: 0.2429
INFO - 2020-12-19 04:03:29 --> Config Class Initialized
INFO - 2020-12-19 04:03:29 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:03:29 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:03:29 --> Utf8 Class Initialized
INFO - 2020-12-19 04:03:29 --> URI Class Initialized
INFO - 2020-12-19 04:03:29 --> Router Class Initialized
INFO - 2020-12-19 04:03:29 --> Output Class Initialized
INFO - 2020-12-19 04:03:29 --> Security Class Initialized
DEBUG - 2020-12-19 04:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:03:29 --> Input Class Initialized
INFO - 2020-12-19 04:03:29 --> Language Class Initialized
INFO - 2020-12-19 04:03:29 --> Language Class Initialized
INFO - 2020-12-19 04:03:29 --> Config Class Initialized
INFO - 2020-12-19 04:03:29 --> Loader Class Initialized
INFO - 2020-12-19 04:03:29 --> Helper loaded: url_helper
INFO - 2020-12-19 04:03:29 --> Helper loaded: file_helper
INFO - 2020-12-19 04:03:29 --> Helper loaded: form_helper
INFO - 2020-12-19 04:03:29 --> Helper loaded: my_helper
INFO - 2020-12-19 04:03:29 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:03:29 --> Controller Class Initialized
DEBUG - 2020-12-19 04:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 04:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:03:29 --> Final output sent to browser
DEBUG - 2020-12-19 04:03:29 --> Total execution time: 0.2447
INFO - 2020-12-19 04:04:52 --> Config Class Initialized
INFO - 2020-12-19 04:04:52 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:04:52 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:04:52 --> Utf8 Class Initialized
INFO - 2020-12-19 04:04:52 --> URI Class Initialized
INFO - 2020-12-19 04:04:52 --> Router Class Initialized
INFO - 2020-12-19 04:04:52 --> Output Class Initialized
INFO - 2020-12-19 04:04:52 --> Security Class Initialized
DEBUG - 2020-12-19 04:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:04:52 --> Input Class Initialized
INFO - 2020-12-19 04:04:52 --> Language Class Initialized
INFO - 2020-12-19 04:04:52 --> Language Class Initialized
INFO - 2020-12-19 04:04:52 --> Config Class Initialized
INFO - 2020-12-19 04:04:52 --> Loader Class Initialized
INFO - 2020-12-19 04:04:52 --> Helper loaded: url_helper
INFO - 2020-12-19 04:04:52 --> Helper loaded: file_helper
INFO - 2020-12-19 04:04:52 --> Helper loaded: form_helper
INFO - 2020-12-19 04:04:52 --> Helper loaded: my_helper
INFO - 2020-12-19 04:04:52 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:04:52 --> Controller Class Initialized
DEBUG - 2020-12-19 04:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 04:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:04:52 --> Final output sent to browser
DEBUG - 2020-12-19 04:04:52 --> Total execution time: 0.2298
INFO - 2020-12-19 04:23:46 --> Config Class Initialized
INFO - 2020-12-19 04:23:46 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:23:46 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:23:46 --> Utf8 Class Initialized
INFO - 2020-12-19 04:23:46 --> URI Class Initialized
INFO - 2020-12-19 04:23:46 --> Router Class Initialized
INFO - 2020-12-19 04:23:46 --> Output Class Initialized
INFO - 2020-12-19 04:23:46 --> Security Class Initialized
DEBUG - 2020-12-19 04:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:23:46 --> Input Class Initialized
INFO - 2020-12-19 04:23:46 --> Language Class Initialized
INFO - 2020-12-19 04:23:46 --> Language Class Initialized
INFO - 2020-12-19 04:23:46 --> Config Class Initialized
INFO - 2020-12-19 04:23:46 --> Loader Class Initialized
INFO - 2020-12-19 04:23:46 --> Helper loaded: url_helper
INFO - 2020-12-19 04:23:46 --> Helper loaded: file_helper
INFO - 2020-12-19 04:23:46 --> Helper loaded: form_helper
INFO - 2020-12-19 04:23:46 --> Helper loaded: my_helper
INFO - 2020-12-19 04:23:46 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:23:46 --> Controller Class Initialized
ERROR - 2020-12-19 04:23:46 --> Severity: Parsing Error --> syntax error, unexpected '$integritas' (T_VARIABLE), expecting '(' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-19 04:24:16 --> Config Class Initialized
INFO - 2020-12-19 04:24:16 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:24:16 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:24:16 --> Utf8 Class Initialized
INFO - 2020-12-19 04:24:16 --> URI Class Initialized
INFO - 2020-12-19 04:24:16 --> Router Class Initialized
INFO - 2020-12-19 04:24:16 --> Output Class Initialized
INFO - 2020-12-19 04:24:16 --> Security Class Initialized
DEBUG - 2020-12-19 04:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:24:16 --> Input Class Initialized
INFO - 2020-12-19 04:24:16 --> Language Class Initialized
INFO - 2020-12-19 04:24:16 --> Language Class Initialized
INFO - 2020-12-19 04:24:16 --> Config Class Initialized
INFO - 2020-12-19 04:24:16 --> Loader Class Initialized
INFO - 2020-12-19 04:24:16 --> Helper loaded: url_helper
INFO - 2020-12-19 04:24:16 --> Helper loaded: file_helper
INFO - 2020-12-19 04:24:16 --> Helper loaded: form_helper
INFO - 2020-12-19 04:24:16 --> Helper loaded: my_helper
INFO - 2020-12-19 04:24:16 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:24:16 --> Controller Class Initialized
ERROR - 2020-12-19 04:24:16 --> Severity: Parsing Error --> syntax error, unexpected '$integritas' (T_VARIABLE), expecting '(' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-19 04:24:18 --> Config Class Initialized
INFO - 2020-12-19 04:24:18 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:24:18 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:24:18 --> Utf8 Class Initialized
INFO - 2020-12-19 04:24:18 --> URI Class Initialized
INFO - 2020-12-19 04:24:18 --> Router Class Initialized
INFO - 2020-12-19 04:24:18 --> Output Class Initialized
INFO - 2020-12-19 04:24:18 --> Security Class Initialized
DEBUG - 2020-12-19 04:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:24:18 --> Input Class Initialized
INFO - 2020-12-19 04:24:18 --> Language Class Initialized
INFO - 2020-12-19 04:24:18 --> Language Class Initialized
INFO - 2020-12-19 04:24:18 --> Config Class Initialized
INFO - 2020-12-19 04:24:18 --> Loader Class Initialized
INFO - 2020-12-19 04:24:18 --> Helper loaded: url_helper
INFO - 2020-12-19 04:24:18 --> Helper loaded: file_helper
INFO - 2020-12-19 04:24:18 --> Helper loaded: form_helper
INFO - 2020-12-19 04:24:18 --> Helper loaded: my_helper
INFO - 2020-12-19 04:24:18 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:24:18 --> Controller Class Initialized
ERROR - 2020-12-19 04:24:18 --> Severity: Parsing Error --> syntax error, unexpected '$integritas' (T_VARIABLE), expecting '(' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-19 04:25:38 --> Config Class Initialized
INFO - 2020-12-19 04:25:38 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:25:38 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:25:38 --> Utf8 Class Initialized
INFO - 2020-12-19 04:25:38 --> URI Class Initialized
INFO - 2020-12-19 04:25:38 --> Router Class Initialized
INFO - 2020-12-19 04:25:38 --> Output Class Initialized
INFO - 2020-12-19 04:25:38 --> Security Class Initialized
DEBUG - 2020-12-19 04:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:25:38 --> Input Class Initialized
INFO - 2020-12-19 04:25:38 --> Language Class Initialized
INFO - 2020-12-19 04:25:38 --> Language Class Initialized
INFO - 2020-12-19 04:25:38 --> Config Class Initialized
INFO - 2020-12-19 04:25:38 --> Loader Class Initialized
INFO - 2020-12-19 04:25:38 --> Helper loaded: url_helper
INFO - 2020-12-19 04:25:38 --> Helper loaded: file_helper
INFO - 2020-12-19 04:25:38 --> Helper loaded: form_helper
INFO - 2020-12-19 04:25:38 --> Helper loaded: my_helper
INFO - 2020-12-19 04:25:38 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:25:38 --> Controller Class Initialized
ERROR - 2020-12-19 04:25:38 --> Severity: Parsing Error --> syntax error, unexpected '$integritas' (T_VARIABLE), expecting '(' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-19 04:25:40 --> Config Class Initialized
INFO - 2020-12-19 04:25:40 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:25:40 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:25:40 --> Utf8 Class Initialized
INFO - 2020-12-19 04:25:40 --> URI Class Initialized
INFO - 2020-12-19 04:25:40 --> Router Class Initialized
INFO - 2020-12-19 04:25:40 --> Output Class Initialized
INFO - 2020-12-19 04:25:40 --> Security Class Initialized
DEBUG - 2020-12-19 04:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:25:40 --> Input Class Initialized
INFO - 2020-12-19 04:25:40 --> Language Class Initialized
INFO - 2020-12-19 04:25:40 --> Language Class Initialized
INFO - 2020-12-19 04:25:40 --> Config Class Initialized
INFO - 2020-12-19 04:25:40 --> Loader Class Initialized
INFO - 2020-12-19 04:25:40 --> Helper loaded: url_helper
INFO - 2020-12-19 04:25:40 --> Helper loaded: file_helper
INFO - 2020-12-19 04:25:40 --> Helper loaded: form_helper
INFO - 2020-12-19 04:25:40 --> Helper loaded: my_helper
INFO - 2020-12-19 04:25:40 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:25:40 --> Controller Class Initialized
ERROR - 2020-12-19 04:25:40 --> Severity: Parsing Error --> syntax error, unexpected '$integritas' (T_VARIABLE), expecting '(' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-19 04:25:56 --> Config Class Initialized
INFO - 2020-12-19 04:25:56 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:25:56 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:25:56 --> Utf8 Class Initialized
INFO - 2020-12-19 04:25:56 --> URI Class Initialized
DEBUG - 2020-12-19 04:25:56 --> No URI present. Default controller set.
INFO - 2020-12-19 04:25:56 --> Router Class Initialized
INFO - 2020-12-19 04:25:56 --> Output Class Initialized
INFO - 2020-12-19 04:25:56 --> Security Class Initialized
DEBUG - 2020-12-19 04:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:25:56 --> Input Class Initialized
INFO - 2020-12-19 04:25:56 --> Language Class Initialized
INFO - 2020-12-19 04:25:56 --> Language Class Initialized
INFO - 2020-12-19 04:25:56 --> Config Class Initialized
INFO - 2020-12-19 04:25:56 --> Loader Class Initialized
INFO - 2020-12-19 04:25:56 --> Helper loaded: url_helper
INFO - 2020-12-19 04:25:56 --> Helper loaded: file_helper
INFO - 2020-12-19 04:25:56 --> Helper loaded: form_helper
INFO - 2020-12-19 04:25:56 --> Helper loaded: my_helper
INFO - 2020-12-19 04:25:56 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:25:56 --> Controller Class Initialized
INFO - 2020-12-19 04:25:56 --> Config Class Initialized
INFO - 2020-12-19 04:25:56 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:25:56 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:25:56 --> Utf8 Class Initialized
INFO - 2020-12-19 04:25:56 --> URI Class Initialized
INFO - 2020-12-19 04:25:56 --> Router Class Initialized
INFO - 2020-12-19 04:25:56 --> Output Class Initialized
INFO - 2020-12-19 04:25:56 --> Security Class Initialized
DEBUG - 2020-12-19 04:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:25:56 --> Input Class Initialized
INFO - 2020-12-19 04:25:56 --> Language Class Initialized
INFO - 2020-12-19 04:25:56 --> Language Class Initialized
INFO - 2020-12-19 04:25:56 --> Config Class Initialized
INFO - 2020-12-19 04:25:56 --> Loader Class Initialized
INFO - 2020-12-19 04:25:56 --> Helper loaded: url_helper
INFO - 2020-12-19 04:25:56 --> Helper loaded: file_helper
INFO - 2020-12-19 04:25:56 --> Helper loaded: form_helper
INFO - 2020-12-19 04:25:56 --> Helper loaded: my_helper
INFO - 2020-12-19 04:25:56 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:25:56 --> Controller Class Initialized
DEBUG - 2020-12-19 04:25:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-19 04:25:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:25:56 --> Final output sent to browser
DEBUG - 2020-12-19 04:25:56 --> Total execution time: 0.2258
INFO - 2020-12-19 04:26:03 --> Config Class Initialized
INFO - 2020-12-19 04:26:03 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:26:03 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:26:03 --> Utf8 Class Initialized
INFO - 2020-12-19 04:26:03 --> URI Class Initialized
INFO - 2020-12-19 04:26:03 --> Router Class Initialized
INFO - 2020-12-19 04:26:03 --> Output Class Initialized
INFO - 2020-12-19 04:26:03 --> Security Class Initialized
DEBUG - 2020-12-19 04:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:26:03 --> Input Class Initialized
INFO - 2020-12-19 04:26:03 --> Language Class Initialized
INFO - 2020-12-19 04:26:03 --> Language Class Initialized
INFO - 2020-12-19 04:26:03 --> Config Class Initialized
INFO - 2020-12-19 04:26:03 --> Loader Class Initialized
INFO - 2020-12-19 04:26:03 --> Helper loaded: url_helper
INFO - 2020-12-19 04:26:03 --> Helper loaded: file_helper
INFO - 2020-12-19 04:26:03 --> Helper loaded: form_helper
INFO - 2020-12-19 04:26:03 --> Helper loaded: my_helper
INFO - 2020-12-19 04:26:03 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:26:03 --> Controller Class Initialized
INFO - 2020-12-19 04:26:03 --> Helper loaded: cookie_helper
INFO - 2020-12-19 04:26:03 --> Final output sent to browser
DEBUG - 2020-12-19 04:26:03 --> Total execution time: 0.2222
INFO - 2020-12-19 04:26:04 --> Config Class Initialized
INFO - 2020-12-19 04:26:04 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:26:04 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:26:04 --> Utf8 Class Initialized
INFO - 2020-12-19 04:26:04 --> URI Class Initialized
INFO - 2020-12-19 04:26:04 --> Router Class Initialized
INFO - 2020-12-19 04:26:04 --> Output Class Initialized
INFO - 2020-12-19 04:26:04 --> Security Class Initialized
DEBUG - 2020-12-19 04:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:26:04 --> Input Class Initialized
INFO - 2020-12-19 04:26:04 --> Language Class Initialized
INFO - 2020-12-19 04:26:04 --> Language Class Initialized
INFO - 2020-12-19 04:26:04 --> Config Class Initialized
INFO - 2020-12-19 04:26:04 --> Loader Class Initialized
INFO - 2020-12-19 04:26:04 --> Helper loaded: url_helper
INFO - 2020-12-19 04:26:04 --> Helper loaded: file_helper
INFO - 2020-12-19 04:26:04 --> Helper loaded: form_helper
INFO - 2020-12-19 04:26:04 --> Helper loaded: my_helper
INFO - 2020-12-19 04:26:04 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:26:04 --> Controller Class Initialized
DEBUG - 2020-12-19 04:26:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-19 04:26:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:26:04 --> Final output sent to browser
DEBUG - 2020-12-19 04:26:04 --> Total execution time: 0.2455
INFO - 2020-12-19 04:26:05 --> Config Class Initialized
INFO - 2020-12-19 04:26:05 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:26:05 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:26:05 --> Utf8 Class Initialized
INFO - 2020-12-19 04:26:05 --> URI Class Initialized
INFO - 2020-12-19 04:26:05 --> Router Class Initialized
INFO - 2020-12-19 04:26:05 --> Output Class Initialized
INFO - 2020-12-19 04:26:05 --> Security Class Initialized
DEBUG - 2020-12-19 04:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:26:05 --> Input Class Initialized
INFO - 2020-12-19 04:26:05 --> Language Class Initialized
INFO - 2020-12-19 04:26:05 --> Language Class Initialized
INFO - 2020-12-19 04:26:05 --> Config Class Initialized
INFO - 2020-12-19 04:26:05 --> Loader Class Initialized
INFO - 2020-12-19 04:26:06 --> Helper loaded: url_helper
INFO - 2020-12-19 04:26:06 --> Helper loaded: file_helper
INFO - 2020-12-19 04:26:06 --> Helper loaded: form_helper
INFO - 2020-12-19 04:26:06 --> Helper loaded: my_helper
INFO - 2020-12-19 04:26:06 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:26:06 --> Controller Class Initialized
ERROR - 2020-12-19 04:26:06 --> Severity: Parsing Error --> syntax error, unexpected '$integritas' (T_VARIABLE), expecting '(' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-19 04:26:44 --> Config Class Initialized
INFO - 2020-12-19 04:26:44 --> Hooks Class Initialized
DEBUG - 2020-12-19 04:26:44 --> UTF-8 Support Enabled
INFO - 2020-12-19 04:26:44 --> Utf8 Class Initialized
INFO - 2020-12-19 04:26:44 --> URI Class Initialized
INFO - 2020-12-19 04:26:44 --> Router Class Initialized
INFO - 2020-12-19 04:26:44 --> Output Class Initialized
INFO - 2020-12-19 04:26:44 --> Security Class Initialized
DEBUG - 2020-12-19 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 04:26:44 --> Input Class Initialized
INFO - 2020-12-19 04:26:44 --> Language Class Initialized
INFO - 2020-12-19 04:26:44 --> Language Class Initialized
INFO - 2020-12-19 04:26:44 --> Config Class Initialized
INFO - 2020-12-19 04:26:44 --> Loader Class Initialized
INFO - 2020-12-19 04:26:44 --> Helper loaded: url_helper
INFO - 2020-12-19 04:26:44 --> Helper loaded: file_helper
INFO - 2020-12-19 04:26:44 --> Helper loaded: form_helper
INFO - 2020-12-19 04:26:44 --> Helper loaded: my_helper
INFO - 2020-12-19 04:26:44 --> Database Driver Class Initialized
DEBUG - 2020-12-19 04:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 04:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 04:26:44 --> Controller Class Initialized
DEBUG - 2020-12-19 04:26:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 04:26:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 04:26:44 --> Final output sent to browser
DEBUG - 2020-12-19 04:26:44 --> Total execution time: 0.2220
INFO - 2020-12-19 05:15:19 --> Config Class Initialized
INFO - 2020-12-19 05:15:19 --> Hooks Class Initialized
DEBUG - 2020-12-19 05:15:19 --> UTF-8 Support Enabled
INFO - 2020-12-19 05:15:19 --> Utf8 Class Initialized
INFO - 2020-12-19 05:15:19 --> URI Class Initialized
INFO - 2020-12-19 05:15:19 --> Router Class Initialized
INFO - 2020-12-19 05:15:19 --> Output Class Initialized
INFO - 2020-12-19 05:15:20 --> Security Class Initialized
DEBUG - 2020-12-19 05:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 05:15:20 --> Input Class Initialized
INFO - 2020-12-19 05:15:20 --> Language Class Initialized
INFO - 2020-12-19 05:15:20 --> Language Class Initialized
INFO - 2020-12-19 05:15:20 --> Config Class Initialized
INFO - 2020-12-19 05:15:20 --> Loader Class Initialized
INFO - 2020-12-19 05:15:20 --> Helper loaded: url_helper
INFO - 2020-12-19 05:15:20 --> Helper loaded: file_helper
INFO - 2020-12-19 05:15:20 --> Helper loaded: form_helper
INFO - 2020-12-19 05:15:20 --> Helper loaded: my_helper
INFO - 2020-12-19 05:15:20 --> Database Driver Class Initialized
DEBUG - 2020-12-19 05:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 05:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 05:15:20 --> Controller Class Initialized
ERROR - 2020-12-19 05:15:20 --> Severity: Parsing Error --> syntax error, unexpected '$religius' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 69
INFO - 2020-12-19 05:16:24 --> Config Class Initialized
INFO - 2020-12-19 05:16:24 --> Hooks Class Initialized
DEBUG - 2020-12-19 05:16:24 --> UTF-8 Support Enabled
INFO - 2020-12-19 05:16:24 --> Utf8 Class Initialized
INFO - 2020-12-19 05:16:24 --> URI Class Initialized
INFO - 2020-12-19 05:16:24 --> Router Class Initialized
INFO - 2020-12-19 05:16:24 --> Output Class Initialized
INFO - 2020-12-19 05:16:24 --> Security Class Initialized
DEBUG - 2020-12-19 05:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 05:16:24 --> Input Class Initialized
INFO - 2020-12-19 05:16:24 --> Language Class Initialized
INFO - 2020-12-19 05:16:24 --> Language Class Initialized
INFO - 2020-12-19 05:16:24 --> Config Class Initialized
INFO - 2020-12-19 05:16:24 --> Loader Class Initialized
INFO - 2020-12-19 05:16:24 --> Helper loaded: url_helper
INFO - 2020-12-19 05:16:24 --> Helper loaded: file_helper
INFO - 2020-12-19 05:16:24 --> Helper loaded: form_helper
INFO - 2020-12-19 05:16:24 --> Helper loaded: my_helper
INFO - 2020-12-19 05:16:24 --> Database Driver Class Initialized
DEBUG - 2020-12-19 05:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 05:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 05:16:24 --> Controller Class Initialized
DEBUG - 2020-12-19 05:16:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 05:16:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 05:16:24 --> Final output sent to browser
DEBUG - 2020-12-19 05:16:24 --> Total execution time: 0.2687
INFO - 2020-12-19 05:34:35 --> Config Class Initialized
INFO - 2020-12-19 05:34:35 --> Hooks Class Initialized
DEBUG - 2020-12-19 05:34:35 --> UTF-8 Support Enabled
INFO - 2020-12-19 05:34:35 --> Utf8 Class Initialized
INFO - 2020-12-19 05:34:35 --> URI Class Initialized
INFO - 2020-12-19 05:34:35 --> Router Class Initialized
INFO - 2020-12-19 05:34:35 --> Output Class Initialized
INFO - 2020-12-19 05:34:35 --> Security Class Initialized
DEBUG - 2020-12-19 05:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 05:34:36 --> Input Class Initialized
INFO - 2020-12-19 05:34:36 --> Language Class Initialized
INFO - 2020-12-19 05:34:36 --> Language Class Initialized
INFO - 2020-12-19 05:34:36 --> Config Class Initialized
INFO - 2020-12-19 05:34:36 --> Loader Class Initialized
INFO - 2020-12-19 05:34:36 --> Helper loaded: url_helper
INFO - 2020-12-19 05:34:36 --> Helper loaded: file_helper
INFO - 2020-12-19 05:34:36 --> Helper loaded: form_helper
INFO - 2020-12-19 05:34:36 --> Helper loaded: my_helper
INFO - 2020-12-19 05:34:36 --> Database Driver Class Initialized
DEBUG - 2020-12-19 05:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 05:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 05:34:36 --> Controller Class Initialized
DEBUG - 2020-12-19 05:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 05:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 05:34:36 --> Final output sent to browser
DEBUG - 2020-12-19 05:34:36 --> Total execution time: 0.2290
INFO - 2020-12-19 05:40:55 --> Config Class Initialized
INFO - 2020-12-19 05:40:55 --> Hooks Class Initialized
DEBUG - 2020-12-19 05:40:55 --> UTF-8 Support Enabled
INFO - 2020-12-19 05:40:55 --> Utf8 Class Initialized
INFO - 2020-12-19 05:40:55 --> URI Class Initialized
INFO - 2020-12-19 05:40:55 --> Router Class Initialized
INFO - 2020-12-19 05:40:55 --> Output Class Initialized
INFO - 2020-12-19 05:40:55 --> Security Class Initialized
DEBUG - 2020-12-19 05:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 05:40:55 --> Input Class Initialized
INFO - 2020-12-19 05:40:55 --> Language Class Initialized
INFO - 2020-12-19 05:40:55 --> Language Class Initialized
INFO - 2020-12-19 05:40:55 --> Config Class Initialized
INFO - 2020-12-19 05:40:55 --> Loader Class Initialized
INFO - 2020-12-19 05:40:55 --> Helper loaded: url_helper
INFO - 2020-12-19 05:40:55 --> Helper loaded: file_helper
INFO - 2020-12-19 05:40:55 --> Helper loaded: form_helper
INFO - 2020-12-19 05:40:55 --> Helper loaded: my_helper
INFO - 2020-12-19 05:40:55 --> Database Driver Class Initialized
DEBUG - 2020-12-19 05:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 05:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 05:40:55 --> Controller Class Initialized
ERROR - 2020-12-19 05:40:55 --> Severity: Parsing Error --> syntax error, unexpected '$religius' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 69
INFO - 2020-12-19 05:41:29 --> Config Class Initialized
INFO - 2020-12-19 05:41:29 --> Hooks Class Initialized
DEBUG - 2020-12-19 05:41:29 --> UTF-8 Support Enabled
INFO - 2020-12-19 05:41:29 --> Utf8 Class Initialized
INFO - 2020-12-19 05:41:29 --> URI Class Initialized
INFO - 2020-12-19 05:41:29 --> Router Class Initialized
INFO - 2020-12-19 05:41:29 --> Output Class Initialized
INFO - 2020-12-19 05:41:29 --> Security Class Initialized
DEBUG - 2020-12-19 05:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 05:41:29 --> Input Class Initialized
INFO - 2020-12-19 05:41:29 --> Language Class Initialized
INFO - 2020-12-19 05:41:29 --> Language Class Initialized
INFO - 2020-12-19 05:41:29 --> Config Class Initialized
INFO - 2020-12-19 05:41:29 --> Loader Class Initialized
INFO - 2020-12-19 05:41:29 --> Helper loaded: url_helper
INFO - 2020-12-19 05:41:29 --> Helper loaded: file_helper
INFO - 2020-12-19 05:41:30 --> Helper loaded: form_helper
INFO - 2020-12-19 05:41:30 --> Helper loaded: my_helper
INFO - 2020-12-19 05:41:30 --> Database Driver Class Initialized
DEBUG - 2020-12-19 05:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 05:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 05:41:30 --> Controller Class Initialized
ERROR - 2020-12-19 05:41:30 --> Severity: Parsing Error --> syntax error, unexpected '$religius' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 69
INFO - 2020-12-19 05:42:08 --> Config Class Initialized
INFO - 2020-12-19 05:42:08 --> Hooks Class Initialized
DEBUG - 2020-12-19 05:42:08 --> UTF-8 Support Enabled
INFO - 2020-12-19 05:42:08 --> Utf8 Class Initialized
INFO - 2020-12-19 05:42:08 --> URI Class Initialized
INFO - 2020-12-19 05:42:08 --> Router Class Initialized
INFO - 2020-12-19 05:42:08 --> Output Class Initialized
INFO - 2020-12-19 05:42:08 --> Security Class Initialized
DEBUG - 2020-12-19 05:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 05:42:08 --> Input Class Initialized
INFO - 2020-12-19 05:42:09 --> Language Class Initialized
INFO - 2020-12-19 05:42:09 --> Language Class Initialized
INFO - 2020-12-19 05:42:09 --> Config Class Initialized
INFO - 2020-12-19 05:42:09 --> Loader Class Initialized
INFO - 2020-12-19 05:42:09 --> Helper loaded: url_helper
INFO - 2020-12-19 05:42:09 --> Helper loaded: file_helper
INFO - 2020-12-19 05:42:09 --> Helper loaded: form_helper
INFO - 2020-12-19 05:42:09 --> Helper loaded: my_helper
INFO - 2020-12-19 05:42:09 --> Database Driver Class Initialized
DEBUG - 2020-12-19 05:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 05:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 05:42:09 --> Controller Class Initialized
DEBUG - 2020-12-19 05:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 05:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 05:42:09 --> Final output sent to browser
DEBUG - 2020-12-19 05:42:09 --> Total execution time: 0.2298
INFO - 2020-12-19 09:30:05 --> Config Class Initialized
INFO - 2020-12-19 09:30:05 --> Hooks Class Initialized
DEBUG - 2020-12-19 09:30:05 --> UTF-8 Support Enabled
INFO - 2020-12-19 09:30:05 --> Utf8 Class Initialized
INFO - 2020-12-19 09:30:05 --> URI Class Initialized
INFO - 2020-12-19 09:30:05 --> Router Class Initialized
INFO - 2020-12-19 09:30:05 --> Output Class Initialized
INFO - 2020-12-19 09:30:05 --> Security Class Initialized
DEBUG - 2020-12-19 09:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 09:30:05 --> Input Class Initialized
INFO - 2020-12-19 09:30:05 --> Language Class Initialized
INFO - 2020-12-19 09:30:05 --> Language Class Initialized
INFO - 2020-12-19 09:30:05 --> Config Class Initialized
INFO - 2020-12-19 09:30:05 --> Loader Class Initialized
INFO - 2020-12-19 09:30:05 --> Helper loaded: url_helper
INFO - 2020-12-19 09:30:05 --> Helper loaded: file_helper
INFO - 2020-12-19 09:30:05 --> Helper loaded: form_helper
INFO - 2020-12-19 09:30:05 --> Helper loaded: my_helper
INFO - 2020-12-19 09:30:05 --> Database Driver Class Initialized
DEBUG - 2020-12-19 09:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 09:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 09:30:05 --> Controller Class Initialized
DEBUG - 2020-12-19 09:30:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 09:30:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 09:30:05 --> Final output sent to browser
DEBUG - 2020-12-19 09:30:05 --> Total execution time: 0.2270
INFO - 2020-12-19 09:30:07 --> Config Class Initialized
INFO - 2020-12-19 09:30:07 --> Hooks Class Initialized
DEBUG - 2020-12-19 09:30:07 --> UTF-8 Support Enabled
INFO - 2020-12-19 09:30:07 --> Utf8 Class Initialized
INFO - 2020-12-19 09:30:07 --> URI Class Initialized
INFO - 2020-12-19 09:30:07 --> Router Class Initialized
INFO - 2020-12-19 09:30:07 --> Output Class Initialized
INFO - 2020-12-19 09:30:07 --> Security Class Initialized
DEBUG - 2020-12-19 09:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-19 09:30:07 --> Input Class Initialized
INFO - 2020-12-19 09:30:07 --> Language Class Initialized
INFO - 2020-12-19 09:30:07 --> Language Class Initialized
INFO - 2020-12-19 09:30:07 --> Config Class Initialized
INFO - 2020-12-19 09:30:07 --> Loader Class Initialized
INFO - 2020-12-19 09:30:07 --> Helper loaded: url_helper
INFO - 2020-12-19 09:30:07 --> Helper loaded: file_helper
INFO - 2020-12-19 09:30:07 --> Helper loaded: form_helper
INFO - 2020-12-19 09:30:07 --> Helper loaded: my_helper
INFO - 2020-12-19 09:30:07 --> Database Driver Class Initialized
DEBUG - 2020-12-19 09:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-19 09:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-19 09:30:07 --> Controller Class Initialized
DEBUG - 2020-12-19 09:30:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-19 09:30:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-19 09:30:07 --> Final output sent to browser
DEBUG - 2020-12-19 09:30:07 --> Total execution time: 0.2320
