<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-02 09:51:37 --> Config Class Initialized
INFO - 2022-07-02 09:51:37 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:51:37 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:51:37 --> Utf8 Class Initialized
INFO - 2022-07-02 09:51:37 --> URI Class Initialized
DEBUG - 2022-07-02 09:51:37 --> No URI present. Default controller set.
INFO - 2022-07-02 09:51:37 --> Router Class Initialized
INFO - 2022-07-02 09:51:37 --> Output Class Initialized
INFO - 2022-07-02 09:51:37 --> Security Class Initialized
DEBUG - 2022-07-02 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:51:37 --> Input Class Initialized
INFO - 2022-07-02 09:51:37 --> Language Class Initialized
INFO - 2022-07-02 09:51:37 --> Language Class Initialized
INFO - 2022-07-02 09:51:37 --> Config Class Initialized
INFO - 2022-07-02 09:51:37 --> Loader Class Initialized
INFO - 2022-07-02 09:51:37 --> Helper loaded: url_helper
INFO - 2022-07-02 09:51:37 --> Helper loaded: file_helper
INFO - 2022-07-02 09:51:37 --> Helper loaded: form_helper
INFO - 2022-07-02 09:51:37 --> Helper loaded: my_helper
INFO - 2022-07-02 09:51:37 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:51:37 --> Controller Class Initialized
INFO - 2022-07-02 09:51:37 --> Config Class Initialized
INFO - 2022-07-02 09:51:37 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:51:37 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:51:37 --> Utf8 Class Initialized
INFO - 2022-07-02 09:51:37 --> URI Class Initialized
INFO - 2022-07-02 09:51:37 --> Router Class Initialized
INFO - 2022-07-02 09:51:37 --> Output Class Initialized
INFO - 2022-07-02 09:51:37 --> Security Class Initialized
DEBUG - 2022-07-02 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:51:37 --> Input Class Initialized
INFO - 2022-07-02 09:51:37 --> Language Class Initialized
INFO - 2022-07-02 09:51:37 --> Language Class Initialized
INFO - 2022-07-02 09:51:37 --> Config Class Initialized
INFO - 2022-07-02 09:51:37 --> Loader Class Initialized
INFO - 2022-07-02 09:51:38 --> Helper loaded: url_helper
INFO - 2022-07-02 09:51:38 --> Helper loaded: file_helper
INFO - 2022-07-02 09:51:38 --> Helper loaded: form_helper
INFO - 2022-07-02 09:51:38 --> Helper loaded: my_helper
INFO - 2022-07-02 09:51:38 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:51:38 --> Controller Class Initialized
DEBUG - 2022-07-02 09:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 09:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:51:38 --> Final output sent to browser
DEBUG - 2022-07-02 09:51:38 --> Total execution time: 0.0474
INFO - 2022-07-02 09:52:28 --> Config Class Initialized
INFO - 2022-07-02 09:52:28 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:28 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:28 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:28 --> URI Class Initialized
INFO - 2022-07-02 09:52:28 --> Router Class Initialized
INFO - 2022-07-02 09:52:28 --> Output Class Initialized
INFO - 2022-07-02 09:52:28 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:28 --> Input Class Initialized
INFO - 2022-07-02 09:52:28 --> Language Class Initialized
INFO - 2022-07-02 09:52:28 --> Language Class Initialized
INFO - 2022-07-02 09:52:28 --> Config Class Initialized
INFO - 2022-07-02 09:52:28 --> Loader Class Initialized
INFO - 2022-07-02 09:52:28 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:28 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:28 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:28 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:28 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:28 --> Controller Class Initialized
INFO - 2022-07-02 09:52:28 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:52:28 --> Final output sent to browser
DEBUG - 2022-07-02 09:52:28 --> Total execution time: 0.0692
INFO - 2022-07-02 09:52:29 --> Config Class Initialized
INFO - 2022-07-02 09:52:29 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:29 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:29 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:29 --> URI Class Initialized
INFO - 2022-07-02 09:52:29 --> Router Class Initialized
INFO - 2022-07-02 09:52:29 --> Output Class Initialized
INFO - 2022-07-02 09:52:29 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:29 --> Input Class Initialized
INFO - 2022-07-02 09:52:29 --> Language Class Initialized
INFO - 2022-07-02 09:52:29 --> Language Class Initialized
INFO - 2022-07-02 09:52:29 --> Config Class Initialized
INFO - 2022-07-02 09:52:29 --> Loader Class Initialized
INFO - 2022-07-02 09:52:29 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:29 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:29 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:29 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:29 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:29 --> Controller Class Initialized
DEBUG - 2022-07-02 09:52:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 09:52:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:52:30 --> Final output sent to browser
DEBUG - 2022-07-02 09:52:30 --> Total execution time: 0.8722
INFO - 2022-07-02 09:52:52 --> Config Class Initialized
INFO - 2022-07-02 09:52:52 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:52 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:52 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:52 --> URI Class Initialized
INFO - 2022-07-02 09:52:52 --> Router Class Initialized
INFO - 2022-07-02 09:52:52 --> Output Class Initialized
INFO - 2022-07-02 09:52:52 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:52 --> Input Class Initialized
INFO - 2022-07-02 09:52:52 --> Language Class Initialized
INFO - 2022-07-02 09:52:52 --> Language Class Initialized
INFO - 2022-07-02 09:52:52 --> Config Class Initialized
INFO - 2022-07-02 09:52:52 --> Loader Class Initialized
INFO - 2022-07-02 09:52:52 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:52 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:52 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:52 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:52 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:52 --> Controller Class Initialized
DEBUG - 2022-07-02 09:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2022-07-02 09:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:52:52 --> Final output sent to browser
DEBUG - 2022-07-02 09:52:52 --> Total execution time: 0.0442
INFO - 2022-07-02 09:52:52 --> Config Class Initialized
INFO - 2022-07-02 09:52:52 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:52 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:52 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:52 --> URI Class Initialized
INFO - 2022-07-02 09:52:52 --> Router Class Initialized
INFO - 2022-07-02 09:52:52 --> Output Class Initialized
INFO - 2022-07-02 09:52:52 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:52 --> Input Class Initialized
INFO - 2022-07-02 09:52:52 --> Language Class Initialized
INFO - 2022-07-02 09:52:52 --> Language Class Initialized
INFO - 2022-07-02 09:52:52 --> Config Class Initialized
INFO - 2022-07-02 09:52:52 --> Loader Class Initialized
INFO - 2022-07-02 09:52:52 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:52 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:52 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:52 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:52 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:52 --> Controller Class Initialized
INFO - 2022-07-02 09:52:53 --> Config Class Initialized
INFO - 2022-07-02 09:52:53 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:53 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:53 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:53 --> URI Class Initialized
INFO - 2022-07-02 09:52:53 --> Router Class Initialized
INFO - 2022-07-02 09:52:53 --> Output Class Initialized
INFO - 2022-07-02 09:52:53 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:53 --> Input Class Initialized
INFO - 2022-07-02 09:52:53 --> Language Class Initialized
INFO - 2022-07-02 09:52:53 --> Language Class Initialized
INFO - 2022-07-02 09:52:53 --> Config Class Initialized
INFO - 2022-07-02 09:52:53 --> Loader Class Initialized
INFO - 2022-07-02 09:52:53 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:53 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:53 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:53 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:53 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:53 --> Controller Class Initialized
DEBUG - 2022-07-02 09:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-02 09:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:52:53 --> Final output sent to browser
DEBUG - 2022-07-02 09:52:53 --> Total execution time: 0.0442
INFO - 2022-07-02 09:52:53 --> Config Class Initialized
INFO - 2022-07-02 09:52:53 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:53 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:53 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:53 --> URI Class Initialized
INFO - 2022-07-02 09:52:53 --> Router Class Initialized
INFO - 2022-07-02 09:52:53 --> Output Class Initialized
INFO - 2022-07-02 09:52:53 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:53 --> Input Class Initialized
INFO - 2022-07-02 09:52:53 --> Language Class Initialized
INFO - 2022-07-02 09:52:53 --> Language Class Initialized
INFO - 2022-07-02 09:52:53 --> Config Class Initialized
INFO - 2022-07-02 09:52:53 --> Loader Class Initialized
INFO - 2022-07-02 09:52:53 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:53 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:53 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:53 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:53 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:53 --> Controller Class Initialized
INFO - 2022-07-02 09:52:57 --> Config Class Initialized
INFO - 2022-07-02 09:52:57 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:57 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:57 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:57 --> URI Class Initialized
INFO - 2022-07-02 09:52:57 --> Router Class Initialized
INFO - 2022-07-02 09:52:57 --> Output Class Initialized
INFO - 2022-07-02 09:52:57 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:57 --> Input Class Initialized
INFO - 2022-07-02 09:52:57 --> Language Class Initialized
INFO - 2022-07-02 09:52:57 --> Language Class Initialized
INFO - 2022-07-02 09:52:57 --> Config Class Initialized
INFO - 2022-07-02 09:52:57 --> Loader Class Initialized
INFO - 2022-07-02 09:52:57 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:57 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:57 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:57 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:57 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:57 --> Controller Class Initialized
INFO - 2022-07-02 09:52:58 --> Config Class Initialized
INFO - 2022-07-02 09:52:58 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:58 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:58 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:58 --> URI Class Initialized
INFO - 2022-07-02 09:52:58 --> Router Class Initialized
INFO - 2022-07-02 09:52:58 --> Output Class Initialized
INFO - 2022-07-02 09:52:58 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:58 --> Input Class Initialized
INFO - 2022-07-02 09:52:58 --> Language Class Initialized
INFO - 2022-07-02 09:52:58 --> Language Class Initialized
INFO - 2022-07-02 09:52:58 --> Config Class Initialized
INFO - 2022-07-02 09:52:58 --> Loader Class Initialized
INFO - 2022-07-02 09:52:58 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:58 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:58 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:58 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:58 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:58 --> Controller Class Initialized
INFO - 2022-07-02 09:52:58 --> Config Class Initialized
INFO - 2022-07-02 09:52:58 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:58 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:58 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:58 --> URI Class Initialized
INFO - 2022-07-02 09:52:58 --> Router Class Initialized
INFO - 2022-07-02 09:52:58 --> Output Class Initialized
INFO - 2022-07-02 09:52:58 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:58 --> Input Class Initialized
INFO - 2022-07-02 09:52:58 --> Language Class Initialized
INFO - 2022-07-02 09:52:58 --> Language Class Initialized
INFO - 2022-07-02 09:52:58 --> Config Class Initialized
INFO - 2022-07-02 09:52:58 --> Loader Class Initialized
INFO - 2022-07-02 09:52:58 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:58 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:58 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:58 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:58 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:58 --> Controller Class Initialized
INFO - 2022-07-02 09:52:59 --> Config Class Initialized
INFO - 2022-07-02 09:52:59 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:52:59 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:52:59 --> Utf8 Class Initialized
INFO - 2022-07-02 09:52:59 --> URI Class Initialized
INFO - 2022-07-02 09:52:59 --> Router Class Initialized
INFO - 2022-07-02 09:52:59 --> Output Class Initialized
INFO - 2022-07-02 09:52:59 --> Security Class Initialized
DEBUG - 2022-07-02 09:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:52:59 --> Input Class Initialized
INFO - 2022-07-02 09:52:59 --> Language Class Initialized
INFO - 2022-07-02 09:52:59 --> Language Class Initialized
INFO - 2022-07-02 09:52:59 --> Config Class Initialized
INFO - 2022-07-02 09:52:59 --> Loader Class Initialized
INFO - 2022-07-02 09:52:59 --> Helper loaded: url_helper
INFO - 2022-07-02 09:52:59 --> Helper loaded: file_helper
INFO - 2022-07-02 09:52:59 --> Helper loaded: form_helper
INFO - 2022-07-02 09:52:59 --> Helper loaded: my_helper
INFO - 2022-07-02 09:52:59 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:52:59 --> Controller Class Initialized
INFO - 2022-07-02 09:53:01 --> Config Class Initialized
INFO - 2022-07-02 09:53:01 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:53:01 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:53:01 --> Utf8 Class Initialized
INFO - 2022-07-02 09:53:01 --> URI Class Initialized
INFO - 2022-07-02 09:53:01 --> Router Class Initialized
INFO - 2022-07-02 09:53:01 --> Output Class Initialized
INFO - 2022-07-02 09:53:01 --> Security Class Initialized
DEBUG - 2022-07-02 09:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:53:01 --> Input Class Initialized
INFO - 2022-07-02 09:53:01 --> Language Class Initialized
INFO - 2022-07-02 09:53:01 --> Language Class Initialized
INFO - 2022-07-02 09:53:01 --> Config Class Initialized
INFO - 2022-07-02 09:53:01 --> Loader Class Initialized
INFO - 2022-07-02 09:53:01 --> Helper loaded: url_helper
INFO - 2022-07-02 09:53:01 --> Helper loaded: file_helper
INFO - 2022-07-02 09:53:01 --> Helper loaded: form_helper
INFO - 2022-07-02 09:53:01 --> Helper loaded: my_helper
INFO - 2022-07-02 09:53:01 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:53:01 --> Controller Class Initialized
ERROR - 2022-07-02 09:53:01 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-02 09:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-02 09:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:53:01 --> Final output sent to browser
DEBUG - 2022-07-02 09:53:01 --> Total execution time: 0.0763
INFO - 2022-07-02 09:53:53 --> Config Class Initialized
INFO - 2022-07-02 09:53:53 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:53:53 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:53:53 --> Utf8 Class Initialized
INFO - 2022-07-02 09:53:53 --> URI Class Initialized
INFO - 2022-07-02 09:53:53 --> Router Class Initialized
INFO - 2022-07-02 09:53:53 --> Output Class Initialized
INFO - 2022-07-02 09:53:53 --> Security Class Initialized
DEBUG - 2022-07-02 09:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:53:53 --> Input Class Initialized
INFO - 2022-07-02 09:53:53 --> Language Class Initialized
INFO - 2022-07-02 09:53:53 --> Language Class Initialized
INFO - 2022-07-02 09:53:53 --> Config Class Initialized
INFO - 2022-07-02 09:53:53 --> Loader Class Initialized
INFO - 2022-07-02 09:53:53 --> Helper loaded: url_helper
INFO - 2022-07-02 09:53:53 --> Helper loaded: file_helper
INFO - 2022-07-02 09:53:53 --> Helper loaded: form_helper
INFO - 2022-07-02 09:53:53 --> Helper loaded: my_helper
INFO - 2022-07-02 09:53:53 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:53:53 --> Controller Class Initialized
DEBUG - 2022-07-02 09:53:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 09:53:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:53:53 --> Final output sent to browser
DEBUG - 2022-07-02 09:53:53 --> Total execution time: 0.0419
INFO - 2022-07-02 09:54:03 --> Config Class Initialized
INFO - 2022-07-02 09:54:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:03 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:03 --> URI Class Initialized
INFO - 2022-07-02 09:54:03 --> Router Class Initialized
INFO - 2022-07-02 09:54:03 --> Output Class Initialized
INFO - 2022-07-02 09:54:03 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:03 --> Input Class Initialized
INFO - 2022-07-02 09:54:03 --> Language Class Initialized
INFO - 2022-07-02 09:54:03 --> Language Class Initialized
INFO - 2022-07-02 09:54:03 --> Config Class Initialized
INFO - 2022-07-02 09:54:03 --> Loader Class Initialized
INFO - 2022-07-02 09:54:03 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:03 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:03 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:03 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:03 --> Controller Class Initialized
INFO - 2022-07-02 09:54:03 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:54:03 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:03 --> Total execution time: 0.0491
INFO - 2022-07-02 09:54:03 --> Config Class Initialized
INFO - 2022-07-02 09:54:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:03 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:03 --> URI Class Initialized
INFO - 2022-07-02 09:54:03 --> Router Class Initialized
INFO - 2022-07-02 09:54:03 --> Output Class Initialized
INFO - 2022-07-02 09:54:03 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:03 --> Input Class Initialized
INFO - 2022-07-02 09:54:03 --> Language Class Initialized
INFO - 2022-07-02 09:54:03 --> Language Class Initialized
INFO - 2022-07-02 09:54:03 --> Config Class Initialized
INFO - 2022-07-02 09:54:03 --> Loader Class Initialized
INFO - 2022-07-02 09:54:03 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:03 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:03 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:03 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:03 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 09:54:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:04 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:04 --> Total execution time: 0.5430
INFO - 2022-07-02 09:54:06 --> Config Class Initialized
INFO - 2022-07-02 09:54:06 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:06 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:06 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:06 --> URI Class Initialized
INFO - 2022-07-02 09:54:06 --> Router Class Initialized
INFO - 2022-07-02 09:54:06 --> Output Class Initialized
INFO - 2022-07-02 09:54:06 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:06 --> Input Class Initialized
INFO - 2022-07-02 09:54:06 --> Language Class Initialized
INFO - 2022-07-02 09:54:06 --> Language Class Initialized
INFO - 2022-07-02 09:54:06 --> Config Class Initialized
INFO - 2022-07-02 09:54:06 --> Loader Class Initialized
INFO - 2022-07-02 09:54:06 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:06 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:06 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:06 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:06 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:06 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-02 09:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:06 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:06 --> Total execution time: 0.0603
INFO - 2022-07-02 09:54:12 --> Config Class Initialized
INFO - 2022-07-02 09:54:12 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:12 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:12 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:12 --> URI Class Initialized
INFO - 2022-07-02 09:54:12 --> Router Class Initialized
INFO - 2022-07-02 09:54:12 --> Output Class Initialized
INFO - 2022-07-02 09:54:12 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:12 --> Input Class Initialized
INFO - 2022-07-02 09:54:12 --> Language Class Initialized
INFO - 2022-07-02 09:54:12 --> Language Class Initialized
INFO - 2022-07-02 09:54:12 --> Config Class Initialized
INFO - 2022-07-02 09:54:12 --> Loader Class Initialized
INFO - 2022-07-02 09:54:12 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:12 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:12 --> Controller Class Initialized
INFO - 2022-07-02 09:54:12 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:54:12 --> Config Class Initialized
INFO - 2022-07-02 09:54:12 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:12 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:12 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:12 --> URI Class Initialized
INFO - 2022-07-02 09:54:12 --> Router Class Initialized
INFO - 2022-07-02 09:54:12 --> Output Class Initialized
INFO - 2022-07-02 09:54:12 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:12 --> Input Class Initialized
INFO - 2022-07-02 09:54:12 --> Language Class Initialized
INFO - 2022-07-02 09:54:12 --> Language Class Initialized
INFO - 2022-07-02 09:54:12 --> Config Class Initialized
INFO - 2022-07-02 09:54:12 --> Loader Class Initialized
INFO - 2022-07-02 09:54:12 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:12 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:12 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 09:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:12 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:12 --> Total execution time: 0.0466
INFO - 2022-07-02 09:54:12 --> Config Class Initialized
INFO - 2022-07-02 09:54:12 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:12 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:12 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:12 --> URI Class Initialized
INFO - 2022-07-02 09:54:12 --> Router Class Initialized
INFO - 2022-07-02 09:54:12 --> Output Class Initialized
INFO - 2022-07-02 09:54:12 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:12 --> Input Class Initialized
INFO - 2022-07-02 09:54:12 --> Language Class Initialized
INFO - 2022-07-02 09:54:12 --> Language Class Initialized
INFO - 2022-07-02 09:54:12 --> Config Class Initialized
INFO - 2022-07-02 09:54:12 --> Loader Class Initialized
INFO - 2022-07-02 09:54:12 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:12 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:12 --> Controller Class Initialized
INFO - 2022-07-02 09:54:12 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:54:12 --> Config Class Initialized
INFO - 2022-07-02 09:54:12 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:12 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:12 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:12 --> URI Class Initialized
INFO - 2022-07-02 09:54:12 --> Router Class Initialized
INFO - 2022-07-02 09:54:12 --> Output Class Initialized
INFO - 2022-07-02 09:54:12 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:12 --> Input Class Initialized
INFO - 2022-07-02 09:54:12 --> Language Class Initialized
INFO - 2022-07-02 09:54:12 --> Language Class Initialized
INFO - 2022-07-02 09:54:12 --> Config Class Initialized
INFO - 2022-07-02 09:54:12 --> Loader Class Initialized
INFO - 2022-07-02 09:54:12 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:12 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:12 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:12 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 09:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:12 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:12 --> Total execution time: 0.0439
INFO - 2022-07-02 09:54:16 --> Config Class Initialized
INFO - 2022-07-02 09:54:16 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:16 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:16 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:16 --> URI Class Initialized
INFO - 2022-07-02 09:54:16 --> Router Class Initialized
INFO - 2022-07-02 09:54:16 --> Output Class Initialized
INFO - 2022-07-02 09:54:16 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:16 --> Input Class Initialized
INFO - 2022-07-02 09:54:16 --> Language Class Initialized
INFO - 2022-07-02 09:54:16 --> Language Class Initialized
INFO - 2022-07-02 09:54:16 --> Config Class Initialized
INFO - 2022-07-02 09:54:16 --> Loader Class Initialized
INFO - 2022-07-02 09:54:16 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:16 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:16 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:16 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:16 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:16 --> Controller Class Initialized
INFO - 2022-07-02 09:54:16 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:54:16 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:16 --> Total execution time: 0.0450
INFO - 2022-07-02 09:54:17 --> Config Class Initialized
INFO - 2022-07-02 09:54:17 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:17 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:17 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:17 --> URI Class Initialized
INFO - 2022-07-02 09:54:17 --> Router Class Initialized
INFO - 2022-07-02 09:54:17 --> Output Class Initialized
INFO - 2022-07-02 09:54:17 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:17 --> Input Class Initialized
INFO - 2022-07-02 09:54:17 --> Language Class Initialized
INFO - 2022-07-02 09:54:17 --> Language Class Initialized
INFO - 2022-07-02 09:54:17 --> Config Class Initialized
INFO - 2022-07-02 09:54:17 --> Loader Class Initialized
INFO - 2022-07-02 09:54:17 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:17 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:17 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:17 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:17 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:17 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 09:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:17 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:17 --> Total execution time: 0.5604
INFO - 2022-07-02 09:54:19 --> Config Class Initialized
INFO - 2022-07-02 09:54:19 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:19 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:19 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:19 --> URI Class Initialized
INFO - 2022-07-02 09:54:19 --> Router Class Initialized
INFO - 2022-07-02 09:54:19 --> Output Class Initialized
INFO - 2022-07-02 09:54:19 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:19 --> Input Class Initialized
INFO - 2022-07-02 09:54:19 --> Language Class Initialized
INFO - 2022-07-02 09:54:19 --> Language Class Initialized
INFO - 2022-07-02 09:54:19 --> Config Class Initialized
INFO - 2022-07-02 09:54:19 --> Loader Class Initialized
INFO - 2022-07-02 09:54:19 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:19 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:19 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:19 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:19 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:19 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-02 09:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:19 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:19 --> Total execution time: 0.0518
INFO - 2022-07-02 09:54:25 --> Config Class Initialized
INFO - 2022-07-02 09:54:25 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:25 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:25 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:25 --> URI Class Initialized
INFO - 2022-07-02 09:54:25 --> Router Class Initialized
INFO - 2022-07-02 09:54:25 --> Output Class Initialized
INFO - 2022-07-02 09:54:25 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:25 --> Input Class Initialized
INFO - 2022-07-02 09:54:25 --> Language Class Initialized
INFO - 2022-07-02 09:54:25 --> Language Class Initialized
INFO - 2022-07-02 09:54:25 --> Config Class Initialized
INFO - 2022-07-02 09:54:25 --> Loader Class Initialized
INFO - 2022-07-02 09:54:25 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:25 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:25 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:25 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:25 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:25 --> Controller Class Initialized
INFO - 2022-07-02 09:54:25 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:54:25 --> Config Class Initialized
INFO - 2022-07-02 09:54:25 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:25 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:25 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:25 --> URI Class Initialized
INFO - 2022-07-02 09:54:25 --> Router Class Initialized
INFO - 2022-07-02 09:54:25 --> Output Class Initialized
INFO - 2022-07-02 09:54:25 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:25 --> Input Class Initialized
INFO - 2022-07-02 09:54:25 --> Language Class Initialized
INFO - 2022-07-02 09:54:25 --> Language Class Initialized
INFO - 2022-07-02 09:54:25 --> Config Class Initialized
INFO - 2022-07-02 09:54:25 --> Loader Class Initialized
INFO - 2022-07-02 09:54:25 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:25 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:25 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:25 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:25 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:25 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 09:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:25 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:25 --> Total execution time: 0.0427
INFO - 2022-07-02 09:54:32 --> Config Class Initialized
INFO - 2022-07-02 09:54:32 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:32 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:32 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:32 --> URI Class Initialized
INFO - 2022-07-02 09:54:32 --> Router Class Initialized
INFO - 2022-07-02 09:54:32 --> Output Class Initialized
INFO - 2022-07-02 09:54:32 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:32 --> Input Class Initialized
INFO - 2022-07-02 09:54:32 --> Language Class Initialized
INFO - 2022-07-02 09:54:32 --> Language Class Initialized
INFO - 2022-07-02 09:54:32 --> Config Class Initialized
INFO - 2022-07-02 09:54:32 --> Loader Class Initialized
INFO - 2022-07-02 09:54:32 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:32 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:32 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:32 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:32 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:32 --> Controller Class Initialized
INFO - 2022-07-02 09:54:32 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:54:32 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:32 --> Total execution time: 0.0573
INFO - 2022-07-02 09:54:33 --> Config Class Initialized
INFO - 2022-07-02 09:54:33 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:33 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:33 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:33 --> URI Class Initialized
INFO - 2022-07-02 09:54:33 --> Router Class Initialized
INFO - 2022-07-02 09:54:33 --> Output Class Initialized
INFO - 2022-07-02 09:54:33 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:33 --> Input Class Initialized
INFO - 2022-07-02 09:54:33 --> Language Class Initialized
INFO - 2022-07-02 09:54:33 --> Language Class Initialized
INFO - 2022-07-02 09:54:33 --> Config Class Initialized
INFO - 2022-07-02 09:54:33 --> Loader Class Initialized
INFO - 2022-07-02 09:54:33 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:33 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:33 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:33 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:33 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:33 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 09:54:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:33 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:33 --> Total execution time: 0.5692
INFO - 2022-07-02 09:54:34 --> Config Class Initialized
INFO - 2022-07-02 09:54:34 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:54:34 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:54:34 --> Utf8 Class Initialized
INFO - 2022-07-02 09:54:34 --> URI Class Initialized
INFO - 2022-07-02 09:54:34 --> Router Class Initialized
INFO - 2022-07-02 09:54:34 --> Output Class Initialized
INFO - 2022-07-02 09:54:34 --> Security Class Initialized
DEBUG - 2022-07-02 09:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:54:34 --> Input Class Initialized
INFO - 2022-07-02 09:54:34 --> Language Class Initialized
INFO - 2022-07-02 09:54:34 --> Language Class Initialized
INFO - 2022-07-02 09:54:34 --> Config Class Initialized
INFO - 2022-07-02 09:54:34 --> Loader Class Initialized
INFO - 2022-07-02 09:54:34 --> Helper loaded: url_helper
INFO - 2022-07-02 09:54:34 --> Helper loaded: file_helper
INFO - 2022-07-02 09:54:34 --> Helper loaded: form_helper
INFO - 2022-07-02 09:54:34 --> Helper loaded: my_helper
INFO - 2022-07-02 09:54:34 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:54:34 --> Controller Class Initialized
DEBUG - 2022-07-02 09:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-02 09:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:54:34 --> Final output sent to browser
DEBUG - 2022-07-02 09:54:34 --> Total execution time: 0.0536
INFO - 2022-07-02 09:55:09 --> Config Class Initialized
INFO - 2022-07-02 09:55:09 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:55:09 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:55:09 --> Utf8 Class Initialized
INFO - 2022-07-02 09:55:09 --> URI Class Initialized
INFO - 2022-07-02 09:55:09 --> Router Class Initialized
INFO - 2022-07-02 09:55:09 --> Output Class Initialized
INFO - 2022-07-02 09:55:09 --> Security Class Initialized
DEBUG - 2022-07-02 09:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:55:09 --> Input Class Initialized
INFO - 2022-07-02 09:55:09 --> Language Class Initialized
INFO - 2022-07-02 09:55:09 --> Language Class Initialized
INFO - 2022-07-02 09:55:09 --> Config Class Initialized
INFO - 2022-07-02 09:55:09 --> Loader Class Initialized
INFO - 2022-07-02 09:55:09 --> Helper loaded: url_helper
INFO - 2022-07-02 09:55:09 --> Helper loaded: file_helper
INFO - 2022-07-02 09:55:09 --> Helper loaded: form_helper
INFO - 2022-07-02 09:55:09 --> Helper loaded: my_helper
INFO - 2022-07-02 09:55:09 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:55:09 --> Controller Class Initialized
INFO - 2022-07-02 09:55:09 --> Upload Class Initialized
INFO - 2022-07-02 09:55:09 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-02 09:55:09 --> The upload path does not appear to be valid.
INFO - 2022-07-02 09:55:09 --> Config Class Initialized
INFO - 2022-07-02 09:55:09 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:55:09 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:55:09 --> Utf8 Class Initialized
INFO - 2022-07-02 09:55:09 --> URI Class Initialized
INFO - 2022-07-02 09:55:09 --> Router Class Initialized
INFO - 2022-07-02 09:55:09 --> Output Class Initialized
INFO - 2022-07-02 09:55:09 --> Security Class Initialized
DEBUG - 2022-07-02 09:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:55:09 --> Input Class Initialized
INFO - 2022-07-02 09:55:09 --> Language Class Initialized
INFO - 2022-07-02 09:55:09 --> Language Class Initialized
INFO - 2022-07-02 09:55:09 --> Config Class Initialized
INFO - 2022-07-02 09:55:09 --> Loader Class Initialized
INFO - 2022-07-02 09:55:09 --> Helper loaded: url_helper
INFO - 2022-07-02 09:55:09 --> Helper loaded: file_helper
INFO - 2022-07-02 09:55:09 --> Helper loaded: form_helper
INFO - 2022-07-02 09:55:09 --> Helper loaded: my_helper
INFO - 2022-07-02 09:55:09 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:55:09 --> Controller Class Initialized
DEBUG - 2022-07-02 09:55:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-02 09:55:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:55:09 --> Final output sent to browser
DEBUG - 2022-07-02 09:55:09 --> Total execution time: 0.0423
INFO - 2022-07-02 09:55:09 --> Config Class Initialized
INFO - 2022-07-02 09:55:09 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:55:09 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:55:09 --> Utf8 Class Initialized
INFO - 2022-07-02 09:55:09 --> URI Class Initialized
INFO - 2022-07-02 09:55:09 --> Router Class Initialized
INFO - 2022-07-02 09:55:09 --> Output Class Initialized
INFO - 2022-07-02 09:55:09 --> Security Class Initialized
DEBUG - 2022-07-02 09:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:55:09 --> Input Class Initialized
INFO - 2022-07-02 09:55:09 --> Language Class Initialized
INFO - 2022-07-02 09:55:10 --> Language Class Initialized
INFO - 2022-07-02 09:55:10 --> Config Class Initialized
INFO - 2022-07-02 09:55:10 --> Loader Class Initialized
INFO - 2022-07-02 09:55:10 --> Helper loaded: url_helper
INFO - 2022-07-02 09:55:10 --> Helper loaded: file_helper
INFO - 2022-07-02 09:55:10 --> Helper loaded: form_helper
INFO - 2022-07-02 09:55:10 --> Helper loaded: my_helper
INFO - 2022-07-02 09:55:10 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:55:10 --> Controller Class Initialized
INFO - 2022-07-02 09:55:16 --> Config Class Initialized
INFO - 2022-07-02 09:55:16 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:55:16 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:55:16 --> Utf8 Class Initialized
INFO - 2022-07-02 09:55:16 --> URI Class Initialized
INFO - 2022-07-02 09:55:16 --> Router Class Initialized
INFO - 2022-07-02 09:55:16 --> Output Class Initialized
INFO - 2022-07-02 09:55:16 --> Security Class Initialized
DEBUG - 2022-07-02 09:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:55:16 --> Input Class Initialized
INFO - 2022-07-02 09:55:16 --> Language Class Initialized
INFO - 2022-07-02 09:55:16 --> Language Class Initialized
INFO - 2022-07-02 09:55:16 --> Config Class Initialized
INFO - 2022-07-02 09:55:16 --> Loader Class Initialized
INFO - 2022-07-02 09:55:16 --> Helper loaded: url_helper
INFO - 2022-07-02 09:55:16 --> Helper loaded: file_helper
INFO - 2022-07-02 09:55:16 --> Helper loaded: form_helper
INFO - 2022-07-02 09:55:16 --> Helper loaded: my_helper
INFO - 2022-07-02 09:55:16 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:55:16 --> Controller Class Initialized
INFO - 2022-07-02 09:55:18 --> Config Class Initialized
INFO - 2022-07-02 09:55:18 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:55:18 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:55:18 --> Utf8 Class Initialized
INFO - 2022-07-02 09:55:18 --> URI Class Initialized
INFO - 2022-07-02 09:55:18 --> Router Class Initialized
INFO - 2022-07-02 09:55:18 --> Output Class Initialized
INFO - 2022-07-02 09:55:18 --> Security Class Initialized
DEBUG - 2022-07-02 09:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:55:18 --> Input Class Initialized
INFO - 2022-07-02 09:55:18 --> Language Class Initialized
INFO - 2022-07-02 09:55:18 --> Language Class Initialized
INFO - 2022-07-02 09:55:18 --> Config Class Initialized
INFO - 2022-07-02 09:55:18 --> Loader Class Initialized
INFO - 2022-07-02 09:55:18 --> Helper loaded: url_helper
INFO - 2022-07-02 09:55:18 --> Helper loaded: file_helper
INFO - 2022-07-02 09:55:18 --> Helper loaded: form_helper
INFO - 2022-07-02 09:55:18 --> Helper loaded: my_helper
INFO - 2022-07-02 09:55:18 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:55:18 --> Controller Class Initialized
ERROR - 2022-07-02 09:55:18 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-02 09:55:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-02 09:55:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:55:18 --> Final output sent to browser
DEBUG - 2022-07-02 09:55:18 --> Total execution time: 0.0470
INFO - 2022-07-02 09:55:58 --> Config Class Initialized
INFO - 2022-07-02 09:55:58 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:55:58 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:55:58 --> Utf8 Class Initialized
INFO - 2022-07-02 09:55:58 --> URI Class Initialized
INFO - 2022-07-02 09:55:58 --> Router Class Initialized
INFO - 2022-07-02 09:55:58 --> Output Class Initialized
INFO - 2022-07-02 09:55:58 --> Security Class Initialized
DEBUG - 2022-07-02 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:55:58 --> Input Class Initialized
INFO - 2022-07-02 09:55:58 --> Language Class Initialized
INFO - 2022-07-02 09:55:58 --> Language Class Initialized
INFO - 2022-07-02 09:55:58 --> Config Class Initialized
INFO - 2022-07-02 09:55:58 --> Loader Class Initialized
INFO - 2022-07-02 09:55:58 --> Helper loaded: url_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: file_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: form_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: my_helper
INFO - 2022-07-02 09:55:58 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:55:58 --> Controller Class Initialized
INFO - 2022-07-02 09:55:58 --> Upload Class Initialized
INFO - 2022-07-02 09:55:58 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-02 09:55:58 --> The upload path does not appear to be valid.
INFO - 2022-07-02 09:55:58 --> Config Class Initialized
INFO - 2022-07-02 09:55:58 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:55:58 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:55:58 --> Utf8 Class Initialized
INFO - 2022-07-02 09:55:58 --> URI Class Initialized
INFO - 2022-07-02 09:55:58 --> Router Class Initialized
INFO - 2022-07-02 09:55:58 --> Output Class Initialized
INFO - 2022-07-02 09:55:58 --> Security Class Initialized
DEBUG - 2022-07-02 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:55:58 --> Input Class Initialized
INFO - 2022-07-02 09:55:58 --> Language Class Initialized
INFO - 2022-07-02 09:55:58 --> Language Class Initialized
INFO - 2022-07-02 09:55:58 --> Config Class Initialized
INFO - 2022-07-02 09:55:58 --> Loader Class Initialized
INFO - 2022-07-02 09:55:58 --> Helper loaded: url_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: file_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: form_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: my_helper
INFO - 2022-07-02 09:55:58 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:55:58 --> Controller Class Initialized
DEBUG - 2022-07-02 09:55:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-02 09:55:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:55:58 --> Final output sent to browser
DEBUG - 2022-07-02 09:55:58 --> Total execution time: 0.0433
INFO - 2022-07-02 09:55:58 --> Config Class Initialized
INFO - 2022-07-02 09:55:58 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:55:58 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:55:58 --> Utf8 Class Initialized
INFO - 2022-07-02 09:55:58 --> URI Class Initialized
INFO - 2022-07-02 09:55:58 --> Router Class Initialized
INFO - 2022-07-02 09:55:58 --> Output Class Initialized
INFO - 2022-07-02 09:55:58 --> Security Class Initialized
DEBUG - 2022-07-02 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:55:58 --> Input Class Initialized
INFO - 2022-07-02 09:55:58 --> Language Class Initialized
INFO - 2022-07-02 09:55:58 --> Language Class Initialized
INFO - 2022-07-02 09:55:58 --> Config Class Initialized
INFO - 2022-07-02 09:55:58 --> Loader Class Initialized
INFO - 2022-07-02 09:55:58 --> Helper loaded: url_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: file_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: form_helper
INFO - 2022-07-02 09:55:58 --> Helper loaded: my_helper
INFO - 2022-07-02 09:55:58 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:55:58 --> Controller Class Initialized
INFO - 2022-07-02 09:56:42 --> Config Class Initialized
INFO - 2022-07-02 09:56:42 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:56:42 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:56:42 --> Utf8 Class Initialized
INFO - 2022-07-02 09:56:42 --> URI Class Initialized
INFO - 2022-07-02 09:56:42 --> Router Class Initialized
INFO - 2022-07-02 09:56:42 --> Output Class Initialized
INFO - 2022-07-02 09:56:42 --> Security Class Initialized
DEBUG - 2022-07-02 09:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:56:42 --> Input Class Initialized
INFO - 2022-07-02 09:56:42 --> Language Class Initialized
INFO - 2022-07-02 09:56:42 --> Language Class Initialized
INFO - 2022-07-02 09:56:42 --> Config Class Initialized
INFO - 2022-07-02 09:56:42 --> Loader Class Initialized
INFO - 2022-07-02 09:56:42 --> Helper loaded: url_helper
INFO - 2022-07-02 09:56:42 --> Helper loaded: file_helper
INFO - 2022-07-02 09:56:42 --> Helper loaded: form_helper
INFO - 2022-07-02 09:56:42 --> Helper loaded: my_helper
INFO - 2022-07-02 09:56:42 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:56:42 --> Controller Class Initialized
DEBUG - 2022-07-02 09:56:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-07-02 09:56:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:56:42 --> Final output sent to browser
DEBUG - 2022-07-02 09:56:42 --> Total execution time: 0.0646
INFO - 2022-07-02 09:56:42 --> Config Class Initialized
INFO - 2022-07-02 09:56:42 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:56:42 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:56:42 --> Utf8 Class Initialized
INFO - 2022-07-02 09:56:42 --> URI Class Initialized
INFO - 2022-07-02 09:56:42 --> Router Class Initialized
INFO - 2022-07-02 09:56:42 --> Output Class Initialized
INFO - 2022-07-02 09:56:42 --> Security Class Initialized
DEBUG - 2022-07-02 09:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:56:42 --> Input Class Initialized
INFO - 2022-07-02 09:56:42 --> Language Class Initialized
INFO - 2022-07-02 09:56:42 --> Language Class Initialized
INFO - 2022-07-02 09:56:42 --> Config Class Initialized
INFO - 2022-07-02 09:56:42 --> Loader Class Initialized
INFO - 2022-07-02 09:56:42 --> Helper loaded: url_helper
INFO - 2022-07-02 09:56:42 --> Helper loaded: file_helper
INFO - 2022-07-02 09:56:42 --> Helper loaded: form_helper
INFO - 2022-07-02 09:56:42 --> Helper loaded: my_helper
INFO - 2022-07-02 09:56:42 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:56:42 --> Controller Class Initialized
INFO - 2022-07-02 09:56:55 --> Config Class Initialized
INFO - 2022-07-02 09:56:55 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:56:55 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:56:55 --> Utf8 Class Initialized
INFO - 2022-07-02 09:56:55 --> URI Class Initialized
INFO - 2022-07-02 09:56:55 --> Router Class Initialized
INFO - 2022-07-02 09:56:55 --> Output Class Initialized
INFO - 2022-07-02 09:56:55 --> Security Class Initialized
DEBUG - 2022-07-02 09:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:56:55 --> Input Class Initialized
INFO - 2022-07-02 09:56:55 --> Language Class Initialized
INFO - 2022-07-02 09:56:55 --> Language Class Initialized
INFO - 2022-07-02 09:56:55 --> Config Class Initialized
INFO - 2022-07-02 09:56:55 --> Loader Class Initialized
INFO - 2022-07-02 09:56:55 --> Helper loaded: url_helper
INFO - 2022-07-02 09:56:55 --> Helper loaded: file_helper
INFO - 2022-07-02 09:56:55 --> Helper loaded: form_helper
INFO - 2022-07-02 09:56:55 --> Helper loaded: my_helper
INFO - 2022-07-02 09:56:55 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:56:55 --> Controller Class Initialized
INFO - 2022-07-02 09:56:55 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:56:55 --> Config Class Initialized
INFO - 2022-07-02 09:56:55 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:56:55 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:56:55 --> Utf8 Class Initialized
INFO - 2022-07-02 09:56:55 --> URI Class Initialized
INFO - 2022-07-02 09:56:55 --> Router Class Initialized
INFO - 2022-07-02 09:56:55 --> Output Class Initialized
INFO - 2022-07-02 09:56:55 --> Security Class Initialized
DEBUG - 2022-07-02 09:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:56:55 --> Input Class Initialized
INFO - 2022-07-02 09:56:55 --> Language Class Initialized
INFO - 2022-07-02 09:56:55 --> Language Class Initialized
INFO - 2022-07-02 09:56:55 --> Config Class Initialized
INFO - 2022-07-02 09:56:55 --> Loader Class Initialized
INFO - 2022-07-02 09:56:55 --> Helper loaded: url_helper
INFO - 2022-07-02 09:56:55 --> Helper loaded: file_helper
INFO - 2022-07-02 09:56:55 --> Helper loaded: form_helper
INFO - 2022-07-02 09:56:55 --> Helper loaded: my_helper
INFO - 2022-07-02 09:56:55 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:56:55 --> Controller Class Initialized
DEBUG - 2022-07-02 09:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 09:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:56:55 --> Final output sent to browser
DEBUG - 2022-07-02 09:56:55 --> Total execution time: 0.0530
INFO - 2022-07-02 09:57:06 --> Config Class Initialized
INFO - 2022-07-02 09:57:06 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:57:06 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:57:06 --> Utf8 Class Initialized
INFO - 2022-07-02 09:57:06 --> URI Class Initialized
INFO - 2022-07-02 09:57:06 --> Router Class Initialized
INFO - 2022-07-02 09:57:06 --> Output Class Initialized
INFO - 2022-07-02 09:57:06 --> Security Class Initialized
DEBUG - 2022-07-02 09:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:57:06 --> Input Class Initialized
INFO - 2022-07-02 09:57:06 --> Language Class Initialized
INFO - 2022-07-02 09:57:06 --> Language Class Initialized
INFO - 2022-07-02 09:57:06 --> Config Class Initialized
INFO - 2022-07-02 09:57:06 --> Loader Class Initialized
INFO - 2022-07-02 09:57:06 --> Helper loaded: url_helper
INFO - 2022-07-02 09:57:06 --> Helper loaded: file_helper
INFO - 2022-07-02 09:57:06 --> Helper loaded: form_helper
INFO - 2022-07-02 09:57:06 --> Helper loaded: my_helper
INFO - 2022-07-02 09:57:06 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:57:06 --> Controller Class Initialized
INFO - 2022-07-02 09:57:06 --> Helper loaded: cookie_helper
INFO - 2022-07-02 09:57:06 --> Final output sent to browser
DEBUG - 2022-07-02 09:57:06 --> Total execution time: 0.0618
INFO - 2022-07-02 09:57:07 --> Config Class Initialized
INFO - 2022-07-02 09:57:07 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:57:07 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:57:07 --> Utf8 Class Initialized
INFO - 2022-07-02 09:57:07 --> URI Class Initialized
INFO - 2022-07-02 09:57:07 --> Router Class Initialized
INFO - 2022-07-02 09:57:07 --> Output Class Initialized
INFO - 2022-07-02 09:57:07 --> Security Class Initialized
DEBUG - 2022-07-02 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:57:07 --> Input Class Initialized
INFO - 2022-07-02 09:57:07 --> Language Class Initialized
INFO - 2022-07-02 09:57:07 --> Language Class Initialized
INFO - 2022-07-02 09:57:07 --> Config Class Initialized
INFO - 2022-07-02 09:57:07 --> Loader Class Initialized
INFO - 2022-07-02 09:57:07 --> Helper loaded: url_helper
INFO - 2022-07-02 09:57:07 --> Helper loaded: file_helper
INFO - 2022-07-02 09:57:07 --> Helper loaded: form_helper
INFO - 2022-07-02 09:57:07 --> Helper loaded: my_helper
INFO - 2022-07-02 09:57:07 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:57:07 --> Controller Class Initialized
DEBUG - 2022-07-02 09:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 09:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:57:07 --> Final output sent to browser
DEBUG - 2022-07-02 09:57:07 --> Total execution time: 0.5297
INFO - 2022-07-02 09:58:42 --> Config Class Initialized
INFO - 2022-07-02 09:58:42 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:58:42 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:58:42 --> Utf8 Class Initialized
INFO - 2022-07-02 09:58:42 --> URI Class Initialized
INFO - 2022-07-02 09:58:42 --> Router Class Initialized
INFO - 2022-07-02 09:58:42 --> Output Class Initialized
INFO - 2022-07-02 09:58:42 --> Security Class Initialized
DEBUG - 2022-07-02 09:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:58:42 --> Input Class Initialized
INFO - 2022-07-02 09:58:42 --> Language Class Initialized
INFO - 2022-07-02 09:58:42 --> Language Class Initialized
INFO - 2022-07-02 09:58:42 --> Config Class Initialized
INFO - 2022-07-02 09:58:42 --> Loader Class Initialized
INFO - 2022-07-02 09:58:42 --> Helper loaded: url_helper
INFO - 2022-07-02 09:58:42 --> Helper loaded: file_helper
INFO - 2022-07-02 09:58:42 --> Helper loaded: form_helper
INFO - 2022-07-02 09:58:42 --> Helper loaded: my_helper
INFO - 2022-07-02 09:58:42 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:58:42 --> Controller Class Initialized
DEBUG - 2022-07-02 09:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-02 09:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:58:42 --> Final output sent to browser
DEBUG - 2022-07-02 09:58:42 --> Total execution time: 0.0798
INFO - 2022-07-02 09:58:45 --> Config Class Initialized
INFO - 2022-07-02 09:58:45 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:58:45 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:58:45 --> Utf8 Class Initialized
INFO - 2022-07-02 09:58:45 --> URI Class Initialized
INFO - 2022-07-02 09:58:45 --> Router Class Initialized
INFO - 2022-07-02 09:58:45 --> Output Class Initialized
INFO - 2022-07-02 09:58:45 --> Security Class Initialized
DEBUG - 2022-07-02 09:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:58:45 --> Input Class Initialized
INFO - 2022-07-02 09:58:45 --> Language Class Initialized
INFO - 2022-07-02 09:58:45 --> Language Class Initialized
INFO - 2022-07-02 09:58:45 --> Config Class Initialized
INFO - 2022-07-02 09:58:45 --> Loader Class Initialized
INFO - 2022-07-02 09:58:45 --> Helper loaded: url_helper
INFO - 2022-07-02 09:58:45 --> Helper loaded: file_helper
INFO - 2022-07-02 09:58:45 --> Helper loaded: form_helper
INFO - 2022-07-02 09:58:45 --> Helper loaded: my_helper
INFO - 2022-07-02 09:58:45 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:58:45 --> Controller Class Initialized
DEBUG - 2022-07-02 09:58:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2022-07-02 09:58:45 --> Final output sent to browser
DEBUG - 2022-07-02 09:58:45 --> Total execution time: 0.3587
INFO - 2022-07-02 09:59:27 --> Config Class Initialized
INFO - 2022-07-02 09:59:27 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:27 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:27 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:27 --> URI Class Initialized
INFO - 2022-07-02 09:59:27 --> Router Class Initialized
INFO - 2022-07-02 09:59:27 --> Output Class Initialized
INFO - 2022-07-02 09:59:27 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:27 --> Input Class Initialized
INFO - 2022-07-02 09:59:27 --> Language Class Initialized
INFO - 2022-07-02 09:59:27 --> Language Class Initialized
INFO - 2022-07-02 09:59:27 --> Config Class Initialized
INFO - 2022-07-02 09:59:27 --> Loader Class Initialized
INFO - 2022-07-02 09:59:27 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:27 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:27 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:27 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:27 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:27 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-02 09:59:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 09:59:27 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:27 --> Total execution time: 0.0529
INFO - 2022-07-02 09:59:32 --> Config Class Initialized
INFO - 2022-07-02 09:59:32 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:32 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:32 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:32 --> URI Class Initialized
INFO - 2022-07-02 09:59:32 --> Router Class Initialized
INFO - 2022-07-02 09:59:32 --> Output Class Initialized
INFO - 2022-07-02 09:59:32 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:32 --> Input Class Initialized
INFO - 2022-07-02 09:59:32 --> Language Class Initialized
INFO - 2022-07-02 09:59:32 --> Language Class Initialized
INFO - 2022-07-02 09:59:32 --> Config Class Initialized
INFO - 2022-07-02 09:59:32 --> Loader Class Initialized
INFO - 2022-07-02 09:59:32 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:32 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:32 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:32 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:32 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:32 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:32 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:32 --> Total execution time: 0.2557
INFO - 2022-07-02 09:59:33 --> Config Class Initialized
INFO - 2022-07-02 09:59:33 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:33 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:33 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:33 --> URI Class Initialized
INFO - 2022-07-02 09:59:33 --> Router Class Initialized
INFO - 2022-07-02 09:59:33 --> Output Class Initialized
INFO - 2022-07-02 09:59:33 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:33 --> Input Class Initialized
INFO - 2022-07-02 09:59:33 --> Language Class Initialized
INFO - 2022-07-02 09:59:33 --> Language Class Initialized
INFO - 2022-07-02 09:59:33 --> Config Class Initialized
INFO - 2022-07-02 09:59:33 --> Loader Class Initialized
INFO - 2022-07-02 09:59:33 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:33 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:33 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:33 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:33 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:33 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:34 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:34 --> Total execution time: 0.1809
INFO - 2022-07-02 09:59:36 --> Config Class Initialized
INFO - 2022-07-02 09:59:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:36 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:36 --> URI Class Initialized
INFO - 2022-07-02 09:59:36 --> Router Class Initialized
INFO - 2022-07-02 09:59:36 --> Output Class Initialized
INFO - 2022-07-02 09:59:36 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:36 --> Input Class Initialized
INFO - 2022-07-02 09:59:36 --> Language Class Initialized
INFO - 2022-07-02 09:59:36 --> Language Class Initialized
INFO - 2022-07-02 09:59:36 --> Config Class Initialized
INFO - 2022-07-02 09:59:36 --> Loader Class Initialized
INFO - 2022-07-02 09:59:36 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:36 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:36 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:36 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:36 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:36 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:36 --> Total execution time: 0.1572
INFO - 2022-07-02 09:59:37 --> Config Class Initialized
INFO - 2022-07-02 09:59:37 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:37 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:37 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:37 --> URI Class Initialized
INFO - 2022-07-02 09:59:37 --> Router Class Initialized
INFO - 2022-07-02 09:59:37 --> Output Class Initialized
INFO - 2022-07-02 09:59:37 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:37 --> Input Class Initialized
INFO - 2022-07-02 09:59:37 --> Language Class Initialized
INFO - 2022-07-02 09:59:37 --> Language Class Initialized
INFO - 2022-07-02 09:59:37 --> Config Class Initialized
INFO - 2022-07-02 09:59:37 --> Loader Class Initialized
INFO - 2022-07-02 09:59:37 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:37 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:37 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:37 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:37 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:37 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:37 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:37 --> Total execution time: 0.1732
INFO - 2022-07-02 09:59:39 --> Config Class Initialized
INFO - 2022-07-02 09:59:39 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:39 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:39 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:39 --> URI Class Initialized
INFO - 2022-07-02 09:59:39 --> Router Class Initialized
INFO - 2022-07-02 09:59:39 --> Output Class Initialized
INFO - 2022-07-02 09:59:39 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:39 --> Input Class Initialized
INFO - 2022-07-02 09:59:39 --> Language Class Initialized
INFO - 2022-07-02 09:59:39 --> Language Class Initialized
INFO - 2022-07-02 09:59:39 --> Config Class Initialized
INFO - 2022-07-02 09:59:39 --> Loader Class Initialized
INFO - 2022-07-02 09:59:39 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:39 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:39 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:39 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:39 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:39 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:39 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:39 --> Total execution time: 0.1610
INFO - 2022-07-02 09:59:42 --> Config Class Initialized
INFO - 2022-07-02 09:59:42 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:42 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:42 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:42 --> URI Class Initialized
INFO - 2022-07-02 09:59:42 --> Router Class Initialized
INFO - 2022-07-02 09:59:42 --> Output Class Initialized
INFO - 2022-07-02 09:59:42 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:42 --> Input Class Initialized
INFO - 2022-07-02 09:59:42 --> Language Class Initialized
INFO - 2022-07-02 09:59:42 --> Language Class Initialized
INFO - 2022-07-02 09:59:42 --> Config Class Initialized
INFO - 2022-07-02 09:59:42 --> Loader Class Initialized
INFO - 2022-07-02 09:59:42 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:42 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:42 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:42 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:42 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:42 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:42 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:42 --> Total execution time: 0.1575
INFO - 2022-07-02 09:59:44 --> Config Class Initialized
INFO - 2022-07-02 09:59:44 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:44 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:44 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:44 --> URI Class Initialized
INFO - 2022-07-02 09:59:44 --> Router Class Initialized
INFO - 2022-07-02 09:59:44 --> Output Class Initialized
INFO - 2022-07-02 09:59:44 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:44 --> Input Class Initialized
INFO - 2022-07-02 09:59:44 --> Language Class Initialized
INFO - 2022-07-02 09:59:44 --> Language Class Initialized
INFO - 2022-07-02 09:59:44 --> Config Class Initialized
INFO - 2022-07-02 09:59:44 --> Loader Class Initialized
INFO - 2022-07-02 09:59:44 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:44 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:44 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:44 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:44 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:44 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:44 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:44 --> Total execution time: 0.2039
INFO - 2022-07-02 09:59:45 --> Config Class Initialized
INFO - 2022-07-02 09:59:45 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:45 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:45 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:45 --> URI Class Initialized
INFO - 2022-07-02 09:59:45 --> Router Class Initialized
INFO - 2022-07-02 09:59:45 --> Output Class Initialized
INFO - 2022-07-02 09:59:45 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:45 --> Input Class Initialized
INFO - 2022-07-02 09:59:45 --> Language Class Initialized
INFO - 2022-07-02 09:59:45 --> Language Class Initialized
INFO - 2022-07-02 09:59:45 --> Config Class Initialized
INFO - 2022-07-02 09:59:45 --> Loader Class Initialized
INFO - 2022-07-02 09:59:45 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:45 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:45 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:45 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:45 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:45 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:45 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:45 --> Total execution time: 0.1692
INFO - 2022-07-02 09:59:48 --> Config Class Initialized
INFO - 2022-07-02 09:59:48 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:48 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:48 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:48 --> URI Class Initialized
INFO - 2022-07-02 09:59:48 --> Router Class Initialized
INFO - 2022-07-02 09:59:48 --> Output Class Initialized
INFO - 2022-07-02 09:59:48 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:48 --> Input Class Initialized
INFO - 2022-07-02 09:59:48 --> Language Class Initialized
INFO - 2022-07-02 09:59:48 --> Language Class Initialized
INFO - 2022-07-02 09:59:48 --> Config Class Initialized
INFO - 2022-07-02 09:59:48 --> Loader Class Initialized
INFO - 2022-07-02 09:59:48 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:48 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:48 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:48 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:48 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:48 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:48 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:48 --> Total execution time: 0.1574
INFO - 2022-07-02 09:59:49 --> Config Class Initialized
INFO - 2022-07-02 09:59:49 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:49 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:49 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:49 --> URI Class Initialized
INFO - 2022-07-02 09:59:49 --> Router Class Initialized
INFO - 2022-07-02 09:59:49 --> Output Class Initialized
INFO - 2022-07-02 09:59:49 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:49 --> Input Class Initialized
INFO - 2022-07-02 09:59:49 --> Language Class Initialized
INFO - 2022-07-02 09:59:49 --> Language Class Initialized
INFO - 2022-07-02 09:59:49 --> Config Class Initialized
INFO - 2022-07-02 09:59:49 --> Loader Class Initialized
INFO - 2022-07-02 09:59:49 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:49 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:49 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:49 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:49 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:49 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:49 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:49 --> Total execution time: 0.1638
INFO - 2022-07-02 09:59:51 --> Config Class Initialized
INFO - 2022-07-02 09:59:51 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:51 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:51 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:51 --> URI Class Initialized
INFO - 2022-07-02 09:59:51 --> Router Class Initialized
INFO - 2022-07-02 09:59:51 --> Output Class Initialized
INFO - 2022-07-02 09:59:51 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:51 --> Input Class Initialized
INFO - 2022-07-02 09:59:51 --> Language Class Initialized
INFO - 2022-07-02 09:59:51 --> Language Class Initialized
INFO - 2022-07-02 09:59:51 --> Config Class Initialized
INFO - 2022-07-02 09:59:51 --> Loader Class Initialized
INFO - 2022-07-02 09:59:51 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:51 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:51 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:51 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:51 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:51 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:51 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:51 --> Total execution time: 0.1602
INFO - 2022-07-02 09:59:54 --> Config Class Initialized
INFO - 2022-07-02 09:59:54 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:54 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:54 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:54 --> URI Class Initialized
INFO - 2022-07-02 09:59:54 --> Router Class Initialized
INFO - 2022-07-02 09:59:54 --> Output Class Initialized
INFO - 2022-07-02 09:59:54 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:54 --> Input Class Initialized
INFO - 2022-07-02 09:59:54 --> Language Class Initialized
INFO - 2022-07-02 09:59:54 --> Language Class Initialized
INFO - 2022-07-02 09:59:54 --> Config Class Initialized
INFO - 2022-07-02 09:59:54 --> Loader Class Initialized
INFO - 2022-07-02 09:59:54 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:54 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:54 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:54 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:54 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:54 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:54 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:54 --> Total execution time: 0.1570
INFO - 2022-07-02 09:59:55 --> Config Class Initialized
INFO - 2022-07-02 09:59:55 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:55 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:55 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:55 --> URI Class Initialized
INFO - 2022-07-02 09:59:55 --> Router Class Initialized
INFO - 2022-07-02 09:59:55 --> Output Class Initialized
INFO - 2022-07-02 09:59:55 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:55 --> Input Class Initialized
INFO - 2022-07-02 09:59:55 --> Language Class Initialized
INFO - 2022-07-02 09:59:55 --> Language Class Initialized
INFO - 2022-07-02 09:59:55 --> Config Class Initialized
INFO - 2022-07-02 09:59:55 --> Loader Class Initialized
INFO - 2022-07-02 09:59:55 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:55 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:55 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:55 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:55 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:55 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:55 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:55 --> Total execution time: 0.1565
INFO - 2022-07-02 09:59:58 --> Config Class Initialized
INFO - 2022-07-02 09:59:58 --> Hooks Class Initialized
DEBUG - 2022-07-02 09:59:58 --> UTF-8 Support Enabled
INFO - 2022-07-02 09:59:58 --> Utf8 Class Initialized
INFO - 2022-07-02 09:59:58 --> URI Class Initialized
INFO - 2022-07-02 09:59:58 --> Router Class Initialized
INFO - 2022-07-02 09:59:58 --> Output Class Initialized
INFO - 2022-07-02 09:59:58 --> Security Class Initialized
DEBUG - 2022-07-02 09:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 09:59:58 --> Input Class Initialized
INFO - 2022-07-02 09:59:58 --> Language Class Initialized
INFO - 2022-07-02 09:59:58 --> Language Class Initialized
INFO - 2022-07-02 09:59:58 --> Config Class Initialized
INFO - 2022-07-02 09:59:58 --> Loader Class Initialized
INFO - 2022-07-02 09:59:58 --> Helper loaded: url_helper
INFO - 2022-07-02 09:59:58 --> Helper loaded: file_helper
INFO - 2022-07-02 09:59:58 --> Helper loaded: form_helper
INFO - 2022-07-02 09:59:58 --> Helper loaded: my_helper
INFO - 2022-07-02 09:59:58 --> Database Driver Class Initialized
DEBUG - 2022-07-02 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 09:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 09:59:58 --> Controller Class Initialized
DEBUG - 2022-07-02 09:59:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 09:59:59 --> Final output sent to browser
DEBUG - 2022-07-02 09:59:59 --> Total execution time: 0.1577
INFO - 2022-07-02 10:00:00 --> Config Class Initialized
INFO - 2022-07-02 10:00:00 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:00:00 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:00:00 --> Utf8 Class Initialized
INFO - 2022-07-02 10:00:00 --> URI Class Initialized
INFO - 2022-07-02 10:00:00 --> Router Class Initialized
INFO - 2022-07-02 10:00:00 --> Output Class Initialized
INFO - 2022-07-02 10:00:00 --> Security Class Initialized
DEBUG - 2022-07-02 10:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:00:00 --> Input Class Initialized
INFO - 2022-07-02 10:00:00 --> Language Class Initialized
INFO - 2022-07-02 10:00:00 --> Language Class Initialized
INFO - 2022-07-02 10:00:00 --> Config Class Initialized
INFO - 2022-07-02 10:00:00 --> Loader Class Initialized
INFO - 2022-07-02 10:00:00 --> Helper loaded: url_helper
INFO - 2022-07-02 10:00:00 --> Helper loaded: file_helper
INFO - 2022-07-02 10:00:00 --> Helper loaded: form_helper
INFO - 2022-07-02 10:00:00 --> Helper loaded: my_helper
INFO - 2022-07-02 10:00:00 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:00:00 --> Controller Class Initialized
DEBUG - 2022-07-02 10:00:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:00:00 --> Final output sent to browser
DEBUG - 2022-07-02 10:00:00 --> Total execution time: 0.1547
INFO - 2022-07-02 10:00:04 --> Config Class Initialized
INFO - 2022-07-02 10:00:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:00:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:00:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:00:04 --> URI Class Initialized
INFO - 2022-07-02 10:00:04 --> Router Class Initialized
INFO - 2022-07-02 10:00:04 --> Output Class Initialized
INFO - 2022-07-02 10:00:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:00:04 --> Input Class Initialized
INFO - 2022-07-02 10:00:04 --> Language Class Initialized
INFO - 2022-07-02 10:00:04 --> Language Class Initialized
INFO - 2022-07-02 10:00:04 --> Config Class Initialized
INFO - 2022-07-02 10:00:04 --> Loader Class Initialized
INFO - 2022-07-02 10:00:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:00:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:00:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:00:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:00:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:00:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:00:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:00:04 --> Total execution time: 0.1702
INFO - 2022-07-02 10:00:06 --> Config Class Initialized
INFO - 2022-07-02 10:00:06 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:00:06 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:00:06 --> Utf8 Class Initialized
INFO - 2022-07-02 10:00:06 --> URI Class Initialized
INFO - 2022-07-02 10:00:06 --> Router Class Initialized
INFO - 2022-07-02 10:00:06 --> Output Class Initialized
INFO - 2022-07-02 10:00:06 --> Security Class Initialized
DEBUG - 2022-07-02 10:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:00:06 --> Input Class Initialized
INFO - 2022-07-02 10:00:06 --> Language Class Initialized
INFO - 2022-07-02 10:00:06 --> Language Class Initialized
INFO - 2022-07-02 10:00:06 --> Config Class Initialized
INFO - 2022-07-02 10:00:06 --> Loader Class Initialized
INFO - 2022-07-02 10:00:06 --> Helper loaded: url_helper
INFO - 2022-07-02 10:00:06 --> Helper loaded: file_helper
INFO - 2022-07-02 10:00:06 --> Helper loaded: form_helper
INFO - 2022-07-02 10:00:06 --> Helper loaded: my_helper
INFO - 2022-07-02 10:00:06 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:00:06 --> Controller Class Initialized
DEBUG - 2022-07-02 10:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:00:06 --> Final output sent to browser
DEBUG - 2022-07-02 10:00:06 --> Total execution time: 0.1772
INFO - 2022-07-02 10:00:06 --> Config Class Initialized
INFO - 2022-07-02 10:00:06 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:00:06 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:00:06 --> Utf8 Class Initialized
INFO - 2022-07-02 10:00:06 --> URI Class Initialized
INFO - 2022-07-02 10:00:06 --> Router Class Initialized
INFO - 2022-07-02 10:00:06 --> Output Class Initialized
INFO - 2022-07-02 10:00:06 --> Security Class Initialized
DEBUG - 2022-07-02 10:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:00:06 --> Input Class Initialized
INFO - 2022-07-02 10:00:06 --> Language Class Initialized
INFO - 2022-07-02 10:00:06 --> Language Class Initialized
INFO - 2022-07-02 10:00:06 --> Config Class Initialized
INFO - 2022-07-02 10:00:06 --> Loader Class Initialized
INFO - 2022-07-02 10:00:06 --> Helper loaded: url_helper
INFO - 2022-07-02 10:00:06 --> Helper loaded: file_helper
INFO - 2022-07-02 10:00:06 --> Helper loaded: form_helper
INFO - 2022-07-02 10:00:06 --> Helper loaded: my_helper
INFO - 2022-07-02 10:00:06 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:00:06 --> Controller Class Initialized
DEBUG - 2022-07-02 10:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2022-07-02 10:00:06 --> Final output sent to browser
DEBUG - 2022-07-02 10:00:06 --> Total execution time: 0.1722
INFO - 2022-07-02 10:02:23 --> Config Class Initialized
INFO - 2022-07-02 10:02:23 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:02:23 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:02:23 --> Utf8 Class Initialized
INFO - 2022-07-02 10:02:23 --> URI Class Initialized
INFO - 2022-07-02 10:02:23 --> Router Class Initialized
INFO - 2022-07-02 10:02:23 --> Output Class Initialized
INFO - 2022-07-02 10:02:23 --> Security Class Initialized
DEBUG - 2022-07-02 10:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:02:23 --> Input Class Initialized
INFO - 2022-07-02 10:02:23 --> Language Class Initialized
INFO - 2022-07-02 10:02:23 --> Language Class Initialized
INFO - 2022-07-02 10:02:23 --> Config Class Initialized
INFO - 2022-07-02 10:02:23 --> Loader Class Initialized
INFO - 2022-07-02 10:02:23 --> Helper loaded: url_helper
INFO - 2022-07-02 10:02:23 --> Helper loaded: file_helper
INFO - 2022-07-02 10:02:23 --> Helper loaded: form_helper
INFO - 2022-07-02 10:02:23 --> Helper loaded: my_helper
INFO - 2022-07-02 10:02:23 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:02:23 --> Controller Class Initialized
DEBUG - 2022-07-02 10:02:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2022-07-02 10:02:23 --> Final output sent to browser
DEBUG - 2022-07-02 10:02:23 --> Total execution time: 0.2797
INFO - 2022-07-02 10:02:44 --> Config Class Initialized
INFO - 2022-07-02 10:02:44 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:02:44 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:02:44 --> Utf8 Class Initialized
INFO - 2022-07-02 10:02:44 --> URI Class Initialized
INFO - 2022-07-02 10:02:44 --> Router Class Initialized
INFO - 2022-07-02 10:02:44 --> Output Class Initialized
INFO - 2022-07-02 10:02:44 --> Security Class Initialized
DEBUG - 2022-07-02 10:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:02:44 --> Input Class Initialized
INFO - 2022-07-02 10:02:44 --> Language Class Initialized
INFO - 2022-07-02 10:02:44 --> Language Class Initialized
INFO - 2022-07-02 10:02:44 --> Config Class Initialized
INFO - 2022-07-02 10:02:44 --> Loader Class Initialized
INFO - 2022-07-02 10:02:44 --> Helper loaded: url_helper
INFO - 2022-07-02 10:02:44 --> Helper loaded: file_helper
INFO - 2022-07-02 10:02:44 --> Helper loaded: form_helper
INFO - 2022-07-02 10:02:44 --> Helper loaded: my_helper
INFO - 2022-07-02 10:02:44 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:02:44 --> Controller Class Initialized
DEBUG - 2022-07-02 10:02:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:02:44 --> Final output sent to browser
DEBUG - 2022-07-02 10:02:44 --> Total execution time: 0.1636
INFO - 2022-07-02 10:02:46 --> Config Class Initialized
INFO - 2022-07-02 10:02:46 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:02:46 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:02:46 --> Utf8 Class Initialized
INFO - 2022-07-02 10:02:46 --> URI Class Initialized
INFO - 2022-07-02 10:02:46 --> Router Class Initialized
INFO - 2022-07-02 10:02:46 --> Output Class Initialized
INFO - 2022-07-02 10:02:46 --> Security Class Initialized
DEBUG - 2022-07-02 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:02:46 --> Input Class Initialized
INFO - 2022-07-02 10:02:46 --> Language Class Initialized
INFO - 2022-07-02 10:02:46 --> Language Class Initialized
INFO - 2022-07-02 10:02:46 --> Config Class Initialized
INFO - 2022-07-02 10:02:46 --> Loader Class Initialized
INFO - 2022-07-02 10:02:46 --> Helper loaded: url_helper
INFO - 2022-07-02 10:02:46 --> Helper loaded: file_helper
INFO - 2022-07-02 10:02:46 --> Helper loaded: form_helper
INFO - 2022-07-02 10:02:46 --> Helper loaded: my_helper
INFO - 2022-07-02 10:02:46 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:02:46 --> Controller Class Initialized
DEBUG - 2022-07-02 10:02:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2022-07-02 10:02:46 --> Final output sent to browser
DEBUG - 2022-07-02 10:02:46 --> Total execution time: 0.1756
INFO - 2022-07-02 10:03:47 --> Config Class Initialized
INFO - 2022-07-02 10:03:47 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:03:47 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:03:47 --> Utf8 Class Initialized
INFO - 2022-07-02 10:03:47 --> URI Class Initialized
INFO - 2022-07-02 10:03:47 --> Router Class Initialized
INFO - 2022-07-02 10:03:47 --> Output Class Initialized
INFO - 2022-07-02 10:03:47 --> Security Class Initialized
DEBUG - 2022-07-02 10:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:03:47 --> Input Class Initialized
INFO - 2022-07-02 10:03:47 --> Language Class Initialized
INFO - 2022-07-02 10:03:47 --> Language Class Initialized
INFO - 2022-07-02 10:03:47 --> Config Class Initialized
INFO - 2022-07-02 10:03:47 --> Loader Class Initialized
INFO - 2022-07-02 10:03:47 --> Helper loaded: url_helper
INFO - 2022-07-02 10:03:47 --> Helper loaded: file_helper
INFO - 2022-07-02 10:03:47 --> Helper loaded: form_helper
INFO - 2022-07-02 10:03:47 --> Helper loaded: my_helper
INFO - 2022-07-02 10:03:47 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:03:47 --> Controller Class Initialized
DEBUG - 2022-07-02 10:03:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:03:48 --> Final output sent to browser
DEBUG - 2022-07-02 10:03:48 --> Total execution time: 0.1802
INFO - 2022-07-02 10:03:50 --> Config Class Initialized
INFO - 2022-07-02 10:03:50 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:03:50 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:03:50 --> Utf8 Class Initialized
INFO - 2022-07-02 10:03:50 --> URI Class Initialized
INFO - 2022-07-02 10:03:50 --> Router Class Initialized
INFO - 2022-07-02 10:03:50 --> Output Class Initialized
INFO - 2022-07-02 10:03:50 --> Security Class Initialized
DEBUG - 2022-07-02 10:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:03:50 --> Input Class Initialized
INFO - 2022-07-02 10:03:50 --> Language Class Initialized
INFO - 2022-07-02 10:03:50 --> Language Class Initialized
INFO - 2022-07-02 10:03:50 --> Config Class Initialized
INFO - 2022-07-02 10:03:50 --> Loader Class Initialized
INFO - 2022-07-02 10:03:50 --> Helper loaded: url_helper
INFO - 2022-07-02 10:03:50 --> Helper loaded: file_helper
INFO - 2022-07-02 10:03:50 --> Helper loaded: form_helper
INFO - 2022-07-02 10:03:50 --> Helper loaded: my_helper
INFO - 2022-07-02 10:03:50 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:03:50 --> Controller Class Initialized
DEBUG - 2022-07-02 10:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2022-07-02 10:03:50 --> Final output sent to browser
DEBUG - 2022-07-02 10:03:50 --> Total execution time: 0.1805
INFO - 2022-07-02 10:04:02 --> Config Class Initialized
INFO - 2022-07-02 10:04:02 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:04:02 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:04:02 --> Utf8 Class Initialized
INFO - 2022-07-02 10:04:02 --> URI Class Initialized
INFO - 2022-07-02 10:04:02 --> Router Class Initialized
INFO - 2022-07-02 10:04:02 --> Output Class Initialized
INFO - 2022-07-02 10:04:02 --> Security Class Initialized
DEBUG - 2022-07-02 10:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:04:02 --> Input Class Initialized
INFO - 2022-07-02 10:04:02 --> Language Class Initialized
INFO - 2022-07-02 10:04:02 --> Language Class Initialized
INFO - 2022-07-02 10:04:02 --> Config Class Initialized
INFO - 2022-07-02 10:04:02 --> Loader Class Initialized
INFO - 2022-07-02 10:04:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:04:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:04:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:04:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:04:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:04:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:04:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:04:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:04:03 --> Total execution time: 0.3377
INFO - 2022-07-02 10:05:21 --> Config Class Initialized
INFO - 2022-07-02 10:05:21 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:05:21 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:05:21 --> Utf8 Class Initialized
INFO - 2022-07-02 10:05:21 --> URI Class Initialized
INFO - 2022-07-02 10:05:21 --> Router Class Initialized
INFO - 2022-07-02 10:05:21 --> Output Class Initialized
INFO - 2022-07-02 10:05:21 --> Security Class Initialized
DEBUG - 2022-07-02 10:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:05:21 --> Input Class Initialized
INFO - 2022-07-02 10:05:21 --> Language Class Initialized
INFO - 2022-07-02 10:05:21 --> Language Class Initialized
INFO - 2022-07-02 10:05:21 --> Config Class Initialized
INFO - 2022-07-02 10:05:21 --> Loader Class Initialized
INFO - 2022-07-02 10:05:21 --> Helper loaded: url_helper
INFO - 2022-07-02 10:05:21 --> Helper loaded: file_helper
INFO - 2022-07-02 10:05:21 --> Helper loaded: form_helper
INFO - 2022-07-02 10:05:21 --> Helper loaded: my_helper
INFO - 2022-07-02 10:05:21 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:05:21 --> Controller Class Initialized
DEBUG - 2022-07-02 10:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2022-07-02 10:05:22 --> Final output sent to browser
DEBUG - 2022-07-02 10:05:22 --> Total execution time: 0.7928
INFO - 2022-07-02 10:06:38 --> Config Class Initialized
INFO - 2022-07-02 10:06:38 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:06:38 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:06:38 --> Utf8 Class Initialized
INFO - 2022-07-02 10:06:38 --> URI Class Initialized
INFO - 2022-07-02 10:06:38 --> Router Class Initialized
INFO - 2022-07-02 10:06:38 --> Output Class Initialized
INFO - 2022-07-02 10:06:38 --> Security Class Initialized
DEBUG - 2022-07-02 10:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:06:38 --> Input Class Initialized
INFO - 2022-07-02 10:06:38 --> Language Class Initialized
INFO - 2022-07-02 10:06:38 --> Language Class Initialized
INFO - 2022-07-02 10:06:38 --> Config Class Initialized
INFO - 2022-07-02 10:06:38 --> Loader Class Initialized
INFO - 2022-07-02 10:06:38 --> Helper loaded: url_helper
INFO - 2022-07-02 10:06:38 --> Helper loaded: file_helper
INFO - 2022-07-02 10:06:38 --> Helper loaded: form_helper
INFO - 2022-07-02 10:06:38 --> Helper loaded: my_helper
INFO - 2022-07-02 10:06:38 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:06:38 --> Controller Class Initialized
DEBUG - 2022-07-02 10:06:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:06:38 --> Final output sent to browser
DEBUG - 2022-07-02 10:06:38 --> Total execution time: 0.2115
INFO - 2022-07-02 10:06:50 --> Config Class Initialized
INFO - 2022-07-02 10:06:50 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:06:50 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:06:50 --> Utf8 Class Initialized
INFO - 2022-07-02 10:06:50 --> URI Class Initialized
INFO - 2022-07-02 10:06:50 --> Router Class Initialized
INFO - 2022-07-02 10:06:50 --> Output Class Initialized
INFO - 2022-07-02 10:06:50 --> Security Class Initialized
DEBUG - 2022-07-02 10:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:06:50 --> Input Class Initialized
INFO - 2022-07-02 10:06:50 --> Language Class Initialized
INFO - 2022-07-02 10:06:50 --> Language Class Initialized
INFO - 2022-07-02 10:06:50 --> Config Class Initialized
INFO - 2022-07-02 10:06:50 --> Loader Class Initialized
INFO - 2022-07-02 10:06:50 --> Helper loaded: url_helper
INFO - 2022-07-02 10:06:50 --> Helper loaded: file_helper
INFO - 2022-07-02 10:06:50 --> Helper loaded: form_helper
INFO - 2022-07-02 10:06:50 --> Helper loaded: my_helper
INFO - 2022-07-02 10:06:50 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:06:50 --> Controller Class Initialized
DEBUG - 2022-07-02 10:06:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:06:50 --> Final output sent to browser
DEBUG - 2022-07-02 10:06:50 --> Total execution time: 0.1580
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:03 --> URI Class Initialized
INFO - 2022-07-02 10:07:03 --> Router Class Initialized
INFO - 2022-07-02 10:07:03 --> Output Class Initialized
INFO - 2022-07-02 10:07:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:03 --> Input Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Loader Class Initialized
INFO - 2022-07-02 10:07:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:03 --> Total execution time: 0.1871
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:03 --> URI Class Initialized
INFO - 2022-07-02 10:07:03 --> Router Class Initialized
INFO - 2022-07-02 10:07:03 --> Output Class Initialized
INFO - 2022-07-02 10:07:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:03 --> Input Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Loader Class Initialized
INFO - 2022-07-02 10:07:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:03 --> Total execution time: 0.1023
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:03 --> URI Class Initialized
INFO - 2022-07-02 10:07:03 --> Router Class Initialized
INFO - 2022-07-02 10:07:03 --> Output Class Initialized
INFO - 2022-07-02 10:07:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:03 --> Input Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Loader Class Initialized
INFO - 2022-07-02 10:07:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:03 --> Total execution time: 0.1704
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:03 --> URI Class Initialized
INFO - 2022-07-02 10:07:03 --> Router Class Initialized
INFO - 2022-07-02 10:07:03 --> Output Class Initialized
INFO - 2022-07-02 10:07:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:03 --> Input Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Loader Class Initialized
INFO - 2022-07-02 10:07:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:03 --> Total execution time: 0.1041
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:03 --> URI Class Initialized
INFO - 2022-07-02 10:07:03 --> Router Class Initialized
INFO - 2022-07-02 10:07:03 --> Output Class Initialized
INFO - 2022-07-02 10:07:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:03 --> Input Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Loader Class Initialized
INFO - 2022-07-02 10:07:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:03 --> Total execution time: 0.1000
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:03 --> URI Class Initialized
INFO - 2022-07-02 10:07:03 --> Router Class Initialized
INFO - 2022-07-02 10:07:03 --> Output Class Initialized
INFO - 2022-07-02 10:07:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:03 --> Input Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Loader Class Initialized
INFO - 2022-07-02 10:07:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:03 --> Total execution time: 0.0988
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:03 --> URI Class Initialized
INFO - 2022-07-02 10:07:03 --> Router Class Initialized
INFO - 2022-07-02 10:07:03 --> Output Class Initialized
INFO - 2022-07-02 10:07:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:03 --> Input Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Loader Class Initialized
INFO - 2022-07-02 10:07:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:03 --> Total execution time: 0.0988
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:03 --> URI Class Initialized
INFO - 2022-07-02 10:07:03 --> Router Class Initialized
INFO - 2022-07-02 10:07:03 --> Output Class Initialized
INFO - 2022-07-02 10:07:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:03 --> Input Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Language Class Initialized
INFO - 2022-07-02 10:07:03 --> Config Class Initialized
INFO - 2022-07-02 10:07:03 --> Loader Class Initialized
INFO - 2022-07-02 10:07:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.0982
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.0981
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.0974
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.0970
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.1404
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.1285
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.1013
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.1022
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:04 --> Total execution time: 0.1045
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:04 --> URI Class Initialized
INFO - 2022-07-02 10:07:04 --> Router Class Initialized
INFO - 2022-07-02 10:07:04 --> Output Class Initialized
INFO - 2022-07-02 10:07:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:04 --> Input Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Language Class Initialized
INFO - 2022-07-02 10:07:04 --> Config Class Initialized
INFO - 2022-07-02 10:07:04 --> Loader Class Initialized
INFO - 2022-07-02 10:07:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:05 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:07:05 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:05 --> Total execution time: 0.1108
INFO - 2022-07-02 10:07:37 --> Config Class Initialized
INFO - 2022-07-02 10:07:37 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:37 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:37 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:37 --> URI Class Initialized
INFO - 2022-07-02 10:07:37 --> Router Class Initialized
INFO - 2022-07-02 10:07:37 --> Output Class Initialized
INFO - 2022-07-02 10:07:37 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:37 --> Input Class Initialized
INFO - 2022-07-02 10:07:37 --> Language Class Initialized
INFO - 2022-07-02 10:07:37 --> Language Class Initialized
INFO - 2022-07-02 10:07:37 --> Config Class Initialized
INFO - 2022-07-02 10:07:37 --> Loader Class Initialized
INFO - 2022-07-02 10:07:37 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:37 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:37 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:37 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:37 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:37 --> Controller Class Initialized
INFO - 2022-07-02 10:07:37 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:07:37 --> Config Class Initialized
INFO - 2022-07-02 10:07:37 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:37 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:37 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:37 --> URI Class Initialized
INFO - 2022-07-02 10:07:37 --> Router Class Initialized
INFO - 2022-07-02 10:07:37 --> Output Class Initialized
INFO - 2022-07-02 10:07:37 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:37 --> Input Class Initialized
INFO - 2022-07-02 10:07:37 --> Language Class Initialized
INFO - 2022-07-02 10:07:37 --> Language Class Initialized
INFO - 2022-07-02 10:07:37 --> Config Class Initialized
INFO - 2022-07-02 10:07:37 --> Loader Class Initialized
INFO - 2022-07-02 10:07:37 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:37 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:37 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:37 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:37 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:37 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 10:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:07:37 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:37 --> Total execution time: 0.0784
INFO - 2022-07-02 10:07:45 --> Config Class Initialized
INFO - 2022-07-02 10:07:45 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:45 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:45 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:45 --> URI Class Initialized
INFO - 2022-07-02 10:07:45 --> Router Class Initialized
INFO - 2022-07-02 10:07:45 --> Output Class Initialized
INFO - 2022-07-02 10:07:45 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:45 --> Input Class Initialized
INFO - 2022-07-02 10:07:45 --> Language Class Initialized
INFO - 2022-07-02 10:07:45 --> Language Class Initialized
INFO - 2022-07-02 10:07:45 --> Config Class Initialized
INFO - 2022-07-02 10:07:45 --> Loader Class Initialized
INFO - 2022-07-02 10:07:45 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:45 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:45 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:45 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:45 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:45 --> Controller Class Initialized
INFO - 2022-07-02 10:07:45 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:07:45 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:45 --> Total execution time: 0.0653
INFO - 2022-07-02 10:07:45 --> Config Class Initialized
INFO - 2022-07-02 10:07:45 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:07:45 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:07:45 --> Utf8 Class Initialized
INFO - 2022-07-02 10:07:45 --> URI Class Initialized
INFO - 2022-07-02 10:07:45 --> Router Class Initialized
INFO - 2022-07-02 10:07:45 --> Output Class Initialized
INFO - 2022-07-02 10:07:45 --> Security Class Initialized
DEBUG - 2022-07-02 10:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:07:45 --> Input Class Initialized
INFO - 2022-07-02 10:07:45 --> Language Class Initialized
INFO - 2022-07-02 10:07:45 --> Language Class Initialized
INFO - 2022-07-02 10:07:45 --> Config Class Initialized
INFO - 2022-07-02 10:07:45 --> Loader Class Initialized
INFO - 2022-07-02 10:07:45 --> Helper loaded: url_helper
INFO - 2022-07-02 10:07:45 --> Helper loaded: file_helper
INFO - 2022-07-02 10:07:45 --> Helper loaded: form_helper
INFO - 2022-07-02 10:07:45 --> Helper loaded: my_helper
INFO - 2022-07-02 10:07:45 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:07:45 --> Controller Class Initialized
DEBUG - 2022-07-02 10:07:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:07:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:07:46 --> Final output sent to browser
DEBUG - 2022-07-02 10:07:46 --> Total execution time: 0.6349
INFO - 2022-07-02 10:08:01 --> Config Class Initialized
INFO - 2022-07-02 10:08:01 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:01 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:01 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:01 --> URI Class Initialized
INFO - 2022-07-02 10:08:01 --> Router Class Initialized
INFO - 2022-07-02 10:08:01 --> Output Class Initialized
INFO - 2022-07-02 10:08:01 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:01 --> Input Class Initialized
INFO - 2022-07-02 10:08:01 --> Language Class Initialized
INFO - 2022-07-02 10:08:01 --> Language Class Initialized
INFO - 2022-07-02 10:08:01 --> Config Class Initialized
INFO - 2022-07-02 10:08:01 --> Loader Class Initialized
INFO - 2022-07-02 10:08:01 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:01 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:01 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:01 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:01 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:01 --> Controller Class Initialized
DEBUG - 2022-07-02 10:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-02 10:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:08:01 --> Final output sent to browser
DEBUG - 2022-07-02 10:08:01 --> Total execution time: 0.0672
INFO - 2022-07-02 10:08:01 --> Config Class Initialized
INFO - 2022-07-02 10:08:01 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:01 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:01 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:01 --> URI Class Initialized
INFO - 2022-07-02 10:08:01 --> Router Class Initialized
INFO - 2022-07-02 10:08:01 --> Output Class Initialized
INFO - 2022-07-02 10:08:01 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:01 --> Input Class Initialized
INFO - 2022-07-02 10:08:01 --> Language Class Initialized
INFO - 2022-07-02 10:08:01 --> Language Class Initialized
INFO - 2022-07-02 10:08:01 --> Config Class Initialized
INFO - 2022-07-02 10:08:01 --> Loader Class Initialized
INFO - 2022-07-02 10:08:01 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:01 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:01 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:01 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:01 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:01 --> Controller Class Initialized
INFO - 2022-07-02 10:08:02 --> Config Class Initialized
INFO - 2022-07-02 10:08:02 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:02 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:02 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:02 --> URI Class Initialized
INFO - 2022-07-02 10:08:02 --> Router Class Initialized
INFO - 2022-07-02 10:08:02 --> Output Class Initialized
INFO - 2022-07-02 10:08:02 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:02 --> Input Class Initialized
INFO - 2022-07-02 10:08:02 --> Language Class Initialized
INFO - 2022-07-02 10:08:02 --> Language Class Initialized
INFO - 2022-07-02 10:08:02 --> Config Class Initialized
INFO - 2022-07-02 10:08:02 --> Loader Class Initialized
INFO - 2022-07-02 10:08:02 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:02 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:02 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:02 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:02 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:02 --> Controller Class Initialized
INFO - 2022-07-02 10:08:03 --> Config Class Initialized
INFO - 2022-07-02 10:08:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:03 --> URI Class Initialized
INFO - 2022-07-02 10:08:03 --> Router Class Initialized
INFO - 2022-07-02 10:08:03 --> Output Class Initialized
INFO - 2022-07-02 10:08:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:03 --> Input Class Initialized
INFO - 2022-07-02 10:08:03 --> Language Class Initialized
INFO - 2022-07-02 10:08:03 --> Language Class Initialized
INFO - 2022-07-02 10:08:03 --> Config Class Initialized
INFO - 2022-07-02 10:08:03 --> Loader Class Initialized
INFO - 2022-07-02 10:08:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:03 --> Controller Class Initialized
INFO - 2022-07-02 10:08:03 --> Config Class Initialized
INFO - 2022-07-02 10:08:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:03 --> URI Class Initialized
INFO - 2022-07-02 10:08:03 --> Router Class Initialized
INFO - 2022-07-02 10:08:03 --> Output Class Initialized
INFO - 2022-07-02 10:08:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:03 --> Input Class Initialized
INFO - 2022-07-02 10:08:03 --> Language Class Initialized
INFO - 2022-07-02 10:08:03 --> Language Class Initialized
INFO - 2022-07-02 10:08:03 --> Config Class Initialized
INFO - 2022-07-02 10:08:03 --> Loader Class Initialized
INFO - 2022-07-02 10:08:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:03 --> Controller Class Initialized
INFO - 2022-07-02 10:08:04 --> Config Class Initialized
INFO - 2022-07-02 10:08:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:04 --> URI Class Initialized
INFO - 2022-07-02 10:08:04 --> Router Class Initialized
INFO - 2022-07-02 10:08:04 --> Output Class Initialized
INFO - 2022-07-02 10:08:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:04 --> Input Class Initialized
INFO - 2022-07-02 10:08:04 --> Language Class Initialized
INFO - 2022-07-02 10:08:04 --> Language Class Initialized
INFO - 2022-07-02 10:08:04 --> Config Class Initialized
INFO - 2022-07-02 10:08:04 --> Loader Class Initialized
INFO - 2022-07-02 10:08:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:04 --> Controller Class Initialized
ERROR - 2022-07-02 10:08:04 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-02 10:08:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-02 10:08:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:08:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:08:04 --> Total execution time: 0.1226
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:14 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:14 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:14 --> URI Class Initialized
INFO - 2022-07-02 10:08:14 --> Router Class Initialized
INFO - 2022-07-02 10:08:14 --> Output Class Initialized
INFO - 2022-07-02 10:08:14 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:14 --> Input Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Loader Class Initialized
INFO - 2022-07-02 10:08:14 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:14 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:14 --> Controller Class Initialized
INFO - 2022-07-02 10:08:14 --> Upload Class Initialized
INFO - 2022-07-02 10:08:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-02 10:08:14 --> The upload path does not appear to be valid.
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:14 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:14 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:14 --> URI Class Initialized
INFO - 2022-07-02 10:08:14 --> Router Class Initialized
INFO - 2022-07-02 10:08:14 --> Output Class Initialized
INFO - 2022-07-02 10:08:14 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:14 --> Input Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Loader Class Initialized
INFO - 2022-07-02 10:08:14 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:14 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:14 --> Controller Class Initialized
DEBUG - 2022-07-02 10:08:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-02 10:08:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:08:14 --> Final output sent to browser
DEBUG - 2022-07-02 10:08:14 --> Total execution time: 0.0557
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:14 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:14 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:14 --> URI Class Initialized
INFO - 2022-07-02 10:08:14 --> Router Class Initialized
INFO - 2022-07-02 10:08:14 --> Output Class Initialized
INFO - 2022-07-02 10:08:14 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:14 --> Input Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Loader Class Initialized
INFO - 2022-07-02 10:08:14 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:14 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:14 --> Controller Class Initialized
INFO - 2022-07-02 10:08:14 --> Upload Class Initialized
INFO - 2022-07-02 10:08:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-02 10:08:14 --> The upload path does not appear to be valid.
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:14 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:14 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:14 --> URI Class Initialized
INFO - 2022-07-02 10:08:14 --> Router Class Initialized
INFO - 2022-07-02 10:08:14 --> Output Class Initialized
INFO - 2022-07-02 10:08:14 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:14 --> Input Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Loader Class Initialized
INFO - 2022-07-02 10:08:14 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:14 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:14 --> Controller Class Initialized
DEBUG - 2022-07-02 10:08:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-02 10:08:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:08:14 --> Final output sent to browser
DEBUG - 2022-07-02 10:08:14 --> Total execution time: 0.0416
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:14 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:14 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:14 --> URI Class Initialized
INFO - 2022-07-02 10:08:14 --> Router Class Initialized
INFO - 2022-07-02 10:08:14 --> Output Class Initialized
INFO - 2022-07-02 10:08:14 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:14 --> Input Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Language Class Initialized
INFO - 2022-07-02 10:08:14 --> Config Class Initialized
INFO - 2022-07-02 10:08:14 --> Loader Class Initialized
INFO - 2022-07-02 10:08:14 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:14 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:14 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:14 --> Controller Class Initialized
INFO - 2022-07-02 10:08:17 --> Config Class Initialized
INFO - 2022-07-02 10:08:17 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:08:17 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:08:17 --> Utf8 Class Initialized
INFO - 2022-07-02 10:08:17 --> URI Class Initialized
INFO - 2022-07-02 10:08:17 --> Router Class Initialized
INFO - 2022-07-02 10:08:17 --> Output Class Initialized
INFO - 2022-07-02 10:08:17 --> Security Class Initialized
DEBUG - 2022-07-02 10:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:08:17 --> Input Class Initialized
INFO - 2022-07-02 10:08:17 --> Language Class Initialized
INFO - 2022-07-02 10:08:17 --> Language Class Initialized
INFO - 2022-07-02 10:08:17 --> Config Class Initialized
INFO - 2022-07-02 10:08:17 --> Loader Class Initialized
INFO - 2022-07-02 10:08:17 --> Helper loaded: url_helper
INFO - 2022-07-02 10:08:17 --> Helper loaded: file_helper
INFO - 2022-07-02 10:08:17 --> Helper loaded: form_helper
INFO - 2022-07-02 10:08:17 --> Helper loaded: my_helper
INFO - 2022-07-02 10:08:17 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:08:17 --> Controller Class Initialized
DEBUG - 2022-07-02 10:08:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:08:17 --> Final output sent to browser
DEBUG - 2022-07-02 10:08:17 --> Total execution time: 0.2726
INFO - 2022-07-02 10:09:34 --> Config Class Initialized
INFO - 2022-07-02 10:09:34 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:34 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:34 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:34 --> URI Class Initialized
INFO - 2022-07-02 10:09:35 --> Router Class Initialized
INFO - 2022-07-02 10:09:35 --> Output Class Initialized
INFO - 2022-07-02 10:09:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:35 --> Input Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Loader Class Initialized
INFO - 2022-07-02 10:09:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:35 --> Total execution time: 0.1904
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:35 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:35 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:35 --> URI Class Initialized
INFO - 2022-07-02 10:09:35 --> Router Class Initialized
INFO - 2022-07-02 10:09:35 --> Output Class Initialized
INFO - 2022-07-02 10:09:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:35 --> Input Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Loader Class Initialized
INFO - 2022-07-02 10:09:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:35 --> Total execution time: 0.1043
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:35 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:35 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:35 --> URI Class Initialized
INFO - 2022-07-02 10:09:35 --> Router Class Initialized
INFO - 2022-07-02 10:09:35 --> Output Class Initialized
INFO - 2022-07-02 10:09:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:35 --> Input Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Loader Class Initialized
INFO - 2022-07-02 10:09:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:35 --> Total execution time: 0.0995
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:35 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:35 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:35 --> URI Class Initialized
INFO - 2022-07-02 10:09:35 --> Router Class Initialized
INFO - 2022-07-02 10:09:35 --> Output Class Initialized
INFO - 2022-07-02 10:09:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:35 --> Input Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Loader Class Initialized
INFO - 2022-07-02 10:09:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:35 --> Total execution time: 0.0990
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:35 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:35 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:35 --> URI Class Initialized
INFO - 2022-07-02 10:09:35 --> Router Class Initialized
INFO - 2022-07-02 10:09:35 --> Output Class Initialized
INFO - 2022-07-02 10:09:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:35 --> Input Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Loader Class Initialized
INFO - 2022-07-02 10:09:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:35 --> Total execution time: 0.1601
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:35 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:35 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:35 --> URI Class Initialized
INFO - 2022-07-02 10:09:35 --> Router Class Initialized
INFO - 2022-07-02 10:09:35 --> Output Class Initialized
INFO - 2022-07-02 10:09:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:35 --> Input Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Loader Class Initialized
INFO - 2022-07-02 10:09:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:35 --> Total execution time: 0.1002
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:35 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:35 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:35 --> URI Class Initialized
INFO - 2022-07-02 10:09:35 --> Router Class Initialized
INFO - 2022-07-02 10:09:35 --> Output Class Initialized
INFO - 2022-07-02 10:09:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:35 --> Input Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Loader Class Initialized
INFO - 2022-07-02 10:09:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:35 --> Total execution time: 0.0986
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:35 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:35 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:35 --> URI Class Initialized
INFO - 2022-07-02 10:09:35 --> Router Class Initialized
INFO - 2022-07-02 10:09:35 --> Output Class Initialized
INFO - 2022-07-02 10:09:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:35 --> Input Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Language Class Initialized
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Loader Class Initialized
INFO - 2022-07-02 10:09:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:35 --> Total execution time: 0.0984
INFO - 2022-07-02 10:09:35 --> Config Class Initialized
INFO - 2022-07-02 10:09:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:36 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:36 --> Total execution time: 0.0984
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:36 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:36 --> Total execution time: 0.0979
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:36 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:36 --> Total execution time: 0.0978
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:36 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:36 --> Total execution time: 0.0977
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:36 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:36 --> Total execution time: 0.1035
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:36 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:36 --> Total execution time: 0.1654
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:36 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:36 --> Total execution time: 0.1039
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:36 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:36 --> Total execution time: 0.1063
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:09:36 --> Utf8 Class Initialized
INFO - 2022-07-02 10:09:36 --> URI Class Initialized
INFO - 2022-07-02 10:09:36 --> Router Class Initialized
INFO - 2022-07-02 10:09:36 --> Output Class Initialized
INFO - 2022-07-02 10:09:36 --> Security Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:09:36 --> Input Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Language Class Initialized
INFO - 2022-07-02 10:09:36 --> Config Class Initialized
INFO - 2022-07-02 10:09:36 --> Loader Class Initialized
INFO - 2022-07-02 10:09:36 --> Helper loaded: url_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: file_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: form_helper
INFO - 2022-07-02 10:09:36 --> Helper loaded: my_helper
INFO - 2022-07-02 10:09:36 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:09:36 --> Controller Class Initialized
DEBUG - 2022-07-02 10:09:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-02 10:09:37 --> Final output sent to browser
DEBUG - 2022-07-02 10:09:37 --> Total execution time: 0.1036
INFO - 2022-07-02 10:12:51 --> Config Class Initialized
INFO - 2022-07-02 10:12:51 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:12:51 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:12:51 --> Utf8 Class Initialized
INFO - 2022-07-02 10:12:51 --> URI Class Initialized
INFO - 2022-07-02 10:12:51 --> Router Class Initialized
INFO - 2022-07-02 10:12:51 --> Output Class Initialized
INFO - 2022-07-02 10:12:51 --> Security Class Initialized
DEBUG - 2022-07-02 10:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:12:51 --> Input Class Initialized
INFO - 2022-07-02 10:12:51 --> Language Class Initialized
INFO - 2022-07-02 10:12:51 --> Language Class Initialized
INFO - 2022-07-02 10:12:51 --> Config Class Initialized
INFO - 2022-07-02 10:12:51 --> Loader Class Initialized
INFO - 2022-07-02 10:12:51 --> Helper loaded: url_helper
INFO - 2022-07-02 10:12:51 --> Helper loaded: file_helper
INFO - 2022-07-02 10:12:51 --> Helper loaded: form_helper
INFO - 2022-07-02 10:12:51 --> Helper loaded: my_helper
INFO - 2022-07-02 10:12:51 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:12:51 --> Controller Class Initialized
INFO - 2022-07-02 10:12:51 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:12:51 --> Config Class Initialized
INFO - 2022-07-02 10:12:51 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:12:51 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:12:51 --> Utf8 Class Initialized
INFO - 2022-07-02 10:12:51 --> URI Class Initialized
INFO - 2022-07-02 10:12:51 --> Router Class Initialized
INFO - 2022-07-02 10:12:51 --> Output Class Initialized
INFO - 2022-07-02 10:12:51 --> Security Class Initialized
DEBUG - 2022-07-02 10:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:12:51 --> Input Class Initialized
INFO - 2022-07-02 10:12:51 --> Language Class Initialized
INFO - 2022-07-02 10:12:51 --> Language Class Initialized
INFO - 2022-07-02 10:12:51 --> Config Class Initialized
INFO - 2022-07-02 10:12:51 --> Loader Class Initialized
INFO - 2022-07-02 10:12:51 --> Helper loaded: url_helper
INFO - 2022-07-02 10:12:51 --> Helper loaded: file_helper
INFO - 2022-07-02 10:12:51 --> Helper loaded: form_helper
INFO - 2022-07-02 10:12:51 --> Helper loaded: my_helper
INFO - 2022-07-02 10:12:51 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:12:51 --> Controller Class Initialized
DEBUG - 2022-07-02 10:12:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 10:12:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:12:51 --> Final output sent to browser
DEBUG - 2022-07-02 10:12:51 --> Total execution time: 0.0543
INFO - 2022-07-02 10:12:56 --> Config Class Initialized
INFO - 2022-07-02 10:12:56 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:12:56 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:12:56 --> Utf8 Class Initialized
INFO - 2022-07-02 10:12:56 --> URI Class Initialized
INFO - 2022-07-02 10:12:56 --> Router Class Initialized
INFO - 2022-07-02 10:12:56 --> Output Class Initialized
INFO - 2022-07-02 10:12:56 --> Security Class Initialized
DEBUG - 2022-07-02 10:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:12:56 --> Input Class Initialized
INFO - 2022-07-02 10:12:56 --> Language Class Initialized
INFO - 2022-07-02 10:12:56 --> Language Class Initialized
INFO - 2022-07-02 10:12:56 --> Config Class Initialized
INFO - 2022-07-02 10:12:56 --> Loader Class Initialized
INFO - 2022-07-02 10:12:56 --> Helper loaded: url_helper
INFO - 2022-07-02 10:12:56 --> Helper loaded: file_helper
INFO - 2022-07-02 10:12:56 --> Helper loaded: form_helper
INFO - 2022-07-02 10:12:56 --> Helper loaded: my_helper
INFO - 2022-07-02 10:12:56 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:12:56 --> Controller Class Initialized
INFO - 2022-07-02 10:12:56 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:12:56 --> Final output sent to browser
DEBUG - 2022-07-02 10:12:56 --> Total execution time: 0.0584
INFO - 2022-07-02 10:12:56 --> Config Class Initialized
INFO - 2022-07-02 10:12:56 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:12:56 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:12:56 --> Utf8 Class Initialized
INFO - 2022-07-02 10:12:56 --> URI Class Initialized
INFO - 2022-07-02 10:12:56 --> Router Class Initialized
INFO - 2022-07-02 10:12:56 --> Output Class Initialized
INFO - 2022-07-02 10:12:56 --> Security Class Initialized
DEBUG - 2022-07-02 10:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:12:56 --> Input Class Initialized
INFO - 2022-07-02 10:12:56 --> Language Class Initialized
INFO - 2022-07-02 10:12:56 --> Language Class Initialized
INFO - 2022-07-02 10:12:56 --> Config Class Initialized
INFO - 2022-07-02 10:12:56 --> Loader Class Initialized
INFO - 2022-07-02 10:12:56 --> Helper loaded: url_helper
INFO - 2022-07-02 10:12:56 --> Helper loaded: file_helper
INFO - 2022-07-02 10:12:56 --> Helper loaded: form_helper
INFO - 2022-07-02 10:12:56 --> Helper loaded: my_helper
INFO - 2022-07-02 10:12:56 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:12:56 --> Controller Class Initialized
DEBUG - 2022-07-02 10:12:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:12:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:12:56 --> Final output sent to browser
DEBUG - 2022-07-02 10:12:56 --> Total execution time: 0.5813
INFO - 2022-07-02 10:12:58 --> Config Class Initialized
INFO - 2022-07-02 10:12:58 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:12:58 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:12:58 --> Utf8 Class Initialized
INFO - 2022-07-02 10:12:58 --> URI Class Initialized
INFO - 2022-07-02 10:12:58 --> Router Class Initialized
INFO - 2022-07-02 10:12:58 --> Output Class Initialized
INFO - 2022-07-02 10:12:58 --> Security Class Initialized
DEBUG - 2022-07-02 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:12:58 --> Input Class Initialized
INFO - 2022-07-02 10:12:58 --> Language Class Initialized
INFO - 2022-07-02 10:12:58 --> Language Class Initialized
INFO - 2022-07-02 10:12:58 --> Config Class Initialized
INFO - 2022-07-02 10:12:58 --> Loader Class Initialized
INFO - 2022-07-02 10:12:58 --> Helper loaded: url_helper
INFO - 2022-07-02 10:12:58 --> Helper loaded: file_helper
INFO - 2022-07-02 10:12:58 --> Helper loaded: form_helper
INFO - 2022-07-02 10:12:58 --> Helper loaded: my_helper
INFO - 2022-07-02 10:12:58 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:12:58 --> Controller Class Initialized
DEBUG - 2022-07-02 10:12:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-02 10:12:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:12:58 --> Final output sent to browser
DEBUG - 2022-07-02 10:12:58 --> Total execution time: 0.0704
INFO - 2022-07-02 10:13:00 --> Config Class Initialized
INFO - 2022-07-02 10:13:00 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:00 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:00 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:00 --> URI Class Initialized
INFO - 2022-07-02 10:13:00 --> Router Class Initialized
INFO - 2022-07-02 10:13:00 --> Output Class Initialized
INFO - 2022-07-02 10:13:00 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:00 --> Input Class Initialized
INFO - 2022-07-02 10:13:00 --> Language Class Initialized
INFO - 2022-07-02 10:13:00 --> Language Class Initialized
INFO - 2022-07-02 10:13:00 --> Config Class Initialized
INFO - 2022-07-02 10:13:00 --> Loader Class Initialized
INFO - 2022-07-02 10:13:00 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:00 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:00 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:00 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:00 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:00 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2022-07-02 10:13:00 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:00 --> Total execution time: 0.3572
INFO - 2022-07-02 10:13:18 --> Config Class Initialized
INFO - 2022-07-02 10:13:18 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:18 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:18 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:18 --> URI Class Initialized
INFO - 2022-07-02 10:13:18 --> Router Class Initialized
INFO - 2022-07-02 10:13:18 --> Output Class Initialized
INFO - 2022-07-02 10:13:18 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:18 --> Input Class Initialized
INFO - 2022-07-02 10:13:18 --> Language Class Initialized
INFO - 2022-07-02 10:13:18 --> Language Class Initialized
INFO - 2022-07-02 10:13:18 --> Config Class Initialized
INFO - 2022-07-02 10:13:18 --> Loader Class Initialized
INFO - 2022-07-02 10:13:18 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:18 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:18 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:18 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:18 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:18 --> Controller Class Initialized
INFO - 2022-07-02 10:13:18 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:13:18 --> Config Class Initialized
INFO - 2022-07-02 10:13:18 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:18 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:18 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:18 --> URI Class Initialized
INFO - 2022-07-02 10:13:18 --> Router Class Initialized
INFO - 2022-07-02 10:13:18 --> Output Class Initialized
INFO - 2022-07-02 10:13:18 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:18 --> Input Class Initialized
INFO - 2022-07-02 10:13:18 --> Language Class Initialized
INFO - 2022-07-02 10:13:18 --> Language Class Initialized
INFO - 2022-07-02 10:13:18 --> Config Class Initialized
INFO - 2022-07-02 10:13:18 --> Loader Class Initialized
INFO - 2022-07-02 10:13:18 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:18 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:18 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:18 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:18 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:18 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 10:13:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:13:18 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:18 --> Total execution time: 0.0609
INFO - 2022-07-02 10:13:23 --> Config Class Initialized
INFO - 2022-07-02 10:13:23 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:23 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:23 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:23 --> URI Class Initialized
INFO - 2022-07-02 10:13:23 --> Router Class Initialized
INFO - 2022-07-02 10:13:23 --> Output Class Initialized
INFO - 2022-07-02 10:13:23 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:23 --> Input Class Initialized
INFO - 2022-07-02 10:13:23 --> Language Class Initialized
INFO - 2022-07-02 10:13:23 --> Language Class Initialized
INFO - 2022-07-02 10:13:23 --> Config Class Initialized
INFO - 2022-07-02 10:13:23 --> Loader Class Initialized
INFO - 2022-07-02 10:13:23 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:23 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:23 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:23 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:23 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:23 --> Controller Class Initialized
INFO - 2022-07-02 10:13:23 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:13:23 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:23 --> Total execution time: 0.0562
INFO - 2022-07-02 10:13:23 --> Config Class Initialized
INFO - 2022-07-02 10:13:23 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:23 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:23 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:23 --> URI Class Initialized
INFO - 2022-07-02 10:13:23 --> Router Class Initialized
INFO - 2022-07-02 10:13:23 --> Output Class Initialized
INFO - 2022-07-02 10:13:23 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:23 --> Input Class Initialized
INFO - 2022-07-02 10:13:23 --> Language Class Initialized
INFO - 2022-07-02 10:13:23 --> Language Class Initialized
INFO - 2022-07-02 10:13:23 --> Config Class Initialized
INFO - 2022-07-02 10:13:23 --> Loader Class Initialized
INFO - 2022-07-02 10:13:23 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:23 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:23 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:23 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:23 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:23 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:13:24 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:24 --> Total execution time: 0.5649
INFO - 2022-07-02 10:13:26 --> Config Class Initialized
INFO - 2022-07-02 10:13:26 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:26 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:26 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:26 --> URI Class Initialized
INFO - 2022-07-02 10:13:26 --> Router Class Initialized
INFO - 2022-07-02 10:13:26 --> Output Class Initialized
INFO - 2022-07-02 10:13:26 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:26 --> Input Class Initialized
INFO - 2022-07-02 10:13:26 --> Language Class Initialized
INFO - 2022-07-02 10:13:26 --> Language Class Initialized
INFO - 2022-07-02 10:13:26 --> Config Class Initialized
INFO - 2022-07-02 10:13:26 --> Loader Class Initialized
INFO - 2022-07-02 10:13:26 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:26 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:26 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:26 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:26 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:26 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-02 10:13:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:13:26 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:26 --> Total execution time: 0.0728
INFO - 2022-07-02 10:13:28 --> Config Class Initialized
INFO - 2022-07-02 10:13:28 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:28 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:28 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:28 --> URI Class Initialized
INFO - 2022-07-02 10:13:28 --> Router Class Initialized
INFO - 2022-07-02 10:13:28 --> Output Class Initialized
INFO - 2022-07-02 10:13:28 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:28 --> Input Class Initialized
INFO - 2022-07-02 10:13:28 --> Language Class Initialized
INFO - 2022-07-02 10:13:28 --> Language Class Initialized
INFO - 2022-07-02 10:13:28 --> Config Class Initialized
INFO - 2022-07-02 10:13:28 --> Loader Class Initialized
INFO - 2022-07-02 10:13:28 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:28 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:28 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:28 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:28 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:28 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xii.php
INFO - 2022-07-02 10:13:29 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:29 --> Total execution time: 0.2987
INFO - 2022-07-02 10:13:51 --> Config Class Initialized
INFO - 2022-07-02 10:13:51 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:51 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:51 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:51 --> URI Class Initialized
INFO - 2022-07-02 10:13:51 --> Router Class Initialized
INFO - 2022-07-02 10:13:51 --> Output Class Initialized
INFO - 2022-07-02 10:13:51 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:51 --> Input Class Initialized
INFO - 2022-07-02 10:13:51 --> Language Class Initialized
INFO - 2022-07-02 10:13:51 --> Language Class Initialized
INFO - 2022-07-02 10:13:51 --> Config Class Initialized
INFO - 2022-07-02 10:13:51 --> Loader Class Initialized
INFO - 2022-07-02 10:13:51 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:51 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:51 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:51 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:51 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:51 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-02 10:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:13:51 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:51 --> Total execution time: 0.1040
INFO - 2022-07-02 10:13:55 --> Config Class Initialized
INFO - 2022-07-02 10:13:55 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:55 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:55 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:55 --> URI Class Initialized
INFO - 2022-07-02 10:13:55 --> Router Class Initialized
INFO - 2022-07-02 10:13:55 --> Output Class Initialized
INFO - 2022-07-02 10:13:55 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:55 --> Input Class Initialized
INFO - 2022-07-02 10:13:55 --> Language Class Initialized
INFO - 2022-07-02 10:13:55 --> Language Class Initialized
INFO - 2022-07-02 10:13:55 --> Config Class Initialized
INFO - 2022-07-02 10:13:55 --> Loader Class Initialized
INFO - 2022-07-02 10:13:55 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:55 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:55 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:55 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:55 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:55 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2022-07-02 10:13:56 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:56 --> Total execution time: 0.2286
INFO - 2022-07-02 10:13:57 --> Config Class Initialized
INFO - 2022-07-02 10:13:57 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:57 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:57 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:57 --> URI Class Initialized
INFO - 2022-07-02 10:13:57 --> Router Class Initialized
INFO - 2022-07-02 10:13:57 --> Output Class Initialized
INFO - 2022-07-02 10:13:57 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:57 --> Input Class Initialized
INFO - 2022-07-02 10:13:57 --> Language Class Initialized
INFO - 2022-07-02 10:13:57 --> Language Class Initialized
INFO - 2022-07-02 10:13:57 --> Config Class Initialized
INFO - 2022-07-02 10:13:57 --> Loader Class Initialized
INFO - 2022-07-02 10:13:57 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:57 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:57 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:57 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:57 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:57 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2022-07-02 10:13:57 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:57 --> Total execution time: 0.1917
INFO - 2022-07-02 10:13:57 --> Config Class Initialized
INFO - 2022-07-02 10:13:57 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:13:57 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:13:57 --> Utf8 Class Initialized
INFO - 2022-07-02 10:13:57 --> URI Class Initialized
INFO - 2022-07-02 10:13:57 --> Router Class Initialized
INFO - 2022-07-02 10:13:57 --> Output Class Initialized
INFO - 2022-07-02 10:13:57 --> Security Class Initialized
DEBUG - 2022-07-02 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:13:57 --> Input Class Initialized
INFO - 2022-07-02 10:13:57 --> Language Class Initialized
INFO - 2022-07-02 10:13:57 --> Language Class Initialized
INFO - 2022-07-02 10:13:57 --> Config Class Initialized
INFO - 2022-07-02 10:13:57 --> Loader Class Initialized
INFO - 2022-07-02 10:13:57 --> Helper loaded: url_helper
INFO - 2022-07-02 10:13:57 --> Helper loaded: file_helper
INFO - 2022-07-02 10:13:57 --> Helper loaded: form_helper
INFO - 2022-07-02 10:13:57 --> Helper loaded: my_helper
INFO - 2022-07-02 10:13:57 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:13:57 --> Controller Class Initialized
DEBUG - 2022-07-02 10:13:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-07-02 10:13:57 --> Final output sent to browser
DEBUG - 2022-07-02 10:13:57 --> Total execution time: 0.1798
INFO - 2022-07-02 10:14:01 --> Config Class Initialized
INFO - 2022-07-02 10:14:01 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:14:01 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:14:01 --> Utf8 Class Initialized
INFO - 2022-07-02 10:14:01 --> URI Class Initialized
INFO - 2022-07-02 10:14:01 --> Router Class Initialized
INFO - 2022-07-02 10:14:01 --> Output Class Initialized
INFO - 2022-07-02 10:14:01 --> Security Class Initialized
DEBUG - 2022-07-02 10:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:14:01 --> Input Class Initialized
INFO - 2022-07-02 10:14:01 --> Language Class Initialized
INFO - 2022-07-02 10:14:01 --> Language Class Initialized
INFO - 2022-07-02 10:14:01 --> Config Class Initialized
INFO - 2022-07-02 10:14:01 --> Loader Class Initialized
INFO - 2022-07-02 10:14:01 --> Helper loaded: url_helper
INFO - 2022-07-02 10:14:01 --> Helper loaded: file_helper
INFO - 2022-07-02 10:14:01 --> Helper loaded: form_helper
INFO - 2022-07-02 10:14:01 --> Helper loaded: my_helper
INFO - 2022-07-02 10:14:01 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:14:01 --> Controller Class Initialized
DEBUG - 2022-07-02 10:14:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2022-07-02 10:14:01 --> Final output sent to browser
DEBUG - 2022-07-02 10:14:01 --> Total execution time: 0.1736
INFO - 2022-07-02 10:14:03 --> Config Class Initialized
INFO - 2022-07-02 10:14:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:14:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:14:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:14:03 --> URI Class Initialized
INFO - 2022-07-02 10:14:03 --> Router Class Initialized
INFO - 2022-07-02 10:14:03 --> Output Class Initialized
INFO - 2022-07-02 10:14:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:14:03 --> Input Class Initialized
INFO - 2022-07-02 10:14:03 --> Language Class Initialized
INFO - 2022-07-02 10:14:03 --> Language Class Initialized
INFO - 2022-07-02 10:14:03 --> Config Class Initialized
INFO - 2022-07-02 10:14:03 --> Loader Class Initialized
INFO - 2022-07-02 10:14:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:14:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:14:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:14:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:14:03 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:14:03 --> Controller Class Initialized
DEBUG - 2022-07-02 10:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2022-07-02 10:14:03 --> Final output sent to browser
DEBUG - 2022-07-02 10:14:03 --> Total execution time: 0.1576
INFO - 2022-07-02 10:14:05 --> Config Class Initialized
INFO - 2022-07-02 10:14:05 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:14:05 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:14:05 --> Utf8 Class Initialized
INFO - 2022-07-02 10:14:05 --> URI Class Initialized
INFO - 2022-07-02 10:14:05 --> Router Class Initialized
INFO - 2022-07-02 10:14:05 --> Output Class Initialized
INFO - 2022-07-02 10:14:05 --> Security Class Initialized
DEBUG - 2022-07-02 10:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:14:05 --> Input Class Initialized
INFO - 2022-07-02 10:14:05 --> Language Class Initialized
INFO - 2022-07-02 10:14:05 --> Language Class Initialized
INFO - 2022-07-02 10:14:05 --> Config Class Initialized
INFO - 2022-07-02 10:14:05 --> Loader Class Initialized
INFO - 2022-07-02 10:14:05 --> Helper loaded: url_helper
INFO - 2022-07-02 10:14:05 --> Helper loaded: file_helper
INFO - 2022-07-02 10:14:05 --> Helper loaded: form_helper
INFO - 2022-07-02 10:14:05 --> Helper loaded: my_helper
INFO - 2022-07-02 10:14:05 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:14:05 --> Controller Class Initialized
DEBUG - 2022-07-02 10:14:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2022-07-02 10:14:05 --> Final output sent to browser
DEBUG - 2022-07-02 10:14:05 --> Total execution time: 0.1621
INFO - 2022-07-02 10:14:07 --> Config Class Initialized
INFO - 2022-07-02 10:14:07 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:14:07 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:14:07 --> Utf8 Class Initialized
INFO - 2022-07-02 10:14:07 --> URI Class Initialized
INFO - 2022-07-02 10:14:07 --> Router Class Initialized
INFO - 2022-07-02 10:14:07 --> Output Class Initialized
INFO - 2022-07-02 10:14:07 --> Security Class Initialized
DEBUG - 2022-07-02 10:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:14:07 --> Input Class Initialized
INFO - 2022-07-02 10:14:07 --> Language Class Initialized
INFO - 2022-07-02 10:14:07 --> Language Class Initialized
INFO - 2022-07-02 10:14:07 --> Config Class Initialized
INFO - 2022-07-02 10:14:07 --> Loader Class Initialized
INFO - 2022-07-02 10:14:07 --> Helper loaded: url_helper
INFO - 2022-07-02 10:14:07 --> Helper loaded: file_helper
INFO - 2022-07-02 10:14:07 --> Helper loaded: form_helper
INFO - 2022-07-02 10:14:07 --> Helper loaded: my_helper
INFO - 2022-07-02 10:14:07 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:14:07 --> Controller Class Initialized
DEBUG - 2022-07-02 10:14:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2022-07-02 10:14:07 --> Final output sent to browser
DEBUG - 2022-07-02 10:14:07 --> Total execution time: 0.1579
INFO - 2022-07-02 10:18:03 --> Config Class Initialized
INFO - 2022-07-02 10:18:03 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:18:03 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:18:03 --> Utf8 Class Initialized
INFO - 2022-07-02 10:18:03 --> URI Class Initialized
INFO - 2022-07-02 10:18:03 --> Router Class Initialized
INFO - 2022-07-02 10:18:03 --> Output Class Initialized
INFO - 2022-07-02 10:18:03 --> Security Class Initialized
DEBUG - 2022-07-02 10:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:18:03 --> Input Class Initialized
INFO - 2022-07-02 10:18:03 --> Language Class Initialized
INFO - 2022-07-02 10:18:03 --> Language Class Initialized
INFO - 2022-07-02 10:18:03 --> Config Class Initialized
INFO - 2022-07-02 10:18:03 --> Loader Class Initialized
INFO - 2022-07-02 10:18:03 --> Helper loaded: url_helper
INFO - 2022-07-02 10:18:03 --> Helper loaded: file_helper
INFO - 2022-07-02 10:18:03 --> Helper loaded: form_helper
INFO - 2022-07-02 10:18:03 --> Helper loaded: my_helper
INFO - 2022-07-02 10:18:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:18:04 --> Controller Class Initialized
INFO - 2022-07-02 10:18:04 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:18:04 --> Config Class Initialized
INFO - 2022-07-02 10:18:04 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:18:04 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:18:04 --> Utf8 Class Initialized
INFO - 2022-07-02 10:18:04 --> URI Class Initialized
INFO - 2022-07-02 10:18:04 --> Router Class Initialized
INFO - 2022-07-02 10:18:04 --> Output Class Initialized
INFO - 2022-07-02 10:18:04 --> Security Class Initialized
DEBUG - 2022-07-02 10:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:18:04 --> Input Class Initialized
INFO - 2022-07-02 10:18:04 --> Language Class Initialized
INFO - 2022-07-02 10:18:04 --> Language Class Initialized
INFO - 2022-07-02 10:18:04 --> Config Class Initialized
INFO - 2022-07-02 10:18:04 --> Loader Class Initialized
INFO - 2022-07-02 10:18:04 --> Helper loaded: url_helper
INFO - 2022-07-02 10:18:04 --> Helper loaded: file_helper
INFO - 2022-07-02 10:18:04 --> Helper loaded: form_helper
INFO - 2022-07-02 10:18:04 --> Helper loaded: my_helper
INFO - 2022-07-02 10:18:04 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:18:04 --> Controller Class Initialized
DEBUG - 2022-07-02 10:18:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 10:18:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:18:04 --> Final output sent to browser
DEBUG - 2022-07-02 10:18:04 --> Total execution time: 0.0541
INFO - 2022-07-02 10:18:08 --> Config Class Initialized
INFO - 2022-07-02 10:18:08 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:18:08 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:18:08 --> Utf8 Class Initialized
INFO - 2022-07-02 10:18:08 --> URI Class Initialized
INFO - 2022-07-02 10:18:08 --> Router Class Initialized
INFO - 2022-07-02 10:18:08 --> Output Class Initialized
INFO - 2022-07-02 10:18:08 --> Security Class Initialized
DEBUG - 2022-07-02 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:18:08 --> Input Class Initialized
INFO - 2022-07-02 10:18:08 --> Language Class Initialized
INFO - 2022-07-02 10:18:08 --> Language Class Initialized
INFO - 2022-07-02 10:18:08 --> Config Class Initialized
INFO - 2022-07-02 10:18:08 --> Loader Class Initialized
INFO - 2022-07-02 10:18:08 --> Helper loaded: url_helper
INFO - 2022-07-02 10:18:08 --> Helper loaded: file_helper
INFO - 2022-07-02 10:18:08 --> Helper loaded: form_helper
INFO - 2022-07-02 10:18:08 --> Helper loaded: my_helper
INFO - 2022-07-02 10:18:08 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:18:08 --> Controller Class Initialized
INFO - 2022-07-02 10:18:08 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:18:08 --> Final output sent to browser
DEBUG - 2022-07-02 10:18:08 --> Total execution time: 0.0457
INFO - 2022-07-02 10:18:08 --> Config Class Initialized
INFO - 2022-07-02 10:18:08 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:18:08 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:18:08 --> Utf8 Class Initialized
INFO - 2022-07-02 10:18:08 --> URI Class Initialized
INFO - 2022-07-02 10:18:08 --> Router Class Initialized
INFO - 2022-07-02 10:18:08 --> Output Class Initialized
INFO - 2022-07-02 10:18:08 --> Security Class Initialized
DEBUG - 2022-07-02 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:18:08 --> Input Class Initialized
INFO - 2022-07-02 10:18:08 --> Language Class Initialized
INFO - 2022-07-02 10:18:08 --> Language Class Initialized
INFO - 2022-07-02 10:18:08 --> Config Class Initialized
INFO - 2022-07-02 10:18:08 --> Loader Class Initialized
INFO - 2022-07-02 10:18:08 --> Helper loaded: url_helper
INFO - 2022-07-02 10:18:08 --> Helper loaded: file_helper
INFO - 2022-07-02 10:18:08 --> Helper loaded: form_helper
INFO - 2022-07-02 10:18:08 --> Helper loaded: my_helper
INFO - 2022-07-02 10:18:08 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:18:08 --> Controller Class Initialized
DEBUG - 2022-07-02 10:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:18:08 --> Final output sent to browser
DEBUG - 2022-07-02 10:18:08 --> Total execution time: 0.5641
INFO - 2022-07-02 10:18:31 --> Config Class Initialized
INFO - 2022-07-02 10:18:31 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:18:31 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:18:31 --> Utf8 Class Initialized
INFO - 2022-07-02 10:18:31 --> URI Class Initialized
INFO - 2022-07-02 10:18:31 --> Router Class Initialized
INFO - 2022-07-02 10:18:31 --> Output Class Initialized
INFO - 2022-07-02 10:18:31 --> Security Class Initialized
DEBUG - 2022-07-02 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:18:31 --> Input Class Initialized
INFO - 2022-07-02 10:18:31 --> Language Class Initialized
INFO - 2022-07-02 10:18:31 --> Language Class Initialized
INFO - 2022-07-02 10:18:31 --> Config Class Initialized
INFO - 2022-07-02 10:18:31 --> Loader Class Initialized
INFO - 2022-07-02 10:18:31 --> Helper loaded: url_helper
INFO - 2022-07-02 10:18:31 --> Helper loaded: file_helper
INFO - 2022-07-02 10:18:31 --> Helper loaded: form_helper
INFO - 2022-07-02 10:18:31 --> Helper loaded: my_helper
INFO - 2022-07-02 10:18:31 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:18:31 --> Controller Class Initialized
DEBUG - 2022-07-02 10:18:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-02 10:18:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:18:31 --> Final output sent to browser
DEBUG - 2022-07-02 10:18:31 --> Total execution time: 0.0699
INFO - 2022-07-02 10:18:33 --> Config Class Initialized
INFO - 2022-07-02 10:18:33 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:18:33 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:18:33 --> Utf8 Class Initialized
INFO - 2022-07-02 10:18:33 --> URI Class Initialized
INFO - 2022-07-02 10:18:33 --> Router Class Initialized
INFO - 2022-07-02 10:18:33 --> Output Class Initialized
INFO - 2022-07-02 10:18:33 --> Security Class Initialized
DEBUG - 2022-07-02 10:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:18:33 --> Input Class Initialized
INFO - 2022-07-02 10:18:33 --> Language Class Initialized
INFO - 2022-07-02 10:18:33 --> Language Class Initialized
INFO - 2022-07-02 10:18:33 --> Config Class Initialized
INFO - 2022-07-02 10:18:33 --> Loader Class Initialized
INFO - 2022-07-02 10:18:33 --> Helper loaded: url_helper
INFO - 2022-07-02 10:18:33 --> Helper loaded: file_helper
INFO - 2022-07-02 10:18:33 --> Helper loaded: form_helper
INFO - 2022-07-02 10:18:33 --> Helper loaded: my_helper
INFO - 2022-07-02 10:18:33 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:18:33 --> Controller Class Initialized
DEBUG - 2022-07-02 10:18:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:18:34 --> Final output sent to browser
DEBUG - 2022-07-02 10:18:34 --> Total execution time: 0.7780
INFO - 2022-07-02 10:19:11 --> Config Class Initialized
INFO - 2022-07-02 10:19:11 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:19:11 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:19:11 --> Utf8 Class Initialized
INFO - 2022-07-02 10:19:11 --> URI Class Initialized
INFO - 2022-07-02 10:19:11 --> Router Class Initialized
INFO - 2022-07-02 10:19:11 --> Output Class Initialized
INFO - 2022-07-02 10:19:11 --> Security Class Initialized
DEBUG - 2022-07-02 10:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:19:11 --> Input Class Initialized
INFO - 2022-07-02 10:19:11 --> Language Class Initialized
INFO - 2022-07-02 10:19:11 --> Language Class Initialized
INFO - 2022-07-02 10:19:11 --> Config Class Initialized
INFO - 2022-07-02 10:19:11 --> Loader Class Initialized
INFO - 2022-07-02 10:19:11 --> Helper loaded: url_helper
INFO - 2022-07-02 10:19:11 --> Helper loaded: file_helper
INFO - 2022-07-02 10:19:11 --> Helper loaded: form_helper
INFO - 2022-07-02 10:19:11 --> Helper loaded: my_helper
INFO - 2022-07-02 10:19:11 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:19:11 --> Controller Class Initialized
DEBUG - 2022-07-02 10:19:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-02 10:19:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:19:11 --> Final output sent to browser
DEBUG - 2022-07-02 10:19:11 --> Total execution time: 0.0707
INFO - 2022-07-02 10:19:40 --> Config Class Initialized
INFO - 2022-07-02 10:19:40 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:19:40 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:19:40 --> Utf8 Class Initialized
INFO - 2022-07-02 10:19:40 --> URI Class Initialized
INFO - 2022-07-02 10:19:40 --> Router Class Initialized
INFO - 2022-07-02 10:19:40 --> Output Class Initialized
INFO - 2022-07-02 10:19:40 --> Security Class Initialized
DEBUG - 2022-07-02 10:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:19:40 --> Input Class Initialized
INFO - 2022-07-02 10:19:40 --> Language Class Initialized
INFO - 2022-07-02 10:19:40 --> Language Class Initialized
INFO - 2022-07-02 10:19:40 --> Config Class Initialized
INFO - 2022-07-02 10:19:40 --> Loader Class Initialized
INFO - 2022-07-02 10:19:40 --> Helper loaded: url_helper
INFO - 2022-07-02 10:19:40 --> Helper loaded: file_helper
INFO - 2022-07-02 10:19:40 --> Helper loaded: form_helper
INFO - 2022-07-02 10:19:40 --> Helper loaded: my_helper
INFO - 2022-07-02 10:19:40 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:19:40 --> Controller Class Initialized
INFO - 2022-07-02 10:19:40 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:19:40 --> Config Class Initialized
INFO - 2022-07-02 10:19:40 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:19:40 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:19:40 --> Utf8 Class Initialized
INFO - 2022-07-02 10:19:40 --> URI Class Initialized
INFO - 2022-07-02 10:19:41 --> Router Class Initialized
INFO - 2022-07-02 10:19:41 --> Output Class Initialized
INFO - 2022-07-02 10:19:41 --> Security Class Initialized
DEBUG - 2022-07-02 10:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:19:41 --> Input Class Initialized
INFO - 2022-07-02 10:19:41 --> Language Class Initialized
INFO - 2022-07-02 10:19:41 --> Language Class Initialized
INFO - 2022-07-02 10:19:41 --> Config Class Initialized
INFO - 2022-07-02 10:19:41 --> Loader Class Initialized
INFO - 2022-07-02 10:19:41 --> Helper loaded: url_helper
INFO - 2022-07-02 10:19:41 --> Helper loaded: file_helper
INFO - 2022-07-02 10:19:41 --> Helper loaded: form_helper
INFO - 2022-07-02 10:19:41 --> Helper loaded: my_helper
INFO - 2022-07-02 10:19:41 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:19:41 --> Controller Class Initialized
DEBUG - 2022-07-02 10:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 10:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:19:41 --> Final output sent to browser
DEBUG - 2022-07-02 10:19:41 --> Total execution time: 0.0531
INFO - 2022-07-02 10:19:49 --> Config Class Initialized
INFO - 2022-07-02 10:19:49 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:19:49 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:19:49 --> Utf8 Class Initialized
INFO - 2022-07-02 10:19:49 --> URI Class Initialized
INFO - 2022-07-02 10:19:49 --> Router Class Initialized
INFO - 2022-07-02 10:19:49 --> Output Class Initialized
INFO - 2022-07-02 10:19:49 --> Security Class Initialized
DEBUG - 2022-07-02 10:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:19:49 --> Input Class Initialized
INFO - 2022-07-02 10:19:49 --> Language Class Initialized
INFO - 2022-07-02 10:19:49 --> Language Class Initialized
INFO - 2022-07-02 10:19:49 --> Config Class Initialized
INFO - 2022-07-02 10:19:49 --> Loader Class Initialized
INFO - 2022-07-02 10:19:49 --> Helper loaded: url_helper
INFO - 2022-07-02 10:19:49 --> Helper loaded: file_helper
INFO - 2022-07-02 10:19:49 --> Helper loaded: form_helper
INFO - 2022-07-02 10:19:49 --> Helper loaded: my_helper
INFO - 2022-07-02 10:19:49 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:19:50 --> Controller Class Initialized
INFO - 2022-07-02 10:19:50 --> Final output sent to browser
DEBUG - 2022-07-02 10:19:50 --> Total execution time: 0.0627
INFO - 2022-07-02 10:19:53 --> Config Class Initialized
INFO - 2022-07-02 10:19:53 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:19:53 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:19:53 --> Utf8 Class Initialized
INFO - 2022-07-02 10:19:53 --> URI Class Initialized
INFO - 2022-07-02 10:19:53 --> Router Class Initialized
INFO - 2022-07-02 10:19:53 --> Output Class Initialized
INFO - 2022-07-02 10:19:53 --> Security Class Initialized
DEBUG - 2022-07-02 10:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:19:53 --> Input Class Initialized
INFO - 2022-07-02 10:19:53 --> Language Class Initialized
INFO - 2022-07-02 10:19:53 --> Language Class Initialized
INFO - 2022-07-02 10:19:53 --> Config Class Initialized
INFO - 2022-07-02 10:19:53 --> Loader Class Initialized
INFO - 2022-07-02 10:19:53 --> Helper loaded: url_helper
INFO - 2022-07-02 10:19:53 --> Helper loaded: file_helper
INFO - 2022-07-02 10:19:53 --> Helper loaded: form_helper
INFO - 2022-07-02 10:19:53 --> Helper loaded: my_helper
INFO - 2022-07-02 10:19:53 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:19:53 --> Controller Class Initialized
INFO - 2022-07-02 10:19:53 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:19:53 --> Final output sent to browser
DEBUG - 2022-07-02 10:19:53 --> Total execution time: 0.0606
INFO - 2022-07-02 10:19:54 --> Config Class Initialized
INFO - 2022-07-02 10:19:54 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:19:54 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:19:54 --> Utf8 Class Initialized
INFO - 2022-07-02 10:19:54 --> URI Class Initialized
INFO - 2022-07-02 10:19:54 --> Router Class Initialized
INFO - 2022-07-02 10:19:54 --> Output Class Initialized
INFO - 2022-07-02 10:19:54 --> Security Class Initialized
DEBUG - 2022-07-02 10:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:19:54 --> Input Class Initialized
INFO - 2022-07-02 10:19:54 --> Language Class Initialized
INFO - 2022-07-02 10:19:54 --> Language Class Initialized
INFO - 2022-07-02 10:19:54 --> Config Class Initialized
INFO - 2022-07-02 10:19:54 --> Loader Class Initialized
INFO - 2022-07-02 10:19:54 --> Helper loaded: url_helper
INFO - 2022-07-02 10:19:54 --> Helper loaded: file_helper
INFO - 2022-07-02 10:19:54 --> Helper loaded: form_helper
INFO - 2022-07-02 10:19:54 --> Helper loaded: my_helper
INFO - 2022-07-02 10:19:54 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:19:54 --> Controller Class Initialized
DEBUG - 2022-07-02 10:19:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:19:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:19:54 --> Final output sent to browser
DEBUG - 2022-07-02 10:19:54 --> Total execution time: 0.5655
INFO - 2022-07-02 10:19:55 --> Config Class Initialized
INFO - 2022-07-02 10:19:55 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:19:55 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:19:55 --> Utf8 Class Initialized
INFO - 2022-07-02 10:19:55 --> URI Class Initialized
INFO - 2022-07-02 10:19:55 --> Router Class Initialized
INFO - 2022-07-02 10:19:55 --> Output Class Initialized
INFO - 2022-07-02 10:19:55 --> Security Class Initialized
DEBUG - 2022-07-02 10:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:19:55 --> Input Class Initialized
INFO - 2022-07-02 10:19:55 --> Language Class Initialized
INFO - 2022-07-02 10:19:55 --> Language Class Initialized
INFO - 2022-07-02 10:19:55 --> Config Class Initialized
INFO - 2022-07-02 10:19:55 --> Loader Class Initialized
INFO - 2022-07-02 10:19:55 --> Helper loaded: url_helper
INFO - 2022-07-02 10:19:55 --> Helper loaded: file_helper
INFO - 2022-07-02 10:19:55 --> Helper loaded: form_helper
INFO - 2022-07-02 10:19:55 --> Helper loaded: my_helper
INFO - 2022-07-02 10:19:55 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:19:55 --> Controller Class Initialized
DEBUG - 2022-07-02 10:19:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-02 10:19:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:19:55 --> Final output sent to browser
DEBUG - 2022-07-02 10:19:55 --> Total execution time: 0.0510
INFO - 2022-07-02 10:20:38 --> Config Class Initialized
INFO - 2022-07-02 10:20:38 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:20:38 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:20:38 --> Utf8 Class Initialized
INFO - 2022-07-02 10:20:38 --> URI Class Initialized
INFO - 2022-07-02 10:20:38 --> Router Class Initialized
INFO - 2022-07-02 10:20:38 --> Output Class Initialized
INFO - 2022-07-02 10:20:38 --> Security Class Initialized
DEBUG - 2022-07-02 10:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:20:38 --> Input Class Initialized
INFO - 2022-07-02 10:20:38 --> Language Class Initialized
INFO - 2022-07-02 10:20:38 --> Language Class Initialized
INFO - 2022-07-02 10:20:38 --> Config Class Initialized
INFO - 2022-07-02 10:20:38 --> Loader Class Initialized
INFO - 2022-07-02 10:20:38 --> Helper loaded: url_helper
INFO - 2022-07-02 10:20:38 --> Helper loaded: file_helper
INFO - 2022-07-02 10:20:38 --> Helper loaded: form_helper
INFO - 2022-07-02 10:20:38 --> Helper loaded: my_helper
INFO - 2022-07-02 10:20:38 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:20:38 --> Controller Class Initialized
DEBUG - 2022-07-02 10:20:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:20:39 --> Final output sent to browser
DEBUG - 2022-07-02 10:20:39 --> Total execution time: 0.3310
INFO - 2022-07-02 10:20:39 --> Config Class Initialized
INFO - 2022-07-02 10:20:39 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:20:39 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:20:39 --> Utf8 Class Initialized
INFO - 2022-07-02 10:20:39 --> URI Class Initialized
INFO - 2022-07-02 10:20:39 --> Router Class Initialized
INFO - 2022-07-02 10:20:39 --> Output Class Initialized
INFO - 2022-07-02 10:20:39 --> Security Class Initialized
DEBUG - 2022-07-02 10:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:20:39 --> Input Class Initialized
INFO - 2022-07-02 10:20:39 --> Language Class Initialized
INFO - 2022-07-02 10:20:39 --> Language Class Initialized
INFO - 2022-07-02 10:20:39 --> Config Class Initialized
INFO - 2022-07-02 10:20:39 --> Loader Class Initialized
INFO - 2022-07-02 10:20:39 --> Helper loaded: url_helper
INFO - 2022-07-02 10:20:39 --> Helper loaded: file_helper
INFO - 2022-07-02 10:20:39 --> Helper loaded: form_helper
INFO - 2022-07-02 10:20:39 --> Helper loaded: my_helper
INFO - 2022-07-02 10:20:39 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:20:39 --> Controller Class Initialized
DEBUG - 2022-07-02 10:20:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:20:39 --> Final output sent to browser
DEBUG - 2022-07-02 10:20:39 --> Total execution time: 0.1186
INFO - 2022-07-02 10:21:07 --> Config Class Initialized
INFO - 2022-07-02 10:21:07 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:07 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:07 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:07 --> URI Class Initialized
INFO - 2022-07-02 10:21:07 --> Router Class Initialized
INFO - 2022-07-02 10:21:07 --> Output Class Initialized
INFO - 2022-07-02 10:21:07 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:07 --> Input Class Initialized
INFO - 2022-07-02 10:21:07 --> Language Class Initialized
INFO - 2022-07-02 10:21:07 --> Language Class Initialized
INFO - 2022-07-02 10:21:07 --> Config Class Initialized
INFO - 2022-07-02 10:21:07 --> Loader Class Initialized
INFO - 2022-07-02 10:21:07 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:07 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:07 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:07 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:07 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:07 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:07 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:07 --> Total execution time: 0.1739
INFO - 2022-07-02 10:21:09 --> Config Class Initialized
INFO - 2022-07-02 10:21:09 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:09 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:09 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:09 --> URI Class Initialized
INFO - 2022-07-02 10:21:09 --> Router Class Initialized
INFO - 2022-07-02 10:21:09 --> Output Class Initialized
INFO - 2022-07-02 10:21:09 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:09 --> Input Class Initialized
INFO - 2022-07-02 10:21:09 --> Language Class Initialized
INFO - 2022-07-02 10:21:09 --> Language Class Initialized
INFO - 2022-07-02 10:21:09 --> Config Class Initialized
INFO - 2022-07-02 10:21:09 --> Loader Class Initialized
INFO - 2022-07-02 10:21:09 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:09 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:09 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:09 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:09 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:09 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:10 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:10 --> Total execution time: 0.1678
INFO - 2022-07-02 10:21:12 --> Config Class Initialized
INFO - 2022-07-02 10:21:12 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:12 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:12 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:12 --> URI Class Initialized
INFO - 2022-07-02 10:21:12 --> Router Class Initialized
INFO - 2022-07-02 10:21:12 --> Output Class Initialized
INFO - 2022-07-02 10:21:12 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:12 --> Input Class Initialized
INFO - 2022-07-02 10:21:12 --> Language Class Initialized
INFO - 2022-07-02 10:21:12 --> Language Class Initialized
INFO - 2022-07-02 10:21:12 --> Config Class Initialized
INFO - 2022-07-02 10:21:12 --> Loader Class Initialized
INFO - 2022-07-02 10:21:12 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:12 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:12 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:12 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:12 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:12 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:12 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:12 --> Total execution time: 0.4274
INFO - 2022-07-02 10:21:13 --> Config Class Initialized
INFO - 2022-07-02 10:21:13 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:13 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:13 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:13 --> URI Class Initialized
INFO - 2022-07-02 10:21:13 --> Router Class Initialized
INFO - 2022-07-02 10:21:13 --> Output Class Initialized
INFO - 2022-07-02 10:21:13 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:13 --> Input Class Initialized
INFO - 2022-07-02 10:21:13 --> Language Class Initialized
INFO - 2022-07-02 10:21:13 --> Language Class Initialized
INFO - 2022-07-02 10:21:13 --> Config Class Initialized
INFO - 2022-07-02 10:21:13 --> Loader Class Initialized
INFO - 2022-07-02 10:21:13 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:13 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:13 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:13 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:13 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:13 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:13 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:13 --> Total execution time: 0.1709
INFO - 2022-07-02 10:21:16 --> Config Class Initialized
INFO - 2022-07-02 10:21:16 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:16 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:16 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:16 --> URI Class Initialized
INFO - 2022-07-02 10:21:16 --> Router Class Initialized
INFO - 2022-07-02 10:21:16 --> Output Class Initialized
INFO - 2022-07-02 10:21:16 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:16 --> Input Class Initialized
INFO - 2022-07-02 10:21:16 --> Language Class Initialized
INFO - 2022-07-02 10:21:16 --> Language Class Initialized
INFO - 2022-07-02 10:21:16 --> Config Class Initialized
INFO - 2022-07-02 10:21:16 --> Loader Class Initialized
INFO - 2022-07-02 10:21:16 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:16 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:16 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:16 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:16 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:16 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:16 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:16 --> Total execution time: 0.1893
INFO - 2022-07-02 10:21:17 --> Config Class Initialized
INFO - 2022-07-02 10:21:17 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:17 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:17 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:17 --> URI Class Initialized
INFO - 2022-07-02 10:21:17 --> Router Class Initialized
INFO - 2022-07-02 10:21:17 --> Output Class Initialized
INFO - 2022-07-02 10:21:17 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:17 --> Input Class Initialized
INFO - 2022-07-02 10:21:17 --> Language Class Initialized
INFO - 2022-07-02 10:21:17 --> Language Class Initialized
INFO - 2022-07-02 10:21:17 --> Config Class Initialized
INFO - 2022-07-02 10:21:17 --> Loader Class Initialized
INFO - 2022-07-02 10:21:17 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:17 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:17 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:17 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:17 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:17 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:18 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:18 --> Total execution time: 0.4907
INFO - 2022-07-02 10:21:19 --> Config Class Initialized
INFO - 2022-07-02 10:21:19 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:19 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:19 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:19 --> URI Class Initialized
INFO - 2022-07-02 10:21:19 --> Router Class Initialized
INFO - 2022-07-02 10:21:19 --> Output Class Initialized
INFO - 2022-07-02 10:21:19 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:19 --> Input Class Initialized
INFO - 2022-07-02 10:21:19 --> Language Class Initialized
INFO - 2022-07-02 10:21:19 --> Language Class Initialized
INFO - 2022-07-02 10:21:19 --> Config Class Initialized
INFO - 2022-07-02 10:21:19 --> Loader Class Initialized
INFO - 2022-07-02 10:21:19 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:19 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:19 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:19 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:19 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:19 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:19 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:19 --> Total execution time: 0.1582
INFO - 2022-07-02 10:21:21 --> Config Class Initialized
INFO - 2022-07-02 10:21:21 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:21 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:21 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:21 --> URI Class Initialized
INFO - 2022-07-02 10:21:21 --> Router Class Initialized
INFO - 2022-07-02 10:21:21 --> Output Class Initialized
INFO - 2022-07-02 10:21:21 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:21 --> Input Class Initialized
INFO - 2022-07-02 10:21:21 --> Language Class Initialized
INFO - 2022-07-02 10:21:21 --> Language Class Initialized
INFO - 2022-07-02 10:21:21 --> Config Class Initialized
INFO - 2022-07-02 10:21:21 --> Loader Class Initialized
INFO - 2022-07-02 10:21:21 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:21 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:21 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:21 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:21 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:21 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:22 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:22 --> Total execution time: 0.2581
INFO - 2022-07-02 10:21:23 --> Config Class Initialized
INFO - 2022-07-02 10:21:23 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:23 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:23 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:23 --> URI Class Initialized
INFO - 2022-07-02 10:21:23 --> Router Class Initialized
INFO - 2022-07-02 10:21:23 --> Output Class Initialized
INFO - 2022-07-02 10:21:23 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:23 --> Input Class Initialized
INFO - 2022-07-02 10:21:23 --> Language Class Initialized
INFO - 2022-07-02 10:21:23 --> Language Class Initialized
INFO - 2022-07-02 10:21:23 --> Config Class Initialized
INFO - 2022-07-02 10:21:23 --> Loader Class Initialized
INFO - 2022-07-02 10:21:23 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:23 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:23 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:23 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:23 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:23 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:23 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:23 --> Total execution time: 0.1651
INFO - 2022-07-02 10:21:25 --> Config Class Initialized
INFO - 2022-07-02 10:21:25 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:25 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:25 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:25 --> URI Class Initialized
INFO - 2022-07-02 10:21:25 --> Router Class Initialized
INFO - 2022-07-02 10:21:25 --> Output Class Initialized
INFO - 2022-07-02 10:21:25 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:25 --> Input Class Initialized
INFO - 2022-07-02 10:21:25 --> Language Class Initialized
INFO - 2022-07-02 10:21:25 --> Language Class Initialized
INFO - 2022-07-02 10:21:25 --> Config Class Initialized
INFO - 2022-07-02 10:21:25 --> Loader Class Initialized
INFO - 2022-07-02 10:21:25 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:25 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:25 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:25 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:25 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:25 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:25 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:25 --> Total execution time: 0.1594
INFO - 2022-07-02 10:21:28 --> Config Class Initialized
INFO - 2022-07-02 10:21:28 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:28 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:28 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:28 --> URI Class Initialized
INFO - 2022-07-02 10:21:28 --> Router Class Initialized
INFO - 2022-07-02 10:21:28 --> Output Class Initialized
INFO - 2022-07-02 10:21:28 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:28 --> Input Class Initialized
INFO - 2022-07-02 10:21:28 --> Language Class Initialized
INFO - 2022-07-02 10:21:28 --> Language Class Initialized
INFO - 2022-07-02 10:21:28 --> Config Class Initialized
INFO - 2022-07-02 10:21:28 --> Loader Class Initialized
INFO - 2022-07-02 10:21:28 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:28 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:28 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:28 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:28 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:28 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:28 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:28 --> Total execution time: 0.1633
INFO - 2022-07-02 10:21:29 --> Config Class Initialized
INFO - 2022-07-02 10:21:29 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:29 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:29 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:29 --> URI Class Initialized
INFO - 2022-07-02 10:21:29 --> Router Class Initialized
INFO - 2022-07-02 10:21:29 --> Output Class Initialized
INFO - 2022-07-02 10:21:29 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:29 --> Input Class Initialized
INFO - 2022-07-02 10:21:29 --> Language Class Initialized
INFO - 2022-07-02 10:21:29 --> Language Class Initialized
INFO - 2022-07-02 10:21:29 --> Config Class Initialized
INFO - 2022-07-02 10:21:29 --> Loader Class Initialized
INFO - 2022-07-02 10:21:29 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:29 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:29 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:29 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:29 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:29 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:29 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:29 --> Total execution time: 0.1561
INFO - 2022-07-02 10:21:31 --> Config Class Initialized
INFO - 2022-07-02 10:21:31 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:31 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:31 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:31 --> URI Class Initialized
INFO - 2022-07-02 10:21:31 --> Router Class Initialized
INFO - 2022-07-02 10:21:31 --> Output Class Initialized
INFO - 2022-07-02 10:21:31 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:31 --> Input Class Initialized
INFO - 2022-07-02 10:21:31 --> Language Class Initialized
INFO - 2022-07-02 10:21:31 --> Language Class Initialized
INFO - 2022-07-02 10:21:31 --> Config Class Initialized
INFO - 2022-07-02 10:21:31 --> Loader Class Initialized
INFO - 2022-07-02 10:21:31 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:31 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:31 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:31 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:31 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:31 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:32 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:32 --> Total execution time: 0.1598
INFO - 2022-07-02 10:21:33 --> Config Class Initialized
INFO - 2022-07-02 10:21:33 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:33 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:33 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:33 --> URI Class Initialized
INFO - 2022-07-02 10:21:33 --> Router Class Initialized
INFO - 2022-07-02 10:21:33 --> Output Class Initialized
INFO - 2022-07-02 10:21:33 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:33 --> Input Class Initialized
INFO - 2022-07-02 10:21:33 --> Language Class Initialized
INFO - 2022-07-02 10:21:33 --> Language Class Initialized
INFO - 2022-07-02 10:21:33 --> Config Class Initialized
INFO - 2022-07-02 10:21:33 --> Loader Class Initialized
INFO - 2022-07-02 10:21:33 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:33 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:33 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:33 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:33 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:33 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:33 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:33 --> Total execution time: 0.1620
INFO - 2022-07-02 10:21:35 --> Config Class Initialized
INFO - 2022-07-02 10:21:35 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:35 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:35 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:35 --> URI Class Initialized
INFO - 2022-07-02 10:21:35 --> Router Class Initialized
INFO - 2022-07-02 10:21:35 --> Output Class Initialized
INFO - 2022-07-02 10:21:35 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:35 --> Input Class Initialized
INFO - 2022-07-02 10:21:35 --> Language Class Initialized
INFO - 2022-07-02 10:21:35 --> Language Class Initialized
INFO - 2022-07-02 10:21:35 --> Config Class Initialized
INFO - 2022-07-02 10:21:35 --> Loader Class Initialized
INFO - 2022-07-02 10:21:35 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:35 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:35 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:35 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:35 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:35 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:35 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:35 --> Total execution time: 0.1603
INFO - 2022-07-02 10:21:37 --> Config Class Initialized
INFO - 2022-07-02 10:21:37 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:37 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:37 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:37 --> URI Class Initialized
INFO - 2022-07-02 10:21:37 --> Router Class Initialized
INFO - 2022-07-02 10:21:37 --> Output Class Initialized
INFO - 2022-07-02 10:21:37 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:37 --> Input Class Initialized
INFO - 2022-07-02 10:21:37 --> Language Class Initialized
INFO - 2022-07-02 10:21:37 --> Language Class Initialized
INFO - 2022-07-02 10:21:37 --> Config Class Initialized
INFO - 2022-07-02 10:21:37 --> Loader Class Initialized
INFO - 2022-07-02 10:21:37 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:37 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:37 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:37 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:37 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:37 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:37 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:37 --> Total execution time: 0.1810
INFO - 2022-07-02 10:21:39 --> Config Class Initialized
INFO - 2022-07-02 10:21:39 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:39 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:39 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:39 --> URI Class Initialized
INFO - 2022-07-02 10:21:39 --> Router Class Initialized
INFO - 2022-07-02 10:21:39 --> Output Class Initialized
INFO - 2022-07-02 10:21:39 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:39 --> Input Class Initialized
INFO - 2022-07-02 10:21:39 --> Language Class Initialized
INFO - 2022-07-02 10:21:39 --> Language Class Initialized
INFO - 2022-07-02 10:21:39 --> Config Class Initialized
INFO - 2022-07-02 10:21:39 --> Loader Class Initialized
INFO - 2022-07-02 10:21:39 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:39 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:39 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:39 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:39 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:39 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:39 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:39 --> Total execution time: 0.3350
INFO - 2022-07-02 10:21:41 --> Config Class Initialized
INFO - 2022-07-02 10:21:41 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:41 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:41 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:41 --> URI Class Initialized
INFO - 2022-07-02 10:21:41 --> Router Class Initialized
INFO - 2022-07-02 10:21:41 --> Output Class Initialized
INFO - 2022-07-02 10:21:41 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:41 --> Input Class Initialized
INFO - 2022-07-02 10:21:41 --> Language Class Initialized
INFO - 2022-07-02 10:21:41 --> Language Class Initialized
INFO - 2022-07-02 10:21:41 --> Config Class Initialized
INFO - 2022-07-02 10:21:41 --> Loader Class Initialized
INFO - 2022-07-02 10:21:41 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:41 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:41 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:41 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:41 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:41 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:41 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:41 --> Total execution time: 0.1621
INFO - 2022-07-02 10:21:44 --> Config Class Initialized
INFO - 2022-07-02 10:21:44 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:44 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:44 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:44 --> URI Class Initialized
INFO - 2022-07-02 10:21:44 --> Router Class Initialized
INFO - 2022-07-02 10:21:44 --> Output Class Initialized
INFO - 2022-07-02 10:21:44 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:44 --> Input Class Initialized
INFO - 2022-07-02 10:21:44 --> Language Class Initialized
INFO - 2022-07-02 10:21:44 --> Language Class Initialized
INFO - 2022-07-02 10:21:44 --> Config Class Initialized
INFO - 2022-07-02 10:21:44 --> Loader Class Initialized
INFO - 2022-07-02 10:21:44 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:44 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:44 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:44 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:44 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:44 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:44 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:44 --> Total execution time: 0.1547
INFO - 2022-07-02 10:21:46 --> Config Class Initialized
INFO - 2022-07-02 10:21:46 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:46 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:46 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:46 --> URI Class Initialized
INFO - 2022-07-02 10:21:46 --> Router Class Initialized
INFO - 2022-07-02 10:21:46 --> Output Class Initialized
INFO - 2022-07-02 10:21:46 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:46 --> Input Class Initialized
INFO - 2022-07-02 10:21:46 --> Language Class Initialized
INFO - 2022-07-02 10:21:46 --> Language Class Initialized
INFO - 2022-07-02 10:21:46 --> Config Class Initialized
INFO - 2022-07-02 10:21:46 --> Loader Class Initialized
INFO - 2022-07-02 10:21:46 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:46 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:46 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:46 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:46 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:46 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:46 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:46 --> Total execution time: 0.1713
INFO - 2022-07-02 10:21:48 --> Config Class Initialized
INFO - 2022-07-02 10:21:48 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:48 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:48 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:48 --> URI Class Initialized
INFO - 2022-07-02 10:21:48 --> Router Class Initialized
INFO - 2022-07-02 10:21:48 --> Output Class Initialized
INFO - 2022-07-02 10:21:48 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:48 --> Input Class Initialized
INFO - 2022-07-02 10:21:48 --> Language Class Initialized
INFO - 2022-07-02 10:21:48 --> Language Class Initialized
INFO - 2022-07-02 10:21:48 --> Config Class Initialized
INFO - 2022-07-02 10:21:48 --> Loader Class Initialized
INFO - 2022-07-02 10:21:48 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:48 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:48 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:48 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:48 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:48 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:48 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:48 --> Total execution time: 0.1588
INFO - 2022-07-02 10:21:50 --> Config Class Initialized
INFO - 2022-07-02 10:21:50 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:50 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:50 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:50 --> URI Class Initialized
INFO - 2022-07-02 10:21:50 --> Router Class Initialized
INFO - 2022-07-02 10:21:50 --> Output Class Initialized
INFO - 2022-07-02 10:21:50 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:50 --> Input Class Initialized
INFO - 2022-07-02 10:21:50 --> Language Class Initialized
INFO - 2022-07-02 10:21:50 --> Language Class Initialized
INFO - 2022-07-02 10:21:50 --> Config Class Initialized
INFO - 2022-07-02 10:21:50 --> Loader Class Initialized
INFO - 2022-07-02 10:21:50 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:50 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:50 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:50 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:50 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:50 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:50 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:50 --> Total execution time: 0.1680
INFO - 2022-07-02 10:21:52 --> Config Class Initialized
INFO - 2022-07-02 10:21:52 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:52 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:52 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:52 --> URI Class Initialized
INFO - 2022-07-02 10:21:52 --> Router Class Initialized
INFO - 2022-07-02 10:21:52 --> Output Class Initialized
INFO - 2022-07-02 10:21:52 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:52 --> Input Class Initialized
INFO - 2022-07-02 10:21:52 --> Language Class Initialized
INFO - 2022-07-02 10:21:52 --> Language Class Initialized
INFO - 2022-07-02 10:21:52 --> Config Class Initialized
INFO - 2022-07-02 10:21:52 --> Loader Class Initialized
INFO - 2022-07-02 10:21:52 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:52 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:52 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:52 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:52 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:52 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:52 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:52 --> Total execution time: 0.1805
INFO - 2022-07-02 10:21:55 --> Config Class Initialized
INFO - 2022-07-02 10:21:55 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:55 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:55 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:55 --> URI Class Initialized
INFO - 2022-07-02 10:21:55 --> Router Class Initialized
INFO - 2022-07-02 10:21:55 --> Output Class Initialized
INFO - 2022-07-02 10:21:55 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:55 --> Input Class Initialized
INFO - 2022-07-02 10:21:55 --> Language Class Initialized
INFO - 2022-07-02 10:21:55 --> Language Class Initialized
INFO - 2022-07-02 10:21:55 --> Config Class Initialized
INFO - 2022-07-02 10:21:55 --> Loader Class Initialized
INFO - 2022-07-02 10:21:55 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:55 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:55 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:55 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:55 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:55 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:55 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:55 --> Total execution time: 0.2214
INFO - 2022-07-02 10:21:57 --> Config Class Initialized
INFO - 2022-07-02 10:21:57 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:21:57 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:21:57 --> Utf8 Class Initialized
INFO - 2022-07-02 10:21:57 --> URI Class Initialized
INFO - 2022-07-02 10:21:57 --> Router Class Initialized
INFO - 2022-07-02 10:21:57 --> Output Class Initialized
INFO - 2022-07-02 10:21:57 --> Security Class Initialized
DEBUG - 2022-07-02 10:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:21:57 --> Input Class Initialized
INFO - 2022-07-02 10:21:57 --> Language Class Initialized
INFO - 2022-07-02 10:21:57 --> Language Class Initialized
INFO - 2022-07-02 10:21:57 --> Config Class Initialized
INFO - 2022-07-02 10:21:57 --> Loader Class Initialized
INFO - 2022-07-02 10:21:57 --> Helper loaded: url_helper
INFO - 2022-07-02 10:21:57 --> Helper loaded: file_helper
INFO - 2022-07-02 10:21:57 --> Helper loaded: form_helper
INFO - 2022-07-02 10:21:57 --> Helper loaded: my_helper
INFO - 2022-07-02 10:21:57 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:21:57 --> Controller Class Initialized
DEBUG - 2022-07-02 10:21:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:21:57 --> Final output sent to browser
DEBUG - 2022-07-02 10:21:57 --> Total execution time: 0.1652
INFO - 2022-07-02 10:23:55 --> Config Class Initialized
INFO - 2022-07-02 10:23:55 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:23:55 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:23:55 --> Utf8 Class Initialized
INFO - 2022-07-02 10:23:55 --> URI Class Initialized
INFO - 2022-07-02 10:23:55 --> Router Class Initialized
INFO - 2022-07-02 10:23:55 --> Output Class Initialized
INFO - 2022-07-02 10:23:55 --> Security Class Initialized
DEBUG - 2022-07-02 10:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:23:55 --> Input Class Initialized
INFO - 2022-07-02 10:23:55 --> Language Class Initialized
INFO - 2022-07-02 10:23:55 --> Language Class Initialized
INFO - 2022-07-02 10:23:55 --> Config Class Initialized
INFO - 2022-07-02 10:23:55 --> Loader Class Initialized
INFO - 2022-07-02 10:23:55 --> Helper loaded: url_helper
INFO - 2022-07-02 10:23:55 --> Helper loaded: file_helper
INFO - 2022-07-02 10:23:55 --> Helper loaded: form_helper
INFO - 2022-07-02 10:23:55 --> Helper loaded: my_helper
INFO - 2022-07-02 10:23:55 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:23:55 --> Controller Class Initialized
INFO - 2022-07-02 10:23:55 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:23:55 --> Config Class Initialized
INFO - 2022-07-02 10:23:55 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:23:55 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:23:55 --> Utf8 Class Initialized
INFO - 2022-07-02 10:23:55 --> URI Class Initialized
INFO - 2022-07-02 10:23:55 --> Router Class Initialized
INFO - 2022-07-02 10:23:55 --> Output Class Initialized
INFO - 2022-07-02 10:23:55 --> Security Class Initialized
DEBUG - 2022-07-02 10:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:23:55 --> Input Class Initialized
INFO - 2022-07-02 10:23:55 --> Language Class Initialized
INFO - 2022-07-02 10:23:55 --> Language Class Initialized
INFO - 2022-07-02 10:23:55 --> Config Class Initialized
INFO - 2022-07-02 10:23:55 --> Loader Class Initialized
INFO - 2022-07-02 10:23:55 --> Helper loaded: url_helper
INFO - 2022-07-02 10:23:55 --> Helper loaded: file_helper
INFO - 2022-07-02 10:23:55 --> Helper loaded: form_helper
INFO - 2022-07-02 10:23:55 --> Helper loaded: my_helper
INFO - 2022-07-02 10:23:55 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:23:55 --> Controller Class Initialized
DEBUG - 2022-07-02 10:23:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 10:23:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:23:55 --> Final output sent to browser
DEBUG - 2022-07-02 10:23:55 --> Total execution time: 0.0415
INFO - 2022-07-02 10:24:01 --> Config Class Initialized
INFO - 2022-07-02 10:24:01 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:01 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:01 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:01 --> URI Class Initialized
INFO - 2022-07-02 10:24:01 --> Router Class Initialized
INFO - 2022-07-02 10:24:01 --> Output Class Initialized
INFO - 2022-07-02 10:24:01 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:01 --> Input Class Initialized
INFO - 2022-07-02 10:24:01 --> Language Class Initialized
INFO - 2022-07-02 10:24:01 --> Language Class Initialized
INFO - 2022-07-02 10:24:01 --> Config Class Initialized
INFO - 2022-07-02 10:24:01 --> Loader Class Initialized
INFO - 2022-07-02 10:24:01 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:01 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:01 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:01 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:01 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:01 --> Controller Class Initialized
INFO - 2022-07-02 10:24:01 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:24:01 --> Final output sent to browser
DEBUG - 2022-07-02 10:24:01 --> Total execution time: 0.0444
INFO - 2022-07-02 10:24:02 --> Config Class Initialized
INFO - 2022-07-02 10:24:02 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:02 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:02 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:02 --> URI Class Initialized
INFO - 2022-07-02 10:24:02 --> Router Class Initialized
INFO - 2022-07-02 10:24:02 --> Output Class Initialized
INFO - 2022-07-02 10:24:02 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:02 --> Input Class Initialized
INFO - 2022-07-02 10:24:02 --> Language Class Initialized
INFO - 2022-07-02 10:24:02 --> Language Class Initialized
INFO - 2022-07-02 10:24:02 --> Config Class Initialized
INFO - 2022-07-02 10:24:02 --> Loader Class Initialized
INFO - 2022-07-02 10:24:02 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:02 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:02 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:02 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:02 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:02 --> Controller Class Initialized
DEBUG - 2022-07-02 10:24:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:24:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:24:02 --> Final output sent to browser
DEBUG - 2022-07-02 10:24:02 --> Total execution time: 0.5908
INFO - 2022-07-02 10:24:13 --> Config Class Initialized
INFO - 2022-07-02 10:24:13 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:13 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:13 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:13 --> URI Class Initialized
INFO - 2022-07-02 10:24:13 --> Router Class Initialized
INFO - 2022-07-02 10:24:13 --> Output Class Initialized
INFO - 2022-07-02 10:24:13 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:13 --> Input Class Initialized
INFO - 2022-07-02 10:24:13 --> Language Class Initialized
INFO - 2022-07-02 10:24:13 --> Language Class Initialized
INFO - 2022-07-02 10:24:13 --> Config Class Initialized
INFO - 2022-07-02 10:24:13 --> Loader Class Initialized
INFO - 2022-07-02 10:24:13 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:13 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:13 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:13 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:13 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:13 --> Controller Class Initialized
DEBUG - 2022-07-02 10:24:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-02 10:24:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:24:13 --> Final output sent to browser
DEBUG - 2022-07-02 10:24:13 --> Total execution time: 0.0419
INFO - 2022-07-02 10:24:14 --> Config Class Initialized
INFO - 2022-07-02 10:24:14 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:14 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:14 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:14 --> URI Class Initialized
INFO - 2022-07-02 10:24:14 --> Router Class Initialized
INFO - 2022-07-02 10:24:14 --> Output Class Initialized
INFO - 2022-07-02 10:24:14 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:14 --> Input Class Initialized
INFO - 2022-07-02 10:24:14 --> Language Class Initialized
INFO - 2022-07-02 10:24:14 --> Language Class Initialized
INFO - 2022-07-02 10:24:14 --> Config Class Initialized
INFO - 2022-07-02 10:24:14 --> Loader Class Initialized
INFO - 2022-07-02 10:24:14 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:14 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:14 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:14 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:14 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:14 --> Controller Class Initialized
INFO - 2022-07-02 10:24:15 --> Config Class Initialized
INFO - 2022-07-02 10:24:15 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:15 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:15 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:15 --> URI Class Initialized
INFO - 2022-07-02 10:24:15 --> Router Class Initialized
INFO - 2022-07-02 10:24:15 --> Output Class Initialized
INFO - 2022-07-02 10:24:15 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:15 --> Input Class Initialized
INFO - 2022-07-02 10:24:15 --> Language Class Initialized
INFO - 2022-07-02 10:24:15 --> Language Class Initialized
INFO - 2022-07-02 10:24:15 --> Config Class Initialized
INFO - 2022-07-02 10:24:15 --> Loader Class Initialized
INFO - 2022-07-02 10:24:15 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:15 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:15 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:15 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:15 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:15 --> Controller Class Initialized
INFO - 2022-07-02 10:24:15 --> Config Class Initialized
INFO - 2022-07-02 10:24:15 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:15 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:15 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:15 --> URI Class Initialized
INFO - 2022-07-02 10:24:15 --> Router Class Initialized
INFO - 2022-07-02 10:24:15 --> Output Class Initialized
INFO - 2022-07-02 10:24:15 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:15 --> Input Class Initialized
INFO - 2022-07-02 10:24:15 --> Language Class Initialized
INFO - 2022-07-02 10:24:15 --> Language Class Initialized
INFO - 2022-07-02 10:24:15 --> Config Class Initialized
INFO - 2022-07-02 10:24:15 --> Loader Class Initialized
INFO - 2022-07-02 10:24:15 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:15 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:15 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:15 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:15 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:15 --> Controller Class Initialized
INFO - 2022-07-02 10:24:17 --> Config Class Initialized
INFO - 2022-07-02 10:24:17 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:17 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:17 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:17 --> URI Class Initialized
INFO - 2022-07-02 10:24:17 --> Router Class Initialized
INFO - 2022-07-02 10:24:17 --> Output Class Initialized
INFO - 2022-07-02 10:24:17 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:17 --> Input Class Initialized
INFO - 2022-07-02 10:24:17 --> Language Class Initialized
INFO - 2022-07-02 10:24:17 --> Language Class Initialized
INFO - 2022-07-02 10:24:17 --> Config Class Initialized
INFO - 2022-07-02 10:24:17 --> Loader Class Initialized
INFO - 2022-07-02 10:24:17 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:17 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:17 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:17 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:17 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:17 --> Controller Class Initialized
ERROR - 2022-07-02 10:24:17 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-02 10:24:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-02 10:24:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:24:17 --> Final output sent to browser
DEBUG - 2022-07-02 10:24:17 --> Total execution time: 0.0575
INFO - 2022-07-02 10:24:28 --> Config Class Initialized
INFO - 2022-07-02 10:24:28 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:28 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:28 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:28 --> URI Class Initialized
INFO - 2022-07-02 10:24:28 --> Router Class Initialized
INFO - 2022-07-02 10:24:28 --> Output Class Initialized
INFO - 2022-07-02 10:24:28 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:28 --> Input Class Initialized
INFO - 2022-07-02 10:24:28 --> Language Class Initialized
INFO - 2022-07-02 10:24:28 --> Language Class Initialized
INFO - 2022-07-02 10:24:28 --> Config Class Initialized
INFO - 2022-07-02 10:24:28 --> Loader Class Initialized
INFO - 2022-07-02 10:24:28 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:28 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:28 --> Controller Class Initialized
INFO - 2022-07-02 10:24:28 --> Upload Class Initialized
INFO - 2022-07-02 10:24:28 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-02 10:24:28 --> The upload path does not appear to be valid.
INFO - 2022-07-02 10:24:28 --> Config Class Initialized
INFO - 2022-07-02 10:24:28 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:28 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:28 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:28 --> URI Class Initialized
INFO - 2022-07-02 10:24:28 --> Router Class Initialized
INFO - 2022-07-02 10:24:28 --> Output Class Initialized
INFO - 2022-07-02 10:24:28 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:28 --> Input Class Initialized
INFO - 2022-07-02 10:24:28 --> Language Class Initialized
INFO - 2022-07-02 10:24:28 --> Language Class Initialized
INFO - 2022-07-02 10:24:28 --> Config Class Initialized
INFO - 2022-07-02 10:24:28 --> Loader Class Initialized
INFO - 2022-07-02 10:24:28 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:28 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:28 --> Controller Class Initialized
DEBUG - 2022-07-02 10:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-02 10:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:24:28 --> Final output sent to browser
DEBUG - 2022-07-02 10:24:28 --> Total execution time: 0.0639
INFO - 2022-07-02 10:24:28 --> Config Class Initialized
INFO - 2022-07-02 10:24:28 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:28 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:28 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:28 --> URI Class Initialized
INFO - 2022-07-02 10:24:28 --> Router Class Initialized
INFO - 2022-07-02 10:24:28 --> Output Class Initialized
INFO - 2022-07-02 10:24:28 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:28 --> Input Class Initialized
INFO - 2022-07-02 10:24:28 --> Language Class Initialized
INFO - 2022-07-02 10:24:28 --> Language Class Initialized
INFO - 2022-07-02 10:24:28 --> Config Class Initialized
INFO - 2022-07-02 10:24:28 --> Loader Class Initialized
INFO - 2022-07-02 10:24:28 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:28 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:28 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:28 --> Controller Class Initialized
INFO - 2022-07-02 10:24:31 --> Config Class Initialized
INFO - 2022-07-02 10:24:31 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:24:31 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:24:31 --> Utf8 Class Initialized
INFO - 2022-07-02 10:24:31 --> URI Class Initialized
INFO - 2022-07-02 10:24:31 --> Router Class Initialized
INFO - 2022-07-02 10:24:31 --> Output Class Initialized
INFO - 2022-07-02 10:24:31 --> Security Class Initialized
DEBUG - 2022-07-02 10:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:24:31 --> Input Class Initialized
INFO - 2022-07-02 10:24:31 --> Language Class Initialized
INFO - 2022-07-02 10:24:31 --> Language Class Initialized
INFO - 2022-07-02 10:24:31 --> Config Class Initialized
INFO - 2022-07-02 10:24:31 --> Loader Class Initialized
INFO - 2022-07-02 10:24:31 --> Helper loaded: url_helper
INFO - 2022-07-02 10:24:31 --> Helper loaded: file_helper
INFO - 2022-07-02 10:24:31 --> Helper loaded: form_helper
INFO - 2022-07-02 10:24:31 --> Helper loaded: my_helper
INFO - 2022-07-02 10:24:31 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:24:31 --> Controller Class Initialized
DEBUG - 2022-07-02 10:24:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-02 10:24:31 --> Final output sent to browser
DEBUG - 2022-07-02 10:24:31 --> Total execution time: 0.2477
INFO - 2022-07-02 10:27:09 --> Config Class Initialized
INFO - 2022-07-02 10:27:09 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:27:09 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:27:09 --> Utf8 Class Initialized
INFO - 2022-07-02 10:27:09 --> URI Class Initialized
INFO - 2022-07-02 10:27:09 --> Router Class Initialized
INFO - 2022-07-02 10:27:09 --> Output Class Initialized
INFO - 2022-07-02 10:27:09 --> Security Class Initialized
DEBUG - 2022-07-02 10:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:27:09 --> Input Class Initialized
INFO - 2022-07-02 10:27:09 --> Language Class Initialized
INFO - 2022-07-02 10:27:09 --> Language Class Initialized
INFO - 2022-07-02 10:27:09 --> Config Class Initialized
INFO - 2022-07-02 10:27:09 --> Loader Class Initialized
INFO - 2022-07-02 10:27:09 --> Helper loaded: url_helper
INFO - 2022-07-02 10:27:09 --> Helper loaded: file_helper
INFO - 2022-07-02 10:27:09 --> Helper loaded: form_helper
INFO - 2022-07-02 10:27:09 --> Helper loaded: my_helper
INFO - 2022-07-02 10:27:09 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:27:09 --> Controller Class Initialized
INFO - 2022-07-02 10:27:09 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:27:09 --> Config Class Initialized
INFO - 2022-07-02 10:27:09 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:27:09 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:27:09 --> Utf8 Class Initialized
INFO - 2022-07-02 10:27:09 --> URI Class Initialized
INFO - 2022-07-02 10:27:09 --> Router Class Initialized
INFO - 2022-07-02 10:27:09 --> Output Class Initialized
INFO - 2022-07-02 10:27:09 --> Security Class Initialized
DEBUG - 2022-07-02 10:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:27:09 --> Input Class Initialized
INFO - 2022-07-02 10:27:09 --> Language Class Initialized
INFO - 2022-07-02 10:27:09 --> Language Class Initialized
INFO - 2022-07-02 10:27:09 --> Config Class Initialized
INFO - 2022-07-02 10:27:09 --> Loader Class Initialized
INFO - 2022-07-02 10:27:09 --> Helper loaded: url_helper
INFO - 2022-07-02 10:27:09 --> Helper loaded: file_helper
INFO - 2022-07-02 10:27:09 --> Helper loaded: form_helper
INFO - 2022-07-02 10:27:09 --> Helper loaded: my_helper
INFO - 2022-07-02 10:27:09 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:27:09 --> Controller Class Initialized
DEBUG - 2022-07-02 10:27:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-02 10:27:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:27:09 --> Final output sent to browser
DEBUG - 2022-07-02 10:27:09 --> Total execution time: 0.0409
INFO - 2022-07-02 10:27:29 --> Config Class Initialized
INFO - 2022-07-02 10:27:29 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:27:29 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:27:29 --> Utf8 Class Initialized
INFO - 2022-07-02 10:27:29 --> URI Class Initialized
INFO - 2022-07-02 10:27:29 --> Router Class Initialized
INFO - 2022-07-02 10:27:29 --> Output Class Initialized
INFO - 2022-07-02 10:27:29 --> Security Class Initialized
DEBUG - 2022-07-02 10:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:27:29 --> Input Class Initialized
INFO - 2022-07-02 10:27:29 --> Language Class Initialized
INFO - 2022-07-02 10:27:29 --> Language Class Initialized
INFO - 2022-07-02 10:27:29 --> Config Class Initialized
INFO - 2022-07-02 10:27:29 --> Loader Class Initialized
INFO - 2022-07-02 10:27:29 --> Helper loaded: url_helper
INFO - 2022-07-02 10:27:29 --> Helper loaded: file_helper
INFO - 2022-07-02 10:27:29 --> Helper loaded: form_helper
INFO - 2022-07-02 10:27:29 --> Helper loaded: my_helper
INFO - 2022-07-02 10:27:29 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:27:29 --> Controller Class Initialized
INFO - 2022-07-02 10:27:29 --> Helper loaded: cookie_helper
INFO - 2022-07-02 10:27:29 --> Final output sent to browser
DEBUG - 2022-07-02 10:27:29 --> Total execution time: 0.0460
INFO - 2022-07-02 10:27:30 --> Config Class Initialized
INFO - 2022-07-02 10:27:30 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:27:30 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:27:30 --> Utf8 Class Initialized
INFO - 2022-07-02 10:27:30 --> URI Class Initialized
INFO - 2022-07-02 10:27:30 --> Router Class Initialized
INFO - 2022-07-02 10:27:30 --> Output Class Initialized
INFO - 2022-07-02 10:27:30 --> Security Class Initialized
DEBUG - 2022-07-02 10:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:27:30 --> Input Class Initialized
INFO - 2022-07-02 10:27:30 --> Language Class Initialized
INFO - 2022-07-02 10:27:30 --> Language Class Initialized
INFO - 2022-07-02 10:27:30 --> Config Class Initialized
INFO - 2022-07-02 10:27:30 --> Loader Class Initialized
INFO - 2022-07-02 10:27:30 --> Helper loaded: url_helper
INFO - 2022-07-02 10:27:30 --> Helper loaded: file_helper
INFO - 2022-07-02 10:27:30 --> Helper loaded: form_helper
INFO - 2022-07-02 10:27:30 --> Helper loaded: my_helper
INFO - 2022-07-02 10:27:30 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:27:30 --> Controller Class Initialized
DEBUG - 2022-07-02 10:27:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:27:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:27:31 --> Final output sent to browser
DEBUG - 2022-07-02 10:27:31 --> Total execution time: 0.5587
INFO - 2022-07-02 10:28:14 --> Config Class Initialized
INFO - 2022-07-02 10:28:14 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:28:14 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:28:14 --> Utf8 Class Initialized
INFO - 2022-07-02 10:28:14 --> URI Class Initialized
DEBUG - 2022-07-02 10:28:14 --> No URI present. Default controller set.
INFO - 2022-07-02 10:28:14 --> Router Class Initialized
INFO - 2022-07-02 10:28:14 --> Output Class Initialized
INFO - 2022-07-02 10:28:14 --> Security Class Initialized
DEBUG - 2022-07-02 10:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:28:14 --> Input Class Initialized
INFO - 2022-07-02 10:28:14 --> Language Class Initialized
INFO - 2022-07-02 10:28:14 --> Language Class Initialized
INFO - 2022-07-02 10:28:14 --> Config Class Initialized
INFO - 2022-07-02 10:28:14 --> Loader Class Initialized
INFO - 2022-07-02 10:28:14 --> Helper loaded: url_helper
INFO - 2022-07-02 10:28:14 --> Helper loaded: file_helper
INFO - 2022-07-02 10:28:14 --> Helper loaded: form_helper
INFO - 2022-07-02 10:28:14 --> Helper loaded: my_helper
INFO - 2022-07-02 10:28:14 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:28:14 --> Controller Class Initialized
DEBUG - 2022-07-02 10:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:28:14 --> Final output sent to browser
DEBUG - 2022-07-02 10:28:14 --> Total execution time: 0.5510
INFO - 2022-07-02 10:28:14 --> Config Class Initialized
INFO - 2022-07-02 10:28:14 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:28:14 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:28:14 --> Utf8 Class Initialized
INFO - 2022-07-02 10:28:14 --> URI Class Initialized
DEBUG - 2022-07-02 10:28:14 --> No URI present. Default controller set.
INFO - 2022-07-02 10:28:14 --> Router Class Initialized
INFO - 2022-07-02 10:28:14 --> Output Class Initialized
INFO - 2022-07-02 10:28:14 --> Security Class Initialized
DEBUG - 2022-07-02 10:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:28:14 --> Input Class Initialized
INFO - 2022-07-02 10:28:14 --> Language Class Initialized
INFO - 2022-07-02 10:28:14 --> Language Class Initialized
INFO - 2022-07-02 10:28:14 --> Config Class Initialized
INFO - 2022-07-02 10:28:14 --> Loader Class Initialized
INFO - 2022-07-02 10:28:14 --> Helper loaded: url_helper
INFO - 2022-07-02 10:28:14 --> Helper loaded: file_helper
INFO - 2022-07-02 10:28:14 --> Helper loaded: form_helper
INFO - 2022-07-02 10:28:14 --> Helper loaded: my_helper
INFO - 2022-07-02 10:28:14 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:28:14 --> Controller Class Initialized
DEBUG - 2022-07-02 10:28:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-02 10:28:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:28:15 --> Final output sent to browser
DEBUG - 2022-07-02 10:28:15 --> Total execution time: 0.5254
INFO - 2022-07-02 10:28:24 --> Config Class Initialized
INFO - 2022-07-02 10:28:24 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:28:24 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:28:24 --> Utf8 Class Initialized
INFO - 2022-07-02 10:28:24 --> URI Class Initialized
INFO - 2022-07-02 10:28:24 --> Router Class Initialized
INFO - 2022-07-02 10:28:24 --> Output Class Initialized
INFO - 2022-07-02 10:28:24 --> Security Class Initialized
DEBUG - 2022-07-02 10:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:28:24 --> Input Class Initialized
INFO - 2022-07-02 10:28:24 --> Language Class Initialized
INFO - 2022-07-02 10:28:24 --> Language Class Initialized
INFO - 2022-07-02 10:28:24 --> Config Class Initialized
INFO - 2022-07-02 10:28:24 --> Loader Class Initialized
INFO - 2022-07-02 10:28:24 --> Helper loaded: url_helper
INFO - 2022-07-02 10:28:24 --> Helper loaded: file_helper
INFO - 2022-07-02 10:28:24 --> Helper loaded: form_helper
INFO - 2022-07-02 10:28:24 --> Helper loaded: my_helper
INFO - 2022-07-02 10:28:24 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:28:24 --> Controller Class Initialized
DEBUG - 2022-07-02 10:28:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-02 10:28:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:28:24 --> Final output sent to browser
DEBUG - 2022-07-02 10:28:24 --> Total execution time: 0.1729
INFO - 2022-07-02 10:28:24 --> Config Class Initialized
INFO - 2022-07-02 10:28:24 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:28:24 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:28:24 --> Utf8 Class Initialized
INFO - 2022-07-02 10:28:24 --> URI Class Initialized
INFO - 2022-07-02 10:28:24 --> Router Class Initialized
INFO - 2022-07-02 10:28:24 --> Output Class Initialized
INFO - 2022-07-02 10:28:24 --> Security Class Initialized
DEBUG - 2022-07-02 10:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:28:24 --> Input Class Initialized
INFO - 2022-07-02 10:28:24 --> Language Class Initialized
INFO - 2022-07-02 10:28:24 --> Language Class Initialized
INFO - 2022-07-02 10:28:24 --> Config Class Initialized
INFO - 2022-07-02 10:28:24 --> Loader Class Initialized
INFO - 2022-07-02 10:28:24 --> Helper loaded: url_helper
INFO - 2022-07-02 10:28:24 --> Helper loaded: file_helper
INFO - 2022-07-02 10:28:24 --> Helper loaded: form_helper
INFO - 2022-07-02 10:28:24 --> Helper loaded: my_helper
INFO - 2022-07-02 10:28:24 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:28:24 --> Controller Class Initialized
DEBUG - 2022-07-02 10:28:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-02 10:28:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:28:24 --> Final output sent to browser
DEBUG - 2022-07-02 10:28:24 --> Total execution time: 0.0844
INFO - 2022-07-02 10:28:44 --> Config Class Initialized
INFO - 2022-07-02 10:28:44 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:28:44 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:28:44 --> Utf8 Class Initialized
INFO - 2022-07-02 10:28:44 --> URI Class Initialized
INFO - 2022-07-02 10:28:44 --> Router Class Initialized
INFO - 2022-07-02 10:28:44 --> Output Class Initialized
INFO - 2022-07-02 10:28:44 --> Security Class Initialized
DEBUG - 2022-07-02 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:28:44 --> Input Class Initialized
INFO - 2022-07-02 10:28:44 --> Language Class Initialized
INFO - 2022-07-02 10:28:44 --> Language Class Initialized
INFO - 2022-07-02 10:28:44 --> Config Class Initialized
INFO - 2022-07-02 10:28:44 --> Loader Class Initialized
INFO - 2022-07-02 10:28:44 --> Helper loaded: url_helper
INFO - 2022-07-02 10:28:44 --> Helper loaded: file_helper
INFO - 2022-07-02 10:28:44 --> Helper loaded: form_helper
INFO - 2022-07-02 10:28:44 --> Helper loaded: my_helper
INFO - 2022-07-02 10:28:44 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:28:44 --> Controller Class Initialized
DEBUG - 2022-07-02 10:28:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-02 10:28:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:28:44 --> Final output sent to browser
DEBUG - 2022-07-02 10:28:44 --> Total execution time: 0.0890
INFO - 2022-07-02 10:33:53 --> Config Class Initialized
INFO - 2022-07-02 10:33:53 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:33:53 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:33:53 --> Utf8 Class Initialized
INFO - 2022-07-02 10:33:53 --> URI Class Initialized
INFO - 2022-07-02 10:33:53 --> Router Class Initialized
INFO - 2022-07-02 10:33:53 --> Output Class Initialized
INFO - 2022-07-02 10:33:53 --> Security Class Initialized
DEBUG - 2022-07-02 10:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:33:53 --> Input Class Initialized
INFO - 2022-07-02 10:33:53 --> Language Class Initialized
INFO - 2022-07-02 10:33:53 --> Language Class Initialized
INFO - 2022-07-02 10:33:53 --> Config Class Initialized
INFO - 2022-07-02 10:33:53 --> Loader Class Initialized
INFO - 2022-07-02 10:33:53 --> Helper loaded: url_helper
INFO - 2022-07-02 10:33:53 --> Helper loaded: file_helper
INFO - 2022-07-02 10:33:53 --> Helper loaded: form_helper
INFO - 2022-07-02 10:33:53 --> Helper loaded: my_helper
INFO - 2022-07-02 10:33:53 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:33:54 --> Controller Class Initialized
INFO - 2022-07-02 10:33:54 --> Final output sent to browser
DEBUG - 2022-07-02 10:33:54 --> Total execution time: 0.1020
INFO - 2022-07-02 10:33:58 --> Config Class Initialized
INFO - 2022-07-02 10:33:58 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:33:58 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:33:58 --> Utf8 Class Initialized
INFO - 2022-07-02 10:33:58 --> URI Class Initialized
INFO - 2022-07-02 10:33:58 --> Router Class Initialized
INFO - 2022-07-02 10:33:58 --> Output Class Initialized
INFO - 2022-07-02 10:33:58 --> Security Class Initialized
DEBUG - 2022-07-02 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:33:58 --> Input Class Initialized
INFO - 2022-07-02 10:33:58 --> Language Class Initialized
INFO - 2022-07-02 10:33:58 --> Language Class Initialized
INFO - 2022-07-02 10:33:58 --> Config Class Initialized
INFO - 2022-07-02 10:33:58 --> Loader Class Initialized
INFO - 2022-07-02 10:33:58 --> Helper loaded: url_helper
INFO - 2022-07-02 10:33:58 --> Helper loaded: file_helper
INFO - 2022-07-02 10:33:58 --> Helper loaded: form_helper
INFO - 2022-07-02 10:33:58 --> Helper loaded: my_helper
INFO - 2022-07-02 10:33:58 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:33:58 --> Controller Class Initialized
DEBUG - 2022-07-02 10:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-07-02 10:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:33:58 --> Final output sent to browser
DEBUG - 2022-07-02 10:33:58 --> Total execution time: 0.1009
INFO - 2022-07-02 10:41:37 --> Config Class Initialized
INFO - 2022-07-02 10:41:37 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:41:38 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:41:38 --> Utf8 Class Initialized
INFO - 2022-07-02 10:41:38 --> URI Class Initialized
INFO - 2022-07-02 10:41:38 --> Router Class Initialized
INFO - 2022-07-02 10:41:38 --> Output Class Initialized
INFO - 2022-07-02 10:41:38 --> Security Class Initialized
DEBUG - 2022-07-02 10:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:41:38 --> Input Class Initialized
INFO - 2022-07-02 10:41:38 --> Language Class Initialized
INFO - 2022-07-02 10:41:38 --> Language Class Initialized
INFO - 2022-07-02 10:41:38 --> Config Class Initialized
INFO - 2022-07-02 10:41:38 --> Loader Class Initialized
INFO - 2022-07-02 10:41:38 --> Helper loaded: url_helper
INFO - 2022-07-02 10:41:38 --> Helper loaded: file_helper
INFO - 2022-07-02 10:41:38 --> Helper loaded: form_helper
INFO - 2022-07-02 10:41:38 --> Helper loaded: my_helper
INFO - 2022-07-02 10:41:38 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:41:38 --> Controller Class Initialized
INFO - 2022-07-02 10:41:38 --> Final output sent to browser
DEBUG - 2022-07-02 10:41:38 --> Total execution time: 0.0936
INFO - 2022-07-02 10:41:41 --> Config Class Initialized
INFO - 2022-07-02 10:41:41 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:41:41 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:41:41 --> Utf8 Class Initialized
INFO - 2022-07-02 10:41:41 --> URI Class Initialized
INFO - 2022-07-02 10:41:41 --> Router Class Initialized
INFO - 2022-07-02 10:41:41 --> Output Class Initialized
INFO - 2022-07-02 10:41:41 --> Security Class Initialized
DEBUG - 2022-07-02 10:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:41:41 --> Input Class Initialized
INFO - 2022-07-02 10:41:41 --> Language Class Initialized
INFO - 2022-07-02 10:41:41 --> Language Class Initialized
INFO - 2022-07-02 10:41:41 --> Config Class Initialized
INFO - 2022-07-02 10:41:41 --> Loader Class Initialized
INFO - 2022-07-02 10:41:41 --> Helper loaded: url_helper
INFO - 2022-07-02 10:41:41 --> Helper loaded: file_helper
INFO - 2022-07-02 10:41:41 --> Helper loaded: form_helper
INFO - 2022-07-02 10:41:41 --> Helper loaded: my_helper
INFO - 2022-07-02 10:41:41 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:41:41 --> Controller Class Initialized
DEBUG - 2022-07-02 10:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-02 10:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:41:41 --> Final output sent to browser
DEBUG - 2022-07-02 10:41:41 --> Total execution time: 0.1117
INFO - 2022-07-02 10:41:41 --> Config Class Initialized
INFO - 2022-07-02 10:41:41 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:41:41 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:41:41 --> Utf8 Class Initialized
INFO - 2022-07-02 10:41:41 --> URI Class Initialized
INFO - 2022-07-02 10:41:41 --> Router Class Initialized
INFO - 2022-07-02 10:41:41 --> Output Class Initialized
INFO - 2022-07-02 10:41:41 --> Security Class Initialized
DEBUG - 2022-07-02 10:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:41:41 --> Input Class Initialized
INFO - 2022-07-02 10:41:41 --> Language Class Initialized
INFO - 2022-07-02 10:41:41 --> Language Class Initialized
INFO - 2022-07-02 10:41:41 --> Config Class Initialized
INFO - 2022-07-02 10:41:41 --> Loader Class Initialized
INFO - 2022-07-02 10:41:41 --> Helper loaded: url_helper
INFO - 2022-07-02 10:41:41 --> Helper loaded: file_helper
INFO - 2022-07-02 10:41:41 --> Helper loaded: form_helper
INFO - 2022-07-02 10:41:41 --> Helper loaded: my_helper
INFO - 2022-07-02 10:41:41 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:41:41 --> Controller Class Initialized
DEBUG - 2022-07-02 10:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-02 10:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-02 10:41:41 --> Final output sent to browser
DEBUG - 2022-07-02 10:41:41 --> Total execution time: 0.0847
INFO - 2022-07-02 10:43:05 --> Config Class Initialized
INFO - 2022-07-02 10:43:05 --> Hooks Class Initialized
DEBUG - 2022-07-02 10:43:05 --> UTF-8 Support Enabled
INFO - 2022-07-02 10:43:05 --> Utf8 Class Initialized
INFO - 2022-07-02 10:43:05 --> URI Class Initialized
INFO - 2022-07-02 10:43:05 --> Router Class Initialized
INFO - 2022-07-02 10:43:05 --> Output Class Initialized
INFO - 2022-07-02 10:43:05 --> Security Class Initialized
DEBUG - 2022-07-02 10:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-02 10:43:05 --> Input Class Initialized
INFO - 2022-07-02 10:43:05 --> Language Class Initialized
INFO - 2022-07-02 10:43:05 --> Language Class Initialized
INFO - 2022-07-02 10:43:05 --> Config Class Initialized
INFO - 2022-07-02 10:43:05 --> Loader Class Initialized
INFO - 2022-07-02 10:43:05 --> Helper loaded: url_helper
INFO - 2022-07-02 10:43:05 --> Helper loaded: file_helper
INFO - 2022-07-02 10:43:05 --> Helper loaded: form_helper
INFO - 2022-07-02 10:43:05 --> Helper loaded: my_helper
INFO - 2022-07-02 10:43:05 --> Database Driver Class Initialized
DEBUG - 2022-07-02 10:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-02 10:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-02 10:43:05 --> Controller Class Initialized
INFO - 2022-07-02 10:43:05 --> Final output sent to browser
DEBUG - 2022-07-02 10:43:05 --> Total execution time: 0.1426
