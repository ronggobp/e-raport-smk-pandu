<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-30 02:24:38 --> Config Class Initialized
INFO - 2020-11-30 02:24:38 --> Hooks Class Initialized
DEBUG - 2020-11-30 02:24:38 --> UTF-8 Support Enabled
INFO - 2020-11-30 02:24:38 --> Utf8 Class Initialized
INFO - 2020-11-30 02:24:38 --> URI Class Initialized
DEBUG - 2020-11-30 02:24:39 --> No URI present. Default controller set.
INFO - 2020-11-30 02:24:39 --> Router Class Initialized
INFO - 2020-11-30 02:24:39 --> Output Class Initialized
INFO - 2020-11-30 02:24:39 --> Security Class Initialized
DEBUG - 2020-11-30 02:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 02:24:39 --> Input Class Initialized
INFO - 2020-11-30 02:24:39 --> Language Class Initialized
INFO - 2020-11-30 02:24:39 --> Language Class Initialized
INFO - 2020-11-30 02:24:39 --> Config Class Initialized
INFO - 2020-11-30 02:24:39 --> Loader Class Initialized
INFO - 2020-11-30 02:24:39 --> Helper loaded: url_helper
INFO - 2020-11-30 02:24:39 --> Helper loaded: file_helper
INFO - 2020-11-30 02:24:39 --> Helper loaded: form_helper
INFO - 2020-11-30 02:24:39 --> Helper loaded: my_helper
INFO - 2020-11-30 02:24:39 --> Database Driver Class Initialized
DEBUG - 2020-11-30 02:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 02:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 02:24:39 --> Controller Class Initialized
INFO - 2020-11-30 02:24:39 --> Config Class Initialized
INFO - 2020-11-30 02:24:39 --> Hooks Class Initialized
DEBUG - 2020-11-30 02:24:39 --> UTF-8 Support Enabled
INFO - 2020-11-30 02:24:39 --> Utf8 Class Initialized
INFO - 2020-11-30 02:24:39 --> URI Class Initialized
INFO - 2020-11-30 02:24:39 --> Router Class Initialized
INFO - 2020-11-30 02:24:39 --> Output Class Initialized
INFO - 2020-11-30 02:24:39 --> Security Class Initialized
DEBUG - 2020-11-30 02:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 02:24:39 --> Input Class Initialized
INFO - 2020-11-30 02:24:39 --> Language Class Initialized
INFO - 2020-11-30 02:24:40 --> Language Class Initialized
INFO - 2020-11-30 02:24:40 --> Config Class Initialized
INFO - 2020-11-30 02:24:40 --> Loader Class Initialized
INFO - 2020-11-30 02:24:40 --> Helper loaded: url_helper
INFO - 2020-11-30 02:24:40 --> Helper loaded: file_helper
INFO - 2020-11-30 02:24:40 --> Helper loaded: form_helper
INFO - 2020-11-30 02:24:40 --> Helper loaded: my_helper
INFO - 2020-11-30 02:24:40 --> Database Driver Class Initialized
DEBUG - 2020-11-30 02:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 02:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 02:24:40 --> Controller Class Initialized
DEBUG - 2020-11-30 02:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-30 02:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 02:24:40 --> Final output sent to browser
DEBUG - 2020-11-30 02:24:40 --> Total execution time: 0.3482
INFO - 2020-11-30 02:55:51 --> Config Class Initialized
INFO - 2020-11-30 02:55:51 --> Hooks Class Initialized
DEBUG - 2020-11-30 02:55:51 --> UTF-8 Support Enabled
INFO - 2020-11-30 02:55:51 --> Utf8 Class Initialized
INFO - 2020-11-30 02:55:51 --> URI Class Initialized
INFO - 2020-11-30 02:55:51 --> Router Class Initialized
INFO - 2020-11-30 02:55:51 --> Output Class Initialized
INFO - 2020-11-30 02:55:51 --> Security Class Initialized
DEBUG - 2020-11-30 02:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 02:55:51 --> Input Class Initialized
INFO - 2020-11-30 02:55:51 --> Language Class Initialized
INFO - 2020-11-30 02:55:51 --> Language Class Initialized
INFO - 2020-11-30 02:55:51 --> Config Class Initialized
INFO - 2020-11-30 02:55:51 --> Loader Class Initialized
INFO - 2020-11-30 02:55:51 --> Helper loaded: url_helper
INFO - 2020-11-30 02:55:51 --> Helper loaded: file_helper
INFO - 2020-11-30 02:55:51 --> Helper loaded: form_helper
INFO - 2020-11-30 02:55:51 --> Helper loaded: my_helper
INFO - 2020-11-30 02:55:51 --> Database Driver Class Initialized
DEBUG - 2020-11-30 02:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 02:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 02:55:51 --> Controller Class Initialized
INFO - 2020-11-30 02:55:51 --> Helper loaded: cookie_helper
INFO - 2020-11-30 02:55:51 --> Final output sent to browser
DEBUG - 2020-11-30 02:55:51 --> Total execution time: 0.4804
INFO - 2020-11-30 02:55:52 --> Config Class Initialized
INFO - 2020-11-30 02:55:52 --> Hooks Class Initialized
DEBUG - 2020-11-30 02:55:52 --> UTF-8 Support Enabled
INFO - 2020-11-30 02:55:52 --> Utf8 Class Initialized
INFO - 2020-11-30 02:55:52 --> URI Class Initialized
INFO - 2020-11-30 02:55:52 --> Router Class Initialized
INFO - 2020-11-30 02:55:52 --> Output Class Initialized
INFO - 2020-11-30 02:55:52 --> Security Class Initialized
DEBUG - 2020-11-30 02:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 02:55:52 --> Input Class Initialized
INFO - 2020-11-30 02:55:52 --> Language Class Initialized
INFO - 2020-11-30 02:55:52 --> Language Class Initialized
INFO - 2020-11-30 02:55:53 --> Config Class Initialized
INFO - 2020-11-30 02:55:53 --> Loader Class Initialized
INFO - 2020-11-30 02:55:53 --> Helper loaded: url_helper
INFO - 2020-11-30 02:55:53 --> Helper loaded: file_helper
INFO - 2020-11-30 02:55:53 --> Helper loaded: form_helper
INFO - 2020-11-30 02:55:53 --> Helper loaded: my_helper
INFO - 2020-11-30 02:55:53 --> Database Driver Class Initialized
DEBUG - 2020-11-30 02:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 02:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 02:55:53 --> Controller Class Initialized
DEBUG - 2020-11-30 02:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-30 02:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 02:55:53 --> Final output sent to browser
DEBUG - 2020-11-30 02:55:53 --> Total execution time: 0.3286
INFO - 2020-11-30 03:02:11 --> Config Class Initialized
INFO - 2020-11-30 03:02:11 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:02:11 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:02:11 --> Utf8 Class Initialized
INFO - 2020-11-30 03:02:11 --> URI Class Initialized
INFO - 2020-11-30 03:02:11 --> Router Class Initialized
INFO - 2020-11-30 03:02:11 --> Output Class Initialized
INFO - 2020-11-30 03:02:11 --> Security Class Initialized
DEBUG - 2020-11-30 03:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:02:11 --> Input Class Initialized
INFO - 2020-11-30 03:02:11 --> Language Class Initialized
INFO - 2020-11-30 03:02:11 --> Language Class Initialized
INFO - 2020-11-30 03:02:11 --> Config Class Initialized
INFO - 2020-11-30 03:02:11 --> Loader Class Initialized
INFO - 2020-11-30 03:02:11 --> Helper loaded: url_helper
INFO - 2020-11-30 03:02:11 --> Helper loaded: file_helper
INFO - 2020-11-30 03:02:11 --> Helper loaded: form_helper
INFO - 2020-11-30 03:02:12 --> Helper loaded: my_helper
INFO - 2020-11-30 03:02:12 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:02:12 --> Controller Class Initialized
DEBUG - 2020-11-30 03:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-30 03:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 03:02:12 --> Final output sent to browser
DEBUG - 2020-11-30 03:02:12 --> Total execution time: 0.3696
INFO - 2020-11-30 03:02:13 --> Config Class Initialized
INFO - 2020-11-30 03:02:13 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:02:13 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:02:13 --> Utf8 Class Initialized
INFO - 2020-11-30 03:02:13 --> URI Class Initialized
INFO - 2020-11-30 03:02:13 --> Router Class Initialized
INFO - 2020-11-30 03:02:13 --> Output Class Initialized
INFO - 2020-11-30 03:02:13 --> Security Class Initialized
DEBUG - 2020-11-30 03:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:02:13 --> Input Class Initialized
INFO - 2020-11-30 03:02:13 --> Language Class Initialized
INFO - 2020-11-30 03:02:13 --> Language Class Initialized
INFO - 2020-11-30 03:02:13 --> Config Class Initialized
INFO - 2020-11-30 03:02:13 --> Loader Class Initialized
INFO - 2020-11-30 03:02:13 --> Helper loaded: url_helper
INFO - 2020-11-30 03:02:13 --> Helper loaded: file_helper
INFO - 2020-11-30 03:02:13 --> Helper loaded: form_helper
INFO - 2020-11-30 03:02:13 --> Helper loaded: my_helper
INFO - 2020-11-30 03:02:13 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:02:13 --> Controller Class Initialized
DEBUG - 2020-11-30 03:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-30 03:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 03:02:13 --> Final output sent to browser
DEBUG - 2020-11-30 03:02:13 --> Total execution time: 0.2372
INFO - 2020-11-30 03:02:19 --> Config Class Initialized
INFO - 2020-11-30 03:02:19 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:02:19 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:02:19 --> Utf8 Class Initialized
INFO - 2020-11-30 03:02:19 --> URI Class Initialized
INFO - 2020-11-30 03:02:19 --> Router Class Initialized
INFO - 2020-11-30 03:02:19 --> Output Class Initialized
INFO - 2020-11-30 03:02:19 --> Security Class Initialized
DEBUG - 2020-11-30 03:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:02:19 --> Input Class Initialized
INFO - 2020-11-30 03:02:19 --> Language Class Initialized
INFO - 2020-11-30 03:02:19 --> Language Class Initialized
INFO - 2020-11-30 03:02:19 --> Config Class Initialized
INFO - 2020-11-30 03:02:19 --> Loader Class Initialized
INFO - 2020-11-30 03:02:19 --> Helper loaded: url_helper
INFO - 2020-11-30 03:02:19 --> Helper loaded: file_helper
INFO - 2020-11-30 03:02:19 --> Helper loaded: form_helper
INFO - 2020-11-30 03:02:19 --> Helper loaded: my_helper
INFO - 2020-11-30 03:02:19 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:02:19 --> Controller Class Initialized
DEBUG - 2020-11-30 03:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-30 03:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 03:02:19 --> Final output sent to browser
DEBUG - 2020-11-30 03:02:19 --> Total execution time: 0.1834
INFO - 2020-11-30 03:02:33 --> Config Class Initialized
INFO - 2020-11-30 03:02:33 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:02:33 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:02:33 --> Utf8 Class Initialized
INFO - 2020-11-30 03:02:33 --> URI Class Initialized
INFO - 2020-11-30 03:02:33 --> Router Class Initialized
INFO - 2020-11-30 03:02:33 --> Output Class Initialized
INFO - 2020-11-30 03:02:33 --> Security Class Initialized
DEBUG - 2020-11-30 03:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:02:33 --> Input Class Initialized
INFO - 2020-11-30 03:02:33 --> Language Class Initialized
INFO - 2020-11-30 03:02:33 --> Language Class Initialized
INFO - 2020-11-30 03:02:33 --> Config Class Initialized
INFO - 2020-11-30 03:02:33 --> Loader Class Initialized
INFO - 2020-11-30 03:02:33 --> Helper loaded: url_helper
INFO - 2020-11-30 03:02:33 --> Helper loaded: file_helper
INFO - 2020-11-30 03:02:33 --> Helper loaded: form_helper
INFO - 2020-11-30 03:02:33 --> Helper loaded: my_helper
INFO - 2020-11-30 03:02:33 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:02:33 --> Controller Class Initialized
DEBUG - 2020-11-30 03:02:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/cetak.php
INFO - 2020-11-30 03:02:33 --> Final output sent to browser
DEBUG - 2020-11-30 03:02:33 --> Total execution time: 0.2002
INFO - 2020-11-30 03:03:54 --> Config Class Initialized
INFO - 2020-11-30 03:03:54 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:03:54 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:03:54 --> Utf8 Class Initialized
INFO - 2020-11-30 03:03:54 --> URI Class Initialized
INFO - 2020-11-30 03:03:54 --> Router Class Initialized
INFO - 2020-11-30 03:03:54 --> Output Class Initialized
INFO - 2020-11-30 03:03:54 --> Security Class Initialized
DEBUG - 2020-11-30 03:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:03:54 --> Input Class Initialized
INFO - 2020-11-30 03:03:54 --> Language Class Initialized
INFO - 2020-11-30 03:03:54 --> Language Class Initialized
INFO - 2020-11-30 03:03:54 --> Config Class Initialized
INFO - 2020-11-30 03:03:54 --> Loader Class Initialized
INFO - 2020-11-30 03:03:54 --> Helper loaded: url_helper
INFO - 2020-11-30 03:03:54 --> Helper loaded: file_helper
INFO - 2020-11-30 03:03:54 --> Helper loaded: form_helper
INFO - 2020-11-30 03:03:54 --> Helper loaded: my_helper
INFO - 2020-11-30 03:03:54 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:03:54 --> Controller Class Initialized
INFO - 2020-11-30 03:03:54 --> Final output sent to browser
DEBUG - 2020-11-30 03:03:54 --> Total execution time: 0.1765
INFO - 2020-11-30 03:08:14 --> Config Class Initialized
INFO - 2020-11-30 03:08:14 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:08:14 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:08:14 --> Utf8 Class Initialized
INFO - 2020-11-30 03:08:14 --> URI Class Initialized
INFO - 2020-11-30 03:08:14 --> Router Class Initialized
INFO - 2020-11-30 03:08:14 --> Output Class Initialized
INFO - 2020-11-30 03:08:14 --> Security Class Initialized
DEBUG - 2020-11-30 03:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:08:14 --> Input Class Initialized
INFO - 2020-11-30 03:08:14 --> Language Class Initialized
INFO - 2020-11-30 03:08:14 --> Language Class Initialized
INFO - 2020-11-30 03:08:14 --> Config Class Initialized
INFO - 2020-11-30 03:08:14 --> Loader Class Initialized
INFO - 2020-11-30 03:08:14 --> Helper loaded: url_helper
INFO - 2020-11-30 03:08:14 --> Helper loaded: file_helper
INFO - 2020-11-30 03:08:14 --> Helper loaded: form_helper
INFO - 2020-11-30 03:08:14 --> Helper loaded: my_helper
INFO - 2020-11-30 03:08:14 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:08:14 --> Controller Class Initialized
DEBUG - 2020-11-30 03:08:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-30 03:08:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 03:08:14 --> Final output sent to browser
DEBUG - 2020-11-30 03:08:14 --> Total execution time: 0.1811
INFO - 2020-11-30 03:08:53 --> Config Class Initialized
INFO - 2020-11-30 03:08:53 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:08:53 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:08:53 --> Utf8 Class Initialized
INFO - 2020-11-30 03:08:53 --> URI Class Initialized
INFO - 2020-11-30 03:08:53 --> Router Class Initialized
INFO - 2020-11-30 03:08:53 --> Output Class Initialized
INFO - 2020-11-30 03:08:53 --> Security Class Initialized
DEBUG - 2020-11-30 03:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:08:53 --> Input Class Initialized
INFO - 2020-11-30 03:08:53 --> Language Class Initialized
INFO - 2020-11-30 03:08:53 --> Language Class Initialized
INFO - 2020-11-30 03:08:53 --> Config Class Initialized
INFO - 2020-11-30 03:08:53 --> Loader Class Initialized
INFO - 2020-11-30 03:08:53 --> Helper loaded: url_helper
INFO - 2020-11-30 03:08:53 --> Helper loaded: file_helper
INFO - 2020-11-30 03:08:53 --> Helper loaded: form_helper
INFO - 2020-11-30 03:08:53 --> Helper loaded: my_helper
INFO - 2020-11-30 03:08:53 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:08:53 --> Controller Class Initialized
DEBUG - 2020-11-30 03:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-30 03:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 03:08:53 --> Final output sent to browser
DEBUG - 2020-11-30 03:08:53 --> Total execution time: 0.1904
INFO - 2020-11-30 03:27:57 --> Config Class Initialized
INFO - 2020-11-30 03:27:57 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:27:57 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:27:57 --> Utf8 Class Initialized
INFO - 2020-11-30 03:27:57 --> URI Class Initialized
INFO - 2020-11-30 03:27:57 --> Router Class Initialized
INFO - 2020-11-30 03:27:57 --> Output Class Initialized
INFO - 2020-11-30 03:27:57 --> Security Class Initialized
DEBUG - 2020-11-30 03:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:27:57 --> Input Class Initialized
INFO - 2020-11-30 03:27:57 --> Language Class Initialized
INFO - 2020-11-30 03:27:57 --> Language Class Initialized
INFO - 2020-11-30 03:27:57 --> Config Class Initialized
INFO - 2020-11-30 03:27:57 --> Loader Class Initialized
INFO - 2020-11-30 03:27:57 --> Helper loaded: url_helper
INFO - 2020-11-30 03:27:57 --> Helper loaded: file_helper
INFO - 2020-11-30 03:27:57 --> Helper loaded: form_helper
INFO - 2020-11-30 03:27:57 --> Helper loaded: my_helper
INFO - 2020-11-30 03:27:57 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:27:57 --> Controller Class Initialized
DEBUG - 2020-11-30 03:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-30 03:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 03:27:57 --> Final output sent to browser
DEBUG - 2020-11-30 03:27:57 --> Total execution time: 0.2318
INFO - 2020-11-30 03:27:58 --> Config Class Initialized
INFO - 2020-11-30 03:27:58 --> Hooks Class Initialized
DEBUG - 2020-11-30 03:27:58 --> UTF-8 Support Enabled
INFO - 2020-11-30 03:27:58 --> Utf8 Class Initialized
INFO - 2020-11-30 03:27:58 --> URI Class Initialized
INFO - 2020-11-30 03:27:58 --> Router Class Initialized
INFO - 2020-11-30 03:27:58 --> Output Class Initialized
INFO - 2020-11-30 03:27:58 --> Security Class Initialized
DEBUG - 2020-11-30 03:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 03:27:58 --> Input Class Initialized
INFO - 2020-11-30 03:27:58 --> Language Class Initialized
INFO - 2020-11-30 03:27:58 --> Language Class Initialized
INFO - 2020-11-30 03:27:58 --> Config Class Initialized
INFO - 2020-11-30 03:27:58 --> Loader Class Initialized
INFO - 2020-11-30 03:27:58 --> Helper loaded: url_helper
INFO - 2020-11-30 03:27:58 --> Helper loaded: file_helper
INFO - 2020-11-30 03:27:58 --> Helper loaded: form_helper
INFO - 2020-11-30 03:27:58 --> Helper loaded: my_helper
INFO - 2020-11-30 03:27:58 --> Database Driver Class Initialized
DEBUG - 2020-11-30 03:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 03:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 03:27:58 --> Controller Class Initialized
INFO - 2020-11-30 03:27:58 --> Final output sent to browser
DEBUG - 2020-11-30 03:27:58 --> Total execution time: 0.1924
INFO - 2020-11-30 08:18:29 --> Config Class Initialized
INFO - 2020-11-30 08:18:29 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:18:29 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:18:29 --> Utf8 Class Initialized
INFO - 2020-11-30 08:18:29 --> URI Class Initialized
INFO - 2020-11-30 08:18:29 --> Router Class Initialized
INFO - 2020-11-30 08:18:29 --> Output Class Initialized
INFO - 2020-11-30 08:18:29 --> Security Class Initialized
DEBUG - 2020-11-30 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:18:29 --> Input Class Initialized
INFO - 2020-11-30 08:18:29 --> Language Class Initialized
INFO - 2020-11-30 08:18:29 --> Language Class Initialized
INFO - 2020-11-30 08:18:29 --> Config Class Initialized
INFO - 2020-11-30 08:18:29 --> Loader Class Initialized
INFO - 2020-11-30 08:18:29 --> Helper loaded: url_helper
INFO - 2020-11-30 08:18:29 --> Helper loaded: file_helper
INFO - 2020-11-30 08:18:29 --> Helper loaded: form_helper
INFO - 2020-11-30 08:18:29 --> Helper loaded: my_helper
INFO - 2020-11-30 08:18:29 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:18:29 --> Controller Class Initialized
DEBUG - 2020-11-30 08:18:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-30 08:18:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 08:18:29 --> Final output sent to browser
DEBUG - 2020-11-30 08:18:29 --> Total execution time: 0.1872
INFO - 2020-11-30 08:18:31 --> Config Class Initialized
INFO - 2020-11-30 08:18:31 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:18:31 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:18:31 --> Utf8 Class Initialized
INFO - 2020-11-30 08:18:31 --> URI Class Initialized
INFO - 2020-11-30 08:18:31 --> Router Class Initialized
INFO - 2020-11-30 08:18:31 --> Output Class Initialized
INFO - 2020-11-30 08:18:31 --> Security Class Initialized
DEBUG - 2020-11-30 08:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:18:31 --> Input Class Initialized
INFO - 2020-11-30 08:18:31 --> Language Class Initialized
INFO - 2020-11-30 08:18:31 --> Language Class Initialized
INFO - 2020-11-30 08:18:31 --> Config Class Initialized
INFO - 2020-11-30 08:18:31 --> Loader Class Initialized
INFO - 2020-11-30 08:18:31 --> Helper loaded: url_helper
INFO - 2020-11-30 08:18:31 --> Helper loaded: file_helper
INFO - 2020-11-30 08:18:31 --> Helper loaded: form_helper
INFO - 2020-11-30 08:18:31 --> Helper loaded: my_helper
INFO - 2020-11-30 08:18:31 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:18:31 --> Controller Class Initialized
INFO - 2020-11-30 08:18:31 --> Final output sent to browser
DEBUG - 2020-11-30 08:18:31 --> Total execution time: 0.1614
INFO - 2020-11-30 08:23:53 --> Config Class Initialized
INFO - 2020-11-30 08:23:53 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:23:53 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:23:53 --> Utf8 Class Initialized
INFO - 2020-11-30 08:23:53 --> URI Class Initialized
INFO - 2020-11-30 08:23:53 --> Router Class Initialized
INFO - 2020-11-30 08:23:53 --> Output Class Initialized
INFO - 2020-11-30 08:23:53 --> Security Class Initialized
DEBUG - 2020-11-30 08:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:23:53 --> Input Class Initialized
INFO - 2020-11-30 08:23:53 --> Language Class Initialized
INFO - 2020-11-30 08:23:53 --> Language Class Initialized
INFO - 2020-11-30 08:23:53 --> Config Class Initialized
INFO - 2020-11-30 08:23:54 --> Loader Class Initialized
INFO - 2020-11-30 08:23:54 --> Helper loaded: url_helper
INFO - 2020-11-30 08:23:54 --> Helper loaded: file_helper
INFO - 2020-11-30 08:23:54 --> Helper loaded: form_helper
INFO - 2020-11-30 08:23:54 --> Helper loaded: my_helper
INFO - 2020-11-30 08:23:54 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:23:54 --> Controller Class Initialized
DEBUG - 2020-11-30 08:23:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-30 08:23:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 08:23:54 --> Final output sent to browser
DEBUG - 2020-11-30 08:23:54 --> Total execution time: 0.1790
INFO - 2020-11-30 08:23:55 --> Config Class Initialized
INFO - 2020-11-30 08:23:55 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:23:55 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:23:55 --> Utf8 Class Initialized
INFO - 2020-11-30 08:23:55 --> URI Class Initialized
INFO - 2020-11-30 08:23:55 --> Router Class Initialized
INFO - 2020-11-30 08:23:55 --> Output Class Initialized
INFO - 2020-11-30 08:23:55 --> Security Class Initialized
DEBUG - 2020-11-30 08:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:23:55 --> Input Class Initialized
INFO - 2020-11-30 08:23:55 --> Language Class Initialized
INFO - 2020-11-30 08:23:55 --> Language Class Initialized
INFO - 2020-11-30 08:23:55 --> Config Class Initialized
INFO - 2020-11-30 08:23:55 --> Loader Class Initialized
INFO - 2020-11-30 08:23:55 --> Helper loaded: url_helper
INFO - 2020-11-30 08:23:55 --> Helper loaded: file_helper
INFO - 2020-11-30 08:23:55 --> Helper loaded: form_helper
INFO - 2020-11-30 08:23:55 --> Helper loaded: my_helper
INFO - 2020-11-30 08:23:55 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:23:55 --> Controller Class Initialized
INFO - 2020-11-30 08:23:55 --> Final output sent to browser
DEBUG - 2020-11-30 08:23:55 --> Total execution time: 0.1517
INFO - 2020-11-30 08:24:07 --> Config Class Initialized
INFO - 2020-11-30 08:24:07 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:24:07 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:24:07 --> Utf8 Class Initialized
INFO - 2020-11-30 08:24:07 --> URI Class Initialized
INFO - 2020-11-30 08:24:07 --> Router Class Initialized
INFO - 2020-11-30 08:24:07 --> Output Class Initialized
INFO - 2020-11-30 08:24:07 --> Security Class Initialized
DEBUG - 2020-11-30 08:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:24:07 --> Input Class Initialized
INFO - 2020-11-30 08:24:07 --> Language Class Initialized
INFO - 2020-11-30 08:24:07 --> Language Class Initialized
INFO - 2020-11-30 08:24:07 --> Config Class Initialized
INFO - 2020-11-30 08:24:08 --> Loader Class Initialized
INFO - 2020-11-30 08:24:08 --> Helper loaded: url_helper
INFO - 2020-11-30 08:24:08 --> Helper loaded: file_helper
INFO - 2020-11-30 08:24:08 --> Helper loaded: form_helper
INFO - 2020-11-30 08:24:08 --> Helper loaded: my_helper
INFO - 2020-11-30 08:24:08 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:24:08 --> Controller Class Initialized
DEBUG - 2020-11-30 08:24:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-30 08:24:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 08:24:08 --> Final output sent to browser
DEBUG - 2020-11-30 08:24:08 --> Total execution time: 0.1911
INFO - 2020-11-30 08:24:09 --> Config Class Initialized
INFO - 2020-11-30 08:24:09 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:24:09 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:24:09 --> Utf8 Class Initialized
INFO - 2020-11-30 08:24:09 --> URI Class Initialized
INFO - 2020-11-30 08:24:09 --> Router Class Initialized
INFO - 2020-11-30 08:24:09 --> Output Class Initialized
INFO - 2020-11-30 08:24:09 --> Security Class Initialized
DEBUG - 2020-11-30 08:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:24:09 --> Input Class Initialized
INFO - 2020-11-30 08:24:09 --> Language Class Initialized
INFO - 2020-11-30 08:24:09 --> Language Class Initialized
INFO - 2020-11-30 08:24:09 --> Config Class Initialized
INFO - 2020-11-30 08:24:09 --> Loader Class Initialized
INFO - 2020-11-30 08:24:09 --> Helper loaded: url_helper
INFO - 2020-11-30 08:24:09 --> Helper loaded: file_helper
INFO - 2020-11-30 08:24:09 --> Helper loaded: form_helper
INFO - 2020-11-30 08:24:09 --> Helper loaded: my_helper
INFO - 2020-11-30 08:24:09 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:24:09 --> Controller Class Initialized
INFO - 2020-11-30 08:24:09 --> Final output sent to browser
DEBUG - 2020-11-30 08:24:09 --> Total execution time: 0.1802
INFO - 2020-11-30 08:27:03 --> Config Class Initialized
INFO - 2020-11-30 08:27:03 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:27:03 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:27:03 --> Utf8 Class Initialized
INFO - 2020-11-30 08:27:03 --> URI Class Initialized
INFO - 2020-11-30 08:27:03 --> Router Class Initialized
INFO - 2020-11-30 08:27:03 --> Output Class Initialized
INFO - 2020-11-30 08:27:03 --> Security Class Initialized
DEBUG - 2020-11-30 08:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:27:03 --> Input Class Initialized
INFO - 2020-11-30 08:27:03 --> Language Class Initialized
INFO - 2020-11-30 08:27:03 --> Language Class Initialized
INFO - 2020-11-30 08:27:03 --> Config Class Initialized
INFO - 2020-11-30 08:27:03 --> Loader Class Initialized
INFO - 2020-11-30 08:27:03 --> Helper loaded: url_helper
INFO - 2020-11-30 08:27:03 --> Helper loaded: file_helper
INFO - 2020-11-30 08:27:03 --> Helper loaded: form_helper
INFO - 2020-11-30 08:27:03 --> Helper loaded: my_helper
INFO - 2020-11-30 08:27:03 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:27:03 --> Controller Class Initialized
DEBUG - 2020-11-30 08:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-30 08:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 08:27:03 --> Final output sent to browser
DEBUG - 2020-11-30 08:27:03 --> Total execution time: 0.1942
INFO - 2020-11-30 08:27:04 --> Config Class Initialized
INFO - 2020-11-30 08:27:04 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:27:04 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:27:04 --> Utf8 Class Initialized
INFO - 2020-11-30 08:27:04 --> URI Class Initialized
INFO - 2020-11-30 08:27:04 --> Router Class Initialized
INFO - 2020-11-30 08:27:04 --> Output Class Initialized
INFO - 2020-11-30 08:27:04 --> Security Class Initialized
DEBUG - 2020-11-30 08:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:27:04 --> Input Class Initialized
INFO - 2020-11-30 08:27:04 --> Language Class Initialized
INFO - 2020-11-30 08:27:04 --> Language Class Initialized
INFO - 2020-11-30 08:27:04 --> Config Class Initialized
INFO - 2020-11-30 08:27:04 --> Loader Class Initialized
INFO - 2020-11-30 08:27:04 --> Helper loaded: url_helper
INFO - 2020-11-30 08:27:04 --> Helper loaded: file_helper
INFO - 2020-11-30 08:27:04 --> Helper loaded: form_helper
INFO - 2020-11-30 08:27:04 --> Helper loaded: my_helper
INFO - 2020-11-30 08:27:04 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:27:04 --> Controller Class Initialized
INFO - 2020-11-30 08:27:04 --> Final output sent to browser
DEBUG - 2020-11-30 08:27:04 --> Total execution time: 0.1633
INFO - 2020-11-30 08:27:12 --> Config Class Initialized
INFO - 2020-11-30 08:27:12 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:27:12 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:27:12 --> Utf8 Class Initialized
INFO - 2020-11-30 08:27:12 --> URI Class Initialized
INFO - 2020-11-30 08:27:12 --> Router Class Initialized
INFO - 2020-11-30 08:27:12 --> Output Class Initialized
INFO - 2020-11-30 08:27:12 --> Security Class Initialized
DEBUG - 2020-11-30 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:27:12 --> Input Class Initialized
INFO - 2020-11-30 08:27:12 --> Language Class Initialized
INFO - 2020-11-30 08:27:12 --> Language Class Initialized
INFO - 2020-11-30 08:27:12 --> Config Class Initialized
INFO - 2020-11-30 08:27:12 --> Loader Class Initialized
INFO - 2020-11-30 08:27:12 --> Helper loaded: url_helper
INFO - 2020-11-30 08:27:12 --> Helper loaded: file_helper
INFO - 2020-11-30 08:27:12 --> Helper loaded: form_helper
INFO - 2020-11-30 08:27:12 --> Helper loaded: my_helper
INFO - 2020-11-30 08:27:12 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:27:12 --> Controller Class Initialized
DEBUG - 2020-11-30 08:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-30 08:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 08:27:12 --> Final output sent to browser
DEBUG - 2020-11-30 08:27:12 --> Total execution time: 0.1976
INFO - 2020-11-30 08:27:12 --> Config Class Initialized
INFO - 2020-11-30 08:27:12 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:27:12 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:27:12 --> Utf8 Class Initialized
INFO - 2020-11-30 08:27:12 --> URI Class Initialized
INFO - 2020-11-30 08:27:12 --> Router Class Initialized
INFO - 2020-11-30 08:27:12 --> Output Class Initialized
INFO - 2020-11-30 08:27:12 --> Security Class Initialized
DEBUG - 2020-11-30 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:27:13 --> Input Class Initialized
INFO - 2020-11-30 08:27:13 --> Language Class Initialized
INFO - 2020-11-30 08:27:13 --> Language Class Initialized
INFO - 2020-11-30 08:27:13 --> Config Class Initialized
INFO - 2020-11-30 08:27:13 --> Loader Class Initialized
INFO - 2020-11-30 08:27:13 --> Helper loaded: url_helper
INFO - 2020-11-30 08:27:13 --> Helper loaded: file_helper
INFO - 2020-11-30 08:27:13 --> Helper loaded: form_helper
INFO - 2020-11-30 08:27:13 --> Helper loaded: my_helper
INFO - 2020-11-30 08:27:13 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:27:13 --> Controller Class Initialized
INFO - 2020-11-30 08:27:13 --> Final output sent to browser
DEBUG - 2020-11-30 08:27:13 --> Total execution time: 0.1667
INFO - 2020-11-30 08:57:10 --> Config Class Initialized
INFO - 2020-11-30 08:57:10 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:57:10 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:57:10 --> Utf8 Class Initialized
INFO - 2020-11-30 08:57:10 --> URI Class Initialized
INFO - 2020-11-30 08:57:10 --> Router Class Initialized
INFO - 2020-11-30 08:57:10 --> Output Class Initialized
INFO - 2020-11-30 08:57:10 --> Security Class Initialized
DEBUG - 2020-11-30 08:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:57:10 --> Input Class Initialized
INFO - 2020-11-30 08:57:10 --> Language Class Initialized
INFO - 2020-11-30 08:57:10 --> Language Class Initialized
INFO - 2020-11-30 08:57:10 --> Config Class Initialized
INFO - 2020-11-30 08:57:10 --> Loader Class Initialized
INFO - 2020-11-30 08:57:10 --> Helper loaded: url_helper
INFO - 2020-11-30 08:57:10 --> Helper loaded: file_helper
INFO - 2020-11-30 08:57:10 --> Helper loaded: form_helper
INFO - 2020-11-30 08:57:10 --> Helper loaded: my_helper
INFO - 2020-11-30 08:57:10 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:57:10 --> Controller Class Initialized
DEBUG - 2020-11-30 08:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-30 08:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 08:57:10 --> Final output sent to browser
DEBUG - 2020-11-30 08:57:10 --> Total execution time: 0.2946
INFO - 2020-11-30 08:57:11 --> Config Class Initialized
INFO - 2020-11-30 08:57:11 --> Hooks Class Initialized
DEBUG - 2020-11-30 08:57:11 --> UTF-8 Support Enabled
INFO - 2020-11-30 08:57:11 --> Utf8 Class Initialized
INFO - 2020-11-30 08:57:11 --> URI Class Initialized
INFO - 2020-11-30 08:57:11 --> Router Class Initialized
INFO - 2020-11-30 08:57:11 --> Output Class Initialized
INFO - 2020-11-30 08:57:11 --> Security Class Initialized
DEBUG - 2020-11-30 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 08:57:11 --> Input Class Initialized
INFO - 2020-11-30 08:57:11 --> Language Class Initialized
INFO - 2020-11-30 08:57:11 --> Language Class Initialized
INFO - 2020-11-30 08:57:11 --> Config Class Initialized
INFO - 2020-11-30 08:57:11 --> Loader Class Initialized
INFO - 2020-11-30 08:57:11 --> Helper loaded: url_helper
INFO - 2020-11-30 08:57:11 --> Helper loaded: file_helper
INFO - 2020-11-30 08:57:11 --> Helper loaded: form_helper
INFO - 2020-11-30 08:57:11 --> Helper loaded: my_helper
INFO - 2020-11-30 08:57:11 --> Database Driver Class Initialized
DEBUG - 2020-11-30 08:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 08:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 08:57:11 --> Controller Class Initialized
DEBUG - 2020-11-30 08:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-30 08:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 08:57:11 --> Final output sent to browser
DEBUG - 2020-11-30 08:57:11 --> Total execution time: 0.1979
INFO - 2020-11-30 09:50:31 --> Config Class Initialized
INFO - 2020-11-30 09:50:31 --> Hooks Class Initialized
DEBUG - 2020-11-30 09:50:31 --> UTF-8 Support Enabled
INFO - 2020-11-30 09:50:31 --> Utf8 Class Initialized
INFO - 2020-11-30 09:50:31 --> URI Class Initialized
INFO - 2020-11-30 09:50:31 --> Router Class Initialized
INFO - 2020-11-30 09:50:31 --> Output Class Initialized
INFO - 2020-11-30 09:50:31 --> Security Class Initialized
DEBUG - 2020-11-30 09:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 09:50:31 --> Input Class Initialized
INFO - 2020-11-30 09:50:31 --> Language Class Initialized
INFO - 2020-11-30 09:50:31 --> Language Class Initialized
INFO - 2020-11-30 09:50:31 --> Config Class Initialized
INFO - 2020-11-30 09:50:31 --> Loader Class Initialized
INFO - 2020-11-30 09:50:31 --> Helper loaded: url_helper
INFO - 2020-11-30 09:50:31 --> Helper loaded: file_helper
INFO - 2020-11-30 09:50:31 --> Helper loaded: form_helper
INFO - 2020-11-30 09:50:31 --> Helper loaded: my_helper
INFO - 2020-11-30 09:50:31 --> Database Driver Class Initialized
DEBUG - 2020-11-30 09:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 09:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 09:50:31 --> Controller Class Initialized
DEBUG - 2020-11-30 09:50:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-30 09:50:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-30 09:50:31 --> Final output sent to browser
DEBUG - 2020-11-30 09:50:31 --> Total execution time: 0.2043
INFO - 2020-11-30 09:50:32 --> Config Class Initialized
INFO - 2020-11-30 09:50:32 --> Hooks Class Initialized
DEBUG - 2020-11-30 09:50:32 --> UTF-8 Support Enabled
INFO - 2020-11-30 09:50:32 --> Utf8 Class Initialized
INFO - 2020-11-30 09:50:32 --> URI Class Initialized
INFO - 2020-11-30 09:50:32 --> Router Class Initialized
INFO - 2020-11-30 09:50:32 --> Output Class Initialized
INFO - 2020-11-30 09:50:32 --> Security Class Initialized
DEBUG - 2020-11-30 09:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 09:50:32 --> Input Class Initialized
INFO - 2020-11-30 09:50:32 --> Language Class Initialized
INFO - 2020-11-30 09:50:32 --> Language Class Initialized
INFO - 2020-11-30 09:50:32 --> Config Class Initialized
INFO - 2020-11-30 09:50:32 --> Loader Class Initialized
INFO - 2020-11-30 09:50:32 --> Helper loaded: url_helper
INFO - 2020-11-30 09:50:32 --> Helper loaded: file_helper
INFO - 2020-11-30 09:50:32 --> Helper loaded: form_helper
INFO - 2020-11-30 09:50:32 --> Helper loaded: my_helper
INFO - 2020-11-30 09:50:32 --> Database Driver Class Initialized
DEBUG - 2020-11-30 09:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-30 09:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 09:50:32 --> Controller Class Initialized
INFO - 2020-11-30 09:50:32 --> Final output sent to browser
DEBUG - 2020-11-30 09:50:32 --> Total execution time: 0.1652
