<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-21 01:25:06 --> Config Class Initialized
INFO - 2020-12-21 01:25:06 --> Hooks Class Initialized
DEBUG - 2020-12-21 01:25:06 --> UTF-8 Support Enabled
INFO - 2020-12-21 01:25:06 --> Utf8 Class Initialized
INFO - 2020-12-21 01:25:06 --> URI Class Initialized
DEBUG - 2020-12-21 01:25:06 --> No URI present. Default controller set.
INFO - 2020-12-21 01:25:06 --> Router Class Initialized
INFO - 2020-12-21 01:25:07 --> Output Class Initialized
INFO - 2020-12-21 01:25:07 --> Security Class Initialized
DEBUG - 2020-12-21 01:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 01:25:07 --> Input Class Initialized
INFO - 2020-12-21 01:25:07 --> Language Class Initialized
INFO - 2020-12-21 01:25:07 --> Language Class Initialized
INFO - 2020-12-21 01:25:07 --> Config Class Initialized
INFO - 2020-12-21 01:25:07 --> Loader Class Initialized
INFO - 2020-12-21 01:25:07 --> Helper loaded: url_helper
INFO - 2020-12-21 01:25:07 --> Helper loaded: file_helper
INFO - 2020-12-21 01:25:07 --> Helper loaded: form_helper
INFO - 2020-12-21 01:25:07 --> Helper loaded: my_helper
INFO - 2020-12-21 01:25:08 --> Database Driver Class Initialized
DEBUG - 2020-12-21 01:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 01:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 01:25:08 --> Controller Class Initialized
INFO - 2020-12-21 01:25:08 --> Config Class Initialized
INFO - 2020-12-21 01:25:08 --> Hooks Class Initialized
DEBUG - 2020-12-21 01:25:08 --> UTF-8 Support Enabled
INFO - 2020-12-21 01:25:08 --> Utf8 Class Initialized
INFO - 2020-12-21 01:25:08 --> URI Class Initialized
INFO - 2020-12-21 01:25:08 --> Router Class Initialized
INFO - 2020-12-21 01:25:08 --> Output Class Initialized
INFO - 2020-12-21 01:25:08 --> Security Class Initialized
DEBUG - 2020-12-21 01:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 01:25:08 --> Input Class Initialized
INFO - 2020-12-21 01:25:08 --> Language Class Initialized
INFO - 2020-12-21 01:25:08 --> Language Class Initialized
INFO - 2020-12-21 01:25:08 --> Config Class Initialized
INFO - 2020-12-21 01:25:08 --> Loader Class Initialized
INFO - 2020-12-21 01:25:08 --> Helper loaded: url_helper
INFO - 2020-12-21 01:25:08 --> Helper loaded: file_helper
INFO - 2020-12-21 01:25:08 --> Helper loaded: form_helper
INFO - 2020-12-21 01:25:08 --> Helper loaded: my_helper
INFO - 2020-12-21 01:25:08 --> Database Driver Class Initialized
DEBUG - 2020-12-21 01:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 01:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 01:25:08 --> Controller Class Initialized
DEBUG - 2020-12-21 01:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-21 01:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-21 01:25:08 --> Final output sent to browser
DEBUG - 2020-12-21 01:25:08 --> Total execution time: 0.5933
INFO - 2020-12-21 01:25:14 --> Config Class Initialized
INFO - 2020-12-21 01:25:14 --> Hooks Class Initialized
DEBUG - 2020-12-21 01:25:14 --> UTF-8 Support Enabled
INFO - 2020-12-21 01:25:14 --> Utf8 Class Initialized
INFO - 2020-12-21 01:25:14 --> URI Class Initialized
INFO - 2020-12-21 01:25:14 --> Router Class Initialized
INFO - 2020-12-21 01:25:14 --> Output Class Initialized
INFO - 2020-12-21 01:25:15 --> Security Class Initialized
DEBUG - 2020-12-21 01:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 01:25:15 --> Input Class Initialized
INFO - 2020-12-21 01:25:15 --> Language Class Initialized
INFO - 2020-12-21 01:25:15 --> Language Class Initialized
INFO - 2020-12-21 01:25:15 --> Config Class Initialized
INFO - 2020-12-21 01:25:15 --> Loader Class Initialized
INFO - 2020-12-21 01:25:15 --> Helper loaded: url_helper
INFO - 2020-12-21 01:25:15 --> Helper loaded: file_helper
INFO - 2020-12-21 01:25:15 --> Helper loaded: form_helper
INFO - 2020-12-21 01:25:15 --> Helper loaded: my_helper
INFO - 2020-12-21 01:25:15 --> Database Driver Class Initialized
DEBUG - 2020-12-21 01:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 01:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 01:25:15 --> Controller Class Initialized
INFO - 2020-12-21 01:25:15 --> Helper loaded: cookie_helper
INFO - 2020-12-21 01:25:15 --> Final output sent to browser
DEBUG - 2020-12-21 01:25:15 --> Total execution time: 0.7824
INFO - 2020-12-21 01:25:17 --> Config Class Initialized
INFO - 2020-12-21 01:25:17 --> Hooks Class Initialized
DEBUG - 2020-12-21 01:25:17 --> UTF-8 Support Enabled
INFO - 2020-12-21 01:25:17 --> Utf8 Class Initialized
INFO - 2020-12-21 01:25:17 --> URI Class Initialized
INFO - 2020-12-21 01:25:17 --> Router Class Initialized
INFO - 2020-12-21 01:25:17 --> Output Class Initialized
INFO - 2020-12-21 01:25:17 --> Security Class Initialized
DEBUG - 2020-12-21 01:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 01:25:17 --> Input Class Initialized
INFO - 2020-12-21 01:25:17 --> Language Class Initialized
INFO - 2020-12-21 01:25:17 --> Language Class Initialized
INFO - 2020-12-21 01:25:17 --> Config Class Initialized
INFO - 2020-12-21 01:25:17 --> Loader Class Initialized
INFO - 2020-12-21 01:25:17 --> Helper loaded: url_helper
INFO - 2020-12-21 01:25:17 --> Helper loaded: file_helper
INFO - 2020-12-21 01:25:17 --> Helper loaded: form_helper
INFO - 2020-12-21 01:25:17 --> Helper loaded: my_helper
INFO - 2020-12-21 01:25:17 --> Database Driver Class Initialized
DEBUG - 2020-12-21 01:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 01:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 01:25:17 --> Controller Class Initialized
DEBUG - 2020-12-21 01:25:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-21 01:25:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-21 01:25:18 --> Final output sent to browser
DEBUG - 2020-12-21 01:25:18 --> Total execution time: 0.7925
INFO - 2020-12-21 01:25:23 --> Config Class Initialized
INFO - 2020-12-21 01:25:23 --> Hooks Class Initialized
DEBUG - 2020-12-21 01:25:23 --> UTF-8 Support Enabled
INFO - 2020-12-21 01:25:23 --> Utf8 Class Initialized
INFO - 2020-12-21 01:25:23 --> URI Class Initialized
INFO - 2020-12-21 01:25:23 --> Router Class Initialized
INFO - 2020-12-21 01:25:23 --> Output Class Initialized
INFO - 2020-12-21 01:25:23 --> Security Class Initialized
DEBUG - 2020-12-21 01:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 01:25:23 --> Input Class Initialized
INFO - 2020-12-21 01:25:23 --> Language Class Initialized
INFO - 2020-12-21 01:25:23 --> Language Class Initialized
INFO - 2020-12-21 01:25:23 --> Config Class Initialized
INFO - 2020-12-21 01:25:23 --> Loader Class Initialized
INFO - 2020-12-21 01:25:23 --> Helper loaded: url_helper
INFO - 2020-12-21 01:25:23 --> Helper loaded: file_helper
INFO - 2020-12-21 01:25:23 --> Helper loaded: form_helper
INFO - 2020-12-21 01:25:23 --> Helper loaded: my_helper
INFO - 2020-12-21 01:25:23 --> Database Driver Class Initialized
DEBUG - 2020-12-21 01:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 01:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 01:25:23 --> Controller Class Initialized
ERROR - 2020-12-21 01:25:23 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-21 02:22:53 --> Config Class Initialized
INFO - 2020-12-21 02:22:53 --> Hooks Class Initialized
DEBUG - 2020-12-21 02:22:54 --> UTF-8 Support Enabled
INFO - 2020-12-21 02:22:54 --> Utf8 Class Initialized
INFO - 2020-12-21 02:22:54 --> URI Class Initialized
DEBUG - 2020-12-21 02:22:54 --> No URI present. Default controller set.
INFO - 2020-12-21 02:22:54 --> Router Class Initialized
INFO - 2020-12-21 02:22:54 --> Output Class Initialized
INFO - 2020-12-21 02:22:54 --> Security Class Initialized
DEBUG - 2020-12-21 02:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 02:22:54 --> Input Class Initialized
INFO - 2020-12-21 02:22:54 --> Language Class Initialized
INFO - 2020-12-21 02:22:54 --> Language Class Initialized
INFO - 2020-12-21 02:22:54 --> Config Class Initialized
INFO - 2020-12-21 02:22:54 --> Loader Class Initialized
INFO - 2020-12-21 02:22:54 --> Helper loaded: url_helper
INFO - 2020-12-21 02:22:54 --> Helper loaded: file_helper
INFO - 2020-12-21 02:22:54 --> Helper loaded: form_helper
INFO - 2020-12-21 02:22:54 --> Helper loaded: my_helper
INFO - 2020-12-21 02:22:54 --> Database Driver Class Initialized
DEBUG - 2020-12-21 02:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 02:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 02:22:54 --> Controller Class Initialized
INFO - 2020-12-21 02:22:54 --> Config Class Initialized
INFO - 2020-12-21 02:22:54 --> Hooks Class Initialized
DEBUG - 2020-12-21 02:22:54 --> UTF-8 Support Enabled
INFO - 2020-12-21 02:22:54 --> Utf8 Class Initialized
INFO - 2020-12-21 02:22:54 --> URI Class Initialized
INFO - 2020-12-21 02:22:54 --> Router Class Initialized
INFO - 2020-12-21 02:22:54 --> Output Class Initialized
INFO - 2020-12-21 02:22:54 --> Security Class Initialized
DEBUG - 2020-12-21 02:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 02:22:54 --> Input Class Initialized
INFO - 2020-12-21 02:22:54 --> Language Class Initialized
INFO - 2020-12-21 02:22:54 --> Language Class Initialized
INFO - 2020-12-21 02:22:54 --> Config Class Initialized
INFO - 2020-12-21 02:22:54 --> Loader Class Initialized
INFO - 2020-12-21 02:22:54 --> Helper loaded: url_helper
INFO - 2020-12-21 02:22:54 --> Helper loaded: file_helper
INFO - 2020-12-21 02:22:54 --> Helper loaded: form_helper
INFO - 2020-12-21 02:22:54 --> Helper loaded: my_helper
INFO - 2020-12-21 02:22:54 --> Database Driver Class Initialized
DEBUG - 2020-12-21 02:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 02:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 02:22:54 --> Controller Class Initialized
DEBUG - 2020-12-21 02:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-21 02:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-21 02:22:55 --> Final output sent to browser
DEBUG - 2020-12-21 02:22:55 --> Total execution time: 0.3163
INFO - 2020-12-21 02:23:02 --> Config Class Initialized
INFO - 2020-12-21 02:23:02 --> Hooks Class Initialized
DEBUG - 2020-12-21 02:23:02 --> UTF-8 Support Enabled
INFO - 2020-12-21 02:23:02 --> Utf8 Class Initialized
INFO - 2020-12-21 02:23:02 --> URI Class Initialized
INFO - 2020-12-21 02:23:02 --> Router Class Initialized
INFO - 2020-12-21 02:23:02 --> Output Class Initialized
INFO - 2020-12-21 02:23:02 --> Security Class Initialized
DEBUG - 2020-12-21 02:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 02:23:02 --> Input Class Initialized
INFO - 2020-12-21 02:23:02 --> Language Class Initialized
INFO - 2020-12-21 02:23:02 --> Language Class Initialized
INFO - 2020-12-21 02:23:02 --> Config Class Initialized
INFO - 2020-12-21 02:23:02 --> Loader Class Initialized
INFO - 2020-12-21 02:23:02 --> Helper loaded: url_helper
INFO - 2020-12-21 02:23:02 --> Helper loaded: file_helper
INFO - 2020-12-21 02:23:02 --> Helper loaded: form_helper
INFO - 2020-12-21 02:23:02 --> Helper loaded: my_helper
INFO - 2020-12-21 02:23:02 --> Database Driver Class Initialized
DEBUG - 2020-12-21 02:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 02:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 02:23:02 --> Controller Class Initialized
INFO - 2020-12-21 02:23:02 --> Helper loaded: cookie_helper
INFO - 2020-12-21 02:23:02 --> Final output sent to browser
DEBUG - 2020-12-21 02:23:02 --> Total execution time: 0.4409
INFO - 2020-12-21 02:23:03 --> Config Class Initialized
INFO - 2020-12-21 02:23:03 --> Hooks Class Initialized
DEBUG - 2020-12-21 02:23:03 --> UTF-8 Support Enabled
INFO - 2020-12-21 02:23:03 --> Utf8 Class Initialized
INFO - 2020-12-21 02:23:03 --> URI Class Initialized
INFO - 2020-12-21 02:23:03 --> Router Class Initialized
INFO - 2020-12-21 02:23:03 --> Output Class Initialized
INFO - 2020-12-21 02:23:03 --> Security Class Initialized
DEBUG - 2020-12-21 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 02:23:03 --> Input Class Initialized
INFO - 2020-12-21 02:23:03 --> Language Class Initialized
INFO - 2020-12-21 02:23:03 --> Language Class Initialized
INFO - 2020-12-21 02:23:03 --> Config Class Initialized
INFO - 2020-12-21 02:23:03 --> Loader Class Initialized
INFO - 2020-12-21 02:23:03 --> Helper loaded: url_helper
INFO - 2020-12-21 02:23:03 --> Helper loaded: file_helper
INFO - 2020-12-21 02:23:03 --> Helper loaded: form_helper
INFO - 2020-12-21 02:23:03 --> Helper loaded: my_helper
INFO - 2020-12-21 02:23:03 --> Database Driver Class Initialized
DEBUG - 2020-12-21 02:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 02:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 02:23:03 --> Controller Class Initialized
DEBUG - 2020-12-21 02:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-21 02:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-21 02:23:04 --> Final output sent to browser
DEBUG - 2020-12-21 02:23:04 --> Total execution time: 0.4496
INFO - 2020-12-21 02:23:08 --> Config Class Initialized
INFO - 2020-12-21 02:23:08 --> Hooks Class Initialized
DEBUG - 2020-12-21 02:23:08 --> UTF-8 Support Enabled
INFO - 2020-12-21 02:23:08 --> Utf8 Class Initialized
INFO - 2020-12-21 02:23:08 --> URI Class Initialized
INFO - 2020-12-21 02:23:08 --> Router Class Initialized
INFO - 2020-12-21 02:23:08 --> Output Class Initialized
INFO - 2020-12-21 02:23:08 --> Security Class Initialized
DEBUG - 2020-12-21 02:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-21 02:23:08 --> Input Class Initialized
INFO - 2020-12-21 02:23:08 --> Language Class Initialized
INFO - 2020-12-21 02:23:08 --> Language Class Initialized
INFO - 2020-12-21 02:23:08 --> Config Class Initialized
INFO - 2020-12-21 02:23:08 --> Loader Class Initialized
INFO - 2020-12-21 02:23:08 --> Helper loaded: url_helper
INFO - 2020-12-21 02:23:08 --> Helper loaded: file_helper
INFO - 2020-12-21 02:23:08 --> Helper loaded: form_helper
INFO - 2020-12-21 02:23:08 --> Helper loaded: my_helper
INFO - 2020-12-21 02:23:08 --> Database Driver Class Initialized
DEBUG - 2020-12-21 02:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-21 02:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-21 02:23:08 --> Controller Class Initialized
ERROR - 2020-12-21 02:23:08 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
