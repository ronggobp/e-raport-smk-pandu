<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-21 02:31:03 --> Config Class Initialized
INFO - 2020-10-21 02:31:03 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:03 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:03 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:03 --> URI Class Initialized
DEBUG - 2020-10-21 02:31:03 --> No URI present. Default controller set.
INFO - 2020-10-21 02:31:03 --> Router Class Initialized
INFO - 2020-10-21 02:31:03 --> Output Class Initialized
INFO - 2020-10-21 02:31:03 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:03 --> Input Class Initialized
INFO - 2020-10-21 02:31:03 --> Language Class Initialized
INFO - 2020-10-21 02:31:03 --> Language Class Initialized
INFO - 2020-10-21 02:31:03 --> Config Class Initialized
INFO - 2020-10-21 02:31:03 --> Loader Class Initialized
INFO - 2020-10-21 02:31:03 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:03 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:04 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:04 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:04 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:04 --> Controller Class Initialized
INFO - 2020-10-21 02:31:04 --> Config Class Initialized
INFO - 2020-10-21 02:31:04 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:04 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:04 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:04 --> URI Class Initialized
INFO - 2020-10-21 02:31:04 --> Router Class Initialized
INFO - 2020-10-21 02:31:04 --> Output Class Initialized
INFO - 2020-10-21 02:31:04 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:04 --> Input Class Initialized
INFO - 2020-10-21 02:31:04 --> Language Class Initialized
INFO - 2020-10-21 02:31:04 --> Language Class Initialized
INFO - 2020-10-21 02:31:04 --> Config Class Initialized
INFO - 2020-10-21 02:31:04 --> Loader Class Initialized
INFO - 2020-10-21 02:31:04 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:04 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:04 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:04 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:04 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:04 --> Controller Class Initialized
DEBUG - 2020-10-21 02:31:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-21 02:31:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:31:04 --> Final output sent to browser
DEBUG - 2020-10-21 02:31:04 --> Total execution time: 0.2091
INFO - 2020-10-21 02:31:08 --> Config Class Initialized
INFO - 2020-10-21 02:31:08 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:08 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:08 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:08 --> URI Class Initialized
INFO - 2020-10-21 02:31:08 --> Router Class Initialized
INFO - 2020-10-21 02:31:08 --> Output Class Initialized
INFO - 2020-10-21 02:31:08 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:08 --> Input Class Initialized
INFO - 2020-10-21 02:31:08 --> Language Class Initialized
INFO - 2020-10-21 02:31:08 --> Language Class Initialized
INFO - 2020-10-21 02:31:08 --> Config Class Initialized
INFO - 2020-10-21 02:31:08 --> Loader Class Initialized
INFO - 2020-10-21 02:31:08 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:08 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:08 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:08 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:08 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:08 --> Controller Class Initialized
DEBUG - 2020-10-21 02:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-21 02:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:31:08 --> Final output sent to browser
DEBUG - 2020-10-21 02:31:09 --> Total execution time: 0.2753
INFO - 2020-10-21 02:31:09 --> Config Class Initialized
INFO - 2020-10-21 02:31:09 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:09 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:09 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:09 --> URI Class Initialized
DEBUG - 2020-10-21 02:31:09 --> No URI present. Default controller set.
INFO - 2020-10-21 02:31:09 --> Router Class Initialized
INFO - 2020-10-21 02:31:09 --> Output Class Initialized
INFO - 2020-10-21 02:31:09 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:09 --> Input Class Initialized
INFO - 2020-10-21 02:31:09 --> Language Class Initialized
INFO - 2020-10-21 02:31:09 --> Language Class Initialized
INFO - 2020-10-21 02:31:09 --> Config Class Initialized
INFO - 2020-10-21 02:31:09 --> Loader Class Initialized
INFO - 2020-10-21 02:31:09 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:09 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:10 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:10 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:10 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:10 --> Controller Class Initialized
INFO - 2020-10-21 02:31:10 --> Config Class Initialized
INFO - 2020-10-21 02:31:10 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:10 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:10 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:10 --> URI Class Initialized
INFO - 2020-10-21 02:31:10 --> Router Class Initialized
INFO - 2020-10-21 02:31:10 --> Output Class Initialized
INFO - 2020-10-21 02:31:10 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:10 --> Input Class Initialized
INFO - 2020-10-21 02:31:10 --> Language Class Initialized
INFO - 2020-10-21 02:31:10 --> Language Class Initialized
INFO - 2020-10-21 02:31:10 --> Config Class Initialized
INFO - 2020-10-21 02:31:10 --> Loader Class Initialized
INFO - 2020-10-21 02:31:10 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:10 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:10 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:10 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:10 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:10 --> Controller Class Initialized
DEBUG - 2020-10-21 02:31:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-21 02:31:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:31:10 --> Final output sent to browser
DEBUG - 2020-10-21 02:31:10 --> Total execution time: 0.2033
INFO - 2020-10-21 02:31:24 --> Config Class Initialized
INFO - 2020-10-21 02:31:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:25 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:25 --> URI Class Initialized
INFO - 2020-10-21 02:31:25 --> Router Class Initialized
INFO - 2020-10-21 02:31:25 --> Output Class Initialized
INFO - 2020-10-21 02:31:25 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:25 --> Input Class Initialized
INFO - 2020-10-21 02:31:25 --> Language Class Initialized
INFO - 2020-10-21 02:31:25 --> Language Class Initialized
INFO - 2020-10-21 02:31:25 --> Config Class Initialized
INFO - 2020-10-21 02:31:25 --> Loader Class Initialized
INFO - 2020-10-21 02:31:25 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:25 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:25 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:25 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:25 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:25 --> Controller Class Initialized
INFO - 2020-10-21 02:31:25 --> Helper loaded: cookie_helper
INFO - 2020-10-21 02:31:25 --> Final output sent to browser
DEBUG - 2020-10-21 02:31:25 --> Total execution time: 0.2824
INFO - 2020-10-21 02:31:30 --> Config Class Initialized
INFO - 2020-10-21 02:31:30 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:30 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:30 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:30 --> URI Class Initialized
INFO - 2020-10-21 02:31:30 --> Router Class Initialized
INFO - 2020-10-21 02:31:30 --> Output Class Initialized
INFO - 2020-10-21 02:31:30 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:30 --> Input Class Initialized
INFO - 2020-10-21 02:31:30 --> Language Class Initialized
INFO - 2020-10-21 02:31:30 --> Language Class Initialized
INFO - 2020-10-21 02:31:30 --> Config Class Initialized
INFO - 2020-10-21 02:31:30 --> Loader Class Initialized
INFO - 2020-10-21 02:31:30 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:30 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:30 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:30 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:30 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:30 --> Controller Class Initialized
DEBUG - 2020-10-21 02:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-21 02:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:31:30 --> Final output sent to browser
DEBUG - 2020-10-21 02:31:30 --> Total execution time: 0.3865
INFO - 2020-10-21 02:31:33 --> Config Class Initialized
INFO - 2020-10-21 02:31:33 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:33 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:33 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:33 --> URI Class Initialized
INFO - 2020-10-21 02:31:33 --> Router Class Initialized
INFO - 2020-10-21 02:31:33 --> Output Class Initialized
INFO - 2020-10-21 02:31:33 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:33 --> Input Class Initialized
INFO - 2020-10-21 02:31:33 --> Language Class Initialized
INFO - 2020-10-21 02:31:33 --> Language Class Initialized
INFO - 2020-10-21 02:31:33 --> Config Class Initialized
INFO - 2020-10-21 02:31:33 --> Loader Class Initialized
INFO - 2020-10-21 02:31:33 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:33 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:33 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:33 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:33 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:34 --> Controller Class Initialized
DEBUG - 2020-10-21 02:31:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 02:31:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:31:34 --> Final output sent to browser
DEBUG - 2020-10-21 02:31:34 --> Total execution time: 0.2162
INFO - 2020-10-21 02:31:34 --> Config Class Initialized
INFO - 2020-10-21 02:31:34 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:31:34 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:31:34 --> Utf8 Class Initialized
INFO - 2020-10-21 02:31:34 --> URI Class Initialized
INFO - 2020-10-21 02:31:34 --> Router Class Initialized
INFO - 2020-10-21 02:31:34 --> Output Class Initialized
INFO - 2020-10-21 02:31:34 --> Security Class Initialized
DEBUG - 2020-10-21 02:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:31:34 --> Input Class Initialized
INFO - 2020-10-21 02:31:34 --> Language Class Initialized
INFO - 2020-10-21 02:31:34 --> Language Class Initialized
INFO - 2020-10-21 02:31:34 --> Config Class Initialized
INFO - 2020-10-21 02:31:34 --> Loader Class Initialized
INFO - 2020-10-21 02:31:34 --> Helper loaded: url_helper
INFO - 2020-10-21 02:31:34 --> Helper loaded: file_helper
INFO - 2020-10-21 02:31:34 --> Helper loaded: form_helper
INFO - 2020-10-21 02:31:34 --> Helper loaded: my_helper
INFO - 2020-10-21 02:31:34 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:31:34 --> Controller Class Initialized
INFO - 2020-10-21 02:34:05 --> Config Class Initialized
INFO - 2020-10-21 02:34:05 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:34:05 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:34:05 --> Utf8 Class Initialized
INFO - 2020-10-21 02:34:05 --> URI Class Initialized
INFO - 2020-10-21 02:34:05 --> Router Class Initialized
INFO - 2020-10-21 02:34:05 --> Output Class Initialized
INFO - 2020-10-21 02:34:05 --> Security Class Initialized
DEBUG - 2020-10-21 02:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:34:05 --> Input Class Initialized
INFO - 2020-10-21 02:34:05 --> Language Class Initialized
INFO - 2020-10-21 02:34:05 --> Language Class Initialized
INFO - 2020-10-21 02:34:05 --> Config Class Initialized
INFO - 2020-10-21 02:34:05 --> Loader Class Initialized
INFO - 2020-10-21 02:34:05 --> Helper loaded: url_helper
INFO - 2020-10-21 02:34:05 --> Helper loaded: file_helper
INFO - 2020-10-21 02:34:05 --> Helper loaded: form_helper
INFO - 2020-10-21 02:34:05 --> Helper loaded: my_helper
INFO - 2020-10-21 02:34:05 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:34:05 --> Controller Class Initialized
DEBUG - 2020-10-21 02:34:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-21 02:34:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:34:06 --> Final output sent to browser
DEBUG - 2020-10-21 02:34:06 --> Total execution time: 0.2546
INFO - 2020-10-21 02:34:06 --> Config Class Initialized
INFO - 2020-10-21 02:34:06 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:34:06 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:34:06 --> Utf8 Class Initialized
INFO - 2020-10-21 02:34:06 --> URI Class Initialized
INFO - 2020-10-21 02:34:06 --> Router Class Initialized
INFO - 2020-10-21 02:34:06 --> Output Class Initialized
INFO - 2020-10-21 02:34:06 --> Security Class Initialized
DEBUG - 2020-10-21 02:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:34:06 --> Input Class Initialized
INFO - 2020-10-21 02:34:06 --> Language Class Initialized
INFO - 2020-10-21 02:34:06 --> Language Class Initialized
INFO - 2020-10-21 02:34:06 --> Config Class Initialized
INFO - 2020-10-21 02:34:06 --> Loader Class Initialized
INFO - 2020-10-21 02:34:06 --> Helper loaded: url_helper
INFO - 2020-10-21 02:34:06 --> Helper loaded: file_helper
INFO - 2020-10-21 02:34:06 --> Helper loaded: form_helper
INFO - 2020-10-21 02:34:06 --> Helper loaded: my_helper
INFO - 2020-10-21 02:34:06 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:34:06 --> Controller Class Initialized
INFO - 2020-10-21 02:34:09 --> Config Class Initialized
INFO - 2020-10-21 02:34:09 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:34:09 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:34:09 --> Utf8 Class Initialized
INFO - 2020-10-21 02:34:09 --> URI Class Initialized
INFO - 2020-10-21 02:34:09 --> Router Class Initialized
INFO - 2020-10-21 02:34:09 --> Output Class Initialized
INFO - 2020-10-21 02:34:09 --> Security Class Initialized
DEBUG - 2020-10-21 02:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:34:09 --> Input Class Initialized
INFO - 2020-10-21 02:34:09 --> Language Class Initialized
INFO - 2020-10-21 02:34:09 --> Language Class Initialized
INFO - 2020-10-21 02:34:09 --> Config Class Initialized
INFO - 2020-10-21 02:34:09 --> Loader Class Initialized
INFO - 2020-10-21 02:34:09 --> Helper loaded: url_helper
INFO - 2020-10-21 02:34:09 --> Helper loaded: file_helper
INFO - 2020-10-21 02:34:09 --> Helper loaded: form_helper
INFO - 2020-10-21 02:34:09 --> Helper loaded: my_helper
INFO - 2020-10-21 02:34:09 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:34:09 --> Controller Class Initialized
ERROR - 2020-10-21 02:34:09 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-21 02:34:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-21 02:34:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:34:09 --> Final output sent to browser
DEBUG - 2020-10-21 02:34:09 --> Total execution time: 0.3025
INFO - 2020-10-21 02:34:15 --> Config Class Initialized
INFO - 2020-10-21 02:34:15 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:34:15 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:34:15 --> Utf8 Class Initialized
INFO - 2020-10-21 02:34:15 --> URI Class Initialized
INFO - 2020-10-21 02:34:15 --> Router Class Initialized
INFO - 2020-10-21 02:34:15 --> Output Class Initialized
INFO - 2020-10-21 02:34:15 --> Security Class Initialized
DEBUG - 2020-10-21 02:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:34:15 --> Input Class Initialized
INFO - 2020-10-21 02:34:15 --> Language Class Initialized
INFO - 2020-10-21 02:34:15 --> Language Class Initialized
INFO - 2020-10-21 02:34:15 --> Config Class Initialized
INFO - 2020-10-21 02:34:15 --> Loader Class Initialized
INFO - 2020-10-21 02:34:15 --> Helper loaded: url_helper
INFO - 2020-10-21 02:34:15 --> Helper loaded: file_helper
INFO - 2020-10-21 02:34:15 --> Helper loaded: form_helper
INFO - 2020-10-21 02:34:15 --> Helper loaded: my_helper
INFO - 2020-10-21 02:34:15 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:34:15 --> Controller Class Initialized
DEBUG - 2020-10-21 02:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-21 02:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:34:15 --> Final output sent to browser
DEBUG - 2020-10-21 02:34:15 --> Total execution time: 0.2145
INFO - 2020-10-21 02:34:15 --> Config Class Initialized
INFO - 2020-10-21 02:34:15 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:34:15 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:34:15 --> Utf8 Class Initialized
INFO - 2020-10-21 02:34:15 --> URI Class Initialized
INFO - 2020-10-21 02:34:15 --> Router Class Initialized
INFO - 2020-10-21 02:34:15 --> Output Class Initialized
INFO - 2020-10-21 02:34:16 --> Security Class Initialized
DEBUG - 2020-10-21 02:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:34:16 --> Input Class Initialized
INFO - 2020-10-21 02:34:16 --> Language Class Initialized
INFO - 2020-10-21 02:34:16 --> Language Class Initialized
INFO - 2020-10-21 02:34:16 --> Config Class Initialized
INFO - 2020-10-21 02:34:16 --> Loader Class Initialized
INFO - 2020-10-21 02:34:16 --> Helper loaded: url_helper
INFO - 2020-10-21 02:34:16 --> Helper loaded: file_helper
INFO - 2020-10-21 02:34:16 --> Helper loaded: form_helper
INFO - 2020-10-21 02:34:16 --> Helper loaded: my_helper
INFO - 2020-10-21 02:34:16 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:34:16 --> Controller Class Initialized
INFO - 2020-10-21 02:34:17 --> Config Class Initialized
INFO - 2020-10-21 02:34:17 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:34:17 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:34:17 --> Utf8 Class Initialized
INFO - 2020-10-21 02:34:17 --> URI Class Initialized
INFO - 2020-10-21 02:34:17 --> Router Class Initialized
INFO - 2020-10-21 02:34:17 --> Output Class Initialized
INFO - 2020-10-21 02:34:17 --> Security Class Initialized
DEBUG - 2020-10-21 02:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:34:17 --> Input Class Initialized
INFO - 2020-10-21 02:34:17 --> Language Class Initialized
INFO - 2020-10-21 02:34:17 --> Language Class Initialized
INFO - 2020-10-21 02:34:17 --> Config Class Initialized
INFO - 2020-10-21 02:34:17 --> Loader Class Initialized
INFO - 2020-10-21 02:34:17 --> Helper loaded: url_helper
INFO - 2020-10-21 02:34:17 --> Helper loaded: file_helper
INFO - 2020-10-21 02:34:17 --> Helper loaded: form_helper
INFO - 2020-10-21 02:34:17 --> Helper loaded: my_helper
INFO - 2020-10-21 02:34:17 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:34:17 --> Controller Class Initialized
DEBUG - 2020-10-21 02:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-21 02:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:34:17 --> Final output sent to browser
DEBUG - 2020-10-21 02:34:17 --> Total execution time: 0.2433
INFO - 2020-10-21 02:34:17 --> Config Class Initialized
INFO - 2020-10-21 02:34:18 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:34:18 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:34:18 --> Utf8 Class Initialized
INFO - 2020-10-21 02:34:18 --> URI Class Initialized
INFO - 2020-10-21 02:34:18 --> Router Class Initialized
INFO - 2020-10-21 02:34:18 --> Output Class Initialized
INFO - 2020-10-21 02:34:18 --> Security Class Initialized
DEBUG - 2020-10-21 02:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:34:18 --> Input Class Initialized
INFO - 2020-10-21 02:34:18 --> Language Class Initialized
INFO - 2020-10-21 02:34:18 --> Language Class Initialized
INFO - 2020-10-21 02:34:18 --> Config Class Initialized
INFO - 2020-10-21 02:34:18 --> Loader Class Initialized
INFO - 2020-10-21 02:34:18 --> Helper loaded: url_helper
INFO - 2020-10-21 02:34:18 --> Helper loaded: file_helper
INFO - 2020-10-21 02:34:18 --> Helper loaded: form_helper
INFO - 2020-10-21 02:34:18 --> Helper loaded: my_helper
INFO - 2020-10-21 02:34:18 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:34:18 --> Controller Class Initialized
INFO - 2020-10-21 02:34:19 --> Config Class Initialized
INFO - 2020-10-21 02:34:19 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:34:19 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:34:19 --> Utf8 Class Initialized
INFO - 2020-10-21 02:34:19 --> URI Class Initialized
INFO - 2020-10-21 02:34:19 --> Router Class Initialized
INFO - 2020-10-21 02:34:19 --> Output Class Initialized
INFO - 2020-10-21 02:34:19 --> Security Class Initialized
DEBUG - 2020-10-21 02:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:34:19 --> Input Class Initialized
INFO - 2020-10-21 02:34:19 --> Language Class Initialized
INFO - 2020-10-21 02:34:19 --> Language Class Initialized
INFO - 2020-10-21 02:34:19 --> Config Class Initialized
INFO - 2020-10-21 02:34:19 --> Loader Class Initialized
INFO - 2020-10-21 02:34:20 --> Helper loaded: url_helper
INFO - 2020-10-21 02:34:20 --> Helper loaded: file_helper
INFO - 2020-10-21 02:34:20 --> Helper loaded: form_helper
INFO - 2020-10-21 02:34:20 --> Helper loaded: my_helper
INFO - 2020-10-21 02:34:20 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:34:20 --> Controller Class Initialized
INFO - 2020-10-21 02:34:20 --> Final output sent to browser
DEBUG - 2020-10-21 02:34:20 --> Total execution time: 0.2321
INFO - 2020-10-21 02:51:03 --> Config Class Initialized
INFO - 2020-10-21 02:51:03 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:51:03 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:51:03 --> Utf8 Class Initialized
INFO - 2020-10-21 02:51:03 --> URI Class Initialized
INFO - 2020-10-21 02:51:03 --> Router Class Initialized
INFO - 2020-10-21 02:51:03 --> Output Class Initialized
INFO - 2020-10-21 02:51:03 --> Security Class Initialized
DEBUG - 2020-10-21 02:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:51:03 --> Input Class Initialized
INFO - 2020-10-21 02:51:03 --> Language Class Initialized
INFO - 2020-10-21 02:51:03 --> Language Class Initialized
INFO - 2020-10-21 02:51:03 --> Config Class Initialized
INFO - 2020-10-21 02:51:03 --> Loader Class Initialized
INFO - 2020-10-21 02:51:03 --> Helper loaded: url_helper
INFO - 2020-10-21 02:51:04 --> Helper loaded: file_helper
INFO - 2020-10-21 02:51:04 --> Helper loaded: form_helper
INFO - 2020-10-21 02:51:04 --> Helper loaded: my_helper
INFO - 2020-10-21 02:51:04 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:51:04 --> Controller Class Initialized
DEBUG - 2020-10-21 02:51:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 02:51:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 02:51:04 --> Final output sent to browser
DEBUG - 2020-10-21 02:51:04 --> Total execution time: 0.2893
INFO - 2020-10-21 02:51:04 --> Config Class Initialized
INFO - 2020-10-21 02:51:04 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:51:04 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:51:04 --> Utf8 Class Initialized
INFO - 2020-10-21 02:51:04 --> URI Class Initialized
INFO - 2020-10-21 02:51:04 --> Router Class Initialized
INFO - 2020-10-21 02:51:04 --> Output Class Initialized
INFO - 2020-10-21 02:51:04 --> Security Class Initialized
DEBUG - 2020-10-21 02:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:51:04 --> Input Class Initialized
INFO - 2020-10-21 02:51:04 --> Language Class Initialized
INFO - 2020-10-21 02:51:04 --> Language Class Initialized
INFO - 2020-10-21 02:51:04 --> Config Class Initialized
INFO - 2020-10-21 02:51:04 --> Loader Class Initialized
INFO - 2020-10-21 02:51:04 --> Helper loaded: url_helper
INFO - 2020-10-21 02:51:04 --> Helper loaded: file_helper
INFO - 2020-10-21 02:51:04 --> Helper loaded: form_helper
INFO - 2020-10-21 02:51:04 --> Helper loaded: my_helper
INFO - 2020-10-21 02:51:04 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:51:04 --> Controller Class Initialized
INFO - 2020-10-21 02:51:05 --> Config Class Initialized
INFO - 2020-10-21 02:51:05 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:51:05 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:51:05 --> Utf8 Class Initialized
INFO - 2020-10-21 02:51:05 --> URI Class Initialized
INFO - 2020-10-21 02:51:05 --> Router Class Initialized
INFO - 2020-10-21 02:51:05 --> Output Class Initialized
INFO - 2020-10-21 02:51:05 --> Security Class Initialized
DEBUG - 2020-10-21 02:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:51:05 --> Input Class Initialized
INFO - 2020-10-21 02:51:05 --> Language Class Initialized
INFO - 2020-10-21 02:51:05 --> Language Class Initialized
INFO - 2020-10-21 02:51:05 --> Config Class Initialized
INFO - 2020-10-21 02:51:05 --> Loader Class Initialized
INFO - 2020-10-21 02:51:05 --> Helper loaded: url_helper
INFO - 2020-10-21 02:51:05 --> Helper loaded: file_helper
INFO - 2020-10-21 02:51:05 --> Helper loaded: form_helper
INFO - 2020-10-21 02:51:05 --> Helper loaded: my_helper
INFO - 2020-10-21 02:51:05 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:51:05 --> Controller Class Initialized
INFO - 2020-10-21 02:51:05 --> Final output sent to browser
DEBUG - 2020-10-21 02:51:05 --> Total execution time: 0.2786
INFO - 2020-10-21 02:51:41 --> Config Class Initialized
INFO - 2020-10-21 02:51:41 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:51:41 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:51:41 --> Utf8 Class Initialized
INFO - 2020-10-21 02:51:41 --> URI Class Initialized
INFO - 2020-10-21 02:51:41 --> Router Class Initialized
INFO - 2020-10-21 02:51:41 --> Output Class Initialized
INFO - 2020-10-21 02:51:41 --> Security Class Initialized
DEBUG - 2020-10-21 02:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:51:41 --> Input Class Initialized
INFO - 2020-10-21 02:51:41 --> Language Class Initialized
INFO - 2020-10-21 02:51:41 --> Language Class Initialized
INFO - 2020-10-21 02:51:41 --> Config Class Initialized
INFO - 2020-10-21 02:51:41 --> Loader Class Initialized
INFO - 2020-10-21 02:51:41 --> Helper loaded: url_helper
INFO - 2020-10-21 02:51:41 --> Helper loaded: file_helper
INFO - 2020-10-21 02:51:41 --> Helper loaded: form_helper
INFO - 2020-10-21 02:51:41 --> Helper loaded: my_helper
INFO - 2020-10-21 02:51:41 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:51:41 --> Controller Class Initialized
ERROR - 2020-10-21 02:51:41 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 02:51:41 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 02:51:41 --> Final output sent to browser
DEBUG - 2020-10-21 02:51:41 --> Total execution time: 0.2567
INFO - 2020-10-21 02:51:59 --> Config Class Initialized
INFO - 2020-10-21 02:51:59 --> Hooks Class Initialized
DEBUG - 2020-10-21 02:51:59 --> UTF-8 Support Enabled
INFO - 2020-10-21 02:51:59 --> Utf8 Class Initialized
INFO - 2020-10-21 02:51:59 --> URI Class Initialized
INFO - 2020-10-21 02:51:59 --> Router Class Initialized
INFO - 2020-10-21 02:51:59 --> Output Class Initialized
INFO - 2020-10-21 02:51:59 --> Security Class Initialized
DEBUG - 2020-10-21 02:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 02:51:59 --> Input Class Initialized
INFO - 2020-10-21 02:51:59 --> Language Class Initialized
INFO - 2020-10-21 02:51:59 --> Language Class Initialized
INFO - 2020-10-21 02:51:59 --> Config Class Initialized
INFO - 2020-10-21 02:51:59 --> Loader Class Initialized
INFO - 2020-10-21 02:51:59 --> Helper loaded: url_helper
INFO - 2020-10-21 02:51:59 --> Helper loaded: file_helper
INFO - 2020-10-21 02:51:59 --> Helper loaded: form_helper
INFO - 2020-10-21 02:51:59 --> Helper loaded: my_helper
INFO - 2020-10-21 02:51:59 --> Database Driver Class Initialized
DEBUG - 2020-10-21 02:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 02:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 02:51:59 --> Controller Class Initialized
ERROR - 2020-10-21 02:51:59 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 02:51:59 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 02:51:59 --> Final output sent to browser
DEBUG - 2020-10-21 02:51:59 --> Total execution time: 0.2478
INFO - 2020-10-21 03:06:50 --> Config Class Initialized
INFO - 2020-10-21 03:06:50 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:06:50 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:06:50 --> Utf8 Class Initialized
INFO - 2020-10-21 03:06:50 --> URI Class Initialized
INFO - 2020-10-21 03:06:50 --> Router Class Initialized
INFO - 2020-10-21 03:06:50 --> Output Class Initialized
INFO - 2020-10-21 03:06:50 --> Security Class Initialized
DEBUG - 2020-10-21 03:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:06:50 --> Input Class Initialized
INFO - 2020-10-21 03:06:50 --> Language Class Initialized
INFO - 2020-10-21 03:06:50 --> Language Class Initialized
INFO - 2020-10-21 03:06:50 --> Config Class Initialized
INFO - 2020-10-21 03:06:50 --> Loader Class Initialized
INFO - 2020-10-21 03:06:50 --> Helper loaded: url_helper
INFO - 2020-10-21 03:06:50 --> Helper loaded: file_helper
INFO - 2020-10-21 03:06:51 --> Helper loaded: form_helper
INFO - 2020-10-21 03:06:51 --> Helper loaded: my_helper
INFO - 2020-10-21 03:06:51 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:06:51 --> Controller Class Initialized
INFO - 2020-10-21 03:06:51 --> Final output sent to browser
DEBUG - 2020-10-21 03:06:51 --> Total execution time: 0.2343
INFO - 2020-10-21 03:06:56 --> Config Class Initialized
INFO - 2020-10-21 03:06:56 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:06:56 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:06:56 --> Utf8 Class Initialized
INFO - 2020-10-21 03:06:56 --> URI Class Initialized
INFO - 2020-10-21 03:06:56 --> Router Class Initialized
INFO - 2020-10-21 03:06:56 --> Output Class Initialized
INFO - 2020-10-21 03:06:56 --> Security Class Initialized
DEBUG - 2020-10-21 03:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:06:56 --> Input Class Initialized
INFO - 2020-10-21 03:06:56 --> Language Class Initialized
INFO - 2020-10-21 03:06:56 --> Language Class Initialized
INFO - 2020-10-21 03:06:56 --> Config Class Initialized
INFO - 2020-10-21 03:06:56 --> Loader Class Initialized
INFO - 2020-10-21 03:06:56 --> Helper loaded: url_helper
INFO - 2020-10-21 03:06:56 --> Helper loaded: file_helper
INFO - 2020-10-21 03:06:56 --> Helper loaded: form_helper
INFO - 2020-10-21 03:06:56 --> Helper loaded: my_helper
INFO - 2020-10-21 03:06:56 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:06:56 --> Controller Class Initialized
ERROR - 2020-10-21 03:06:56 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:06:56 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:06:56 --> Final output sent to browser
DEBUG - 2020-10-21 03:06:56 --> Total execution time: 0.2592
INFO - 2020-10-21 03:06:58 --> Config Class Initialized
INFO - 2020-10-21 03:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:06:58 --> Utf8 Class Initialized
INFO - 2020-10-21 03:06:58 --> URI Class Initialized
INFO - 2020-10-21 03:06:58 --> Router Class Initialized
INFO - 2020-10-21 03:06:58 --> Output Class Initialized
INFO - 2020-10-21 03:06:58 --> Security Class Initialized
DEBUG - 2020-10-21 03:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:06:58 --> Input Class Initialized
INFO - 2020-10-21 03:06:58 --> Language Class Initialized
INFO - 2020-10-21 03:06:58 --> Language Class Initialized
INFO - 2020-10-21 03:06:58 --> Config Class Initialized
INFO - 2020-10-21 03:06:58 --> Loader Class Initialized
INFO - 2020-10-21 03:06:58 --> Helper loaded: url_helper
INFO - 2020-10-21 03:06:58 --> Helper loaded: file_helper
INFO - 2020-10-21 03:06:58 --> Helper loaded: form_helper
INFO - 2020-10-21 03:06:58 --> Helper loaded: my_helper
INFO - 2020-10-21 03:06:58 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:06:58 --> Controller Class Initialized
DEBUG - 2020-10-21 03:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:06:58 --> Final output sent to browser
DEBUG - 2020-10-21 03:06:58 --> Total execution time: 0.2230
INFO - 2020-10-21 03:06:58 --> Config Class Initialized
INFO - 2020-10-21 03:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:06:58 --> Utf8 Class Initialized
INFO - 2020-10-21 03:06:58 --> URI Class Initialized
INFO - 2020-10-21 03:06:58 --> Router Class Initialized
INFO - 2020-10-21 03:06:58 --> Output Class Initialized
INFO - 2020-10-21 03:06:58 --> Security Class Initialized
DEBUG - 2020-10-21 03:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:06:58 --> Input Class Initialized
INFO - 2020-10-21 03:06:58 --> Language Class Initialized
INFO - 2020-10-21 03:06:58 --> Language Class Initialized
INFO - 2020-10-21 03:06:58 --> Config Class Initialized
INFO - 2020-10-21 03:06:58 --> Loader Class Initialized
INFO - 2020-10-21 03:06:58 --> Helper loaded: url_helper
INFO - 2020-10-21 03:06:58 --> Helper loaded: file_helper
INFO - 2020-10-21 03:06:58 --> Helper loaded: form_helper
INFO - 2020-10-21 03:06:58 --> Helper loaded: my_helper
INFO - 2020-10-21 03:06:58 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:06:58 --> Controller Class Initialized
INFO - 2020-10-21 03:07:44 --> Config Class Initialized
INFO - 2020-10-21 03:07:44 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:07:44 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:07:44 --> Utf8 Class Initialized
INFO - 2020-10-21 03:07:44 --> URI Class Initialized
INFO - 2020-10-21 03:07:44 --> Router Class Initialized
INFO - 2020-10-21 03:07:44 --> Output Class Initialized
INFO - 2020-10-21 03:07:44 --> Security Class Initialized
DEBUG - 2020-10-21 03:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:07:44 --> Input Class Initialized
INFO - 2020-10-21 03:07:44 --> Language Class Initialized
INFO - 2020-10-21 03:07:44 --> Language Class Initialized
INFO - 2020-10-21 03:07:44 --> Config Class Initialized
INFO - 2020-10-21 03:07:44 --> Loader Class Initialized
INFO - 2020-10-21 03:07:44 --> Helper loaded: url_helper
INFO - 2020-10-21 03:07:44 --> Helper loaded: file_helper
INFO - 2020-10-21 03:07:44 --> Helper loaded: form_helper
INFO - 2020-10-21 03:07:44 --> Helper loaded: my_helper
INFO - 2020-10-21 03:07:44 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:07:44 --> Controller Class Initialized
INFO - 2020-10-21 03:07:44 --> Final output sent to browser
DEBUG - 2020-10-21 03:07:44 --> Total execution time: 0.2243
INFO - 2020-10-21 03:08:46 --> Config Class Initialized
INFO - 2020-10-21 03:08:46 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:08:46 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:08:46 --> Utf8 Class Initialized
INFO - 2020-10-21 03:08:46 --> URI Class Initialized
INFO - 2020-10-21 03:08:46 --> Router Class Initialized
INFO - 2020-10-21 03:08:46 --> Output Class Initialized
INFO - 2020-10-21 03:08:46 --> Security Class Initialized
DEBUG - 2020-10-21 03:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:08:46 --> Input Class Initialized
INFO - 2020-10-21 03:08:46 --> Language Class Initialized
INFO - 2020-10-21 03:08:46 --> Language Class Initialized
INFO - 2020-10-21 03:08:46 --> Config Class Initialized
INFO - 2020-10-21 03:08:46 --> Loader Class Initialized
INFO - 2020-10-21 03:08:46 --> Helper loaded: url_helper
INFO - 2020-10-21 03:08:46 --> Helper loaded: file_helper
INFO - 2020-10-21 03:08:46 --> Helper loaded: form_helper
INFO - 2020-10-21 03:08:46 --> Helper loaded: my_helper
INFO - 2020-10-21 03:08:46 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:08:46 --> Controller Class Initialized
ERROR - 2020-10-21 03:08:46 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:08:46 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:08:46 --> Final output sent to browser
DEBUG - 2020-10-21 03:08:46 --> Total execution time: 0.2591
INFO - 2020-10-21 03:08:47 --> Config Class Initialized
INFO - 2020-10-21 03:08:47 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:08:47 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:08:47 --> Utf8 Class Initialized
INFO - 2020-10-21 03:08:47 --> URI Class Initialized
INFO - 2020-10-21 03:08:47 --> Router Class Initialized
INFO - 2020-10-21 03:08:47 --> Output Class Initialized
INFO - 2020-10-21 03:08:47 --> Security Class Initialized
DEBUG - 2020-10-21 03:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:08:47 --> Input Class Initialized
INFO - 2020-10-21 03:08:47 --> Language Class Initialized
INFO - 2020-10-21 03:08:47 --> Language Class Initialized
INFO - 2020-10-21 03:08:47 --> Config Class Initialized
INFO - 2020-10-21 03:08:47 --> Loader Class Initialized
INFO - 2020-10-21 03:08:47 --> Helper loaded: url_helper
INFO - 2020-10-21 03:08:47 --> Helper loaded: file_helper
INFO - 2020-10-21 03:08:47 --> Helper loaded: form_helper
INFO - 2020-10-21 03:08:47 --> Helper loaded: my_helper
INFO - 2020-10-21 03:08:47 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:08:47 --> Controller Class Initialized
DEBUG - 2020-10-21 03:08:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:08:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:08:47 --> Final output sent to browser
DEBUG - 2020-10-21 03:08:47 --> Total execution time: 0.2451
INFO - 2020-10-21 03:08:47 --> Config Class Initialized
INFO - 2020-10-21 03:08:47 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:08:47 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:08:47 --> Utf8 Class Initialized
INFO - 2020-10-21 03:08:47 --> URI Class Initialized
INFO - 2020-10-21 03:08:47 --> Router Class Initialized
INFO - 2020-10-21 03:08:47 --> Output Class Initialized
INFO - 2020-10-21 03:08:47 --> Security Class Initialized
DEBUG - 2020-10-21 03:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:08:47 --> Input Class Initialized
INFO - 2020-10-21 03:08:47 --> Language Class Initialized
INFO - 2020-10-21 03:08:47 --> Language Class Initialized
INFO - 2020-10-21 03:08:47 --> Config Class Initialized
INFO - 2020-10-21 03:08:47 --> Loader Class Initialized
INFO - 2020-10-21 03:08:47 --> Helper loaded: url_helper
INFO - 2020-10-21 03:08:47 --> Helper loaded: file_helper
INFO - 2020-10-21 03:08:47 --> Helper loaded: form_helper
INFO - 2020-10-21 03:08:47 --> Helper loaded: my_helper
INFO - 2020-10-21 03:08:48 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:08:48 --> Controller Class Initialized
INFO - 2020-10-21 03:09:36 --> Config Class Initialized
INFO - 2020-10-21 03:09:36 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:09:36 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:09:36 --> Utf8 Class Initialized
INFO - 2020-10-21 03:09:36 --> URI Class Initialized
INFO - 2020-10-21 03:09:36 --> Router Class Initialized
INFO - 2020-10-21 03:09:36 --> Output Class Initialized
INFO - 2020-10-21 03:09:36 --> Security Class Initialized
DEBUG - 2020-10-21 03:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:09:36 --> Input Class Initialized
INFO - 2020-10-21 03:09:36 --> Language Class Initialized
INFO - 2020-10-21 03:09:36 --> Language Class Initialized
INFO - 2020-10-21 03:09:36 --> Config Class Initialized
INFO - 2020-10-21 03:09:36 --> Loader Class Initialized
INFO - 2020-10-21 03:09:36 --> Helper loaded: url_helper
INFO - 2020-10-21 03:09:36 --> Helper loaded: file_helper
INFO - 2020-10-21 03:09:36 --> Helper loaded: form_helper
INFO - 2020-10-21 03:09:36 --> Helper loaded: my_helper
INFO - 2020-10-21 03:09:36 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:09:36 --> Controller Class Initialized
INFO - 2020-10-21 03:09:36 --> Final output sent to browser
DEBUG - 2020-10-21 03:09:36 --> Total execution time: 0.2419
INFO - 2020-10-21 03:09:50 --> Config Class Initialized
INFO - 2020-10-21 03:09:50 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:09:50 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:09:50 --> Utf8 Class Initialized
INFO - 2020-10-21 03:09:50 --> URI Class Initialized
INFO - 2020-10-21 03:09:50 --> Router Class Initialized
INFO - 2020-10-21 03:09:50 --> Output Class Initialized
INFO - 2020-10-21 03:09:50 --> Security Class Initialized
DEBUG - 2020-10-21 03:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:09:50 --> Input Class Initialized
INFO - 2020-10-21 03:09:50 --> Language Class Initialized
INFO - 2020-10-21 03:09:50 --> Language Class Initialized
INFO - 2020-10-21 03:09:50 --> Config Class Initialized
INFO - 2020-10-21 03:09:50 --> Loader Class Initialized
INFO - 2020-10-21 03:09:50 --> Helper loaded: url_helper
INFO - 2020-10-21 03:09:50 --> Helper loaded: file_helper
INFO - 2020-10-21 03:09:50 --> Helper loaded: form_helper
INFO - 2020-10-21 03:09:50 --> Helper loaded: my_helper
INFO - 2020-10-21 03:09:50 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:09:50 --> Controller Class Initialized
INFO - 2020-10-21 03:09:50 --> Final output sent to browser
DEBUG - 2020-10-21 03:09:50 --> Total execution time: 0.2312
INFO - 2020-10-21 03:09:54 --> Config Class Initialized
INFO - 2020-10-21 03:09:54 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:09:54 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:09:54 --> Utf8 Class Initialized
INFO - 2020-10-21 03:09:54 --> URI Class Initialized
INFO - 2020-10-21 03:09:54 --> Router Class Initialized
INFO - 2020-10-21 03:09:54 --> Output Class Initialized
INFO - 2020-10-21 03:09:54 --> Security Class Initialized
DEBUG - 2020-10-21 03:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:09:54 --> Input Class Initialized
INFO - 2020-10-21 03:09:54 --> Language Class Initialized
INFO - 2020-10-21 03:09:54 --> Language Class Initialized
INFO - 2020-10-21 03:09:54 --> Config Class Initialized
INFO - 2020-10-21 03:09:54 --> Loader Class Initialized
INFO - 2020-10-21 03:09:54 --> Helper loaded: url_helper
INFO - 2020-10-21 03:09:54 --> Helper loaded: file_helper
INFO - 2020-10-21 03:09:54 --> Helper loaded: form_helper
INFO - 2020-10-21 03:09:54 --> Helper loaded: my_helper
INFO - 2020-10-21 03:09:54 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:09:54 --> Controller Class Initialized
INFO - 2020-10-21 03:09:54 --> Final output sent to browser
DEBUG - 2020-10-21 03:09:54 --> Total execution time: 0.2500
INFO - 2020-10-21 03:09:54 --> Config Class Initialized
INFO - 2020-10-21 03:09:54 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:09:54 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:09:54 --> Utf8 Class Initialized
INFO - 2020-10-21 03:09:54 --> URI Class Initialized
INFO - 2020-10-21 03:09:54 --> Router Class Initialized
INFO - 2020-10-21 03:09:54 --> Output Class Initialized
INFO - 2020-10-21 03:09:54 --> Security Class Initialized
DEBUG - 2020-10-21 03:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:09:54 --> Input Class Initialized
INFO - 2020-10-21 03:09:54 --> Language Class Initialized
INFO - 2020-10-21 03:09:54 --> Language Class Initialized
INFO - 2020-10-21 03:09:54 --> Config Class Initialized
INFO - 2020-10-21 03:09:54 --> Loader Class Initialized
INFO - 2020-10-21 03:09:54 --> Helper loaded: url_helper
INFO - 2020-10-21 03:09:54 --> Helper loaded: file_helper
INFO - 2020-10-21 03:09:54 --> Helper loaded: form_helper
INFO - 2020-10-21 03:09:54 --> Helper loaded: my_helper
INFO - 2020-10-21 03:09:54 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:09:54 --> Controller Class Initialized
INFO - 2020-10-21 03:09:57 --> Config Class Initialized
INFO - 2020-10-21 03:09:57 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:09:57 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:09:57 --> Utf8 Class Initialized
INFO - 2020-10-21 03:09:57 --> URI Class Initialized
INFO - 2020-10-21 03:09:57 --> Router Class Initialized
INFO - 2020-10-21 03:09:57 --> Output Class Initialized
INFO - 2020-10-21 03:09:57 --> Security Class Initialized
DEBUG - 2020-10-21 03:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:09:57 --> Input Class Initialized
INFO - 2020-10-21 03:09:57 --> Language Class Initialized
INFO - 2020-10-21 03:09:57 --> Language Class Initialized
INFO - 2020-10-21 03:09:57 --> Config Class Initialized
INFO - 2020-10-21 03:09:57 --> Loader Class Initialized
INFO - 2020-10-21 03:09:57 --> Helper loaded: url_helper
INFO - 2020-10-21 03:09:57 --> Helper loaded: file_helper
INFO - 2020-10-21 03:09:57 --> Helper loaded: form_helper
INFO - 2020-10-21 03:09:57 --> Helper loaded: my_helper
INFO - 2020-10-21 03:09:57 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:09:57 --> Controller Class Initialized
INFO - 2020-10-21 03:09:57 --> Final output sent to browser
DEBUG - 2020-10-21 03:09:57 --> Total execution time: 0.2600
INFO - 2020-10-21 03:10:04 --> Config Class Initialized
INFO - 2020-10-21 03:10:04 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:10:04 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:10:04 --> Utf8 Class Initialized
INFO - 2020-10-21 03:10:04 --> URI Class Initialized
INFO - 2020-10-21 03:10:04 --> Router Class Initialized
INFO - 2020-10-21 03:10:04 --> Output Class Initialized
INFO - 2020-10-21 03:10:04 --> Security Class Initialized
DEBUG - 2020-10-21 03:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:10:04 --> Input Class Initialized
INFO - 2020-10-21 03:10:04 --> Language Class Initialized
INFO - 2020-10-21 03:10:04 --> Language Class Initialized
INFO - 2020-10-21 03:10:04 --> Config Class Initialized
INFO - 2020-10-21 03:10:04 --> Loader Class Initialized
INFO - 2020-10-21 03:10:04 --> Helper loaded: url_helper
INFO - 2020-10-21 03:10:04 --> Helper loaded: file_helper
INFO - 2020-10-21 03:10:04 --> Helper loaded: form_helper
INFO - 2020-10-21 03:10:04 --> Helper loaded: my_helper
INFO - 2020-10-21 03:10:04 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:10:04 --> Controller Class Initialized
INFO - 2020-10-21 03:10:04 --> Final output sent to browser
DEBUG - 2020-10-21 03:10:04 --> Total execution time: 0.2334
INFO - 2020-10-21 03:10:04 --> Config Class Initialized
INFO - 2020-10-21 03:10:04 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:10:04 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:10:04 --> Utf8 Class Initialized
INFO - 2020-10-21 03:10:04 --> URI Class Initialized
INFO - 2020-10-21 03:10:04 --> Router Class Initialized
INFO - 2020-10-21 03:10:04 --> Output Class Initialized
INFO - 2020-10-21 03:10:04 --> Security Class Initialized
DEBUG - 2020-10-21 03:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:10:04 --> Input Class Initialized
INFO - 2020-10-21 03:10:04 --> Language Class Initialized
INFO - 2020-10-21 03:10:04 --> Language Class Initialized
INFO - 2020-10-21 03:10:04 --> Config Class Initialized
INFO - 2020-10-21 03:10:04 --> Loader Class Initialized
INFO - 2020-10-21 03:10:04 --> Helper loaded: url_helper
INFO - 2020-10-21 03:10:04 --> Helper loaded: file_helper
INFO - 2020-10-21 03:10:04 --> Helper loaded: form_helper
INFO - 2020-10-21 03:10:04 --> Helper loaded: my_helper
INFO - 2020-10-21 03:10:04 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:10:04 --> Controller Class Initialized
INFO - 2020-10-21 03:10:06 --> Config Class Initialized
INFO - 2020-10-21 03:10:06 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:10:06 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:10:06 --> Utf8 Class Initialized
INFO - 2020-10-21 03:10:06 --> URI Class Initialized
INFO - 2020-10-21 03:10:06 --> Router Class Initialized
INFO - 2020-10-21 03:10:06 --> Output Class Initialized
INFO - 2020-10-21 03:10:06 --> Security Class Initialized
DEBUG - 2020-10-21 03:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:10:06 --> Input Class Initialized
INFO - 2020-10-21 03:10:06 --> Language Class Initialized
INFO - 2020-10-21 03:10:06 --> Language Class Initialized
INFO - 2020-10-21 03:10:06 --> Config Class Initialized
INFO - 2020-10-21 03:10:06 --> Loader Class Initialized
INFO - 2020-10-21 03:10:06 --> Helper loaded: url_helper
INFO - 2020-10-21 03:10:06 --> Helper loaded: file_helper
INFO - 2020-10-21 03:10:06 --> Helper loaded: form_helper
INFO - 2020-10-21 03:10:06 --> Helper loaded: my_helper
INFO - 2020-10-21 03:10:06 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:10:06 --> Controller Class Initialized
INFO - 2020-10-21 03:10:06 --> Final output sent to browser
DEBUG - 2020-10-21 03:10:06 --> Total execution time: 0.2448
INFO - 2020-10-21 03:10:13 --> Config Class Initialized
INFO - 2020-10-21 03:10:13 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:10:13 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:10:13 --> Utf8 Class Initialized
INFO - 2020-10-21 03:10:13 --> URI Class Initialized
INFO - 2020-10-21 03:10:13 --> Router Class Initialized
INFO - 2020-10-21 03:10:13 --> Output Class Initialized
INFO - 2020-10-21 03:10:13 --> Security Class Initialized
DEBUG - 2020-10-21 03:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:10:13 --> Input Class Initialized
INFO - 2020-10-21 03:10:13 --> Language Class Initialized
INFO - 2020-10-21 03:10:13 --> Language Class Initialized
INFO - 2020-10-21 03:10:13 --> Config Class Initialized
INFO - 2020-10-21 03:10:13 --> Loader Class Initialized
INFO - 2020-10-21 03:10:13 --> Helper loaded: url_helper
INFO - 2020-10-21 03:10:13 --> Helper loaded: file_helper
INFO - 2020-10-21 03:10:13 --> Helper loaded: form_helper
INFO - 2020-10-21 03:10:13 --> Helper loaded: my_helper
INFO - 2020-10-21 03:10:13 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:10:13 --> Controller Class Initialized
INFO - 2020-10-21 03:10:13 --> Final output sent to browser
DEBUG - 2020-10-21 03:10:13 --> Total execution time: 0.2663
INFO - 2020-10-21 03:10:13 --> Config Class Initialized
INFO - 2020-10-21 03:10:13 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:10:13 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:10:13 --> Utf8 Class Initialized
INFO - 2020-10-21 03:10:13 --> URI Class Initialized
INFO - 2020-10-21 03:10:13 --> Router Class Initialized
INFO - 2020-10-21 03:10:13 --> Output Class Initialized
INFO - 2020-10-21 03:10:13 --> Security Class Initialized
DEBUG - 2020-10-21 03:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:10:13 --> Input Class Initialized
INFO - 2020-10-21 03:10:13 --> Language Class Initialized
INFO - 2020-10-21 03:10:13 --> Language Class Initialized
INFO - 2020-10-21 03:10:13 --> Config Class Initialized
INFO - 2020-10-21 03:10:13 --> Loader Class Initialized
INFO - 2020-10-21 03:10:13 --> Helper loaded: url_helper
INFO - 2020-10-21 03:10:13 --> Helper loaded: file_helper
INFO - 2020-10-21 03:10:13 --> Helper loaded: form_helper
INFO - 2020-10-21 03:10:13 --> Helper loaded: my_helper
INFO - 2020-10-21 03:10:13 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:10:13 --> Controller Class Initialized
INFO - 2020-10-21 03:10:15 --> Config Class Initialized
INFO - 2020-10-21 03:10:15 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:10:15 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:10:15 --> Utf8 Class Initialized
INFO - 2020-10-21 03:10:15 --> URI Class Initialized
INFO - 2020-10-21 03:10:15 --> Router Class Initialized
INFO - 2020-10-21 03:10:15 --> Output Class Initialized
INFO - 2020-10-21 03:10:15 --> Security Class Initialized
DEBUG - 2020-10-21 03:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:10:15 --> Input Class Initialized
INFO - 2020-10-21 03:10:15 --> Language Class Initialized
INFO - 2020-10-21 03:10:15 --> Language Class Initialized
INFO - 2020-10-21 03:10:15 --> Config Class Initialized
INFO - 2020-10-21 03:10:15 --> Loader Class Initialized
INFO - 2020-10-21 03:10:15 --> Helper loaded: url_helper
INFO - 2020-10-21 03:10:15 --> Helper loaded: file_helper
INFO - 2020-10-21 03:10:15 --> Helper loaded: form_helper
INFO - 2020-10-21 03:10:15 --> Helper loaded: my_helper
INFO - 2020-10-21 03:10:15 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:10:15 --> Controller Class Initialized
INFO - 2020-10-21 03:10:15 --> Final output sent to browser
DEBUG - 2020-10-21 03:10:15 --> Total execution time: 0.2634
INFO - 2020-10-21 03:10:20 --> Config Class Initialized
INFO - 2020-10-21 03:10:20 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:10:20 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:10:20 --> Utf8 Class Initialized
INFO - 2020-10-21 03:10:20 --> URI Class Initialized
INFO - 2020-10-21 03:10:20 --> Router Class Initialized
INFO - 2020-10-21 03:10:20 --> Output Class Initialized
INFO - 2020-10-21 03:10:20 --> Security Class Initialized
DEBUG - 2020-10-21 03:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:10:20 --> Input Class Initialized
INFO - 2020-10-21 03:10:20 --> Language Class Initialized
INFO - 2020-10-21 03:10:20 --> Language Class Initialized
INFO - 2020-10-21 03:10:20 --> Config Class Initialized
INFO - 2020-10-21 03:10:20 --> Loader Class Initialized
INFO - 2020-10-21 03:10:20 --> Helper loaded: url_helper
INFO - 2020-10-21 03:10:20 --> Helper loaded: file_helper
INFO - 2020-10-21 03:10:20 --> Helper loaded: form_helper
INFO - 2020-10-21 03:10:20 --> Helper loaded: my_helper
INFO - 2020-10-21 03:10:20 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:10:20 --> Controller Class Initialized
INFO - 2020-10-21 03:10:20 --> Final output sent to browser
DEBUG - 2020-10-21 03:10:20 --> Total execution time: 0.2846
INFO - 2020-10-21 03:10:20 --> Config Class Initialized
INFO - 2020-10-21 03:10:20 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:10:20 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:10:20 --> Utf8 Class Initialized
INFO - 2020-10-21 03:10:20 --> URI Class Initialized
INFO - 2020-10-21 03:10:21 --> Router Class Initialized
INFO - 2020-10-21 03:10:21 --> Output Class Initialized
INFO - 2020-10-21 03:10:21 --> Security Class Initialized
DEBUG - 2020-10-21 03:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:10:21 --> Input Class Initialized
INFO - 2020-10-21 03:10:21 --> Language Class Initialized
INFO - 2020-10-21 03:10:21 --> Language Class Initialized
INFO - 2020-10-21 03:10:21 --> Config Class Initialized
INFO - 2020-10-21 03:10:21 --> Loader Class Initialized
INFO - 2020-10-21 03:10:21 --> Helper loaded: url_helper
INFO - 2020-10-21 03:10:21 --> Helper loaded: file_helper
INFO - 2020-10-21 03:10:21 --> Helper loaded: form_helper
INFO - 2020-10-21 03:10:21 --> Helper loaded: my_helper
INFO - 2020-10-21 03:10:21 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:10:21 --> Controller Class Initialized
INFO - 2020-10-21 03:11:03 --> Config Class Initialized
INFO - 2020-10-21 03:11:03 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:11:03 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:11:03 --> Utf8 Class Initialized
INFO - 2020-10-21 03:11:03 --> URI Class Initialized
INFO - 2020-10-21 03:11:03 --> Router Class Initialized
INFO - 2020-10-21 03:11:03 --> Output Class Initialized
INFO - 2020-10-21 03:11:03 --> Security Class Initialized
DEBUG - 2020-10-21 03:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:11:03 --> Input Class Initialized
INFO - 2020-10-21 03:11:03 --> Language Class Initialized
INFO - 2020-10-21 03:11:03 --> Language Class Initialized
INFO - 2020-10-21 03:11:04 --> Config Class Initialized
INFO - 2020-10-21 03:11:04 --> Loader Class Initialized
INFO - 2020-10-21 03:11:04 --> Helper loaded: url_helper
INFO - 2020-10-21 03:11:04 --> Helper loaded: file_helper
INFO - 2020-10-21 03:11:04 --> Helper loaded: form_helper
INFO - 2020-10-21 03:11:04 --> Helper loaded: my_helper
INFO - 2020-10-21 03:11:04 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:11:04 --> Controller Class Initialized
INFO - 2020-10-21 03:11:04 --> Final output sent to browser
DEBUG - 2020-10-21 03:11:04 --> Total execution time: 0.2346
INFO - 2020-10-21 03:11:12 --> Config Class Initialized
INFO - 2020-10-21 03:11:12 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:11:12 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:11:12 --> Utf8 Class Initialized
INFO - 2020-10-21 03:11:12 --> URI Class Initialized
INFO - 2020-10-21 03:11:12 --> Router Class Initialized
INFO - 2020-10-21 03:11:12 --> Output Class Initialized
INFO - 2020-10-21 03:11:12 --> Security Class Initialized
DEBUG - 2020-10-21 03:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:11:12 --> Input Class Initialized
INFO - 2020-10-21 03:11:12 --> Language Class Initialized
INFO - 2020-10-21 03:11:12 --> Language Class Initialized
INFO - 2020-10-21 03:11:12 --> Config Class Initialized
INFO - 2020-10-21 03:11:12 --> Loader Class Initialized
INFO - 2020-10-21 03:11:12 --> Helper loaded: url_helper
INFO - 2020-10-21 03:11:12 --> Helper loaded: file_helper
INFO - 2020-10-21 03:11:12 --> Helper loaded: form_helper
INFO - 2020-10-21 03:11:12 --> Helper loaded: my_helper
INFO - 2020-10-21 03:11:12 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:11:12 --> Controller Class Initialized
INFO - 2020-10-21 03:11:12 --> Final output sent to browser
DEBUG - 2020-10-21 03:11:12 --> Total execution time: 0.2339
INFO - 2020-10-21 03:11:30 --> Config Class Initialized
INFO - 2020-10-21 03:11:30 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:11:30 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:11:30 --> Utf8 Class Initialized
INFO - 2020-10-21 03:11:30 --> URI Class Initialized
INFO - 2020-10-21 03:11:30 --> Router Class Initialized
INFO - 2020-10-21 03:11:30 --> Output Class Initialized
INFO - 2020-10-21 03:11:30 --> Security Class Initialized
DEBUG - 2020-10-21 03:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:11:30 --> Input Class Initialized
INFO - 2020-10-21 03:11:30 --> Language Class Initialized
INFO - 2020-10-21 03:11:30 --> Language Class Initialized
INFO - 2020-10-21 03:11:30 --> Config Class Initialized
INFO - 2020-10-21 03:11:30 --> Loader Class Initialized
INFO - 2020-10-21 03:11:30 --> Helper loaded: url_helper
INFO - 2020-10-21 03:11:30 --> Helper loaded: file_helper
INFO - 2020-10-21 03:11:30 --> Helper loaded: form_helper
INFO - 2020-10-21 03:11:30 --> Helper loaded: my_helper
INFO - 2020-10-21 03:11:30 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:11:30 --> Controller Class Initialized
INFO - 2020-10-21 03:11:30 --> Final output sent to browser
DEBUG - 2020-10-21 03:11:30 --> Total execution time: 0.2680
INFO - 2020-10-21 03:11:30 --> Config Class Initialized
INFO - 2020-10-21 03:11:30 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:11:30 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:11:30 --> Utf8 Class Initialized
INFO - 2020-10-21 03:11:30 --> URI Class Initialized
INFO - 2020-10-21 03:11:30 --> Router Class Initialized
INFO - 2020-10-21 03:11:30 --> Output Class Initialized
INFO - 2020-10-21 03:11:30 --> Security Class Initialized
DEBUG - 2020-10-21 03:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:11:30 --> Input Class Initialized
INFO - 2020-10-21 03:11:30 --> Language Class Initialized
INFO - 2020-10-21 03:11:30 --> Language Class Initialized
INFO - 2020-10-21 03:11:30 --> Config Class Initialized
INFO - 2020-10-21 03:11:30 --> Loader Class Initialized
INFO - 2020-10-21 03:11:30 --> Helper loaded: url_helper
INFO - 2020-10-21 03:11:30 --> Helper loaded: file_helper
INFO - 2020-10-21 03:11:30 --> Helper loaded: form_helper
INFO - 2020-10-21 03:11:30 --> Helper loaded: my_helper
INFO - 2020-10-21 03:11:30 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:11:30 --> Controller Class Initialized
INFO - 2020-10-21 03:12:23 --> Config Class Initialized
INFO - 2020-10-21 03:12:23 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:12:23 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:12:23 --> Utf8 Class Initialized
INFO - 2020-10-21 03:12:23 --> URI Class Initialized
INFO - 2020-10-21 03:12:23 --> Router Class Initialized
INFO - 2020-10-21 03:12:23 --> Output Class Initialized
INFO - 2020-10-21 03:12:23 --> Security Class Initialized
DEBUG - 2020-10-21 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:12:23 --> Input Class Initialized
INFO - 2020-10-21 03:12:23 --> Language Class Initialized
INFO - 2020-10-21 03:12:23 --> Language Class Initialized
INFO - 2020-10-21 03:12:23 --> Config Class Initialized
INFO - 2020-10-21 03:12:24 --> Loader Class Initialized
INFO - 2020-10-21 03:12:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:12:24 --> Helper loaded: file_helper
INFO - 2020-10-21 03:12:24 --> Helper loaded: form_helper
INFO - 2020-10-21 03:12:24 --> Helper loaded: my_helper
INFO - 2020-10-21 03:12:24 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:12:24 --> Controller Class Initialized
DEBUG - 2020-10-21 03:12:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:12:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:12:24 --> Final output sent to browser
DEBUG - 2020-10-21 03:12:24 --> Total execution time: 0.2397
INFO - 2020-10-21 03:12:24 --> Config Class Initialized
INFO - 2020-10-21 03:12:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:12:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:12:24 --> Utf8 Class Initialized
INFO - 2020-10-21 03:12:24 --> URI Class Initialized
INFO - 2020-10-21 03:12:24 --> Router Class Initialized
INFO - 2020-10-21 03:12:24 --> Output Class Initialized
INFO - 2020-10-21 03:12:24 --> Security Class Initialized
DEBUG - 2020-10-21 03:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:12:24 --> Input Class Initialized
INFO - 2020-10-21 03:12:24 --> Language Class Initialized
INFO - 2020-10-21 03:12:24 --> Language Class Initialized
INFO - 2020-10-21 03:12:24 --> Config Class Initialized
INFO - 2020-10-21 03:12:24 --> Loader Class Initialized
INFO - 2020-10-21 03:12:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:12:24 --> Helper loaded: file_helper
INFO - 2020-10-21 03:12:24 --> Helper loaded: form_helper
INFO - 2020-10-21 03:12:24 --> Helper loaded: my_helper
INFO - 2020-10-21 03:12:24 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:12:24 --> Controller Class Initialized
INFO - 2020-10-21 03:12:25 --> Config Class Initialized
INFO - 2020-10-21 03:12:25 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:12:25 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:12:25 --> Utf8 Class Initialized
INFO - 2020-10-21 03:12:25 --> URI Class Initialized
INFO - 2020-10-21 03:12:25 --> Router Class Initialized
INFO - 2020-10-21 03:12:25 --> Output Class Initialized
INFO - 2020-10-21 03:12:25 --> Security Class Initialized
DEBUG - 2020-10-21 03:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:12:25 --> Input Class Initialized
INFO - 2020-10-21 03:12:25 --> Language Class Initialized
INFO - 2020-10-21 03:12:25 --> Language Class Initialized
INFO - 2020-10-21 03:12:25 --> Config Class Initialized
INFO - 2020-10-21 03:12:25 --> Loader Class Initialized
INFO - 2020-10-21 03:12:25 --> Helper loaded: url_helper
INFO - 2020-10-21 03:12:25 --> Helper loaded: file_helper
INFO - 2020-10-21 03:12:25 --> Helper loaded: form_helper
INFO - 2020-10-21 03:12:25 --> Helper loaded: my_helper
INFO - 2020-10-21 03:12:25 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:12:25 --> Controller Class Initialized
INFO - 2020-10-21 03:12:25 --> Final output sent to browser
DEBUG - 2020-10-21 03:12:25 --> Total execution time: 0.2262
INFO - 2020-10-21 03:12:34 --> Config Class Initialized
INFO - 2020-10-21 03:12:34 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:12:34 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:12:34 --> Utf8 Class Initialized
INFO - 2020-10-21 03:12:35 --> URI Class Initialized
INFO - 2020-10-21 03:12:35 --> Router Class Initialized
INFO - 2020-10-21 03:12:35 --> Output Class Initialized
INFO - 2020-10-21 03:12:35 --> Security Class Initialized
DEBUG - 2020-10-21 03:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:12:35 --> Input Class Initialized
INFO - 2020-10-21 03:12:35 --> Language Class Initialized
INFO - 2020-10-21 03:12:35 --> Language Class Initialized
INFO - 2020-10-21 03:12:35 --> Config Class Initialized
INFO - 2020-10-21 03:12:35 --> Loader Class Initialized
INFO - 2020-10-21 03:12:35 --> Helper loaded: url_helper
INFO - 2020-10-21 03:12:35 --> Helper loaded: file_helper
INFO - 2020-10-21 03:12:35 --> Helper loaded: form_helper
INFO - 2020-10-21 03:12:35 --> Helper loaded: my_helper
INFO - 2020-10-21 03:12:35 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:12:35 --> Controller Class Initialized
INFO - 2020-10-21 03:12:35 --> Final output sent to browser
DEBUG - 2020-10-21 03:12:35 --> Total execution time: 0.2302
INFO - 2020-10-21 03:12:42 --> Config Class Initialized
INFO - 2020-10-21 03:12:42 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:12:42 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:12:42 --> Utf8 Class Initialized
INFO - 2020-10-21 03:12:42 --> URI Class Initialized
INFO - 2020-10-21 03:12:42 --> Router Class Initialized
INFO - 2020-10-21 03:12:42 --> Output Class Initialized
INFO - 2020-10-21 03:12:42 --> Security Class Initialized
DEBUG - 2020-10-21 03:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:12:42 --> Input Class Initialized
INFO - 2020-10-21 03:12:42 --> Language Class Initialized
INFO - 2020-10-21 03:12:42 --> Language Class Initialized
INFO - 2020-10-21 03:12:42 --> Config Class Initialized
INFO - 2020-10-21 03:12:42 --> Loader Class Initialized
INFO - 2020-10-21 03:12:42 --> Helper loaded: url_helper
INFO - 2020-10-21 03:12:42 --> Helper loaded: file_helper
INFO - 2020-10-21 03:12:42 --> Helper loaded: form_helper
INFO - 2020-10-21 03:12:42 --> Helper loaded: my_helper
INFO - 2020-10-21 03:12:42 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:12:42 --> Controller Class Initialized
ERROR - 2020-10-21 03:12:42 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:12:42 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:12:42 --> Final output sent to browser
DEBUG - 2020-10-21 03:12:42 --> Total execution time: 0.2710
INFO - 2020-10-21 03:12:44 --> Config Class Initialized
INFO - 2020-10-21 03:12:44 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:12:44 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:12:44 --> Utf8 Class Initialized
INFO - 2020-10-21 03:12:44 --> URI Class Initialized
INFO - 2020-10-21 03:12:44 --> Router Class Initialized
INFO - 2020-10-21 03:12:44 --> Output Class Initialized
INFO - 2020-10-21 03:12:44 --> Security Class Initialized
DEBUG - 2020-10-21 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:12:44 --> Input Class Initialized
INFO - 2020-10-21 03:12:44 --> Language Class Initialized
INFO - 2020-10-21 03:12:44 --> Language Class Initialized
INFO - 2020-10-21 03:12:44 --> Config Class Initialized
INFO - 2020-10-21 03:12:44 --> Loader Class Initialized
INFO - 2020-10-21 03:12:44 --> Helper loaded: url_helper
INFO - 2020-10-21 03:12:44 --> Helper loaded: file_helper
INFO - 2020-10-21 03:12:44 --> Helper loaded: form_helper
INFO - 2020-10-21 03:12:44 --> Helper loaded: my_helper
INFO - 2020-10-21 03:12:44 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:12:44 --> Controller Class Initialized
DEBUG - 2020-10-21 03:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:12:44 --> Final output sent to browser
DEBUG - 2020-10-21 03:12:44 --> Total execution time: 0.2405
INFO - 2020-10-21 03:12:44 --> Config Class Initialized
INFO - 2020-10-21 03:12:44 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:12:44 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:12:44 --> Utf8 Class Initialized
INFO - 2020-10-21 03:12:44 --> URI Class Initialized
INFO - 2020-10-21 03:12:44 --> Router Class Initialized
INFO - 2020-10-21 03:12:44 --> Output Class Initialized
INFO - 2020-10-21 03:12:44 --> Security Class Initialized
DEBUG - 2020-10-21 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:12:44 --> Input Class Initialized
INFO - 2020-10-21 03:12:44 --> Language Class Initialized
INFO - 2020-10-21 03:12:44 --> Language Class Initialized
INFO - 2020-10-21 03:12:44 --> Config Class Initialized
INFO - 2020-10-21 03:12:44 --> Loader Class Initialized
INFO - 2020-10-21 03:12:44 --> Helper loaded: url_helper
INFO - 2020-10-21 03:12:44 --> Helper loaded: file_helper
INFO - 2020-10-21 03:12:44 --> Helper loaded: form_helper
INFO - 2020-10-21 03:12:44 --> Helper loaded: my_helper
INFO - 2020-10-21 03:12:45 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:12:45 --> Controller Class Initialized
INFO - 2020-10-21 03:12:50 --> Config Class Initialized
INFO - 2020-10-21 03:12:50 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:12:50 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:12:50 --> Utf8 Class Initialized
INFO - 2020-10-21 03:12:50 --> URI Class Initialized
INFO - 2020-10-21 03:12:50 --> Router Class Initialized
INFO - 2020-10-21 03:12:50 --> Output Class Initialized
INFO - 2020-10-21 03:12:50 --> Security Class Initialized
DEBUG - 2020-10-21 03:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:12:50 --> Input Class Initialized
INFO - 2020-10-21 03:12:50 --> Language Class Initialized
INFO - 2020-10-21 03:12:50 --> Language Class Initialized
INFO - 2020-10-21 03:12:50 --> Config Class Initialized
INFO - 2020-10-21 03:12:50 --> Loader Class Initialized
INFO - 2020-10-21 03:12:51 --> Helper loaded: url_helper
INFO - 2020-10-21 03:12:51 --> Helper loaded: file_helper
INFO - 2020-10-21 03:12:51 --> Helper loaded: form_helper
INFO - 2020-10-21 03:12:51 --> Helper loaded: my_helper
INFO - 2020-10-21 03:12:51 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:12:51 --> Controller Class Initialized
INFO - 2020-10-21 03:12:51 --> Final output sent to browser
DEBUG - 2020-10-21 03:12:51 --> Total execution time: 0.2318
INFO - 2020-10-21 03:14:27 --> Config Class Initialized
INFO - 2020-10-21 03:14:27 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:14:27 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:14:27 --> Utf8 Class Initialized
INFO - 2020-10-21 03:14:27 --> URI Class Initialized
INFO - 2020-10-21 03:14:27 --> Router Class Initialized
INFO - 2020-10-21 03:14:27 --> Output Class Initialized
INFO - 2020-10-21 03:14:27 --> Security Class Initialized
DEBUG - 2020-10-21 03:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:14:27 --> Input Class Initialized
INFO - 2020-10-21 03:14:27 --> Language Class Initialized
INFO - 2020-10-21 03:14:27 --> Language Class Initialized
INFO - 2020-10-21 03:14:27 --> Config Class Initialized
INFO - 2020-10-21 03:14:27 --> Loader Class Initialized
INFO - 2020-10-21 03:14:27 --> Helper loaded: url_helper
INFO - 2020-10-21 03:14:27 --> Helper loaded: file_helper
INFO - 2020-10-21 03:14:27 --> Helper loaded: form_helper
INFO - 2020-10-21 03:14:27 --> Helper loaded: my_helper
INFO - 2020-10-21 03:14:27 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:14:27 --> Controller Class Initialized
DEBUG - 2020-10-21 03:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-21 03:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:14:27 --> Final output sent to browser
DEBUG - 2020-10-21 03:14:27 --> Total execution time: 0.2856
INFO - 2020-10-21 03:14:27 --> Config Class Initialized
INFO - 2020-10-21 03:14:28 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:14:28 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:14:28 --> Utf8 Class Initialized
INFO - 2020-10-21 03:14:28 --> URI Class Initialized
INFO - 2020-10-21 03:14:28 --> Router Class Initialized
INFO - 2020-10-21 03:14:28 --> Output Class Initialized
INFO - 2020-10-21 03:14:28 --> Security Class Initialized
DEBUG - 2020-10-21 03:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:14:28 --> Input Class Initialized
INFO - 2020-10-21 03:14:28 --> Language Class Initialized
INFO - 2020-10-21 03:14:28 --> Language Class Initialized
INFO - 2020-10-21 03:14:28 --> Config Class Initialized
INFO - 2020-10-21 03:14:28 --> Loader Class Initialized
INFO - 2020-10-21 03:14:28 --> Helper loaded: url_helper
INFO - 2020-10-21 03:14:28 --> Helper loaded: file_helper
INFO - 2020-10-21 03:14:28 --> Helper loaded: form_helper
INFO - 2020-10-21 03:14:28 --> Helper loaded: my_helper
INFO - 2020-10-21 03:14:28 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:14:28 --> Controller Class Initialized
INFO - 2020-10-21 03:14:29 --> Config Class Initialized
INFO - 2020-10-21 03:14:29 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:14:29 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:14:29 --> Utf8 Class Initialized
INFO - 2020-10-21 03:14:29 --> URI Class Initialized
INFO - 2020-10-21 03:14:29 --> Router Class Initialized
INFO - 2020-10-21 03:14:29 --> Output Class Initialized
INFO - 2020-10-21 03:14:29 --> Security Class Initialized
DEBUG - 2020-10-21 03:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:14:29 --> Input Class Initialized
INFO - 2020-10-21 03:14:29 --> Language Class Initialized
INFO - 2020-10-21 03:14:29 --> Language Class Initialized
INFO - 2020-10-21 03:14:29 --> Config Class Initialized
INFO - 2020-10-21 03:14:29 --> Loader Class Initialized
INFO - 2020-10-21 03:14:29 --> Helper loaded: url_helper
INFO - 2020-10-21 03:14:29 --> Helper loaded: file_helper
INFO - 2020-10-21 03:14:29 --> Helper loaded: form_helper
INFO - 2020-10-21 03:14:29 --> Helper loaded: my_helper
INFO - 2020-10-21 03:14:29 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:14:29 --> Controller Class Initialized
INFO - 2020-10-21 03:14:29 --> Final output sent to browser
DEBUG - 2020-10-21 03:14:29 --> Total execution time: 0.2526
INFO - 2020-10-21 03:15:23 --> Config Class Initialized
INFO - 2020-10-21 03:15:23 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:15:23 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:15:23 --> Utf8 Class Initialized
INFO - 2020-10-21 03:15:23 --> URI Class Initialized
INFO - 2020-10-21 03:15:23 --> Router Class Initialized
INFO - 2020-10-21 03:15:23 --> Output Class Initialized
INFO - 2020-10-21 03:15:23 --> Security Class Initialized
DEBUG - 2020-10-21 03:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:15:23 --> Input Class Initialized
INFO - 2020-10-21 03:15:23 --> Language Class Initialized
INFO - 2020-10-21 03:15:23 --> Language Class Initialized
INFO - 2020-10-21 03:15:23 --> Config Class Initialized
INFO - 2020-10-21 03:15:23 --> Loader Class Initialized
INFO - 2020-10-21 03:15:23 --> Helper loaded: url_helper
INFO - 2020-10-21 03:15:23 --> Helper loaded: file_helper
INFO - 2020-10-21 03:15:23 --> Helper loaded: form_helper
INFO - 2020-10-21 03:15:23 --> Helper loaded: my_helper
INFO - 2020-10-21 03:15:23 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:15:23 --> Controller Class Initialized
DEBUG - 2020-10-21 03:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-21 03:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:15:24 --> Final output sent to browser
DEBUG - 2020-10-21 03:15:24 --> Total execution time: 0.2932
INFO - 2020-10-21 03:15:24 --> Config Class Initialized
INFO - 2020-10-21 03:15:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:15:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:15:24 --> Utf8 Class Initialized
INFO - 2020-10-21 03:15:24 --> URI Class Initialized
INFO - 2020-10-21 03:15:24 --> Router Class Initialized
INFO - 2020-10-21 03:15:24 --> Output Class Initialized
INFO - 2020-10-21 03:15:24 --> Security Class Initialized
DEBUG - 2020-10-21 03:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:15:24 --> Input Class Initialized
INFO - 2020-10-21 03:15:24 --> Language Class Initialized
INFO - 2020-10-21 03:15:24 --> Language Class Initialized
INFO - 2020-10-21 03:15:24 --> Config Class Initialized
INFO - 2020-10-21 03:15:24 --> Loader Class Initialized
INFO - 2020-10-21 03:15:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:15:24 --> Helper loaded: file_helper
INFO - 2020-10-21 03:15:24 --> Helper loaded: form_helper
INFO - 2020-10-21 03:15:24 --> Helper loaded: my_helper
INFO - 2020-10-21 03:15:24 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:15:24 --> Controller Class Initialized
INFO - 2020-10-21 03:15:27 --> Config Class Initialized
INFO - 2020-10-21 03:15:27 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:15:27 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:15:27 --> Utf8 Class Initialized
INFO - 2020-10-21 03:15:27 --> URI Class Initialized
INFO - 2020-10-21 03:15:27 --> Router Class Initialized
INFO - 2020-10-21 03:15:27 --> Output Class Initialized
INFO - 2020-10-21 03:15:27 --> Security Class Initialized
DEBUG - 2020-10-21 03:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:15:27 --> Input Class Initialized
INFO - 2020-10-21 03:15:27 --> Language Class Initialized
INFO - 2020-10-21 03:15:27 --> Language Class Initialized
INFO - 2020-10-21 03:15:27 --> Config Class Initialized
INFO - 2020-10-21 03:15:27 --> Loader Class Initialized
INFO - 2020-10-21 03:15:27 --> Helper loaded: url_helper
INFO - 2020-10-21 03:15:27 --> Helper loaded: file_helper
INFO - 2020-10-21 03:15:27 --> Helper loaded: form_helper
INFO - 2020-10-21 03:15:27 --> Helper loaded: my_helper
INFO - 2020-10-21 03:15:27 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:15:27 --> Controller Class Initialized
DEBUG - 2020-10-21 03:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:15:27 --> Final output sent to browser
DEBUG - 2020-10-21 03:15:27 --> Total execution time: 0.2946
INFO - 2020-10-21 03:15:27 --> Config Class Initialized
INFO - 2020-10-21 03:15:27 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:15:27 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:15:27 --> Utf8 Class Initialized
INFO - 2020-10-21 03:15:27 --> URI Class Initialized
INFO - 2020-10-21 03:15:27 --> Router Class Initialized
INFO - 2020-10-21 03:15:27 --> Output Class Initialized
INFO - 2020-10-21 03:15:27 --> Security Class Initialized
DEBUG - 2020-10-21 03:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:15:27 --> Input Class Initialized
INFO - 2020-10-21 03:15:27 --> Language Class Initialized
INFO - 2020-10-21 03:15:27 --> Language Class Initialized
INFO - 2020-10-21 03:15:27 --> Config Class Initialized
INFO - 2020-10-21 03:15:27 --> Loader Class Initialized
INFO - 2020-10-21 03:15:27 --> Helper loaded: url_helper
INFO - 2020-10-21 03:15:27 --> Helper loaded: file_helper
INFO - 2020-10-21 03:15:27 --> Helper loaded: form_helper
INFO - 2020-10-21 03:15:27 --> Helper loaded: my_helper
INFO - 2020-10-21 03:15:27 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:15:27 --> Controller Class Initialized
INFO - 2020-10-21 03:15:28 --> Config Class Initialized
INFO - 2020-10-21 03:15:28 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:15:28 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:15:28 --> Utf8 Class Initialized
INFO - 2020-10-21 03:15:28 --> URI Class Initialized
INFO - 2020-10-21 03:15:28 --> Router Class Initialized
INFO - 2020-10-21 03:15:28 --> Output Class Initialized
INFO - 2020-10-21 03:15:28 --> Security Class Initialized
DEBUG - 2020-10-21 03:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:15:28 --> Input Class Initialized
INFO - 2020-10-21 03:15:28 --> Language Class Initialized
INFO - 2020-10-21 03:15:28 --> Language Class Initialized
INFO - 2020-10-21 03:15:28 --> Config Class Initialized
INFO - 2020-10-21 03:15:28 --> Loader Class Initialized
INFO - 2020-10-21 03:15:28 --> Helper loaded: url_helper
INFO - 2020-10-21 03:15:28 --> Helper loaded: file_helper
INFO - 2020-10-21 03:15:28 --> Helper loaded: form_helper
INFO - 2020-10-21 03:15:28 --> Helper loaded: my_helper
INFO - 2020-10-21 03:15:28 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:15:28 --> Controller Class Initialized
INFO - 2020-10-21 03:15:28 --> Final output sent to browser
DEBUG - 2020-10-21 03:15:28 --> Total execution time: 0.2364
INFO - 2020-10-21 03:15:38 --> Config Class Initialized
INFO - 2020-10-21 03:15:38 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:15:38 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:15:38 --> Utf8 Class Initialized
INFO - 2020-10-21 03:15:38 --> URI Class Initialized
INFO - 2020-10-21 03:15:38 --> Router Class Initialized
INFO - 2020-10-21 03:15:38 --> Output Class Initialized
INFO - 2020-10-21 03:15:38 --> Security Class Initialized
DEBUG - 2020-10-21 03:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:15:38 --> Input Class Initialized
INFO - 2020-10-21 03:15:38 --> Language Class Initialized
INFO - 2020-10-21 03:15:38 --> Language Class Initialized
INFO - 2020-10-21 03:15:38 --> Config Class Initialized
INFO - 2020-10-21 03:15:38 --> Loader Class Initialized
INFO - 2020-10-21 03:15:38 --> Helper loaded: url_helper
INFO - 2020-10-21 03:15:38 --> Helper loaded: file_helper
INFO - 2020-10-21 03:15:38 --> Helper loaded: form_helper
INFO - 2020-10-21 03:15:38 --> Helper loaded: my_helper
INFO - 2020-10-21 03:15:38 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:15:38 --> Controller Class Initialized
ERROR - 2020-10-21 03:15:38 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:15:38 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:15:38 --> Final output sent to browser
DEBUG - 2020-10-21 03:15:38 --> Total execution time: 0.2916
INFO - 2020-10-21 03:15:41 --> Config Class Initialized
INFO - 2020-10-21 03:15:41 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:15:41 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:15:41 --> Utf8 Class Initialized
INFO - 2020-10-21 03:15:41 --> URI Class Initialized
INFO - 2020-10-21 03:15:41 --> Router Class Initialized
INFO - 2020-10-21 03:15:41 --> Output Class Initialized
INFO - 2020-10-21 03:15:41 --> Security Class Initialized
DEBUG - 2020-10-21 03:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:15:41 --> Input Class Initialized
INFO - 2020-10-21 03:15:41 --> Language Class Initialized
INFO - 2020-10-21 03:15:41 --> Language Class Initialized
INFO - 2020-10-21 03:15:41 --> Config Class Initialized
INFO - 2020-10-21 03:15:41 --> Loader Class Initialized
INFO - 2020-10-21 03:15:41 --> Helper loaded: url_helper
INFO - 2020-10-21 03:15:41 --> Helper loaded: file_helper
INFO - 2020-10-21 03:15:41 --> Helper loaded: form_helper
INFO - 2020-10-21 03:15:41 --> Helper loaded: my_helper
INFO - 2020-10-21 03:15:41 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:15:41 --> Controller Class Initialized
DEBUG - 2020-10-21 03:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:15:41 --> Final output sent to browser
DEBUG - 2020-10-21 03:15:41 --> Total execution time: 0.2701
INFO - 2020-10-21 03:15:41 --> Config Class Initialized
INFO - 2020-10-21 03:15:41 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:15:41 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:15:41 --> Utf8 Class Initialized
INFO - 2020-10-21 03:15:41 --> URI Class Initialized
INFO - 2020-10-21 03:15:41 --> Router Class Initialized
INFO - 2020-10-21 03:15:41 --> Output Class Initialized
INFO - 2020-10-21 03:15:41 --> Security Class Initialized
DEBUG - 2020-10-21 03:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:15:41 --> Input Class Initialized
INFO - 2020-10-21 03:15:41 --> Language Class Initialized
INFO - 2020-10-21 03:15:41 --> Language Class Initialized
INFO - 2020-10-21 03:15:41 --> Config Class Initialized
INFO - 2020-10-21 03:15:41 --> Loader Class Initialized
INFO - 2020-10-21 03:15:41 --> Helper loaded: url_helper
INFO - 2020-10-21 03:15:41 --> Helper loaded: file_helper
INFO - 2020-10-21 03:15:41 --> Helper loaded: form_helper
INFO - 2020-10-21 03:15:41 --> Helper loaded: my_helper
INFO - 2020-10-21 03:15:41 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:15:41 --> Controller Class Initialized
INFO - 2020-10-21 03:21:05 --> Config Class Initialized
INFO - 2020-10-21 03:21:05 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:21:05 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:21:05 --> Utf8 Class Initialized
INFO - 2020-10-21 03:21:05 --> URI Class Initialized
INFO - 2020-10-21 03:21:05 --> Router Class Initialized
INFO - 2020-10-21 03:21:05 --> Output Class Initialized
INFO - 2020-10-21 03:21:05 --> Security Class Initialized
DEBUG - 2020-10-21 03:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:21:05 --> Input Class Initialized
INFO - 2020-10-21 03:21:05 --> Language Class Initialized
INFO - 2020-10-21 03:21:05 --> Language Class Initialized
INFO - 2020-10-21 03:21:05 --> Config Class Initialized
INFO - 2020-10-21 03:21:05 --> Loader Class Initialized
INFO - 2020-10-21 03:21:05 --> Helper loaded: url_helper
INFO - 2020-10-21 03:21:05 --> Helper loaded: file_helper
INFO - 2020-10-21 03:21:05 --> Helper loaded: form_helper
INFO - 2020-10-21 03:21:05 --> Helper loaded: my_helper
INFO - 2020-10-21 03:21:05 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:21:05 --> Controller Class Initialized
INFO - 2020-10-21 03:21:05 --> Final output sent to browser
DEBUG - 2020-10-21 03:21:05 --> Total execution time: 0.2486
INFO - 2020-10-21 03:22:23 --> Config Class Initialized
INFO - 2020-10-21 03:22:23 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:22:23 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:22:23 --> Utf8 Class Initialized
INFO - 2020-10-21 03:22:23 --> URI Class Initialized
INFO - 2020-10-21 03:22:23 --> Router Class Initialized
INFO - 2020-10-21 03:22:23 --> Output Class Initialized
INFO - 2020-10-21 03:22:24 --> Security Class Initialized
DEBUG - 2020-10-21 03:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:22:24 --> Input Class Initialized
INFO - 2020-10-21 03:22:24 --> Language Class Initialized
INFO - 2020-10-21 03:22:24 --> Language Class Initialized
INFO - 2020-10-21 03:22:24 --> Config Class Initialized
INFO - 2020-10-21 03:22:24 --> Loader Class Initialized
INFO - 2020-10-21 03:22:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:22:24 --> Helper loaded: file_helper
INFO - 2020-10-21 03:22:24 --> Helper loaded: form_helper
INFO - 2020-10-21 03:22:24 --> Helper loaded: my_helper
INFO - 2020-10-21 03:22:24 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:22:24 --> Controller Class Initialized
INFO - 2020-10-21 03:22:24 --> Final output sent to browser
DEBUG - 2020-10-21 03:22:24 --> Total execution time: 0.2668
INFO - 2020-10-21 03:22:24 --> Config Class Initialized
INFO - 2020-10-21 03:22:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:22:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:22:24 --> Utf8 Class Initialized
INFO - 2020-10-21 03:22:24 --> URI Class Initialized
INFO - 2020-10-21 03:22:24 --> Router Class Initialized
INFO - 2020-10-21 03:22:24 --> Output Class Initialized
INFO - 2020-10-21 03:22:24 --> Security Class Initialized
DEBUG - 2020-10-21 03:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:22:24 --> Input Class Initialized
INFO - 2020-10-21 03:22:24 --> Language Class Initialized
INFO - 2020-10-21 03:22:24 --> Language Class Initialized
INFO - 2020-10-21 03:22:24 --> Config Class Initialized
INFO - 2020-10-21 03:22:24 --> Loader Class Initialized
INFO - 2020-10-21 03:22:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:22:24 --> Helper loaded: file_helper
INFO - 2020-10-21 03:22:24 --> Helper loaded: form_helper
INFO - 2020-10-21 03:22:24 --> Helper loaded: my_helper
INFO - 2020-10-21 03:22:24 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:22:24 --> Controller Class Initialized
INFO - 2020-10-21 03:22:31 --> Config Class Initialized
INFO - 2020-10-21 03:22:31 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:22:31 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:22:31 --> Utf8 Class Initialized
INFO - 2020-10-21 03:22:31 --> URI Class Initialized
INFO - 2020-10-21 03:22:31 --> Router Class Initialized
INFO - 2020-10-21 03:22:31 --> Output Class Initialized
INFO - 2020-10-21 03:22:31 --> Security Class Initialized
DEBUG - 2020-10-21 03:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:22:31 --> Input Class Initialized
INFO - 2020-10-21 03:22:31 --> Language Class Initialized
INFO - 2020-10-21 03:22:31 --> Language Class Initialized
INFO - 2020-10-21 03:22:31 --> Config Class Initialized
INFO - 2020-10-21 03:22:31 --> Loader Class Initialized
INFO - 2020-10-21 03:22:31 --> Helper loaded: url_helper
INFO - 2020-10-21 03:22:31 --> Helper loaded: file_helper
INFO - 2020-10-21 03:22:31 --> Helper loaded: form_helper
INFO - 2020-10-21 03:22:31 --> Helper loaded: my_helper
INFO - 2020-10-21 03:22:31 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:22:31 --> Controller Class Initialized
DEBUG - 2020-10-21 03:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:22:31 --> Final output sent to browser
DEBUG - 2020-10-21 03:22:31 --> Total execution time: 0.3086
INFO - 2020-10-21 03:22:31 --> Config Class Initialized
INFO - 2020-10-21 03:22:31 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:22:31 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:22:31 --> Utf8 Class Initialized
INFO - 2020-10-21 03:22:31 --> URI Class Initialized
INFO - 2020-10-21 03:22:32 --> Router Class Initialized
INFO - 2020-10-21 03:22:32 --> Output Class Initialized
INFO - 2020-10-21 03:22:32 --> Security Class Initialized
DEBUG - 2020-10-21 03:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:22:32 --> Input Class Initialized
INFO - 2020-10-21 03:22:32 --> Language Class Initialized
INFO - 2020-10-21 03:22:32 --> Language Class Initialized
INFO - 2020-10-21 03:22:32 --> Config Class Initialized
INFO - 2020-10-21 03:22:32 --> Loader Class Initialized
INFO - 2020-10-21 03:22:32 --> Helper loaded: url_helper
INFO - 2020-10-21 03:22:32 --> Helper loaded: file_helper
INFO - 2020-10-21 03:22:32 --> Helper loaded: form_helper
INFO - 2020-10-21 03:22:32 --> Helper loaded: my_helper
INFO - 2020-10-21 03:22:32 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:22:32 --> Controller Class Initialized
INFO - 2020-10-21 03:22:33 --> Config Class Initialized
INFO - 2020-10-21 03:22:33 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:22:33 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:22:33 --> Utf8 Class Initialized
INFO - 2020-10-21 03:22:33 --> URI Class Initialized
INFO - 2020-10-21 03:22:33 --> Router Class Initialized
INFO - 2020-10-21 03:22:33 --> Output Class Initialized
INFO - 2020-10-21 03:22:33 --> Security Class Initialized
DEBUG - 2020-10-21 03:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:22:33 --> Input Class Initialized
INFO - 2020-10-21 03:22:33 --> Language Class Initialized
INFO - 2020-10-21 03:22:33 --> Language Class Initialized
INFO - 2020-10-21 03:22:33 --> Config Class Initialized
INFO - 2020-10-21 03:22:33 --> Loader Class Initialized
INFO - 2020-10-21 03:22:33 --> Helper loaded: url_helper
INFO - 2020-10-21 03:22:33 --> Helper loaded: file_helper
INFO - 2020-10-21 03:22:33 --> Helper loaded: form_helper
INFO - 2020-10-21 03:22:33 --> Helper loaded: my_helper
INFO - 2020-10-21 03:22:33 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:22:33 --> Controller Class Initialized
INFO - 2020-10-21 03:22:33 --> Final output sent to browser
DEBUG - 2020-10-21 03:22:33 --> Total execution time: 0.2535
INFO - 2020-10-21 03:23:17 --> Config Class Initialized
INFO - 2020-10-21 03:23:17 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:23:17 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:23:17 --> Utf8 Class Initialized
INFO - 2020-10-21 03:23:17 --> URI Class Initialized
INFO - 2020-10-21 03:23:17 --> Router Class Initialized
INFO - 2020-10-21 03:23:17 --> Output Class Initialized
INFO - 2020-10-21 03:23:17 --> Security Class Initialized
DEBUG - 2020-10-21 03:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:23:17 --> Input Class Initialized
INFO - 2020-10-21 03:23:17 --> Language Class Initialized
INFO - 2020-10-21 03:23:17 --> Language Class Initialized
INFO - 2020-10-21 03:23:17 --> Config Class Initialized
INFO - 2020-10-21 03:23:17 --> Loader Class Initialized
INFO - 2020-10-21 03:23:17 --> Helper loaded: url_helper
INFO - 2020-10-21 03:23:17 --> Helper loaded: file_helper
INFO - 2020-10-21 03:23:17 --> Helper loaded: form_helper
INFO - 2020-10-21 03:23:17 --> Helper loaded: my_helper
INFO - 2020-10-21 03:23:17 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:23:17 --> Controller Class Initialized
INFO - 2020-10-21 03:23:17 --> Final output sent to browser
DEBUG - 2020-10-21 03:23:17 --> Total execution time: 0.2801
INFO - 2020-10-21 03:23:17 --> Config Class Initialized
INFO - 2020-10-21 03:23:17 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:23:18 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:23:18 --> Utf8 Class Initialized
INFO - 2020-10-21 03:23:18 --> URI Class Initialized
INFO - 2020-10-21 03:23:18 --> Router Class Initialized
INFO - 2020-10-21 03:23:18 --> Output Class Initialized
INFO - 2020-10-21 03:23:18 --> Security Class Initialized
DEBUG - 2020-10-21 03:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:23:18 --> Input Class Initialized
INFO - 2020-10-21 03:23:18 --> Language Class Initialized
INFO - 2020-10-21 03:23:18 --> Language Class Initialized
INFO - 2020-10-21 03:23:18 --> Config Class Initialized
INFO - 2020-10-21 03:23:18 --> Loader Class Initialized
INFO - 2020-10-21 03:23:18 --> Helper loaded: url_helper
INFO - 2020-10-21 03:23:18 --> Helper loaded: file_helper
INFO - 2020-10-21 03:23:18 --> Helper loaded: form_helper
INFO - 2020-10-21 03:23:18 --> Helper loaded: my_helper
INFO - 2020-10-21 03:23:18 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:23:18 --> Controller Class Initialized
INFO - 2020-10-21 03:24:46 --> Config Class Initialized
INFO - 2020-10-21 03:24:46 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:24:46 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:24:46 --> Utf8 Class Initialized
INFO - 2020-10-21 03:24:46 --> URI Class Initialized
INFO - 2020-10-21 03:24:46 --> Router Class Initialized
INFO - 2020-10-21 03:24:46 --> Output Class Initialized
INFO - 2020-10-21 03:24:46 --> Security Class Initialized
DEBUG - 2020-10-21 03:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:24:46 --> Input Class Initialized
INFO - 2020-10-21 03:24:46 --> Language Class Initialized
INFO - 2020-10-21 03:24:46 --> Language Class Initialized
INFO - 2020-10-21 03:24:46 --> Config Class Initialized
INFO - 2020-10-21 03:24:46 --> Loader Class Initialized
INFO - 2020-10-21 03:24:46 --> Helper loaded: url_helper
INFO - 2020-10-21 03:24:46 --> Helper loaded: file_helper
INFO - 2020-10-21 03:24:46 --> Helper loaded: form_helper
INFO - 2020-10-21 03:24:46 --> Helper loaded: my_helper
INFO - 2020-10-21 03:24:46 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:24:46 --> Controller Class Initialized
DEBUG - 2020-10-21 03:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:24:46 --> Final output sent to browser
DEBUG - 2020-10-21 03:24:46 --> Total execution time: 0.2685
INFO - 2020-10-21 03:24:46 --> Config Class Initialized
INFO - 2020-10-21 03:24:46 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:24:46 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:24:46 --> Utf8 Class Initialized
INFO - 2020-10-21 03:24:46 --> URI Class Initialized
INFO - 2020-10-21 03:24:46 --> Router Class Initialized
INFO - 2020-10-21 03:24:46 --> Output Class Initialized
INFO - 2020-10-21 03:24:46 --> Security Class Initialized
DEBUG - 2020-10-21 03:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:24:46 --> Input Class Initialized
INFO - 2020-10-21 03:24:46 --> Language Class Initialized
INFO - 2020-10-21 03:24:46 --> Language Class Initialized
INFO - 2020-10-21 03:24:46 --> Config Class Initialized
INFO - 2020-10-21 03:24:46 --> Loader Class Initialized
INFO - 2020-10-21 03:24:46 --> Helper loaded: url_helper
INFO - 2020-10-21 03:24:46 --> Helper loaded: file_helper
INFO - 2020-10-21 03:24:46 --> Helper loaded: form_helper
INFO - 2020-10-21 03:24:46 --> Helper loaded: my_helper
INFO - 2020-10-21 03:24:46 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:24:46 --> Controller Class Initialized
INFO - 2020-10-21 03:25:05 --> Config Class Initialized
INFO - 2020-10-21 03:25:05 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:25:05 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:25:05 --> Utf8 Class Initialized
INFO - 2020-10-21 03:25:05 --> URI Class Initialized
INFO - 2020-10-21 03:25:05 --> Router Class Initialized
INFO - 2020-10-21 03:25:05 --> Output Class Initialized
INFO - 2020-10-21 03:25:05 --> Security Class Initialized
DEBUG - 2020-10-21 03:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:25:05 --> Input Class Initialized
INFO - 2020-10-21 03:25:05 --> Language Class Initialized
INFO - 2020-10-21 03:25:05 --> Language Class Initialized
INFO - 2020-10-21 03:25:05 --> Config Class Initialized
INFO - 2020-10-21 03:25:05 --> Loader Class Initialized
INFO - 2020-10-21 03:25:05 --> Helper loaded: url_helper
INFO - 2020-10-21 03:25:05 --> Helper loaded: file_helper
INFO - 2020-10-21 03:25:05 --> Helper loaded: form_helper
INFO - 2020-10-21 03:25:05 --> Helper loaded: my_helper
INFO - 2020-10-21 03:25:05 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:25:05 --> Controller Class Initialized
DEBUG - 2020-10-21 03:25:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:25:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:25:05 --> Final output sent to browser
DEBUG - 2020-10-21 03:25:05 --> Total execution time: 0.2664
INFO - 2020-10-21 03:25:05 --> Config Class Initialized
INFO - 2020-10-21 03:25:05 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:25:05 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:25:05 --> Utf8 Class Initialized
INFO - 2020-10-21 03:25:05 --> URI Class Initialized
INFO - 2020-10-21 03:25:05 --> Router Class Initialized
INFO - 2020-10-21 03:25:05 --> Output Class Initialized
INFO - 2020-10-21 03:25:05 --> Security Class Initialized
DEBUG - 2020-10-21 03:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:25:05 --> Input Class Initialized
INFO - 2020-10-21 03:25:05 --> Language Class Initialized
INFO - 2020-10-21 03:25:05 --> Language Class Initialized
INFO - 2020-10-21 03:25:05 --> Config Class Initialized
INFO - 2020-10-21 03:25:05 --> Loader Class Initialized
INFO - 2020-10-21 03:25:05 --> Helper loaded: url_helper
INFO - 2020-10-21 03:25:05 --> Helper loaded: file_helper
INFO - 2020-10-21 03:25:05 --> Helper loaded: form_helper
INFO - 2020-10-21 03:25:05 --> Helper loaded: my_helper
INFO - 2020-10-21 03:25:05 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:25:05 --> Controller Class Initialized
INFO - 2020-10-21 03:25:24 --> Config Class Initialized
INFO - 2020-10-21 03:25:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:25:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:25:24 --> Utf8 Class Initialized
INFO - 2020-10-21 03:25:24 --> URI Class Initialized
INFO - 2020-10-21 03:25:24 --> Router Class Initialized
INFO - 2020-10-21 03:25:24 --> Output Class Initialized
INFO - 2020-10-21 03:25:24 --> Security Class Initialized
DEBUG - 2020-10-21 03:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:25:24 --> Input Class Initialized
INFO - 2020-10-21 03:25:24 --> Language Class Initialized
INFO - 2020-10-21 03:25:24 --> Language Class Initialized
INFO - 2020-10-21 03:25:24 --> Config Class Initialized
INFO - 2020-10-21 03:25:24 --> Loader Class Initialized
INFO - 2020-10-21 03:25:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:25:24 --> Helper loaded: file_helper
INFO - 2020-10-21 03:25:24 --> Helper loaded: form_helper
INFO - 2020-10-21 03:25:24 --> Helper loaded: my_helper
INFO - 2020-10-21 03:25:24 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:25:24 --> Controller Class Initialized
DEBUG - 2020-10-21 03:25:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:25:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:25:24 --> Final output sent to browser
DEBUG - 2020-10-21 03:25:24 --> Total execution time: 0.2528
INFO - 2020-10-21 03:25:24 --> Config Class Initialized
INFO - 2020-10-21 03:25:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:25:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:25:24 --> Utf8 Class Initialized
INFO - 2020-10-21 03:25:24 --> URI Class Initialized
INFO - 2020-10-21 03:25:24 --> Router Class Initialized
INFO - 2020-10-21 03:25:24 --> Output Class Initialized
INFO - 2020-10-21 03:25:24 --> Security Class Initialized
DEBUG - 2020-10-21 03:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:25:24 --> Input Class Initialized
INFO - 2020-10-21 03:25:24 --> Language Class Initialized
INFO - 2020-10-21 03:25:24 --> Language Class Initialized
INFO - 2020-10-21 03:25:24 --> Config Class Initialized
INFO - 2020-10-21 03:25:24 --> Loader Class Initialized
INFO - 2020-10-21 03:25:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:25:24 --> Helper loaded: file_helper
INFO - 2020-10-21 03:25:24 --> Helper loaded: form_helper
INFO - 2020-10-21 03:25:24 --> Helper loaded: my_helper
INFO - 2020-10-21 03:25:24 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:25:24 --> Controller Class Initialized
INFO - 2020-10-21 03:25:44 --> Config Class Initialized
INFO - 2020-10-21 03:25:44 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:25:44 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:25:44 --> Utf8 Class Initialized
INFO - 2020-10-21 03:25:44 --> URI Class Initialized
INFO - 2020-10-21 03:25:44 --> Router Class Initialized
INFO - 2020-10-21 03:25:44 --> Output Class Initialized
INFO - 2020-10-21 03:25:44 --> Security Class Initialized
DEBUG - 2020-10-21 03:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:25:44 --> Input Class Initialized
INFO - 2020-10-21 03:25:44 --> Language Class Initialized
INFO - 2020-10-21 03:25:44 --> Language Class Initialized
INFO - 2020-10-21 03:25:44 --> Config Class Initialized
INFO - 2020-10-21 03:25:44 --> Loader Class Initialized
INFO - 2020-10-21 03:25:44 --> Helper loaded: url_helper
INFO - 2020-10-21 03:25:44 --> Helper loaded: file_helper
INFO - 2020-10-21 03:25:44 --> Helper loaded: form_helper
INFO - 2020-10-21 03:25:44 --> Helper loaded: my_helper
INFO - 2020-10-21 03:25:44 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:25:44 --> Controller Class Initialized
DEBUG - 2020-10-21 03:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:25:44 --> Final output sent to browser
DEBUG - 2020-10-21 03:25:44 --> Total execution time: 0.2915
INFO - 2020-10-21 03:25:44 --> Config Class Initialized
INFO - 2020-10-21 03:25:44 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:25:44 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:25:44 --> Utf8 Class Initialized
INFO - 2020-10-21 03:25:44 --> URI Class Initialized
INFO - 2020-10-21 03:25:44 --> Router Class Initialized
INFO - 2020-10-21 03:25:44 --> Output Class Initialized
INFO - 2020-10-21 03:25:44 --> Security Class Initialized
DEBUG - 2020-10-21 03:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:25:44 --> Input Class Initialized
INFO - 2020-10-21 03:25:44 --> Language Class Initialized
INFO - 2020-10-21 03:25:44 --> Language Class Initialized
INFO - 2020-10-21 03:25:44 --> Config Class Initialized
INFO - 2020-10-21 03:25:44 --> Loader Class Initialized
INFO - 2020-10-21 03:25:44 --> Helper loaded: url_helper
INFO - 2020-10-21 03:25:44 --> Helper loaded: file_helper
INFO - 2020-10-21 03:25:44 --> Helper loaded: form_helper
INFO - 2020-10-21 03:25:44 --> Helper loaded: my_helper
INFO - 2020-10-21 03:25:44 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:25:44 --> Controller Class Initialized
INFO - 2020-10-21 03:26:10 --> Config Class Initialized
INFO - 2020-10-21 03:26:10 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:10 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:10 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:10 --> URI Class Initialized
INFO - 2020-10-21 03:26:10 --> Router Class Initialized
INFO - 2020-10-21 03:26:10 --> Output Class Initialized
INFO - 2020-10-21 03:26:10 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:10 --> Input Class Initialized
INFO - 2020-10-21 03:26:10 --> Language Class Initialized
INFO - 2020-10-21 03:26:10 --> Language Class Initialized
INFO - 2020-10-21 03:26:10 --> Config Class Initialized
INFO - 2020-10-21 03:26:10 --> Loader Class Initialized
INFO - 2020-10-21 03:26:10 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:10 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:10 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:10 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:10 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:10 --> Controller Class Initialized
INFO - 2020-10-21 03:26:10 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:10 --> Total execution time: 0.2555
INFO - 2020-10-21 03:26:16 --> Config Class Initialized
INFO - 2020-10-21 03:26:16 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:16 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:16 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:16 --> URI Class Initialized
INFO - 2020-10-21 03:26:16 --> Router Class Initialized
INFO - 2020-10-21 03:26:16 --> Output Class Initialized
INFO - 2020-10-21 03:26:16 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:16 --> Input Class Initialized
INFO - 2020-10-21 03:26:16 --> Language Class Initialized
INFO - 2020-10-21 03:26:16 --> Language Class Initialized
INFO - 2020-10-21 03:26:16 --> Config Class Initialized
INFO - 2020-10-21 03:26:16 --> Loader Class Initialized
INFO - 2020-10-21 03:26:16 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:16 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:16 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:16 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:16 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:16 --> Controller Class Initialized
ERROR - 2020-10-21 03:26:16 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:26:16 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:26:16 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:16 --> Total execution time: 0.2784
INFO - 2020-10-21 03:26:18 --> Config Class Initialized
INFO - 2020-10-21 03:26:18 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:18 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:18 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:18 --> URI Class Initialized
INFO - 2020-10-21 03:26:18 --> Router Class Initialized
INFO - 2020-10-21 03:26:18 --> Output Class Initialized
INFO - 2020-10-21 03:26:18 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:18 --> Input Class Initialized
INFO - 2020-10-21 03:26:18 --> Language Class Initialized
INFO - 2020-10-21 03:26:18 --> Language Class Initialized
INFO - 2020-10-21 03:26:18 --> Config Class Initialized
INFO - 2020-10-21 03:26:18 --> Loader Class Initialized
INFO - 2020-10-21 03:26:18 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:18 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:18 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:18 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:18 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:18 --> Controller Class Initialized
DEBUG - 2020-10-21 03:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:26:18 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:18 --> Total execution time: 0.2745
INFO - 2020-10-21 03:26:18 --> Config Class Initialized
INFO - 2020-10-21 03:26:18 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:18 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:18 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:18 --> URI Class Initialized
INFO - 2020-10-21 03:26:18 --> Router Class Initialized
INFO - 2020-10-21 03:26:18 --> Output Class Initialized
INFO - 2020-10-21 03:26:18 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:18 --> Input Class Initialized
INFO - 2020-10-21 03:26:18 --> Language Class Initialized
INFO - 2020-10-21 03:26:18 --> Language Class Initialized
INFO - 2020-10-21 03:26:18 --> Config Class Initialized
INFO - 2020-10-21 03:26:18 --> Loader Class Initialized
INFO - 2020-10-21 03:26:18 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:18 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:18 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:18 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:18 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:18 --> Controller Class Initialized
INFO - 2020-10-21 03:26:25 --> Config Class Initialized
INFO - 2020-10-21 03:26:25 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:25 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:25 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:25 --> URI Class Initialized
INFO - 2020-10-21 03:26:25 --> Router Class Initialized
INFO - 2020-10-21 03:26:25 --> Output Class Initialized
INFO - 2020-10-21 03:26:25 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:25 --> Input Class Initialized
INFO - 2020-10-21 03:26:25 --> Language Class Initialized
INFO - 2020-10-21 03:26:25 --> Language Class Initialized
INFO - 2020-10-21 03:26:25 --> Config Class Initialized
INFO - 2020-10-21 03:26:25 --> Loader Class Initialized
INFO - 2020-10-21 03:26:25 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:25 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:25 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:25 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:25 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:26 --> Controller Class Initialized
INFO - 2020-10-21 03:26:26 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:26 --> Total execution time: 0.2441
INFO - 2020-10-21 03:26:30 --> Config Class Initialized
INFO - 2020-10-21 03:26:30 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:30 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:30 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:30 --> URI Class Initialized
INFO - 2020-10-21 03:26:30 --> Router Class Initialized
INFO - 2020-10-21 03:26:30 --> Output Class Initialized
INFO - 2020-10-21 03:26:30 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:30 --> Input Class Initialized
INFO - 2020-10-21 03:26:30 --> Language Class Initialized
INFO - 2020-10-21 03:26:30 --> Language Class Initialized
INFO - 2020-10-21 03:26:30 --> Config Class Initialized
INFO - 2020-10-21 03:26:30 --> Loader Class Initialized
INFO - 2020-10-21 03:26:30 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:30 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:30 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:30 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:30 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:30 --> Controller Class Initialized
INFO - 2020-10-21 03:26:30 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:30 --> Total execution time: 0.2775
INFO - 2020-10-21 03:26:30 --> Config Class Initialized
INFO - 2020-10-21 03:26:30 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:30 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:30 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:30 --> URI Class Initialized
INFO - 2020-10-21 03:26:30 --> Router Class Initialized
INFO - 2020-10-21 03:26:30 --> Output Class Initialized
INFO - 2020-10-21 03:26:30 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:31 --> Input Class Initialized
INFO - 2020-10-21 03:26:31 --> Language Class Initialized
INFO - 2020-10-21 03:26:31 --> Language Class Initialized
INFO - 2020-10-21 03:26:31 --> Config Class Initialized
INFO - 2020-10-21 03:26:31 --> Loader Class Initialized
INFO - 2020-10-21 03:26:31 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:31 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:31 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:31 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:31 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:31 --> Controller Class Initialized
INFO - 2020-10-21 03:26:38 --> Config Class Initialized
INFO - 2020-10-21 03:26:38 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:38 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:38 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:38 --> URI Class Initialized
INFO - 2020-10-21 03:26:38 --> Router Class Initialized
INFO - 2020-10-21 03:26:38 --> Output Class Initialized
INFO - 2020-10-21 03:26:38 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:38 --> Input Class Initialized
INFO - 2020-10-21 03:26:38 --> Language Class Initialized
INFO - 2020-10-21 03:26:38 --> Language Class Initialized
INFO - 2020-10-21 03:26:38 --> Config Class Initialized
INFO - 2020-10-21 03:26:38 --> Loader Class Initialized
INFO - 2020-10-21 03:26:38 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:38 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:38 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:38 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:38 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:38 --> Controller Class Initialized
INFO - 2020-10-21 03:26:38 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:38 --> Total execution time: 0.2992
INFO - 2020-10-21 03:26:38 --> Config Class Initialized
INFO - 2020-10-21 03:26:38 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:38 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:38 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:38 --> URI Class Initialized
INFO - 2020-10-21 03:26:38 --> Router Class Initialized
INFO - 2020-10-21 03:26:38 --> Output Class Initialized
INFO - 2020-10-21 03:26:38 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:38 --> Input Class Initialized
INFO - 2020-10-21 03:26:38 --> Language Class Initialized
INFO - 2020-10-21 03:26:38 --> Language Class Initialized
INFO - 2020-10-21 03:26:38 --> Config Class Initialized
INFO - 2020-10-21 03:26:38 --> Loader Class Initialized
INFO - 2020-10-21 03:26:38 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:38 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:38 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:38 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:38 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:38 --> Controller Class Initialized
INFO - 2020-10-21 03:26:41 --> Config Class Initialized
INFO - 2020-10-21 03:26:41 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:41 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:41 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:41 --> URI Class Initialized
INFO - 2020-10-21 03:26:41 --> Router Class Initialized
INFO - 2020-10-21 03:26:41 --> Output Class Initialized
INFO - 2020-10-21 03:26:41 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:41 --> Input Class Initialized
INFO - 2020-10-21 03:26:41 --> Language Class Initialized
INFO - 2020-10-21 03:26:41 --> Language Class Initialized
INFO - 2020-10-21 03:26:41 --> Config Class Initialized
INFO - 2020-10-21 03:26:42 --> Loader Class Initialized
INFO - 2020-10-21 03:26:42 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:42 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:42 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:42 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:42 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:42 --> Controller Class Initialized
INFO - 2020-10-21 03:26:42 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:42 --> Total execution time: 0.2755
INFO - 2020-10-21 03:26:42 --> Config Class Initialized
INFO - 2020-10-21 03:26:42 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:42 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:42 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:42 --> URI Class Initialized
INFO - 2020-10-21 03:26:42 --> Router Class Initialized
INFO - 2020-10-21 03:26:42 --> Output Class Initialized
INFO - 2020-10-21 03:26:42 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:42 --> Input Class Initialized
INFO - 2020-10-21 03:26:42 --> Language Class Initialized
INFO - 2020-10-21 03:26:42 --> Language Class Initialized
INFO - 2020-10-21 03:26:42 --> Config Class Initialized
INFO - 2020-10-21 03:26:42 --> Loader Class Initialized
INFO - 2020-10-21 03:26:42 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:42 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:42 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:42 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:42 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:42 --> Controller Class Initialized
INFO - 2020-10-21 03:26:45 --> Config Class Initialized
INFO - 2020-10-21 03:26:45 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:45 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:45 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:45 --> URI Class Initialized
INFO - 2020-10-21 03:26:45 --> Router Class Initialized
INFO - 2020-10-21 03:26:45 --> Output Class Initialized
INFO - 2020-10-21 03:26:45 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:45 --> Input Class Initialized
INFO - 2020-10-21 03:26:45 --> Language Class Initialized
INFO - 2020-10-21 03:26:45 --> Language Class Initialized
INFO - 2020-10-21 03:26:45 --> Config Class Initialized
INFO - 2020-10-21 03:26:45 --> Loader Class Initialized
INFO - 2020-10-21 03:26:45 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:45 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:45 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:45 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:45 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:45 --> Controller Class Initialized
INFO - 2020-10-21 03:26:45 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:45 --> Total execution time: 0.2993
INFO - 2020-10-21 03:26:45 --> Config Class Initialized
INFO - 2020-10-21 03:26:45 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:45 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:45 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:45 --> URI Class Initialized
INFO - 2020-10-21 03:26:45 --> Router Class Initialized
INFO - 2020-10-21 03:26:45 --> Output Class Initialized
INFO - 2020-10-21 03:26:45 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:45 --> Input Class Initialized
INFO - 2020-10-21 03:26:45 --> Language Class Initialized
INFO - 2020-10-21 03:26:45 --> Language Class Initialized
INFO - 2020-10-21 03:26:45 --> Config Class Initialized
INFO - 2020-10-21 03:26:45 --> Loader Class Initialized
INFO - 2020-10-21 03:26:45 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:45 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:45 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:45 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:45 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:45 --> Controller Class Initialized
INFO - 2020-10-21 03:26:47 --> Config Class Initialized
INFO - 2020-10-21 03:26:47 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:47 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:47 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:47 --> URI Class Initialized
INFO - 2020-10-21 03:26:47 --> Router Class Initialized
INFO - 2020-10-21 03:26:47 --> Output Class Initialized
INFO - 2020-10-21 03:26:47 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:47 --> Input Class Initialized
INFO - 2020-10-21 03:26:47 --> Language Class Initialized
INFO - 2020-10-21 03:26:47 --> Language Class Initialized
INFO - 2020-10-21 03:26:47 --> Config Class Initialized
INFO - 2020-10-21 03:26:47 --> Loader Class Initialized
INFO - 2020-10-21 03:26:47 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:47 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:47 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:47 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:47 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:47 --> Controller Class Initialized
INFO - 2020-10-21 03:26:47 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:47 --> Total execution time: 0.3839
INFO - 2020-10-21 03:26:47 --> Config Class Initialized
INFO - 2020-10-21 03:26:47 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:47 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:47 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:47 --> URI Class Initialized
INFO - 2020-10-21 03:26:47 --> Router Class Initialized
INFO - 2020-10-21 03:26:47 --> Output Class Initialized
INFO - 2020-10-21 03:26:47 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:47 --> Input Class Initialized
INFO - 2020-10-21 03:26:47 --> Language Class Initialized
INFO - 2020-10-21 03:26:47 --> Language Class Initialized
INFO - 2020-10-21 03:26:47 --> Config Class Initialized
INFO - 2020-10-21 03:26:47 --> Loader Class Initialized
INFO - 2020-10-21 03:26:47 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:47 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:47 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:47 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:47 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:47 --> Controller Class Initialized
INFO - 2020-10-21 03:26:53 --> Config Class Initialized
INFO - 2020-10-21 03:26:53 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:53 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:53 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:53 --> URI Class Initialized
INFO - 2020-10-21 03:26:53 --> Router Class Initialized
INFO - 2020-10-21 03:26:53 --> Output Class Initialized
INFO - 2020-10-21 03:26:53 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:53 --> Input Class Initialized
INFO - 2020-10-21 03:26:53 --> Language Class Initialized
INFO - 2020-10-21 03:26:53 --> Language Class Initialized
INFO - 2020-10-21 03:26:53 --> Config Class Initialized
INFO - 2020-10-21 03:26:53 --> Loader Class Initialized
INFO - 2020-10-21 03:26:53 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:53 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:53 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:53 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:53 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:53 --> Controller Class Initialized
INFO - 2020-10-21 03:26:53 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:53 --> Total execution time: 0.3046
INFO - 2020-10-21 03:26:53 --> Config Class Initialized
INFO - 2020-10-21 03:26:53 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:53 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:54 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:54 --> URI Class Initialized
INFO - 2020-10-21 03:26:54 --> Router Class Initialized
INFO - 2020-10-21 03:26:54 --> Output Class Initialized
INFO - 2020-10-21 03:26:54 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:54 --> Input Class Initialized
INFO - 2020-10-21 03:26:54 --> Language Class Initialized
INFO - 2020-10-21 03:26:54 --> Language Class Initialized
INFO - 2020-10-21 03:26:54 --> Config Class Initialized
INFO - 2020-10-21 03:26:54 --> Loader Class Initialized
INFO - 2020-10-21 03:26:54 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:54 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:54 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:54 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:54 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:54 --> Controller Class Initialized
INFO - 2020-10-21 03:26:56 --> Config Class Initialized
INFO - 2020-10-21 03:26:56 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:56 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:56 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:56 --> URI Class Initialized
INFO - 2020-10-21 03:26:56 --> Router Class Initialized
INFO - 2020-10-21 03:26:56 --> Output Class Initialized
INFO - 2020-10-21 03:26:56 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:56 --> Input Class Initialized
INFO - 2020-10-21 03:26:56 --> Language Class Initialized
INFO - 2020-10-21 03:26:56 --> Language Class Initialized
INFO - 2020-10-21 03:26:56 --> Config Class Initialized
INFO - 2020-10-21 03:26:56 --> Loader Class Initialized
INFO - 2020-10-21 03:26:56 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:56 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:56 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:56 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:56 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:56 --> Controller Class Initialized
INFO - 2020-10-21 03:26:56 --> Final output sent to browser
DEBUG - 2020-10-21 03:26:56 --> Total execution time: 0.3098
INFO - 2020-10-21 03:26:56 --> Config Class Initialized
INFO - 2020-10-21 03:26:56 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:26:56 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:26:56 --> Utf8 Class Initialized
INFO - 2020-10-21 03:26:56 --> URI Class Initialized
INFO - 2020-10-21 03:26:56 --> Router Class Initialized
INFO - 2020-10-21 03:26:56 --> Output Class Initialized
INFO - 2020-10-21 03:26:56 --> Security Class Initialized
DEBUG - 2020-10-21 03:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:26:56 --> Input Class Initialized
INFO - 2020-10-21 03:26:56 --> Language Class Initialized
INFO - 2020-10-21 03:26:56 --> Language Class Initialized
INFO - 2020-10-21 03:26:56 --> Config Class Initialized
INFO - 2020-10-21 03:26:56 --> Loader Class Initialized
INFO - 2020-10-21 03:26:56 --> Helper loaded: url_helper
INFO - 2020-10-21 03:26:56 --> Helper loaded: file_helper
INFO - 2020-10-21 03:26:56 --> Helper loaded: form_helper
INFO - 2020-10-21 03:26:56 --> Helper loaded: my_helper
INFO - 2020-10-21 03:26:56 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:26:56 --> Controller Class Initialized
INFO - 2020-10-21 03:27:51 --> Config Class Initialized
INFO - 2020-10-21 03:27:51 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:27:51 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:27:51 --> Utf8 Class Initialized
INFO - 2020-10-21 03:27:51 --> URI Class Initialized
INFO - 2020-10-21 03:27:51 --> Router Class Initialized
INFO - 2020-10-21 03:27:51 --> Output Class Initialized
INFO - 2020-10-21 03:27:51 --> Security Class Initialized
DEBUG - 2020-10-21 03:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:27:51 --> Input Class Initialized
INFO - 2020-10-21 03:27:51 --> Language Class Initialized
INFO - 2020-10-21 03:27:51 --> Language Class Initialized
INFO - 2020-10-21 03:27:51 --> Config Class Initialized
INFO - 2020-10-21 03:27:51 --> Loader Class Initialized
INFO - 2020-10-21 03:27:51 --> Helper loaded: url_helper
INFO - 2020-10-21 03:27:51 --> Helper loaded: file_helper
INFO - 2020-10-21 03:27:51 --> Helper loaded: form_helper
INFO - 2020-10-21 03:27:51 --> Helper loaded: my_helper
INFO - 2020-10-21 03:27:51 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:27:51 --> Controller Class Initialized
DEBUG - 2020-10-21 03:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:27:51 --> Final output sent to browser
DEBUG - 2020-10-21 03:27:51 --> Total execution time: 0.3251
INFO - 2020-10-21 03:27:51 --> Config Class Initialized
INFO - 2020-10-21 03:27:51 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:27:51 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:27:51 --> Utf8 Class Initialized
INFO - 2020-10-21 03:27:52 --> URI Class Initialized
INFO - 2020-10-21 03:27:52 --> Router Class Initialized
INFO - 2020-10-21 03:27:52 --> Output Class Initialized
INFO - 2020-10-21 03:27:52 --> Security Class Initialized
DEBUG - 2020-10-21 03:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:27:52 --> Input Class Initialized
INFO - 2020-10-21 03:27:52 --> Language Class Initialized
INFO - 2020-10-21 03:27:52 --> Language Class Initialized
INFO - 2020-10-21 03:27:52 --> Config Class Initialized
INFO - 2020-10-21 03:27:52 --> Loader Class Initialized
INFO - 2020-10-21 03:27:52 --> Helper loaded: url_helper
INFO - 2020-10-21 03:27:52 --> Helper loaded: file_helper
INFO - 2020-10-21 03:27:52 --> Helper loaded: form_helper
INFO - 2020-10-21 03:27:52 --> Helper loaded: my_helper
INFO - 2020-10-21 03:27:52 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:27:52 --> Controller Class Initialized
INFO - 2020-10-21 03:27:52 --> Config Class Initialized
INFO - 2020-10-21 03:27:52 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:27:52 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:27:52 --> Utf8 Class Initialized
INFO - 2020-10-21 03:27:52 --> URI Class Initialized
INFO - 2020-10-21 03:27:52 --> Router Class Initialized
INFO - 2020-10-21 03:27:52 --> Output Class Initialized
INFO - 2020-10-21 03:27:52 --> Security Class Initialized
DEBUG - 2020-10-21 03:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:27:52 --> Input Class Initialized
INFO - 2020-10-21 03:27:52 --> Language Class Initialized
INFO - 2020-10-21 03:27:52 --> Language Class Initialized
INFO - 2020-10-21 03:27:52 --> Config Class Initialized
INFO - 2020-10-21 03:27:52 --> Loader Class Initialized
INFO - 2020-10-21 03:27:52 --> Helper loaded: url_helper
INFO - 2020-10-21 03:27:52 --> Helper loaded: file_helper
INFO - 2020-10-21 03:27:52 --> Helper loaded: form_helper
INFO - 2020-10-21 03:27:52 --> Helper loaded: my_helper
INFO - 2020-10-21 03:27:52 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:27:52 --> Controller Class Initialized
INFO - 2020-10-21 03:27:52 --> Final output sent to browser
DEBUG - 2020-10-21 03:27:52 --> Total execution time: 0.2690
INFO - 2020-10-21 03:27:54 --> Config Class Initialized
INFO - 2020-10-21 03:27:54 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:27:54 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:27:54 --> Utf8 Class Initialized
INFO - 2020-10-21 03:27:54 --> URI Class Initialized
INFO - 2020-10-21 03:27:54 --> Router Class Initialized
INFO - 2020-10-21 03:27:54 --> Output Class Initialized
INFO - 2020-10-21 03:27:54 --> Security Class Initialized
DEBUG - 2020-10-21 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:27:54 --> Input Class Initialized
INFO - 2020-10-21 03:27:55 --> Language Class Initialized
INFO - 2020-10-21 03:27:55 --> Language Class Initialized
INFO - 2020-10-21 03:27:55 --> Config Class Initialized
INFO - 2020-10-21 03:27:55 --> Loader Class Initialized
INFO - 2020-10-21 03:27:55 --> Helper loaded: url_helper
INFO - 2020-10-21 03:27:55 --> Helper loaded: file_helper
INFO - 2020-10-21 03:27:55 --> Helper loaded: form_helper
INFO - 2020-10-21 03:27:55 --> Helper loaded: my_helper
INFO - 2020-10-21 03:27:55 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:27:55 --> Controller Class Initialized
INFO - 2020-10-21 03:27:55 --> Final output sent to browser
DEBUG - 2020-10-21 03:27:55 --> Total execution time: 0.2689
INFO - 2020-10-21 03:28:06 --> Config Class Initialized
INFO - 2020-10-21 03:28:06 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:28:06 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:28:06 --> Utf8 Class Initialized
INFO - 2020-10-21 03:28:06 --> URI Class Initialized
INFO - 2020-10-21 03:28:06 --> Router Class Initialized
INFO - 2020-10-21 03:28:06 --> Output Class Initialized
INFO - 2020-10-21 03:28:06 --> Security Class Initialized
DEBUG - 2020-10-21 03:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:28:06 --> Input Class Initialized
INFO - 2020-10-21 03:28:06 --> Language Class Initialized
INFO - 2020-10-21 03:28:06 --> Language Class Initialized
INFO - 2020-10-21 03:28:06 --> Config Class Initialized
INFO - 2020-10-21 03:28:06 --> Loader Class Initialized
INFO - 2020-10-21 03:28:06 --> Helper loaded: url_helper
INFO - 2020-10-21 03:28:06 --> Helper loaded: file_helper
INFO - 2020-10-21 03:28:06 --> Helper loaded: form_helper
INFO - 2020-10-21 03:28:06 --> Helper loaded: my_helper
INFO - 2020-10-21 03:28:06 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:28:06 --> Controller Class Initialized
ERROR - 2020-10-21 03:28:06 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:28:07 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:28:07 --> Final output sent to browser
DEBUG - 2020-10-21 03:28:07 --> Total execution time: 0.3087
INFO - 2020-10-21 03:28:08 --> Config Class Initialized
INFO - 2020-10-21 03:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:28:08 --> Utf8 Class Initialized
INFO - 2020-10-21 03:28:08 --> URI Class Initialized
INFO - 2020-10-21 03:28:08 --> Router Class Initialized
INFO - 2020-10-21 03:28:08 --> Output Class Initialized
INFO - 2020-10-21 03:28:08 --> Security Class Initialized
DEBUG - 2020-10-21 03:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:28:08 --> Input Class Initialized
INFO - 2020-10-21 03:28:08 --> Language Class Initialized
INFO - 2020-10-21 03:28:08 --> Language Class Initialized
INFO - 2020-10-21 03:28:08 --> Config Class Initialized
INFO - 2020-10-21 03:28:08 --> Loader Class Initialized
INFO - 2020-10-21 03:28:08 --> Helper loaded: url_helper
INFO - 2020-10-21 03:28:08 --> Helper loaded: file_helper
INFO - 2020-10-21 03:28:08 --> Helper loaded: form_helper
INFO - 2020-10-21 03:28:08 --> Helper loaded: my_helper
INFO - 2020-10-21 03:28:08 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:28:08 --> Controller Class Initialized
DEBUG - 2020-10-21 03:28:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:28:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:28:09 --> Final output sent to browser
DEBUG - 2020-10-21 03:28:09 --> Total execution time: 0.2908
INFO - 2020-10-21 03:28:09 --> Config Class Initialized
INFO - 2020-10-21 03:28:09 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:28:09 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:28:09 --> Utf8 Class Initialized
INFO - 2020-10-21 03:28:09 --> URI Class Initialized
INFO - 2020-10-21 03:28:09 --> Router Class Initialized
INFO - 2020-10-21 03:28:09 --> Output Class Initialized
INFO - 2020-10-21 03:28:09 --> Security Class Initialized
DEBUG - 2020-10-21 03:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:28:09 --> Input Class Initialized
INFO - 2020-10-21 03:28:09 --> Language Class Initialized
INFO - 2020-10-21 03:28:09 --> Language Class Initialized
INFO - 2020-10-21 03:28:09 --> Config Class Initialized
INFO - 2020-10-21 03:28:09 --> Loader Class Initialized
INFO - 2020-10-21 03:28:09 --> Helper loaded: url_helper
INFO - 2020-10-21 03:28:09 --> Helper loaded: file_helper
INFO - 2020-10-21 03:28:09 --> Helper loaded: form_helper
INFO - 2020-10-21 03:28:09 --> Helper loaded: my_helper
INFO - 2020-10-21 03:28:09 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:28:09 --> Controller Class Initialized
INFO - 2020-10-21 03:29:52 --> Config Class Initialized
INFO - 2020-10-21 03:29:52 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:29:52 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:29:52 --> Utf8 Class Initialized
INFO - 2020-10-21 03:29:52 --> URI Class Initialized
INFO - 2020-10-21 03:29:52 --> Router Class Initialized
INFO - 2020-10-21 03:29:52 --> Output Class Initialized
INFO - 2020-10-21 03:29:52 --> Security Class Initialized
DEBUG - 2020-10-21 03:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:29:52 --> Input Class Initialized
INFO - 2020-10-21 03:29:52 --> Language Class Initialized
INFO - 2020-10-21 03:29:52 --> Language Class Initialized
INFO - 2020-10-21 03:29:52 --> Config Class Initialized
INFO - 2020-10-21 03:29:52 --> Loader Class Initialized
INFO - 2020-10-21 03:29:52 --> Helper loaded: url_helper
INFO - 2020-10-21 03:29:53 --> Helper loaded: file_helper
INFO - 2020-10-21 03:29:53 --> Helper loaded: form_helper
INFO - 2020-10-21 03:29:53 --> Helper loaded: my_helper
INFO - 2020-10-21 03:29:53 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:29:53 --> Controller Class Initialized
INFO - 2020-10-21 03:29:53 --> Final output sent to browser
DEBUG - 2020-10-21 03:29:53 --> Total execution time: 0.2870
INFO - 2020-10-21 03:29:55 --> Config Class Initialized
INFO - 2020-10-21 03:29:55 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:29:55 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:29:55 --> Utf8 Class Initialized
INFO - 2020-10-21 03:29:55 --> URI Class Initialized
INFO - 2020-10-21 03:29:55 --> Router Class Initialized
INFO - 2020-10-21 03:29:55 --> Output Class Initialized
INFO - 2020-10-21 03:29:55 --> Security Class Initialized
DEBUG - 2020-10-21 03:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:29:55 --> Input Class Initialized
INFO - 2020-10-21 03:29:55 --> Language Class Initialized
INFO - 2020-10-21 03:29:55 --> Language Class Initialized
INFO - 2020-10-21 03:29:55 --> Config Class Initialized
INFO - 2020-10-21 03:29:55 --> Loader Class Initialized
INFO - 2020-10-21 03:29:55 --> Helper loaded: url_helper
INFO - 2020-10-21 03:29:55 --> Helper loaded: file_helper
INFO - 2020-10-21 03:29:55 --> Helper loaded: form_helper
INFO - 2020-10-21 03:29:55 --> Helper loaded: my_helper
INFO - 2020-10-21 03:29:55 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:29:55 --> Controller Class Initialized
DEBUG - 2020-10-21 03:29:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:29:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:29:55 --> Final output sent to browser
DEBUG - 2020-10-21 03:29:55 --> Total execution time: 0.3760
INFO - 2020-10-21 03:29:55 --> Config Class Initialized
INFO - 2020-10-21 03:29:55 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:29:55 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:29:55 --> Utf8 Class Initialized
INFO - 2020-10-21 03:29:55 --> URI Class Initialized
INFO - 2020-10-21 03:29:55 --> Router Class Initialized
INFO - 2020-10-21 03:29:55 --> Output Class Initialized
INFO - 2020-10-21 03:29:56 --> Security Class Initialized
DEBUG - 2020-10-21 03:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:29:56 --> Input Class Initialized
INFO - 2020-10-21 03:29:56 --> Language Class Initialized
INFO - 2020-10-21 03:29:56 --> Language Class Initialized
INFO - 2020-10-21 03:29:56 --> Config Class Initialized
INFO - 2020-10-21 03:29:56 --> Loader Class Initialized
INFO - 2020-10-21 03:29:56 --> Helper loaded: url_helper
INFO - 2020-10-21 03:29:56 --> Helper loaded: file_helper
INFO - 2020-10-21 03:29:56 --> Helper loaded: form_helper
INFO - 2020-10-21 03:29:56 --> Helper loaded: my_helper
INFO - 2020-10-21 03:29:56 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:29:56 --> Controller Class Initialized
INFO - 2020-10-21 03:29:57 --> Config Class Initialized
INFO - 2020-10-21 03:29:57 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:29:57 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:29:57 --> Utf8 Class Initialized
INFO - 2020-10-21 03:29:57 --> URI Class Initialized
INFO - 2020-10-21 03:29:57 --> Router Class Initialized
INFO - 2020-10-21 03:29:57 --> Output Class Initialized
INFO - 2020-10-21 03:29:57 --> Security Class Initialized
DEBUG - 2020-10-21 03:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:29:57 --> Input Class Initialized
INFO - 2020-10-21 03:29:57 --> Language Class Initialized
INFO - 2020-10-21 03:29:57 --> Language Class Initialized
INFO - 2020-10-21 03:29:57 --> Config Class Initialized
INFO - 2020-10-21 03:29:57 --> Loader Class Initialized
INFO - 2020-10-21 03:29:57 --> Helper loaded: url_helper
INFO - 2020-10-21 03:29:57 --> Helper loaded: file_helper
INFO - 2020-10-21 03:29:57 --> Helper loaded: form_helper
INFO - 2020-10-21 03:29:57 --> Helper loaded: my_helper
INFO - 2020-10-21 03:29:57 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:29:57 --> Controller Class Initialized
INFO - 2020-10-21 03:29:57 --> Final output sent to browser
DEBUG - 2020-10-21 03:29:57 --> Total execution time: 0.3014
INFO - 2020-10-21 03:30:01 --> Config Class Initialized
INFO - 2020-10-21 03:30:01 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:30:01 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:30:01 --> Utf8 Class Initialized
INFO - 2020-10-21 03:30:01 --> URI Class Initialized
INFO - 2020-10-21 03:30:01 --> Router Class Initialized
INFO - 2020-10-21 03:30:01 --> Output Class Initialized
INFO - 2020-10-21 03:30:01 --> Security Class Initialized
DEBUG - 2020-10-21 03:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:30:01 --> Input Class Initialized
INFO - 2020-10-21 03:30:01 --> Language Class Initialized
INFO - 2020-10-21 03:30:01 --> Language Class Initialized
INFO - 2020-10-21 03:30:01 --> Config Class Initialized
INFO - 2020-10-21 03:30:01 --> Loader Class Initialized
INFO - 2020-10-21 03:30:01 --> Helper loaded: url_helper
INFO - 2020-10-21 03:30:01 --> Helper loaded: file_helper
INFO - 2020-10-21 03:30:01 --> Helper loaded: form_helper
INFO - 2020-10-21 03:30:01 --> Helper loaded: my_helper
INFO - 2020-10-21 03:30:01 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:30:01 --> Controller Class Initialized
INFO - 2020-10-21 03:30:01 --> Final output sent to browser
DEBUG - 2020-10-21 03:30:01 --> Total execution time: 0.2919
INFO - 2020-10-21 03:30:01 --> Config Class Initialized
INFO - 2020-10-21 03:30:01 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:30:01 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:30:01 --> Utf8 Class Initialized
INFO - 2020-10-21 03:30:01 --> URI Class Initialized
INFO - 2020-10-21 03:30:01 --> Router Class Initialized
INFO - 2020-10-21 03:30:01 --> Output Class Initialized
INFO - 2020-10-21 03:30:01 --> Security Class Initialized
DEBUG - 2020-10-21 03:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:30:01 --> Input Class Initialized
INFO - 2020-10-21 03:30:01 --> Language Class Initialized
INFO - 2020-10-21 03:30:01 --> Language Class Initialized
INFO - 2020-10-21 03:30:01 --> Config Class Initialized
INFO - 2020-10-21 03:30:01 --> Loader Class Initialized
INFO - 2020-10-21 03:30:01 --> Helper loaded: url_helper
INFO - 2020-10-21 03:30:01 --> Helper loaded: file_helper
INFO - 2020-10-21 03:30:01 --> Helper loaded: form_helper
INFO - 2020-10-21 03:30:01 --> Helper loaded: my_helper
INFO - 2020-10-21 03:30:01 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:30:01 --> Controller Class Initialized
INFO - 2020-10-21 03:30:54 --> Config Class Initialized
INFO - 2020-10-21 03:30:54 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:30:54 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:30:54 --> Utf8 Class Initialized
INFO - 2020-10-21 03:30:54 --> URI Class Initialized
INFO - 2020-10-21 03:30:54 --> Router Class Initialized
INFO - 2020-10-21 03:30:54 --> Output Class Initialized
INFO - 2020-10-21 03:30:54 --> Security Class Initialized
DEBUG - 2020-10-21 03:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:30:54 --> Input Class Initialized
INFO - 2020-10-21 03:30:54 --> Language Class Initialized
INFO - 2020-10-21 03:30:54 --> Language Class Initialized
INFO - 2020-10-21 03:30:54 --> Config Class Initialized
INFO - 2020-10-21 03:30:54 --> Loader Class Initialized
INFO - 2020-10-21 03:30:54 --> Helper loaded: url_helper
INFO - 2020-10-21 03:30:54 --> Helper loaded: file_helper
INFO - 2020-10-21 03:30:54 --> Helper loaded: form_helper
INFO - 2020-10-21 03:30:54 --> Helper loaded: my_helper
INFO - 2020-10-21 03:30:54 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:30:54 --> Controller Class Initialized
DEBUG - 2020-10-21 03:30:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:30:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:30:54 --> Final output sent to browser
DEBUG - 2020-10-21 03:30:54 --> Total execution time: 0.2730
INFO - 2020-10-21 03:30:54 --> Config Class Initialized
INFO - 2020-10-21 03:30:54 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:30:54 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:30:54 --> Utf8 Class Initialized
INFO - 2020-10-21 03:30:54 --> URI Class Initialized
INFO - 2020-10-21 03:30:54 --> Router Class Initialized
INFO - 2020-10-21 03:30:54 --> Output Class Initialized
INFO - 2020-10-21 03:30:54 --> Security Class Initialized
DEBUG - 2020-10-21 03:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:30:54 --> Input Class Initialized
INFO - 2020-10-21 03:30:54 --> Language Class Initialized
INFO - 2020-10-21 03:30:54 --> Language Class Initialized
INFO - 2020-10-21 03:30:54 --> Config Class Initialized
INFO - 2020-10-21 03:30:54 --> Loader Class Initialized
INFO - 2020-10-21 03:30:54 --> Helper loaded: url_helper
INFO - 2020-10-21 03:30:54 --> Helper loaded: file_helper
INFO - 2020-10-21 03:30:54 --> Helper loaded: form_helper
INFO - 2020-10-21 03:30:54 --> Helper loaded: my_helper
INFO - 2020-10-21 03:30:54 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:30:54 --> Controller Class Initialized
INFO - 2020-10-21 03:31:12 --> Config Class Initialized
INFO - 2020-10-21 03:31:12 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:31:12 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:31:12 --> Utf8 Class Initialized
INFO - 2020-10-21 03:31:12 --> URI Class Initialized
INFO - 2020-10-21 03:31:12 --> Router Class Initialized
INFO - 2020-10-21 03:31:12 --> Output Class Initialized
INFO - 2020-10-21 03:31:12 --> Security Class Initialized
DEBUG - 2020-10-21 03:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:31:12 --> Input Class Initialized
INFO - 2020-10-21 03:31:12 --> Language Class Initialized
INFO - 2020-10-21 03:31:12 --> Language Class Initialized
INFO - 2020-10-21 03:31:12 --> Config Class Initialized
INFO - 2020-10-21 03:31:12 --> Loader Class Initialized
INFO - 2020-10-21 03:31:12 --> Helper loaded: url_helper
INFO - 2020-10-21 03:31:12 --> Helper loaded: file_helper
INFO - 2020-10-21 03:31:12 --> Helper loaded: form_helper
INFO - 2020-10-21 03:31:12 --> Helper loaded: my_helper
INFO - 2020-10-21 03:31:12 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:31:12 --> Controller Class Initialized
INFO - 2020-10-21 03:31:12 --> Final output sent to browser
DEBUG - 2020-10-21 03:31:12 --> Total execution time: 0.3020
INFO - 2020-10-21 03:31:31 --> Config Class Initialized
INFO - 2020-10-21 03:31:31 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:31:31 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:31:31 --> Utf8 Class Initialized
INFO - 2020-10-21 03:31:32 --> URI Class Initialized
INFO - 2020-10-21 03:31:32 --> Router Class Initialized
INFO - 2020-10-21 03:31:32 --> Output Class Initialized
INFO - 2020-10-21 03:31:32 --> Security Class Initialized
DEBUG - 2020-10-21 03:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:31:32 --> Input Class Initialized
INFO - 2020-10-21 03:31:32 --> Language Class Initialized
INFO - 2020-10-21 03:31:32 --> Language Class Initialized
INFO - 2020-10-21 03:31:32 --> Config Class Initialized
INFO - 2020-10-21 03:31:32 --> Loader Class Initialized
INFO - 2020-10-21 03:31:32 --> Helper loaded: url_helper
INFO - 2020-10-21 03:31:32 --> Helper loaded: file_helper
INFO - 2020-10-21 03:31:32 --> Helper loaded: form_helper
INFO - 2020-10-21 03:31:32 --> Helper loaded: my_helper
INFO - 2020-10-21 03:31:32 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:31:32 --> Controller Class Initialized
ERROR - 2020-10-21 03:31:32 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:31:32 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:31:32 --> Final output sent to browser
DEBUG - 2020-10-21 03:31:32 --> Total execution time: 0.3312
INFO - 2020-10-21 03:31:34 --> Config Class Initialized
INFO - 2020-10-21 03:31:34 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:31:34 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:31:34 --> Utf8 Class Initialized
INFO - 2020-10-21 03:31:34 --> URI Class Initialized
INFO - 2020-10-21 03:31:34 --> Router Class Initialized
INFO - 2020-10-21 03:31:34 --> Output Class Initialized
INFO - 2020-10-21 03:31:34 --> Security Class Initialized
DEBUG - 2020-10-21 03:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:31:34 --> Input Class Initialized
INFO - 2020-10-21 03:31:34 --> Language Class Initialized
INFO - 2020-10-21 03:31:34 --> Language Class Initialized
INFO - 2020-10-21 03:31:34 --> Config Class Initialized
INFO - 2020-10-21 03:31:34 --> Loader Class Initialized
INFO - 2020-10-21 03:31:34 --> Helper loaded: url_helper
INFO - 2020-10-21 03:31:34 --> Helper loaded: file_helper
INFO - 2020-10-21 03:31:34 --> Helper loaded: form_helper
INFO - 2020-10-21 03:31:34 --> Helper loaded: my_helper
INFO - 2020-10-21 03:31:34 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:31:34 --> Controller Class Initialized
DEBUG - 2020-10-21 03:31:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:31:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:31:34 --> Final output sent to browser
DEBUG - 2020-10-21 03:31:34 --> Total execution time: 0.3714
INFO - 2020-10-21 03:31:34 --> Config Class Initialized
INFO - 2020-10-21 03:31:34 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:31:34 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:31:34 --> Utf8 Class Initialized
INFO - 2020-10-21 03:31:34 --> URI Class Initialized
INFO - 2020-10-21 03:31:34 --> Router Class Initialized
INFO - 2020-10-21 03:31:34 --> Output Class Initialized
INFO - 2020-10-21 03:31:34 --> Security Class Initialized
DEBUG - 2020-10-21 03:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:31:34 --> Input Class Initialized
INFO - 2020-10-21 03:31:34 --> Language Class Initialized
INFO - 2020-10-21 03:31:34 --> Language Class Initialized
INFO - 2020-10-21 03:31:34 --> Config Class Initialized
INFO - 2020-10-21 03:31:34 --> Loader Class Initialized
INFO - 2020-10-21 03:31:34 --> Helper loaded: url_helper
INFO - 2020-10-21 03:31:34 --> Helper loaded: file_helper
INFO - 2020-10-21 03:31:34 --> Helper loaded: form_helper
INFO - 2020-10-21 03:31:34 --> Helper loaded: my_helper
INFO - 2020-10-21 03:31:34 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:31:35 --> Controller Class Initialized
INFO - 2020-10-21 03:31:37 --> Config Class Initialized
INFO - 2020-10-21 03:31:37 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:31:37 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:31:37 --> Utf8 Class Initialized
INFO - 2020-10-21 03:31:37 --> URI Class Initialized
INFO - 2020-10-21 03:31:37 --> Router Class Initialized
INFO - 2020-10-21 03:31:37 --> Output Class Initialized
INFO - 2020-10-21 03:31:37 --> Security Class Initialized
DEBUG - 2020-10-21 03:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:31:37 --> Input Class Initialized
INFO - 2020-10-21 03:31:37 --> Language Class Initialized
INFO - 2020-10-21 03:31:37 --> Language Class Initialized
INFO - 2020-10-21 03:31:37 --> Config Class Initialized
INFO - 2020-10-21 03:31:37 --> Loader Class Initialized
INFO - 2020-10-21 03:31:37 --> Helper loaded: url_helper
INFO - 2020-10-21 03:31:37 --> Helper loaded: file_helper
INFO - 2020-10-21 03:31:37 --> Helper loaded: form_helper
INFO - 2020-10-21 03:31:37 --> Helper loaded: my_helper
INFO - 2020-10-21 03:31:37 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:31:37 --> Controller Class Initialized
INFO - 2020-10-21 03:31:37 --> Final output sent to browser
DEBUG - 2020-10-21 03:31:37 --> Total execution time: 0.2830
INFO - 2020-10-21 03:31:42 --> Config Class Initialized
INFO - 2020-10-21 03:31:42 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:31:42 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:31:42 --> Utf8 Class Initialized
INFO - 2020-10-21 03:31:42 --> URI Class Initialized
INFO - 2020-10-21 03:31:42 --> Router Class Initialized
INFO - 2020-10-21 03:31:42 --> Output Class Initialized
INFO - 2020-10-21 03:31:42 --> Security Class Initialized
DEBUG - 2020-10-21 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:31:42 --> Input Class Initialized
INFO - 2020-10-21 03:31:42 --> Language Class Initialized
INFO - 2020-10-21 03:31:42 --> Language Class Initialized
INFO - 2020-10-21 03:31:42 --> Config Class Initialized
INFO - 2020-10-21 03:31:42 --> Loader Class Initialized
INFO - 2020-10-21 03:31:42 --> Helper loaded: url_helper
INFO - 2020-10-21 03:31:42 --> Helper loaded: file_helper
INFO - 2020-10-21 03:31:42 --> Helper loaded: form_helper
INFO - 2020-10-21 03:31:42 --> Helper loaded: my_helper
INFO - 2020-10-21 03:31:42 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:31:42 --> Controller Class Initialized
INFO - 2020-10-21 03:31:42 --> Final output sent to browser
DEBUG - 2020-10-21 03:31:42 --> Total execution time: 0.3160
INFO - 2020-10-21 03:31:42 --> Config Class Initialized
INFO - 2020-10-21 03:31:42 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:31:42 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:31:42 --> Utf8 Class Initialized
INFO - 2020-10-21 03:31:42 --> URI Class Initialized
INFO - 2020-10-21 03:31:42 --> Router Class Initialized
INFO - 2020-10-21 03:31:42 --> Output Class Initialized
INFO - 2020-10-21 03:31:42 --> Security Class Initialized
DEBUG - 2020-10-21 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:31:42 --> Input Class Initialized
INFO - 2020-10-21 03:31:42 --> Language Class Initialized
INFO - 2020-10-21 03:31:42 --> Language Class Initialized
INFO - 2020-10-21 03:31:42 --> Config Class Initialized
INFO - 2020-10-21 03:31:42 --> Loader Class Initialized
INFO - 2020-10-21 03:31:42 --> Helper loaded: url_helper
INFO - 2020-10-21 03:31:42 --> Helper loaded: file_helper
INFO - 2020-10-21 03:31:42 --> Helper loaded: form_helper
INFO - 2020-10-21 03:31:42 --> Helper loaded: my_helper
INFO - 2020-10-21 03:31:42 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:31:42 --> Controller Class Initialized
INFO - 2020-10-21 03:33:58 --> Config Class Initialized
INFO - 2020-10-21 03:33:58 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:33:58 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:33:58 --> Utf8 Class Initialized
INFO - 2020-10-21 03:33:58 --> URI Class Initialized
INFO - 2020-10-21 03:33:58 --> Router Class Initialized
INFO - 2020-10-21 03:33:58 --> Output Class Initialized
INFO - 2020-10-21 03:33:58 --> Security Class Initialized
DEBUG - 2020-10-21 03:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:33:59 --> Input Class Initialized
INFO - 2020-10-21 03:33:59 --> Language Class Initialized
INFO - 2020-10-21 03:33:59 --> Language Class Initialized
INFO - 2020-10-21 03:33:59 --> Config Class Initialized
INFO - 2020-10-21 03:33:59 --> Loader Class Initialized
INFO - 2020-10-21 03:33:59 --> Helper loaded: url_helper
INFO - 2020-10-21 03:33:59 --> Helper loaded: file_helper
INFO - 2020-10-21 03:33:59 --> Helper loaded: form_helper
INFO - 2020-10-21 03:33:59 --> Helper loaded: my_helper
INFO - 2020-10-21 03:33:59 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:33:59 --> Controller Class Initialized
DEBUG - 2020-10-21 03:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:33:59 --> Final output sent to browser
DEBUG - 2020-10-21 03:33:59 --> Total execution time: 0.2722
INFO - 2020-10-21 03:33:59 --> Config Class Initialized
INFO - 2020-10-21 03:33:59 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:33:59 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:33:59 --> Utf8 Class Initialized
INFO - 2020-10-21 03:33:59 --> URI Class Initialized
INFO - 2020-10-21 03:33:59 --> Router Class Initialized
INFO - 2020-10-21 03:33:59 --> Output Class Initialized
INFO - 2020-10-21 03:33:59 --> Security Class Initialized
DEBUG - 2020-10-21 03:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:33:59 --> Input Class Initialized
INFO - 2020-10-21 03:33:59 --> Language Class Initialized
INFO - 2020-10-21 03:33:59 --> Language Class Initialized
INFO - 2020-10-21 03:33:59 --> Config Class Initialized
INFO - 2020-10-21 03:33:59 --> Loader Class Initialized
INFO - 2020-10-21 03:33:59 --> Helper loaded: url_helper
INFO - 2020-10-21 03:33:59 --> Helper loaded: file_helper
INFO - 2020-10-21 03:33:59 --> Helper loaded: form_helper
INFO - 2020-10-21 03:33:59 --> Helper loaded: my_helper
INFO - 2020-10-21 03:33:59 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:33:59 --> Controller Class Initialized
INFO - 2020-10-21 03:34:01 --> Config Class Initialized
INFO - 2020-10-21 03:34:01 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:01 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:01 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:01 --> URI Class Initialized
INFO - 2020-10-21 03:34:01 --> Router Class Initialized
INFO - 2020-10-21 03:34:01 --> Output Class Initialized
INFO - 2020-10-21 03:34:01 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:01 --> Input Class Initialized
INFO - 2020-10-21 03:34:01 --> Language Class Initialized
INFO - 2020-10-21 03:34:01 --> Language Class Initialized
INFO - 2020-10-21 03:34:01 --> Config Class Initialized
INFO - 2020-10-21 03:34:01 --> Loader Class Initialized
INFO - 2020-10-21 03:34:01 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:01 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:01 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:01 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:01 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:01 --> Controller Class Initialized
INFO - 2020-10-21 03:34:01 --> Final output sent to browser
DEBUG - 2020-10-21 03:34:01 --> Total execution time: 0.2964
INFO - 2020-10-21 03:34:06 --> Config Class Initialized
INFO - 2020-10-21 03:34:06 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:06 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:06 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:06 --> URI Class Initialized
INFO - 2020-10-21 03:34:06 --> Router Class Initialized
INFO - 2020-10-21 03:34:06 --> Output Class Initialized
INFO - 2020-10-21 03:34:06 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:06 --> Input Class Initialized
INFO - 2020-10-21 03:34:06 --> Language Class Initialized
INFO - 2020-10-21 03:34:06 --> Language Class Initialized
INFO - 2020-10-21 03:34:06 --> Config Class Initialized
INFO - 2020-10-21 03:34:06 --> Loader Class Initialized
INFO - 2020-10-21 03:34:06 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:06 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:06 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:06 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:06 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:06 --> Controller Class Initialized
INFO - 2020-10-21 03:34:06 --> Final output sent to browser
DEBUG - 2020-10-21 03:34:06 --> Total execution time: 0.2985
INFO - 2020-10-21 03:34:06 --> Config Class Initialized
INFO - 2020-10-21 03:34:06 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:06 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:06 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:06 --> URI Class Initialized
INFO - 2020-10-21 03:34:06 --> Router Class Initialized
INFO - 2020-10-21 03:34:07 --> Output Class Initialized
INFO - 2020-10-21 03:34:07 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:07 --> Input Class Initialized
INFO - 2020-10-21 03:34:07 --> Language Class Initialized
INFO - 2020-10-21 03:34:07 --> Language Class Initialized
INFO - 2020-10-21 03:34:07 --> Config Class Initialized
INFO - 2020-10-21 03:34:07 --> Loader Class Initialized
INFO - 2020-10-21 03:34:07 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:07 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:07 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:07 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:07 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:07 --> Controller Class Initialized
INFO - 2020-10-21 03:34:12 --> Config Class Initialized
INFO - 2020-10-21 03:34:12 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:12 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:12 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:12 --> URI Class Initialized
INFO - 2020-10-21 03:34:12 --> Router Class Initialized
INFO - 2020-10-21 03:34:12 --> Output Class Initialized
INFO - 2020-10-21 03:34:12 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:12 --> Input Class Initialized
INFO - 2020-10-21 03:34:12 --> Language Class Initialized
INFO - 2020-10-21 03:34:12 --> Language Class Initialized
INFO - 2020-10-21 03:34:12 --> Config Class Initialized
INFO - 2020-10-21 03:34:12 --> Loader Class Initialized
INFO - 2020-10-21 03:34:12 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:12 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:12 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:12 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:12 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:12 --> Controller Class Initialized
INFO - 2020-10-21 03:34:12 --> Final output sent to browser
DEBUG - 2020-10-21 03:34:12 --> Total execution time: 0.3112
INFO - 2020-10-21 03:34:22 --> Config Class Initialized
INFO - 2020-10-21 03:34:22 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:22 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:22 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:22 --> URI Class Initialized
INFO - 2020-10-21 03:34:22 --> Router Class Initialized
INFO - 2020-10-21 03:34:22 --> Output Class Initialized
INFO - 2020-10-21 03:34:22 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:22 --> Input Class Initialized
INFO - 2020-10-21 03:34:22 --> Language Class Initialized
INFO - 2020-10-21 03:34:22 --> Language Class Initialized
INFO - 2020-10-21 03:34:23 --> Config Class Initialized
INFO - 2020-10-21 03:34:23 --> Loader Class Initialized
INFO - 2020-10-21 03:34:23 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:23 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:23 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:23 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:23 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:23 --> Controller Class Initialized
ERROR - 2020-10-21 03:34:23 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:34:23 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:34:23 --> Final output sent to browser
DEBUG - 2020-10-21 03:34:23 --> Total execution time: 0.3199
INFO - 2020-10-21 03:34:24 --> Config Class Initialized
INFO - 2020-10-21 03:34:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:25 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:25 --> URI Class Initialized
INFO - 2020-10-21 03:34:25 --> Router Class Initialized
INFO - 2020-10-21 03:34:25 --> Output Class Initialized
INFO - 2020-10-21 03:34:25 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:25 --> Input Class Initialized
INFO - 2020-10-21 03:34:25 --> Language Class Initialized
INFO - 2020-10-21 03:34:25 --> Language Class Initialized
INFO - 2020-10-21 03:34:25 --> Config Class Initialized
INFO - 2020-10-21 03:34:25 --> Loader Class Initialized
INFO - 2020-10-21 03:34:25 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:25 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:25 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:25 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:25 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:25 --> Controller Class Initialized
DEBUG - 2020-10-21 03:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:34:25 --> Final output sent to browser
DEBUG - 2020-10-21 03:34:25 --> Total execution time: 0.3149
INFO - 2020-10-21 03:34:25 --> Config Class Initialized
INFO - 2020-10-21 03:34:25 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:25 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:25 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:25 --> URI Class Initialized
INFO - 2020-10-21 03:34:25 --> Router Class Initialized
INFO - 2020-10-21 03:34:25 --> Output Class Initialized
INFO - 2020-10-21 03:34:25 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:25 --> Input Class Initialized
INFO - 2020-10-21 03:34:25 --> Language Class Initialized
INFO - 2020-10-21 03:34:25 --> Language Class Initialized
INFO - 2020-10-21 03:34:25 --> Config Class Initialized
INFO - 2020-10-21 03:34:25 --> Loader Class Initialized
INFO - 2020-10-21 03:34:25 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:25 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:25 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:25 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:25 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:25 --> Controller Class Initialized
INFO - 2020-10-21 03:34:28 --> Config Class Initialized
INFO - 2020-10-21 03:34:28 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:28 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:28 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:28 --> URI Class Initialized
INFO - 2020-10-21 03:34:28 --> Router Class Initialized
INFO - 2020-10-21 03:34:28 --> Output Class Initialized
INFO - 2020-10-21 03:34:28 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:28 --> Input Class Initialized
INFO - 2020-10-21 03:34:28 --> Language Class Initialized
INFO - 2020-10-21 03:34:28 --> Language Class Initialized
INFO - 2020-10-21 03:34:28 --> Config Class Initialized
INFO - 2020-10-21 03:34:28 --> Loader Class Initialized
INFO - 2020-10-21 03:34:28 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:28 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:28 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:28 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:28 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:28 --> Controller Class Initialized
INFO - 2020-10-21 03:34:28 --> Final output sent to browser
DEBUG - 2020-10-21 03:34:28 --> Total execution time: 0.3022
INFO - 2020-10-21 03:34:35 --> Config Class Initialized
INFO - 2020-10-21 03:34:35 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:35 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:36 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:36 --> URI Class Initialized
INFO - 2020-10-21 03:34:36 --> Router Class Initialized
INFO - 2020-10-21 03:34:36 --> Output Class Initialized
INFO - 2020-10-21 03:34:36 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:36 --> Input Class Initialized
INFO - 2020-10-21 03:34:36 --> Language Class Initialized
INFO - 2020-10-21 03:34:36 --> Language Class Initialized
INFO - 2020-10-21 03:34:36 --> Config Class Initialized
INFO - 2020-10-21 03:34:36 --> Loader Class Initialized
INFO - 2020-10-21 03:34:36 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:36 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:36 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:36 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:36 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:36 --> Controller Class Initialized
INFO - 2020-10-21 03:34:36 --> Final output sent to browser
DEBUG - 2020-10-21 03:34:36 --> Total execution time: 0.3093
INFO - 2020-10-21 03:34:36 --> Config Class Initialized
INFO - 2020-10-21 03:34:36 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:34:36 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:34:36 --> Utf8 Class Initialized
INFO - 2020-10-21 03:34:36 --> URI Class Initialized
INFO - 2020-10-21 03:34:36 --> Router Class Initialized
INFO - 2020-10-21 03:34:36 --> Output Class Initialized
INFO - 2020-10-21 03:34:36 --> Security Class Initialized
DEBUG - 2020-10-21 03:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:34:36 --> Input Class Initialized
INFO - 2020-10-21 03:34:36 --> Language Class Initialized
INFO - 2020-10-21 03:34:36 --> Language Class Initialized
INFO - 2020-10-21 03:34:36 --> Config Class Initialized
INFO - 2020-10-21 03:34:36 --> Loader Class Initialized
INFO - 2020-10-21 03:34:36 --> Helper loaded: url_helper
INFO - 2020-10-21 03:34:36 --> Helper loaded: file_helper
INFO - 2020-10-21 03:34:36 --> Helper loaded: form_helper
INFO - 2020-10-21 03:34:36 --> Helper loaded: my_helper
INFO - 2020-10-21 03:34:36 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:34:36 --> Controller Class Initialized
INFO - 2020-10-21 03:43:21 --> Config Class Initialized
INFO - 2020-10-21 03:43:21 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:43:21 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:43:21 --> Utf8 Class Initialized
INFO - 2020-10-21 03:43:21 --> URI Class Initialized
INFO - 2020-10-21 03:43:21 --> Router Class Initialized
INFO - 2020-10-21 03:43:21 --> Output Class Initialized
INFO - 2020-10-21 03:43:21 --> Security Class Initialized
DEBUG - 2020-10-21 03:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:43:21 --> Input Class Initialized
INFO - 2020-10-21 03:43:21 --> Language Class Initialized
INFO - 2020-10-21 03:43:21 --> Language Class Initialized
INFO - 2020-10-21 03:43:21 --> Config Class Initialized
INFO - 2020-10-21 03:43:21 --> Loader Class Initialized
INFO - 2020-10-21 03:43:21 --> Helper loaded: url_helper
INFO - 2020-10-21 03:43:21 --> Helper loaded: file_helper
INFO - 2020-10-21 03:43:21 --> Helper loaded: form_helper
INFO - 2020-10-21 03:43:21 --> Helper loaded: my_helper
INFO - 2020-10-21 03:43:21 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:43:21 --> Controller Class Initialized
INFO - 2020-10-21 03:43:21 --> Final output sent to browser
DEBUG - 2020-10-21 03:43:21 --> Total execution time: 0.2721
INFO - 2020-10-21 03:43:31 --> Config Class Initialized
INFO - 2020-10-21 03:43:31 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:43:31 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:43:31 --> Utf8 Class Initialized
INFO - 2020-10-21 03:43:31 --> URI Class Initialized
INFO - 2020-10-21 03:43:31 --> Router Class Initialized
INFO - 2020-10-21 03:43:31 --> Output Class Initialized
INFO - 2020-10-21 03:43:31 --> Security Class Initialized
DEBUG - 2020-10-21 03:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:43:31 --> Input Class Initialized
INFO - 2020-10-21 03:43:31 --> Language Class Initialized
INFO - 2020-10-21 03:43:31 --> Language Class Initialized
INFO - 2020-10-21 03:43:31 --> Config Class Initialized
INFO - 2020-10-21 03:43:31 --> Loader Class Initialized
INFO - 2020-10-21 03:43:31 --> Helper loaded: url_helper
INFO - 2020-10-21 03:43:31 --> Helper loaded: file_helper
INFO - 2020-10-21 03:43:31 --> Helper loaded: form_helper
INFO - 2020-10-21 03:43:31 --> Helper loaded: my_helper
INFO - 2020-10-21 03:43:31 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:43:31 --> Controller Class Initialized
ERROR - 2020-10-21 03:43:31 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:43:31 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:43:31 --> Final output sent to browser
DEBUG - 2020-10-21 03:43:31 --> Total execution time: 0.3184
INFO - 2020-10-21 03:43:33 --> Config Class Initialized
INFO - 2020-10-21 03:43:33 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:43:33 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:43:33 --> Utf8 Class Initialized
INFO - 2020-10-21 03:43:33 --> URI Class Initialized
INFO - 2020-10-21 03:43:33 --> Router Class Initialized
INFO - 2020-10-21 03:43:33 --> Output Class Initialized
INFO - 2020-10-21 03:43:33 --> Security Class Initialized
DEBUG - 2020-10-21 03:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:43:33 --> Input Class Initialized
INFO - 2020-10-21 03:43:33 --> Language Class Initialized
INFO - 2020-10-21 03:43:33 --> Language Class Initialized
INFO - 2020-10-21 03:43:33 --> Config Class Initialized
INFO - 2020-10-21 03:43:33 --> Loader Class Initialized
INFO - 2020-10-21 03:43:33 --> Helper loaded: url_helper
INFO - 2020-10-21 03:43:33 --> Helper loaded: file_helper
INFO - 2020-10-21 03:43:33 --> Helper loaded: form_helper
INFO - 2020-10-21 03:43:33 --> Helper loaded: my_helper
INFO - 2020-10-21 03:43:33 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:43:33 --> Controller Class Initialized
DEBUG - 2020-10-21 03:43:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:43:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:43:33 --> Final output sent to browser
DEBUG - 2020-10-21 03:43:33 --> Total execution time: 0.3426
INFO - 2020-10-21 03:43:33 --> Config Class Initialized
INFO - 2020-10-21 03:43:33 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:43:33 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:43:33 --> Utf8 Class Initialized
INFO - 2020-10-21 03:43:33 --> URI Class Initialized
INFO - 2020-10-21 03:43:33 --> Router Class Initialized
INFO - 2020-10-21 03:43:33 --> Output Class Initialized
INFO - 2020-10-21 03:43:33 --> Security Class Initialized
DEBUG - 2020-10-21 03:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:43:33 --> Input Class Initialized
INFO - 2020-10-21 03:43:33 --> Language Class Initialized
INFO - 2020-10-21 03:43:33 --> Language Class Initialized
INFO - 2020-10-21 03:43:33 --> Config Class Initialized
INFO - 2020-10-21 03:43:33 --> Loader Class Initialized
INFO - 2020-10-21 03:43:33 --> Helper loaded: url_helper
INFO - 2020-10-21 03:43:33 --> Helper loaded: file_helper
INFO - 2020-10-21 03:43:33 --> Helper loaded: form_helper
INFO - 2020-10-21 03:43:33 --> Helper loaded: my_helper
INFO - 2020-10-21 03:43:33 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:43:33 --> Controller Class Initialized
INFO - 2020-10-21 03:44:04 --> Config Class Initialized
INFO - 2020-10-21 03:44:04 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:44:04 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:44:04 --> Utf8 Class Initialized
INFO - 2020-10-21 03:44:04 --> URI Class Initialized
INFO - 2020-10-21 03:44:04 --> Router Class Initialized
INFO - 2020-10-21 03:44:04 --> Output Class Initialized
INFO - 2020-10-21 03:44:04 --> Security Class Initialized
DEBUG - 2020-10-21 03:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:44:04 --> Input Class Initialized
INFO - 2020-10-21 03:44:04 --> Language Class Initialized
INFO - 2020-10-21 03:44:04 --> Language Class Initialized
INFO - 2020-10-21 03:44:04 --> Config Class Initialized
INFO - 2020-10-21 03:44:05 --> Loader Class Initialized
INFO - 2020-10-21 03:44:05 --> Helper loaded: url_helper
INFO - 2020-10-21 03:44:05 --> Helper loaded: file_helper
INFO - 2020-10-21 03:44:05 --> Helper loaded: form_helper
INFO - 2020-10-21 03:44:05 --> Helper loaded: my_helper
INFO - 2020-10-21 03:44:05 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:44:05 --> Controller Class Initialized
DEBUG - 2020-10-21 03:44:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:44:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:44:05 --> Final output sent to browser
DEBUG - 2020-10-21 03:44:05 --> Total execution time: 0.2942
INFO - 2020-10-21 03:44:05 --> Config Class Initialized
INFO - 2020-10-21 03:44:05 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:44:05 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:44:05 --> Utf8 Class Initialized
INFO - 2020-10-21 03:44:05 --> URI Class Initialized
INFO - 2020-10-21 03:44:05 --> Router Class Initialized
INFO - 2020-10-21 03:44:05 --> Output Class Initialized
INFO - 2020-10-21 03:44:05 --> Security Class Initialized
DEBUG - 2020-10-21 03:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:44:05 --> Input Class Initialized
INFO - 2020-10-21 03:44:05 --> Language Class Initialized
INFO - 2020-10-21 03:44:05 --> Language Class Initialized
INFO - 2020-10-21 03:44:05 --> Config Class Initialized
INFO - 2020-10-21 03:44:05 --> Loader Class Initialized
INFO - 2020-10-21 03:44:05 --> Helper loaded: url_helper
INFO - 2020-10-21 03:44:05 --> Helper loaded: file_helper
INFO - 2020-10-21 03:44:05 --> Helper loaded: form_helper
INFO - 2020-10-21 03:44:05 --> Helper loaded: my_helper
INFO - 2020-10-21 03:44:05 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:44:05 --> Controller Class Initialized
INFO - 2020-10-21 03:44:06 --> Config Class Initialized
INFO - 2020-10-21 03:44:06 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:44:06 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:44:06 --> Utf8 Class Initialized
INFO - 2020-10-21 03:44:06 --> URI Class Initialized
INFO - 2020-10-21 03:44:06 --> Router Class Initialized
INFO - 2020-10-21 03:44:06 --> Output Class Initialized
INFO - 2020-10-21 03:44:06 --> Security Class Initialized
DEBUG - 2020-10-21 03:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:44:06 --> Input Class Initialized
INFO - 2020-10-21 03:44:06 --> Language Class Initialized
INFO - 2020-10-21 03:44:06 --> Language Class Initialized
INFO - 2020-10-21 03:44:06 --> Config Class Initialized
INFO - 2020-10-21 03:44:06 --> Loader Class Initialized
INFO - 2020-10-21 03:44:06 --> Helper loaded: url_helper
INFO - 2020-10-21 03:44:06 --> Helper loaded: file_helper
INFO - 2020-10-21 03:44:06 --> Helper loaded: form_helper
INFO - 2020-10-21 03:44:06 --> Helper loaded: my_helper
INFO - 2020-10-21 03:44:06 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:44:06 --> Controller Class Initialized
INFO - 2020-10-21 03:44:06 --> Final output sent to browser
DEBUG - 2020-10-21 03:44:06 --> Total execution time: 0.2749
INFO - 2020-10-21 03:44:22 --> Config Class Initialized
INFO - 2020-10-21 03:44:22 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:44:22 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:44:22 --> Utf8 Class Initialized
INFO - 2020-10-21 03:44:22 --> URI Class Initialized
INFO - 2020-10-21 03:44:22 --> Router Class Initialized
INFO - 2020-10-21 03:44:22 --> Output Class Initialized
INFO - 2020-10-21 03:44:22 --> Security Class Initialized
DEBUG - 2020-10-21 03:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:44:22 --> Input Class Initialized
INFO - 2020-10-21 03:44:22 --> Language Class Initialized
INFO - 2020-10-21 03:44:22 --> Language Class Initialized
INFO - 2020-10-21 03:44:22 --> Config Class Initialized
INFO - 2020-10-21 03:44:22 --> Loader Class Initialized
INFO - 2020-10-21 03:44:22 --> Helper loaded: url_helper
INFO - 2020-10-21 03:44:22 --> Helper loaded: file_helper
INFO - 2020-10-21 03:44:22 --> Helper loaded: form_helper
INFO - 2020-10-21 03:44:22 --> Helper loaded: my_helper
INFO - 2020-10-21 03:44:22 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:44:22 --> Controller Class Initialized
ERROR - 2020-10-21 03:44:22 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:44:22 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:44:22 --> Final output sent to browser
DEBUG - 2020-10-21 03:44:22 --> Total execution time: 0.3288
INFO - 2020-10-21 03:44:24 --> Config Class Initialized
INFO - 2020-10-21 03:44:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:44:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:44:24 --> Utf8 Class Initialized
INFO - 2020-10-21 03:44:24 --> URI Class Initialized
INFO - 2020-10-21 03:44:24 --> Router Class Initialized
INFO - 2020-10-21 03:44:24 --> Output Class Initialized
INFO - 2020-10-21 03:44:24 --> Security Class Initialized
DEBUG - 2020-10-21 03:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:44:24 --> Input Class Initialized
INFO - 2020-10-21 03:44:24 --> Language Class Initialized
INFO - 2020-10-21 03:44:24 --> Language Class Initialized
INFO - 2020-10-21 03:44:24 --> Config Class Initialized
INFO - 2020-10-21 03:44:24 --> Loader Class Initialized
INFO - 2020-10-21 03:44:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:44:24 --> Helper loaded: file_helper
INFO - 2020-10-21 03:44:24 --> Helper loaded: form_helper
INFO - 2020-10-21 03:44:24 --> Helper loaded: my_helper
INFO - 2020-10-21 03:44:24 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:44:24 --> Controller Class Initialized
DEBUG - 2020-10-21 03:44:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:44:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:44:24 --> Final output sent to browser
DEBUG - 2020-10-21 03:44:24 --> Total execution time: 0.2960
INFO - 2020-10-21 03:44:24 --> Config Class Initialized
INFO - 2020-10-21 03:44:24 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:44:24 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:44:24 --> Utf8 Class Initialized
INFO - 2020-10-21 03:44:24 --> URI Class Initialized
INFO - 2020-10-21 03:44:24 --> Router Class Initialized
INFO - 2020-10-21 03:44:24 --> Output Class Initialized
INFO - 2020-10-21 03:44:24 --> Security Class Initialized
DEBUG - 2020-10-21 03:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:44:24 --> Input Class Initialized
INFO - 2020-10-21 03:44:24 --> Language Class Initialized
INFO - 2020-10-21 03:44:24 --> Language Class Initialized
INFO - 2020-10-21 03:44:24 --> Config Class Initialized
INFO - 2020-10-21 03:44:24 --> Loader Class Initialized
INFO - 2020-10-21 03:44:24 --> Helper loaded: url_helper
INFO - 2020-10-21 03:44:25 --> Helper loaded: file_helper
INFO - 2020-10-21 03:44:25 --> Helper loaded: form_helper
INFO - 2020-10-21 03:44:25 --> Helper loaded: my_helper
INFO - 2020-10-21 03:44:25 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:44:25 --> Controller Class Initialized
INFO - 2020-10-21 03:45:55 --> Config Class Initialized
INFO - 2020-10-21 03:45:55 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:45:55 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:45:55 --> Utf8 Class Initialized
INFO - 2020-10-21 03:45:55 --> URI Class Initialized
INFO - 2020-10-21 03:45:55 --> Router Class Initialized
INFO - 2020-10-21 03:45:55 --> Output Class Initialized
INFO - 2020-10-21 03:45:55 --> Security Class Initialized
DEBUG - 2020-10-21 03:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:45:55 --> Input Class Initialized
INFO - 2020-10-21 03:45:55 --> Language Class Initialized
INFO - 2020-10-21 03:45:55 --> Language Class Initialized
INFO - 2020-10-21 03:45:55 --> Config Class Initialized
INFO - 2020-10-21 03:45:55 --> Loader Class Initialized
INFO - 2020-10-21 03:45:55 --> Helper loaded: url_helper
INFO - 2020-10-21 03:45:55 --> Helper loaded: file_helper
INFO - 2020-10-21 03:45:55 --> Helper loaded: form_helper
INFO - 2020-10-21 03:45:55 --> Helper loaded: my_helper
INFO - 2020-10-21 03:45:55 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:45:55 --> Controller Class Initialized
INFO - 2020-10-21 03:45:55 --> Final output sent to browser
DEBUG - 2020-10-21 03:45:55 --> Total execution time: 0.2944
INFO - 2020-10-21 03:46:01 --> Config Class Initialized
INFO - 2020-10-21 03:46:01 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:46:01 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:46:01 --> Utf8 Class Initialized
INFO - 2020-10-21 03:46:01 --> URI Class Initialized
INFO - 2020-10-21 03:46:01 --> Router Class Initialized
INFO - 2020-10-21 03:46:01 --> Output Class Initialized
INFO - 2020-10-21 03:46:01 --> Security Class Initialized
DEBUG - 2020-10-21 03:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:46:01 --> Input Class Initialized
INFO - 2020-10-21 03:46:01 --> Language Class Initialized
INFO - 2020-10-21 03:46:01 --> Language Class Initialized
INFO - 2020-10-21 03:46:01 --> Config Class Initialized
INFO - 2020-10-21 03:46:01 --> Loader Class Initialized
INFO - 2020-10-21 03:46:01 --> Helper loaded: url_helper
INFO - 2020-10-21 03:46:01 --> Helper loaded: file_helper
INFO - 2020-10-21 03:46:01 --> Helper loaded: form_helper
INFO - 2020-10-21 03:46:01 --> Helper loaded: my_helper
INFO - 2020-10-21 03:46:01 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:46:01 --> Controller Class Initialized
ERROR - 2020-10-21 03:46:01 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:46:01 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:46:01 --> Final output sent to browser
DEBUG - 2020-10-21 03:46:01 --> Total execution time: 0.3099
INFO - 2020-10-21 03:46:03 --> Config Class Initialized
INFO - 2020-10-21 03:46:03 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:46:03 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:46:03 --> Utf8 Class Initialized
INFO - 2020-10-21 03:46:03 --> URI Class Initialized
INFO - 2020-10-21 03:46:03 --> Router Class Initialized
INFO - 2020-10-21 03:46:03 --> Output Class Initialized
INFO - 2020-10-21 03:46:03 --> Security Class Initialized
DEBUG - 2020-10-21 03:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:46:03 --> Input Class Initialized
INFO - 2020-10-21 03:46:03 --> Language Class Initialized
INFO - 2020-10-21 03:46:03 --> Language Class Initialized
INFO - 2020-10-21 03:46:03 --> Config Class Initialized
INFO - 2020-10-21 03:46:03 --> Loader Class Initialized
INFO - 2020-10-21 03:46:03 --> Helper loaded: url_helper
INFO - 2020-10-21 03:46:03 --> Helper loaded: file_helper
INFO - 2020-10-21 03:46:03 --> Helper loaded: form_helper
INFO - 2020-10-21 03:46:03 --> Helper loaded: my_helper
INFO - 2020-10-21 03:46:03 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:46:03 --> Controller Class Initialized
DEBUG - 2020-10-21 03:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:46:03 --> Final output sent to browser
DEBUG - 2020-10-21 03:46:03 --> Total execution time: 0.3090
INFO - 2020-10-21 03:46:03 --> Config Class Initialized
INFO - 2020-10-21 03:46:03 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:46:03 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:46:03 --> Utf8 Class Initialized
INFO - 2020-10-21 03:46:03 --> URI Class Initialized
INFO - 2020-10-21 03:46:03 --> Router Class Initialized
INFO - 2020-10-21 03:46:03 --> Output Class Initialized
INFO - 2020-10-21 03:46:03 --> Security Class Initialized
DEBUG - 2020-10-21 03:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:46:03 --> Input Class Initialized
INFO - 2020-10-21 03:46:03 --> Language Class Initialized
INFO - 2020-10-21 03:46:03 --> Language Class Initialized
INFO - 2020-10-21 03:46:03 --> Config Class Initialized
INFO - 2020-10-21 03:46:03 --> Loader Class Initialized
INFO - 2020-10-21 03:46:03 --> Helper loaded: url_helper
INFO - 2020-10-21 03:46:03 --> Helper loaded: file_helper
INFO - 2020-10-21 03:46:03 --> Helper loaded: form_helper
INFO - 2020-10-21 03:46:03 --> Helper loaded: my_helper
INFO - 2020-10-21 03:46:03 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:46:03 --> Controller Class Initialized
INFO - 2020-10-21 03:47:13 --> Config Class Initialized
INFO - 2020-10-21 03:47:13 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:13 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:13 --> URI Class Initialized
INFO - 2020-10-21 03:47:13 --> Router Class Initialized
INFO - 2020-10-21 03:47:13 --> Output Class Initialized
INFO - 2020-10-21 03:47:13 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:14 --> Input Class Initialized
INFO - 2020-10-21 03:47:14 --> Language Class Initialized
INFO - 2020-10-21 03:47:14 --> Language Class Initialized
INFO - 2020-10-21 03:47:14 --> Config Class Initialized
INFO - 2020-10-21 03:47:14 --> Loader Class Initialized
INFO - 2020-10-21 03:47:14 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:14 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:14 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:14 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:14 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:14 --> Controller Class Initialized
DEBUG - 2020-10-21 03:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:47:14 --> Final output sent to browser
DEBUG - 2020-10-21 03:47:14 --> Total execution time: 0.4074
INFO - 2020-10-21 03:47:14 --> Config Class Initialized
INFO - 2020-10-21 03:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:14 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:14 --> URI Class Initialized
INFO - 2020-10-21 03:47:14 --> Router Class Initialized
INFO - 2020-10-21 03:47:14 --> Output Class Initialized
INFO - 2020-10-21 03:47:14 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:14 --> Input Class Initialized
INFO - 2020-10-21 03:47:14 --> Language Class Initialized
INFO - 2020-10-21 03:47:14 --> Language Class Initialized
INFO - 2020-10-21 03:47:14 --> Config Class Initialized
INFO - 2020-10-21 03:47:14 --> Loader Class Initialized
INFO - 2020-10-21 03:47:14 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:14 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:14 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:14 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:14 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:14 --> Controller Class Initialized
INFO - 2020-10-21 03:47:22 --> Config Class Initialized
INFO - 2020-10-21 03:47:22 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:22 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:22 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:22 --> URI Class Initialized
INFO - 2020-10-21 03:47:22 --> Router Class Initialized
INFO - 2020-10-21 03:47:22 --> Output Class Initialized
INFO - 2020-10-21 03:47:22 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:22 --> Input Class Initialized
INFO - 2020-10-21 03:47:22 --> Language Class Initialized
INFO - 2020-10-21 03:47:22 --> Language Class Initialized
INFO - 2020-10-21 03:47:22 --> Config Class Initialized
INFO - 2020-10-21 03:47:22 --> Loader Class Initialized
INFO - 2020-10-21 03:47:22 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:22 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:22 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:22 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:22 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:22 --> Controller Class Initialized
INFO - 2020-10-21 03:47:22 --> Final output sent to browser
DEBUG - 2020-10-21 03:47:22 --> Total execution time: 0.2696
INFO - 2020-10-21 03:47:27 --> Config Class Initialized
INFO - 2020-10-21 03:47:27 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:27 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:27 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:27 --> URI Class Initialized
INFO - 2020-10-21 03:47:27 --> Router Class Initialized
INFO - 2020-10-21 03:47:27 --> Output Class Initialized
INFO - 2020-10-21 03:47:27 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:27 --> Input Class Initialized
INFO - 2020-10-21 03:47:27 --> Language Class Initialized
INFO - 2020-10-21 03:47:27 --> Language Class Initialized
INFO - 2020-10-21 03:47:27 --> Config Class Initialized
INFO - 2020-10-21 03:47:27 --> Loader Class Initialized
INFO - 2020-10-21 03:47:27 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:27 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:27 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:27 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:27 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:27 --> Controller Class Initialized
ERROR - 2020-10-21 03:47:27 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-21 03:47:27 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-21 03:47:27 --> Final output sent to browser
DEBUG - 2020-10-21 03:47:27 --> Total execution time: 0.3397
INFO - 2020-10-21 03:47:28 --> Config Class Initialized
INFO - 2020-10-21 03:47:28 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:28 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:28 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:28 --> URI Class Initialized
INFO - 2020-10-21 03:47:28 --> Router Class Initialized
INFO - 2020-10-21 03:47:28 --> Output Class Initialized
INFO - 2020-10-21 03:47:28 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:28 --> Input Class Initialized
INFO - 2020-10-21 03:47:28 --> Language Class Initialized
INFO - 2020-10-21 03:47:28 --> Language Class Initialized
INFO - 2020-10-21 03:47:28 --> Config Class Initialized
INFO - 2020-10-21 03:47:29 --> Loader Class Initialized
INFO - 2020-10-21 03:47:29 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:29 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:29 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:29 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:29 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:29 --> Controller Class Initialized
DEBUG - 2020-10-21 03:47:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-21 03:47:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:47:29 --> Final output sent to browser
DEBUG - 2020-10-21 03:47:29 --> Total execution time: 0.3112
INFO - 2020-10-21 03:47:29 --> Config Class Initialized
INFO - 2020-10-21 03:47:29 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:29 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:29 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:29 --> URI Class Initialized
INFO - 2020-10-21 03:47:29 --> Router Class Initialized
INFO - 2020-10-21 03:47:29 --> Output Class Initialized
INFO - 2020-10-21 03:47:29 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:29 --> Input Class Initialized
INFO - 2020-10-21 03:47:29 --> Language Class Initialized
INFO - 2020-10-21 03:47:29 --> Language Class Initialized
INFO - 2020-10-21 03:47:29 --> Config Class Initialized
INFO - 2020-10-21 03:47:29 --> Loader Class Initialized
INFO - 2020-10-21 03:47:29 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:29 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:29 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:29 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:29 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:29 --> Controller Class Initialized
INFO - 2020-10-21 03:47:31 --> Config Class Initialized
INFO - 2020-10-21 03:47:31 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:31 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:31 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:31 --> URI Class Initialized
INFO - 2020-10-21 03:47:31 --> Router Class Initialized
INFO - 2020-10-21 03:47:31 --> Output Class Initialized
INFO - 2020-10-21 03:47:31 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:31 --> Input Class Initialized
INFO - 2020-10-21 03:47:31 --> Language Class Initialized
INFO - 2020-10-21 03:47:31 --> Language Class Initialized
INFO - 2020-10-21 03:47:31 --> Config Class Initialized
INFO - 2020-10-21 03:47:31 --> Loader Class Initialized
INFO - 2020-10-21 03:47:31 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:31 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:31 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:31 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:31 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:32 --> Controller Class Initialized
INFO - 2020-10-21 03:47:32 --> Final output sent to browser
DEBUG - 2020-10-21 03:47:32 --> Total execution time: 0.3196
INFO - 2020-10-21 03:47:35 --> Config Class Initialized
INFO - 2020-10-21 03:47:35 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:35 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:35 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:35 --> URI Class Initialized
INFO - 2020-10-21 03:47:35 --> Router Class Initialized
INFO - 2020-10-21 03:47:35 --> Output Class Initialized
INFO - 2020-10-21 03:47:35 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:35 --> Input Class Initialized
INFO - 2020-10-21 03:47:35 --> Language Class Initialized
INFO - 2020-10-21 03:47:35 --> Language Class Initialized
INFO - 2020-10-21 03:47:35 --> Config Class Initialized
INFO - 2020-10-21 03:47:35 --> Loader Class Initialized
INFO - 2020-10-21 03:47:35 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:35 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:35 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:35 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:35 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:35 --> Controller Class Initialized
INFO - 2020-10-21 03:47:35 --> Final output sent to browser
DEBUG - 2020-10-21 03:47:35 --> Total execution time: 0.3149
INFO - 2020-10-21 03:47:35 --> Config Class Initialized
INFO - 2020-10-21 03:47:35 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:47:35 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:47:35 --> Utf8 Class Initialized
INFO - 2020-10-21 03:47:35 --> URI Class Initialized
INFO - 2020-10-21 03:47:35 --> Router Class Initialized
INFO - 2020-10-21 03:47:35 --> Output Class Initialized
INFO - 2020-10-21 03:47:35 --> Security Class Initialized
DEBUG - 2020-10-21 03:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:47:35 --> Input Class Initialized
INFO - 2020-10-21 03:47:36 --> Language Class Initialized
INFO - 2020-10-21 03:47:36 --> Language Class Initialized
INFO - 2020-10-21 03:47:36 --> Config Class Initialized
INFO - 2020-10-21 03:47:36 --> Loader Class Initialized
INFO - 2020-10-21 03:47:36 --> Helper loaded: url_helper
INFO - 2020-10-21 03:47:36 --> Helper loaded: file_helper
INFO - 2020-10-21 03:47:36 --> Helper loaded: form_helper
INFO - 2020-10-21 03:47:36 --> Helper loaded: my_helper
INFO - 2020-10-21 03:47:36 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:47:36 --> Controller Class Initialized
INFO - 2020-10-21 03:48:08 --> Config Class Initialized
INFO - 2020-10-21 03:48:08 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:48:08 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:48:08 --> Utf8 Class Initialized
INFO - 2020-10-21 03:48:08 --> URI Class Initialized
INFO - 2020-10-21 03:48:08 --> Router Class Initialized
INFO - 2020-10-21 03:48:08 --> Output Class Initialized
INFO - 2020-10-21 03:48:09 --> Security Class Initialized
DEBUG - 2020-10-21 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:48:09 --> Input Class Initialized
INFO - 2020-10-21 03:48:09 --> Language Class Initialized
INFO - 2020-10-21 03:48:09 --> Language Class Initialized
INFO - 2020-10-21 03:48:09 --> Config Class Initialized
INFO - 2020-10-21 03:48:09 --> Loader Class Initialized
INFO - 2020-10-21 03:48:09 --> Helper loaded: url_helper
INFO - 2020-10-21 03:48:09 --> Helper loaded: file_helper
INFO - 2020-10-21 03:48:09 --> Helper loaded: form_helper
INFO - 2020-10-21 03:48:09 --> Helper loaded: my_helper
INFO - 2020-10-21 03:48:09 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:48:09 --> Controller Class Initialized
DEBUG - 2020-10-21 03:48:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-21 03:48:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:48:09 --> Final output sent to browser
DEBUG - 2020-10-21 03:48:09 --> Total execution time: 0.3602
INFO - 2020-10-21 03:48:09 --> Config Class Initialized
INFO - 2020-10-21 03:48:09 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:48:09 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:48:09 --> Utf8 Class Initialized
INFO - 2020-10-21 03:48:09 --> URI Class Initialized
INFO - 2020-10-21 03:48:09 --> Router Class Initialized
INFO - 2020-10-21 03:48:09 --> Output Class Initialized
INFO - 2020-10-21 03:48:09 --> Security Class Initialized
DEBUG - 2020-10-21 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:48:09 --> Input Class Initialized
INFO - 2020-10-21 03:48:09 --> Language Class Initialized
INFO - 2020-10-21 03:48:09 --> Language Class Initialized
INFO - 2020-10-21 03:48:09 --> Config Class Initialized
INFO - 2020-10-21 03:48:09 --> Loader Class Initialized
INFO - 2020-10-21 03:48:09 --> Helper loaded: url_helper
INFO - 2020-10-21 03:48:09 --> Helper loaded: file_helper
INFO - 2020-10-21 03:48:09 --> Helper loaded: form_helper
INFO - 2020-10-21 03:48:09 --> Helper loaded: my_helper
INFO - 2020-10-21 03:48:09 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:48:09 --> Controller Class Initialized
INFO - 2020-10-21 03:48:11 --> Config Class Initialized
INFO - 2020-10-21 03:48:11 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:48:11 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:48:11 --> Utf8 Class Initialized
INFO - 2020-10-21 03:48:11 --> URI Class Initialized
INFO - 2020-10-21 03:48:11 --> Router Class Initialized
INFO - 2020-10-21 03:48:11 --> Output Class Initialized
INFO - 2020-10-21 03:48:11 --> Security Class Initialized
DEBUG - 2020-10-21 03:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:48:11 --> Input Class Initialized
INFO - 2020-10-21 03:48:11 --> Language Class Initialized
INFO - 2020-10-21 03:48:11 --> Language Class Initialized
INFO - 2020-10-21 03:48:11 --> Config Class Initialized
INFO - 2020-10-21 03:48:11 --> Loader Class Initialized
INFO - 2020-10-21 03:48:11 --> Helper loaded: url_helper
INFO - 2020-10-21 03:48:11 --> Helper loaded: file_helper
INFO - 2020-10-21 03:48:11 --> Helper loaded: form_helper
INFO - 2020-10-21 03:48:11 --> Helper loaded: my_helper
INFO - 2020-10-21 03:48:11 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:48:11 --> Controller Class Initialized
ERROR - 2020-10-21 03:48:11 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-21 03:48:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-21 03:48:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:48:11 --> Final output sent to browser
DEBUG - 2020-10-21 03:48:11 --> Total execution time: 0.3641
INFO - 2020-10-21 03:49:16 --> Config Class Initialized
INFO - 2020-10-21 03:49:16 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:49:16 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:49:16 --> Utf8 Class Initialized
INFO - 2020-10-21 03:49:16 --> URI Class Initialized
INFO - 2020-10-21 03:49:16 --> Router Class Initialized
INFO - 2020-10-21 03:49:16 --> Output Class Initialized
INFO - 2020-10-21 03:49:16 --> Security Class Initialized
DEBUG - 2020-10-21 03:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:49:16 --> Input Class Initialized
INFO - 2020-10-21 03:49:16 --> Language Class Initialized
INFO - 2020-10-21 03:49:16 --> Language Class Initialized
INFO - 2020-10-21 03:49:16 --> Config Class Initialized
INFO - 2020-10-21 03:49:16 --> Loader Class Initialized
INFO - 2020-10-21 03:49:16 --> Helper loaded: url_helper
INFO - 2020-10-21 03:49:16 --> Helper loaded: file_helper
INFO - 2020-10-21 03:49:16 --> Helper loaded: form_helper
INFO - 2020-10-21 03:49:16 --> Helper loaded: my_helper
INFO - 2020-10-21 03:49:16 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:49:16 --> Controller Class Initialized
DEBUG - 2020-10-21 03:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-21 03:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:49:16 --> Final output sent to browser
DEBUG - 2020-10-21 03:49:16 --> Total execution time: 0.3942
INFO - 2020-10-21 03:49:16 --> Config Class Initialized
INFO - 2020-10-21 03:49:16 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:49:16 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:49:16 --> Utf8 Class Initialized
INFO - 2020-10-21 03:49:16 --> URI Class Initialized
INFO - 2020-10-21 03:49:16 --> Router Class Initialized
INFO - 2020-10-21 03:49:16 --> Output Class Initialized
INFO - 2020-10-21 03:49:16 --> Security Class Initialized
DEBUG - 2020-10-21 03:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:49:16 --> Input Class Initialized
INFO - 2020-10-21 03:49:16 --> Language Class Initialized
INFO - 2020-10-21 03:49:16 --> Language Class Initialized
INFO - 2020-10-21 03:49:16 --> Config Class Initialized
INFO - 2020-10-21 03:49:16 --> Loader Class Initialized
INFO - 2020-10-21 03:49:16 --> Helper loaded: url_helper
INFO - 2020-10-21 03:49:16 --> Helper loaded: file_helper
INFO - 2020-10-21 03:49:16 --> Helper loaded: form_helper
INFO - 2020-10-21 03:49:16 --> Helper loaded: my_helper
INFO - 2020-10-21 03:49:16 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:49:16 --> Controller Class Initialized
INFO - 2020-10-21 03:52:00 --> Config Class Initialized
INFO - 2020-10-21 03:52:00 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:52:00 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:52:00 --> Utf8 Class Initialized
INFO - 2020-10-21 03:52:00 --> URI Class Initialized
INFO - 2020-10-21 03:52:00 --> Router Class Initialized
INFO - 2020-10-21 03:52:00 --> Output Class Initialized
INFO - 2020-10-21 03:52:00 --> Security Class Initialized
DEBUG - 2020-10-21 03:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:52:00 --> Input Class Initialized
INFO - 2020-10-21 03:52:00 --> Language Class Initialized
INFO - 2020-10-21 03:52:00 --> Language Class Initialized
INFO - 2020-10-21 03:52:00 --> Config Class Initialized
INFO - 2020-10-21 03:52:00 --> Loader Class Initialized
INFO - 2020-10-21 03:52:00 --> Helper loaded: url_helper
INFO - 2020-10-21 03:52:00 --> Helper loaded: file_helper
INFO - 2020-10-21 03:52:00 --> Helper loaded: form_helper
INFO - 2020-10-21 03:52:00 --> Helper loaded: my_helper
INFO - 2020-10-21 03:52:00 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:52:00 --> Controller Class Initialized
DEBUG - 2020-10-21 03:52:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-21 03:52:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-21 03:52:00 --> Final output sent to browser
DEBUG - 2020-10-21 03:52:00 --> Total execution time: 0.3091
INFO - 2020-10-21 03:52:00 --> Config Class Initialized
INFO - 2020-10-21 03:52:00 --> Hooks Class Initialized
DEBUG - 2020-10-21 03:52:00 --> UTF-8 Support Enabled
INFO - 2020-10-21 03:52:00 --> Utf8 Class Initialized
INFO - 2020-10-21 03:52:00 --> URI Class Initialized
INFO - 2020-10-21 03:52:00 --> Router Class Initialized
INFO - 2020-10-21 03:52:00 --> Output Class Initialized
INFO - 2020-10-21 03:52:01 --> Security Class Initialized
DEBUG - 2020-10-21 03:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 03:52:01 --> Input Class Initialized
INFO - 2020-10-21 03:52:01 --> Language Class Initialized
INFO - 2020-10-21 03:52:01 --> Language Class Initialized
INFO - 2020-10-21 03:52:01 --> Config Class Initialized
INFO - 2020-10-21 03:52:01 --> Loader Class Initialized
INFO - 2020-10-21 03:52:01 --> Helper loaded: url_helper
INFO - 2020-10-21 03:52:01 --> Helper loaded: file_helper
INFO - 2020-10-21 03:52:01 --> Helper loaded: form_helper
INFO - 2020-10-21 03:52:01 --> Helper loaded: my_helper
INFO - 2020-10-21 03:52:01 --> Database Driver Class Initialized
DEBUG - 2020-10-21 03:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-21 03:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 03:52:01 --> Controller Class Initialized
