<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-10 01:52:42 --> Config Class Initialized
INFO - 2021-12-10 01:52:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:52:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:52:42 --> Utf8 Class Initialized
INFO - 2021-12-10 01:52:42 --> URI Class Initialized
DEBUG - 2021-12-10 01:52:42 --> No URI present. Default controller set.
INFO - 2021-12-10 01:52:42 --> Router Class Initialized
INFO - 2021-12-10 01:52:42 --> Output Class Initialized
INFO - 2021-12-10 01:52:42 --> Security Class Initialized
DEBUG - 2021-12-10 01:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:52:42 --> Input Class Initialized
INFO - 2021-12-10 01:52:42 --> Language Class Initialized
INFO - 2021-12-10 01:52:42 --> Language Class Initialized
INFO - 2021-12-10 01:52:42 --> Config Class Initialized
INFO - 2021-12-10 01:52:42 --> Loader Class Initialized
INFO - 2021-12-10 01:52:42 --> Helper loaded: url_helper
INFO - 2021-12-10 01:52:42 --> Helper loaded: file_helper
INFO - 2021-12-10 01:52:42 --> Helper loaded: form_helper
INFO - 2021-12-10 01:52:42 --> Helper loaded: my_helper
INFO - 2021-12-10 01:52:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:52:42 --> Controller Class Initialized
INFO - 2021-12-10 01:52:42 --> Config Class Initialized
INFO - 2021-12-10 01:52:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:52:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:52:42 --> Utf8 Class Initialized
INFO - 2021-12-10 01:52:42 --> URI Class Initialized
INFO - 2021-12-10 01:52:42 --> Router Class Initialized
INFO - 2021-12-10 01:52:42 --> Output Class Initialized
INFO - 2021-12-10 01:52:42 --> Security Class Initialized
DEBUG - 2021-12-10 01:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:52:42 --> Input Class Initialized
INFO - 2021-12-10 01:52:42 --> Language Class Initialized
INFO - 2021-12-10 01:52:42 --> Language Class Initialized
INFO - 2021-12-10 01:52:42 --> Config Class Initialized
INFO - 2021-12-10 01:52:42 --> Loader Class Initialized
INFO - 2021-12-10 01:52:42 --> Helper loaded: url_helper
INFO - 2021-12-10 01:52:42 --> Helper loaded: file_helper
INFO - 2021-12-10 01:52:42 --> Helper loaded: form_helper
INFO - 2021-12-10 01:52:42 --> Helper loaded: my_helper
INFO - 2021-12-10 01:52:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:52:42 --> Controller Class Initialized
DEBUG - 2021-12-10 01:52:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 01:52:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:52:42 --> Final output sent to browser
DEBUG - 2021-12-10 01:52:42 --> Total execution time: 0.0280
INFO - 2021-12-10 01:54:07 --> Config Class Initialized
INFO - 2021-12-10 01:54:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:07 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:07 --> URI Class Initialized
INFO - 2021-12-10 01:54:07 --> Router Class Initialized
INFO - 2021-12-10 01:54:07 --> Output Class Initialized
INFO - 2021-12-10 01:54:07 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:07 --> Input Class Initialized
INFO - 2021-12-10 01:54:07 --> Language Class Initialized
INFO - 2021-12-10 01:54:07 --> Language Class Initialized
INFO - 2021-12-10 01:54:07 --> Config Class Initialized
INFO - 2021-12-10 01:54:07 --> Loader Class Initialized
INFO - 2021-12-10 01:54:07 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:07 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:07 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:07 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:07 --> Controller Class Initialized
INFO - 2021-12-10 01:54:07 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:54:07 --> Final output sent to browser
DEBUG - 2021-12-10 01:54:07 --> Total execution time: 0.0530
INFO - 2021-12-10 01:54:07 --> Config Class Initialized
INFO - 2021-12-10 01:54:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:07 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:07 --> URI Class Initialized
INFO - 2021-12-10 01:54:07 --> Router Class Initialized
INFO - 2021-12-10 01:54:07 --> Output Class Initialized
INFO - 2021-12-10 01:54:07 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:07 --> Input Class Initialized
INFO - 2021-12-10 01:54:07 --> Language Class Initialized
INFO - 2021-12-10 01:54:07 --> Language Class Initialized
INFO - 2021-12-10 01:54:07 --> Config Class Initialized
INFO - 2021-12-10 01:54:07 --> Loader Class Initialized
INFO - 2021-12-10 01:54:07 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:07 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:07 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:07 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:07 --> Controller Class Initialized
DEBUG - 2021-12-10 01:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 01:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:54:07 --> Final output sent to browser
DEBUG - 2021-12-10 01:54:07 --> Total execution time: 0.2640
INFO - 2021-12-10 01:54:12 --> Config Class Initialized
INFO - 2021-12-10 01:54:12 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:12 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:12 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:12 --> URI Class Initialized
INFO - 2021-12-10 01:54:12 --> Router Class Initialized
INFO - 2021-12-10 01:54:12 --> Output Class Initialized
INFO - 2021-12-10 01:54:12 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:12 --> Input Class Initialized
INFO - 2021-12-10 01:54:12 --> Language Class Initialized
INFO - 2021-12-10 01:54:12 --> Language Class Initialized
INFO - 2021-12-10 01:54:12 --> Config Class Initialized
INFO - 2021-12-10 01:54:12 --> Loader Class Initialized
INFO - 2021-12-10 01:54:12 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:12 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:12 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:12 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:12 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:12 --> Controller Class Initialized
DEBUG - 2021-12-10 01:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 01:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:54:12 --> Final output sent to browser
DEBUG - 2021-12-10 01:54:12 --> Total execution time: 0.0440
INFO - 2021-12-10 01:54:12 --> Config Class Initialized
INFO - 2021-12-10 01:54:12 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:12 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:12 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:12 --> URI Class Initialized
INFO - 2021-12-10 01:54:12 --> Router Class Initialized
INFO - 2021-12-10 01:54:12 --> Output Class Initialized
INFO - 2021-12-10 01:54:12 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:12 --> Input Class Initialized
INFO - 2021-12-10 01:54:12 --> Language Class Initialized
INFO - 2021-12-10 01:54:12 --> Language Class Initialized
INFO - 2021-12-10 01:54:12 --> Config Class Initialized
INFO - 2021-12-10 01:54:12 --> Loader Class Initialized
INFO - 2021-12-10 01:54:12 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:12 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:12 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:12 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:12 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:12 --> Controller Class Initialized
INFO - 2021-12-10 01:54:16 --> Config Class Initialized
INFO - 2021-12-10 01:54:16 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:16 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:16 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:16 --> URI Class Initialized
INFO - 2021-12-10 01:54:16 --> Router Class Initialized
INFO - 2021-12-10 01:54:16 --> Output Class Initialized
INFO - 2021-12-10 01:54:16 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:16 --> Input Class Initialized
INFO - 2021-12-10 01:54:16 --> Language Class Initialized
INFO - 2021-12-10 01:54:16 --> Language Class Initialized
INFO - 2021-12-10 01:54:16 --> Config Class Initialized
INFO - 2021-12-10 01:54:16 --> Loader Class Initialized
INFO - 2021-12-10 01:54:16 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:16 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:16 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:16 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:16 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:16 --> Controller Class Initialized
INFO - 2021-12-10 01:54:16 --> Final output sent to browser
DEBUG - 2021-12-10 01:54:16 --> Total execution time: 0.0500
INFO - 2021-12-10 01:54:16 --> Config Class Initialized
INFO - 2021-12-10 01:54:16 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:16 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:16 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:16 --> URI Class Initialized
INFO - 2021-12-10 01:54:16 --> Router Class Initialized
INFO - 2021-12-10 01:54:16 --> Output Class Initialized
INFO - 2021-12-10 01:54:16 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:16 --> Input Class Initialized
INFO - 2021-12-10 01:54:16 --> Language Class Initialized
INFO - 2021-12-10 01:54:16 --> Language Class Initialized
INFO - 2021-12-10 01:54:16 --> Config Class Initialized
INFO - 2021-12-10 01:54:16 --> Loader Class Initialized
INFO - 2021-12-10 01:54:16 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:16 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:16 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:16 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:16 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:16 --> Controller Class Initialized
INFO - 2021-12-10 01:54:19 --> Config Class Initialized
INFO - 2021-12-10 01:54:19 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:19 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:19 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:19 --> URI Class Initialized
INFO - 2021-12-10 01:54:19 --> Router Class Initialized
INFO - 2021-12-10 01:54:19 --> Output Class Initialized
INFO - 2021-12-10 01:54:19 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:19 --> Input Class Initialized
INFO - 2021-12-10 01:54:19 --> Language Class Initialized
INFO - 2021-12-10 01:54:19 --> Language Class Initialized
INFO - 2021-12-10 01:54:19 --> Config Class Initialized
INFO - 2021-12-10 01:54:19 --> Loader Class Initialized
INFO - 2021-12-10 01:54:19 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:19 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:19 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:19 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:19 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:19 --> Controller Class Initialized
INFO - 2021-12-10 01:54:19 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:54:19 --> Config Class Initialized
INFO - 2021-12-10 01:54:19 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:19 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:19 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:19 --> URI Class Initialized
INFO - 2021-12-10 01:54:19 --> Router Class Initialized
INFO - 2021-12-10 01:54:19 --> Output Class Initialized
INFO - 2021-12-10 01:54:19 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:19 --> Input Class Initialized
INFO - 2021-12-10 01:54:19 --> Language Class Initialized
INFO - 2021-12-10 01:54:19 --> Language Class Initialized
INFO - 2021-12-10 01:54:19 --> Config Class Initialized
INFO - 2021-12-10 01:54:19 --> Loader Class Initialized
INFO - 2021-12-10 01:54:19 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:19 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:19 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:19 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:19 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:19 --> Controller Class Initialized
DEBUG - 2021-12-10 01:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 01:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:54:19 --> Final output sent to browser
DEBUG - 2021-12-10 01:54:19 --> Total execution time: 0.0430
INFO - 2021-12-10 01:54:46 --> Config Class Initialized
INFO - 2021-12-10 01:54:46 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:46 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:46 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:46 --> URI Class Initialized
INFO - 2021-12-10 01:54:46 --> Router Class Initialized
INFO - 2021-12-10 01:54:46 --> Output Class Initialized
INFO - 2021-12-10 01:54:46 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:46 --> Input Class Initialized
INFO - 2021-12-10 01:54:46 --> Language Class Initialized
INFO - 2021-12-10 01:54:46 --> Language Class Initialized
INFO - 2021-12-10 01:54:46 --> Config Class Initialized
INFO - 2021-12-10 01:54:46 --> Loader Class Initialized
INFO - 2021-12-10 01:54:46 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:46 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:46 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:46 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:46 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:46 --> Controller Class Initialized
INFO - 2021-12-10 01:54:46 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:54:46 --> Final output sent to browser
DEBUG - 2021-12-10 01:54:46 --> Total execution time: 0.0460
INFO - 2021-12-10 01:54:47 --> Config Class Initialized
INFO - 2021-12-10 01:54:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:54:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:54:47 --> Utf8 Class Initialized
INFO - 2021-12-10 01:54:47 --> URI Class Initialized
INFO - 2021-12-10 01:54:47 --> Router Class Initialized
INFO - 2021-12-10 01:54:47 --> Output Class Initialized
INFO - 2021-12-10 01:54:47 --> Security Class Initialized
DEBUG - 2021-12-10 01:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:54:48 --> Input Class Initialized
INFO - 2021-12-10 01:54:48 --> Language Class Initialized
INFO - 2021-12-10 01:54:48 --> Language Class Initialized
INFO - 2021-12-10 01:54:48 --> Config Class Initialized
INFO - 2021-12-10 01:54:48 --> Loader Class Initialized
INFO - 2021-12-10 01:54:48 --> Helper loaded: url_helper
INFO - 2021-12-10 01:54:48 --> Helper loaded: file_helper
INFO - 2021-12-10 01:54:48 --> Helper loaded: form_helper
INFO - 2021-12-10 01:54:48 --> Helper loaded: my_helper
INFO - 2021-12-10 01:54:48 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:54:48 --> Controller Class Initialized
DEBUG - 2021-12-10 01:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 01:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:54:48 --> Final output sent to browser
DEBUG - 2021-12-10 01:54:48 --> Total execution time: 0.1580
INFO - 2021-12-10 01:56:06 --> Config Class Initialized
INFO - 2021-12-10 01:56:06 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:56:06 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:56:06 --> Utf8 Class Initialized
INFO - 2021-12-10 01:56:06 --> URI Class Initialized
INFO - 2021-12-10 01:56:07 --> Router Class Initialized
INFO - 2021-12-10 01:56:07 --> Output Class Initialized
INFO - 2021-12-10 01:56:07 --> Security Class Initialized
DEBUG - 2021-12-10 01:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:56:07 --> Input Class Initialized
INFO - 2021-12-10 01:56:07 --> Language Class Initialized
INFO - 2021-12-10 01:56:07 --> Language Class Initialized
INFO - 2021-12-10 01:56:07 --> Config Class Initialized
INFO - 2021-12-10 01:56:07 --> Loader Class Initialized
INFO - 2021-12-10 01:56:07 --> Helper loaded: url_helper
INFO - 2021-12-10 01:56:07 --> Helper loaded: file_helper
INFO - 2021-12-10 01:56:07 --> Helper loaded: form_helper
INFO - 2021-12-10 01:56:07 --> Helper loaded: my_helper
INFO - 2021-12-10 01:56:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:56:07 --> Controller Class Initialized
DEBUG - 2021-12-10 01:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 01:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:56:07 --> Final output sent to browser
DEBUG - 2021-12-10 01:56:07 --> Total execution time: 0.0400
INFO - 2021-12-10 01:56:07 --> Config Class Initialized
INFO - 2021-12-10 01:56:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:56:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:56:07 --> Utf8 Class Initialized
INFO - 2021-12-10 01:56:07 --> URI Class Initialized
INFO - 2021-12-10 01:56:07 --> Router Class Initialized
INFO - 2021-12-10 01:56:07 --> Output Class Initialized
INFO - 2021-12-10 01:56:07 --> Security Class Initialized
DEBUG - 2021-12-10 01:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:56:07 --> Input Class Initialized
INFO - 2021-12-10 01:56:07 --> Language Class Initialized
INFO - 2021-12-10 01:56:07 --> Language Class Initialized
INFO - 2021-12-10 01:56:07 --> Config Class Initialized
INFO - 2021-12-10 01:56:07 --> Loader Class Initialized
INFO - 2021-12-10 01:56:07 --> Helper loaded: url_helper
INFO - 2021-12-10 01:56:07 --> Helper loaded: file_helper
INFO - 2021-12-10 01:56:07 --> Helper loaded: form_helper
INFO - 2021-12-10 01:56:07 --> Helper loaded: my_helper
INFO - 2021-12-10 01:56:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:56:07 --> Controller Class Initialized
INFO - 2021-12-10 01:56:13 --> Config Class Initialized
INFO - 2021-12-10 01:56:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:56:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:56:13 --> Utf8 Class Initialized
INFO - 2021-12-10 01:56:13 --> URI Class Initialized
INFO - 2021-12-10 01:56:13 --> Router Class Initialized
INFO - 2021-12-10 01:56:13 --> Output Class Initialized
INFO - 2021-12-10 01:56:13 --> Security Class Initialized
DEBUG - 2021-12-10 01:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:56:13 --> Input Class Initialized
INFO - 2021-12-10 01:56:13 --> Language Class Initialized
INFO - 2021-12-10 01:56:13 --> Language Class Initialized
INFO - 2021-12-10 01:56:13 --> Config Class Initialized
INFO - 2021-12-10 01:56:13 --> Loader Class Initialized
INFO - 2021-12-10 01:56:13 --> Helper loaded: url_helper
INFO - 2021-12-10 01:56:13 --> Helper loaded: file_helper
INFO - 2021-12-10 01:56:13 --> Helper loaded: form_helper
INFO - 2021-12-10 01:56:13 --> Helper loaded: my_helper
INFO - 2021-12-10 01:56:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:56:13 --> Controller Class Initialized
DEBUG - 2021-12-10 01:56:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-12-10 01:56:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:56:13 --> Final output sent to browser
DEBUG - 2021-12-10 01:56:13 --> Total execution time: 0.0290
INFO - 2021-12-10 01:56:13 --> Config Class Initialized
INFO - 2021-12-10 01:56:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:56:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:56:13 --> Utf8 Class Initialized
INFO - 2021-12-10 01:56:13 --> URI Class Initialized
INFO - 2021-12-10 01:56:13 --> Router Class Initialized
INFO - 2021-12-10 01:56:13 --> Output Class Initialized
INFO - 2021-12-10 01:56:13 --> Security Class Initialized
DEBUG - 2021-12-10 01:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:56:13 --> Input Class Initialized
INFO - 2021-12-10 01:56:13 --> Language Class Initialized
INFO - 2021-12-10 01:56:13 --> Language Class Initialized
INFO - 2021-12-10 01:56:13 --> Config Class Initialized
INFO - 2021-12-10 01:56:13 --> Loader Class Initialized
INFO - 2021-12-10 01:56:13 --> Helper loaded: url_helper
INFO - 2021-12-10 01:56:13 --> Helper loaded: file_helper
INFO - 2021-12-10 01:56:13 --> Helper loaded: form_helper
INFO - 2021-12-10 01:56:13 --> Helper loaded: my_helper
INFO - 2021-12-10 01:56:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:56:13 --> Controller Class Initialized
INFO - 2021-12-10 01:56:52 --> Config Class Initialized
INFO - 2021-12-10 01:56:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:56:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:56:52 --> Utf8 Class Initialized
INFO - 2021-12-10 01:56:52 --> URI Class Initialized
INFO - 2021-12-10 01:56:52 --> Router Class Initialized
INFO - 2021-12-10 01:56:52 --> Output Class Initialized
INFO - 2021-12-10 01:56:52 --> Security Class Initialized
DEBUG - 2021-12-10 01:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:56:52 --> Input Class Initialized
INFO - 2021-12-10 01:56:52 --> Language Class Initialized
INFO - 2021-12-10 01:56:52 --> Language Class Initialized
INFO - 2021-12-10 01:56:52 --> Config Class Initialized
INFO - 2021-12-10 01:56:52 --> Loader Class Initialized
INFO - 2021-12-10 01:56:52 --> Helper loaded: url_helper
INFO - 2021-12-10 01:56:52 --> Helper loaded: file_helper
INFO - 2021-12-10 01:56:52 --> Helper loaded: form_helper
INFO - 2021-12-10 01:56:52 --> Helper loaded: my_helper
INFO - 2021-12-10 01:56:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:56:52 --> Controller Class Initialized
DEBUG - 2021-12-10 01:56:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 01:56:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:56:52 --> Final output sent to browser
DEBUG - 2021-12-10 01:56:52 --> Total execution time: 0.0350
INFO - 2021-12-10 01:56:52 --> Config Class Initialized
INFO - 2021-12-10 01:56:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:56:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:56:52 --> Utf8 Class Initialized
INFO - 2021-12-10 01:56:52 --> URI Class Initialized
INFO - 2021-12-10 01:56:52 --> Router Class Initialized
INFO - 2021-12-10 01:56:52 --> Output Class Initialized
INFO - 2021-12-10 01:56:52 --> Security Class Initialized
DEBUG - 2021-12-10 01:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:56:52 --> Input Class Initialized
INFO - 2021-12-10 01:56:52 --> Language Class Initialized
INFO - 2021-12-10 01:56:52 --> Language Class Initialized
INFO - 2021-12-10 01:56:52 --> Config Class Initialized
INFO - 2021-12-10 01:56:52 --> Loader Class Initialized
INFO - 2021-12-10 01:56:52 --> Helper loaded: url_helper
INFO - 2021-12-10 01:56:52 --> Helper loaded: file_helper
INFO - 2021-12-10 01:56:52 --> Helper loaded: form_helper
INFO - 2021-12-10 01:56:52 --> Helper loaded: my_helper
INFO - 2021-12-10 01:56:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:56:52 --> Controller Class Initialized
INFO - 2021-12-10 01:57:02 --> Config Class Initialized
INFO - 2021-12-10 01:57:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:02 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:02 --> URI Class Initialized
INFO - 2021-12-10 01:57:02 --> Router Class Initialized
INFO - 2021-12-10 01:57:02 --> Output Class Initialized
INFO - 2021-12-10 01:57:02 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:02 --> Input Class Initialized
INFO - 2021-12-10 01:57:02 --> Language Class Initialized
INFO - 2021-12-10 01:57:02 --> Language Class Initialized
INFO - 2021-12-10 01:57:02 --> Config Class Initialized
INFO - 2021-12-10 01:57:02 --> Loader Class Initialized
INFO - 2021-12-10 01:57:02 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:02 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:02 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:02 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:02 --> Controller Class Initialized
INFO - 2021-12-10 01:57:02 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:57:02 --> Config Class Initialized
INFO - 2021-12-10 01:57:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:02 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:02 --> URI Class Initialized
INFO - 2021-12-10 01:57:02 --> Router Class Initialized
INFO - 2021-12-10 01:57:02 --> Output Class Initialized
INFO - 2021-12-10 01:57:02 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:02 --> Input Class Initialized
INFO - 2021-12-10 01:57:02 --> Language Class Initialized
INFO - 2021-12-10 01:57:02 --> Language Class Initialized
INFO - 2021-12-10 01:57:02 --> Config Class Initialized
INFO - 2021-12-10 01:57:02 --> Loader Class Initialized
INFO - 2021-12-10 01:57:02 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:02 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:02 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:02 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:02 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 01:57:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:02 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:02 --> Total execution time: 0.0380
INFO - 2021-12-10 01:57:15 --> Config Class Initialized
INFO - 2021-12-10 01:57:15 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:15 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:15 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:15 --> URI Class Initialized
INFO - 2021-12-10 01:57:15 --> Router Class Initialized
INFO - 2021-12-10 01:57:15 --> Output Class Initialized
INFO - 2021-12-10 01:57:15 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:15 --> Input Class Initialized
INFO - 2021-12-10 01:57:15 --> Language Class Initialized
INFO - 2021-12-10 01:57:15 --> Language Class Initialized
INFO - 2021-12-10 01:57:15 --> Config Class Initialized
INFO - 2021-12-10 01:57:15 --> Loader Class Initialized
INFO - 2021-12-10 01:57:15 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:15 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:15 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:15 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:15 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:15 --> Controller Class Initialized
INFO - 2021-12-10 01:57:15 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:57:15 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:15 --> Total execution time: 0.0540
INFO - 2021-12-10 01:57:15 --> Config Class Initialized
INFO - 2021-12-10 01:57:15 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:15 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:15 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:15 --> URI Class Initialized
INFO - 2021-12-10 01:57:15 --> Router Class Initialized
INFO - 2021-12-10 01:57:15 --> Output Class Initialized
INFO - 2021-12-10 01:57:15 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:15 --> Input Class Initialized
INFO - 2021-12-10 01:57:15 --> Language Class Initialized
INFO - 2021-12-10 01:57:15 --> Language Class Initialized
INFO - 2021-12-10 01:57:15 --> Config Class Initialized
INFO - 2021-12-10 01:57:15 --> Loader Class Initialized
INFO - 2021-12-10 01:57:15 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:15 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:15 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:15 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:15 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:15 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 01:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:15 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:15 --> Total execution time: 0.1570
INFO - 2021-12-10 01:57:18 --> Config Class Initialized
INFO - 2021-12-10 01:57:18 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:18 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:18 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:18 --> URI Class Initialized
INFO - 2021-12-10 01:57:18 --> Router Class Initialized
INFO - 2021-12-10 01:57:18 --> Output Class Initialized
INFO - 2021-12-10 01:57:18 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:18 --> Input Class Initialized
INFO - 2021-12-10 01:57:18 --> Language Class Initialized
INFO - 2021-12-10 01:57:18 --> Language Class Initialized
INFO - 2021-12-10 01:57:18 --> Config Class Initialized
INFO - 2021-12-10 01:57:18 --> Loader Class Initialized
INFO - 2021-12-10 01:57:18 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:18 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:18 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:18 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:18 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:18 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 01:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:18 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:18 --> Total execution time: 0.0610
INFO - 2021-12-10 01:57:20 --> Config Class Initialized
INFO - 2021-12-10 01:57:20 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:20 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:20 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:20 --> URI Class Initialized
INFO - 2021-12-10 01:57:20 --> Router Class Initialized
INFO - 2021-12-10 01:57:20 --> Output Class Initialized
INFO - 2021-12-10 01:57:20 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:20 --> Input Class Initialized
INFO - 2021-12-10 01:57:20 --> Language Class Initialized
INFO - 2021-12-10 01:57:20 --> Language Class Initialized
INFO - 2021-12-10 01:57:20 --> Config Class Initialized
INFO - 2021-12-10 01:57:20 --> Loader Class Initialized
INFO - 2021-12-10 01:57:20 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:20 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:20 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:20 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:20 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:20 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-10 01:57:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:20 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:20 --> Total execution time: 0.0770
INFO - 2021-12-10 01:57:25 --> Config Class Initialized
INFO - 2021-12-10 01:57:25 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:25 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:25 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:25 --> URI Class Initialized
INFO - 2021-12-10 01:57:25 --> Router Class Initialized
INFO - 2021-12-10 01:57:25 --> Output Class Initialized
INFO - 2021-12-10 01:57:25 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:25 --> Input Class Initialized
INFO - 2021-12-10 01:57:25 --> Language Class Initialized
INFO - 2021-12-10 01:57:26 --> Language Class Initialized
INFO - 2021-12-10 01:57:26 --> Config Class Initialized
INFO - 2021-12-10 01:57:26 --> Loader Class Initialized
INFO - 2021-12-10 01:57:26 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:26 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:26 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:26 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:26 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:26 --> Controller Class Initialized
INFO - 2021-12-10 01:57:26 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:57:26 --> Config Class Initialized
INFO - 2021-12-10 01:57:26 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:26 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:26 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:26 --> URI Class Initialized
INFO - 2021-12-10 01:57:26 --> Router Class Initialized
INFO - 2021-12-10 01:57:26 --> Output Class Initialized
INFO - 2021-12-10 01:57:26 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:26 --> Input Class Initialized
INFO - 2021-12-10 01:57:26 --> Language Class Initialized
INFO - 2021-12-10 01:57:26 --> Language Class Initialized
INFO - 2021-12-10 01:57:26 --> Config Class Initialized
INFO - 2021-12-10 01:57:26 --> Loader Class Initialized
INFO - 2021-12-10 01:57:26 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:26 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:26 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:26 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:26 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:26 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 01:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:26 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:26 --> Total execution time: 0.0380
INFO - 2021-12-10 01:57:34 --> Config Class Initialized
INFO - 2021-12-10 01:57:34 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:34 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:34 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:34 --> URI Class Initialized
INFO - 2021-12-10 01:57:34 --> Router Class Initialized
INFO - 2021-12-10 01:57:34 --> Output Class Initialized
INFO - 2021-12-10 01:57:34 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:34 --> Input Class Initialized
INFO - 2021-12-10 01:57:34 --> Language Class Initialized
INFO - 2021-12-10 01:57:34 --> Language Class Initialized
INFO - 2021-12-10 01:57:34 --> Config Class Initialized
INFO - 2021-12-10 01:57:34 --> Loader Class Initialized
INFO - 2021-12-10 01:57:34 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:34 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:34 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:34 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:34 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:34 --> Controller Class Initialized
INFO - 2021-12-10 01:57:34 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:57:34 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:34 --> Total execution time: 0.0280
INFO - 2021-12-10 01:57:35 --> Config Class Initialized
INFO - 2021-12-10 01:57:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:35 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:35 --> URI Class Initialized
INFO - 2021-12-10 01:57:35 --> Router Class Initialized
INFO - 2021-12-10 01:57:35 --> Output Class Initialized
INFO - 2021-12-10 01:57:35 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:35 --> Input Class Initialized
INFO - 2021-12-10 01:57:35 --> Language Class Initialized
INFO - 2021-12-10 01:57:35 --> Language Class Initialized
INFO - 2021-12-10 01:57:35 --> Config Class Initialized
INFO - 2021-12-10 01:57:35 --> Loader Class Initialized
INFO - 2021-12-10 01:57:35 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:35 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:35 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:35 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:35 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 01:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:35 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:35 --> Total execution time: 0.1640
INFO - 2021-12-10 01:57:39 --> Config Class Initialized
INFO - 2021-12-10 01:57:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:39 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:39 --> URI Class Initialized
INFO - 2021-12-10 01:57:39 --> Router Class Initialized
INFO - 2021-12-10 01:57:39 --> Output Class Initialized
INFO - 2021-12-10 01:57:39 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:39 --> Input Class Initialized
INFO - 2021-12-10 01:57:39 --> Language Class Initialized
INFO - 2021-12-10 01:57:39 --> Language Class Initialized
INFO - 2021-12-10 01:57:39 --> Config Class Initialized
INFO - 2021-12-10 01:57:39 --> Loader Class Initialized
INFO - 2021-12-10 01:57:39 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:39 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:39 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:39 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:39 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 01:57:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:39 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:39 --> Total execution time: 0.0630
INFO - 2021-12-10 01:57:41 --> Config Class Initialized
INFO - 2021-12-10 01:57:41 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:41 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:41 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:41 --> URI Class Initialized
INFO - 2021-12-10 01:57:41 --> Router Class Initialized
INFO - 2021-12-10 01:57:41 --> Output Class Initialized
INFO - 2021-12-10 01:57:41 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:41 --> Input Class Initialized
INFO - 2021-12-10 01:57:41 --> Language Class Initialized
INFO - 2021-12-10 01:57:41 --> Language Class Initialized
INFO - 2021-12-10 01:57:41 --> Config Class Initialized
INFO - 2021-12-10 01:57:41 --> Loader Class Initialized
INFO - 2021-12-10 01:57:41 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:41 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:41 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:41 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:41 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:41 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 01:57:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:41 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:41 --> Total execution time: 0.0970
INFO - 2021-12-10 01:57:47 --> Config Class Initialized
INFO - 2021-12-10 01:57:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:57:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:57:47 --> Utf8 Class Initialized
INFO - 2021-12-10 01:57:47 --> URI Class Initialized
INFO - 2021-12-10 01:57:47 --> Router Class Initialized
INFO - 2021-12-10 01:57:47 --> Output Class Initialized
INFO - 2021-12-10 01:57:47 --> Security Class Initialized
DEBUG - 2021-12-10 01:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:57:47 --> Input Class Initialized
INFO - 2021-12-10 01:57:47 --> Language Class Initialized
INFO - 2021-12-10 01:57:47 --> Language Class Initialized
INFO - 2021-12-10 01:57:47 --> Config Class Initialized
INFO - 2021-12-10 01:57:47 --> Loader Class Initialized
INFO - 2021-12-10 01:57:47 --> Helper loaded: url_helper
INFO - 2021-12-10 01:57:47 --> Helper loaded: file_helper
INFO - 2021-12-10 01:57:47 --> Helper loaded: form_helper
INFO - 2021-12-10 01:57:47 --> Helper loaded: my_helper
INFO - 2021-12-10 01:57:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:57:47 --> Controller Class Initialized
DEBUG - 2021-12-10 01:57:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 01:57:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:57:47 --> Final output sent to browser
DEBUG - 2021-12-10 01:57:47 --> Total execution time: 0.0430
INFO - 2021-12-10 01:59:25 --> Config Class Initialized
INFO - 2021-12-10 01:59:25 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:25 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:25 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:25 --> URI Class Initialized
INFO - 2021-12-10 01:59:25 --> Router Class Initialized
INFO - 2021-12-10 01:59:25 --> Output Class Initialized
INFO - 2021-12-10 01:59:25 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:25 --> Input Class Initialized
INFO - 2021-12-10 01:59:25 --> Language Class Initialized
INFO - 2021-12-10 01:59:25 --> Language Class Initialized
INFO - 2021-12-10 01:59:25 --> Config Class Initialized
INFO - 2021-12-10 01:59:25 --> Loader Class Initialized
INFO - 2021-12-10 01:59:25 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:25 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:25 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:25 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:25 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:25 --> Controller Class Initialized
DEBUG - 2021-12-10 01:59:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-10 01:59:25 --> Final output sent to browser
DEBUG - 2021-12-10 01:59:25 --> Total execution time: 0.0910
INFO - 2021-12-10 01:59:39 --> Config Class Initialized
INFO - 2021-12-10 01:59:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:39 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:39 --> URI Class Initialized
INFO - 2021-12-10 01:59:39 --> Router Class Initialized
INFO - 2021-12-10 01:59:39 --> Output Class Initialized
INFO - 2021-12-10 01:59:39 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:39 --> Input Class Initialized
INFO - 2021-12-10 01:59:39 --> Language Class Initialized
INFO - 2021-12-10 01:59:39 --> Language Class Initialized
INFO - 2021-12-10 01:59:39 --> Config Class Initialized
INFO - 2021-12-10 01:59:39 --> Loader Class Initialized
INFO - 2021-12-10 01:59:39 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:39 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:39 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:39 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:39 --> Controller Class Initialized
INFO - 2021-12-10 01:59:39 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:59:39 --> Config Class Initialized
INFO - 2021-12-10 01:59:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:39 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:39 --> URI Class Initialized
INFO - 2021-12-10 01:59:39 --> Router Class Initialized
INFO - 2021-12-10 01:59:39 --> Output Class Initialized
INFO - 2021-12-10 01:59:39 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:39 --> Input Class Initialized
INFO - 2021-12-10 01:59:39 --> Language Class Initialized
INFO - 2021-12-10 01:59:39 --> Language Class Initialized
INFO - 2021-12-10 01:59:39 --> Config Class Initialized
INFO - 2021-12-10 01:59:39 --> Loader Class Initialized
INFO - 2021-12-10 01:59:39 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:39 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:39 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:39 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:39 --> Controller Class Initialized
DEBUG - 2021-12-10 01:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 01:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:59:39 --> Final output sent to browser
DEBUG - 2021-12-10 01:59:39 --> Total execution time: 0.0350
INFO - 2021-12-10 01:59:47 --> Config Class Initialized
INFO - 2021-12-10 01:59:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:47 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:47 --> URI Class Initialized
INFO - 2021-12-10 01:59:47 --> Router Class Initialized
INFO - 2021-12-10 01:59:47 --> Output Class Initialized
INFO - 2021-12-10 01:59:47 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:47 --> Input Class Initialized
INFO - 2021-12-10 01:59:47 --> Language Class Initialized
INFO - 2021-12-10 01:59:47 --> Language Class Initialized
INFO - 2021-12-10 01:59:47 --> Config Class Initialized
INFO - 2021-12-10 01:59:47 --> Loader Class Initialized
INFO - 2021-12-10 01:59:47 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:47 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:47 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:47 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:47 --> Controller Class Initialized
INFO - 2021-12-10 01:59:47 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:59:47 --> Final output sent to browser
DEBUG - 2021-12-10 01:59:47 --> Total execution time: 0.0430
INFO - 2021-12-10 01:59:47 --> Config Class Initialized
INFO - 2021-12-10 01:59:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:47 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:47 --> URI Class Initialized
INFO - 2021-12-10 01:59:47 --> Router Class Initialized
INFO - 2021-12-10 01:59:47 --> Output Class Initialized
INFO - 2021-12-10 01:59:47 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:47 --> Input Class Initialized
INFO - 2021-12-10 01:59:47 --> Language Class Initialized
INFO - 2021-12-10 01:59:47 --> Language Class Initialized
INFO - 2021-12-10 01:59:47 --> Config Class Initialized
INFO - 2021-12-10 01:59:47 --> Loader Class Initialized
INFO - 2021-12-10 01:59:47 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:47 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:47 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:47 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:47 --> Controller Class Initialized
DEBUG - 2021-12-10 01:59:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 01:59:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:59:47 --> Final output sent to browser
DEBUG - 2021-12-10 01:59:47 --> Total execution time: 0.2040
INFO - 2021-12-10 01:59:50 --> Config Class Initialized
INFO - 2021-12-10 01:59:50 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:50 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:50 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:50 --> URI Class Initialized
INFO - 2021-12-10 01:59:50 --> Router Class Initialized
INFO - 2021-12-10 01:59:50 --> Output Class Initialized
INFO - 2021-12-10 01:59:50 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:50 --> Input Class Initialized
INFO - 2021-12-10 01:59:50 --> Language Class Initialized
INFO - 2021-12-10 01:59:50 --> Language Class Initialized
INFO - 2021-12-10 01:59:50 --> Config Class Initialized
INFO - 2021-12-10 01:59:50 --> Loader Class Initialized
INFO - 2021-12-10 01:59:50 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:50 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:50 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:50 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:50 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:50 --> Controller Class Initialized
DEBUG - 2021-12-10 01:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 01:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:59:50 --> Final output sent to browser
DEBUG - 2021-12-10 01:59:50 --> Total execution time: 0.0950
INFO - 2021-12-10 01:59:52 --> Config Class Initialized
INFO - 2021-12-10 01:59:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:52 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:52 --> URI Class Initialized
INFO - 2021-12-10 01:59:52 --> Router Class Initialized
INFO - 2021-12-10 01:59:52 --> Output Class Initialized
INFO - 2021-12-10 01:59:52 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:52 --> Input Class Initialized
INFO - 2021-12-10 01:59:52 --> Language Class Initialized
INFO - 2021-12-10 01:59:52 --> Language Class Initialized
INFO - 2021-12-10 01:59:52 --> Config Class Initialized
INFO - 2021-12-10 01:59:52 --> Loader Class Initialized
INFO - 2021-12-10 01:59:52 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:52 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:52 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:52 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:52 --> Controller Class Initialized
INFO - 2021-12-10 01:59:52 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:59:52 --> Config Class Initialized
INFO - 2021-12-10 01:59:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:52 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:52 --> URI Class Initialized
INFO - 2021-12-10 01:59:52 --> Router Class Initialized
INFO - 2021-12-10 01:59:52 --> Output Class Initialized
INFO - 2021-12-10 01:59:52 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:52 --> Input Class Initialized
INFO - 2021-12-10 01:59:52 --> Language Class Initialized
INFO - 2021-12-10 01:59:52 --> Language Class Initialized
INFO - 2021-12-10 01:59:52 --> Config Class Initialized
INFO - 2021-12-10 01:59:52 --> Loader Class Initialized
INFO - 2021-12-10 01:59:52 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:52 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:52 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:52 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:52 --> Controller Class Initialized
DEBUG - 2021-12-10 01:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 01:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:59:52 --> Final output sent to browser
DEBUG - 2021-12-10 01:59:52 --> Total execution time: 0.0380
INFO - 2021-12-10 01:59:57 --> Config Class Initialized
INFO - 2021-12-10 01:59:57 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:57 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:57 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:57 --> URI Class Initialized
INFO - 2021-12-10 01:59:57 --> Router Class Initialized
INFO - 2021-12-10 01:59:57 --> Output Class Initialized
INFO - 2021-12-10 01:59:57 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:57 --> Input Class Initialized
INFO - 2021-12-10 01:59:57 --> Language Class Initialized
INFO - 2021-12-10 01:59:57 --> Language Class Initialized
INFO - 2021-12-10 01:59:57 --> Config Class Initialized
INFO - 2021-12-10 01:59:57 --> Loader Class Initialized
INFO - 2021-12-10 01:59:57 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:57 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:57 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:57 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:57 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:57 --> Controller Class Initialized
INFO - 2021-12-10 01:59:57 --> Helper loaded: cookie_helper
INFO - 2021-12-10 01:59:57 --> Final output sent to browser
DEBUG - 2021-12-10 01:59:57 --> Total execution time: 0.0460
INFO - 2021-12-10 01:59:57 --> Config Class Initialized
INFO - 2021-12-10 01:59:57 --> Hooks Class Initialized
DEBUG - 2021-12-10 01:59:57 --> UTF-8 Support Enabled
INFO - 2021-12-10 01:59:57 --> Utf8 Class Initialized
INFO - 2021-12-10 01:59:57 --> URI Class Initialized
INFO - 2021-12-10 01:59:57 --> Router Class Initialized
INFO - 2021-12-10 01:59:57 --> Output Class Initialized
INFO - 2021-12-10 01:59:57 --> Security Class Initialized
DEBUG - 2021-12-10 01:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 01:59:57 --> Input Class Initialized
INFO - 2021-12-10 01:59:57 --> Language Class Initialized
INFO - 2021-12-10 01:59:57 --> Language Class Initialized
INFO - 2021-12-10 01:59:57 --> Config Class Initialized
INFO - 2021-12-10 01:59:57 --> Loader Class Initialized
INFO - 2021-12-10 01:59:57 --> Helper loaded: url_helper
INFO - 2021-12-10 01:59:57 --> Helper loaded: file_helper
INFO - 2021-12-10 01:59:57 --> Helper loaded: form_helper
INFO - 2021-12-10 01:59:57 --> Helper loaded: my_helper
INFO - 2021-12-10 01:59:57 --> Database Driver Class Initialized
DEBUG - 2021-12-10 01:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 01:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 01:59:57 --> Controller Class Initialized
DEBUG - 2021-12-10 01:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 01:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 01:59:57 --> Final output sent to browser
DEBUG - 2021-12-10 01:59:57 --> Total execution time: 0.1870
INFO - 2021-12-10 02:00:01 --> Config Class Initialized
INFO - 2021-12-10 02:00:01 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:01 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:01 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:01 --> URI Class Initialized
INFO - 2021-12-10 02:00:01 --> Router Class Initialized
INFO - 2021-12-10 02:00:01 --> Output Class Initialized
INFO - 2021-12-10 02:00:01 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:01 --> Input Class Initialized
INFO - 2021-12-10 02:00:01 --> Language Class Initialized
INFO - 2021-12-10 02:00:01 --> Language Class Initialized
INFO - 2021-12-10 02:00:01 --> Config Class Initialized
INFO - 2021-12-10 02:00:01 --> Loader Class Initialized
INFO - 2021-12-10 02:00:01 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:01 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:01 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:01 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:01 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:01 --> Controller Class Initialized
DEBUG - 2021-12-10 02:00:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 02:00:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:00:01 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:01 --> Total execution time: 0.0740
INFO - 2021-12-10 02:00:08 --> Config Class Initialized
INFO - 2021-12-10 02:00:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:08 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:08 --> URI Class Initialized
INFO - 2021-12-10 02:00:08 --> Router Class Initialized
INFO - 2021-12-10 02:00:08 --> Output Class Initialized
INFO - 2021-12-10 02:00:08 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:08 --> Input Class Initialized
INFO - 2021-12-10 02:00:08 --> Language Class Initialized
INFO - 2021-12-10 02:00:08 --> Language Class Initialized
INFO - 2021-12-10 02:00:08 --> Config Class Initialized
INFO - 2021-12-10 02:00:08 --> Loader Class Initialized
INFO - 2021-12-10 02:00:08 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:08 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:08 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:08 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:08 --> Controller Class Initialized
DEBUG - 2021-12-10 02:00:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 02:00:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:00:08 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:08 --> Total execution time: 0.0580
INFO - 2021-12-10 02:00:11 --> Config Class Initialized
INFO - 2021-12-10 02:00:11 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:11 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:11 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:11 --> URI Class Initialized
INFO - 2021-12-10 02:00:11 --> Router Class Initialized
INFO - 2021-12-10 02:00:11 --> Output Class Initialized
INFO - 2021-12-10 02:00:11 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:11 --> Input Class Initialized
INFO - 2021-12-10 02:00:11 --> Language Class Initialized
INFO - 2021-12-10 02:00:11 --> Language Class Initialized
INFO - 2021-12-10 02:00:11 --> Config Class Initialized
INFO - 2021-12-10 02:00:11 --> Loader Class Initialized
INFO - 2021-12-10 02:00:11 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:11 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:11 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:11 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:11 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:11 --> Controller Class Initialized
DEBUG - 2021-12-10 02:00:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-10 02:00:11 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:11 --> Total execution time: 0.0870
INFO - 2021-12-10 02:00:23 --> Config Class Initialized
INFO - 2021-12-10 02:00:23 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:23 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:23 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:23 --> URI Class Initialized
INFO - 2021-12-10 02:00:23 --> Router Class Initialized
INFO - 2021-12-10 02:00:23 --> Output Class Initialized
INFO - 2021-12-10 02:00:23 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:23 --> Input Class Initialized
INFO - 2021-12-10 02:00:23 --> Language Class Initialized
INFO - 2021-12-10 02:00:23 --> Language Class Initialized
INFO - 2021-12-10 02:00:23 --> Config Class Initialized
INFO - 2021-12-10 02:00:23 --> Loader Class Initialized
INFO - 2021-12-10 02:00:23 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:23 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:23 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:23 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:23 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:23 --> Controller Class Initialized
DEBUG - 2021-12-10 02:00:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 02:00:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:00:23 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:23 --> Total execution time: 0.0730
INFO - 2021-12-10 02:00:27 --> Config Class Initialized
INFO - 2021-12-10 02:00:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:27 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:27 --> URI Class Initialized
INFO - 2021-12-10 02:00:27 --> Router Class Initialized
INFO - 2021-12-10 02:00:27 --> Output Class Initialized
INFO - 2021-12-10 02:00:27 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:27 --> Input Class Initialized
INFO - 2021-12-10 02:00:27 --> Language Class Initialized
INFO - 2021-12-10 02:00:27 --> Language Class Initialized
INFO - 2021-12-10 02:00:27 --> Config Class Initialized
INFO - 2021-12-10 02:00:27 --> Loader Class Initialized
INFO - 2021-12-10 02:00:27 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:27 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:27 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:27 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:27 --> Controller Class Initialized
DEBUG - 2021-12-10 02:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 02:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:00:27 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:27 --> Total execution time: 0.0370
INFO - 2021-12-10 02:00:32 --> Config Class Initialized
INFO - 2021-12-10 02:00:32 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:32 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:32 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:32 --> URI Class Initialized
INFO - 2021-12-10 02:00:32 --> Router Class Initialized
INFO - 2021-12-10 02:00:32 --> Output Class Initialized
INFO - 2021-12-10 02:00:32 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:32 --> Input Class Initialized
INFO - 2021-12-10 02:00:32 --> Language Class Initialized
INFO - 2021-12-10 02:00:32 --> Language Class Initialized
INFO - 2021-12-10 02:00:32 --> Config Class Initialized
INFO - 2021-12-10 02:00:32 --> Loader Class Initialized
INFO - 2021-12-10 02:00:32 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:32 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:32 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:32 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:32 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:32 --> Controller Class Initialized
DEBUG - 2021-12-10 02:00:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-10 02:00:32 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:32 --> Total execution time: 0.0690
INFO - 2021-12-10 02:00:47 --> Config Class Initialized
INFO - 2021-12-10 02:00:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:47 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:47 --> URI Class Initialized
INFO - 2021-12-10 02:00:47 --> Router Class Initialized
INFO - 2021-12-10 02:00:47 --> Output Class Initialized
INFO - 2021-12-10 02:00:47 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:47 --> Input Class Initialized
INFO - 2021-12-10 02:00:47 --> Language Class Initialized
INFO - 2021-12-10 02:00:47 --> Language Class Initialized
INFO - 2021-12-10 02:00:47 --> Config Class Initialized
INFO - 2021-12-10 02:00:47 --> Loader Class Initialized
INFO - 2021-12-10 02:00:47 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:47 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:47 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:47 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:47 --> Controller Class Initialized
INFO - 2021-12-10 02:00:47 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:00:47 --> Config Class Initialized
INFO - 2021-12-10 02:00:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:47 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:47 --> URI Class Initialized
INFO - 2021-12-10 02:00:47 --> Router Class Initialized
INFO - 2021-12-10 02:00:47 --> Output Class Initialized
INFO - 2021-12-10 02:00:47 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:47 --> Input Class Initialized
INFO - 2021-12-10 02:00:47 --> Language Class Initialized
INFO - 2021-12-10 02:00:47 --> Language Class Initialized
INFO - 2021-12-10 02:00:47 --> Config Class Initialized
INFO - 2021-12-10 02:00:47 --> Loader Class Initialized
INFO - 2021-12-10 02:00:47 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:47 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:47 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:47 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:47 --> Controller Class Initialized
DEBUG - 2021-12-10 02:00:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 02:00:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:00:48 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:48 --> Total execution time: 0.0380
INFO - 2021-12-10 02:00:52 --> Config Class Initialized
INFO - 2021-12-10 02:00:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:52 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:52 --> URI Class Initialized
INFO - 2021-12-10 02:00:52 --> Router Class Initialized
INFO - 2021-12-10 02:00:52 --> Output Class Initialized
INFO - 2021-12-10 02:00:52 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:52 --> Input Class Initialized
INFO - 2021-12-10 02:00:52 --> Language Class Initialized
INFO - 2021-12-10 02:00:52 --> Language Class Initialized
INFO - 2021-12-10 02:00:52 --> Config Class Initialized
INFO - 2021-12-10 02:00:52 --> Loader Class Initialized
INFO - 2021-12-10 02:00:52 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:52 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:52 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:52 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:52 --> Controller Class Initialized
INFO - 2021-12-10 02:00:52 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:00:52 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:52 --> Total execution time: 0.0460
INFO - 2021-12-10 02:00:53 --> Config Class Initialized
INFO - 2021-12-10 02:00:53 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:00:53 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:00:53 --> Utf8 Class Initialized
INFO - 2021-12-10 02:00:53 --> URI Class Initialized
INFO - 2021-12-10 02:00:53 --> Router Class Initialized
INFO - 2021-12-10 02:00:53 --> Output Class Initialized
INFO - 2021-12-10 02:00:53 --> Security Class Initialized
DEBUG - 2021-12-10 02:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:00:53 --> Input Class Initialized
INFO - 2021-12-10 02:00:53 --> Language Class Initialized
INFO - 2021-12-10 02:00:53 --> Language Class Initialized
INFO - 2021-12-10 02:00:53 --> Config Class Initialized
INFO - 2021-12-10 02:00:53 --> Loader Class Initialized
INFO - 2021-12-10 02:00:53 --> Helper loaded: url_helper
INFO - 2021-12-10 02:00:53 --> Helper loaded: file_helper
INFO - 2021-12-10 02:00:53 --> Helper loaded: form_helper
INFO - 2021-12-10 02:00:53 --> Helper loaded: my_helper
INFO - 2021-12-10 02:00:53 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:00:53 --> Controller Class Initialized
DEBUG - 2021-12-10 02:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 02:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:00:53 --> Final output sent to browser
DEBUG - 2021-12-10 02:00:53 --> Total execution time: 0.2270
INFO - 2021-12-10 02:02:09 --> Config Class Initialized
INFO - 2021-12-10 02:02:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:09 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:09 --> URI Class Initialized
INFO - 2021-12-10 02:02:09 --> Router Class Initialized
INFO - 2021-12-10 02:02:09 --> Output Class Initialized
INFO - 2021-12-10 02:02:09 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:09 --> Input Class Initialized
INFO - 2021-12-10 02:02:09 --> Language Class Initialized
INFO - 2021-12-10 02:02:09 --> Language Class Initialized
INFO - 2021-12-10 02:02:09 --> Config Class Initialized
INFO - 2021-12-10 02:02:09 --> Loader Class Initialized
INFO - 2021-12-10 02:02:09 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:09 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:09 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:09 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:09 --> Controller Class Initialized
DEBUG - 2021-12-10 02:02:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 02:02:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:02:09 --> Final output sent to browser
DEBUG - 2021-12-10 02:02:09 --> Total execution time: 0.0540
INFO - 2021-12-10 02:02:09 --> Config Class Initialized
INFO - 2021-12-10 02:02:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:09 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:09 --> URI Class Initialized
INFO - 2021-12-10 02:02:09 --> Router Class Initialized
INFO - 2021-12-10 02:02:09 --> Output Class Initialized
INFO - 2021-12-10 02:02:09 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:09 --> Input Class Initialized
INFO - 2021-12-10 02:02:09 --> Language Class Initialized
INFO - 2021-12-10 02:02:09 --> Language Class Initialized
INFO - 2021-12-10 02:02:09 --> Config Class Initialized
INFO - 2021-12-10 02:02:09 --> Loader Class Initialized
INFO - 2021-12-10 02:02:09 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:09 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:09 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:09 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:09 --> Controller Class Initialized
INFO - 2021-12-10 02:02:11 --> Config Class Initialized
INFO - 2021-12-10 02:02:11 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:11 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:11 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:11 --> URI Class Initialized
INFO - 2021-12-10 02:02:11 --> Router Class Initialized
INFO - 2021-12-10 02:02:11 --> Output Class Initialized
INFO - 2021-12-10 02:02:11 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:11 --> Input Class Initialized
INFO - 2021-12-10 02:02:11 --> Language Class Initialized
INFO - 2021-12-10 02:02:11 --> Language Class Initialized
INFO - 2021-12-10 02:02:11 --> Config Class Initialized
INFO - 2021-12-10 02:02:11 --> Loader Class Initialized
INFO - 2021-12-10 02:02:11 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:11 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:11 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:11 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:11 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:11 --> Controller Class Initialized
INFO - 2021-12-10 02:02:11 --> Final output sent to browser
DEBUG - 2021-12-10 02:02:11 --> Total execution time: 0.0290
INFO - 2021-12-10 02:02:11 --> Config Class Initialized
INFO - 2021-12-10 02:02:11 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:11 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:11 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:11 --> URI Class Initialized
INFO - 2021-12-10 02:02:11 --> Router Class Initialized
INFO - 2021-12-10 02:02:11 --> Output Class Initialized
INFO - 2021-12-10 02:02:11 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:11 --> Input Class Initialized
INFO - 2021-12-10 02:02:11 --> Language Class Initialized
INFO - 2021-12-10 02:02:11 --> Language Class Initialized
INFO - 2021-12-10 02:02:11 --> Config Class Initialized
INFO - 2021-12-10 02:02:11 --> Loader Class Initialized
INFO - 2021-12-10 02:02:11 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:11 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:11 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:11 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:11 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:11 --> Controller Class Initialized
INFO - 2021-12-10 02:02:13 --> Config Class Initialized
INFO - 2021-12-10 02:02:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:13 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:13 --> URI Class Initialized
INFO - 2021-12-10 02:02:13 --> Router Class Initialized
INFO - 2021-12-10 02:02:13 --> Output Class Initialized
INFO - 2021-12-10 02:02:13 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:13 --> Input Class Initialized
INFO - 2021-12-10 02:02:13 --> Language Class Initialized
INFO - 2021-12-10 02:02:13 --> Language Class Initialized
INFO - 2021-12-10 02:02:13 --> Config Class Initialized
INFO - 2021-12-10 02:02:13 --> Loader Class Initialized
INFO - 2021-12-10 02:02:13 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:13 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:13 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:13 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:13 --> Controller Class Initialized
INFO - 2021-12-10 02:02:13 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:02:13 --> Config Class Initialized
INFO - 2021-12-10 02:02:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:13 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:13 --> URI Class Initialized
INFO - 2021-12-10 02:02:13 --> Router Class Initialized
INFO - 2021-12-10 02:02:13 --> Output Class Initialized
INFO - 2021-12-10 02:02:13 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:13 --> Input Class Initialized
INFO - 2021-12-10 02:02:13 --> Language Class Initialized
INFO - 2021-12-10 02:02:13 --> Language Class Initialized
INFO - 2021-12-10 02:02:13 --> Config Class Initialized
INFO - 2021-12-10 02:02:13 --> Loader Class Initialized
INFO - 2021-12-10 02:02:13 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:13 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:13 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:13 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:13 --> Controller Class Initialized
DEBUG - 2021-12-10 02:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 02:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:02:13 --> Final output sent to browser
DEBUG - 2021-12-10 02:02:13 --> Total execution time: 0.0620
INFO - 2021-12-10 02:02:22 --> Config Class Initialized
INFO - 2021-12-10 02:02:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:22 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:22 --> URI Class Initialized
INFO - 2021-12-10 02:02:22 --> Router Class Initialized
INFO - 2021-12-10 02:02:22 --> Output Class Initialized
INFO - 2021-12-10 02:02:22 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:22 --> Input Class Initialized
INFO - 2021-12-10 02:02:22 --> Language Class Initialized
INFO - 2021-12-10 02:02:22 --> Language Class Initialized
INFO - 2021-12-10 02:02:22 --> Config Class Initialized
INFO - 2021-12-10 02:02:22 --> Loader Class Initialized
INFO - 2021-12-10 02:02:22 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:22 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:22 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:22 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:22 --> Controller Class Initialized
INFO - 2021-12-10 02:02:22 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:02:22 --> Final output sent to browser
DEBUG - 2021-12-10 02:02:22 --> Total execution time: 0.0530
INFO - 2021-12-10 02:02:22 --> Config Class Initialized
INFO - 2021-12-10 02:02:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:22 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:22 --> URI Class Initialized
INFO - 2021-12-10 02:02:22 --> Router Class Initialized
INFO - 2021-12-10 02:02:22 --> Output Class Initialized
INFO - 2021-12-10 02:02:22 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:22 --> Input Class Initialized
INFO - 2021-12-10 02:02:22 --> Language Class Initialized
INFO - 2021-12-10 02:02:22 --> Language Class Initialized
INFO - 2021-12-10 02:02:22 --> Config Class Initialized
INFO - 2021-12-10 02:02:22 --> Loader Class Initialized
INFO - 2021-12-10 02:02:22 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:22 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:22 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:22 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:22 --> Controller Class Initialized
DEBUG - 2021-12-10 02:02:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 02:02:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:02:22 --> Final output sent to browser
DEBUG - 2021-12-10 02:02:22 --> Total execution time: 0.1610
INFO - 2021-12-10 02:02:33 --> Config Class Initialized
INFO - 2021-12-10 02:02:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:33 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:33 --> URI Class Initialized
INFO - 2021-12-10 02:02:33 --> Router Class Initialized
INFO - 2021-12-10 02:02:33 --> Output Class Initialized
INFO - 2021-12-10 02:02:33 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:33 --> Input Class Initialized
INFO - 2021-12-10 02:02:33 --> Language Class Initialized
INFO - 2021-12-10 02:02:33 --> Language Class Initialized
INFO - 2021-12-10 02:02:33 --> Config Class Initialized
INFO - 2021-12-10 02:02:33 --> Loader Class Initialized
INFO - 2021-12-10 02:02:33 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:33 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:33 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:33 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:33 --> Controller Class Initialized
DEBUG - 2021-12-10 02:02:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 02:02:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:02:33 --> Final output sent to browser
DEBUG - 2021-12-10 02:02:33 --> Total execution time: 0.1070
INFO - 2021-12-10 02:02:40 --> Config Class Initialized
INFO - 2021-12-10 02:02:40 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:40 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:40 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:40 --> URI Class Initialized
INFO - 2021-12-10 02:02:40 --> Router Class Initialized
INFO - 2021-12-10 02:02:40 --> Output Class Initialized
INFO - 2021-12-10 02:02:40 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:40 --> Input Class Initialized
INFO - 2021-12-10 02:02:40 --> Language Class Initialized
INFO - 2021-12-10 02:02:40 --> Language Class Initialized
INFO - 2021-12-10 02:02:40 --> Config Class Initialized
INFO - 2021-12-10 02:02:40 --> Loader Class Initialized
INFO - 2021-12-10 02:02:40 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:40 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:40 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:40 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:40 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:40 --> Controller Class Initialized
DEBUG - 2021-12-10 02:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 02:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:02:40 --> Final output sent to browser
DEBUG - 2021-12-10 02:02:40 --> Total execution time: 0.0690
INFO - 2021-12-10 02:02:43 --> Config Class Initialized
INFO - 2021-12-10 02:02:43 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:02:43 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:02:43 --> Utf8 Class Initialized
INFO - 2021-12-10 02:02:43 --> URI Class Initialized
INFO - 2021-12-10 02:02:43 --> Router Class Initialized
INFO - 2021-12-10 02:02:43 --> Output Class Initialized
INFO - 2021-12-10 02:02:43 --> Security Class Initialized
DEBUG - 2021-12-10 02:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:02:43 --> Input Class Initialized
INFO - 2021-12-10 02:02:43 --> Language Class Initialized
INFO - 2021-12-10 02:02:43 --> Language Class Initialized
INFO - 2021-12-10 02:02:43 --> Config Class Initialized
INFO - 2021-12-10 02:02:43 --> Loader Class Initialized
INFO - 2021-12-10 02:02:43 --> Helper loaded: url_helper
INFO - 2021-12-10 02:02:43 --> Helper loaded: file_helper
INFO - 2021-12-10 02:02:43 --> Helper loaded: form_helper
INFO - 2021-12-10 02:02:43 --> Helper loaded: my_helper
INFO - 2021-12-10 02:02:43 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:02:43 --> Controller Class Initialized
DEBUG - 2021-12-10 02:02:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-10 02:02:43 --> Final output sent to browser
DEBUG - 2021-12-10 02:02:43 --> Total execution time: 0.0970
INFO - 2021-12-10 02:03:15 --> Config Class Initialized
INFO - 2021-12-10 02:03:15 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:15 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:15 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:15 --> URI Class Initialized
INFO - 2021-12-10 02:03:15 --> Router Class Initialized
INFO - 2021-12-10 02:03:15 --> Output Class Initialized
INFO - 2021-12-10 02:03:15 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:15 --> Input Class Initialized
INFO - 2021-12-10 02:03:15 --> Language Class Initialized
INFO - 2021-12-10 02:03:15 --> Language Class Initialized
INFO - 2021-12-10 02:03:15 --> Config Class Initialized
INFO - 2021-12-10 02:03:15 --> Loader Class Initialized
INFO - 2021-12-10 02:03:15 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:15 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:15 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:15 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:15 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:15 --> Controller Class Initialized
INFO - 2021-12-10 02:03:15 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:03:15 --> Config Class Initialized
INFO - 2021-12-10 02:03:15 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:15 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:15 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:15 --> URI Class Initialized
INFO - 2021-12-10 02:03:15 --> Router Class Initialized
INFO - 2021-12-10 02:03:15 --> Output Class Initialized
INFO - 2021-12-10 02:03:15 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:15 --> Input Class Initialized
INFO - 2021-12-10 02:03:15 --> Language Class Initialized
INFO - 2021-12-10 02:03:15 --> Language Class Initialized
INFO - 2021-12-10 02:03:15 --> Config Class Initialized
INFO - 2021-12-10 02:03:15 --> Loader Class Initialized
INFO - 2021-12-10 02:03:15 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:15 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:15 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:15 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:15 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:15 --> Controller Class Initialized
DEBUG - 2021-12-10 02:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 02:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:03:15 --> Final output sent to browser
DEBUG - 2021-12-10 02:03:15 --> Total execution time: 0.0350
INFO - 2021-12-10 02:03:21 --> Config Class Initialized
INFO - 2021-12-10 02:03:21 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:21 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:21 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:21 --> URI Class Initialized
INFO - 2021-12-10 02:03:21 --> Router Class Initialized
INFO - 2021-12-10 02:03:21 --> Output Class Initialized
INFO - 2021-12-10 02:03:21 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:21 --> Input Class Initialized
INFO - 2021-12-10 02:03:21 --> Language Class Initialized
INFO - 2021-12-10 02:03:22 --> Language Class Initialized
INFO - 2021-12-10 02:03:22 --> Config Class Initialized
INFO - 2021-12-10 02:03:22 --> Loader Class Initialized
INFO - 2021-12-10 02:03:22 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:22 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:22 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:22 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:22 --> Controller Class Initialized
INFO - 2021-12-10 02:03:22 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:03:22 --> Final output sent to browser
DEBUG - 2021-12-10 02:03:22 --> Total execution time: 0.0380
INFO - 2021-12-10 02:03:22 --> Config Class Initialized
INFO - 2021-12-10 02:03:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:22 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:22 --> URI Class Initialized
INFO - 2021-12-10 02:03:22 --> Router Class Initialized
INFO - 2021-12-10 02:03:22 --> Output Class Initialized
INFO - 2021-12-10 02:03:22 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:22 --> Input Class Initialized
INFO - 2021-12-10 02:03:22 --> Language Class Initialized
INFO - 2021-12-10 02:03:22 --> Language Class Initialized
INFO - 2021-12-10 02:03:22 --> Config Class Initialized
INFO - 2021-12-10 02:03:22 --> Loader Class Initialized
INFO - 2021-12-10 02:03:22 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:22 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:22 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:22 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:22 --> Controller Class Initialized
DEBUG - 2021-12-10 02:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 02:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:03:23 --> Final output sent to browser
DEBUG - 2021-12-10 02:03:23 --> Total execution time: 0.2320
INFO - 2021-12-10 02:03:25 --> Config Class Initialized
INFO - 2021-12-10 02:03:25 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:25 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:25 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:25 --> URI Class Initialized
INFO - 2021-12-10 02:03:25 --> Router Class Initialized
INFO - 2021-12-10 02:03:25 --> Output Class Initialized
INFO - 2021-12-10 02:03:25 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:25 --> Input Class Initialized
INFO - 2021-12-10 02:03:25 --> Language Class Initialized
INFO - 2021-12-10 02:03:25 --> Language Class Initialized
INFO - 2021-12-10 02:03:25 --> Config Class Initialized
INFO - 2021-12-10 02:03:25 --> Loader Class Initialized
INFO - 2021-12-10 02:03:25 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:25 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:25 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:25 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:25 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:25 --> Controller Class Initialized
DEBUG - 2021-12-10 02:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 02:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:03:25 --> Final output sent to browser
DEBUG - 2021-12-10 02:03:25 --> Total execution time: 0.0600
INFO - 2021-12-10 02:03:25 --> Config Class Initialized
INFO - 2021-12-10 02:03:25 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:25 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:25 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:25 --> URI Class Initialized
INFO - 2021-12-10 02:03:25 --> Router Class Initialized
INFO - 2021-12-10 02:03:25 --> Output Class Initialized
INFO - 2021-12-10 02:03:25 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:25 --> Input Class Initialized
INFO - 2021-12-10 02:03:25 --> Language Class Initialized
INFO - 2021-12-10 02:03:25 --> Language Class Initialized
INFO - 2021-12-10 02:03:25 --> Config Class Initialized
INFO - 2021-12-10 02:03:25 --> Loader Class Initialized
INFO - 2021-12-10 02:03:25 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:25 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:25 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:25 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:25 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:25 --> Controller Class Initialized
INFO - 2021-12-10 02:03:27 --> Config Class Initialized
INFO - 2021-12-10 02:03:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:27 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:27 --> URI Class Initialized
INFO - 2021-12-10 02:03:27 --> Router Class Initialized
INFO - 2021-12-10 02:03:27 --> Output Class Initialized
INFO - 2021-12-10 02:03:27 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:27 --> Input Class Initialized
INFO - 2021-12-10 02:03:27 --> Language Class Initialized
INFO - 2021-12-10 02:03:27 --> Language Class Initialized
INFO - 2021-12-10 02:03:27 --> Config Class Initialized
INFO - 2021-12-10 02:03:27 --> Loader Class Initialized
INFO - 2021-12-10 02:03:27 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:27 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:27 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:27 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:27 --> Controller Class Initialized
INFO - 2021-12-10 02:03:27 --> Final output sent to browser
DEBUG - 2021-12-10 02:03:27 --> Total execution time: 0.0410
INFO - 2021-12-10 02:03:27 --> Config Class Initialized
INFO - 2021-12-10 02:03:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:27 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:27 --> URI Class Initialized
INFO - 2021-12-10 02:03:27 --> Router Class Initialized
INFO - 2021-12-10 02:03:27 --> Output Class Initialized
INFO - 2021-12-10 02:03:27 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:27 --> Input Class Initialized
INFO - 2021-12-10 02:03:27 --> Language Class Initialized
INFO - 2021-12-10 02:03:27 --> Language Class Initialized
INFO - 2021-12-10 02:03:27 --> Config Class Initialized
INFO - 2021-12-10 02:03:27 --> Loader Class Initialized
INFO - 2021-12-10 02:03:27 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:27 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:27 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:27 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:27 --> Controller Class Initialized
INFO - 2021-12-10 02:03:30 --> Config Class Initialized
INFO - 2021-12-10 02:03:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:30 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:30 --> URI Class Initialized
INFO - 2021-12-10 02:03:30 --> Router Class Initialized
INFO - 2021-12-10 02:03:30 --> Output Class Initialized
INFO - 2021-12-10 02:03:30 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:30 --> Input Class Initialized
INFO - 2021-12-10 02:03:30 --> Language Class Initialized
INFO - 2021-12-10 02:03:30 --> Language Class Initialized
INFO - 2021-12-10 02:03:30 --> Config Class Initialized
INFO - 2021-12-10 02:03:30 --> Loader Class Initialized
INFO - 2021-12-10 02:03:30 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:30 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:30 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:30 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:30 --> Controller Class Initialized
INFO - 2021-12-10 02:03:30 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:03:30 --> Config Class Initialized
INFO - 2021-12-10 02:03:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:30 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:30 --> URI Class Initialized
INFO - 2021-12-10 02:03:30 --> Router Class Initialized
INFO - 2021-12-10 02:03:30 --> Output Class Initialized
INFO - 2021-12-10 02:03:30 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:30 --> Input Class Initialized
INFO - 2021-12-10 02:03:30 --> Language Class Initialized
INFO - 2021-12-10 02:03:30 --> Language Class Initialized
INFO - 2021-12-10 02:03:30 --> Config Class Initialized
INFO - 2021-12-10 02:03:30 --> Loader Class Initialized
INFO - 2021-12-10 02:03:30 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:30 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:30 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:30 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:30 --> Controller Class Initialized
DEBUG - 2021-12-10 02:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 02:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:03:30 --> Final output sent to browser
DEBUG - 2021-12-10 02:03:30 --> Total execution time: 0.0390
INFO - 2021-12-10 02:03:39 --> Config Class Initialized
INFO - 2021-12-10 02:03:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:39 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:39 --> URI Class Initialized
INFO - 2021-12-10 02:03:39 --> Router Class Initialized
INFO - 2021-12-10 02:03:39 --> Output Class Initialized
INFO - 2021-12-10 02:03:39 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:39 --> Input Class Initialized
INFO - 2021-12-10 02:03:39 --> Language Class Initialized
INFO - 2021-12-10 02:03:39 --> Language Class Initialized
INFO - 2021-12-10 02:03:39 --> Config Class Initialized
INFO - 2021-12-10 02:03:39 --> Loader Class Initialized
INFO - 2021-12-10 02:03:39 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:39 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:39 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:39 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:39 --> Controller Class Initialized
INFO - 2021-12-10 02:03:39 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:03:39 --> Final output sent to browser
DEBUG - 2021-12-10 02:03:39 --> Total execution time: 0.0600
INFO - 2021-12-10 02:03:39 --> Config Class Initialized
INFO - 2021-12-10 02:03:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:03:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:03:39 --> Utf8 Class Initialized
INFO - 2021-12-10 02:03:39 --> URI Class Initialized
INFO - 2021-12-10 02:03:39 --> Router Class Initialized
INFO - 2021-12-10 02:03:39 --> Output Class Initialized
INFO - 2021-12-10 02:03:39 --> Security Class Initialized
DEBUG - 2021-12-10 02:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:03:39 --> Input Class Initialized
INFO - 2021-12-10 02:03:39 --> Language Class Initialized
INFO - 2021-12-10 02:03:39 --> Language Class Initialized
INFO - 2021-12-10 02:03:39 --> Config Class Initialized
INFO - 2021-12-10 02:03:39 --> Loader Class Initialized
INFO - 2021-12-10 02:03:39 --> Helper loaded: url_helper
INFO - 2021-12-10 02:03:39 --> Helper loaded: file_helper
INFO - 2021-12-10 02:03:39 --> Helper loaded: form_helper
INFO - 2021-12-10 02:03:39 --> Helper loaded: my_helper
INFO - 2021-12-10 02:03:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:03:39 --> Controller Class Initialized
DEBUG - 2021-12-10 02:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 02:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:03:39 --> Final output sent to browser
DEBUG - 2021-12-10 02:03:39 --> Total execution time: 0.1340
INFO - 2021-12-10 02:50:57 --> Config Class Initialized
INFO - 2021-12-10 02:50:57 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:50:57 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:50:57 --> Utf8 Class Initialized
INFO - 2021-12-10 02:50:57 --> URI Class Initialized
INFO - 2021-12-10 02:50:57 --> Router Class Initialized
INFO - 2021-12-10 02:50:57 --> Output Class Initialized
INFO - 2021-12-10 02:50:57 --> Security Class Initialized
DEBUG - 2021-12-10 02:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:50:57 --> Input Class Initialized
INFO - 2021-12-10 02:50:57 --> Language Class Initialized
INFO - 2021-12-10 02:50:57 --> Language Class Initialized
INFO - 2021-12-10 02:50:57 --> Config Class Initialized
INFO - 2021-12-10 02:50:57 --> Loader Class Initialized
INFO - 2021-12-10 02:50:57 --> Helper loaded: url_helper
INFO - 2021-12-10 02:50:57 --> Helper loaded: file_helper
INFO - 2021-12-10 02:50:57 --> Helper loaded: form_helper
INFO - 2021-12-10 02:50:57 --> Helper loaded: my_helper
INFO - 2021-12-10 02:50:57 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:50:57 --> Controller Class Initialized
DEBUG - 2021-12-10 02:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 02:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:50:57 --> Final output sent to browser
DEBUG - 2021-12-10 02:50:57 --> Total execution time: 0.1080
INFO - 2021-12-10 02:51:00 --> Config Class Initialized
INFO - 2021-12-10 02:51:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:51:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:51:00 --> Utf8 Class Initialized
INFO - 2021-12-10 02:51:00 --> URI Class Initialized
INFO - 2021-12-10 02:51:00 --> Router Class Initialized
INFO - 2021-12-10 02:51:00 --> Output Class Initialized
INFO - 2021-12-10 02:51:00 --> Security Class Initialized
DEBUG - 2021-12-10 02:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:51:00 --> Input Class Initialized
INFO - 2021-12-10 02:51:00 --> Language Class Initialized
INFO - 2021-12-10 02:51:00 --> Language Class Initialized
INFO - 2021-12-10 02:51:00 --> Config Class Initialized
INFO - 2021-12-10 02:51:00 --> Loader Class Initialized
INFO - 2021-12-10 02:51:00 --> Helper loaded: url_helper
INFO - 2021-12-10 02:51:00 --> Helper loaded: file_helper
INFO - 2021-12-10 02:51:00 --> Helper loaded: form_helper
INFO - 2021-12-10 02:51:00 --> Helper loaded: my_helper
INFO - 2021-12-10 02:51:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:51:00 --> Controller Class Initialized
DEBUG - 2021-12-10 02:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 02:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:51:00 --> Final output sent to browser
DEBUG - 2021-12-10 02:51:00 --> Total execution time: 0.0490
INFO - 2021-12-10 02:51:34 --> Config Class Initialized
INFO - 2021-12-10 02:51:34 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:51:34 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:51:34 --> Utf8 Class Initialized
INFO - 2021-12-10 02:51:34 --> URI Class Initialized
INFO - 2021-12-10 02:51:34 --> Router Class Initialized
INFO - 2021-12-10 02:51:34 --> Output Class Initialized
INFO - 2021-12-10 02:51:34 --> Security Class Initialized
DEBUG - 2021-12-10 02:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:51:34 --> Input Class Initialized
INFO - 2021-12-10 02:51:34 --> Language Class Initialized
INFO - 2021-12-10 02:51:34 --> Language Class Initialized
INFO - 2021-12-10 02:51:34 --> Config Class Initialized
INFO - 2021-12-10 02:51:34 --> Loader Class Initialized
INFO - 2021-12-10 02:51:34 --> Helper loaded: url_helper
INFO - 2021-12-10 02:51:34 --> Helper loaded: file_helper
INFO - 2021-12-10 02:51:34 --> Helper loaded: form_helper
INFO - 2021-12-10 02:51:34 --> Helper loaded: my_helper
INFO - 2021-12-10 02:51:34 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:51:34 --> Controller Class Initialized
DEBUG - 2021-12-10 02:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-10 02:51:34 --> Final output sent to browser
DEBUG - 2021-12-10 02:51:34 --> Total execution time: 0.0910
INFO - 2021-12-10 02:52:22 --> Config Class Initialized
INFO - 2021-12-10 02:52:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:52:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:52:22 --> Utf8 Class Initialized
INFO - 2021-12-10 02:52:22 --> URI Class Initialized
INFO - 2021-12-10 02:52:22 --> Router Class Initialized
INFO - 2021-12-10 02:52:22 --> Output Class Initialized
INFO - 2021-12-10 02:52:22 --> Security Class Initialized
DEBUG - 2021-12-10 02:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:52:22 --> Input Class Initialized
INFO - 2021-12-10 02:52:22 --> Language Class Initialized
INFO - 2021-12-10 02:52:22 --> Language Class Initialized
INFO - 2021-12-10 02:52:22 --> Config Class Initialized
INFO - 2021-12-10 02:52:22 --> Loader Class Initialized
INFO - 2021-12-10 02:52:22 --> Helper loaded: url_helper
INFO - 2021-12-10 02:52:22 --> Helper loaded: file_helper
INFO - 2021-12-10 02:52:22 --> Helper loaded: form_helper
INFO - 2021-12-10 02:52:22 --> Helper loaded: my_helper
INFO - 2021-12-10 02:52:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:52:22 --> Controller Class Initialized
INFO - 2021-12-10 02:52:22 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:52:22 --> Config Class Initialized
INFO - 2021-12-10 02:52:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:52:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:52:22 --> Utf8 Class Initialized
INFO - 2021-12-10 02:52:22 --> URI Class Initialized
INFO - 2021-12-10 02:52:22 --> Router Class Initialized
INFO - 2021-12-10 02:52:22 --> Output Class Initialized
INFO - 2021-12-10 02:52:22 --> Security Class Initialized
DEBUG - 2021-12-10 02:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:52:22 --> Input Class Initialized
INFO - 2021-12-10 02:52:22 --> Language Class Initialized
INFO - 2021-12-10 02:52:22 --> Language Class Initialized
INFO - 2021-12-10 02:52:22 --> Config Class Initialized
INFO - 2021-12-10 02:52:22 --> Loader Class Initialized
INFO - 2021-12-10 02:52:22 --> Helper loaded: url_helper
INFO - 2021-12-10 02:52:22 --> Helper loaded: file_helper
INFO - 2021-12-10 02:52:22 --> Helper loaded: form_helper
INFO - 2021-12-10 02:52:22 --> Helper loaded: my_helper
INFO - 2021-12-10 02:52:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:52:22 --> Controller Class Initialized
DEBUG - 2021-12-10 02:52:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 02:52:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:52:22 --> Final output sent to browser
DEBUG - 2021-12-10 02:52:22 --> Total execution time: 0.0380
INFO - 2021-12-10 02:52:31 --> Config Class Initialized
INFO - 2021-12-10 02:52:31 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:52:31 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:52:31 --> Utf8 Class Initialized
INFO - 2021-12-10 02:52:31 --> URI Class Initialized
INFO - 2021-12-10 02:52:31 --> Router Class Initialized
INFO - 2021-12-10 02:52:31 --> Output Class Initialized
INFO - 2021-12-10 02:52:31 --> Security Class Initialized
DEBUG - 2021-12-10 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:52:31 --> Input Class Initialized
INFO - 2021-12-10 02:52:31 --> Language Class Initialized
INFO - 2021-12-10 02:52:31 --> Language Class Initialized
INFO - 2021-12-10 02:52:31 --> Config Class Initialized
INFO - 2021-12-10 02:52:31 --> Loader Class Initialized
INFO - 2021-12-10 02:52:31 --> Helper loaded: url_helper
INFO - 2021-12-10 02:52:31 --> Helper loaded: file_helper
INFO - 2021-12-10 02:52:31 --> Helper loaded: form_helper
INFO - 2021-12-10 02:52:31 --> Helper loaded: my_helper
INFO - 2021-12-10 02:52:31 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:52:31 --> Controller Class Initialized
INFO - 2021-12-10 02:52:31 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:52:31 --> Final output sent to browser
DEBUG - 2021-12-10 02:52:31 --> Total execution time: 0.0430
INFO - 2021-12-10 02:52:31 --> Config Class Initialized
INFO - 2021-12-10 02:52:31 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:52:31 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:52:31 --> Utf8 Class Initialized
INFO - 2021-12-10 02:52:31 --> URI Class Initialized
INFO - 2021-12-10 02:52:31 --> Router Class Initialized
INFO - 2021-12-10 02:52:31 --> Output Class Initialized
INFO - 2021-12-10 02:52:31 --> Security Class Initialized
DEBUG - 2021-12-10 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:52:31 --> Input Class Initialized
INFO - 2021-12-10 02:52:31 --> Language Class Initialized
INFO - 2021-12-10 02:52:31 --> Language Class Initialized
INFO - 2021-12-10 02:52:31 --> Config Class Initialized
INFO - 2021-12-10 02:52:31 --> Loader Class Initialized
INFO - 2021-12-10 02:52:31 --> Helper loaded: url_helper
INFO - 2021-12-10 02:52:31 --> Helper loaded: file_helper
INFO - 2021-12-10 02:52:31 --> Helper loaded: form_helper
INFO - 2021-12-10 02:52:31 --> Helper loaded: my_helper
INFO - 2021-12-10 02:52:31 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:52:31 --> Controller Class Initialized
DEBUG - 2021-12-10 02:52:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 02:52:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:52:31 --> Final output sent to browser
DEBUG - 2021-12-10 02:52:31 --> Total execution time: 0.2030
INFO - 2021-12-10 02:52:37 --> Config Class Initialized
INFO - 2021-12-10 02:52:37 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:52:37 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:52:37 --> Utf8 Class Initialized
INFO - 2021-12-10 02:52:37 --> URI Class Initialized
INFO - 2021-12-10 02:52:37 --> Router Class Initialized
INFO - 2021-12-10 02:52:37 --> Output Class Initialized
INFO - 2021-12-10 02:52:37 --> Security Class Initialized
DEBUG - 2021-12-10 02:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:52:37 --> Input Class Initialized
INFO - 2021-12-10 02:52:37 --> Language Class Initialized
INFO - 2021-12-10 02:52:37 --> Language Class Initialized
INFO - 2021-12-10 02:52:37 --> Config Class Initialized
INFO - 2021-12-10 02:52:37 --> Loader Class Initialized
INFO - 2021-12-10 02:52:37 --> Helper loaded: url_helper
INFO - 2021-12-10 02:52:37 --> Helper loaded: file_helper
INFO - 2021-12-10 02:52:37 --> Helper loaded: form_helper
INFO - 2021-12-10 02:52:37 --> Helper loaded: my_helper
INFO - 2021-12-10 02:52:37 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:52:37 --> Controller Class Initialized
DEBUG - 2021-12-10 02:52:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 02:52:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:52:37 --> Final output sent to browser
DEBUG - 2021-12-10 02:52:37 --> Total execution time: 0.1280
INFO - 2021-12-10 02:52:41 --> Config Class Initialized
INFO - 2021-12-10 02:52:41 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:52:41 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:52:41 --> Utf8 Class Initialized
INFO - 2021-12-10 02:52:41 --> URI Class Initialized
INFO - 2021-12-10 02:52:41 --> Router Class Initialized
INFO - 2021-12-10 02:52:41 --> Output Class Initialized
INFO - 2021-12-10 02:52:41 --> Security Class Initialized
DEBUG - 2021-12-10 02:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:52:41 --> Input Class Initialized
INFO - 2021-12-10 02:52:41 --> Language Class Initialized
INFO - 2021-12-10 02:52:41 --> Language Class Initialized
INFO - 2021-12-10 02:52:41 --> Config Class Initialized
INFO - 2021-12-10 02:52:41 --> Loader Class Initialized
INFO - 2021-12-10 02:52:41 --> Helper loaded: url_helper
INFO - 2021-12-10 02:52:41 --> Helper loaded: file_helper
INFO - 2021-12-10 02:52:41 --> Helper loaded: form_helper
INFO - 2021-12-10 02:52:41 --> Helper loaded: my_helper
INFO - 2021-12-10 02:52:41 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:52:41 --> Controller Class Initialized
DEBUG - 2021-12-10 02:52:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 02:52:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:52:41 --> Final output sent to browser
DEBUG - 2021-12-10 02:52:41 --> Total execution time: 0.0430
INFO - 2021-12-10 02:52:44 --> Config Class Initialized
INFO - 2021-12-10 02:52:44 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:52:44 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:52:44 --> Utf8 Class Initialized
INFO - 2021-12-10 02:52:44 --> URI Class Initialized
INFO - 2021-12-10 02:52:44 --> Router Class Initialized
INFO - 2021-12-10 02:52:44 --> Output Class Initialized
INFO - 2021-12-10 02:52:44 --> Security Class Initialized
DEBUG - 2021-12-10 02:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:52:44 --> Input Class Initialized
INFO - 2021-12-10 02:52:44 --> Language Class Initialized
INFO - 2021-12-10 02:52:44 --> Language Class Initialized
INFO - 2021-12-10 02:52:44 --> Config Class Initialized
INFO - 2021-12-10 02:52:44 --> Loader Class Initialized
INFO - 2021-12-10 02:52:44 --> Helper loaded: url_helper
INFO - 2021-12-10 02:52:44 --> Helper loaded: file_helper
INFO - 2021-12-10 02:52:44 --> Helper loaded: form_helper
INFO - 2021-12-10 02:52:44 --> Helper loaded: my_helper
INFO - 2021-12-10 02:52:44 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:52:44 --> Controller Class Initialized
DEBUG - 2021-12-10 02:52:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-10 02:52:44 --> Final output sent to browser
DEBUG - 2021-12-10 02:52:44 --> Total execution time: 0.0950
INFO - 2021-12-10 02:53:43 --> Config Class Initialized
INFO - 2021-12-10 02:53:43 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:53:43 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:53:43 --> Utf8 Class Initialized
INFO - 2021-12-10 02:53:43 --> URI Class Initialized
INFO - 2021-12-10 02:53:43 --> Router Class Initialized
INFO - 2021-12-10 02:53:43 --> Output Class Initialized
INFO - 2021-12-10 02:53:43 --> Security Class Initialized
DEBUG - 2021-12-10 02:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:53:43 --> Input Class Initialized
INFO - 2021-12-10 02:53:43 --> Language Class Initialized
INFO - 2021-12-10 02:53:43 --> Language Class Initialized
INFO - 2021-12-10 02:53:43 --> Config Class Initialized
INFO - 2021-12-10 02:53:43 --> Loader Class Initialized
INFO - 2021-12-10 02:53:43 --> Helper loaded: url_helper
INFO - 2021-12-10 02:53:43 --> Helper loaded: file_helper
INFO - 2021-12-10 02:53:43 --> Helper loaded: form_helper
INFO - 2021-12-10 02:53:43 --> Helper loaded: my_helper
INFO - 2021-12-10 02:53:43 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:53:43 --> Controller Class Initialized
DEBUG - 2021-12-10 02:53:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-10 02:53:43 --> Final output sent to browser
DEBUG - 2021-12-10 02:53:43 --> Total execution time: 0.0570
INFO - 2021-12-10 02:54:17 --> Config Class Initialized
INFO - 2021-12-10 02:54:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:54:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:54:17 --> Utf8 Class Initialized
INFO - 2021-12-10 02:54:17 --> URI Class Initialized
INFO - 2021-12-10 02:54:17 --> Router Class Initialized
INFO - 2021-12-10 02:54:17 --> Output Class Initialized
INFO - 2021-12-10 02:54:17 --> Security Class Initialized
DEBUG - 2021-12-10 02:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:54:17 --> Input Class Initialized
INFO - 2021-12-10 02:54:17 --> Language Class Initialized
INFO - 2021-12-10 02:54:17 --> Language Class Initialized
INFO - 2021-12-10 02:54:17 --> Config Class Initialized
INFO - 2021-12-10 02:54:17 --> Loader Class Initialized
INFO - 2021-12-10 02:54:17 --> Helper loaded: url_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: file_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: form_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: my_helper
INFO - 2021-12-10 02:54:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:54:17 --> Controller Class Initialized
INFO - 2021-12-10 02:54:17 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:54:17 --> Config Class Initialized
INFO - 2021-12-10 02:54:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:54:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:54:17 --> Utf8 Class Initialized
INFO - 2021-12-10 02:54:17 --> URI Class Initialized
INFO - 2021-12-10 02:54:17 --> Router Class Initialized
INFO - 2021-12-10 02:54:17 --> Output Class Initialized
INFO - 2021-12-10 02:54:17 --> Security Class Initialized
DEBUG - 2021-12-10 02:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:54:17 --> Input Class Initialized
INFO - 2021-12-10 02:54:17 --> Language Class Initialized
INFO - 2021-12-10 02:54:17 --> Language Class Initialized
INFO - 2021-12-10 02:54:17 --> Config Class Initialized
INFO - 2021-12-10 02:54:17 --> Loader Class Initialized
INFO - 2021-12-10 02:54:17 --> Helper loaded: url_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: file_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: form_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: my_helper
INFO - 2021-12-10 02:54:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:54:17 --> Controller Class Initialized
INFO - 2021-12-10 02:54:17 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:54:17 --> Config Class Initialized
INFO - 2021-12-10 02:54:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:54:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:54:17 --> Utf8 Class Initialized
INFO - 2021-12-10 02:54:17 --> URI Class Initialized
INFO - 2021-12-10 02:54:17 --> Router Class Initialized
INFO - 2021-12-10 02:54:17 --> Output Class Initialized
INFO - 2021-12-10 02:54:17 --> Security Class Initialized
DEBUG - 2021-12-10 02:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:54:17 --> Input Class Initialized
INFO - 2021-12-10 02:54:17 --> Language Class Initialized
INFO - 2021-12-10 02:54:17 --> Language Class Initialized
INFO - 2021-12-10 02:54:17 --> Config Class Initialized
INFO - 2021-12-10 02:54:17 --> Loader Class Initialized
INFO - 2021-12-10 02:54:17 --> Helper loaded: url_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: file_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: form_helper
INFO - 2021-12-10 02:54:17 --> Helper loaded: my_helper
INFO - 2021-12-10 02:54:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:54:17 --> Controller Class Initialized
DEBUG - 2021-12-10 02:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 02:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:54:17 --> Final output sent to browser
DEBUG - 2021-12-10 02:54:17 --> Total execution time: 0.0370
INFO - 2021-12-10 02:54:27 --> Config Class Initialized
INFO - 2021-12-10 02:54:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:54:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:54:27 --> Utf8 Class Initialized
INFO - 2021-12-10 02:54:27 --> URI Class Initialized
INFO - 2021-12-10 02:54:27 --> Router Class Initialized
INFO - 2021-12-10 02:54:27 --> Output Class Initialized
INFO - 2021-12-10 02:54:27 --> Security Class Initialized
DEBUG - 2021-12-10 02:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:54:27 --> Input Class Initialized
INFO - 2021-12-10 02:54:27 --> Language Class Initialized
INFO - 2021-12-10 02:54:27 --> Language Class Initialized
INFO - 2021-12-10 02:54:27 --> Config Class Initialized
INFO - 2021-12-10 02:54:27 --> Loader Class Initialized
INFO - 2021-12-10 02:54:27 --> Helper loaded: url_helper
INFO - 2021-12-10 02:54:27 --> Helper loaded: file_helper
INFO - 2021-12-10 02:54:27 --> Helper loaded: form_helper
INFO - 2021-12-10 02:54:27 --> Helper loaded: my_helper
INFO - 2021-12-10 02:54:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:54:27 --> Controller Class Initialized
INFO - 2021-12-10 02:54:27 --> Helper loaded: cookie_helper
INFO - 2021-12-10 02:54:27 --> Final output sent to browser
DEBUG - 2021-12-10 02:54:27 --> Total execution time: 0.0520
INFO - 2021-12-10 02:54:28 --> Config Class Initialized
INFO - 2021-12-10 02:54:28 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:54:28 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:54:28 --> Utf8 Class Initialized
INFO - 2021-12-10 02:54:28 --> URI Class Initialized
INFO - 2021-12-10 02:54:28 --> Router Class Initialized
INFO - 2021-12-10 02:54:28 --> Output Class Initialized
INFO - 2021-12-10 02:54:28 --> Security Class Initialized
DEBUG - 2021-12-10 02:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:54:28 --> Input Class Initialized
INFO - 2021-12-10 02:54:28 --> Language Class Initialized
INFO - 2021-12-10 02:54:28 --> Language Class Initialized
INFO - 2021-12-10 02:54:28 --> Config Class Initialized
INFO - 2021-12-10 02:54:28 --> Loader Class Initialized
INFO - 2021-12-10 02:54:28 --> Helper loaded: url_helper
INFO - 2021-12-10 02:54:28 --> Helper loaded: file_helper
INFO - 2021-12-10 02:54:28 --> Helper loaded: form_helper
INFO - 2021-12-10 02:54:28 --> Helper loaded: my_helper
INFO - 2021-12-10 02:54:28 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:54:28 --> Controller Class Initialized
DEBUG - 2021-12-10 02:54:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 02:54:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:54:28 --> Final output sent to browser
DEBUG - 2021-12-10 02:54:28 --> Total execution time: 0.1890
INFO - 2021-12-10 02:55:04 --> Config Class Initialized
INFO - 2021-12-10 02:55:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:55:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:55:04 --> Utf8 Class Initialized
INFO - 2021-12-10 02:55:04 --> URI Class Initialized
INFO - 2021-12-10 02:55:04 --> Router Class Initialized
INFO - 2021-12-10 02:55:04 --> Output Class Initialized
INFO - 2021-12-10 02:55:04 --> Security Class Initialized
DEBUG - 2021-12-10 02:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:55:04 --> Input Class Initialized
INFO - 2021-12-10 02:55:04 --> Language Class Initialized
INFO - 2021-12-10 02:55:04 --> Language Class Initialized
INFO - 2021-12-10 02:55:04 --> Config Class Initialized
INFO - 2021-12-10 02:55:04 --> Loader Class Initialized
INFO - 2021-12-10 02:55:04 --> Helper loaded: url_helper
INFO - 2021-12-10 02:55:04 --> Helper loaded: file_helper
INFO - 2021-12-10 02:55:04 --> Helper loaded: form_helper
INFO - 2021-12-10 02:55:04 --> Helper loaded: my_helper
INFO - 2021-12-10 02:55:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:55:04 --> Controller Class Initialized
DEBUG - 2021-12-10 02:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 02:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:55:04 --> Final output sent to browser
DEBUG - 2021-12-10 02:55:04 --> Total execution time: 0.0740
INFO - 2021-12-10 02:55:19 --> Config Class Initialized
INFO - 2021-12-10 02:55:19 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:55:19 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:55:19 --> Utf8 Class Initialized
INFO - 2021-12-10 02:55:19 --> URI Class Initialized
INFO - 2021-12-10 02:55:19 --> Router Class Initialized
INFO - 2021-12-10 02:55:19 --> Output Class Initialized
INFO - 2021-12-10 02:55:19 --> Security Class Initialized
DEBUG - 2021-12-10 02:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:55:19 --> Input Class Initialized
INFO - 2021-12-10 02:55:19 --> Language Class Initialized
INFO - 2021-12-10 02:55:19 --> Language Class Initialized
INFO - 2021-12-10 02:55:19 --> Config Class Initialized
INFO - 2021-12-10 02:55:19 --> Loader Class Initialized
INFO - 2021-12-10 02:55:19 --> Helper loaded: url_helper
INFO - 2021-12-10 02:55:19 --> Helper loaded: file_helper
INFO - 2021-12-10 02:55:19 --> Helper loaded: form_helper
INFO - 2021-12-10 02:55:19 --> Helper loaded: my_helper
INFO - 2021-12-10 02:55:19 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:55:19 --> Controller Class Initialized
INFO - 2021-12-10 02:55:19 --> Final output sent to browser
DEBUG - 2021-12-10 02:55:19 --> Total execution time: 0.0540
INFO - 2021-12-10 02:55:21 --> Config Class Initialized
INFO - 2021-12-10 02:55:21 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:55:21 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:55:21 --> Utf8 Class Initialized
INFO - 2021-12-10 02:55:21 --> URI Class Initialized
INFO - 2021-12-10 02:55:21 --> Router Class Initialized
INFO - 2021-12-10 02:55:21 --> Output Class Initialized
INFO - 2021-12-10 02:55:21 --> Security Class Initialized
DEBUG - 2021-12-10 02:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:55:21 --> Input Class Initialized
INFO - 2021-12-10 02:55:21 --> Language Class Initialized
INFO - 2021-12-10 02:55:21 --> Language Class Initialized
INFO - 2021-12-10 02:55:21 --> Config Class Initialized
INFO - 2021-12-10 02:55:21 --> Loader Class Initialized
INFO - 2021-12-10 02:55:21 --> Helper loaded: url_helper
INFO - 2021-12-10 02:55:21 --> Helper loaded: file_helper
INFO - 2021-12-10 02:55:21 --> Helper loaded: form_helper
INFO - 2021-12-10 02:55:21 --> Helper loaded: my_helper
INFO - 2021-12-10 02:55:21 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:55:21 --> Controller Class Initialized
DEBUG - 2021-12-10 02:55:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 02:55:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:55:21 --> Final output sent to browser
DEBUG - 2021-12-10 02:55:21 --> Total execution time: 0.0580
INFO - 2021-12-10 02:55:26 --> Config Class Initialized
INFO - 2021-12-10 02:55:26 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:55:26 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:55:26 --> Utf8 Class Initialized
INFO - 2021-12-10 02:55:26 --> URI Class Initialized
INFO - 2021-12-10 02:55:26 --> Router Class Initialized
INFO - 2021-12-10 02:55:26 --> Output Class Initialized
INFO - 2021-12-10 02:55:26 --> Security Class Initialized
DEBUG - 2021-12-10 02:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:55:26 --> Input Class Initialized
INFO - 2021-12-10 02:55:26 --> Language Class Initialized
INFO - 2021-12-10 02:55:26 --> Language Class Initialized
INFO - 2021-12-10 02:55:26 --> Config Class Initialized
INFO - 2021-12-10 02:55:26 --> Loader Class Initialized
INFO - 2021-12-10 02:55:26 --> Helper loaded: url_helper
INFO - 2021-12-10 02:55:26 --> Helper loaded: file_helper
INFO - 2021-12-10 02:55:26 --> Helper loaded: form_helper
INFO - 2021-12-10 02:55:26 --> Helper loaded: my_helper
INFO - 2021-12-10 02:55:26 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:55:26 --> Controller Class Initialized
DEBUG - 2021-12-10 02:55:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-10 02:55:26 --> Final output sent to browser
DEBUG - 2021-12-10 02:55:26 --> Total execution time: 0.0850
INFO - 2021-12-10 02:55:42 --> Config Class Initialized
INFO - 2021-12-10 02:55:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:55:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:55:42 --> Utf8 Class Initialized
INFO - 2021-12-10 02:55:42 --> URI Class Initialized
INFO - 2021-12-10 02:55:42 --> Router Class Initialized
INFO - 2021-12-10 02:55:42 --> Output Class Initialized
INFO - 2021-12-10 02:55:42 --> Security Class Initialized
DEBUG - 2021-12-10 02:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:55:42 --> Input Class Initialized
INFO - 2021-12-10 02:55:42 --> Language Class Initialized
INFO - 2021-12-10 02:55:42 --> Language Class Initialized
INFO - 2021-12-10 02:55:42 --> Config Class Initialized
INFO - 2021-12-10 02:55:42 --> Loader Class Initialized
INFO - 2021-12-10 02:55:42 --> Helper loaded: url_helper
INFO - 2021-12-10 02:55:42 --> Helper loaded: file_helper
INFO - 2021-12-10 02:55:42 --> Helper loaded: form_helper
INFO - 2021-12-10 02:55:42 --> Helper loaded: my_helper
INFO - 2021-12-10 02:55:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:55:42 --> Controller Class Initialized
DEBUG - 2021-12-10 02:55:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 02:55:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 02:55:42 --> Final output sent to browser
DEBUG - 2021-12-10 02:55:42 --> Total execution time: 0.0790
INFO - 2021-12-10 02:55:47 --> Config Class Initialized
INFO - 2021-12-10 02:55:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 02:55:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 02:55:47 --> Utf8 Class Initialized
INFO - 2021-12-10 02:55:47 --> URI Class Initialized
INFO - 2021-12-10 02:55:47 --> Router Class Initialized
INFO - 2021-12-10 02:55:47 --> Output Class Initialized
INFO - 2021-12-10 02:55:47 --> Security Class Initialized
DEBUG - 2021-12-10 02:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 02:55:47 --> Input Class Initialized
INFO - 2021-12-10 02:55:47 --> Language Class Initialized
INFO - 2021-12-10 02:55:47 --> Language Class Initialized
INFO - 2021-12-10 02:55:47 --> Config Class Initialized
INFO - 2021-12-10 02:55:47 --> Loader Class Initialized
INFO - 2021-12-10 02:55:47 --> Helper loaded: url_helper
INFO - 2021-12-10 02:55:47 --> Helper loaded: file_helper
INFO - 2021-12-10 02:55:47 --> Helper loaded: form_helper
INFO - 2021-12-10 02:55:47 --> Helper loaded: my_helper
INFO - 2021-12-10 02:55:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 02:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 02:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 02:55:47 --> Controller Class Initialized
INFO - 2021-12-10 02:55:47 --> Final output sent to browser
DEBUG - 2021-12-10 02:55:47 --> Total execution time: 0.0690
INFO - 2021-12-10 03:11:58 --> Config Class Initialized
INFO - 2021-12-10 03:11:58 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:11:58 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:11:58 --> Utf8 Class Initialized
INFO - 2021-12-10 03:11:58 --> URI Class Initialized
INFO - 2021-12-10 03:11:58 --> Router Class Initialized
INFO - 2021-12-10 03:11:58 --> Output Class Initialized
INFO - 2021-12-10 03:11:58 --> Security Class Initialized
DEBUG - 2021-12-10 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:11:58 --> Input Class Initialized
INFO - 2021-12-10 03:11:58 --> Language Class Initialized
INFO - 2021-12-10 03:11:58 --> Language Class Initialized
INFO - 2021-12-10 03:11:58 --> Config Class Initialized
INFO - 2021-12-10 03:11:58 --> Loader Class Initialized
INFO - 2021-12-10 03:11:58 --> Helper loaded: url_helper
INFO - 2021-12-10 03:11:58 --> Helper loaded: file_helper
INFO - 2021-12-10 03:11:58 --> Helper loaded: form_helper
INFO - 2021-12-10 03:11:58 --> Helper loaded: my_helper
INFO - 2021-12-10 03:11:58 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:11:58 --> Controller Class Initialized
INFO - 2021-12-10 03:11:58 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:11:58 --> Config Class Initialized
INFO - 2021-12-10 03:11:58 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:11:58 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:11:58 --> Utf8 Class Initialized
INFO - 2021-12-10 03:11:58 --> URI Class Initialized
INFO - 2021-12-10 03:11:58 --> Router Class Initialized
INFO - 2021-12-10 03:11:58 --> Output Class Initialized
INFO - 2021-12-10 03:11:58 --> Security Class Initialized
DEBUG - 2021-12-10 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:11:58 --> Input Class Initialized
INFO - 2021-12-10 03:11:58 --> Language Class Initialized
INFO - 2021-12-10 03:11:58 --> Language Class Initialized
INFO - 2021-12-10 03:11:58 --> Config Class Initialized
INFO - 2021-12-10 03:11:58 --> Loader Class Initialized
INFO - 2021-12-10 03:11:58 --> Helper loaded: url_helper
INFO - 2021-12-10 03:11:58 --> Helper loaded: file_helper
INFO - 2021-12-10 03:11:58 --> Helper loaded: form_helper
INFO - 2021-12-10 03:11:58 --> Helper loaded: my_helper
INFO - 2021-12-10 03:11:58 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:11:58 --> Controller Class Initialized
DEBUG - 2021-12-10 03:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:11:58 --> Final output sent to browser
DEBUG - 2021-12-10 03:11:58 --> Total execution time: 0.0410
INFO - 2021-12-10 03:12:02 --> Config Class Initialized
INFO - 2021-12-10 03:12:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:12:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:12:02 --> Utf8 Class Initialized
INFO - 2021-12-10 03:12:02 --> URI Class Initialized
INFO - 2021-12-10 03:12:02 --> Router Class Initialized
INFO - 2021-12-10 03:12:02 --> Output Class Initialized
INFO - 2021-12-10 03:12:02 --> Security Class Initialized
DEBUG - 2021-12-10 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:12:02 --> Input Class Initialized
INFO - 2021-12-10 03:12:02 --> Language Class Initialized
INFO - 2021-12-10 03:12:02 --> Language Class Initialized
INFO - 2021-12-10 03:12:02 --> Config Class Initialized
INFO - 2021-12-10 03:12:02 --> Loader Class Initialized
INFO - 2021-12-10 03:12:02 --> Helper loaded: url_helper
INFO - 2021-12-10 03:12:02 --> Helper loaded: file_helper
INFO - 2021-12-10 03:12:02 --> Helper loaded: form_helper
INFO - 2021-12-10 03:12:02 --> Helper loaded: my_helper
INFO - 2021-12-10 03:12:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:12:02 --> Controller Class Initialized
INFO - 2021-12-10 03:12:02 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:12:02 --> Final output sent to browser
DEBUG - 2021-12-10 03:12:02 --> Total execution time: 0.0470
INFO - 2021-12-10 03:12:03 --> Config Class Initialized
INFO - 2021-12-10 03:12:03 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:12:03 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:12:03 --> Utf8 Class Initialized
INFO - 2021-12-10 03:12:03 --> URI Class Initialized
INFO - 2021-12-10 03:12:03 --> Router Class Initialized
INFO - 2021-12-10 03:12:03 --> Output Class Initialized
INFO - 2021-12-10 03:12:03 --> Security Class Initialized
DEBUG - 2021-12-10 03:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:12:03 --> Input Class Initialized
INFO - 2021-12-10 03:12:03 --> Language Class Initialized
INFO - 2021-12-10 03:12:03 --> Language Class Initialized
INFO - 2021-12-10 03:12:03 --> Config Class Initialized
INFO - 2021-12-10 03:12:03 --> Loader Class Initialized
INFO - 2021-12-10 03:12:03 --> Helper loaded: url_helper
INFO - 2021-12-10 03:12:03 --> Helper loaded: file_helper
INFO - 2021-12-10 03:12:03 --> Helper loaded: form_helper
INFO - 2021-12-10 03:12:03 --> Helper loaded: my_helper
INFO - 2021-12-10 03:12:03 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:12:03 --> Controller Class Initialized
DEBUG - 2021-12-10 03:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:12:03 --> Final output sent to browser
DEBUG - 2021-12-10 03:12:03 --> Total execution time: 0.2270
INFO - 2021-12-10 03:12:08 --> Config Class Initialized
INFO - 2021-12-10 03:12:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:12:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:12:08 --> Utf8 Class Initialized
INFO - 2021-12-10 03:12:08 --> URI Class Initialized
INFO - 2021-12-10 03:12:08 --> Router Class Initialized
INFO - 2021-12-10 03:12:08 --> Output Class Initialized
INFO - 2021-12-10 03:12:08 --> Security Class Initialized
DEBUG - 2021-12-10 03:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:12:08 --> Input Class Initialized
INFO - 2021-12-10 03:12:08 --> Language Class Initialized
INFO - 2021-12-10 03:12:08 --> Language Class Initialized
INFO - 2021-12-10 03:12:08 --> Config Class Initialized
INFO - 2021-12-10 03:12:08 --> Loader Class Initialized
INFO - 2021-12-10 03:12:08 --> Helper loaded: url_helper
INFO - 2021-12-10 03:12:08 --> Helper loaded: file_helper
INFO - 2021-12-10 03:12:08 --> Helper loaded: form_helper
INFO - 2021-12-10 03:12:08 --> Helper loaded: my_helper
INFO - 2021-12-10 03:12:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:12:08 --> Controller Class Initialized
DEBUG - 2021-12-10 03:12:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:12:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:12:08 --> Final output sent to browser
DEBUG - 2021-12-10 03:12:08 --> Total execution time: 0.0950
INFO - 2021-12-10 03:12:15 --> Config Class Initialized
INFO - 2021-12-10 03:12:15 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:12:15 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:12:15 --> Utf8 Class Initialized
INFO - 2021-12-10 03:12:15 --> URI Class Initialized
INFO - 2021-12-10 03:12:15 --> Router Class Initialized
INFO - 2021-12-10 03:12:15 --> Output Class Initialized
INFO - 2021-12-10 03:12:15 --> Security Class Initialized
DEBUG - 2021-12-10 03:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:12:15 --> Input Class Initialized
INFO - 2021-12-10 03:12:15 --> Language Class Initialized
INFO - 2021-12-10 03:12:15 --> Language Class Initialized
INFO - 2021-12-10 03:12:15 --> Config Class Initialized
INFO - 2021-12-10 03:12:15 --> Loader Class Initialized
INFO - 2021-12-10 03:12:15 --> Helper loaded: url_helper
INFO - 2021-12-10 03:12:15 --> Helper loaded: file_helper
INFO - 2021-12-10 03:12:15 --> Helper loaded: form_helper
INFO - 2021-12-10 03:12:15 --> Helper loaded: my_helper
INFO - 2021-12-10 03:12:15 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:12:15 --> Controller Class Initialized
DEBUG - 2021-12-10 03:12:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:12:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:12:15 --> Final output sent to browser
DEBUG - 2021-12-10 03:12:15 --> Total execution time: 0.0530
INFO - 2021-12-10 03:12:22 --> Config Class Initialized
INFO - 2021-12-10 03:12:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:12:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:12:22 --> Utf8 Class Initialized
INFO - 2021-12-10 03:12:22 --> URI Class Initialized
INFO - 2021-12-10 03:12:22 --> Router Class Initialized
INFO - 2021-12-10 03:12:22 --> Output Class Initialized
INFO - 2021-12-10 03:12:22 --> Security Class Initialized
DEBUG - 2021-12-10 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:12:22 --> Input Class Initialized
INFO - 2021-12-10 03:12:22 --> Language Class Initialized
INFO - 2021-12-10 03:12:22 --> Language Class Initialized
INFO - 2021-12-10 03:12:22 --> Config Class Initialized
INFO - 2021-12-10 03:12:22 --> Loader Class Initialized
INFO - 2021-12-10 03:12:22 --> Helper loaded: url_helper
INFO - 2021-12-10 03:12:22 --> Helper loaded: file_helper
INFO - 2021-12-10 03:12:22 --> Helper loaded: form_helper
INFO - 2021-12-10 03:12:22 --> Helper loaded: my_helper
INFO - 2021-12-10 03:12:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:12:22 --> Controller Class Initialized
DEBUG - 2021-12-10 03:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-10 03:12:22 --> Final output sent to browser
DEBUG - 2021-12-10 03:12:22 --> Total execution time: 0.0820
INFO - 2021-12-10 03:13:00 --> Config Class Initialized
INFO - 2021-12-10 03:13:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:13:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:13:00 --> Utf8 Class Initialized
INFO - 2021-12-10 03:13:00 --> URI Class Initialized
INFO - 2021-12-10 03:13:00 --> Router Class Initialized
INFO - 2021-12-10 03:13:00 --> Output Class Initialized
INFO - 2021-12-10 03:13:00 --> Security Class Initialized
DEBUG - 2021-12-10 03:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:13:00 --> Input Class Initialized
INFO - 2021-12-10 03:13:00 --> Language Class Initialized
INFO - 2021-12-10 03:13:00 --> Language Class Initialized
INFO - 2021-12-10 03:13:00 --> Config Class Initialized
INFO - 2021-12-10 03:13:00 --> Loader Class Initialized
INFO - 2021-12-10 03:13:00 --> Helper loaded: url_helper
INFO - 2021-12-10 03:13:00 --> Helper loaded: file_helper
INFO - 2021-12-10 03:13:00 --> Helper loaded: form_helper
INFO - 2021-12-10 03:13:00 --> Helper loaded: my_helper
INFO - 2021-12-10 03:13:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:13:00 --> Controller Class Initialized
DEBUG - 2021-12-10 03:13:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-10 03:13:00 --> Final output sent to browser
DEBUG - 2021-12-10 03:13:00 --> Total execution time: 0.0730
INFO - 2021-12-10 03:13:11 --> Config Class Initialized
INFO - 2021-12-10 03:13:11 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:13:11 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:13:11 --> Utf8 Class Initialized
INFO - 2021-12-10 03:13:11 --> URI Class Initialized
INFO - 2021-12-10 03:13:11 --> Router Class Initialized
INFO - 2021-12-10 03:13:11 --> Output Class Initialized
INFO - 2021-12-10 03:13:11 --> Security Class Initialized
DEBUG - 2021-12-10 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:13:11 --> Input Class Initialized
INFO - 2021-12-10 03:13:11 --> Language Class Initialized
INFO - 2021-12-10 03:13:11 --> Language Class Initialized
INFO - 2021-12-10 03:13:11 --> Config Class Initialized
INFO - 2021-12-10 03:13:11 --> Loader Class Initialized
INFO - 2021-12-10 03:13:11 --> Helper loaded: url_helper
INFO - 2021-12-10 03:13:11 --> Helper loaded: file_helper
INFO - 2021-12-10 03:13:11 --> Helper loaded: form_helper
INFO - 2021-12-10 03:13:11 --> Helper loaded: my_helper
INFO - 2021-12-10 03:13:11 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:13:11 --> Controller Class Initialized
DEBUG - 2021-12-10 03:13:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-10 03:13:12 --> Final output sent to browser
DEBUG - 2021-12-10 03:13:12 --> Total execution time: 0.0620
INFO - 2021-12-10 03:13:42 --> Config Class Initialized
INFO - 2021-12-10 03:13:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:13:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:13:42 --> Utf8 Class Initialized
INFO - 2021-12-10 03:13:42 --> URI Class Initialized
INFO - 2021-12-10 03:13:42 --> Router Class Initialized
INFO - 2021-12-10 03:13:42 --> Output Class Initialized
INFO - 2021-12-10 03:13:42 --> Security Class Initialized
DEBUG - 2021-12-10 03:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:13:42 --> Input Class Initialized
INFO - 2021-12-10 03:13:42 --> Language Class Initialized
INFO - 2021-12-10 03:13:42 --> Language Class Initialized
INFO - 2021-12-10 03:13:42 --> Config Class Initialized
INFO - 2021-12-10 03:13:42 --> Loader Class Initialized
INFO - 2021-12-10 03:13:42 --> Helper loaded: url_helper
INFO - 2021-12-10 03:13:42 --> Helper loaded: file_helper
INFO - 2021-12-10 03:13:42 --> Helper loaded: form_helper
INFO - 2021-12-10 03:13:42 --> Helper loaded: my_helper
INFO - 2021-12-10 03:13:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:13:42 --> Controller Class Initialized
INFO - 2021-12-10 03:13:42 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:13:42 --> Config Class Initialized
INFO - 2021-12-10 03:13:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:13:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:13:42 --> Utf8 Class Initialized
INFO - 2021-12-10 03:13:42 --> URI Class Initialized
INFO - 2021-12-10 03:13:42 --> Router Class Initialized
INFO - 2021-12-10 03:13:42 --> Output Class Initialized
INFO - 2021-12-10 03:13:42 --> Security Class Initialized
DEBUG - 2021-12-10 03:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:13:42 --> Input Class Initialized
INFO - 2021-12-10 03:13:42 --> Language Class Initialized
INFO - 2021-12-10 03:13:42 --> Language Class Initialized
INFO - 2021-12-10 03:13:42 --> Config Class Initialized
INFO - 2021-12-10 03:13:42 --> Loader Class Initialized
INFO - 2021-12-10 03:13:42 --> Helper loaded: url_helper
INFO - 2021-12-10 03:13:42 --> Helper loaded: file_helper
INFO - 2021-12-10 03:13:42 --> Helper loaded: form_helper
INFO - 2021-12-10 03:13:42 --> Helper loaded: my_helper
INFO - 2021-12-10 03:13:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:13:42 --> Controller Class Initialized
DEBUG - 2021-12-10 03:13:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:13:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:13:42 --> Final output sent to browser
DEBUG - 2021-12-10 03:13:42 --> Total execution time: 0.0350
INFO - 2021-12-10 03:13:47 --> Config Class Initialized
INFO - 2021-12-10 03:13:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:13:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:13:47 --> Utf8 Class Initialized
INFO - 2021-12-10 03:13:47 --> URI Class Initialized
INFO - 2021-12-10 03:13:47 --> Router Class Initialized
INFO - 2021-12-10 03:13:47 --> Output Class Initialized
INFO - 2021-12-10 03:13:47 --> Security Class Initialized
DEBUG - 2021-12-10 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:13:47 --> Input Class Initialized
INFO - 2021-12-10 03:13:47 --> Language Class Initialized
INFO - 2021-12-10 03:13:47 --> Language Class Initialized
INFO - 2021-12-10 03:13:47 --> Config Class Initialized
INFO - 2021-12-10 03:13:47 --> Loader Class Initialized
INFO - 2021-12-10 03:13:47 --> Helper loaded: url_helper
INFO - 2021-12-10 03:13:47 --> Helper loaded: file_helper
INFO - 2021-12-10 03:13:47 --> Helper loaded: form_helper
INFO - 2021-12-10 03:13:47 --> Helper loaded: my_helper
INFO - 2021-12-10 03:13:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:13:47 --> Controller Class Initialized
INFO - 2021-12-10 03:13:47 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:13:47 --> Final output sent to browser
DEBUG - 2021-12-10 03:13:47 --> Total execution time: 0.0530
INFO - 2021-12-10 03:13:47 --> Config Class Initialized
INFO - 2021-12-10 03:13:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:13:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:13:47 --> Utf8 Class Initialized
INFO - 2021-12-10 03:13:47 --> URI Class Initialized
INFO - 2021-12-10 03:13:47 --> Router Class Initialized
INFO - 2021-12-10 03:13:47 --> Output Class Initialized
INFO - 2021-12-10 03:13:47 --> Security Class Initialized
DEBUG - 2021-12-10 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:13:47 --> Input Class Initialized
INFO - 2021-12-10 03:13:47 --> Language Class Initialized
INFO - 2021-12-10 03:13:47 --> Language Class Initialized
INFO - 2021-12-10 03:13:47 --> Config Class Initialized
INFO - 2021-12-10 03:13:47 --> Loader Class Initialized
INFO - 2021-12-10 03:13:47 --> Helper loaded: url_helper
INFO - 2021-12-10 03:13:47 --> Helper loaded: file_helper
INFO - 2021-12-10 03:13:47 --> Helper loaded: form_helper
INFO - 2021-12-10 03:13:47 --> Helper loaded: my_helper
INFO - 2021-12-10 03:13:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:13:47 --> Controller Class Initialized
DEBUG - 2021-12-10 03:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:13:48 --> Final output sent to browser
DEBUG - 2021-12-10 03:13:48 --> Total execution time: 0.1980
INFO - 2021-12-10 03:14:00 --> Config Class Initialized
INFO - 2021-12-10 03:14:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:00 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:00 --> URI Class Initialized
INFO - 2021-12-10 03:14:00 --> Router Class Initialized
INFO - 2021-12-10 03:14:00 --> Output Class Initialized
INFO - 2021-12-10 03:14:00 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:00 --> Input Class Initialized
INFO - 2021-12-10 03:14:00 --> Language Class Initialized
INFO - 2021-12-10 03:14:00 --> Language Class Initialized
INFO - 2021-12-10 03:14:00 --> Config Class Initialized
INFO - 2021-12-10 03:14:00 --> Loader Class Initialized
INFO - 2021-12-10 03:14:00 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:00 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:00 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:00 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:00 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 03:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:14:00 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:00 --> Total execution time: 0.0600
INFO - 2021-12-10 03:14:00 --> Config Class Initialized
INFO - 2021-12-10 03:14:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:00 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:00 --> URI Class Initialized
INFO - 2021-12-10 03:14:00 --> Router Class Initialized
INFO - 2021-12-10 03:14:00 --> Output Class Initialized
INFO - 2021-12-10 03:14:00 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:00 --> Input Class Initialized
INFO - 2021-12-10 03:14:00 --> Language Class Initialized
INFO - 2021-12-10 03:14:00 --> Language Class Initialized
INFO - 2021-12-10 03:14:00 --> Config Class Initialized
INFO - 2021-12-10 03:14:00 --> Loader Class Initialized
INFO - 2021-12-10 03:14:00 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:00 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:00 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:00 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:00 --> Controller Class Initialized
INFO - 2021-12-10 03:14:01 --> Config Class Initialized
INFO - 2021-12-10 03:14:01 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:01 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:01 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:01 --> URI Class Initialized
INFO - 2021-12-10 03:14:01 --> Router Class Initialized
INFO - 2021-12-10 03:14:01 --> Output Class Initialized
INFO - 2021-12-10 03:14:01 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:01 --> Input Class Initialized
INFO - 2021-12-10 03:14:01 --> Language Class Initialized
INFO - 2021-12-10 03:14:01 --> Language Class Initialized
INFO - 2021-12-10 03:14:01 --> Config Class Initialized
INFO - 2021-12-10 03:14:01 --> Loader Class Initialized
INFO - 2021-12-10 03:14:01 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:01 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:01 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:01 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:01 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:01 --> Controller Class Initialized
INFO - 2021-12-10 03:14:01 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:01 --> Total execution time: 0.0590
INFO - 2021-12-10 03:14:01 --> Config Class Initialized
INFO - 2021-12-10 03:14:01 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:01 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:01 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:01 --> URI Class Initialized
INFO - 2021-12-10 03:14:01 --> Router Class Initialized
INFO - 2021-12-10 03:14:01 --> Output Class Initialized
INFO - 2021-12-10 03:14:01 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:01 --> Input Class Initialized
INFO - 2021-12-10 03:14:01 --> Language Class Initialized
INFO - 2021-12-10 03:14:01 --> Language Class Initialized
INFO - 2021-12-10 03:14:01 --> Config Class Initialized
INFO - 2021-12-10 03:14:01 --> Loader Class Initialized
INFO - 2021-12-10 03:14:01 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:01 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:01 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:01 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:01 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:01 --> Controller Class Initialized
INFO - 2021-12-10 03:14:04 --> Config Class Initialized
INFO - 2021-12-10 03:14:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:04 --> URI Class Initialized
INFO - 2021-12-10 03:14:04 --> Router Class Initialized
INFO - 2021-12-10 03:14:04 --> Output Class Initialized
INFO - 2021-12-10 03:14:04 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:04 --> Input Class Initialized
INFO - 2021-12-10 03:14:04 --> Language Class Initialized
INFO - 2021-12-10 03:14:04 --> Language Class Initialized
INFO - 2021-12-10 03:14:04 --> Config Class Initialized
INFO - 2021-12-10 03:14:04 --> Loader Class Initialized
INFO - 2021-12-10 03:14:04 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:04 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:04 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:04 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:04 --> Controller Class Initialized
INFO - 2021-12-10 03:14:04 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:14:04 --> Config Class Initialized
INFO - 2021-12-10 03:14:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:04 --> URI Class Initialized
INFO - 2021-12-10 03:14:04 --> Router Class Initialized
INFO - 2021-12-10 03:14:04 --> Output Class Initialized
INFO - 2021-12-10 03:14:04 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:04 --> Input Class Initialized
INFO - 2021-12-10 03:14:04 --> Language Class Initialized
INFO - 2021-12-10 03:14:04 --> Language Class Initialized
INFO - 2021-12-10 03:14:04 --> Config Class Initialized
INFO - 2021-12-10 03:14:04 --> Loader Class Initialized
INFO - 2021-12-10 03:14:04 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:04 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:04 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:04 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:04 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:14:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:14:04 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:04 --> Total execution time: 0.0410
INFO - 2021-12-10 03:14:26 --> Config Class Initialized
INFO - 2021-12-10 03:14:26 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:26 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:26 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:26 --> URI Class Initialized
INFO - 2021-12-10 03:14:26 --> Router Class Initialized
INFO - 2021-12-10 03:14:26 --> Output Class Initialized
INFO - 2021-12-10 03:14:26 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:26 --> Input Class Initialized
INFO - 2021-12-10 03:14:26 --> Language Class Initialized
INFO - 2021-12-10 03:14:26 --> Language Class Initialized
INFO - 2021-12-10 03:14:26 --> Config Class Initialized
INFO - 2021-12-10 03:14:26 --> Loader Class Initialized
INFO - 2021-12-10 03:14:26 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:26 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:26 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:26 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:26 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:26 --> Controller Class Initialized
INFO - 2021-12-10 03:14:26 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:14:26 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:26 --> Total execution time: 0.0540
INFO - 2021-12-10 03:14:27 --> Config Class Initialized
INFO - 2021-12-10 03:14:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:27 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:27 --> URI Class Initialized
INFO - 2021-12-10 03:14:27 --> Router Class Initialized
INFO - 2021-12-10 03:14:27 --> Output Class Initialized
INFO - 2021-12-10 03:14:27 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:27 --> Input Class Initialized
INFO - 2021-12-10 03:14:27 --> Language Class Initialized
INFO - 2021-12-10 03:14:27 --> Language Class Initialized
INFO - 2021-12-10 03:14:27 --> Config Class Initialized
INFO - 2021-12-10 03:14:27 --> Loader Class Initialized
INFO - 2021-12-10 03:14:27 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:27 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:27 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:27 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:27 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:14:27 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:27 --> Total execution time: 0.1650
INFO - 2021-12-10 03:14:29 --> Config Class Initialized
INFO - 2021-12-10 03:14:29 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:29 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:29 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:29 --> URI Class Initialized
INFO - 2021-12-10 03:14:29 --> Router Class Initialized
INFO - 2021-12-10 03:14:29 --> Output Class Initialized
INFO - 2021-12-10 03:14:29 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:29 --> Input Class Initialized
INFO - 2021-12-10 03:14:29 --> Language Class Initialized
INFO - 2021-12-10 03:14:29 --> Language Class Initialized
INFO - 2021-12-10 03:14:29 --> Config Class Initialized
INFO - 2021-12-10 03:14:29 --> Loader Class Initialized
INFO - 2021-12-10 03:14:29 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:29 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:29 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:29 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:29 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:29 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:14:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:14:29 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:29 --> Total execution time: 0.1060
INFO - 2021-12-10 03:14:33 --> Config Class Initialized
INFO - 2021-12-10 03:14:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:33 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:33 --> URI Class Initialized
INFO - 2021-12-10 03:14:33 --> Router Class Initialized
INFO - 2021-12-10 03:14:33 --> Output Class Initialized
INFO - 2021-12-10 03:14:33 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:33 --> Input Class Initialized
INFO - 2021-12-10 03:14:33 --> Language Class Initialized
INFO - 2021-12-10 03:14:33 --> Language Class Initialized
INFO - 2021-12-10 03:14:33 --> Config Class Initialized
INFO - 2021-12-10 03:14:33 --> Loader Class Initialized
INFO - 2021-12-10 03:14:33 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:33 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:33 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:33 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:33 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:14:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:14:33 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:33 --> Total execution time: 0.0620
INFO - 2021-12-10 03:14:37 --> Config Class Initialized
INFO - 2021-12-10 03:14:37 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:37 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:37 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:37 --> URI Class Initialized
INFO - 2021-12-10 03:14:37 --> Router Class Initialized
INFO - 2021-12-10 03:14:37 --> Output Class Initialized
INFO - 2021-12-10 03:14:37 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:37 --> Input Class Initialized
INFO - 2021-12-10 03:14:37 --> Language Class Initialized
INFO - 2021-12-10 03:14:37 --> Language Class Initialized
INFO - 2021-12-10 03:14:37 --> Config Class Initialized
INFO - 2021-12-10 03:14:37 --> Loader Class Initialized
INFO - 2021-12-10 03:14:37 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:37 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:37 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:37 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:37 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:37 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-10 03:14:37 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:37 --> Total execution time: 0.0950
INFO - 2021-12-10 03:14:46 --> Config Class Initialized
INFO - 2021-12-10 03:14:46 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:46 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:46 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:46 --> URI Class Initialized
INFO - 2021-12-10 03:14:46 --> Router Class Initialized
INFO - 2021-12-10 03:14:46 --> Output Class Initialized
INFO - 2021-12-10 03:14:46 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:46 --> Input Class Initialized
INFO - 2021-12-10 03:14:46 --> Language Class Initialized
INFO - 2021-12-10 03:14:46 --> Language Class Initialized
INFO - 2021-12-10 03:14:46 --> Config Class Initialized
INFO - 2021-12-10 03:14:46 --> Loader Class Initialized
INFO - 2021-12-10 03:14:46 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:46 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:46 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:46 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:47 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:14:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:14:47 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:47 --> Total execution time: 0.0950
INFO - 2021-12-10 03:14:52 --> Config Class Initialized
INFO - 2021-12-10 03:14:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:52 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:52 --> URI Class Initialized
INFO - 2021-12-10 03:14:52 --> Router Class Initialized
INFO - 2021-12-10 03:14:52 --> Output Class Initialized
INFO - 2021-12-10 03:14:52 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:52 --> Input Class Initialized
INFO - 2021-12-10 03:14:52 --> Language Class Initialized
INFO - 2021-12-10 03:14:52 --> Language Class Initialized
INFO - 2021-12-10 03:14:52 --> Config Class Initialized
INFO - 2021-12-10 03:14:52 --> Loader Class Initialized
INFO - 2021-12-10 03:14:52 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:52 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:52 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:52 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:52 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:14:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:14:52 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:52 --> Total execution time: 0.0530
INFO - 2021-12-10 03:14:55 --> Config Class Initialized
INFO - 2021-12-10 03:14:55 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:14:55 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:14:55 --> Utf8 Class Initialized
INFO - 2021-12-10 03:14:55 --> URI Class Initialized
INFO - 2021-12-10 03:14:55 --> Router Class Initialized
INFO - 2021-12-10 03:14:55 --> Output Class Initialized
INFO - 2021-12-10 03:14:55 --> Security Class Initialized
DEBUG - 2021-12-10 03:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:14:55 --> Input Class Initialized
INFO - 2021-12-10 03:14:55 --> Language Class Initialized
INFO - 2021-12-10 03:14:55 --> Language Class Initialized
INFO - 2021-12-10 03:14:55 --> Config Class Initialized
INFO - 2021-12-10 03:14:55 --> Loader Class Initialized
INFO - 2021-12-10 03:14:55 --> Helper loaded: url_helper
INFO - 2021-12-10 03:14:55 --> Helper loaded: file_helper
INFO - 2021-12-10 03:14:55 --> Helper loaded: form_helper
INFO - 2021-12-10 03:14:55 --> Helper loaded: my_helper
INFO - 2021-12-10 03:14:55 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:14:55 --> Controller Class Initialized
DEBUG - 2021-12-10 03:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-10 03:14:55 --> Final output sent to browser
DEBUG - 2021-12-10 03:14:55 --> Total execution time: 0.0630
INFO - 2021-12-10 03:17:48 --> Config Class Initialized
INFO - 2021-12-10 03:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:17:48 --> Utf8 Class Initialized
INFO - 2021-12-10 03:17:48 --> URI Class Initialized
INFO - 2021-12-10 03:17:48 --> Router Class Initialized
INFO - 2021-12-10 03:17:48 --> Output Class Initialized
INFO - 2021-12-10 03:17:48 --> Security Class Initialized
DEBUG - 2021-12-10 03:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:17:48 --> Input Class Initialized
INFO - 2021-12-10 03:17:48 --> Language Class Initialized
INFO - 2021-12-10 03:17:48 --> Language Class Initialized
INFO - 2021-12-10 03:17:48 --> Config Class Initialized
INFO - 2021-12-10 03:17:48 --> Loader Class Initialized
INFO - 2021-12-10 03:17:48 --> Helper loaded: url_helper
INFO - 2021-12-10 03:17:48 --> Helper loaded: file_helper
INFO - 2021-12-10 03:17:48 --> Helper loaded: form_helper
INFO - 2021-12-10 03:17:48 --> Helper loaded: my_helper
INFO - 2021-12-10 03:17:48 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:17:48 --> Controller Class Initialized
DEBUG - 2021-12-10 03:17:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:17:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:17:48 --> Final output sent to browser
DEBUG - 2021-12-10 03:17:48 --> Total execution time: 0.0850
INFO - 2021-12-10 03:17:52 --> Config Class Initialized
INFO - 2021-12-10 03:17:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:17:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:17:52 --> Utf8 Class Initialized
INFO - 2021-12-10 03:17:52 --> URI Class Initialized
INFO - 2021-12-10 03:17:52 --> Router Class Initialized
INFO - 2021-12-10 03:17:52 --> Output Class Initialized
INFO - 2021-12-10 03:17:52 --> Security Class Initialized
DEBUG - 2021-12-10 03:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:17:52 --> Input Class Initialized
INFO - 2021-12-10 03:17:52 --> Language Class Initialized
INFO - 2021-12-10 03:17:52 --> Language Class Initialized
INFO - 2021-12-10 03:17:52 --> Config Class Initialized
INFO - 2021-12-10 03:17:52 --> Loader Class Initialized
INFO - 2021-12-10 03:17:52 --> Helper loaded: url_helper
INFO - 2021-12-10 03:17:52 --> Helper loaded: file_helper
INFO - 2021-12-10 03:17:52 --> Helper loaded: form_helper
INFO - 2021-12-10 03:17:52 --> Helper loaded: my_helper
INFO - 2021-12-10 03:17:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:17:52 --> Controller Class Initialized
DEBUG - 2021-12-10 03:17:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:17:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:17:52 --> Final output sent to browser
DEBUG - 2021-12-10 03:17:52 --> Total execution time: 0.0530
INFO - 2021-12-10 03:17:54 --> Config Class Initialized
INFO - 2021-12-10 03:17:54 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:17:54 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:17:54 --> Utf8 Class Initialized
INFO - 2021-12-10 03:17:54 --> URI Class Initialized
INFO - 2021-12-10 03:17:54 --> Router Class Initialized
INFO - 2021-12-10 03:17:54 --> Output Class Initialized
INFO - 2021-12-10 03:17:54 --> Security Class Initialized
DEBUG - 2021-12-10 03:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:17:54 --> Input Class Initialized
INFO - 2021-12-10 03:17:54 --> Language Class Initialized
INFO - 2021-12-10 03:17:54 --> Language Class Initialized
INFO - 2021-12-10 03:17:54 --> Config Class Initialized
INFO - 2021-12-10 03:17:54 --> Loader Class Initialized
INFO - 2021-12-10 03:17:54 --> Helper loaded: url_helper
INFO - 2021-12-10 03:17:54 --> Helper loaded: file_helper
INFO - 2021-12-10 03:17:54 --> Helper loaded: form_helper
INFO - 2021-12-10 03:17:54 --> Helper loaded: my_helper
INFO - 2021-12-10 03:17:54 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:17:54 --> Controller Class Initialized
DEBUG - 2021-12-10 03:17:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-10 03:17:54 --> Final output sent to browser
DEBUG - 2021-12-10 03:17:54 --> Total execution time: 0.0690
INFO - 2021-12-10 03:19:09 --> Config Class Initialized
INFO - 2021-12-10 03:19:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:19:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:19:09 --> Utf8 Class Initialized
INFO - 2021-12-10 03:19:09 --> URI Class Initialized
INFO - 2021-12-10 03:19:09 --> Router Class Initialized
INFO - 2021-12-10 03:19:09 --> Output Class Initialized
INFO - 2021-12-10 03:19:09 --> Security Class Initialized
DEBUG - 2021-12-10 03:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:19:09 --> Input Class Initialized
INFO - 2021-12-10 03:19:09 --> Language Class Initialized
INFO - 2021-12-10 03:19:09 --> Language Class Initialized
INFO - 2021-12-10 03:19:09 --> Config Class Initialized
INFO - 2021-12-10 03:19:09 --> Loader Class Initialized
INFO - 2021-12-10 03:19:09 --> Helper loaded: url_helper
INFO - 2021-12-10 03:19:09 --> Helper loaded: file_helper
INFO - 2021-12-10 03:19:09 --> Helper loaded: form_helper
INFO - 2021-12-10 03:19:09 --> Helper loaded: my_helper
INFO - 2021-12-10 03:19:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:19:09 --> Controller Class Initialized
DEBUG - 2021-12-10 03:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:19:09 --> Final output sent to browser
DEBUG - 2021-12-10 03:19:09 --> Total execution time: 0.0980
INFO - 2021-12-10 03:19:14 --> Config Class Initialized
INFO - 2021-12-10 03:19:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:19:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:19:14 --> Utf8 Class Initialized
INFO - 2021-12-10 03:19:14 --> URI Class Initialized
INFO - 2021-12-10 03:19:14 --> Router Class Initialized
INFO - 2021-12-10 03:19:14 --> Output Class Initialized
INFO - 2021-12-10 03:19:14 --> Security Class Initialized
DEBUG - 2021-12-10 03:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:19:14 --> Input Class Initialized
INFO - 2021-12-10 03:19:14 --> Language Class Initialized
INFO - 2021-12-10 03:19:14 --> Language Class Initialized
INFO - 2021-12-10 03:19:14 --> Config Class Initialized
INFO - 2021-12-10 03:19:14 --> Loader Class Initialized
INFO - 2021-12-10 03:19:14 --> Helper loaded: url_helper
INFO - 2021-12-10 03:19:14 --> Helper loaded: file_helper
INFO - 2021-12-10 03:19:14 --> Helper loaded: form_helper
INFO - 2021-12-10 03:19:14 --> Helper loaded: my_helper
INFO - 2021-12-10 03:19:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:19:14 --> Controller Class Initialized
DEBUG - 2021-12-10 03:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:19:14 --> Final output sent to browser
DEBUG - 2021-12-10 03:19:14 --> Total execution time: 0.0700
INFO - 2021-12-10 03:19:17 --> Config Class Initialized
INFO - 2021-12-10 03:19:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:19:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:19:17 --> Utf8 Class Initialized
INFO - 2021-12-10 03:19:17 --> URI Class Initialized
INFO - 2021-12-10 03:19:17 --> Router Class Initialized
INFO - 2021-12-10 03:19:17 --> Output Class Initialized
INFO - 2021-12-10 03:19:17 --> Security Class Initialized
DEBUG - 2021-12-10 03:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:19:17 --> Input Class Initialized
INFO - 2021-12-10 03:19:17 --> Language Class Initialized
INFO - 2021-12-10 03:19:17 --> Language Class Initialized
INFO - 2021-12-10 03:19:17 --> Config Class Initialized
INFO - 2021-12-10 03:19:17 --> Loader Class Initialized
INFO - 2021-12-10 03:19:17 --> Helper loaded: url_helper
INFO - 2021-12-10 03:19:17 --> Helper loaded: file_helper
INFO - 2021-12-10 03:19:17 --> Helper loaded: form_helper
INFO - 2021-12-10 03:19:17 --> Helper loaded: my_helper
INFO - 2021-12-10 03:19:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:19:17 --> Controller Class Initialized
DEBUG - 2021-12-10 03:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-10 03:19:17 --> Final output sent to browser
DEBUG - 2021-12-10 03:19:17 --> Total execution time: 0.0620
INFO - 2021-12-10 03:20:05 --> Config Class Initialized
INFO - 2021-12-10 03:20:05 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:05 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:05 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:05 --> URI Class Initialized
INFO - 2021-12-10 03:20:05 --> Router Class Initialized
INFO - 2021-12-10 03:20:05 --> Output Class Initialized
INFO - 2021-12-10 03:20:05 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:05 --> Input Class Initialized
INFO - 2021-12-10 03:20:05 --> Language Class Initialized
INFO - 2021-12-10 03:20:05 --> Language Class Initialized
INFO - 2021-12-10 03:20:05 --> Config Class Initialized
INFO - 2021-12-10 03:20:05 --> Loader Class Initialized
INFO - 2021-12-10 03:20:05 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:05 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:05 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:05 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:05 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:05 --> Controller Class Initialized
DEBUG - 2021-12-10 03:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-10 03:20:05 --> Final output sent to browser
DEBUG - 2021-12-10 03:20:05 --> Total execution time: 0.0660
INFO - 2021-12-10 03:20:06 --> Config Class Initialized
INFO - 2021-12-10 03:20:06 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:06 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:06 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:06 --> URI Class Initialized
INFO - 2021-12-10 03:20:06 --> Router Class Initialized
INFO - 2021-12-10 03:20:06 --> Output Class Initialized
INFO - 2021-12-10 03:20:06 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:06 --> Input Class Initialized
INFO - 2021-12-10 03:20:06 --> Language Class Initialized
INFO - 2021-12-10 03:20:06 --> Language Class Initialized
INFO - 2021-12-10 03:20:06 --> Config Class Initialized
INFO - 2021-12-10 03:20:06 --> Loader Class Initialized
INFO - 2021-12-10 03:20:06 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:06 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:06 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:06 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:06 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:06 --> Controller Class Initialized
DEBUG - 2021-12-10 03:20:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-10 03:20:06 --> Final output sent to browser
DEBUG - 2021-12-10 03:20:06 --> Total execution time: 0.0710
INFO - 2021-12-10 03:20:31 --> Config Class Initialized
INFO - 2021-12-10 03:20:31 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:31 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:31 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:31 --> URI Class Initialized
DEBUG - 2021-12-10 03:20:31 --> No URI present. Default controller set.
INFO - 2021-12-10 03:20:31 --> Router Class Initialized
INFO - 2021-12-10 03:20:31 --> Output Class Initialized
INFO - 2021-12-10 03:20:31 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:31 --> Input Class Initialized
INFO - 2021-12-10 03:20:31 --> Language Class Initialized
INFO - 2021-12-10 03:20:31 --> Language Class Initialized
INFO - 2021-12-10 03:20:31 --> Config Class Initialized
INFO - 2021-12-10 03:20:31 --> Loader Class Initialized
INFO - 2021-12-10 03:20:31 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:31 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:31 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:31 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:31 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:31 --> Controller Class Initialized
DEBUG - 2021-12-10 03:20:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:20:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:20:31 --> Final output sent to browser
DEBUG - 2021-12-10 03:20:31 --> Total execution time: 0.2230
INFO - 2021-12-10 03:20:44 --> Config Class Initialized
INFO - 2021-12-10 03:20:44 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:44 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:44 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:44 --> URI Class Initialized
INFO - 2021-12-10 03:20:44 --> Router Class Initialized
INFO - 2021-12-10 03:20:44 --> Output Class Initialized
INFO - 2021-12-10 03:20:44 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:44 --> Input Class Initialized
INFO - 2021-12-10 03:20:44 --> Language Class Initialized
INFO - 2021-12-10 03:20:44 --> Language Class Initialized
INFO - 2021-12-10 03:20:44 --> Config Class Initialized
INFO - 2021-12-10 03:20:44 --> Loader Class Initialized
INFO - 2021-12-10 03:20:44 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:44 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:44 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:44 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:44 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:44 --> Controller Class Initialized
INFO - 2021-12-10 03:20:44 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:20:44 --> Config Class Initialized
INFO - 2021-12-10 03:20:44 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:44 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:44 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:44 --> URI Class Initialized
INFO - 2021-12-10 03:20:44 --> Router Class Initialized
INFO - 2021-12-10 03:20:44 --> Output Class Initialized
INFO - 2021-12-10 03:20:44 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:44 --> Input Class Initialized
INFO - 2021-12-10 03:20:44 --> Language Class Initialized
INFO - 2021-12-10 03:20:44 --> Language Class Initialized
INFO - 2021-12-10 03:20:44 --> Config Class Initialized
INFO - 2021-12-10 03:20:44 --> Loader Class Initialized
INFO - 2021-12-10 03:20:44 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:44 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:44 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:44 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:44 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:44 --> Controller Class Initialized
DEBUG - 2021-12-10 03:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:20:44 --> Final output sent to browser
DEBUG - 2021-12-10 03:20:44 --> Total execution time: 0.0420
INFO - 2021-12-10 03:20:49 --> Config Class Initialized
INFO - 2021-12-10 03:20:49 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:49 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:49 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:49 --> URI Class Initialized
INFO - 2021-12-10 03:20:49 --> Router Class Initialized
INFO - 2021-12-10 03:20:49 --> Output Class Initialized
INFO - 2021-12-10 03:20:49 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:49 --> Input Class Initialized
INFO - 2021-12-10 03:20:49 --> Language Class Initialized
INFO - 2021-12-10 03:20:49 --> Language Class Initialized
INFO - 2021-12-10 03:20:49 --> Config Class Initialized
INFO - 2021-12-10 03:20:49 --> Loader Class Initialized
INFO - 2021-12-10 03:20:49 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:49 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:49 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:49 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:49 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:49 --> Controller Class Initialized
INFO - 2021-12-10 03:20:49 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:20:49 --> Final output sent to browser
DEBUG - 2021-12-10 03:20:49 --> Total execution time: 0.0530
INFO - 2021-12-10 03:20:50 --> Config Class Initialized
INFO - 2021-12-10 03:20:50 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:50 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:50 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:50 --> URI Class Initialized
INFO - 2021-12-10 03:20:50 --> Router Class Initialized
INFO - 2021-12-10 03:20:50 --> Output Class Initialized
INFO - 2021-12-10 03:20:50 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:50 --> Input Class Initialized
INFO - 2021-12-10 03:20:50 --> Language Class Initialized
INFO - 2021-12-10 03:20:50 --> Language Class Initialized
INFO - 2021-12-10 03:20:50 --> Config Class Initialized
INFO - 2021-12-10 03:20:50 --> Loader Class Initialized
INFO - 2021-12-10 03:20:50 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:50 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:50 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:50 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:50 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:50 --> Controller Class Initialized
DEBUG - 2021-12-10 03:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:20:50 --> Final output sent to browser
DEBUG - 2021-12-10 03:20:50 --> Total execution time: 0.1510
INFO - 2021-12-10 03:20:52 --> Config Class Initialized
INFO - 2021-12-10 03:20:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:52 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:52 --> URI Class Initialized
INFO - 2021-12-10 03:20:52 --> Router Class Initialized
INFO - 2021-12-10 03:20:52 --> Output Class Initialized
INFO - 2021-12-10 03:20:52 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:52 --> Input Class Initialized
INFO - 2021-12-10 03:20:52 --> Language Class Initialized
INFO - 2021-12-10 03:20:52 --> Language Class Initialized
INFO - 2021-12-10 03:20:52 --> Config Class Initialized
INFO - 2021-12-10 03:20:52 --> Loader Class Initialized
INFO - 2021-12-10 03:20:52 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:52 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:52 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:52 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:52 --> Controller Class Initialized
DEBUG - 2021-12-10 03:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:20:52 --> Final output sent to browser
DEBUG - 2021-12-10 03:20:52 --> Total execution time: 0.1050
INFO - 2021-12-10 03:20:57 --> Config Class Initialized
INFO - 2021-12-10 03:20:57 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:20:57 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:20:57 --> Utf8 Class Initialized
INFO - 2021-12-10 03:20:57 --> URI Class Initialized
INFO - 2021-12-10 03:20:57 --> Router Class Initialized
INFO - 2021-12-10 03:20:57 --> Output Class Initialized
INFO - 2021-12-10 03:20:57 --> Security Class Initialized
DEBUG - 2021-12-10 03:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:20:57 --> Input Class Initialized
INFO - 2021-12-10 03:20:57 --> Language Class Initialized
INFO - 2021-12-10 03:20:57 --> Language Class Initialized
INFO - 2021-12-10 03:20:57 --> Config Class Initialized
INFO - 2021-12-10 03:20:57 --> Loader Class Initialized
INFO - 2021-12-10 03:20:57 --> Helper loaded: url_helper
INFO - 2021-12-10 03:20:57 --> Helper loaded: file_helper
INFO - 2021-12-10 03:20:57 --> Helper loaded: form_helper
INFO - 2021-12-10 03:20:57 --> Helper loaded: my_helper
INFO - 2021-12-10 03:20:57 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:20:57 --> Controller Class Initialized
DEBUG - 2021-12-10 03:20:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:20:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:20:57 --> Final output sent to browser
DEBUG - 2021-12-10 03:20:57 --> Total execution time: 0.0510
INFO - 2021-12-10 03:21:00 --> Config Class Initialized
INFO - 2021-12-10 03:21:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:21:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:21:00 --> Utf8 Class Initialized
INFO - 2021-12-10 03:21:00 --> URI Class Initialized
INFO - 2021-12-10 03:21:00 --> Router Class Initialized
INFO - 2021-12-10 03:21:00 --> Output Class Initialized
INFO - 2021-12-10 03:21:00 --> Security Class Initialized
DEBUG - 2021-12-10 03:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:21:00 --> Input Class Initialized
INFO - 2021-12-10 03:21:00 --> Language Class Initialized
INFO - 2021-12-10 03:21:00 --> Language Class Initialized
INFO - 2021-12-10 03:21:00 --> Config Class Initialized
INFO - 2021-12-10 03:21:00 --> Loader Class Initialized
INFO - 2021-12-10 03:21:00 --> Helper loaded: url_helper
INFO - 2021-12-10 03:21:00 --> Helper loaded: file_helper
INFO - 2021-12-10 03:21:00 --> Helper loaded: form_helper
INFO - 2021-12-10 03:21:00 --> Helper loaded: my_helper
INFO - 2021-12-10 03:21:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:21:00 --> Controller Class Initialized
DEBUG - 2021-12-10 03:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-10 03:21:00 --> Final output sent to browser
DEBUG - 2021-12-10 03:21:00 --> Total execution time: 0.0880
INFO - 2021-12-10 03:21:01 --> Config Class Initialized
INFO - 2021-12-10 03:21:01 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:21:01 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:21:01 --> Utf8 Class Initialized
INFO - 2021-12-10 03:21:01 --> URI Class Initialized
INFO - 2021-12-10 03:21:01 --> Router Class Initialized
INFO - 2021-12-10 03:21:01 --> Output Class Initialized
INFO - 2021-12-10 03:21:01 --> Security Class Initialized
DEBUG - 2021-12-10 03:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:21:01 --> Input Class Initialized
INFO - 2021-12-10 03:21:01 --> Language Class Initialized
INFO - 2021-12-10 03:21:01 --> Language Class Initialized
INFO - 2021-12-10 03:21:01 --> Config Class Initialized
INFO - 2021-12-10 03:21:01 --> Loader Class Initialized
INFO - 2021-12-10 03:21:01 --> Helper loaded: url_helper
INFO - 2021-12-10 03:21:01 --> Helper loaded: file_helper
INFO - 2021-12-10 03:21:01 --> Helper loaded: form_helper
INFO - 2021-12-10 03:21:01 --> Helper loaded: my_helper
INFO - 2021-12-10 03:21:01 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:21:01 --> Controller Class Initialized
DEBUG - 2021-12-10 03:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-10 03:21:01 --> Final output sent to browser
DEBUG - 2021-12-10 03:21:01 --> Total execution time: 0.0680
INFO - 2021-12-10 03:21:21 --> Config Class Initialized
INFO - 2021-12-10 03:21:21 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:21:21 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:21:21 --> Utf8 Class Initialized
INFO - 2021-12-10 03:21:21 --> URI Class Initialized
INFO - 2021-12-10 03:21:21 --> Router Class Initialized
INFO - 2021-12-10 03:21:21 --> Output Class Initialized
INFO - 2021-12-10 03:21:21 --> Security Class Initialized
DEBUG - 2021-12-10 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:21:21 --> Input Class Initialized
INFO - 2021-12-10 03:21:21 --> Language Class Initialized
INFO - 2021-12-10 03:21:21 --> Language Class Initialized
INFO - 2021-12-10 03:21:21 --> Config Class Initialized
INFO - 2021-12-10 03:21:21 --> Loader Class Initialized
INFO - 2021-12-10 03:21:21 --> Helper loaded: url_helper
INFO - 2021-12-10 03:21:21 --> Helper loaded: file_helper
INFO - 2021-12-10 03:21:21 --> Helper loaded: form_helper
INFO - 2021-12-10 03:21:21 --> Helper loaded: my_helper
INFO - 2021-12-10 03:21:21 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:21:21 --> Controller Class Initialized
DEBUG - 2021-12-10 03:21:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-10 03:21:21 --> Final output sent to browser
DEBUG - 2021-12-10 03:21:21 --> Total execution time: 0.0650
INFO - 2021-12-10 03:21:33 --> Config Class Initialized
INFO - 2021-12-10 03:21:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:21:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:21:33 --> Utf8 Class Initialized
INFO - 2021-12-10 03:21:33 --> URI Class Initialized
INFO - 2021-12-10 03:21:33 --> Router Class Initialized
INFO - 2021-12-10 03:21:33 --> Output Class Initialized
INFO - 2021-12-10 03:21:33 --> Security Class Initialized
DEBUG - 2021-12-10 03:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:21:33 --> Input Class Initialized
INFO - 2021-12-10 03:21:33 --> Language Class Initialized
INFO - 2021-12-10 03:21:33 --> Language Class Initialized
INFO - 2021-12-10 03:21:33 --> Config Class Initialized
INFO - 2021-12-10 03:21:33 --> Loader Class Initialized
INFO - 2021-12-10 03:21:33 --> Helper loaded: url_helper
INFO - 2021-12-10 03:21:33 --> Helper loaded: file_helper
INFO - 2021-12-10 03:21:33 --> Helper loaded: form_helper
INFO - 2021-12-10 03:21:33 --> Helper loaded: my_helper
INFO - 2021-12-10 03:21:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:21:33 --> Controller Class Initialized
DEBUG - 2021-12-10 03:21:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-10 03:21:33 --> Final output sent to browser
DEBUG - 2021-12-10 03:21:33 --> Total execution time: 0.0690
INFO - 2021-12-10 03:21:39 --> Config Class Initialized
INFO - 2021-12-10 03:21:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:21:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:21:39 --> Utf8 Class Initialized
INFO - 2021-12-10 03:21:39 --> URI Class Initialized
INFO - 2021-12-10 03:21:39 --> Router Class Initialized
INFO - 2021-12-10 03:21:39 --> Output Class Initialized
INFO - 2021-12-10 03:21:39 --> Security Class Initialized
DEBUG - 2021-12-10 03:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:21:39 --> Input Class Initialized
INFO - 2021-12-10 03:21:39 --> Language Class Initialized
INFO - 2021-12-10 03:21:39 --> Language Class Initialized
INFO - 2021-12-10 03:21:39 --> Config Class Initialized
INFO - 2021-12-10 03:21:39 --> Loader Class Initialized
INFO - 2021-12-10 03:21:39 --> Helper loaded: url_helper
INFO - 2021-12-10 03:21:39 --> Helper loaded: file_helper
INFO - 2021-12-10 03:21:39 --> Helper loaded: form_helper
INFO - 2021-12-10 03:21:39 --> Helper loaded: my_helper
INFO - 2021-12-10 03:21:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:21:39 --> Controller Class Initialized
DEBUG - 2021-12-10 03:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-10 03:21:39 --> Final output sent to browser
DEBUG - 2021-12-10 03:21:39 --> Total execution time: 0.0710
INFO - 2021-12-10 03:22:07 --> Config Class Initialized
INFO - 2021-12-10 03:22:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:22:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:22:07 --> Utf8 Class Initialized
INFO - 2021-12-10 03:22:07 --> URI Class Initialized
INFO - 2021-12-10 03:22:07 --> Router Class Initialized
INFO - 2021-12-10 03:22:07 --> Output Class Initialized
INFO - 2021-12-10 03:22:07 --> Security Class Initialized
DEBUG - 2021-12-10 03:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:22:07 --> Input Class Initialized
INFO - 2021-12-10 03:22:07 --> Language Class Initialized
INFO - 2021-12-10 03:22:07 --> Language Class Initialized
INFO - 2021-12-10 03:22:07 --> Config Class Initialized
INFO - 2021-12-10 03:22:07 --> Loader Class Initialized
INFO - 2021-12-10 03:22:07 --> Helper loaded: url_helper
INFO - 2021-12-10 03:22:07 --> Helper loaded: file_helper
INFO - 2021-12-10 03:22:07 --> Helper loaded: form_helper
INFO - 2021-12-10 03:22:07 --> Helper loaded: my_helper
INFO - 2021-12-10 03:22:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:22:07 --> Controller Class Initialized
INFO - 2021-12-10 03:22:07 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:22:07 --> Config Class Initialized
INFO - 2021-12-10 03:22:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:22:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:22:07 --> Utf8 Class Initialized
INFO - 2021-12-10 03:22:07 --> URI Class Initialized
INFO - 2021-12-10 03:22:07 --> Router Class Initialized
INFO - 2021-12-10 03:22:07 --> Output Class Initialized
INFO - 2021-12-10 03:22:07 --> Security Class Initialized
DEBUG - 2021-12-10 03:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:22:07 --> Input Class Initialized
INFO - 2021-12-10 03:22:07 --> Language Class Initialized
INFO - 2021-12-10 03:22:07 --> Language Class Initialized
INFO - 2021-12-10 03:22:07 --> Config Class Initialized
INFO - 2021-12-10 03:22:07 --> Loader Class Initialized
INFO - 2021-12-10 03:22:07 --> Helper loaded: url_helper
INFO - 2021-12-10 03:22:07 --> Helper loaded: file_helper
INFO - 2021-12-10 03:22:07 --> Helper loaded: form_helper
INFO - 2021-12-10 03:22:07 --> Helper loaded: my_helper
INFO - 2021-12-10 03:22:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:22:07 --> Controller Class Initialized
DEBUG - 2021-12-10 03:22:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:22:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:22:07 --> Final output sent to browser
DEBUG - 2021-12-10 03:22:07 --> Total execution time: 0.0380
INFO - 2021-12-10 03:22:13 --> Config Class Initialized
INFO - 2021-12-10 03:22:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:22:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:22:13 --> Utf8 Class Initialized
INFO - 2021-12-10 03:22:13 --> URI Class Initialized
INFO - 2021-12-10 03:22:13 --> Router Class Initialized
INFO - 2021-12-10 03:22:13 --> Output Class Initialized
INFO - 2021-12-10 03:22:13 --> Security Class Initialized
DEBUG - 2021-12-10 03:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:22:13 --> Input Class Initialized
INFO - 2021-12-10 03:22:13 --> Language Class Initialized
INFO - 2021-12-10 03:22:13 --> Language Class Initialized
INFO - 2021-12-10 03:22:13 --> Config Class Initialized
INFO - 2021-12-10 03:22:13 --> Loader Class Initialized
INFO - 2021-12-10 03:22:13 --> Helper loaded: url_helper
INFO - 2021-12-10 03:22:13 --> Helper loaded: file_helper
INFO - 2021-12-10 03:22:13 --> Helper loaded: form_helper
INFO - 2021-12-10 03:22:13 --> Helper loaded: my_helper
INFO - 2021-12-10 03:22:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:22:13 --> Controller Class Initialized
INFO - 2021-12-10 03:22:13 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:22:13 --> Final output sent to browser
DEBUG - 2021-12-10 03:22:13 --> Total execution time: 0.0490
INFO - 2021-12-10 03:22:13 --> Config Class Initialized
INFO - 2021-12-10 03:22:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:22:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:22:13 --> Utf8 Class Initialized
INFO - 2021-12-10 03:22:13 --> URI Class Initialized
INFO - 2021-12-10 03:22:13 --> Router Class Initialized
INFO - 2021-12-10 03:22:13 --> Output Class Initialized
INFO - 2021-12-10 03:22:13 --> Security Class Initialized
DEBUG - 2021-12-10 03:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:22:13 --> Input Class Initialized
INFO - 2021-12-10 03:22:13 --> Language Class Initialized
INFO - 2021-12-10 03:22:13 --> Language Class Initialized
INFO - 2021-12-10 03:22:13 --> Config Class Initialized
INFO - 2021-12-10 03:22:13 --> Loader Class Initialized
INFO - 2021-12-10 03:22:13 --> Helper loaded: url_helper
INFO - 2021-12-10 03:22:13 --> Helper loaded: file_helper
INFO - 2021-12-10 03:22:13 --> Helper loaded: form_helper
INFO - 2021-12-10 03:22:13 --> Helper loaded: my_helper
INFO - 2021-12-10 03:22:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:22:13 --> Controller Class Initialized
DEBUG - 2021-12-10 03:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:22:14 --> Final output sent to browser
DEBUG - 2021-12-10 03:22:14 --> Total execution time: 0.2260
INFO - 2021-12-10 03:28:03 --> Config Class Initialized
INFO - 2021-12-10 03:28:03 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:03 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:03 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:03 --> URI Class Initialized
INFO - 2021-12-10 03:28:03 --> Router Class Initialized
INFO - 2021-12-10 03:28:03 --> Output Class Initialized
INFO - 2021-12-10 03:28:03 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:03 --> Input Class Initialized
INFO - 2021-12-10 03:28:03 --> Language Class Initialized
INFO - 2021-12-10 03:28:03 --> Language Class Initialized
INFO - 2021-12-10 03:28:03 --> Config Class Initialized
INFO - 2021-12-10 03:28:03 --> Loader Class Initialized
INFO - 2021-12-10 03:28:03 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:03 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:03 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:03 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:03 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:03 --> Controller Class Initialized
DEBUG - 2021-12-10 03:28:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 03:28:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:28:03 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:03 --> Total execution time: 0.0480
INFO - 2021-12-10 03:28:03 --> Config Class Initialized
INFO - 2021-12-10 03:28:03 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:03 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:03 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:03 --> URI Class Initialized
INFO - 2021-12-10 03:28:03 --> Router Class Initialized
INFO - 2021-12-10 03:28:03 --> Output Class Initialized
INFO - 2021-12-10 03:28:03 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:03 --> Input Class Initialized
INFO - 2021-12-10 03:28:03 --> Language Class Initialized
INFO - 2021-12-10 03:28:03 --> Language Class Initialized
INFO - 2021-12-10 03:28:03 --> Config Class Initialized
INFO - 2021-12-10 03:28:03 --> Loader Class Initialized
INFO - 2021-12-10 03:28:03 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:03 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:03 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:03 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:03 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:03 --> Controller Class Initialized
INFO - 2021-12-10 03:28:06 --> Config Class Initialized
INFO - 2021-12-10 03:28:06 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:06 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:06 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:06 --> URI Class Initialized
INFO - 2021-12-10 03:28:06 --> Router Class Initialized
INFO - 2021-12-10 03:28:06 --> Output Class Initialized
INFO - 2021-12-10 03:28:06 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:06 --> Input Class Initialized
INFO - 2021-12-10 03:28:06 --> Language Class Initialized
INFO - 2021-12-10 03:28:06 --> Language Class Initialized
INFO - 2021-12-10 03:28:06 --> Config Class Initialized
INFO - 2021-12-10 03:28:06 --> Loader Class Initialized
INFO - 2021-12-10 03:28:06 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:06 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:06 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:06 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:06 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:06 --> Controller Class Initialized
INFO - 2021-12-10 03:28:06 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:06 --> Total execution time: 0.0490
INFO - 2021-12-10 03:28:06 --> Config Class Initialized
INFO - 2021-12-10 03:28:06 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:06 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:06 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:06 --> URI Class Initialized
INFO - 2021-12-10 03:28:06 --> Router Class Initialized
INFO - 2021-12-10 03:28:06 --> Output Class Initialized
INFO - 2021-12-10 03:28:06 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:06 --> Input Class Initialized
INFO - 2021-12-10 03:28:06 --> Language Class Initialized
INFO - 2021-12-10 03:28:06 --> Language Class Initialized
INFO - 2021-12-10 03:28:06 --> Config Class Initialized
INFO - 2021-12-10 03:28:06 --> Loader Class Initialized
INFO - 2021-12-10 03:28:06 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:06 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:06 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:06 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:06 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:06 --> Controller Class Initialized
INFO - 2021-12-10 03:28:08 --> Config Class Initialized
INFO - 2021-12-10 03:28:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:08 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:08 --> URI Class Initialized
INFO - 2021-12-10 03:28:08 --> Router Class Initialized
INFO - 2021-12-10 03:28:08 --> Output Class Initialized
INFO - 2021-12-10 03:28:08 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:08 --> Input Class Initialized
INFO - 2021-12-10 03:28:08 --> Language Class Initialized
INFO - 2021-12-10 03:28:08 --> Language Class Initialized
INFO - 2021-12-10 03:28:08 --> Config Class Initialized
INFO - 2021-12-10 03:28:08 --> Loader Class Initialized
INFO - 2021-12-10 03:28:08 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:08 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:08 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:08 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:08 --> Controller Class Initialized
INFO - 2021-12-10 03:28:08 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:28:08 --> Config Class Initialized
INFO - 2021-12-10 03:28:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:08 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:08 --> URI Class Initialized
INFO - 2021-12-10 03:28:08 --> Router Class Initialized
INFO - 2021-12-10 03:28:08 --> Output Class Initialized
INFO - 2021-12-10 03:28:08 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:08 --> Input Class Initialized
INFO - 2021-12-10 03:28:08 --> Language Class Initialized
INFO - 2021-12-10 03:28:08 --> Language Class Initialized
INFO - 2021-12-10 03:28:08 --> Config Class Initialized
INFO - 2021-12-10 03:28:08 --> Loader Class Initialized
INFO - 2021-12-10 03:28:08 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:08 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:08 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:08 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:08 --> Controller Class Initialized
DEBUG - 2021-12-10 03:28:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:28:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:28:08 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:08 --> Total execution time: 0.0350
INFO - 2021-12-10 03:28:17 --> Config Class Initialized
INFO - 2021-12-10 03:28:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:17 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:17 --> URI Class Initialized
INFO - 2021-12-10 03:28:17 --> Router Class Initialized
INFO - 2021-12-10 03:28:17 --> Output Class Initialized
INFO - 2021-12-10 03:28:17 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:17 --> Input Class Initialized
INFO - 2021-12-10 03:28:17 --> Language Class Initialized
INFO - 2021-12-10 03:28:17 --> Language Class Initialized
INFO - 2021-12-10 03:28:17 --> Config Class Initialized
INFO - 2021-12-10 03:28:17 --> Loader Class Initialized
INFO - 2021-12-10 03:28:17 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:17 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:17 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:17 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:17 --> Controller Class Initialized
INFO - 2021-12-10 03:28:17 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:28:17 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:17 --> Total execution time: 0.0590
INFO - 2021-12-10 03:28:18 --> Config Class Initialized
INFO - 2021-12-10 03:28:18 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:18 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:18 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:18 --> URI Class Initialized
INFO - 2021-12-10 03:28:18 --> Router Class Initialized
INFO - 2021-12-10 03:28:18 --> Output Class Initialized
INFO - 2021-12-10 03:28:18 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:18 --> Input Class Initialized
INFO - 2021-12-10 03:28:18 --> Language Class Initialized
INFO - 2021-12-10 03:28:18 --> Language Class Initialized
INFO - 2021-12-10 03:28:18 --> Config Class Initialized
INFO - 2021-12-10 03:28:18 --> Loader Class Initialized
INFO - 2021-12-10 03:28:18 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:18 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:18 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:18 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:18 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:18 --> Controller Class Initialized
DEBUG - 2021-12-10 03:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:28:18 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:18 --> Total execution time: 0.6400
INFO - 2021-12-10 03:28:20 --> Config Class Initialized
INFO - 2021-12-10 03:28:20 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:20 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:20 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:20 --> URI Class Initialized
INFO - 2021-12-10 03:28:20 --> Router Class Initialized
INFO - 2021-12-10 03:28:20 --> Output Class Initialized
INFO - 2021-12-10 03:28:20 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:20 --> Input Class Initialized
INFO - 2021-12-10 03:28:20 --> Language Class Initialized
INFO - 2021-12-10 03:28:20 --> Language Class Initialized
INFO - 2021-12-10 03:28:20 --> Config Class Initialized
INFO - 2021-12-10 03:28:20 --> Loader Class Initialized
INFO - 2021-12-10 03:28:20 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:20 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:20 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:20 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:20 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:20 --> Controller Class Initialized
DEBUG - 2021-12-10 03:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:28:20 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:20 --> Total execution time: 0.1110
INFO - 2021-12-10 03:28:34 --> Config Class Initialized
INFO - 2021-12-10 03:28:34 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:34 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:34 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:34 --> URI Class Initialized
INFO - 2021-12-10 03:28:34 --> Router Class Initialized
INFO - 2021-12-10 03:28:34 --> Output Class Initialized
INFO - 2021-12-10 03:28:34 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:34 --> Input Class Initialized
INFO - 2021-12-10 03:28:34 --> Language Class Initialized
INFO - 2021-12-10 03:28:34 --> Language Class Initialized
INFO - 2021-12-10 03:28:34 --> Config Class Initialized
INFO - 2021-12-10 03:28:34 --> Loader Class Initialized
INFO - 2021-12-10 03:28:34 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:34 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:34 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:34 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:34 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:34 --> Controller Class Initialized
DEBUG - 2021-12-10 03:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:28:34 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:34 --> Total execution time: 0.0690
INFO - 2021-12-10 03:28:49 --> Config Class Initialized
INFO - 2021-12-10 03:28:49 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:49 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:49 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:49 --> URI Class Initialized
INFO - 2021-12-10 03:28:49 --> Router Class Initialized
INFO - 2021-12-10 03:28:49 --> Output Class Initialized
INFO - 2021-12-10 03:28:49 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:49 --> Input Class Initialized
INFO - 2021-12-10 03:28:49 --> Language Class Initialized
INFO - 2021-12-10 03:28:49 --> Language Class Initialized
INFO - 2021-12-10 03:28:49 --> Config Class Initialized
INFO - 2021-12-10 03:28:49 --> Loader Class Initialized
INFO - 2021-12-10 03:28:49 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:49 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:49 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:49 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:49 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:49 --> Controller Class Initialized
DEBUG - 2021-12-10 03:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-10 03:28:49 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:49 --> Total execution time: 0.1740
INFO - 2021-12-10 03:28:51 --> Config Class Initialized
INFO - 2021-12-10 03:28:51 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:28:51 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:28:51 --> Utf8 Class Initialized
INFO - 2021-12-10 03:28:51 --> URI Class Initialized
INFO - 2021-12-10 03:28:51 --> Router Class Initialized
INFO - 2021-12-10 03:28:51 --> Output Class Initialized
INFO - 2021-12-10 03:28:51 --> Security Class Initialized
DEBUG - 2021-12-10 03:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:28:51 --> Input Class Initialized
INFO - 2021-12-10 03:28:51 --> Language Class Initialized
INFO - 2021-12-10 03:28:51 --> Language Class Initialized
INFO - 2021-12-10 03:28:51 --> Config Class Initialized
INFO - 2021-12-10 03:28:51 --> Loader Class Initialized
INFO - 2021-12-10 03:28:51 --> Helper loaded: url_helper
INFO - 2021-12-10 03:28:51 --> Helper loaded: file_helper
INFO - 2021-12-10 03:28:51 --> Helper loaded: form_helper
INFO - 2021-12-10 03:28:51 --> Helper loaded: my_helper
INFO - 2021-12-10 03:28:51 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:28:51 --> Controller Class Initialized
DEBUG - 2021-12-10 03:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-10 03:28:51 --> Final output sent to browser
DEBUG - 2021-12-10 03:28:51 --> Total execution time: 0.1540
INFO - 2021-12-10 03:31:36 --> Config Class Initialized
INFO - 2021-12-10 03:31:36 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:31:36 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:31:36 --> Utf8 Class Initialized
INFO - 2021-12-10 03:31:36 --> URI Class Initialized
INFO - 2021-12-10 03:31:37 --> Router Class Initialized
INFO - 2021-12-10 03:31:37 --> Output Class Initialized
INFO - 2021-12-10 03:31:37 --> Security Class Initialized
DEBUG - 2021-12-10 03:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:31:37 --> Input Class Initialized
INFO - 2021-12-10 03:31:37 --> Language Class Initialized
INFO - 2021-12-10 03:31:37 --> Language Class Initialized
INFO - 2021-12-10 03:31:37 --> Config Class Initialized
INFO - 2021-12-10 03:31:37 --> Loader Class Initialized
INFO - 2021-12-10 03:31:37 --> Helper loaded: url_helper
INFO - 2021-12-10 03:31:37 --> Helper loaded: file_helper
INFO - 2021-12-10 03:31:37 --> Helper loaded: form_helper
INFO - 2021-12-10 03:31:37 --> Helper loaded: my_helper
INFO - 2021-12-10 03:31:37 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:31:37 --> Controller Class Initialized
DEBUG - 2021-12-10 03:31:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-10 03:31:37 --> Final output sent to browser
DEBUG - 2021-12-10 03:31:37 --> Total execution time: 0.1390
INFO - 2021-12-10 03:31:53 --> Config Class Initialized
INFO - 2021-12-10 03:31:53 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:31:53 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:31:53 --> Utf8 Class Initialized
INFO - 2021-12-10 03:31:53 --> URI Class Initialized
INFO - 2021-12-10 03:31:53 --> Router Class Initialized
INFO - 2021-12-10 03:31:53 --> Output Class Initialized
INFO - 2021-12-10 03:31:53 --> Security Class Initialized
DEBUG - 2021-12-10 03:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:31:53 --> Input Class Initialized
INFO - 2021-12-10 03:31:53 --> Language Class Initialized
INFO - 2021-12-10 03:31:53 --> Language Class Initialized
INFO - 2021-12-10 03:31:53 --> Config Class Initialized
INFO - 2021-12-10 03:31:53 --> Loader Class Initialized
INFO - 2021-12-10 03:31:53 --> Helper loaded: url_helper
INFO - 2021-12-10 03:31:53 --> Helper loaded: file_helper
INFO - 2021-12-10 03:31:53 --> Helper loaded: form_helper
INFO - 2021-12-10 03:31:53 --> Helper loaded: my_helper
INFO - 2021-12-10 03:31:53 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:31:53 --> Controller Class Initialized
DEBUG - 2021-12-10 03:31:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-10 03:31:53 --> Final output sent to browser
DEBUG - 2021-12-10 03:31:53 --> Total execution time: 0.1220
INFO - 2021-12-10 03:32:47 --> Config Class Initialized
INFO - 2021-12-10 03:32:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:32:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:32:47 --> Utf8 Class Initialized
INFO - 2021-12-10 03:32:47 --> URI Class Initialized
INFO - 2021-12-10 03:32:47 --> Router Class Initialized
INFO - 2021-12-10 03:32:47 --> Output Class Initialized
INFO - 2021-12-10 03:32:47 --> Security Class Initialized
DEBUG - 2021-12-10 03:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:32:47 --> Input Class Initialized
INFO - 2021-12-10 03:32:47 --> Language Class Initialized
INFO - 2021-12-10 03:32:47 --> Language Class Initialized
INFO - 2021-12-10 03:32:47 --> Config Class Initialized
INFO - 2021-12-10 03:32:47 --> Loader Class Initialized
INFO - 2021-12-10 03:32:47 --> Helper loaded: url_helper
INFO - 2021-12-10 03:32:47 --> Helper loaded: file_helper
INFO - 2021-12-10 03:32:47 --> Helper loaded: form_helper
INFO - 2021-12-10 03:32:47 --> Helper loaded: my_helper
INFO - 2021-12-10 03:32:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:32:47 --> Controller Class Initialized
INFO - 2021-12-10 03:32:47 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:32:47 --> Config Class Initialized
INFO - 2021-12-10 03:32:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:32:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:32:47 --> Utf8 Class Initialized
INFO - 2021-12-10 03:32:47 --> URI Class Initialized
INFO - 2021-12-10 03:32:47 --> Router Class Initialized
INFO - 2021-12-10 03:32:47 --> Output Class Initialized
INFO - 2021-12-10 03:32:47 --> Security Class Initialized
DEBUG - 2021-12-10 03:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:32:47 --> Input Class Initialized
INFO - 2021-12-10 03:32:47 --> Language Class Initialized
INFO - 2021-12-10 03:32:47 --> Language Class Initialized
INFO - 2021-12-10 03:32:47 --> Config Class Initialized
INFO - 2021-12-10 03:32:47 --> Loader Class Initialized
INFO - 2021-12-10 03:32:47 --> Helper loaded: url_helper
INFO - 2021-12-10 03:32:47 --> Helper loaded: file_helper
INFO - 2021-12-10 03:32:47 --> Helper loaded: form_helper
INFO - 2021-12-10 03:32:47 --> Helper loaded: my_helper
INFO - 2021-12-10 03:32:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:32:47 --> Controller Class Initialized
DEBUG - 2021-12-10 03:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:32:47 --> Final output sent to browser
DEBUG - 2021-12-10 03:32:47 --> Total execution time: 0.0420
INFO - 2021-12-10 03:33:00 --> Config Class Initialized
INFO - 2021-12-10 03:33:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:00 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:00 --> URI Class Initialized
INFO - 2021-12-10 03:33:00 --> Router Class Initialized
INFO - 2021-12-10 03:33:00 --> Output Class Initialized
INFO - 2021-12-10 03:33:00 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:00 --> Input Class Initialized
INFO - 2021-12-10 03:33:00 --> Language Class Initialized
INFO - 2021-12-10 03:33:00 --> Language Class Initialized
INFO - 2021-12-10 03:33:00 --> Config Class Initialized
INFO - 2021-12-10 03:33:00 --> Loader Class Initialized
INFO - 2021-12-10 03:33:00 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:00 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:00 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:00 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:00 --> Controller Class Initialized
INFO - 2021-12-10 03:33:00 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:33:00 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:00 --> Total execution time: 0.0510
INFO - 2021-12-10 03:33:01 --> Config Class Initialized
INFO - 2021-12-10 03:33:01 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:01 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:01 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:01 --> URI Class Initialized
INFO - 2021-12-10 03:33:01 --> Router Class Initialized
INFO - 2021-12-10 03:33:01 --> Output Class Initialized
INFO - 2021-12-10 03:33:01 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:01 --> Input Class Initialized
INFO - 2021-12-10 03:33:01 --> Language Class Initialized
INFO - 2021-12-10 03:33:01 --> Language Class Initialized
INFO - 2021-12-10 03:33:01 --> Config Class Initialized
INFO - 2021-12-10 03:33:01 --> Loader Class Initialized
INFO - 2021-12-10 03:33:01 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:01 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:01 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:01 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:01 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:01 --> Controller Class Initialized
DEBUG - 2021-12-10 03:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:33:01 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:01 --> Total execution time: 0.7390
INFO - 2021-12-10 03:33:04 --> Config Class Initialized
INFO - 2021-12-10 03:33:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:04 --> URI Class Initialized
INFO - 2021-12-10 03:33:04 --> Router Class Initialized
INFO - 2021-12-10 03:33:04 --> Output Class Initialized
INFO - 2021-12-10 03:33:04 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:04 --> Input Class Initialized
INFO - 2021-12-10 03:33:04 --> Language Class Initialized
INFO - 2021-12-10 03:33:04 --> Language Class Initialized
INFO - 2021-12-10 03:33:04 --> Config Class Initialized
INFO - 2021-12-10 03:33:04 --> Loader Class Initialized
INFO - 2021-12-10 03:33:04 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:04 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:04 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:04 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:04 --> Controller Class Initialized
DEBUG - 2021-12-10 03:33:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:33:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:33:04 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:04 --> Total execution time: 0.1230
INFO - 2021-12-10 03:33:15 --> Config Class Initialized
INFO - 2021-12-10 03:33:15 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:15 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:15 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:15 --> URI Class Initialized
INFO - 2021-12-10 03:33:15 --> Router Class Initialized
INFO - 2021-12-10 03:33:15 --> Output Class Initialized
INFO - 2021-12-10 03:33:15 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:15 --> Input Class Initialized
INFO - 2021-12-10 03:33:15 --> Language Class Initialized
INFO - 2021-12-10 03:33:15 --> Language Class Initialized
INFO - 2021-12-10 03:33:15 --> Config Class Initialized
INFO - 2021-12-10 03:33:15 --> Loader Class Initialized
INFO - 2021-12-10 03:33:15 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:15 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:15 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:15 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:15 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:15 --> Controller Class Initialized
INFO - 2021-12-10 03:33:15 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:33:15 --> Config Class Initialized
INFO - 2021-12-10 03:33:15 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:15 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:15 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:15 --> URI Class Initialized
INFO - 2021-12-10 03:33:15 --> Router Class Initialized
INFO - 2021-12-10 03:33:15 --> Output Class Initialized
INFO - 2021-12-10 03:33:15 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:15 --> Input Class Initialized
INFO - 2021-12-10 03:33:15 --> Language Class Initialized
INFO - 2021-12-10 03:33:15 --> Language Class Initialized
INFO - 2021-12-10 03:33:15 --> Config Class Initialized
INFO - 2021-12-10 03:33:15 --> Loader Class Initialized
INFO - 2021-12-10 03:33:15 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:15 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:15 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:15 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:15 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:15 --> Controller Class Initialized
DEBUG - 2021-12-10 03:33:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:33:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:33:15 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:15 --> Total execution time: 0.0350
INFO - 2021-12-10 03:33:18 --> Config Class Initialized
INFO - 2021-12-10 03:33:18 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:18 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:18 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:19 --> URI Class Initialized
INFO - 2021-12-10 03:33:19 --> Router Class Initialized
INFO - 2021-12-10 03:33:19 --> Output Class Initialized
INFO - 2021-12-10 03:33:19 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:19 --> Input Class Initialized
INFO - 2021-12-10 03:33:19 --> Language Class Initialized
INFO - 2021-12-10 03:33:19 --> Language Class Initialized
INFO - 2021-12-10 03:33:19 --> Config Class Initialized
INFO - 2021-12-10 03:33:19 --> Loader Class Initialized
INFO - 2021-12-10 03:33:19 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:19 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:19 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:19 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:19 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:19 --> Controller Class Initialized
INFO - 2021-12-10 03:33:19 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:33:19 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:19 --> Total execution time: 0.0560
INFO - 2021-12-10 03:33:19 --> Config Class Initialized
INFO - 2021-12-10 03:33:19 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:19 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:19 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:19 --> URI Class Initialized
INFO - 2021-12-10 03:33:19 --> Router Class Initialized
INFO - 2021-12-10 03:33:19 --> Output Class Initialized
INFO - 2021-12-10 03:33:19 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:19 --> Input Class Initialized
INFO - 2021-12-10 03:33:19 --> Language Class Initialized
INFO - 2021-12-10 03:33:19 --> Language Class Initialized
INFO - 2021-12-10 03:33:19 --> Config Class Initialized
INFO - 2021-12-10 03:33:19 --> Loader Class Initialized
INFO - 2021-12-10 03:33:19 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:19 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:19 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:19 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:19 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:19 --> Controller Class Initialized
DEBUG - 2021-12-10 03:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:33:19 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:19 --> Total execution time: 0.6760
INFO - 2021-12-10 03:33:22 --> Config Class Initialized
INFO - 2021-12-10 03:33:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:22 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:22 --> URI Class Initialized
INFO - 2021-12-10 03:33:22 --> Router Class Initialized
INFO - 2021-12-10 03:33:22 --> Output Class Initialized
INFO - 2021-12-10 03:33:22 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:22 --> Input Class Initialized
INFO - 2021-12-10 03:33:22 --> Language Class Initialized
INFO - 2021-12-10 03:33:22 --> Language Class Initialized
INFO - 2021-12-10 03:33:22 --> Config Class Initialized
INFO - 2021-12-10 03:33:22 --> Loader Class Initialized
INFO - 2021-12-10 03:33:22 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:22 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:22 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:22 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:22 --> Controller Class Initialized
DEBUG - 2021-12-10 03:33:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:33:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:33:22 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:22 --> Total execution time: 0.1140
INFO - 2021-12-10 03:33:30 --> Config Class Initialized
INFO - 2021-12-10 03:33:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:30 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:30 --> URI Class Initialized
INFO - 2021-12-10 03:33:30 --> Router Class Initialized
INFO - 2021-12-10 03:33:30 --> Output Class Initialized
INFO - 2021-12-10 03:33:30 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:30 --> Input Class Initialized
INFO - 2021-12-10 03:33:30 --> Language Class Initialized
INFO - 2021-12-10 03:33:30 --> Language Class Initialized
INFO - 2021-12-10 03:33:30 --> Config Class Initialized
INFO - 2021-12-10 03:33:30 --> Loader Class Initialized
INFO - 2021-12-10 03:33:30 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:30 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:30 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:30 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:30 --> Controller Class Initialized
DEBUG - 2021-12-10 03:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:33:30 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:30 --> Total execution time: 0.0520
INFO - 2021-12-10 03:33:38 --> Config Class Initialized
INFO - 2021-12-10 03:33:38 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:33:38 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:33:38 --> Utf8 Class Initialized
INFO - 2021-12-10 03:33:38 --> URI Class Initialized
INFO - 2021-12-10 03:33:38 --> Router Class Initialized
INFO - 2021-12-10 03:33:38 --> Output Class Initialized
INFO - 2021-12-10 03:33:38 --> Security Class Initialized
DEBUG - 2021-12-10 03:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:33:38 --> Input Class Initialized
INFO - 2021-12-10 03:33:38 --> Language Class Initialized
INFO - 2021-12-10 03:33:38 --> Language Class Initialized
INFO - 2021-12-10 03:33:38 --> Config Class Initialized
INFO - 2021-12-10 03:33:38 --> Loader Class Initialized
INFO - 2021-12-10 03:33:38 --> Helper loaded: url_helper
INFO - 2021-12-10 03:33:38 --> Helper loaded: file_helper
INFO - 2021-12-10 03:33:38 --> Helper loaded: form_helper
INFO - 2021-12-10 03:33:38 --> Helper loaded: my_helper
INFO - 2021-12-10 03:33:38 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:33:38 --> Controller Class Initialized
DEBUG - 2021-12-10 03:33:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-10 03:33:38 --> Final output sent to browser
DEBUG - 2021-12-10 03:33:38 --> Total execution time: 0.1750
INFO - 2021-12-10 03:34:55 --> Config Class Initialized
INFO - 2021-12-10 03:34:55 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:34:55 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:34:55 --> Utf8 Class Initialized
INFO - 2021-12-10 03:34:55 --> URI Class Initialized
INFO - 2021-12-10 03:34:55 --> Router Class Initialized
INFO - 2021-12-10 03:34:55 --> Output Class Initialized
INFO - 2021-12-10 03:34:55 --> Security Class Initialized
DEBUG - 2021-12-10 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:34:55 --> Input Class Initialized
INFO - 2021-12-10 03:34:55 --> Language Class Initialized
INFO - 2021-12-10 03:34:55 --> Language Class Initialized
INFO - 2021-12-10 03:34:55 --> Config Class Initialized
INFO - 2021-12-10 03:34:55 --> Loader Class Initialized
INFO - 2021-12-10 03:34:55 --> Helper loaded: url_helper
INFO - 2021-12-10 03:34:55 --> Helper loaded: file_helper
INFO - 2021-12-10 03:34:55 --> Helper loaded: form_helper
INFO - 2021-12-10 03:34:55 --> Helper loaded: my_helper
INFO - 2021-12-10 03:34:55 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:34:55 --> Controller Class Initialized
DEBUG - 2021-12-10 03:34:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-10 03:34:55 --> Final output sent to browser
DEBUG - 2021-12-10 03:34:55 --> Total execution time: 0.1690
INFO - 2021-12-10 03:35:04 --> Config Class Initialized
INFO - 2021-12-10 03:35:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:35:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:35:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:35:04 --> URI Class Initialized
INFO - 2021-12-10 03:35:04 --> Router Class Initialized
INFO - 2021-12-10 03:35:04 --> Output Class Initialized
INFO - 2021-12-10 03:35:04 --> Security Class Initialized
DEBUG - 2021-12-10 03:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:35:04 --> Input Class Initialized
INFO - 2021-12-10 03:35:04 --> Language Class Initialized
INFO - 2021-12-10 03:35:04 --> Language Class Initialized
INFO - 2021-12-10 03:35:04 --> Config Class Initialized
INFO - 2021-12-10 03:35:04 --> Loader Class Initialized
INFO - 2021-12-10 03:35:04 --> Helper loaded: url_helper
INFO - 2021-12-10 03:35:04 --> Helper loaded: file_helper
INFO - 2021-12-10 03:35:04 --> Helper loaded: form_helper
INFO - 2021-12-10 03:35:04 --> Helper loaded: my_helper
INFO - 2021-12-10 03:35:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:35:04 --> Controller Class Initialized
DEBUG - 2021-12-10 03:35:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-10 03:35:05 --> Final output sent to browser
DEBUG - 2021-12-10 03:35:05 --> Total execution time: 0.1350
INFO - 2021-12-10 03:37:35 --> Config Class Initialized
INFO - 2021-12-10 03:37:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:37:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:37:35 --> Utf8 Class Initialized
INFO - 2021-12-10 03:37:35 --> URI Class Initialized
INFO - 2021-12-10 03:37:35 --> Router Class Initialized
INFO - 2021-12-10 03:37:35 --> Output Class Initialized
INFO - 2021-12-10 03:37:35 --> Security Class Initialized
DEBUG - 2021-12-10 03:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:37:35 --> Input Class Initialized
INFO - 2021-12-10 03:37:35 --> Language Class Initialized
INFO - 2021-12-10 03:37:35 --> Language Class Initialized
INFO - 2021-12-10 03:37:35 --> Config Class Initialized
INFO - 2021-12-10 03:37:35 --> Loader Class Initialized
INFO - 2021-12-10 03:37:35 --> Helper loaded: url_helper
INFO - 2021-12-10 03:37:35 --> Helper loaded: file_helper
INFO - 2021-12-10 03:37:35 --> Helper loaded: form_helper
INFO - 2021-12-10 03:37:35 --> Helper loaded: my_helper
INFO - 2021-12-10 03:37:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:37:35 --> Controller Class Initialized
INFO - 2021-12-10 03:37:35 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:37:35 --> Config Class Initialized
INFO - 2021-12-10 03:37:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:37:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:37:35 --> Utf8 Class Initialized
INFO - 2021-12-10 03:37:35 --> URI Class Initialized
INFO - 2021-12-10 03:37:35 --> Router Class Initialized
INFO - 2021-12-10 03:37:35 --> Output Class Initialized
INFO - 2021-12-10 03:37:35 --> Security Class Initialized
DEBUG - 2021-12-10 03:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:37:35 --> Input Class Initialized
INFO - 2021-12-10 03:37:35 --> Language Class Initialized
INFO - 2021-12-10 03:37:35 --> Language Class Initialized
INFO - 2021-12-10 03:37:35 --> Config Class Initialized
INFO - 2021-12-10 03:37:35 --> Loader Class Initialized
INFO - 2021-12-10 03:37:35 --> Helper loaded: url_helper
INFO - 2021-12-10 03:37:35 --> Helper loaded: file_helper
INFO - 2021-12-10 03:37:35 --> Helper loaded: form_helper
INFO - 2021-12-10 03:37:35 --> Helper loaded: my_helper
INFO - 2021-12-10 03:37:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:37:35 --> Controller Class Initialized
DEBUG - 2021-12-10 03:37:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:37:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:37:35 --> Final output sent to browser
DEBUG - 2021-12-10 03:37:35 --> Total execution time: 0.0410
INFO - 2021-12-10 03:37:49 --> Config Class Initialized
INFO - 2021-12-10 03:37:49 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:37:49 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:37:49 --> Utf8 Class Initialized
INFO - 2021-12-10 03:37:49 --> URI Class Initialized
INFO - 2021-12-10 03:37:49 --> Router Class Initialized
INFO - 2021-12-10 03:37:49 --> Output Class Initialized
INFO - 2021-12-10 03:37:49 --> Security Class Initialized
DEBUG - 2021-12-10 03:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:37:49 --> Input Class Initialized
INFO - 2021-12-10 03:37:49 --> Language Class Initialized
INFO - 2021-12-10 03:37:49 --> Language Class Initialized
INFO - 2021-12-10 03:37:49 --> Config Class Initialized
INFO - 2021-12-10 03:37:49 --> Loader Class Initialized
INFO - 2021-12-10 03:37:49 --> Helper loaded: url_helper
INFO - 2021-12-10 03:37:49 --> Helper loaded: file_helper
INFO - 2021-12-10 03:37:49 --> Helper loaded: form_helper
INFO - 2021-12-10 03:37:49 --> Helper loaded: my_helper
INFO - 2021-12-10 03:37:49 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:37:49 --> Controller Class Initialized
INFO - 2021-12-10 03:37:49 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:37:49 --> Final output sent to browser
DEBUG - 2021-12-10 03:37:49 --> Total execution time: 0.0510
INFO - 2021-12-10 03:37:50 --> Config Class Initialized
INFO - 2021-12-10 03:37:50 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:37:50 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:37:50 --> Utf8 Class Initialized
INFO - 2021-12-10 03:37:50 --> URI Class Initialized
INFO - 2021-12-10 03:37:50 --> Router Class Initialized
INFO - 2021-12-10 03:37:50 --> Output Class Initialized
INFO - 2021-12-10 03:37:50 --> Security Class Initialized
DEBUG - 2021-12-10 03:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:37:50 --> Input Class Initialized
INFO - 2021-12-10 03:37:50 --> Language Class Initialized
INFO - 2021-12-10 03:37:50 --> Language Class Initialized
INFO - 2021-12-10 03:37:50 --> Config Class Initialized
INFO - 2021-12-10 03:37:50 --> Loader Class Initialized
INFO - 2021-12-10 03:37:50 --> Helper loaded: url_helper
INFO - 2021-12-10 03:37:50 --> Helper loaded: file_helper
INFO - 2021-12-10 03:37:50 --> Helper loaded: form_helper
INFO - 2021-12-10 03:37:50 --> Helper loaded: my_helper
INFO - 2021-12-10 03:37:50 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:37:50 --> Controller Class Initialized
DEBUG - 2021-12-10 03:37:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:37:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:37:50 --> Final output sent to browser
DEBUG - 2021-12-10 03:37:50 --> Total execution time: 0.7580
INFO - 2021-12-10 03:37:58 --> Config Class Initialized
INFO - 2021-12-10 03:37:58 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:37:58 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:37:58 --> Utf8 Class Initialized
INFO - 2021-12-10 03:37:58 --> URI Class Initialized
INFO - 2021-12-10 03:37:58 --> Router Class Initialized
INFO - 2021-12-10 03:37:58 --> Output Class Initialized
INFO - 2021-12-10 03:37:58 --> Security Class Initialized
DEBUG - 2021-12-10 03:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:37:58 --> Input Class Initialized
INFO - 2021-12-10 03:37:58 --> Language Class Initialized
INFO - 2021-12-10 03:37:58 --> Language Class Initialized
INFO - 2021-12-10 03:37:58 --> Config Class Initialized
INFO - 2021-12-10 03:37:58 --> Loader Class Initialized
INFO - 2021-12-10 03:37:58 --> Helper loaded: url_helper
INFO - 2021-12-10 03:37:58 --> Helper loaded: file_helper
INFO - 2021-12-10 03:37:58 --> Helper loaded: form_helper
INFO - 2021-12-10 03:37:58 --> Helper loaded: my_helper
INFO - 2021-12-10 03:37:58 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:37:58 --> Controller Class Initialized
DEBUG - 2021-12-10 03:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:37:58 --> Final output sent to browser
DEBUG - 2021-12-10 03:37:58 --> Total execution time: 0.0770
INFO - 2021-12-10 03:38:08 --> Config Class Initialized
INFO - 2021-12-10 03:38:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:38:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:38:08 --> Utf8 Class Initialized
INFO - 2021-12-10 03:38:08 --> URI Class Initialized
INFO - 2021-12-10 03:38:08 --> Router Class Initialized
INFO - 2021-12-10 03:38:08 --> Output Class Initialized
INFO - 2021-12-10 03:38:08 --> Security Class Initialized
DEBUG - 2021-12-10 03:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:38:08 --> Input Class Initialized
INFO - 2021-12-10 03:38:08 --> Language Class Initialized
INFO - 2021-12-10 03:38:08 --> Language Class Initialized
INFO - 2021-12-10 03:38:08 --> Config Class Initialized
INFO - 2021-12-10 03:38:08 --> Loader Class Initialized
INFO - 2021-12-10 03:38:08 --> Helper loaded: url_helper
INFO - 2021-12-10 03:38:08 --> Helper loaded: file_helper
INFO - 2021-12-10 03:38:08 --> Helper loaded: form_helper
INFO - 2021-12-10 03:38:08 --> Helper loaded: my_helper
INFO - 2021-12-10 03:38:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:38:08 --> Controller Class Initialized
INFO - 2021-12-10 03:38:08 --> Final output sent to browser
DEBUG - 2021-12-10 03:38:08 --> Total execution time: 0.0800
INFO - 2021-12-10 03:38:10 --> Config Class Initialized
INFO - 2021-12-10 03:38:10 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:38:10 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:38:10 --> Utf8 Class Initialized
INFO - 2021-12-10 03:38:10 --> URI Class Initialized
INFO - 2021-12-10 03:38:10 --> Router Class Initialized
INFO - 2021-12-10 03:38:10 --> Output Class Initialized
INFO - 2021-12-10 03:38:10 --> Security Class Initialized
DEBUG - 2021-12-10 03:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:38:10 --> Input Class Initialized
INFO - 2021-12-10 03:38:10 --> Language Class Initialized
INFO - 2021-12-10 03:38:10 --> Language Class Initialized
INFO - 2021-12-10 03:38:10 --> Config Class Initialized
INFO - 2021-12-10 03:38:10 --> Loader Class Initialized
INFO - 2021-12-10 03:38:10 --> Helper loaded: url_helper
INFO - 2021-12-10 03:38:10 --> Helper loaded: file_helper
INFO - 2021-12-10 03:38:10 --> Helper loaded: form_helper
INFO - 2021-12-10 03:38:10 --> Helper loaded: my_helper
INFO - 2021-12-10 03:38:10 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:38:10 --> Controller Class Initialized
DEBUG - 2021-12-10 03:38:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:38:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:38:10 --> Final output sent to browser
DEBUG - 2021-12-10 03:38:10 --> Total execution time: 0.0520
INFO - 2021-12-10 03:38:14 --> Config Class Initialized
INFO - 2021-12-10 03:38:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:38:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:38:14 --> Utf8 Class Initialized
INFO - 2021-12-10 03:38:14 --> URI Class Initialized
INFO - 2021-12-10 03:38:14 --> Router Class Initialized
INFO - 2021-12-10 03:38:14 --> Output Class Initialized
INFO - 2021-12-10 03:38:14 --> Security Class Initialized
DEBUG - 2021-12-10 03:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:38:14 --> Input Class Initialized
INFO - 2021-12-10 03:38:14 --> Language Class Initialized
INFO - 2021-12-10 03:38:14 --> Language Class Initialized
INFO - 2021-12-10 03:38:14 --> Config Class Initialized
INFO - 2021-12-10 03:38:14 --> Loader Class Initialized
INFO - 2021-12-10 03:38:14 --> Helper loaded: url_helper
INFO - 2021-12-10 03:38:14 --> Helper loaded: file_helper
INFO - 2021-12-10 03:38:14 --> Helper loaded: form_helper
INFO - 2021-12-10 03:38:14 --> Helper loaded: my_helper
INFO - 2021-12-10 03:38:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:38:14 --> Controller Class Initialized
DEBUG - 2021-12-10 03:38:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-10 03:38:14 --> Final output sent to browser
DEBUG - 2021-12-10 03:38:14 --> Total execution time: 0.1640
INFO - 2021-12-10 03:38:37 --> Config Class Initialized
INFO - 2021-12-10 03:38:37 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:38:37 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:38:37 --> Utf8 Class Initialized
INFO - 2021-12-10 03:38:37 --> URI Class Initialized
INFO - 2021-12-10 03:38:37 --> Router Class Initialized
INFO - 2021-12-10 03:38:37 --> Output Class Initialized
INFO - 2021-12-10 03:38:37 --> Security Class Initialized
DEBUG - 2021-12-10 03:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:38:37 --> Input Class Initialized
INFO - 2021-12-10 03:38:37 --> Language Class Initialized
INFO - 2021-12-10 03:38:37 --> Language Class Initialized
INFO - 2021-12-10 03:38:37 --> Config Class Initialized
INFO - 2021-12-10 03:38:37 --> Loader Class Initialized
INFO - 2021-12-10 03:38:37 --> Helper loaded: url_helper
INFO - 2021-12-10 03:38:37 --> Helper loaded: file_helper
INFO - 2021-12-10 03:38:37 --> Helper loaded: form_helper
INFO - 2021-12-10 03:38:37 --> Helper loaded: my_helper
INFO - 2021-12-10 03:38:37 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:38:37 --> Controller Class Initialized
DEBUG - 2021-12-10 03:38:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-10 03:38:37 --> Final output sent to browser
DEBUG - 2021-12-10 03:38:37 --> Total execution time: 0.1670
INFO - 2021-12-10 03:38:51 --> Config Class Initialized
INFO - 2021-12-10 03:38:51 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:38:51 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:38:51 --> Utf8 Class Initialized
INFO - 2021-12-10 03:38:51 --> URI Class Initialized
INFO - 2021-12-10 03:38:51 --> Router Class Initialized
INFO - 2021-12-10 03:38:51 --> Output Class Initialized
INFO - 2021-12-10 03:38:51 --> Security Class Initialized
DEBUG - 2021-12-10 03:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:38:51 --> Input Class Initialized
INFO - 2021-12-10 03:38:51 --> Language Class Initialized
INFO - 2021-12-10 03:38:51 --> Language Class Initialized
INFO - 2021-12-10 03:38:51 --> Config Class Initialized
INFO - 2021-12-10 03:38:51 --> Loader Class Initialized
INFO - 2021-12-10 03:38:51 --> Helper loaded: url_helper
INFO - 2021-12-10 03:38:51 --> Helper loaded: file_helper
INFO - 2021-12-10 03:38:51 --> Helper loaded: form_helper
INFO - 2021-12-10 03:38:51 --> Helper loaded: my_helper
INFO - 2021-12-10 03:38:51 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:38:51 --> Controller Class Initialized
DEBUG - 2021-12-10 03:38:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-10 03:38:51 --> Final output sent to browser
DEBUG - 2021-12-10 03:38:51 --> Total execution time: 0.1590
INFO - 2021-12-10 03:39:04 --> Config Class Initialized
INFO - 2021-12-10 03:39:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:39:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:39:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:39:04 --> URI Class Initialized
INFO - 2021-12-10 03:39:04 --> Router Class Initialized
INFO - 2021-12-10 03:39:04 --> Output Class Initialized
INFO - 2021-12-10 03:39:04 --> Security Class Initialized
DEBUG - 2021-12-10 03:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:39:04 --> Input Class Initialized
INFO - 2021-12-10 03:39:04 --> Language Class Initialized
INFO - 2021-12-10 03:39:04 --> Language Class Initialized
INFO - 2021-12-10 03:39:04 --> Config Class Initialized
INFO - 2021-12-10 03:39:04 --> Loader Class Initialized
INFO - 2021-12-10 03:39:04 --> Helper loaded: url_helper
INFO - 2021-12-10 03:39:04 --> Helper loaded: file_helper
INFO - 2021-12-10 03:39:04 --> Helper loaded: form_helper
INFO - 2021-12-10 03:39:04 --> Helper loaded: my_helper
INFO - 2021-12-10 03:39:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:39:04 --> Controller Class Initialized
INFO - 2021-12-10 03:39:04 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:39:04 --> Config Class Initialized
INFO - 2021-12-10 03:39:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:39:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:39:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:39:04 --> URI Class Initialized
INFO - 2021-12-10 03:39:04 --> Router Class Initialized
INFO - 2021-12-10 03:39:04 --> Output Class Initialized
INFO - 2021-12-10 03:39:04 --> Security Class Initialized
DEBUG - 2021-12-10 03:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:39:04 --> Input Class Initialized
INFO - 2021-12-10 03:39:04 --> Language Class Initialized
INFO - 2021-12-10 03:39:04 --> Language Class Initialized
INFO - 2021-12-10 03:39:04 --> Config Class Initialized
INFO - 2021-12-10 03:39:04 --> Loader Class Initialized
INFO - 2021-12-10 03:39:04 --> Helper loaded: url_helper
INFO - 2021-12-10 03:39:04 --> Helper loaded: file_helper
INFO - 2021-12-10 03:39:04 --> Helper loaded: form_helper
INFO - 2021-12-10 03:39:04 --> Helper loaded: my_helper
INFO - 2021-12-10 03:39:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:39:04 --> Controller Class Initialized
DEBUG - 2021-12-10 03:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:39:04 --> Final output sent to browser
DEBUG - 2021-12-10 03:39:04 --> Total execution time: 0.0360
INFO - 2021-12-10 03:39:34 --> Config Class Initialized
INFO - 2021-12-10 03:39:34 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:39:34 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:39:34 --> Utf8 Class Initialized
INFO - 2021-12-10 03:39:34 --> URI Class Initialized
INFO - 2021-12-10 03:39:34 --> Router Class Initialized
INFO - 2021-12-10 03:39:34 --> Output Class Initialized
INFO - 2021-12-10 03:39:34 --> Security Class Initialized
DEBUG - 2021-12-10 03:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:39:34 --> Input Class Initialized
INFO - 2021-12-10 03:39:34 --> Language Class Initialized
INFO - 2021-12-10 03:39:34 --> Language Class Initialized
INFO - 2021-12-10 03:39:34 --> Config Class Initialized
INFO - 2021-12-10 03:39:34 --> Loader Class Initialized
INFO - 2021-12-10 03:39:34 --> Helper loaded: url_helper
INFO - 2021-12-10 03:39:34 --> Helper loaded: file_helper
INFO - 2021-12-10 03:39:34 --> Helper loaded: form_helper
INFO - 2021-12-10 03:39:34 --> Helper loaded: my_helper
INFO - 2021-12-10 03:39:34 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:39:34 --> Controller Class Initialized
INFO - 2021-12-10 03:39:34 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:39:34 --> Final output sent to browser
DEBUG - 2021-12-10 03:39:34 --> Total execution time: 0.0630
INFO - 2021-12-10 03:39:35 --> Config Class Initialized
INFO - 2021-12-10 03:39:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:39:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:39:35 --> Utf8 Class Initialized
INFO - 2021-12-10 03:39:35 --> URI Class Initialized
INFO - 2021-12-10 03:39:35 --> Router Class Initialized
INFO - 2021-12-10 03:39:35 --> Output Class Initialized
INFO - 2021-12-10 03:39:35 --> Security Class Initialized
DEBUG - 2021-12-10 03:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:39:35 --> Input Class Initialized
INFO - 2021-12-10 03:39:35 --> Language Class Initialized
INFO - 2021-12-10 03:39:35 --> Language Class Initialized
INFO - 2021-12-10 03:39:35 --> Config Class Initialized
INFO - 2021-12-10 03:39:35 --> Loader Class Initialized
INFO - 2021-12-10 03:39:35 --> Helper loaded: url_helper
INFO - 2021-12-10 03:39:35 --> Helper loaded: file_helper
INFO - 2021-12-10 03:39:35 --> Helper loaded: form_helper
INFO - 2021-12-10 03:39:35 --> Helper loaded: my_helper
INFO - 2021-12-10 03:39:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:39:35 --> Controller Class Initialized
DEBUG - 2021-12-10 03:39:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:39:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:39:35 --> Final output sent to browser
DEBUG - 2021-12-10 03:39:35 --> Total execution time: 0.7430
INFO - 2021-12-10 03:39:48 --> Config Class Initialized
INFO - 2021-12-10 03:39:48 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:39:48 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:39:48 --> Utf8 Class Initialized
INFO - 2021-12-10 03:39:48 --> URI Class Initialized
INFO - 2021-12-10 03:39:48 --> Router Class Initialized
INFO - 2021-12-10 03:39:48 --> Output Class Initialized
INFO - 2021-12-10 03:39:48 --> Security Class Initialized
DEBUG - 2021-12-10 03:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:39:48 --> Input Class Initialized
INFO - 2021-12-10 03:39:48 --> Language Class Initialized
INFO - 2021-12-10 03:39:48 --> Language Class Initialized
INFO - 2021-12-10 03:39:48 --> Config Class Initialized
INFO - 2021-12-10 03:39:48 --> Loader Class Initialized
INFO - 2021-12-10 03:39:48 --> Helper loaded: url_helper
INFO - 2021-12-10 03:39:48 --> Helper loaded: file_helper
INFO - 2021-12-10 03:39:48 --> Helper loaded: form_helper
INFO - 2021-12-10 03:39:48 --> Helper loaded: my_helper
INFO - 2021-12-10 03:39:48 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:39:48 --> Controller Class Initialized
DEBUG - 2021-12-10 03:39:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:39:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:39:48 --> Final output sent to browser
DEBUG - 2021-12-10 03:39:48 --> Total execution time: 0.1030
INFO - 2021-12-10 03:39:55 --> Config Class Initialized
INFO - 2021-12-10 03:39:55 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:39:55 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:39:55 --> Utf8 Class Initialized
INFO - 2021-12-10 03:39:55 --> URI Class Initialized
INFO - 2021-12-10 03:39:55 --> Router Class Initialized
INFO - 2021-12-10 03:39:55 --> Output Class Initialized
INFO - 2021-12-10 03:39:55 --> Security Class Initialized
DEBUG - 2021-12-10 03:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:39:55 --> Input Class Initialized
INFO - 2021-12-10 03:39:55 --> Language Class Initialized
INFO - 2021-12-10 03:39:55 --> Language Class Initialized
INFO - 2021-12-10 03:39:55 --> Config Class Initialized
INFO - 2021-12-10 03:39:55 --> Loader Class Initialized
INFO - 2021-12-10 03:39:55 --> Helper loaded: url_helper
INFO - 2021-12-10 03:39:55 --> Helper loaded: file_helper
INFO - 2021-12-10 03:39:55 --> Helper loaded: form_helper
INFO - 2021-12-10 03:39:55 --> Helper loaded: my_helper
INFO - 2021-12-10 03:39:55 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:39:55 --> Controller Class Initialized
INFO - 2021-12-10 03:39:55 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:39:55 --> Config Class Initialized
INFO - 2021-12-10 03:39:55 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:39:55 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:39:55 --> Utf8 Class Initialized
INFO - 2021-12-10 03:39:55 --> URI Class Initialized
INFO - 2021-12-10 03:39:55 --> Router Class Initialized
INFO - 2021-12-10 03:39:55 --> Output Class Initialized
INFO - 2021-12-10 03:39:55 --> Security Class Initialized
DEBUG - 2021-12-10 03:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:39:55 --> Input Class Initialized
INFO - 2021-12-10 03:39:55 --> Language Class Initialized
INFO - 2021-12-10 03:39:55 --> Language Class Initialized
INFO - 2021-12-10 03:39:55 --> Config Class Initialized
INFO - 2021-12-10 03:39:55 --> Loader Class Initialized
INFO - 2021-12-10 03:39:55 --> Helper loaded: url_helper
INFO - 2021-12-10 03:39:55 --> Helper loaded: file_helper
INFO - 2021-12-10 03:39:55 --> Helper loaded: form_helper
INFO - 2021-12-10 03:39:55 --> Helper loaded: my_helper
INFO - 2021-12-10 03:39:55 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:39:55 --> Controller Class Initialized
DEBUG - 2021-12-10 03:39:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:39:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:39:55 --> Final output sent to browser
DEBUG - 2021-12-10 03:39:55 --> Total execution time: 0.0350
INFO - 2021-12-10 03:40:02 --> Config Class Initialized
INFO - 2021-12-10 03:40:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:02 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:02 --> URI Class Initialized
INFO - 2021-12-10 03:40:02 --> Router Class Initialized
INFO - 2021-12-10 03:40:02 --> Output Class Initialized
INFO - 2021-12-10 03:40:02 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:02 --> Input Class Initialized
INFO - 2021-12-10 03:40:02 --> Language Class Initialized
INFO - 2021-12-10 03:40:02 --> Language Class Initialized
INFO - 2021-12-10 03:40:02 --> Config Class Initialized
INFO - 2021-12-10 03:40:02 --> Loader Class Initialized
INFO - 2021-12-10 03:40:02 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:02 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:02 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:02 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:02 --> Controller Class Initialized
INFO - 2021-12-10 03:40:02 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:40:02 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:02 --> Total execution time: 0.0560
INFO - 2021-12-10 03:40:02 --> Config Class Initialized
INFO - 2021-12-10 03:40:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:02 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:02 --> URI Class Initialized
INFO - 2021-12-10 03:40:02 --> Router Class Initialized
INFO - 2021-12-10 03:40:02 --> Output Class Initialized
INFO - 2021-12-10 03:40:02 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:02 --> Input Class Initialized
INFO - 2021-12-10 03:40:02 --> Language Class Initialized
INFO - 2021-12-10 03:40:02 --> Language Class Initialized
INFO - 2021-12-10 03:40:02 --> Config Class Initialized
INFO - 2021-12-10 03:40:02 --> Loader Class Initialized
INFO - 2021-12-10 03:40:02 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:02 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:02 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:02 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:02 --> Controller Class Initialized
DEBUG - 2021-12-10 03:40:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:40:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:40:03 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:03 --> Total execution time: 0.7030
INFO - 2021-12-10 03:40:04 --> Config Class Initialized
INFO - 2021-12-10 03:40:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:04 --> URI Class Initialized
INFO - 2021-12-10 03:40:04 --> Router Class Initialized
INFO - 2021-12-10 03:40:04 --> Output Class Initialized
INFO - 2021-12-10 03:40:04 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:04 --> Input Class Initialized
INFO - 2021-12-10 03:40:04 --> Language Class Initialized
INFO - 2021-12-10 03:40:04 --> Language Class Initialized
INFO - 2021-12-10 03:40:04 --> Config Class Initialized
INFO - 2021-12-10 03:40:04 --> Loader Class Initialized
INFO - 2021-12-10 03:40:04 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:04 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:04 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:04 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:04 --> Controller Class Initialized
DEBUG - 2021-12-10 03:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:40:04 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:04 --> Total execution time: 0.0780
INFO - 2021-12-10 03:40:08 --> Config Class Initialized
INFO - 2021-12-10 03:40:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:08 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:08 --> URI Class Initialized
INFO - 2021-12-10 03:40:08 --> Router Class Initialized
INFO - 2021-12-10 03:40:08 --> Output Class Initialized
INFO - 2021-12-10 03:40:08 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:08 --> Input Class Initialized
INFO - 2021-12-10 03:40:08 --> Language Class Initialized
INFO - 2021-12-10 03:40:08 --> Language Class Initialized
INFO - 2021-12-10 03:40:08 --> Config Class Initialized
INFO - 2021-12-10 03:40:08 --> Loader Class Initialized
INFO - 2021-12-10 03:40:08 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:08 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:08 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:08 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:08 --> Controller Class Initialized
INFO - 2021-12-10 03:40:08 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:08 --> Total execution time: 0.0670
INFO - 2021-12-10 03:40:10 --> Config Class Initialized
INFO - 2021-12-10 03:40:10 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:10 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:10 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:10 --> URI Class Initialized
INFO - 2021-12-10 03:40:10 --> Router Class Initialized
INFO - 2021-12-10 03:40:10 --> Output Class Initialized
INFO - 2021-12-10 03:40:10 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:10 --> Input Class Initialized
INFO - 2021-12-10 03:40:10 --> Language Class Initialized
INFO - 2021-12-10 03:40:10 --> Language Class Initialized
INFO - 2021-12-10 03:40:10 --> Config Class Initialized
INFO - 2021-12-10 03:40:10 --> Loader Class Initialized
INFO - 2021-12-10 03:40:10 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:10 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:10 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:10 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:10 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:10 --> Controller Class Initialized
INFO - 2021-12-10 03:40:10 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:40:10 --> Config Class Initialized
INFO - 2021-12-10 03:40:10 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:10 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:10 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:10 --> URI Class Initialized
INFO - 2021-12-10 03:40:10 --> Router Class Initialized
INFO - 2021-12-10 03:40:10 --> Output Class Initialized
INFO - 2021-12-10 03:40:10 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:10 --> Input Class Initialized
INFO - 2021-12-10 03:40:10 --> Language Class Initialized
INFO - 2021-12-10 03:40:10 --> Language Class Initialized
INFO - 2021-12-10 03:40:10 --> Config Class Initialized
INFO - 2021-12-10 03:40:10 --> Loader Class Initialized
INFO - 2021-12-10 03:40:10 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:10 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:10 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:10 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:10 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:10 --> Controller Class Initialized
DEBUG - 2021-12-10 03:40:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:40:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:40:10 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:10 --> Total execution time: 0.0360
INFO - 2021-12-10 03:40:14 --> Config Class Initialized
INFO - 2021-12-10 03:40:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:14 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:14 --> URI Class Initialized
INFO - 2021-12-10 03:40:14 --> Router Class Initialized
INFO - 2021-12-10 03:40:14 --> Output Class Initialized
INFO - 2021-12-10 03:40:14 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:14 --> Input Class Initialized
INFO - 2021-12-10 03:40:14 --> Language Class Initialized
INFO - 2021-12-10 03:40:14 --> Language Class Initialized
INFO - 2021-12-10 03:40:14 --> Config Class Initialized
INFO - 2021-12-10 03:40:14 --> Loader Class Initialized
INFO - 2021-12-10 03:40:14 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:14 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:14 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:14 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:14 --> Controller Class Initialized
INFO - 2021-12-10 03:40:14 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:40:14 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:14 --> Total execution time: 0.0560
INFO - 2021-12-10 03:40:14 --> Config Class Initialized
INFO - 2021-12-10 03:40:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:14 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:14 --> URI Class Initialized
INFO - 2021-12-10 03:40:14 --> Router Class Initialized
INFO - 2021-12-10 03:40:14 --> Output Class Initialized
INFO - 2021-12-10 03:40:14 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:14 --> Input Class Initialized
INFO - 2021-12-10 03:40:14 --> Language Class Initialized
INFO - 2021-12-10 03:40:14 --> Language Class Initialized
INFO - 2021-12-10 03:40:14 --> Config Class Initialized
INFO - 2021-12-10 03:40:14 --> Loader Class Initialized
INFO - 2021-12-10 03:40:14 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:14 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:14 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:14 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:14 --> Controller Class Initialized
DEBUG - 2021-12-10 03:40:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:40:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:40:15 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:15 --> Total execution time: 0.7100
INFO - 2021-12-10 03:40:18 --> Config Class Initialized
INFO - 2021-12-10 03:40:18 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:18 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:18 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:18 --> URI Class Initialized
INFO - 2021-12-10 03:40:18 --> Router Class Initialized
INFO - 2021-12-10 03:40:18 --> Output Class Initialized
INFO - 2021-12-10 03:40:18 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:18 --> Input Class Initialized
INFO - 2021-12-10 03:40:18 --> Language Class Initialized
INFO - 2021-12-10 03:40:18 --> Language Class Initialized
INFO - 2021-12-10 03:40:18 --> Config Class Initialized
INFO - 2021-12-10 03:40:18 --> Loader Class Initialized
INFO - 2021-12-10 03:40:18 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:18 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:18 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:18 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:18 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:18 --> Controller Class Initialized
DEBUG - 2021-12-10 03:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:40:18 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:18 --> Total execution time: 0.1260
INFO - 2021-12-10 03:40:25 --> Config Class Initialized
INFO - 2021-12-10 03:40:25 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:25 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:25 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:25 --> URI Class Initialized
INFO - 2021-12-10 03:40:25 --> Router Class Initialized
INFO - 2021-12-10 03:40:25 --> Output Class Initialized
INFO - 2021-12-10 03:40:25 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:25 --> Input Class Initialized
INFO - 2021-12-10 03:40:25 --> Language Class Initialized
INFO - 2021-12-10 03:40:25 --> Language Class Initialized
INFO - 2021-12-10 03:40:25 --> Config Class Initialized
INFO - 2021-12-10 03:40:25 --> Loader Class Initialized
INFO - 2021-12-10 03:40:25 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:25 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:25 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:25 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:25 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:25 --> Controller Class Initialized
INFO - 2021-12-10 03:40:25 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:25 --> Total execution time: 0.1100
INFO - 2021-12-10 03:40:26 --> Config Class Initialized
INFO - 2021-12-10 03:40:26 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:26 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:26 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:26 --> URI Class Initialized
INFO - 2021-12-10 03:40:26 --> Router Class Initialized
INFO - 2021-12-10 03:40:26 --> Output Class Initialized
INFO - 2021-12-10 03:40:26 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:26 --> Input Class Initialized
INFO - 2021-12-10 03:40:26 --> Language Class Initialized
INFO - 2021-12-10 03:40:26 --> Language Class Initialized
INFO - 2021-12-10 03:40:26 --> Config Class Initialized
INFO - 2021-12-10 03:40:26 --> Loader Class Initialized
INFO - 2021-12-10 03:40:26 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:26 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:26 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:26 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:26 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:26 --> Controller Class Initialized
DEBUG - 2021-12-10 03:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:40:26 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:26 --> Total execution time: 0.0770
INFO - 2021-12-10 03:40:30 --> Config Class Initialized
INFO - 2021-12-10 03:40:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:30 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:30 --> URI Class Initialized
INFO - 2021-12-10 03:40:30 --> Router Class Initialized
INFO - 2021-12-10 03:40:30 --> Output Class Initialized
INFO - 2021-12-10 03:40:30 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:30 --> Input Class Initialized
INFO - 2021-12-10 03:40:30 --> Language Class Initialized
INFO - 2021-12-10 03:40:31 --> Language Class Initialized
INFO - 2021-12-10 03:40:31 --> Config Class Initialized
INFO - 2021-12-10 03:40:31 --> Loader Class Initialized
INFO - 2021-12-10 03:40:31 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:31 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:31 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:31 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:31 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:31 --> Controller Class Initialized
DEBUG - 2021-12-10 03:40:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-10 03:40:31 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:31 --> Total execution time: 0.1960
INFO - 2021-12-10 03:40:56 --> Config Class Initialized
INFO - 2021-12-10 03:40:56 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:40:56 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:40:56 --> Utf8 Class Initialized
INFO - 2021-12-10 03:40:56 --> URI Class Initialized
INFO - 2021-12-10 03:40:56 --> Router Class Initialized
INFO - 2021-12-10 03:40:56 --> Output Class Initialized
INFO - 2021-12-10 03:40:56 --> Security Class Initialized
DEBUG - 2021-12-10 03:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:40:56 --> Input Class Initialized
INFO - 2021-12-10 03:40:56 --> Language Class Initialized
INFO - 2021-12-10 03:40:56 --> Language Class Initialized
INFO - 2021-12-10 03:40:56 --> Config Class Initialized
INFO - 2021-12-10 03:40:56 --> Loader Class Initialized
INFO - 2021-12-10 03:40:56 --> Helper loaded: url_helper
INFO - 2021-12-10 03:40:56 --> Helper loaded: file_helper
INFO - 2021-12-10 03:40:56 --> Helper loaded: form_helper
INFO - 2021-12-10 03:40:56 --> Helper loaded: my_helper
INFO - 2021-12-10 03:40:56 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:40:56 --> Controller Class Initialized
DEBUG - 2021-12-10 03:40:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-10 03:40:57 --> Final output sent to browser
DEBUG - 2021-12-10 03:40:57 --> Total execution time: 0.1650
INFO - 2021-12-10 03:41:05 --> Config Class Initialized
INFO - 2021-12-10 03:41:05 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:41:05 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:41:05 --> Utf8 Class Initialized
INFO - 2021-12-10 03:41:05 --> URI Class Initialized
INFO - 2021-12-10 03:41:05 --> Router Class Initialized
INFO - 2021-12-10 03:41:05 --> Output Class Initialized
INFO - 2021-12-10 03:41:05 --> Security Class Initialized
DEBUG - 2021-12-10 03:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:41:05 --> Input Class Initialized
INFO - 2021-12-10 03:41:05 --> Language Class Initialized
INFO - 2021-12-10 03:41:05 --> Language Class Initialized
INFO - 2021-12-10 03:41:05 --> Config Class Initialized
INFO - 2021-12-10 03:41:05 --> Loader Class Initialized
INFO - 2021-12-10 03:41:05 --> Helper loaded: url_helper
INFO - 2021-12-10 03:41:05 --> Helper loaded: file_helper
INFO - 2021-12-10 03:41:05 --> Helper loaded: form_helper
INFO - 2021-12-10 03:41:05 --> Helper loaded: my_helper
INFO - 2021-12-10 03:41:05 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:41:05 --> Controller Class Initialized
DEBUG - 2021-12-10 03:41:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-10 03:41:06 --> Final output sent to browser
DEBUG - 2021-12-10 03:41:06 --> Total execution time: 0.1510
INFO - 2021-12-10 03:41:16 --> Config Class Initialized
INFO - 2021-12-10 03:41:16 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:41:16 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:41:16 --> Utf8 Class Initialized
INFO - 2021-12-10 03:41:16 --> URI Class Initialized
INFO - 2021-12-10 03:41:16 --> Router Class Initialized
INFO - 2021-12-10 03:41:16 --> Output Class Initialized
INFO - 2021-12-10 03:41:16 --> Security Class Initialized
DEBUG - 2021-12-10 03:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:41:16 --> Input Class Initialized
INFO - 2021-12-10 03:41:16 --> Language Class Initialized
INFO - 2021-12-10 03:41:16 --> Language Class Initialized
INFO - 2021-12-10 03:41:16 --> Config Class Initialized
INFO - 2021-12-10 03:41:16 --> Loader Class Initialized
INFO - 2021-12-10 03:41:16 --> Helper loaded: url_helper
INFO - 2021-12-10 03:41:16 --> Helper loaded: file_helper
INFO - 2021-12-10 03:41:16 --> Helper loaded: form_helper
INFO - 2021-12-10 03:41:16 --> Helper loaded: my_helper
INFO - 2021-12-10 03:41:16 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:41:16 --> Controller Class Initialized
DEBUG - 2021-12-10 03:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:41:16 --> Final output sent to browser
DEBUG - 2021-12-10 03:41:16 --> Total execution time: 0.0970
INFO - 2021-12-10 03:41:35 --> Config Class Initialized
INFO - 2021-12-10 03:41:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:41:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:41:35 --> Utf8 Class Initialized
INFO - 2021-12-10 03:41:35 --> URI Class Initialized
INFO - 2021-12-10 03:41:35 --> Router Class Initialized
INFO - 2021-12-10 03:41:35 --> Output Class Initialized
INFO - 2021-12-10 03:41:35 --> Security Class Initialized
DEBUG - 2021-12-10 03:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:41:35 --> Input Class Initialized
INFO - 2021-12-10 03:41:35 --> Language Class Initialized
INFO - 2021-12-10 03:41:35 --> Language Class Initialized
INFO - 2021-12-10 03:41:35 --> Config Class Initialized
INFO - 2021-12-10 03:41:35 --> Loader Class Initialized
INFO - 2021-12-10 03:41:35 --> Helper loaded: url_helper
INFO - 2021-12-10 03:41:35 --> Helper loaded: file_helper
INFO - 2021-12-10 03:41:35 --> Helper loaded: form_helper
INFO - 2021-12-10 03:41:35 --> Helper loaded: my_helper
INFO - 2021-12-10 03:41:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:41:35 --> Controller Class Initialized
INFO - 2021-12-10 03:41:35 --> Final output sent to browser
DEBUG - 2021-12-10 03:41:35 --> Total execution time: 0.1010
INFO - 2021-12-10 03:41:40 --> Config Class Initialized
INFO - 2021-12-10 03:41:40 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:41:40 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:41:40 --> Utf8 Class Initialized
INFO - 2021-12-10 03:41:40 --> URI Class Initialized
INFO - 2021-12-10 03:41:40 --> Router Class Initialized
INFO - 2021-12-10 03:41:40 --> Output Class Initialized
INFO - 2021-12-10 03:41:40 --> Security Class Initialized
DEBUG - 2021-12-10 03:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:41:40 --> Input Class Initialized
INFO - 2021-12-10 03:41:40 --> Language Class Initialized
INFO - 2021-12-10 03:41:40 --> Language Class Initialized
INFO - 2021-12-10 03:41:40 --> Config Class Initialized
INFO - 2021-12-10 03:41:40 --> Loader Class Initialized
INFO - 2021-12-10 03:41:40 --> Helper loaded: url_helper
INFO - 2021-12-10 03:41:40 --> Helper loaded: file_helper
INFO - 2021-12-10 03:41:40 --> Helper loaded: form_helper
INFO - 2021-12-10 03:41:40 --> Helper loaded: my_helper
INFO - 2021-12-10 03:41:40 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:41:40 --> Controller Class Initialized
INFO - 2021-12-10 03:41:40 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:41:40 --> Config Class Initialized
INFO - 2021-12-10 03:41:40 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:41:40 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:41:40 --> Utf8 Class Initialized
INFO - 2021-12-10 03:41:40 --> URI Class Initialized
INFO - 2021-12-10 03:41:40 --> Router Class Initialized
INFO - 2021-12-10 03:41:40 --> Output Class Initialized
INFO - 2021-12-10 03:41:40 --> Security Class Initialized
DEBUG - 2021-12-10 03:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:41:40 --> Input Class Initialized
INFO - 2021-12-10 03:41:40 --> Language Class Initialized
INFO - 2021-12-10 03:41:40 --> Language Class Initialized
INFO - 2021-12-10 03:41:40 --> Config Class Initialized
INFO - 2021-12-10 03:41:40 --> Loader Class Initialized
INFO - 2021-12-10 03:41:40 --> Helper loaded: url_helper
INFO - 2021-12-10 03:41:40 --> Helper loaded: file_helper
INFO - 2021-12-10 03:41:40 --> Helper loaded: form_helper
INFO - 2021-12-10 03:41:40 --> Helper loaded: my_helper
INFO - 2021-12-10 03:41:40 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:41:40 --> Controller Class Initialized
DEBUG - 2021-12-10 03:41:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:41:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:41:40 --> Final output sent to browser
DEBUG - 2021-12-10 03:41:40 --> Total execution time: 0.0350
INFO - 2021-12-10 03:42:02 --> Config Class Initialized
INFO - 2021-12-10 03:42:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:42:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:42:02 --> Utf8 Class Initialized
INFO - 2021-12-10 03:42:02 --> URI Class Initialized
INFO - 2021-12-10 03:42:02 --> Router Class Initialized
INFO - 2021-12-10 03:42:02 --> Output Class Initialized
INFO - 2021-12-10 03:42:02 --> Security Class Initialized
DEBUG - 2021-12-10 03:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:42:02 --> Input Class Initialized
INFO - 2021-12-10 03:42:02 --> Language Class Initialized
INFO - 2021-12-10 03:42:02 --> Language Class Initialized
INFO - 2021-12-10 03:42:02 --> Config Class Initialized
INFO - 2021-12-10 03:42:02 --> Loader Class Initialized
INFO - 2021-12-10 03:42:02 --> Helper loaded: url_helper
INFO - 2021-12-10 03:42:02 --> Helper loaded: file_helper
INFO - 2021-12-10 03:42:02 --> Helper loaded: form_helper
INFO - 2021-12-10 03:42:02 --> Helper loaded: my_helper
INFO - 2021-12-10 03:42:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:42:02 --> Controller Class Initialized
INFO - 2021-12-10 03:42:02 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:42:02 --> Final output sent to browser
DEBUG - 2021-12-10 03:42:02 --> Total execution time: 0.0490
INFO - 2021-12-10 03:42:02 --> Config Class Initialized
INFO - 2021-12-10 03:42:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:42:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:42:02 --> Utf8 Class Initialized
INFO - 2021-12-10 03:42:02 --> URI Class Initialized
INFO - 2021-12-10 03:42:02 --> Router Class Initialized
INFO - 2021-12-10 03:42:02 --> Output Class Initialized
INFO - 2021-12-10 03:42:02 --> Security Class Initialized
DEBUG - 2021-12-10 03:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:42:02 --> Input Class Initialized
INFO - 2021-12-10 03:42:02 --> Language Class Initialized
INFO - 2021-12-10 03:42:02 --> Language Class Initialized
INFO - 2021-12-10 03:42:02 --> Config Class Initialized
INFO - 2021-12-10 03:42:02 --> Loader Class Initialized
INFO - 2021-12-10 03:42:02 --> Helper loaded: url_helper
INFO - 2021-12-10 03:42:02 --> Helper loaded: file_helper
INFO - 2021-12-10 03:42:02 --> Helper loaded: form_helper
INFO - 2021-12-10 03:42:02 --> Helper loaded: my_helper
INFO - 2021-12-10 03:42:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:42:02 --> Controller Class Initialized
DEBUG - 2021-12-10 03:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:42:03 --> Final output sent to browser
DEBUG - 2021-12-10 03:42:03 --> Total execution time: 0.7600
INFO - 2021-12-10 03:42:06 --> Config Class Initialized
INFO - 2021-12-10 03:42:06 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:42:06 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:42:06 --> Utf8 Class Initialized
INFO - 2021-12-10 03:42:06 --> URI Class Initialized
INFO - 2021-12-10 03:42:06 --> Router Class Initialized
INFO - 2021-12-10 03:42:06 --> Output Class Initialized
INFO - 2021-12-10 03:42:06 --> Security Class Initialized
DEBUG - 2021-12-10 03:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:42:06 --> Input Class Initialized
INFO - 2021-12-10 03:42:06 --> Language Class Initialized
INFO - 2021-12-10 03:42:06 --> Language Class Initialized
INFO - 2021-12-10 03:42:06 --> Config Class Initialized
INFO - 2021-12-10 03:42:06 --> Loader Class Initialized
INFO - 2021-12-10 03:42:06 --> Helper loaded: url_helper
INFO - 2021-12-10 03:42:06 --> Helper loaded: file_helper
INFO - 2021-12-10 03:42:06 --> Helper loaded: form_helper
INFO - 2021-12-10 03:42:06 --> Helper loaded: my_helper
INFO - 2021-12-10 03:42:06 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:42:06 --> Controller Class Initialized
DEBUG - 2021-12-10 03:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:42:06 --> Final output sent to browser
DEBUG - 2021-12-10 03:42:06 --> Total execution time: 0.1030
INFO - 2021-12-10 03:42:18 --> Config Class Initialized
INFO - 2021-12-10 03:42:18 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:42:18 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:42:18 --> Utf8 Class Initialized
INFO - 2021-12-10 03:42:18 --> URI Class Initialized
INFO - 2021-12-10 03:42:18 --> Router Class Initialized
INFO - 2021-12-10 03:42:18 --> Output Class Initialized
INFO - 2021-12-10 03:42:18 --> Security Class Initialized
DEBUG - 2021-12-10 03:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:42:18 --> Input Class Initialized
INFO - 2021-12-10 03:42:18 --> Language Class Initialized
INFO - 2021-12-10 03:42:18 --> Language Class Initialized
INFO - 2021-12-10 03:42:18 --> Config Class Initialized
INFO - 2021-12-10 03:42:18 --> Loader Class Initialized
INFO - 2021-12-10 03:42:18 --> Helper loaded: url_helper
INFO - 2021-12-10 03:42:18 --> Helper loaded: file_helper
INFO - 2021-12-10 03:42:18 --> Helper loaded: form_helper
INFO - 2021-12-10 03:42:18 --> Helper loaded: my_helper
INFO - 2021-12-10 03:42:18 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:42:18 --> Controller Class Initialized
DEBUG - 2021-12-10 03:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:42:18 --> Final output sent to browser
DEBUG - 2021-12-10 03:42:18 --> Total execution time: 0.0490
INFO - 2021-12-10 03:42:22 --> Config Class Initialized
INFO - 2021-12-10 03:42:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:42:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:42:22 --> Utf8 Class Initialized
INFO - 2021-12-10 03:42:22 --> URI Class Initialized
INFO - 2021-12-10 03:42:22 --> Router Class Initialized
INFO - 2021-12-10 03:42:22 --> Output Class Initialized
INFO - 2021-12-10 03:42:22 --> Security Class Initialized
DEBUG - 2021-12-10 03:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:42:22 --> Input Class Initialized
INFO - 2021-12-10 03:42:22 --> Language Class Initialized
INFO - 2021-12-10 03:42:22 --> Language Class Initialized
INFO - 2021-12-10 03:42:22 --> Config Class Initialized
INFO - 2021-12-10 03:42:22 --> Loader Class Initialized
INFO - 2021-12-10 03:42:22 --> Helper loaded: url_helper
INFO - 2021-12-10 03:42:22 --> Helper loaded: file_helper
INFO - 2021-12-10 03:42:22 --> Helper loaded: form_helper
INFO - 2021-12-10 03:42:22 --> Helper loaded: my_helper
INFO - 2021-12-10 03:42:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:42:22 --> Controller Class Initialized
DEBUG - 2021-12-10 03:42:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-12-10 03:42:22 --> Final output sent to browser
DEBUG - 2021-12-10 03:42:22 --> Total execution time: 0.1880
INFO - 2021-12-10 03:42:47 --> Config Class Initialized
INFO - 2021-12-10 03:42:47 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:42:47 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:42:47 --> Utf8 Class Initialized
INFO - 2021-12-10 03:42:47 --> URI Class Initialized
INFO - 2021-12-10 03:42:47 --> Router Class Initialized
INFO - 2021-12-10 03:42:47 --> Output Class Initialized
INFO - 2021-12-10 03:42:47 --> Security Class Initialized
DEBUG - 2021-12-10 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:42:47 --> Input Class Initialized
INFO - 2021-12-10 03:42:47 --> Language Class Initialized
INFO - 2021-12-10 03:42:47 --> Language Class Initialized
INFO - 2021-12-10 03:42:47 --> Config Class Initialized
INFO - 2021-12-10 03:42:47 --> Loader Class Initialized
INFO - 2021-12-10 03:42:47 --> Helper loaded: url_helper
INFO - 2021-12-10 03:42:47 --> Helper loaded: file_helper
INFO - 2021-12-10 03:42:47 --> Helper loaded: form_helper
INFO - 2021-12-10 03:42:47 --> Helper loaded: my_helper
INFO - 2021-12-10 03:42:47 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:42:47 --> Controller Class Initialized
DEBUG - 2021-12-10 03:42:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-12-10 03:42:47 --> Final output sent to browser
DEBUG - 2021-12-10 03:42:47 --> Total execution time: 0.1300
INFO - 2021-12-10 03:42:59 --> Config Class Initialized
INFO - 2021-12-10 03:42:59 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:42:59 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:42:59 --> Utf8 Class Initialized
INFO - 2021-12-10 03:42:59 --> URI Class Initialized
INFO - 2021-12-10 03:42:59 --> Router Class Initialized
INFO - 2021-12-10 03:42:59 --> Output Class Initialized
INFO - 2021-12-10 03:42:59 --> Security Class Initialized
DEBUG - 2021-12-10 03:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:42:59 --> Input Class Initialized
INFO - 2021-12-10 03:42:59 --> Language Class Initialized
INFO - 2021-12-10 03:42:59 --> Language Class Initialized
INFO - 2021-12-10 03:42:59 --> Config Class Initialized
INFO - 2021-12-10 03:42:59 --> Loader Class Initialized
INFO - 2021-12-10 03:42:59 --> Helper loaded: url_helper
INFO - 2021-12-10 03:42:59 --> Helper loaded: file_helper
INFO - 2021-12-10 03:42:59 --> Helper loaded: form_helper
INFO - 2021-12-10 03:42:59 --> Helper loaded: my_helper
INFO - 2021-12-10 03:42:59 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:42:59 --> Controller Class Initialized
DEBUG - 2021-12-10 03:42:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-12-10 03:42:59 --> Final output sent to browser
DEBUG - 2021-12-10 03:42:59 --> Total execution time: 0.1350
INFO - 2021-12-10 03:45:08 --> Config Class Initialized
INFO - 2021-12-10 03:45:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:45:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:45:08 --> Utf8 Class Initialized
INFO - 2021-12-10 03:45:08 --> URI Class Initialized
INFO - 2021-12-10 03:45:08 --> Router Class Initialized
INFO - 2021-12-10 03:45:08 --> Output Class Initialized
INFO - 2021-12-10 03:45:08 --> Security Class Initialized
DEBUG - 2021-12-10 03:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:45:08 --> Input Class Initialized
INFO - 2021-12-10 03:45:08 --> Language Class Initialized
INFO - 2021-12-10 03:45:08 --> Language Class Initialized
INFO - 2021-12-10 03:45:08 --> Config Class Initialized
INFO - 2021-12-10 03:45:08 --> Loader Class Initialized
INFO - 2021-12-10 03:45:08 --> Helper loaded: url_helper
INFO - 2021-12-10 03:45:08 --> Helper loaded: file_helper
INFO - 2021-12-10 03:45:08 --> Helper loaded: form_helper
INFO - 2021-12-10 03:45:08 --> Helper loaded: my_helper
INFO - 2021-12-10 03:45:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:45:08 --> Controller Class Initialized
INFO - 2021-12-10 03:45:08 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:45:08 --> Config Class Initialized
INFO - 2021-12-10 03:45:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:45:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:45:08 --> Utf8 Class Initialized
INFO - 2021-12-10 03:45:08 --> URI Class Initialized
INFO - 2021-12-10 03:45:08 --> Router Class Initialized
INFO - 2021-12-10 03:45:08 --> Output Class Initialized
INFO - 2021-12-10 03:45:08 --> Security Class Initialized
DEBUG - 2021-12-10 03:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:45:08 --> Input Class Initialized
INFO - 2021-12-10 03:45:08 --> Language Class Initialized
INFO - 2021-12-10 03:45:08 --> Language Class Initialized
INFO - 2021-12-10 03:45:08 --> Config Class Initialized
INFO - 2021-12-10 03:45:08 --> Loader Class Initialized
INFO - 2021-12-10 03:45:08 --> Helper loaded: url_helper
INFO - 2021-12-10 03:45:08 --> Helper loaded: file_helper
INFO - 2021-12-10 03:45:08 --> Helper loaded: form_helper
INFO - 2021-12-10 03:45:08 --> Helper loaded: my_helper
INFO - 2021-12-10 03:45:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:45:08 --> Controller Class Initialized
DEBUG - 2021-12-10 03:45:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:45:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:45:08 --> Final output sent to browser
DEBUG - 2021-12-10 03:45:08 --> Total execution time: 0.0380
INFO - 2021-12-10 03:45:23 --> Config Class Initialized
INFO - 2021-12-10 03:45:23 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:45:23 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:45:23 --> Utf8 Class Initialized
INFO - 2021-12-10 03:45:23 --> URI Class Initialized
INFO - 2021-12-10 03:45:23 --> Router Class Initialized
INFO - 2021-12-10 03:45:23 --> Output Class Initialized
INFO - 2021-12-10 03:45:23 --> Security Class Initialized
DEBUG - 2021-12-10 03:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:45:23 --> Input Class Initialized
INFO - 2021-12-10 03:45:23 --> Language Class Initialized
INFO - 2021-12-10 03:45:23 --> Language Class Initialized
INFO - 2021-12-10 03:45:23 --> Config Class Initialized
INFO - 2021-12-10 03:45:23 --> Loader Class Initialized
INFO - 2021-12-10 03:45:23 --> Helper loaded: url_helper
INFO - 2021-12-10 03:45:23 --> Helper loaded: file_helper
INFO - 2021-12-10 03:45:23 --> Helper loaded: form_helper
INFO - 2021-12-10 03:45:23 --> Helper loaded: my_helper
INFO - 2021-12-10 03:45:23 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:45:23 --> Controller Class Initialized
INFO - 2021-12-10 03:45:23 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:45:23 --> Final output sent to browser
DEBUG - 2021-12-10 03:45:23 --> Total execution time: 0.0490
INFO - 2021-12-10 03:45:23 --> Config Class Initialized
INFO - 2021-12-10 03:45:23 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:45:23 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:45:23 --> Utf8 Class Initialized
INFO - 2021-12-10 03:45:23 --> URI Class Initialized
INFO - 2021-12-10 03:45:23 --> Router Class Initialized
INFO - 2021-12-10 03:45:23 --> Output Class Initialized
INFO - 2021-12-10 03:45:23 --> Security Class Initialized
DEBUG - 2021-12-10 03:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:45:23 --> Input Class Initialized
INFO - 2021-12-10 03:45:23 --> Language Class Initialized
INFO - 2021-12-10 03:45:23 --> Language Class Initialized
INFO - 2021-12-10 03:45:23 --> Config Class Initialized
INFO - 2021-12-10 03:45:23 --> Loader Class Initialized
INFO - 2021-12-10 03:45:23 --> Helper loaded: url_helper
INFO - 2021-12-10 03:45:23 --> Helper loaded: file_helper
INFO - 2021-12-10 03:45:23 --> Helper loaded: form_helper
INFO - 2021-12-10 03:45:23 --> Helper loaded: my_helper
INFO - 2021-12-10 03:45:23 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:45:23 --> Controller Class Initialized
DEBUG - 2021-12-10 03:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:45:24 --> Final output sent to browser
DEBUG - 2021-12-10 03:45:24 --> Total execution time: 0.7400
INFO - 2021-12-10 03:46:33 --> Config Class Initialized
INFO - 2021-12-10 03:46:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:46:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:46:33 --> Utf8 Class Initialized
INFO - 2021-12-10 03:46:33 --> URI Class Initialized
INFO - 2021-12-10 03:46:33 --> Router Class Initialized
INFO - 2021-12-10 03:46:33 --> Output Class Initialized
INFO - 2021-12-10 03:46:33 --> Security Class Initialized
DEBUG - 2021-12-10 03:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:46:33 --> Input Class Initialized
INFO - 2021-12-10 03:46:33 --> Language Class Initialized
INFO - 2021-12-10 03:46:33 --> Language Class Initialized
INFO - 2021-12-10 03:46:33 --> Config Class Initialized
INFO - 2021-12-10 03:46:33 --> Loader Class Initialized
INFO - 2021-12-10 03:46:33 --> Helper loaded: url_helper
INFO - 2021-12-10 03:46:33 --> Helper loaded: file_helper
INFO - 2021-12-10 03:46:33 --> Helper loaded: form_helper
INFO - 2021-12-10 03:46:33 --> Helper loaded: my_helper
INFO - 2021-12-10 03:46:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:46:33 --> Controller Class Initialized
DEBUG - 2021-12-10 03:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 03:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:46:33 --> Final output sent to browser
DEBUG - 2021-12-10 03:46:33 --> Total execution time: 0.0480
INFO - 2021-12-10 03:46:33 --> Config Class Initialized
INFO - 2021-12-10 03:46:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:46:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:46:33 --> Utf8 Class Initialized
INFO - 2021-12-10 03:46:33 --> URI Class Initialized
INFO - 2021-12-10 03:46:33 --> Router Class Initialized
INFO - 2021-12-10 03:46:33 --> Output Class Initialized
INFO - 2021-12-10 03:46:33 --> Security Class Initialized
DEBUG - 2021-12-10 03:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:46:33 --> Input Class Initialized
INFO - 2021-12-10 03:46:33 --> Language Class Initialized
INFO - 2021-12-10 03:46:33 --> Language Class Initialized
INFO - 2021-12-10 03:46:33 --> Config Class Initialized
INFO - 2021-12-10 03:46:33 --> Loader Class Initialized
INFO - 2021-12-10 03:46:33 --> Helper loaded: url_helper
INFO - 2021-12-10 03:46:33 --> Helper loaded: file_helper
INFO - 2021-12-10 03:46:33 --> Helper loaded: form_helper
INFO - 2021-12-10 03:46:33 --> Helper loaded: my_helper
INFO - 2021-12-10 03:46:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:46:33 --> Controller Class Initialized
INFO - 2021-12-10 03:46:38 --> Config Class Initialized
INFO - 2021-12-10 03:46:38 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:46:38 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:46:38 --> Utf8 Class Initialized
INFO - 2021-12-10 03:46:38 --> URI Class Initialized
INFO - 2021-12-10 03:46:38 --> Router Class Initialized
INFO - 2021-12-10 03:46:38 --> Output Class Initialized
INFO - 2021-12-10 03:46:38 --> Security Class Initialized
DEBUG - 2021-12-10 03:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:46:38 --> Input Class Initialized
INFO - 2021-12-10 03:46:38 --> Language Class Initialized
INFO - 2021-12-10 03:46:38 --> Language Class Initialized
INFO - 2021-12-10 03:46:38 --> Config Class Initialized
INFO - 2021-12-10 03:46:38 --> Loader Class Initialized
INFO - 2021-12-10 03:46:38 --> Helper loaded: url_helper
INFO - 2021-12-10 03:46:38 --> Helper loaded: file_helper
INFO - 2021-12-10 03:46:38 --> Helper loaded: form_helper
INFO - 2021-12-10 03:46:38 --> Helper loaded: my_helper
INFO - 2021-12-10 03:46:38 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:46:38 --> Controller Class Initialized
INFO - 2021-12-10 03:46:38 --> Final output sent to browser
DEBUG - 2021-12-10 03:46:38 --> Total execution time: 0.0650
INFO - 2021-12-10 03:46:38 --> Config Class Initialized
INFO - 2021-12-10 03:46:38 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:46:38 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:46:38 --> Utf8 Class Initialized
INFO - 2021-12-10 03:46:38 --> URI Class Initialized
INFO - 2021-12-10 03:46:38 --> Router Class Initialized
INFO - 2021-12-10 03:46:38 --> Output Class Initialized
INFO - 2021-12-10 03:46:38 --> Security Class Initialized
DEBUG - 2021-12-10 03:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:46:38 --> Input Class Initialized
INFO - 2021-12-10 03:46:38 --> Language Class Initialized
INFO - 2021-12-10 03:46:38 --> Language Class Initialized
INFO - 2021-12-10 03:46:38 --> Config Class Initialized
INFO - 2021-12-10 03:46:38 --> Loader Class Initialized
INFO - 2021-12-10 03:46:38 --> Helper loaded: url_helper
INFO - 2021-12-10 03:46:38 --> Helper loaded: file_helper
INFO - 2021-12-10 03:46:38 --> Helper loaded: form_helper
INFO - 2021-12-10 03:46:38 --> Helper loaded: my_helper
INFO - 2021-12-10 03:46:38 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:46:38 --> Controller Class Initialized
INFO - 2021-12-10 03:46:42 --> Config Class Initialized
INFO - 2021-12-10 03:46:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:46:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:46:42 --> Utf8 Class Initialized
INFO - 2021-12-10 03:46:42 --> URI Class Initialized
INFO - 2021-12-10 03:46:42 --> Router Class Initialized
INFO - 2021-12-10 03:46:42 --> Output Class Initialized
INFO - 2021-12-10 03:46:42 --> Security Class Initialized
DEBUG - 2021-12-10 03:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:46:42 --> Input Class Initialized
INFO - 2021-12-10 03:46:42 --> Language Class Initialized
INFO - 2021-12-10 03:46:42 --> Language Class Initialized
INFO - 2021-12-10 03:46:42 --> Config Class Initialized
INFO - 2021-12-10 03:46:42 --> Loader Class Initialized
INFO - 2021-12-10 03:46:42 --> Helper loaded: url_helper
INFO - 2021-12-10 03:46:42 --> Helper loaded: file_helper
INFO - 2021-12-10 03:46:42 --> Helper loaded: form_helper
INFO - 2021-12-10 03:46:42 --> Helper loaded: my_helper
INFO - 2021-12-10 03:46:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:46:42 --> Controller Class Initialized
INFO - 2021-12-10 03:46:42 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:46:42 --> Config Class Initialized
INFO - 2021-12-10 03:46:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:46:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:46:42 --> Utf8 Class Initialized
INFO - 2021-12-10 03:46:42 --> URI Class Initialized
INFO - 2021-12-10 03:46:42 --> Router Class Initialized
INFO - 2021-12-10 03:46:42 --> Output Class Initialized
INFO - 2021-12-10 03:46:42 --> Security Class Initialized
DEBUG - 2021-12-10 03:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:46:42 --> Input Class Initialized
INFO - 2021-12-10 03:46:42 --> Language Class Initialized
INFO - 2021-12-10 03:46:42 --> Language Class Initialized
INFO - 2021-12-10 03:46:42 --> Config Class Initialized
INFO - 2021-12-10 03:46:42 --> Loader Class Initialized
INFO - 2021-12-10 03:46:42 --> Helper loaded: url_helper
INFO - 2021-12-10 03:46:42 --> Helper loaded: file_helper
INFO - 2021-12-10 03:46:42 --> Helper loaded: form_helper
INFO - 2021-12-10 03:46:42 --> Helper loaded: my_helper
INFO - 2021-12-10 03:46:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:46:42 --> Controller Class Initialized
DEBUG - 2021-12-10 03:46:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:46:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:46:42 --> Final output sent to browser
DEBUG - 2021-12-10 03:46:42 --> Total execution time: 0.0610
INFO - 2021-12-10 03:48:04 --> Config Class Initialized
INFO - 2021-12-10 03:48:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:04 --> URI Class Initialized
INFO - 2021-12-10 03:48:04 --> Router Class Initialized
INFO - 2021-12-10 03:48:04 --> Output Class Initialized
INFO - 2021-12-10 03:48:04 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:04 --> Input Class Initialized
INFO - 2021-12-10 03:48:04 --> Language Class Initialized
INFO - 2021-12-10 03:48:04 --> Language Class Initialized
INFO - 2021-12-10 03:48:04 --> Config Class Initialized
INFO - 2021-12-10 03:48:04 --> Loader Class Initialized
INFO - 2021-12-10 03:48:04 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:04 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:04 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:04 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:04 --> Controller Class Initialized
INFO - 2021-12-10 03:48:04 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:48:04 --> Final output sent to browser
DEBUG - 2021-12-10 03:48:04 --> Total execution time: 0.0620
INFO - 2021-12-10 03:48:04 --> Config Class Initialized
INFO - 2021-12-10 03:48:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:04 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:04 --> URI Class Initialized
INFO - 2021-12-10 03:48:04 --> Router Class Initialized
INFO - 2021-12-10 03:48:05 --> Output Class Initialized
INFO - 2021-12-10 03:48:05 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:05 --> Input Class Initialized
INFO - 2021-12-10 03:48:05 --> Language Class Initialized
INFO - 2021-12-10 03:48:05 --> Language Class Initialized
INFO - 2021-12-10 03:48:05 --> Config Class Initialized
INFO - 2021-12-10 03:48:05 --> Loader Class Initialized
INFO - 2021-12-10 03:48:05 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:05 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:05 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:05 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:05 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:05 --> Controller Class Initialized
DEBUG - 2021-12-10 03:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:48:05 --> Final output sent to browser
DEBUG - 2021-12-10 03:48:05 --> Total execution time: 0.1450
INFO - 2021-12-10 03:48:07 --> Config Class Initialized
INFO - 2021-12-10 03:48:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:07 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:07 --> URI Class Initialized
INFO - 2021-12-10 03:48:07 --> Router Class Initialized
INFO - 2021-12-10 03:48:07 --> Output Class Initialized
INFO - 2021-12-10 03:48:07 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:07 --> Input Class Initialized
INFO - 2021-12-10 03:48:07 --> Language Class Initialized
INFO - 2021-12-10 03:48:07 --> Language Class Initialized
INFO - 2021-12-10 03:48:07 --> Config Class Initialized
INFO - 2021-12-10 03:48:07 --> Loader Class Initialized
INFO - 2021-12-10 03:48:07 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:07 --> Controller Class Initialized
DEBUG - 2021-12-10 03:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-10 03:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:48:07 --> Final output sent to browser
DEBUG - 2021-12-10 03:48:07 --> Total execution time: 0.0940
INFO - 2021-12-10 03:48:07 --> Config Class Initialized
INFO - 2021-12-10 03:48:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:07 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:07 --> URI Class Initialized
INFO - 2021-12-10 03:48:07 --> Router Class Initialized
INFO - 2021-12-10 03:48:07 --> Output Class Initialized
INFO - 2021-12-10 03:48:07 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:07 --> Input Class Initialized
INFO - 2021-12-10 03:48:07 --> Language Class Initialized
INFO - 2021-12-10 03:48:07 --> Language Class Initialized
INFO - 2021-12-10 03:48:07 --> Config Class Initialized
INFO - 2021-12-10 03:48:07 --> Loader Class Initialized
INFO - 2021-12-10 03:48:07 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:07 --> Controller Class Initialized
DEBUG - 2021-12-10 03:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 03:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:48:07 --> Final output sent to browser
DEBUG - 2021-12-10 03:48:07 --> Total execution time: 0.0510
INFO - 2021-12-10 03:48:07 --> Config Class Initialized
INFO - 2021-12-10 03:48:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:07 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:07 --> URI Class Initialized
INFO - 2021-12-10 03:48:07 --> Router Class Initialized
INFO - 2021-12-10 03:48:07 --> Output Class Initialized
INFO - 2021-12-10 03:48:07 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:07 --> Input Class Initialized
INFO - 2021-12-10 03:48:07 --> Language Class Initialized
INFO - 2021-12-10 03:48:07 --> Language Class Initialized
INFO - 2021-12-10 03:48:07 --> Config Class Initialized
INFO - 2021-12-10 03:48:07 --> Loader Class Initialized
INFO - 2021-12-10 03:48:07 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:07 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:07 --> Controller Class Initialized
INFO - 2021-12-10 03:48:09 --> Config Class Initialized
INFO - 2021-12-10 03:48:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:09 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:09 --> URI Class Initialized
INFO - 2021-12-10 03:48:09 --> Router Class Initialized
INFO - 2021-12-10 03:48:09 --> Output Class Initialized
INFO - 2021-12-10 03:48:09 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:09 --> Input Class Initialized
INFO - 2021-12-10 03:48:09 --> Language Class Initialized
INFO - 2021-12-10 03:48:09 --> Language Class Initialized
INFO - 2021-12-10 03:48:09 --> Config Class Initialized
INFO - 2021-12-10 03:48:09 --> Loader Class Initialized
INFO - 2021-12-10 03:48:09 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:09 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:09 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:09 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:09 --> Controller Class Initialized
INFO - 2021-12-10 03:48:09 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:48:09 --> Config Class Initialized
INFO - 2021-12-10 03:48:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:09 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:09 --> URI Class Initialized
INFO - 2021-12-10 03:48:09 --> Router Class Initialized
INFO - 2021-12-10 03:48:09 --> Output Class Initialized
INFO - 2021-12-10 03:48:09 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:09 --> Input Class Initialized
INFO - 2021-12-10 03:48:09 --> Language Class Initialized
INFO - 2021-12-10 03:48:09 --> Language Class Initialized
INFO - 2021-12-10 03:48:09 --> Config Class Initialized
INFO - 2021-12-10 03:48:09 --> Loader Class Initialized
INFO - 2021-12-10 03:48:09 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:09 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:09 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:09 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:09 --> Controller Class Initialized
DEBUG - 2021-12-10 03:48:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:48:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:48:09 --> Final output sent to browser
DEBUG - 2021-12-10 03:48:09 --> Total execution time: 0.0350
INFO - 2021-12-10 03:48:13 --> Config Class Initialized
INFO - 2021-12-10 03:48:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:13 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:13 --> URI Class Initialized
INFO - 2021-12-10 03:48:13 --> Router Class Initialized
INFO - 2021-12-10 03:48:13 --> Output Class Initialized
INFO - 2021-12-10 03:48:13 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:13 --> Input Class Initialized
INFO - 2021-12-10 03:48:13 --> Language Class Initialized
INFO - 2021-12-10 03:48:13 --> Language Class Initialized
INFO - 2021-12-10 03:48:13 --> Config Class Initialized
INFO - 2021-12-10 03:48:13 --> Loader Class Initialized
INFO - 2021-12-10 03:48:13 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:13 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:13 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:13 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:13 --> Controller Class Initialized
INFO - 2021-12-10 03:48:13 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:48:13 --> Final output sent to browser
DEBUG - 2021-12-10 03:48:13 --> Total execution time: 0.0550
INFO - 2021-12-10 03:48:13 --> Config Class Initialized
INFO - 2021-12-10 03:48:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:48:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:48:13 --> Utf8 Class Initialized
INFO - 2021-12-10 03:48:13 --> URI Class Initialized
INFO - 2021-12-10 03:48:13 --> Router Class Initialized
INFO - 2021-12-10 03:48:13 --> Output Class Initialized
INFO - 2021-12-10 03:48:13 --> Security Class Initialized
DEBUG - 2021-12-10 03:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:48:13 --> Input Class Initialized
INFO - 2021-12-10 03:48:13 --> Language Class Initialized
INFO - 2021-12-10 03:48:13 --> Language Class Initialized
INFO - 2021-12-10 03:48:13 --> Config Class Initialized
INFO - 2021-12-10 03:48:13 --> Loader Class Initialized
INFO - 2021-12-10 03:48:13 --> Helper loaded: url_helper
INFO - 2021-12-10 03:48:13 --> Helper loaded: file_helper
INFO - 2021-12-10 03:48:13 --> Helper loaded: form_helper
INFO - 2021-12-10 03:48:13 --> Helper loaded: my_helper
INFO - 2021-12-10 03:48:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:48:13 --> Controller Class Initialized
DEBUG - 2021-12-10 03:48:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:48:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:48:13 --> Final output sent to browser
DEBUG - 2021-12-10 03:48:13 --> Total execution time: 0.1420
INFO - 2021-12-10 03:49:03 --> Config Class Initialized
INFO - 2021-12-10 03:49:03 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:03 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:03 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:03 --> URI Class Initialized
INFO - 2021-12-10 03:49:03 --> Router Class Initialized
INFO - 2021-12-10 03:49:03 --> Output Class Initialized
INFO - 2021-12-10 03:49:03 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:03 --> Input Class Initialized
INFO - 2021-12-10 03:49:03 --> Language Class Initialized
INFO - 2021-12-10 03:49:03 --> Language Class Initialized
INFO - 2021-12-10 03:49:03 --> Config Class Initialized
INFO - 2021-12-10 03:49:03 --> Loader Class Initialized
INFO - 2021-12-10 03:49:03 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:03 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:03 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:03 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:03 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:03 --> Controller Class Initialized
DEBUG - 2021-12-10 03:49:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:49:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:49:03 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:03 --> Total execution time: 0.0800
INFO - 2021-12-10 03:49:05 --> Config Class Initialized
INFO - 2021-12-10 03:49:05 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:05 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:05 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:05 --> URI Class Initialized
INFO - 2021-12-10 03:49:05 --> Router Class Initialized
INFO - 2021-12-10 03:49:05 --> Output Class Initialized
INFO - 2021-12-10 03:49:05 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:05 --> Input Class Initialized
INFO - 2021-12-10 03:49:05 --> Language Class Initialized
INFO - 2021-12-10 03:49:05 --> Language Class Initialized
INFO - 2021-12-10 03:49:05 --> Config Class Initialized
INFO - 2021-12-10 03:49:05 --> Loader Class Initialized
INFO - 2021-12-10 03:49:05 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:05 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:05 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:05 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:05 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:05 --> Controller Class Initialized
DEBUG - 2021-12-10 03:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:49:06 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:06 --> Total execution time: 0.1080
INFO - 2021-12-10 03:49:10 --> Config Class Initialized
INFO - 2021-12-10 03:49:10 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:10 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:10 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:10 --> URI Class Initialized
INFO - 2021-12-10 03:49:10 --> Router Class Initialized
INFO - 2021-12-10 03:49:10 --> Output Class Initialized
INFO - 2021-12-10 03:49:10 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:10 --> Input Class Initialized
INFO - 2021-12-10 03:49:10 --> Language Class Initialized
INFO - 2021-12-10 03:49:10 --> Language Class Initialized
INFO - 2021-12-10 03:49:10 --> Config Class Initialized
INFO - 2021-12-10 03:49:10 --> Loader Class Initialized
INFO - 2021-12-10 03:49:10 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:10 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:10 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:10 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:10 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:10 --> Controller Class Initialized
DEBUG - 2021-12-10 03:49:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:49:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:49:10 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:10 --> Total execution time: 0.0690
INFO - 2021-12-10 03:49:12 --> Config Class Initialized
INFO - 2021-12-10 03:49:12 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:12 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:12 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:12 --> URI Class Initialized
INFO - 2021-12-10 03:49:12 --> Router Class Initialized
INFO - 2021-12-10 03:49:12 --> Output Class Initialized
INFO - 2021-12-10 03:49:12 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:12 --> Input Class Initialized
INFO - 2021-12-10 03:49:12 --> Language Class Initialized
INFO - 2021-12-10 03:49:13 --> Language Class Initialized
INFO - 2021-12-10 03:49:13 --> Config Class Initialized
INFO - 2021-12-10 03:49:13 --> Loader Class Initialized
INFO - 2021-12-10 03:49:13 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:13 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:13 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:13 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:13 --> Controller Class Initialized
DEBUG - 2021-12-10 03:49:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-12-10 03:49:13 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:13 --> Total execution time: 0.0680
INFO - 2021-12-10 03:49:27 --> Config Class Initialized
INFO - 2021-12-10 03:49:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:27 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:27 --> URI Class Initialized
INFO - 2021-12-10 03:49:27 --> Router Class Initialized
INFO - 2021-12-10 03:49:27 --> Output Class Initialized
INFO - 2021-12-10 03:49:27 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:27 --> Input Class Initialized
INFO - 2021-12-10 03:49:27 --> Language Class Initialized
INFO - 2021-12-10 03:49:27 --> Language Class Initialized
INFO - 2021-12-10 03:49:27 --> Config Class Initialized
INFO - 2021-12-10 03:49:27 --> Loader Class Initialized
INFO - 2021-12-10 03:49:27 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:27 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:27 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:27 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:27 --> Controller Class Initialized
INFO - 2021-12-10 03:49:27 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:49:27 --> Config Class Initialized
INFO - 2021-12-10 03:49:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:27 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:27 --> URI Class Initialized
INFO - 2021-12-10 03:49:27 --> Router Class Initialized
INFO - 2021-12-10 03:49:27 --> Output Class Initialized
INFO - 2021-12-10 03:49:27 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:27 --> Input Class Initialized
INFO - 2021-12-10 03:49:27 --> Language Class Initialized
INFO - 2021-12-10 03:49:27 --> Language Class Initialized
INFO - 2021-12-10 03:49:27 --> Config Class Initialized
INFO - 2021-12-10 03:49:27 --> Loader Class Initialized
INFO - 2021-12-10 03:49:27 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:27 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:27 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:27 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:27 --> Controller Class Initialized
DEBUG - 2021-12-10 03:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:49:27 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:27 --> Total execution time: 0.0390
INFO - 2021-12-10 03:49:39 --> Config Class Initialized
INFO - 2021-12-10 03:49:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:39 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:39 --> URI Class Initialized
INFO - 2021-12-10 03:49:39 --> Router Class Initialized
INFO - 2021-12-10 03:49:39 --> Output Class Initialized
INFO - 2021-12-10 03:49:39 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:39 --> Input Class Initialized
INFO - 2021-12-10 03:49:39 --> Language Class Initialized
INFO - 2021-12-10 03:49:39 --> Language Class Initialized
INFO - 2021-12-10 03:49:39 --> Config Class Initialized
INFO - 2021-12-10 03:49:39 --> Loader Class Initialized
INFO - 2021-12-10 03:49:39 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:39 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:39 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:39 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:39 --> Controller Class Initialized
INFO - 2021-12-10 03:49:39 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:49:39 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:39 --> Total execution time: 0.0520
INFO - 2021-12-10 03:49:40 --> Config Class Initialized
INFO - 2021-12-10 03:49:40 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:40 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:40 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:40 --> URI Class Initialized
INFO - 2021-12-10 03:49:40 --> Router Class Initialized
INFO - 2021-12-10 03:49:40 --> Output Class Initialized
INFO - 2021-12-10 03:49:40 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:40 --> Input Class Initialized
INFO - 2021-12-10 03:49:40 --> Language Class Initialized
INFO - 2021-12-10 03:49:40 --> Language Class Initialized
INFO - 2021-12-10 03:49:40 --> Config Class Initialized
INFO - 2021-12-10 03:49:40 --> Loader Class Initialized
INFO - 2021-12-10 03:49:40 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:40 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:40 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:40 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:40 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:40 --> Controller Class Initialized
DEBUG - 2021-12-10 03:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:49:40 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:40 --> Total execution time: 0.2070
INFO - 2021-12-10 03:49:41 --> Config Class Initialized
INFO - 2021-12-10 03:49:41 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:41 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:41 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:41 --> URI Class Initialized
INFO - 2021-12-10 03:49:41 --> Router Class Initialized
INFO - 2021-12-10 03:49:41 --> Output Class Initialized
INFO - 2021-12-10 03:49:41 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:41 --> Input Class Initialized
INFO - 2021-12-10 03:49:41 --> Language Class Initialized
INFO - 2021-12-10 03:49:41 --> Language Class Initialized
INFO - 2021-12-10 03:49:41 --> Config Class Initialized
INFO - 2021-12-10 03:49:41 --> Loader Class Initialized
INFO - 2021-12-10 03:49:41 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:41 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:41 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:41 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:41 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:41 --> Controller Class Initialized
DEBUG - 2021-12-10 03:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 03:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:49:41 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:41 --> Total execution time: 0.0560
INFO - 2021-12-10 03:49:41 --> Config Class Initialized
INFO - 2021-12-10 03:49:41 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:41 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:41 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:41 --> URI Class Initialized
INFO - 2021-12-10 03:49:41 --> Router Class Initialized
INFO - 2021-12-10 03:49:41 --> Output Class Initialized
INFO - 2021-12-10 03:49:41 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:41 --> Input Class Initialized
INFO - 2021-12-10 03:49:41 --> Language Class Initialized
INFO - 2021-12-10 03:49:41 --> Language Class Initialized
INFO - 2021-12-10 03:49:41 --> Config Class Initialized
INFO - 2021-12-10 03:49:41 --> Loader Class Initialized
INFO - 2021-12-10 03:49:41 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:41 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:41 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:41 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:41 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:41 --> Controller Class Initialized
INFO - 2021-12-10 03:49:43 --> Config Class Initialized
INFO - 2021-12-10 03:49:43 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:43 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:43 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:43 --> URI Class Initialized
INFO - 2021-12-10 03:49:43 --> Router Class Initialized
INFO - 2021-12-10 03:49:43 --> Output Class Initialized
INFO - 2021-12-10 03:49:43 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:43 --> Input Class Initialized
INFO - 2021-12-10 03:49:43 --> Language Class Initialized
INFO - 2021-12-10 03:49:43 --> Language Class Initialized
INFO - 2021-12-10 03:49:43 --> Config Class Initialized
INFO - 2021-12-10 03:49:43 --> Loader Class Initialized
INFO - 2021-12-10 03:49:43 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:43 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:43 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:43 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:43 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:43 --> Controller Class Initialized
INFO - 2021-12-10 03:49:43 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:43 --> Total execution time: 0.0610
INFO - 2021-12-10 03:49:43 --> Config Class Initialized
INFO - 2021-12-10 03:49:43 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:43 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:43 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:43 --> URI Class Initialized
INFO - 2021-12-10 03:49:43 --> Router Class Initialized
INFO - 2021-12-10 03:49:43 --> Output Class Initialized
INFO - 2021-12-10 03:49:43 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:43 --> Input Class Initialized
INFO - 2021-12-10 03:49:43 --> Language Class Initialized
INFO - 2021-12-10 03:49:43 --> Language Class Initialized
INFO - 2021-12-10 03:49:43 --> Config Class Initialized
INFO - 2021-12-10 03:49:43 --> Loader Class Initialized
INFO - 2021-12-10 03:49:43 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:43 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:43 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:43 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:43 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:43 --> Controller Class Initialized
INFO - 2021-12-10 03:49:48 --> Config Class Initialized
INFO - 2021-12-10 03:49:48 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:48 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:48 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:48 --> URI Class Initialized
INFO - 2021-12-10 03:49:48 --> Router Class Initialized
INFO - 2021-12-10 03:49:48 --> Output Class Initialized
INFO - 2021-12-10 03:49:48 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:48 --> Input Class Initialized
INFO - 2021-12-10 03:49:48 --> Language Class Initialized
INFO - 2021-12-10 03:49:48 --> Language Class Initialized
INFO - 2021-12-10 03:49:48 --> Config Class Initialized
INFO - 2021-12-10 03:49:48 --> Loader Class Initialized
INFO - 2021-12-10 03:49:48 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:48 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:48 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:48 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:48 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:48 --> Controller Class Initialized
INFO - 2021-12-10 03:49:48 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:49:48 --> Config Class Initialized
INFO - 2021-12-10 03:49:48 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:49:48 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:49:48 --> Utf8 Class Initialized
INFO - 2021-12-10 03:49:48 --> URI Class Initialized
INFO - 2021-12-10 03:49:48 --> Router Class Initialized
INFO - 2021-12-10 03:49:48 --> Output Class Initialized
INFO - 2021-12-10 03:49:48 --> Security Class Initialized
DEBUG - 2021-12-10 03:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:49:48 --> Input Class Initialized
INFO - 2021-12-10 03:49:48 --> Language Class Initialized
INFO - 2021-12-10 03:49:48 --> Language Class Initialized
INFO - 2021-12-10 03:49:48 --> Config Class Initialized
INFO - 2021-12-10 03:49:48 --> Loader Class Initialized
INFO - 2021-12-10 03:49:48 --> Helper loaded: url_helper
INFO - 2021-12-10 03:49:48 --> Helper loaded: file_helper
INFO - 2021-12-10 03:49:48 --> Helper loaded: form_helper
INFO - 2021-12-10 03:49:48 --> Helper loaded: my_helper
INFO - 2021-12-10 03:49:48 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:49:48 --> Controller Class Initialized
DEBUG - 2021-12-10 03:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:49:48 --> Final output sent to browser
DEBUG - 2021-12-10 03:49:48 --> Total execution time: 0.0340
INFO - 2021-12-10 03:51:02 --> Config Class Initialized
INFO - 2021-12-10 03:51:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:51:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:51:02 --> Utf8 Class Initialized
INFO - 2021-12-10 03:51:02 --> URI Class Initialized
INFO - 2021-12-10 03:51:02 --> Router Class Initialized
INFO - 2021-12-10 03:51:02 --> Output Class Initialized
INFO - 2021-12-10 03:51:02 --> Security Class Initialized
DEBUG - 2021-12-10 03:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:51:02 --> Input Class Initialized
INFO - 2021-12-10 03:51:02 --> Language Class Initialized
INFO - 2021-12-10 03:51:02 --> Language Class Initialized
INFO - 2021-12-10 03:51:02 --> Config Class Initialized
INFO - 2021-12-10 03:51:02 --> Loader Class Initialized
INFO - 2021-12-10 03:51:02 --> Helper loaded: url_helper
INFO - 2021-12-10 03:51:02 --> Helper loaded: file_helper
INFO - 2021-12-10 03:51:02 --> Helper loaded: form_helper
INFO - 2021-12-10 03:51:02 --> Helper loaded: my_helper
INFO - 2021-12-10 03:51:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:51:02 --> Controller Class Initialized
INFO - 2021-12-10 03:51:02 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:51:02 --> Final output sent to browser
DEBUG - 2021-12-10 03:51:02 --> Total execution time: 0.0600
INFO - 2021-12-10 03:51:02 --> Config Class Initialized
INFO - 2021-12-10 03:51:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:51:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:51:02 --> Utf8 Class Initialized
INFO - 2021-12-10 03:51:02 --> URI Class Initialized
INFO - 2021-12-10 03:51:02 --> Router Class Initialized
INFO - 2021-12-10 03:51:02 --> Output Class Initialized
INFO - 2021-12-10 03:51:02 --> Security Class Initialized
DEBUG - 2021-12-10 03:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:51:02 --> Input Class Initialized
INFO - 2021-12-10 03:51:02 --> Language Class Initialized
INFO - 2021-12-10 03:51:02 --> Language Class Initialized
INFO - 2021-12-10 03:51:02 --> Config Class Initialized
INFO - 2021-12-10 03:51:02 --> Loader Class Initialized
INFO - 2021-12-10 03:51:02 --> Helper loaded: url_helper
INFO - 2021-12-10 03:51:02 --> Helper loaded: file_helper
INFO - 2021-12-10 03:51:02 --> Helper loaded: form_helper
INFO - 2021-12-10 03:51:02 --> Helper loaded: my_helper
INFO - 2021-12-10 03:51:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:51:02 --> Controller Class Initialized
DEBUG - 2021-12-10 03:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:51:03 --> Final output sent to browser
DEBUG - 2021-12-10 03:51:03 --> Total execution time: 0.6680
INFO - 2021-12-10 03:51:12 --> Config Class Initialized
INFO - 2021-12-10 03:51:12 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:51:12 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:51:12 --> Utf8 Class Initialized
INFO - 2021-12-10 03:51:12 --> URI Class Initialized
INFO - 2021-12-10 03:51:12 --> Router Class Initialized
INFO - 2021-12-10 03:51:12 --> Output Class Initialized
INFO - 2021-12-10 03:51:12 --> Security Class Initialized
DEBUG - 2021-12-10 03:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:51:12 --> Input Class Initialized
INFO - 2021-12-10 03:51:12 --> Language Class Initialized
INFO - 2021-12-10 03:51:12 --> Language Class Initialized
INFO - 2021-12-10 03:51:12 --> Config Class Initialized
INFO - 2021-12-10 03:51:12 --> Loader Class Initialized
INFO - 2021-12-10 03:51:12 --> Helper loaded: url_helper
INFO - 2021-12-10 03:51:12 --> Helper loaded: file_helper
INFO - 2021-12-10 03:51:12 --> Helper loaded: form_helper
INFO - 2021-12-10 03:51:12 --> Helper loaded: my_helper
INFO - 2021-12-10 03:51:12 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:51:12 --> Controller Class Initialized
DEBUG - 2021-12-10 03:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:51:12 --> Final output sent to browser
DEBUG - 2021-12-10 03:51:12 --> Total execution time: 0.1220
INFO - 2021-12-10 03:51:15 --> Config Class Initialized
INFO - 2021-12-10 03:51:15 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:51:16 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:51:16 --> Utf8 Class Initialized
INFO - 2021-12-10 03:51:16 --> URI Class Initialized
INFO - 2021-12-10 03:51:16 --> Router Class Initialized
INFO - 2021-12-10 03:51:16 --> Output Class Initialized
INFO - 2021-12-10 03:51:16 --> Security Class Initialized
DEBUG - 2021-12-10 03:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:51:16 --> Input Class Initialized
INFO - 2021-12-10 03:51:16 --> Language Class Initialized
INFO - 2021-12-10 03:51:16 --> Language Class Initialized
INFO - 2021-12-10 03:51:16 --> Config Class Initialized
INFO - 2021-12-10 03:51:16 --> Loader Class Initialized
INFO - 2021-12-10 03:51:16 --> Helper loaded: url_helper
INFO - 2021-12-10 03:51:16 --> Helper loaded: file_helper
INFO - 2021-12-10 03:51:16 --> Helper loaded: form_helper
INFO - 2021-12-10 03:51:16 --> Helper loaded: my_helper
INFO - 2021-12-10 03:51:16 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:51:16 --> Controller Class Initialized
DEBUG - 2021-12-10 03:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:51:16 --> Final output sent to browser
DEBUG - 2021-12-10 03:51:16 --> Total execution time: 0.0450
INFO - 2021-12-10 03:51:19 --> Config Class Initialized
INFO - 2021-12-10 03:51:19 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:51:19 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:51:19 --> Utf8 Class Initialized
INFO - 2021-12-10 03:51:19 --> URI Class Initialized
INFO - 2021-12-10 03:51:19 --> Router Class Initialized
INFO - 2021-12-10 03:51:19 --> Output Class Initialized
INFO - 2021-12-10 03:51:19 --> Security Class Initialized
DEBUG - 2021-12-10 03:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:51:19 --> Input Class Initialized
INFO - 2021-12-10 03:51:19 --> Language Class Initialized
INFO - 2021-12-10 03:51:19 --> Language Class Initialized
INFO - 2021-12-10 03:51:19 --> Config Class Initialized
INFO - 2021-12-10 03:51:19 --> Loader Class Initialized
INFO - 2021-12-10 03:51:19 --> Helper loaded: url_helper
INFO - 2021-12-10 03:51:19 --> Helper loaded: file_helper
INFO - 2021-12-10 03:51:19 --> Helper loaded: form_helper
INFO - 2021-12-10 03:51:19 --> Helper loaded: my_helper
INFO - 2021-12-10 03:51:19 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:51:19 --> Controller Class Initialized
DEBUG - 2021-12-10 03:51:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 03:51:19 --> Final output sent to browser
DEBUG - 2021-12-10 03:51:19 --> Total execution time: 0.1720
INFO - 2021-12-10 03:56:12 --> Config Class Initialized
INFO - 2021-12-10 03:56:12 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:56:12 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:56:12 --> Utf8 Class Initialized
INFO - 2021-12-10 03:56:12 --> URI Class Initialized
INFO - 2021-12-10 03:56:12 --> Router Class Initialized
INFO - 2021-12-10 03:56:12 --> Output Class Initialized
INFO - 2021-12-10 03:56:12 --> Security Class Initialized
DEBUG - 2021-12-10 03:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:56:12 --> Input Class Initialized
INFO - 2021-12-10 03:56:12 --> Language Class Initialized
INFO - 2021-12-10 03:56:12 --> Language Class Initialized
INFO - 2021-12-10 03:56:12 --> Config Class Initialized
INFO - 2021-12-10 03:56:12 --> Loader Class Initialized
INFO - 2021-12-10 03:56:12 --> Helper loaded: url_helper
INFO - 2021-12-10 03:56:12 --> Helper loaded: file_helper
INFO - 2021-12-10 03:56:12 --> Helper loaded: form_helper
INFO - 2021-12-10 03:56:12 --> Helper loaded: my_helper
INFO - 2021-12-10 03:56:12 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:56:12 --> Controller Class Initialized
DEBUG - 2021-12-10 03:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 03:56:12 --> Final output sent to browser
DEBUG - 2021-12-10 03:56:12 --> Total execution time: 0.1580
INFO - 2021-12-10 03:56:20 --> Config Class Initialized
INFO - 2021-12-10 03:56:20 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:56:20 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:56:20 --> Utf8 Class Initialized
INFO - 2021-12-10 03:56:20 --> URI Class Initialized
INFO - 2021-12-10 03:56:20 --> Router Class Initialized
INFO - 2021-12-10 03:56:20 --> Output Class Initialized
INFO - 2021-12-10 03:56:20 --> Security Class Initialized
DEBUG - 2021-12-10 03:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:56:20 --> Input Class Initialized
INFO - 2021-12-10 03:56:20 --> Language Class Initialized
INFO - 2021-12-10 03:56:20 --> Language Class Initialized
INFO - 2021-12-10 03:56:20 --> Config Class Initialized
INFO - 2021-12-10 03:56:20 --> Loader Class Initialized
INFO - 2021-12-10 03:56:20 --> Helper loaded: url_helper
INFO - 2021-12-10 03:56:20 --> Helper loaded: file_helper
INFO - 2021-12-10 03:56:20 --> Helper loaded: form_helper
INFO - 2021-12-10 03:56:20 --> Helper loaded: my_helper
INFO - 2021-12-10 03:56:20 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:56:20 --> Controller Class Initialized
DEBUG - 2021-12-10 03:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 03:56:20 --> Final output sent to browser
DEBUG - 2021-12-10 03:56:20 --> Total execution time: 0.1400
INFO - 2021-12-10 03:56:39 --> Config Class Initialized
INFO - 2021-12-10 03:56:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:56:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:56:39 --> Utf8 Class Initialized
INFO - 2021-12-10 03:56:39 --> URI Class Initialized
INFO - 2021-12-10 03:56:39 --> Router Class Initialized
INFO - 2021-12-10 03:56:39 --> Output Class Initialized
INFO - 2021-12-10 03:56:39 --> Security Class Initialized
DEBUG - 2021-12-10 03:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:56:39 --> Input Class Initialized
INFO - 2021-12-10 03:56:39 --> Language Class Initialized
INFO - 2021-12-10 03:56:39 --> Language Class Initialized
INFO - 2021-12-10 03:56:39 --> Config Class Initialized
INFO - 2021-12-10 03:56:39 --> Loader Class Initialized
INFO - 2021-12-10 03:56:39 --> Helper loaded: url_helper
INFO - 2021-12-10 03:56:39 --> Helper loaded: file_helper
INFO - 2021-12-10 03:56:39 --> Helper loaded: form_helper
INFO - 2021-12-10 03:56:39 --> Helper loaded: my_helper
INFO - 2021-12-10 03:56:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:56:39 --> Controller Class Initialized
DEBUG - 2021-12-10 03:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 03:56:39 --> Final output sent to browser
DEBUG - 2021-12-10 03:56:39 --> Total execution time: 0.1180
INFO - 2021-12-10 03:57:07 --> Config Class Initialized
INFO - 2021-12-10 03:57:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:57:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:57:07 --> Utf8 Class Initialized
INFO - 2021-12-10 03:57:07 --> URI Class Initialized
INFO - 2021-12-10 03:57:07 --> Router Class Initialized
INFO - 2021-12-10 03:57:07 --> Output Class Initialized
INFO - 2021-12-10 03:57:07 --> Security Class Initialized
DEBUG - 2021-12-10 03:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:57:07 --> Input Class Initialized
INFO - 2021-12-10 03:57:07 --> Language Class Initialized
INFO - 2021-12-10 03:57:07 --> Language Class Initialized
INFO - 2021-12-10 03:57:07 --> Config Class Initialized
INFO - 2021-12-10 03:57:07 --> Loader Class Initialized
INFO - 2021-12-10 03:57:07 --> Helper loaded: url_helper
INFO - 2021-12-10 03:57:07 --> Helper loaded: file_helper
INFO - 2021-12-10 03:57:07 --> Helper loaded: form_helper
INFO - 2021-12-10 03:57:07 --> Helper loaded: my_helper
INFO - 2021-12-10 03:57:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:57:07 --> Controller Class Initialized
INFO - 2021-12-10 03:57:07 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:57:07 --> Config Class Initialized
INFO - 2021-12-10 03:57:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:57:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:57:07 --> Utf8 Class Initialized
INFO - 2021-12-10 03:57:07 --> URI Class Initialized
INFO - 2021-12-10 03:57:07 --> Router Class Initialized
INFO - 2021-12-10 03:57:07 --> Output Class Initialized
INFO - 2021-12-10 03:57:07 --> Security Class Initialized
DEBUG - 2021-12-10 03:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:57:07 --> Input Class Initialized
INFO - 2021-12-10 03:57:07 --> Language Class Initialized
INFO - 2021-12-10 03:57:07 --> Language Class Initialized
INFO - 2021-12-10 03:57:07 --> Config Class Initialized
INFO - 2021-12-10 03:57:07 --> Loader Class Initialized
INFO - 2021-12-10 03:57:07 --> Helper loaded: url_helper
INFO - 2021-12-10 03:57:07 --> Helper loaded: file_helper
INFO - 2021-12-10 03:57:07 --> Helper loaded: form_helper
INFO - 2021-12-10 03:57:07 --> Helper loaded: my_helper
INFO - 2021-12-10 03:57:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:57:07 --> Controller Class Initialized
DEBUG - 2021-12-10 03:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:57:07 --> Final output sent to browser
DEBUG - 2021-12-10 03:57:07 --> Total execution time: 0.0350
INFO - 2021-12-10 03:57:13 --> Config Class Initialized
INFO - 2021-12-10 03:57:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:57:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:57:13 --> Utf8 Class Initialized
INFO - 2021-12-10 03:57:13 --> URI Class Initialized
INFO - 2021-12-10 03:57:13 --> Router Class Initialized
INFO - 2021-12-10 03:57:13 --> Output Class Initialized
INFO - 2021-12-10 03:57:13 --> Security Class Initialized
DEBUG - 2021-12-10 03:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:57:13 --> Input Class Initialized
INFO - 2021-12-10 03:57:13 --> Language Class Initialized
INFO - 2021-12-10 03:57:13 --> Language Class Initialized
INFO - 2021-12-10 03:57:13 --> Config Class Initialized
INFO - 2021-12-10 03:57:13 --> Loader Class Initialized
INFO - 2021-12-10 03:57:13 --> Helper loaded: url_helper
INFO - 2021-12-10 03:57:13 --> Helper loaded: file_helper
INFO - 2021-12-10 03:57:13 --> Helper loaded: form_helper
INFO - 2021-12-10 03:57:13 --> Helper loaded: my_helper
INFO - 2021-12-10 03:57:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:57:13 --> Controller Class Initialized
DEBUG - 2021-12-10 03:57:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 03:57:13 --> Final output sent to browser
DEBUG - 2021-12-10 03:57:13 --> Total execution time: 0.1320
INFO - 2021-12-10 03:57:26 --> Config Class Initialized
INFO - 2021-12-10 03:57:26 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:57:26 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:57:26 --> Utf8 Class Initialized
INFO - 2021-12-10 03:57:26 --> URI Class Initialized
INFO - 2021-12-10 03:57:26 --> Router Class Initialized
INFO - 2021-12-10 03:57:26 --> Output Class Initialized
INFO - 2021-12-10 03:57:26 --> Security Class Initialized
DEBUG - 2021-12-10 03:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:57:26 --> Input Class Initialized
INFO - 2021-12-10 03:57:26 --> Language Class Initialized
INFO - 2021-12-10 03:57:26 --> Language Class Initialized
INFO - 2021-12-10 03:57:26 --> Config Class Initialized
INFO - 2021-12-10 03:57:26 --> Loader Class Initialized
INFO - 2021-12-10 03:57:26 --> Helper loaded: url_helper
INFO - 2021-12-10 03:57:26 --> Helper loaded: file_helper
INFO - 2021-12-10 03:57:26 --> Helper loaded: form_helper
INFO - 2021-12-10 03:57:26 --> Helper loaded: my_helper
INFO - 2021-12-10 03:57:26 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:57:26 --> Controller Class Initialized
INFO - 2021-12-10 03:57:26 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:57:26 --> Final output sent to browser
DEBUG - 2021-12-10 03:57:26 --> Total execution time: 0.0370
INFO - 2021-12-10 03:57:26 --> Config Class Initialized
INFO - 2021-12-10 03:57:26 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:57:26 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:57:26 --> Utf8 Class Initialized
INFO - 2021-12-10 03:57:26 --> URI Class Initialized
INFO - 2021-12-10 03:57:26 --> Router Class Initialized
INFO - 2021-12-10 03:57:26 --> Output Class Initialized
INFO - 2021-12-10 03:57:26 --> Security Class Initialized
DEBUG - 2021-12-10 03:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:57:26 --> Input Class Initialized
INFO - 2021-12-10 03:57:26 --> Language Class Initialized
INFO - 2021-12-10 03:57:26 --> Language Class Initialized
INFO - 2021-12-10 03:57:26 --> Config Class Initialized
INFO - 2021-12-10 03:57:26 --> Loader Class Initialized
INFO - 2021-12-10 03:57:26 --> Helper loaded: url_helper
INFO - 2021-12-10 03:57:26 --> Helper loaded: file_helper
INFO - 2021-12-10 03:57:26 --> Helper loaded: form_helper
INFO - 2021-12-10 03:57:26 --> Helper loaded: my_helper
INFO - 2021-12-10 03:57:26 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:57:26 --> Controller Class Initialized
DEBUG - 2021-12-10 03:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:57:27 --> Final output sent to browser
DEBUG - 2021-12-10 03:57:27 --> Total execution time: 0.7240
INFO - 2021-12-10 03:57:30 --> Config Class Initialized
INFO - 2021-12-10 03:57:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:57:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:57:30 --> Utf8 Class Initialized
INFO - 2021-12-10 03:57:30 --> URI Class Initialized
INFO - 2021-12-10 03:57:30 --> Router Class Initialized
INFO - 2021-12-10 03:57:30 --> Output Class Initialized
INFO - 2021-12-10 03:57:30 --> Security Class Initialized
DEBUG - 2021-12-10 03:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:57:30 --> Input Class Initialized
INFO - 2021-12-10 03:57:30 --> Language Class Initialized
INFO - 2021-12-10 03:57:30 --> Language Class Initialized
INFO - 2021-12-10 03:57:30 --> Config Class Initialized
INFO - 2021-12-10 03:57:30 --> Loader Class Initialized
INFO - 2021-12-10 03:57:30 --> Helper loaded: url_helper
INFO - 2021-12-10 03:57:30 --> Helper loaded: file_helper
INFO - 2021-12-10 03:57:30 --> Helper loaded: form_helper
INFO - 2021-12-10 03:57:30 --> Helper loaded: my_helper
INFO - 2021-12-10 03:57:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:57:30 --> Controller Class Initialized
DEBUG - 2021-12-10 03:57:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:57:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:57:30 --> Final output sent to browser
DEBUG - 2021-12-10 03:57:30 --> Total execution time: 0.1240
INFO - 2021-12-10 03:57:35 --> Config Class Initialized
INFO - 2021-12-10 03:57:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:57:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:57:35 --> Utf8 Class Initialized
INFO - 2021-12-10 03:57:35 --> URI Class Initialized
INFO - 2021-12-10 03:57:35 --> Router Class Initialized
INFO - 2021-12-10 03:57:35 --> Output Class Initialized
INFO - 2021-12-10 03:57:35 --> Security Class Initialized
DEBUG - 2021-12-10 03:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:57:35 --> Input Class Initialized
INFO - 2021-12-10 03:57:35 --> Language Class Initialized
INFO - 2021-12-10 03:57:35 --> Language Class Initialized
INFO - 2021-12-10 03:57:35 --> Config Class Initialized
INFO - 2021-12-10 03:57:35 --> Loader Class Initialized
INFO - 2021-12-10 03:57:35 --> Helper loaded: url_helper
INFO - 2021-12-10 03:57:35 --> Helper loaded: file_helper
INFO - 2021-12-10 03:57:35 --> Helper loaded: form_helper
INFO - 2021-12-10 03:57:35 --> Helper loaded: my_helper
INFO - 2021-12-10 03:57:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:57:35 --> Controller Class Initialized
DEBUG - 2021-12-10 03:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:57:35 --> Final output sent to browser
DEBUG - 2021-12-10 03:57:35 --> Total execution time: 0.0730
INFO - 2021-12-10 03:57:38 --> Config Class Initialized
INFO - 2021-12-10 03:57:38 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:57:38 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:57:38 --> Utf8 Class Initialized
INFO - 2021-12-10 03:57:38 --> URI Class Initialized
INFO - 2021-12-10 03:57:38 --> Router Class Initialized
INFO - 2021-12-10 03:57:38 --> Output Class Initialized
INFO - 2021-12-10 03:57:38 --> Security Class Initialized
DEBUG - 2021-12-10 03:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:57:38 --> Input Class Initialized
INFO - 2021-12-10 03:57:38 --> Language Class Initialized
INFO - 2021-12-10 03:57:38 --> Language Class Initialized
INFO - 2021-12-10 03:57:38 --> Config Class Initialized
INFO - 2021-12-10 03:57:38 --> Loader Class Initialized
INFO - 2021-12-10 03:57:38 --> Helper loaded: url_helper
INFO - 2021-12-10 03:57:38 --> Helper loaded: file_helper
INFO - 2021-12-10 03:57:38 --> Helper loaded: form_helper
INFO - 2021-12-10 03:57:38 --> Helper loaded: my_helper
INFO - 2021-12-10 03:57:38 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:57:38 --> Controller Class Initialized
DEBUG - 2021-12-10 03:57:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-12-10 03:57:39 --> Final output sent to browser
DEBUG - 2021-12-10 03:57:39 --> Total execution time: 0.1810
INFO - 2021-12-10 03:58:46 --> Config Class Initialized
INFO - 2021-12-10 03:58:46 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:58:46 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:58:46 --> Utf8 Class Initialized
INFO - 2021-12-10 03:58:46 --> URI Class Initialized
INFO - 2021-12-10 03:58:46 --> Router Class Initialized
INFO - 2021-12-10 03:58:46 --> Output Class Initialized
INFO - 2021-12-10 03:58:46 --> Security Class Initialized
DEBUG - 2021-12-10 03:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:58:46 --> Input Class Initialized
INFO - 2021-12-10 03:58:46 --> Language Class Initialized
INFO - 2021-12-10 03:58:46 --> Language Class Initialized
INFO - 2021-12-10 03:58:46 --> Config Class Initialized
INFO - 2021-12-10 03:58:46 --> Loader Class Initialized
INFO - 2021-12-10 03:58:46 --> Helper loaded: url_helper
INFO - 2021-12-10 03:58:46 --> Helper loaded: file_helper
INFO - 2021-12-10 03:58:46 --> Helper loaded: form_helper
INFO - 2021-12-10 03:58:46 --> Helper loaded: my_helper
INFO - 2021-12-10 03:58:46 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:58:46 --> Controller Class Initialized
DEBUG - 2021-12-10 03:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-12-10 03:58:46 --> Final output sent to browser
DEBUG - 2021-12-10 03:58:46 --> Total execution time: 0.1780
INFO - 2021-12-10 03:59:16 --> Config Class Initialized
INFO - 2021-12-10 03:59:16 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:59:16 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:59:16 --> Utf8 Class Initialized
INFO - 2021-12-10 03:59:16 --> URI Class Initialized
INFO - 2021-12-10 03:59:16 --> Router Class Initialized
INFO - 2021-12-10 03:59:16 --> Output Class Initialized
INFO - 2021-12-10 03:59:16 --> Security Class Initialized
DEBUG - 2021-12-10 03:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:59:16 --> Input Class Initialized
INFO - 2021-12-10 03:59:16 --> Language Class Initialized
INFO - 2021-12-10 03:59:16 --> Language Class Initialized
INFO - 2021-12-10 03:59:16 --> Config Class Initialized
INFO - 2021-12-10 03:59:16 --> Loader Class Initialized
INFO - 2021-12-10 03:59:16 --> Helper loaded: url_helper
INFO - 2021-12-10 03:59:16 --> Helper loaded: file_helper
INFO - 2021-12-10 03:59:16 --> Helper loaded: form_helper
INFO - 2021-12-10 03:59:16 --> Helper loaded: my_helper
INFO - 2021-12-10 03:59:16 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:59:16 --> Controller Class Initialized
INFO - 2021-12-10 03:59:16 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:59:16 --> Config Class Initialized
INFO - 2021-12-10 03:59:16 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:59:16 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:59:16 --> Utf8 Class Initialized
INFO - 2021-12-10 03:59:16 --> URI Class Initialized
INFO - 2021-12-10 03:59:16 --> Router Class Initialized
INFO - 2021-12-10 03:59:16 --> Output Class Initialized
INFO - 2021-12-10 03:59:16 --> Security Class Initialized
DEBUG - 2021-12-10 03:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:59:16 --> Input Class Initialized
INFO - 2021-12-10 03:59:16 --> Language Class Initialized
INFO - 2021-12-10 03:59:16 --> Language Class Initialized
INFO - 2021-12-10 03:59:16 --> Config Class Initialized
INFO - 2021-12-10 03:59:16 --> Loader Class Initialized
INFO - 2021-12-10 03:59:16 --> Helper loaded: url_helper
INFO - 2021-12-10 03:59:16 --> Helper loaded: file_helper
INFO - 2021-12-10 03:59:16 --> Helper loaded: form_helper
INFO - 2021-12-10 03:59:16 --> Helper loaded: my_helper
INFO - 2021-12-10 03:59:16 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:59:16 --> Controller Class Initialized
DEBUG - 2021-12-10 03:59:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 03:59:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:59:16 --> Final output sent to browser
DEBUG - 2021-12-10 03:59:16 --> Total execution time: 0.0350
INFO - 2021-12-10 03:59:22 --> Config Class Initialized
INFO - 2021-12-10 03:59:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:59:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:59:22 --> Utf8 Class Initialized
INFO - 2021-12-10 03:59:22 --> URI Class Initialized
INFO - 2021-12-10 03:59:22 --> Router Class Initialized
INFO - 2021-12-10 03:59:22 --> Output Class Initialized
INFO - 2021-12-10 03:59:22 --> Security Class Initialized
DEBUG - 2021-12-10 03:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:59:22 --> Input Class Initialized
INFO - 2021-12-10 03:59:22 --> Language Class Initialized
INFO - 2021-12-10 03:59:22 --> Language Class Initialized
INFO - 2021-12-10 03:59:22 --> Config Class Initialized
INFO - 2021-12-10 03:59:22 --> Loader Class Initialized
INFO - 2021-12-10 03:59:22 --> Helper loaded: url_helper
INFO - 2021-12-10 03:59:22 --> Helper loaded: file_helper
INFO - 2021-12-10 03:59:22 --> Helper loaded: form_helper
INFO - 2021-12-10 03:59:22 --> Helper loaded: my_helper
INFO - 2021-12-10 03:59:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:59:22 --> Controller Class Initialized
INFO - 2021-12-10 03:59:22 --> Helper loaded: cookie_helper
INFO - 2021-12-10 03:59:22 --> Final output sent to browser
DEBUG - 2021-12-10 03:59:22 --> Total execution time: 0.0580
INFO - 2021-12-10 03:59:22 --> Config Class Initialized
INFO - 2021-12-10 03:59:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:59:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:59:22 --> Utf8 Class Initialized
INFO - 2021-12-10 03:59:22 --> URI Class Initialized
INFO - 2021-12-10 03:59:22 --> Router Class Initialized
INFO - 2021-12-10 03:59:22 --> Output Class Initialized
INFO - 2021-12-10 03:59:22 --> Security Class Initialized
DEBUG - 2021-12-10 03:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:59:22 --> Input Class Initialized
INFO - 2021-12-10 03:59:22 --> Language Class Initialized
INFO - 2021-12-10 03:59:22 --> Language Class Initialized
INFO - 2021-12-10 03:59:22 --> Config Class Initialized
INFO - 2021-12-10 03:59:22 --> Loader Class Initialized
INFO - 2021-12-10 03:59:22 --> Helper loaded: url_helper
INFO - 2021-12-10 03:59:22 --> Helper loaded: file_helper
INFO - 2021-12-10 03:59:22 --> Helper loaded: form_helper
INFO - 2021-12-10 03:59:22 --> Helper loaded: my_helper
INFO - 2021-12-10 03:59:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:59:22 --> Controller Class Initialized
DEBUG - 2021-12-10 03:59:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 03:59:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:59:22 --> Final output sent to browser
DEBUG - 2021-12-10 03:59:22 --> Total execution time: 0.7630
INFO - 2021-12-10 03:59:30 --> Config Class Initialized
INFO - 2021-12-10 03:59:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:59:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:59:30 --> Utf8 Class Initialized
INFO - 2021-12-10 03:59:30 --> URI Class Initialized
INFO - 2021-12-10 03:59:30 --> Router Class Initialized
INFO - 2021-12-10 03:59:30 --> Output Class Initialized
INFO - 2021-12-10 03:59:30 --> Security Class Initialized
DEBUG - 2021-12-10 03:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:59:30 --> Input Class Initialized
INFO - 2021-12-10 03:59:30 --> Language Class Initialized
INFO - 2021-12-10 03:59:30 --> Language Class Initialized
INFO - 2021-12-10 03:59:30 --> Config Class Initialized
INFO - 2021-12-10 03:59:30 --> Loader Class Initialized
INFO - 2021-12-10 03:59:30 --> Helper loaded: url_helper
INFO - 2021-12-10 03:59:30 --> Helper loaded: file_helper
INFO - 2021-12-10 03:59:30 --> Helper loaded: form_helper
INFO - 2021-12-10 03:59:30 --> Helper loaded: my_helper
INFO - 2021-12-10 03:59:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:59:30 --> Controller Class Initialized
DEBUG - 2021-12-10 03:59:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 03:59:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:59:30 --> Final output sent to browser
DEBUG - 2021-12-10 03:59:30 --> Total execution time: 0.1040
INFO - 2021-12-10 03:59:36 --> Config Class Initialized
INFO - 2021-12-10 03:59:36 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:59:36 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:59:36 --> Utf8 Class Initialized
INFO - 2021-12-10 03:59:36 --> URI Class Initialized
INFO - 2021-12-10 03:59:36 --> Router Class Initialized
INFO - 2021-12-10 03:59:36 --> Output Class Initialized
INFO - 2021-12-10 03:59:36 --> Security Class Initialized
DEBUG - 2021-12-10 03:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:59:36 --> Input Class Initialized
INFO - 2021-12-10 03:59:36 --> Language Class Initialized
INFO - 2021-12-10 03:59:36 --> Language Class Initialized
INFO - 2021-12-10 03:59:36 --> Config Class Initialized
INFO - 2021-12-10 03:59:36 --> Loader Class Initialized
INFO - 2021-12-10 03:59:36 --> Helper loaded: url_helper
INFO - 2021-12-10 03:59:36 --> Helper loaded: file_helper
INFO - 2021-12-10 03:59:36 --> Helper loaded: form_helper
INFO - 2021-12-10 03:59:36 --> Helper loaded: my_helper
INFO - 2021-12-10 03:59:36 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:59:36 --> Controller Class Initialized
DEBUG - 2021-12-10 03:59:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 03:59:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 03:59:36 --> Final output sent to browser
DEBUG - 2021-12-10 03:59:36 --> Total execution time: 0.0550
INFO - 2021-12-10 03:59:41 --> Config Class Initialized
INFO - 2021-12-10 03:59:41 --> Hooks Class Initialized
DEBUG - 2021-12-10 03:59:41 --> UTF-8 Support Enabled
INFO - 2021-12-10 03:59:41 --> Utf8 Class Initialized
INFO - 2021-12-10 03:59:41 --> URI Class Initialized
INFO - 2021-12-10 03:59:41 --> Router Class Initialized
INFO - 2021-12-10 03:59:41 --> Output Class Initialized
INFO - 2021-12-10 03:59:41 --> Security Class Initialized
DEBUG - 2021-12-10 03:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 03:59:41 --> Input Class Initialized
INFO - 2021-12-10 03:59:41 --> Language Class Initialized
INFO - 2021-12-10 03:59:41 --> Language Class Initialized
INFO - 2021-12-10 03:59:41 --> Config Class Initialized
INFO - 2021-12-10 03:59:41 --> Loader Class Initialized
INFO - 2021-12-10 03:59:41 --> Helper loaded: url_helper
INFO - 2021-12-10 03:59:41 --> Helper loaded: file_helper
INFO - 2021-12-10 03:59:41 --> Helper loaded: form_helper
INFO - 2021-12-10 03:59:41 --> Helper loaded: my_helper
INFO - 2021-12-10 03:59:41 --> Database Driver Class Initialized
DEBUG - 2021-12-10 03:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 03:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 03:59:41 --> Controller Class Initialized
DEBUG - 2021-12-10 03:59:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-12-10 03:59:41 --> Final output sent to browser
DEBUG - 2021-12-10 03:59:41 --> Total execution time: 0.1730
INFO - 2021-12-10 04:02:35 --> Config Class Initialized
INFO - 2021-12-10 04:02:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:02:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:02:35 --> Utf8 Class Initialized
INFO - 2021-12-10 04:02:35 --> URI Class Initialized
INFO - 2021-12-10 04:02:35 --> Router Class Initialized
INFO - 2021-12-10 04:02:35 --> Output Class Initialized
INFO - 2021-12-10 04:02:35 --> Security Class Initialized
DEBUG - 2021-12-10 04:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:02:35 --> Input Class Initialized
INFO - 2021-12-10 04:02:35 --> Language Class Initialized
INFO - 2021-12-10 04:02:35 --> Language Class Initialized
INFO - 2021-12-10 04:02:35 --> Config Class Initialized
INFO - 2021-12-10 04:02:35 --> Loader Class Initialized
INFO - 2021-12-10 04:02:35 --> Helper loaded: url_helper
INFO - 2021-12-10 04:02:35 --> Helper loaded: file_helper
INFO - 2021-12-10 04:02:35 --> Helper loaded: form_helper
INFO - 2021-12-10 04:02:35 --> Helper loaded: my_helper
INFO - 2021-12-10 04:02:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:02:35 --> Controller Class Initialized
DEBUG - 2021-12-10 04:02:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-12-10 04:02:35 --> Final output sent to browser
DEBUG - 2021-12-10 04:02:35 --> Total execution time: 0.1710
INFO - 2021-12-10 04:02:51 --> Config Class Initialized
INFO - 2021-12-10 04:02:51 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:02:51 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:02:51 --> Utf8 Class Initialized
INFO - 2021-12-10 04:02:51 --> URI Class Initialized
INFO - 2021-12-10 04:02:51 --> Router Class Initialized
INFO - 2021-12-10 04:02:51 --> Output Class Initialized
INFO - 2021-12-10 04:02:51 --> Security Class Initialized
DEBUG - 2021-12-10 04:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:02:51 --> Input Class Initialized
INFO - 2021-12-10 04:02:51 --> Language Class Initialized
INFO - 2021-12-10 04:02:51 --> Language Class Initialized
INFO - 2021-12-10 04:02:51 --> Config Class Initialized
INFO - 2021-12-10 04:02:51 --> Loader Class Initialized
INFO - 2021-12-10 04:02:51 --> Helper loaded: url_helper
INFO - 2021-12-10 04:02:51 --> Helper loaded: file_helper
INFO - 2021-12-10 04:02:51 --> Helper loaded: form_helper
INFO - 2021-12-10 04:02:51 --> Helper loaded: my_helper
INFO - 2021-12-10 04:02:51 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:02:51 --> Controller Class Initialized
DEBUG - 2021-12-10 04:02:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-12-10 04:02:51 --> Final output sent to browser
DEBUG - 2021-12-10 04:02:51 --> Total execution time: 0.1510
INFO - 2021-12-10 04:03:00 --> Config Class Initialized
INFO - 2021-12-10 04:03:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:03:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:03:00 --> Utf8 Class Initialized
INFO - 2021-12-10 04:03:00 --> URI Class Initialized
INFO - 2021-12-10 04:03:00 --> Router Class Initialized
INFO - 2021-12-10 04:03:00 --> Output Class Initialized
INFO - 2021-12-10 04:03:00 --> Security Class Initialized
DEBUG - 2021-12-10 04:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:03:00 --> Input Class Initialized
INFO - 2021-12-10 04:03:00 --> Language Class Initialized
INFO - 2021-12-10 04:03:00 --> Language Class Initialized
INFO - 2021-12-10 04:03:00 --> Config Class Initialized
INFO - 2021-12-10 04:03:00 --> Loader Class Initialized
INFO - 2021-12-10 04:03:00 --> Helper loaded: url_helper
INFO - 2021-12-10 04:03:00 --> Helper loaded: file_helper
INFO - 2021-12-10 04:03:00 --> Helper loaded: form_helper
INFO - 2021-12-10 04:03:00 --> Helper loaded: my_helper
INFO - 2021-12-10 04:03:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:03:00 --> Controller Class Initialized
DEBUG - 2021-12-10 04:03:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-12-10 04:03:00 --> Final output sent to browser
DEBUG - 2021-12-10 04:03:00 --> Total execution time: 0.1120
INFO - 2021-12-10 04:03:34 --> Config Class Initialized
INFO - 2021-12-10 04:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:03:34 --> Utf8 Class Initialized
INFO - 2021-12-10 04:03:34 --> URI Class Initialized
INFO - 2021-12-10 04:03:34 --> Router Class Initialized
INFO - 2021-12-10 04:03:34 --> Output Class Initialized
INFO - 2021-12-10 04:03:34 --> Security Class Initialized
DEBUG - 2021-12-10 04:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:03:34 --> Input Class Initialized
INFO - 2021-12-10 04:03:34 --> Language Class Initialized
INFO - 2021-12-10 04:03:34 --> Language Class Initialized
INFO - 2021-12-10 04:03:34 --> Config Class Initialized
INFO - 2021-12-10 04:03:34 --> Loader Class Initialized
INFO - 2021-12-10 04:03:34 --> Helper loaded: url_helper
INFO - 2021-12-10 04:03:34 --> Helper loaded: file_helper
INFO - 2021-12-10 04:03:34 --> Helper loaded: form_helper
INFO - 2021-12-10 04:03:34 --> Helper loaded: my_helper
INFO - 2021-12-10 04:03:34 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:03:34 --> Controller Class Initialized
INFO - 2021-12-10 04:03:34 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:03:34 --> Config Class Initialized
INFO - 2021-12-10 04:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:03:34 --> Utf8 Class Initialized
INFO - 2021-12-10 04:03:34 --> URI Class Initialized
INFO - 2021-12-10 04:03:34 --> Router Class Initialized
INFO - 2021-12-10 04:03:34 --> Output Class Initialized
INFO - 2021-12-10 04:03:34 --> Security Class Initialized
DEBUG - 2021-12-10 04:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:03:34 --> Input Class Initialized
INFO - 2021-12-10 04:03:34 --> Language Class Initialized
INFO - 2021-12-10 04:03:34 --> Language Class Initialized
INFO - 2021-12-10 04:03:34 --> Config Class Initialized
INFO - 2021-12-10 04:03:34 --> Loader Class Initialized
INFO - 2021-12-10 04:03:34 --> Helper loaded: url_helper
INFO - 2021-12-10 04:03:34 --> Helper loaded: file_helper
INFO - 2021-12-10 04:03:34 --> Helper loaded: form_helper
INFO - 2021-12-10 04:03:34 --> Helper loaded: my_helper
INFO - 2021-12-10 04:03:34 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:03:34 --> Controller Class Initialized
DEBUG - 2021-12-10 04:03:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:03:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:03:34 --> Final output sent to browser
DEBUG - 2021-12-10 04:03:34 --> Total execution time: 0.0600
INFO - 2021-12-10 04:03:38 --> Config Class Initialized
INFO - 2021-12-10 04:03:38 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:03:38 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:03:38 --> Utf8 Class Initialized
INFO - 2021-12-10 04:03:38 --> URI Class Initialized
INFO - 2021-12-10 04:03:38 --> Router Class Initialized
INFO - 2021-12-10 04:03:38 --> Output Class Initialized
INFO - 2021-12-10 04:03:38 --> Security Class Initialized
DEBUG - 2021-12-10 04:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:03:38 --> Input Class Initialized
INFO - 2021-12-10 04:03:38 --> Language Class Initialized
INFO - 2021-12-10 04:03:38 --> Language Class Initialized
INFO - 2021-12-10 04:03:38 --> Config Class Initialized
INFO - 2021-12-10 04:03:38 --> Loader Class Initialized
INFO - 2021-12-10 04:03:38 --> Helper loaded: url_helper
INFO - 2021-12-10 04:03:38 --> Helper loaded: file_helper
INFO - 2021-12-10 04:03:38 --> Helper loaded: form_helper
INFO - 2021-12-10 04:03:38 --> Helper loaded: my_helper
INFO - 2021-12-10 04:03:38 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:03:38 --> Controller Class Initialized
INFO - 2021-12-10 04:03:38 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:03:38 --> Final output sent to browser
DEBUG - 2021-12-10 04:03:38 --> Total execution time: 0.0460
INFO - 2021-12-10 04:03:38 --> Config Class Initialized
INFO - 2021-12-10 04:03:38 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:03:38 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:03:38 --> Utf8 Class Initialized
INFO - 2021-12-10 04:03:38 --> URI Class Initialized
INFO - 2021-12-10 04:03:38 --> Router Class Initialized
INFO - 2021-12-10 04:03:38 --> Output Class Initialized
INFO - 2021-12-10 04:03:38 --> Security Class Initialized
DEBUG - 2021-12-10 04:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:03:38 --> Input Class Initialized
INFO - 2021-12-10 04:03:38 --> Language Class Initialized
INFO - 2021-12-10 04:03:38 --> Language Class Initialized
INFO - 2021-12-10 04:03:38 --> Config Class Initialized
INFO - 2021-12-10 04:03:38 --> Loader Class Initialized
INFO - 2021-12-10 04:03:38 --> Helper loaded: url_helper
INFO - 2021-12-10 04:03:38 --> Helper loaded: file_helper
INFO - 2021-12-10 04:03:38 --> Helper loaded: form_helper
INFO - 2021-12-10 04:03:38 --> Helper loaded: my_helper
INFO - 2021-12-10 04:03:38 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:03:38 --> Controller Class Initialized
DEBUG - 2021-12-10 04:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:03:39 --> Final output sent to browser
DEBUG - 2021-12-10 04:03:39 --> Total execution time: 0.7640
INFO - 2021-12-10 04:03:42 --> Config Class Initialized
INFO - 2021-12-10 04:03:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:03:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:03:42 --> Utf8 Class Initialized
INFO - 2021-12-10 04:03:42 --> URI Class Initialized
INFO - 2021-12-10 04:03:42 --> Router Class Initialized
INFO - 2021-12-10 04:03:42 --> Output Class Initialized
INFO - 2021-12-10 04:03:42 --> Security Class Initialized
DEBUG - 2021-12-10 04:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:03:42 --> Input Class Initialized
INFO - 2021-12-10 04:03:42 --> Language Class Initialized
INFO - 2021-12-10 04:03:42 --> Language Class Initialized
INFO - 2021-12-10 04:03:42 --> Config Class Initialized
INFO - 2021-12-10 04:03:42 --> Loader Class Initialized
INFO - 2021-12-10 04:03:42 --> Helper loaded: url_helper
INFO - 2021-12-10 04:03:42 --> Helper loaded: file_helper
INFO - 2021-12-10 04:03:42 --> Helper loaded: form_helper
INFO - 2021-12-10 04:03:42 --> Helper loaded: my_helper
INFO - 2021-12-10 04:03:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:03:42 --> Controller Class Initialized
DEBUG - 2021-12-10 04:03:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 04:03:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:03:43 --> Final output sent to browser
DEBUG - 2021-12-10 04:03:43 --> Total execution time: 0.1300
INFO - 2021-12-10 04:03:56 --> Config Class Initialized
INFO - 2021-12-10 04:03:56 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:03:56 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:03:56 --> Utf8 Class Initialized
INFO - 2021-12-10 04:03:56 --> URI Class Initialized
INFO - 2021-12-10 04:03:56 --> Router Class Initialized
INFO - 2021-12-10 04:03:56 --> Output Class Initialized
INFO - 2021-12-10 04:03:56 --> Security Class Initialized
DEBUG - 2021-12-10 04:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:03:56 --> Input Class Initialized
INFO - 2021-12-10 04:03:56 --> Language Class Initialized
INFO - 2021-12-10 04:03:56 --> Language Class Initialized
INFO - 2021-12-10 04:03:56 --> Config Class Initialized
INFO - 2021-12-10 04:03:56 --> Loader Class Initialized
INFO - 2021-12-10 04:03:56 --> Helper loaded: url_helper
INFO - 2021-12-10 04:03:56 --> Helper loaded: file_helper
INFO - 2021-12-10 04:03:56 --> Helper loaded: form_helper
INFO - 2021-12-10 04:03:56 --> Helper loaded: my_helper
INFO - 2021-12-10 04:03:56 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:03:56 --> Controller Class Initialized
DEBUG - 2021-12-10 04:03:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 04:03:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:03:56 --> Final output sent to browser
DEBUG - 2021-12-10 04:03:56 --> Total execution time: 0.0450
INFO - 2021-12-10 04:04:03 --> Config Class Initialized
INFO - 2021-12-10 04:04:03 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:04:03 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:04:03 --> Utf8 Class Initialized
INFO - 2021-12-10 04:04:03 --> URI Class Initialized
INFO - 2021-12-10 04:04:03 --> Router Class Initialized
INFO - 2021-12-10 04:04:03 --> Output Class Initialized
INFO - 2021-12-10 04:04:03 --> Security Class Initialized
DEBUG - 2021-12-10 04:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:04:03 --> Input Class Initialized
INFO - 2021-12-10 04:04:03 --> Language Class Initialized
INFO - 2021-12-10 04:04:03 --> Language Class Initialized
INFO - 2021-12-10 04:04:03 --> Config Class Initialized
INFO - 2021-12-10 04:04:03 --> Loader Class Initialized
INFO - 2021-12-10 04:04:03 --> Helper loaded: url_helper
INFO - 2021-12-10 04:04:03 --> Helper loaded: file_helper
INFO - 2021-12-10 04:04:03 --> Helper loaded: form_helper
INFO - 2021-12-10 04:04:03 --> Helper loaded: my_helper
INFO - 2021-12-10 04:04:03 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:04:03 --> Controller Class Initialized
DEBUG - 2021-12-10 04:04:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-12-10 04:04:04 --> Final output sent to browser
DEBUG - 2021-12-10 04:04:04 --> Total execution time: 0.1650
INFO - 2021-12-10 04:04:33 --> Config Class Initialized
INFO - 2021-12-10 04:04:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:04:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:04:33 --> Utf8 Class Initialized
INFO - 2021-12-10 04:04:33 --> URI Class Initialized
INFO - 2021-12-10 04:04:33 --> Router Class Initialized
INFO - 2021-12-10 04:04:33 --> Output Class Initialized
INFO - 2021-12-10 04:04:33 --> Security Class Initialized
DEBUG - 2021-12-10 04:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:04:33 --> Input Class Initialized
INFO - 2021-12-10 04:04:33 --> Language Class Initialized
INFO - 2021-12-10 04:04:33 --> Language Class Initialized
INFO - 2021-12-10 04:04:33 --> Config Class Initialized
INFO - 2021-12-10 04:04:33 --> Loader Class Initialized
INFO - 2021-12-10 04:04:33 --> Helper loaded: url_helper
INFO - 2021-12-10 04:04:33 --> Helper loaded: file_helper
INFO - 2021-12-10 04:04:33 --> Helper loaded: form_helper
INFO - 2021-12-10 04:04:33 --> Helper loaded: my_helper
INFO - 2021-12-10 04:04:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:04:33 --> Controller Class Initialized
DEBUG - 2021-12-10 04:04:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-12-10 04:04:34 --> Final output sent to browser
DEBUG - 2021-12-10 04:04:34 --> Total execution time: 0.1380
INFO - 2021-12-10 04:04:42 --> Config Class Initialized
INFO - 2021-12-10 04:04:42 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:04:42 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:04:42 --> Utf8 Class Initialized
INFO - 2021-12-10 04:04:42 --> URI Class Initialized
INFO - 2021-12-10 04:04:42 --> Router Class Initialized
INFO - 2021-12-10 04:04:42 --> Output Class Initialized
INFO - 2021-12-10 04:04:42 --> Security Class Initialized
DEBUG - 2021-12-10 04:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:04:42 --> Input Class Initialized
INFO - 2021-12-10 04:04:42 --> Language Class Initialized
INFO - 2021-12-10 04:04:42 --> Language Class Initialized
INFO - 2021-12-10 04:04:42 --> Config Class Initialized
INFO - 2021-12-10 04:04:42 --> Loader Class Initialized
INFO - 2021-12-10 04:04:42 --> Helper loaded: url_helper
INFO - 2021-12-10 04:04:42 --> Helper loaded: file_helper
INFO - 2021-12-10 04:04:42 --> Helper loaded: form_helper
INFO - 2021-12-10 04:04:42 --> Helper loaded: my_helper
INFO - 2021-12-10 04:04:42 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:04:42 --> Controller Class Initialized
DEBUG - 2021-12-10 04:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-12-10 04:04:42 --> Final output sent to browser
DEBUG - 2021-12-10 04:04:42 --> Total execution time: 0.1340
INFO - 2021-12-10 04:05:14 --> Config Class Initialized
INFO - 2021-12-10 04:05:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:05:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:05:14 --> Utf8 Class Initialized
INFO - 2021-12-10 04:05:14 --> URI Class Initialized
INFO - 2021-12-10 04:05:14 --> Router Class Initialized
INFO - 2021-12-10 04:05:14 --> Output Class Initialized
INFO - 2021-12-10 04:05:14 --> Security Class Initialized
DEBUG - 2021-12-10 04:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:05:14 --> Input Class Initialized
INFO - 2021-12-10 04:05:14 --> Language Class Initialized
INFO - 2021-12-10 04:05:14 --> Language Class Initialized
INFO - 2021-12-10 04:05:14 --> Config Class Initialized
INFO - 2021-12-10 04:05:14 --> Loader Class Initialized
INFO - 2021-12-10 04:05:14 --> Helper loaded: url_helper
INFO - 2021-12-10 04:05:14 --> Helper loaded: file_helper
INFO - 2021-12-10 04:05:14 --> Helper loaded: form_helper
INFO - 2021-12-10 04:05:14 --> Helper loaded: my_helper
INFO - 2021-12-10 04:05:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:05:14 --> Controller Class Initialized
INFO - 2021-12-10 04:05:14 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:05:14 --> Config Class Initialized
INFO - 2021-12-10 04:05:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:05:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:05:14 --> Utf8 Class Initialized
INFO - 2021-12-10 04:05:14 --> URI Class Initialized
INFO - 2021-12-10 04:05:14 --> Router Class Initialized
INFO - 2021-12-10 04:05:14 --> Output Class Initialized
INFO - 2021-12-10 04:05:14 --> Security Class Initialized
DEBUG - 2021-12-10 04:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:05:14 --> Input Class Initialized
INFO - 2021-12-10 04:05:14 --> Language Class Initialized
INFO - 2021-12-10 04:05:14 --> Language Class Initialized
INFO - 2021-12-10 04:05:14 --> Config Class Initialized
INFO - 2021-12-10 04:05:14 --> Loader Class Initialized
INFO - 2021-12-10 04:05:14 --> Helper loaded: url_helper
INFO - 2021-12-10 04:05:14 --> Helper loaded: file_helper
INFO - 2021-12-10 04:05:14 --> Helper loaded: form_helper
INFO - 2021-12-10 04:05:14 --> Helper loaded: my_helper
INFO - 2021-12-10 04:05:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:05:14 --> Controller Class Initialized
DEBUG - 2021-12-10 04:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:05:14 --> Final output sent to browser
DEBUG - 2021-12-10 04:05:14 --> Total execution time: 0.0360
INFO - 2021-12-10 04:05:18 --> Config Class Initialized
INFO - 2021-12-10 04:05:18 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:05:18 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:05:18 --> Utf8 Class Initialized
INFO - 2021-12-10 04:05:18 --> URI Class Initialized
INFO - 2021-12-10 04:05:18 --> Router Class Initialized
INFO - 2021-12-10 04:05:18 --> Output Class Initialized
INFO - 2021-12-10 04:05:18 --> Security Class Initialized
DEBUG - 2021-12-10 04:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:05:18 --> Input Class Initialized
INFO - 2021-12-10 04:05:18 --> Language Class Initialized
INFO - 2021-12-10 04:05:18 --> Language Class Initialized
INFO - 2021-12-10 04:05:18 --> Config Class Initialized
INFO - 2021-12-10 04:05:18 --> Loader Class Initialized
INFO - 2021-12-10 04:05:18 --> Helper loaded: url_helper
INFO - 2021-12-10 04:05:18 --> Helper loaded: file_helper
INFO - 2021-12-10 04:05:18 --> Helper loaded: form_helper
INFO - 2021-12-10 04:05:18 --> Helper loaded: my_helper
INFO - 2021-12-10 04:05:18 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:05:18 --> Controller Class Initialized
INFO - 2021-12-10 04:05:18 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:05:18 --> Final output sent to browser
DEBUG - 2021-12-10 04:05:18 --> Total execution time: 0.0320
INFO - 2021-12-10 04:05:18 --> Config Class Initialized
INFO - 2021-12-10 04:05:18 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:05:18 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:05:18 --> Utf8 Class Initialized
INFO - 2021-12-10 04:05:18 --> URI Class Initialized
INFO - 2021-12-10 04:05:18 --> Router Class Initialized
INFO - 2021-12-10 04:05:18 --> Output Class Initialized
INFO - 2021-12-10 04:05:18 --> Security Class Initialized
DEBUG - 2021-12-10 04:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:05:18 --> Input Class Initialized
INFO - 2021-12-10 04:05:18 --> Language Class Initialized
INFO - 2021-12-10 04:05:18 --> Language Class Initialized
INFO - 2021-12-10 04:05:18 --> Config Class Initialized
INFO - 2021-12-10 04:05:18 --> Loader Class Initialized
INFO - 2021-12-10 04:05:18 --> Helper loaded: url_helper
INFO - 2021-12-10 04:05:18 --> Helper loaded: file_helper
INFO - 2021-12-10 04:05:18 --> Helper loaded: form_helper
INFO - 2021-12-10 04:05:18 --> Helper loaded: my_helper
INFO - 2021-12-10 04:05:18 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:05:19 --> Controller Class Initialized
DEBUG - 2021-12-10 04:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:05:19 --> Final output sent to browser
DEBUG - 2021-12-10 04:05:19 --> Total execution time: 0.7290
INFO - 2021-12-10 04:05:23 --> Config Class Initialized
INFO - 2021-12-10 04:05:23 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:05:23 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:05:23 --> Utf8 Class Initialized
INFO - 2021-12-10 04:05:23 --> URI Class Initialized
INFO - 2021-12-10 04:05:23 --> Router Class Initialized
INFO - 2021-12-10 04:05:23 --> Output Class Initialized
INFO - 2021-12-10 04:05:23 --> Security Class Initialized
DEBUG - 2021-12-10 04:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:05:23 --> Input Class Initialized
INFO - 2021-12-10 04:05:23 --> Language Class Initialized
INFO - 2021-12-10 04:05:23 --> Language Class Initialized
INFO - 2021-12-10 04:05:23 --> Config Class Initialized
INFO - 2021-12-10 04:05:23 --> Loader Class Initialized
INFO - 2021-12-10 04:05:23 --> Helper loaded: url_helper
INFO - 2021-12-10 04:05:23 --> Helper loaded: file_helper
INFO - 2021-12-10 04:05:23 --> Helper loaded: form_helper
INFO - 2021-12-10 04:05:23 --> Helper loaded: my_helper
INFO - 2021-12-10 04:05:23 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:05:23 --> Controller Class Initialized
DEBUG - 2021-12-10 04:05:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 04:05:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:05:23 --> Final output sent to browser
DEBUG - 2021-12-10 04:05:23 --> Total execution time: 0.0760
INFO - 2021-12-10 04:05:27 --> Config Class Initialized
INFO - 2021-12-10 04:05:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:05:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:05:27 --> Utf8 Class Initialized
INFO - 2021-12-10 04:05:27 --> URI Class Initialized
INFO - 2021-12-10 04:05:27 --> Router Class Initialized
INFO - 2021-12-10 04:05:27 --> Output Class Initialized
INFO - 2021-12-10 04:05:27 --> Security Class Initialized
DEBUG - 2021-12-10 04:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:05:27 --> Input Class Initialized
INFO - 2021-12-10 04:05:27 --> Language Class Initialized
INFO - 2021-12-10 04:05:27 --> Language Class Initialized
INFO - 2021-12-10 04:05:27 --> Config Class Initialized
INFO - 2021-12-10 04:05:27 --> Loader Class Initialized
INFO - 2021-12-10 04:05:27 --> Helper loaded: url_helper
INFO - 2021-12-10 04:05:27 --> Helper loaded: file_helper
INFO - 2021-12-10 04:05:27 --> Helper loaded: form_helper
INFO - 2021-12-10 04:05:27 --> Helper loaded: my_helper
INFO - 2021-12-10 04:05:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:05:27 --> Controller Class Initialized
DEBUG - 2021-12-10 04:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 04:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:05:27 --> Final output sent to browser
DEBUG - 2021-12-10 04:05:27 --> Total execution time: 0.0590
INFO - 2021-12-10 04:05:29 --> Config Class Initialized
INFO - 2021-12-10 04:05:29 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:05:29 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:05:29 --> Utf8 Class Initialized
INFO - 2021-12-10 04:05:29 --> URI Class Initialized
INFO - 2021-12-10 04:05:29 --> Router Class Initialized
INFO - 2021-12-10 04:05:29 --> Output Class Initialized
INFO - 2021-12-10 04:05:29 --> Security Class Initialized
DEBUG - 2021-12-10 04:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:05:29 --> Input Class Initialized
INFO - 2021-12-10 04:05:29 --> Language Class Initialized
INFO - 2021-12-10 04:05:29 --> Language Class Initialized
INFO - 2021-12-10 04:05:29 --> Config Class Initialized
INFO - 2021-12-10 04:05:29 --> Loader Class Initialized
INFO - 2021-12-10 04:05:29 --> Helper loaded: url_helper
INFO - 2021-12-10 04:05:29 --> Helper loaded: file_helper
INFO - 2021-12-10 04:05:29 --> Helper loaded: form_helper
INFO - 2021-12-10 04:05:29 --> Helper loaded: my_helper
INFO - 2021-12-10 04:05:29 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:05:29 --> Controller Class Initialized
DEBUG - 2021-12-10 04:05:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-10 04:05:29 --> Final output sent to browser
DEBUG - 2021-12-10 04:05:29 --> Total execution time: 0.1650
INFO - 2021-12-10 04:05:52 --> Config Class Initialized
INFO - 2021-12-10 04:05:52 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:05:52 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:05:52 --> Utf8 Class Initialized
INFO - 2021-12-10 04:05:52 --> URI Class Initialized
INFO - 2021-12-10 04:05:52 --> Router Class Initialized
INFO - 2021-12-10 04:05:52 --> Output Class Initialized
INFO - 2021-12-10 04:05:52 --> Security Class Initialized
DEBUG - 2021-12-10 04:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:05:52 --> Input Class Initialized
INFO - 2021-12-10 04:05:52 --> Language Class Initialized
INFO - 2021-12-10 04:05:52 --> Language Class Initialized
INFO - 2021-12-10 04:05:52 --> Config Class Initialized
INFO - 2021-12-10 04:05:52 --> Loader Class Initialized
INFO - 2021-12-10 04:05:52 --> Helper loaded: url_helper
INFO - 2021-12-10 04:05:52 --> Helper loaded: file_helper
INFO - 2021-12-10 04:05:52 --> Helper loaded: form_helper
INFO - 2021-12-10 04:05:52 --> Helper loaded: my_helper
INFO - 2021-12-10 04:05:52 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:05:52 --> Controller Class Initialized
DEBUG - 2021-12-10 04:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-10 04:05:52 --> Final output sent to browser
DEBUG - 2021-12-10 04:05:52 --> Total execution time: 0.1550
INFO - 2021-12-10 04:06:07 --> Config Class Initialized
INFO - 2021-12-10 04:06:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:06:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:06:07 --> Utf8 Class Initialized
INFO - 2021-12-10 04:06:07 --> URI Class Initialized
INFO - 2021-12-10 04:06:07 --> Router Class Initialized
INFO - 2021-12-10 04:06:07 --> Output Class Initialized
INFO - 2021-12-10 04:06:07 --> Security Class Initialized
DEBUG - 2021-12-10 04:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:06:07 --> Input Class Initialized
INFO - 2021-12-10 04:06:07 --> Language Class Initialized
INFO - 2021-12-10 04:06:07 --> Language Class Initialized
INFO - 2021-12-10 04:06:07 --> Config Class Initialized
INFO - 2021-12-10 04:06:07 --> Loader Class Initialized
INFO - 2021-12-10 04:06:07 --> Helper loaded: url_helper
INFO - 2021-12-10 04:06:07 --> Helper loaded: file_helper
INFO - 2021-12-10 04:06:07 --> Helper loaded: form_helper
INFO - 2021-12-10 04:06:07 --> Helper loaded: my_helper
INFO - 2021-12-10 04:06:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:06:07 --> Controller Class Initialized
DEBUG - 2021-12-10 04:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-10 04:06:07 --> Final output sent to browser
DEBUG - 2021-12-10 04:06:07 --> Total execution time: 0.1420
INFO - 2021-12-10 04:12:32 --> Config Class Initialized
INFO - 2021-12-10 04:12:32 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:12:32 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:12:32 --> Utf8 Class Initialized
INFO - 2021-12-10 04:12:32 --> URI Class Initialized
INFO - 2021-12-10 04:12:32 --> Router Class Initialized
INFO - 2021-12-10 04:12:32 --> Output Class Initialized
INFO - 2021-12-10 04:12:32 --> Security Class Initialized
DEBUG - 2021-12-10 04:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:12:32 --> Input Class Initialized
INFO - 2021-12-10 04:12:32 --> Language Class Initialized
INFO - 2021-12-10 04:12:32 --> Language Class Initialized
INFO - 2021-12-10 04:12:32 --> Config Class Initialized
INFO - 2021-12-10 04:12:32 --> Loader Class Initialized
INFO - 2021-12-10 04:12:32 --> Helper loaded: url_helper
INFO - 2021-12-10 04:12:32 --> Helper loaded: file_helper
INFO - 2021-12-10 04:12:32 --> Helper loaded: form_helper
INFO - 2021-12-10 04:12:32 --> Helper loaded: my_helper
INFO - 2021-12-10 04:12:32 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:12:32 --> Controller Class Initialized
DEBUG - 2021-12-10 04:12:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-10 04:12:32 --> Final output sent to browser
DEBUG - 2021-12-10 04:12:32 --> Total execution time: 0.1370
INFO - 2021-12-10 04:12:38 --> Config Class Initialized
INFO - 2021-12-10 04:12:38 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:12:38 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:12:38 --> Utf8 Class Initialized
INFO - 2021-12-10 04:12:38 --> URI Class Initialized
INFO - 2021-12-10 04:12:38 --> Router Class Initialized
INFO - 2021-12-10 04:12:38 --> Output Class Initialized
INFO - 2021-12-10 04:12:38 --> Security Class Initialized
DEBUG - 2021-12-10 04:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:12:38 --> Input Class Initialized
INFO - 2021-12-10 04:12:38 --> Language Class Initialized
INFO - 2021-12-10 04:12:38 --> Language Class Initialized
INFO - 2021-12-10 04:12:38 --> Config Class Initialized
INFO - 2021-12-10 04:12:38 --> Loader Class Initialized
INFO - 2021-12-10 04:12:38 --> Helper loaded: url_helper
INFO - 2021-12-10 04:12:38 --> Helper loaded: file_helper
INFO - 2021-12-10 04:12:38 --> Helper loaded: form_helper
INFO - 2021-12-10 04:12:38 --> Helper loaded: my_helper
INFO - 2021-12-10 04:12:38 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:12:38 --> Controller Class Initialized
DEBUG - 2021-12-10 04:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-10 04:12:38 --> Final output sent to browser
DEBUG - 2021-12-10 04:12:38 --> Total execution time: 0.1240
INFO - 2021-12-10 04:12:58 --> Config Class Initialized
INFO - 2021-12-10 04:12:58 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:12:58 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:12:58 --> Utf8 Class Initialized
INFO - 2021-12-10 04:12:58 --> URI Class Initialized
INFO - 2021-12-10 04:12:58 --> Router Class Initialized
INFO - 2021-12-10 04:12:58 --> Output Class Initialized
INFO - 2021-12-10 04:12:58 --> Security Class Initialized
DEBUG - 2021-12-10 04:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:12:58 --> Input Class Initialized
INFO - 2021-12-10 04:12:58 --> Language Class Initialized
INFO - 2021-12-10 04:12:58 --> Language Class Initialized
INFO - 2021-12-10 04:12:58 --> Config Class Initialized
INFO - 2021-12-10 04:12:58 --> Loader Class Initialized
INFO - 2021-12-10 04:12:58 --> Helper loaded: url_helper
INFO - 2021-12-10 04:12:58 --> Helper loaded: file_helper
INFO - 2021-12-10 04:12:58 --> Helper loaded: form_helper
INFO - 2021-12-10 04:12:58 --> Helper loaded: my_helper
INFO - 2021-12-10 04:12:58 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:12:59 --> Controller Class Initialized
INFO - 2021-12-10 04:12:59 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:12:59 --> Config Class Initialized
INFO - 2021-12-10 04:12:59 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:12:59 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:12:59 --> Utf8 Class Initialized
INFO - 2021-12-10 04:12:59 --> URI Class Initialized
INFO - 2021-12-10 04:12:59 --> Router Class Initialized
INFO - 2021-12-10 04:12:59 --> Output Class Initialized
INFO - 2021-12-10 04:12:59 --> Security Class Initialized
DEBUG - 2021-12-10 04:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:12:59 --> Input Class Initialized
INFO - 2021-12-10 04:12:59 --> Language Class Initialized
INFO - 2021-12-10 04:12:59 --> Language Class Initialized
INFO - 2021-12-10 04:12:59 --> Config Class Initialized
INFO - 2021-12-10 04:12:59 --> Loader Class Initialized
INFO - 2021-12-10 04:12:59 --> Helper loaded: url_helper
INFO - 2021-12-10 04:12:59 --> Helper loaded: file_helper
INFO - 2021-12-10 04:12:59 --> Helper loaded: form_helper
INFO - 2021-12-10 04:12:59 --> Helper loaded: my_helper
INFO - 2021-12-10 04:12:59 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:12:59 --> Controller Class Initialized
DEBUG - 2021-12-10 04:12:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:12:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:12:59 --> Final output sent to browser
DEBUG - 2021-12-10 04:12:59 --> Total execution time: 0.0440
INFO - 2021-12-10 04:18:00 --> Config Class Initialized
INFO - 2021-12-10 04:18:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:00 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:00 --> URI Class Initialized
INFO - 2021-12-10 04:18:00 --> Router Class Initialized
INFO - 2021-12-10 04:18:00 --> Output Class Initialized
INFO - 2021-12-10 04:18:00 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:00 --> Input Class Initialized
INFO - 2021-12-10 04:18:00 --> Language Class Initialized
INFO - 2021-12-10 04:18:00 --> Language Class Initialized
INFO - 2021-12-10 04:18:00 --> Config Class Initialized
INFO - 2021-12-10 04:18:00 --> Loader Class Initialized
INFO - 2021-12-10 04:18:00 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:00 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:00 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:00 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:00 --> Controller Class Initialized
INFO - 2021-12-10 04:18:00 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:18:00 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:00 --> Total execution time: 0.0530
INFO - 2021-12-10 04:18:00 --> Config Class Initialized
INFO - 2021-12-10 04:18:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:00 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:00 --> URI Class Initialized
INFO - 2021-12-10 04:18:00 --> Router Class Initialized
INFO - 2021-12-10 04:18:00 --> Output Class Initialized
INFO - 2021-12-10 04:18:00 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:00 --> Input Class Initialized
INFO - 2021-12-10 04:18:00 --> Language Class Initialized
INFO - 2021-12-10 04:18:00 --> Language Class Initialized
INFO - 2021-12-10 04:18:00 --> Config Class Initialized
INFO - 2021-12-10 04:18:00 --> Loader Class Initialized
INFO - 2021-12-10 04:18:00 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:00 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:00 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:00 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:00 --> Controller Class Initialized
DEBUG - 2021-12-10 04:18:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:18:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:18:01 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:01 --> Total execution time: 0.7330
INFO - 2021-12-10 04:18:08 --> Config Class Initialized
INFO - 2021-12-10 04:18:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:08 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:08 --> URI Class Initialized
INFO - 2021-12-10 04:18:08 --> Router Class Initialized
INFO - 2021-12-10 04:18:08 --> Output Class Initialized
INFO - 2021-12-10 04:18:08 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:08 --> Input Class Initialized
INFO - 2021-12-10 04:18:08 --> Language Class Initialized
INFO - 2021-12-10 04:18:08 --> Language Class Initialized
INFO - 2021-12-10 04:18:08 --> Config Class Initialized
INFO - 2021-12-10 04:18:08 --> Loader Class Initialized
INFO - 2021-12-10 04:18:08 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:08 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:08 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:08 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:08 --> Controller Class Initialized
DEBUG - 2021-12-10 04:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-10 04:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:18:08 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:08 --> Total execution time: 0.0510
INFO - 2021-12-10 04:18:08 --> Config Class Initialized
INFO - 2021-12-10 04:18:08 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:08 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:08 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:08 --> URI Class Initialized
INFO - 2021-12-10 04:18:08 --> Router Class Initialized
INFO - 2021-12-10 04:18:08 --> Output Class Initialized
INFO - 2021-12-10 04:18:08 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:08 --> Input Class Initialized
INFO - 2021-12-10 04:18:08 --> Language Class Initialized
INFO - 2021-12-10 04:18:08 --> Language Class Initialized
INFO - 2021-12-10 04:18:08 --> Config Class Initialized
INFO - 2021-12-10 04:18:08 --> Loader Class Initialized
INFO - 2021-12-10 04:18:08 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:08 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:08 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:08 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:08 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:08 --> Controller Class Initialized
INFO - 2021-12-10 04:18:09 --> Config Class Initialized
INFO - 2021-12-10 04:18:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:09 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:09 --> URI Class Initialized
INFO - 2021-12-10 04:18:09 --> Router Class Initialized
INFO - 2021-12-10 04:18:09 --> Output Class Initialized
INFO - 2021-12-10 04:18:09 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:09 --> Input Class Initialized
INFO - 2021-12-10 04:18:09 --> Language Class Initialized
INFO - 2021-12-10 04:18:09 --> Language Class Initialized
INFO - 2021-12-10 04:18:09 --> Config Class Initialized
INFO - 2021-12-10 04:18:09 --> Loader Class Initialized
INFO - 2021-12-10 04:18:09 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:09 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:09 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:09 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:09 --> Controller Class Initialized
INFO - 2021-12-10 04:18:09 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:09 --> Total execution time: 0.0660
INFO - 2021-12-10 04:18:09 --> Config Class Initialized
INFO - 2021-12-10 04:18:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:09 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:09 --> URI Class Initialized
INFO - 2021-12-10 04:18:09 --> Router Class Initialized
INFO - 2021-12-10 04:18:09 --> Output Class Initialized
INFO - 2021-12-10 04:18:09 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:09 --> Input Class Initialized
INFO - 2021-12-10 04:18:09 --> Language Class Initialized
INFO - 2021-12-10 04:18:09 --> Language Class Initialized
INFO - 2021-12-10 04:18:09 --> Config Class Initialized
INFO - 2021-12-10 04:18:09 --> Loader Class Initialized
INFO - 2021-12-10 04:18:09 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:09 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:09 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:09 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:09 --> Controller Class Initialized
INFO - 2021-12-10 04:18:13 --> Config Class Initialized
INFO - 2021-12-10 04:18:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:13 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:13 --> URI Class Initialized
INFO - 2021-12-10 04:18:13 --> Router Class Initialized
INFO - 2021-12-10 04:18:13 --> Output Class Initialized
INFO - 2021-12-10 04:18:13 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:13 --> Input Class Initialized
INFO - 2021-12-10 04:18:13 --> Language Class Initialized
INFO - 2021-12-10 04:18:13 --> Language Class Initialized
INFO - 2021-12-10 04:18:13 --> Config Class Initialized
INFO - 2021-12-10 04:18:13 --> Loader Class Initialized
INFO - 2021-12-10 04:18:13 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:13 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:13 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:13 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:13 --> Controller Class Initialized
DEBUG - 2021-12-10 04:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-12-10 04:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:18:13 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:13 --> Total execution time: 0.0530
INFO - 2021-12-10 04:18:13 --> Config Class Initialized
INFO - 2021-12-10 04:18:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:13 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:13 --> URI Class Initialized
INFO - 2021-12-10 04:18:13 --> Router Class Initialized
INFO - 2021-12-10 04:18:13 --> Output Class Initialized
INFO - 2021-12-10 04:18:13 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:13 --> Input Class Initialized
INFO - 2021-12-10 04:18:13 --> Language Class Initialized
INFO - 2021-12-10 04:18:13 --> Language Class Initialized
INFO - 2021-12-10 04:18:13 --> Config Class Initialized
INFO - 2021-12-10 04:18:13 --> Loader Class Initialized
INFO - 2021-12-10 04:18:14 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:14 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:14 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:14 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:14 --> Controller Class Initialized
INFO - 2021-12-10 04:18:17 --> Config Class Initialized
INFO - 2021-12-10 04:18:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:17 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:17 --> URI Class Initialized
INFO - 2021-12-10 04:18:17 --> Router Class Initialized
INFO - 2021-12-10 04:18:17 --> Output Class Initialized
INFO - 2021-12-10 04:18:17 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:17 --> Input Class Initialized
INFO - 2021-12-10 04:18:17 --> Language Class Initialized
INFO - 2021-12-10 04:18:17 --> Language Class Initialized
INFO - 2021-12-10 04:18:17 --> Config Class Initialized
INFO - 2021-12-10 04:18:17 --> Loader Class Initialized
INFO - 2021-12-10 04:18:17 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:17 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:17 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:17 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:17 --> Controller Class Initialized
INFO - 2021-12-10 04:18:17 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:18:17 --> Config Class Initialized
INFO - 2021-12-10 04:18:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:17 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:17 --> URI Class Initialized
INFO - 2021-12-10 04:18:17 --> Router Class Initialized
INFO - 2021-12-10 04:18:17 --> Output Class Initialized
INFO - 2021-12-10 04:18:17 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:17 --> Input Class Initialized
INFO - 2021-12-10 04:18:17 --> Language Class Initialized
INFO - 2021-12-10 04:18:17 --> Language Class Initialized
INFO - 2021-12-10 04:18:17 --> Config Class Initialized
INFO - 2021-12-10 04:18:17 --> Loader Class Initialized
INFO - 2021-12-10 04:18:17 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:17 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:17 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:17 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:17 --> Controller Class Initialized
DEBUG - 2021-12-10 04:18:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:18:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:18:17 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:17 --> Total execution time: 0.0350
INFO - 2021-12-10 04:18:28 --> Config Class Initialized
INFO - 2021-12-10 04:18:28 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:28 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:28 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:28 --> URI Class Initialized
INFO - 2021-12-10 04:18:28 --> Router Class Initialized
INFO - 2021-12-10 04:18:28 --> Output Class Initialized
INFO - 2021-12-10 04:18:28 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:28 --> Input Class Initialized
INFO - 2021-12-10 04:18:28 --> Language Class Initialized
INFO - 2021-12-10 04:18:28 --> Language Class Initialized
INFO - 2021-12-10 04:18:28 --> Config Class Initialized
INFO - 2021-12-10 04:18:28 --> Loader Class Initialized
INFO - 2021-12-10 04:18:28 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:28 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:28 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:28 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:28 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:28 --> Controller Class Initialized
INFO - 2021-12-10 04:18:28 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:18:28 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:28 --> Total execution time: 0.0430
INFO - 2021-12-10 04:18:28 --> Config Class Initialized
INFO - 2021-12-10 04:18:28 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:28 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:28 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:28 --> URI Class Initialized
INFO - 2021-12-10 04:18:28 --> Router Class Initialized
INFO - 2021-12-10 04:18:28 --> Output Class Initialized
INFO - 2021-12-10 04:18:28 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:28 --> Input Class Initialized
INFO - 2021-12-10 04:18:28 --> Language Class Initialized
INFO - 2021-12-10 04:18:28 --> Language Class Initialized
INFO - 2021-12-10 04:18:28 --> Config Class Initialized
INFO - 2021-12-10 04:18:28 --> Loader Class Initialized
INFO - 2021-12-10 04:18:28 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:28 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:28 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:28 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:28 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:28 --> Controller Class Initialized
DEBUG - 2021-12-10 04:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:18:28 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:28 --> Total execution time: 0.1550
INFO - 2021-12-10 04:18:30 --> Config Class Initialized
INFO - 2021-12-10 04:18:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:30 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:30 --> URI Class Initialized
INFO - 2021-12-10 04:18:30 --> Router Class Initialized
INFO - 2021-12-10 04:18:30 --> Output Class Initialized
INFO - 2021-12-10 04:18:30 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:30 --> Input Class Initialized
INFO - 2021-12-10 04:18:30 --> Language Class Initialized
INFO - 2021-12-10 04:18:30 --> Language Class Initialized
INFO - 2021-12-10 04:18:30 --> Config Class Initialized
INFO - 2021-12-10 04:18:30 --> Loader Class Initialized
INFO - 2021-12-10 04:18:30 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:30 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:30 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:30 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:30 --> Controller Class Initialized
DEBUG - 2021-12-10 04:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 04:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:18:30 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:30 --> Total execution time: 0.0700
INFO - 2021-12-10 04:18:35 --> Config Class Initialized
INFO - 2021-12-10 04:18:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:35 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:35 --> URI Class Initialized
INFO - 2021-12-10 04:18:35 --> Router Class Initialized
INFO - 2021-12-10 04:18:35 --> Output Class Initialized
INFO - 2021-12-10 04:18:35 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:35 --> Input Class Initialized
INFO - 2021-12-10 04:18:35 --> Language Class Initialized
INFO - 2021-12-10 04:18:35 --> Language Class Initialized
INFO - 2021-12-10 04:18:35 --> Config Class Initialized
INFO - 2021-12-10 04:18:35 --> Loader Class Initialized
INFO - 2021-12-10 04:18:35 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:35 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:35 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:35 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:35 --> Controller Class Initialized
DEBUG - 2021-12-10 04:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 04:18:35 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:35 --> Total execution time: 0.0950
INFO - 2021-12-10 04:18:50 --> Config Class Initialized
INFO - 2021-12-10 04:18:50 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:18:50 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:18:50 --> Utf8 Class Initialized
INFO - 2021-12-10 04:18:50 --> URI Class Initialized
INFO - 2021-12-10 04:18:50 --> Router Class Initialized
INFO - 2021-12-10 04:18:50 --> Output Class Initialized
INFO - 2021-12-10 04:18:50 --> Security Class Initialized
DEBUG - 2021-12-10 04:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:18:50 --> Input Class Initialized
INFO - 2021-12-10 04:18:50 --> Language Class Initialized
INFO - 2021-12-10 04:18:50 --> Language Class Initialized
INFO - 2021-12-10 04:18:50 --> Config Class Initialized
INFO - 2021-12-10 04:18:50 --> Loader Class Initialized
INFO - 2021-12-10 04:18:50 --> Helper loaded: url_helper
INFO - 2021-12-10 04:18:50 --> Helper loaded: file_helper
INFO - 2021-12-10 04:18:50 --> Helper loaded: form_helper
INFO - 2021-12-10 04:18:50 --> Helper loaded: my_helper
INFO - 2021-12-10 04:18:50 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:18:50 --> Controller Class Initialized
DEBUG - 2021-12-10 04:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 04:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:18:50 --> Final output sent to browser
DEBUG - 2021-12-10 04:18:50 --> Total execution time: 0.0930
INFO - 2021-12-10 04:20:05 --> Config Class Initialized
INFO - 2021-12-10 04:20:05 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:20:05 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:20:05 --> Utf8 Class Initialized
INFO - 2021-12-10 04:20:05 --> URI Class Initialized
INFO - 2021-12-10 04:20:05 --> Router Class Initialized
INFO - 2021-12-10 04:20:05 --> Output Class Initialized
INFO - 2021-12-10 04:20:05 --> Security Class Initialized
DEBUG - 2021-12-10 04:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:20:05 --> Input Class Initialized
INFO - 2021-12-10 04:20:05 --> Language Class Initialized
INFO - 2021-12-10 04:20:05 --> Language Class Initialized
INFO - 2021-12-10 04:20:05 --> Config Class Initialized
INFO - 2021-12-10 04:20:05 --> Loader Class Initialized
INFO - 2021-12-10 04:20:05 --> Helper loaded: url_helper
INFO - 2021-12-10 04:20:05 --> Helper loaded: file_helper
INFO - 2021-12-10 04:20:05 --> Helper loaded: form_helper
INFO - 2021-12-10 04:20:05 --> Helper loaded: my_helper
INFO - 2021-12-10 04:20:05 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:20:05 --> Controller Class Initialized
DEBUG - 2021-12-10 04:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 04:20:05 --> Final output sent to browser
DEBUG - 2021-12-10 04:20:05 --> Total execution time: 0.0700
INFO - 2021-12-10 04:20:41 --> Config Class Initialized
INFO - 2021-12-10 04:20:41 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:20:41 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:20:41 --> Utf8 Class Initialized
INFO - 2021-12-10 04:20:41 --> URI Class Initialized
INFO - 2021-12-10 04:20:41 --> Router Class Initialized
INFO - 2021-12-10 04:20:41 --> Output Class Initialized
INFO - 2021-12-10 04:20:41 --> Security Class Initialized
DEBUG - 2021-12-10 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:20:41 --> Input Class Initialized
INFO - 2021-12-10 04:20:41 --> Language Class Initialized
INFO - 2021-12-10 04:20:41 --> Language Class Initialized
INFO - 2021-12-10 04:20:41 --> Config Class Initialized
INFO - 2021-12-10 04:20:41 --> Loader Class Initialized
INFO - 2021-12-10 04:20:41 --> Helper loaded: url_helper
INFO - 2021-12-10 04:20:41 --> Helper loaded: file_helper
INFO - 2021-12-10 04:20:41 --> Helper loaded: form_helper
INFO - 2021-12-10 04:20:41 --> Helper loaded: my_helper
INFO - 2021-12-10 04:20:41 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:20:41 --> Controller Class Initialized
DEBUG - 2021-12-10 04:20:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 04:20:41 --> Final output sent to browser
DEBUG - 2021-12-10 04:20:41 --> Total execution time: 0.0610
INFO - 2021-12-10 04:20:50 --> Config Class Initialized
INFO - 2021-12-10 04:20:50 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:20:50 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:20:50 --> Utf8 Class Initialized
INFO - 2021-12-10 04:20:50 --> URI Class Initialized
INFO - 2021-12-10 04:20:50 --> Router Class Initialized
INFO - 2021-12-10 04:20:50 --> Output Class Initialized
INFO - 2021-12-10 04:20:50 --> Security Class Initialized
DEBUG - 2021-12-10 04:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:20:50 --> Input Class Initialized
INFO - 2021-12-10 04:20:50 --> Language Class Initialized
INFO - 2021-12-10 04:20:50 --> Language Class Initialized
INFO - 2021-12-10 04:20:50 --> Config Class Initialized
INFO - 2021-12-10 04:20:50 --> Loader Class Initialized
INFO - 2021-12-10 04:20:50 --> Helper loaded: url_helper
INFO - 2021-12-10 04:20:50 --> Helper loaded: file_helper
INFO - 2021-12-10 04:20:50 --> Helper loaded: form_helper
INFO - 2021-12-10 04:20:50 --> Helper loaded: my_helper
INFO - 2021-12-10 04:20:50 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:20:50 --> Controller Class Initialized
DEBUG - 2021-12-10 04:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-10 04:20:50 --> Final output sent to browser
DEBUG - 2021-12-10 04:20:50 --> Total execution time: 0.0670
INFO - 2021-12-10 04:21:01 --> Config Class Initialized
INFO - 2021-12-10 04:21:01 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:01 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:01 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:01 --> URI Class Initialized
INFO - 2021-12-10 04:21:01 --> Router Class Initialized
INFO - 2021-12-10 04:21:01 --> Output Class Initialized
INFO - 2021-12-10 04:21:01 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:01 --> Input Class Initialized
INFO - 2021-12-10 04:21:01 --> Language Class Initialized
INFO - 2021-12-10 04:21:01 --> Language Class Initialized
INFO - 2021-12-10 04:21:01 --> Config Class Initialized
INFO - 2021-12-10 04:21:01 --> Loader Class Initialized
INFO - 2021-12-10 04:21:01 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:01 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:01 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:01 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:01 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:01 --> Controller Class Initialized
INFO - 2021-12-10 04:21:01 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:21:01 --> Config Class Initialized
INFO - 2021-12-10 04:21:01 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:01 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:01 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:01 --> URI Class Initialized
INFO - 2021-12-10 04:21:01 --> Router Class Initialized
INFO - 2021-12-10 04:21:01 --> Output Class Initialized
INFO - 2021-12-10 04:21:01 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:01 --> Input Class Initialized
INFO - 2021-12-10 04:21:01 --> Language Class Initialized
INFO - 2021-12-10 04:21:01 --> Language Class Initialized
INFO - 2021-12-10 04:21:01 --> Config Class Initialized
INFO - 2021-12-10 04:21:01 --> Loader Class Initialized
INFO - 2021-12-10 04:21:01 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:01 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:01 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:01 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:01 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:01 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:01 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:01 --> Total execution time: 0.0350
INFO - 2021-12-10 04:21:07 --> Config Class Initialized
INFO - 2021-12-10 04:21:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:07 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:07 --> URI Class Initialized
INFO - 2021-12-10 04:21:07 --> Router Class Initialized
INFO - 2021-12-10 04:21:07 --> Output Class Initialized
INFO - 2021-12-10 04:21:07 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:07 --> Input Class Initialized
INFO - 2021-12-10 04:21:07 --> Language Class Initialized
INFO - 2021-12-10 04:21:07 --> Language Class Initialized
INFO - 2021-12-10 04:21:07 --> Config Class Initialized
INFO - 2021-12-10 04:21:07 --> Loader Class Initialized
INFO - 2021-12-10 04:21:07 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:07 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:07 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:07 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:07 --> Controller Class Initialized
INFO - 2021-12-10 04:21:07 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:21:07 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:07 --> Total execution time: 0.0470
INFO - 2021-12-10 04:21:07 --> Config Class Initialized
INFO - 2021-12-10 04:21:07 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:07 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:07 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:07 --> URI Class Initialized
INFO - 2021-12-10 04:21:07 --> Router Class Initialized
INFO - 2021-12-10 04:21:07 --> Output Class Initialized
INFO - 2021-12-10 04:21:07 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:07 --> Input Class Initialized
INFO - 2021-12-10 04:21:07 --> Language Class Initialized
INFO - 2021-12-10 04:21:07 --> Language Class Initialized
INFO - 2021-12-10 04:21:07 --> Config Class Initialized
INFO - 2021-12-10 04:21:07 --> Loader Class Initialized
INFO - 2021-12-10 04:21:07 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:07 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:07 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:07 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:07 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:07 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:07 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:07 --> Total execution time: 0.1930
INFO - 2021-12-10 04:21:09 --> Config Class Initialized
INFO - 2021-12-10 04:21:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:09 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:09 --> URI Class Initialized
INFO - 2021-12-10 04:21:09 --> Router Class Initialized
INFO - 2021-12-10 04:21:09 --> Output Class Initialized
INFO - 2021-12-10 04:21:09 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:09 --> Input Class Initialized
INFO - 2021-12-10 04:21:09 --> Language Class Initialized
INFO - 2021-12-10 04:21:09 --> Language Class Initialized
INFO - 2021-12-10 04:21:09 --> Config Class Initialized
INFO - 2021-12-10 04:21:09 --> Loader Class Initialized
INFO - 2021-12-10 04:21:09 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:09 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:09 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:09 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:09 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 04:21:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:09 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:09 --> Total execution time: 0.1260
INFO - 2021-12-10 04:21:12 --> Config Class Initialized
INFO - 2021-12-10 04:21:12 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:12 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:12 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:12 --> URI Class Initialized
INFO - 2021-12-10 04:21:12 --> Router Class Initialized
INFO - 2021-12-10 04:21:12 --> Output Class Initialized
INFO - 2021-12-10 04:21:12 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:12 --> Input Class Initialized
INFO - 2021-12-10 04:21:12 --> Language Class Initialized
INFO - 2021-12-10 04:21:12 --> Language Class Initialized
INFO - 2021-12-10 04:21:12 --> Config Class Initialized
INFO - 2021-12-10 04:21:12 --> Loader Class Initialized
INFO - 2021-12-10 04:21:12 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:12 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:12 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:12 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:12 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:12 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-12-10 04:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:12 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:12 --> Total execution time: 0.0630
INFO - 2021-12-10 04:21:13 --> Config Class Initialized
INFO - 2021-12-10 04:21:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:13 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:13 --> URI Class Initialized
INFO - 2021-12-10 04:21:13 --> Router Class Initialized
INFO - 2021-12-10 04:21:13 --> Output Class Initialized
INFO - 2021-12-10 04:21:13 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:13 --> Input Class Initialized
INFO - 2021-12-10 04:21:13 --> Language Class Initialized
INFO - 2021-12-10 04:21:13 --> Language Class Initialized
INFO - 2021-12-10 04:21:13 --> Config Class Initialized
INFO - 2021-12-10 04:21:13 --> Loader Class Initialized
INFO - 2021-12-10 04:21:13 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:13 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:13 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:13 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:14 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-10 04:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:14 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:14 --> Total execution time: 0.0890
INFO - 2021-12-10 04:21:14 --> Config Class Initialized
INFO - 2021-12-10 04:21:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:14 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:14 --> URI Class Initialized
INFO - 2021-12-10 04:21:14 --> Router Class Initialized
INFO - 2021-12-10 04:21:14 --> Output Class Initialized
INFO - 2021-12-10 04:21:14 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:14 --> Input Class Initialized
INFO - 2021-12-10 04:21:14 --> Language Class Initialized
INFO - 2021-12-10 04:21:14 --> Language Class Initialized
INFO - 2021-12-10 04:21:14 --> Config Class Initialized
INFO - 2021-12-10 04:21:14 --> Loader Class Initialized
INFO - 2021-12-10 04:21:14 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:14 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:14 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:14 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:14 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 04:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:14 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:14 --> Total execution time: 0.0810
INFO - 2021-12-10 04:21:18 --> Config Class Initialized
INFO - 2021-12-10 04:21:18 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:18 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:18 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:18 --> URI Class Initialized
INFO - 2021-12-10 04:21:18 --> Router Class Initialized
INFO - 2021-12-10 04:21:18 --> Output Class Initialized
INFO - 2021-12-10 04:21:18 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:18 --> Input Class Initialized
INFO - 2021-12-10 04:21:18 --> Language Class Initialized
INFO - 2021-12-10 04:21:18 --> Language Class Initialized
INFO - 2021-12-10 04:21:18 --> Config Class Initialized
INFO - 2021-12-10 04:21:18 --> Loader Class Initialized
INFO - 2021-12-10 04:21:18 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:18 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:18 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:18 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:18 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:18 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-12-10 04:21:18 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:18 --> Total execution time: 0.0730
INFO - 2021-12-10 04:21:30 --> Config Class Initialized
INFO - 2021-12-10 04:21:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:30 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:30 --> URI Class Initialized
INFO - 2021-12-10 04:21:30 --> Router Class Initialized
INFO - 2021-12-10 04:21:30 --> Output Class Initialized
INFO - 2021-12-10 04:21:30 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:30 --> Input Class Initialized
INFO - 2021-12-10 04:21:30 --> Language Class Initialized
INFO - 2021-12-10 04:21:30 --> Language Class Initialized
INFO - 2021-12-10 04:21:30 --> Config Class Initialized
INFO - 2021-12-10 04:21:30 --> Loader Class Initialized
INFO - 2021-12-10 04:21:30 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:30 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:30 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:30 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:30 --> Controller Class Initialized
INFO - 2021-12-10 04:21:30 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:21:30 --> Config Class Initialized
INFO - 2021-12-10 04:21:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:30 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:30 --> URI Class Initialized
INFO - 2021-12-10 04:21:30 --> Router Class Initialized
INFO - 2021-12-10 04:21:30 --> Output Class Initialized
INFO - 2021-12-10 04:21:30 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:30 --> Input Class Initialized
INFO - 2021-12-10 04:21:30 --> Language Class Initialized
INFO - 2021-12-10 04:21:30 --> Language Class Initialized
INFO - 2021-12-10 04:21:30 --> Config Class Initialized
INFO - 2021-12-10 04:21:30 --> Loader Class Initialized
INFO - 2021-12-10 04:21:30 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:30 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:30 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:30 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:30 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:30 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:30 --> Total execution time: 0.0350
INFO - 2021-12-10 04:21:35 --> Config Class Initialized
INFO - 2021-12-10 04:21:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:35 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:35 --> URI Class Initialized
INFO - 2021-12-10 04:21:35 --> Router Class Initialized
INFO - 2021-12-10 04:21:35 --> Output Class Initialized
INFO - 2021-12-10 04:21:35 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:35 --> Input Class Initialized
INFO - 2021-12-10 04:21:35 --> Language Class Initialized
INFO - 2021-12-10 04:21:35 --> Language Class Initialized
INFO - 2021-12-10 04:21:35 --> Config Class Initialized
INFO - 2021-12-10 04:21:35 --> Loader Class Initialized
INFO - 2021-12-10 04:21:35 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:35 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:35 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:35 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:35 --> Controller Class Initialized
INFO - 2021-12-10 04:21:35 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:21:35 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:35 --> Total execution time: 0.0580
INFO - 2021-12-10 04:21:35 --> Config Class Initialized
INFO - 2021-12-10 04:21:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:35 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:35 --> URI Class Initialized
INFO - 2021-12-10 04:21:35 --> Router Class Initialized
INFO - 2021-12-10 04:21:35 --> Output Class Initialized
INFO - 2021-12-10 04:21:35 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:35 --> Input Class Initialized
INFO - 2021-12-10 04:21:35 --> Language Class Initialized
INFO - 2021-12-10 04:21:35 --> Language Class Initialized
INFO - 2021-12-10 04:21:35 --> Config Class Initialized
INFO - 2021-12-10 04:21:35 --> Loader Class Initialized
INFO - 2021-12-10 04:21:35 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:35 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:35 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:35 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:35 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:21:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:36 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:36 --> Total execution time: 0.1990
INFO - 2021-12-10 04:21:37 --> Config Class Initialized
INFO - 2021-12-10 04:21:37 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:37 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:37 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:37 --> URI Class Initialized
INFO - 2021-12-10 04:21:37 --> Router Class Initialized
INFO - 2021-12-10 04:21:37 --> Output Class Initialized
INFO - 2021-12-10 04:21:37 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:37 --> Input Class Initialized
INFO - 2021-12-10 04:21:37 --> Language Class Initialized
INFO - 2021-12-10 04:21:37 --> Language Class Initialized
INFO - 2021-12-10 04:21:37 --> Config Class Initialized
INFO - 2021-12-10 04:21:37 --> Loader Class Initialized
INFO - 2021-12-10 04:21:37 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:37 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:37 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:37 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:37 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:37 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 04:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:37 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:37 --> Total execution time: 0.1150
INFO - 2021-12-10 04:21:40 --> Config Class Initialized
INFO - 2021-12-10 04:21:40 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:40 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:40 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:40 --> URI Class Initialized
INFO - 2021-12-10 04:21:40 --> Router Class Initialized
INFO - 2021-12-10 04:21:40 --> Output Class Initialized
INFO - 2021-12-10 04:21:40 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:40 --> Input Class Initialized
INFO - 2021-12-10 04:21:40 --> Language Class Initialized
INFO - 2021-12-10 04:21:40 --> Language Class Initialized
INFO - 2021-12-10 04:21:40 --> Config Class Initialized
INFO - 2021-12-10 04:21:40 --> Loader Class Initialized
INFO - 2021-12-10 04:21:40 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:40 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:40 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:40 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:40 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:40 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 04:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:21:40 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:40 --> Total execution time: 0.0610
INFO - 2021-12-10 04:21:44 --> Config Class Initialized
INFO - 2021-12-10 04:21:44 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:21:44 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:21:44 --> Utf8 Class Initialized
INFO - 2021-12-10 04:21:44 --> URI Class Initialized
INFO - 2021-12-10 04:21:44 --> Router Class Initialized
INFO - 2021-12-10 04:21:44 --> Output Class Initialized
INFO - 2021-12-10 04:21:44 --> Security Class Initialized
DEBUG - 2021-12-10 04:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:21:44 --> Input Class Initialized
INFO - 2021-12-10 04:21:44 --> Language Class Initialized
INFO - 2021-12-10 04:21:44 --> Language Class Initialized
INFO - 2021-12-10 04:21:44 --> Config Class Initialized
INFO - 2021-12-10 04:21:44 --> Loader Class Initialized
INFO - 2021-12-10 04:21:44 --> Helper loaded: url_helper
INFO - 2021-12-10 04:21:44 --> Helper loaded: file_helper
INFO - 2021-12-10 04:21:44 --> Helper loaded: form_helper
INFO - 2021-12-10 04:21:44 --> Helper loaded: my_helper
INFO - 2021-12-10 04:21:44 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:21:44 --> Controller Class Initialized
DEBUG - 2021-12-10 04:21:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-12-10 04:21:44 --> Final output sent to browser
DEBUG - 2021-12-10 04:21:44 --> Total execution time: 0.0800
INFO - 2021-12-10 04:22:00 --> Config Class Initialized
INFO - 2021-12-10 04:22:00 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:00 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:00 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:00 --> URI Class Initialized
DEBUG - 2021-12-10 04:22:00 --> No URI present. Default controller set.
INFO - 2021-12-10 04:22:00 --> Router Class Initialized
INFO - 2021-12-10 04:22:00 --> Output Class Initialized
INFO - 2021-12-10 04:22:00 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:00 --> Input Class Initialized
INFO - 2021-12-10 04:22:00 --> Language Class Initialized
INFO - 2021-12-10 04:22:00 --> Language Class Initialized
INFO - 2021-12-10 04:22:00 --> Config Class Initialized
INFO - 2021-12-10 04:22:00 --> Loader Class Initialized
INFO - 2021-12-10 04:22:00 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:00 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:00 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:00 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:00 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:00 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:00 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:00 --> Total execution time: 0.2050
INFO - 2021-12-10 04:22:02 --> Config Class Initialized
INFO - 2021-12-10 04:22:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:02 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:02 --> URI Class Initialized
INFO - 2021-12-10 04:22:02 --> Router Class Initialized
INFO - 2021-12-10 04:22:02 --> Output Class Initialized
INFO - 2021-12-10 04:22:02 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:02 --> Input Class Initialized
INFO - 2021-12-10 04:22:02 --> Language Class Initialized
INFO - 2021-12-10 04:22:02 --> Language Class Initialized
INFO - 2021-12-10 04:22:02 --> Config Class Initialized
INFO - 2021-12-10 04:22:02 --> Loader Class Initialized
INFO - 2021-12-10 04:22:02 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:02 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:02 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:02 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:02 --> Controller Class Initialized
INFO - 2021-12-10 04:22:02 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:22:02 --> Config Class Initialized
INFO - 2021-12-10 04:22:02 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:02 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:02 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:02 --> URI Class Initialized
INFO - 2021-12-10 04:22:02 --> Router Class Initialized
INFO - 2021-12-10 04:22:02 --> Output Class Initialized
INFO - 2021-12-10 04:22:02 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:02 --> Input Class Initialized
INFO - 2021-12-10 04:22:02 --> Language Class Initialized
INFO - 2021-12-10 04:22:02 --> Language Class Initialized
INFO - 2021-12-10 04:22:02 --> Config Class Initialized
INFO - 2021-12-10 04:22:02 --> Loader Class Initialized
INFO - 2021-12-10 04:22:02 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:02 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:02 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:02 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:02 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:02 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:02 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:02 --> Total execution time: 0.0400
INFO - 2021-12-10 04:22:09 --> Config Class Initialized
INFO - 2021-12-10 04:22:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:09 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:09 --> URI Class Initialized
INFO - 2021-12-10 04:22:09 --> Router Class Initialized
INFO - 2021-12-10 04:22:09 --> Output Class Initialized
INFO - 2021-12-10 04:22:09 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:09 --> Input Class Initialized
INFO - 2021-12-10 04:22:09 --> Language Class Initialized
INFO - 2021-12-10 04:22:09 --> Language Class Initialized
INFO - 2021-12-10 04:22:09 --> Config Class Initialized
INFO - 2021-12-10 04:22:09 --> Loader Class Initialized
INFO - 2021-12-10 04:22:09 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:09 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:09 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:09 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:09 --> Controller Class Initialized
INFO - 2021-12-10 04:22:09 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:22:09 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:09 --> Total execution time: 0.0460
INFO - 2021-12-10 04:22:10 --> Config Class Initialized
INFO - 2021-12-10 04:22:10 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:10 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:10 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:10 --> URI Class Initialized
INFO - 2021-12-10 04:22:10 --> Router Class Initialized
INFO - 2021-12-10 04:22:10 --> Output Class Initialized
INFO - 2021-12-10 04:22:10 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:10 --> Input Class Initialized
INFO - 2021-12-10 04:22:10 --> Language Class Initialized
INFO - 2021-12-10 04:22:10 --> Language Class Initialized
INFO - 2021-12-10 04:22:10 --> Config Class Initialized
INFO - 2021-12-10 04:22:10 --> Loader Class Initialized
INFO - 2021-12-10 04:22:10 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:10 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:10 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:10 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:10 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:10 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:10 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:10 --> Total execution time: 0.1360
INFO - 2021-12-10 04:22:11 --> Config Class Initialized
INFO - 2021-12-10 04:22:11 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:11 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:11 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:11 --> URI Class Initialized
INFO - 2021-12-10 04:22:11 --> Router Class Initialized
INFO - 2021-12-10 04:22:11 --> Output Class Initialized
INFO - 2021-12-10 04:22:11 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:11 --> Input Class Initialized
INFO - 2021-12-10 04:22:11 --> Language Class Initialized
INFO - 2021-12-10 04:22:11 --> Language Class Initialized
INFO - 2021-12-10 04:22:11 --> Config Class Initialized
INFO - 2021-12-10 04:22:11 --> Loader Class Initialized
INFO - 2021-12-10 04:22:11 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:11 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:11 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:11 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:11 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:11 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 04:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:11 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:11 --> Total execution time: 0.1390
INFO - 2021-12-10 04:22:14 --> Config Class Initialized
INFO - 2021-12-10 04:22:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:14 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:14 --> URI Class Initialized
INFO - 2021-12-10 04:22:14 --> Router Class Initialized
INFO - 2021-12-10 04:22:14 --> Output Class Initialized
INFO - 2021-12-10 04:22:14 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:14 --> Input Class Initialized
INFO - 2021-12-10 04:22:14 --> Language Class Initialized
INFO - 2021-12-10 04:22:14 --> Language Class Initialized
INFO - 2021-12-10 04:22:14 --> Config Class Initialized
INFO - 2021-12-10 04:22:14 --> Loader Class Initialized
INFO - 2021-12-10 04:22:14 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:14 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:14 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:14 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:14 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 04:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:14 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:14 --> Total execution time: 0.0570
INFO - 2021-12-10 04:22:17 --> Config Class Initialized
INFO - 2021-12-10 04:22:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:17 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:17 --> URI Class Initialized
INFO - 2021-12-10 04:22:17 --> Router Class Initialized
INFO - 2021-12-10 04:22:17 --> Output Class Initialized
INFO - 2021-12-10 04:22:17 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:17 --> Input Class Initialized
INFO - 2021-12-10 04:22:17 --> Language Class Initialized
INFO - 2021-12-10 04:22:17 --> Language Class Initialized
INFO - 2021-12-10 04:22:17 --> Config Class Initialized
INFO - 2021-12-10 04:22:17 --> Loader Class Initialized
INFO - 2021-12-10 04:22:17 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:17 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:17 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:17 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:17 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-12-10 04:22:17 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:17 --> Total execution time: 0.0860
INFO - 2021-12-10 04:22:26 --> Config Class Initialized
INFO - 2021-12-10 04:22:26 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:26 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:26 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:26 --> URI Class Initialized
INFO - 2021-12-10 04:22:26 --> Router Class Initialized
INFO - 2021-12-10 04:22:26 --> Output Class Initialized
INFO - 2021-12-10 04:22:26 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:26 --> Input Class Initialized
INFO - 2021-12-10 04:22:26 --> Language Class Initialized
INFO - 2021-12-10 04:22:26 --> Language Class Initialized
INFO - 2021-12-10 04:22:26 --> Config Class Initialized
INFO - 2021-12-10 04:22:26 --> Loader Class Initialized
INFO - 2021-12-10 04:22:26 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:26 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:27 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:27 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:27 --> Controller Class Initialized
INFO - 2021-12-10 04:22:27 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:22:27 --> Config Class Initialized
INFO - 2021-12-10 04:22:27 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:27 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:27 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:27 --> URI Class Initialized
INFO - 2021-12-10 04:22:27 --> Router Class Initialized
INFO - 2021-12-10 04:22:27 --> Output Class Initialized
INFO - 2021-12-10 04:22:27 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:27 --> Input Class Initialized
INFO - 2021-12-10 04:22:27 --> Language Class Initialized
INFO - 2021-12-10 04:22:27 --> Language Class Initialized
INFO - 2021-12-10 04:22:27 --> Config Class Initialized
INFO - 2021-12-10 04:22:27 --> Loader Class Initialized
INFO - 2021-12-10 04:22:27 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:27 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:27 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:27 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:27 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:27 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:27 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:27 --> Total execution time: 0.0350
INFO - 2021-12-10 04:22:33 --> Config Class Initialized
INFO - 2021-12-10 04:22:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:33 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:33 --> URI Class Initialized
INFO - 2021-12-10 04:22:33 --> Router Class Initialized
INFO - 2021-12-10 04:22:33 --> Output Class Initialized
INFO - 2021-12-10 04:22:33 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:33 --> Input Class Initialized
INFO - 2021-12-10 04:22:33 --> Language Class Initialized
INFO - 2021-12-10 04:22:33 --> Language Class Initialized
INFO - 2021-12-10 04:22:33 --> Config Class Initialized
INFO - 2021-12-10 04:22:33 --> Loader Class Initialized
INFO - 2021-12-10 04:22:33 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:33 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:33 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:33 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:33 --> Controller Class Initialized
INFO - 2021-12-10 04:22:33 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:22:33 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:33 --> Total execution time: 0.0490
INFO - 2021-12-10 04:22:33 --> Config Class Initialized
INFO - 2021-12-10 04:22:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:33 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:33 --> URI Class Initialized
INFO - 2021-12-10 04:22:33 --> Router Class Initialized
INFO - 2021-12-10 04:22:33 --> Output Class Initialized
INFO - 2021-12-10 04:22:33 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:33 --> Input Class Initialized
INFO - 2021-12-10 04:22:33 --> Language Class Initialized
INFO - 2021-12-10 04:22:33 --> Language Class Initialized
INFO - 2021-12-10 04:22:33 --> Config Class Initialized
INFO - 2021-12-10 04:22:33 --> Loader Class Initialized
INFO - 2021-12-10 04:22:33 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:33 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:33 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:33 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:33 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-10 04:22:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:33 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:33 --> Total execution time: 0.2060
INFO - 2021-12-10 04:22:35 --> Config Class Initialized
INFO - 2021-12-10 04:22:35 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:35 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:35 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:35 --> URI Class Initialized
INFO - 2021-12-10 04:22:35 --> Router Class Initialized
INFO - 2021-12-10 04:22:35 --> Output Class Initialized
INFO - 2021-12-10 04:22:35 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:35 --> Input Class Initialized
INFO - 2021-12-10 04:22:35 --> Language Class Initialized
INFO - 2021-12-10 04:22:35 --> Language Class Initialized
INFO - 2021-12-10 04:22:35 --> Config Class Initialized
INFO - 2021-12-10 04:22:35 --> Loader Class Initialized
INFO - 2021-12-10 04:22:35 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:35 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:35 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:35 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:35 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:35 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 04:22:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:35 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:35 --> Total execution time: 0.0750
INFO - 2021-12-10 04:22:38 --> Config Class Initialized
INFO - 2021-12-10 04:22:38 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:38 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:38 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:38 --> URI Class Initialized
INFO - 2021-12-10 04:22:38 --> Router Class Initialized
INFO - 2021-12-10 04:22:38 --> Output Class Initialized
INFO - 2021-12-10 04:22:38 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:38 --> Input Class Initialized
INFO - 2021-12-10 04:22:38 --> Language Class Initialized
INFO - 2021-12-10 04:22:38 --> Language Class Initialized
INFO - 2021-12-10 04:22:38 --> Config Class Initialized
INFO - 2021-12-10 04:22:38 --> Loader Class Initialized
INFO - 2021-12-10 04:22:38 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:38 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:38 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:38 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:38 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:38 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-10 04:22:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:38 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:38 --> Total execution time: 0.0990
INFO - 2021-12-10 04:22:41 --> Config Class Initialized
INFO - 2021-12-10 04:22:41 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:22:41 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:22:41 --> Utf8 Class Initialized
INFO - 2021-12-10 04:22:41 --> URI Class Initialized
INFO - 2021-12-10 04:22:41 --> Router Class Initialized
INFO - 2021-12-10 04:22:41 --> Output Class Initialized
INFO - 2021-12-10 04:22:41 --> Security Class Initialized
DEBUG - 2021-12-10 04:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:22:41 --> Input Class Initialized
INFO - 2021-12-10 04:22:41 --> Language Class Initialized
INFO - 2021-12-10 04:22:41 --> Language Class Initialized
INFO - 2021-12-10 04:22:41 --> Config Class Initialized
INFO - 2021-12-10 04:22:41 --> Loader Class Initialized
INFO - 2021-12-10 04:22:41 --> Helper loaded: url_helper
INFO - 2021-12-10 04:22:41 --> Helper loaded: file_helper
INFO - 2021-12-10 04:22:41 --> Helper loaded: form_helper
INFO - 2021-12-10 04:22:41 --> Helper loaded: my_helper
INFO - 2021-12-10 04:22:41 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:22:41 --> Controller Class Initialized
DEBUG - 2021-12-10 04:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-10 04:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:22:41 --> Final output sent to browser
DEBUG - 2021-12-10 04:22:41 --> Total execution time: 0.0690
INFO - 2021-12-10 04:23:58 --> Config Class Initialized
INFO - 2021-12-10 04:23:58 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:23:58 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:23:58 --> Utf8 Class Initialized
INFO - 2021-12-10 04:23:58 --> URI Class Initialized
INFO - 2021-12-10 04:23:58 --> Router Class Initialized
INFO - 2021-12-10 04:23:58 --> Output Class Initialized
INFO - 2021-12-10 04:23:58 --> Security Class Initialized
DEBUG - 2021-12-10 04:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:23:58 --> Input Class Initialized
INFO - 2021-12-10 04:23:58 --> Language Class Initialized
INFO - 2021-12-10 04:23:58 --> Language Class Initialized
INFO - 2021-12-10 04:23:58 --> Config Class Initialized
INFO - 2021-12-10 04:23:58 --> Loader Class Initialized
INFO - 2021-12-10 04:23:58 --> Helper loaded: url_helper
INFO - 2021-12-10 04:23:58 --> Helper loaded: file_helper
INFO - 2021-12-10 04:23:58 --> Helper loaded: form_helper
INFO - 2021-12-10 04:23:58 --> Helper loaded: my_helper
INFO - 2021-12-10 04:23:58 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:23:58 --> Controller Class Initialized
DEBUG - 2021-12-10 04:23:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-10 04:23:58 --> Final output sent to browser
DEBUG - 2021-12-10 04:23:58 --> Total execution time: 0.0660
INFO - 2021-12-10 04:24:17 --> Config Class Initialized
INFO - 2021-12-10 04:24:17 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:24:17 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:24:17 --> Utf8 Class Initialized
INFO - 2021-12-10 04:24:17 --> URI Class Initialized
INFO - 2021-12-10 04:24:17 --> Router Class Initialized
INFO - 2021-12-10 04:24:17 --> Output Class Initialized
INFO - 2021-12-10 04:24:17 --> Security Class Initialized
DEBUG - 2021-12-10 04:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:24:17 --> Input Class Initialized
INFO - 2021-12-10 04:24:17 --> Language Class Initialized
INFO - 2021-12-10 04:24:17 --> Language Class Initialized
INFO - 2021-12-10 04:24:17 --> Config Class Initialized
INFO - 2021-12-10 04:24:17 --> Loader Class Initialized
INFO - 2021-12-10 04:24:17 --> Helper loaded: url_helper
INFO - 2021-12-10 04:24:17 --> Helper loaded: file_helper
INFO - 2021-12-10 04:24:17 --> Helper loaded: form_helper
INFO - 2021-12-10 04:24:17 --> Helper loaded: my_helper
INFO - 2021-12-10 04:24:17 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:24:17 --> Controller Class Initialized
DEBUG - 2021-12-10 04:24:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-10 04:24:17 --> Final output sent to browser
DEBUG - 2021-12-10 04:24:17 --> Total execution time: 0.0520
INFO - 2021-12-10 04:24:28 --> Config Class Initialized
INFO - 2021-12-10 04:24:28 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:24:28 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:24:28 --> Utf8 Class Initialized
INFO - 2021-12-10 04:24:28 --> URI Class Initialized
INFO - 2021-12-10 04:24:28 --> Router Class Initialized
INFO - 2021-12-10 04:24:28 --> Output Class Initialized
INFO - 2021-12-10 04:24:28 --> Security Class Initialized
DEBUG - 2021-12-10 04:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:24:28 --> Input Class Initialized
INFO - 2021-12-10 04:24:28 --> Language Class Initialized
INFO - 2021-12-10 04:24:28 --> Language Class Initialized
INFO - 2021-12-10 04:24:28 --> Config Class Initialized
INFO - 2021-12-10 04:24:28 --> Loader Class Initialized
INFO - 2021-12-10 04:24:28 --> Helper loaded: url_helper
INFO - 2021-12-10 04:24:28 --> Helper loaded: file_helper
INFO - 2021-12-10 04:24:28 --> Helper loaded: form_helper
INFO - 2021-12-10 04:24:28 --> Helper loaded: my_helper
INFO - 2021-12-10 04:24:28 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:24:28 --> Controller Class Initialized
INFO - 2021-12-10 04:24:28 --> Helper loaded: cookie_helper
INFO - 2021-12-10 04:24:28 --> Config Class Initialized
INFO - 2021-12-10 04:24:28 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:24:28 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:24:28 --> Utf8 Class Initialized
INFO - 2021-12-10 04:24:28 --> URI Class Initialized
INFO - 2021-12-10 04:24:28 --> Router Class Initialized
INFO - 2021-12-10 04:24:28 --> Output Class Initialized
INFO - 2021-12-10 04:24:28 --> Security Class Initialized
DEBUG - 2021-12-10 04:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:24:28 --> Input Class Initialized
INFO - 2021-12-10 04:24:28 --> Language Class Initialized
INFO - 2021-12-10 04:24:28 --> Language Class Initialized
INFO - 2021-12-10 04:24:28 --> Config Class Initialized
INFO - 2021-12-10 04:24:28 --> Loader Class Initialized
INFO - 2021-12-10 04:24:28 --> Helper loaded: url_helper
INFO - 2021-12-10 04:24:28 --> Helper loaded: file_helper
INFO - 2021-12-10 04:24:28 --> Helper loaded: form_helper
INFO - 2021-12-10 04:24:28 --> Helper loaded: my_helper
INFO - 2021-12-10 04:24:28 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:24:28 --> Controller Class Initialized
DEBUG - 2021-12-10 04:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-10 04:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-10 04:24:28 --> Final output sent to browser
DEBUG - 2021-12-10 04:24:28 --> Total execution time: 0.0350
