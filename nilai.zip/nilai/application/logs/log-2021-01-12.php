<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-12 01:32:43 --> Config Class Initialized
INFO - 2021-01-12 01:32:43 --> Hooks Class Initialized
DEBUG - 2021-01-12 01:32:43 --> UTF-8 Support Enabled
INFO - 2021-01-12 01:32:43 --> Utf8 Class Initialized
INFO - 2021-01-12 01:32:43 --> URI Class Initialized
DEBUG - 2021-01-12 01:32:43 --> No URI present. Default controller set.
INFO - 2021-01-12 01:32:43 --> Router Class Initialized
INFO - 2021-01-12 01:32:43 --> Output Class Initialized
INFO - 2021-01-12 01:32:43 --> Security Class Initialized
DEBUG - 2021-01-12 01:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 01:32:43 --> Input Class Initialized
INFO - 2021-01-12 01:32:43 --> Language Class Initialized
INFO - 2021-01-12 01:32:43 --> Language Class Initialized
INFO - 2021-01-12 01:32:43 --> Config Class Initialized
INFO - 2021-01-12 01:32:43 --> Loader Class Initialized
INFO - 2021-01-12 01:32:43 --> Helper loaded: url_helper
INFO - 2021-01-12 01:32:43 --> Helper loaded: file_helper
INFO - 2021-01-12 01:32:43 --> Helper loaded: form_helper
INFO - 2021-01-12 01:32:43 --> Helper loaded: my_helper
INFO - 2021-01-12 01:32:43 --> Database Driver Class Initialized
DEBUG - 2021-01-12 01:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 01:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 01:32:43 --> Controller Class Initialized
INFO - 2021-01-12 01:32:43 --> Config Class Initialized
INFO - 2021-01-12 01:32:43 --> Hooks Class Initialized
DEBUG - 2021-01-12 01:32:43 --> UTF-8 Support Enabled
INFO - 2021-01-12 01:32:43 --> Utf8 Class Initialized
INFO - 2021-01-12 01:32:43 --> URI Class Initialized
INFO - 2021-01-12 01:32:43 --> Router Class Initialized
INFO - 2021-01-12 01:32:43 --> Output Class Initialized
INFO - 2021-01-12 01:32:43 --> Security Class Initialized
DEBUG - 2021-01-12 01:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 01:32:44 --> Input Class Initialized
INFO - 2021-01-12 01:32:44 --> Language Class Initialized
INFO - 2021-01-12 01:32:44 --> Language Class Initialized
INFO - 2021-01-12 01:32:44 --> Config Class Initialized
INFO - 2021-01-12 01:32:44 --> Loader Class Initialized
INFO - 2021-01-12 01:32:44 --> Helper loaded: url_helper
INFO - 2021-01-12 01:32:44 --> Helper loaded: file_helper
INFO - 2021-01-12 01:32:44 --> Helper loaded: form_helper
INFO - 2021-01-12 01:32:44 --> Helper loaded: my_helper
INFO - 2021-01-12 01:32:44 --> Database Driver Class Initialized
DEBUG - 2021-01-12 01:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 01:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 01:32:44 --> Controller Class Initialized
DEBUG - 2021-01-12 01:32:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 01:32:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 01:32:44 --> Final output sent to browser
DEBUG - 2021-01-12 01:32:44 --> Total execution time: 0.5638
INFO - 2021-01-12 01:38:04 --> Config Class Initialized
INFO - 2021-01-12 01:38:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 01:38:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 01:38:04 --> Utf8 Class Initialized
INFO - 2021-01-12 01:38:04 --> URI Class Initialized
INFO - 2021-01-12 01:38:04 --> Router Class Initialized
INFO - 2021-01-12 01:38:04 --> Output Class Initialized
INFO - 2021-01-12 01:38:04 --> Security Class Initialized
DEBUG - 2021-01-12 01:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 01:38:04 --> Input Class Initialized
INFO - 2021-01-12 01:38:04 --> Language Class Initialized
INFO - 2021-01-12 01:38:04 --> Language Class Initialized
INFO - 2021-01-12 01:38:04 --> Config Class Initialized
INFO - 2021-01-12 01:38:04 --> Loader Class Initialized
INFO - 2021-01-12 01:38:04 --> Helper loaded: url_helper
INFO - 2021-01-12 01:38:04 --> Helper loaded: file_helper
INFO - 2021-01-12 01:38:04 --> Helper loaded: form_helper
INFO - 2021-01-12 01:38:04 --> Helper loaded: my_helper
INFO - 2021-01-12 01:38:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 01:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 01:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 01:38:04 --> Controller Class Initialized
INFO - 2021-01-12 01:38:04 --> Helper loaded: cookie_helper
INFO - 2021-01-12 01:38:04 --> Final output sent to browser
DEBUG - 2021-01-12 01:38:04 --> Total execution time: 0.4817
INFO - 2021-01-12 01:38:05 --> Config Class Initialized
INFO - 2021-01-12 01:38:05 --> Hooks Class Initialized
DEBUG - 2021-01-12 01:38:05 --> UTF-8 Support Enabled
INFO - 2021-01-12 01:38:05 --> Utf8 Class Initialized
INFO - 2021-01-12 01:38:05 --> URI Class Initialized
INFO - 2021-01-12 01:38:05 --> Router Class Initialized
INFO - 2021-01-12 01:38:05 --> Output Class Initialized
INFO - 2021-01-12 01:38:05 --> Security Class Initialized
DEBUG - 2021-01-12 01:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 01:38:05 --> Input Class Initialized
INFO - 2021-01-12 01:38:05 --> Language Class Initialized
INFO - 2021-01-12 01:38:05 --> Language Class Initialized
INFO - 2021-01-12 01:38:05 --> Config Class Initialized
INFO - 2021-01-12 01:38:05 --> Loader Class Initialized
INFO - 2021-01-12 01:38:05 --> Helper loaded: url_helper
INFO - 2021-01-12 01:38:05 --> Helper loaded: file_helper
INFO - 2021-01-12 01:38:05 --> Helper loaded: form_helper
INFO - 2021-01-12 01:38:05 --> Helper loaded: my_helper
INFO - 2021-01-12 01:38:05 --> Database Driver Class Initialized
DEBUG - 2021-01-12 01:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 01:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 01:38:05 --> Controller Class Initialized
DEBUG - 2021-01-12 01:38:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 01:38:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 01:38:06 --> Final output sent to browser
DEBUG - 2021-01-12 01:38:06 --> Total execution time: 0.8276
INFO - 2021-01-12 02:14:57 --> Config Class Initialized
INFO - 2021-01-12 02:14:57 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:14:57 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:14:57 --> Utf8 Class Initialized
INFO - 2021-01-12 02:14:57 --> URI Class Initialized
INFO - 2021-01-12 02:14:57 --> Router Class Initialized
INFO - 2021-01-12 02:14:57 --> Output Class Initialized
INFO - 2021-01-12 02:14:57 --> Security Class Initialized
DEBUG - 2021-01-12 02:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:14:57 --> Input Class Initialized
INFO - 2021-01-12 02:14:57 --> Language Class Initialized
INFO - 2021-01-12 02:14:57 --> Language Class Initialized
INFO - 2021-01-12 02:14:57 --> Config Class Initialized
INFO - 2021-01-12 02:14:57 --> Loader Class Initialized
INFO - 2021-01-12 02:14:57 --> Helper loaded: url_helper
INFO - 2021-01-12 02:14:57 --> Helper loaded: file_helper
INFO - 2021-01-12 02:14:57 --> Helper loaded: form_helper
INFO - 2021-01-12 02:14:57 --> Helper loaded: my_helper
INFO - 2021-01-12 02:14:57 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:14:57 --> Controller Class Initialized
INFO - 2021-01-12 02:14:57 --> Helper loaded: cookie_helper
INFO - 2021-01-12 02:14:57 --> Config Class Initialized
INFO - 2021-01-12 02:14:57 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:14:57 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:14:57 --> Utf8 Class Initialized
INFO - 2021-01-12 02:14:57 --> URI Class Initialized
INFO - 2021-01-12 02:14:57 --> Router Class Initialized
INFO - 2021-01-12 02:14:57 --> Output Class Initialized
INFO - 2021-01-12 02:14:57 --> Security Class Initialized
DEBUG - 2021-01-12 02:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:14:57 --> Input Class Initialized
INFO - 2021-01-12 02:14:57 --> Language Class Initialized
INFO - 2021-01-12 02:14:57 --> Language Class Initialized
INFO - 2021-01-12 02:14:57 --> Config Class Initialized
INFO - 2021-01-12 02:14:57 --> Loader Class Initialized
INFO - 2021-01-12 02:14:57 --> Helper loaded: url_helper
INFO - 2021-01-12 02:14:57 --> Helper loaded: file_helper
INFO - 2021-01-12 02:14:57 --> Helper loaded: form_helper
INFO - 2021-01-12 02:14:57 --> Helper loaded: my_helper
INFO - 2021-01-12 02:14:57 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:14:57 --> Controller Class Initialized
DEBUG - 2021-01-12 02:14:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 02:14:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 02:14:57 --> Final output sent to browser
DEBUG - 2021-01-12 02:14:57 --> Total execution time: 0.2159
INFO - 2021-01-12 02:15:03 --> Config Class Initialized
INFO - 2021-01-12 02:15:03 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:03 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:03 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:03 --> URI Class Initialized
INFO - 2021-01-12 02:15:03 --> Router Class Initialized
INFO - 2021-01-12 02:15:03 --> Output Class Initialized
INFO - 2021-01-12 02:15:03 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:03 --> Input Class Initialized
INFO - 2021-01-12 02:15:03 --> Language Class Initialized
INFO - 2021-01-12 02:15:03 --> Language Class Initialized
INFO - 2021-01-12 02:15:03 --> Config Class Initialized
INFO - 2021-01-12 02:15:04 --> Loader Class Initialized
INFO - 2021-01-12 02:15:04 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:04 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:04 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:04 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:04 --> Controller Class Initialized
INFO - 2021-01-12 02:15:04 --> Helper loaded: cookie_helper
INFO - 2021-01-12 02:15:04 --> Final output sent to browser
DEBUG - 2021-01-12 02:15:04 --> Total execution time: 0.2691
INFO - 2021-01-12 02:15:04 --> Config Class Initialized
INFO - 2021-01-12 02:15:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:04 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:04 --> URI Class Initialized
INFO - 2021-01-12 02:15:04 --> Router Class Initialized
INFO - 2021-01-12 02:15:04 --> Output Class Initialized
INFO - 2021-01-12 02:15:04 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:04 --> Input Class Initialized
INFO - 2021-01-12 02:15:04 --> Language Class Initialized
INFO - 2021-01-12 02:15:04 --> Language Class Initialized
INFO - 2021-01-12 02:15:04 --> Config Class Initialized
INFO - 2021-01-12 02:15:04 --> Loader Class Initialized
INFO - 2021-01-12 02:15:04 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:04 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:04 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:04 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:04 --> Controller Class Initialized
DEBUG - 2021-01-12 02:15:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 02:15:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 02:15:04 --> Final output sent to browser
DEBUG - 2021-01-12 02:15:04 --> Total execution time: 0.3600
INFO - 2021-01-12 02:15:09 --> Config Class Initialized
INFO - 2021-01-12 02:15:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:09 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:09 --> URI Class Initialized
INFO - 2021-01-12 02:15:09 --> Router Class Initialized
INFO - 2021-01-12 02:15:09 --> Output Class Initialized
INFO - 2021-01-12 02:15:09 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:09 --> Input Class Initialized
INFO - 2021-01-12 02:15:09 --> Language Class Initialized
INFO - 2021-01-12 02:15:09 --> Language Class Initialized
INFO - 2021-01-12 02:15:09 --> Config Class Initialized
INFO - 2021-01-12 02:15:09 --> Loader Class Initialized
INFO - 2021-01-12 02:15:09 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:09 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:09 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:09 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:09 --> Controller Class Initialized
DEBUG - 2021-01-12 02:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-12 02:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 02:15:09 --> Final output sent to browser
DEBUG - 2021-01-12 02:15:09 --> Total execution time: 0.2118
INFO - 2021-01-12 02:15:10 --> Config Class Initialized
INFO - 2021-01-12 02:15:10 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:10 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:10 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:10 --> URI Class Initialized
INFO - 2021-01-12 02:15:10 --> Router Class Initialized
INFO - 2021-01-12 02:15:10 --> Output Class Initialized
INFO - 2021-01-12 02:15:10 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:10 --> Input Class Initialized
INFO - 2021-01-12 02:15:10 --> Language Class Initialized
INFO - 2021-01-12 02:15:10 --> Language Class Initialized
INFO - 2021-01-12 02:15:10 --> Config Class Initialized
INFO - 2021-01-12 02:15:10 --> Loader Class Initialized
INFO - 2021-01-12 02:15:10 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:10 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:10 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:10 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:10 --> Controller Class Initialized
INFO - 2021-01-12 02:15:22 --> Config Class Initialized
INFO - 2021-01-12 02:15:22 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:22 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:22 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:22 --> URI Class Initialized
INFO - 2021-01-12 02:15:22 --> Router Class Initialized
INFO - 2021-01-12 02:15:22 --> Output Class Initialized
INFO - 2021-01-12 02:15:22 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:22 --> Input Class Initialized
INFO - 2021-01-12 02:15:22 --> Language Class Initialized
INFO - 2021-01-12 02:15:22 --> Language Class Initialized
INFO - 2021-01-12 02:15:22 --> Config Class Initialized
INFO - 2021-01-12 02:15:22 --> Loader Class Initialized
INFO - 2021-01-12 02:15:22 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:22 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:22 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:22 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:22 --> Controller Class Initialized
INFO - 2021-01-12 02:15:22 --> Final output sent to browser
DEBUG - 2021-01-12 02:15:22 --> Total execution time: 0.2121
INFO - 2021-01-12 02:15:36 --> Config Class Initialized
INFO - 2021-01-12 02:15:36 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:36 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:36 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:36 --> URI Class Initialized
INFO - 2021-01-12 02:15:36 --> Router Class Initialized
INFO - 2021-01-12 02:15:36 --> Output Class Initialized
INFO - 2021-01-12 02:15:36 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:36 --> Input Class Initialized
INFO - 2021-01-12 02:15:36 --> Language Class Initialized
INFO - 2021-01-12 02:15:36 --> Language Class Initialized
INFO - 2021-01-12 02:15:36 --> Config Class Initialized
INFO - 2021-01-12 02:15:36 --> Loader Class Initialized
INFO - 2021-01-12 02:15:36 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:36 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:36 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:36 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:36 --> Controller Class Initialized
INFO - 2021-01-12 02:15:36 --> Final output sent to browser
DEBUG - 2021-01-12 02:15:36 --> Total execution time: 0.2065
INFO - 2021-01-12 02:15:36 --> Config Class Initialized
INFO - 2021-01-12 02:15:36 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:36 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:36 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:36 --> URI Class Initialized
INFO - 2021-01-12 02:15:36 --> Router Class Initialized
INFO - 2021-01-12 02:15:36 --> Output Class Initialized
INFO - 2021-01-12 02:15:36 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:36 --> Input Class Initialized
INFO - 2021-01-12 02:15:36 --> Language Class Initialized
INFO - 2021-01-12 02:15:36 --> Language Class Initialized
INFO - 2021-01-12 02:15:36 --> Config Class Initialized
INFO - 2021-01-12 02:15:36 --> Loader Class Initialized
INFO - 2021-01-12 02:15:36 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:36 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:36 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:36 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:36 --> Controller Class Initialized
INFO - 2021-01-12 02:15:39 --> Config Class Initialized
INFO - 2021-01-12 02:15:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:40 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:40 --> URI Class Initialized
INFO - 2021-01-12 02:15:40 --> Router Class Initialized
INFO - 2021-01-12 02:15:40 --> Output Class Initialized
INFO - 2021-01-12 02:15:40 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:40 --> Input Class Initialized
INFO - 2021-01-12 02:15:40 --> Language Class Initialized
INFO - 2021-01-12 02:15:40 --> Language Class Initialized
INFO - 2021-01-12 02:15:40 --> Config Class Initialized
INFO - 2021-01-12 02:15:40 --> Loader Class Initialized
INFO - 2021-01-12 02:15:40 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:40 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:40 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:40 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:40 --> Controller Class Initialized
INFO - 2021-01-12 02:15:40 --> Final output sent to browser
DEBUG - 2021-01-12 02:15:40 --> Total execution time: 0.2069
INFO - 2021-01-12 02:15:56 --> Config Class Initialized
INFO - 2021-01-12 02:15:56 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:56 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:56 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:56 --> URI Class Initialized
INFO - 2021-01-12 02:15:56 --> Router Class Initialized
INFO - 2021-01-12 02:15:56 --> Output Class Initialized
INFO - 2021-01-12 02:15:56 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:56 --> Input Class Initialized
INFO - 2021-01-12 02:15:56 --> Language Class Initialized
INFO - 2021-01-12 02:15:56 --> Language Class Initialized
INFO - 2021-01-12 02:15:56 --> Config Class Initialized
INFO - 2021-01-12 02:15:56 --> Loader Class Initialized
INFO - 2021-01-12 02:15:56 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:56 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:56 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:56 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:56 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:56 --> Controller Class Initialized
INFO - 2021-01-12 02:15:56 --> Final output sent to browser
DEBUG - 2021-01-12 02:15:56 --> Total execution time: 0.2041
INFO - 2021-01-12 02:15:56 --> Config Class Initialized
INFO - 2021-01-12 02:15:56 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:15:56 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:15:56 --> Utf8 Class Initialized
INFO - 2021-01-12 02:15:56 --> URI Class Initialized
INFO - 2021-01-12 02:15:56 --> Router Class Initialized
INFO - 2021-01-12 02:15:56 --> Output Class Initialized
INFO - 2021-01-12 02:15:56 --> Security Class Initialized
DEBUG - 2021-01-12 02:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:15:56 --> Input Class Initialized
INFO - 2021-01-12 02:15:56 --> Language Class Initialized
INFO - 2021-01-12 02:15:56 --> Language Class Initialized
INFO - 2021-01-12 02:15:56 --> Config Class Initialized
INFO - 2021-01-12 02:15:56 --> Loader Class Initialized
INFO - 2021-01-12 02:15:56 --> Helper loaded: url_helper
INFO - 2021-01-12 02:15:56 --> Helper loaded: file_helper
INFO - 2021-01-12 02:15:56 --> Helper loaded: form_helper
INFO - 2021-01-12 02:15:56 --> Helper loaded: my_helper
INFO - 2021-01-12 02:15:56 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:15:56 --> Controller Class Initialized
INFO - 2021-01-12 02:16:03 --> Config Class Initialized
INFO - 2021-01-12 02:16:03 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:03 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:03 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:03 --> URI Class Initialized
INFO - 2021-01-12 02:16:03 --> Router Class Initialized
INFO - 2021-01-12 02:16:03 --> Output Class Initialized
INFO - 2021-01-12 02:16:03 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:03 --> Input Class Initialized
INFO - 2021-01-12 02:16:03 --> Language Class Initialized
INFO - 2021-01-12 02:16:03 --> Language Class Initialized
INFO - 2021-01-12 02:16:03 --> Config Class Initialized
INFO - 2021-01-12 02:16:03 --> Loader Class Initialized
INFO - 2021-01-12 02:16:03 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:03 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:03 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:03 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:03 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:03 --> Controller Class Initialized
DEBUG - 2021-01-12 02:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-01-12 02:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 02:16:03 --> Final output sent to browser
DEBUG - 2021-01-12 02:16:03 --> Total execution time: 0.2366
INFO - 2021-01-12 02:16:03 --> Config Class Initialized
INFO - 2021-01-12 02:16:03 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:03 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:03 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:03 --> URI Class Initialized
INFO - 2021-01-12 02:16:03 --> Router Class Initialized
INFO - 2021-01-12 02:16:04 --> Output Class Initialized
INFO - 2021-01-12 02:16:04 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:04 --> Input Class Initialized
INFO - 2021-01-12 02:16:04 --> Language Class Initialized
INFO - 2021-01-12 02:16:04 --> Language Class Initialized
INFO - 2021-01-12 02:16:04 --> Config Class Initialized
INFO - 2021-01-12 02:16:04 --> Loader Class Initialized
INFO - 2021-01-12 02:16:04 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:04 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:04 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:04 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:04 --> Controller Class Initialized
INFO - 2021-01-12 02:16:06 --> Config Class Initialized
INFO - 2021-01-12 02:16:06 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:06 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:06 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:06 --> URI Class Initialized
INFO - 2021-01-12 02:16:06 --> Router Class Initialized
INFO - 2021-01-12 02:16:06 --> Output Class Initialized
INFO - 2021-01-12 02:16:06 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:06 --> Input Class Initialized
INFO - 2021-01-12 02:16:06 --> Language Class Initialized
INFO - 2021-01-12 02:16:06 --> Language Class Initialized
INFO - 2021-01-12 02:16:06 --> Config Class Initialized
INFO - 2021-01-12 02:16:06 --> Loader Class Initialized
INFO - 2021-01-12 02:16:06 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:06 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:06 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:06 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:06 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:06 --> Controller Class Initialized
INFO - 2021-01-12 02:16:09 --> Config Class Initialized
INFO - 2021-01-12 02:16:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:09 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:09 --> URI Class Initialized
INFO - 2021-01-12 02:16:09 --> Router Class Initialized
INFO - 2021-01-12 02:16:09 --> Output Class Initialized
INFO - 2021-01-12 02:16:09 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:09 --> Input Class Initialized
INFO - 2021-01-12 02:16:09 --> Language Class Initialized
INFO - 2021-01-12 02:16:09 --> Language Class Initialized
INFO - 2021-01-12 02:16:09 --> Config Class Initialized
INFO - 2021-01-12 02:16:09 --> Loader Class Initialized
INFO - 2021-01-12 02:16:09 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:09 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:09 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:09 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:09 --> Controller Class Initialized
INFO - 2021-01-12 02:16:17 --> Config Class Initialized
INFO - 2021-01-12 02:16:17 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:17 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:17 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:17 --> URI Class Initialized
INFO - 2021-01-12 02:16:17 --> Router Class Initialized
INFO - 2021-01-12 02:16:17 --> Output Class Initialized
INFO - 2021-01-12 02:16:17 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:17 --> Input Class Initialized
INFO - 2021-01-12 02:16:17 --> Language Class Initialized
INFO - 2021-01-12 02:16:17 --> Language Class Initialized
INFO - 2021-01-12 02:16:17 --> Config Class Initialized
INFO - 2021-01-12 02:16:17 --> Loader Class Initialized
INFO - 2021-01-12 02:16:17 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:17 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:17 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:17 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:17 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:17 --> Controller Class Initialized
INFO - 2021-01-12 02:16:22 --> Config Class Initialized
INFO - 2021-01-12 02:16:22 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:22 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:22 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:22 --> URI Class Initialized
INFO - 2021-01-12 02:16:22 --> Router Class Initialized
INFO - 2021-01-12 02:16:22 --> Output Class Initialized
INFO - 2021-01-12 02:16:22 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:22 --> Input Class Initialized
INFO - 2021-01-12 02:16:22 --> Language Class Initialized
INFO - 2021-01-12 02:16:22 --> Language Class Initialized
INFO - 2021-01-12 02:16:22 --> Config Class Initialized
INFO - 2021-01-12 02:16:22 --> Loader Class Initialized
INFO - 2021-01-12 02:16:22 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:22 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:22 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:22 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:22 --> Controller Class Initialized
INFO - 2021-01-12 02:16:22 --> Helper loaded: cookie_helper
INFO - 2021-01-12 02:16:22 --> Config Class Initialized
INFO - 2021-01-12 02:16:22 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:22 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:22 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:22 --> URI Class Initialized
INFO - 2021-01-12 02:16:22 --> Router Class Initialized
INFO - 2021-01-12 02:16:22 --> Output Class Initialized
INFO - 2021-01-12 02:16:22 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:22 --> Input Class Initialized
INFO - 2021-01-12 02:16:22 --> Language Class Initialized
INFO - 2021-01-12 02:16:22 --> Language Class Initialized
INFO - 2021-01-12 02:16:22 --> Config Class Initialized
INFO - 2021-01-12 02:16:22 --> Loader Class Initialized
INFO - 2021-01-12 02:16:22 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:22 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:22 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:22 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:22 --> Controller Class Initialized
DEBUG - 2021-01-12 02:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 02:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 02:16:22 --> Final output sent to browser
DEBUG - 2021-01-12 02:16:22 --> Total execution time: 0.2383
INFO - 2021-01-12 02:16:32 --> Config Class Initialized
INFO - 2021-01-12 02:16:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:32 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:32 --> URI Class Initialized
INFO - 2021-01-12 02:16:32 --> Router Class Initialized
INFO - 2021-01-12 02:16:32 --> Output Class Initialized
INFO - 2021-01-12 02:16:32 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:32 --> Input Class Initialized
INFO - 2021-01-12 02:16:32 --> Language Class Initialized
INFO - 2021-01-12 02:16:32 --> Language Class Initialized
INFO - 2021-01-12 02:16:32 --> Config Class Initialized
INFO - 2021-01-12 02:16:32 --> Loader Class Initialized
INFO - 2021-01-12 02:16:32 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:32 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:32 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:32 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:32 --> Controller Class Initialized
INFO - 2021-01-12 02:16:32 --> Helper loaded: cookie_helper
INFO - 2021-01-12 02:16:32 --> Final output sent to browser
DEBUG - 2021-01-12 02:16:32 --> Total execution time: 0.3109
INFO - 2021-01-12 02:16:33 --> Config Class Initialized
INFO - 2021-01-12 02:16:33 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:33 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:33 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:33 --> URI Class Initialized
INFO - 2021-01-12 02:16:33 --> Router Class Initialized
INFO - 2021-01-12 02:16:33 --> Output Class Initialized
INFO - 2021-01-12 02:16:33 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:33 --> Input Class Initialized
INFO - 2021-01-12 02:16:33 --> Language Class Initialized
INFO - 2021-01-12 02:16:33 --> Language Class Initialized
INFO - 2021-01-12 02:16:33 --> Config Class Initialized
INFO - 2021-01-12 02:16:33 --> Loader Class Initialized
INFO - 2021-01-12 02:16:33 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:33 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:33 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:33 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:33 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:33 --> Controller Class Initialized
DEBUG - 2021-01-12 02:16:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 02:16:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 02:16:33 --> Final output sent to browser
DEBUG - 2021-01-12 02:16:33 --> Total execution time: 0.3591
INFO - 2021-01-12 02:16:35 --> Config Class Initialized
INFO - 2021-01-12 02:16:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:35 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:35 --> URI Class Initialized
INFO - 2021-01-12 02:16:35 --> Router Class Initialized
INFO - 2021-01-12 02:16:35 --> Output Class Initialized
INFO - 2021-01-12 02:16:35 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:35 --> Input Class Initialized
INFO - 2021-01-12 02:16:35 --> Language Class Initialized
INFO - 2021-01-12 02:16:35 --> Language Class Initialized
INFO - 2021-01-12 02:16:35 --> Config Class Initialized
INFO - 2021-01-12 02:16:35 --> Loader Class Initialized
INFO - 2021-01-12 02:16:35 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:35 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:35 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:35 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:35 --> Controller Class Initialized
DEBUG - 2021-01-12 02:16:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 02:16:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 02:16:35 --> Final output sent to browser
DEBUG - 2021-01-12 02:16:35 --> Total execution time: 0.2111
INFO - 2021-01-12 02:16:42 --> Config Class Initialized
INFO - 2021-01-12 02:16:42 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:16:42 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:16:42 --> Utf8 Class Initialized
INFO - 2021-01-12 02:16:42 --> URI Class Initialized
INFO - 2021-01-12 02:16:42 --> Router Class Initialized
INFO - 2021-01-12 02:16:42 --> Output Class Initialized
INFO - 2021-01-12 02:16:42 --> Security Class Initialized
DEBUG - 2021-01-12 02:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:16:42 --> Input Class Initialized
INFO - 2021-01-12 02:16:42 --> Language Class Initialized
INFO - 2021-01-12 02:16:42 --> Language Class Initialized
INFO - 2021-01-12 02:16:42 --> Config Class Initialized
INFO - 2021-01-12 02:16:42 --> Loader Class Initialized
INFO - 2021-01-12 02:16:42 --> Helper loaded: url_helper
INFO - 2021-01-12 02:16:42 --> Helper loaded: file_helper
INFO - 2021-01-12 02:16:42 --> Helper loaded: form_helper
INFO - 2021-01-12 02:16:42 --> Helper loaded: my_helper
INFO - 2021-01-12 02:16:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:16:42 --> Controller Class Initialized
DEBUG - 2021-01-12 02:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 02:16:42 --> Final output sent to browser
DEBUG - 2021-01-12 02:16:42 --> Total execution time: 0.2959
INFO - 2021-01-12 02:21:39 --> Config Class Initialized
INFO - 2021-01-12 02:21:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:21:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:21:39 --> Utf8 Class Initialized
INFO - 2021-01-12 02:21:39 --> URI Class Initialized
INFO - 2021-01-12 02:21:39 --> Router Class Initialized
INFO - 2021-01-12 02:21:39 --> Output Class Initialized
INFO - 2021-01-12 02:21:39 --> Security Class Initialized
DEBUG - 2021-01-12 02:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:21:39 --> Input Class Initialized
INFO - 2021-01-12 02:21:39 --> Language Class Initialized
INFO - 2021-01-12 02:21:39 --> Language Class Initialized
INFO - 2021-01-12 02:21:40 --> Config Class Initialized
INFO - 2021-01-12 02:21:40 --> Loader Class Initialized
INFO - 2021-01-12 02:21:40 --> Helper loaded: url_helper
INFO - 2021-01-12 02:21:40 --> Helper loaded: file_helper
INFO - 2021-01-12 02:21:40 --> Helper loaded: form_helper
INFO - 2021-01-12 02:21:40 --> Helper loaded: my_helper
INFO - 2021-01-12 02:21:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:21:40 --> Controller Class Initialized
DEBUG - 2021-01-12 02:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 02:21:40 --> Final output sent to browser
DEBUG - 2021-01-12 02:21:40 --> Total execution time: 0.2381
INFO - 2021-01-12 02:21:59 --> Config Class Initialized
INFO - 2021-01-12 02:21:59 --> Hooks Class Initialized
DEBUG - 2021-01-12 02:21:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 02:21:59 --> Utf8 Class Initialized
INFO - 2021-01-12 02:21:59 --> URI Class Initialized
INFO - 2021-01-12 02:21:59 --> Router Class Initialized
INFO - 2021-01-12 02:21:59 --> Output Class Initialized
INFO - 2021-01-12 02:21:59 --> Security Class Initialized
DEBUG - 2021-01-12 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 02:21:59 --> Input Class Initialized
INFO - 2021-01-12 02:21:59 --> Language Class Initialized
INFO - 2021-01-12 02:21:59 --> Language Class Initialized
INFO - 2021-01-12 02:21:59 --> Config Class Initialized
INFO - 2021-01-12 02:21:59 --> Loader Class Initialized
INFO - 2021-01-12 02:21:59 --> Helper loaded: url_helper
INFO - 2021-01-12 02:21:59 --> Helper loaded: file_helper
INFO - 2021-01-12 02:21:59 --> Helper loaded: form_helper
INFO - 2021-01-12 02:21:59 --> Helper loaded: my_helper
INFO - 2021-01-12 02:21:59 --> Database Driver Class Initialized
DEBUG - 2021-01-12 02:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 02:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 02:21:59 --> Controller Class Initialized
DEBUG - 2021-01-12 02:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 02:21:59 --> Final output sent to browser
DEBUG - 2021-01-12 02:21:59 --> Total execution time: 0.2674
INFO - 2021-01-12 03:10:20 --> Config Class Initialized
INFO - 2021-01-12 03:10:20 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:10:20 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:10:20 --> Utf8 Class Initialized
INFO - 2021-01-12 03:10:20 --> URI Class Initialized
INFO - 2021-01-12 03:10:20 --> Router Class Initialized
INFO - 2021-01-12 03:10:20 --> Output Class Initialized
INFO - 2021-01-12 03:10:20 --> Security Class Initialized
DEBUG - 2021-01-12 03:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:10:20 --> Input Class Initialized
INFO - 2021-01-12 03:10:20 --> Language Class Initialized
INFO - 2021-01-12 03:10:20 --> Language Class Initialized
INFO - 2021-01-12 03:10:20 --> Config Class Initialized
INFO - 2021-01-12 03:10:20 --> Loader Class Initialized
INFO - 2021-01-12 03:10:20 --> Helper loaded: url_helper
INFO - 2021-01-12 03:10:20 --> Helper loaded: file_helper
INFO - 2021-01-12 03:10:20 --> Helper loaded: form_helper
INFO - 2021-01-12 03:10:20 --> Helper loaded: my_helper
INFO - 2021-01-12 03:10:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:10:20 --> Controller Class Initialized
DEBUG - 2021-01-12 03:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 03:10:20 --> Final output sent to browser
DEBUG - 2021-01-12 03:10:21 --> Total execution time: 0.2867
INFO - 2021-01-12 03:10:30 --> Config Class Initialized
INFO - 2021-01-12 03:10:30 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:10:30 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:10:30 --> Utf8 Class Initialized
INFO - 2021-01-12 03:10:30 --> URI Class Initialized
INFO - 2021-01-12 03:10:31 --> Router Class Initialized
INFO - 2021-01-12 03:10:31 --> Output Class Initialized
INFO - 2021-01-12 03:10:31 --> Security Class Initialized
DEBUG - 2021-01-12 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:10:31 --> Input Class Initialized
INFO - 2021-01-12 03:10:31 --> Language Class Initialized
INFO - 2021-01-12 03:10:31 --> Language Class Initialized
INFO - 2021-01-12 03:10:31 --> Config Class Initialized
INFO - 2021-01-12 03:10:31 --> Loader Class Initialized
INFO - 2021-01-12 03:10:31 --> Helper loaded: url_helper
INFO - 2021-01-12 03:10:31 --> Helper loaded: file_helper
INFO - 2021-01-12 03:10:31 --> Helper loaded: form_helper
INFO - 2021-01-12 03:10:31 --> Helper loaded: my_helper
INFO - 2021-01-12 03:10:31 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:10:31 --> Controller Class Initialized
DEBUG - 2021-01-12 03:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 03:10:31 --> Final output sent to browser
DEBUG - 2021-01-12 03:10:31 --> Total execution time: 0.2844
INFO - 2021-01-12 03:13:46 --> Config Class Initialized
INFO - 2021-01-12 03:13:46 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:13:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:13:46 --> Utf8 Class Initialized
INFO - 2021-01-12 03:13:46 --> URI Class Initialized
INFO - 2021-01-12 03:13:46 --> Router Class Initialized
INFO - 2021-01-12 03:13:46 --> Output Class Initialized
INFO - 2021-01-12 03:13:46 --> Security Class Initialized
DEBUG - 2021-01-12 03:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:13:46 --> Input Class Initialized
INFO - 2021-01-12 03:13:46 --> Language Class Initialized
INFO - 2021-01-12 03:13:46 --> Language Class Initialized
INFO - 2021-01-12 03:13:46 --> Config Class Initialized
INFO - 2021-01-12 03:13:46 --> Loader Class Initialized
INFO - 2021-01-12 03:13:46 --> Helper loaded: url_helper
INFO - 2021-01-12 03:13:47 --> Helper loaded: file_helper
INFO - 2021-01-12 03:13:47 --> Helper loaded: form_helper
INFO - 2021-01-12 03:13:47 --> Helper loaded: my_helper
INFO - 2021-01-12 03:13:47 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:13:47 --> Controller Class Initialized
DEBUG - 2021-01-12 03:13:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 03:13:47 --> Final output sent to browser
DEBUG - 2021-01-12 03:13:47 --> Total execution time: 0.2438
INFO - 2021-01-12 03:13:59 --> Config Class Initialized
INFO - 2021-01-12 03:13:59 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:13:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:13:59 --> Utf8 Class Initialized
INFO - 2021-01-12 03:13:59 --> URI Class Initialized
INFO - 2021-01-12 03:13:59 --> Router Class Initialized
INFO - 2021-01-12 03:13:59 --> Output Class Initialized
INFO - 2021-01-12 03:13:59 --> Security Class Initialized
DEBUG - 2021-01-12 03:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:13:59 --> Input Class Initialized
INFO - 2021-01-12 03:13:59 --> Language Class Initialized
INFO - 2021-01-12 03:13:59 --> Language Class Initialized
INFO - 2021-01-12 03:13:59 --> Config Class Initialized
INFO - 2021-01-12 03:13:59 --> Loader Class Initialized
INFO - 2021-01-12 03:13:59 --> Helper loaded: url_helper
INFO - 2021-01-12 03:13:59 --> Helper loaded: file_helper
INFO - 2021-01-12 03:13:59 --> Helper loaded: form_helper
INFO - 2021-01-12 03:13:59 --> Helper loaded: my_helper
INFO - 2021-01-12 03:13:59 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:13:59 --> Controller Class Initialized
DEBUG - 2021-01-12 03:13:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 03:13:59 --> Final output sent to browser
DEBUG - 2021-01-12 03:13:59 --> Total execution time: 0.2734
INFO - 2021-01-12 03:14:08 --> Config Class Initialized
INFO - 2021-01-12 03:14:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:14:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:14:08 --> Utf8 Class Initialized
INFO - 2021-01-12 03:14:08 --> URI Class Initialized
INFO - 2021-01-12 03:14:08 --> Router Class Initialized
INFO - 2021-01-12 03:14:08 --> Output Class Initialized
INFO - 2021-01-12 03:14:08 --> Security Class Initialized
DEBUG - 2021-01-12 03:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:14:08 --> Input Class Initialized
INFO - 2021-01-12 03:14:08 --> Language Class Initialized
INFO - 2021-01-12 03:14:08 --> Language Class Initialized
INFO - 2021-01-12 03:14:08 --> Config Class Initialized
INFO - 2021-01-12 03:14:08 --> Loader Class Initialized
INFO - 2021-01-12 03:14:08 --> Helper loaded: url_helper
INFO - 2021-01-12 03:14:08 --> Helper loaded: file_helper
INFO - 2021-01-12 03:14:08 --> Helper loaded: form_helper
INFO - 2021-01-12 03:14:08 --> Helper loaded: my_helper
INFO - 2021-01-12 03:14:08 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:14:08 --> Controller Class Initialized
DEBUG - 2021-01-12 03:14:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 03:14:08 --> Final output sent to browser
DEBUG - 2021-01-12 03:14:08 --> Total execution time: 0.2543
INFO - 2021-01-12 03:15:40 --> Config Class Initialized
INFO - 2021-01-12 03:15:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:15:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:15:40 --> Utf8 Class Initialized
INFO - 2021-01-12 03:15:40 --> URI Class Initialized
INFO - 2021-01-12 03:15:40 --> Router Class Initialized
INFO - 2021-01-12 03:15:40 --> Output Class Initialized
INFO - 2021-01-12 03:15:40 --> Security Class Initialized
DEBUG - 2021-01-12 03:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:15:40 --> Input Class Initialized
INFO - 2021-01-12 03:15:40 --> Language Class Initialized
INFO - 2021-01-12 03:15:40 --> Language Class Initialized
INFO - 2021-01-12 03:15:40 --> Config Class Initialized
INFO - 2021-01-12 03:15:40 --> Loader Class Initialized
INFO - 2021-01-12 03:15:40 --> Helper loaded: url_helper
INFO - 2021-01-12 03:15:40 --> Helper loaded: file_helper
INFO - 2021-01-12 03:15:40 --> Helper loaded: form_helper
INFO - 2021-01-12 03:15:40 --> Helper loaded: my_helper
INFO - 2021-01-12 03:15:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:15:40 --> Controller Class Initialized
DEBUG - 2021-01-12 03:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-12 03:15:41 --> Final output sent to browser
DEBUG - 2021-01-12 03:15:41 --> Total execution time: 0.3343
INFO - 2021-01-12 03:15:59 --> Config Class Initialized
INFO - 2021-01-12 03:15:59 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:15:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:15:59 --> Utf8 Class Initialized
INFO - 2021-01-12 03:15:59 --> URI Class Initialized
INFO - 2021-01-12 03:15:59 --> Router Class Initialized
INFO - 2021-01-12 03:15:59 --> Output Class Initialized
INFO - 2021-01-12 03:15:59 --> Security Class Initialized
DEBUG - 2021-01-12 03:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:15:59 --> Input Class Initialized
INFO - 2021-01-12 03:15:59 --> Language Class Initialized
INFO - 2021-01-12 03:15:59 --> Language Class Initialized
INFO - 2021-01-12 03:15:59 --> Config Class Initialized
INFO - 2021-01-12 03:15:59 --> Loader Class Initialized
INFO - 2021-01-12 03:15:59 --> Helper loaded: url_helper
INFO - 2021-01-12 03:15:59 --> Helper loaded: file_helper
INFO - 2021-01-12 03:15:59 --> Helper loaded: form_helper
INFO - 2021-01-12 03:15:59 --> Helper loaded: my_helper
INFO - 2021-01-12 03:15:59 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:15:59 --> Controller Class Initialized
DEBUG - 2021-01-12 03:15:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-12 03:15:59 --> Final output sent to browser
DEBUG - 2021-01-12 03:15:59 --> Total execution time: 0.3406
INFO - 2021-01-12 03:16:05 --> Config Class Initialized
INFO - 2021-01-12 03:16:05 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:16:05 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:16:05 --> Utf8 Class Initialized
INFO - 2021-01-12 03:16:05 --> URI Class Initialized
INFO - 2021-01-12 03:16:05 --> Router Class Initialized
INFO - 2021-01-12 03:16:05 --> Output Class Initialized
INFO - 2021-01-12 03:16:05 --> Security Class Initialized
DEBUG - 2021-01-12 03:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:16:05 --> Input Class Initialized
INFO - 2021-01-12 03:16:05 --> Language Class Initialized
INFO - 2021-01-12 03:16:05 --> Language Class Initialized
INFO - 2021-01-12 03:16:05 --> Config Class Initialized
INFO - 2021-01-12 03:16:05 --> Loader Class Initialized
INFO - 2021-01-12 03:16:05 --> Helper loaded: url_helper
INFO - 2021-01-12 03:16:05 --> Helper loaded: file_helper
INFO - 2021-01-12 03:16:05 --> Helper loaded: form_helper
INFO - 2021-01-12 03:16:05 --> Helper loaded: my_helper
INFO - 2021-01-12 03:16:05 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:16:05 --> Controller Class Initialized
DEBUG - 2021-01-12 03:16:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-12 03:16:05 --> Final output sent to browser
DEBUG - 2021-01-12 03:16:05 --> Total execution time: 0.3426
INFO - 2021-01-12 03:16:34 --> Config Class Initialized
INFO - 2021-01-12 03:16:34 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:16:34 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:16:34 --> Utf8 Class Initialized
INFO - 2021-01-12 03:16:34 --> URI Class Initialized
INFO - 2021-01-12 03:16:34 --> Router Class Initialized
INFO - 2021-01-12 03:16:34 --> Output Class Initialized
INFO - 2021-01-12 03:16:34 --> Security Class Initialized
DEBUG - 2021-01-12 03:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:16:34 --> Input Class Initialized
INFO - 2021-01-12 03:16:34 --> Language Class Initialized
INFO - 2021-01-12 03:16:34 --> Language Class Initialized
INFO - 2021-01-12 03:16:34 --> Config Class Initialized
INFO - 2021-01-12 03:16:34 --> Loader Class Initialized
INFO - 2021-01-12 03:16:34 --> Helper loaded: url_helper
INFO - 2021-01-12 03:16:34 --> Helper loaded: file_helper
INFO - 2021-01-12 03:16:34 --> Helper loaded: form_helper
INFO - 2021-01-12 03:16:34 --> Helper loaded: my_helper
INFO - 2021-01-12 03:16:34 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:16:34 --> Controller Class Initialized
DEBUG - 2021-01-12 03:16:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:16:34 --> Final output sent to browser
DEBUG - 2021-01-12 03:16:34 --> Total execution time: 0.2914
INFO - 2021-01-12 03:16:38 --> Config Class Initialized
INFO - 2021-01-12 03:16:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:16:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:16:38 --> Utf8 Class Initialized
INFO - 2021-01-12 03:16:38 --> URI Class Initialized
INFO - 2021-01-12 03:16:38 --> Router Class Initialized
INFO - 2021-01-12 03:16:38 --> Output Class Initialized
INFO - 2021-01-12 03:16:38 --> Security Class Initialized
DEBUG - 2021-01-12 03:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:16:38 --> Input Class Initialized
INFO - 2021-01-12 03:16:38 --> Language Class Initialized
INFO - 2021-01-12 03:16:38 --> Language Class Initialized
INFO - 2021-01-12 03:16:38 --> Config Class Initialized
INFO - 2021-01-12 03:16:38 --> Loader Class Initialized
INFO - 2021-01-12 03:16:38 --> Helper loaded: url_helper
INFO - 2021-01-12 03:16:38 --> Helper loaded: file_helper
INFO - 2021-01-12 03:16:38 --> Helper loaded: form_helper
INFO - 2021-01-12 03:16:38 --> Helper loaded: my_helper
INFO - 2021-01-12 03:16:38 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:16:38 --> Controller Class Initialized
DEBUG - 2021-01-12 03:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-12 03:16:38 --> Final output sent to browser
DEBUG - 2021-01-12 03:16:38 --> Total execution time: 0.3941
INFO - 2021-01-12 03:17:17 --> Config Class Initialized
INFO - 2021-01-12 03:17:17 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:17:17 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:17:17 --> Utf8 Class Initialized
INFO - 2021-01-12 03:17:17 --> URI Class Initialized
INFO - 2021-01-12 03:17:17 --> Router Class Initialized
INFO - 2021-01-12 03:17:17 --> Output Class Initialized
INFO - 2021-01-12 03:17:17 --> Security Class Initialized
DEBUG - 2021-01-12 03:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:17:17 --> Input Class Initialized
INFO - 2021-01-12 03:17:17 --> Language Class Initialized
INFO - 2021-01-12 03:17:17 --> Language Class Initialized
INFO - 2021-01-12 03:17:17 --> Config Class Initialized
INFO - 2021-01-12 03:17:17 --> Loader Class Initialized
INFO - 2021-01-12 03:17:17 --> Helper loaded: url_helper
INFO - 2021-01-12 03:17:17 --> Helper loaded: file_helper
INFO - 2021-01-12 03:17:17 --> Helper loaded: form_helper
INFO - 2021-01-12 03:17:17 --> Helper loaded: my_helper
INFO - 2021-01-12 03:17:17 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:17:17 --> Controller Class Initialized
DEBUG - 2021-01-12 03:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-12 03:17:17 --> Final output sent to browser
DEBUG - 2021-01-12 03:17:17 --> Total execution time: 0.3586
INFO - 2021-01-12 03:17:30 --> Config Class Initialized
INFO - 2021-01-12 03:17:30 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:17:30 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:17:30 --> Utf8 Class Initialized
INFO - 2021-01-12 03:17:30 --> URI Class Initialized
INFO - 2021-01-12 03:17:30 --> Router Class Initialized
INFO - 2021-01-12 03:17:30 --> Output Class Initialized
INFO - 2021-01-12 03:17:30 --> Security Class Initialized
DEBUG - 2021-01-12 03:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:17:30 --> Input Class Initialized
INFO - 2021-01-12 03:17:30 --> Language Class Initialized
INFO - 2021-01-12 03:17:30 --> Language Class Initialized
INFO - 2021-01-12 03:17:30 --> Config Class Initialized
INFO - 2021-01-12 03:17:30 --> Loader Class Initialized
INFO - 2021-01-12 03:17:30 --> Helper loaded: url_helper
INFO - 2021-01-12 03:17:30 --> Helper loaded: file_helper
INFO - 2021-01-12 03:17:30 --> Helper loaded: form_helper
INFO - 2021-01-12 03:17:30 --> Helper loaded: my_helper
INFO - 2021-01-12 03:17:30 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:17:31 --> Controller Class Initialized
DEBUG - 2021-01-12 03:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-12 03:17:31 --> Final output sent to browser
DEBUG - 2021-01-12 03:17:31 --> Total execution time: 0.3419
INFO - 2021-01-12 03:17:42 --> Config Class Initialized
INFO - 2021-01-12 03:17:42 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:17:42 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:17:42 --> Utf8 Class Initialized
INFO - 2021-01-12 03:17:42 --> URI Class Initialized
INFO - 2021-01-12 03:17:42 --> Router Class Initialized
INFO - 2021-01-12 03:17:42 --> Output Class Initialized
INFO - 2021-01-12 03:17:42 --> Security Class Initialized
DEBUG - 2021-01-12 03:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:17:42 --> Input Class Initialized
INFO - 2021-01-12 03:17:42 --> Language Class Initialized
INFO - 2021-01-12 03:17:42 --> Language Class Initialized
INFO - 2021-01-12 03:17:42 --> Config Class Initialized
INFO - 2021-01-12 03:17:42 --> Loader Class Initialized
INFO - 2021-01-12 03:17:42 --> Helper loaded: url_helper
INFO - 2021-01-12 03:17:42 --> Helper loaded: file_helper
INFO - 2021-01-12 03:17:42 --> Helper loaded: form_helper
INFO - 2021-01-12 03:17:42 --> Helper loaded: my_helper
INFO - 2021-01-12 03:17:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:17:42 --> Controller Class Initialized
DEBUG - 2021-01-12 03:17:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 03:17:42 --> Final output sent to browser
DEBUG - 2021-01-12 03:17:42 --> Total execution time: 0.3995
INFO - 2021-01-12 03:18:08 --> Config Class Initialized
INFO - 2021-01-12 03:18:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:18:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:18:08 --> Utf8 Class Initialized
INFO - 2021-01-12 03:18:08 --> URI Class Initialized
INFO - 2021-01-12 03:18:08 --> Router Class Initialized
INFO - 2021-01-12 03:18:08 --> Output Class Initialized
INFO - 2021-01-12 03:18:08 --> Security Class Initialized
DEBUG - 2021-01-12 03:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:18:08 --> Input Class Initialized
INFO - 2021-01-12 03:18:08 --> Language Class Initialized
INFO - 2021-01-12 03:18:08 --> Language Class Initialized
INFO - 2021-01-12 03:18:08 --> Config Class Initialized
INFO - 2021-01-12 03:18:08 --> Loader Class Initialized
INFO - 2021-01-12 03:18:08 --> Helper loaded: url_helper
INFO - 2021-01-12 03:18:08 --> Helper loaded: file_helper
INFO - 2021-01-12 03:18:08 --> Helper loaded: form_helper
INFO - 2021-01-12 03:18:08 --> Helper loaded: my_helper
INFO - 2021-01-12 03:18:08 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:18:08 --> Controller Class Initialized
DEBUG - 2021-01-12 03:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 03:18:08 --> Final output sent to browser
DEBUG - 2021-01-12 03:18:08 --> Total execution time: 0.3420
INFO - 2021-01-12 03:32:37 --> Config Class Initialized
INFO - 2021-01-12 03:32:37 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:32:37 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:32:37 --> Utf8 Class Initialized
INFO - 2021-01-12 03:32:37 --> URI Class Initialized
DEBUG - 2021-01-12 03:32:37 --> No URI present. Default controller set.
INFO - 2021-01-12 03:32:37 --> Router Class Initialized
INFO - 2021-01-12 03:32:37 --> Output Class Initialized
INFO - 2021-01-12 03:32:37 --> Security Class Initialized
DEBUG - 2021-01-12 03:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:32:37 --> Input Class Initialized
INFO - 2021-01-12 03:32:37 --> Language Class Initialized
INFO - 2021-01-12 03:32:37 --> Language Class Initialized
INFO - 2021-01-12 03:32:37 --> Config Class Initialized
INFO - 2021-01-12 03:32:37 --> Loader Class Initialized
INFO - 2021-01-12 03:32:37 --> Helper loaded: url_helper
INFO - 2021-01-12 03:32:37 --> Helper loaded: file_helper
INFO - 2021-01-12 03:32:37 --> Helper loaded: form_helper
INFO - 2021-01-12 03:32:37 --> Helper loaded: my_helper
INFO - 2021-01-12 03:32:37 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:32:37 --> Controller Class Initialized
DEBUG - 2021-01-12 03:32:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 03:32:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 03:32:37 --> Final output sent to browser
DEBUG - 2021-01-12 03:32:37 --> Total execution time: 0.3280
INFO - 2021-01-12 03:32:39 --> Config Class Initialized
INFO - 2021-01-12 03:32:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:32:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:32:39 --> Utf8 Class Initialized
INFO - 2021-01-12 03:32:39 --> URI Class Initialized
INFO - 2021-01-12 03:32:39 --> Router Class Initialized
INFO - 2021-01-12 03:32:39 --> Output Class Initialized
INFO - 2021-01-12 03:32:39 --> Security Class Initialized
DEBUG - 2021-01-12 03:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:32:39 --> Input Class Initialized
INFO - 2021-01-12 03:32:39 --> Language Class Initialized
INFO - 2021-01-12 03:32:39 --> Language Class Initialized
INFO - 2021-01-12 03:32:39 --> Config Class Initialized
INFO - 2021-01-12 03:32:39 --> Loader Class Initialized
INFO - 2021-01-12 03:32:39 --> Helper loaded: url_helper
INFO - 2021-01-12 03:32:39 --> Helper loaded: file_helper
INFO - 2021-01-12 03:32:39 --> Helper loaded: form_helper
INFO - 2021-01-12 03:32:39 --> Helper loaded: my_helper
INFO - 2021-01-12 03:32:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:32:39 --> Controller Class Initialized
DEBUG - 2021-01-12 03:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 03:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 03:32:39 --> Final output sent to browser
DEBUG - 2021-01-12 03:32:40 --> Total execution time: 0.2497
INFO - 2021-01-12 03:32:49 --> Config Class Initialized
INFO - 2021-01-12 03:32:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:32:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:32:49 --> Utf8 Class Initialized
INFO - 2021-01-12 03:32:49 --> URI Class Initialized
INFO - 2021-01-12 03:32:49 --> Router Class Initialized
INFO - 2021-01-12 03:32:49 --> Output Class Initialized
INFO - 2021-01-12 03:32:49 --> Security Class Initialized
DEBUG - 2021-01-12 03:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:32:49 --> Input Class Initialized
INFO - 2021-01-12 03:32:49 --> Language Class Initialized
INFO - 2021-01-12 03:32:49 --> Language Class Initialized
INFO - 2021-01-12 03:32:49 --> Config Class Initialized
INFO - 2021-01-12 03:32:49 --> Loader Class Initialized
INFO - 2021-01-12 03:32:49 --> Helper loaded: url_helper
INFO - 2021-01-12 03:32:49 --> Helper loaded: file_helper
INFO - 2021-01-12 03:32:49 --> Helper loaded: form_helper
INFO - 2021-01-12 03:32:49 --> Helper loaded: my_helper
INFO - 2021-01-12 03:32:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:32:49 --> Controller Class Initialized
DEBUG - 2021-01-12 03:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:32:49 --> Final output sent to browser
DEBUG - 2021-01-12 03:32:49 --> Total execution time: 0.2791
INFO - 2021-01-12 03:33:12 --> Config Class Initialized
INFO - 2021-01-12 03:33:12 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:12 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:12 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:12 --> URI Class Initialized
INFO - 2021-01-12 03:33:12 --> Router Class Initialized
INFO - 2021-01-12 03:33:12 --> Output Class Initialized
INFO - 2021-01-12 03:33:12 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:12 --> Input Class Initialized
INFO - 2021-01-12 03:33:12 --> Language Class Initialized
INFO - 2021-01-12 03:33:12 --> Language Class Initialized
INFO - 2021-01-12 03:33:12 --> Config Class Initialized
INFO - 2021-01-12 03:33:12 --> Loader Class Initialized
INFO - 2021-01-12 03:33:12 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:12 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:12 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:12 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:12 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:12 --> Controller Class Initialized
INFO - 2021-01-12 03:33:13 --> Helper loaded: cookie_helper
INFO - 2021-01-12 03:33:13 --> Config Class Initialized
INFO - 2021-01-12 03:33:13 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:13 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:13 --> URI Class Initialized
INFO - 2021-01-12 03:33:13 --> Router Class Initialized
INFO - 2021-01-12 03:33:13 --> Output Class Initialized
INFO - 2021-01-12 03:33:13 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:13 --> Input Class Initialized
INFO - 2021-01-12 03:33:13 --> Language Class Initialized
INFO - 2021-01-12 03:33:13 --> Language Class Initialized
INFO - 2021-01-12 03:33:13 --> Config Class Initialized
INFO - 2021-01-12 03:33:13 --> Loader Class Initialized
INFO - 2021-01-12 03:33:13 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:13 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:13 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:13 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:13 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:13 --> Controller Class Initialized
DEBUG - 2021-01-12 03:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 03:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 03:33:13 --> Final output sent to browser
DEBUG - 2021-01-12 03:33:13 --> Total execution time: 0.3110
INFO - 2021-01-12 03:33:18 --> Config Class Initialized
INFO - 2021-01-12 03:33:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:18 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:18 --> URI Class Initialized
INFO - 2021-01-12 03:33:18 --> Router Class Initialized
INFO - 2021-01-12 03:33:18 --> Output Class Initialized
INFO - 2021-01-12 03:33:18 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:18 --> Input Class Initialized
INFO - 2021-01-12 03:33:18 --> Language Class Initialized
INFO - 2021-01-12 03:33:18 --> Language Class Initialized
INFO - 2021-01-12 03:33:18 --> Config Class Initialized
INFO - 2021-01-12 03:33:18 --> Loader Class Initialized
INFO - 2021-01-12 03:33:18 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:18 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:18 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:18 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:18 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:18 --> Controller Class Initialized
INFO - 2021-01-12 03:33:18 --> Helper loaded: cookie_helper
INFO - 2021-01-12 03:33:18 --> Final output sent to browser
DEBUG - 2021-01-12 03:33:18 --> Total execution time: 0.3558
INFO - 2021-01-12 03:33:19 --> Config Class Initialized
INFO - 2021-01-12 03:33:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:19 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:19 --> URI Class Initialized
INFO - 2021-01-12 03:33:19 --> Router Class Initialized
INFO - 2021-01-12 03:33:19 --> Output Class Initialized
INFO - 2021-01-12 03:33:19 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:19 --> Input Class Initialized
INFO - 2021-01-12 03:33:19 --> Language Class Initialized
INFO - 2021-01-12 03:33:19 --> Language Class Initialized
INFO - 2021-01-12 03:33:19 --> Config Class Initialized
INFO - 2021-01-12 03:33:19 --> Loader Class Initialized
INFO - 2021-01-12 03:33:19 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:19 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:19 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:19 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:19 --> Controller Class Initialized
DEBUG - 2021-01-12 03:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 03:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 03:33:19 --> Final output sent to browser
DEBUG - 2021-01-12 03:33:19 --> Total execution time: 0.4314
INFO - 2021-01-12 03:33:22 --> Config Class Initialized
INFO - 2021-01-12 03:33:22 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:22 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:22 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:22 --> URI Class Initialized
INFO - 2021-01-12 03:33:22 --> Router Class Initialized
INFO - 2021-01-12 03:33:22 --> Output Class Initialized
INFO - 2021-01-12 03:33:22 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:22 --> Input Class Initialized
INFO - 2021-01-12 03:33:22 --> Language Class Initialized
INFO - 2021-01-12 03:33:22 --> Language Class Initialized
INFO - 2021-01-12 03:33:22 --> Config Class Initialized
INFO - 2021-01-12 03:33:22 --> Loader Class Initialized
INFO - 2021-01-12 03:33:22 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:22 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:22 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:22 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:22 --> Controller Class Initialized
DEBUG - 2021-01-12 03:33:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-12 03:33:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 03:33:22 --> Final output sent to browser
DEBUG - 2021-01-12 03:33:22 --> Total execution time: 0.2680
INFO - 2021-01-12 03:33:22 --> Config Class Initialized
INFO - 2021-01-12 03:33:22 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:22 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:22 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:22 --> URI Class Initialized
INFO - 2021-01-12 03:33:22 --> Router Class Initialized
INFO - 2021-01-12 03:33:22 --> Output Class Initialized
INFO - 2021-01-12 03:33:22 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:22 --> Input Class Initialized
INFO - 2021-01-12 03:33:22 --> Language Class Initialized
INFO - 2021-01-12 03:33:22 --> Language Class Initialized
INFO - 2021-01-12 03:33:22 --> Config Class Initialized
INFO - 2021-01-12 03:33:22 --> Loader Class Initialized
INFO - 2021-01-12 03:33:22 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:22 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:22 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:22 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:22 --> Controller Class Initialized
INFO - 2021-01-12 03:33:28 --> Config Class Initialized
INFO - 2021-01-12 03:33:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:28 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:28 --> URI Class Initialized
INFO - 2021-01-12 03:33:28 --> Router Class Initialized
INFO - 2021-01-12 03:33:28 --> Output Class Initialized
INFO - 2021-01-12 03:33:28 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:28 --> Input Class Initialized
INFO - 2021-01-12 03:33:28 --> Language Class Initialized
INFO - 2021-01-12 03:33:28 --> Language Class Initialized
INFO - 2021-01-12 03:33:28 --> Config Class Initialized
INFO - 2021-01-12 03:33:28 --> Loader Class Initialized
INFO - 2021-01-12 03:33:28 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:28 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:28 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:28 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:28 --> Controller Class Initialized
INFO - 2021-01-12 03:33:28 --> Final output sent to browser
DEBUG - 2021-01-12 03:33:28 --> Total execution time: 0.2449
INFO - 2021-01-12 03:33:48 --> Config Class Initialized
INFO - 2021-01-12 03:33:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:48 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:48 --> URI Class Initialized
INFO - 2021-01-12 03:33:48 --> Router Class Initialized
INFO - 2021-01-12 03:33:48 --> Output Class Initialized
INFO - 2021-01-12 03:33:48 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:48 --> Input Class Initialized
INFO - 2021-01-12 03:33:48 --> Language Class Initialized
INFO - 2021-01-12 03:33:48 --> Language Class Initialized
INFO - 2021-01-12 03:33:48 --> Config Class Initialized
INFO - 2021-01-12 03:33:48 --> Loader Class Initialized
INFO - 2021-01-12 03:33:48 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:48 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:48 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:48 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:48 --> Controller Class Initialized
INFO - 2021-01-12 03:33:48 --> Final output sent to browser
DEBUG - 2021-01-12 03:33:48 --> Total execution time: 0.2436
INFO - 2021-01-12 03:33:48 --> Config Class Initialized
INFO - 2021-01-12 03:33:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:48 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:48 --> URI Class Initialized
INFO - 2021-01-12 03:33:48 --> Router Class Initialized
INFO - 2021-01-12 03:33:48 --> Output Class Initialized
INFO - 2021-01-12 03:33:48 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:48 --> Input Class Initialized
INFO - 2021-01-12 03:33:48 --> Language Class Initialized
INFO - 2021-01-12 03:33:48 --> Language Class Initialized
INFO - 2021-01-12 03:33:48 --> Config Class Initialized
INFO - 2021-01-12 03:33:48 --> Loader Class Initialized
INFO - 2021-01-12 03:33:48 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:48 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:48 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:48 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:48 --> Controller Class Initialized
INFO - 2021-01-12 03:33:52 --> Config Class Initialized
INFO - 2021-01-12 03:33:52 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:33:52 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:33:52 --> Utf8 Class Initialized
INFO - 2021-01-12 03:33:52 --> URI Class Initialized
INFO - 2021-01-12 03:33:52 --> Router Class Initialized
INFO - 2021-01-12 03:33:52 --> Output Class Initialized
INFO - 2021-01-12 03:33:52 --> Security Class Initialized
DEBUG - 2021-01-12 03:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:33:52 --> Input Class Initialized
INFO - 2021-01-12 03:33:52 --> Language Class Initialized
INFO - 2021-01-12 03:33:52 --> Language Class Initialized
INFO - 2021-01-12 03:33:52 --> Config Class Initialized
INFO - 2021-01-12 03:33:52 --> Loader Class Initialized
INFO - 2021-01-12 03:33:52 --> Helper loaded: url_helper
INFO - 2021-01-12 03:33:52 --> Helper loaded: file_helper
INFO - 2021-01-12 03:33:52 --> Helper loaded: form_helper
INFO - 2021-01-12 03:33:52 --> Helper loaded: my_helper
INFO - 2021-01-12 03:33:52 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:33:52 --> Controller Class Initialized
INFO - 2021-01-12 03:33:52 --> Final output sent to browser
DEBUG - 2021-01-12 03:33:52 --> Total execution time: 0.2435
INFO - 2021-01-12 03:34:15 --> Config Class Initialized
INFO - 2021-01-12 03:34:15 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:34:16 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:34:16 --> Utf8 Class Initialized
INFO - 2021-01-12 03:34:16 --> URI Class Initialized
INFO - 2021-01-12 03:34:16 --> Router Class Initialized
INFO - 2021-01-12 03:34:16 --> Output Class Initialized
INFO - 2021-01-12 03:34:16 --> Security Class Initialized
DEBUG - 2021-01-12 03:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:34:16 --> Input Class Initialized
INFO - 2021-01-12 03:34:16 --> Language Class Initialized
INFO - 2021-01-12 03:34:16 --> Language Class Initialized
INFO - 2021-01-12 03:34:16 --> Config Class Initialized
INFO - 2021-01-12 03:34:16 --> Loader Class Initialized
INFO - 2021-01-12 03:34:16 --> Helper loaded: url_helper
INFO - 2021-01-12 03:34:16 --> Helper loaded: file_helper
INFO - 2021-01-12 03:34:16 --> Helper loaded: form_helper
INFO - 2021-01-12 03:34:16 --> Helper loaded: my_helper
INFO - 2021-01-12 03:34:16 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:34:16 --> Controller Class Initialized
INFO - 2021-01-12 03:34:16 --> Final output sent to browser
DEBUG - 2021-01-12 03:34:16 --> Total execution time: 0.2984
INFO - 2021-01-12 03:34:16 --> Config Class Initialized
INFO - 2021-01-12 03:34:16 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:34:16 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:34:16 --> Utf8 Class Initialized
INFO - 2021-01-12 03:34:16 --> URI Class Initialized
INFO - 2021-01-12 03:34:16 --> Router Class Initialized
INFO - 2021-01-12 03:34:16 --> Output Class Initialized
INFO - 2021-01-12 03:34:16 --> Security Class Initialized
DEBUG - 2021-01-12 03:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:34:16 --> Input Class Initialized
INFO - 2021-01-12 03:34:16 --> Language Class Initialized
INFO - 2021-01-12 03:34:16 --> Language Class Initialized
INFO - 2021-01-12 03:34:16 --> Config Class Initialized
INFO - 2021-01-12 03:34:16 --> Loader Class Initialized
INFO - 2021-01-12 03:34:16 --> Helper loaded: url_helper
INFO - 2021-01-12 03:34:16 --> Helper loaded: file_helper
INFO - 2021-01-12 03:34:16 --> Helper loaded: form_helper
INFO - 2021-01-12 03:34:16 --> Helper loaded: my_helper
INFO - 2021-01-12 03:34:16 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:34:16 --> Controller Class Initialized
INFO - 2021-01-12 03:34:17 --> Config Class Initialized
INFO - 2021-01-12 03:34:17 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:34:17 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:34:17 --> Utf8 Class Initialized
INFO - 2021-01-12 03:34:17 --> URI Class Initialized
INFO - 2021-01-12 03:34:17 --> Router Class Initialized
INFO - 2021-01-12 03:34:17 --> Output Class Initialized
INFO - 2021-01-12 03:34:17 --> Security Class Initialized
DEBUG - 2021-01-12 03:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:34:17 --> Input Class Initialized
INFO - 2021-01-12 03:34:17 --> Language Class Initialized
INFO - 2021-01-12 03:34:17 --> Language Class Initialized
INFO - 2021-01-12 03:34:17 --> Config Class Initialized
INFO - 2021-01-12 03:34:17 --> Loader Class Initialized
INFO - 2021-01-12 03:34:17 --> Helper loaded: url_helper
INFO - 2021-01-12 03:34:17 --> Helper loaded: file_helper
INFO - 2021-01-12 03:34:17 --> Helper loaded: form_helper
INFO - 2021-01-12 03:34:17 --> Helper loaded: my_helper
INFO - 2021-01-12 03:34:17 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:34:18 --> Controller Class Initialized
INFO - 2021-01-12 03:34:18 --> Final output sent to browser
DEBUG - 2021-01-12 03:34:18 --> Total execution time: 0.2482
INFO - 2021-01-12 03:34:27 --> Config Class Initialized
INFO - 2021-01-12 03:34:27 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:34:27 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:34:27 --> Utf8 Class Initialized
INFO - 2021-01-12 03:34:27 --> URI Class Initialized
INFO - 2021-01-12 03:34:27 --> Router Class Initialized
INFO - 2021-01-12 03:34:27 --> Output Class Initialized
INFO - 2021-01-12 03:34:27 --> Security Class Initialized
DEBUG - 2021-01-12 03:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:34:27 --> Input Class Initialized
INFO - 2021-01-12 03:34:27 --> Language Class Initialized
INFO - 2021-01-12 03:34:27 --> Language Class Initialized
INFO - 2021-01-12 03:34:27 --> Config Class Initialized
INFO - 2021-01-12 03:34:27 --> Loader Class Initialized
INFO - 2021-01-12 03:34:27 --> Helper loaded: url_helper
INFO - 2021-01-12 03:34:27 --> Helper loaded: file_helper
INFO - 2021-01-12 03:34:27 --> Helper loaded: form_helper
INFO - 2021-01-12 03:34:27 --> Helper loaded: my_helper
INFO - 2021-01-12 03:34:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:34:27 --> Controller Class Initialized
INFO - 2021-01-12 03:34:27 --> Final output sent to browser
DEBUG - 2021-01-12 03:34:27 --> Total execution time: 0.2464
INFO - 2021-01-12 03:34:28 --> Config Class Initialized
INFO - 2021-01-12 03:34:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:34:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:34:28 --> Utf8 Class Initialized
INFO - 2021-01-12 03:34:28 --> URI Class Initialized
INFO - 2021-01-12 03:34:28 --> Router Class Initialized
INFO - 2021-01-12 03:34:28 --> Output Class Initialized
INFO - 2021-01-12 03:34:28 --> Security Class Initialized
DEBUG - 2021-01-12 03:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:34:28 --> Input Class Initialized
INFO - 2021-01-12 03:34:28 --> Language Class Initialized
INFO - 2021-01-12 03:34:28 --> Language Class Initialized
INFO - 2021-01-12 03:34:28 --> Config Class Initialized
INFO - 2021-01-12 03:34:28 --> Loader Class Initialized
INFO - 2021-01-12 03:34:28 --> Helper loaded: url_helper
INFO - 2021-01-12 03:34:28 --> Helper loaded: file_helper
INFO - 2021-01-12 03:34:28 --> Helper loaded: form_helper
INFO - 2021-01-12 03:34:28 --> Helper loaded: my_helper
INFO - 2021-01-12 03:34:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:34:28 --> Controller Class Initialized
INFO - 2021-01-12 03:34:40 --> Config Class Initialized
INFO - 2021-01-12 03:34:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:34:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:34:40 --> Utf8 Class Initialized
INFO - 2021-01-12 03:34:40 --> URI Class Initialized
INFO - 2021-01-12 03:34:40 --> Router Class Initialized
INFO - 2021-01-12 03:34:40 --> Output Class Initialized
INFO - 2021-01-12 03:34:40 --> Security Class Initialized
DEBUG - 2021-01-12 03:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:34:40 --> Input Class Initialized
INFO - 2021-01-12 03:34:40 --> Language Class Initialized
INFO - 2021-01-12 03:34:40 --> Language Class Initialized
INFO - 2021-01-12 03:34:40 --> Config Class Initialized
INFO - 2021-01-12 03:34:40 --> Loader Class Initialized
INFO - 2021-01-12 03:34:40 --> Helper loaded: url_helper
INFO - 2021-01-12 03:34:40 --> Helper loaded: file_helper
INFO - 2021-01-12 03:34:40 --> Helper loaded: form_helper
INFO - 2021-01-12 03:34:40 --> Helper loaded: my_helper
INFO - 2021-01-12 03:34:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:34:40 --> Controller Class Initialized
INFO - 2021-01-12 03:34:40 --> Final output sent to browser
DEBUG - 2021-01-12 03:34:40 --> Total execution time: 0.2466
INFO - 2021-01-12 03:35:04 --> Config Class Initialized
INFO - 2021-01-12 03:35:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:04 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:04 --> URI Class Initialized
INFO - 2021-01-12 03:35:04 --> Router Class Initialized
INFO - 2021-01-12 03:35:04 --> Output Class Initialized
INFO - 2021-01-12 03:35:04 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:04 --> Input Class Initialized
INFO - 2021-01-12 03:35:04 --> Language Class Initialized
INFO - 2021-01-12 03:35:04 --> Language Class Initialized
INFO - 2021-01-12 03:35:04 --> Config Class Initialized
INFO - 2021-01-12 03:35:04 --> Loader Class Initialized
INFO - 2021-01-12 03:35:04 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:04 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:04 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:04 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:04 --> Controller Class Initialized
INFO - 2021-01-12 03:35:04 --> Final output sent to browser
DEBUG - 2021-01-12 03:35:04 --> Total execution time: 0.2547
INFO - 2021-01-12 03:35:04 --> Config Class Initialized
INFO - 2021-01-12 03:35:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:04 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:04 --> URI Class Initialized
INFO - 2021-01-12 03:35:04 --> Router Class Initialized
INFO - 2021-01-12 03:35:04 --> Output Class Initialized
INFO - 2021-01-12 03:35:04 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:04 --> Input Class Initialized
INFO - 2021-01-12 03:35:04 --> Language Class Initialized
INFO - 2021-01-12 03:35:04 --> Language Class Initialized
INFO - 2021-01-12 03:35:04 --> Config Class Initialized
INFO - 2021-01-12 03:35:04 --> Loader Class Initialized
INFO - 2021-01-12 03:35:05 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:05 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:05 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:05 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:05 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:05 --> Controller Class Initialized
INFO - 2021-01-12 03:35:07 --> Config Class Initialized
INFO - 2021-01-12 03:35:07 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:07 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:07 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:07 --> URI Class Initialized
INFO - 2021-01-12 03:35:07 --> Router Class Initialized
INFO - 2021-01-12 03:35:07 --> Output Class Initialized
INFO - 2021-01-12 03:35:07 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:07 --> Input Class Initialized
INFO - 2021-01-12 03:35:07 --> Language Class Initialized
INFO - 2021-01-12 03:35:07 --> Language Class Initialized
INFO - 2021-01-12 03:35:07 --> Config Class Initialized
INFO - 2021-01-12 03:35:07 --> Loader Class Initialized
INFO - 2021-01-12 03:35:07 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:07 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:07 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:07 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:07 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:07 --> Controller Class Initialized
INFO - 2021-01-12 03:35:07 --> Final output sent to browser
DEBUG - 2021-01-12 03:35:07 --> Total execution time: 0.2811
INFO - 2021-01-12 03:35:18 --> Config Class Initialized
INFO - 2021-01-12 03:35:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:18 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:18 --> URI Class Initialized
INFO - 2021-01-12 03:35:18 --> Router Class Initialized
INFO - 2021-01-12 03:35:18 --> Output Class Initialized
INFO - 2021-01-12 03:35:18 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:18 --> Input Class Initialized
INFO - 2021-01-12 03:35:18 --> Language Class Initialized
INFO - 2021-01-12 03:35:18 --> Language Class Initialized
INFO - 2021-01-12 03:35:18 --> Config Class Initialized
INFO - 2021-01-12 03:35:18 --> Loader Class Initialized
INFO - 2021-01-12 03:35:18 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:18 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:18 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:18 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:18 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:18 --> Controller Class Initialized
INFO - 2021-01-12 03:35:18 --> Final output sent to browser
DEBUG - 2021-01-12 03:35:18 --> Total execution time: 0.2576
INFO - 2021-01-12 03:35:18 --> Config Class Initialized
INFO - 2021-01-12 03:35:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:18 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:18 --> URI Class Initialized
INFO - 2021-01-12 03:35:18 --> Router Class Initialized
INFO - 2021-01-12 03:35:18 --> Output Class Initialized
INFO - 2021-01-12 03:35:18 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:19 --> Input Class Initialized
INFO - 2021-01-12 03:35:19 --> Language Class Initialized
INFO - 2021-01-12 03:35:19 --> Language Class Initialized
INFO - 2021-01-12 03:35:19 --> Config Class Initialized
INFO - 2021-01-12 03:35:19 --> Loader Class Initialized
INFO - 2021-01-12 03:35:19 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:19 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:19 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:19 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:19 --> Controller Class Initialized
INFO - 2021-01-12 03:35:21 --> Config Class Initialized
INFO - 2021-01-12 03:35:21 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:21 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:21 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:21 --> URI Class Initialized
INFO - 2021-01-12 03:35:21 --> Router Class Initialized
INFO - 2021-01-12 03:35:21 --> Output Class Initialized
INFO - 2021-01-12 03:35:21 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:21 --> Input Class Initialized
INFO - 2021-01-12 03:35:21 --> Language Class Initialized
INFO - 2021-01-12 03:35:21 --> Language Class Initialized
INFO - 2021-01-12 03:35:21 --> Config Class Initialized
INFO - 2021-01-12 03:35:21 --> Loader Class Initialized
INFO - 2021-01-12 03:35:21 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:21 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:21 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:21 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:21 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:21 --> Controller Class Initialized
INFO - 2021-01-12 03:35:21 --> Final output sent to browser
DEBUG - 2021-01-12 03:35:21 --> Total execution time: 0.2793
INFO - 2021-01-12 03:35:48 --> Config Class Initialized
INFO - 2021-01-12 03:35:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:48 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:48 --> URI Class Initialized
INFO - 2021-01-12 03:35:48 --> Router Class Initialized
INFO - 2021-01-12 03:35:48 --> Output Class Initialized
INFO - 2021-01-12 03:35:48 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:48 --> Input Class Initialized
INFO - 2021-01-12 03:35:48 --> Language Class Initialized
INFO - 2021-01-12 03:35:48 --> Language Class Initialized
INFO - 2021-01-12 03:35:48 --> Config Class Initialized
INFO - 2021-01-12 03:35:48 --> Loader Class Initialized
INFO - 2021-01-12 03:35:48 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:48 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:48 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:48 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:48 --> Controller Class Initialized
INFO - 2021-01-12 03:35:48 --> Final output sent to browser
DEBUG - 2021-01-12 03:35:49 --> Total execution time: 0.2432
INFO - 2021-01-12 03:35:49 --> Config Class Initialized
INFO - 2021-01-12 03:35:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:49 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:49 --> URI Class Initialized
INFO - 2021-01-12 03:35:49 --> Router Class Initialized
INFO - 2021-01-12 03:35:49 --> Output Class Initialized
INFO - 2021-01-12 03:35:49 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:49 --> Input Class Initialized
INFO - 2021-01-12 03:35:49 --> Language Class Initialized
INFO - 2021-01-12 03:35:49 --> Language Class Initialized
INFO - 2021-01-12 03:35:49 --> Config Class Initialized
INFO - 2021-01-12 03:35:49 --> Loader Class Initialized
INFO - 2021-01-12 03:35:49 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:49 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:49 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:49 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:49 --> Controller Class Initialized
INFO - 2021-01-12 03:35:51 --> Config Class Initialized
INFO - 2021-01-12 03:35:51 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:35:51 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:35:51 --> Utf8 Class Initialized
INFO - 2021-01-12 03:35:51 --> URI Class Initialized
INFO - 2021-01-12 03:35:51 --> Router Class Initialized
INFO - 2021-01-12 03:35:51 --> Output Class Initialized
INFO - 2021-01-12 03:35:51 --> Security Class Initialized
DEBUG - 2021-01-12 03:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:35:51 --> Input Class Initialized
INFO - 2021-01-12 03:35:51 --> Language Class Initialized
INFO - 2021-01-12 03:35:51 --> Language Class Initialized
INFO - 2021-01-12 03:35:51 --> Config Class Initialized
INFO - 2021-01-12 03:35:51 --> Loader Class Initialized
INFO - 2021-01-12 03:35:51 --> Helper loaded: url_helper
INFO - 2021-01-12 03:35:51 --> Helper loaded: file_helper
INFO - 2021-01-12 03:35:51 --> Helper loaded: form_helper
INFO - 2021-01-12 03:35:51 --> Helper loaded: my_helper
INFO - 2021-01-12 03:35:51 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:35:51 --> Controller Class Initialized
INFO - 2021-01-12 03:35:51 --> Final output sent to browser
DEBUG - 2021-01-12 03:35:51 --> Total execution time: 0.2669
INFO - 2021-01-12 03:36:00 --> Config Class Initialized
INFO - 2021-01-12 03:36:00 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:36:00 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:36:00 --> Utf8 Class Initialized
INFO - 2021-01-12 03:36:00 --> URI Class Initialized
INFO - 2021-01-12 03:36:00 --> Router Class Initialized
INFO - 2021-01-12 03:36:00 --> Output Class Initialized
INFO - 2021-01-12 03:36:00 --> Security Class Initialized
DEBUG - 2021-01-12 03:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:36:00 --> Input Class Initialized
INFO - 2021-01-12 03:36:00 --> Language Class Initialized
INFO - 2021-01-12 03:36:00 --> Language Class Initialized
INFO - 2021-01-12 03:36:00 --> Config Class Initialized
INFO - 2021-01-12 03:36:00 --> Loader Class Initialized
INFO - 2021-01-12 03:36:00 --> Helper loaded: url_helper
INFO - 2021-01-12 03:36:00 --> Helper loaded: file_helper
INFO - 2021-01-12 03:36:00 --> Helper loaded: form_helper
INFO - 2021-01-12 03:36:00 --> Helper loaded: my_helper
INFO - 2021-01-12 03:36:00 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:36:01 --> Controller Class Initialized
INFO - 2021-01-12 03:36:01 --> Final output sent to browser
DEBUG - 2021-01-12 03:36:01 --> Total execution time: 0.2509
INFO - 2021-01-12 03:36:01 --> Config Class Initialized
INFO - 2021-01-12 03:36:01 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:36:01 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:36:01 --> Utf8 Class Initialized
INFO - 2021-01-12 03:36:01 --> URI Class Initialized
INFO - 2021-01-12 03:36:01 --> Router Class Initialized
INFO - 2021-01-12 03:36:01 --> Output Class Initialized
INFO - 2021-01-12 03:36:01 --> Security Class Initialized
DEBUG - 2021-01-12 03:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:36:01 --> Input Class Initialized
INFO - 2021-01-12 03:36:01 --> Language Class Initialized
INFO - 2021-01-12 03:36:01 --> Language Class Initialized
INFO - 2021-01-12 03:36:01 --> Config Class Initialized
INFO - 2021-01-12 03:36:01 --> Loader Class Initialized
INFO - 2021-01-12 03:36:01 --> Helper loaded: url_helper
INFO - 2021-01-12 03:36:01 --> Helper loaded: file_helper
INFO - 2021-01-12 03:36:01 --> Helper loaded: form_helper
INFO - 2021-01-12 03:36:01 --> Helper loaded: my_helper
INFO - 2021-01-12 03:36:01 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:36:01 --> Controller Class Initialized
INFO - 2021-01-12 03:40:49 --> Config Class Initialized
INFO - 2021-01-12 03:40:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:40:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:40:49 --> Utf8 Class Initialized
INFO - 2021-01-12 03:40:49 --> URI Class Initialized
INFO - 2021-01-12 03:40:49 --> Router Class Initialized
INFO - 2021-01-12 03:40:49 --> Output Class Initialized
INFO - 2021-01-12 03:40:49 --> Security Class Initialized
DEBUG - 2021-01-12 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:40:49 --> Input Class Initialized
INFO - 2021-01-12 03:40:49 --> Language Class Initialized
INFO - 2021-01-12 03:40:49 --> Language Class Initialized
INFO - 2021-01-12 03:40:49 --> Config Class Initialized
INFO - 2021-01-12 03:40:49 --> Loader Class Initialized
INFO - 2021-01-12 03:40:49 --> Helper loaded: url_helper
INFO - 2021-01-12 03:40:49 --> Helper loaded: file_helper
INFO - 2021-01-12 03:40:49 --> Helper loaded: form_helper
INFO - 2021-01-12 03:40:49 --> Helper loaded: my_helper
INFO - 2021-01-12 03:40:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:40:49 --> Controller Class Initialized
DEBUG - 2021-01-12 03:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:40:49 --> Final output sent to browser
DEBUG - 2021-01-12 03:40:49 --> Total execution time: 0.3440
INFO - 2021-01-12 03:41:08 --> Config Class Initialized
INFO - 2021-01-12 03:41:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:41:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:41:08 --> Utf8 Class Initialized
INFO - 2021-01-12 03:41:08 --> URI Class Initialized
INFO - 2021-01-12 03:41:08 --> Router Class Initialized
INFO - 2021-01-12 03:41:08 --> Output Class Initialized
INFO - 2021-01-12 03:41:08 --> Security Class Initialized
DEBUG - 2021-01-12 03:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:41:08 --> Input Class Initialized
INFO - 2021-01-12 03:41:08 --> Language Class Initialized
INFO - 2021-01-12 03:41:08 --> Language Class Initialized
INFO - 2021-01-12 03:41:08 --> Config Class Initialized
INFO - 2021-01-12 03:41:08 --> Loader Class Initialized
INFO - 2021-01-12 03:41:08 --> Helper loaded: url_helper
INFO - 2021-01-12 03:41:08 --> Helper loaded: file_helper
INFO - 2021-01-12 03:41:08 --> Helper loaded: form_helper
INFO - 2021-01-12 03:41:08 --> Helper loaded: my_helper
INFO - 2021-01-12 03:41:08 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:41:08 --> Controller Class Initialized
DEBUG - 2021-01-12 03:41:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:41:08 --> Final output sent to browser
DEBUG - 2021-01-12 03:41:08 --> Total execution time: 0.3406
INFO - 2021-01-12 03:41:25 --> Config Class Initialized
INFO - 2021-01-12 03:41:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:41:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:41:26 --> Utf8 Class Initialized
INFO - 2021-01-12 03:41:26 --> URI Class Initialized
INFO - 2021-01-12 03:41:26 --> Router Class Initialized
INFO - 2021-01-12 03:41:26 --> Output Class Initialized
INFO - 2021-01-12 03:41:26 --> Security Class Initialized
DEBUG - 2021-01-12 03:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:41:26 --> Input Class Initialized
INFO - 2021-01-12 03:41:26 --> Language Class Initialized
INFO - 2021-01-12 03:41:26 --> Language Class Initialized
INFO - 2021-01-12 03:41:26 --> Config Class Initialized
INFO - 2021-01-12 03:41:26 --> Loader Class Initialized
INFO - 2021-01-12 03:41:26 --> Helper loaded: url_helper
INFO - 2021-01-12 03:41:26 --> Helper loaded: file_helper
INFO - 2021-01-12 03:41:26 --> Helper loaded: form_helper
INFO - 2021-01-12 03:41:26 --> Helper loaded: my_helper
INFO - 2021-01-12 03:41:26 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:41:26 --> Controller Class Initialized
DEBUG - 2021-01-12 03:41:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:41:26 --> Final output sent to browser
DEBUG - 2021-01-12 03:41:26 --> Total execution time: 0.3227
INFO - 2021-01-12 03:41:57 --> Config Class Initialized
INFO - 2021-01-12 03:41:57 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:41:57 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:41:57 --> Utf8 Class Initialized
INFO - 2021-01-12 03:41:57 --> URI Class Initialized
INFO - 2021-01-12 03:41:57 --> Router Class Initialized
INFO - 2021-01-12 03:41:57 --> Output Class Initialized
INFO - 2021-01-12 03:41:57 --> Security Class Initialized
DEBUG - 2021-01-12 03:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:41:57 --> Input Class Initialized
INFO - 2021-01-12 03:41:57 --> Language Class Initialized
INFO - 2021-01-12 03:41:57 --> Language Class Initialized
INFO - 2021-01-12 03:41:57 --> Config Class Initialized
INFO - 2021-01-12 03:41:57 --> Loader Class Initialized
INFO - 2021-01-12 03:41:57 --> Helper loaded: url_helper
INFO - 2021-01-12 03:41:57 --> Helper loaded: file_helper
INFO - 2021-01-12 03:41:57 --> Helper loaded: form_helper
INFO - 2021-01-12 03:41:57 --> Helper loaded: my_helper
INFO - 2021-01-12 03:41:57 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:41:57 --> Controller Class Initialized
DEBUG - 2021-01-12 03:41:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:41:57 --> Final output sent to browser
DEBUG - 2021-01-12 03:41:57 --> Total execution time: 0.3357
INFO - 2021-01-12 03:42:35 --> Config Class Initialized
INFO - 2021-01-12 03:42:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:42:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:42:35 --> Utf8 Class Initialized
INFO - 2021-01-12 03:42:35 --> URI Class Initialized
INFO - 2021-01-12 03:42:35 --> Router Class Initialized
INFO - 2021-01-12 03:42:35 --> Output Class Initialized
INFO - 2021-01-12 03:42:35 --> Security Class Initialized
DEBUG - 2021-01-12 03:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:42:35 --> Input Class Initialized
INFO - 2021-01-12 03:42:35 --> Language Class Initialized
INFO - 2021-01-12 03:42:35 --> Language Class Initialized
INFO - 2021-01-12 03:42:35 --> Config Class Initialized
INFO - 2021-01-12 03:42:35 --> Loader Class Initialized
INFO - 2021-01-12 03:42:35 --> Helper loaded: url_helper
INFO - 2021-01-12 03:42:35 --> Helper loaded: file_helper
INFO - 2021-01-12 03:42:35 --> Helper loaded: form_helper
INFO - 2021-01-12 03:42:35 --> Helper loaded: my_helper
INFO - 2021-01-12 03:42:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:42:35 --> Controller Class Initialized
DEBUG - 2021-01-12 03:42:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:42:35 --> Final output sent to browser
DEBUG - 2021-01-12 03:42:35 --> Total execution time: 0.3314
INFO - 2021-01-12 03:43:06 --> Config Class Initialized
INFO - 2021-01-12 03:43:06 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:43:06 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:43:06 --> Utf8 Class Initialized
INFO - 2021-01-12 03:43:06 --> URI Class Initialized
INFO - 2021-01-12 03:43:06 --> Router Class Initialized
INFO - 2021-01-12 03:43:06 --> Output Class Initialized
INFO - 2021-01-12 03:43:06 --> Security Class Initialized
DEBUG - 2021-01-12 03:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:43:06 --> Input Class Initialized
INFO - 2021-01-12 03:43:06 --> Language Class Initialized
INFO - 2021-01-12 03:43:06 --> Language Class Initialized
INFO - 2021-01-12 03:43:06 --> Config Class Initialized
INFO - 2021-01-12 03:43:06 --> Loader Class Initialized
INFO - 2021-01-12 03:43:06 --> Helper loaded: url_helper
INFO - 2021-01-12 03:43:06 --> Helper loaded: file_helper
INFO - 2021-01-12 03:43:06 --> Helper loaded: form_helper
INFO - 2021-01-12 03:43:06 --> Helper loaded: my_helper
INFO - 2021-01-12 03:43:06 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:43:06 --> Controller Class Initialized
DEBUG - 2021-01-12 03:43:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:43:06 --> Final output sent to browser
DEBUG - 2021-01-12 03:43:06 --> Total execution time: 0.3857
INFO - 2021-01-12 03:43:40 --> Config Class Initialized
INFO - 2021-01-12 03:43:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:43:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:43:40 --> Utf8 Class Initialized
INFO - 2021-01-12 03:43:40 --> URI Class Initialized
INFO - 2021-01-12 03:43:40 --> Router Class Initialized
INFO - 2021-01-12 03:43:40 --> Output Class Initialized
INFO - 2021-01-12 03:43:40 --> Security Class Initialized
DEBUG - 2021-01-12 03:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:43:40 --> Input Class Initialized
INFO - 2021-01-12 03:43:40 --> Language Class Initialized
INFO - 2021-01-12 03:43:40 --> Language Class Initialized
INFO - 2021-01-12 03:43:40 --> Config Class Initialized
INFO - 2021-01-12 03:43:40 --> Loader Class Initialized
INFO - 2021-01-12 03:43:40 --> Helper loaded: url_helper
INFO - 2021-01-12 03:43:40 --> Helper loaded: file_helper
INFO - 2021-01-12 03:43:40 --> Helper loaded: form_helper
INFO - 2021-01-12 03:43:40 --> Helper loaded: my_helper
INFO - 2021-01-12 03:43:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:43:40 --> Controller Class Initialized
DEBUG - 2021-01-12 03:43:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:43:40 --> Final output sent to browser
DEBUG - 2021-01-12 03:43:40 --> Total execution time: 0.3382
INFO - 2021-01-12 03:44:26 --> Config Class Initialized
INFO - 2021-01-12 03:44:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:44:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:44:26 --> Utf8 Class Initialized
INFO - 2021-01-12 03:44:26 --> URI Class Initialized
INFO - 2021-01-12 03:44:26 --> Router Class Initialized
INFO - 2021-01-12 03:44:26 --> Output Class Initialized
INFO - 2021-01-12 03:44:26 --> Security Class Initialized
DEBUG - 2021-01-12 03:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:44:26 --> Input Class Initialized
INFO - 2021-01-12 03:44:26 --> Language Class Initialized
INFO - 2021-01-12 03:44:26 --> Language Class Initialized
INFO - 2021-01-12 03:44:26 --> Config Class Initialized
INFO - 2021-01-12 03:44:26 --> Loader Class Initialized
INFO - 2021-01-12 03:44:26 --> Helper loaded: url_helper
INFO - 2021-01-12 03:44:26 --> Helper loaded: file_helper
INFO - 2021-01-12 03:44:26 --> Helper loaded: form_helper
INFO - 2021-01-12 03:44:26 --> Helper loaded: my_helper
INFO - 2021-01-12 03:44:26 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:44:26 --> Controller Class Initialized
DEBUG - 2021-01-12 03:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:44:27 --> Final output sent to browser
DEBUG - 2021-01-12 03:44:27 --> Total execution time: 0.3355
INFO - 2021-01-12 03:45:38 --> Config Class Initialized
INFO - 2021-01-12 03:45:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:45:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:45:38 --> Utf8 Class Initialized
INFO - 2021-01-12 03:45:38 --> URI Class Initialized
INFO - 2021-01-12 03:45:38 --> Router Class Initialized
INFO - 2021-01-12 03:45:38 --> Output Class Initialized
INFO - 2021-01-12 03:45:38 --> Security Class Initialized
DEBUG - 2021-01-12 03:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:45:38 --> Input Class Initialized
INFO - 2021-01-12 03:45:38 --> Language Class Initialized
INFO - 2021-01-12 03:45:38 --> Language Class Initialized
INFO - 2021-01-12 03:45:38 --> Config Class Initialized
INFO - 2021-01-12 03:45:38 --> Loader Class Initialized
INFO - 2021-01-12 03:45:38 --> Helper loaded: url_helper
INFO - 2021-01-12 03:45:38 --> Helper loaded: file_helper
INFO - 2021-01-12 03:45:38 --> Helper loaded: form_helper
INFO - 2021-01-12 03:45:38 --> Helper loaded: my_helper
INFO - 2021-01-12 03:45:38 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:45:38 --> Controller Class Initialized
DEBUG - 2021-01-12 03:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 03:45:39 --> Final output sent to browser
DEBUG - 2021-01-12 03:45:39 --> Total execution time: 0.3375
INFO - 2021-01-12 03:46:10 --> Config Class Initialized
INFO - 2021-01-12 03:46:10 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:46:10 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:46:10 --> Utf8 Class Initialized
INFO - 2021-01-12 03:46:10 --> URI Class Initialized
INFO - 2021-01-12 03:46:10 --> Router Class Initialized
INFO - 2021-01-12 03:46:10 --> Output Class Initialized
INFO - 2021-01-12 03:46:10 --> Security Class Initialized
DEBUG - 2021-01-12 03:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:46:10 --> Input Class Initialized
INFO - 2021-01-12 03:46:10 --> Language Class Initialized
INFO - 2021-01-12 03:46:10 --> Language Class Initialized
INFO - 2021-01-12 03:46:10 --> Config Class Initialized
INFO - 2021-01-12 03:46:10 --> Loader Class Initialized
INFO - 2021-01-12 03:46:10 --> Helper loaded: url_helper
INFO - 2021-01-12 03:46:10 --> Helper loaded: file_helper
INFO - 2021-01-12 03:46:10 --> Helper loaded: form_helper
INFO - 2021-01-12 03:46:10 --> Helper loaded: my_helper
INFO - 2021-01-12 03:46:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:46:10 --> Controller Class Initialized
INFO - 2021-01-12 03:47:14 --> Config Class Initialized
INFO - 2021-01-12 03:47:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:47:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:47:14 --> Utf8 Class Initialized
INFO - 2021-01-12 03:47:14 --> URI Class Initialized
INFO - 2021-01-12 03:47:14 --> Router Class Initialized
INFO - 2021-01-12 03:47:15 --> Output Class Initialized
INFO - 2021-01-12 03:47:15 --> Security Class Initialized
DEBUG - 2021-01-12 03:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:47:15 --> Input Class Initialized
INFO - 2021-01-12 03:47:15 --> Language Class Initialized
INFO - 2021-01-12 03:47:15 --> Language Class Initialized
INFO - 2021-01-12 03:47:15 --> Config Class Initialized
INFO - 2021-01-12 03:47:15 --> Loader Class Initialized
INFO - 2021-01-12 03:47:15 --> Helper loaded: url_helper
INFO - 2021-01-12 03:47:15 --> Helper loaded: file_helper
INFO - 2021-01-12 03:47:15 --> Helper loaded: form_helper
INFO - 2021-01-12 03:47:15 --> Helper loaded: my_helper
INFO - 2021-01-12 03:47:15 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:47:15 --> Controller Class Initialized
INFO - 2021-01-12 03:47:15 --> Helper loaded: cookie_helper
INFO - 2021-01-12 03:47:15 --> Config Class Initialized
INFO - 2021-01-12 03:47:15 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:47:15 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:47:15 --> Utf8 Class Initialized
INFO - 2021-01-12 03:47:15 --> URI Class Initialized
INFO - 2021-01-12 03:47:15 --> Router Class Initialized
INFO - 2021-01-12 03:47:15 --> Output Class Initialized
INFO - 2021-01-12 03:47:15 --> Security Class Initialized
DEBUG - 2021-01-12 03:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:47:15 --> Input Class Initialized
INFO - 2021-01-12 03:47:15 --> Language Class Initialized
INFO - 2021-01-12 03:47:15 --> Language Class Initialized
INFO - 2021-01-12 03:47:15 --> Config Class Initialized
INFO - 2021-01-12 03:47:15 --> Loader Class Initialized
INFO - 2021-01-12 03:47:15 --> Helper loaded: url_helper
INFO - 2021-01-12 03:47:15 --> Helper loaded: file_helper
INFO - 2021-01-12 03:47:15 --> Helper loaded: form_helper
INFO - 2021-01-12 03:47:15 --> Helper loaded: my_helper
INFO - 2021-01-12 03:47:15 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:47:15 --> Controller Class Initialized
DEBUG - 2021-01-12 03:47:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 03:47:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 03:47:15 --> Final output sent to browser
DEBUG - 2021-01-12 03:47:15 --> Total execution time: 0.3192
INFO - 2021-01-12 03:47:27 --> Config Class Initialized
INFO - 2021-01-12 03:47:27 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:47:27 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:47:27 --> Utf8 Class Initialized
INFO - 2021-01-12 03:47:27 --> URI Class Initialized
INFO - 2021-01-12 03:47:27 --> Router Class Initialized
INFO - 2021-01-12 03:47:27 --> Output Class Initialized
INFO - 2021-01-12 03:47:27 --> Security Class Initialized
DEBUG - 2021-01-12 03:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:47:27 --> Input Class Initialized
INFO - 2021-01-12 03:47:27 --> Language Class Initialized
INFO - 2021-01-12 03:47:27 --> Language Class Initialized
INFO - 2021-01-12 03:47:27 --> Config Class Initialized
INFO - 2021-01-12 03:47:27 --> Loader Class Initialized
INFO - 2021-01-12 03:47:27 --> Helper loaded: url_helper
INFO - 2021-01-12 03:47:27 --> Helper loaded: file_helper
INFO - 2021-01-12 03:47:27 --> Helper loaded: form_helper
INFO - 2021-01-12 03:47:27 --> Helper loaded: my_helper
INFO - 2021-01-12 03:47:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:47:27 --> Controller Class Initialized
INFO - 2021-01-12 03:47:27 --> Helper loaded: cookie_helper
INFO - 2021-01-12 03:47:27 --> Final output sent to browser
DEBUG - 2021-01-12 03:47:27 --> Total execution time: 0.3696
INFO - 2021-01-12 03:47:27 --> Config Class Initialized
INFO - 2021-01-12 03:47:27 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:47:27 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:47:27 --> Utf8 Class Initialized
INFO - 2021-01-12 03:47:27 --> URI Class Initialized
INFO - 2021-01-12 03:47:27 --> Router Class Initialized
INFO - 2021-01-12 03:47:28 --> Output Class Initialized
INFO - 2021-01-12 03:47:28 --> Security Class Initialized
DEBUG - 2021-01-12 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:47:28 --> Input Class Initialized
INFO - 2021-01-12 03:47:28 --> Language Class Initialized
INFO - 2021-01-12 03:47:28 --> Language Class Initialized
INFO - 2021-01-12 03:47:28 --> Config Class Initialized
INFO - 2021-01-12 03:47:28 --> Loader Class Initialized
INFO - 2021-01-12 03:47:28 --> Helper loaded: url_helper
INFO - 2021-01-12 03:47:28 --> Helper loaded: file_helper
INFO - 2021-01-12 03:47:28 --> Helper loaded: form_helper
INFO - 2021-01-12 03:47:28 --> Helper loaded: my_helper
INFO - 2021-01-12 03:47:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:47:28 --> Controller Class Initialized
DEBUG - 2021-01-12 03:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 03:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 03:47:28 --> Final output sent to browser
DEBUG - 2021-01-12 03:47:28 --> Total execution time: 0.4598
INFO - 2021-01-12 03:47:30 --> Config Class Initialized
INFO - 2021-01-12 03:47:30 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:47:30 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:47:30 --> Utf8 Class Initialized
INFO - 2021-01-12 03:47:30 --> URI Class Initialized
INFO - 2021-01-12 03:47:30 --> Router Class Initialized
INFO - 2021-01-12 03:47:30 --> Output Class Initialized
INFO - 2021-01-12 03:47:30 --> Security Class Initialized
DEBUG - 2021-01-12 03:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:47:30 --> Input Class Initialized
INFO - 2021-01-12 03:47:30 --> Language Class Initialized
INFO - 2021-01-12 03:47:30 --> Language Class Initialized
INFO - 2021-01-12 03:47:30 --> Config Class Initialized
INFO - 2021-01-12 03:47:30 --> Loader Class Initialized
INFO - 2021-01-12 03:47:30 --> Helper loaded: url_helper
INFO - 2021-01-12 03:47:30 --> Helper loaded: file_helper
INFO - 2021-01-12 03:47:30 --> Helper loaded: form_helper
INFO - 2021-01-12 03:47:30 --> Helper loaded: my_helper
INFO - 2021-01-12 03:47:30 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:47:30 --> Controller Class Initialized
DEBUG - 2021-01-12 03:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 03:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 03:47:30 --> Final output sent to browser
DEBUG - 2021-01-12 03:47:30 --> Total execution time: 0.3108
INFO - 2021-01-12 03:47:31 --> Config Class Initialized
INFO - 2021-01-12 03:47:31 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:47:31 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:47:32 --> Utf8 Class Initialized
INFO - 2021-01-12 03:47:32 --> URI Class Initialized
INFO - 2021-01-12 03:47:32 --> Router Class Initialized
INFO - 2021-01-12 03:47:32 --> Output Class Initialized
INFO - 2021-01-12 03:47:32 --> Security Class Initialized
DEBUG - 2021-01-12 03:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:47:32 --> Input Class Initialized
INFO - 2021-01-12 03:47:32 --> Language Class Initialized
INFO - 2021-01-12 03:47:32 --> Language Class Initialized
INFO - 2021-01-12 03:47:32 --> Config Class Initialized
INFO - 2021-01-12 03:47:32 --> Loader Class Initialized
INFO - 2021-01-12 03:47:32 --> Helper loaded: url_helper
INFO - 2021-01-12 03:47:32 --> Helper loaded: file_helper
INFO - 2021-01-12 03:47:32 --> Helper loaded: form_helper
INFO - 2021-01-12 03:47:32 --> Helper loaded: my_helper
INFO - 2021-01-12 03:47:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:47:32 --> Controller Class Initialized
DEBUG - 2021-01-12 03:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 03:47:32 --> Final output sent to browser
DEBUG - 2021-01-12 03:47:32 --> Total execution time: 0.3311
INFO - 2021-01-12 03:47:35 --> Config Class Initialized
INFO - 2021-01-12 03:47:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:47:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:47:35 --> Utf8 Class Initialized
INFO - 2021-01-12 03:47:35 --> URI Class Initialized
INFO - 2021-01-12 03:47:35 --> Router Class Initialized
INFO - 2021-01-12 03:47:35 --> Output Class Initialized
INFO - 2021-01-12 03:47:35 --> Security Class Initialized
DEBUG - 2021-01-12 03:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:47:35 --> Input Class Initialized
INFO - 2021-01-12 03:47:35 --> Language Class Initialized
INFO - 2021-01-12 03:47:35 --> Language Class Initialized
INFO - 2021-01-12 03:47:35 --> Config Class Initialized
INFO - 2021-01-12 03:47:35 --> Loader Class Initialized
INFO - 2021-01-12 03:47:35 --> Helper loaded: url_helper
INFO - 2021-01-12 03:47:35 --> Helper loaded: file_helper
INFO - 2021-01-12 03:47:35 --> Helper loaded: form_helper
INFO - 2021-01-12 03:47:35 --> Helper loaded: my_helper
INFO - 2021-01-12 03:47:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:47:35 --> Controller Class Initialized
DEBUG - 2021-01-12 03:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:47:35 --> Final output sent to browser
DEBUG - 2021-01-12 03:47:35 --> Total execution time: 0.3394
INFO - 2021-01-12 03:48:09 --> Config Class Initialized
INFO - 2021-01-12 03:48:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:48:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:48:09 --> Utf8 Class Initialized
INFO - 2021-01-12 03:48:09 --> URI Class Initialized
INFO - 2021-01-12 03:48:09 --> Router Class Initialized
INFO - 2021-01-12 03:48:09 --> Output Class Initialized
INFO - 2021-01-12 03:48:09 --> Security Class Initialized
DEBUG - 2021-01-12 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:48:09 --> Input Class Initialized
INFO - 2021-01-12 03:48:09 --> Language Class Initialized
INFO - 2021-01-12 03:48:10 --> Language Class Initialized
INFO - 2021-01-12 03:48:10 --> Config Class Initialized
INFO - 2021-01-12 03:48:10 --> Loader Class Initialized
INFO - 2021-01-12 03:48:10 --> Helper loaded: url_helper
INFO - 2021-01-12 03:48:10 --> Helper loaded: file_helper
INFO - 2021-01-12 03:48:10 --> Helper loaded: form_helper
INFO - 2021-01-12 03:48:10 --> Helper loaded: my_helper
INFO - 2021-01-12 03:48:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:48:10 --> Controller Class Initialized
DEBUG - 2021-01-12 03:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:48:10 --> Final output sent to browser
DEBUG - 2021-01-12 03:48:10 --> Total execution time: 0.2983
INFO - 2021-01-12 03:50:40 --> Config Class Initialized
INFO - 2021-01-12 03:50:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:50:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:50:40 --> Utf8 Class Initialized
INFO - 2021-01-12 03:50:40 --> URI Class Initialized
INFO - 2021-01-12 03:50:40 --> Router Class Initialized
INFO - 2021-01-12 03:50:40 --> Output Class Initialized
INFO - 2021-01-12 03:50:40 --> Security Class Initialized
DEBUG - 2021-01-12 03:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:50:40 --> Input Class Initialized
INFO - 2021-01-12 03:50:40 --> Language Class Initialized
INFO - 2021-01-12 03:50:40 --> Language Class Initialized
INFO - 2021-01-12 03:50:40 --> Config Class Initialized
INFO - 2021-01-12 03:50:40 --> Loader Class Initialized
INFO - 2021-01-12 03:50:40 --> Helper loaded: url_helper
INFO - 2021-01-12 03:50:40 --> Helper loaded: file_helper
INFO - 2021-01-12 03:50:40 --> Helper loaded: form_helper
INFO - 2021-01-12 03:50:40 --> Helper loaded: my_helper
INFO - 2021-01-12 03:50:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:50:40 --> Controller Class Initialized
DEBUG - 2021-01-12 03:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:50:40 --> Final output sent to browser
DEBUG - 2021-01-12 03:50:40 --> Total execution time: 0.3353
INFO - 2021-01-12 03:51:13 --> Config Class Initialized
INFO - 2021-01-12 03:51:13 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:51:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:51:13 --> Utf8 Class Initialized
INFO - 2021-01-12 03:51:13 --> URI Class Initialized
INFO - 2021-01-12 03:51:13 --> Router Class Initialized
INFO - 2021-01-12 03:51:13 --> Output Class Initialized
INFO - 2021-01-12 03:51:13 --> Security Class Initialized
DEBUG - 2021-01-12 03:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:51:13 --> Input Class Initialized
INFO - 2021-01-12 03:51:13 --> Language Class Initialized
INFO - 2021-01-12 03:51:13 --> Language Class Initialized
INFO - 2021-01-12 03:51:13 --> Config Class Initialized
INFO - 2021-01-12 03:51:13 --> Loader Class Initialized
INFO - 2021-01-12 03:51:13 --> Helper loaded: url_helper
INFO - 2021-01-12 03:51:13 --> Helper loaded: file_helper
INFO - 2021-01-12 03:51:13 --> Helper loaded: form_helper
INFO - 2021-01-12 03:51:13 --> Helper loaded: my_helper
INFO - 2021-01-12 03:51:13 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:51:14 --> Controller Class Initialized
DEBUG - 2021-01-12 03:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:51:14 --> Final output sent to browser
DEBUG - 2021-01-12 03:51:14 --> Total execution time: 0.3620
INFO - 2021-01-12 03:51:28 --> Config Class Initialized
INFO - 2021-01-12 03:51:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:51:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:51:28 --> Utf8 Class Initialized
INFO - 2021-01-12 03:51:28 --> URI Class Initialized
INFO - 2021-01-12 03:51:28 --> Router Class Initialized
INFO - 2021-01-12 03:51:28 --> Output Class Initialized
INFO - 2021-01-12 03:51:28 --> Security Class Initialized
DEBUG - 2021-01-12 03:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:51:28 --> Input Class Initialized
INFO - 2021-01-12 03:51:28 --> Language Class Initialized
INFO - 2021-01-12 03:51:28 --> Language Class Initialized
INFO - 2021-01-12 03:51:28 --> Config Class Initialized
INFO - 2021-01-12 03:51:28 --> Loader Class Initialized
INFO - 2021-01-12 03:51:28 --> Helper loaded: url_helper
INFO - 2021-01-12 03:51:28 --> Helper loaded: file_helper
INFO - 2021-01-12 03:51:28 --> Helper loaded: form_helper
INFO - 2021-01-12 03:51:28 --> Helper loaded: my_helper
INFO - 2021-01-12 03:51:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:51:28 --> Controller Class Initialized
DEBUG - 2021-01-12 03:51:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:51:28 --> Final output sent to browser
DEBUG - 2021-01-12 03:51:28 --> Total execution time: 0.3505
INFO - 2021-01-12 03:51:46 --> Config Class Initialized
INFO - 2021-01-12 03:51:46 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:51:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:51:46 --> Utf8 Class Initialized
INFO - 2021-01-12 03:51:46 --> URI Class Initialized
INFO - 2021-01-12 03:51:46 --> Router Class Initialized
INFO - 2021-01-12 03:51:46 --> Output Class Initialized
INFO - 2021-01-12 03:51:46 --> Security Class Initialized
DEBUG - 2021-01-12 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:51:46 --> Input Class Initialized
INFO - 2021-01-12 03:51:46 --> Language Class Initialized
INFO - 2021-01-12 03:51:46 --> Language Class Initialized
INFO - 2021-01-12 03:51:46 --> Config Class Initialized
INFO - 2021-01-12 03:51:46 --> Loader Class Initialized
INFO - 2021-01-12 03:51:46 --> Helper loaded: url_helper
INFO - 2021-01-12 03:51:46 --> Helper loaded: file_helper
INFO - 2021-01-12 03:51:46 --> Helper loaded: form_helper
INFO - 2021-01-12 03:51:46 --> Helper loaded: my_helper
INFO - 2021-01-12 03:51:46 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:51:46 --> Controller Class Initialized
DEBUG - 2021-01-12 03:51:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:51:46 --> Final output sent to browser
DEBUG - 2021-01-12 03:51:47 --> Total execution time: 0.3428
INFO - 2021-01-12 03:52:03 --> Config Class Initialized
INFO - 2021-01-12 03:52:03 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:52:03 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:52:03 --> Utf8 Class Initialized
INFO - 2021-01-12 03:52:03 --> URI Class Initialized
INFO - 2021-01-12 03:52:03 --> Router Class Initialized
INFO - 2021-01-12 03:52:03 --> Output Class Initialized
INFO - 2021-01-12 03:52:03 --> Security Class Initialized
DEBUG - 2021-01-12 03:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:52:03 --> Input Class Initialized
INFO - 2021-01-12 03:52:03 --> Language Class Initialized
INFO - 2021-01-12 03:52:03 --> Language Class Initialized
INFO - 2021-01-12 03:52:03 --> Config Class Initialized
INFO - 2021-01-12 03:52:03 --> Loader Class Initialized
INFO - 2021-01-12 03:52:03 --> Helper loaded: url_helper
INFO - 2021-01-12 03:52:03 --> Helper loaded: file_helper
INFO - 2021-01-12 03:52:03 --> Helper loaded: form_helper
INFO - 2021-01-12 03:52:03 --> Helper loaded: my_helper
INFO - 2021-01-12 03:52:03 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:52:03 --> Controller Class Initialized
DEBUG - 2021-01-12 03:52:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:52:03 --> Final output sent to browser
DEBUG - 2021-01-12 03:52:03 --> Total execution time: 0.3392
INFO - 2021-01-12 03:53:32 --> Config Class Initialized
INFO - 2021-01-12 03:53:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:53:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:53:32 --> Utf8 Class Initialized
INFO - 2021-01-12 03:53:32 --> URI Class Initialized
INFO - 2021-01-12 03:53:32 --> Router Class Initialized
INFO - 2021-01-12 03:53:32 --> Output Class Initialized
INFO - 2021-01-12 03:53:32 --> Security Class Initialized
DEBUG - 2021-01-12 03:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:53:32 --> Input Class Initialized
INFO - 2021-01-12 03:53:32 --> Language Class Initialized
INFO - 2021-01-12 03:53:32 --> Language Class Initialized
INFO - 2021-01-12 03:53:32 --> Config Class Initialized
INFO - 2021-01-12 03:53:32 --> Loader Class Initialized
INFO - 2021-01-12 03:53:32 --> Helper loaded: url_helper
INFO - 2021-01-12 03:53:32 --> Helper loaded: file_helper
INFO - 2021-01-12 03:53:32 --> Helper loaded: form_helper
INFO - 2021-01-12 03:53:32 --> Helper loaded: my_helper
INFO - 2021-01-12 03:53:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:53:32 --> Controller Class Initialized
DEBUG - 2021-01-12 03:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:53:32 --> Final output sent to browser
DEBUG - 2021-01-12 03:53:32 --> Total execution time: 0.3629
INFO - 2021-01-12 03:58:19 --> Config Class Initialized
INFO - 2021-01-12 03:58:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:58:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:58:19 --> Utf8 Class Initialized
INFO - 2021-01-12 03:58:19 --> URI Class Initialized
INFO - 2021-01-12 03:58:19 --> Router Class Initialized
INFO - 2021-01-12 03:58:19 --> Output Class Initialized
INFO - 2021-01-12 03:58:19 --> Security Class Initialized
DEBUG - 2021-01-12 03:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:58:19 --> Input Class Initialized
INFO - 2021-01-12 03:58:19 --> Language Class Initialized
INFO - 2021-01-12 03:58:19 --> Language Class Initialized
INFO - 2021-01-12 03:58:19 --> Config Class Initialized
INFO - 2021-01-12 03:58:19 --> Loader Class Initialized
INFO - 2021-01-12 03:58:19 --> Helper loaded: url_helper
INFO - 2021-01-12 03:58:19 --> Helper loaded: file_helper
INFO - 2021-01-12 03:58:19 --> Helper loaded: form_helper
INFO - 2021-01-12 03:58:19 --> Helper loaded: my_helper
INFO - 2021-01-12 03:58:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:58:19 --> Controller Class Initialized
DEBUG - 2021-01-12 03:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:58:19 --> Final output sent to browser
DEBUG - 2021-01-12 03:58:19 --> Total execution time: 0.3432
INFO - 2021-01-12 03:58:59 --> Config Class Initialized
INFO - 2021-01-12 03:58:59 --> Hooks Class Initialized
DEBUG - 2021-01-12 03:58:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 03:58:59 --> Utf8 Class Initialized
INFO - 2021-01-12 03:58:59 --> URI Class Initialized
INFO - 2021-01-12 03:58:59 --> Router Class Initialized
INFO - 2021-01-12 03:58:59 --> Output Class Initialized
INFO - 2021-01-12 03:58:59 --> Security Class Initialized
DEBUG - 2021-01-12 03:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 03:58:59 --> Input Class Initialized
INFO - 2021-01-12 03:58:59 --> Language Class Initialized
INFO - 2021-01-12 03:58:59 --> Language Class Initialized
INFO - 2021-01-12 03:58:59 --> Config Class Initialized
INFO - 2021-01-12 03:58:59 --> Loader Class Initialized
INFO - 2021-01-12 03:58:59 --> Helper loaded: url_helper
INFO - 2021-01-12 03:58:59 --> Helper loaded: file_helper
INFO - 2021-01-12 03:58:59 --> Helper loaded: form_helper
INFO - 2021-01-12 03:58:59 --> Helper loaded: my_helper
INFO - 2021-01-12 03:58:59 --> Database Driver Class Initialized
DEBUG - 2021-01-12 03:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 03:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 03:58:59 --> Controller Class Initialized
DEBUG - 2021-01-12 03:58:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 03:58:59 --> Final output sent to browser
DEBUG - 2021-01-12 03:58:59 --> Total execution time: 0.3320
INFO - 2021-01-12 04:40:34 --> Config Class Initialized
INFO - 2021-01-12 04:40:34 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:40:34 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:40:34 --> Utf8 Class Initialized
INFO - 2021-01-12 04:40:34 --> URI Class Initialized
INFO - 2021-01-12 04:40:34 --> Router Class Initialized
INFO - 2021-01-12 04:40:34 --> Output Class Initialized
INFO - 2021-01-12 04:40:34 --> Security Class Initialized
DEBUG - 2021-01-12 04:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:40:34 --> Input Class Initialized
INFO - 2021-01-12 04:40:34 --> Language Class Initialized
INFO - 2021-01-12 04:40:34 --> Language Class Initialized
INFO - 2021-01-12 04:40:34 --> Config Class Initialized
INFO - 2021-01-12 04:40:34 --> Loader Class Initialized
INFO - 2021-01-12 04:40:34 --> Helper loaded: url_helper
INFO - 2021-01-12 04:40:34 --> Helper loaded: file_helper
INFO - 2021-01-12 04:40:34 --> Helper loaded: form_helper
INFO - 2021-01-12 04:40:34 --> Helper loaded: my_helper
INFO - 2021-01-12 04:40:34 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:40:34 --> Controller Class Initialized
DEBUG - 2021-01-12 04:40:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:40:34 --> Final output sent to browser
DEBUG - 2021-01-12 04:40:34 --> Total execution time: 0.3214
INFO - 2021-01-12 04:40:58 --> Config Class Initialized
INFO - 2021-01-12 04:40:58 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:40:58 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:40:58 --> Utf8 Class Initialized
INFO - 2021-01-12 04:40:58 --> URI Class Initialized
INFO - 2021-01-12 04:40:58 --> Router Class Initialized
INFO - 2021-01-12 04:40:58 --> Output Class Initialized
INFO - 2021-01-12 04:40:58 --> Security Class Initialized
DEBUG - 2021-01-12 04:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:40:58 --> Input Class Initialized
INFO - 2021-01-12 04:40:58 --> Language Class Initialized
INFO - 2021-01-12 04:40:58 --> Language Class Initialized
INFO - 2021-01-12 04:40:58 --> Config Class Initialized
INFO - 2021-01-12 04:40:58 --> Loader Class Initialized
INFO - 2021-01-12 04:40:58 --> Helper loaded: url_helper
INFO - 2021-01-12 04:40:58 --> Helper loaded: file_helper
INFO - 2021-01-12 04:40:58 --> Helper loaded: form_helper
INFO - 2021-01-12 04:40:58 --> Helper loaded: my_helper
INFO - 2021-01-12 04:40:58 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:40:58 --> Controller Class Initialized
DEBUG - 2021-01-12 04:40:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:40:58 --> Final output sent to browser
DEBUG - 2021-01-12 04:40:58 --> Total execution time: 0.3118
INFO - 2021-01-12 04:41:32 --> Config Class Initialized
INFO - 2021-01-12 04:41:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:41:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:41:32 --> Utf8 Class Initialized
INFO - 2021-01-12 04:41:32 --> URI Class Initialized
INFO - 2021-01-12 04:41:32 --> Router Class Initialized
INFO - 2021-01-12 04:41:32 --> Output Class Initialized
INFO - 2021-01-12 04:41:32 --> Security Class Initialized
DEBUG - 2021-01-12 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:41:32 --> Input Class Initialized
INFO - 2021-01-12 04:41:32 --> Language Class Initialized
INFO - 2021-01-12 04:41:32 --> Language Class Initialized
INFO - 2021-01-12 04:41:32 --> Config Class Initialized
INFO - 2021-01-12 04:41:32 --> Loader Class Initialized
INFO - 2021-01-12 04:41:32 --> Helper loaded: url_helper
INFO - 2021-01-12 04:41:32 --> Helper loaded: file_helper
INFO - 2021-01-12 04:41:32 --> Helper loaded: form_helper
INFO - 2021-01-12 04:41:32 --> Helper loaded: my_helper
INFO - 2021-01-12 04:41:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:41:32 --> Controller Class Initialized
DEBUG - 2021-01-12 04:41:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:41:32 --> Final output sent to browser
DEBUG - 2021-01-12 04:41:32 --> Total execution time: 0.3440
INFO - 2021-01-12 04:42:08 --> Config Class Initialized
INFO - 2021-01-12 04:42:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:42:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:42:08 --> Utf8 Class Initialized
INFO - 2021-01-12 04:42:08 --> URI Class Initialized
INFO - 2021-01-12 04:42:08 --> Router Class Initialized
INFO - 2021-01-12 04:42:08 --> Output Class Initialized
INFO - 2021-01-12 04:42:08 --> Security Class Initialized
DEBUG - 2021-01-12 04:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:42:08 --> Input Class Initialized
INFO - 2021-01-12 04:42:08 --> Language Class Initialized
INFO - 2021-01-12 04:42:08 --> Language Class Initialized
INFO - 2021-01-12 04:42:08 --> Config Class Initialized
INFO - 2021-01-12 04:42:08 --> Loader Class Initialized
INFO - 2021-01-12 04:42:08 --> Helper loaded: url_helper
INFO - 2021-01-12 04:42:09 --> Helper loaded: file_helper
INFO - 2021-01-12 04:42:09 --> Helper loaded: form_helper
INFO - 2021-01-12 04:42:09 --> Helper loaded: my_helper
INFO - 2021-01-12 04:42:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:42:09 --> Controller Class Initialized
DEBUG - 2021-01-12 04:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:42:09 --> Final output sent to browser
DEBUG - 2021-01-12 04:42:09 --> Total execution time: 0.3171
INFO - 2021-01-12 04:42:32 --> Config Class Initialized
INFO - 2021-01-12 04:42:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:42:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:42:32 --> Utf8 Class Initialized
INFO - 2021-01-12 04:42:32 --> URI Class Initialized
INFO - 2021-01-12 04:42:32 --> Router Class Initialized
INFO - 2021-01-12 04:42:32 --> Output Class Initialized
INFO - 2021-01-12 04:42:32 --> Security Class Initialized
DEBUG - 2021-01-12 04:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:42:32 --> Input Class Initialized
INFO - 2021-01-12 04:42:32 --> Language Class Initialized
INFO - 2021-01-12 04:42:32 --> Language Class Initialized
INFO - 2021-01-12 04:42:32 --> Config Class Initialized
INFO - 2021-01-12 04:42:32 --> Loader Class Initialized
INFO - 2021-01-12 04:42:32 --> Helper loaded: url_helper
INFO - 2021-01-12 04:42:32 --> Helper loaded: file_helper
INFO - 2021-01-12 04:42:32 --> Helper loaded: form_helper
INFO - 2021-01-12 04:42:32 --> Helper loaded: my_helper
INFO - 2021-01-12 04:42:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:42:32 --> Controller Class Initialized
DEBUG - 2021-01-12 04:42:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:42:32 --> Final output sent to browser
DEBUG - 2021-01-12 04:42:32 --> Total execution time: 0.3582
INFO - 2021-01-12 04:42:48 --> Config Class Initialized
INFO - 2021-01-12 04:42:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:42:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:42:48 --> Utf8 Class Initialized
INFO - 2021-01-12 04:42:48 --> URI Class Initialized
INFO - 2021-01-12 04:42:48 --> Router Class Initialized
INFO - 2021-01-12 04:42:48 --> Output Class Initialized
INFO - 2021-01-12 04:42:48 --> Security Class Initialized
DEBUG - 2021-01-12 04:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:42:48 --> Input Class Initialized
INFO - 2021-01-12 04:42:48 --> Language Class Initialized
INFO - 2021-01-12 04:42:48 --> Language Class Initialized
INFO - 2021-01-12 04:42:48 --> Config Class Initialized
INFO - 2021-01-12 04:42:48 --> Loader Class Initialized
INFO - 2021-01-12 04:42:48 --> Helper loaded: url_helper
INFO - 2021-01-12 04:42:48 --> Helper loaded: file_helper
INFO - 2021-01-12 04:42:48 --> Helper loaded: form_helper
INFO - 2021-01-12 04:42:48 --> Helper loaded: my_helper
INFO - 2021-01-12 04:42:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:42:48 --> Controller Class Initialized
DEBUG - 2021-01-12 04:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:42:48 --> Final output sent to browser
DEBUG - 2021-01-12 04:42:48 --> Total execution time: 0.3361
INFO - 2021-01-12 04:43:14 --> Config Class Initialized
INFO - 2021-01-12 04:43:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:43:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:43:14 --> Utf8 Class Initialized
INFO - 2021-01-12 04:43:14 --> URI Class Initialized
INFO - 2021-01-12 04:43:14 --> Router Class Initialized
INFO - 2021-01-12 04:43:14 --> Output Class Initialized
INFO - 2021-01-12 04:43:14 --> Security Class Initialized
DEBUG - 2021-01-12 04:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:43:14 --> Input Class Initialized
INFO - 2021-01-12 04:43:14 --> Language Class Initialized
INFO - 2021-01-12 04:43:14 --> Language Class Initialized
INFO - 2021-01-12 04:43:14 --> Config Class Initialized
INFO - 2021-01-12 04:43:14 --> Loader Class Initialized
INFO - 2021-01-12 04:43:14 --> Helper loaded: url_helper
INFO - 2021-01-12 04:43:14 --> Helper loaded: file_helper
INFO - 2021-01-12 04:43:14 --> Helper loaded: form_helper
INFO - 2021-01-12 04:43:14 --> Helper loaded: my_helper
INFO - 2021-01-12 04:43:14 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:43:14 --> Controller Class Initialized
DEBUG - 2021-01-12 04:43:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:43:14 --> Final output sent to browser
DEBUG - 2021-01-12 04:43:14 --> Total execution time: 0.3526
INFO - 2021-01-12 04:43:39 --> Config Class Initialized
INFO - 2021-01-12 04:43:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:43:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:43:39 --> Utf8 Class Initialized
INFO - 2021-01-12 04:43:39 --> URI Class Initialized
INFO - 2021-01-12 04:43:39 --> Router Class Initialized
INFO - 2021-01-12 04:43:39 --> Output Class Initialized
INFO - 2021-01-12 04:43:39 --> Security Class Initialized
DEBUG - 2021-01-12 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:43:39 --> Input Class Initialized
INFO - 2021-01-12 04:43:39 --> Language Class Initialized
INFO - 2021-01-12 04:43:39 --> Language Class Initialized
INFO - 2021-01-12 04:43:39 --> Config Class Initialized
INFO - 2021-01-12 04:43:39 --> Loader Class Initialized
INFO - 2021-01-12 04:43:39 --> Helper loaded: url_helper
INFO - 2021-01-12 04:43:39 --> Helper loaded: file_helper
INFO - 2021-01-12 04:43:39 --> Helper loaded: form_helper
INFO - 2021-01-12 04:43:39 --> Helper loaded: my_helper
INFO - 2021-01-12 04:43:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:43:39 --> Controller Class Initialized
DEBUG - 2021-01-12 04:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:43:39 --> Final output sent to browser
DEBUG - 2021-01-12 04:43:39 --> Total execution time: 0.3474
INFO - 2021-01-12 04:43:51 --> Config Class Initialized
INFO - 2021-01-12 04:43:51 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:43:51 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:43:51 --> Utf8 Class Initialized
INFO - 2021-01-12 04:43:51 --> URI Class Initialized
INFO - 2021-01-12 04:43:51 --> Router Class Initialized
INFO - 2021-01-12 04:43:51 --> Output Class Initialized
INFO - 2021-01-12 04:43:51 --> Security Class Initialized
DEBUG - 2021-01-12 04:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:43:51 --> Input Class Initialized
INFO - 2021-01-12 04:43:51 --> Language Class Initialized
INFO - 2021-01-12 04:43:51 --> Language Class Initialized
INFO - 2021-01-12 04:43:51 --> Config Class Initialized
INFO - 2021-01-12 04:43:51 --> Loader Class Initialized
INFO - 2021-01-12 04:43:51 --> Helper loaded: url_helper
INFO - 2021-01-12 04:43:51 --> Helper loaded: file_helper
INFO - 2021-01-12 04:43:51 --> Helper loaded: form_helper
INFO - 2021-01-12 04:43:51 --> Helper loaded: my_helper
INFO - 2021-01-12 04:43:51 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:43:51 --> Controller Class Initialized
DEBUG - 2021-01-12 04:43:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:43:51 --> Final output sent to browser
DEBUG - 2021-01-12 04:43:51 --> Total execution time: 0.3430
INFO - 2021-01-12 04:44:03 --> Config Class Initialized
INFO - 2021-01-12 04:44:03 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:44:03 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:44:03 --> Utf8 Class Initialized
INFO - 2021-01-12 04:44:03 --> URI Class Initialized
INFO - 2021-01-12 04:44:03 --> Router Class Initialized
INFO - 2021-01-12 04:44:03 --> Output Class Initialized
INFO - 2021-01-12 04:44:03 --> Security Class Initialized
DEBUG - 2021-01-12 04:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:44:03 --> Input Class Initialized
INFO - 2021-01-12 04:44:03 --> Language Class Initialized
INFO - 2021-01-12 04:44:03 --> Language Class Initialized
INFO - 2021-01-12 04:44:03 --> Config Class Initialized
INFO - 2021-01-12 04:44:03 --> Loader Class Initialized
INFO - 2021-01-12 04:44:03 --> Helper loaded: url_helper
INFO - 2021-01-12 04:44:03 --> Helper loaded: file_helper
INFO - 2021-01-12 04:44:03 --> Helper loaded: form_helper
INFO - 2021-01-12 04:44:03 --> Helper loaded: my_helper
INFO - 2021-01-12 04:44:03 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:44:03 --> Controller Class Initialized
DEBUG - 2021-01-12 04:44:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:44:03 --> Final output sent to browser
DEBUG - 2021-01-12 04:44:03 --> Total execution time: 0.3202
INFO - 2021-01-12 04:44:26 --> Config Class Initialized
INFO - 2021-01-12 04:44:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:44:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:44:26 --> Utf8 Class Initialized
INFO - 2021-01-12 04:44:26 --> URI Class Initialized
INFO - 2021-01-12 04:44:26 --> Router Class Initialized
INFO - 2021-01-12 04:44:26 --> Output Class Initialized
INFO - 2021-01-12 04:44:26 --> Security Class Initialized
DEBUG - 2021-01-12 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:44:26 --> Input Class Initialized
INFO - 2021-01-12 04:44:26 --> Language Class Initialized
INFO - 2021-01-12 04:44:26 --> Language Class Initialized
INFO - 2021-01-12 04:44:26 --> Config Class Initialized
INFO - 2021-01-12 04:44:26 --> Loader Class Initialized
INFO - 2021-01-12 04:44:26 --> Helper loaded: url_helper
INFO - 2021-01-12 04:44:26 --> Helper loaded: file_helper
INFO - 2021-01-12 04:44:26 --> Helper loaded: form_helper
INFO - 2021-01-12 04:44:26 --> Helper loaded: my_helper
INFO - 2021-01-12 04:44:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:44:27 --> Controller Class Initialized
DEBUG - 2021-01-12 04:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:44:27 --> Final output sent to browser
DEBUG - 2021-01-12 04:44:27 --> Total execution time: 0.3318
INFO - 2021-01-12 04:44:29 --> Config Class Initialized
INFO - 2021-01-12 04:44:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:44:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:44:29 --> Utf8 Class Initialized
INFO - 2021-01-12 04:44:29 --> URI Class Initialized
INFO - 2021-01-12 04:44:29 --> Router Class Initialized
INFO - 2021-01-12 04:44:29 --> Output Class Initialized
INFO - 2021-01-12 04:44:29 --> Security Class Initialized
DEBUG - 2021-01-12 04:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:44:29 --> Input Class Initialized
INFO - 2021-01-12 04:44:29 --> Language Class Initialized
INFO - 2021-01-12 04:44:29 --> Language Class Initialized
INFO - 2021-01-12 04:44:29 --> Config Class Initialized
INFO - 2021-01-12 04:44:29 --> Loader Class Initialized
INFO - 2021-01-12 04:44:29 --> Helper loaded: url_helper
INFO - 2021-01-12 04:44:29 --> Helper loaded: file_helper
INFO - 2021-01-12 04:44:29 --> Helper loaded: form_helper
INFO - 2021-01-12 04:44:29 --> Helper loaded: my_helper
INFO - 2021-01-12 04:44:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:44:29 --> Controller Class Initialized
DEBUG - 2021-01-12 04:44:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:44:29 --> Final output sent to browser
DEBUG - 2021-01-12 04:44:29 --> Total execution time: 0.2878
INFO - 2021-01-12 04:44:50 --> Config Class Initialized
INFO - 2021-01-12 04:44:50 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:44:50 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:44:50 --> Utf8 Class Initialized
INFO - 2021-01-12 04:44:50 --> URI Class Initialized
INFO - 2021-01-12 04:44:50 --> Router Class Initialized
INFO - 2021-01-12 04:44:50 --> Output Class Initialized
INFO - 2021-01-12 04:44:50 --> Security Class Initialized
DEBUG - 2021-01-12 04:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:44:50 --> Input Class Initialized
INFO - 2021-01-12 04:44:50 --> Language Class Initialized
INFO - 2021-01-12 04:44:50 --> Language Class Initialized
INFO - 2021-01-12 04:44:50 --> Config Class Initialized
INFO - 2021-01-12 04:44:50 --> Loader Class Initialized
INFO - 2021-01-12 04:44:50 --> Helper loaded: url_helper
INFO - 2021-01-12 04:44:50 --> Helper loaded: file_helper
INFO - 2021-01-12 04:44:50 --> Helper loaded: form_helper
INFO - 2021-01-12 04:44:50 --> Helper loaded: my_helper
INFO - 2021-01-12 04:44:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:44:50 --> Controller Class Initialized
DEBUG - 2021-01-12 04:44:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:44:50 --> Final output sent to browser
DEBUG - 2021-01-12 04:44:50 --> Total execution time: 0.3193
INFO - 2021-01-12 04:45:06 --> Config Class Initialized
INFO - 2021-01-12 04:45:06 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:45:06 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:45:06 --> Utf8 Class Initialized
INFO - 2021-01-12 04:45:06 --> URI Class Initialized
INFO - 2021-01-12 04:45:06 --> Router Class Initialized
INFO - 2021-01-12 04:45:06 --> Output Class Initialized
INFO - 2021-01-12 04:45:06 --> Security Class Initialized
DEBUG - 2021-01-12 04:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:45:06 --> Input Class Initialized
INFO - 2021-01-12 04:45:06 --> Language Class Initialized
INFO - 2021-01-12 04:45:06 --> Language Class Initialized
INFO - 2021-01-12 04:45:06 --> Config Class Initialized
INFO - 2021-01-12 04:45:06 --> Loader Class Initialized
INFO - 2021-01-12 04:45:06 --> Helper loaded: url_helper
INFO - 2021-01-12 04:45:06 --> Helper loaded: file_helper
INFO - 2021-01-12 04:45:06 --> Helper loaded: form_helper
INFO - 2021-01-12 04:45:06 --> Helper loaded: my_helper
INFO - 2021-01-12 04:45:06 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:45:06 --> Controller Class Initialized
DEBUG - 2021-01-12 04:45:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:45:06 --> Final output sent to browser
DEBUG - 2021-01-12 04:45:06 --> Total execution time: 0.3187
INFO - 2021-01-12 04:45:52 --> Config Class Initialized
INFO - 2021-01-12 04:45:52 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:45:52 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:45:52 --> Utf8 Class Initialized
INFO - 2021-01-12 04:45:52 --> URI Class Initialized
INFO - 2021-01-12 04:45:52 --> Router Class Initialized
INFO - 2021-01-12 04:45:52 --> Output Class Initialized
INFO - 2021-01-12 04:45:52 --> Security Class Initialized
DEBUG - 2021-01-12 04:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:45:52 --> Input Class Initialized
INFO - 2021-01-12 04:45:52 --> Language Class Initialized
INFO - 2021-01-12 04:45:52 --> Language Class Initialized
INFO - 2021-01-12 04:45:52 --> Config Class Initialized
INFO - 2021-01-12 04:45:52 --> Loader Class Initialized
INFO - 2021-01-12 04:45:52 --> Helper loaded: url_helper
INFO - 2021-01-12 04:45:52 --> Helper loaded: file_helper
INFO - 2021-01-12 04:45:52 --> Helper loaded: form_helper
INFO - 2021-01-12 04:45:52 --> Helper loaded: my_helper
INFO - 2021-01-12 04:45:52 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:45:52 --> Controller Class Initialized
DEBUG - 2021-01-12 04:45:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:45:52 --> Final output sent to browser
DEBUG - 2021-01-12 04:45:52 --> Total execution time: 0.3257
INFO - 2021-01-12 04:46:37 --> Config Class Initialized
INFO - 2021-01-12 04:46:37 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:46:37 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:46:37 --> Utf8 Class Initialized
INFO - 2021-01-12 04:46:37 --> URI Class Initialized
INFO - 2021-01-12 04:46:37 --> Router Class Initialized
INFO - 2021-01-12 04:46:37 --> Output Class Initialized
INFO - 2021-01-12 04:46:37 --> Security Class Initialized
DEBUG - 2021-01-12 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:46:37 --> Input Class Initialized
INFO - 2021-01-12 04:46:37 --> Language Class Initialized
INFO - 2021-01-12 04:46:37 --> Language Class Initialized
INFO - 2021-01-12 04:46:37 --> Config Class Initialized
INFO - 2021-01-12 04:46:37 --> Loader Class Initialized
INFO - 2021-01-12 04:46:37 --> Helper loaded: url_helper
INFO - 2021-01-12 04:46:37 --> Helper loaded: file_helper
INFO - 2021-01-12 04:46:37 --> Helper loaded: form_helper
INFO - 2021-01-12 04:46:37 --> Helper loaded: my_helper
INFO - 2021-01-12 04:46:37 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:46:37 --> Controller Class Initialized
DEBUG - 2021-01-12 04:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:46:37 --> Final output sent to browser
DEBUG - 2021-01-12 04:46:37 --> Total execution time: 0.3362
INFO - 2021-01-12 04:46:57 --> Config Class Initialized
INFO - 2021-01-12 04:46:57 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:46:57 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:46:57 --> Utf8 Class Initialized
INFO - 2021-01-12 04:46:57 --> URI Class Initialized
INFO - 2021-01-12 04:46:57 --> Router Class Initialized
INFO - 2021-01-12 04:46:57 --> Output Class Initialized
INFO - 2021-01-12 04:46:57 --> Security Class Initialized
DEBUG - 2021-01-12 04:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:46:57 --> Input Class Initialized
INFO - 2021-01-12 04:46:57 --> Language Class Initialized
INFO - 2021-01-12 04:46:57 --> Language Class Initialized
INFO - 2021-01-12 04:46:57 --> Config Class Initialized
INFO - 2021-01-12 04:46:57 --> Loader Class Initialized
INFO - 2021-01-12 04:46:57 --> Helper loaded: url_helper
INFO - 2021-01-12 04:46:57 --> Helper loaded: file_helper
INFO - 2021-01-12 04:46:57 --> Helper loaded: form_helper
INFO - 2021-01-12 04:46:57 --> Helper loaded: my_helper
INFO - 2021-01-12 04:46:57 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:46:57 --> Controller Class Initialized
DEBUG - 2021-01-12 04:46:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:46:57 --> Final output sent to browser
DEBUG - 2021-01-12 04:46:57 --> Total execution time: 0.2638
INFO - 2021-01-12 04:47:00 --> Config Class Initialized
INFO - 2021-01-12 04:47:00 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:47:00 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:47:00 --> Utf8 Class Initialized
INFO - 2021-01-12 04:47:00 --> URI Class Initialized
INFO - 2021-01-12 04:47:00 --> Router Class Initialized
INFO - 2021-01-12 04:47:00 --> Output Class Initialized
INFO - 2021-01-12 04:47:00 --> Security Class Initialized
DEBUG - 2021-01-12 04:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:47:00 --> Input Class Initialized
INFO - 2021-01-12 04:47:00 --> Language Class Initialized
INFO - 2021-01-12 04:47:00 --> Language Class Initialized
INFO - 2021-01-12 04:47:00 --> Config Class Initialized
INFO - 2021-01-12 04:47:00 --> Loader Class Initialized
INFO - 2021-01-12 04:47:00 --> Helper loaded: url_helper
INFO - 2021-01-12 04:47:00 --> Helper loaded: file_helper
INFO - 2021-01-12 04:47:00 --> Helper loaded: form_helper
INFO - 2021-01-12 04:47:00 --> Helper loaded: my_helper
INFO - 2021-01-12 04:47:00 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:47:00 --> Controller Class Initialized
DEBUG - 2021-01-12 04:47:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:47:00 --> Final output sent to browser
DEBUG - 2021-01-12 04:47:00 --> Total execution time: 0.3180
INFO - 2021-01-12 04:48:28 --> Config Class Initialized
INFO - 2021-01-12 04:48:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:48:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:48:28 --> Utf8 Class Initialized
INFO - 2021-01-12 04:48:28 --> URI Class Initialized
INFO - 2021-01-12 04:48:28 --> Router Class Initialized
INFO - 2021-01-12 04:48:28 --> Output Class Initialized
INFO - 2021-01-12 04:48:28 --> Security Class Initialized
DEBUG - 2021-01-12 04:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:48:28 --> Input Class Initialized
INFO - 2021-01-12 04:48:28 --> Language Class Initialized
INFO - 2021-01-12 04:48:28 --> Language Class Initialized
INFO - 2021-01-12 04:48:28 --> Config Class Initialized
INFO - 2021-01-12 04:48:28 --> Loader Class Initialized
INFO - 2021-01-12 04:48:28 --> Helper loaded: url_helper
INFO - 2021-01-12 04:48:28 --> Helper loaded: file_helper
INFO - 2021-01-12 04:48:28 --> Helper loaded: form_helper
INFO - 2021-01-12 04:48:28 --> Helper loaded: my_helper
INFO - 2021-01-12 04:48:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:48:28 --> Controller Class Initialized
DEBUG - 2021-01-12 04:48:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:48:28 --> Final output sent to browser
DEBUG - 2021-01-12 04:48:28 --> Total execution time: 0.3400
INFO - 2021-01-12 04:49:16 --> Config Class Initialized
INFO - 2021-01-12 04:49:16 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:49:16 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:49:16 --> Utf8 Class Initialized
INFO - 2021-01-12 04:49:16 --> URI Class Initialized
INFO - 2021-01-12 04:49:16 --> Router Class Initialized
INFO - 2021-01-12 04:49:16 --> Output Class Initialized
INFO - 2021-01-12 04:49:16 --> Security Class Initialized
DEBUG - 2021-01-12 04:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:49:16 --> Input Class Initialized
INFO - 2021-01-12 04:49:16 --> Language Class Initialized
INFO - 2021-01-12 04:49:16 --> Language Class Initialized
INFO - 2021-01-12 04:49:16 --> Config Class Initialized
INFO - 2021-01-12 04:49:16 --> Loader Class Initialized
INFO - 2021-01-12 04:49:16 --> Helper loaded: url_helper
INFO - 2021-01-12 04:49:16 --> Helper loaded: file_helper
INFO - 2021-01-12 04:49:16 --> Helper loaded: form_helper
INFO - 2021-01-12 04:49:16 --> Helper loaded: my_helper
INFO - 2021-01-12 04:49:16 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:49:16 --> Controller Class Initialized
DEBUG - 2021-01-12 04:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:49:16 --> Final output sent to browser
DEBUG - 2021-01-12 04:49:16 --> Total execution time: 0.3114
INFO - 2021-01-12 04:50:04 --> Config Class Initialized
INFO - 2021-01-12 04:50:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:50:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:50:04 --> Utf8 Class Initialized
INFO - 2021-01-12 04:50:04 --> URI Class Initialized
INFO - 2021-01-12 04:50:04 --> Router Class Initialized
INFO - 2021-01-12 04:50:04 --> Output Class Initialized
INFO - 2021-01-12 04:50:04 --> Security Class Initialized
DEBUG - 2021-01-12 04:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:50:04 --> Input Class Initialized
INFO - 2021-01-12 04:50:04 --> Language Class Initialized
INFO - 2021-01-12 04:50:04 --> Language Class Initialized
INFO - 2021-01-12 04:50:04 --> Config Class Initialized
INFO - 2021-01-12 04:50:05 --> Loader Class Initialized
INFO - 2021-01-12 04:50:05 --> Helper loaded: url_helper
INFO - 2021-01-12 04:50:05 --> Helper loaded: file_helper
INFO - 2021-01-12 04:50:05 --> Helper loaded: form_helper
INFO - 2021-01-12 04:50:05 --> Helper loaded: my_helper
INFO - 2021-01-12 04:50:05 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:50:05 --> Controller Class Initialized
DEBUG - 2021-01-12 04:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:50:05 --> Final output sent to browser
DEBUG - 2021-01-12 04:50:05 --> Total execution time: 0.2489
INFO - 2021-01-12 04:50:32 --> Config Class Initialized
INFO - 2021-01-12 04:50:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:50:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:50:32 --> Utf8 Class Initialized
INFO - 2021-01-12 04:50:32 --> URI Class Initialized
INFO - 2021-01-12 04:50:32 --> Router Class Initialized
INFO - 2021-01-12 04:50:32 --> Output Class Initialized
INFO - 2021-01-12 04:50:32 --> Security Class Initialized
DEBUG - 2021-01-12 04:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:50:32 --> Input Class Initialized
INFO - 2021-01-12 04:50:32 --> Language Class Initialized
INFO - 2021-01-12 04:50:32 --> Language Class Initialized
INFO - 2021-01-12 04:50:32 --> Config Class Initialized
INFO - 2021-01-12 04:50:32 --> Loader Class Initialized
INFO - 2021-01-12 04:50:32 --> Helper loaded: url_helper
INFO - 2021-01-12 04:50:32 --> Helper loaded: file_helper
INFO - 2021-01-12 04:50:32 --> Helper loaded: form_helper
INFO - 2021-01-12 04:50:32 --> Helper loaded: my_helper
INFO - 2021-01-12 04:50:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:50:32 --> Controller Class Initialized
DEBUG - 2021-01-12 04:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:50:33 --> Final output sent to browser
DEBUG - 2021-01-12 04:50:33 --> Total execution time: 0.3256
INFO - 2021-01-12 04:51:04 --> Config Class Initialized
INFO - 2021-01-12 04:51:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:51:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:51:04 --> Utf8 Class Initialized
INFO - 2021-01-12 04:51:04 --> URI Class Initialized
INFO - 2021-01-12 04:51:04 --> Router Class Initialized
INFO - 2021-01-12 04:51:04 --> Output Class Initialized
INFO - 2021-01-12 04:51:04 --> Security Class Initialized
DEBUG - 2021-01-12 04:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:51:04 --> Input Class Initialized
INFO - 2021-01-12 04:51:04 --> Language Class Initialized
INFO - 2021-01-12 04:51:04 --> Language Class Initialized
INFO - 2021-01-12 04:51:04 --> Config Class Initialized
INFO - 2021-01-12 04:51:04 --> Loader Class Initialized
INFO - 2021-01-12 04:51:04 --> Helper loaded: url_helper
INFO - 2021-01-12 04:51:04 --> Helper loaded: file_helper
INFO - 2021-01-12 04:51:04 --> Helper loaded: form_helper
INFO - 2021-01-12 04:51:04 --> Helper loaded: my_helper
INFO - 2021-01-12 04:51:05 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:51:05 --> Controller Class Initialized
DEBUG - 2021-01-12 04:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:51:05 --> Final output sent to browser
DEBUG - 2021-01-12 04:51:05 --> Total execution time: 0.3391
INFO - 2021-01-12 04:52:01 --> Config Class Initialized
INFO - 2021-01-12 04:52:01 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:52:01 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:52:01 --> Utf8 Class Initialized
INFO - 2021-01-12 04:52:01 --> URI Class Initialized
INFO - 2021-01-12 04:52:01 --> Router Class Initialized
INFO - 2021-01-12 04:52:01 --> Output Class Initialized
INFO - 2021-01-12 04:52:01 --> Security Class Initialized
DEBUG - 2021-01-12 04:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:52:01 --> Input Class Initialized
INFO - 2021-01-12 04:52:01 --> Language Class Initialized
INFO - 2021-01-12 04:52:01 --> Language Class Initialized
INFO - 2021-01-12 04:52:01 --> Config Class Initialized
INFO - 2021-01-12 04:52:01 --> Loader Class Initialized
INFO - 2021-01-12 04:52:01 --> Helper loaded: url_helper
INFO - 2021-01-12 04:52:01 --> Helper loaded: file_helper
INFO - 2021-01-12 04:52:01 --> Helper loaded: form_helper
INFO - 2021-01-12 04:52:01 --> Helper loaded: my_helper
INFO - 2021-01-12 04:52:01 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:52:01 --> Controller Class Initialized
DEBUG - 2021-01-12 04:52:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:52:01 --> Final output sent to browser
DEBUG - 2021-01-12 04:52:01 --> Total execution time: 0.3208
INFO - 2021-01-12 04:52:34 --> Config Class Initialized
INFO - 2021-01-12 04:52:34 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:52:34 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:52:34 --> Utf8 Class Initialized
INFO - 2021-01-12 04:52:34 --> URI Class Initialized
INFO - 2021-01-12 04:52:34 --> Router Class Initialized
INFO - 2021-01-12 04:52:34 --> Output Class Initialized
INFO - 2021-01-12 04:52:34 --> Security Class Initialized
DEBUG - 2021-01-12 04:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:52:34 --> Input Class Initialized
INFO - 2021-01-12 04:52:34 --> Language Class Initialized
INFO - 2021-01-12 04:52:34 --> Language Class Initialized
INFO - 2021-01-12 04:52:34 --> Config Class Initialized
INFO - 2021-01-12 04:52:34 --> Loader Class Initialized
INFO - 2021-01-12 04:52:34 --> Helper loaded: url_helper
INFO - 2021-01-12 04:52:34 --> Helper loaded: file_helper
INFO - 2021-01-12 04:52:34 --> Helper loaded: form_helper
INFO - 2021-01-12 04:52:34 --> Helper loaded: my_helper
INFO - 2021-01-12 04:52:34 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:52:34 --> Controller Class Initialized
DEBUG - 2021-01-12 04:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:52:34 --> Final output sent to browser
DEBUG - 2021-01-12 04:52:34 --> Total execution time: 0.3333
INFO - 2021-01-12 04:52:46 --> Config Class Initialized
INFO - 2021-01-12 04:52:46 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:52:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:52:46 --> Utf8 Class Initialized
INFO - 2021-01-12 04:52:46 --> URI Class Initialized
INFO - 2021-01-12 04:52:46 --> Router Class Initialized
INFO - 2021-01-12 04:52:46 --> Output Class Initialized
INFO - 2021-01-12 04:52:46 --> Security Class Initialized
DEBUG - 2021-01-12 04:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:52:46 --> Input Class Initialized
INFO - 2021-01-12 04:52:46 --> Language Class Initialized
INFO - 2021-01-12 04:52:46 --> Language Class Initialized
INFO - 2021-01-12 04:52:46 --> Config Class Initialized
INFO - 2021-01-12 04:52:46 --> Loader Class Initialized
INFO - 2021-01-12 04:52:46 --> Helper loaded: url_helper
INFO - 2021-01-12 04:52:46 --> Helper loaded: file_helper
INFO - 2021-01-12 04:52:46 --> Helper loaded: form_helper
INFO - 2021-01-12 04:52:46 --> Helper loaded: my_helper
INFO - 2021-01-12 04:52:46 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:52:46 --> Controller Class Initialized
DEBUG - 2021-01-12 04:52:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:52:46 --> Final output sent to browser
DEBUG - 2021-01-12 04:52:46 --> Total execution time: 0.3300
INFO - 2021-01-12 04:53:05 --> Config Class Initialized
INFO - 2021-01-12 04:53:05 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:53:05 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:53:05 --> Utf8 Class Initialized
INFO - 2021-01-12 04:53:05 --> URI Class Initialized
INFO - 2021-01-12 04:53:05 --> Router Class Initialized
INFO - 2021-01-12 04:53:05 --> Output Class Initialized
INFO - 2021-01-12 04:53:05 --> Security Class Initialized
DEBUG - 2021-01-12 04:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:53:05 --> Input Class Initialized
INFO - 2021-01-12 04:53:05 --> Language Class Initialized
INFO - 2021-01-12 04:53:05 --> Language Class Initialized
INFO - 2021-01-12 04:53:05 --> Config Class Initialized
INFO - 2021-01-12 04:53:05 --> Loader Class Initialized
INFO - 2021-01-12 04:53:05 --> Helper loaded: url_helper
INFO - 2021-01-12 04:53:05 --> Helper loaded: file_helper
INFO - 2021-01-12 04:53:05 --> Helper loaded: form_helper
INFO - 2021-01-12 04:53:05 --> Helper loaded: my_helper
INFO - 2021-01-12 04:53:05 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:53:05 --> Controller Class Initialized
DEBUG - 2021-01-12 04:53:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:53:05 --> Final output sent to browser
DEBUG - 2021-01-12 04:53:05 --> Total execution time: 0.3447
INFO - 2021-01-12 04:53:44 --> Config Class Initialized
INFO - 2021-01-12 04:53:44 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:53:44 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:53:44 --> Utf8 Class Initialized
INFO - 2021-01-12 04:53:44 --> URI Class Initialized
INFO - 2021-01-12 04:53:44 --> Router Class Initialized
INFO - 2021-01-12 04:53:44 --> Output Class Initialized
INFO - 2021-01-12 04:53:44 --> Security Class Initialized
DEBUG - 2021-01-12 04:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:53:44 --> Input Class Initialized
INFO - 2021-01-12 04:53:44 --> Language Class Initialized
INFO - 2021-01-12 04:53:44 --> Language Class Initialized
INFO - 2021-01-12 04:53:44 --> Config Class Initialized
INFO - 2021-01-12 04:53:44 --> Loader Class Initialized
INFO - 2021-01-12 04:53:44 --> Helper loaded: url_helper
INFO - 2021-01-12 04:53:44 --> Helper loaded: file_helper
INFO - 2021-01-12 04:53:44 --> Helper loaded: form_helper
INFO - 2021-01-12 04:53:44 --> Helper loaded: my_helper
INFO - 2021-01-12 04:53:44 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:53:44 --> Controller Class Initialized
DEBUG - 2021-01-12 04:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:53:44 --> Final output sent to browser
DEBUG - 2021-01-12 04:53:44 --> Total execution time: 0.3205
INFO - 2021-01-12 04:54:26 --> Config Class Initialized
INFO - 2021-01-12 04:54:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:54:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:54:26 --> Utf8 Class Initialized
INFO - 2021-01-12 04:54:26 --> URI Class Initialized
INFO - 2021-01-12 04:54:26 --> Router Class Initialized
INFO - 2021-01-12 04:54:26 --> Output Class Initialized
INFO - 2021-01-12 04:54:26 --> Security Class Initialized
DEBUG - 2021-01-12 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:54:26 --> Input Class Initialized
INFO - 2021-01-12 04:54:26 --> Language Class Initialized
INFO - 2021-01-12 04:54:26 --> Language Class Initialized
INFO - 2021-01-12 04:54:26 --> Config Class Initialized
INFO - 2021-01-12 04:54:26 --> Loader Class Initialized
INFO - 2021-01-12 04:54:26 --> Helper loaded: url_helper
INFO - 2021-01-12 04:54:26 --> Helper loaded: file_helper
INFO - 2021-01-12 04:54:26 --> Helper loaded: form_helper
INFO - 2021-01-12 04:54:26 --> Helper loaded: my_helper
INFO - 2021-01-12 04:54:26 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:54:26 --> Controller Class Initialized
DEBUG - 2021-01-12 04:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:54:26 --> Final output sent to browser
DEBUG - 2021-01-12 04:54:26 --> Total execution time: 0.3676
INFO - 2021-01-12 04:54:58 --> Config Class Initialized
INFO - 2021-01-12 04:54:58 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:54:58 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:54:58 --> Utf8 Class Initialized
INFO - 2021-01-12 04:54:58 --> URI Class Initialized
INFO - 2021-01-12 04:54:58 --> Router Class Initialized
INFO - 2021-01-12 04:54:58 --> Output Class Initialized
INFO - 2021-01-12 04:54:58 --> Security Class Initialized
DEBUG - 2021-01-12 04:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:54:58 --> Input Class Initialized
INFO - 2021-01-12 04:54:58 --> Language Class Initialized
INFO - 2021-01-12 04:54:58 --> Language Class Initialized
INFO - 2021-01-12 04:54:58 --> Config Class Initialized
INFO - 2021-01-12 04:54:58 --> Loader Class Initialized
INFO - 2021-01-12 04:54:58 --> Helper loaded: url_helper
INFO - 2021-01-12 04:54:58 --> Helper loaded: file_helper
INFO - 2021-01-12 04:54:58 --> Helper loaded: form_helper
INFO - 2021-01-12 04:54:58 --> Helper loaded: my_helper
INFO - 2021-01-12 04:54:58 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:54:58 --> Controller Class Initialized
DEBUG - 2021-01-12 04:54:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:54:58 --> Final output sent to browser
DEBUG - 2021-01-12 04:54:58 --> Total execution time: 0.3391
INFO - 2021-01-12 04:55:25 --> Config Class Initialized
INFO - 2021-01-12 04:55:25 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:55:25 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:55:25 --> Utf8 Class Initialized
INFO - 2021-01-12 04:55:25 --> URI Class Initialized
INFO - 2021-01-12 04:55:25 --> Router Class Initialized
INFO - 2021-01-12 04:55:25 --> Output Class Initialized
INFO - 2021-01-12 04:55:25 --> Security Class Initialized
DEBUG - 2021-01-12 04:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:55:25 --> Input Class Initialized
INFO - 2021-01-12 04:55:25 --> Language Class Initialized
INFO - 2021-01-12 04:55:25 --> Language Class Initialized
INFO - 2021-01-12 04:55:25 --> Config Class Initialized
INFO - 2021-01-12 04:55:25 --> Loader Class Initialized
INFO - 2021-01-12 04:55:25 --> Helper loaded: url_helper
INFO - 2021-01-12 04:55:25 --> Helper loaded: file_helper
INFO - 2021-01-12 04:55:25 --> Helper loaded: form_helper
INFO - 2021-01-12 04:55:25 --> Helper loaded: my_helper
INFO - 2021-01-12 04:55:25 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:55:25 --> Controller Class Initialized
DEBUG - 2021-01-12 04:55:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:55:25 --> Final output sent to browser
DEBUG - 2021-01-12 04:55:25 --> Total execution time: 0.3673
INFO - 2021-01-12 04:55:29 --> Config Class Initialized
INFO - 2021-01-12 04:55:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:55:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:55:29 --> Utf8 Class Initialized
INFO - 2021-01-12 04:55:29 --> URI Class Initialized
INFO - 2021-01-12 04:55:29 --> Router Class Initialized
INFO - 2021-01-12 04:55:29 --> Output Class Initialized
INFO - 2021-01-12 04:55:29 --> Security Class Initialized
DEBUG - 2021-01-12 04:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:55:29 --> Input Class Initialized
INFO - 2021-01-12 04:55:29 --> Language Class Initialized
INFO - 2021-01-12 04:55:29 --> Language Class Initialized
INFO - 2021-01-12 04:55:29 --> Config Class Initialized
INFO - 2021-01-12 04:55:29 --> Loader Class Initialized
INFO - 2021-01-12 04:55:29 --> Helper loaded: url_helper
INFO - 2021-01-12 04:55:29 --> Helper loaded: file_helper
INFO - 2021-01-12 04:55:29 --> Helper loaded: form_helper
INFO - 2021-01-12 04:55:29 --> Helper loaded: my_helper
INFO - 2021-01-12 04:55:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:55:29 --> Controller Class Initialized
DEBUG - 2021-01-12 04:55:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:55:30 --> Final output sent to browser
DEBUG - 2021-01-12 04:55:30 --> Total execution time: 0.2682
INFO - 2021-01-12 04:55:52 --> Config Class Initialized
INFO - 2021-01-12 04:55:52 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:55:52 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:55:52 --> Utf8 Class Initialized
INFO - 2021-01-12 04:55:52 --> URI Class Initialized
INFO - 2021-01-12 04:55:52 --> Router Class Initialized
INFO - 2021-01-12 04:55:52 --> Output Class Initialized
INFO - 2021-01-12 04:55:52 --> Security Class Initialized
DEBUG - 2021-01-12 04:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:55:52 --> Input Class Initialized
INFO - 2021-01-12 04:55:52 --> Language Class Initialized
INFO - 2021-01-12 04:55:52 --> Language Class Initialized
INFO - 2021-01-12 04:55:52 --> Config Class Initialized
INFO - 2021-01-12 04:55:52 --> Loader Class Initialized
INFO - 2021-01-12 04:55:52 --> Helper loaded: url_helper
INFO - 2021-01-12 04:55:52 --> Helper loaded: file_helper
INFO - 2021-01-12 04:55:52 --> Helper loaded: form_helper
INFO - 2021-01-12 04:55:52 --> Helper loaded: my_helper
INFO - 2021-01-12 04:55:52 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:55:52 --> Controller Class Initialized
DEBUG - 2021-01-12 04:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:55:52 --> Final output sent to browser
DEBUG - 2021-01-12 04:55:52 --> Total execution time: 0.3434
INFO - 2021-01-12 04:56:00 --> Config Class Initialized
INFO - 2021-01-12 04:56:00 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:56:00 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:56:00 --> Utf8 Class Initialized
INFO - 2021-01-12 04:56:00 --> URI Class Initialized
INFO - 2021-01-12 04:56:00 --> Router Class Initialized
INFO - 2021-01-12 04:56:00 --> Output Class Initialized
INFO - 2021-01-12 04:56:00 --> Security Class Initialized
DEBUG - 2021-01-12 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:56:00 --> Input Class Initialized
INFO - 2021-01-12 04:56:00 --> Language Class Initialized
INFO - 2021-01-12 04:56:00 --> Language Class Initialized
INFO - 2021-01-12 04:56:00 --> Config Class Initialized
INFO - 2021-01-12 04:56:00 --> Loader Class Initialized
INFO - 2021-01-12 04:56:00 --> Helper loaded: url_helper
INFO - 2021-01-12 04:56:00 --> Helper loaded: file_helper
INFO - 2021-01-12 04:56:00 --> Helper loaded: form_helper
INFO - 2021-01-12 04:56:00 --> Helper loaded: my_helper
INFO - 2021-01-12 04:56:00 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:56:00 --> Controller Class Initialized
DEBUG - 2021-01-12 04:56:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:56:00 --> Final output sent to browser
DEBUG - 2021-01-12 04:56:00 --> Total execution time: 0.3353
INFO - 2021-01-12 04:56:24 --> Config Class Initialized
INFO - 2021-01-12 04:56:25 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:56:25 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:56:25 --> Utf8 Class Initialized
INFO - 2021-01-12 04:56:25 --> URI Class Initialized
INFO - 2021-01-12 04:56:25 --> Router Class Initialized
INFO - 2021-01-12 04:56:25 --> Output Class Initialized
INFO - 2021-01-12 04:56:25 --> Security Class Initialized
DEBUG - 2021-01-12 04:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:56:25 --> Input Class Initialized
INFO - 2021-01-12 04:56:25 --> Language Class Initialized
INFO - 2021-01-12 04:56:25 --> Language Class Initialized
INFO - 2021-01-12 04:56:25 --> Config Class Initialized
INFO - 2021-01-12 04:56:25 --> Loader Class Initialized
INFO - 2021-01-12 04:56:25 --> Helper loaded: url_helper
INFO - 2021-01-12 04:56:25 --> Helper loaded: file_helper
INFO - 2021-01-12 04:56:25 --> Helper loaded: form_helper
INFO - 2021-01-12 04:56:25 --> Helper loaded: my_helper
INFO - 2021-01-12 04:56:25 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:56:25 --> Controller Class Initialized
DEBUG - 2021-01-12 04:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:56:25 --> Final output sent to browser
DEBUG - 2021-01-12 04:56:25 --> Total execution time: 0.3433
INFO - 2021-01-12 04:58:14 --> Config Class Initialized
INFO - 2021-01-12 04:58:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:58:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:58:14 --> Utf8 Class Initialized
INFO - 2021-01-12 04:58:14 --> URI Class Initialized
INFO - 2021-01-12 04:58:14 --> Router Class Initialized
INFO - 2021-01-12 04:58:14 --> Output Class Initialized
INFO - 2021-01-12 04:58:14 --> Security Class Initialized
DEBUG - 2021-01-12 04:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:58:14 --> Input Class Initialized
INFO - 2021-01-12 04:58:14 --> Language Class Initialized
INFO - 2021-01-12 04:58:14 --> Language Class Initialized
INFO - 2021-01-12 04:58:14 --> Config Class Initialized
INFO - 2021-01-12 04:58:14 --> Loader Class Initialized
INFO - 2021-01-12 04:58:14 --> Helper loaded: url_helper
INFO - 2021-01-12 04:58:14 --> Helper loaded: file_helper
INFO - 2021-01-12 04:58:14 --> Helper loaded: form_helper
INFO - 2021-01-12 04:58:14 --> Helper loaded: my_helper
INFO - 2021-01-12 04:58:15 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:58:15 --> Controller Class Initialized
DEBUG - 2021-01-12 04:58:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:58:15 --> Final output sent to browser
DEBUG - 2021-01-12 04:58:15 --> Total execution time: 0.3406
INFO - 2021-01-12 04:58:21 --> Config Class Initialized
INFO - 2021-01-12 04:58:21 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:58:21 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:58:22 --> Utf8 Class Initialized
INFO - 2021-01-12 04:58:22 --> URI Class Initialized
INFO - 2021-01-12 04:58:22 --> Router Class Initialized
INFO - 2021-01-12 04:58:22 --> Output Class Initialized
INFO - 2021-01-12 04:58:22 --> Security Class Initialized
DEBUG - 2021-01-12 04:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:58:22 --> Input Class Initialized
INFO - 2021-01-12 04:58:22 --> Language Class Initialized
INFO - 2021-01-12 04:58:22 --> Language Class Initialized
INFO - 2021-01-12 04:58:22 --> Config Class Initialized
INFO - 2021-01-12 04:58:22 --> Loader Class Initialized
INFO - 2021-01-12 04:58:22 --> Helper loaded: url_helper
INFO - 2021-01-12 04:58:22 --> Helper loaded: file_helper
INFO - 2021-01-12 04:58:22 --> Helper loaded: form_helper
INFO - 2021-01-12 04:58:22 --> Helper loaded: my_helper
INFO - 2021-01-12 04:58:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:58:22 --> Controller Class Initialized
DEBUG - 2021-01-12 04:58:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:58:22 --> Final output sent to browser
DEBUG - 2021-01-12 04:58:22 --> Total execution time: 0.3548
INFO - 2021-01-12 04:59:14 --> Config Class Initialized
INFO - 2021-01-12 04:59:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:59:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:59:14 --> Utf8 Class Initialized
INFO - 2021-01-12 04:59:14 --> URI Class Initialized
INFO - 2021-01-12 04:59:14 --> Router Class Initialized
INFO - 2021-01-12 04:59:14 --> Output Class Initialized
INFO - 2021-01-12 04:59:14 --> Security Class Initialized
DEBUG - 2021-01-12 04:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:59:14 --> Input Class Initialized
INFO - 2021-01-12 04:59:14 --> Language Class Initialized
INFO - 2021-01-12 04:59:14 --> Language Class Initialized
INFO - 2021-01-12 04:59:14 --> Config Class Initialized
INFO - 2021-01-12 04:59:14 --> Loader Class Initialized
INFO - 2021-01-12 04:59:14 --> Helper loaded: url_helper
INFO - 2021-01-12 04:59:14 --> Helper loaded: file_helper
INFO - 2021-01-12 04:59:14 --> Helper loaded: form_helper
INFO - 2021-01-12 04:59:14 --> Helper loaded: my_helper
INFO - 2021-01-12 04:59:14 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:59:14 --> Controller Class Initialized
DEBUG - 2021-01-12 04:59:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:59:14 --> Final output sent to browser
DEBUG - 2021-01-12 04:59:14 --> Total execution time: 0.3429
INFO - 2021-01-12 04:59:28 --> Config Class Initialized
INFO - 2021-01-12 04:59:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 04:59:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 04:59:28 --> Utf8 Class Initialized
INFO - 2021-01-12 04:59:28 --> URI Class Initialized
INFO - 2021-01-12 04:59:28 --> Router Class Initialized
INFO - 2021-01-12 04:59:28 --> Output Class Initialized
INFO - 2021-01-12 04:59:28 --> Security Class Initialized
DEBUG - 2021-01-12 04:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 04:59:28 --> Input Class Initialized
INFO - 2021-01-12 04:59:28 --> Language Class Initialized
INFO - 2021-01-12 04:59:28 --> Language Class Initialized
INFO - 2021-01-12 04:59:28 --> Config Class Initialized
INFO - 2021-01-12 04:59:28 --> Loader Class Initialized
INFO - 2021-01-12 04:59:28 --> Helper loaded: url_helper
INFO - 2021-01-12 04:59:28 --> Helper loaded: file_helper
INFO - 2021-01-12 04:59:28 --> Helper loaded: form_helper
INFO - 2021-01-12 04:59:28 --> Helper loaded: my_helper
INFO - 2021-01-12 04:59:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 04:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 04:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 04:59:28 --> Controller Class Initialized
DEBUG - 2021-01-12 04:59:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 04:59:28 --> Final output sent to browser
DEBUG - 2021-01-12 04:59:28 --> Total execution time: 0.3394
INFO - 2021-01-12 05:00:29 --> Config Class Initialized
INFO - 2021-01-12 05:00:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:00:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:00:29 --> Utf8 Class Initialized
INFO - 2021-01-12 05:00:29 --> URI Class Initialized
INFO - 2021-01-12 05:00:29 --> Router Class Initialized
INFO - 2021-01-12 05:00:29 --> Output Class Initialized
INFO - 2021-01-12 05:00:29 --> Security Class Initialized
DEBUG - 2021-01-12 05:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:00:29 --> Input Class Initialized
INFO - 2021-01-12 05:00:29 --> Language Class Initialized
INFO - 2021-01-12 05:00:29 --> Language Class Initialized
INFO - 2021-01-12 05:00:29 --> Config Class Initialized
INFO - 2021-01-12 05:00:29 --> Loader Class Initialized
INFO - 2021-01-12 05:00:29 --> Helper loaded: url_helper
INFO - 2021-01-12 05:00:29 --> Helper loaded: file_helper
INFO - 2021-01-12 05:00:29 --> Helper loaded: form_helper
INFO - 2021-01-12 05:00:29 --> Helper loaded: my_helper
INFO - 2021-01-12 05:00:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:00:29 --> Controller Class Initialized
DEBUG - 2021-01-12 05:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:00:29 --> Final output sent to browser
DEBUG - 2021-01-12 05:00:29 --> Total execution time: 0.3472
INFO - 2021-01-12 05:00:36 --> Config Class Initialized
INFO - 2021-01-12 05:00:36 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:00:36 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:00:36 --> Utf8 Class Initialized
INFO - 2021-01-12 05:00:36 --> URI Class Initialized
INFO - 2021-01-12 05:00:36 --> Router Class Initialized
INFO - 2021-01-12 05:00:36 --> Output Class Initialized
INFO - 2021-01-12 05:00:36 --> Security Class Initialized
DEBUG - 2021-01-12 05:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:00:36 --> Input Class Initialized
INFO - 2021-01-12 05:00:36 --> Language Class Initialized
INFO - 2021-01-12 05:00:36 --> Language Class Initialized
INFO - 2021-01-12 05:00:36 --> Config Class Initialized
INFO - 2021-01-12 05:00:36 --> Loader Class Initialized
INFO - 2021-01-12 05:00:36 --> Helper loaded: url_helper
INFO - 2021-01-12 05:00:36 --> Helper loaded: file_helper
INFO - 2021-01-12 05:00:36 --> Helper loaded: form_helper
INFO - 2021-01-12 05:00:36 --> Helper loaded: my_helper
INFO - 2021-01-12 05:00:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:00:36 --> Controller Class Initialized
DEBUG - 2021-01-12 05:00:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:00:36 --> Final output sent to browser
DEBUG - 2021-01-12 05:00:36 --> Total execution time: 0.3351
INFO - 2021-01-12 05:04:29 --> Config Class Initialized
INFO - 2021-01-12 05:04:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:04:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:04:29 --> Utf8 Class Initialized
INFO - 2021-01-12 05:04:29 --> URI Class Initialized
INFO - 2021-01-12 05:04:29 --> Router Class Initialized
INFO - 2021-01-12 05:04:29 --> Output Class Initialized
INFO - 2021-01-12 05:04:29 --> Security Class Initialized
DEBUG - 2021-01-12 05:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:04:29 --> Input Class Initialized
INFO - 2021-01-12 05:04:29 --> Language Class Initialized
INFO - 2021-01-12 05:04:29 --> Language Class Initialized
INFO - 2021-01-12 05:04:29 --> Config Class Initialized
INFO - 2021-01-12 05:04:29 --> Loader Class Initialized
INFO - 2021-01-12 05:04:29 --> Helper loaded: url_helper
INFO - 2021-01-12 05:04:29 --> Helper loaded: file_helper
INFO - 2021-01-12 05:04:29 --> Helper loaded: form_helper
INFO - 2021-01-12 05:04:29 --> Helper loaded: my_helper
INFO - 2021-01-12 05:04:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:04:29 --> Controller Class Initialized
DEBUG - 2021-01-12 05:04:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:04:29 --> Final output sent to browser
DEBUG - 2021-01-12 05:04:29 --> Total execution time: 0.3669
INFO - 2021-01-12 05:05:26 --> Config Class Initialized
INFO - 2021-01-12 05:05:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:05:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:05:26 --> Utf8 Class Initialized
INFO - 2021-01-12 05:05:26 --> URI Class Initialized
INFO - 2021-01-12 05:05:26 --> Router Class Initialized
INFO - 2021-01-12 05:05:26 --> Output Class Initialized
INFO - 2021-01-12 05:05:26 --> Security Class Initialized
DEBUG - 2021-01-12 05:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:05:26 --> Input Class Initialized
INFO - 2021-01-12 05:05:26 --> Language Class Initialized
INFO - 2021-01-12 05:05:26 --> Language Class Initialized
INFO - 2021-01-12 05:05:26 --> Config Class Initialized
INFO - 2021-01-12 05:05:26 --> Loader Class Initialized
INFO - 2021-01-12 05:05:26 --> Helper loaded: url_helper
INFO - 2021-01-12 05:05:26 --> Helper loaded: file_helper
INFO - 2021-01-12 05:05:26 --> Helper loaded: form_helper
INFO - 2021-01-12 05:05:26 --> Helper loaded: my_helper
INFO - 2021-01-12 05:05:26 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:05:26 --> Controller Class Initialized
DEBUG - 2021-01-12 05:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:05:26 --> Final output sent to browser
DEBUG - 2021-01-12 05:05:26 --> Total execution time: 0.3295
INFO - 2021-01-12 05:05:46 --> Config Class Initialized
INFO - 2021-01-12 05:05:46 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:05:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:05:46 --> Utf8 Class Initialized
INFO - 2021-01-12 05:05:46 --> URI Class Initialized
INFO - 2021-01-12 05:05:46 --> Router Class Initialized
INFO - 2021-01-12 05:05:46 --> Output Class Initialized
INFO - 2021-01-12 05:05:46 --> Security Class Initialized
DEBUG - 2021-01-12 05:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:05:46 --> Input Class Initialized
INFO - 2021-01-12 05:05:46 --> Language Class Initialized
INFO - 2021-01-12 05:05:46 --> Language Class Initialized
INFO - 2021-01-12 05:05:46 --> Config Class Initialized
INFO - 2021-01-12 05:05:46 --> Loader Class Initialized
INFO - 2021-01-12 05:05:46 --> Helper loaded: url_helper
INFO - 2021-01-12 05:05:46 --> Helper loaded: file_helper
INFO - 2021-01-12 05:05:46 --> Helper loaded: form_helper
INFO - 2021-01-12 05:05:46 --> Helper loaded: my_helper
INFO - 2021-01-12 05:05:46 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:05:46 --> Controller Class Initialized
DEBUG - 2021-01-12 05:05:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:05:46 --> Final output sent to browser
DEBUG - 2021-01-12 05:05:46 --> Total execution time: 0.3532
INFO - 2021-01-12 05:06:54 --> Config Class Initialized
INFO - 2021-01-12 05:06:54 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:06:54 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:06:54 --> Utf8 Class Initialized
INFO - 2021-01-12 05:06:54 --> URI Class Initialized
INFO - 2021-01-12 05:06:54 --> Router Class Initialized
INFO - 2021-01-12 05:06:54 --> Output Class Initialized
INFO - 2021-01-12 05:06:54 --> Security Class Initialized
DEBUG - 2021-01-12 05:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:06:54 --> Input Class Initialized
INFO - 2021-01-12 05:06:54 --> Language Class Initialized
INFO - 2021-01-12 05:06:54 --> Language Class Initialized
INFO - 2021-01-12 05:06:55 --> Config Class Initialized
INFO - 2021-01-12 05:06:55 --> Loader Class Initialized
INFO - 2021-01-12 05:06:55 --> Helper loaded: url_helper
INFO - 2021-01-12 05:06:55 --> Helper loaded: file_helper
INFO - 2021-01-12 05:06:55 --> Helper loaded: form_helper
INFO - 2021-01-12 05:06:55 --> Helper loaded: my_helper
INFO - 2021-01-12 05:06:55 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:06:55 --> Controller Class Initialized
DEBUG - 2021-01-12 05:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:06:55 --> Final output sent to browser
DEBUG - 2021-01-12 05:06:55 --> Total execution time: 0.3442
INFO - 2021-01-12 05:07:08 --> Config Class Initialized
INFO - 2021-01-12 05:07:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:07:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:07:08 --> Utf8 Class Initialized
INFO - 2021-01-12 05:07:08 --> URI Class Initialized
INFO - 2021-01-12 05:07:08 --> Router Class Initialized
INFO - 2021-01-12 05:07:08 --> Output Class Initialized
INFO - 2021-01-12 05:07:08 --> Security Class Initialized
DEBUG - 2021-01-12 05:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:07:08 --> Input Class Initialized
INFO - 2021-01-12 05:07:08 --> Language Class Initialized
INFO - 2021-01-12 05:07:08 --> Language Class Initialized
INFO - 2021-01-12 05:07:08 --> Config Class Initialized
INFO - 2021-01-12 05:07:08 --> Loader Class Initialized
INFO - 2021-01-12 05:07:08 --> Helper loaded: url_helper
INFO - 2021-01-12 05:07:08 --> Helper loaded: file_helper
INFO - 2021-01-12 05:07:08 --> Helper loaded: form_helper
INFO - 2021-01-12 05:07:08 --> Helper loaded: my_helper
INFO - 2021-01-12 05:07:08 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:07:09 --> Controller Class Initialized
DEBUG - 2021-01-12 05:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:07:09 --> Final output sent to browser
DEBUG - 2021-01-12 05:07:09 --> Total execution time: 0.3602
INFO - 2021-01-12 05:07:21 --> Config Class Initialized
INFO - 2021-01-12 05:07:21 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:07:21 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:07:21 --> Utf8 Class Initialized
INFO - 2021-01-12 05:07:21 --> URI Class Initialized
INFO - 2021-01-12 05:07:21 --> Router Class Initialized
INFO - 2021-01-12 05:07:21 --> Output Class Initialized
INFO - 2021-01-12 05:07:21 --> Security Class Initialized
DEBUG - 2021-01-12 05:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:07:21 --> Input Class Initialized
INFO - 2021-01-12 05:07:21 --> Language Class Initialized
INFO - 2021-01-12 05:07:21 --> Language Class Initialized
INFO - 2021-01-12 05:07:21 --> Config Class Initialized
INFO - 2021-01-12 05:07:21 --> Loader Class Initialized
INFO - 2021-01-12 05:07:21 --> Helper loaded: url_helper
INFO - 2021-01-12 05:07:21 --> Helper loaded: file_helper
INFO - 2021-01-12 05:07:21 --> Helper loaded: form_helper
INFO - 2021-01-12 05:07:21 --> Helper loaded: my_helper
INFO - 2021-01-12 05:07:21 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:07:21 --> Controller Class Initialized
DEBUG - 2021-01-12 05:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:07:22 --> Final output sent to browser
DEBUG - 2021-01-12 05:07:22 --> Total execution time: 0.3601
INFO - 2021-01-12 05:07:45 --> Config Class Initialized
INFO - 2021-01-12 05:07:45 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:07:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:07:46 --> Utf8 Class Initialized
INFO - 2021-01-12 05:07:46 --> URI Class Initialized
INFO - 2021-01-12 05:07:46 --> Router Class Initialized
INFO - 2021-01-12 05:07:46 --> Output Class Initialized
INFO - 2021-01-12 05:07:46 --> Security Class Initialized
DEBUG - 2021-01-12 05:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:07:46 --> Input Class Initialized
INFO - 2021-01-12 05:07:46 --> Language Class Initialized
INFO - 2021-01-12 05:07:46 --> Language Class Initialized
INFO - 2021-01-12 05:07:46 --> Config Class Initialized
INFO - 2021-01-12 05:07:46 --> Loader Class Initialized
INFO - 2021-01-12 05:07:46 --> Helper loaded: url_helper
INFO - 2021-01-12 05:07:46 --> Helper loaded: file_helper
INFO - 2021-01-12 05:07:46 --> Helper loaded: form_helper
INFO - 2021-01-12 05:07:46 --> Helper loaded: my_helper
INFO - 2021-01-12 05:07:46 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:07:46 --> Controller Class Initialized
DEBUG - 2021-01-12 05:07:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:07:46 --> Final output sent to browser
DEBUG - 2021-01-12 05:07:46 --> Total execution time: 0.3369
INFO - 2021-01-12 05:08:11 --> Config Class Initialized
INFO - 2021-01-12 05:08:11 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:08:11 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:08:11 --> Utf8 Class Initialized
INFO - 2021-01-12 05:08:11 --> URI Class Initialized
INFO - 2021-01-12 05:08:11 --> Router Class Initialized
INFO - 2021-01-12 05:08:11 --> Output Class Initialized
INFO - 2021-01-12 05:08:11 --> Security Class Initialized
DEBUG - 2021-01-12 05:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:08:11 --> Input Class Initialized
INFO - 2021-01-12 05:08:11 --> Language Class Initialized
INFO - 2021-01-12 05:08:11 --> Language Class Initialized
INFO - 2021-01-12 05:08:11 --> Config Class Initialized
INFO - 2021-01-12 05:08:11 --> Loader Class Initialized
INFO - 2021-01-12 05:08:11 --> Helper loaded: url_helper
INFO - 2021-01-12 05:08:11 --> Helper loaded: file_helper
INFO - 2021-01-12 05:08:11 --> Helper loaded: form_helper
INFO - 2021-01-12 05:08:11 --> Helper loaded: my_helper
INFO - 2021-01-12 05:08:11 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:08:11 --> Controller Class Initialized
DEBUG - 2021-01-12 05:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:08:11 --> Final output sent to browser
DEBUG - 2021-01-12 05:08:11 --> Total execution time: 0.3340
INFO - 2021-01-12 05:08:28 --> Config Class Initialized
INFO - 2021-01-12 05:08:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:08:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:08:28 --> Utf8 Class Initialized
INFO - 2021-01-12 05:08:28 --> URI Class Initialized
INFO - 2021-01-12 05:08:28 --> Router Class Initialized
INFO - 2021-01-12 05:08:28 --> Output Class Initialized
INFO - 2021-01-12 05:08:28 --> Security Class Initialized
DEBUG - 2021-01-12 05:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:08:28 --> Input Class Initialized
INFO - 2021-01-12 05:08:28 --> Language Class Initialized
INFO - 2021-01-12 05:08:28 --> Language Class Initialized
INFO - 2021-01-12 05:08:28 --> Config Class Initialized
INFO - 2021-01-12 05:08:28 --> Loader Class Initialized
INFO - 2021-01-12 05:08:28 --> Helper loaded: url_helper
INFO - 2021-01-12 05:08:28 --> Helper loaded: file_helper
INFO - 2021-01-12 05:08:28 --> Helper loaded: form_helper
INFO - 2021-01-12 05:08:28 --> Helper loaded: my_helper
INFO - 2021-01-12 05:08:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:08:28 --> Controller Class Initialized
DEBUG - 2021-01-12 05:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:08:28 --> Final output sent to browser
DEBUG - 2021-01-12 05:08:28 --> Total execution time: 0.3343
INFO - 2021-01-12 05:08:57 --> Config Class Initialized
INFO - 2021-01-12 05:08:57 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:08:57 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:08:57 --> Utf8 Class Initialized
INFO - 2021-01-12 05:08:57 --> URI Class Initialized
INFO - 2021-01-12 05:08:57 --> Router Class Initialized
INFO - 2021-01-12 05:08:58 --> Output Class Initialized
INFO - 2021-01-12 05:08:58 --> Security Class Initialized
DEBUG - 2021-01-12 05:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:08:58 --> Input Class Initialized
INFO - 2021-01-12 05:08:58 --> Language Class Initialized
INFO - 2021-01-12 05:08:58 --> Language Class Initialized
INFO - 2021-01-12 05:08:58 --> Config Class Initialized
INFO - 2021-01-12 05:08:58 --> Loader Class Initialized
INFO - 2021-01-12 05:08:58 --> Helper loaded: url_helper
INFO - 2021-01-12 05:08:58 --> Helper loaded: file_helper
INFO - 2021-01-12 05:08:58 --> Helper loaded: form_helper
INFO - 2021-01-12 05:08:58 --> Helper loaded: my_helper
INFO - 2021-01-12 05:08:58 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:08:58 --> Controller Class Initialized
DEBUG - 2021-01-12 05:08:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:08:58 --> Final output sent to browser
DEBUG - 2021-01-12 05:08:58 --> Total execution time: 0.3630
INFO - 2021-01-12 05:09:10 --> Config Class Initialized
INFO - 2021-01-12 05:09:10 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:09:10 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:09:10 --> Utf8 Class Initialized
INFO - 2021-01-12 05:09:10 --> URI Class Initialized
INFO - 2021-01-12 05:09:10 --> Router Class Initialized
INFO - 2021-01-12 05:09:10 --> Output Class Initialized
INFO - 2021-01-12 05:09:10 --> Security Class Initialized
DEBUG - 2021-01-12 05:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:09:10 --> Input Class Initialized
INFO - 2021-01-12 05:09:10 --> Language Class Initialized
INFO - 2021-01-12 05:09:10 --> Language Class Initialized
INFO - 2021-01-12 05:09:10 --> Config Class Initialized
INFO - 2021-01-12 05:09:10 --> Loader Class Initialized
INFO - 2021-01-12 05:09:10 --> Helper loaded: url_helper
INFO - 2021-01-12 05:09:10 --> Helper loaded: file_helper
INFO - 2021-01-12 05:09:10 --> Helper loaded: form_helper
INFO - 2021-01-12 05:09:10 --> Helper loaded: my_helper
INFO - 2021-01-12 05:09:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:09:10 --> Controller Class Initialized
DEBUG - 2021-01-12 05:09:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:09:10 --> Final output sent to browser
DEBUG - 2021-01-12 05:09:10 --> Total execution time: 0.3592
INFO - 2021-01-12 05:09:24 --> Config Class Initialized
INFO - 2021-01-12 05:09:24 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:09:24 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:09:24 --> Utf8 Class Initialized
INFO - 2021-01-12 05:09:24 --> URI Class Initialized
INFO - 2021-01-12 05:09:24 --> Router Class Initialized
INFO - 2021-01-12 05:09:24 --> Output Class Initialized
INFO - 2021-01-12 05:09:24 --> Security Class Initialized
DEBUG - 2021-01-12 05:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:09:24 --> Input Class Initialized
INFO - 2021-01-12 05:09:24 --> Language Class Initialized
INFO - 2021-01-12 05:09:24 --> Language Class Initialized
INFO - 2021-01-12 05:09:24 --> Config Class Initialized
INFO - 2021-01-12 05:09:24 --> Loader Class Initialized
INFO - 2021-01-12 05:09:24 --> Helper loaded: url_helper
INFO - 2021-01-12 05:09:24 --> Helper loaded: file_helper
INFO - 2021-01-12 05:09:24 --> Helper loaded: form_helper
INFO - 2021-01-12 05:09:24 --> Helper loaded: my_helper
INFO - 2021-01-12 05:09:24 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:09:24 --> Controller Class Initialized
DEBUG - 2021-01-12 05:09:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:09:24 --> Final output sent to browser
DEBUG - 2021-01-12 05:09:24 --> Total execution time: 0.3765
INFO - 2021-01-12 05:09:36 --> Config Class Initialized
INFO - 2021-01-12 05:09:36 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:09:36 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:09:36 --> Utf8 Class Initialized
INFO - 2021-01-12 05:09:36 --> URI Class Initialized
INFO - 2021-01-12 05:09:36 --> Router Class Initialized
INFO - 2021-01-12 05:09:36 --> Output Class Initialized
INFO - 2021-01-12 05:09:36 --> Security Class Initialized
DEBUG - 2021-01-12 05:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:09:36 --> Input Class Initialized
INFO - 2021-01-12 05:09:36 --> Language Class Initialized
INFO - 2021-01-12 05:09:36 --> Language Class Initialized
INFO - 2021-01-12 05:09:36 --> Config Class Initialized
INFO - 2021-01-12 05:09:36 --> Loader Class Initialized
INFO - 2021-01-12 05:09:36 --> Helper loaded: url_helper
INFO - 2021-01-12 05:09:36 --> Helper loaded: file_helper
INFO - 2021-01-12 05:09:36 --> Helper loaded: form_helper
INFO - 2021-01-12 05:09:36 --> Helper loaded: my_helper
INFO - 2021-01-12 05:09:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:09:36 --> Controller Class Initialized
DEBUG - 2021-01-12 05:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:09:36 --> Final output sent to browser
DEBUG - 2021-01-12 05:09:36 --> Total execution time: 0.3364
INFO - 2021-01-12 05:09:55 --> Config Class Initialized
INFO - 2021-01-12 05:09:55 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:09:55 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:09:55 --> Utf8 Class Initialized
INFO - 2021-01-12 05:09:55 --> URI Class Initialized
INFO - 2021-01-12 05:09:55 --> Router Class Initialized
INFO - 2021-01-12 05:09:55 --> Output Class Initialized
INFO - 2021-01-12 05:09:55 --> Security Class Initialized
DEBUG - 2021-01-12 05:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:09:55 --> Input Class Initialized
INFO - 2021-01-12 05:09:55 --> Language Class Initialized
INFO - 2021-01-12 05:09:55 --> Language Class Initialized
INFO - 2021-01-12 05:09:55 --> Config Class Initialized
INFO - 2021-01-12 05:09:55 --> Loader Class Initialized
INFO - 2021-01-12 05:09:55 --> Helper loaded: url_helper
INFO - 2021-01-12 05:09:55 --> Helper loaded: file_helper
INFO - 2021-01-12 05:09:55 --> Helper loaded: form_helper
INFO - 2021-01-12 05:09:55 --> Helper loaded: my_helper
INFO - 2021-01-12 05:09:55 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:09:55 --> Controller Class Initialized
DEBUG - 2021-01-12 05:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:09:55 --> Final output sent to browser
DEBUG - 2021-01-12 05:09:55 --> Total execution time: 0.3416
INFO - 2021-01-12 05:10:19 --> Config Class Initialized
INFO - 2021-01-12 05:10:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:10:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:10:19 --> Utf8 Class Initialized
INFO - 2021-01-12 05:10:19 --> URI Class Initialized
INFO - 2021-01-12 05:10:19 --> Router Class Initialized
INFO - 2021-01-12 05:10:19 --> Output Class Initialized
INFO - 2021-01-12 05:10:19 --> Security Class Initialized
DEBUG - 2021-01-12 05:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:10:19 --> Input Class Initialized
INFO - 2021-01-12 05:10:19 --> Language Class Initialized
INFO - 2021-01-12 05:10:19 --> Language Class Initialized
INFO - 2021-01-12 05:10:19 --> Config Class Initialized
INFO - 2021-01-12 05:10:19 --> Loader Class Initialized
INFO - 2021-01-12 05:10:19 --> Helper loaded: url_helper
INFO - 2021-01-12 05:10:19 --> Helper loaded: file_helper
INFO - 2021-01-12 05:10:19 --> Helper loaded: form_helper
INFO - 2021-01-12 05:10:19 --> Helper loaded: my_helper
INFO - 2021-01-12 05:10:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:10:19 --> Controller Class Initialized
DEBUG - 2021-01-12 05:10:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:10:19 --> Final output sent to browser
DEBUG - 2021-01-12 05:10:19 --> Total execution time: 0.3596
INFO - 2021-01-12 05:10:32 --> Config Class Initialized
INFO - 2021-01-12 05:10:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:10:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:10:32 --> Utf8 Class Initialized
INFO - 2021-01-12 05:10:32 --> URI Class Initialized
INFO - 2021-01-12 05:10:32 --> Router Class Initialized
INFO - 2021-01-12 05:10:32 --> Output Class Initialized
INFO - 2021-01-12 05:10:32 --> Security Class Initialized
DEBUG - 2021-01-12 05:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:10:32 --> Input Class Initialized
INFO - 2021-01-12 05:10:32 --> Language Class Initialized
INFO - 2021-01-12 05:10:32 --> Language Class Initialized
INFO - 2021-01-12 05:10:32 --> Config Class Initialized
INFO - 2021-01-12 05:10:32 --> Loader Class Initialized
INFO - 2021-01-12 05:10:32 --> Helper loaded: url_helper
INFO - 2021-01-12 05:10:32 --> Helper loaded: file_helper
INFO - 2021-01-12 05:10:32 --> Helper loaded: form_helper
INFO - 2021-01-12 05:10:32 --> Helper loaded: my_helper
INFO - 2021-01-12 05:10:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:10:32 --> Controller Class Initialized
DEBUG - 2021-01-12 05:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:10:32 --> Final output sent to browser
DEBUG - 2021-01-12 05:10:32 --> Total execution time: 0.3516
INFO - 2021-01-12 05:10:49 --> Config Class Initialized
INFO - 2021-01-12 05:10:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:10:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:10:49 --> Utf8 Class Initialized
INFO - 2021-01-12 05:10:49 --> URI Class Initialized
INFO - 2021-01-12 05:10:49 --> Router Class Initialized
INFO - 2021-01-12 05:10:49 --> Output Class Initialized
INFO - 2021-01-12 05:10:49 --> Security Class Initialized
DEBUG - 2021-01-12 05:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:10:49 --> Input Class Initialized
INFO - 2021-01-12 05:10:49 --> Language Class Initialized
INFO - 2021-01-12 05:10:49 --> Language Class Initialized
INFO - 2021-01-12 05:10:49 --> Config Class Initialized
INFO - 2021-01-12 05:10:49 --> Loader Class Initialized
INFO - 2021-01-12 05:10:49 --> Helper loaded: url_helper
INFO - 2021-01-12 05:10:49 --> Helper loaded: file_helper
INFO - 2021-01-12 05:10:49 --> Helper loaded: form_helper
INFO - 2021-01-12 05:10:49 --> Helper loaded: my_helper
INFO - 2021-01-12 05:10:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:10:49 --> Controller Class Initialized
DEBUG - 2021-01-12 05:10:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:10:49 --> Final output sent to browser
DEBUG - 2021-01-12 05:10:49 --> Total execution time: 0.3479
INFO - 2021-01-12 05:11:03 --> Config Class Initialized
INFO - 2021-01-12 05:11:03 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:11:03 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:11:03 --> Utf8 Class Initialized
INFO - 2021-01-12 05:11:03 --> URI Class Initialized
INFO - 2021-01-12 05:11:03 --> Router Class Initialized
INFO - 2021-01-12 05:11:03 --> Output Class Initialized
INFO - 2021-01-12 05:11:03 --> Security Class Initialized
DEBUG - 2021-01-12 05:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:11:03 --> Input Class Initialized
INFO - 2021-01-12 05:11:03 --> Language Class Initialized
INFO - 2021-01-12 05:11:03 --> Language Class Initialized
INFO - 2021-01-12 05:11:03 --> Config Class Initialized
INFO - 2021-01-12 05:11:03 --> Loader Class Initialized
INFO - 2021-01-12 05:11:03 --> Helper loaded: url_helper
INFO - 2021-01-12 05:11:03 --> Helper loaded: file_helper
INFO - 2021-01-12 05:11:03 --> Helper loaded: form_helper
INFO - 2021-01-12 05:11:03 --> Helper loaded: my_helper
INFO - 2021-01-12 05:11:03 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:11:03 --> Controller Class Initialized
DEBUG - 2021-01-12 05:11:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:11:03 --> Final output sent to browser
DEBUG - 2021-01-12 05:11:03 --> Total execution time: 0.2903
INFO - 2021-01-12 05:11:51 --> Config Class Initialized
INFO - 2021-01-12 05:11:51 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:11:51 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:11:51 --> Utf8 Class Initialized
INFO - 2021-01-12 05:11:51 --> URI Class Initialized
INFO - 2021-01-12 05:11:51 --> Router Class Initialized
INFO - 2021-01-12 05:11:51 --> Output Class Initialized
INFO - 2021-01-12 05:11:51 --> Security Class Initialized
DEBUG - 2021-01-12 05:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:11:51 --> Input Class Initialized
INFO - 2021-01-12 05:11:51 --> Language Class Initialized
INFO - 2021-01-12 05:11:51 --> Language Class Initialized
INFO - 2021-01-12 05:11:51 --> Config Class Initialized
INFO - 2021-01-12 05:11:51 --> Loader Class Initialized
INFO - 2021-01-12 05:11:51 --> Helper loaded: url_helper
INFO - 2021-01-12 05:11:51 --> Helper loaded: file_helper
INFO - 2021-01-12 05:11:51 --> Helper loaded: form_helper
INFO - 2021-01-12 05:11:51 --> Helper loaded: my_helper
INFO - 2021-01-12 05:11:51 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:11:51 --> Controller Class Initialized
DEBUG - 2021-01-12 05:11:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:11:52 --> Final output sent to browser
DEBUG - 2021-01-12 05:11:52 --> Total execution time: 0.3378
INFO - 2021-01-12 05:12:11 --> Config Class Initialized
INFO - 2021-01-12 05:12:11 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:12:11 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:12:11 --> Utf8 Class Initialized
INFO - 2021-01-12 05:12:11 --> URI Class Initialized
INFO - 2021-01-12 05:12:12 --> Router Class Initialized
INFO - 2021-01-12 05:12:12 --> Output Class Initialized
INFO - 2021-01-12 05:12:12 --> Security Class Initialized
DEBUG - 2021-01-12 05:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:12:12 --> Input Class Initialized
INFO - 2021-01-12 05:12:12 --> Language Class Initialized
INFO - 2021-01-12 05:12:12 --> Language Class Initialized
INFO - 2021-01-12 05:12:12 --> Config Class Initialized
INFO - 2021-01-12 05:12:12 --> Loader Class Initialized
INFO - 2021-01-12 05:12:12 --> Helper loaded: url_helper
INFO - 2021-01-12 05:12:12 --> Helper loaded: file_helper
INFO - 2021-01-12 05:12:12 --> Helper loaded: form_helper
INFO - 2021-01-12 05:12:12 --> Helper loaded: my_helper
INFO - 2021-01-12 05:12:12 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:12:12 --> Controller Class Initialized
DEBUG - 2021-01-12 05:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:12:12 --> Final output sent to browser
DEBUG - 2021-01-12 05:12:12 --> Total execution time: 0.3553
INFO - 2021-01-12 05:12:35 --> Config Class Initialized
INFO - 2021-01-12 05:12:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:12:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:12:35 --> Utf8 Class Initialized
INFO - 2021-01-12 05:12:35 --> URI Class Initialized
INFO - 2021-01-12 05:12:35 --> Router Class Initialized
INFO - 2021-01-12 05:12:35 --> Output Class Initialized
INFO - 2021-01-12 05:12:35 --> Security Class Initialized
DEBUG - 2021-01-12 05:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:12:35 --> Input Class Initialized
INFO - 2021-01-12 05:12:35 --> Language Class Initialized
INFO - 2021-01-12 05:12:35 --> Language Class Initialized
INFO - 2021-01-12 05:12:35 --> Config Class Initialized
INFO - 2021-01-12 05:12:35 --> Loader Class Initialized
INFO - 2021-01-12 05:12:35 --> Helper loaded: url_helper
INFO - 2021-01-12 05:12:35 --> Helper loaded: file_helper
INFO - 2021-01-12 05:12:35 --> Helper loaded: form_helper
INFO - 2021-01-12 05:12:35 --> Helper loaded: my_helper
INFO - 2021-01-12 05:12:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:12:35 --> Controller Class Initialized
DEBUG - 2021-01-12 05:12:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:12:35 --> Final output sent to browser
DEBUG - 2021-01-12 05:12:35 --> Total execution time: 0.3403
INFO - 2021-01-12 05:12:48 --> Config Class Initialized
INFO - 2021-01-12 05:12:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:12:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:12:48 --> Utf8 Class Initialized
INFO - 2021-01-12 05:12:48 --> URI Class Initialized
INFO - 2021-01-12 05:12:48 --> Router Class Initialized
INFO - 2021-01-12 05:12:48 --> Output Class Initialized
INFO - 2021-01-12 05:12:48 --> Security Class Initialized
DEBUG - 2021-01-12 05:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:12:48 --> Input Class Initialized
INFO - 2021-01-12 05:12:48 --> Language Class Initialized
INFO - 2021-01-12 05:12:48 --> Language Class Initialized
INFO - 2021-01-12 05:12:48 --> Config Class Initialized
INFO - 2021-01-12 05:12:48 --> Loader Class Initialized
INFO - 2021-01-12 05:12:48 --> Helper loaded: url_helper
INFO - 2021-01-12 05:12:48 --> Helper loaded: file_helper
INFO - 2021-01-12 05:12:48 --> Helper loaded: form_helper
INFO - 2021-01-12 05:12:48 --> Helper loaded: my_helper
INFO - 2021-01-12 05:12:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:12:48 --> Controller Class Initialized
DEBUG - 2021-01-12 05:12:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:12:48 --> Final output sent to browser
DEBUG - 2021-01-12 05:12:48 --> Total execution time: 0.3682
INFO - 2021-01-12 05:13:36 --> Config Class Initialized
INFO - 2021-01-12 05:13:36 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:13:36 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:13:36 --> Utf8 Class Initialized
INFO - 2021-01-12 05:13:36 --> URI Class Initialized
INFO - 2021-01-12 05:13:36 --> Router Class Initialized
INFO - 2021-01-12 05:13:36 --> Output Class Initialized
INFO - 2021-01-12 05:13:36 --> Security Class Initialized
DEBUG - 2021-01-12 05:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:13:36 --> Input Class Initialized
INFO - 2021-01-12 05:13:36 --> Language Class Initialized
INFO - 2021-01-12 05:13:36 --> Language Class Initialized
INFO - 2021-01-12 05:13:36 --> Config Class Initialized
INFO - 2021-01-12 05:13:36 --> Loader Class Initialized
INFO - 2021-01-12 05:13:36 --> Helper loaded: url_helper
INFO - 2021-01-12 05:13:36 --> Helper loaded: file_helper
INFO - 2021-01-12 05:13:36 --> Helper loaded: form_helper
INFO - 2021-01-12 05:13:36 --> Helper loaded: my_helper
INFO - 2021-01-12 05:13:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:13:36 --> Controller Class Initialized
DEBUG - 2021-01-12 05:13:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:13:36 --> Final output sent to browser
DEBUG - 2021-01-12 05:13:36 --> Total execution time: 0.3634
INFO - 2021-01-12 05:14:03 --> Config Class Initialized
INFO - 2021-01-12 05:14:03 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:14:03 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:14:03 --> Utf8 Class Initialized
INFO - 2021-01-12 05:14:03 --> URI Class Initialized
INFO - 2021-01-12 05:14:03 --> Router Class Initialized
INFO - 2021-01-12 05:14:03 --> Output Class Initialized
INFO - 2021-01-12 05:14:03 --> Security Class Initialized
DEBUG - 2021-01-12 05:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:14:03 --> Input Class Initialized
INFO - 2021-01-12 05:14:03 --> Language Class Initialized
INFO - 2021-01-12 05:14:03 --> Language Class Initialized
INFO - 2021-01-12 05:14:03 --> Config Class Initialized
INFO - 2021-01-12 05:14:03 --> Loader Class Initialized
INFO - 2021-01-12 05:14:03 --> Helper loaded: url_helper
INFO - 2021-01-12 05:14:03 --> Helper loaded: file_helper
INFO - 2021-01-12 05:14:03 --> Helper loaded: form_helper
INFO - 2021-01-12 05:14:03 --> Helper loaded: my_helper
INFO - 2021-01-12 05:14:03 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:14:03 --> Controller Class Initialized
DEBUG - 2021-01-12 05:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:14:03 --> Final output sent to browser
DEBUG - 2021-01-12 05:14:04 --> Total execution time: 0.3554
INFO - 2021-01-12 05:14:18 --> Config Class Initialized
INFO - 2021-01-12 05:14:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:14:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:14:18 --> Utf8 Class Initialized
INFO - 2021-01-12 05:14:18 --> URI Class Initialized
INFO - 2021-01-12 05:14:18 --> Router Class Initialized
INFO - 2021-01-12 05:14:18 --> Output Class Initialized
INFO - 2021-01-12 05:14:18 --> Security Class Initialized
DEBUG - 2021-01-12 05:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:14:18 --> Input Class Initialized
INFO - 2021-01-12 05:14:18 --> Language Class Initialized
INFO - 2021-01-12 05:14:18 --> Language Class Initialized
INFO - 2021-01-12 05:14:18 --> Config Class Initialized
INFO - 2021-01-12 05:14:18 --> Loader Class Initialized
INFO - 2021-01-12 05:14:18 --> Helper loaded: url_helper
INFO - 2021-01-12 05:14:18 --> Helper loaded: file_helper
INFO - 2021-01-12 05:14:18 --> Helper loaded: form_helper
INFO - 2021-01-12 05:14:18 --> Helper loaded: my_helper
INFO - 2021-01-12 05:14:18 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:14:18 --> Controller Class Initialized
DEBUG - 2021-01-12 05:14:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:14:18 --> Final output sent to browser
DEBUG - 2021-01-12 05:14:18 --> Total execution time: 0.3503
INFO - 2021-01-12 05:14:40 --> Config Class Initialized
INFO - 2021-01-12 05:14:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:14:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:14:40 --> Utf8 Class Initialized
INFO - 2021-01-12 05:14:40 --> URI Class Initialized
INFO - 2021-01-12 05:14:40 --> Router Class Initialized
INFO - 2021-01-12 05:14:40 --> Output Class Initialized
INFO - 2021-01-12 05:14:40 --> Security Class Initialized
DEBUG - 2021-01-12 05:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:14:40 --> Input Class Initialized
INFO - 2021-01-12 05:14:40 --> Language Class Initialized
INFO - 2021-01-12 05:14:40 --> Language Class Initialized
INFO - 2021-01-12 05:14:40 --> Config Class Initialized
INFO - 2021-01-12 05:14:40 --> Loader Class Initialized
INFO - 2021-01-12 05:14:40 --> Helper loaded: url_helper
INFO - 2021-01-12 05:14:40 --> Helper loaded: file_helper
INFO - 2021-01-12 05:14:40 --> Helper loaded: form_helper
INFO - 2021-01-12 05:14:40 --> Helper loaded: my_helper
INFO - 2021-01-12 05:14:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:14:40 --> Controller Class Initialized
DEBUG - 2021-01-12 05:14:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:14:40 --> Final output sent to browser
DEBUG - 2021-01-12 05:14:40 --> Total execution time: 0.3628
INFO - 2021-01-12 05:15:06 --> Config Class Initialized
INFO - 2021-01-12 05:15:06 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:15:06 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:15:06 --> Utf8 Class Initialized
INFO - 2021-01-12 05:15:06 --> URI Class Initialized
INFO - 2021-01-12 05:15:06 --> Router Class Initialized
INFO - 2021-01-12 05:15:06 --> Output Class Initialized
INFO - 2021-01-12 05:15:06 --> Security Class Initialized
DEBUG - 2021-01-12 05:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:15:06 --> Input Class Initialized
INFO - 2021-01-12 05:15:06 --> Language Class Initialized
INFO - 2021-01-12 05:15:06 --> Language Class Initialized
INFO - 2021-01-12 05:15:06 --> Config Class Initialized
INFO - 2021-01-12 05:15:06 --> Loader Class Initialized
INFO - 2021-01-12 05:15:06 --> Helper loaded: url_helper
INFO - 2021-01-12 05:15:06 --> Helper loaded: file_helper
INFO - 2021-01-12 05:15:06 --> Helper loaded: form_helper
INFO - 2021-01-12 05:15:06 --> Helper loaded: my_helper
INFO - 2021-01-12 05:15:06 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:15:06 --> Controller Class Initialized
DEBUG - 2021-01-12 05:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:15:06 --> Final output sent to browser
DEBUG - 2021-01-12 05:15:06 --> Total execution time: 0.3464
INFO - 2021-01-12 05:15:18 --> Config Class Initialized
INFO - 2021-01-12 05:15:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:15:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:15:18 --> Utf8 Class Initialized
INFO - 2021-01-12 05:15:18 --> URI Class Initialized
INFO - 2021-01-12 05:15:18 --> Router Class Initialized
INFO - 2021-01-12 05:15:18 --> Output Class Initialized
INFO - 2021-01-12 05:15:18 --> Security Class Initialized
DEBUG - 2021-01-12 05:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:15:18 --> Input Class Initialized
INFO - 2021-01-12 05:15:18 --> Language Class Initialized
INFO - 2021-01-12 05:15:18 --> Language Class Initialized
INFO - 2021-01-12 05:15:18 --> Config Class Initialized
INFO - 2021-01-12 05:15:18 --> Loader Class Initialized
INFO - 2021-01-12 05:15:18 --> Helper loaded: url_helper
INFO - 2021-01-12 05:15:18 --> Helper loaded: file_helper
INFO - 2021-01-12 05:15:18 --> Helper loaded: form_helper
INFO - 2021-01-12 05:15:18 --> Helper loaded: my_helper
INFO - 2021-01-12 05:15:18 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:15:18 --> Controller Class Initialized
DEBUG - 2021-01-12 05:15:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:15:18 --> Final output sent to browser
DEBUG - 2021-01-12 05:15:18 --> Total execution time: 0.3558
INFO - 2021-01-12 05:15:41 --> Config Class Initialized
INFO - 2021-01-12 05:15:41 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:15:41 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:15:41 --> Utf8 Class Initialized
INFO - 2021-01-12 05:15:41 --> URI Class Initialized
INFO - 2021-01-12 05:15:41 --> Router Class Initialized
INFO - 2021-01-12 05:15:41 --> Output Class Initialized
INFO - 2021-01-12 05:15:42 --> Security Class Initialized
DEBUG - 2021-01-12 05:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:15:42 --> Input Class Initialized
INFO - 2021-01-12 05:15:42 --> Language Class Initialized
INFO - 2021-01-12 05:15:42 --> Language Class Initialized
INFO - 2021-01-12 05:15:42 --> Config Class Initialized
INFO - 2021-01-12 05:15:42 --> Loader Class Initialized
INFO - 2021-01-12 05:15:42 --> Helper loaded: url_helper
INFO - 2021-01-12 05:15:42 --> Helper loaded: file_helper
INFO - 2021-01-12 05:15:42 --> Helper loaded: form_helper
INFO - 2021-01-12 05:15:42 --> Helper loaded: my_helper
INFO - 2021-01-12 05:15:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:15:42 --> Controller Class Initialized
DEBUG - 2021-01-12 05:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:15:42 --> Final output sent to browser
DEBUG - 2021-01-12 05:15:42 --> Total execution time: 0.3581
INFO - 2021-01-12 05:16:23 --> Config Class Initialized
INFO - 2021-01-12 05:16:23 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:16:23 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:16:23 --> Utf8 Class Initialized
INFO - 2021-01-12 05:16:23 --> URI Class Initialized
INFO - 2021-01-12 05:16:23 --> Router Class Initialized
INFO - 2021-01-12 05:16:23 --> Output Class Initialized
INFO - 2021-01-12 05:16:23 --> Security Class Initialized
DEBUG - 2021-01-12 05:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:16:23 --> Input Class Initialized
INFO - 2021-01-12 05:16:23 --> Language Class Initialized
INFO - 2021-01-12 05:16:23 --> Language Class Initialized
INFO - 2021-01-12 05:16:23 --> Config Class Initialized
INFO - 2021-01-12 05:16:23 --> Loader Class Initialized
INFO - 2021-01-12 05:16:23 --> Helper loaded: url_helper
INFO - 2021-01-12 05:16:23 --> Helper loaded: file_helper
INFO - 2021-01-12 05:16:23 --> Helper loaded: form_helper
INFO - 2021-01-12 05:16:23 --> Helper loaded: my_helper
INFO - 2021-01-12 05:16:23 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:16:23 --> Controller Class Initialized
DEBUG - 2021-01-12 05:16:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:16:23 --> Final output sent to browser
DEBUG - 2021-01-12 05:16:23 --> Total execution time: 0.3517
INFO - 2021-01-12 05:16:35 --> Config Class Initialized
INFO - 2021-01-12 05:16:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:16:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:16:35 --> Utf8 Class Initialized
INFO - 2021-01-12 05:16:35 --> URI Class Initialized
INFO - 2021-01-12 05:16:35 --> Router Class Initialized
INFO - 2021-01-12 05:16:35 --> Output Class Initialized
INFO - 2021-01-12 05:16:35 --> Security Class Initialized
DEBUG - 2021-01-12 05:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:16:35 --> Input Class Initialized
INFO - 2021-01-12 05:16:35 --> Language Class Initialized
INFO - 2021-01-12 05:16:35 --> Language Class Initialized
INFO - 2021-01-12 05:16:35 --> Config Class Initialized
INFO - 2021-01-12 05:16:35 --> Loader Class Initialized
INFO - 2021-01-12 05:16:35 --> Helper loaded: url_helper
INFO - 2021-01-12 05:16:35 --> Helper loaded: file_helper
INFO - 2021-01-12 05:16:35 --> Helper loaded: form_helper
INFO - 2021-01-12 05:16:35 --> Helper loaded: my_helper
INFO - 2021-01-12 05:16:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:16:35 --> Controller Class Initialized
DEBUG - 2021-01-12 05:16:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:16:36 --> Final output sent to browser
DEBUG - 2021-01-12 05:16:36 --> Total execution time: 0.3416
INFO - 2021-01-12 05:16:53 --> Config Class Initialized
INFO - 2021-01-12 05:16:53 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:16:53 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:16:53 --> Utf8 Class Initialized
INFO - 2021-01-12 05:16:53 --> URI Class Initialized
INFO - 2021-01-12 05:16:53 --> Router Class Initialized
INFO - 2021-01-12 05:16:53 --> Output Class Initialized
INFO - 2021-01-12 05:16:53 --> Security Class Initialized
DEBUG - 2021-01-12 05:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:16:53 --> Input Class Initialized
INFO - 2021-01-12 05:16:53 --> Language Class Initialized
INFO - 2021-01-12 05:16:53 --> Language Class Initialized
INFO - 2021-01-12 05:16:53 --> Config Class Initialized
INFO - 2021-01-12 05:16:53 --> Loader Class Initialized
INFO - 2021-01-12 05:16:53 --> Helper loaded: url_helper
INFO - 2021-01-12 05:16:53 --> Helper loaded: file_helper
INFO - 2021-01-12 05:16:53 --> Helper loaded: form_helper
INFO - 2021-01-12 05:16:53 --> Helper loaded: my_helper
INFO - 2021-01-12 05:16:53 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:16:53 --> Controller Class Initialized
DEBUG - 2021-01-12 05:16:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:16:53 --> Final output sent to browser
DEBUG - 2021-01-12 05:16:53 --> Total execution time: 0.3476
INFO - 2021-01-12 05:17:13 --> Config Class Initialized
INFO - 2021-01-12 05:17:13 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:17:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:17:13 --> Utf8 Class Initialized
INFO - 2021-01-12 05:17:13 --> URI Class Initialized
INFO - 2021-01-12 05:17:13 --> Router Class Initialized
INFO - 2021-01-12 05:17:13 --> Output Class Initialized
INFO - 2021-01-12 05:17:13 --> Security Class Initialized
DEBUG - 2021-01-12 05:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:17:13 --> Input Class Initialized
INFO - 2021-01-12 05:17:13 --> Language Class Initialized
INFO - 2021-01-12 05:17:13 --> Language Class Initialized
INFO - 2021-01-12 05:17:13 --> Config Class Initialized
INFO - 2021-01-12 05:17:13 --> Loader Class Initialized
INFO - 2021-01-12 05:17:13 --> Helper loaded: url_helper
INFO - 2021-01-12 05:17:13 --> Helper loaded: file_helper
INFO - 2021-01-12 05:17:13 --> Helper loaded: form_helper
INFO - 2021-01-12 05:17:13 --> Helper loaded: my_helper
INFO - 2021-01-12 05:17:13 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:17:13 --> Controller Class Initialized
DEBUG - 2021-01-12 05:17:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:17:13 --> Final output sent to browser
DEBUG - 2021-01-12 05:17:14 --> Total execution time: 0.3455
INFO - 2021-01-12 05:17:25 --> Config Class Initialized
INFO - 2021-01-12 05:17:25 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:17:25 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:17:25 --> Utf8 Class Initialized
INFO - 2021-01-12 05:17:25 --> URI Class Initialized
INFO - 2021-01-12 05:17:26 --> Router Class Initialized
INFO - 2021-01-12 05:17:26 --> Output Class Initialized
INFO - 2021-01-12 05:17:26 --> Security Class Initialized
DEBUG - 2021-01-12 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:17:26 --> Input Class Initialized
INFO - 2021-01-12 05:17:26 --> Language Class Initialized
INFO - 2021-01-12 05:17:26 --> Language Class Initialized
INFO - 2021-01-12 05:17:26 --> Config Class Initialized
INFO - 2021-01-12 05:17:26 --> Loader Class Initialized
INFO - 2021-01-12 05:17:26 --> Helper loaded: url_helper
INFO - 2021-01-12 05:17:26 --> Helper loaded: file_helper
INFO - 2021-01-12 05:17:26 --> Helper loaded: form_helper
INFO - 2021-01-12 05:17:26 --> Helper loaded: my_helper
INFO - 2021-01-12 05:17:26 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:17:26 --> Controller Class Initialized
DEBUG - 2021-01-12 05:17:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:17:26 --> Final output sent to browser
DEBUG - 2021-01-12 05:17:26 --> Total execution time: 0.3657
INFO - 2021-01-12 05:17:39 --> Config Class Initialized
INFO - 2021-01-12 05:17:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:17:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:17:39 --> Utf8 Class Initialized
INFO - 2021-01-12 05:17:39 --> URI Class Initialized
INFO - 2021-01-12 05:17:39 --> Router Class Initialized
INFO - 2021-01-12 05:17:39 --> Output Class Initialized
INFO - 2021-01-12 05:17:39 --> Security Class Initialized
DEBUG - 2021-01-12 05:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:17:39 --> Input Class Initialized
INFO - 2021-01-12 05:17:39 --> Language Class Initialized
INFO - 2021-01-12 05:17:39 --> Language Class Initialized
INFO - 2021-01-12 05:17:39 --> Config Class Initialized
INFO - 2021-01-12 05:17:39 --> Loader Class Initialized
INFO - 2021-01-12 05:17:39 --> Helper loaded: url_helper
INFO - 2021-01-12 05:17:39 --> Helper loaded: file_helper
INFO - 2021-01-12 05:17:39 --> Helper loaded: form_helper
INFO - 2021-01-12 05:17:39 --> Helper loaded: my_helper
INFO - 2021-01-12 05:17:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:17:39 --> Controller Class Initialized
DEBUG - 2021-01-12 05:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:17:39 --> Final output sent to browser
DEBUG - 2021-01-12 05:17:39 --> Total execution time: 0.3546
INFO - 2021-01-12 05:18:39 --> Config Class Initialized
INFO - 2021-01-12 05:18:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:18:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:18:39 --> Utf8 Class Initialized
INFO - 2021-01-12 05:18:39 --> URI Class Initialized
INFO - 2021-01-12 05:18:39 --> Router Class Initialized
INFO - 2021-01-12 05:18:39 --> Output Class Initialized
INFO - 2021-01-12 05:18:39 --> Security Class Initialized
DEBUG - 2021-01-12 05:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:18:39 --> Input Class Initialized
INFO - 2021-01-12 05:18:39 --> Language Class Initialized
INFO - 2021-01-12 05:18:39 --> Language Class Initialized
INFO - 2021-01-12 05:18:39 --> Config Class Initialized
INFO - 2021-01-12 05:18:39 --> Loader Class Initialized
INFO - 2021-01-12 05:18:39 --> Helper loaded: url_helper
INFO - 2021-01-12 05:18:39 --> Helper loaded: file_helper
INFO - 2021-01-12 05:18:39 --> Helper loaded: form_helper
INFO - 2021-01-12 05:18:39 --> Helper loaded: my_helper
INFO - 2021-01-12 05:18:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:18:39 --> Controller Class Initialized
DEBUG - 2021-01-12 05:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:18:39 --> Final output sent to browser
DEBUG - 2021-01-12 05:18:39 --> Total execution time: 0.3564
INFO - 2021-01-12 05:23:48 --> Config Class Initialized
INFO - 2021-01-12 05:23:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:23:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:23:49 --> Utf8 Class Initialized
INFO - 2021-01-12 05:23:49 --> URI Class Initialized
INFO - 2021-01-12 05:23:49 --> Router Class Initialized
INFO - 2021-01-12 05:23:49 --> Output Class Initialized
INFO - 2021-01-12 05:23:49 --> Security Class Initialized
DEBUG - 2021-01-12 05:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:23:49 --> Input Class Initialized
INFO - 2021-01-12 05:23:49 --> Language Class Initialized
INFO - 2021-01-12 05:23:49 --> Language Class Initialized
INFO - 2021-01-12 05:23:49 --> Config Class Initialized
INFO - 2021-01-12 05:23:49 --> Loader Class Initialized
INFO - 2021-01-12 05:23:49 --> Helper loaded: url_helper
INFO - 2021-01-12 05:23:49 --> Helper loaded: file_helper
INFO - 2021-01-12 05:23:49 --> Helper loaded: form_helper
INFO - 2021-01-12 05:23:49 --> Helper loaded: my_helper
INFO - 2021-01-12 05:23:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:23:49 --> Controller Class Initialized
DEBUG - 2021-01-12 05:23:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:23:50 --> Final output sent to browser
DEBUG - 2021-01-12 05:23:50 --> Total execution time: 1.2217
INFO - 2021-01-12 05:24:09 --> Config Class Initialized
INFO - 2021-01-12 05:24:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:24:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:24:09 --> Utf8 Class Initialized
INFO - 2021-01-12 05:24:09 --> URI Class Initialized
INFO - 2021-01-12 05:24:09 --> Router Class Initialized
INFO - 2021-01-12 05:24:09 --> Output Class Initialized
INFO - 2021-01-12 05:24:09 --> Security Class Initialized
DEBUG - 2021-01-12 05:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:24:09 --> Input Class Initialized
INFO - 2021-01-12 05:24:09 --> Language Class Initialized
INFO - 2021-01-12 05:24:09 --> Language Class Initialized
INFO - 2021-01-12 05:24:09 --> Config Class Initialized
INFO - 2021-01-12 05:24:09 --> Loader Class Initialized
INFO - 2021-01-12 05:24:09 --> Helper loaded: url_helper
INFO - 2021-01-12 05:24:09 --> Helper loaded: file_helper
INFO - 2021-01-12 05:24:09 --> Helper loaded: form_helper
INFO - 2021-01-12 05:24:09 --> Helper loaded: my_helper
INFO - 2021-01-12 05:24:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:24:09 --> Controller Class Initialized
DEBUG - 2021-01-12 05:24:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:24:10 --> Final output sent to browser
DEBUG - 2021-01-12 05:24:10 --> Total execution time: 1.1208
INFO - 2021-01-12 05:27:38 --> Config Class Initialized
INFO - 2021-01-12 05:27:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:27:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:27:38 --> Utf8 Class Initialized
INFO - 2021-01-12 05:27:38 --> URI Class Initialized
INFO - 2021-01-12 05:27:38 --> Router Class Initialized
INFO - 2021-01-12 05:27:38 --> Output Class Initialized
INFO - 2021-01-12 05:27:38 --> Security Class Initialized
DEBUG - 2021-01-12 05:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:27:38 --> Input Class Initialized
INFO - 2021-01-12 05:27:38 --> Language Class Initialized
INFO - 2021-01-12 05:27:38 --> Language Class Initialized
INFO - 2021-01-12 05:27:38 --> Config Class Initialized
INFO - 2021-01-12 05:27:38 --> Loader Class Initialized
INFO - 2021-01-12 05:27:38 --> Helper loaded: url_helper
INFO - 2021-01-12 05:27:38 --> Helper loaded: file_helper
INFO - 2021-01-12 05:27:38 --> Helper loaded: form_helper
INFO - 2021-01-12 05:27:38 --> Helper loaded: my_helper
INFO - 2021-01-12 05:27:38 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:27:38 --> Controller Class Initialized
DEBUG - 2021-01-12 05:27:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:27:39 --> Final output sent to browser
DEBUG - 2021-01-12 05:27:39 --> Total execution time: 1.0848
INFO - 2021-01-12 05:28:34 --> Config Class Initialized
INFO - 2021-01-12 05:28:34 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:28:34 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:28:34 --> Utf8 Class Initialized
INFO - 2021-01-12 05:28:34 --> URI Class Initialized
INFO - 2021-01-12 05:28:35 --> Router Class Initialized
INFO - 2021-01-12 05:28:35 --> Output Class Initialized
INFO - 2021-01-12 05:28:35 --> Security Class Initialized
DEBUG - 2021-01-12 05:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:28:35 --> Input Class Initialized
INFO - 2021-01-12 05:28:35 --> Language Class Initialized
INFO - 2021-01-12 05:28:35 --> Language Class Initialized
INFO - 2021-01-12 05:28:35 --> Config Class Initialized
INFO - 2021-01-12 05:28:35 --> Loader Class Initialized
INFO - 2021-01-12 05:28:35 --> Helper loaded: url_helper
INFO - 2021-01-12 05:28:35 --> Helper loaded: file_helper
INFO - 2021-01-12 05:28:35 --> Helper loaded: form_helper
INFO - 2021-01-12 05:28:35 --> Helper loaded: my_helper
INFO - 2021-01-12 05:28:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:28:35 --> Controller Class Initialized
DEBUG - 2021-01-12 05:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:28:35 --> Final output sent to browser
DEBUG - 2021-01-12 05:28:36 --> Total execution time: 1.2017
INFO - 2021-01-12 05:29:16 --> Config Class Initialized
INFO - 2021-01-12 05:29:16 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:29:16 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:29:16 --> Utf8 Class Initialized
INFO - 2021-01-12 05:29:16 --> URI Class Initialized
INFO - 2021-01-12 05:29:16 --> Router Class Initialized
INFO - 2021-01-12 05:29:17 --> Output Class Initialized
INFO - 2021-01-12 05:29:17 --> Security Class Initialized
DEBUG - 2021-01-12 05:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:29:17 --> Input Class Initialized
INFO - 2021-01-12 05:29:17 --> Language Class Initialized
INFO - 2021-01-12 05:29:17 --> Language Class Initialized
INFO - 2021-01-12 05:29:17 --> Config Class Initialized
INFO - 2021-01-12 05:29:17 --> Loader Class Initialized
INFO - 2021-01-12 05:29:17 --> Helper loaded: url_helper
INFO - 2021-01-12 05:29:17 --> Helper loaded: file_helper
INFO - 2021-01-12 05:29:17 --> Helper loaded: form_helper
INFO - 2021-01-12 05:29:17 --> Helper loaded: my_helper
INFO - 2021-01-12 05:29:17 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:29:17 --> Controller Class Initialized
DEBUG - 2021-01-12 05:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:29:17 --> Final output sent to browser
DEBUG - 2021-01-12 05:29:18 --> Total execution time: 1.1416
INFO - 2021-01-12 05:29:38 --> Config Class Initialized
INFO - 2021-01-12 05:29:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:29:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:29:38 --> Utf8 Class Initialized
INFO - 2021-01-12 05:29:38 --> URI Class Initialized
INFO - 2021-01-12 05:29:38 --> Router Class Initialized
INFO - 2021-01-12 05:29:38 --> Output Class Initialized
INFO - 2021-01-12 05:29:38 --> Security Class Initialized
DEBUG - 2021-01-12 05:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:29:38 --> Input Class Initialized
INFO - 2021-01-12 05:29:38 --> Language Class Initialized
INFO - 2021-01-12 05:29:38 --> Language Class Initialized
INFO - 2021-01-12 05:29:38 --> Config Class Initialized
INFO - 2021-01-12 05:29:39 --> Loader Class Initialized
INFO - 2021-01-12 05:29:39 --> Helper loaded: url_helper
INFO - 2021-01-12 05:29:39 --> Helper loaded: file_helper
INFO - 2021-01-12 05:29:39 --> Helper loaded: form_helper
INFO - 2021-01-12 05:29:39 --> Helper loaded: my_helper
INFO - 2021-01-12 05:29:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:29:39 --> Controller Class Initialized
DEBUG - 2021-01-12 05:29:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:29:39 --> Final output sent to browser
DEBUG - 2021-01-12 05:29:39 --> Total execution time: 1.0373
INFO - 2021-01-12 05:30:35 --> Config Class Initialized
INFO - 2021-01-12 05:30:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:30:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:30:35 --> Utf8 Class Initialized
INFO - 2021-01-12 05:30:35 --> URI Class Initialized
INFO - 2021-01-12 05:30:35 --> Router Class Initialized
INFO - 2021-01-12 05:30:35 --> Output Class Initialized
INFO - 2021-01-12 05:30:35 --> Security Class Initialized
DEBUG - 2021-01-12 05:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:30:35 --> Input Class Initialized
INFO - 2021-01-12 05:30:35 --> Language Class Initialized
INFO - 2021-01-12 05:30:35 --> Language Class Initialized
INFO - 2021-01-12 05:30:35 --> Config Class Initialized
INFO - 2021-01-12 05:30:35 --> Loader Class Initialized
INFO - 2021-01-12 05:30:35 --> Helper loaded: url_helper
INFO - 2021-01-12 05:30:35 --> Helper loaded: file_helper
INFO - 2021-01-12 05:30:35 --> Helper loaded: form_helper
INFO - 2021-01-12 05:30:35 --> Helper loaded: my_helper
INFO - 2021-01-12 05:30:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:30:36 --> Controller Class Initialized
DEBUG - 2021-01-12 05:30:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:30:36 --> Final output sent to browser
DEBUG - 2021-01-12 05:30:36 --> Total execution time: 1.1426
INFO - 2021-01-12 05:31:13 --> Config Class Initialized
INFO - 2021-01-12 05:31:13 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:31:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:31:13 --> Utf8 Class Initialized
INFO - 2021-01-12 05:31:13 --> URI Class Initialized
INFO - 2021-01-12 05:31:13 --> Router Class Initialized
INFO - 2021-01-12 05:31:13 --> Output Class Initialized
INFO - 2021-01-12 05:31:13 --> Security Class Initialized
DEBUG - 2021-01-12 05:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:31:13 --> Input Class Initialized
INFO - 2021-01-12 05:31:13 --> Language Class Initialized
INFO - 2021-01-12 05:31:13 --> Language Class Initialized
INFO - 2021-01-12 05:31:13 --> Config Class Initialized
INFO - 2021-01-12 05:31:13 --> Loader Class Initialized
INFO - 2021-01-12 05:31:13 --> Helper loaded: url_helper
INFO - 2021-01-12 05:31:13 --> Helper loaded: file_helper
INFO - 2021-01-12 05:31:13 --> Helper loaded: form_helper
INFO - 2021-01-12 05:31:13 --> Helper loaded: my_helper
INFO - 2021-01-12 05:31:13 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:31:14 --> Controller Class Initialized
DEBUG - 2021-01-12 05:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:31:14 --> Final output sent to browser
DEBUG - 2021-01-12 05:31:14 --> Total execution time: 1.2607
INFO - 2021-01-12 05:31:26 --> Config Class Initialized
INFO - 2021-01-12 05:31:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:31:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:31:26 --> Utf8 Class Initialized
INFO - 2021-01-12 05:31:27 --> URI Class Initialized
INFO - 2021-01-12 05:31:27 --> Router Class Initialized
INFO - 2021-01-12 05:31:27 --> Output Class Initialized
INFO - 2021-01-12 05:31:27 --> Security Class Initialized
DEBUG - 2021-01-12 05:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:31:27 --> Input Class Initialized
INFO - 2021-01-12 05:31:27 --> Language Class Initialized
INFO - 2021-01-12 05:31:27 --> Language Class Initialized
INFO - 2021-01-12 05:31:27 --> Config Class Initialized
INFO - 2021-01-12 05:31:27 --> Loader Class Initialized
INFO - 2021-01-12 05:31:27 --> Helper loaded: url_helper
INFO - 2021-01-12 05:31:27 --> Helper loaded: file_helper
INFO - 2021-01-12 05:31:27 --> Helper loaded: form_helper
INFO - 2021-01-12 05:31:27 --> Helper loaded: my_helper
INFO - 2021-01-12 05:31:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:31:27 --> Controller Class Initialized
DEBUG - 2021-01-12 05:31:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:31:28 --> Final output sent to browser
DEBUG - 2021-01-12 05:31:28 --> Total execution time: 1.2138
INFO - 2021-01-12 05:32:00 --> Config Class Initialized
INFO - 2021-01-12 05:32:00 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:32:00 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:32:00 --> Utf8 Class Initialized
INFO - 2021-01-12 05:32:00 --> URI Class Initialized
INFO - 2021-01-12 05:32:00 --> Router Class Initialized
INFO - 2021-01-12 05:32:00 --> Output Class Initialized
INFO - 2021-01-12 05:32:00 --> Security Class Initialized
DEBUG - 2021-01-12 05:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:32:00 --> Input Class Initialized
INFO - 2021-01-12 05:32:01 --> Language Class Initialized
INFO - 2021-01-12 05:32:01 --> Language Class Initialized
INFO - 2021-01-12 05:32:01 --> Config Class Initialized
INFO - 2021-01-12 05:32:01 --> Loader Class Initialized
INFO - 2021-01-12 05:32:01 --> Helper loaded: url_helper
INFO - 2021-01-12 05:32:01 --> Helper loaded: file_helper
INFO - 2021-01-12 05:32:01 --> Helper loaded: form_helper
INFO - 2021-01-12 05:32:01 --> Helper loaded: my_helper
INFO - 2021-01-12 05:32:01 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:32:01 --> Controller Class Initialized
DEBUG - 2021-01-12 05:32:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:32:01 --> Final output sent to browser
DEBUG - 2021-01-12 05:32:01 --> Total execution time: 1.0887
INFO - 2021-01-12 05:33:47 --> Config Class Initialized
INFO - 2021-01-12 05:33:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:33:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:33:48 --> Utf8 Class Initialized
INFO - 2021-01-12 05:33:48 --> URI Class Initialized
INFO - 2021-01-12 05:33:48 --> Router Class Initialized
INFO - 2021-01-12 05:33:48 --> Output Class Initialized
INFO - 2021-01-12 05:33:48 --> Security Class Initialized
DEBUG - 2021-01-12 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:33:48 --> Input Class Initialized
INFO - 2021-01-12 05:33:48 --> Language Class Initialized
INFO - 2021-01-12 05:33:48 --> Language Class Initialized
INFO - 2021-01-12 05:33:48 --> Config Class Initialized
INFO - 2021-01-12 05:33:48 --> Loader Class Initialized
INFO - 2021-01-12 05:33:48 --> Helper loaded: url_helper
INFO - 2021-01-12 05:33:48 --> Helper loaded: file_helper
INFO - 2021-01-12 05:33:48 --> Helper loaded: form_helper
INFO - 2021-01-12 05:33:48 --> Helper loaded: my_helper
INFO - 2021-01-12 05:33:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:33:48 --> Controller Class Initialized
DEBUG - 2021-01-12 05:33:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:33:49 --> Final output sent to browser
DEBUG - 2021-01-12 05:33:49 --> Total execution time: 1.1787
INFO - 2021-01-12 05:34:00 --> Config Class Initialized
INFO - 2021-01-12 05:34:01 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:34:01 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:34:01 --> Utf8 Class Initialized
INFO - 2021-01-12 05:34:01 --> URI Class Initialized
INFO - 2021-01-12 05:34:01 --> Router Class Initialized
INFO - 2021-01-12 05:34:01 --> Output Class Initialized
INFO - 2021-01-12 05:34:01 --> Security Class Initialized
DEBUG - 2021-01-12 05:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:34:01 --> Input Class Initialized
INFO - 2021-01-12 05:34:01 --> Language Class Initialized
INFO - 2021-01-12 05:34:01 --> Language Class Initialized
INFO - 2021-01-12 05:34:01 --> Config Class Initialized
INFO - 2021-01-12 05:34:01 --> Loader Class Initialized
INFO - 2021-01-12 05:34:01 --> Helper loaded: url_helper
INFO - 2021-01-12 05:34:01 --> Helper loaded: file_helper
INFO - 2021-01-12 05:34:01 --> Helper loaded: form_helper
INFO - 2021-01-12 05:34:01 --> Helper loaded: my_helper
INFO - 2021-01-12 05:34:01 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:34:01 --> Controller Class Initialized
DEBUG - 2021-01-12 05:34:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:34:02 --> Final output sent to browser
DEBUG - 2021-01-12 05:34:02 --> Total execution time: 1.1993
INFO - 2021-01-12 05:34:16 --> Config Class Initialized
INFO - 2021-01-12 05:34:16 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:34:16 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:34:16 --> Utf8 Class Initialized
INFO - 2021-01-12 05:34:16 --> URI Class Initialized
INFO - 2021-01-12 05:34:16 --> Router Class Initialized
INFO - 2021-01-12 05:34:16 --> Output Class Initialized
INFO - 2021-01-12 05:34:16 --> Security Class Initialized
DEBUG - 2021-01-12 05:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:34:16 --> Input Class Initialized
INFO - 2021-01-12 05:34:16 --> Language Class Initialized
INFO - 2021-01-12 05:34:17 --> Language Class Initialized
INFO - 2021-01-12 05:34:17 --> Config Class Initialized
INFO - 2021-01-12 05:34:17 --> Loader Class Initialized
INFO - 2021-01-12 05:34:17 --> Helper loaded: url_helper
INFO - 2021-01-12 05:34:17 --> Helper loaded: file_helper
INFO - 2021-01-12 05:34:17 --> Helper loaded: form_helper
INFO - 2021-01-12 05:34:17 --> Helper loaded: my_helper
INFO - 2021-01-12 05:34:17 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:34:17 --> Controller Class Initialized
DEBUG - 2021-01-12 05:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:34:17 --> Final output sent to browser
DEBUG - 2021-01-12 05:34:17 --> Total execution time: 1.1445
INFO - 2021-01-12 05:34:33 --> Config Class Initialized
INFO - 2021-01-12 05:34:33 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:34:34 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:34:34 --> Utf8 Class Initialized
INFO - 2021-01-12 05:34:34 --> URI Class Initialized
INFO - 2021-01-12 05:34:34 --> Router Class Initialized
INFO - 2021-01-12 05:34:34 --> Output Class Initialized
INFO - 2021-01-12 05:34:34 --> Security Class Initialized
DEBUG - 2021-01-12 05:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:34:34 --> Input Class Initialized
INFO - 2021-01-12 05:34:34 --> Language Class Initialized
INFO - 2021-01-12 05:34:34 --> Language Class Initialized
INFO - 2021-01-12 05:34:34 --> Config Class Initialized
INFO - 2021-01-12 05:34:34 --> Loader Class Initialized
INFO - 2021-01-12 05:34:34 --> Helper loaded: url_helper
INFO - 2021-01-12 05:34:34 --> Helper loaded: file_helper
INFO - 2021-01-12 05:34:34 --> Helper loaded: form_helper
INFO - 2021-01-12 05:34:34 --> Helper loaded: my_helper
INFO - 2021-01-12 05:34:34 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:34:34 --> Controller Class Initialized
DEBUG - 2021-01-12 05:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:34:35 --> Final output sent to browser
DEBUG - 2021-01-12 05:34:35 --> Total execution time: 1.2063
INFO - 2021-01-12 05:40:10 --> Config Class Initialized
INFO - 2021-01-12 05:40:10 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:40:10 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:40:10 --> Utf8 Class Initialized
INFO - 2021-01-12 05:40:11 --> URI Class Initialized
INFO - 2021-01-12 05:40:11 --> Router Class Initialized
INFO - 2021-01-12 05:40:11 --> Output Class Initialized
INFO - 2021-01-12 05:40:11 --> Security Class Initialized
DEBUG - 2021-01-12 05:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:40:11 --> Input Class Initialized
INFO - 2021-01-12 05:40:11 --> Language Class Initialized
INFO - 2021-01-12 05:40:11 --> Language Class Initialized
INFO - 2021-01-12 05:40:11 --> Config Class Initialized
INFO - 2021-01-12 05:40:11 --> Loader Class Initialized
INFO - 2021-01-12 05:40:11 --> Helper loaded: url_helper
INFO - 2021-01-12 05:40:11 --> Helper loaded: file_helper
INFO - 2021-01-12 05:40:11 --> Helper loaded: form_helper
INFO - 2021-01-12 05:40:11 --> Helper loaded: my_helper
INFO - 2021-01-12 05:40:11 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:40:11 --> Controller Class Initialized
DEBUG - 2021-01-12 05:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:40:12 --> Final output sent to browser
DEBUG - 2021-01-12 05:40:12 --> Total execution time: 1.2345
INFO - 2021-01-12 05:41:13 --> Config Class Initialized
INFO - 2021-01-12 05:41:13 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:41:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:41:13 --> Utf8 Class Initialized
INFO - 2021-01-12 05:41:13 --> URI Class Initialized
INFO - 2021-01-12 05:41:13 --> Router Class Initialized
INFO - 2021-01-12 05:41:13 --> Output Class Initialized
INFO - 2021-01-12 05:41:13 --> Security Class Initialized
DEBUG - 2021-01-12 05:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:41:13 --> Input Class Initialized
INFO - 2021-01-12 05:41:13 --> Language Class Initialized
INFO - 2021-01-12 05:41:13 --> Language Class Initialized
INFO - 2021-01-12 05:41:13 --> Config Class Initialized
INFO - 2021-01-12 05:41:13 --> Loader Class Initialized
INFO - 2021-01-12 05:41:13 --> Helper loaded: url_helper
INFO - 2021-01-12 05:41:13 --> Helper loaded: file_helper
INFO - 2021-01-12 05:41:13 --> Helper loaded: form_helper
INFO - 2021-01-12 05:41:13 --> Helper loaded: my_helper
INFO - 2021-01-12 05:41:13 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:41:14 --> Controller Class Initialized
DEBUG - 2021-01-12 05:41:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:41:14 --> Final output sent to browser
DEBUG - 2021-01-12 05:41:14 --> Total execution time: 1.0582
INFO - 2021-01-12 05:41:49 --> Config Class Initialized
INFO - 2021-01-12 05:41:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:41:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:41:50 --> Utf8 Class Initialized
INFO - 2021-01-12 05:41:50 --> URI Class Initialized
INFO - 2021-01-12 05:41:50 --> Router Class Initialized
INFO - 2021-01-12 05:41:50 --> Output Class Initialized
INFO - 2021-01-12 05:41:50 --> Security Class Initialized
DEBUG - 2021-01-12 05:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:41:50 --> Input Class Initialized
INFO - 2021-01-12 05:41:50 --> Language Class Initialized
INFO - 2021-01-12 05:41:50 --> Language Class Initialized
INFO - 2021-01-12 05:41:50 --> Config Class Initialized
INFO - 2021-01-12 05:41:50 --> Loader Class Initialized
INFO - 2021-01-12 05:41:50 --> Helper loaded: url_helper
INFO - 2021-01-12 05:41:50 --> Helper loaded: file_helper
INFO - 2021-01-12 05:41:50 --> Helper loaded: form_helper
INFO - 2021-01-12 05:41:50 --> Helper loaded: my_helper
INFO - 2021-01-12 05:41:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:41:50 --> Controller Class Initialized
DEBUG - 2021-01-12 05:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:41:51 --> Final output sent to browser
DEBUG - 2021-01-12 05:41:51 --> Total execution time: 1.2298
INFO - 2021-01-12 05:42:09 --> Config Class Initialized
INFO - 2021-01-12 05:42:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:42:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:42:09 --> Utf8 Class Initialized
INFO - 2021-01-12 05:42:09 --> URI Class Initialized
INFO - 2021-01-12 05:42:09 --> Router Class Initialized
INFO - 2021-01-12 05:42:09 --> Output Class Initialized
INFO - 2021-01-12 05:42:09 --> Security Class Initialized
DEBUG - 2021-01-12 05:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:42:09 --> Input Class Initialized
INFO - 2021-01-12 05:42:09 --> Language Class Initialized
INFO - 2021-01-12 05:42:09 --> Language Class Initialized
INFO - 2021-01-12 05:42:09 --> Config Class Initialized
INFO - 2021-01-12 05:42:09 --> Loader Class Initialized
INFO - 2021-01-12 05:42:09 --> Helper loaded: url_helper
INFO - 2021-01-12 05:42:09 --> Helper loaded: file_helper
INFO - 2021-01-12 05:42:09 --> Helper loaded: form_helper
INFO - 2021-01-12 05:42:09 --> Helper loaded: my_helper
INFO - 2021-01-12 05:42:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:42:10 --> Controller Class Initialized
DEBUG - 2021-01-12 05:42:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:42:10 --> Final output sent to browser
DEBUG - 2021-01-12 05:42:10 --> Total execution time: 1.1995
INFO - 2021-01-12 05:42:27 --> Config Class Initialized
INFO - 2021-01-12 05:42:27 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:42:27 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:42:27 --> Utf8 Class Initialized
INFO - 2021-01-12 05:42:27 --> URI Class Initialized
INFO - 2021-01-12 05:42:27 --> Router Class Initialized
INFO - 2021-01-12 05:42:27 --> Output Class Initialized
INFO - 2021-01-12 05:42:27 --> Security Class Initialized
DEBUG - 2021-01-12 05:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:42:27 --> Input Class Initialized
INFO - 2021-01-12 05:42:27 --> Language Class Initialized
INFO - 2021-01-12 05:42:28 --> Language Class Initialized
INFO - 2021-01-12 05:42:28 --> Config Class Initialized
INFO - 2021-01-12 05:42:28 --> Loader Class Initialized
INFO - 2021-01-12 05:42:28 --> Helper loaded: url_helper
INFO - 2021-01-12 05:42:28 --> Helper loaded: file_helper
INFO - 2021-01-12 05:42:28 --> Helper loaded: form_helper
INFO - 2021-01-12 05:42:28 --> Helper loaded: my_helper
INFO - 2021-01-12 05:42:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:42:28 --> Controller Class Initialized
DEBUG - 2021-01-12 05:42:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:42:28 --> Final output sent to browser
DEBUG - 2021-01-12 05:42:28 --> Total execution time: 1.2486
INFO - 2021-01-12 05:42:52 --> Config Class Initialized
INFO - 2021-01-12 05:42:52 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:42:52 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:42:52 --> Utf8 Class Initialized
INFO - 2021-01-12 05:42:52 --> URI Class Initialized
INFO - 2021-01-12 05:42:52 --> Router Class Initialized
INFO - 2021-01-12 05:42:52 --> Output Class Initialized
INFO - 2021-01-12 05:42:52 --> Security Class Initialized
DEBUG - 2021-01-12 05:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:42:52 --> Input Class Initialized
INFO - 2021-01-12 05:42:52 --> Language Class Initialized
INFO - 2021-01-12 05:42:52 --> Language Class Initialized
INFO - 2021-01-12 05:42:53 --> Config Class Initialized
INFO - 2021-01-12 05:42:53 --> Loader Class Initialized
INFO - 2021-01-12 05:42:53 --> Helper loaded: url_helper
INFO - 2021-01-12 05:42:53 --> Helper loaded: file_helper
INFO - 2021-01-12 05:42:53 --> Helper loaded: form_helper
INFO - 2021-01-12 05:42:53 --> Helper loaded: my_helper
INFO - 2021-01-12 05:42:53 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:42:53 --> Controller Class Initialized
DEBUG - 2021-01-12 05:42:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:42:53 --> Final output sent to browser
DEBUG - 2021-01-12 05:42:53 --> Total execution time: 1.2084
INFO - 2021-01-12 05:43:14 --> Config Class Initialized
INFO - 2021-01-12 05:43:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:43:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:43:14 --> Utf8 Class Initialized
INFO - 2021-01-12 05:43:14 --> URI Class Initialized
INFO - 2021-01-12 05:43:14 --> Router Class Initialized
INFO - 2021-01-12 05:43:14 --> Output Class Initialized
INFO - 2021-01-12 05:43:14 --> Security Class Initialized
DEBUG - 2021-01-12 05:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:43:14 --> Input Class Initialized
INFO - 2021-01-12 05:43:14 --> Language Class Initialized
INFO - 2021-01-12 05:43:14 --> Language Class Initialized
INFO - 2021-01-12 05:43:14 --> Config Class Initialized
INFO - 2021-01-12 05:43:14 --> Loader Class Initialized
INFO - 2021-01-12 05:43:14 --> Helper loaded: url_helper
INFO - 2021-01-12 05:43:14 --> Helper loaded: file_helper
INFO - 2021-01-12 05:43:14 --> Helper loaded: form_helper
INFO - 2021-01-12 05:43:14 --> Helper loaded: my_helper
INFO - 2021-01-12 05:43:14 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:43:15 --> Controller Class Initialized
DEBUG - 2021-01-12 05:43:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-12 05:43:15 --> Final output sent to browser
DEBUG - 2021-01-12 05:43:15 --> Total execution time: 1.2996
INFO - 2021-01-12 05:44:47 --> Config Class Initialized
INFO - 2021-01-12 05:44:47 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:44:47 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:44:47 --> Utf8 Class Initialized
INFO - 2021-01-12 05:44:47 --> URI Class Initialized
INFO - 2021-01-12 05:44:47 --> Router Class Initialized
INFO - 2021-01-12 05:44:47 --> Output Class Initialized
INFO - 2021-01-12 05:44:47 --> Security Class Initialized
DEBUG - 2021-01-12 05:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:44:47 --> Input Class Initialized
INFO - 2021-01-12 05:44:47 --> Language Class Initialized
INFO - 2021-01-12 05:44:47 --> Language Class Initialized
INFO - 2021-01-12 05:44:47 --> Config Class Initialized
INFO - 2021-01-12 05:44:47 --> Loader Class Initialized
INFO - 2021-01-12 05:44:47 --> Helper loaded: url_helper
INFO - 2021-01-12 05:44:47 --> Helper loaded: file_helper
INFO - 2021-01-12 05:44:47 --> Helper loaded: form_helper
INFO - 2021-01-12 05:44:48 --> Helper loaded: my_helper
INFO - 2021-01-12 05:44:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:44:48 --> Controller Class Initialized
INFO - 2021-01-12 05:44:48 --> Helper loaded: cookie_helper
INFO - 2021-01-12 05:44:48 --> Config Class Initialized
INFO - 2021-01-12 05:44:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:44:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:44:48 --> Utf8 Class Initialized
INFO - 2021-01-12 05:44:48 --> URI Class Initialized
INFO - 2021-01-12 05:44:48 --> Router Class Initialized
INFO - 2021-01-12 05:44:48 --> Output Class Initialized
INFO - 2021-01-12 05:44:48 --> Security Class Initialized
DEBUG - 2021-01-12 05:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:44:48 --> Input Class Initialized
INFO - 2021-01-12 05:44:48 --> Language Class Initialized
INFO - 2021-01-12 05:44:48 --> Language Class Initialized
INFO - 2021-01-12 05:44:48 --> Config Class Initialized
INFO - 2021-01-12 05:44:48 --> Loader Class Initialized
INFO - 2021-01-12 05:44:48 --> Helper loaded: url_helper
INFO - 2021-01-12 05:44:48 --> Helper loaded: file_helper
INFO - 2021-01-12 05:44:49 --> Helper loaded: form_helper
INFO - 2021-01-12 05:44:49 --> Helper loaded: my_helper
INFO - 2021-01-12 05:44:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:44:49 --> Controller Class Initialized
DEBUG - 2021-01-12 05:44:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 05:44:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:44:49 --> Final output sent to browser
DEBUG - 2021-01-12 05:44:49 --> Total execution time: 1.0627
INFO - 2021-01-12 05:44:54 --> Config Class Initialized
INFO - 2021-01-12 05:44:54 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:44:54 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:44:54 --> Utf8 Class Initialized
INFO - 2021-01-12 05:44:54 --> URI Class Initialized
INFO - 2021-01-12 05:44:54 --> Router Class Initialized
INFO - 2021-01-12 05:44:54 --> Output Class Initialized
INFO - 2021-01-12 05:44:54 --> Security Class Initialized
DEBUG - 2021-01-12 05:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:44:54 --> Input Class Initialized
INFO - 2021-01-12 05:44:54 --> Language Class Initialized
INFO - 2021-01-12 05:44:54 --> Language Class Initialized
INFO - 2021-01-12 05:44:54 --> Config Class Initialized
INFO - 2021-01-12 05:44:54 --> Loader Class Initialized
INFO - 2021-01-12 05:44:54 --> Helper loaded: url_helper
INFO - 2021-01-12 05:44:54 --> Helper loaded: file_helper
INFO - 2021-01-12 05:44:54 --> Helper loaded: form_helper
INFO - 2021-01-12 05:44:54 --> Helper loaded: my_helper
INFO - 2021-01-12 05:44:54 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:44:54 --> Controller Class Initialized
INFO - 2021-01-12 05:44:55 --> Helper loaded: cookie_helper
INFO - 2021-01-12 05:44:55 --> Final output sent to browser
DEBUG - 2021-01-12 05:44:55 --> Total execution time: 0.9118
INFO - 2021-01-12 05:44:55 --> Config Class Initialized
INFO - 2021-01-12 05:44:55 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:44:55 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:44:55 --> Utf8 Class Initialized
INFO - 2021-01-12 05:44:55 --> URI Class Initialized
INFO - 2021-01-12 05:44:56 --> Router Class Initialized
INFO - 2021-01-12 05:44:56 --> Output Class Initialized
INFO - 2021-01-12 05:44:56 --> Security Class Initialized
DEBUG - 2021-01-12 05:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:44:56 --> Input Class Initialized
INFO - 2021-01-12 05:44:56 --> Language Class Initialized
INFO - 2021-01-12 05:44:56 --> Language Class Initialized
INFO - 2021-01-12 05:44:56 --> Config Class Initialized
INFO - 2021-01-12 05:44:56 --> Loader Class Initialized
INFO - 2021-01-12 05:44:56 --> Helper loaded: url_helper
INFO - 2021-01-12 05:44:56 --> Helper loaded: file_helper
INFO - 2021-01-12 05:44:56 --> Helper loaded: form_helper
INFO - 2021-01-12 05:44:56 --> Helper loaded: my_helper
INFO - 2021-01-12 05:44:56 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:44:56 --> Controller Class Initialized
DEBUG - 2021-01-12 05:44:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 05:44:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:44:56 --> Final output sent to browser
DEBUG - 2021-01-12 05:44:56 --> Total execution time: 0.9195
INFO - 2021-01-12 05:44:59 --> Config Class Initialized
INFO - 2021-01-12 05:44:59 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:44:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:44:59 --> Utf8 Class Initialized
INFO - 2021-01-12 05:44:59 --> URI Class Initialized
INFO - 2021-01-12 05:44:59 --> Router Class Initialized
INFO - 2021-01-12 05:44:59 --> Output Class Initialized
INFO - 2021-01-12 05:44:59 --> Security Class Initialized
DEBUG - 2021-01-12 05:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:44:59 --> Input Class Initialized
INFO - 2021-01-12 05:44:59 --> Language Class Initialized
INFO - 2021-01-12 05:44:59 --> Language Class Initialized
INFO - 2021-01-12 05:44:59 --> Config Class Initialized
INFO - 2021-01-12 05:44:59 --> Loader Class Initialized
INFO - 2021-01-12 05:44:59 --> Helper loaded: url_helper
INFO - 2021-01-12 05:44:59 --> Helper loaded: file_helper
INFO - 2021-01-12 05:44:59 --> Helper loaded: form_helper
INFO - 2021-01-12 05:44:59 --> Helper loaded: my_helper
INFO - 2021-01-12 05:44:59 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:44:59 --> Controller Class Initialized
DEBUG - 2021-01-12 05:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 05:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:45:00 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:00 --> Total execution time: 1.0095
INFO - 2021-01-12 05:45:01 --> Config Class Initialized
INFO - 2021-01-12 05:45:01 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:45:02 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:45:02 --> Utf8 Class Initialized
INFO - 2021-01-12 05:45:02 --> URI Class Initialized
INFO - 2021-01-12 05:45:02 --> Router Class Initialized
INFO - 2021-01-12 05:45:02 --> Output Class Initialized
INFO - 2021-01-12 05:45:02 --> Security Class Initialized
DEBUG - 2021-01-12 05:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:45:02 --> Input Class Initialized
INFO - 2021-01-12 05:45:02 --> Language Class Initialized
INFO - 2021-01-12 05:45:02 --> Language Class Initialized
INFO - 2021-01-12 05:45:02 --> Config Class Initialized
INFO - 2021-01-12 05:45:02 --> Loader Class Initialized
INFO - 2021-01-12 05:45:02 --> Helper loaded: url_helper
INFO - 2021-01-12 05:45:02 --> Helper loaded: file_helper
INFO - 2021-01-12 05:45:02 --> Helper loaded: form_helper
INFO - 2021-01-12 05:45:02 --> Helper loaded: my_helper
INFO - 2021-01-12 05:45:02 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:45:02 --> Controller Class Initialized
DEBUG - 2021-01-12 05:45:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:45:03 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:03 --> Total execution time: 1.1133
INFO - 2021-01-12 05:45:14 --> Config Class Initialized
INFO - 2021-01-12 05:45:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:45:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:45:14 --> Utf8 Class Initialized
INFO - 2021-01-12 05:45:14 --> URI Class Initialized
INFO - 2021-01-12 05:45:14 --> Router Class Initialized
INFO - 2021-01-12 05:45:15 --> Output Class Initialized
INFO - 2021-01-12 05:45:15 --> Security Class Initialized
DEBUG - 2021-01-12 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:45:15 --> Input Class Initialized
INFO - 2021-01-12 05:45:15 --> Language Class Initialized
INFO - 2021-01-12 05:45:15 --> Language Class Initialized
INFO - 2021-01-12 05:45:15 --> Config Class Initialized
INFO - 2021-01-12 05:45:15 --> Loader Class Initialized
INFO - 2021-01-12 05:45:15 --> Helper loaded: url_helper
INFO - 2021-01-12 05:45:15 --> Helper loaded: file_helper
INFO - 2021-01-12 05:45:15 --> Helper loaded: form_helper
INFO - 2021-01-12 05:45:15 --> Helper loaded: my_helper
INFO - 2021-01-12 05:45:15 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:45:15 --> Controller Class Initialized
DEBUG - 2021-01-12 05:45:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 05:45:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:45:16 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:16 --> Total execution time: 1.3000
INFO - 2021-01-12 05:45:23 --> Config Class Initialized
INFO - 2021-01-12 05:45:23 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:45:23 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:45:23 --> Utf8 Class Initialized
INFO - 2021-01-12 05:45:23 --> URI Class Initialized
INFO - 2021-01-12 05:45:23 --> Router Class Initialized
INFO - 2021-01-12 05:45:23 --> Output Class Initialized
INFO - 2021-01-12 05:45:23 --> Security Class Initialized
DEBUG - 2021-01-12 05:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:45:23 --> Input Class Initialized
INFO - 2021-01-12 05:45:23 --> Language Class Initialized
INFO - 2021-01-12 05:45:24 --> Language Class Initialized
INFO - 2021-01-12 05:45:24 --> Config Class Initialized
INFO - 2021-01-12 05:45:24 --> Loader Class Initialized
INFO - 2021-01-12 05:45:24 --> Helper loaded: url_helper
INFO - 2021-01-12 05:45:24 --> Helper loaded: file_helper
INFO - 2021-01-12 05:45:24 --> Helper loaded: form_helper
INFO - 2021-01-12 05:45:24 --> Helper loaded: my_helper
INFO - 2021-01-12 05:45:24 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:45:24 --> Controller Class Initialized
INFO - 2021-01-12 05:45:24 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:24 --> Total execution time: 1.0708
INFO - 2021-01-12 05:45:26 --> Config Class Initialized
INFO - 2021-01-12 05:45:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:45:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:45:26 --> Utf8 Class Initialized
INFO - 2021-01-12 05:45:26 --> URI Class Initialized
INFO - 2021-01-12 05:45:26 --> Router Class Initialized
INFO - 2021-01-12 05:45:26 --> Output Class Initialized
INFO - 2021-01-12 05:45:26 --> Security Class Initialized
DEBUG - 2021-01-12 05:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:45:26 --> Input Class Initialized
INFO - 2021-01-12 05:45:26 --> Language Class Initialized
INFO - 2021-01-12 05:45:26 --> Language Class Initialized
INFO - 2021-01-12 05:45:26 --> Config Class Initialized
INFO - 2021-01-12 05:45:26 --> Loader Class Initialized
INFO - 2021-01-12 05:45:27 --> Helper loaded: url_helper
INFO - 2021-01-12 05:45:27 --> Helper loaded: file_helper
INFO - 2021-01-12 05:45:27 --> Helper loaded: form_helper
INFO - 2021-01-12 05:45:27 --> Helper loaded: my_helper
INFO - 2021-01-12 05:45:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:45:27 --> Controller Class Initialized
DEBUG - 2021-01-12 05:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 05:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:45:27 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:27 --> Total execution time: 1.1662
INFO - 2021-01-12 05:45:29 --> Config Class Initialized
INFO - 2021-01-12 05:45:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:45:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:45:29 --> Utf8 Class Initialized
INFO - 2021-01-12 05:45:29 --> URI Class Initialized
INFO - 2021-01-12 05:45:29 --> Router Class Initialized
INFO - 2021-01-12 05:45:29 --> Output Class Initialized
INFO - 2021-01-12 05:45:29 --> Security Class Initialized
DEBUG - 2021-01-12 05:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:45:29 --> Input Class Initialized
INFO - 2021-01-12 05:45:29 --> Language Class Initialized
INFO - 2021-01-12 05:45:29 --> Language Class Initialized
INFO - 2021-01-12 05:45:29 --> Config Class Initialized
INFO - 2021-01-12 05:45:29 --> Loader Class Initialized
INFO - 2021-01-12 05:45:29 --> Helper loaded: url_helper
INFO - 2021-01-12 05:45:29 --> Helper loaded: file_helper
INFO - 2021-01-12 05:45:29 --> Helper loaded: form_helper
INFO - 2021-01-12 05:45:29 --> Helper loaded: my_helper
INFO - 2021-01-12 05:45:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:45:30 --> Controller Class Initialized
DEBUG - 2021-01-12 05:45:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:45:30 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:30 --> Total execution time: 0.9607
INFO - 2021-01-12 05:45:37 --> Config Class Initialized
INFO - 2021-01-12 05:45:37 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:45:37 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:45:37 --> Utf8 Class Initialized
INFO - 2021-01-12 05:45:37 --> URI Class Initialized
INFO - 2021-01-12 05:45:37 --> Router Class Initialized
INFO - 2021-01-12 05:45:37 --> Output Class Initialized
INFO - 2021-01-12 05:45:37 --> Security Class Initialized
DEBUG - 2021-01-12 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:45:37 --> Input Class Initialized
INFO - 2021-01-12 05:45:37 --> Language Class Initialized
INFO - 2021-01-12 05:45:37 --> Language Class Initialized
INFO - 2021-01-12 05:45:37 --> Config Class Initialized
INFO - 2021-01-12 05:45:37 --> Loader Class Initialized
INFO - 2021-01-12 05:45:37 --> Helper loaded: url_helper
INFO - 2021-01-12 05:45:37 --> Helper loaded: file_helper
INFO - 2021-01-12 05:45:37 --> Helper loaded: form_helper
INFO - 2021-01-12 05:45:37 --> Helper loaded: my_helper
INFO - 2021-01-12 05:45:37 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:45:37 --> Controller Class Initialized
DEBUG - 2021-01-12 05:45:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 05:45:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:45:38 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:38 --> Total execution time: 0.9922
INFO - 2021-01-12 05:45:45 --> Config Class Initialized
INFO - 2021-01-12 05:45:45 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:45:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:45:46 --> Utf8 Class Initialized
INFO - 2021-01-12 05:45:46 --> URI Class Initialized
INFO - 2021-01-12 05:45:46 --> Router Class Initialized
INFO - 2021-01-12 05:45:46 --> Output Class Initialized
INFO - 2021-01-12 05:45:46 --> Security Class Initialized
DEBUG - 2021-01-12 05:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:45:46 --> Input Class Initialized
INFO - 2021-01-12 05:45:46 --> Language Class Initialized
INFO - 2021-01-12 05:45:46 --> Language Class Initialized
INFO - 2021-01-12 05:45:46 --> Config Class Initialized
INFO - 2021-01-12 05:45:46 --> Loader Class Initialized
INFO - 2021-01-12 05:45:46 --> Helper loaded: url_helper
INFO - 2021-01-12 05:45:46 --> Helper loaded: file_helper
INFO - 2021-01-12 05:45:46 --> Helper loaded: form_helper
INFO - 2021-01-12 05:45:46 --> Helper loaded: my_helper
INFO - 2021-01-12 05:45:46 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:45:46 --> Controller Class Initialized
INFO - 2021-01-12 05:45:46 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:47 --> Total execution time: 1.0768
INFO - 2021-01-12 05:45:53 --> Config Class Initialized
INFO - 2021-01-12 05:45:53 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:45:53 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:45:53 --> Utf8 Class Initialized
INFO - 2021-01-12 05:45:53 --> URI Class Initialized
INFO - 2021-01-12 05:45:53 --> Router Class Initialized
INFO - 2021-01-12 05:45:53 --> Output Class Initialized
INFO - 2021-01-12 05:45:53 --> Security Class Initialized
DEBUG - 2021-01-12 05:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:45:53 --> Input Class Initialized
INFO - 2021-01-12 05:45:53 --> Language Class Initialized
INFO - 2021-01-12 05:45:54 --> Language Class Initialized
INFO - 2021-01-12 05:45:54 --> Config Class Initialized
INFO - 2021-01-12 05:45:54 --> Loader Class Initialized
INFO - 2021-01-12 05:45:54 --> Helper loaded: url_helper
INFO - 2021-01-12 05:45:54 --> Helper loaded: file_helper
INFO - 2021-01-12 05:45:54 --> Helper loaded: form_helper
INFO - 2021-01-12 05:45:54 --> Helper loaded: my_helper
INFO - 2021-01-12 05:45:54 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:45:54 --> Controller Class Initialized
DEBUG - 2021-01-12 05:45:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:45:54 --> Final output sent to browser
DEBUG - 2021-01-12 05:45:54 --> Total execution time: 1.1127
INFO - 2021-01-12 05:46:18 --> Config Class Initialized
INFO - 2021-01-12 05:46:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:46:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:46:18 --> Utf8 Class Initialized
INFO - 2021-01-12 05:46:18 --> URI Class Initialized
INFO - 2021-01-12 05:46:18 --> Router Class Initialized
INFO - 2021-01-12 05:46:18 --> Output Class Initialized
INFO - 2021-01-12 05:46:18 --> Security Class Initialized
DEBUG - 2021-01-12 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:46:18 --> Input Class Initialized
INFO - 2021-01-12 05:46:18 --> Language Class Initialized
INFO - 2021-01-12 05:46:18 --> Language Class Initialized
INFO - 2021-01-12 05:46:18 --> Config Class Initialized
INFO - 2021-01-12 05:46:18 --> Loader Class Initialized
INFO - 2021-01-12 05:46:19 --> Helper loaded: url_helper
INFO - 2021-01-12 05:46:19 --> Helper loaded: file_helper
INFO - 2021-01-12 05:46:19 --> Helper loaded: form_helper
INFO - 2021-01-12 05:46:19 --> Helper loaded: my_helper
INFO - 2021-01-12 05:46:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:46:19 --> Controller Class Initialized
DEBUG - 2021-01-12 05:46:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:46:19 --> Final output sent to browser
DEBUG - 2021-01-12 05:46:19 --> Total execution time: 1.2896
INFO - 2021-01-12 05:46:36 --> Config Class Initialized
INFO - 2021-01-12 05:46:36 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:46:36 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:46:36 --> Utf8 Class Initialized
INFO - 2021-01-12 05:46:36 --> URI Class Initialized
INFO - 2021-01-12 05:46:36 --> Router Class Initialized
INFO - 2021-01-12 05:46:36 --> Output Class Initialized
INFO - 2021-01-12 05:46:36 --> Security Class Initialized
DEBUG - 2021-01-12 05:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:46:36 --> Input Class Initialized
INFO - 2021-01-12 05:46:36 --> Language Class Initialized
INFO - 2021-01-12 05:46:36 --> Language Class Initialized
INFO - 2021-01-12 05:46:36 --> Config Class Initialized
INFO - 2021-01-12 05:46:36 --> Loader Class Initialized
INFO - 2021-01-12 05:46:36 --> Helper loaded: url_helper
INFO - 2021-01-12 05:46:37 --> Helper loaded: file_helper
INFO - 2021-01-12 05:46:37 --> Helper loaded: form_helper
INFO - 2021-01-12 05:46:37 --> Helper loaded: my_helper
INFO - 2021-01-12 05:46:37 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:46:37 --> Controller Class Initialized
DEBUG - 2021-01-12 05:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:46:37 --> Final output sent to browser
DEBUG - 2021-01-12 05:46:37 --> Total execution time: 1.2405
INFO - 2021-01-12 05:46:49 --> Config Class Initialized
INFO - 2021-01-12 05:46:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:46:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:46:49 --> Utf8 Class Initialized
INFO - 2021-01-12 05:46:49 --> URI Class Initialized
INFO - 2021-01-12 05:46:49 --> Router Class Initialized
INFO - 2021-01-12 05:46:49 --> Output Class Initialized
INFO - 2021-01-12 05:46:49 --> Security Class Initialized
DEBUG - 2021-01-12 05:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:46:49 --> Input Class Initialized
INFO - 2021-01-12 05:46:49 --> Language Class Initialized
INFO - 2021-01-12 05:46:50 --> Language Class Initialized
INFO - 2021-01-12 05:46:50 --> Config Class Initialized
INFO - 2021-01-12 05:46:50 --> Loader Class Initialized
INFO - 2021-01-12 05:46:50 --> Helper loaded: url_helper
INFO - 2021-01-12 05:46:50 --> Helper loaded: file_helper
INFO - 2021-01-12 05:46:50 --> Helper loaded: form_helper
INFO - 2021-01-12 05:46:50 --> Helper loaded: my_helper
INFO - 2021-01-12 05:46:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:46:50 --> Controller Class Initialized
DEBUG - 2021-01-12 05:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:46:50 --> Final output sent to browser
DEBUG - 2021-01-12 05:46:50 --> Total execution time: 1.2814
INFO - 2021-01-12 05:47:08 --> Config Class Initialized
INFO - 2021-01-12 05:47:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:47:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:47:08 --> Utf8 Class Initialized
INFO - 2021-01-12 05:47:08 --> URI Class Initialized
INFO - 2021-01-12 05:47:08 --> Router Class Initialized
INFO - 2021-01-12 05:47:08 --> Output Class Initialized
INFO - 2021-01-12 05:47:08 --> Security Class Initialized
DEBUG - 2021-01-12 05:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:47:08 --> Input Class Initialized
INFO - 2021-01-12 05:47:08 --> Language Class Initialized
INFO - 2021-01-12 05:47:08 --> Language Class Initialized
INFO - 2021-01-12 05:47:08 --> Config Class Initialized
INFO - 2021-01-12 05:47:08 --> Loader Class Initialized
INFO - 2021-01-12 05:47:09 --> Helper loaded: url_helper
INFO - 2021-01-12 05:47:09 --> Helper loaded: file_helper
INFO - 2021-01-12 05:47:09 --> Helper loaded: form_helper
INFO - 2021-01-12 05:47:09 --> Helper loaded: my_helper
INFO - 2021-01-12 05:47:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:47:09 --> Controller Class Initialized
DEBUG - 2021-01-12 05:47:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:47:09 --> Final output sent to browser
DEBUG - 2021-01-12 05:47:09 --> Total execution time: 1.3143
INFO - 2021-01-12 05:47:19 --> Config Class Initialized
INFO - 2021-01-12 05:47:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:47:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:47:20 --> Utf8 Class Initialized
INFO - 2021-01-12 05:47:20 --> URI Class Initialized
INFO - 2021-01-12 05:47:20 --> Router Class Initialized
INFO - 2021-01-12 05:47:20 --> Output Class Initialized
INFO - 2021-01-12 05:47:20 --> Security Class Initialized
DEBUG - 2021-01-12 05:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:47:20 --> Input Class Initialized
INFO - 2021-01-12 05:47:20 --> Language Class Initialized
INFO - 2021-01-12 05:47:20 --> Language Class Initialized
INFO - 2021-01-12 05:47:20 --> Config Class Initialized
INFO - 2021-01-12 05:47:20 --> Loader Class Initialized
INFO - 2021-01-12 05:47:20 --> Helper loaded: url_helper
INFO - 2021-01-12 05:47:20 --> Helper loaded: file_helper
INFO - 2021-01-12 05:47:20 --> Helper loaded: form_helper
INFO - 2021-01-12 05:47:20 --> Helper loaded: my_helper
INFO - 2021-01-12 05:47:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:47:20 --> Controller Class Initialized
DEBUG - 2021-01-12 05:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:47:21 --> Final output sent to browser
DEBUG - 2021-01-12 05:47:21 --> Total execution time: 1.2281
INFO - 2021-01-12 05:47:35 --> Config Class Initialized
INFO - 2021-01-12 05:47:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:47:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:47:35 --> Utf8 Class Initialized
INFO - 2021-01-12 05:47:35 --> URI Class Initialized
INFO - 2021-01-12 05:47:35 --> Router Class Initialized
INFO - 2021-01-12 05:47:35 --> Output Class Initialized
INFO - 2021-01-12 05:47:35 --> Security Class Initialized
DEBUG - 2021-01-12 05:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:47:35 --> Input Class Initialized
INFO - 2021-01-12 05:47:35 --> Language Class Initialized
INFO - 2021-01-12 05:47:35 --> Language Class Initialized
INFO - 2021-01-12 05:47:35 --> Config Class Initialized
INFO - 2021-01-12 05:47:35 --> Loader Class Initialized
INFO - 2021-01-12 05:47:35 --> Helper loaded: url_helper
INFO - 2021-01-12 05:47:35 --> Helper loaded: file_helper
INFO - 2021-01-12 05:47:35 --> Helper loaded: form_helper
INFO - 2021-01-12 05:47:36 --> Helper loaded: my_helper
INFO - 2021-01-12 05:47:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:47:36 --> Controller Class Initialized
DEBUG - 2021-01-12 05:47:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:47:36 --> Final output sent to browser
DEBUG - 2021-01-12 05:47:36 --> Total execution time: 1.3607
INFO - 2021-01-12 05:47:49 --> Config Class Initialized
INFO - 2021-01-12 05:47:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:47:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:47:50 --> Utf8 Class Initialized
INFO - 2021-01-12 05:47:50 --> URI Class Initialized
INFO - 2021-01-12 05:47:50 --> Router Class Initialized
INFO - 2021-01-12 05:47:50 --> Output Class Initialized
INFO - 2021-01-12 05:47:50 --> Security Class Initialized
DEBUG - 2021-01-12 05:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:47:50 --> Input Class Initialized
INFO - 2021-01-12 05:47:50 --> Language Class Initialized
INFO - 2021-01-12 05:47:50 --> Language Class Initialized
INFO - 2021-01-12 05:47:50 --> Config Class Initialized
INFO - 2021-01-12 05:47:50 --> Loader Class Initialized
INFO - 2021-01-12 05:47:50 --> Helper loaded: url_helper
INFO - 2021-01-12 05:47:50 --> Helper loaded: file_helper
INFO - 2021-01-12 05:47:50 --> Helper loaded: form_helper
INFO - 2021-01-12 05:47:50 --> Helper loaded: my_helper
INFO - 2021-01-12 05:47:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:47:50 --> Controller Class Initialized
DEBUG - 2021-01-12 05:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:47:51 --> Final output sent to browser
DEBUG - 2021-01-12 05:47:51 --> Total execution time: 1.1546
INFO - 2021-01-12 05:50:09 --> Config Class Initialized
INFO - 2021-01-12 05:50:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:50:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:50:09 --> Utf8 Class Initialized
INFO - 2021-01-12 05:50:09 --> URI Class Initialized
INFO - 2021-01-12 05:50:09 --> Router Class Initialized
INFO - 2021-01-12 05:50:09 --> Output Class Initialized
INFO - 2021-01-12 05:50:09 --> Security Class Initialized
DEBUG - 2021-01-12 05:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:50:09 --> Input Class Initialized
INFO - 2021-01-12 05:50:09 --> Language Class Initialized
INFO - 2021-01-12 05:50:09 --> Language Class Initialized
INFO - 2021-01-12 05:50:09 --> Config Class Initialized
INFO - 2021-01-12 05:50:09 --> Loader Class Initialized
INFO - 2021-01-12 05:50:09 --> Helper loaded: url_helper
INFO - 2021-01-12 05:50:09 --> Helper loaded: file_helper
INFO - 2021-01-12 05:50:10 --> Helper loaded: form_helper
INFO - 2021-01-12 05:50:10 --> Helper loaded: my_helper
INFO - 2021-01-12 05:50:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:50:10 --> Controller Class Initialized
DEBUG - 2021-01-12 05:50:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:50:10 --> Final output sent to browser
DEBUG - 2021-01-12 05:50:10 --> Total execution time: 1.1866
INFO - 2021-01-12 05:50:30 --> Config Class Initialized
INFO - 2021-01-12 05:50:30 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:50:30 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:50:31 --> Utf8 Class Initialized
INFO - 2021-01-12 05:50:31 --> URI Class Initialized
INFO - 2021-01-12 05:50:31 --> Router Class Initialized
INFO - 2021-01-12 05:50:31 --> Output Class Initialized
INFO - 2021-01-12 05:50:31 --> Security Class Initialized
DEBUG - 2021-01-12 05:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:50:31 --> Input Class Initialized
INFO - 2021-01-12 05:50:31 --> Language Class Initialized
INFO - 2021-01-12 05:50:31 --> Language Class Initialized
INFO - 2021-01-12 05:50:31 --> Config Class Initialized
INFO - 2021-01-12 05:50:31 --> Loader Class Initialized
INFO - 2021-01-12 05:50:31 --> Helper loaded: url_helper
INFO - 2021-01-12 05:50:31 --> Helper loaded: file_helper
INFO - 2021-01-12 05:50:31 --> Helper loaded: form_helper
INFO - 2021-01-12 05:50:31 --> Helper loaded: my_helper
INFO - 2021-01-12 05:50:31 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:50:31 --> Controller Class Initialized
DEBUG - 2021-01-12 05:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:50:32 --> Final output sent to browser
DEBUG - 2021-01-12 05:50:32 --> Total execution time: 1.2912
INFO - 2021-01-12 05:53:08 --> Config Class Initialized
INFO - 2021-01-12 05:53:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:53:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:53:08 --> Utf8 Class Initialized
INFO - 2021-01-12 05:53:08 --> URI Class Initialized
INFO - 2021-01-12 05:53:08 --> Router Class Initialized
INFO - 2021-01-12 05:53:08 --> Output Class Initialized
INFO - 2021-01-12 05:53:08 --> Security Class Initialized
DEBUG - 2021-01-12 05:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:53:09 --> Input Class Initialized
INFO - 2021-01-12 05:53:09 --> Language Class Initialized
INFO - 2021-01-12 05:53:09 --> Language Class Initialized
INFO - 2021-01-12 05:53:09 --> Config Class Initialized
INFO - 2021-01-12 05:53:09 --> Loader Class Initialized
INFO - 2021-01-12 05:53:09 --> Helper loaded: url_helper
INFO - 2021-01-12 05:53:09 --> Helper loaded: file_helper
INFO - 2021-01-12 05:53:09 --> Helper loaded: form_helper
INFO - 2021-01-12 05:53:09 --> Helper loaded: my_helper
INFO - 2021-01-12 05:53:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:53:09 --> Controller Class Initialized
DEBUG - 2021-01-12 05:53:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:53:09 --> Final output sent to browser
DEBUG - 2021-01-12 05:53:09 --> Total execution time: 1.2957
INFO - 2021-01-12 05:54:18 --> Config Class Initialized
INFO - 2021-01-12 05:54:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:54:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:54:18 --> Utf8 Class Initialized
INFO - 2021-01-12 05:54:18 --> URI Class Initialized
INFO - 2021-01-12 05:54:18 --> Router Class Initialized
INFO - 2021-01-12 05:54:18 --> Output Class Initialized
INFO - 2021-01-12 05:54:18 --> Security Class Initialized
DEBUG - 2021-01-12 05:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:54:18 --> Input Class Initialized
INFO - 2021-01-12 05:54:18 --> Language Class Initialized
INFO - 2021-01-12 05:54:18 --> Language Class Initialized
INFO - 2021-01-12 05:54:18 --> Config Class Initialized
INFO - 2021-01-12 05:54:18 --> Loader Class Initialized
INFO - 2021-01-12 05:54:18 --> Helper loaded: url_helper
INFO - 2021-01-12 05:54:18 --> Helper loaded: file_helper
INFO - 2021-01-12 05:54:18 --> Helper loaded: form_helper
INFO - 2021-01-12 05:54:18 --> Helper loaded: my_helper
INFO - 2021-01-12 05:54:18 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:54:19 --> Controller Class Initialized
DEBUG - 2021-01-12 05:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:54:19 --> Final output sent to browser
DEBUG - 2021-01-12 05:54:19 --> Total execution time: 1.1652
INFO - 2021-01-12 05:54:39 --> Config Class Initialized
INFO - 2021-01-12 05:54:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:54:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:54:39 --> Utf8 Class Initialized
INFO - 2021-01-12 05:54:39 --> URI Class Initialized
INFO - 2021-01-12 05:54:39 --> Router Class Initialized
INFO - 2021-01-12 05:54:40 --> Output Class Initialized
INFO - 2021-01-12 05:54:40 --> Security Class Initialized
DEBUG - 2021-01-12 05:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:54:40 --> Input Class Initialized
INFO - 2021-01-12 05:54:40 --> Language Class Initialized
INFO - 2021-01-12 05:54:40 --> Language Class Initialized
INFO - 2021-01-12 05:54:40 --> Config Class Initialized
INFO - 2021-01-12 05:54:40 --> Loader Class Initialized
INFO - 2021-01-12 05:54:40 --> Helper loaded: url_helper
INFO - 2021-01-12 05:54:40 --> Helper loaded: file_helper
INFO - 2021-01-12 05:54:40 --> Helper loaded: form_helper
INFO - 2021-01-12 05:54:40 --> Helper loaded: my_helper
INFO - 2021-01-12 05:54:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:54:40 --> Controller Class Initialized
DEBUG - 2021-01-12 05:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:54:40 --> Final output sent to browser
DEBUG - 2021-01-12 05:54:40 --> Total execution time: 1.2377
INFO - 2021-01-12 05:54:57 --> Config Class Initialized
INFO - 2021-01-12 05:54:57 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:54:57 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:54:57 --> Utf8 Class Initialized
INFO - 2021-01-12 05:54:57 --> URI Class Initialized
INFO - 2021-01-12 05:54:57 --> Router Class Initialized
INFO - 2021-01-12 05:54:57 --> Output Class Initialized
INFO - 2021-01-12 05:54:57 --> Security Class Initialized
DEBUG - 2021-01-12 05:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:54:57 --> Input Class Initialized
INFO - 2021-01-12 05:54:57 --> Language Class Initialized
INFO - 2021-01-12 05:54:57 --> Language Class Initialized
INFO - 2021-01-12 05:54:57 --> Config Class Initialized
INFO - 2021-01-12 05:54:57 --> Loader Class Initialized
INFO - 2021-01-12 05:54:57 --> Helper loaded: url_helper
INFO - 2021-01-12 05:54:57 --> Helper loaded: file_helper
INFO - 2021-01-12 05:54:57 --> Helper loaded: form_helper
INFO - 2021-01-12 05:54:57 --> Helper loaded: my_helper
INFO - 2021-01-12 05:54:57 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:54:58 --> Controller Class Initialized
DEBUG - 2021-01-12 05:54:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:54:58 --> Final output sent to browser
DEBUG - 2021-01-12 05:54:58 --> Total execution time: 1.2167
INFO - 2021-01-12 05:55:40 --> Config Class Initialized
INFO - 2021-01-12 05:55:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:55:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:55:40 --> Utf8 Class Initialized
INFO - 2021-01-12 05:55:40 --> URI Class Initialized
INFO - 2021-01-12 05:55:40 --> Router Class Initialized
INFO - 2021-01-12 05:55:40 --> Output Class Initialized
INFO - 2021-01-12 05:55:40 --> Security Class Initialized
DEBUG - 2021-01-12 05:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:55:40 --> Input Class Initialized
INFO - 2021-01-12 05:55:40 --> Language Class Initialized
INFO - 2021-01-12 05:55:41 --> Language Class Initialized
INFO - 2021-01-12 05:55:41 --> Config Class Initialized
INFO - 2021-01-12 05:55:41 --> Loader Class Initialized
INFO - 2021-01-12 05:55:41 --> Helper loaded: url_helper
INFO - 2021-01-12 05:55:41 --> Helper loaded: file_helper
INFO - 2021-01-12 05:55:41 --> Helper loaded: form_helper
INFO - 2021-01-12 05:55:41 --> Helper loaded: my_helper
INFO - 2021-01-12 05:55:41 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:55:41 --> Controller Class Initialized
DEBUG - 2021-01-12 05:55:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:55:41 --> Final output sent to browser
DEBUG - 2021-01-12 05:55:41 --> Total execution time: 1.2351
INFO - 2021-01-12 05:55:58 --> Config Class Initialized
INFO - 2021-01-12 05:55:58 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:55:58 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:55:58 --> Utf8 Class Initialized
INFO - 2021-01-12 05:55:58 --> URI Class Initialized
INFO - 2021-01-12 05:55:58 --> Router Class Initialized
INFO - 2021-01-12 05:55:58 --> Output Class Initialized
INFO - 2021-01-12 05:55:58 --> Security Class Initialized
DEBUG - 2021-01-12 05:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:55:58 --> Input Class Initialized
INFO - 2021-01-12 05:55:58 --> Language Class Initialized
INFO - 2021-01-12 05:55:58 --> Language Class Initialized
INFO - 2021-01-12 05:55:58 --> Config Class Initialized
INFO - 2021-01-12 05:55:58 --> Loader Class Initialized
INFO - 2021-01-12 05:55:58 --> Helper loaded: url_helper
INFO - 2021-01-12 05:55:58 --> Helper loaded: file_helper
INFO - 2021-01-12 05:55:58 --> Helper loaded: form_helper
INFO - 2021-01-12 05:55:58 --> Helper loaded: my_helper
INFO - 2021-01-12 05:55:58 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:55:59 --> Controller Class Initialized
INFO - 2021-01-12 05:55:59 --> Helper loaded: cookie_helper
INFO - 2021-01-12 05:55:59 --> Config Class Initialized
INFO - 2021-01-12 05:55:59 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:55:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:55:59 --> Utf8 Class Initialized
INFO - 2021-01-12 05:55:59 --> URI Class Initialized
INFO - 2021-01-12 05:55:59 --> Router Class Initialized
INFO - 2021-01-12 05:55:59 --> Output Class Initialized
INFO - 2021-01-12 05:55:59 --> Security Class Initialized
DEBUG - 2021-01-12 05:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:55:59 --> Input Class Initialized
INFO - 2021-01-12 05:55:59 --> Language Class Initialized
INFO - 2021-01-12 05:55:59 --> Language Class Initialized
INFO - 2021-01-12 05:55:59 --> Config Class Initialized
INFO - 2021-01-12 05:55:59 --> Loader Class Initialized
INFO - 2021-01-12 05:55:59 --> Helper loaded: url_helper
INFO - 2021-01-12 05:55:59 --> Helper loaded: file_helper
INFO - 2021-01-12 05:55:59 --> Helper loaded: form_helper
INFO - 2021-01-12 05:55:59 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:00 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:00 --> Controller Class Initialized
DEBUG - 2021-01-12 05:56:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 05:56:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:56:00 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:00 --> Total execution time: 1.0928
INFO - 2021-01-12 05:56:07 --> Config Class Initialized
INFO - 2021-01-12 05:56:07 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:07 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:07 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:07 --> URI Class Initialized
INFO - 2021-01-12 05:56:07 --> Router Class Initialized
INFO - 2021-01-12 05:56:07 --> Output Class Initialized
INFO - 2021-01-12 05:56:07 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:07 --> Input Class Initialized
INFO - 2021-01-12 05:56:07 --> Language Class Initialized
INFO - 2021-01-12 05:56:07 --> Language Class Initialized
INFO - 2021-01-12 05:56:07 --> Config Class Initialized
INFO - 2021-01-12 05:56:07 --> Loader Class Initialized
INFO - 2021-01-12 05:56:07 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:07 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:08 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:08 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:08 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:08 --> Controller Class Initialized
INFO - 2021-01-12 05:56:08 --> Helper loaded: cookie_helper
INFO - 2021-01-12 05:56:08 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:08 --> Total execution time: 1.0283
INFO - 2021-01-12 05:56:08 --> Config Class Initialized
INFO - 2021-01-12 05:56:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:08 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:08 --> URI Class Initialized
INFO - 2021-01-12 05:56:09 --> Router Class Initialized
INFO - 2021-01-12 05:56:09 --> Output Class Initialized
INFO - 2021-01-12 05:56:09 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:09 --> Input Class Initialized
INFO - 2021-01-12 05:56:09 --> Language Class Initialized
INFO - 2021-01-12 05:56:09 --> Language Class Initialized
INFO - 2021-01-12 05:56:09 --> Config Class Initialized
INFO - 2021-01-12 05:56:09 --> Loader Class Initialized
INFO - 2021-01-12 05:56:09 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:09 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:09 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:09 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:09 --> Controller Class Initialized
DEBUG - 2021-01-12 05:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 05:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:56:09 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:09 --> Total execution time: 1.0116
INFO - 2021-01-12 05:56:12 --> Config Class Initialized
INFO - 2021-01-12 05:56:12 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:13 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:13 --> URI Class Initialized
INFO - 2021-01-12 05:56:13 --> Router Class Initialized
INFO - 2021-01-12 05:56:13 --> Output Class Initialized
INFO - 2021-01-12 05:56:13 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:13 --> Input Class Initialized
INFO - 2021-01-12 05:56:13 --> Language Class Initialized
INFO - 2021-01-12 05:56:13 --> Language Class Initialized
INFO - 2021-01-12 05:56:13 --> Config Class Initialized
INFO - 2021-01-12 05:56:13 --> Loader Class Initialized
INFO - 2021-01-12 05:56:13 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:13 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:13 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:13 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:13 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:14 --> Controller Class Initialized
DEBUG - 2021-01-12 05:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-12 05:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:56:14 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:14 --> Total execution time: 1.1897
INFO - 2021-01-12 05:56:14 --> Config Class Initialized
INFO - 2021-01-12 05:56:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:14 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:14 --> URI Class Initialized
INFO - 2021-01-12 05:56:14 --> Router Class Initialized
INFO - 2021-01-12 05:56:14 --> Output Class Initialized
INFO - 2021-01-12 05:56:14 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:14 --> Input Class Initialized
INFO - 2021-01-12 05:56:14 --> Language Class Initialized
INFO - 2021-01-12 05:56:14 --> Language Class Initialized
INFO - 2021-01-12 05:56:14 --> Config Class Initialized
INFO - 2021-01-12 05:56:14 --> Loader Class Initialized
INFO - 2021-01-12 05:56:14 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:14 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:14 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:15 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:15 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:15 --> Controller Class Initialized
INFO - 2021-01-12 05:56:15 --> Config Class Initialized
INFO - 2021-01-12 05:56:15 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:16 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:16 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:16 --> URI Class Initialized
INFO - 2021-01-12 05:56:16 --> Router Class Initialized
INFO - 2021-01-12 05:56:16 --> Output Class Initialized
INFO - 2021-01-12 05:56:16 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:16 --> Input Class Initialized
INFO - 2021-01-12 05:56:16 --> Language Class Initialized
INFO - 2021-01-12 05:56:16 --> Language Class Initialized
INFO - 2021-01-12 05:56:16 --> Config Class Initialized
INFO - 2021-01-12 05:56:16 --> Loader Class Initialized
INFO - 2021-01-12 05:56:16 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:16 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:16 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:16 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:16 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:16 --> Controller Class Initialized
INFO - 2021-01-12 05:56:16 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:16 --> Total execution time: 0.8769
INFO - 2021-01-12 05:56:37 --> Config Class Initialized
INFO - 2021-01-12 05:56:37 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:37 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:37 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:37 --> URI Class Initialized
INFO - 2021-01-12 05:56:37 --> Router Class Initialized
INFO - 2021-01-12 05:56:37 --> Output Class Initialized
INFO - 2021-01-12 05:56:38 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:38 --> Input Class Initialized
INFO - 2021-01-12 05:56:38 --> Language Class Initialized
INFO - 2021-01-12 05:56:38 --> Language Class Initialized
INFO - 2021-01-12 05:56:38 --> Config Class Initialized
INFO - 2021-01-12 05:56:38 --> Loader Class Initialized
INFO - 2021-01-12 05:56:38 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:38 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:38 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:38 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:38 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:38 --> Controller Class Initialized
INFO - 2021-01-12 05:56:38 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:38 --> Total execution time: 0.9213
INFO - 2021-01-12 05:56:38 --> Config Class Initialized
INFO - 2021-01-12 05:56:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:39 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:39 --> URI Class Initialized
INFO - 2021-01-12 05:56:39 --> Router Class Initialized
INFO - 2021-01-12 05:56:39 --> Output Class Initialized
INFO - 2021-01-12 05:56:39 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:39 --> Input Class Initialized
INFO - 2021-01-12 05:56:39 --> Language Class Initialized
INFO - 2021-01-12 05:56:39 --> Language Class Initialized
INFO - 2021-01-12 05:56:39 --> Config Class Initialized
INFO - 2021-01-12 05:56:39 --> Loader Class Initialized
INFO - 2021-01-12 05:56:39 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:39 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:39 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:39 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:39 --> Controller Class Initialized
INFO - 2021-01-12 05:56:41 --> Config Class Initialized
INFO - 2021-01-12 05:56:41 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:41 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:41 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:41 --> URI Class Initialized
INFO - 2021-01-12 05:56:41 --> Router Class Initialized
INFO - 2021-01-12 05:56:42 --> Output Class Initialized
INFO - 2021-01-12 05:56:42 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:42 --> Input Class Initialized
INFO - 2021-01-12 05:56:42 --> Language Class Initialized
INFO - 2021-01-12 05:56:42 --> Language Class Initialized
INFO - 2021-01-12 05:56:42 --> Config Class Initialized
INFO - 2021-01-12 05:56:42 --> Loader Class Initialized
INFO - 2021-01-12 05:56:42 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:42 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:42 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:42 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:42 --> Controller Class Initialized
INFO - 2021-01-12 05:56:42 --> Helper loaded: cookie_helper
INFO - 2021-01-12 05:56:42 --> Config Class Initialized
INFO - 2021-01-12 05:56:42 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:42 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:42 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:42 --> URI Class Initialized
INFO - 2021-01-12 05:56:43 --> Router Class Initialized
INFO - 2021-01-12 05:56:43 --> Output Class Initialized
INFO - 2021-01-12 05:56:43 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:43 --> Input Class Initialized
INFO - 2021-01-12 05:56:43 --> Language Class Initialized
INFO - 2021-01-12 05:56:43 --> Language Class Initialized
INFO - 2021-01-12 05:56:43 --> Config Class Initialized
INFO - 2021-01-12 05:56:43 --> Loader Class Initialized
INFO - 2021-01-12 05:56:43 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:43 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:43 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:43 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:43 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:43 --> Controller Class Initialized
DEBUG - 2021-01-12 05:56:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 05:56:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:56:43 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:43 --> Total execution time: 1.1642
INFO - 2021-01-12 05:56:48 --> Config Class Initialized
INFO - 2021-01-12 05:56:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:48 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:48 --> URI Class Initialized
INFO - 2021-01-12 05:56:48 --> Router Class Initialized
INFO - 2021-01-12 05:56:49 --> Output Class Initialized
INFO - 2021-01-12 05:56:49 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:49 --> Input Class Initialized
INFO - 2021-01-12 05:56:49 --> Language Class Initialized
INFO - 2021-01-12 05:56:49 --> Language Class Initialized
INFO - 2021-01-12 05:56:49 --> Config Class Initialized
INFO - 2021-01-12 05:56:49 --> Loader Class Initialized
INFO - 2021-01-12 05:56:49 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:49 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:49 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:49 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:49 --> Controller Class Initialized
INFO - 2021-01-12 05:56:49 --> Helper loaded: cookie_helper
INFO - 2021-01-12 05:56:49 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:50 --> Total execution time: 1.2358
INFO - 2021-01-12 05:56:50 --> Config Class Initialized
INFO - 2021-01-12 05:56:50 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:50 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:50 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:50 --> URI Class Initialized
INFO - 2021-01-12 05:56:50 --> Router Class Initialized
INFO - 2021-01-12 05:56:50 --> Output Class Initialized
INFO - 2021-01-12 05:56:50 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:50 --> Input Class Initialized
INFO - 2021-01-12 05:56:50 --> Language Class Initialized
INFO - 2021-01-12 05:56:50 --> Language Class Initialized
INFO - 2021-01-12 05:56:50 --> Config Class Initialized
INFO - 2021-01-12 05:56:50 --> Loader Class Initialized
INFO - 2021-01-12 05:56:51 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:51 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:51 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:51 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:51 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:51 --> Controller Class Initialized
DEBUG - 2021-01-12 05:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 05:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:56:51 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:51 --> Total execution time: 0.9855
INFO - 2021-01-12 05:56:54 --> Config Class Initialized
INFO - 2021-01-12 05:56:54 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:54 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:54 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:54 --> URI Class Initialized
INFO - 2021-01-12 05:56:54 --> Router Class Initialized
INFO - 2021-01-12 05:56:54 --> Output Class Initialized
INFO - 2021-01-12 05:56:54 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:54 --> Input Class Initialized
INFO - 2021-01-12 05:56:54 --> Language Class Initialized
INFO - 2021-01-12 05:56:54 --> Language Class Initialized
INFO - 2021-01-12 05:56:54 --> Config Class Initialized
INFO - 2021-01-12 05:56:54 --> Loader Class Initialized
INFO - 2021-01-12 05:56:54 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:54 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:54 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:54 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:54 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:55 --> Controller Class Initialized
DEBUG - 2021-01-12 05:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 05:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:56:55 --> Final output sent to browser
DEBUG - 2021-01-12 05:56:55 --> Total execution time: 1.1414
INFO - 2021-01-12 05:56:58 --> Config Class Initialized
INFO - 2021-01-12 05:56:58 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:56:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:56:59 --> Utf8 Class Initialized
INFO - 2021-01-12 05:56:59 --> URI Class Initialized
INFO - 2021-01-12 05:56:59 --> Router Class Initialized
INFO - 2021-01-12 05:56:59 --> Output Class Initialized
INFO - 2021-01-12 05:56:59 --> Security Class Initialized
DEBUG - 2021-01-12 05:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:56:59 --> Input Class Initialized
INFO - 2021-01-12 05:56:59 --> Language Class Initialized
INFO - 2021-01-12 05:56:59 --> Language Class Initialized
INFO - 2021-01-12 05:56:59 --> Config Class Initialized
INFO - 2021-01-12 05:56:59 --> Loader Class Initialized
INFO - 2021-01-12 05:56:59 --> Helper loaded: url_helper
INFO - 2021-01-12 05:56:59 --> Helper loaded: file_helper
INFO - 2021-01-12 05:56:59 --> Helper loaded: form_helper
INFO - 2021-01-12 05:56:59 --> Helper loaded: my_helper
INFO - 2021-01-12 05:56:59 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:56:59 --> Controller Class Initialized
DEBUG - 2021-01-12 05:56:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 05:56:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:56:59 --> Final output sent to browser
DEBUG - 2021-01-12 05:57:00 --> Total execution time: 1.0345
INFO - 2021-01-12 05:57:11 --> Config Class Initialized
INFO - 2021-01-12 05:57:11 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:57:11 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:57:11 --> Utf8 Class Initialized
INFO - 2021-01-12 05:57:11 --> URI Class Initialized
INFO - 2021-01-12 05:57:11 --> Router Class Initialized
INFO - 2021-01-12 05:57:11 --> Output Class Initialized
INFO - 2021-01-12 05:57:11 --> Security Class Initialized
DEBUG - 2021-01-12 05:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:57:11 --> Input Class Initialized
INFO - 2021-01-12 05:57:11 --> Language Class Initialized
INFO - 2021-01-12 05:57:11 --> Language Class Initialized
INFO - 2021-01-12 05:57:11 --> Config Class Initialized
INFO - 2021-01-12 05:57:11 --> Loader Class Initialized
INFO - 2021-01-12 05:57:11 --> Helper loaded: url_helper
INFO - 2021-01-12 05:57:11 --> Helper loaded: file_helper
INFO - 2021-01-12 05:57:11 --> Helper loaded: form_helper
INFO - 2021-01-12 05:57:11 --> Helper loaded: my_helper
INFO - 2021-01-12 05:57:12 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:57:12 --> Controller Class Initialized
INFO - 2021-01-12 05:57:12 --> Final output sent to browser
DEBUG - 2021-01-12 05:57:12 --> Total execution time: 1.0552
INFO - 2021-01-12 05:57:13 --> Config Class Initialized
INFO - 2021-01-12 05:57:13 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:57:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:57:13 --> Utf8 Class Initialized
INFO - 2021-01-12 05:57:13 --> URI Class Initialized
INFO - 2021-01-12 05:57:13 --> Router Class Initialized
INFO - 2021-01-12 05:57:13 --> Output Class Initialized
INFO - 2021-01-12 05:57:13 --> Security Class Initialized
DEBUG - 2021-01-12 05:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:57:14 --> Input Class Initialized
INFO - 2021-01-12 05:57:14 --> Language Class Initialized
INFO - 2021-01-12 05:57:14 --> Language Class Initialized
INFO - 2021-01-12 05:57:14 --> Config Class Initialized
INFO - 2021-01-12 05:57:14 --> Loader Class Initialized
INFO - 2021-01-12 05:57:14 --> Helper loaded: url_helper
INFO - 2021-01-12 05:57:14 --> Helper loaded: file_helper
INFO - 2021-01-12 05:57:14 --> Helper loaded: form_helper
INFO - 2021-01-12 05:57:14 --> Helper loaded: my_helper
INFO - 2021-01-12 05:57:14 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:57:14 --> Controller Class Initialized
DEBUG - 2021-01-12 05:57:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 05:57:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 05:57:14 --> Final output sent to browser
DEBUG - 2021-01-12 05:57:14 --> Total execution time: 1.1912
INFO - 2021-01-12 05:57:16 --> Config Class Initialized
INFO - 2021-01-12 05:57:17 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:57:17 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:57:17 --> Utf8 Class Initialized
INFO - 2021-01-12 05:57:17 --> URI Class Initialized
INFO - 2021-01-12 05:57:17 --> Router Class Initialized
INFO - 2021-01-12 05:57:17 --> Output Class Initialized
INFO - 2021-01-12 05:57:17 --> Security Class Initialized
DEBUG - 2021-01-12 05:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:57:17 --> Input Class Initialized
INFO - 2021-01-12 05:57:17 --> Language Class Initialized
INFO - 2021-01-12 05:57:17 --> Language Class Initialized
INFO - 2021-01-12 05:57:17 --> Config Class Initialized
INFO - 2021-01-12 05:57:17 --> Loader Class Initialized
INFO - 2021-01-12 05:57:17 --> Helper loaded: url_helper
INFO - 2021-01-12 05:57:17 --> Helper loaded: file_helper
INFO - 2021-01-12 05:57:17 --> Helper loaded: form_helper
INFO - 2021-01-12 05:57:17 --> Helper loaded: my_helper
INFO - 2021-01-12 05:57:17 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:57:17 --> Controller Class Initialized
DEBUG - 2021-01-12 05:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:57:18 --> Final output sent to browser
DEBUG - 2021-01-12 05:57:18 --> Total execution time: 1.0989
INFO - 2021-01-12 05:58:25 --> Config Class Initialized
INFO - 2021-01-12 05:58:25 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:58:25 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:58:25 --> Utf8 Class Initialized
INFO - 2021-01-12 05:58:25 --> URI Class Initialized
INFO - 2021-01-12 05:58:25 --> Router Class Initialized
INFO - 2021-01-12 05:58:25 --> Output Class Initialized
INFO - 2021-01-12 05:58:25 --> Security Class Initialized
DEBUG - 2021-01-12 05:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:58:25 --> Input Class Initialized
INFO - 2021-01-12 05:58:25 --> Language Class Initialized
INFO - 2021-01-12 05:58:25 --> Language Class Initialized
INFO - 2021-01-12 05:58:25 --> Config Class Initialized
INFO - 2021-01-12 05:58:25 --> Loader Class Initialized
INFO - 2021-01-12 05:58:25 --> Helper loaded: url_helper
INFO - 2021-01-12 05:58:25 --> Helper loaded: file_helper
INFO - 2021-01-12 05:58:25 --> Helper loaded: form_helper
INFO - 2021-01-12 05:58:25 --> Helper loaded: my_helper
INFO - 2021-01-12 05:58:25 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:58:26 --> Controller Class Initialized
DEBUG - 2021-01-12 05:58:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:58:26 --> Final output sent to browser
DEBUG - 2021-01-12 05:58:26 --> Total execution time: 1.2320
INFO - 2021-01-12 05:59:49 --> Config Class Initialized
INFO - 2021-01-12 05:59:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 05:59:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 05:59:49 --> Utf8 Class Initialized
INFO - 2021-01-12 05:59:49 --> URI Class Initialized
INFO - 2021-01-12 05:59:49 --> Router Class Initialized
INFO - 2021-01-12 05:59:49 --> Output Class Initialized
INFO - 2021-01-12 05:59:49 --> Security Class Initialized
DEBUG - 2021-01-12 05:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 05:59:49 --> Input Class Initialized
INFO - 2021-01-12 05:59:49 --> Language Class Initialized
INFO - 2021-01-12 05:59:49 --> Language Class Initialized
INFO - 2021-01-12 05:59:49 --> Config Class Initialized
INFO - 2021-01-12 05:59:49 --> Loader Class Initialized
INFO - 2021-01-12 05:59:49 --> Helper loaded: url_helper
INFO - 2021-01-12 05:59:49 --> Helper loaded: file_helper
INFO - 2021-01-12 05:59:49 --> Helper loaded: form_helper
INFO - 2021-01-12 05:59:49 --> Helper loaded: my_helper
INFO - 2021-01-12 05:59:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 05:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 05:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 05:59:50 --> Controller Class Initialized
DEBUG - 2021-01-12 05:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-12 05:59:50 --> Final output sent to browser
DEBUG - 2021-01-12 05:59:50 --> Total execution time: 1.2920
INFO - 2021-01-12 06:00:19 --> Config Class Initialized
INFO - 2021-01-12 06:00:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:00:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:00:19 --> Utf8 Class Initialized
INFO - 2021-01-12 06:00:19 --> URI Class Initialized
INFO - 2021-01-12 06:00:19 --> Router Class Initialized
INFO - 2021-01-12 06:00:19 --> Output Class Initialized
INFO - 2021-01-12 06:00:19 --> Security Class Initialized
DEBUG - 2021-01-12 06:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:00:19 --> Input Class Initialized
INFO - 2021-01-12 06:00:19 --> Language Class Initialized
INFO - 2021-01-12 06:00:19 --> Language Class Initialized
INFO - 2021-01-12 06:00:19 --> Config Class Initialized
INFO - 2021-01-12 06:00:19 --> Loader Class Initialized
INFO - 2021-01-12 06:00:19 --> Helper loaded: url_helper
INFO - 2021-01-12 06:00:19 --> Helper loaded: file_helper
INFO - 2021-01-12 06:00:19 --> Helper loaded: form_helper
INFO - 2021-01-12 06:00:19 --> Helper loaded: my_helper
INFO - 2021-01-12 06:00:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:00:20 --> Controller Class Initialized
INFO - 2021-01-12 06:00:20 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:00:20 --> Config Class Initialized
INFO - 2021-01-12 06:00:20 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:00:20 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:00:20 --> Utf8 Class Initialized
INFO - 2021-01-12 06:00:20 --> URI Class Initialized
INFO - 2021-01-12 06:00:20 --> Router Class Initialized
INFO - 2021-01-12 06:00:20 --> Output Class Initialized
INFO - 2021-01-12 06:00:20 --> Security Class Initialized
DEBUG - 2021-01-12 06:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:00:20 --> Input Class Initialized
INFO - 2021-01-12 06:00:20 --> Language Class Initialized
INFO - 2021-01-12 06:00:20 --> Language Class Initialized
INFO - 2021-01-12 06:00:20 --> Config Class Initialized
INFO - 2021-01-12 06:00:21 --> Loader Class Initialized
INFO - 2021-01-12 06:00:21 --> Helper loaded: url_helper
INFO - 2021-01-12 06:00:21 --> Helper loaded: file_helper
INFO - 2021-01-12 06:00:21 --> Helper loaded: form_helper
INFO - 2021-01-12 06:00:21 --> Helper loaded: my_helper
INFO - 2021-01-12 06:00:21 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:00:21 --> Controller Class Initialized
DEBUG - 2021-01-12 06:00:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 06:00:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:00:21 --> Final output sent to browser
DEBUG - 2021-01-12 06:00:21 --> Total execution time: 1.1926
INFO - 2021-01-12 06:00:46 --> Config Class Initialized
INFO - 2021-01-12 06:00:46 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:00:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:00:46 --> Utf8 Class Initialized
INFO - 2021-01-12 06:00:46 --> URI Class Initialized
INFO - 2021-01-12 06:00:46 --> Router Class Initialized
INFO - 2021-01-12 06:00:46 --> Output Class Initialized
INFO - 2021-01-12 06:00:46 --> Security Class Initialized
DEBUG - 2021-01-12 06:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:00:46 --> Input Class Initialized
INFO - 2021-01-12 06:00:46 --> Language Class Initialized
INFO - 2021-01-12 06:00:46 --> Language Class Initialized
INFO - 2021-01-12 06:00:46 --> Config Class Initialized
INFO - 2021-01-12 06:00:46 --> Loader Class Initialized
INFO - 2021-01-12 06:00:46 --> Helper loaded: url_helper
INFO - 2021-01-12 06:00:46 --> Helper loaded: file_helper
INFO - 2021-01-12 06:00:46 --> Helper loaded: form_helper
INFO - 2021-01-12 06:00:46 --> Helper loaded: my_helper
INFO - 2021-01-12 06:00:46 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:00:47 --> Controller Class Initialized
INFO - 2021-01-12 06:00:47 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:00:47 --> Final output sent to browser
DEBUG - 2021-01-12 06:00:47 --> Total execution time: 1.0096
INFO - 2021-01-12 06:00:48 --> Config Class Initialized
INFO - 2021-01-12 06:00:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:00:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:00:48 --> Utf8 Class Initialized
INFO - 2021-01-12 06:00:48 --> URI Class Initialized
INFO - 2021-01-12 06:00:48 --> Router Class Initialized
INFO - 2021-01-12 06:00:48 --> Output Class Initialized
INFO - 2021-01-12 06:00:48 --> Security Class Initialized
DEBUG - 2021-01-12 06:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:00:49 --> Input Class Initialized
INFO - 2021-01-12 06:00:49 --> Language Class Initialized
INFO - 2021-01-12 06:00:49 --> Language Class Initialized
INFO - 2021-01-12 06:00:49 --> Config Class Initialized
INFO - 2021-01-12 06:00:49 --> Loader Class Initialized
INFO - 2021-01-12 06:00:49 --> Helper loaded: url_helper
INFO - 2021-01-12 06:00:49 --> Helper loaded: file_helper
INFO - 2021-01-12 06:00:49 --> Helper loaded: form_helper
INFO - 2021-01-12 06:00:49 --> Helper loaded: my_helper
INFO - 2021-01-12 06:00:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:00:49 --> Controller Class Initialized
DEBUG - 2021-01-12 06:00:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 06:00:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:00:49 --> Final output sent to browser
DEBUG - 2021-01-12 06:00:49 --> Total execution time: 1.1981
INFO - 2021-01-12 06:00:52 --> Config Class Initialized
INFO - 2021-01-12 06:00:52 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:00:52 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:00:52 --> Utf8 Class Initialized
INFO - 2021-01-12 06:00:52 --> URI Class Initialized
INFO - 2021-01-12 06:00:52 --> Router Class Initialized
INFO - 2021-01-12 06:00:52 --> Output Class Initialized
INFO - 2021-01-12 06:00:52 --> Security Class Initialized
DEBUG - 2021-01-12 06:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:00:52 --> Input Class Initialized
INFO - 2021-01-12 06:00:52 --> Language Class Initialized
INFO - 2021-01-12 06:00:52 --> Language Class Initialized
INFO - 2021-01-12 06:00:52 --> Config Class Initialized
INFO - 2021-01-12 06:00:52 --> Loader Class Initialized
INFO - 2021-01-12 06:00:52 --> Helper loaded: url_helper
INFO - 2021-01-12 06:00:52 --> Helper loaded: file_helper
INFO - 2021-01-12 06:00:52 --> Helper loaded: form_helper
INFO - 2021-01-12 06:00:52 --> Helper loaded: my_helper
INFO - 2021-01-12 06:00:52 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:00:52 --> Controller Class Initialized
DEBUG - 2021-01-12 06:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 06:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:00:53 --> Final output sent to browser
DEBUG - 2021-01-12 06:00:53 --> Total execution time: 1.0235
INFO - 2021-01-12 06:00:59 --> Config Class Initialized
INFO - 2021-01-12 06:00:59 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:00:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:00:59 --> Utf8 Class Initialized
INFO - 2021-01-12 06:00:59 --> URI Class Initialized
INFO - 2021-01-12 06:00:59 --> Router Class Initialized
INFO - 2021-01-12 06:00:59 --> Output Class Initialized
INFO - 2021-01-12 06:00:59 --> Security Class Initialized
DEBUG - 2021-01-12 06:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:01:00 --> Input Class Initialized
INFO - 2021-01-12 06:01:00 --> Language Class Initialized
INFO - 2021-01-12 06:01:00 --> Language Class Initialized
INFO - 2021-01-12 06:01:00 --> Config Class Initialized
INFO - 2021-01-12 06:01:00 --> Loader Class Initialized
INFO - 2021-01-12 06:01:00 --> Helper loaded: url_helper
INFO - 2021-01-12 06:01:00 --> Helper loaded: file_helper
INFO - 2021-01-12 06:01:00 --> Helper loaded: form_helper
INFO - 2021-01-12 06:01:00 --> Helper loaded: my_helper
INFO - 2021-01-12 06:01:00 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:01:00 --> Controller Class Initialized
INFO - 2021-01-12 06:01:00 --> Final output sent to browser
DEBUG - 2021-01-12 06:01:00 --> Total execution time: 0.9602
INFO - 2021-01-12 06:01:02 --> Config Class Initialized
INFO - 2021-01-12 06:01:02 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:01:02 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:01:02 --> Utf8 Class Initialized
INFO - 2021-01-12 06:01:02 --> URI Class Initialized
INFO - 2021-01-12 06:01:02 --> Router Class Initialized
INFO - 2021-01-12 06:01:02 --> Output Class Initialized
INFO - 2021-01-12 06:01:02 --> Security Class Initialized
DEBUG - 2021-01-12 06:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:01:02 --> Input Class Initialized
INFO - 2021-01-12 06:01:02 --> Language Class Initialized
INFO - 2021-01-12 06:01:02 --> Language Class Initialized
INFO - 2021-01-12 06:01:02 --> Config Class Initialized
INFO - 2021-01-12 06:01:02 --> Loader Class Initialized
INFO - 2021-01-12 06:01:03 --> Helper loaded: url_helper
INFO - 2021-01-12 06:01:03 --> Helper loaded: file_helper
INFO - 2021-01-12 06:01:03 --> Helper loaded: form_helper
INFO - 2021-01-12 06:01:03 --> Helper loaded: my_helper
INFO - 2021-01-12 06:01:03 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:01:03 --> Controller Class Initialized
DEBUG - 2021-01-12 06:01:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 06:01:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:01:03 --> Final output sent to browser
DEBUG - 2021-01-12 06:01:03 --> Total execution time: 1.2225
INFO - 2021-01-12 06:01:38 --> Config Class Initialized
INFO - 2021-01-12 06:01:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:01:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:01:38 --> Utf8 Class Initialized
INFO - 2021-01-12 06:01:38 --> URI Class Initialized
INFO - 2021-01-12 06:01:38 --> Router Class Initialized
INFO - 2021-01-12 06:01:38 --> Output Class Initialized
INFO - 2021-01-12 06:01:38 --> Security Class Initialized
DEBUG - 2021-01-12 06:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:01:39 --> Input Class Initialized
INFO - 2021-01-12 06:01:39 --> Language Class Initialized
INFO - 2021-01-12 06:01:39 --> Language Class Initialized
INFO - 2021-01-12 06:01:39 --> Config Class Initialized
INFO - 2021-01-12 06:01:39 --> Loader Class Initialized
INFO - 2021-01-12 06:01:39 --> Helper loaded: url_helper
INFO - 2021-01-12 06:01:39 --> Helper loaded: file_helper
INFO - 2021-01-12 06:01:39 --> Helper loaded: form_helper
INFO - 2021-01-12 06:01:39 --> Helper loaded: my_helper
INFO - 2021-01-12 06:01:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:01:39 --> Controller Class Initialized
DEBUG - 2021-01-12 06:01:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 06:01:39 --> Final output sent to browser
DEBUG - 2021-01-12 06:01:39 --> Total execution time: 1.1573
INFO - 2021-01-12 06:03:19 --> Config Class Initialized
INFO - 2021-01-12 06:03:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:03:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:03:19 --> Utf8 Class Initialized
INFO - 2021-01-12 06:03:19 --> URI Class Initialized
INFO - 2021-01-12 06:03:19 --> Router Class Initialized
INFO - 2021-01-12 06:03:20 --> Output Class Initialized
INFO - 2021-01-12 06:03:20 --> Security Class Initialized
DEBUG - 2021-01-12 06:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:03:20 --> Input Class Initialized
INFO - 2021-01-12 06:03:20 --> Language Class Initialized
INFO - 2021-01-12 06:03:20 --> Language Class Initialized
INFO - 2021-01-12 06:03:20 --> Config Class Initialized
INFO - 2021-01-12 06:03:20 --> Loader Class Initialized
INFO - 2021-01-12 06:03:20 --> Helper loaded: url_helper
INFO - 2021-01-12 06:03:20 --> Helper loaded: file_helper
INFO - 2021-01-12 06:03:20 --> Helper loaded: form_helper
INFO - 2021-01-12 06:03:20 --> Helper loaded: my_helper
INFO - 2021-01-12 06:03:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:03:20 --> Controller Class Initialized
DEBUG - 2021-01-12 06:03:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 06:03:20 --> Final output sent to browser
DEBUG - 2021-01-12 06:03:21 --> Total execution time: 1.2816
INFO - 2021-01-12 06:43:21 --> Config Class Initialized
INFO - 2021-01-12 06:43:21 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:43:21 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:43:21 --> Utf8 Class Initialized
INFO - 2021-01-12 06:43:21 --> URI Class Initialized
INFO - 2021-01-12 06:43:21 --> Router Class Initialized
INFO - 2021-01-12 06:43:21 --> Output Class Initialized
INFO - 2021-01-12 06:43:21 --> Security Class Initialized
DEBUG - 2021-01-12 06:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:43:21 --> Input Class Initialized
INFO - 2021-01-12 06:43:21 --> Language Class Initialized
INFO - 2021-01-12 06:43:21 --> Language Class Initialized
INFO - 2021-01-12 06:43:21 --> Config Class Initialized
INFO - 2021-01-12 06:43:21 --> Loader Class Initialized
INFO - 2021-01-12 06:43:21 --> Helper loaded: url_helper
INFO - 2021-01-12 06:43:21 --> Helper loaded: file_helper
INFO - 2021-01-12 06:43:21 --> Helper loaded: form_helper
INFO - 2021-01-12 06:43:21 --> Helper loaded: my_helper
INFO - 2021-01-12 06:43:21 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:43:21 --> Controller Class Initialized
DEBUG - 2021-01-12 06:43:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 06:43:21 --> Final output sent to browser
DEBUG - 2021-01-12 06:43:21 --> Total execution time: 0.3857
INFO - 2021-01-12 06:44:08 --> Config Class Initialized
INFO - 2021-01-12 06:44:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:44:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:44:08 --> Utf8 Class Initialized
INFO - 2021-01-12 06:44:08 --> URI Class Initialized
INFO - 2021-01-12 06:44:08 --> Router Class Initialized
INFO - 2021-01-12 06:44:08 --> Output Class Initialized
INFO - 2021-01-12 06:44:08 --> Security Class Initialized
DEBUG - 2021-01-12 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:44:08 --> Input Class Initialized
INFO - 2021-01-12 06:44:08 --> Language Class Initialized
INFO - 2021-01-12 06:44:08 --> Language Class Initialized
INFO - 2021-01-12 06:44:08 --> Config Class Initialized
INFO - 2021-01-12 06:44:08 --> Loader Class Initialized
INFO - 2021-01-12 06:44:08 --> Helper loaded: url_helper
INFO - 2021-01-12 06:44:08 --> Helper loaded: file_helper
INFO - 2021-01-12 06:44:08 --> Helper loaded: form_helper
INFO - 2021-01-12 06:44:08 --> Helper loaded: my_helper
INFO - 2021-01-12 06:44:08 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:44:08 --> Controller Class Initialized
DEBUG - 2021-01-12 06:44:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 06:44:08 --> Final output sent to browser
DEBUG - 2021-01-12 06:44:08 --> Total execution time: 0.3837
INFO - 2021-01-12 06:44:23 --> Config Class Initialized
INFO - 2021-01-12 06:44:23 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:44:23 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:44:23 --> Utf8 Class Initialized
INFO - 2021-01-12 06:44:23 --> URI Class Initialized
INFO - 2021-01-12 06:44:23 --> Router Class Initialized
INFO - 2021-01-12 06:44:23 --> Output Class Initialized
INFO - 2021-01-12 06:44:23 --> Security Class Initialized
DEBUG - 2021-01-12 06:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:44:23 --> Input Class Initialized
INFO - 2021-01-12 06:44:23 --> Language Class Initialized
INFO - 2021-01-12 06:44:23 --> Language Class Initialized
INFO - 2021-01-12 06:44:23 --> Config Class Initialized
INFO - 2021-01-12 06:44:23 --> Loader Class Initialized
INFO - 2021-01-12 06:44:23 --> Helper loaded: url_helper
INFO - 2021-01-12 06:44:23 --> Helper loaded: file_helper
INFO - 2021-01-12 06:44:23 --> Helper loaded: form_helper
INFO - 2021-01-12 06:44:23 --> Helper loaded: my_helper
INFO - 2021-01-12 06:44:23 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:44:23 --> Controller Class Initialized
DEBUG - 2021-01-12 06:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 06:44:23 --> Final output sent to browser
DEBUG - 2021-01-12 06:44:23 --> Total execution time: 0.3832
INFO - 2021-01-12 06:44:41 --> Config Class Initialized
INFO - 2021-01-12 06:44:41 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:44:41 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:44:41 --> Utf8 Class Initialized
INFO - 2021-01-12 06:44:41 --> URI Class Initialized
INFO - 2021-01-12 06:44:41 --> Router Class Initialized
INFO - 2021-01-12 06:44:41 --> Output Class Initialized
INFO - 2021-01-12 06:44:41 --> Security Class Initialized
DEBUG - 2021-01-12 06:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:44:41 --> Input Class Initialized
INFO - 2021-01-12 06:44:41 --> Language Class Initialized
INFO - 2021-01-12 06:44:41 --> Language Class Initialized
INFO - 2021-01-12 06:44:41 --> Config Class Initialized
INFO - 2021-01-12 06:44:41 --> Loader Class Initialized
INFO - 2021-01-12 06:44:41 --> Helper loaded: url_helper
INFO - 2021-01-12 06:44:41 --> Helper loaded: file_helper
INFO - 2021-01-12 06:44:41 --> Helper loaded: form_helper
INFO - 2021-01-12 06:44:41 --> Helper loaded: my_helper
INFO - 2021-01-12 06:44:41 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:44:41 --> Controller Class Initialized
DEBUG - 2021-01-12 06:44:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 06:44:41 --> Final output sent to browser
DEBUG - 2021-01-12 06:44:41 --> Total execution time: 0.3788
INFO - 2021-01-12 06:45:35 --> Config Class Initialized
INFO - 2021-01-12 06:45:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:45:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:45:35 --> Utf8 Class Initialized
INFO - 2021-01-12 06:45:35 --> URI Class Initialized
INFO - 2021-01-12 06:45:35 --> Router Class Initialized
INFO - 2021-01-12 06:45:35 --> Output Class Initialized
INFO - 2021-01-12 06:45:35 --> Security Class Initialized
DEBUG - 2021-01-12 06:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:45:35 --> Input Class Initialized
INFO - 2021-01-12 06:45:35 --> Language Class Initialized
INFO - 2021-01-12 06:45:35 --> Language Class Initialized
INFO - 2021-01-12 06:45:35 --> Config Class Initialized
INFO - 2021-01-12 06:45:35 --> Loader Class Initialized
INFO - 2021-01-12 06:45:35 --> Helper loaded: url_helper
INFO - 2021-01-12 06:45:35 --> Helper loaded: file_helper
INFO - 2021-01-12 06:45:35 --> Helper loaded: form_helper
INFO - 2021-01-12 06:45:35 --> Helper loaded: my_helper
INFO - 2021-01-12 06:45:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:45:35 --> Controller Class Initialized
DEBUG - 2021-01-12 06:45:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 06:45:35 --> Final output sent to browser
DEBUG - 2021-01-12 06:45:35 --> Total execution time: 0.4882
INFO - 2021-01-12 06:45:50 --> Config Class Initialized
INFO - 2021-01-12 06:45:50 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:45:50 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:45:50 --> Utf8 Class Initialized
INFO - 2021-01-12 06:45:50 --> URI Class Initialized
INFO - 2021-01-12 06:45:50 --> Router Class Initialized
INFO - 2021-01-12 06:45:50 --> Output Class Initialized
INFO - 2021-01-12 06:45:50 --> Security Class Initialized
DEBUG - 2021-01-12 06:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:45:50 --> Input Class Initialized
INFO - 2021-01-12 06:45:50 --> Language Class Initialized
INFO - 2021-01-12 06:45:50 --> Language Class Initialized
INFO - 2021-01-12 06:45:50 --> Config Class Initialized
INFO - 2021-01-12 06:45:50 --> Loader Class Initialized
INFO - 2021-01-12 06:45:50 --> Helper loaded: url_helper
INFO - 2021-01-12 06:45:50 --> Helper loaded: file_helper
INFO - 2021-01-12 06:45:50 --> Helper loaded: form_helper
INFO - 2021-01-12 06:45:50 --> Helper loaded: my_helper
INFO - 2021-01-12 06:45:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:45:50 --> Controller Class Initialized
DEBUG - 2021-01-12 06:45:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-12 06:45:50 --> Final output sent to browser
DEBUG - 2021-01-12 06:45:50 --> Total execution time: 0.3957
INFO - 2021-01-12 06:47:20 --> Config Class Initialized
INFO - 2021-01-12 06:47:20 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:47:20 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:47:20 --> Utf8 Class Initialized
INFO - 2021-01-12 06:47:20 --> URI Class Initialized
INFO - 2021-01-12 06:47:20 --> Router Class Initialized
INFO - 2021-01-12 06:47:20 --> Output Class Initialized
INFO - 2021-01-12 06:47:20 --> Security Class Initialized
DEBUG - 2021-01-12 06:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:47:20 --> Input Class Initialized
INFO - 2021-01-12 06:47:20 --> Language Class Initialized
INFO - 2021-01-12 06:47:20 --> Language Class Initialized
INFO - 2021-01-12 06:47:20 --> Config Class Initialized
INFO - 2021-01-12 06:47:20 --> Loader Class Initialized
INFO - 2021-01-12 06:47:20 --> Helper loaded: url_helper
INFO - 2021-01-12 06:47:20 --> Helper loaded: file_helper
INFO - 2021-01-12 06:47:20 --> Helper loaded: form_helper
INFO - 2021-01-12 06:47:20 --> Helper loaded: my_helper
INFO - 2021-01-12 06:47:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:47:20 --> Controller Class Initialized
INFO - 2021-01-12 06:47:20 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:47:20 --> Config Class Initialized
INFO - 2021-01-12 06:47:20 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:47:20 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:47:20 --> Utf8 Class Initialized
INFO - 2021-01-12 06:47:20 --> URI Class Initialized
INFO - 2021-01-12 06:47:20 --> Router Class Initialized
INFO - 2021-01-12 06:47:20 --> Output Class Initialized
INFO - 2021-01-12 06:47:21 --> Security Class Initialized
DEBUG - 2021-01-12 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:47:21 --> Input Class Initialized
INFO - 2021-01-12 06:47:21 --> Language Class Initialized
INFO - 2021-01-12 06:47:21 --> Language Class Initialized
INFO - 2021-01-12 06:47:21 --> Config Class Initialized
INFO - 2021-01-12 06:47:21 --> Loader Class Initialized
INFO - 2021-01-12 06:47:21 --> Helper loaded: url_helper
INFO - 2021-01-12 06:47:21 --> Helper loaded: file_helper
INFO - 2021-01-12 06:47:21 --> Helper loaded: form_helper
INFO - 2021-01-12 06:47:21 --> Helper loaded: my_helper
INFO - 2021-01-12 06:47:21 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:47:21 --> Controller Class Initialized
DEBUG - 2021-01-12 06:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 06:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:47:21 --> Final output sent to browser
DEBUG - 2021-01-12 06:47:21 --> Total execution time: 0.3492
INFO - 2021-01-12 06:47:26 --> Config Class Initialized
INFO - 2021-01-12 06:47:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:47:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:47:26 --> Utf8 Class Initialized
INFO - 2021-01-12 06:47:26 --> URI Class Initialized
INFO - 2021-01-12 06:47:26 --> Router Class Initialized
INFO - 2021-01-12 06:47:26 --> Output Class Initialized
INFO - 2021-01-12 06:47:27 --> Security Class Initialized
DEBUG - 2021-01-12 06:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:47:27 --> Input Class Initialized
INFO - 2021-01-12 06:47:27 --> Language Class Initialized
INFO - 2021-01-12 06:47:27 --> Language Class Initialized
INFO - 2021-01-12 06:47:27 --> Config Class Initialized
INFO - 2021-01-12 06:47:27 --> Loader Class Initialized
INFO - 2021-01-12 06:47:27 --> Helper loaded: url_helper
INFO - 2021-01-12 06:47:27 --> Helper loaded: file_helper
INFO - 2021-01-12 06:47:27 --> Helper loaded: form_helper
INFO - 2021-01-12 06:47:27 --> Helper loaded: my_helper
INFO - 2021-01-12 06:47:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:47:27 --> Controller Class Initialized
INFO - 2021-01-12 06:47:27 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:47:27 --> Final output sent to browser
DEBUG - 2021-01-12 06:47:27 --> Total execution time: 0.4501
INFO - 2021-01-12 06:47:27 --> Config Class Initialized
INFO - 2021-01-12 06:47:27 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:47:27 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:47:27 --> Utf8 Class Initialized
INFO - 2021-01-12 06:47:27 --> URI Class Initialized
INFO - 2021-01-12 06:47:27 --> Router Class Initialized
INFO - 2021-01-12 06:47:27 --> Output Class Initialized
INFO - 2021-01-12 06:47:27 --> Security Class Initialized
DEBUG - 2021-01-12 06:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:47:27 --> Input Class Initialized
INFO - 2021-01-12 06:47:27 --> Language Class Initialized
INFO - 2021-01-12 06:47:27 --> Language Class Initialized
INFO - 2021-01-12 06:47:27 --> Config Class Initialized
INFO - 2021-01-12 06:47:27 --> Loader Class Initialized
INFO - 2021-01-12 06:47:28 --> Helper loaded: url_helper
INFO - 2021-01-12 06:47:28 --> Helper loaded: file_helper
INFO - 2021-01-12 06:47:28 --> Helper loaded: form_helper
INFO - 2021-01-12 06:47:28 --> Helper loaded: my_helper
INFO - 2021-01-12 06:47:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:47:28 --> Controller Class Initialized
DEBUG - 2021-01-12 06:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 06:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:47:28 --> Final output sent to browser
DEBUG - 2021-01-12 06:47:28 --> Total execution time: 0.4688
INFO - 2021-01-12 06:47:32 --> Config Class Initialized
INFO - 2021-01-12 06:47:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:47:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:47:32 --> Utf8 Class Initialized
INFO - 2021-01-12 06:47:32 --> URI Class Initialized
INFO - 2021-01-12 06:47:32 --> Router Class Initialized
INFO - 2021-01-12 06:47:32 --> Output Class Initialized
INFO - 2021-01-12 06:47:32 --> Security Class Initialized
DEBUG - 2021-01-12 06:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:47:32 --> Input Class Initialized
INFO - 2021-01-12 06:47:32 --> Language Class Initialized
INFO - 2021-01-12 06:47:32 --> Language Class Initialized
INFO - 2021-01-12 06:47:32 --> Config Class Initialized
INFO - 2021-01-12 06:47:32 --> Loader Class Initialized
INFO - 2021-01-12 06:47:32 --> Helper loaded: url_helper
INFO - 2021-01-12 06:47:32 --> Helper loaded: file_helper
INFO - 2021-01-12 06:47:32 --> Helper loaded: form_helper
INFO - 2021-01-12 06:47:32 --> Helper loaded: my_helper
INFO - 2021-01-12 06:47:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:47:32 --> Controller Class Initialized
DEBUG - 2021-01-12 06:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 06:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:47:32 --> Final output sent to browser
DEBUG - 2021-01-12 06:47:32 --> Total execution time: 0.3651
INFO - 2021-01-12 06:47:38 --> Config Class Initialized
INFO - 2021-01-12 06:47:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:47:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:47:38 --> Utf8 Class Initialized
INFO - 2021-01-12 06:47:38 --> URI Class Initialized
INFO - 2021-01-12 06:47:38 --> Router Class Initialized
INFO - 2021-01-12 06:47:38 --> Output Class Initialized
INFO - 2021-01-12 06:47:38 --> Security Class Initialized
DEBUG - 2021-01-12 06:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:47:38 --> Input Class Initialized
INFO - 2021-01-12 06:47:38 --> Language Class Initialized
INFO - 2021-01-12 06:47:38 --> Language Class Initialized
INFO - 2021-01-12 06:47:38 --> Config Class Initialized
INFO - 2021-01-12 06:47:38 --> Loader Class Initialized
INFO - 2021-01-12 06:47:38 --> Helper loaded: url_helper
INFO - 2021-01-12 06:47:38 --> Helper loaded: file_helper
INFO - 2021-01-12 06:47:38 --> Helper loaded: form_helper
INFO - 2021-01-12 06:47:38 --> Helper loaded: my_helper
INFO - 2021-01-12 06:47:38 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:47:38 --> Controller Class Initialized
INFO - 2021-01-12 06:47:39 --> Final output sent to browser
DEBUG - 2021-01-12 06:47:39 --> Total execution time: 0.3522
INFO - 2021-01-12 06:47:40 --> Config Class Initialized
INFO - 2021-01-12 06:47:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:47:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:47:40 --> Utf8 Class Initialized
INFO - 2021-01-12 06:47:40 --> URI Class Initialized
INFO - 2021-01-12 06:47:40 --> Router Class Initialized
INFO - 2021-01-12 06:47:40 --> Output Class Initialized
INFO - 2021-01-12 06:47:40 --> Security Class Initialized
DEBUG - 2021-01-12 06:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:47:40 --> Input Class Initialized
INFO - 2021-01-12 06:47:40 --> Language Class Initialized
INFO - 2021-01-12 06:47:40 --> Language Class Initialized
INFO - 2021-01-12 06:47:40 --> Config Class Initialized
INFO - 2021-01-12 06:47:40 --> Loader Class Initialized
INFO - 2021-01-12 06:47:40 --> Helper loaded: url_helper
INFO - 2021-01-12 06:47:40 --> Helper loaded: file_helper
INFO - 2021-01-12 06:47:40 --> Helper loaded: form_helper
INFO - 2021-01-12 06:47:40 --> Helper loaded: my_helper
INFO - 2021-01-12 06:47:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:47:40 --> Controller Class Initialized
DEBUG - 2021-01-12 06:47:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 06:47:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:47:40 --> Final output sent to browser
DEBUG - 2021-01-12 06:47:40 --> Total execution time: 0.3446
INFO - 2021-01-12 06:47:44 --> Config Class Initialized
INFO - 2021-01-12 06:47:44 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:47:44 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:47:44 --> Utf8 Class Initialized
INFO - 2021-01-12 06:47:44 --> URI Class Initialized
INFO - 2021-01-12 06:47:44 --> Router Class Initialized
INFO - 2021-01-12 06:47:44 --> Output Class Initialized
INFO - 2021-01-12 06:47:44 --> Security Class Initialized
DEBUG - 2021-01-12 06:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:47:44 --> Input Class Initialized
INFO - 2021-01-12 06:47:44 --> Language Class Initialized
INFO - 2021-01-12 06:47:44 --> Language Class Initialized
INFO - 2021-01-12 06:47:44 --> Config Class Initialized
INFO - 2021-01-12 06:47:44 --> Loader Class Initialized
INFO - 2021-01-12 06:47:44 --> Helper loaded: url_helper
INFO - 2021-01-12 06:47:44 --> Helper loaded: file_helper
INFO - 2021-01-12 06:47:44 --> Helper loaded: form_helper
INFO - 2021-01-12 06:47:44 --> Helper loaded: my_helper
INFO - 2021-01-12 06:47:44 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:47:44 --> Controller Class Initialized
DEBUG - 2021-01-12 06:47:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 06:47:44 --> Final output sent to browser
DEBUG - 2021-01-12 06:47:44 --> Total execution time: 0.4931
INFO - 2021-01-12 06:49:05 --> Config Class Initialized
INFO - 2021-01-12 06:49:05 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:49:05 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:49:05 --> Utf8 Class Initialized
INFO - 2021-01-12 06:49:05 --> URI Class Initialized
INFO - 2021-01-12 06:49:05 --> Router Class Initialized
INFO - 2021-01-12 06:49:05 --> Output Class Initialized
INFO - 2021-01-12 06:49:05 --> Security Class Initialized
DEBUG - 2021-01-12 06:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:49:05 --> Input Class Initialized
INFO - 2021-01-12 06:49:05 --> Language Class Initialized
INFO - 2021-01-12 06:49:05 --> Language Class Initialized
INFO - 2021-01-12 06:49:05 --> Config Class Initialized
INFO - 2021-01-12 06:49:05 --> Loader Class Initialized
INFO - 2021-01-12 06:49:05 --> Helper loaded: url_helper
INFO - 2021-01-12 06:49:05 --> Helper loaded: file_helper
INFO - 2021-01-12 06:49:05 --> Helper loaded: form_helper
INFO - 2021-01-12 06:49:05 --> Helper loaded: my_helper
INFO - 2021-01-12 06:49:05 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:49:05 --> Controller Class Initialized
DEBUG - 2021-01-12 06:49:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 06:49:05 --> Final output sent to browser
DEBUG - 2021-01-12 06:49:05 --> Total execution time: 0.3818
INFO - 2021-01-12 06:49:26 --> Config Class Initialized
INFO - 2021-01-12 06:49:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:49:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:49:26 --> Utf8 Class Initialized
INFO - 2021-01-12 06:49:26 --> URI Class Initialized
INFO - 2021-01-12 06:49:26 --> Router Class Initialized
INFO - 2021-01-12 06:49:26 --> Output Class Initialized
INFO - 2021-01-12 06:49:26 --> Security Class Initialized
DEBUG - 2021-01-12 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:49:26 --> Input Class Initialized
INFO - 2021-01-12 06:49:26 --> Language Class Initialized
INFO - 2021-01-12 06:49:26 --> Language Class Initialized
INFO - 2021-01-12 06:49:26 --> Config Class Initialized
INFO - 2021-01-12 06:49:26 --> Loader Class Initialized
INFO - 2021-01-12 06:49:26 --> Helper loaded: url_helper
INFO - 2021-01-12 06:49:26 --> Helper loaded: file_helper
INFO - 2021-01-12 06:49:26 --> Helper loaded: form_helper
INFO - 2021-01-12 06:49:26 --> Helper loaded: my_helper
INFO - 2021-01-12 06:49:26 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:49:26 --> Controller Class Initialized
DEBUG - 2021-01-12 06:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 06:49:26 --> Final output sent to browser
DEBUG - 2021-01-12 06:49:26 --> Total execution time: 0.4049
INFO - 2021-01-12 06:49:38 --> Config Class Initialized
INFO - 2021-01-12 06:49:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:49:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:49:38 --> Utf8 Class Initialized
INFO - 2021-01-12 06:49:38 --> URI Class Initialized
INFO - 2021-01-12 06:49:38 --> Router Class Initialized
INFO - 2021-01-12 06:49:38 --> Output Class Initialized
INFO - 2021-01-12 06:49:38 --> Security Class Initialized
DEBUG - 2021-01-12 06:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:49:38 --> Input Class Initialized
INFO - 2021-01-12 06:49:38 --> Language Class Initialized
INFO - 2021-01-12 06:49:38 --> Language Class Initialized
INFO - 2021-01-12 06:49:38 --> Config Class Initialized
INFO - 2021-01-12 06:49:38 --> Loader Class Initialized
INFO - 2021-01-12 06:49:38 --> Helper loaded: url_helper
INFO - 2021-01-12 06:49:38 --> Helper loaded: file_helper
INFO - 2021-01-12 06:49:38 --> Helper loaded: form_helper
INFO - 2021-01-12 06:49:38 --> Helper loaded: my_helper
INFO - 2021-01-12 06:49:38 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:49:38 --> Controller Class Initialized
DEBUG - 2021-01-12 06:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 06:49:38 --> Final output sent to browser
DEBUG - 2021-01-12 06:49:38 --> Total execution time: 0.3877
INFO - 2021-01-12 06:49:56 --> Config Class Initialized
INFO - 2021-01-12 06:49:56 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:49:56 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:49:56 --> Utf8 Class Initialized
INFO - 2021-01-12 06:49:56 --> URI Class Initialized
INFO - 2021-01-12 06:49:56 --> Router Class Initialized
INFO - 2021-01-12 06:49:56 --> Output Class Initialized
INFO - 2021-01-12 06:49:56 --> Security Class Initialized
DEBUG - 2021-01-12 06:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:49:56 --> Input Class Initialized
INFO - 2021-01-12 06:49:56 --> Language Class Initialized
INFO - 2021-01-12 06:49:56 --> Language Class Initialized
INFO - 2021-01-12 06:49:56 --> Config Class Initialized
INFO - 2021-01-12 06:49:56 --> Loader Class Initialized
INFO - 2021-01-12 06:49:56 --> Helper loaded: url_helper
INFO - 2021-01-12 06:49:56 --> Helper loaded: file_helper
INFO - 2021-01-12 06:49:56 --> Helper loaded: form_helper
INFO - 2021-01-12 06:49:56 --> Helper loaded: my_helper
INFO - 2021-01-12 06:49:57 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:49:57 --> Controller Class Initialized
DEBUG - 2021-01-12 06:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 06:49:57 --> Final output sent to browser
DEBUG - 2021-01-12 06:49:57 --> Total execution time: 0.4436
INFO - 2021-01-12 06:50:09 --> Config Class Initialized
INFO - 2021-01-12 06:50:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:50:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:50:09 --> Utf8 Class Initialized
INFO - 2021-01-12 06:50:09 --> URI Class Initialized
INFO - 2021-01-12 06:50:09 --> Router Class Initialized
INFO - 2021-01-12 06:50:09 --> Output Class Initialized
INFO - 2021-01-12 06:50:09 --> Security Class Initialized
DEBUG - 2021-01-12 06:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:50:09 --> Input Class Initialized
INFO - 2021-01-12 06:50:09 --> Language Class Initialized
INFO - 2021-01-12 06:50:09 --> Language Class Initialized
INFO - 2021-01-12 06:50:09 --> Config Class Initialized
INFO - 2021-01-12 06:50:10 --> Loader Class Initialized
INFO - 2021-01-12 06:50:10 --> Helper loaded: url_helper
INFO - 2021-01-12 06:50:10 --> Helper loaded: file_helper
INFO - 2021-01-12 06:50:10 --> Helper loaded: form_helper
INFO - 2021-01-12 06:50:10 --> Helper loaded: my_helper
INFO - 2021-01-12 06:50:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:50:10 --> Controller Class Initialized
DEBUG - 2021-01-12 06:50:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 06:50:10 --> Final output sent to browser
DEBUG - 2021-01-12 06:50:10 --> Total execution time: 0.3824
INFO - 2021-01-12 06:50:20 --> Config Class Initialized
INFO - 2021-01-12 06:50:20 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:50:20 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:50:20 --> Utf8 Class Initialized
INFO - 2021-01-12 06:50:20 --> URI Class Initialized
INFO - 2021-01-12 06:50:20 --> Router Class Initialized
INFO - 2021-01-12 06:50:20 --> Output Class Initialized
INFO - 2021-01-12 06:50:21 --> Security Class Initialized
DEBUG - 2021-01-12 06:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:50:21 --> Input Class Initialized
INFO - 2021-01-12 06:50:21 --> Language Class Initialized
INFO - 2021-01-12 06:50:21 --> Language Class Initialized
INFO - 2021-01-12 06:50:21 --> Config Class Initialized
INFO - 2021-01-12 06:50:21 --> Loader Class Initialized
INFO - 2021-01-12 06:50:21 --> Helper loaded: url_helper
INFO - 2021-01-12 06:50:21 --> Helper loaded: file_helper
INFO - 2021-01-12 06:50:21 --> Helper loaded: form_helper
INFO - 2021-01-12 06:50:21 --> Helper loaded: my_helper
INFO - 2021-01-12 06:50:21 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:50:21 --> Controller Class Initialized
DEBUG - 2021-01-12 06:50:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 06:50:21 --> Final output sent to browser
DEBUG - 2021-01-12 06:50:21 --> Total execution time: 0.4118
INFO - 2021-01-12 06:50:32 --> Config Class Initialized
INFO - 2021-01-12 06:50:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:50:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:50:32 --> Utf8 Class Initialized
INFO - 2021-01-12 06:50:32 --> URI Class Initialized
INFO - 2021-01-12 06:50:32 --> Router Class Initialized
INFO - 2021-01-12 06:50:32 --> Output Class Initialized
INFO - 2021-01-12 06:50:32 --> Security Class Initialized
DEBUG - 2021-01-12 06:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:50:32 --> Input Class Initialized
INFO - 2021-01-12 06:50:32 --> Language Class Initialized
INFO - 2021-01-12 06:50:32 --> Language Class Initialized
INFO - 2021-01-12 06:50:32 --> Config Class Initialized
INFO - 2021-01-12 06:50:32 --> Loader Class Initialized
INFO - 2021-01-12 06:50:32 --> Helper loaded: url_helper
INFO - 2021-01-12 06:50:32 --> Helper loaded: file_helper
INFO - 2021-01-12 06:50:32 --> Helper loaded: form_helper
INFO - 2021-01-12 06:50:32 --> Helper loaded: my_helper
INFO - 2021-01-12 06:50:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:50:32 --> Controller Class Initialized
DEBUG - 2021-01-12 06:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-12 06:50:32 --> Final output sent to browser
DEBUG - 2021-01-12 06:50:32 --> Total execution time: 0.3863
INFO - 2021-01-12 06:51:22 --> Config Class Initialized
INFO - 2021-01-12 06:51:22 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:51:22 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:51:22 --> Utf8 Class Initialized
INFO - 2021-01-12 06:51:22 --> URI Class Initialized
INFO - 2021-01-12 06:51:22 --> Router Class Initialized
INFO - 2021-01-12 06:51:22 --> Output Class Initialized
INFO - 2021-01-12 06:51:22 --> Security Class Initialized
DEBUG - 2021-01-12 06:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:51:22 --> Input Class Initialized
INFO - 2021-01-12 06:51:22 --> Language Class Initialized
INFO - 2021-01-12 06:51:22 --> Language Class Initialized
INFO - 2021-01-12 06:51:22 --> Config Class Initialized
INFO - 2021-01-12 06:51:22 --> Loader Class Initialized
INFO - 2021-01-12 06:51:22 --> Helper loaded: url_helper
INFO - 2021-01-12 06:51:22 --> Helper loaded: file_helper
INFO - 2021-01-12 06:51:22 --> Helper loaded: form_helper
INFO - 2021-01-12 06:51:22 --> Helper loaded: my_helper
INFO - 2021-01-12 06:51:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:51:22 --> Controller Class Initialized
INFO - 2021-01-12 06:51:22 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:51:22 --> Config Class Initialized
INFO - 2021-01-12 06:51:22 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:51:22 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:51:22 --> Utf8 Class Initialized
INFO - 2021-01-12 06:51:22 --> URI Class Initialized
INFO - 2021-01-12 06:51:22 --> Router Class Initialized
INFO - 2021-01-12 06:51:22 --> Output Class Initialized
INFO - 2021-01-12 06:51:22 --> Security Class Initialized
DEBUG - 2021-01-12 06:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:51:22 --> Input Class Initialized
INFO - 2021-01-12 06:51:22 --> Language Class Initialized
INFO - 2021-01-12 06:51:22 --> Language Class Initialized
INFO - 2021-01-12 06:51:22 --> Config Class Initialized
INFO - 2021-01-12 06:51:22 --> Loader Class Initialized
INFO - 2021-01-12 06:51:22 --> Helper loaded: url_helper
INFO - 2021-01-12 06:51:22 --> Helper loaded: file_helper
INFO - 2021-01-12 06:51:22 --> Helper loaded: form_helper
INFO - 2021-01-12 06:51:22 --> Helper loaded: my_helper
INFO - 2021-01-12 06:51:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:51:22 --> Controller Class Initialized
DEBUG - 2021-01-12 06:51:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 06:51:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:51:22 --> Final output sent to browser
DEBUG - 2021-01-12 06:51:22 --> Total execution time: 0.3729
INFO - 2021-01-12 06:51:28 --> Config Class Initialized
INFO - 2021-01-12 06:51:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:51:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:51:29 --> Utf8 Class Initialized
INFO - 2021-01-12 06:51:29 --> URI Class Initialized
INFO - 2021-01-12 06:51:29 --> Router Class Initialized
INFO - 2021-01-12 06:51:29 --> Output Class Initialized
INFO - 2021-01-12 06:51:29 --> Security Class Initialized
DEBUG - 2021-01-12 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:51:29 --> Input Class Initialized
INFO - 2021-01-12 06:51:29 --> Language Class Initialized
INFO - 2021-01-12 06:51:29 --> Language Class Initialized
INFO - 2021-01-12 06:51:29 --> Config Class Initialized
INFO - 2021-01-12 06:51:29 --> Loader Class Initialized
INFO - 2021-01-12 06:51:29 --> Helper loaded: url_helper
INFO - 2021-01-12 06:51:29 --> Helper loaded: file_helper
INFO - 2021-01-12 06:51:29 --> Helper loaded: form_helper
INFO - 2021-01-12 06:51:29 --> Helper loaded: my_helper
INFO - 2021-01-12 06:51:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:51:29 --> Controller Class Initialized
INFO - 2021-01-12 06:51:29 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:51:29 --> Final output sent to browser
DEBUG - 2021-01-12 06:51:29 --> Total execution time: 0.4405
INFO - 2021-01-12 06:51:29 --> Config Class Initialized
INFO - 2021-01-12 06:51:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:51:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:51:29 --> Utf8 Class Initialized
INFO - 2021-01-12 06:51:29 --> URI Class Initialized
INFO - 2021-01-12 06:51:29 --> Router Class Initialized
INFO - 2021-01-12 06:51:29 --> Output Class Initialized
INFO - 2021-01-12 06:51:29 --> Security Class Initialized
DEBUG - 2021-01-12 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:51:29 --> Input Class Initialized
INFO - 2021-01-12 06:51:29 --> Language Class Initialized
INFO - 2021-01-12 06:51:29 --> Language Class Initialized
INFO - 2021-01-12 06:51:29 --> Config Class Initialized
INFO - 2021-01-12 06:51:29 --> Loader Class Initialized
INFO - 2021-01-12 06:51:29 --> Helper loaded: url_helper
INFO - 2021-01-12 06:51:29 --> Helper loaded: file_helper
INFO - 2021-01-12 06:51:29 --> Helper loaded: form_helper
INFO - 2021-01-12 06:51:29 --> Helper loaded: my_helper
INFO - 2021-01-12 06:51:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:51:30 --> Controller Class Initialized
DEBUG - 2021-01-12 06:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 06:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:51:30 --> Final output sent to browser
DEBUG - 2021-01-12 06:51:30 --> Total execution time: 0.4834
INFO - 2021-01-12 06:51:33 --> Config Class Initialized
INFO - 2021-01-12 06:51:33 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:51:33 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:51:33 --> Utf8 Class Initialized
INFO - 2021-01-12 06:51:33 --> URI Class Initialized
INFO - 2021-01-12 06:51:33 --> Router Class Initialized
INFO - 2021-01-12 06:51:33 --> Output Class Initialized
INFO - 2021-01-12 06:51:33 --> Security Class Initialized
DEBUG - 2021-01-12 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:51:33 --> Input Class Initialized
INFO - 2021-01-12 06:51:33 --> Language Class Initialized
INFO - 2021-01-12 06:51:33 --> Language Class Initialized
INFO - 2021-01-12 06:51:33 --> Config Class Initialized
INFO - 2021-01-12 06:51:33 --> Loader Class Initialized
INFO - 2021-01-12 06:51:33 --> Helper loaded: url_helper
INFO - 2021-01-12 06:51:33 --> Helper loaded: file_helper
INFO - 2021-01-12 06:51:33 --> Helper loaded: form_helper
INFO - 2021-01-12 06:51:33 --> Helper loaded: my_helper
INFO - 2021-01-12 06:51:33 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:51:33 --> Controller Class Initialized
DEBUG - 2021-01-12 06:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 06:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:51:33 --> Final output sent to browser
DEBUG - 2021-01-12 06:51:33 --> Total execution time: 0.3585
INFO - 2021-01-12 06:51:39 --> Config Class Initialized
INFO - 2021-01-12 06:51:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:51:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:51:39 --> Utf8 Class Initialized
INFO - 2021-01-12 06:51:39 --> URI Class Initialized
INFO - 2021-01-12 06:51:39 --> Router Class Initialized
INFO - 2021-01-12 06:51:39 --> Output Class Initialized
INFO - 2021-01-12 06:51:39 --> Security Class Initialized
DEBUG - 2021-01-12 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:51:39 --> Input Class Initialized
INFO - 2021-01-12 06:51:39 --> Language Class Initialized
INFO - 2021-01-12 06:51:39 --> Language Class Initialized
INFO - 2021-01-12 06:51:39 --> Config Class Initialized
INFO - 2021-01-12 06:51:39 --> Loader Class Initialized
INFO - 2021-01-12 06:51:39 --> Helper loaded: url_helper
INFO - 2021-01-12 06:51:39 --> Helper loaded: file_helper
INFO - 2021-01-12 06:51:39 --> Helper loaded: form_helper
INFO - 2021-01-12 06:51:39 --> Helper loaded: my_helper
INFO - 2021-01-12 06:51:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:51:39 --> Controller Class Initialized
INFO - 2021-01-12 06:51:39 --> Final output sent to browser
DEBUG - 2021-01-12 06:51:39 --> Total execution time: 0.3460
INFO - 2021-01-12 06:51:40 --> Config Class Initialized
INFO - 2021-01-12 06:51:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:51:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:51:40 --> Utf8 Class Initialized
INFO - 2021-01-12 06:51:40 --> URI Class Initialized
INFO - 2021-01-12 06:51:40 --> Router Class Initialized
INFO - 2021-01-12 06:51:40 --> Output Class Initialized
INFO - 2021-01-12 06:51:40 --> Security Class Initialized
DEBUG - 2021-01-12 06:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:51:40 --> Input Class Initialized
INFO - 2021-01-12 06:51:40 --> Language Class Initialized
INFO - 2021-01-12 06:51:40 --> Language Class Initialized
INFO - 2021-01-12 06:51:40 --> Config Class Initialized
INFO - 2021-01-12 06:51:40 --> Loader Class Initialized
INFO - 2021-01-12 06:51:40 --> Helper loaded: url_helper
INFO - 2021-01-12 06:51:40 --> Helper loaded: file_helper
INFO - 2021-01-12 06:51:40 --> Helper loaded: form_helper
INFO - 2021-01-12 06:51:40 --> Helper loaded: my_helper
INFO - 2021-01-12 06:51:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:51:41 --> Controller Class Initialized
DEBUG - 2021-01-12 06:51:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 06:51:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:51:41 --> Final output sent to browser
DEBUG - 2021-01-12 06:51:41 --> Total execution time: 0.3495
INFO - 2021-01-12 06:51:43 --> Config Class Initialized
INFO - 2021-01-12 06:51:43 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:51:43 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:51:43 --> Utf8 Class Initialized
INFO - 2021-01-12 06:51:43 --> URI Class Initialized
INFO - 2021-01-12 06:51:43 --> Router Class Initialized
INFO - 2021-01-12 06:51:43 --> Output Class Initialized
INFO - 2021-01-12 06:51:43 --> Security Class Initialized
DEBUG - 2021-01-12 06:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:51:43 --> Input Class Initialized
INFO - 2021-01-12 06:51:43 --> Language Class Initialized
INFO - 2021-01-12 06:51:43 --> Language Class Initialized
INFO - 2021-01-12 06:51:43 --> Config Class Initialized
INFO - 2021-01-12 06:51:43 --> Loader Class Initialized
INFO - 2021-01-12 06:51:43 --> Helper loaded: url_helper
INFO - 2021-01-12 06:51:43 --> Helper loaded: file_helper
INFO - 2021-01-12 06:51:43 --> Helper loaded: form_helper
INFO - 2021-01-12 06:51:43 --> Helper loaded: my_helper
INFO - 2021-01-12 06:51:43 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:51:43 --> Controller Class Initialized
DEBUG - 2021-01-12 06:51:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-12 06:51:44 --> Final output sent to browser
DEBUG - 2021-01-12 06:51:44 --> Total execution time: 0.4544
INFO - 2021-01-12 06:52:11 --> Config Class Initialized
INFO - 2021-01-12 06:52:11 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:52:11 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:52:11 --> Utf8 Class Initialized
INFO - 2021-01-12 06:52:11 --> URI Class Initialized
INFO - 2021-01-12 06:52:11 --> Router Class Initialized
INFO - 2021-01-12 06:52:11 --> Output Class Initialized
INFO - 2021-01-12 06:52:11 --> Security Class Initialized
DEBUG - 2021-01-12 06:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:52:11 --> Input Class Initialized
INFO - 2021-01-12 06:52:11 --> Language Class Initialized
INFO - 2021-01-12 06:52:11 --> Language Class Initialized
INFO - 2021-01-12 06:52:11 --> Config Class Initialized
INFO - 2021-01-12 06:52:11 --> Loader Class Initialized
INFO - 2021-01-12 06:52:11 --> Helper loaded: url_helper
INFO - 2021-01-12 06:52:11 --> Helper loaded: file_helper
INFO - 2021-01-12 06:52:11 --> Helper loaded: form_helper
INFO - 2021-01-12 06:52:11 --> Helper loaded: my_helper
INFO - 2021-01-12 06:52:11 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:52:11 --> Controller Class Initialized
DEBUG - 2021-01-12 06:52:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-12 06:52:11 --> Final output sent to browser
DEBUG - 2021-01-12 06:52:11 --> Total execution time: 0.4052
INFO - 2021-01-12 06:52:23 --> Config Class Initialized
INFO - 2021-01-12 06:52:23 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:52:23 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:52:23 --> Utf8 Class Initialized
INFO - 2021-01-12 06:52:23 --> URI Class Initialized
INFO - 2021-01-12 06:52:23 --> Router Class Initialized
INFO - 2021-01-12 06:52:23 --> Output Class Initialized
INFO - 2021-01-12 06:52:23 --> Security Class Initialized
DEBUG - 2021-01-12 06:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:52:23 --> Input Class Initialized
INFO - 2021-01-12 06:52:23 --> Language Class Initialized
INFO - 2021-01-12 06:52:23 --> Language Class Initialized
INFO - 2021-01-12 06:52:23 --> Config Class Initialized
INFO - 2021-01-12 06:52:23 --> Loader Class Initialized
INFO - 2021-01-12 06:52:23 --> Helper loaded: url_helper
INFO - 2021-01-12 06:52:23 --> Helper loaded: file_helper
INFO - 2021-01-12 06:52:23 --> Helper loaded: form_helper
INFO - 2021-01-12 06:52:23 --> Helper loaded: my_helper
INFO - 2021-01-12 06:52:23 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:52:23 --> Controller Class Initialized
DEBUG - 2021-01-12 06:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-12 06:52:23 --> Final output sent to browser
DEBUG - 2021-01-12 06:52:23 --> Total execution time: 0.4063
INFO - 2021-01-12 06:52:35 --> Config Class Initialized
INFO - 2021-01-12 06:52:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:52:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:52:35 --> Utf8 Class Initialized
INFO - 2021-01-12 06:52:35 --> URI Class Initialized
INFO - 2021-01-12 06:52:35 --> Router Class Initialized
INFO - 2021-01-12 06:52:36 --> Output Class Initialized
INFO - 2021-01-12 06:52:36 --> Security Class Initialized
DEBUG - 2021-01-12 06:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:52:36 --> Input Class Initialized
INFO - 2021-01-12 06:52:36 --> Language Class Initialized
INFO - 2021-01-12 06:52:36 --> Language Class Initialized
INFO - 2021-01-12 06:52:36 --> Config Class Initialized
INFO - 2021-01-12 06:52:36 --> Loader Class Initialized
INFO - 2021-01-12 06:52:36 --> Helper loaded: url_helper
INFO - 2021-01-12 06:52:36 --> Helper loaded: file_helper
INFO - 2021-01-12 06:52:36 --> Helper loaded: form_helper
INFO - 2021-01-12 06:52:36 --> Helper loaded: my_helper
INFO - 2021-01-12 06:52:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:52:36 --> Controller Class Initialized
DEBUG - 2021-01-12 06:52:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-12 06:52:36 --> Final output sent to browser
DEBUG - 2021-01-12 06:52:36 --> Total execution time: 0.4265
INFO - 2021-01-12 06:52:48 --> Config Class Initialized
INFO - 2021-01-12 06:52:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:52:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:52:48 --> Utf8 Class Initialized
INFO - 2021-01-12 06:52:48 --> URI Class Initialized
INFO - 2021-01-12 06:52:48 --> Router Class Initialized
INFO - 2021-01-12 06:52:48 --> Output Class Initialized
INFO - 2021-01-12 06:52:48 --> Security Class Initialized
DEBUG - 2021-01-12 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:52:48 --> Input Class Initialized
INFO - 2021-01-12 06:52:48 --> Language Class Initialized
INFO - 2021-01-12 06:52:48 --> Language Class Initialized
INFO - 2021-01-12 06:52:48 --> Config Class Initialized
INFO - 2021-01-12 06:52:48 --> Loader Class Initialized
INFO - 2021-01-12 06:52:48 --> Helper loaded: url_helper
INFO - 2021-01-12 06:52:48 --> Helper loaded: file_helper
INFO - 2021-01-12 06:52:48 --> Helper loaded: form_helper
INFO - 2021-01-12 06:52:48 --> Helper loaded: my_helper
INFO - 2021-01-12 06:52:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:52:48 --> Controller Class Initialized
DEBUG - 2021-01-12 06:52:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-12 06:52:48 --> Final output sent to browser
DEBUG - 2021-01-12 06:52:48 --> Total execution time: 0.3922
INFO - 2021-01-12 06:53:01 --> Config Class Initialized
INFO - 2021-01-12 06:53:01 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:53:01 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:53:01 --> Utf8 Class Initialized
INFO - 2021-01-12 06:53:01 --> URI Class Initialized
INFO - 2021-01-12 06:53:01 --> Router Class Initialized
INFO - 2021-01-12 06:53:01 --> Output Class Initialized
INFO - 2021-01-12 06:53:01 --> Security Class Initialized
DEBUG - 2021-01-12 06:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:53:01 --> Input Class Initialized
INFO - 2021-01-12 06:53:01 --> Language Class Initialized
INFO - 2021-01-12 06:53:01 --> Language Class Initialized
INFO - 2021-01-12 06:53:01 --> Config Class Initialized
INFO - 2021-01-12 06:53:01 --> Loader Class Initialized
INFO - 2021-01-12 06:53:01 --> Helper loaded: url_helper
INFO - 2021-01-12 06:53:01 --> Helper loaded: file_helper
INFO - 2021-01-12 06:53:01 --> Helper loaded: form_helper
INFO - 2021-01-12 06:53:01 --> Helper loaded: my_helper
INFO - 2021-01-12 06:53:01 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:53:01 --> Controller Class Initialized
DEBUG - 2021-01-12 06:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-12 06:53:01 --> Final output sent to browser
DEBUG - 2021-01-12 06:53:01 --> Total execution time: 0.4042
INFO - 2021-01-12 06:53:54 --> Config Class Initialized
INFO - 2021-01-12 06:53:54 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:53:54 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:53:54 --> Utf8 Class Initialized
INFO - 2021-01-12 06:53:54 --> URI Class Initialized
INFO - 2021-01-12 06:53:54 --> Router Class Initialized
INFO - 2021-01-12 06:53:54 --> Output Class Initialized
INFO - 2021-01-12 06:53:54 --> Security Class Initialized
DEBUG - 2021-01-12 06:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:53:54 --> Input Class Initialized
INFO - 2021-01-12 06:53:54 --> Language Class Initialized
INFO - 2021-01-12 06:53:54 --> Language Class Initialized
INFO - 2021-01-12 06:53:54 --> Config Class Initialized
INFO - 2021-01-12 06:53:54 --> Loader Class Initialized
INFO - 2021-01-12 06:53:54 --> Helper loaded: url_helper
INFO - 2021-01-12 06:53:54 --> Helper loaded: file_helper
INFO - 2021-01-12 06:53:54 --> Helper loaded: form_helper
INFO - 2021-01-12 06:53:54 --> Helper loaded: my_helper
INFO - 2021-01-12 06:53:54 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:53:54 --> Controller Class Initialized
INFO - 2021-01-12 06:53:55 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:53:55 --> Config Class Initialized
INFO - 2021-01-12 06:53:55 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:53:55 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:53:55 --> Utf8 Class Initialized
INFO - 2021-01-12 06:53:55 --> URI Class Initialized
INFO - 2021-01-12 06:53:55 --> Router Class Initialized
INFO - 2021-01-12 06:53:55 --> Output Class Initialized
INFO - 2021-01-12 06:53:55 --> Security Class Initialized
DEBUG - 2021-01-12 06:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:53:55 --> Input Class Initialized
INFO - 2021-01-12 06:53:55 --> Language Class Initialized
INFO - 2021-01-12 06:53:55 --> Language Class Initialized
INFO - 2021-01-12 06:53:55 --> Config Class Initialized
INFO - 2021-01-12 06:53:55 --> Loader Class Initialized
INFO - 2021-01-12 06:53:55 --> Helper loaded: url_helper
INFO - 2021-01-12 06:53:55 --> Helper loaded: file_helper
INFO - 2021-01-12 06:53:55 --> Helper loaded: form_helper
INFO - 2021-01-12 06:53:55 --> Helper loaded: my_helper
INFO - 2021-01-12 06:53:55 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:53:55 --> Controller Class Initialized
DEBUG - 2021-01-12 06:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 06:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:53:55 --> Final output sent to browser
DEBUG - 2021-01-12 06:53:55 --> Total execution time: 0.3357
INFO - 2021-01-12 06:54:00 --> Config Class Initialized
INFO - 2021-01-12 06:54:00 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:54:00 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:54:00 --> Utf8 Class Initialized
INFO - 2021-01-12 06:54:00 --> URI Class Initialized
INFO - 2021-01-12 06:54:00 --> Router Class Initialized
INFO - 2021-01-12 06:54:00 --> Output Class Initialized
INFO - 2021-01-12 06:54:00 --> Security Class Initialized
DEBUG - 2021-01-12 06:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:54:00 --> Input Class Initialized
INFO - 2021-01-12 06:54:00 --> Language Class Initialized
INFO - 2021-01-12 06:54:00 --> Language Class Initialized
INFO - 2021-01-12 06:54:00 --> Config Class Initialized
INFO - 2021-01-12 06:54:00 --> Loader Class Initialized
INFO - 2021-01-12 06:54:00 --> Helper loaded: url_helper
INFO - 2021-01-12 06:54:00 --> Helper loaded: file_helper
INFO - 2021-01-12 06:54:00 --> Helper loaded: form_helper
INFO - 2021-01-12 06:54:00 --> Helper loaded: my_helper
INFO - 2021-01-12 06:54:00 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:54:00 --> Controller Class Initialized
INFO - 2021-01-12 06:54:00 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:54:01 --> Final output sent to browser
DEBUG - 2021-01-12 06:54:01 --> Total execution time: 0.4445
INFO - 2021-01-12 06:54:01 --> Config Class Initialized
INFO - 2021-01-12 06:54:01 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:54:01 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:54:01 --> Utf8 Class Initialized
INFO - 2021-01-12 06:54:01 --> URI Class Initialized
INFO - 2021-01-12 06:54:01 --> Router Class Initialized
INFO - 2021-01-12 06:54:01 --> Output Class Initialized
INFO - 2021-01-12 06:54:01 --> Security Class Initialized
DEBUG - 2021-01-12 06:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:54:01 --> Input Class Initialized
INFO - 2021-01-12 06:54:01 --> Language Class Initialized
INFO - 2021-01-12 06:54:01 --> Language Class Initialized
INFO - 2021-01-12 06:54:01 --> Config Class Initialized
INFO - 2021-01-12 06:54:01 --> Loader Class Initialized
INFO - 2021-01-12 06:54:01 --> Helper loaded: url_helper
INFO - 2021-01-12 06:54:01 --> Helper loaded: file_helper
INFO - 2021-01-12 06:54:01 --> Helper loaded: form_helper
INFO - 2021-01-12 06:54:01 --> Helper loaded: my_helper
INFO - 2021-01-12 06:54:01 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:54:01 --> Controller Class Initialized
DEBUG - 2021-01-12 06:54:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 06:54:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:54:01 --> Final output sent to browser
DEBUG - 2021-01-12 06:54:01 --> Total execution time: 0.4927
INFO - 2021-01-12 06:54:04 --> Config Class Initialized
INFO - 2021-01-12 06:54:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:54:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:54:04 --> Utf8 Class Initialized
INFO - 2021-01-12 06:54:04 --> URI Class Initialized
INFO - 2021-01-12 06:54:04 --> Router Class Initialized
INFO - 2021-01-12 06:54:04 --> Output Class Initialized
INFO - 2021-01-12 06:54:04 --> Security Class Initialized
DEBUG - 2021-01-12 06:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:54:04 --> Input Class Initialized
INFO - 2021-01-12 06:54:04 --> Language Class Initialized
INFO - 2021-01-12 06:54:04 --> Language Class Initialized
INFO - 2021-01-12 06:54:04 --> Config Class Initialized
INFO - 2021-01-12 06:54:04 --> Loader Class Initialized
INFO - 2021-01-12 06:54:04 --> Helper loaded: url_helper
INFO - 2021-01-12 06:54:04 --> Helper loaded: file_helper
INFO - 2021-01-12 06:54:04 --> Helper loaded: form_helper
INFO - 2021-01-12 06:54:04 --> Helper loaded: my_helper
INFO - 2021-01-12 06:54:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:54:04 --> Controller Class Initialized
DEBUG - 2021-01-12 06:54:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 06:54:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:54:04 --> Final output sent to browser
DEBUG - 2021-01-12 06:54:04 --> Total execution time: 0.3976
INFO - 2021-01-12 06:54:10 --> Config Class Initialized
INFO - 2021-01-12 06:54:10 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:54:10 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:54:10 --> Utf8 Class Initialized
INFO - 2021-01-12 06:54:10 --> URI Class Initialized
INFO - 2021-01-12 06:54:10 --> Router Class Initialized
INFO - 2021-01-12 06:54:10 --> Output Class Initialized
INFO - 2021-01-12 06:54:10 --> Security Class Initialized
DEBUG - 2021-01-12 06:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:54:10 --> Input Class Initialized
INFO - 2021-01-12 06:54:10 --> Language Class Initialized
INFO - 2021-01-12 06:54:10 --> Language Class Initialized
INFO - 2021-01-12 06:54:10 --> Config Class Initialized
INFO - 2021-01-12 06:54:10 --> Loader Class Initialized
INFO - 2021-01-12 06:54:10 --> Helper loaded: url_helper
INFO - 2021-01-12 06:54:10 --> Helper loaded: file_helper
INFO - 2021-01-12 06:54:10 --> Helper loaded: form_helper
INFO - 2021-01-12 06:54:10 --> Helper loaded: my_helper
INFO - 2021-01-12 06:54:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:54:10 --> Controller Class Initialized
INFO - 2021-01-12 06:54:11 --> Final output sent to browser
DEBUG - 2021-01-12 06:54:11 --> Total execution time: 0.3673
INFO - 2021-01-12 06:54:12 --> Config Class Initialized
INFO - 2021-01-12 06:54:12 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:54:12 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:54:12 --> Utf8 Class Initialized
INFO - 2021-01-12 06:54:12 --> URI Class Initialized
INFO - 2021-01-12 06:54:12 --> Router Class Initialized
INFO - 2021-01-12 06:54:12 --> Output Class Initialized
INFO - 2021-01-12 06:54:12 --> Security Class Initialized
DEBUG - 2021-01-12 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:54:12 --> Input Class Initialized
INFO - 2021-01-12 06:54:12 --> Language Class Initialized
INFO - 2021-01-12 06:54:12 --> Language Class Initialized
INFO - 2021-01-12 06:54:12 --> Config Class Initialized
INFO - 2021-01-12 06:54:12 --> Loader Class Initialized
INFO - 2021-01-12 06:54:12 --> Helper loaded: url_helper
INFO - 2021-01-12 06:54:12 --> Helper loaded: file_helper
INFO - 2021-01-12 06:54:12 --> Helper loaded: form_helper
INFO - 2021-01-12 06:54:12 --> Helper loaded: my_helper
INFO - 2021-01-12 06:54:12 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:54:12 --> Controller Class Initialized
DEBUG - 2021-01-12 06:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 06:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:54:12 --> Final output sent to browser
DEBUG - 2021-01-12 06:54:12 --> Total execution time: 0.3703
INFO - 2021-01-12 06:54:14 --> Config Class Initialized
INFO - 2021-01-12 06:54:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:54:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:54:14 --> Utf8 Class Initialized
INFO - 2021-01-12 06:54:14 --> URI Class Initialized
INFO - 2021-01-12 06:54:14 --> Router Class Initialized
INFO - 2021-01-12 06:54:14 --> Output Class Initialized
INFO - 2021-01-12 06:54:14 --> Security Class Initialized
DEBUG - 2021-01-12 06:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:54:14 --> Input Class Initialized
INFO - 2021-01-12 06:54:14 --> Language Class Initialized
INFO - 2021-01-12 06:54:14 --> Language Class Initialized
INFO - 2021-01-12 06:54:14 --> Config Class Initialized
INFO - 2021-01-12 06:54:14 --> Loader Class Initialized
INFO - 2021-01-12 06:54:14 --> Helper loaded: url_helper
INFO - 2021-01-12 06:54:14 --> Helper loaded: file_helper
INFO - 2021-01-12 06:54:14 --> Helper loaded: form_helper
INFO - 2021-01-12 06:54:14 --> Helper loaded: my_helper
INFO - 2021-01-12 06:54:14 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:54:15 --> Controller Class Initialized
DEBUG - 2021-01-12 06:54:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-12 06:54:15 --> Final output sent to browser
DEBUG - 2021-01-12 06:54:15 --> Total execution time: 0.4505
INFO - 2021-01-12 06:54:35 --> Config Class Initialized
INFO - 2021-01-12 06:54:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:54:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:54:35 --> Utf8 Class Initialized
INFO - 2021-01-12 06:54:35 --> URI Class Initialized
INFO - 2021-01-12 06:54:35 --> Router Class Initialized
INFO - 2021-01-12 06:54:35 --> Output Class Initialized
INFO - 2021-01-12 06:54:35 --> Security Class Initialized
DEBUG - 2021-01-12 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:54:36 --> Input Class Initialized
INFO - 2021-01-12 06:54:36 --> Language Class Initialized
INFO - 2021-01-12 06:54:36 --> Language Class Initialized
INFO - 2021-01-12 06:54:36 --> Config Class Initialized
INFO - 2021-01-12 06:54:36 --> Loader Class Initialized
INFO - 2021-01-12 06:54:36 --> Helper loaded: url_helper
INFO - 2021-01-12 06:54:36 --> Helper loaded: file_helper
INFO - 2021-01-12 06:54:36 --> Helper loaded: form_helper
INFO - 2021-01-12 06:54:36 --> Helper loaded: my_helper
INFO - 2021-01-12 06:54:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:54:36 --> Controller Class Initialized
DEBUG - 2021-01-12 06:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-12 06:54:36 --> Final output sent to browser
DEBUG - 2021-01-12 06:54:36 --> Total execution time: 0.3364
INFO - 2021-01-12 06:55:07 --> Config Class Initialized
INFO - 2021-01-12 06:55:07 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:55:07 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:55:07 --> Utf8 Class Initialized
INFO - 2021-01-12 06:55:07 --> URI Class Initialized
INFO - 2021-01-12 06:55:07 --> Router Class Initialized
INFO - 2021-01-12 06:55:07 --> Output Class Initialized
INFO - 2021-01-12 06:55:07 --> Security Class Initialized
DEBUG - 2021-01-12 06:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:55:07 --> Input Class Initialized
INFO - 2021-01-12 06:55:07 --> Language Class Initialized
INFO - 2021-01-12 06:55:07 --> Language Class Initialized
INFO - 2021-01-12 06:55:07 --> Config Class Initialized
INFO - 2021-01-12 06:55:07 --> Loader Class Initialized
INFO - 2021-01-12 06:55:07 --> Helper loaded: url_helper
INFO - 2021-01-12 06:55:07 --> Helper loaded: file_helper
INFO - 2021-01-12 06:55:07 --> Helper loaded: form_helper
INFO - 2021-01-12 06:55:07 --> Helper loaded: my_helper
INFO - 2021-01-12 06:55:07 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:55:07 --> Controller Class Initialized
DEBUG - 2021-01-12 06:55:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-12 06:55:07 --> Final output sent to browser
DEBUG - 2021-01-12 06:55:07 --> Total execution time: 0.3978
INFO - 2021-01-12 06:55:20 --> Config Class Initialized
INFO - 2021-01-12 06:55:20 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:55:20 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:55:20 --> Utf8 Class Initialized
INFO - 2021-01-12 06:55:20 --> URI Class Initialized
INFO - 2021-01-12 06:55:20 --> Router Class Initialized
INFO - 2021-01-12 06:55:20 --> Output Class Initialized
INFO - 2021-01-12 06:55:20 --> Security Class Initialized
DEBUG - 2021-01-12 06:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:55:20 --> Input Class Initialized
INFO - 2021-01-12 06:55:20 --> Language Class Initialized
INFO - 2021-01-12 06:55:20 --> Language Class Initialized
INFO - 2021-01-12 06:55:20 --> Config Class Initialized
INFO - 2021-01-12 06:55:20 --> Loader Class Initialized
INFO - 2021-01-12 06:55:20 --> Helper loaded: url_helper
INFO - 2021-01-12 06:55:20 --> Helper loaded: file_helper
INFO - 2021-01-12 06:55:20 --> Helper loaded: form_helper
INFO - 2021-01-12 06:55:20 --> Helper loaded: my_helper
INFO - 2021-01-12 06:55:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:55:20 --> Controller Class Initialized
DEBUG - 2021-01-12 06:55:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-12 06:55:21 --> Final output sent to browser
DEBUG - 2021-01-12 06:55:21 --> Total execution time: 0.4064
INFO - 2021-01-12 06:55:47 --> Config Class Initialized
INFO - 2021-01-12 06:55:47 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:55:47 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:55:47 --> Utf8 Class Initialized
INFO - 2021-01-12 06:55:47 --> URI Class Initialized
INFO - 2021-01-12 06:55:47 --> Router Class Initialized
INFO - 2021-01-12 06:55:47 --> Output Class Initialized
INFO - 2021-01-12 06:55:48 --> Security Class Initialized
DEBUG - 2021-01-12 06:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:55:48 --> Input Class Initialized
INFO - 2021-01-12 06:55:48 --> Language Class Initialized
INFO - 2021-01-12 06:55:48 --> Language Class Initialized
INFO - 2021-01-12 06:55:48 --> Config Class Initialized
INFO - 2021-01-12 06:55:48 --> Loader Class Initialized
INFO - 2021-01-12 06:55:48 --> Helper loaded: url_helper
INFO - 2021-01-12 06:55:48 --> Helper loaded: file_helper
INFO - 2021-01-12 06:55:48 --> Helper loaded: form_helper
INFO - 2021-01-12 06:55:48 --> Helper loaded: my_helper
INFO - 2021-01-12 06:55:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:55:48 --> Controller Class Initialized
INFO - 2021-01-12 06:55:48 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:55:48 --> Config Class Initialized
INFO - 2021-01-12 06:55:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:55:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:55:48 --> Utf8 Class Initialized
INFO - 2021-01-12 06:55:48 --> URI Class Initialized
INFO - 2021-01-12 06:55:48 --> Router Class Initialized
INFO - 2021-01-12 06:55:48 --> Output Class Initialized
INFO - 2021-01-12 06:55:48 --> Security Class Initialized
DEBUG - 2021-01-12 06:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:55:48 --> Input Class Initialized
INFO - 2021-01-12 06:55:48 --> Language Class Initialized
INFO - 2021-01-12 06:55:48 --> Language Class Initialized
INFO - 2021-01-12 06:55:48 --> Config Class Initialized
INFO - 2021-01-12 06:55:48 --> Loader Class Initialized
INFO - 2021-01-12 06:55:48 --> Helper loaded: url_helper
INFO - 2021-01-12 06:55:48 --> Helper loaded: file_helper
INFO - 2021-01-12 06:55:48 --> Helper loaded: form_helper
INFO - 2021-01-12 06:55:48 --> Helper loaded: my_helper
INFO - 2021-01-12 06:55:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:55:48 --> Controller Class Initialized
DEBUG - 2021-01-12 06:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 06:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:55:48 --> Final output sent to browser
DEBUG - 2021-01-12 06:55:48 --> Total execution time: 0.3727
INFO - 2021-01-12 06:56:06 --> Config Class Initialized
INFO - 2021-01-12 06:56:06 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:56:06 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:56:06 --> Utf8 Class Initialized
INFO - 2021-01-12 06:56:06 --> URI Class Initialized
INFO - 2021-01-12 06:56:06 --> Router Class Initialized
INFO - 2021-01-12 06:56:06 --> Output Class Initialized
INFO - 2021-01-12 06:56:06 --> Security Class Initialized
DEBUG - 2021-01-12 06:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:56:06 --> Input Class Initialized
INFO - 2021-01-12 06:56:06 --> Language Class Initialized
INFO - 2021-01-12 06:56:06 --> Language Class Initialized
INFO - 2021-01-12 06:56:06 --> Config Class Initialized
INFO - 2021-01-12 06:56:06 --> Loader Class Initialized
INFO - 2021-01-12 06:56:06 --> Helper loaded: url_helper
INFO - 2021-01-12 06:56:06 --> Helper loaded: file_helper
INFO - 2021-01-12 06:56:06 --> Helper loaded: form_helper
INFO - 2021-01-12 06:56:06 --> Helper loaded: my_helper
INFO - 2021-01-12 06:56:06 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:56:06 --> Controller Class Initialized
INFO - 2021-01-12 06:56:06 --> Helper loaded: cookie_helper
INFO - 2021-01-12 06:56:06 --> Final output sent to browser
DEBUG - 2021-01-12 06:56:06 --> Total execution time: 0.4345
INFO - 2021-01-12 06:56:08 --> Config Class Initialized
INFO - 2021-01-12 06:56:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:56:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:56:08 --> Utf8 Class Initialized
INFO - 2021-01-12 06:56:08 --> URI Class Initialized
INFO - 2021-01-12 06:56:08 --> Router Class Initialized
INFO - 2021-01-12 06:56:08 --> Output Class Initialized
INFO - 2021-01-12 06:56:08 --> Security Class Initialized
DEBUG - 2021-01-12 06:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:56:08 --> Input Class Initialized
INFO - 2021-01-12 06:56:08 --> Language Class Initialized
INFO - 2021-01-12 06:56:08 --> Language Class Initialized
INFO - 2021-01-12 06:56:08 --> Config Class Initialized
INFO - 2021-01-12 06:56:08 --> Loader Class Initialized
INFO - 2021-01-12 06:56:08 --> Helper loaded: url_helper
INFO - 2021-01-12 06:56:08 --> Helper loaded: file_helper
INFO - 2021-01-12 06:56:08 --> Helper loaded: form_helper
INFO - 2021-01-12 06:56:08 --> Helper loaded: my_helper
INFO - 2021-01-12 06:56:08 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:56:09 --> Controller Class Initialized
DEBUG - 2021-01-12 06:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 06:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:56:09 --> Final output sent to browser
DEBUG - 2021-01-12 06:56:09 --> Total execution time: 0.5077
INFO - 2021-01-12 06:56:21 --> Config Class Initialized
INFO - 2021-01-12 06:56:21 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:56:21 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:56:21 --> Utf8 Class Initialized
INFO - 2021-01-12 06:56:21 --> URI Class Initialized
INFO - 2021-01-12 06:56:21 --> Router Class Initialized
INFO - 2021-01-12 06:56:21 --> Output Class Initialized
INFO - 2021-01-12 06:56:21 --> Security Class Initialized
DEBUG - 2021-01-12 06:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:56:21 --> Input Class Initialized
INFO - 2021-01-12 06:56:21 --> Language Class Initialized
INFO - 2021-01-12 06:56:21 --> Language Class Initialized
INFO - 2021-01-12 06:56:21 --> Config Class Initialized
INFO - 2021-01-12 06:56:21 --> Loader Class Initialized
INFO - 2021-01-12 06:56:21 --> Helper loaded: url_helper
INFO - 2021-01-12 06:56:21 --> Helper loaded: file_helper
INFO - 2021-01-12 06:56:21 --> Helper loaded: form_helper
INFO - 2021-01-12 06:56:21 --> Helper loaded: my_helper
INFO - 2021-01-12 06:56:21 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:56:22 --> Controller Class Initialized
DEBUG - 2021-01-12 06:56:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 06:56:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:56:22 --> Final output sent to browser
DEBUG - 2021-01-12 06:56:22 --> Total execution time: 0.3424
INFO - 2021-01-12 06:56:28 --> Config Class Initialized
INFO - 2021-01-12 06:56:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:56:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:56:28 --> Utf8 Class Initialized
INFO - 2021-01-12 06:56:28 --> URI Class Initialized
INFO - 2021-01-12 06:56:28 --> Router Class Initialized
INFO - 2021-01-12 06:56:28 --> Output Class Initialized
INFO - 2021-01-12 06:56:28 --> Security Class Initialized
DEBUG - 2021-01-12 06:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:56:28 --> Input Class Initialized
INFO - 2021-01-12 06:56:28 --> Language Class Initialized
INFO - 2021-01-12 06:56:28 --> Language Class Initialized
INFO - 2021-01-12 06:56:28 --> Config Class Initialized
INFO - 2021-01-12 06:56:28 --> Loader Class Initialized
INFO - 2021-01-12 06:56:28 --> Helper loaded: url_helper
INFO - 2021-01-12 06:56:28 --> Helper loaded: file_helper
INFO - 2021-01-12 06:56:28 --> Helper loaded: form_helper
INFO - 2021-01-12 06:56:28 --> Helper loaded: my_helper
INFO - 2021-01-12 06:56:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:56:28 --> Controller Class Initialized
INFO - 2021-01-12 06:56:28 --> Final output sent to browser
DEBUG - 2021-01-12 06:56:28 --> Total execution time: 0.4227
INFO - 2021-01-12 06:56:29 --> Config Class Initialized
INFO - 2021-01-12 06:56:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:56:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:56:29 --> Utf8 Class Initialized
INFO - 2021-01-12 06:56:29 --> URI Class Initialized
INFO - 2021-01-12 06:56:29 --> Router Class Initialized
INFO - 2021-01-12 06:56:29 --> Output Class Initialized
INFO - 2021-01-12 06:56:29 --> Security Class Initialized
DEBUG - 2021-01-12 06:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:56:29 --> Input Class Initialized
INFO - 2021-01-12 06:56:29 --> Language Class Initialized
INFO - 2021-01-12 06:56:29 --> Language Class Initialized
INFO - 2021-01-12 06:56:30 --> Config Class Initialized
INFO - 2021-01-12 06:56:30 --> Loader Class Initialized
INFO - 2021-01-12 06:56:30 --> Helper loaded: url_helper
INFO - 2021-01-12 06:56:30 --> Helper loaded: file_helper
INFO - 2021-01-12 06:56:30 --> Helper loaded: form_helper
INFO - 2021-01-12 06:56:30 --> Helper loaded: my_helper
INFO - 2021-01-12 06:56:30 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:56:30 --> Controller Class Initialized
DEBUG - 2021-01-12 06:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 06:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:56:30 --> Final output sent to browser
DEBUG - 2021-01-12 06:56:30 --> Total execution time: 0.4475
INFO - 2021-01-12 06:56:32 --> Config Class Initialized
INFO - 2021-01-12 06:56:33 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:56:33 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:56:33 --> Utf8 Class Initialized
INFO - 2021-01-12 06:56:33 --> URI Class Initialized
DEBUG - 2021-01-12 06:56:33 --> No URI present. Default controller set.
INFO - 2021-01-12 06:56:33 --> Router Class Initialized
INFO - 2021-01-12 06:56:33 --> Output Class Initialized
INFO - 2021-01-12 06:56:33 --> Security Class Initialized
DEBUG - 2021-01-12 06:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:56:33 --> Input Class Initialized
INFO - 2021-01-12 06:56:33 --> Language Class Initialized
INFO - 2021-01-12 06:56:33 --> Language Class Initialized
INFO - 2021-01-12 06:56:33 --> Config Class Initialized
INFO - 2021-01-12 06:56:33 --> Loader Class Initialized
INFO - 2021-01-12 06:56:33 --> Helper loaded: url_helper
INFO - 2021-01-12 06:56:33 --> Helper loaded: file_helper
INFO - 2021-01-12 06:56:33 --> Helper loaded: form_helper
INFO - 2021-01-12 06:56:33 --> Helper loaded: my_helper
INFO - 2021-01-12 06:56:33 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:56:33 --> Controller Class Initialized
DEBUG - 2021-01-12 06:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 06:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:56:33 --> Final output sent to browser
DEBUG - 2021-01-12 06:56:33 --> Total execution time: 0.3825
INFO - 2021-01-12 06:56:34 --> Config Class Initialized
INFO - 2021-01-12 06:56:34 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:56:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:56:35 --> Utf8 Class Initialized
INFO - 2021-01-12 06:56:35 --> URI Class Initialized
INFO - 2021-01-12 06:56:35 --> Router Class Initialized
INFO - 2021-01-12 06:56:35 --> Output Class Initialized
INFO - 2021-01-12 06:56:35 --> Security Class Initialized
DEBUG - 2021-01-12 06:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:56:35 --> Input Class Initialized
INFO - 2021-01-12 06:56:35 --> Language Class Initialized
INFO - 2021-01-12 06:56:35 --> Language Class Initialized
INFO - 2021-01-12 06:56:35 --> Config Class Initialized
INFO - 2021-01-12 06:56:35 --> Loader Class Initialized
INFO - 2021-01-12 06:56:35 --> Helper loaded: url_helper
INFO - 2021-01-12 06:56:35 --> Helper loaded: file_helper
INFO - 2021-01-12 06:56:35 --> Helper loaded: form_helper
INFO - 2021-01-12 06:56:35 --> Helper loaded: my_helper
INFO - 2021-01-12 06:56:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:56:35 --> Controller Class Initialized
DEBUG - 2021-01-12 06:56:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 06:56:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 06:56:35 --> Final output sent to browser
DEBUG - 2021-01-12 06:56:35 --> Total execution time: 0.3427
INFO - 2021-01-12 06:56:37 --> Config Class Initialized
INFO - 2021-01-12 06:56:37 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:56:37 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:56:37 --> Utf8 Class Initialized
INFO - 2021-01-12 06:56:37 --> URI Class Initialized
INFO - 2021-01-12 06:56:37 --> Router Class Initialized
INFO - 2021-01-12 06:56:37 --> Output Class Initialized
INFO - 2021-01-12 06:56:37 --> Security Class Initialized
DEBUG - 2021-01-12 06:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:56:37 --> Input Class Initialized
INFO - 2021-01-12 06:56:37 --> Language Class Initialized
INFO - 2021-01-12 06:56:37 --> Language Class Initialized
INFO - 2021-01-12 06:56:37 --> Config Class Initialized
INFO - 2021-01-12 06:56:37 --> Loader Class Initialized
INFO - 2021-01-12 06:56:37 --> Helper loaded: url_helper
INFO - 2021-01-12 06:56:37 --> Helper loaded: file_helper
INFO - 2021-01-12 06:56:37 --> Helper loaded: form_helper
INFO - 2021-01-12 06:56:38 --> Helper loaded: my_helper
INFO - 2021-01-12 06:56:38 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:56:38 --> Controller Class Initialized
DEBUG - 2021-01-12 06:56:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 06:56:38 --> Final output sent to browser
DEBUG - 2021-01-12 06:56:38 --> Total execution time: 0.3668
INFO - 2021-01-12 06:57:26 --> Config Class Initialized
INFO - 2021-01-12 06:57:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:57:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:57:26 --> Utf8 Class Initialized
INFO - 2021-01-12 06:57:26 --> URI Class Initialized
INFO - 2021-01-12 06:57:26 --> Router Class Initialized
INFO - 2021-01-12 06:57:26 --> Output Class Initialized
INFO - 2021-01-12 06:57:26 --> Security Class Initialized
DEBUG - 2021-01-12 06:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:57:26 --> Input Class Initialized
INFO - 2021-01-12 06:57:26 --> Language Class Initialized
INFO - 2021-01-12 06:57:26 --> Language Class Initialized
INFO - 2021-01-12 06:57:26 --> Config Class Initialized
INFO - 2021-01-12 06:57:27 --> Loader Class Initialized
INFO - 2021-01-12 06:57:27 --> Helper loaded: url_helper
INFO - 2021-01-12 06:57:27 --> Helper loaded: file_helper
INFO - 2021-01-12 06:57:27 --> Helper loaded: form_helper
INFO - 2021-01-12 06:57:27 --> Helper loaded: my_helper
INFO - 2021-01-12 06:57:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:57:27 --> Controller Class Initialized
DEBUG - 2021-01-12 06:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 06:57:27 --> Final output sent to browser
DEBUG - 2021-01-12 06:57:27 --> Total execution time: 0.3984
INFO - 2021-01-12 06:59:10 --> Config Class Initialized
INFO - 2021-01-12 06:59:10 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:59:10 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:59:10 --> Utf8 Class Initialized
INFO - 2021-01-12 06:59:10 --> URI Class Initialized
INFO - 2021-01-12 06:59:10 --> Router Class Initialized
INFO - 2021-01-12 06:59:10 --> Output Class Initialized
INFO - 2021-01-12 06:59:10 --> Security Class Initialized
DEBUG - 2021-01-12 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:59:10 --> Input Class Initialized
INFO - 2021-01-12 06:59:10 --> Language Class Initialized
INFO - 2021-01-12 06:59:10 --> Language Class Initialized
INFO - 2021-01-12 06:59:10 --> Config Class Initialized
INFO - 2021-01-12 06:59:10 --> Loader Class Initialized
INFO - 2021-01-12 06:59:10 --> Helper loaded: url_helper
INFO - 2021-01-12 06:59:10 --> Helper loaded: file_helper
INFO - 2021-01-12 06:59:10 --> Helper loaded: form_helper
INFO - 2021-01-12 06:59:10 --> Helper loaded: my_helper
INFO - 2021-01-12 06:59:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:59:10 --> Controller Class Initialized
DEBUG - 2021-01-12 06:59:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 06:59:10 --> Final output sent to browser
DEBUG - 2021-01-12 06:59:10 --> Total execution time: 0.3993
INFO - 2021-01-12 06:59:52 --> Config Class Initialized
INFO - 2021-01-12 06:59:52 --> Hooks Class Initialized
DEBUG - 2021-01-12 06:59:53 --> UTF-8 Support Enabled
INFO - 2021-01-12 06:59:53 --> Utf8 Class Initialized
INFO - 2021-01-12 06:59:53 --> URI Class Initialized
INFO - 2021-01-12 06:59:53 --> Router Class Initialized
INFO - 2021-01-12 06:59:53 --> Output Class Initialized
INFO - 2021-01-12 06:59:53 --> Security Class Initialized
DEBUG - 2021-01-12 06:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 06:59:53 --> Input Class Initialized
INFO - 2021-01-12 06:59:53 --> Language Class Initialized
INFO - 2021-01-12 06:59:53 --> Language Class Initialized
INFO - 2021-01-12 06:59:53 --> Config Class Initialized
INFO - 2021-01-12 06:59:53 --> Loader Class Initialized
INFO - 2021-01-12 06:59:53 --> Helper loaded: url_helper
INFO - 2021-01-12 06:59:53 --> Helper loaded: file_helper
INFO - 2021-01-12 06:59:53 --> Helper loaded: form_helper
INFO - 2021-01-12 06:59:53 --> Helper loaded: my_helper
INFO - 2021-01-12 06:59:53 --> Database Driver Class Initialized
DEBUG - 2021-01-12 06:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 06:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 06:59:53 --> Controller Class Initialized
DEBUG - 2021-01-12 06:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 06:59:53 --> Final output sent to browser
DEBUG - 2021-01-12 06:59:53 --> Total execution time: 0.4078
INFO - 2021-01-12 07:00:19 --> Config Class Initialized
INFO - 2021-01-12 07:00:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:00:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:00:19 --> Utf8 Class Initialized
INFO - 2021-01-12 07:00:19 --> URI Class Initialized
INFO - 2021-01-12 07:00:19 --> Router Class Initialized
INFO - 2021-01-12 07:00:19 --> Output Class Initialized
INFO - 2021-01-12 07:00:19 --> Security Class Initialized
DEBUG - 2021-01-12 07:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:00:19 --> Input Class Initialized
INFO - 2021-01-12 07:00:19 --> Language Class Initialized
INFO - 2021-01-12 07:00:19 --> Language Class Initialized
INFO - 2021-01-12 07:00:19 --> Config Class Initialized
INFO - 2021-01-12 07:00:19 --> Loader Class Initialized
INFO - 2021-01-12 07:00:19 --> Helper loaded: url_helper
INFO - 2021-01-12 07:00:19 --> Helper loaded: file_helper
INFO - 2021-01-12 07:00:19 --> Helper loaded: form_helper
INFO - 2021-01-12 07:00:19 --> Helper loaded: my_helper
INFO - 2021-01-12 07:00:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:00:19 --> Controller Class Initialized
DEBUG - 2021-01-12 07:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 07:00:19 --> Final output sent to browser
DEBUG - 2021-01-12 07:00:19 --> Total execution time: 0.4005
INFO - 2021-01-12 07:00:35 --> Config Class Initialized
INFO - 2021-01-12 07:00:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:00:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:00:35 --> Utf8 Class Initialized
INFO - 2021-01-12 07:00:35 --> URI Class Initialized
INFO - 2021-01-12 07:00:35 --> Router Class Initialized
INFO - 2021-01-12 07:00:35 --> Output Class Initialized
INFO - 2021-01-12 07:00:35 --> Security Class Initialized
DEBUG - 2021-01-12 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:00:35 --> Input Class Initialized
INFO - 2021-01-12 07:00:35 --> Language Class Initialized
INFO - 2021-01-12 07:00:35 --> Language Class Initialized
INFO - 2021-01-12 07:00:35 --> Config Class Initialized
INFO - 2021-01-12 07:00:35 --> Loader Class Initialized
INFO - 2021-01-12 07:00:35 --> Helper loaded: url_helper
INFO - 2021-01-12 07:00:35 --> Helper loaded: file_helper
INFO - 2021-01-12 07:00:35 --> Helper loaded: form_helper
INFO - 2021-01-12 07:00:35 --> Helper loaded: my_helper
INFO - 2021-01-12 07:00:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:00:35 --> Controller Class Initialized
DEBUG - 2021-01-12 07:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 07:00:35 --> Final output sent to browser
DEBUG - 2021-01-12 07:00:35 --> Total execution time: 0.4315
INFO - 2021-01-12 07:01:25 --> Config Class Initialized
INFO - 2021-01-12 07:01:25 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:01:25 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:01:25 --> Utf8 Class Initialized
INFO - 2021-01-12 07:01:25 --> URI Class Initialized
INFO - 2021-01-12 07:01:25 --> Router Class Initialized
INFO - 2021-01-12 07:01:25 --> Output Class Initialized
INFO - 2021-01-12 07:01:25 --> Security Class Initialized
DEBUG - 2021-01-12 07:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:01:25 --> Input Class Initialized
INFO - 2021-01-12 07:01:25 --> Language Class Initialized
INFO - 2021-01-12 07:01:25 --> Language Class Initialized
INFO - 2021-01-12 07:01:25 --> Config Class Initialized
INFO - 2021-01-12 07:01:25 --> Loader Class Initialized
INFO - 2021-01-12 07:01:25 --> Helper loaded: url_helper
INFO - 2021-01-12 07:01:25 --> Helper loaded: file_helper
INFO - 2021-01-12 07:01:25 --> Helper loaded: form_helper
INFO - 2021-01-12 07:01:25 --> Helper loaded: my_helper
INFO - 2021-01-12 07:01:25 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:01:25 --> Controller Class Initialized
DEBUG - 2021-01-12 07:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 07:01:25 --> Final output sent to browser
DEBUG - 2021-01-12 07:01:25 --> Total execution time: 0.4899
INFO - 2021-01-12 07:01:51 --> Config Class Initialized
INFO - 2021-01-12 07:01:51 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:01:51 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:01:51 --> Utf8 Class Initialized
INFO - 2021-01-12 07:01:51 --> URI Class Initialized
INFO - 2021-01-12 07:01:51 --> Router Class Initialized
INFO - 2021-01-12 07:01:51 --> Output Class Initialized
INFO - 2021-01-12 07:01:51 --> Security Class Initialized
DEBUG - 2021-01-12 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:01:52 --> Input Class Initialized
INFO - 2021-01-12 07:01:52 --> Language Class Initialized
INFO - 2021-01-12 07:01:52 --> Language Class Initialized
INFO - 2021-01-12 07:01:52 --> Config Class Initialized
INFO - 2021-01-12 07:01:52 --> Loader Class Initialized
INFO - 2021-01-12 07:01:52 --> Helper loaded: url_helper
INFO - 2021-01-12 07:01:52 --> Helper loaded: file_helper
INFO - 2021-01-12 07:01:52 --> Helper loaded: form_helper
INFO - 2021-01-12 07:01:52 --> Helper loaded: my_helper
INFO - 2021-01-12 07:01:52 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:01:52 --> Controller Class Initialized
DEBUG - 2021-01-12 07:01:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 07:01:52 --> Final output sent to browser
DEBUG - 2021-01-12 07:01:52 --> Total execution time: 0.4177
INFO - 2021-01-12 07:02:41 --> Config Class Initialized
INFO - 2021-01-12 07:02:41 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:02:41 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:02:41 --> Utf8 Class Initialized
INFO - 2021-01-12 07:02:41 --> URI Class Initialized
INFO - 2021-01-12 07:02:41 --> Router Class Initialized
INFO - 2021-01-12 07:02:42 --> Output Class Initialized
INFO - 2021-01-12 07:02:42 --> Security Class Initialized
DEBUG - 2021-01-12 07:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:02:42 --> Input Class Initialized
INFO - 2021-01-12 07:02:42 --> Language Class Initialized
INFO - 2021-01-12 07:02:42 --> Language Class Initialized
INFO - 2021-01-12 07:02:42 --> Config Class Initialized
INFO - 2021-01-12 07:02:42 --> Loader Class Initialized
INFO - 2021-01-12 07:02:42 --> Helper loaded: url_helper
INFO - 2021-01-12 07:02:42 --> Helper loaded: file_helper
INFO - 2021-01-12 07:02:42 --> Helper loaded: form_helper
INFO - 2021-01-12 07:02:42 --> Helper loaded: my_helper
INFO - 2021-01-12 07:02:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:02:42 --> Controller Class Initialized
DEBUG - 2021-01-12 07:02:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-12 07:02:42 --> Final output sent to browser
DEBUG - 2021-01-12 07:02:42 --> Total execution time: 0.4288
INFO - 2021-01-12 07:03:30 --> Config Class Initialized
INFO - 2021-01-12 07:03:30 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:03:30 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:03:30 --> Utf8 Class Initialized
INFO - 2021-01-12 07:03:30 --> URI Class Initialized
INFO - 2021-01-12 07:03:30 --> Router Class Initialized
INFO - 2021-01-12 07:03:30 --> Output Class Initialized
INFO - 2021-01-12 07:03:30 --> Security Class Initialized
DEBUG - 2021-01-12 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:03:30 --> Input Class Initialized
INFO - 2021-01-12 07:03:30 --> Language Class Initialized
INFO - 2021-01-12 07:03:30 --> Language Class Initialized
INFO - 2021-01-12 07:03:30 --> Config Class Initialized
INFO - 2021-01-12 07:03:30 --> Loader Class Initialized
INFO - 2021-01-12 07:03:30 --> Helper loaded: url_helper
INFO - 2021-01-12 07:03:30 --> Helper loaded: file_helper
INFO - 2021-01-12 07:03:30 --> Helper loaded: form_helper
INFO - 2021-01-12 07:03:30 --> Helper loaded: my_helper
INFO - 2021-01-12 07:03:30 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:03:30 --> Controller Class Initialized
INFO - 2021-01-12 07:03:30 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:03:30 --> Config Class Initialized
INFO - 2021-01-12 07:03:30 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:03:30 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:03:30 --> Utf8 Class Initialized
INFO - 2021-01-12 07:03:30 --> URI Class Initialized
INFO - 2021-01-12 07:03:30 --> Router Class Initialized
INFO - 2021-01-12 07:03:30 --> Output Class Initialized
INFO - 2021-01-12 07:03:30 --> Security Class Initialized
DEBUG - 2021-01-12 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:03:30 --> Input Class Initialized
INFO - 2021-01-12 07:03:30 --> Language Class Initialized
INFO - 2021-01-12 07:03:30 --> Language Class Initialized
INFO - 2021-01-12 07:03:30 --> Config Class Initialized
INFO - 2021-01-12 07:03:30 --> Loader Class Initialized
INFO - 2021-01-12 07:03:30 --> Helper loaded: url_helper
INFO - 2021-01-12 07:03:30 --> Helper loaded: file_helper
INFO - 2021-01-12 07:03:31 --> Helper loaded: form_helper
INFO - 2021-01-12 07:03:31 --> Helper loaded: my_helper
INFO - 2021-01-12 07:03:31 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:03:31 --> Controller Class Initialized
DEBUG - 2021-01-12 07:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:03:31 --> Final output sent to browser
DEBUG - 2021-01-12 07:03:31 --> Total execution time: 0.4266
INFO - 2021-01-12 07:03:38 --> Config Class Initialized
INFO - 2021-01-12 07:03:38 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:03:38 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:03:38 --> Utf8 Class Initialized
INFO - 2021-01-12 07:03:38 --> URI Class Initialized
INFO - 2021-01-12 07:03:38 --> Router Class Initialized
INFO - 2021-01-12 07:03:38 --> Output Class Initialized
INFO - 2021-01-12 07:03:38 --> Security Class Initialized
DEBUG - 2021-01-12 07:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:03:38 --> Input Class Initialized
INFO - 2021-01-12 07:03:38 --> Language Class Initialized
INFO - 2021-01-12 07:03:38 --> Language Class Initialized
INFO - 2021-01-12 07:03:38 --> Config Class Initialized
INFO - 2021-01-12 07:03:38 --> Loader Class Initialized
INFO - 2021-01-12 07:03:38 --> Helper loaded: url_helper
INFO - 2021-01-12 07:03:38 --> Helper loaded: file_helper
INFO - 2021-01-12 07:03:38 --> Helper loaded: form_helper
INFO - 2021-01-12 07:03:38 --> Helper loaded: my_helper
INFO - 2021-01-12 07:03:38 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:03:38 --> Controller Class Initialized
INFO - 2021-01-12 07:03:38 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:03:38 --> Final output sent to browser
DEBUG - 2021-01-12 07:03:38 --> Total execution time: 0.4483
INFO - 2021-01-12 07:03:39 --> Config Class Initialized
INFO - 2021-01-12 07:03:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:03:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:03:39 --> Utf8 Class Initialized
INFO - 2021-01-12 07:03:39 --> URI Class Initialized
INFO - 2021-01-12 07:03:39 --> Router Class Initialized
INFO - 2021-01-12 07:03:39 --> Output Class Initialized
INFO - 2021-01-12 07:03:39 --> Security Class Initialized
DEBUG - 2021-01-12 07:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:03:39 --> Input Class Initialized
INFO - 2021-01-12 07:03:39 --> Language Class Initialized
INFO - 2021-01-12 07:03:39 --> Language Class Initialized
INFO - 2021-01-12 07:03:39 --> Config Class Initialized
INFO - 2021-01-12 07:03:39 --> Loader Class Initialized
INFO - 2021-01-12 07:03:39 --> Helper loaded: url_helper
INFO - 2021-01-12 07:03:39 --> Helper loaded: file_helper
INFO - 2021-01-12 07:03:39 --> Helper loaded: form_helper
INFO - 2021-01-12 07:03:39 --> Helper loaded: my_helper
INFO - 2021-01-12 07:03:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:03:39 --> Controller Class Initialized
DEBUG - 2021-01-12 07:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 07:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:03:39 --> Final output sent to browser
DEBUG - 2021-01-12 07:03:39 --> Total execution time: 0.4929
INFO - 2021-01-12 07:03:41 --> Config Class Initialized
INFO - 2021-01-12 07:03:41 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:03:41 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:03:41 --> Utf8 Class Initialized
INFO - 2021-01-12 07:03:41 --> URI Class Initialized
INFO - 2021-01-12 07:03:41 --> Router Class Initialized
INFO - 2021-01-12 07:03:41 --> Output Class Initialized
INFO - 2021-01-12 07:03:41 --> Security Class Initialized
DEBUG - 2021-01-12 07:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:03:41 --> Input Class Initialized
INFO - 2021-01-12 07:03:41 --> Language Class Initialized
INFO - 2021-01-12 07:03:41 --> Language Class Initialized
INFO - 2021-01-12 07:03:41 --> Config Class Initialized
INFO - 2021-01-12 07:03:41 --> Loader Class Initialized
INFO - 2021-01-12 07:03:41 --> Helper loaded: url_helper
INFO - 2021-01-12 07:03:41 --> Helper loaded: file_helper
INFO - 2021-01-12 07:03:41 --> Helper loaded: form_helper
INFO - 2021-01-12 07:03:41 --> Helper loaded: my_helper
INFO - 2021-01-12 07:03:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:03:42 --> Controller Class Initialized
DEBUG - 2021-01-12 07:03:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-01-12 07:03:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:03:42 --> Final output sent to browser
DEBUG - 2021-01-12 07:03:42 --> Total execution time: 0.3713
INFO - 2021-01-12 07:03:42 --> Config Class Initialized
INFO - 2021-01-12 07:03:42 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:03:42 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:03:42 --> Utf8 Class Initialized
INFO - 2021-01-12 07:03:42 --> URI Class Initialized
INFO - 2021-01-12 07:03:42 --> Router Class Initialized
INFO - 2021-01-12 07:03:42 --> Output Class Initialized
INFO - 2021-01-12 07:03:42 --> Security Class Initialized
DEBUG - 2021-01-12 07:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:03:42 --> Input Class Initialized
INFO - 2021-01-12 07:03:42 --> Language Class Initialized
INFO - 2021-01-12 07:03:42 --> Language Class Initialized
INFO - 2021-01-12 07:03:42 --> Config Class Initialized
INFO - 2021-01-12 07:03:42 --> Loader Class Initialized
INFO - 2021-01-12 07:03:42 --> Helper loaded: url_helper
INFO - 2021-01-12 07:03:42 --> Helper loaded: file_helper
INFO - 2021-01-12 07:03:42 --> Helper loaded: form_helper
INFO - 2021-01-12 07:03:42 --> Helper loaded: my_helper
INFO - 2021-01-12 07:03:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:03:42 --> Controller Class Initialized
INFO - 2021-01-12 07:03:43 --> Config Class Initialized
INFO - 2021-01-12 07:03:43 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:03:43 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:03:43 --> Utf8 Class Initialized
INFO - 2021-01-12 07:03:43 --> URI Class Initialized
INFO - 2021-01-12 07:03:43 --> Router Class Initialized
INFO - 2021-01-12 07:03:43 --> Output Class Initialized
INFO - 2021-01-12 07:03:43 --> Security Class Initialized
DEBUG - 2021-01-12 07:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:03:43 --> Input Class Initialized
INFO - 2021-01-12 07:03:43 --> Language Class Initialized
INFO - 2021-01-12 07:03:43 --> Language Class Initialized
INFO - 2021-01-12 07:03:43 --> Config Class Initialized
INFO - 2021-01-12 07:03:43 --> Loader Class Initialized
INFO - 2021-01-12 07:03:43 --> Helper loaded: url_helper
INFO - 2021-01-12 07:03:43 --> Helper loaded: file_helper
INFO - 2021-01-12 07:03:43 --> Helper loaded: form_helper
INFO - 2021-01-12 07:03:43 --> Helper loaded: my_helper
INFO - 2021-01-12 07:03:43 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:03:43 --> Controller Class Initialized
DEBUG - 2021-01-12 07:03:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-12 07:03:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:03:43 --> Final output sent to browser
DEBUG - 2021-01-12 07:03:43 --> Total execution time: 0.3764
INFO - 2021-01-12 07:03:43 --> Config Class Initialized
INFO - 2021-01-12 07:03:43 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:03:43 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:03:43 --> Utf8 Class Initialized
INFO - 2021-01-12 07:03:43 --> URI Class Initialized
INFO - 2021-01-12 07:03:43 --> Router Class Initialized
INFO - 2021-01-12 07:03:43 --> Output Class Initialized
INFO - 2021-01-12 07:03:43 --> Security Class Initialized
DEBUG - 2021-01-12 07:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:03:43 --> Input Class Initialized
INFO - 2021-01-12 07:03:43 --> Language Class Initialized
INFO - 2021-01-12 07:03:43 --> Language Class Initialized
INFO - 2021-01-12 07:03:43 --> Config Class Initialized
INFO - 2021-01-12 07:03:43 --> Loader Class Initialized
INFO - 2021-01-12 07:03:43 --> Helper loaded: url_helper
INFO - 2021-01-12 07:03:43 --> Helper loaded: file_helper
INFO - 2021-01-12 07:03:44 --> Helper loaded: form_helper
INFO - 2021-01-12 07:03:44 --> Helper loaded: my_helper
INFO - 2021-01-12 07:03:44 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:03:44 --> Controller Class Initialized
INFO - 2021-01-12 07:04:18 --> Config Class Initialized
INFO - 2021-01-12 07:04:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:04:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:04:18 --> Utf8 Class Initialized
INFO - 2021-01-12 07:04:18 --> URI Class Initialized
INFO - 2021-01-12 07:04:18 --> Router Class Initialized
INFO - 2021-01-12 07:04:18 --> Output Class Initialized
INFO - 2021-01-12 07:04:18 --> Security Class Initialized
DEBUG - 2021-01-12 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:04:19 --> Input Class Initialized
INFO - 2021-01-12 07:04:19 --> Language Class Initialized
INFO - 2021-01-12 07:04:19 --> Language Class Initialized
INFO - 2021-01-12 07:04:19 --> Config Class Initialized
INFO - 2021-01-12 07:04:19 --> Loader Class Initialized
INFO - 2021-01-12 07:04:19 --> Helper loaded: url_helper
INFO - 2021-01-12 07:04:19 --> Helper loaded: file_helper
INFO - 2021-01-12 07:04:19 --> Helper loaded: form_helper
INFO - 2021-01-12 07:04:19 --> Helper loaded: my_helper
INFO - 2021-01-12 07:04:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:04:19 --> Controller Class Initialized
INFO - 2021-01-12 07:04:46 --> Config Class Initialized
INFO - 2021-01-12 07:04:46 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:04:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:04:46 --> Utf8 Class Initialized
INFO - 2021-01-12 07:04:46 --> URI Class Initialized
INFO - 2021-01-12 07:04:46 --> Router Class Initialized
INFO - 2021-01-12 07:04:46 --> Output Class Initialized
INFO - 2021-01-12 07:04:46 --> Security Class Initialized
DEBUG - 2021-01-12 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:04:46 --> Input Class Initialized
INFO - 2021-01-12 07:04:46 --> Language Class Initialized
INFO - 2021-01-12 07:04:46 --> Language Class Initialized
INFO - 2021-01-12 07:04:46 --> Config Class Initialized
INFO - 2021-01-12 07:04:46 --> Loader Class Initialized
INFO - 2021-01-12 07:04:46 --> Helper loaded: url_helper
INFO - 2021-01-12 07:04:46 --> Helper loaded: file_helper
INFO - 2021-01-12 07:04:46 --> Helper loaded: form_helper
INFO - 2021-01-12 07:04:46 --> Helper loaded: my_helper
INFO - 2021-01-12 07:04:46 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:04:46 --> Controller Class Initialized
INFO - 2021-01-12 07:04:46 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:04:46 --> Config Class Initialized
INFO - 2021-01-12 07:04:46 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:04:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:04:46 --> Utf8 Class Initialized
INFO - 2021-01-12 07:04:46 --> URI Class Initialized
INFO - 2021-01-12 07:04:46 --> Router Class Initialized
INFO - 2021-01-12 07:04:46 --> Output Class Initialized
INFO - 2021-01-12 07:04:46 --> Security Class Initialized
DEBUG - 2021-01-12 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:04:46 --> Input Class Initialized
INFO - 2021-01-12 07:04:46 --> Language Class Initialized
INFO - 2021-01-12 07:04:46 --> Language Class Initialized
INFO - 2021-01-12 07:04:46 --> Config Class Initialized
INFO - 2021-01-12 07:04:46 --> Loader Class Initialized
INFO - 2021-01-12 07:04:46 --> Helper loaded: url_helper
INFO - 2021-01-12 07:04:46 --> Helper loaded: file_helper
INFO - 2021-01-12 07:04:46 --> Helper loaded: form_helper
INFO - 2021-01-12 07:04:46 --> Helper loaded: my_helper
INFO - 2021-01-12 07:04:46 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:04:46 --> Controller Class Initialized
DEBUG - 2021-01-12 07:04:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:04:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:04:46 --> Final output sent to browser
DEBUG - 2021-01-12 07:04:46 --> Total execution time: 0.4340
INFO - 2021-01-12 07:05:18 --> Config Class Initialized
INFO - 2021-01-12 07:05:18 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:05:18 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:05:18 --> Utf8 Class Initialized
INFO - 2021-01-12 07:05:18 --> URI Class Initialized
INFO - 2021-01-12 07:05:18 --> Router Class Initialized
INFO - 2021-01-12 07:05:18 --> Output Class Initialized
INFO - 2021-01-12 07:05:18 --> Security Class Initialized
DEBUG - 2021-01-12 07:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:05:18 --> Input Class Initialized
INFO - 2021-01-12 07:05:18 --> Language Class Initialized
INFO - 2021-01-12 07:05:18 --> Language Class Initialized
INFO - 2021-01-12 07:05:18 --> Config Class Initialized
INFO - 2021-01-12 07:05:18 --> Loader Class Initialized
INFO - 2021-01-12 07:05:18 --> Helper loaded: url_helper
INFO - 2021-01-12 07:05:18 --> Helper loaded: file_helper
INFO - 2021-01-12 07:05:18 --> Helper loaded: form_helper
INFO - 2021-01-12 07:05:18 --> Helper loaded: my_helper
INFO - 2021-01-12 07:05:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:05:19 --> Controller Class Initialized
INFO - 2021-01-12 07:05:19 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:05:19 --> Final output sent to browser
DEBUG - 2021-01-12 07:05:19 --> Total execution time: 0.4975
INFO - 2021-01-12 07:05:19 --> Config Class Initialized
INFO - 2021-01-12 07:05:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:05:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:05:19 --> Utf8 Class Initialized
INFO - 2021-01-12 07:05:19 --> URI Class Initialized
INFO - 2021-01-12 07:05:19 --> Router Class Initialized
INFO - 2021-01-12 07:05:19 --> Output Class Initialized
INFO - 2021-01-12 07:05:19 --> Security Class Initialized
DEBUG - 2021-01-12 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:05:19 --> Input Class Initialized
INFO - 2021-01-12 07:05:19 --> Language Class Initialized
INFO - 2021-01-12 07:05:19 --> Language Class Initialized
INFO - 2021-01-12 07:05:19 --> Config Class Initialized
INFO - 2021-01-12 07:05:19 --> Loader Class Initialized
INFO - 2021-01-12 07:05:19 --> Helper loaded: url_helper
INFO - 2021-01-12 07:05:19 --> Helper loaded: file_helper
INFO - 2021-01-12 07:05:19 --> Helper loaded: form_helper
INFO - 2021-01-12 07:05:19 --> Helper loaded: my_helper
INFO - 2021-01-12 07:05:19 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:05:20 --> Controller Class Initialized
DEBUG - 2021-01-12 07:05:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 07:05:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:05:20 --> Final output sent to browser
DEBUG - 2021-01-12 07:05:20 --> Total execution time: 0.5317
INFO - 2021-01-12 07:05:23 --> Config Class Initialized
INFO - 2021-01-12 07:05:23 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:05:23 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:05:23 --> Utf8 Class Initialized
INFO - 2021-01-12 07:05:23 --> URI Class Initialized
INFO - 2021-01-12 07:05:23 --> Router Class Initialized
INFO - 2021-01-12 07:05:23 --> Output Class Initialized
INFO - 2021-01-12 07:05:23 --> Security Class Initialized
DEBUG - 2021-01-12 07:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:05:23 --> Input Class Initialized
INFO - 2021-01-12 07:05:23 --> Language Class Initialized
INFO - 2021-01-12 07:05:23 --> Language Class Initialized
INFO - 2021-01-12 07:05:23 --> Config Class Initialized
INFO - 2021-01-12 07:05:23 --> Loader Class Initialized
INFO - 2021-01-12 07:05:23 --> Helper loaded: url_helper
INFO - 2021-01-12 07:05:23 --> Helper loaded: file_helper
INFO - 2021-01-12 07:05:23 --> Helper loaded: form_helper
INFO - 2021-01-12 07:05:23 --> Helper loaded: my_helper
INFO - 2021-01-12 07:05:23 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:05:23 --> Controller Class Initialized
DEBUG - 2021-01-12 07:05:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 07:05:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:05:23 --> Final output sent to browser
DEBUG - 2021-01-12 07:05:23 --> Total execution time: 0.4321
INFO - 2021-01-12 07:05:30 --> Config Class Initialized
INFO - 2021-01-12 07:05:30 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:05:30 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:05:30 --> Utf8 Class Initialized
INFO - 2021-01-12 07:05:30 --> URI Class Initialized
INFO - 2021-01-12 07:05:30 --> Router Class Initialized
INFO - 2021-01-12 07:05:30 --> Output Class Initialized
INFO - 2021-01-12 07:05:30 --> Security Class Initialized
DEBUG - 2021-01-12 07:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:05:30 --> Input Class Initialized
INFO - 2021-01-12 07:05:30 --> Language Class Initialized
INFO - 2021-01-12 07:05:30 --> Language Class Initialized
INFO - 2021-01-12 07:05:30 --> Config Class Initialized
INFO - 2021-01-12 07:05:30 --> Loader Class Initialized
INFO - 2021-01-12 07:05:30 --> Helper loaded: url_helper
INFO - 2021-01-12 07:05:30 --> Helper loaded: file_helper
INFO - 2021-01-12 07:05:30 --> Helper loaded: form_helper
INFO - 2021-01-12 07:05:30 --> Helper loaded: my_helper
INFO - 2021-01-12 07:05:30 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:05:30 --> Controller Class Initialized
INFO - 2021-01-12 07:05:30 --> Final output sent to browser
DEBUG - 2021-01-12 07:05:30 --> Total execution time: 0.3969
INFO - 2021-01-12 07:05:31 --> Config Class Initialized
INFO - 2021-01-12 07:05:31 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:05:31 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:05:31 --> Utf8 Class Initialized
INFO - 2021-01-12 07:05:31 --> URI Class Initialized
INFO - 2021-01-12 07:05:31 --> Router Class Initialized
INFO - 2021-01-12 07:05:31 --> Output Class Initialized
INFO - 2021-01-12 07:05:31 --> Security Class Initialized
DEBUG - 2021-01-12 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:05:31 --> Input Class Initialized
INFO - 2021-01-12 07:05:31 --> Language Class Initialized
INFO - 2021-01-12 07:05:31 --> Language Class Initialized
INFO - 2021-01-12 07:05:31 --> Config Class Initialized
INFO - 2021-01-12 07:05:31 --> Loader Class Initialized
INFO - 2021-01-12 07:05:31 --> Helper loaded: url_helper
INFO - 2021-01-12 07:05:32 --> Helper loaded: file_helper
INFO - 2021-01-12 07:05:32 --> Helper loaded: form_helper
INFO - 2021-01-12 07:05:32 --> Helper loaded: my_helper
INFO - 2021-01-12 07:05:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:05:32 --> Controller Class Initialized
DEBUG - 2021-01-12 07:05:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:05:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:05:32 --> Final output sent to browser
DEBUG - 2021-01-12 07:05:32 --> Total execution time: 0.3573
INFO - 2021-01-12 07:05:39 --> Config Class Initialized
INFO - 2021-01-12 07:05:39 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:05:39 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:05:39 --> Utf8 Class Initialized
INFO - 2021-01-12 07:05:39 --> URI Class Initialized
INFO - 2021-01-12 07:05:39 --> Router Class Initialized
INFO - 2021-01-12 07:05:39 --> Output Class Initialized
INFO - 2021-01-12 07:05:39 --> Security Class Initialized
DEBUG - 2021-01-12 07:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:05:39 --> Input Class Initialized
INFO - 2021-01-12 07:05:39 --> Language Class Initialized
INFO - 2021-01-12 07:05:39 --> Language Class Initialized
INFO - 2021-01-12 07:05:39 --> Config Class Initialized
INFO - 2021-01-12 07:05:39 --> Loader Class Initialized
INFO - 2021-01-12 07:05:39 --> Helper loaded: url_helper
INFO - 2021-01-12 07:05:39 --> Helper loaded: file_helper
INFO - 2021-01-12 07:05:39 --> Helper loaded: form_helper
INFO - 2021-01-12 07:05:39 --> Helper loaded: my_helper
INFO - 2021-01-12 07:05:39 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:05:39 --> Controller Class Initialized
DEBUG - 2021-01-12 07:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-12 07:05:39 --> Final output sent to browser
DEBUG - 2021-01-12 07:05:39 --> Total execution time: 0.4650
INFO - 2021-01-12 07:06:17 --> Config Class Initialized
INFO - 2021-01-12 07:06:17 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:06:17 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:06:17 --> Utf8 Class Initialized
INFO - 2021-01-12 07:06:17 --> URI Class Initialized
INFO - 2021-01-12 07:06:17 --> Router Class Initialized
INFO - 2021-01-12 07:06:17 --> Output Class Initialized
INFO - 2021-01-12 07:06:17 --> Security Class Initialized
DEBUG - 2021-01-12 07:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:06:17 --> Input Class Initialized
INFO - 2021-01-12 07:06:18 --> Language Class Initialized
INFO - 2021-01-12 07:06:18 --> Language Class Initialized
INFO - 2021-01-12 07:06:18 --> Config Class Initialized
INFO - 2021-01-12 07:06:18 --> Loader Class Initialized
INFO - 2021-01-12 07:06:18 --> Helper loaded: url_helper
INFO - 2021-01-12 07:06:18 --> Helper loaded: file_helper
INFO - 2021-01-12 07:06:18 --> Helper loaded: form_helper
INFO - 2021-01-12 07:06:18 --> Helper loaded: my_helper
INFO - 2021-01-12 07:06:18 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:06:18 --> Controller Class Initialized
DEBUG - 2021-01-12 07:06:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-12 07:06:18 --> Final output sent to browser
DEBUG - 2021-01-12 07:06:18 --> Total execution time: 0.5012
INFO - 2021-01-12 07:06:33 --> Config Class Initialized
INFO - 2021-01-12 07:06:33 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:06:33 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:06:33 --> Utf8 Class Initialized
INFO - 2021-01-12 07:06:33 --> URI Class Initialized
INFO - 2021-01-12 07:06:33 --> Router Class Initialized
INFO - 2021-01-12 07:06:33 --> Output Class Initialized
INFO - 2021-01-12 07:06:33 --> Security Class Initialized
DEBUG - 2021-01-12 07:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:06:33 --> Input Class Initialized
INFO - 2021-01-12 07:06:33 --> Language Class Initialized
INFO - 2021-01-12 07:06:33 --> Language Class Initialized
INFO - 2021-01-12 07:06:33 --> Config Class Initialized
INFO - 2021-01-12 07:06:33 --> Loader Class Initialized
INFO - 2021-01-12 07:06:33 --> Helper loaded: url_helper
INFO - 2021-01-12 07:06:33 --> Helper loaded: file_helper
INFO - 2021-01-12 07:06:33 --> Helper loaded: form_helper
INFO - 2021-01-12 07:06:33 --> Helper loaded: my_helper
INFO - 2021-01-12 07:06:33 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:06:33 --> Controller Class Initialized
DEBUG - 2021-01-12 07:06:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-12 07:06:33 --> Final output sent to browser
DEBUG - 2021-01-12 07:06:33 --> Total execution time: 0.4206
INFO - 2021-01-12 07:07:15 --> Config Class Initialized
INFO - 2021-01-12 07:07:15 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:07:15 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:07:15 --> Utf8 Class Initialized
INFO - 2021-01-12 07:07:15 --> URI Class Initialized
INFO - 2021-01-12 07:07:15 --> Router Class Initialized
INFO - 2021-01-12 07:07:15 --> Output Class Initialized
INFO - 2021-01-12 07:07:15 --> Security Class Initialized
DEBUG - 2021-01-12 07:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:07:15 --> Input Class Initialized
INFO - 2021-01-12 07:07:15 --> Language Class Initialized
INFO - 2021-01-12 07:07:15 --> Language Class Initialized
INFO - 2021-01-12 07:07:15 --> Config Class Initialized
INFO - 2021-01-12 07:07:15 --> Loader Class Initialized
INFO - 2021-01-12 07:07:15 --> Helper loaded: url_helper
INFO - 2021-01-12 07:07:15 --> Helper loaded: file_helper
INFO - 2021-01-12 07:07:15 --> Helper loaded: form_helper
INFO - 2021-01-12 07:07:15 --> Helper loaded: my_helper
INFO - 2021-01-12 07:07:15 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:07:16 --> Controller Class Initialized
INFO - 2021-01-12 07:07:16 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:07:16 --> Config Class Initialized
INFO - 2021-01-12 07:07:16 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:07:16 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:07:16 --> Utf8 Class Initialized
INFO - 2021-01-12 07:07:16 --> URI Class Initialized
INFO - 2021-01-12 07:07:16 --> Router Class Initialized
INFO - 2021-01-12 07:07:16 --> Output Class Initialized
INFO - 2021-01-12 07:07:16 --> Security Class Initialized
DEBUG - 2021-01-12 07:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:07:16 --> Input Class Initialized
INFO - 2021-01-12 07:07:16 --> Language Class Initialized
INFO - 2021-01-12 07:07:16 --> Language Class Initialized
INFO - 2021-01-12 07:07:16 --> Config Class Initialized
INFO - 2021-01-12 07:07:16 --> Loader Class Initialized
INFO - 2021-01-12 07:07:16 --> Helper loaded: url_helper
INFO - 2021-01-12 07:07:16 --> Helper loaded: file_helper
INFO - 2021-01-12 07:07:16 --> Helper loaded: form_helper
INFO - 2021-01-12 07:07:16 --> Helper loaded: my_helper
INFO - 2021-01-12 07:07:16 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:07:16 --> Controller Class Initialized
DEBUG - 2021-01-12 07:07:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:07:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:07:16 --> Final output sent to browser
DEBUG - 2021-01-12 07:07:16 --> Total execution time: 0.3697
INFO - 2021-01-12 07:07:21 --> Config Class Initialized
INFO - 2021-01-12 07:07:21 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:07:21 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:07:21 --> Utf8 Class Initialized
INFO - 2021-01-12 07:07:21 --> URI Class Initialized
INFO - 2021-01-12 07:07:21 --> Router Class Initialized
INFO - 2021-01-12 07:07:21 --> Output Class Initialized
INFO - 2021-01-12 07:07:21 --> Security Class Initialized
DEBUG - 2021-01-12 07:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:07:21 --> Input Class Initialized
INFO - 2021-01-12 07:07:21 --> Language Class Initialized
INFO - 2021-01-12 07:07:21 --> Language Class Initialized
INFO - 2021-01-12 07:07:21 --> Config Class Initialized
INFO - 2021-01-12 07:07:21 --> Loader Class Initialized
INFO - 2021-01-12 07:07:21 --> Helper loaded: url_helper
INFO - 2021-01-12 07:07:21 --> Helper loaded: file_helper
INFO - 2021-01-12 07:07:21 --> Helper loaded: form_helper
INFO - 2021-01-12 07:07:22 --> Helper loaded: my_helper
INFO - 2021-01-12 07:07:22 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:07:22 --> Controller Class Initialized
INFO - 2021-01-12 07:07:22 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:07:22 --> Final output sent to browser
DEBUG - 2021-01-12 07:07:22 --> Total execution time: 0.4369
INFO - 2021-01-12 07:07:23 --> Config Class Initialized
INFO - 2021-01-12 07:07:23 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:07:23 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:07:23 --> Utf8 Class Initialized
INFO - 2021-01-12 07:07:23 --> URI Class Initialized
INFO - 2021-01-12 07:07:23 --> Router Class Initialized
INFO - 2021-01-12 07:07:23 --> Output Class Initialized
INFO - 2021-01-12 07:07:23 --> Security Class Initialized
DEBUG - 2021-01-12 07:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:07:23 --> Input Class Initialized
INFO - 2021-01-12 07:07:23 --> Language Class Initialized
INFO - 2021-01-12 07:07:23 --> Language Class Initialized
INFO - 2021-01-12 07:07:23 --> Config Class Initialized
INFO - 2021-01-12 07:07:23 --> Loader Class Initialized
INFO - 2021-01-12 07:07:23 --> Helper loaded: url_helper
INFO - 2021-01-12 07:07:23 --> Helper loaded: file_helper
INFO - 2021-01-12 07:07:23 --> Helper loaded: form_helper
INFO - 2021-01-12 07:07:23 --> Helper loaded: my_helper
INFO - 2021-01-12 07:07:23 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:07:23 --> Controller Class Initialized
DEBUG - 2021-01-12 07:07:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 07:07:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:07:23 --> Final output sent to browser
DEBUG - 2021-01-12 07:07:23 --> Total execution time: 0.5047
INFO - 2021-01-12 07:07:26 --> Config Class Initialized
INFO - 2021-01-12 07:07:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:07:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:07:26 --> Utf8 Class Initialized
INFO - 2021-01-12 07:07:26 --> URI Class Initialized
INFO - 2021-01-12 07:07:26 --> Router Class Initialized
INFO - 2021-01-12 07:07:26 --> Output Class Initialized
INFO - 2021-01-12 07:07:26 --> Security Class Initialized
DEBUG - 2021-01-12 07:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:07:26 --> Input Class Initialized
INFO - 2021-01-12 07:07:26 --> Language Class Initialized
INFO - 2021-01-12 07:07:26 --> Language Class Initialized
INFO - 2021-01-12 07:07:26 --> Config Class Initialized
INFO - 2021-01-12 07:07:26 --> Loader Class Initialized
INFO - 2021-01-12 07:07:26 --> Helper loaded: url_helper
INFO - 2021-01-12 07:07:26 --> Helper loaded: file_helper
INFO - 2021-01-12 07:07:26 --> Helper loaded: form_helper
INFO - 2021-01-12 07:07:26 --> Helper loaded: my_helper
INFO - 2021-01-12 07:07:26 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:07:26 --> Controller Class Initialized
DEBUG - 2021-01-12 07:07:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-12 07:07:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:07:26 --> Final output sent to browser
DEBUG - 2021-01-12 07:07:26 --> Total execution time: 0.3698
INFO - 2021-01-12 07:07:26 --> Config Class Initialized
INFO - 2021-01-12 07:07:26 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:07:26 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:07:26 --> Utf8 Class Initialized
INFO - 2021-01-12 07:07:26 --> URI Class Initialized
INFO - 2021-01-12 07:07:27 --> Router Class Initialized
INFO - 2021-01-12 07:07:27 --> Output Class Initialized
INFO - 2021-01-12 07:07:27 --> Security Class Initialized
DEBUG - 2021-01-12 07:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:07:27 --> Input Class Initialized
INFO - 2021-01-12 07:07:27 --> Language Class Initialized
INFO - 2021-01-12 07:07:27 --> Language Class Initialized
INFO - 2021-01-12 07:07:27 --> Config Class Initialized
INFO - 2021-01-12 07:07:27 --> Loader Class Initialized
INFO - 2021-01-12 07:07:27 --> Helper loaded: url_helper
INFO - 2021-01-12 07:07:27 --> Helper loaded: file_helper
INFO - 2021-01-12 07:07:27 --> Helper loaded: form_helper
INFO - 2021-01-12 07:07:27 --> Helper loaded: my_helper
INFO - 2021-01-12 07:07:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:07:27 --> Controller Class Initialized
INFO - 2021-01-12 07:07:35 --> Config Class Initialized
INFO - 2021-01-12 07:07:35 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:07:35 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:07:35 --> Utf8 Class Initialized
INFO - 2021-01-12 07:07:35 --> URI Class Initialized
INFO - 2021-01-12 07:07:35 --> Router Class Initialized
INFO - 2021-01-12 07:07:35 --> Output Class Initialized
INFO - 2021-01-12 07:07:35 --> Security Class Initialized
DEBUG - 2021-01-12 07:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:07:35 --> Input Class Initialized
INFO - 2021-01-12 07:07:35 --> Language Class Initialized
INFO - 2021-01-12 07:07:35 --> Language Class Initialized
INFO - 2021-01-12 07:07:35 --> Config Class Initialized
INFO - 2021-01-12 07:07:35 --> Loader Class Initialized
INFO - 2021-01-12 07:07:35 --> Helper loaded: url_helper
INFO - 2021-01-12 07:07:35 --> Helper loaded: file_helper
INFO - 2021-01-12 07:07:35 --> Helper loaded: form_helper
INFO - 2021-01-12 07:07:35 --> Helper loaded: my_helper
INFO - 2021-01-12 07:07:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:07:36 --> Controller Class Initialized
DEBUG - 2021-01-12 07:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-12 07:07:36 --> Final output sent to browser
DEBUG - 2021-01-12 07:07:36 --> Total execution time: 0.4079
INFO - 2021-01-12 07:08:12 --> Config Class Initialized
INFO - 2021-01-12 07:08:12 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:12 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:12 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:12 --> URI Class Initialized
INFO - 2021-01-12 07:08:12 --> Router Class Initialized
INFO - 2021-01-12 07:08:12 --> Output Class Initialized
INFO - 2021-01-12 07:08:12 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:12 --> Input Class Initialized
INFO - 2021-01-12 07:08:12 --> Language Class Initialized
INFO - 2021-01-12 07:08:12 --> Language Class Initialized
INFO - 2021-01-12 07:08:12 --> Config Class Initialized
INFO - 2021-01-12 07:08:12 --> Loader Class Initialized
INFO - 2021-01-12 07:08:12 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:12 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:13 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:13 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:13 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:13 --> Controller Class Initialized
INFO - 2021-01-12 07:08:13 --> Final output sent to browser
DEBUG - 2021-01-12 07:08:13 --> Total execution time: 0.4163
INFO - 2021-01-12 07:08:20 --> Config Class Initialized
INFO - 2021-01-12 07:08:20 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:20 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:20 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:20 --> URI Class Initialized
INFO - 2021-01-12 07:08:20 --> Router Class Initialized
INFO - 2021-01-12 07:08:20 --> Output Class Initialized
INFO - 2021-01-12 07:08:20 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:20 --> Input Class Initialized
INFO - 2021-01-12 07:08:20 --> Language Class Initialized
INFO - 2021-01-12 07:08:20 --> Language Class Initialized
INFO - 2021-01-12 07:08:20 --> Config Class Initialized
INFO - 2021-01-12 07:08:20 --> Loader Class Initialized
INFO - 2021-01-12 07:08:20 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:20 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:20 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:20 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:20 --> Controller Class Initialized
INFO - 2021-01-12 07:08:20 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:08:20 --> Config Class Initialized
INFO - 2021-01-12 07:08:21 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:21 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:21 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:21 --> URI Class Initialized
INFO - 2021-01-12 07:08:21 --> Router Class Initialized
INFO - 2021-01-12 07:08:21 --> Output Class Initialized
INFO - 2021-01-12 07:08:21 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:21 --> Input Class Initialized
INFO - 2021-01-12 07:08:21 --> Language Class Initialized
INFO - 2021-01-12 07:08:21 --> Language Class Initialized
INFO - 2021-01-12 07:08:21 --> Config Class Initialized
INFO - 2021-01-12 07:08:21 --> Loader Class Initialized
INFO - 2021-01-12 07:08:21 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:21 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:21 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:21 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:21 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:21 --> Controller Class Initialized
DEBUG - 2021-01-12 07:08:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:08:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:08:21 --> Final output sent to browser
DEBUG - 2021-01-12 07:08:21 --> Total execution time: 0.3654
INFO - 2021-01-12 07:08:24 --> Config Class Initialized
INFO - 2021-01-12 07:08:24 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:24 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:24 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:24 --> URI Class Initialized
INFO - 2021-01-12 07:08:24 --> Router Class Initialized
INFO - 2021-01-12 07:08:24 --> Output Class Initialized
INFO - 2021-01-12 07:08:24 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:24 --> Input Class Initialized
INFO - 2021-01-12 07:08:24 --> Language Class Initialized
INFO - 2021-01-12 07:08:24 --> Language Class Initialized
INFO - 2021-01-12 07:08:24 --> Config Class Initialized
INFO - 2021-01-12 07:08:24 --> Loader Class Initialized
INFO - 2021-01-12 07:08:24 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:24 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:24 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:24 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:24 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:24 --> Controller Class Initialized
INFO - 2021-01-12 07:08:24 --> Config Class Initialized
INFO - 2021-01-12 07:08:24 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:24 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:24 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:24 --> URI Class Initialized
INFO - 2021-01-12 07:08:24 --> Router Class Initialized
INFO - 2021-01-12 07:08:24 --> Output Class Initialized
INFO - 2021-01-12 07:08:24 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:24 --> Input Class Initialized
INFO - 2021-01-12 07:08:24 --> Language Class Initialized
INFO - 2021-01-12 07:08:24 --> Language Class Initialized
INFO - 2021-01-12 07:08:24 --> Config Class Initialized
INFO - 2021-01-12 07:08:24 --> Loader Class Initialized
INFO - 2021-01-12 07:08:25 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:25 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:25 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:25 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:25 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:25 --> Controller Class Initialized
DEBUG - 2021-01-12 07:08:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/unauthorized_access/views/no_akses.php
DEBUG - 2021-01-12 07:08:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:08:25 --> Final output sent to browser
DEBUG - 2021-01-12 07:08:25 --> Total execution time: 0.3719
INFO - 2021-01-12 07:08:30 --> Config Class Initialized
INFO - 2021-01-12 07:08:30 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:30 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:30 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:30 --> URI Class Initialized
INFO - 2021-01-12 07:08:30 --> Router Class Initialized
INFO - 2021-01-12 07:08:30 --> Output Class Initialized
INFO - 2021-01-12 07:08:30 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:30 --> Input Class Initialized
INFO - 2021-01-12 07:08:30 --> Language Class Initialized
INFO - 2021-01-12 07:08:30 --> Language Class Initialized
INFO - 2021-01-12 07:08:30 --> Config Class Initialized
INFO - 2021-01-12 07:08:30 --> Loader Class Initialized
INFO - 2021-01-12 07:08:30 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:30 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:30 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:30 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:30 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:31 --> Controller Class Initialized
DEBUG - 2021-01-12 07:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:08:31 --> Final output sent to browser
DEBUG - 2021-01-12 07:08:31 --> Total execution time: 0.4021
INFO - 2021-01-12 07:08:32 --> Config Class Initialized
INFO - 2021-01-12 07:08:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:32 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:32 --> URI Class Initialized
DEBUG - 2021-01-12 07:08:32 --> No URI present. Default controller set.
INFO - 2021-01-12 07:08:32 --> Router Class Initialized
INFO - 2021-01-12 07:08:32 --> Output Class Initialized
INFO - 2021-01-12 07:08:32 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:32 --> Input Class Initialized
INFO - 2021-01-12 07:08:32 --> Language Class Initialized
INFO - 2021-01-12 07:08:32 --> Language Class Initialized
INFO - 2021-01-12 07:08:32 --> Config Class Initialized
INFO - 2021-01-12 07:08:32 --> Loader Class Initialized
INFO - 2021-01-12 07:08:32 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:32 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:32 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:32 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:32 --> Controller Class Initialized
INFO - 2021-01-12 07:08:32 --> Config Class Initialized
INFO - 2021-01-12 07:08:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:32 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:32 --> URI Class Initialized
INFO - 2021-01-12 07:08:32 --> Router Class Initialized
INFO - 2021-01-12 07:08:32 --> Output Class Initialized
INFO - 2021-01-12 07:08:32 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:32 --> Input Class Initialized
INFO - 2021-01-12 07:08:32 --> Language Class Initialized
INFO - 2021-01-12 07:08:32 --> Language Class Initialized
INFO - 2021-01-12 07:08:32 --> Config Class Initialized
INFO - 2021-01-12 07:08:32 --> Loader Class Initialized
INFO - 2021-01-12 07:08:32 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:32 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:32 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:32 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:32 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:32 --> Controller Class Initialized
DEBUG - 2021-01-12 07:08:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:08:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:08:33 --> Final output sent to browser
DEBUG - 2021-01-12 07:08:33 --> Total execution time: 0.4050
INFO - 2021-01-12 07:08:33 --> Config Class Initialized
INFO - 2021-01-12 07:08:33 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:08:33 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:08:33 --> Utf8 Class Initialized
INFO - 2021-01-12 07:08:33 --> URI Class Initialized
INFO - 2021-01-12 07:08:33 --> Router Class Initialized
INFO - 2021-01-12 07:08:33 --> Output Class Initialized
INFO - 2021-01-12 07:08:33 --> Security Class Initialized
DEBUG - 2021-01-12 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:08:33 --> Input Class Initialized
INFO - 2021-01-12 07:08:33 --> Language Class Initialized
INFO - 2021-01-12 07:08:33 --> Language Class Initialized
INFO - 2021-01-12 07:08:33 --> Config Class Initialized
INFO - 2021-01-12 07:08:33 --> Loader Class Initialized
INFO - 2021-01-12 07:08:33 --> Helper loaded: url_helper
INFO - 2021-01-12 07:08:33 --> Helper loaded: file_helper
INFO - 2021-01-12 07:08:33 --> Helper loaded: form_helper
INFO - 2021-01-12 07:08:33 --> Helper loaded: my_helper
INFO - 2021-01-12 07:08:33 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:08:33 --> Controller Class Initialized
DEBUG - 2021-01-12 07:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:08:33 --> Final output sent to browser
DEBUG - 2021-01-12 07:08:33 --> Total execution time: 0.4077
INFO - 2021-01-12 07:11:46 --> Config Class Initialized
INFO - 2021-01-12 07:11:46 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:11:46 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:11:46 --> Utf8 Class Initialized
INFO - 2021-01-12 07:11:46 --> URI Class Initialized
INFO - 2021-01-12 07:11:46 --> Router Class Initialized
INFO - 2021-01-12 07:11:46 --> Output Class Initialized
INFO - 2021-01-12 07:11:46 --> Security Class Initialized
DEBUG - 2021-01-12 07:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:11:46 --> Input Class Initialized
INFO - 2021-01-12 07:11:46 --> Language Class Initialized
INFO - 2021-01-12 07:11:46 --> Language Class Initialized
INFO - 2021-01-12 07:11:46 --> Config Class Initialized
INFO - 2021-01-12 07:11:46 --> Loader Class Initialized
INFO - 2021-01-12 07:11:46 --> Helper loaded: url_helper
INFO - 2021-01-12 07:11:47 --> Helper loaded: file_helper
INFO - 2021-01-12 07:11:47 --> Helper loaded: form_helper
INFO - 2021-01-12 07:11:47 --> Helper loaded: my_helper
INFO - 2021-01-12 07:11:47 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:11:47 --> Controller Class Initialized
INFO - 2021-01-12 07:11:47 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:11:47 --> Final output sent to browser
DEBUG - 2021-01-12 07:11:47 --> Total execution time: 0.5503
INFO - 2021-01-12 07:11:47 --> Config Class Initialized
INFO - 2021-01-12 07:11:47 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:11:47 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:11:47 --> Utf8 Class Initialized
INFO - 2021-01-12 07:11:47 --> URI Class Initialized
INFO - 2021-01-12 07:11:47 --> Router Class Initialized
INFO - 2021-01-12 07:11:47 --> Output Class Initialized
INFO - 2021-01-12 07:11:47 --> Security Class Initialized
DEBUG - 2021-01-12 07:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:11:47 --> Input Class Initialized
INFO - 2021-01-12 07:11:47 --> Language Class Initialized
INFO - 2021-01-12 07:11:47 --> Language Class Initialized
INFO - 2021-01-12 07:11:47 --> Config Class Initialized
INFO - 2021-01-12 07:11:47 --> Loader Class Initialized
INFO - 2021-01-12 07:11:47 --> Helper loaded: url_helper
INFO - 2021-01-12 07:11:47 --> Helper loaded: file_helper
INFO - 2021-01-12 07:11:47 --> Helper loaded: form_helper
INFO - 2021-01-12 07:11:47 --> Helper loaded: my_helper
INFO - 2021-01-12 07:11:47 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:11:47 --> Controller Class Initialized
DEBUG - 2021-01-12 07:11:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 07:11:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:11:47 --> Final output sent to browser
DEBUG - 2021-01-12 07:11:48 --> Total execution time: 0.5985
INFO - 2021-01-12 07:11:50 --> Config Class Initialized
INFO - 2021-01-12 07:11:50 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:11:50 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:11:50 --> Utf8 Class Initialized
INFO - 2021-01-12 07:11:50 --> URI Class Initialized
INFO - 2021-01-12 07:11:50 --> Router Class Initialized
INFO - 2021-01-12 07:11:50 --> Output Class Initialized
INFO - 2021-01-12 07:11:50 --> Security Class Initialized
DEBUG - 2021-01-12 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:11:50 --> Input Class Initialized
INFO - 2021-01-12 07:11:50 --> Language Class Initialized
INFO - 2021-01-12 07:11:50 --> Language Class Initialized
INFO - 2021-01-12 07:11:50 --> Config Class Initialized
INFO - 2021-01-12 07:11:50 --> Loader Class Initialized
INFO - 2021-01-12 07:11:50 --> Helper loaded: url_helper
INFO - 2021-01-12 07:11:50 --> Helper loaded: file_helper
INFO - 2021-01-12 07:11:50 --> Helper loaded: form_helper
INFO - 2021-01-12 07:11:50 --> Helper loaded: my_helper
INFO - 2021-01-12 07:11:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:11:50 --> Controller Class Initialized
DEBUG - 2021-01-12 07:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:11:50 --> Final output sent to browser
DEBUG - 2021-01-12 07:11:50 --> Total execution time: 0.4291
INFO - 2021-01-12 07:11:53 --> Config Class Initialized
INFO - 2021-01-12 07:11:53 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:11:53 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:11:53 --> Utf8 Class Initialized
INFO - 2021-01-12 07:11:53 --> URI Class Initialized
INFO - 2021-01-12 07:11:53 --> Router Class Initialized
INFO - 2021-01-12 07:11:53 --> Output Class Initialized
INFO - 2021-01-12 07:11:53 --> Security Class Initialized
DEBUG - 2021-01-12 07:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:11:53 --> Input Class Initialized
INFO - 2021-01-12 07:11:53 --> Language Class Initialized
INFO - 2021-01-12 07:11:53 --> Language Class Initialized
INFO - 2021-01-12 07:11:53 --> Config Class Initialized
INFO - 2021-01-12 07:11:53 --> Loader Class Initialized
INFO - 2021-01-12 07:11:53 --> Helper loaded: url_helper
INFO - 2021-01-12 07:11:53 --> Helper loaded: file_helper
INFO - 2021-01-12 07:11:53 --> Helper loaded: form_helper
INFO - 2021-01-12 07:11:53 --> Helper loaded: my_helper
INFO - 2021-01-12 07:11:53 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:11:53 --> Controller Class Initialized
DEBUG - 2021-01-12 07:11:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:11:53 --> Final output sent to browser
DEBUG - 2021-01-12 07:11:53 --> Total execution time: 0.4256
INFO - 2021-01-12 07:12:01 --> Config Class Initialized
INFO - 2021-01-12 07:12:01 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:12:01 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:12:01 --> Utf8 Class Initialized
INFO - 2021-01-12 07:12:01 --> URI Class Initialized
INFO - 2021-01-12 07:12:01 --> Router Class Initialized
INFO - 2021-01-12 07:12:01 --> Output Class Initialized
INFO - 2021-01-12 07:12:01 --> Security Class Initialized
DEBUG - 2021-01-12 07:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:12:01 --> Input Class Initialized
INFO - 2021-01-12 07:12:01 --> Language Class Initialized
INFO - 2021-01-12 07:12:01 --> Language Class Initialized
INFO - 2021-01-12 07:12:01 --> Config Class Initialized
INFO - 2021-01-12 07:12:01 --> Loader Class Initialized
INFO - 2021-01-12 07:12:01 --> Helper loaded: url_helper
INFO - 2021-01-12 07:12:01 --> Helper loaded: file_helper
INFO - 2021-01-12 07:12:01 --> Helper loaded: form_helper
INFO - 2021-01-12 07:12:01 --> Helper loaded: my_helper
INFO - 2021-01-12 07:12:01 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:12:01 --> Controller Class Initialized
DEBUG - 2021-01-12 07:12:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 07:12:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:12:01 --> Final output sent to browser
DEBUG - 2021-01-12 07:12:02 --> Total execution time: 0.3923
INFO - 2021-01-12 07:12:05 --> Config Class Initialized
INFO - 2021-01-12 07:12:05 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:12:05 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:12:05 --> Utf8 Class Initialized
INFO - 2021-01-12 07:12:05 --> URI Class Initialized
INFO - 2021-01-12 07:12:05 --> Router Class Initialized
INFO - 2021-01-12 07:12:05 --> Output Class Initialized
INFO - 2021-01-12 07:12:05 --> Security Class Initialized
DEBUG - 2021-01-12 07:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:12:05 --> Input Class Initialized
INFO - 2021-01-12 07:12:05 --> Language Class Initialized
INFO - 2021-01-12 07:12:05 --> Language Class Initialized
INFO - 2021-01-12 07:12:05 --> Config Class Initialized
INFO - 2021-01-12 07:12:05 --> Loader Class Initialized
INFO - 2021-01-12 07:12:05 --> Helper loaded: url_helper
INFO - 2021-01-12 07:12:05 --> Helper loaded: file_helper
INFO - 2021-01-12 07:12:05 --> Helper loaded: form_helper
INFO - 2021-01-12 07:12:05 --> Helper loaded: my_helper
INFO - 2021-01-12 07:12:05 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:12:05 --> Controller Class Initialized
INFO - 2021-01-12 07:12:05 --> Final output sent to browser
DEBUG - 2021-01-12 07:12:05 --> Total execution time: 0.3785
INFO - 2021-01-12 07:12:07 --> Config Class Initialized
INFO - 2021-01-12 07:12:07 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:12:07 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:12:07 --> Utf8 Class Initialized
INFO - 2021-01-12 07:12:07 --> URI Class Initialized
INFO - 2021-01-12 07:12:07 --> Router Class Initialized
INFO - 2021-01-12 07:12:07 --> Output Class Initialized
INFO - 2021-01-12 07:12:07 --> Security Class Initialized
DEBUG - 2021-01-12 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:12:07 --> Input Class Initialized
INFO - 2021-01-12 07:12:07 --> Language Class Initialized
INFO - 2021-01-12 07:12:07 --> Language Class Initialized
INFO - 2021-01-12 07:12:07 --> Config Class Initialized
INFO - 2021-01-12 07:12:07 --> Loader Class Initialized
INFO - 2021-01-12 07:12:07 --> Helper loaded: url_helper
INFO - 2021-01-12 07:12:07 --> Helper loaded: file_helper
INFO - 2021-01-12 07:12:07 --> Helper loaded: form_helper
INFO - 2021-01-12 07:12:07 --> Helper loaded: my_helper
INFO - 2021-01-12 07:12:07 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:12:07 --> Controller Class Initialized
DEBUG - 2021-01-12 07:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:12:07 --> Final output sent to browser
DEBUG - 2021-01-12 07:12:07 --> Total execution time: 0.4431
INFO - 2021-01-12 07:12:09 --> Config Class Initialized
INFO - 2021-01-12 07:12:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:12:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:12:09 --> Utf8 Class Initialized
INFO - 2021-01-12 07:12:09 --> URI Class Initialized
INFO - 2021-01-12 07:12:09 --> Router Class Initialized
INFO - 2021-01-12 07:12:09 --> Output Class Initialized
INFO - 2021-01-12 07:12:09 --> Security Class Initialized
DEBUG - 2021-01-12 07:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:12:10 --> Input Class Initialized
INFO - 2021-01-12 07:12:10 --> Language Class Initialized
INFO - 2021-01-12 07:12:10 --> Language Class Initialized
INFO - 2021-01-12 07:12:10 --> Config Class Initialized
INFO - 2021-01-12 07:12:10 --> Loader Class Initialized
INFO - 2021-01-12 07:12:10 --> Helper loaded: url_helper
INFO - 2021-01-12 07:12:10 --> Helper loaded: file_helper
INFO - 2021-01-12 07:12:10 --> Helper loaded: form_helper
INFO - 2021-01-12 07:12:10 --> Helper loaded: my_helper
INFO - 2021-01-12 07:12:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:12:10 --> Controller Class Initialized
DEBUG - 2021-01-12 07:12:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:12:10 --> Final output sent to browser
DEBUG - 2021-01-12 07:12:10 --> Total execution time: 0.4282
INFO - 2021-01-12 07:12:50 --> Config Class Initialized
INFO - 2021-01-12 07:12:50 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:12:50 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:12:50 --> Utf8 Class Initialized
INFO - 2021-01-12 07:12:50 --> URI Class Initialized
INFO - 2021-01-12 07:12:50 --> Router Class Initialized
INFO - 2021-01-12 07:12:50 --> Output Class Initialized
INFO - 2021-01-12 07:12:50 --> Security Class Initialized
DEBUG - 2021-01-12 07:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:12:50 --> Input Class Initialized
INFO - 2021-01-12 07:12:50 --> Language Class Initialized
INFO - 2021-01-12 07:12:50 --> Language Class Initialized
INFO - 2021-01-12 07:12:50 --> Config Class Initialized
INFO - 2021-01-12 07:12:50 --> Loader Class Initialized
INFO - 2021-01-12 07:12:50 --> Helper loaded: url_helper
INFO - 2021-01-12 07:12:50 --> Helper loaded: file_helper
INFO - 2021-01-12 07:12:50 --> Helper loaded: form_helper
INFO - 2021-01-12 07:12:50 --> Helper loaded: my_helper
INFO - 2021-01-12 07:12:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:12:50 --> Controller Class Initialized
DEBUG - 2021-01-12 07:12:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:12:50 --> Final output sent to browser
DEBUG - 2021-01-12 07:12:50 --> Total execution time: 0.4779
INFO - 2021-01-12 07:13:08 --> Config Class Initialized
INFO - 2021-01-12 07:13:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:13:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:13:08 --> Utf8 Class Initialized
INFO - 2021-01-12 07:13:08 --> URI Class Initialized
INFO - 2021-01-12 07:13:08 --> Router Class Initialized
INFO - 2021-01-12 07:13:08 --> Output Class Initialized
INFO - 2021-01-12 07:13:08 --> Security Class Initialized
DEBUG - 2021-01-12 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:13:08 --> Input Class Initialized
INFO - 2021-01-12 07:13:08 --> Language Class Initialized
INFO - 2021-01-12 07:13:08 --> Language Class Initialized
INFO - 2021-01-12 07:13:08 --> Config Class Initialized
INFO - 2021-01-12 07:13:08 --> Loader Class Initialized
INFO - 2021-01-12 07:13:08 --> Helper loaded: url_helper
INFO - 2021-01-12 07:13:08 --> Helper loaded: file_helper
INFO - 2021-01-12 07:13:08 --> Helper loaded: form_helper
INFO - 2021-01-12 07:13:08 --> Helper loaded: my_helper
INFO - 2021-01-12 07:13:08 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:13:08 --> Controller Class Initialized
DEBUG - 2021-01-12 07:13:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:13:08 --> Final output sent to browser
DEBUG - 2021-01-12 07:13:08 --> Total execution time: 0.4691
INFO - 2021-01-12 07:13:19 --> Config Class Initialized
INFO - 2021-01-12 07:13:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:13:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:13:19 --> Utf8 Class Initialized
INFO - 2021-01-12 07:13:19 --> URI Class Initialized
INFO - 2021-01-12 07:13:19 --> Router Class Initialized
INFO - 2021-01-12 07:13:19 --> Output Class Initialized
INFO - 2021-01-12 07:13:19 --> Security Class Initialized
DEBUG - 2021-01-12 07:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:13:20 --> Input Class Initialized
INFO - 2021-01-12 07:13:20 --> Language Class Initialized
INFO - 2021-01-12 07:13:20 --> Language Class Initialized
INFO - 2021-01-12 07:13:20 --> Config Class Initialized
INFO - 2021-01-12 07:13:20 --> Loader Class Initialized
INFO - 2021-01-12 07:13:20 --> Helper loaded: url_helper
INFO - 2021-01-12 07:13:20 --> Helper loaded: file_helper
INFO - 2021-01-12 07:13:20 --> Helper loaded: form_helper
INFO - 2021-01-12 07:13:20 --> Helper loaded: my_helper
INFO - 2021-01-12 07:13:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:13:20 --> Controller Class Initialized
DEBUG - 2021-01-12 07:13:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:13:20 --> Final output sent to browser
DEBUG - 2021-01-12 07:13:20 --> Total execution time: 0.3801
INFO - 2021-01-12 07:14:00 --> Config Class Initialized
INFO - 2021-01-12 07:14:00 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:14:00 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:14:00 --> Utf8 Class Initialized
INFO - 2021-01-12 07:14:00 --> URI Class Initialized
INFO - 2021-01-12 07:14:00 --> Router Class Initialized
INFO - 2021-01-12 07:14:00 --> Output Class Initialized
INFO - 2021-01-12 07:14:00 --> Security Class Initialized
DEBUG - 2021-01-12 07:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:14:00 --> Input Class Initialized
INFO - 2021-01-12 07:14:00 --> Language Class Initialized
INFO - 2021-01-12 07:14:00 --> Language Class Initialized
INFO - 2021-01-12 07:14:00 --> Config Class Initialized
INFO - 2021-01-12 07:14:00 --> Loader Class Initialized
INFO - 2021-01-12 07:14:00 --> Helper loaded: url_helper
INFO - 2021-01-12 07:14:00 --> Helper loaded: file_helper
INFO - 2021-01-12 07:14:00 --> Helper loaded: form_helper
INFO - 2021-01-12 07:14:00 --> Helper loaded: my_helper
INFO - 2021-01-12 07:14:00 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:14:00 --> Controller Class Initialized
DEBUG - 2021-01-12 07:14:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:14:01 --> Final output sent to browser
DEBUG - 2021-01-12 07:14:01 --> Total execution time: 0.4557
INFO - 2021-01-12 07:15:49 --> Config Class Initialized
INFO - 2021-01-12 07:15:49 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:15:49 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:15:49 --> Utf8 Class Initialized
INFO - 2021-01-12 07:15:49 --> URI Class Initialized
INFO - 2021-01-12 07:15:49 --> Router Class Initialized
INFO - 2021-01-12 07:15:50 --> Output Class Initialized
INFO - 2021-01-12 07:15:50 --> Security Class Initialized
DEBUG - 2021-01-12 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:15:50 --> Input Class Initialized
INFO - 2021-01-12 07:15:50 --> Language Class Initialized
INFO - 2021-01-12 07:15:50 --> Language Class Initialized
INFO - 2021-01-12 07:15:50 --> Config Class Initialized
INFO - 2021-01-12 07:15:50 --> Loader Class Initialized
INFO - 2021-01-12 07:15:50 --> Helper loaded: url_helper
INFO - 2021-01-12 07:15:50 --> Helper loaded: file_helper
INFO - 2021-01-12 07:15:50 --> Helper loaded: form_helper
INFO - 2021-01-12 07:15:50 --> Helper loaded: my_helper
INFO - 2021-01-12 07:15:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:15:50 --> Controller Class Initialized
DEBUG - 2021-01-12 07:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:15:50 --> Final output sent to browser
DEBUG - 2021-01-12 07:15:50 --> Total execution time: 0.4730
INFO - 2021-01-12 07:16:02 --> Config Class Initialized
INFO - 2021-01-12 07:16:02 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:16:02 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:16:02 --> Utf8 Class Initialized
INFO - 2021-01-12 07:16:02 --> URI Class Initialized
INFO - 2021-01-12 07:16:03 --> Router Class Initialized
INFO - 2021-01-12 07:16:03 --> Output Class Initialized
INFO - 2021-01-12 07:16:03 --> Security Class Initialized
DEBUG - 2021-01-12 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:16:03 --> Input Class Initialized
INFO - 2021-01-12 07:16:03 --> Language Class Initialized
INFO - 2021-01-12 07:16:03 --> Language Class Initialized
INFO - 2021-01-12 07:16:03 --> Config Class Initialized
INFO - 2021-01-12 07:16:03 --> Loader Class Initialized
INFO - 2021-01-12 07:16:03 --> Helper loaded: url_helper
INFO - 2021-01-12 07:16:03 --> Helper loaded: file_helper
INFO - 2021-01-12 07:16:03 --> Helper loaded: form_helper
INFO - 2021-01-12 07:16:03 --> Helper loaded: my_helper
INFO - 2021-01-12 07:16:03 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:16:03 --> Controller Class Initialized
DEBUG - 2021-01-12 07:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:16:03 --> Final output sent to browser
DEBUG - 2021-01-12 07:16:03 --> Total execution time: 0.4440
INFO - 2021-01-12 07:17:04 --> Config Class Initialized
INFO - 2021-01-12 07:17:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:17:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:17:04 --> Utf8 Class Initialized
INFO - 2021-01-12 07:17:04 --> URI Class Initialized
INFO - 2021-01-12 07:17:04 --> Router Class Initialized
INFO - 2021-01-12 07:17:04 --> Output Class Initialized
INFO - 2021-01-12 07:17:04 --> Security Class Initialized
DEBUG - 2021-01-12 07:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:17:04 --> Input Class Initialized
INFO - 2021-01-12 07:17:04 --> Language Class Initialized
INFO - 2021-01-12 07:17:04 --> Language Class Initialized
INFO - 2021-01-12 07:17:04 --> Config Class Initialized
INFO - 2021-01-12 07:17:04 --> Loader Class Initialized
INFO - 2021-01-12 07:17:04 --> Helper loaded: url_helper
INFO - 2021-01-12 07:17:04 --> Helper loaded: file_helper
INFO - 2021-01-12 07:17:04 --> Helper loaded: form_helper
INFO - 2021-01-12 07:17:04 --> Helper loaded: my_helper
INFO - 2021-01-12 07:17:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:17:04 --> Controller Class Initialized
DEBUG - 2021-01-12 07:17:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:17:04 --> Final output sent to browser
DEBUG - 2021-01-12 07:17:04 --> Total execution time: 0.4447
INFO - 2021-01-12 07:17:41 --> Config Class Initialized
INFO - 2021-01-12 07:17:41 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:17:41 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:17:41 --> Utf8 Class Initialized
INFO - 2021-01-12 07:17:41 --> URI Class Initialized
INFO - 2021-01-12 07:17:41 --> Router Class Initialized
INFO - 2021-01-12 07:17:41 --> Output Class Initialized
INFO - 2021-01-12 07:17:41 --> Security Class Initialized
DEBUG - 2021-01-12 07:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:17:41 --> Input Class Initialized
INFO - 2021-01-12 07:17:41 --> Language Class Initialized
INFO - 2021-01-12 07:17:41 --> Language Class Initialized
INFO - 2021-01-12 07:17:41 --> Config Class Initialized
INFO - 2021-01-12 07:17:41 --> Loader Class Initialized
INFO - 2021-01-12 07:17:41 --> Helper loaded: url_helper
INFO - 2021-01-12 07:17:41 --> Helper loaded: file_helper
INFO - 2021-01-12 07:17:41 --> Helper loaded: form_helper
INFO - 2021-01-12 07:17:41 --> Helper loaded: my_helper
INFO - 2021-01-12 07:17:41 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:17:41 --> Controller Class Initialized
DEBUG - 2021-01-12 07:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:17:41 --> Final output sent to browser
DEBUG - 2021-01-12 07:17:41 --> Total execution time: 0.4545
INFO - 2021-01-12 07:17:56 --> Config Class Initialized
INFO - 2021-01-12 07:17:56 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:17:56 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:17:56 --> Utf8 Class Initialized
INFO - 2021-01-12 07:17:56 --> URI Class Initialized
INFO - 2021-01-12 07:17:56 --> Router Class Initialized
INFO - 2021-01-12 07:17:56 --> Output Class Initialized
INFO - 2021-01-12 07:17:56 --> Security Class Initialized
DEBUG - 2021-01-12 07:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:17:56 --> Input Class Initialized
INFO - 2021-01-12 07:17:56 --> Language Class Initialized
INFO - 2021-01-12 07:17:56 --> Language Class Initialized
INFO - 2021-01-12 07:17:56 --> Config Class Initialized
INFO - 2021-01-12 07:17:56 --> Loader Class Initialized
INFO - 2021-01-12 07:17:56 --> Helper loaded: url_helper
INFO - 2021-01-12 07:17:56 --> Helper loaded: file_helper
INFO - 2021-01-12 07:17:56 --> Helper loaded: form_helper
INFO - 2021-01-12 07:17:56 --> Helper loaded: my_helper
INFO - 2021-01-12 07:17:56 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:17:56 --> Controller Class Initialized
DEBUG - 2021-01-12 07:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:17:56 --> Final output sent to browser
DEBUG - 2021-01-12 07:17:56 --> Total execution time: 0.4484
INFO - 2021-01-12 07:18:09 --> Config Class Initialized
INFO - 2021-01-12 07:18:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:18:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:18:09 --> Utf8 Class Initialized
INFO - 2021-01-12 07:18:09 --> URI Class Initialized
INFO - 2021-01-12 07:18:09 --> Router Class Initialized
INFO - 2021-01-12 07:18:09 --> Output Class Initialized
INFO - 2021-01-12 07:18:09 --> Security Class Initialized
DEBUG - 2021-01-12 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:18:09 --> Input Class Initialized
INFO - 2021-01-12 07:18:09 --> Language Class Initialized
INFO - 2021-01-12 07:18:09 --> Language Class Initialized
INFO - 2021-01-12 07:18:09 --> Config Class Initialized
INFO - 2021-01-12 07:18:09 --> Loader Class Initialized
INFO - 2021-01-12 07:18:09 --> Helper loaded: url_helper
INFO - 2021-01-12 07:18:09 --> Helper loaded: file_helper
INFO - 2021-01-12 07:18:09 --> Helper loaded: form_helper
INFO - 2021-01-12 07:18:09 --> Helper loaded: my_helper
INFO - 2021-01-12 07:18:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:18:09 --> Controller Class Initialized
DEBUG - 2021-01-12 07:18:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:18:09 --> Final output sent to browser
DEBUG - 2021-01-12 07:18:09 --> Total execution time: 0.4721
INFO - 2021-01-12 07:18:31 --> Config Class Initialized
INFO - 2021-01-12 07:18:31 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:18:31 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:18:31 --> Utf8 Class Initialized
INFO - 2021-01-12 07:18:31 --> URI Class Initialized
INFO - 2021-01-12 07:18:31 --> Router Class Initialized
INFO - 2021-01-12 07:18:31 --> Output Class Initialized
INFO - 2021-01-12 07:18:31 --> Security Class Initialized
DEBUG - 2021-01-12 07:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:18:31 --> Input Class Initialized
INFO - 2021-01-12 07:18:31 --> Language Class Initialized
INFO - 2021-01-12 07:18:31 --> Language Class Initialized
INFO - 2021-01-12 07:18:31 --> Config Class Initialized
INFO - 2021-01-12 07:18:31 --> Loader Class Initialized
INFO - 2021-01-12 07:18:31 --> Helper loaded: url_helper
INFO - 2021-01-12 07:18:31 --> Helper loaded: file_helper
INFO - 2021-01-12 07:18:31 --> Helper loaded: form_helper
INFO - 2021-01-12 07:18:31 --> Helper loaded: my_helper
INFO - 2021-01-12 07:18:31 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:18:31 --> Controller Class Initialized
DEBUG - 2021-01-12 07:18:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:18:31 --> Final output sent to browser
DEBUG - 2021-01-12 07:18:31 --> Total execution time: 0.4435
INFO - 2021-01-12 07:18:44 --> Config Class Initialized
INFO - 2021-01-12 07:18:44 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:18:44 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:18:44 --> Utf8 Class Initialized
INFO - 2021-01-12 07:18:44 --> URI Class Initialized
INFO - 2021-01-12 07:18:44 --> Router Class Initialized
INFO - 2021-01-12 07:18:44 --> Output Class Initialized
INFO - 2021-01-12 07:18:44 --> Security Class Initialized
DEBUG - 2021-01-12 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:18:44 --> Input Class Initialized
INFO - 2021-01-12 07:18:44 --> Language Class Initialized
INFO - 2021-01-12 07:18:44 --> Language Class Initialized
INFO - 2021-01-12 07:18:44 --> Config Class Initialized
INFO - 2021-01-12 07:18:44 --> Loader Class Initialized
INFO - 2021-01-12 07:18:44 --> Helper loaded: url_helper
INFO - 2021-01-12 07:18:44 --> Helper loaded: file_helper
INFO - 2021-01-12 07:18:44 --> Helper loaded: form_helper
INFO - 2021-01-12 07:18:44 --> Helper loaded: my_helper
INFO - 2021-01-12 07:18:44 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:18:44 --> Controller Class Initialized
DEBUG - 2021-01-12 07:18:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-01-12 07:18:44 --> Final output sent to browser
DEBUG - 2021-01-12 07:18:44 --> Total execution time: 0.4601
INFO - 2021-01-12 07:19:13 --> Config Class Initialized
INFO - 2021-01-12 07:19:13 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:19:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:19:13 --> Utf8 Class Initialized
INFO - 2021-01-12 07:19:13 --> URI Class Initialized
INFO - 2021-01-12 07:19:13 --> Router Class Initialized
INFO - 2021-01-12 07:19:13 --> Output Class Initialized
INFO - 2021-01-12 07:19:13 --> Security Class Initialized
DEBUG - 2021-01-12 07:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:19:13 --> Input Class Initialized
INFO - 2021-01-12 07:19:13 --> Language Class Initialized
INFO - 2021-01-12 07:19:14 --> Language Class Initialized
INFO - 2021-01-12 07:19:14 --> Config Class Initialized
INFO - 2021-01-12 07:19:14 --> Loader Class Initialized
INFO - 2021-01-12 07:19:14 --> Helper loaded: url_helper
INFO - 2021-01-12 07:19:14 --> Helper loaded: file_helper
INFO - 2021-01-12 07:19:14 --> Helper loaded: form_helper
INFO - 2021-01-12 07:19:14 --> Helper loaded: my_helper
INFO - 2021-01-12 07:19:14 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:19:14 --> Controller Class Initialized
INFO - 2021-01-12 07:19:14 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:19:14 --> Config Class Initialized
INFO - 2021-01-12 07:19:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:19:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:19:14 --> Utf8 Class Initialized
INFO - 2021-01-12 07:19:14 --> URI Class Initialized
INFO - 2021-01-12 07:19:14 --> Router Class Initialized
INFO - 2021-01-12 07:19:14 --> Output Class Initialized
INFO - 2021-01-12 07:19:14 --> Security Class Initialized
DEBUG - 2021-01-12 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:19:14 --> Input Class Initialized
INFO - 2021-01-12 07:19:14 --> Language Class Initialized
INFO - 2021-01-12 07:19:14 --> Language Class Initialized
INFO - 2021-01-12 07:19:14 --> Config Class Initialized
INFO - 2021-01-12 07:19:14 --> Loader Class Initialized
INFO - 2021-01-12 07:19:14 --> Helper loaded: url_helper
INFO - 2021-01-12 07:19:14 --> Helper loaded: file_helper
INFO - 2021-01-12 07:19:14 --> Helper loaded: form_helper
INFO - 2021-01-12 07:19:14 --> Helper loaded: my_helper
INFO - 2021-01-12 07:19:14 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:19:14 --> Controller Class Initialized
DEBUG - 2021-01-12 07:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:19:14 --> Final output sent to browser
DEBUG - 2021-01-12 07:19:14 --> Total execution time: 0.4421
INFO - 2021-01-12 07:19:27 --> Config Class Initialized
INFO - 2021-01-12 07:19:27 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:19:27 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:19:27 --> Utf8 Class Initialized
INFO - 2021-01-12 07:19:27 --> URI Class Initialized
INFO - 2021-01-12 07:19:27 --> Router Class Initialized
INFO - 2021-01-12 07:19:27 --> Output Class Initialized
INFO - 2021-01-12 07:19:27 --> Security Class Initialized
DEBUG - 2021-01-12 07:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:19:27 --> Input Class Initialized
INFO - 2021-01-12 07:19:27 --> Language Class Initialized
INFO - 2021-01-12 07:19:27 --> Language Class Initialized
INFO - 2021-01-12 07:19:27 --> Config Class Initialized
INFO - 2021-01-12 07:19:27 --> Loader Class Initialized
INFO - 2021-01-12 07:19:27 --> Helper loaded: url_helper
INFO - 2021-01-12 07:19:27 --> Helper loaded: file_helper
INFO - 2021-01-12 07:19:27 --> Helper loaded: form_helper
INFO - 2021-01-12 07:19:27 --> Helper loaded: my_helper
INFO - 2021-01-12 07:19:27 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:19:27 --> Controller Class Initialized
INFO - 2021-01-12 07:19:27 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:19:27 --> Final output sent to browser
DEBUG - 2021-01-12 07:19:27 --> Total execution time: 0.5589
INFO - 2021-01-12 07:19:29 --> Config Class Initialized
INFO - 2021-01-12 07:19:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:19:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:19:29 --> Utf8 Class Initialized
INFO - 2021-01-12 07:19:29 --> URI Class Initialized
INFO - 2021-01-12 07:19:29 --> Router Class Initialized
INFO - 2021-01-12 07:19:29 --> Output Class Initialized
INFO - 2021-01-12 07:19:29 --> Security Class Initialized
DEBUG - 2021-01-12 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:19:29 --> Input Class Initialized
INFO - 2021-01-12 07:19:29 --> Language Class Initialized
INFO - 2021-01-12 07:19:29 --> Language Class Initialized
INFO - 2021-01-12 07:19:29 --> Config Class Initialized
INFO - 2021-01-12 07:19:29 --> Loader Class Initialized
INFO - 2021-01-12 07:19:29 --> Helper loaded: url_helper
INFO - 2021-01-12 07:19:29 --> Helper loaded: file_helper
INFO - 2021-01-12 07:19:29 --> Helper loaded: form_helper
INFO - 2021-01-12 07:19:29 --> Helper loaded: my_helper
INFO - 2021-01-12 07:19:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:19:30 --> Controller Class Initialized
DEBUG - 2021-01-12 07:19:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 07:19:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:19:30 --> Final output sent to browser
DEBUG - 2021-01-12 07:19:30 --> Total execution time: 0.6003
INFO - 2021-01-12 07:19:32 --> Config Class Initialized
INFO - 2021-01-12 07:19:32 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:19:32 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:19:32 --> Utf8 Class Initialized
INFO - 2021-01-12 07:19:32 --> URI Class Initialized
INFO - 2021-01-12 07:19:32 --> Router Class Initialized
INFO - 2021-01-12 07:19:32 --> Output Class Initialized
INFO - 2021-01-12 07:19:32 --> Security Class Initialized
DEBUG - 2021-01-12 07:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:19:32 --> Input Class Initialized
INFO - 2021-01-12 07:19:32 --> Language Class Initialized
INFO - 2021-01-12 07:19:32 --> Language Class Initialized
INFO - 2021-01-12 07:19:32 --> Config Class Initialized
INFO - 2021-01-12 07:19:32 --> Loader Class Initialized
INFO - 2021-01-12 07:19:32 --> Helper loaded: url_helper
INFO - 2021-01-12 07:19:33 --> Helper loaded: file_helper
INFO - 2021-01-12 07:19:33 --> Helper loaded: form_helper
INFO - 2021-01-12 07:19:33 --> Helper loaded: my_helper
INFO - 2021-01-12 07:19:33 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:19:33 --> Controller Class Initialized
DEBUG - 2021-01-12 07:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 07:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:19:33 --> Final output sent to browser
DEBUG - 2021-01-12 07:19:33 --> Total execution time: 0.4540
INFO - 2021-01-12 07:19:42 --> Config Class Initialized
INFO - 2021-01-12 07:19:42 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:19:42 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:19:42 --> Utf8 Class Initialized
INFO - 2021-01-12 07:19:42 --> URI Class Initialized
INFO - 2021-01-12 07:19:42 --> Router Class Initialized
INFO - 2021-01-12 07:19:42 --> Output Class Initialized
INFO - 2021-01-12 07:19:42 --> Security Class Initialized
DEBUG - 2021-01-12 07:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:19:42 --> Input Class Initialized
INFO - 2021-01-12 07:19:42 --> Language Class Initialized
INFO - 2021-01-12 07:19:42 --> Language Class Initialized
INFO - 2021-01-12 07:19:42 --> Config Class Initialized
INFO - 2021-01-12 07:19:42 --> Loader Class Initialized
INFO - 2021-01-12 07:19:42 --> Helper loaded: url_helper
INFO - 2021-01-12 07:19:42 --> Helper loaded: file_helper
INFO - 2021-01-12 07:19:42 --> Helper loaded: form_helper
INFO - 2021-01-12 07:19:42 --> Helper loaded: my_helper
INFO - 2021-01-12 07:19:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:19:42 --> Controller Class Initialized
INFO - 2021-01-12 07:19:42 --> Final output sent to browser
DEBUG - 2021-01-12 07:19:42 --> Total execution time: 0.3921
INFO - 2021-01-12 07:19:52 --> Config Class Initialized
INFO - 2021-01-12 07:19:52 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:19:52 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:19:52 --> Utf8 Class Initialized
INFO - 2021-01-12 07:19:52 --> URI Class Initialized
INFO - 2021-01-12 07:19:52 --> Router Class Initialized
INFO - 2021-01-12 07:19:52 --> Output Class Initialized
INFO - 2021-01-12 07:19:52 --> Security Class Initialized
DEBUG - 2021-01-12 07:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:19:53 --> Input Class Initialized
INFO - 2021-01-12 07:19:53 --> Language Class Initialized
INFO - 2021-01-12 07:19:53 --> Language Class Initialized
INFO - 2021-01-12 07:19:53 --> Config Class Initialized
INFO - 2021-01-12 07:19:53 --> Loader Class Initialized
INFO - 2021-01-12 07:19:53 --> Helper loaded: url_helper
INFO - 2021-01-12 07:19:53 --> Helper loaded: file_helper
INFO - 2021-01-12 07:19:53 --> Helper loaded: form_helper
INFO - 2021-01-12 07:19:53 --> Helper loaded: my_helper
INFO - 2021-01-12 07:19:53 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:19:53 --> Controller Class Initialized
DEBUG - 2021-01-12 07:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:19:53 --> Final output sent to browser
DEBUG - 2021-01-12 07:19:53 --> Total execution time: 0.4819
INFO - 2021-01-12 07:20:01 --> Config Class Initialized
INFO - 2021-01-12 07:20:01 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:20:01 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:20:01 --> Utf8 Class Initialized
INFO - 2021-01-12 07:20:01 --> URI Class Initialized
INFO - 2021-01-12 07:20:01 --> Router Class Initialized
INFO - 2021-01-12 07:20:01 --> Output Class Initialized
INFO - 2021-01-12 07:20:01 --> Security Class Initialized
DEBUG - 2021-01-12 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:20:01 --> Input Class Initialized
INFO - 2021-01-12 07:20:01 --> Language Class Initialized
INFO - 2021-01-12 07:20:01 --> Language Class Initialized
INFO - 2021-01-12 07:20:01 --> Config Class Initialized
INFO - 2021-01-12 07:20:01 --> Loader Class Initialized
INFO - 2021-01-12 07:20:01 --> Helper loaded: url_helper
INFO - 2021-01-12 07:20:01 --> Helper loaded: file_helper
INFO - 2021-01-12 07:20:01 --> Helper loaded: form_helper
INFO - 2021-01-12 07:20:01 --> Helper loaded: my_helper
INFO - 2021-01-12 07:20:01 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:20:01 --> Controller Class Initialized
DEBUG - 2021-01-12 07:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-12 07:20:01 --> Final output sent to browser
DEBUG - 2021-01-12 07:20:01 --> Total execution time: 0.4309
INFO - 2021-01-12 07:20:15 --> Config Class Initialized
INFO - 2021-01-12 07:20:15 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:20:15 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:20:15 --> Utf8 Class Initialized
INFO - 2021-01-12 07:20:15 --> URI Class Initialized
INFO - 2021-01-12 07:20:15 --> Router Class Initialized
INFO - 2021-01-12 07:20:15 --> Output Class Initialized
INFO - 2021-01-12 07:20:15 --> Security Class Initialized
DEBUG - 2021-01-12 07:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:20:15 --> Input Class Initialized
INFO - 2021-01-12 07:20:15 --> Language Class Initialized
INFO - 2021-01-12 07:20:15 --> Language Class Initialized
INFO - 2021-01-12 07:20:15 --> Config Class Initialized
INFO - 2021-01-12 07:20:15 --> Loader Class Initialized
INFO - 2021-01-12 07:20:15 --> Helper loaded: url_helper
INFO - 2021-01-12 07:20:15 --> Helper loaded: file_helper
INFO - 2021-01-12 07:20:15 --> Helper loaded: form_helper
INFO - 2021-01-12 07:20:15 --> Helper loaded: my_helper
INFO - 2021-01-12 07:20:15 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:20:15 --> Controller Class Initialized
DEBUG - 2021-01-12 07:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-12 07:20:16 --> Final output sent to browser
DEBUG - 2021-01-12 07:20:16 --> Total execution time: 0.5430
INFO - 2021-01-12 07:20:50 --> Config Class Initialized
INFO - 2021-01-12 07:20:50 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:20:50 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:20:50 --> Utf8 Class Initialized
INFO - 2021-01-12 07:20:50 --> URI Class Initialized
INFO - 2021-01-12 07:20:50 --> Router Class Initialized
INFO - 2021-01-12 07:20:50 --> Output Class Initialized
INFO - 2021-01-12 07:20:50 --> Security Class Initialized
DEBUG - 2021-01-12 07:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:20:50 --> Input Class Initialized
INFO - 2021-01-12 07:20:50 --> Language Class Initialized
INFO - 2021-01-12 07:20:50 --> Language Class Initialized
INFO - 2021-01-12 07:20:50 --> Config Class Initialized
INFO - 2021-01-12 07:20:50 --> Loader Class Initialized
INFO - 2021-01-12 07:20:50 --> Helper loaded: url_helper
INFO - 2021-01-12 07:20:50 --> Helper loaded: file_helper
INFO - 2021-01-12 07:20:50 --> Helper loaded: form_helper
INFO - 2021-01-12 07:20:50 --> Helper loaded: my_helper
INFO - 2021-01-12 07:20:50 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:20:50 --> Controller Class Initialized
DEBUG - 2021-01-12 07:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-12 07:20:50 --> Final output sent to browser
DEBUG - 2021-01-12 07:20:50 --> Total execution time: 0.4827
INFO - 2021-01-12 07:21:06 --> Config Class Initialized
INFO - 2021-01-12 07:21:06 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:21:06 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:21:06 --> Utf8 Class Initialized
INFO - 2021-01-12 07:21:06 --> URI Class Initialized
INFO - 2021-01-12 07:21:06 --> Router Class Initialized
INFO - 2021-01-12 07:21:06 --> Output Class Initialized
INFO - 2021-01-12 07:21:06 --> Security Class Initialized
DEBUG - 2021-01-12 07:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:21:06 --> Input Class Initialized
INFO - 2021-01-12 07:21:07 --> Language Class Initialized
INFO - 2021-01-12 07:21:07 --> Language Class Initialized
INFO - 2021-01-12 07:21:07 --> Config Class Initialized
INFO - 2021-01-12 07:21:07 --> Loader Class Initialized
INFO - 2021-01-12 07:21:07 --> Helper loaded: url_helper
INFO - 2021-01-12 07:21:07 --> Helper loaded: file_helper
INFO - 2021-01-12 07:21:07 --> Helper loaded: form_helper
INFO - 2021-01-12 07:21:07 --> Helper loaded: my_helper
INFO - 2021-01-12 07:21:07 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:21:07 --> Controller Class Initialized
DEBUG - 2021-01-12 07:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-12 07:21:07 --> Final output sent to browser
DEBUG - 2021-01-12 07:21:07 --> Total execution time: 0.4656
INFO - 2021-01-12 07:21:20 --> Config Class Initialized
INFO - 2021-01-12 07:21:20 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:21:20 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:21:20 --> Utf8 Class Initialized
INFO - 2021-01-12 07:21:20 --> URI Class Initialized
INFO - 2021-01-12 07:21:20 --> Router Class Initialized
INFO - 2021-01-12 07:21:20 --> Output Class Initialized
INFO - 2021-01-12 07:21:20 --> Security Class Initialized
DEBUG - 2021-01-12 07:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:21:20 --> Input Class Initialized
INFO - 2021-01-12 07:21:20 --> Language Class Initialized
INFO - 2021-01-12 07:21:20 --> Language Class Initialized
INFO - 2021-01-12 07:21:20 --> Config Class Initialized
INFO - 2021-01-12 07:21:20 --> Loader Class Initialized
INFO - 2021-01-12 07:21:20 --> Helper loaded: url_helper
INFO - 2021-01-12 07:21:20 --> Helper loaded: file_helper
INFO - 2021-01-12 07:21:20 --> Helper loaded: form_helper
INFO - 2021-01-12 07:21:20 --> Helper loaded: my_helper
INFO - 2021-01-12 07:21:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:21:20 --> Controller Class Initialized
DEBUG - 2021-01-12 07:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-01-12 07:21:20 --> Final output sent to browser
DEBUG - 2021-01-12 07:21:20 --> Total execution time: 0.4869
INFO - 2021-01-12 07:22:42 --> Config Class Initialized
INFO - 2021-01-12 07:22:42 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:22:42 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:22:42 --> Utf8 Class Initialized
INFO - 2021-01-12 07:22:42 --> URI Class Initialized
INFO - 2021-01-12 07:22:42 --> Router Class Initialized
INFO - 2021-01-12 07:22:42 --> Output Class Initialized
INFO - 2021-01-12 07:22:42 --> Security Class Initialized
DEBUG - 2021-01-12 07:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:22:42 --> Input Class Initialized
INFO - 2021-01-12 07:22:42 --> Language Class Initialized
INFO - 2021-01-12 07:22:42 --> Language Class Initialized
INFO - 2021-01-12 07:22:42 --> Config Class Initialized
INFO - 2021-01-12 07:22:42 --> Loader Class Initialized
INFO - 2021-01-12 07:22:42 --> Helper loaded: url_helper
INFO - 2021-01-12 07:22:42 --> Helper loaded: file_helper
INFO - 2021-01-12 07:22:42 --> Helper loaded: form_helper
INFO - 2021-01-12 07:22:42 --> Helper loaded: my_helper
INFO - 2021-01-12 07:22:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:22:42 --> Controller Class Initialized
INFO - 2021-01-12 07:22:42 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:22:42 --> Config Class Initialized
INFO - 2021-01-12 07:22:42 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:22:42 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:22:42 --> Utf8 Class Initialized
INFO - 2021-01-12 07:22:42 --> URI Class Initialized
INFO - 2021-01-12 07:22:42 --> Router Class Initialized
INFO - 2021-01-12 07:22:42 --> Output Class Initialized
INFO - 2021-01-12 07:22:43 --> Security Class Initialized
DEBUG - 2021-01-12 07:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:22:43 --> Input Class Initialized
INFO - 2021-01-12 07:22:43 --> Language Class Initialized
INFO - 2021-01-12 07:22:43 --> Language Class Initialized
INFO - 2021-01-12 07:22:43 --> Config Class Initialized
INFO - 2021-01-12 07:22:43 --> Loader Class Initialized
INFO - 2021-01-12 07:22:43 --> Helper loaded: url_helper
INFO - 2021-01-12 07:22:43 --> Helper loaded: file_helper
INFO - 2021-01-12 07:22:43 --> Helper loaded: form_helper
INFO - 2021-01-12 07:22:43 --> Helper loaded: my_helper
INFO - 2021-01-12 07:22:43 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:22:43 --> Controller Class Initialized
DEBUG - 2021-01-12 07:22:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:22:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:22:43 --> Final output sent to browser
DEBUG - 2021-01-12 07:22:43 --> Total execution time: 0.4765
INFO - 2021-01-12 07:22:47 --> Config Class Initialized
INFO - 2021-01-12 07:22:47 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:22:47 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:22:47 --> Utf8 Class Initialized
INFO - 2021-01-12 07:22:48 --> URI Class Initialized
INFO - 2021-01-12 07:22:48 --> Router Class Initialized
INFO - 2021-01-12 07:22:48 --> Output Class Initialized
INFO - 2021-01-12 07:22:48 --> Security Class Initialized
DEBUG - 2021-01-12 07:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:22:48 --> Input Class Initialized
INFO - 2021-01-12 07:22:48 --> Language Class Initialized
INFO - 2021-01-12 07:22:48 --> Language Class Initialized
INFO - 2021-01-12 07:22:48 --> Config Class Initialized
INFO - 2021-01-12 07:22:48 --> Loader Class Initialized
INFO - 2021-01-12 07:22:48 --> Helper loaded: url_helper
INFO - 2021-01-12 07:22:48 --> Helper loaded: file_helper
INFO - 2021-01-12 07:22:48 --> Helper loaded: form_helper
INFO - 2021-01-12 07:22:48 --> Helper loaded: my_helper
INFO - 2021-01-12 07:22:48 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:22:48 --> Controller Class Initialized
INFO - 2021-01-12 07:22:48 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:22:48 --> Final output sent to browser
DEBUG - 2021-01-12 07:22:48 --> Total execution time: 0.4734
INFO - 2021-01-12 07:22:48 --> Config Class Initialized
INFO - 2021-01-12 07:22:48 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:22:48 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:22:48 --> Utf8 Class Initialized
INFO - 2021-01-12 07:22:48 --> URI Class Initialized
INFO - 2021-01-12 07:22:48 --> Router Class Initialized
INFO - 2021-01-12 07:22:48 --> Output Class Initialized
INFO - 2021-01-12 07:22:48 --> Security Class Initialized
DEBUG - 2021-01-12 07:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:22:49 --> Input Class Initialized
INFO - 2021-01-12 07:22:49 --> Language Class Initialized
INFO - 2021-01-12 07:22:49 --> Language Class Initialized
INFO - 2021-01-12 07:22:49 --> Config Class Initialized
INFO - 2021-01-12 07:22:49 --> Loader Class Initialized
INFO - 2021-01-12 07:22:49 --> Helper loaded: url_helper
INFO - 2021-01-12 07:22:49 --> Helper loaded: file_helper
INFO - 2021-01-12 07:22:49 --> Helper loaded: form_helper
INFO - 2021-01-12 07:22:49 --> Helper loaded: my_helper
INFO - 2021-01-12 07:22:49 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:22:49 --> Controller Class Initialized
DEBUG - 2021-01-12 07:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 07:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:22:49 --> Final output sent to browser
DEBUG - 2021-01-12 07:22:49 --> Total execution time: 0.5446
INFO - 2021-01-12 07:22:51 --> Config Class Initialized
INFO - 2021-01-12 07:22:51 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:22:51 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:22:51 --> Utf8 Class Initialized
INFO - 2021-01-12 07:22:51 --> URI Class Initialized
INFO - 2021-01-12 07:22:51 --> Router Class Initialized
INFO - 2021-01-12 07:22:51 --> Output Class Initialized
INFO - 2021-01-12 07:22:51 --> Security Class Initialized
DEBUG - 2021-01-12 07:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:22:51 --> Input Class Initialized
INFO - 2021-01-12 07:22:51 --> Language Class Initialized
INFO - 2021-01-12 07:22:51 --> Language Class Initialized
INFO - 2021-01-12 07:22:51 --> Config Class Initialized
INFO - 2021-01-12 07:22:51 --> Loader Class Initialized
INFO - 2021-01-12 07:22:51 --> Helper loaded: url_helper
INFO - 2021-01-12 07:22:51 --> Helper loaded: file_helper
INFO - 2021-01-12 07:22:51 --> Helper loaded: form_helper
INFO - 2021-01-12 07:22:51 --> Helper loaded: my_helper
INFO - 2021-01-12 07:22:51 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:22:51 --> Controller Class Initialized
DEBUG - 2021-01-12 07:22:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 07:22:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:22:51 --> Final output sent to browser
DEBUG - 2021-01-12 07:22:51 --> Total execution time: 0.4325
INFO - 2021-01-12 07:22:57 --> Config Class Initialized
INFO - 2021-01-12 07:22:57 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:22:57 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:22:57 --> Utf8 Class Initialized
INFO - 2021-01-12 07:22:57 --> URI Class Initialized
INFO - 2021-01-12 07:22:57 --> Router Class Initialized
INFO - 2021-01-12 07:22:57 --> Output Class Initialized
INFO - 2021-01-12 07:22:57 --> Security Class Initialized
DEBUG - 2021-01-12 07:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:22:57 --> Input Class Initialized
INFO - 2021-01-12 07:22:57 --> Language Class Initialized
INFO - 2021-01-12 07:22:57 --> Language Class Initialized
INFO - 2021-01-12 07:22:57 --> Config Class Initialized
INFO - 2021-01-12 07:22:57 --> Loader Class Initialized
INFO - 2021-01-12 07:22:57 --> Helper loaded: url_helper
INFO - 2021-01-12 07:22:57 --> Helper loaded: file_helper
INFO - 2021-01-12 07:22:57 --> Helper loaded: form_helper
INFO - 2021-01-12 07:22:57 --> Helper loaded: my_helper
INFO - 2021-01-12 07:22:57 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:22:57 --> Controller Class Initialized
INFO - 2021-01-12 07:22:57 --> Final output sent to browser
DEBUG - 2021-01-12 07:22:57 --> Total execution time: 0.4020
INFO - 2021-01-12 07:22:59 --> Config Class Initialized
INFO - 2021-01-12 07:22:59 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:22:59 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:22:59 --> Utf8 Class Initialized
INFO - 2021-01-12 07:22:59 --> URI Class Initialized
INFO - 2021-01-12 07:22:59 --> Router Class Initialized
INFO - 2021-01-12 07:22:59 --> Output Class Initialized
INFO - 2021-01-12 07:22:59 --> Security Class Initialized
DEBUG - 2021-01-12 07:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:22:59 --> Input Class Initialized
INFO - 2021-01-12 07:22:59 --> Language Class Initialized
INFO - 2021-01-12 07:22:59 --> Language Class Initialized
INFO - 2021-01-12 07:22:59 --> Config Class Initialized
INFO - 2021-01-12 07:22:59 --> Loader Class Initialized
INFO - 2021-01-12 07:22:59 --> Helper loaded: url_helper
INFO - 2021-01-12 07:22:59 --> Helper loaded: file_helper
INFO - 2021-01-12 07:22:59 --> Helper loaded: form_helper
INFO - 2021-01-12 07:22:59 --> Helper loaded: my_helper
INFO - 2021-01-12 07:22:59 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:22:59 --> Controller Class Initialized
DEBUG - 2021-01-12 07:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:23:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:23:00 --> Final output sent to browser
DEBUG - 2021-01-12 07:23:00 --> Total execution time: 0.4031
INFO - 2021-01-12 07:23:04 --> Config Class Initialized
INFO - 2021-01-12 07:23:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:23:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:23:04 --> Utf8 Class Initialized
INFO - 2021-01-12 07:23:04 --> URI Class Initialized
INFO - 2021-01-12 07:23:04 --> Router Class Initialized
INFO - 2021-01-12 07:23:04 --> Output Class Initialized
INFO - 2021-01-12 07:23:04 --> Security Class Initialized
DEBUG - 2021-01-12 07:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:23:04 --> Input Class Initialized
INFO - 2021-01-12 07:23:04 --> Language Class Initialized
INFO - 2021-01-12 07:23:04 --> Language Class Initialized
INFO - 2021-01-12 07:23:04 --> Config Class Initialized
INFO - 2021-01-12 07:23:04 --> Loader Class Initialized
INFO - 2021-01-12 07:23:04 --> Helper loaded: url_helper
INFO - 2021-01-12 07:23:04 --> Helper loaded: file_helper
INFO - 2021-01-12 07:23:04 --> Helper loaded: form_helper
INFO - 2021-01-12 07:23:04 --> Helper loaded: my_helper
INFO - 2021-01-12 07:23:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:23:04 --> Controller Class Initialized
DEBUG - 2021-01-12 07:23:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-12 07:23:05 --> Final output sent to browser
DEBUG - 2021-01-12 07:23:05 --> Total execution time: 0.4924
INFO - 2021-01-12 07:24:23 --> Config Class Initialized
INFO - 2021-01-12 07:24:23 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:24:23 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:24:23 --> Utf8 Class Initialized
INFO - 2021-01-12 07:24:23 --> URI Class Initialized
INFO - 2021-01-12 07:24:23 --> Router Class Initialized
INFO - 2021-01-12 07:24:23 --> Output Class Initialized
INFO - 2021-01-12 07:24:23 --> Security Class Initialized
DEBUG - 2021-01-12 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:24:23 --> Input Class Initialized
INFO - 2021-01-12 07:24:23 --> Language Class Initialized
INFO - 2021-01-12 07:24:23 --> Language Class Initialized
INFO - 2021-01-12 07:24:23 --> Config Class Initialized
INFO - 2021-01-12 07:24:23 --> Loader Class Initialized
INFO - 2021-01-12 07:24:23 --> Helper loaded: url_helper
INFO - 2021-01-12 07:24:23 --> Helper loaded: file_helper
INFO - 2021-01-12 07:24:23 --> Helper loaded: form_helper
INFO - 2021-01-12 07:24:23 --> Helper loaded: my_helper
INFO - 2021-01-12 07:24:23 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:24:23 --> Controller Class Initialized
DEBUG - 2021-01-12 07:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-12 07:24:23 --> Final output sent to browser
DEBUG - 2021-01-12 07:24:23 --> Total execution time: 0.5462
INFO - 2021-01-12 07:25:09 --> Config Class Initialized
INFO - 2021-01-12 07:25:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:25:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:25:09 --> Utf8 Class Initialized
INFO - 2021-01-12 07:25:09 --> URI Class Initialized
INFO - 2021-01-12 07:25:09 --> Router Class Initialized
INFO - 2021-01-12 07:25:09 --> Output Class Initialized
INFO - 2021-01-12 07:25:09 --> Security Class Initialized
DEBUG - 2021-01-12 07:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:25:09 --> Input Class Initialized
INFO - 2021-01-12 07:25:09 --> Language Class Initialized
INFO - 2021-01-12 07:25:09 --> Language Class Initialized
INFO - 2021-01-12 07:25:09 --> Config Class Initialized
INFO - 2021-01-12 07:25:09 --> Loader Class Initialized
INFO - 2021-01-12 07:25:09 --> Helper loaded: url_helper
INFO - 2021-01-12 07:25:09 --> Helper loaded: file_helper
INFO - 2021-01-12 07:25:09 --> Helper loaded: form_helper
INFO - 2021-01-12 07:25:09 --> Helper loaded: my_helper
INFO - 2021-01-12 07:25:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:25:09 --> Controller Class Initialized
DEBUG - 2021-01-12 07:25:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-12 07:25:09 --> Final output sent to browser
DEBUG - 2021-01-12 07:25:09 --> Total execution time: 0.4603
INFO - 2021-01-12 07:26:09 --> Config Class Initialized
INFO - 2021-01-12 07:26:09 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:09 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:09 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:10 --> URI Class Initialized
INFO - 2021-01-12 07:26:10 --> Router Class Initialized
INFO - 2021-01-12 07:26:10 --> Output Class Initialized
INFO - 2021-01-12 07:26:10 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:10 --> Input Class Initialized
INFO - 2021-01-12 07:26:10 --> Language Class Initialized
INFO - 2021-01-12 07:26:10 --> Language Class Initialized
INFO - 2021-01-12 07:26:10 --> Config Class Initialized
INFO - 2021-01-12 07:26:10 --> Loader Class Initialized
INFO - 2021-01-12 07:26:10 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:10 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:10 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:10 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:10 --> Controller Class Initialized
DEBUG - 2021-01-12 07:26:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-01-12 07:26:10 --> Final output sent to browser
DEBUG - 2021-01-12 07:26:10 --> Total execution time: 0.4573
INFO - 2021-01-12 07:26:28 --> Config Class Initialized
INFO - 2021-01-12 07:26:28 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:28 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:28 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:28 --> URI Class Initialized
INFO - 2021-01-12 07:26:28 --> Router Class Initialized
INFO - 2021-01-12 07:26:28 --> Output Class Initialized
INFO - 2021-01-12 07:26:28 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:28 --> Input Class Initialized
INFO - 2021-01-12 07:26:28 --> Language Class Initialized
INFO - 2021-01-12 07:26:28 --> Language Class Initialized
INFO - 2021-01-12 07:26:28 --> Config Class Initialized
INFO - 2021-01-12 07:26:28 --> Loader Class Initialized
INFO - 2021-01-12 07:26:28 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:28 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:28 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:28 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:28 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:28 --> Controller Class Initialized
INFO - 2021-01-12 07:26:28 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:26:29 --> Config Class Initialized
INFO - 2021-01-12 07:26:29 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:29 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:29 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:29 --> URI Class Initialized
INFO - 2021-01-12 07:26:29 --> Router Class Initialized
INFO - 2021-01-12 07:26:29 --> Output Class Initialized
INFO - 2021-01-12 07:26:29 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:29 --> Input Class Initialized
INFO - 2021-01-12 07:26:29 --> Language Class Initialized
INFO - 2021-01-12 07:26:29 --> Language Class Initialized
INFO - 2021-01-12 07:26:29 --> Config Class Initialized
INFO - 2021-01-12 07:26:29 --> Loader Class Initialized
INFO - 2021-01-12 07:26:29 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:29 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:29 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:29 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:29 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:29 --> Controller Class Initialized
DEBUG - 2021-01-12 07:26:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-12 07:26:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:26:29 --> Final output sent to browser
DEBUG - 2021-01-12 07:26:29 --> Total execution time: 0.5022
INFO - 2021-01-12 07:26:36 --> Config Class Initialized
INFO - 2021-01-12 07:26:36 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:36 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:36 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:36 --> URI Class Initialized
INFO - 2021-01-12 07:26:36 --> Router Class Initialized
INFO - 2021-01-12 07:26:36 --> Output Class Initialized
INFO - 2021-01-12 07:26:36 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:36 --> Input Class Initialized
INFO - 2021-01-12 07:26:36 --> Language Class Initialized
INFO - 2021-01-12 07:26:36 --> Language Class Initialized
INFO - 2021-01-12 07:26:36 --> Config Class Initialized
INFO - 2021-01-12 07:26:36 --> Loader Class Initialized
INFO - 2021-01-12 07:26:36 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:36 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:36 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:36 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:36 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:36 --> Controller Class Initialized
INFO - 2021-01-12 07:26:36 --> Helper loaded: cookie_helper
INFO - 2021-01-12 07:26:36 --> Final output sent to browser
DEBUG - 2021-01-12 07:26:36 --> Total execution time: 0.4834
INFO - 2021-01-12 07:26:37 --> Config Class Initialized
INFO - 2021-01-12 07:26:37 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:37 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:37 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:37 --> URI Class Initialized
INFO - 2021-01-12 07:26:37 --> Router Class Initialized
INFO - 2021-01-12 07:26:37 --> Output Class Initialized
INFO - 2021-01-12 07:26:37 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:37 --> Input Class Initialized
INFO - 2021-01-12 07:26:37 --> Language Class Initialized
INFO - 2021-01-12 07:26:37 --> Language Class Initialized
INFO - 2021-01-12 07:26:37 --> Config Class Initialized
INFO - 2021-01-12 07:26:37 --> Loader Class Initialized
INFO - 2021-01-12 07:26:37 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:37 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:37 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:37 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:37 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:37 --> Controller Class Initialized
DEBUG - 2021-01-12 07:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 07:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:26:37 --> Final output sent to browser
DEBUG - 2021-01-12 07:26:38 --> Total execution time: 0.5637
INFO - 2021-01-12 07:26:40 --> Config Class Initialized
INFO - 2021-01-12 07:26:40 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:40 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:40 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:40 --> URI Class Initialized
INFO - 2021-01-12 07:26:40 --> Router Class Initialized
INFO - 2021-01-12 07:26:40 --> Output Class Initialized
INFO - 2021-01-12 07:26:40 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:40 --> Input Class Initialized
INFO - 2021-01-12 07:26:40 --> Language Class Initialized
INFO - 2021-01-12 07:26:40 --> Language Class Initialized
INFO - 2021-01-12 07:26:40 --> Config Class Initialized
INFO - 2021-01-12 07:26:40 --> Loader Class Initialized
INFO - 2021-01-12 07:26:40 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:40 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:40 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:40 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:40 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:40 --> Controller Class Initialized
DEBUG - 2021-01-12 07:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-12 07:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:26:41 --> Final output sent to browser
DEBUG - 2021-01-12 07:26:41 --> Total execution time: 0.4556
INFO - 2021-01-12 07:26:47 --> Config Class Initialized
INFO - 2021-01-12 07:26:47 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:47 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:47 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:47 --> URI Class Initialized
INFO - 2021-01-12 07:26:47 --> Router Class Initialized
INFO - 2021-01-12 07:26:47 --> Output Class Initialized
INFO - 2021-01-12 07:26:47 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:47 --> Input Class Initialized
INFO - 2021-01-12 07:26:47 --> Language Class Initialized
INFO - 2021-01-12 07:26:47 --> Language Class Initialized
INFO - 2021-01-12 07:26:47 --> Config Class Initialized
INFO - 2021-01-12 07:26:47 --> Loader Class Initialized
INFO - 2021-01-12 07:26:47 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:47 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:47 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:47 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:47 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:47 --> Controller Class Initialized
INFO - 2021-01-12 07:26:47 --> Final output sent to browser
DEBUG - 2021-01-12 07:26:47 --> Total execution time: 0.4027
INFO - 2021-01-12 07:26:50 --> Config Class Initialized
INFO - 2021-01-12 07:26:50 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:50 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:50 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:50 --> URI Class Initialized
INFO - 2021-01-12 07:26:50 --> Router Class Initialized
INFO - 2021-01-12 07:26:50 --> Output Class Initialized
INFO - 2021-01-12 07:26:51 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:51 --> Input Class Initialized
INFO - 2021-01-12 07:26:51 --> Language Class Initialized
INFO - 2021-01-12 07:26:51 --> Language Class Initialized
INFO - 2021-01-12 07:26:51 --> Config Class Initialized
INFO - 2021-01-12 07:26:51 --> Loader Class Initialized
INFO - 2021-01-12 07:26:51 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:51 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:51 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:51 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:51 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:51 --> Controller Class Initialized
DEBUG - 2021-01-12 07:26:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:26:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:26:51 --> Final output sent to browser
DEBUG - 2021-01-12 07:26:51 --> Total execution time: 0.4134
INFO - 2021-01-12 07:26:53 --> Config Class Initialized
INFO - 2021-01-12 07:26:53 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:26:53 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:26:53 --> Utf8 Class Initialized
INFO - 2021-01-12 07:26:53 --> URI Class Initialized
INFO - 2021-01-12 07:26:53 --> Router Class Initialized
INFO - 2021-01-12 07:26:53 --> Output Class Initialized
INFO - 2021-01-12 07:26:53 --> Security Class Initialized
DEBUG - 2021-01-12 07:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:26:53 --> Input Class Initialized
INFO - 2021-01-12 07:26:53 --> Language Class Initialized
INFO - 2021-01-12 07:26:53 --> Language Class Initialized
INFO - 2021-01-12 07:26:53 --> Config Class Initialized
INFO - 2021-01-12 07:26:53 --> Loader Class Initialized
INFO - 2021-01-12 07:26:53 --> Helper loaded: url_helper
INFO - 2021-01-12 07:26:53 --> Helper loaded: file_helper
INFO - 2021-01-12 07:26:53 --> Helper loaded: form_helper
INFO - 2021-01-12 07:26:53 --> Helper loaded: my_helper
INFO - 2021-01-12 07:26:53 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:26:53 --> Controller Class Initialized
DEBUG - 2021-01-12 07:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-12 07:26:53 --> Final output sent to browser
DEBUG - 2021-01-12 07:26:53 --> Total execution time: 0.4371
INFO - 2021-01-12 07:27:10 --> Config Class Initialized
INFO - 2021-01-12 07:27:10 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:27:10 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:27:10 --> Utf8 Class Initialized
INFO - 2021-01-12 07:27:10 --> URI Class Initialized
INFO - 2021-01-12 07:27:10 --> Router Class Initialized
INFO - 2021-01-12 07:27:10 --> Output Class Initialized
INFO - 2021-01-12 07:27:10 --> Security Class Initialized
DEBUG - 2021-01-12 07:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:27:10 --> Input Class Initialized
INFO - 2021-01-12 07:27:10 --> Language Class Initialized
INFO - 2021-01-12 07:27:10 --> Language Class Initialized
INFO - 2021-01-12 07:27:10 --> Config Class Initialized
INFO - 2021-01-12 07:27:10 --> Loader Class Initialized
INFO - 2021-01-12 07:27:10 --> Helper loaded: url_helper
INFO - 2021-01-12 07:27:10 --> Helper loaded: file_helper
INFO - 2021-01-12 07:27:10 --> Helper loaded: form_helper
INFO - 2021-01-12 07:27:10 --> Helper loaded: my_helper
INFO - 2021-01-12 07:27:10 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:27:10 --> Controller Class Initialized
DEBUG - 2021-01-12 07:27:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-12 07:27:11 --> Final output sent to browser
DEBUG - 2021-01-12 07:27:11 --> Total execution time: 0.4765
INFO - 2021-01-12 07:27:33 --> Config Class Initialized
INFO - 2021-01-12 07:27:33 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:27:33 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:27:33 --> Utf8 Class Initialized
INFO - 2021-01-12 07:27:33 --> URI Class Initialized
INFO - 2021-01-12 07:27:33 --> Router Class Initialized
INFO - 2021-01-12 07:27:33 --> Output Class Initialized
INFO - 2021-01-12 07:27:33 --> Security Class Initialized
DEBUG - 2021-01-12 07:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:27:33 --> Input Class Initialized
INFO - 2021-01-12 07:27:33 --> Language Class Initialized
INFO - 2021-01-12 07:27:33 --> Language Class Initialized
INFO - 2021-01-12 07:27:33 --> Config Class Initialized
INFO - 2021-01-12 07:27:33 --> Loader Class Initialized
INFO - 2021-01-12 07:27:34 --> Helper loaded: url_helper
INFO - 2021-01-12 07:27:34 --> Helper loaded: file_helper
INFO - 2021-01-12 07:27:34 --> Helper loaded: form_helper
INFO - 2021-01-12 07:27:34 --> Helper loaded: my_helper
INFO - 2021-01-12 07:27:34 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:27:34 --> Controller Class Initialized
DEBUG - 2021-01-12 07:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-12 07:27:34 --> Final output sent to browser
DEBUG - 2021-01-12 07:27:34 --> Total execution time: 0.4931
INFO - 2021-01-12 07:29:34 --> Config Class Initialized
INFO - 2021-01-12 07:29:34 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:29:34 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:29:34 --> Utf8 Class Initialized
INFO - 2021-01-12 07:29:34 --> URI Class Initialized
INFO - 2021-01-12 07:29:35 --> Router Class Initialized
INFO - 2021-01-12 07:29:35 --> Output Class Initialized
INFO - 2021-01-12 07:29:35 --> Security Class Initialized
DEBUG - 2021-01-12 07:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:29:35 --> Input Class Initialized
INFO - 2021-01-12 07:29:35 --> Language Class Initialized
INFO - 2021-01-12 07:29:35 --> Language Class Initialized
INFO - 2021-01-12 07:29:35 --> Config Class Initialized
INFO - 2021-01-12 07:29:35 --> Loader Class Initialized
INFO - 2021-01-12 07:29:35 --> Helper loaded: url_helper
INFO - 2021-01-12 07:29:35 --> Helper loaded: file_helper
INFO - 2021-01-12 07:29:35 --> Helper loaded: form_helper
INFO - 2021-01-12 07:29:35 --> Helper loaded: my_helper
INFO - 2021-01-12 07:29:35 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:29:35 --> Controller Class Initialized
DEBUG - 2021-01-12 07:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-12 07:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:29:35 --> Final output sent to browser
DEBUG - 2021-01-12 07:29:35 --> Total execution time: 0.4722
INFO - 2021-01-12 07:29:42 --> Config Class Initialized
INFO - 2021-01-12 07:29:42 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:29:42 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:29:42 --> Utf8 Class Initialized
INFO - 2021-01-12 07:29:42 --> URI Class Initialized
INFO - 2021-01-12 07:29:42 --> Router Class Initialized
INFO - 2021-01-12 07:29:42 --> Output Class Initialized
INFO - 2021-01-12 07:29:42 --> Security Class Initialized
DEBUG - 2021-01-12 07:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:29:42 --> Input Class Initialized
INFO - 2021-01-12 07:29:42 --> Language Class Initialized
INFO - 2021-01-12 07:29:42 --> Language Class Initialized
INFO - 2021-01-12 07:29:42 --> Config Class Initialized
INFO - 2021-01-12 07:29:42 --> Loader Class Initialized
INFO - 2021-01-12 07:29:42 --> Helper loaded: url_helper
INFO - 2021-01-12 07:29:42 --> Helper loaded: file_helper
INFO - 2021-01-12 07:29:42 --> Helper loaded: form_helper
INFO - 2021-01-12 07:29:42 --> Helper loaded: my_helper
INFO - 2021-01-12 07:29:42 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:29:42 --> Controller Class Initialized
DEBUG - 2021-01-12 07:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-12 07:29:42 --> Final output sent to browser
DEBUG - 2021-01-12 07:29:42 --> Total execution time: 0.4429
INFO - 2021-01-12 07:47:44 --> Config Class Initialized
INFO - 2021-01-12 07:47:44 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:47:44 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:47:44 --> Utf8 Class Initialized
INFO - 2021-01-12 07:47:44 --> URI Class Initialized
INFO - 2021-01-12 07:47:44 --> Router Class Initialized
INFO - 2021-01-12 07:47:44 --> Output Class Initialized
INFO - 2021-01-12 07:47:45 --> Security Class Initialized
DEBUG - 2021-01-12 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:47:45 --> Input Class Initialized
INFO - 2021-01-12 07:47:45 --> Language Class Initialized
INFO - 2021-01-12 07:47:45 --> Language Class Initialized
INFO - 2021-01-12 07:47:45 --> Config Class Initialized
INFO - 2021-01-12 07:47:45 --> Loader Class Initialized
INFO - 2021-01-12 07:47:45 --> Helper loaded: url_helper
INFO - 2021-01-12 07:47:45 --> Helper loaded: file_helper
INFO - 2021-01-12 07:47:45 --> Helper loaded: form_helper
INFO - 2021-01-12 07:47:45 --> Helper loaded: my_helper
INFO - 2021-01-12 07:47:45 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:47:45 --> Controller Class Initialized
DEBUG - 2021-01-12 07:47:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2021-01-12 07:47:45 --> Final output sent to browser
DEBUG - 2021-01-12 07:47:45 --> Total execution time: 1.1747
INFO - 2021-01-12 07:51:02 --> Config Class Initialized
INFO - 2021-01-12 07:51:02 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:51:02 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:51:02 --> Utf8 Class Initialized
INFO - 2021-01-12 07:51:02 --> URI Class Initialized
INFO - 2021-01-12 07:51:02 --> Router Class Initialized
INFO - 2021-01-12 07:51:02 --> Output Class Initialized
INFO - 2021-01-12 07:51:02 --> Security Class Initialized
DEBUG - 2021-01-12 07:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:51:03 --> Input Class Initialized
INFO - 2021-01-12 07:51:03 --> Language Class Initialized
INFO - 2021-01-12 07:51:03 --> Language Class Initialized
INFO - 2021-01-12 07:51:03 --> Config Class Initialized
INFO - 2021-01-12 07:51:03 --> Loader Class Initialized
INFO - 2021-01-12 07:51:03 --> Helper loaded: url_helper
INFO - 2021-01-12 07:51:03 --> Helper loaded: file_helper
INFO - 2021-01-12 07:51:03 --> Helper loaded: form_helper
INFO - 2021-01-12 07:51:03 --> Helper loaded: my_helper
INFO - 2021-01-12 07:51:03 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:51:03 --> Controller Class Initialized
DEBUG - 2021-01-12 07:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:51:03 --> Final output sent to browser
DEBUG - 2021-01-12 07:51:03 --> Total execution time: 1.3024
INFO - 2021-01-12 07:51:05 --> Config Class Initialized
INFO - 2021-01-12 07:51:05 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:51:05 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:51:05 --> Utf8 Class Initialized
INFO - 2021-01-12 07:51:05 --> URI Class Initialized
DEBUG - 2021-01-12 07:51:05 --> No URI present. Default controller set.
INFO - 2021-01-12 07:51:05 --> Router Class Initialized
INFO - 2021-01-12 07:51:05 --> Output Class Initialized
INFO - 2021-01-12 07:51:05 --> Security Class Initialized
DEBUG - 2021-01-12 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:51:05 --> Input Class Initialized
INFO - 2021-01-12 07:51:05 --> Language Class Initialized
INFO - 2021-01-12 07:51:05 --> Language Class Initialized
INFO - 2021-01-12 07:51:06 --> Config Class Initialized
INFO - 2021-01-12 07:51:06 --> Loader Class Initialized
INFO - 2021-01-12 07:51:06 --> Helper loaded: url_helper
INFO - 2021-01-12 07:51:06 --> Helper loaded: file_helper
INFO - 2021-01-12 07:51:06 --> Helper loaded: form_helper
INFO - 2021-01-12 07:51:06 --> Helper loaded: my_helper
INFO - 2021-01-12 07:51:06 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:51:06 --> Controller Class Initialized
DEBUG - 2021-01-12 07:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-12 07:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:51:06 --> Final output sent to browser
DEBUG - 2021-01-12 07:51:06 --> Total execution time: 1.6207
INFO - 2021-01-12 07:51:08 --> Config Class Initialized
INFO - 2021-01-12 07:51:08 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:51:08 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:51:08 --> Utf8 Class Initialized
INFO - 2021-01-12 07:51:08 --> URI Class Initialized
INFO - 2021-01-12 07:51:08 --> Router Class Initialized
INFO - 2021-01-12 07:51:08 --> Output Class Initialized
INFO - 2021-01-12 07:51:08 --> Security Class Initialized
DEBUG - 2021-01-12 07:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:51:08 --> Input Class Initialized
INFO - 2021-01-12 07:51:08 --> Language Class Initialized
INFO - 2021-01-12 07:51:08 --> Language Class Initialized
INFO - 2021-01-12 07:51:08 --> Config Class Initialized
INFO - 2021-01-12 07:51:08 --> Loader Class Initialized
INFO - 2021-01-12 07:51:08 --> Helper loaded: url_helper
INFO - 2021-01-12 07:51:08 --> Helper loaded: file_helper
INFO - 2021-01-12 07:51:08 --> Helper loaded: form_helper
INFO - 2021-01-12 07:51:09 --> Helper loaded: my_helper
INFO - 2021-01-12 07:51:09 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:51:09 --> Controller Class Initialized
DEBUG - 2021-01-12 07:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:51:09 --> Final output sent to browser
DEBUG - 2021-01-12 07:51:09 --> Total execution time: 1.3575
INFO - 2021-01-12 07:51:13 --> Config Class Initialized
INFO - 2021-01-12 07:51:13 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:51:13 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:51:13 --> Utf8 Class Initialized
INFO - 2021-01-12 07:51:13 --> URI Class Initialized
INFO - 2021-01-12 07:51:13 --> Router Class Initialized
INFO - 2021-01-12 07:51:13 --> Output Class Initialized
INFO - 2021-01-12 07:51:13 --> Security Class Initialized
DEBUG - 2021-01-12 07:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:51:13 --> Input Class Initialized
INFO - 2021-01-12 07:51:13 --> Language Class Initialized
INFO - 2021-01-12 07:51:13 --> Language Class Initialized
INFO - 2021-01-12 07:51:14 --> Config Class Initialized
INFO - 2021-01-12 07:51:14 --> Loader Class Initialized
INFO - 2021-01-12 07:51:14 --> Helper loaded: url_helper
INFO - 2021-01-12 07:51:14 --> Helper loaded: file_helper
INFO - 2021-01-12 07:51:14 --> Helper loaded: form_helper
INFO - 2021-01-12 07:51:14 --> Helper loaded: my_helper
INFO - 2021-01-12 07:51:14 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:51:14 --> Controller Class Initialized
DEBUG - 2021-01-12 07:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-01-12 07:51:14 --> Final output sent to browser
DEBUG - 2021-01-12 07:51:14 --> Total execution time: 1.2879
INFO - 2021-01-12 07:52:03 --> Config Class Initialized
INFO - 2021-01-12 07:52:04 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:52:04 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:52:04 --> Utf8 Class Initialized
INFO - 2021-01-12 07:52:04 --> URI Class Initialized
INFO - 2021-01-12 07:52:04 --> Router Class Initialized
INFO - 2021-01-12 07:52:04 --> Output Class Initialized
INFO - 2021-01-12 07:52:04 --> Security Class Initialized
DEBUG - 2021-01-12 07:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:52:04 --> Input Class Initialized
INFO - 2021-01-12 07:52:04 --> Language Class Initialized
INFO - 2021-01-12 07:52:04 --> Language Class Initialized
INFO - 2021-01-12 07:52:04 --> Config Class Initialized
INFO - 2021-01-12 07:52:04 --> Loader Class Initialized
INFO - 2021-01-12 07:52:04 --> Helper loaded: url_helper
INFO - 2021-01-12 07:52:04 --> Helper loaded: file_helper
INFO - 2021-01-12 07:52:04 --> Helper loaded: form_helper
INFO - 2021-01-12 07:52:04 --> Helper loaded: my_helper
INFO - 2021-01-12 07:52:04 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:52:05 --> Controller Class Initialized
DEBUG - 2021-01-12 07:52:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-12 07:52:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:52:05 --> Final output sent to browser
DEBUG - 2021-01-12 07:52:05 --> Total execution time: 1.4085
INFO - 2021-01-12 07:52:14 --> Config Class Initialized
INFO - 2021-01-12 07:52:14 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:52:14 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:52:14 --> Utf8 Class Initialized
INFO - 2021-01-12 07:52:14 --> URI Class Initialized
INFO - 2021-01-12 07:52:14 --> Router Class Initialized
INFO - 2021-01-12 07:52:14 --> Output Class Initialized
INFO - 2021-01-12 07:52:14 --> Security Class Initialized
DEBUG - 2021-01-12 07:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:52:15 --> Input Class Initialized
INFO - 2021-01-12 07:52:15 --> Language Class Initialized
INFO - 2021-01-12 07:52:15 --> Language Class Initialized
INFO - 2021-01-12 07:52:15 --> Config Class Initialized
INFO - 2021-01-12 07:52:15 --> Loader Class Initialized
INFO - 2021-01-12 07:52:15 --> Helper loaded: url_helper
INFO - 2021-01-12 07:52:15 --> Helper loaded: file_helper
INFO - 2021-01-12 07:52:15 --> Helper loaded: form_helper
INFO - 2021-01-12 07:52:15 --> Helper loaded: my_helper
INFO - 2021-01-12 07:52:15 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:52:15 --> Controller Class Initialized
DEBUG - 2021-01-12 07:52:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-12 07:52:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:52:15 --> Final output sent to browser
DEBUG - 2021-01-12 07:52:15 --> Total execution time: 1.1438
INFO - 2021-01-12 07:52:19 --> Config Class Initialized
INFO - 2021-01-12 07:52:19 --> Hooks Class Initialized
DEBUG - 2021-01-12 07:52:19 --> UTF-8 Support Enabled
INFO - 2021-01-12 07:52:19 --> Utf8 Class Initialized
INFO - 2021-01-12 07:52:19 --> URI Class Initialized
INFO - 2021-01-12 07:52:19 --> Router Class Initialized
INFO - 2021-01-12 07:52:19 --> Output Class Initialized
INFO - 2021-01-12 07:52:19 --> Security Class Initialized
DEBUG - 2021-01-12 07:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-12 07:52:20 --> Input Class Initialized
INFO - 2021-01-12 07:52:20 --> Language Class Initialized
INFO - 2021-01-12 07:52:20 --> Language Class Initialized
INFO - 2021-01-12 07:52:20 --> Config Class Initialized
INFO - 2021-01-12 07:52:20 --> Loader Class Initialized
INFO - 2021-01-12 07:52:20 --> Helper loaded: url_helper
INFO - 2021-01-12 07:52:20 --> Helper loaded: file_helper
INFO - 2021-01-12 07:52:20 --> Helper loaded: form_helper
INFO - 2021-01-12 07:52:20 --> Helper loaded: my_helper
INFO - 2021-01-12 07:52:20 --> Database Driver Class Initialized
DEBUG - 2021-01-12 07:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-12 07:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-12 07:52:20 --> Controller Class Initialized
DEBUG - 2021-01-12 07:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-12 07:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-12 07:52:20 --> Final output sent to browser
DEBUG - 2021-01-12 07:52:20 --> Total execution time: 1.3477
