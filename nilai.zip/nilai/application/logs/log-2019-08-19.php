<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-19 07:46:48 --> Config Class Initialized
INFO - 2019-08-19 07:46:48 --> Hooks Class Initialized
DEBUG - 2019-08-19 07:46:48 --> UTF-8 Support Enabled
INFO - 2019-08-19 07:46:48 --> Utf8 Class Initialized
INFO - 2019-08-19 07:46:48 --> URI Class Initialized
INFO - 2019-08-19 07:46:48 --> Router Class Initialized
INFO - 2019-08-19 07:46:48 --> Output Class Initialized
INFO - 2019-08-19 07:46:48 --> Security Class Initialized
DEBUG - 2019-08-19 07:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 07:46:48 --> Input Class Initialized
INFO - 2019-08-19 07:46:48 --> Language Class Initialized
INFO - 2019-08-19 07:46:48 --> Language Class Initialized
INFO - 2019-08-19 07:46:48 --> Config Class Initialized
INFO - 2019-08-19 07:46:48 --> Loader Class Initialized
INFO - 2019-08-19 07:46:48 --> Helper loaded: url_helper
INFO - 2019-08-19 07:46:48 --> Helper loaded: file_helper
INFO - 2019-08-19 07:46:48 --> Helper loaded: form_helper
INFO - 2019-08-19 07:46:48 --> Helper loaded: my_helper
INFO - 2019-08-19 07:46:48 --> Database Driver Class Initialized
DEBUG - 2019-08-19 07:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 07:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 07:46:48 --> Controller Class Initialized
DEBUG - 2019-08-19 07:46:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2019-08-19 07:46:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-08-19 07:46:48 --> Final output sent to browser
DEBUG - 2019-08-19 07:46:48 --> Total execution time: 0.0668
INFO - 2019-08-19 07:46:49 --> Config Class Initialized
INFO - 2019-08-19 07:46:49 --> Hooks Class Initialized
DEBUG - 2019-08-19 07:46:49 --> UTF-8 Support Enabled
INFO - 2019-08-19 07:46:49 --> Utf8 Class Initialized
INFO - 2019-08-19 07:46:49 --> URI Class Initialized
INFO - 2019-08-19 07:46:49 --> Router Class Initialized
INFO - 2019-08-19 07:46:49 --> Output Class Initialized
INFO - 2019-08-19 07:46:49 --> Security Class Initialized
DEBUG - 2019-08-19 07:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 07:46:49 --> Input Class Initialized
INFO - 2019-08-19 07:46:49 --> Language Class Initialized
INFO - 2019-08-19 07:46:49 --> Language Class Initialized
INFO - 2019-08-19 07:46:49 --> Config Class Initialized
INFO - 2019-08-19 07:46:49 --> Loader Class Initialized
INFO - 2019-08-19 07:46:49 --> Helper loaded: url_helper
INFO - 2019-08-19 07:46:49 --> Helper loaded: file_helper
INFO - 2019-08-19 07:46:49 --> Helper loaded: form_helper
INFO - 2019-08-19 07:46:49 --> Helper loaded: my_helper
INFO - 2019-08-19 07:46:49 --> Database Driver Class Initialized
DEBUG - 2019-08-19 07:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 07:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 07:46:49 --> Controller Class Initialized
DEBUG - 2019-08-19 07:46:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2019-08-19 07:46:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-08-19 07:46:49 --> Final output sent to browser
DEBUG - 2019-08-19 07:46:49 --> Total execution time: 0.0642
INFO - 2019-08-19 07:46:50 --> Config Class Initialized
INFO - 2019-08-19 07:46:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 07:46:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 07:46:50 --> Utf8 Class Initialized
INFO - 2019-08-19 07:46:50 --> URI Class Initialized
INFO - 2019-08-19 07:46:50 --> Router Class Initialized
INFO - 2019-08-19 07:46:50 --> Output Class Initialized
INFO - 2019-08-19 07:46:50 --> Security Class Initialized
DEBUG - 2019-08-19 07:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 07:46:50 --> Input Class Initialized
INFO - 2019-08-19 07:46:50 --> Language Class Initialized
INFO - 2019-08-19 07:46:50 --> Language Class Initialized
INFO - 2019-08-19 07:46:50 --> Config Class Initialized
INFO - 2019-08-19 07:46:50 --> Loader Class Initialized
INFO - 2019-08-19 07:46:50 --> Helper loaded: url_helper
INFO - 2019-08-19 07:46:50 --> Helper loaded: file_helper
INFO - 2019-08-19 07:46:50 --> Helper loaded: form_helper
INFO - 2019-08-19 07:46:50 --> Helper loaded: my_helper
INFO - 2019-08-19 07:46:50 --> Database Driver Class Initialized
DEBUG - 2019-08-19 07:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 07:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 07:46:50 --> Controller Class Initialized
DEBUG - 2019-08-19 07:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-08-19 07:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-08-19 07:46:50 --> Final output sent to browser
DEBUG - 2019-08-19 07:46:50 --> Total execution time: 0.0831
INFO - 2019-08-19 07:46:52 --> Config Class Initialized
INFO - 2019-08-19 07:46:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 07:46:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 07:46:52 --> Utf8 Class Initialized
INFO - 2019-08-19 07:46:52 --> URI Class Initialized
INFO - 2019-08-19 07:46:52 --> Router Class Initialized
INFO - 2019-08-19 07:46:52 --> Output Class Initialized
INFO - 2019-08-19 07:46:52 --> Security Class Initialized
DEBUG - 2019-08-19 07:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 07:46:52 --> Input Class Initialized
INFO - 2019-08-19 07:46:52 --> Language Class Initialized
INFO - 2019-08-19 07:46:52 --> Language Class Initialized
INFO - 2019-08-19 07:46:52 --> Config Class Initialized
INFO - 2019-08-19 07:46:52 --> Loader Class Initialized
INFO - 2019-08-19 07:46:52 --> Helper loaded: url_helper
INFO - 2019-08-19 07:46:52 --> Helper loaded: file_helper
INFO - 2019-08-19 07:46:52 --> Helper loaded: form_helper
INFO - 2019-08-19 07:46:52 --> Helper loaded: my_helper
INFO - 2019-08-19 07:46:52 --> Database Driver Class Initialized
DEBUG - 2019-08-19 07:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 07:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 07:46:52 --> Controller Class Initialized
DEBUG - 2019-08-19 07:46:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-08-19 07:46:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-08-19 07:46:52 --> Final output sent to browser
DEBUG - 2019-08-19 07:46:52 --> Total execution time: 0.0770
INFO - 2019-08-19 07:46:52 --> Config Class Initialized
INFO - 2019-08-19 07:46:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 07:46:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 07:46:52 --> Utf8 Class Initialized
INFO - 2019-08-19 07:46:52 --> URI Class Initialized
INFO - 2019-08-19 07:46:52 --> Router Class Initialized
INFO - 2019-08-19 07:46:52 --> Output Class Initialized
INFO - 2019-08-19 07:46:52 --> Security Class Initialized
DEBUG - 2019-08-19 07:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 07:46:52 --> Input Class Initialized
INFO - 2019-08-19 07:46:52 --> Language Class Initialized
INFO - 2019-08-19 07:46:52 --> Language Class Initialized
INFO - 2019-08-19 07:46:52 --> Config Class Initialized
INFO - 2019-08-19 07:46:52 --> Loader Class Initialized
INFO - 2019-08-19 07:46:52 --> Helper loaded: url_helper
INFO - 2019-08-19 07:46:52 --> Helper loaded: file_helper
INFO - 2019-08-19 07:46:52 --> Helper loaded: form_helper
INFO - 2019-08-19 07:46:52 --> Helper loaded: my_helper
INFO - 2019-08-19 07:46:52 --> Database Driver Class Initialized
DEBUG - 2019-08-19 07:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 07:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 07:46:52 --> Controller Class Initialized
DEBUG - 2019-08-19 07:46:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-08-19 07:46:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-08-19 07:46:52 --> Final output sent to browser
DEBUG - 2019-08-19 07:46:52 --> Total execution time: 0.0824
INFO - 2019-08-19 07:46:54 --> Config Class Initialized
INFO - 2019-08-19 07:46:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 07:46:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 07:46:54 --> Utf8 Class Initialized
INFO - 2019-08-19 07:46:54 --> URI Class Initialized
INFO - 2019-08-19 07:46:54 --> Router Class Initialized
INFO - 2019-08-19 07:46:54 --> Output Class Initialized
INFO - 2019-08-19 07:46:54 --> Security Class Initialized
DEBUG - 2019-08-19 07:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 07:46:54 --> Input Class Initialized
INFO - 2019-08-19 07:46:54 --> Language Class Initialized
INFO - 2019-08-19 07:46:54 --> Language Class Initialized
INFO - 2019-08-19 07:46:54 --> Config Class Initialized
INFO - 2019-08-19 07:46:54 --> Loader Class Initialized
INFO - 2019-08-19 07:46:54 --> Helper loaded: url_helper
INFO - 2019-08-19 07:46:54 --> Helper loaded: file_helper
INFO - 2019-08-19 07:46:54 --> Helper loaded: form_helper
INFO - 2019-08-19 07:46:54 --> Helper loaded: my_helper
INFO - 2019-08-19 07:46:54 --> Database Driver Class Initialized
DEBUG - 2019-08-19 07:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 07:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 07:46:54 --> Controller Class Initialized
DEBUG - 2019-08-19 07:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2019-08-19 07:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-08-19 07:46:54 --> Final output sent to browser
DEBUG - 2019-08-19 07:46:54 --> Total execution time: 0.0693
INFO - 2019-08-19 07:46:57 --> Config Class Initialized
INFO - 2019-08-19 07:46:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 07:46:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 07:46:57 --> Utf8 Class Initialized
INFO - 2019-08-19 07:46:57 --> URI Class Initialized
INFO - 2019-08-19 07:46:57 --> Router Class Initialized
INFO - 2019-08-19 07:46:57 --> Output Class Initialized
INFO - 2019-08-19 07:46:57 --> Security Class Initialized
DEBUG - 2019-08-19 07:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 07:46:57 --> Input Class Initialized
INFO - 2019-08-19 07:46:57 --> Language Class Initialized
INFO - 2019-08-19 07:46:57 --> Language Class Initialized
INFO - 2019-08-19 07:46:57 --> Config Class Initialized
INFO - 2019-08-19 07:46:57 --> Loader Class Initialized
INFO - 2019-08-19 07:46:57 --> Helper loaded: url_helper
INFO - 2019-08-19 07:46:57 --> Helper loaded: file_helper
INFO - 2019-08-19 07:46:57 --> Helper loaded: form_helper
INFO - 2019-08-19 07:46:57 --> Helper loaded: my_helper
INFO - 2019-08-19 07:46:57 --> Database Driver Class Initialized
DEBUG - 2019-08-19 07:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 07:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 07:46:57 --> Controller Class Initialized
DEBUG - 2019-08-19 07:46:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-08-19 07:46:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-08-19 07:46:57 --> Final output sent to browser
DEBUG - 2019-08-19 07:46:57 --> Total execution time: 0.0719
