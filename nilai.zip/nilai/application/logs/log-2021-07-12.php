<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-12 03:27:44 --> Config Class Initialized
INFO - 2021-07-12 03:27:44 --> Hooks Class Initialized
DEBUG - 2021-07-12 03:27:44 --> UTF-8 Support Enabled
INFO - 2021-07-12 03:27:44 --> Utf8 Class Initialized
INFO - 2021-07-12 03:27:44 --> URI Class Initialized
DEBUG - 2021-07-12 03:27:44 --> No URI present. Default controller set.
INFO - 2021-07-12 03:27:44 --> Router Class Initialized
INFO - 2021-07-12 03:27:44 --> Output Class Initialized
INFO - 2021-07-12 03:27:44 --> Security Class Initialized
DEBUG - 2021-07-12 03:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 03:27:44 --> Input Class Initialized
INFO - 2021-07-12 03:27:44 --> Language Class Initialized
INFO - 2021-07-12 03:27:44 --> Language Class Initialized
INFO - 2021-07-12 03:27:44 --> Config Class Initialized
INFO - 2021-07-12 03:27:44 --> Loader Class Initialized
INFO - 2021-07-12 03:27:44 --> Helper loaded: url_helper
INFO - 2021-07-12 03:27:44 --> Helper loaded: file_helper
INFO - 2021-07-12 03:27:44 --> Helper loaded: form_helper
INFO - 2021-07-12 03:27:44 --> Helper loaded: my_helper
INFO - 2021-07-12 03:27:44 --> Database Driver Class Initialized
DEBUG - 2021-07-12 03:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 03:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 03:27:44 --> Controller Class Initialized
INFO - 2021-07-12 03:27:44 --> Config Class Initialized
INFO - 2021-07-12 03:27:44 --> Hooks Class Initialized
DEBUG - 2021-07-12 03:27:44 --> UTF-8 Support Enabled
INFO - 2021-07-12 03:27:44 --> Utf8 Class Initialized
INFO - 2021-07-12 03:27:44 --> URI Class Initialized
INFO - 2021-07-12 03:27:44 --> Router Class Initialized
INFO - 2021-07-12 03:27:44 --> Output Class Initialized
INFO - 2021-07-12 03:27:44 --> Security Class Initialized
DEBUG - 2021-07-12 03:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 03:27:44 --> Input Class Initialized
INFO - 2021-07-12 03:27:44 --> Language Class Initialized
INFO - 2021-07-12 03:27:44 --> Language Class Initialized
INFO - 2021-07-12 03:27:44 --> Config Class Initialized
INFO - 2021-07-12 03:27:44 --> Loader Class Initialized
INFO - 2021-07-12 03:27:44 --> Helper loaded: url_helper
INFO - 2021-07-12 03:27:44 --> Helper loaded: file_helper
INFO - 2021-07-12 03:27:44 --> Helper loaded: form_helper
INFO - 2021-07-12 03:27:44 --> Helper loaded: my_helper
INFO - 2021-07-12 03:27:44 --> Database Driver Class Initialized
DEBUG - 2021-07-12 03:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 03:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 03:27:44 --> Controller Class Initialized
DEBUG - 2021-07-12 03:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 03:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 03:27:44 --> Final output sent to browser
DEBUG - 2021-07-12 03:27:44 --> Total execution time: 0.1051
INFO - 2021-07-12 03:31:35 --> Config Class Initialized
INFO - 2021-07-12 03:31:35 --> Hooks Class Initialized
DEBUG - 2021-07-12 03:31:35 --> UTF-8 Support Enabled
INFO - 2021-07-12 03:31:35 --> Utf8 Class Initialized
INFO - 2021-07-12 03:31:35 --> URI Class Initialized
INFO - 2021-07-12 03:31:35 --> Router Class Initialized
INFO - 2021-07-12 03:31:35 --> Output Class Initialized
INFO - 2021-07-12 03:31:35 --> Security Class Initialized
DEBUG - 2021-07-12 03:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 03:31:35 --> Input Class Initialized
INFO - 2021-07-12 03:31:35 --> Language Class Initialized
INFO - 2021-07-12 03:31:35 --> Language Class Initialized
INFO - 2021-07-12 03:31:35 --> Config Class Initialized
INFO - 2021-07-12 03:31:35 --> Loader Class Initialized
INFO - 2021-07-12 03:31:35 --> Helper loaded: url_helper
INFO - 2021-07-12 03:31:35 --> Helper loaded: file_helper
INFO - 2021-07-12 03:31:35 --> Helper loaded: form_helper
INFO - 2021-07-12 03:31:35 --> Helper loaded: my_helper
INFO - 2021-07-12 03:31:35 --> Database Driver Class Initialized
DEBUG - 2021-07-12 03:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 03:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 03:31:35 --> Controller Class Initialized
INFO - 2021-07-12 03:31:35 --> Helper loaded: cookie_helper
INFO - 2021-07-12 03:31:35 --> Final output sent to browser
DEBUG - 2021-07-12 03:31:35 --> Total execution time: 0.0759
INFO - 2021-07-12 03:31:36 --> Config Class Initialized
INFO - 2021-07-12 03:31:36 --> Hooks Class Initialized
DEBUG - 2021-07-12 03:31:36 --> UTF-8 Support Enabled
INFO - 2021-07-12 03:31:36 --> Utf8 Class Initialized
INFO - 2021-07-12 03:31:36 --> URI Class Initialized
INFO - 2021-07-12 03:31:36 --> Router Class Initialized
INFO - 2021-07-12 03:31:36 --> Output Class Initialized
INFO - 2021-07-12 03:31:36 --> Security Class Initialized
DEBUG - 2021-07-12 03:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 03:31:36 --> Input Class Initialized
INFO - 2021-07-12 03:31:36 --> Language Class Initialized
INFO - 2021-07-12 03:31:36 --> Language Class Initialized
INFO - 2021-07-12 03:31:36 --> Config Class Initialized
INFO - 2021-07-12 03:31:36 --> Loader Class Initialized
INFO - 2021-07-12 03:31:36 --> Helper loaded: url_helper
INFO - 2021-07-12 03:31:36 --> Helper loaded: file_helper
INFO - 2021-07-12 03:31:36 --> Helper loaded: form_helper
INFO - 2021-07-12 03:31:36 --> Helper loaded: my_helper
INFO - 2021-07-12 03:31:36 --> Database Driver Class Initialized
DEBUG - 2021-07-12 03:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 03:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 03:31:36 --> Controller Class Initialized
DEBUG - 2021-07-12 03:31:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 03:31:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 03:31:37 --> Final output sent to browser
DEBUG - 2021-07-12 03:31:37 --> Total execution time: 0.7469
INFO - 2021-07-12 03:42:49 --> Config Class Initialized
INFO - 2021-07-12 03:42:49 --> Hooks Class Initialized
DEBUG - 2021-07-12 03:42:49 --> UTF-8 Support Enabled
INFO - 2021-07-12 03:42:49 --> Utf8 Class Initialized
INFO - 2021-07-12 03:42:49 --> URI Class Initialized
INFO - 2021-07-12 03:42:49 --> Router Class Initialized
INFO - 2021-07-12 03:42:49 --> Output Class Initialized
INFO - 2021-07-12 03:42:49 --> Security Class Initialized
DEBUG - 2021-07-12 03:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 03:42:49 --> Input Class Initialized
INFO - 2021-07-12 03:42:49 --> Language Class Initialized
INFO - 2021-07-12 03:42:49 --> Language Class Initialized
INFO - 2021-07-12 03:42:49 --> Config Class Initialized
INFO - 2021-07-12 03:42:49 --> Loader Class Initialized
INFO - 2021-07-12 03:42:49 --> Helper loaded: url_helper
INFO - 2021-07-12 03:42:49 --> Helper loaded: file_helper
INFO - 2021-07-12 03:42:49 --> Helper loaded: form_helper
INFO - 2021-07-12 03:42:49 --> Helper loaded: my_helper
INFO - 2021-07-12 03:42:49 --> Database Driver Class Initialized
DEBUG - 2021-07-12 03:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 03:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 03:42:49 --> Controller Class Initialized
DEBUG - 2021-07-12 03:42:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-12 03:42:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 03:42:49 --> Final output sent to browser
DEBUG - 2021-07-12 03:42:49 --> Total execution time: 0.0855
INFO - 2021-07-12 03:42:49 --> Config Class Initialized
INFO - 2021-07-12 03:42:49 --> Hooks Class Initialized
DEBUG - 2021-07-12 03:42:49 --> UTF-8 Support Enabled
INFO - 2021-07-12 03:42:49 --> Utf8 Class Initialized
INFO - 2021-07-12 03:42:49 --> URI Class Initialized
INFO - 2021-07-12 03:42:49 --> Router Class Initialized
INFO - 2021-07-12 03:42:49 --> Output Class Initialized
INFO - 2021-07-12 03:42:49 --> Security Class Initialized
DEBUG - 2021-07-12 03:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 03:42:49 --> Input Class Initialized
INFO - 2021-07-12 03:42:49 --> Language Class Initialized
INFO - 2021-07-12 03:42:49 --> Language Class Initialized
INFO - 2021-07-12 03:42:49 --> Config Class Initialized
INFO - 2021-07-12 03:42:49 --> Loader Class Initialized
INFO - 2021-07-12 03:42:49 --> Helper loaded: url_helper
INFO - 2021-07-12 03:42:49 --> Helper loaded: file_helper
INFO - 2021-07-12 03:42:49 --> Helper loaded: form_helper
INFO - 2021-07-12 03:42:49 --> Helper loaded: my_helper
INFO - 2021-07-12 03:42:49 --> Database Driver Class Initialized
DEBUG - 2021-07-12 03:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 03:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 03:42:49 --> Controller Class Initialized
INFO - 2021-07-12 03:43:34 --> Config Class Initialized
INFO - 2021-07-12 03:43:34 --> Hooks Class Initialized
DEBUG - 2021-07-12 03:43:34 --> UTF-8 Support Enabled
INFO - 2021-07-12 03:43:34 --> Utf8 Class Initialized
INFO - 2021-07-12 03:43:34 --> URI Class Initialized
INFO - 2021-07-12 03:43:34 --> Router Class Initialized
INFO - 2021-07-12 03:43:34 --> Output Class Initialized
INFO - 2021-07-12 03:43:34 --> Security Class Initialized
DEBUG - 2021-07-12 03:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 03:43:34 --> Input Class Initialized
INFO - 2021-07-12 03:43:34 --> Language Class Initialized
INFO - 2021-07-12 03:43:34 --> Language Class Initialized
INFO - 2021-07-12 03:43:34 --> Config Class Initialized
INFO - 2021-07-12 03:43:34 --> Loader Class Initialized
INFO - 2021-07-12 03:43:34 --> Helper loaded: url_helper
INFO - 2021-07-12 03:43:34 --> Helper loaded: file_helper
INFO - 2021-07-12 03:43:34 --> Helper loaded: form_helper
INFO - 2021-07-12 03:43:34 --> Helper loaded: my_helper
INFO - 2021-07-12 03:43:34 --> Database Driver Class Initialized
DEBUG - 2021-07-12 03:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 03:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 03:43:34 --> Controller Class Initialized
ERROR - 2021-07-12 03:43:34 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-12 03:43:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-12 03:43:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 03:43:34 --> Final output sent to browser
DEBUG - 2021-07-12 03:43:34 --> Total execution time: 0.1107
INFO - 2021-07-12 04:08:17 --> Config Class Initialized
INFO - 2021-07-12 04:08:17 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:08:17 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:08:17 --> Utf8 Class Initialized
INFO - 2021-07-12 04:08:17 --> URI Class Initialized
DEBUG - 2021-07-12 04:08:17 --> No URI present. Default controller set.
INFO - 2021-07-12 04:08:17 --> Router Class Initialized
INFO - 2021-07-12 04:08:17 --> Output Class Initialized
INFO - 2021-07-12 04:08:17 --> Security Class Initialized
DEBUG - 2021-07-12 04:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:08:17 --> Input Class Initialized
INFO - 2021-07-12 04:08:17 --> Language Class Initialized
INFO - 2021-07-12 04:08:17 --> Language Class Initialized
INFO - 2021-07-12 04:08:17 --> Config Class Initialized
INFO - 2021-07-12 04:08:17 --> Loader Class Initialized
INFO - 2021-07-12 04:08:17 --> Helper loaded: url_helper
INFO - 2021-07-12 04:08:17 --> Helper loaded: file_helper
INFO - 2021-07-12 04:08:17 --> Helper loaded: form_helper
INFO - 2021-07-12 04:08:17 --> Helper loaded: my_helper
INFO - 2021-07-12 04:08:17 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:08:17 --> Controller Class Initialized
INFO - 2021-07-12 04:08:18 --> Config Class Initialized
INFO - 2021-07-12 04:08:18 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:08:18 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:08:18 --> Utf8 Class Initialized
INFO - 2021-07-12 04:08:18 --> URI Class Initialized
INFO - 2021-07-12 04:08:18 --> Router Class Initialized
INFO - 2021-07-12 04:08:18 --> Output Class Initialized
INFO - 2021-07-12 04:08:18 --> Security Class Initialized
DEBUG - 2021-07-12 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:08:18 --> Input Class Initialized
INFO - 2021-07-12 04:08:18 --> Language Class Initialized
INFO - 2021-07-12 04:08:18 --> Language Class Initialized
INFO - 2021-07-12 04:08:18 --> Config Class Initialized
INFO - 2021-07-12 04:08:18 --> Loader Class Initialized
INFO - 2021-07-12 04:08:18 --> Helper loaded: url_helper
INFO - 2021-07-12 04:08:18 --> Helper loaded: file_helper
INFO - 2021-07-12 04:08:18 --> Helper loaded: form_helper
INFO - 2021-07-12 04:08:18 --> Helper loaded: my_helper
INFO - 2021-07-12 04:08:18 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:08:18 --> Controller Class Initialized
DEBUG - 2021-07-12 04:08:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 04:08:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:08:18 --> Final output sent to browser
DEBUG - 2021-07-12 04:08:18 --> Total execution time: 0.0894
INFO - 2021-07-12 04:08:23 --> Config Class Initialized
INFO - 2021-07-12 04:08:23 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:08:23 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:08:23 --> Utf8 Class Initialized
INFO - 2021-07-12 04:08:23 --> URI Class Initialized
INFO - 2021-07-12 04:08:23 --> Router Class Initialized
INFO - 2021-07-12 04:08:23 --> Output Class Initialized
INFO - 2021-07-12 04:08:23 --> Security Class Initialized
DEBUG - 2021-07-12 04:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:08:23 --> Input Class Initialized
INFO - 2021-07-12 04:08:23 --> Language Class Initialized
INFO - 2021-07-12 04:08:23 --> Language Class Initialized
INFO - 2021-07-12 04:08:23 --> Config Class Initialized
INFO - 2021-07-12 04:08:23 --> Loader Class Initialized
INFO - 2021-07-12 04:08:23 --> Helper loaded: url_helper
INFO - 2021-07-12 04:08:23 --> Helper loaded: file_helper
INFO - 2021-07-12 04:08:23 --> Helper loaded: form_helper
INFO - 2021-07-12 04:08:23 --> Helper loaded: my_helper
INFO - 2021-07-12 04:08:23 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:08:23 --> Controller Class Initialized
INFO - 2021-07-12 04:08:23 --> Helper loaded: cookie_helper
INFO - 2021-07-12 04:08:23 --> Final output sent to browser
DEBUG - 2021-07-12 04:08:23 --> Total execution time: 0.0654
INFO - 2021-07-12 04:08:24 --> Config Class Initialized
INFO - 2021-07-12 04:08:24 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:08:24 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:08:24 --> Utf8 Class Initialized
INFO - 2021-07-12 04:08:24 --> URI Class Initialized
INFO - 2021-07-12 04:08:24 --> Router Class Initialized
INFO - 2021-07-12 04:08:24 --> Output Class Initialized
INFO - 2021-07-12 04:08:24 --> Security Class Initialized
DEBUG - 2021-07-12 04:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:08:24 --> Input Class Initialized
INFO - 2021-07-12 04:08:24 --> Language Class Initialized
INFO - 2021-07-12 04:08:24 --> Language Class Initialized
INFO - 2021-07-12 04:08:24 --> Config Class Initialized
INFO - 2021-07-12 04:08:24 --> Loader Class Initialized
INFO - 2021-07-12 04:08:24 --> Helper loaded: url_helper
INFO - 2021-07-12 04:08:24 --> Helper loaded: file_helper
INFO - 2021-07-12 04:08:24 --> Helper loaded: form_helper
INFO - 2021-07-12 04:08:24 --> Helper loaded: my_helper
INFO - 2021-07-12 04:08:24 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:08:24 --> Controller Class Initialized
DEBUG - 2021-07-12 04:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 04:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:08:24 --> Final output sent to browser
DEBUG - 2021-07-12 04:08:24 --> Total execution time: 0.8316
INFO - 2021-07-12 04:09:10 --> Config Class Initialized
INFO - 2021-07-12 04:09:10 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:09:10 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:09:10 --> Utf8 Class Initialized
INFO - 2021-07-12 04:09:10 --> URI Class Initialized
INFO - 2021-07-12 04:09:10 --> Router Class Initialized
INFO - 2021-07-12 04:09:10 --> Output Class Initialized
INFO - 2021-07-12 04:09:10 --> Security Class Initialized
DEBUG - 2021-07-12 04:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:09:10 --> Input Class Initialized
INFO - 2021-07-12 04:09:10 --> Language Class Initialized
INFO - 2021-07-12 04:09:10 --> Language Class Initialized
INFO - 2021-07-12 04:09:10 --> Config Class Initialized
INFO - 2021-07-12 04:09:10 --> Loader Class Initialized
INFO - 2021-07-12 04:09:10 --> Helper loaded: url_helper
INFO - 2021-07-12 04:09:10 --> Helper loaded: file_helper
INFO - 2021-07-12 04:09:10 --> Helper loaded: form_helper
INFO - 2021-07-12 04:09:10 --> Helper loaded: my_helper
INFO - 2021-07-12 04:09:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:09:10 --> Controller Class Initialized
DEBUG - 2021-07-12 04:09:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-12 04:09:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:09:10 --> Final output sent to browser
DEBUG - 2021-07-12 04:09:10 --> Total execution time: 0.0697
INFO - 2021-07-12 04:09:10 --> Config Class Initialized
INFO - 2021-07-12 04:09:10 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:09:10 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:09:10 --> Utf8 Class Initialized
INFO - 2021-07-12 04:09:10 --> URI Class Initialized
INFO - 2021-07-12 04:09:10 --> Router Class Initialized
INFO - 2021-07-12 04:09:10 --> Output Class Initialized
INFO - 2021-07-12 04:09:10 --> Security Class Initialized
DEBUG - 2021-07-12 04:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:09:10 --> Input Class Initialized
INFO - 2021-07-12 04:09:10 --> Language Class Initialized
INFO - 2021-07-12 04:09:10 --> Language Class Initialized
INFO - 2021-07-12 04:09:10 --> Config Class Initialized
INFO - 2021-07-12 04:09:10 --> Loader Class Initialized
INFO - 2021-07-12 04:09:10 --> Helper loaded: url_helper
INFO - 2021-07-12 04:09:10 --> Helper loaded: file_helper
INFO - 2021-07-12 04:09:10 --> Helper loaded: form_helper
INFO - 2021-07-12 04:09:10 --> Helper loaded: my_helper
INFO - 2021-07-12 04:09:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:09:10 --> Controller Class Initialized
INFO - 2021-07-12 04:09:11 --> Config Class Initialized
INFO - 2021-07-12 04:09:11 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:09:11 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:09:11 --> Utf8 Class Initialized
INFO - 2021-07-12 04:09:11 --> URI Class Initialized
INFO - 2021-07-12 04:09:11 --> Router Class Initialized
INFO - 2021-07-12 04:09:11 --> Output Class Initialized
INFO - 2021-07-12 04:09:11 --> Security Class Initialized
DEBUG - 2021-07-12 04:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:09:11 --> Input Class Initialized
INFO - 2021-07-12 04:09:11 --> Language Class Initialized
INFO - 2021-07-12 04:09:11 --> Language Class Initialized
INFO - 2021-07-12 04:09:11 --> Config Class Initialized
INFO - 2021-07-12 04:09:11 --> Loader Class Initialized
INFO - 2021-07-12 04:09:11 --> Helper loaded: url_helper
INFO - 2021-07-12 04:09:11 --> Helper loaded: file_helper
INFO - 2021-07-12 04:09:11 --> Helper loaded: form_helper
INFO - 2021-07-12 04:09:11 --> Helper loaded: my_helper
INFO - 2021-07-12 04:09:11 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:09:11 --> Controller Class Initialized
ERROR - 2021-07-12 04:09:11 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-12 04:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-12 04:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:09:11 --> Final output sent to browser
DEBUG - 2021-07-12 04:09:11 --> Total execution time: 0.1098
INFO - 2021-07-12 04:28:54 --> Config Class Initialized
INFO - 2021-07-12 04:28:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:28:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:28:54 --> Utf8 Class Initialized
INFO - 2021-07-12 04:28:54 --> URI Class Initialized
INFO - 2021-07-12 04:28:54 --> Router Class Initialized
INFO - 2021-07-12 04:28:54 --> Output Class Initialized
INFO - 2021-07-12 04:28:54 --> Security Class Initialized
DEBUG - 2021-07-12 04:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:28:54 --> Input Class Initialized
INFO - 2021-07-12 04:28:54 --> Language Class Initialized
INFO - 2021-07-12 04:28:54 --> Language Class Initialized
INFO - 2021-07-12 04:28:54 --> Config Class Initialized
INFO - 2021-07-12 04:28:54 --> Loader Class Initialized
INFO - 2021-07-12 04:28:54 --> Helper loaded: url_helper
INFO - 2021-07-12 04:28:54 --> Helper loaded: file_helper
INFO - 2021-07-12 04:28:54 --> Helper loaded: form_helper
INFO - 2021-07-12 04:28:54 --> Helper loaded: my_helper
INFO - 2021-07-12 04:28:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:28:54 --> Controller Class Initialized
DEBUG - 2021-07-12 04:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-07-12 04:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:28:54 --> Final output sent to browser
DEBUG - 2021-07-12 04:28:54 --> Total execution time: 0.0614
INFO - 2021-07-12 04:28:54 --> Config Class Initialized
INFO - 2021-07-12 04:28:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:28:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:28:54 --> Utf8 Class Initialized
INFO - 2021-07-12 04:28:54 --> URI Class Initialized
INFO - 2021-07-12 04:28:54 --> Router Class Initialized
INFO - 2021-07-12 04:28:54 --> Output Class Initialized
INFO - 2021-07-12 04:28:54 --> Security Class Initialized
DEBUG - 2021-07-12 04:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:28:54 --> Input Class Initialized
INFO - 2021-07-12 04:28:54 --> Language Class Initialized
INFO - 2021-07-12 04:28:54 --> Language Class Initialized
INFO - 2021-07-12 04:28:54 --> Config Class Initialized
INFO - 2021-07-12 04:28:54 --> Loader Class Initialized
INFO - 2021-07-12 04:28:54 --> Helper loaded: url_helper
INFO - 2021-07-12 04:28:54 --> Helper loaded: file_helper
INFO - 2021-07-12 04:28:54 --> Helper loaded: form_helper
INFO - 2021-07-12 04:28:54 --> Helper loaded: my_helper
INFO - 2021-07-12 04:28:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:28:54 --> Controller Class Initialized
INFO - 2021-07-12 04:28:57 --> Config Class Initialized
INFO - 2021-07-12 04:28:57 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:28:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:28:57 --> Utf8 Class Initialized
INFO - 2021-07-12 04:28:57 --> URI Class Initialized
INFO - 2021-07-12 04:28:57 --> Router Class Initialized
INFO - 2021-07-12 04:28:57 --> Output Class Initialized
INFO - 2021-07-12 04:28:57 --> Security Class Initialized
DEBUG - 2021-07-12 04:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:28:57 --> Input Class Initialized
INFO - 2021-07-12 04:28:57 --> Language Class Initialized
INFO - 2021-07-12 04:28:57 --> Language Class Initialized
INFO - 2021-07-12 04:28:57 --> Config Class Initialized
INFO - 2021-07-12 04:28:57 --> Loader Class Initialized
INFO - 2021-07-12 04:28:57 --> Helper loaded: url_helper
INFO - 2021-07-12 04:28:57 --> Helper loaded: file_helper
INFO - 2021-07-12 04:28:57 --> Helper loaded: form_helper
INFO - 2021-07-12 04:28:57 --> Helper loaded: my_helper
INFO - 2021-07-12 04:28:57 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:28:57 --> Controller Class Initialized
INFO - 2021-07-12 04:28:57 --> Final output sent to browser
DEBUG - 2021-07-12 04:28:57 --> Total execution time: 0.0684
INFO - 2021-07-12 04:29:07 --> Config Class Initialized
INFO - 2021-07-12 04:29:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:29:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:29:07 --> Utf8 Class Initialized
INFO - 2021-07-12 04:29:07 --> URI Class Initialized
INFO - 2021-07-12 04:29:07 --> Router Class Initialized
INFO - 2021-07-12 04:29:07 --> Output Class Initialized
INFO - 2021-07-12 04:29:07 --> Security Class Initialized
DEBUG - 2021-07-12 04:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:29:07 --> Input Class Initialized
INFO - 2021-07-12 04:29:07 --> Language Class Initialized
INFO - 2021-07-12 04:29:07 --> Language Class Initialized
INFO - 2021-07-12 04:29:07 --> Config Class Initialized
INFO - 2021-07-12 04:29:07 --> Loader Class Initialized
INFO - 2021-07-12 04:29:07 --> Helper loaded: url_helper
INFO - 2021-07-12 04:29:07 --> Helper loaded: file_helper
INFO - 2021-07-12 04:29:07 --> Helper loaded: form_helper
INFO - 2021-07-12 04:29:07 --> Helper loaded: my_helper
INFO - 2021-07-12 04:29:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:29:07 --> Controller Class Initialized
INFO - 2021-07-12 04:29:07 --> Helper loaded: cookie_helper
INFO - 2021-07-12 04:29:07 --> Config Class Initialized
INFO - 2021-07-12 04:29:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:29:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:29:07 --> Utf8 Class Initialized
INFO - 2021-07-12 04:29:07 --> URI Class Initialized
INFO - 2021-07-12 04:29:07 --> Router Class Initialized
INFO - 2021-07-12 04:29:07 --> Output Class Initialized
INFO - 2021-07-12 04:29:07 --> Security Class Initialized
DEBUG - 2021-07-12 04:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:29:07 --> Input Class Initialized
INFO - 2021-07-12 04:29:07 --> Language Class Initialized
INFO - 2021-07-12 04:29:07 --> Language Class Initialized
INFO - 2021-07-12 04:29:07 --> Config Class Initialized
INFO - 2021-07-12 04:29:07 --> Loader Class Initialized
INFO - 2021-07-12 04:29:07 --> Helper loaded: url_helper
INFO - 2021-07-12 04:29:07 --> Helper loaded: file_helper
INFO - 2021-07-12 04:29:07 --> Helper loaded: form_helper
INFO - 2021-07-12 04:29:07 --> Helper loaded: my_helper
INFO - 2021-07-12 04:29:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:29:07 --> Controller Class Initialized
DEBUG - 2021-07-12 04:29:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 04:29:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:29:07 --> Final output sent to browser
DEBUG - 2021-07-12 04:29:07 --> Total execution time: 0.0533
INFO - 2021-07-12 04:29:13 --> Config Class Initialized
INFO - 2021-07-12 04:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:29:13 --> Utf8 Class Initialized
INFO - 2021-07-12 04:29:13 --> URI Class Initialized
INFO - 2021-07-12 04:29:13 --> Router Class Initialized
INFO - 2021-07-12 04:29:13 --> Output Class Initialized
INFO - 2021-07-12 04:29:13 --> Security Class Initialized
DEBUG - 2021-07-12 04:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:29:13 --> Input Class Initialized
INFO - 2021-07-12 04:29:13 --> Language Class Initialized
INFO - 2021-07-12 04:29:13 --> Language Class Initialized
INFO - 2021-07-12 04:29:13 --> Config Class Initialized
INFO - 2021-07-12 04:29:13 --> Loader Class Initialized
INFO - 2021-07-12 04:29:13 --> Helper loaded: url_helper
INFO - 2021-07-12 04:29:13 --> Helper loaded: file_helper
INFO - 2021-07-12 04:29:13 --> Helper loaded: form_helper
INFO - 2021-07-12 04:29:13 --> Helper loaded: my_helper
INFO - 2021-07-12 04:29:13 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:29:13 --> Controller Class Initialized
INFO - 2021-07-12 04:29:13 --> Helper loaded: cookie_helper
INFO - 2021-07-12 04:29:13 --> Final output sent to browser
DEBUG - 2021-07-12 04:29:13 --> Total execution time: 0.0644
INFO - 2021-07-12 04:29:13 --> Config Class Initialized
INFO - 2021-07-12 04:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:29:13 --> Utf8 Class Initialized
INFO - 2021-07-12 04:29:13 --> URI Class Initialized
INFO - 2021-07-12 04:29:13 --> Router Class Initialized
INFO - 2021-07-12 04:29:13 --> Output Class Initialized
INFO - 2021-07-12 04:29:13 --> Security Class Initialized
DEBUG - 2021-07-12 04:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:29:13 --> Input Class Initialized
INFO - 2021-07-12 04:29:13 --> Language Class Initialized
INFO - 2021-07-12 04:29:13 --> Language Class Initialized
INFO - 2021-07-12 04:29:13 --> Config Class Initialized
INFO - 2021-07-12 04:29:13 --> Loader Class Initialized
INFO - 2021-07-12 04:29:13 --> Helper loaded: url_helper
INFO - 2021-07-12 04:29:13 --> Helper loaded: file_helper
INFO - 2021-07-12 04:29:13 --> Helper loaded: form_helper
INFO - 2021-07-12 04:29:13 --> Helper loaded: my_helper
INFO - 2021-07-12 04:29:13 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:29:13 --> Controller Class Initialized
DEBUG - 2021-07-12 04:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 04:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:29:14 --> Final output sent to browser
DEBUG - 2021-07-12 04:29:14 --> Total execution time: 0.6365
INFO - 2021-07-12 04:29:22 --> Config Class Initialized
INFO - 2021-07-12 04:29:22 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:29:22 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:29:22 --> Utf8 Class Initialized
INFO - 2021-07-12 04:29:22 --> URI Class Initialized
INFO - 2021-07-12 04:29:22 --> Router Class Initialized
INFO - 2021-07-12 04:29:22 --> Output Class Initialized
INFO - 2021-07-12 04:29:22 --> Security Class Initialized
DEBUG - 2021-07-12 04:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:29:22 --> Input Class Initialized
INFO - 2021-07-12 04:29:22 --> Language Class Initialized
INFO - 2021-07-12 04:29:22 --> Language Class Initialized
INFO - 2021-07-12 04:29:22 --> Config Class Initialized
INFO - 2021-07-12 04:29:22 --> Loader Class Initialized
INFO - 2021-07-12 04:29:22 --> Helper loaded: url_helper
INFO - 2021-07-12 04:29:22 --> Helper loaded: file_helper
INFO - 2021-07-12 04:29:22 --> Helper loaded: form_helper
INFO - 2021-07-12 04:29:22 --> Helper loaded: my_helper
INFO - 2021-07-12 04:29:22 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:29:22 --> Controller Class Initialized
INFO - 2021-07-12 04:29:22 --> Helper loaded: cookie_helper
INFO - 2021-07-12 04:29:22 --> Config Class Initialized
INFO - 2021-07-12 04:29:22 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:29:22 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:29:22 --> Utf8 Class Initialized
INFO - 2021-07-12 04:29:22 --> URI Class Initialized
INFO - 2021-07-12 04:29:22 --> Router Class Initialized
INFO - 2021-07-12 04:29:22 --> Output Class Initialized
INFO - 2021-07-12 04:29:22 --> Security Class Initialized
DEBUG - 2021-07-12 04:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:29:22 --> Input Class Initialized
INFO - 2021-07-12 04:29:22 --> Language Class Initialized
INFO - 2021-07-12 04:29:22 --> Language Class Initialized
INFO - 2021-07-12 04:29:22 --> Config Class Initialized
INFO - 2021-07-12 04:29:22 --> Loader Class Initialized
INFO - 2021-07-12 04:29:22 --> Helper loaded: url_helper
INFO - 2021-07-12 04:29:22 --> Helper loaded: file_helper
INFO - 2021-07-12 04:29:22 --> Helper loaded: form_helper
INFO - 2021-07-12 04:29:22 --> Helper loaded: my_helper
INFO - 2021-07-12 04:29:22 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:29:22 --> Controller Class Initialized
DEBUG - 2021-07-12 04:29:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 04:29:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:29:22 --> Final output sent to browser
DEBUG - 2021-07-12 04:29:22 --> Total execution time: 0.0566
INFO - 2021-07-12 04:32:31 --> Config Class Initialized
INFO - 2021-07-12 04:32:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:32:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:32:31 --> Utf8 Class Initialized
INFO - 2021-07-12 04:32:31 --> URI Class Initialized
INFO - 2021-07-12 04:32:31 --> Router Class Initialized
INFO - 2021-07-12 04:32:31 --> Output Class Initialized
INFO - 2021-07-12 04:32:31 --> Security Class Initialized
DEBUG - 2021-07-12 04:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:32:31 --> Input Class Initialized
INFO - 2021-07-12 04:32:31 --> Language Class Initialized
INFO - 2021-07-12 04:32:31 --> Language Class Initialized
INFO - 2021-07-12 04:32:31 --> Config Class Initialized
INFO - 2021-07-12 04:32:31 --> Loader Class Initialized
INFO - 2021-07-12 04:32:31 --> Helper loaded: url_helper
INFO - 2021-07-12 04:32:31 --> Helper loaded: file_helper
INFO - 2021-07-12 04:32:31 --> Helper loaded: form_helper
INFO - 2021-07-12 04:32:31 --> Helper loaded: my_helper
INFO - 2021-07-12 04:32:31 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:32:31 --> Controller Class Initialized
INFO - 2021-07-12 04:32:31 --> Helper loaded: cookie_helper
INFO - 2021-07-12 04:32:31 --> Final output sent to browser
DEBUG - 2021-07-12 04:32:31 --> Total execution time: 0.0557
INFO - 2021-07-12 04:32:31 --> Config Class Initialized
INFO - 2021-07-12 04:32:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:32:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:32:31 --> Utf8 Class Initialized
INFO - 2021-07-12 04:32:31 --> URI Class Initialized
INFO - 2021-07-12 04:32:31 --> Router Class Initialized
INFO - 2021-07-12 04:32:31 --> Output Class Initialized
INFO - 2021-07-12 04:32:31 --> Security Class Initialized
DEBUG - 2021-07-12 04:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:32:31 --> Input Class Initialized
INFO - 2021-07-12 04:32:31 --> Language Class Initialized
INFO - 2021-07-12 04:32:31 --> Language Class Initialized
INFO - 2021-07-12 04:32:31 --> Config Class Initialized
INFO - 2021-07-12 04:32:31 --> Loader Class Initialized
INFO - 2021-07-12 04:32:31 --> Helper loaded: url_helper
INFO - 2021-07-12 04:32:31 --> Helper loaded: file_helper
INFO - 2021-07-12 04:32:31 --> Helper loaded: form_helper
INFO - 2021-07-12 04:32:31 --> Helper loaded: my_helper
INFO - 2021-07-12 04:32:31 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:32:31 --> Controller Class Initialized
DEBUG - 2021-07-12 04:32:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 04:32:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:32:31 --> Final output sent to browser
DEBUG - 2021-07-12 04:32:31 --> Total execution time: 0.6571
INFO - 2021-07-12 04:32:36 --> Config Class Initialized
INFO - 2021-07-12 04:32:36 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:32:36 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:32:36 --> Utf8 Class Initialized
INFO - 2021-07-12 04:32:36 --> URI Class Initialized
INFO - 2021-07-12 04:32:36 --> Router Class Initialized
INFO - 2021-07-12 04:32:36 --> Output Class Initialized
INFO - 2021-07-12 04:32:36 --> Security Class Initialized
DEBUG - 2021-07-12 04:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:32:36 --> Input Class Initialized
INFO - 2021-07-12 04:32:36 --> Language Class Initialized
INFO - 2021-07-12 04:32:36 --> Language Class Initialized
INFO - 2021-07-12 04:32:36 --> Config Class Initialized
INFO - 2021-07-12 04:32:36 --> Loader Class Initialized
INFO - 2021-07-12 04:32:36 --> Helper loaded: url_helper
INFO - 2021-07-12 04:32:36 --> Helper loaded: file_helper
INFO - 2021-07-12 04:32:36 --> Helper loaded: form_helper
INFO - 2021-07-12 04:32:36 --> Helper loaded: my_helper
INFO - 2021-07-12 04:32:36 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:32:36 --> Controller Class Initialized
DEBUG - 2021-07-12 04:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 04:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 04:32:36 --> Final output sent to browser
DEBUG - 2021-07-12 04:32:36 --> Total execution time: 0.1310
INFO - 2021-07-12 04:32:38 --> Config Class Initialized
INFO - 2021-07-12 04:32:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:32:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:32:38 --> Utf8 Class Initialized
INFO - 2021-07-12 04:32:38 --> URI Class Initialized
INFO - 2021-07-12 04:32:38 --> Router Class Initialized
INFO - 2021-07-12 04:32:38 --> Output Class Initialized
INFO - 2021-07-12 04:32:38 --> Security Class Initialized
DEBUG - 2021-07-12 04:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:32:38 --> Input Class Initialized
INFO - 2021-07-12 04:32:38 --> Language Class Initialized
INFO - 2021-07-12 04:32:38 --> Language Class Initialized
INFO - 2021-07-12 04:32:38 --> Config Class Initialized
INFO - 2021-07-12 04:32:38 --> Loader Class Initialized
INFO - 2021-07-12 04:32:38 --> Helper loaded: url_helper
INFO - 2021-07-12 04:32:38 --> Helper loaded: file_helper
INFO - 2021-07-12 04:32:38 --> Helper loaded: form_helper
INFO - 2021-07-12 04:32:38 --> Helper loaded: my_helper
INFO - 2021-07-12 04:32:38 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:32:38 --> Controller Class Initialized
DEBUG - 2021-07-12 04:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-07-12 04:32:39 --> Final output sent to browser
DEBUG - 2021-07-12 04:32:39 --> Total execution time: 0.2400
INFO - 2021-07-12 04:34:16 --> Config Class Initialized
INFO - 2021-07-12 04:34:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:34:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:34:16 --> Utf8 Class Initialized
INFO - 2021-07-12 04:34:16 --> URI Class Initialized
INFO - 2021-07-12 04:34:16 --> Router Class Initialized
INFO - 2021-07-12 04:34:16 --> Output Class Initialized
INFO - 2021-07-12 04:34:16 --> Security Class Initialized
DEBUG - 2021-07-12 04:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:34:16 --> Input Class Initialized
INFO - 2021-07-12 04:34:16 --> Language Class Initialized
INFO - 2021-07-12 04:34:16 --> Language Class Initialized
INFO - 2021-07-12 04:34:16 --> Config Class Initialized
INFO - 2021-07-12 04:34:16 --> Loader Class Initialized
INFO - 2021-07-12 04:34:16 --> Helper loaded: url_helper
INFO - 2021-07-12 04:34:16 --> Helper loaded: file_helper
INFO - 2021-07-12 04:34:16 --> Helper loaded: form_helper
INFO - 2021-07-12 04:34:16 --> Helper loaded: my_helper
INFO - 2021-07-12 04:34:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:34:16 --> Controller Class Initialized
ERROR - 2021-07-12 04:34:16 --> Severity: Notice --> Use of undefined constant I - assumed 'I' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_tkj_xi.php 296
ERROR - 2021-07-12 04:34:16 --> Severity: Notice --> Use of undefined constant XII - assumed 'XII' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_tkj_xi.php 299
DEBUG - 2021-07-12 04:34:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-07-12 04:34:16 --> Final output sent to browser
DEBUG - 2021-07-12 04:34:16 --> Total execution time: 0.1562
INFO - 2021-07-12 04:34:35 --> Config Class Initialized
INFO - 2021-07-12 04:34:35 --> Hooks Class Initialized
DEBUG - 2021-07-12 04:34:35 --> UTF-8 Support Enabled
INFO - 2021-07-12 04:34:35 --> Utf8 Class Initialized
INFO - 2021-07-12 04:34:35 --> URI Class Initialized
INFO - 2021-07-12 04:34:35 --> Router Class Initialized
INFO - 2021-07-12 04:34:35 --> Output Class Initialized
INFO - 2021-07-12 04:34:35 --> Security Class Initialized
DEBUG - 2021-07-12 04:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 04:34:35 --> Input Class Initialized
INFO - 2021-07-12 04:34:35 --> Language Class Initialized
INFO - 2021-07-12 04:34:35 --> Language Class Initialized
INFO - 2021-07-12 04:34:35 --> Config Class Initialized
INFO - 2021-07-12 04:34:35 --> Loader Class Initialized
INFO - 2021-07-12 04:34:35 --> Helper loaded: url_helper
INFO - 2021-07-12 04:34:35 --> Helper loaded: file_helper
INFO - 2021-07-12 04:34:35 --> Helper loaded: form_helper
INFO - 2021-07-12 04:34:35 --> Helper loaded: my_helper
INFO - 2021-07-12 04:34:35 --> Database Driver Class Initialized
DEBUG - 2021-07-12 04:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 04:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 04:34:35 --> Controller Class Initialized
DEBUG - 2021-07-12 04:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-07-12 04:34:35 --> Final output sent to browser
DEBUG - 2021-07-12 04:34:35 --> Total execution time: 0.1270
INFO - 2021-07-12 05:09:54 --> Config Class Initialized
INFO - 2021-07-12 05:09:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 05:09:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 05:09:54 --> Utf8 Class Initialized
INFO - 2021-07-12 05:09:54 --> URI Class Initialized
INFO - 2021-07-12 05:09:54 --> Router Class Initialized
INFO - 2021-07-12 05:09:54 --> Output Class Initialized
INFO - 2021-07-12 05:09:54 --> Security Class Initialized
DEBUG - 2021-07-12 05:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 05:09:54 --> Input Class Initialized
INFO - 2021-07-12 05:09:54 --> Language Class Initialized
INFO - 2021-07-12 05:09:54 --> Language Class Initialized
INFO - 2021-07-12 05:09:54 --> Config Class Initialized
INFO - 2021-07-12 05:09:54 --> Loader Class Initialized
INFO - 2021-07-12 05:09:54 --> Helper loaded: url_helper
INFO - 2021-07-12 05:09:54 --> Helper loaded: file_helper
INFO - 2021-07-12 05:09:54 --> Helper loaded: form_helper
INFO - 2021-07-12 05:09:54 --> Helper loaded: my_helper
INFO - 2021-07-12 05:09:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 05:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 05:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 05:09:54 --> Controller Class Initialized
ERROR - 2021-07-12 05:09:54 --> Severity: Parsing Error --> syntax error, unexpected '"I"' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_tkj_xi.php 296
INFO - 2021-07-12 05:10:20 --> Config Class Initialized
INFO - 2021-07-12 05:10:20 --> Hooks Class Initialized
DEBUG - 2021-07-12 05:10:20 --> UTF-8 Support Enabled
INFO - 2021-07-12 05:10:20 --> Utf8 Class Initialized
INFO - 2021-07-12 05:10:20 --> URI Class Initialized
INFO - 2021-07-12 05:10:20 --> Router Class Initialized
INFO - 2021-07-12 05:10:20 --> Output Class Initialized
INFO - 2021-07-12 05:10:20 --> Security Class Initialized
DEBUG - 2021-07-12 05:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 05:10:20 --> Input Class Initialized
INFO - 2021-07-12 05:10:20 --> Language Class Initialized
INFO - 2021-07-12 05:10:20 --> Language Class Initialized
INFO - 2021-07-12 05:10:20 --> Config Class Initialized
INFO - 2021-07-12 05:10:20 --> Loader Class Initialized
INFO - 2021-07-12 05:10:20 --> Helper loaded: url_helper
INFO - 2021-07-12 05:10:20 --> Helper loaded: file_helper
INFO - 2021-07-12 05:10:20 --> Helper loaded: form_helper
INFO - 2021-07-12 05:10:20 --> Helper loaded: my_helper
INFO - 2021-07-12 05:10:20 --> Database Driver Class Initialized
DEBUG - 2021-07-12 05:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 05:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 05:10:20 --> Controller Class Initialized
DEBUG - 2021-07-12 05:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-07-12 05:10:20 --> Final output sent to browser
DEBUG - 2021-07-12 05:10:20 --> Total execution time: 0.1334
INFO - 2021-07-12 05:10:34 --> Config Class Initialized
INFO - 2021-07-12 05:10:34 --> Hooks Class Initialized
DEBUG - 2021-07-12 05:10:34 --> UTF-8 Support Enabled
INFO - 2021-07-12 05:10:34 --> Utf8 Class Initialized
INFO - 2021-07-12 05:10:34 --> URI Class Initialized
INFO - 2021-07-12 05:10:34 --> Router Class Initialized
INFO - 2021-07-12 05:10:34 --> Output Class Initialized
INFO - 2021-07-12 05:10:34 --> Security Class Initialized
DEBUG - 2021-07-12 05:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 05:10:34 --> Input Class Initialized
INFO - 2021-07-12 05:10:34 --> Language Class Initialized
INFO - 2021-07-12 05:10:34 --> Language Class Initialized
INFO - 2021-07-12 05:10:34 --> Config Class Initialized
INFO - 2021-07-12 05:10:34 --> Loader Class Initialized
INFO - 2021-07-12 05:10:34 --> Helper loaded: url_helper
INFO - 2021-07-12 05:10:34 --> Helper loaded: file_helper
INFO - 2021-07-12 05:10:34 --> Helper loaded: form_helper
INFO - 2021-07-12 05:10:34 --> Helper loaded: my_helper
INFO - 2021-07-12 05:10:34 --> Database Driver Class Initialized
DEBUG - 2021-07-12 05:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 05:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 05:10:34 --> Controller Class Initialized
ERROR - 2021-07-12 05:10:34 --> Severity: Parsing Error --> syntax error, unexpected 'I' (T_STRING) C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_tkj_xi.php 296
INFO - 2021-07-12 05:10:47 --> Config Class Initialized
INFO - 2021-07-12 05:10:47 --> Hooks Class Initialized
DEBUG - 2021-07-12 05:10:47 --> UTF-8 Support Enabled
INFO - 2021-07-12 05:10:47 --> Utf8 Class Initialized
INFO - 2021-07-12 05:10:47 --> URI Class Initialized
INFO - 2021-07-12 05:10:47 --> Router Class Initialized
INFO - 2021-07-12 05:10:47 --> Output Class Initialized
INFO - 2021-07-12 05:10:47 --> Security Class Initialized
DEBUG - 2021-07-12 05:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 05:10:47 --> Input Class Initialized
INFO - 2021-07-12 05:10:47 --> Language Class Initialized
INFO - 2021-07-12 05:10:47 --> Language Class Initialized
INFO - 2021-07-12 05:10:47 --> Config Class Initialized
INFO - 2021-07-12 05:10:47 --> Loader Class Initialized
INFO - 2021-07-12 05:10:47 --> Helper loaded: url_helper
INFO - 2021-07-12 05:10:47 --> Helper loaded: file_helper
INFO - 2021-07-12 05:10:47 --> Helper loaded: form_helper
INFO - 2021-07-12 05:10:47 --> Helper loaded: my_helper
INFO - 2021-07-12 05:10:47 --> Database Driver Class Initialized
DEBUG - 2021-07-12 05:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 05:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 05:10:47 --> Controller Class Initialized
DEBUG - 2021-07-12 05:10:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-07-12 05:10:47 --> Final output sent to browser
DEBUG - 2021-07-12 05:10:47 --> Total execution time: 0.1355
INFO - 2021-07-12 08:16:38 --> Config Class Initialized
INFO - 2021-07-12 08:16:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:16:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:16:38 --> Utf8 Class Initialized
INFO - 2021-07-12 08:16:38 --> URI Class Initialized
INFO - 2021-07-12 08:16:38 --> Router Class Initialized
INFO - 2021-07-12 08:16:38 --> Output Class Initialized
INFO - 2021-07-12 08:16:38 --> Security Class Initialized
DEBUG - 2021-07-12 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:16:38 --> Input Class Initialized
INFO - 2021-07-12 08:16:38 --> Language Class Initialized
INFO - 2021-07-12 08:16:38 --> Language Class Initialized
INFO - 2021-07-12 08:16:38 --> Config Class Initialized
INFO - 2021-07-12 08:16:38 --> Loader Class Initialized
INFO - 2021-07-12 08:16:38 --> Helper loaded: url_helper
INFO - 2021-07-12 08:16:38 --> Helper loaded: file_helper
INFO - 2021-07-12 08:16:38 --> Helper loaded: form_helper
INFO - 2021-07-12 08:16:38 --> Helper loaded: my_helper
INFO - 2021-07-12 08:16:38 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:16:38 --> Controller Class Initialized
INFO - 2021-07-12 08:16:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:16:38 --> Config Class Initialized
INFO - 2021-07-12 08:16:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:16:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:16:38 --> Utf8 Class Initialized
INFO - 2021-07-12 08:16:38 --> URI Class Initialized
INFO - 2021-07-12 08:16:38 --> Router Class Initialized
INFO - 2021-07-12 08:16:38 --> Output Class Initialized
INFO - 2021-07-12 08:16:38 --> Security Class Initialized
DEBUG - 2021-07-12 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:16:38 --> Input Class Initialized
INFO - 2021-07-12 08:16:38 --> Language Class Initialized
INFO - 2021-07-12 08:16:38 --> Language Class Initialized
INFO - 2021-07-12 08:16:38 --> Config Class Initialized
INFO - 2021-07-12 08:16:38 --> Loader Class Initialized
INFO - 2021-07-12 08:16:38 --> Helper loaded: url_helper
INFO - 2021-07-12 08:16:38 --> Helper loaded: file_helper
INFO - 2021-07-12 08:16:38 --> Helper loaded: form_helper
INFO - 2021-07-12 08:16:38 --> Helper loaded: my_helper
INFO - 2021-07-12 08:16:38 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:16:38 --> Controller Class Initialized
DEBUG - 2021-07-12 08:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 08:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:16:38 --> Final output sent to browser
DEBUG - 2021-07-12 08:16:38 --> Total execution time: 0.0554
INFO - 2021-07-12 08:16:45 --> Config Class Initialized
INFO - 2021-07-12 08:16:45 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:16:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:16:45 --> Utf8 Class Initialized
INFO - 2021-07-12 08:16:45 --> URI Class Initialized
INFO - 2021-07-12 08:16:45 --> Router Class Initialized
INFO - 2021-07-12 08:16:45 --> Output Class Initialized
INFO - 2021-07-12 08:16:45 --> Security Class Initialized
DEBUG - 2021-07-12 08:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:16:45 --> Input Class Initialized
INFO - 2021-07-12 08:16:45 --> Language Class Initialized
INFO - 2021-07-12 08:16:45 --> Language Class Initialized
INFO - 2021-07-12 08:16:45 --> Config Class Initialized
INFO - 2021-07-12 08:16:45 --> Loader Class Initialized
INFO - 2021-07-12 08:16:45 --> Helper loaded: url_helper
INFO - 2021-07-12 08:16:45 --> Helper loaded: file_helper
INFO - 2021-07-12 08:16:45 --> Helper loaded: form_helper
INFO - 2021-07-12 08:16:45 --> Helper loaded: my_helper
INFO - 2021-07-12 08:16:45 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:16:45 --> Controller Class Initialized
INFO - 2021-07-12 08:16:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:16:45 --> Final output sent to browser
DEBUG - 2021-07-12 08:16:45 --> Total execution time: 0.0712
INFO - 2021-07-12 08:16:45 --> Config Class Initialized
INFO - 2021-07-12 08:16:45 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:16:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:16:45 --> Utf8 Class Initialized
INFO - 2021-07-12 08:16:45 --> URI Class Initialized
INFO - 2021-07-12 08:16:45 --> Router Class Initialized
INFO - 2021-07-12 08:16:45 --> Output Class Initialized
INFO - 2021-07-12 08:16:45 --> Security Class Initialized
DEBUG - 2021-07-12 08:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:16:45 --> Input Class Initialized
INFO - 2021-07-12 08:16:45 --> Language Class Initialized
INFO - 2021-07-12 08:16:45 --> Language Class Initialized
INFO - 2021-07-12 08:16:45 --> Config Class Initialized
INFO - 2021-07-12 08:16:45 --> Loader Class Initialized
INFO - 2021-07-12 08:16:45 --> Helper loaded: url_helper
INFO - 2021-07-12 08:16:45 --> Helper loaded: file_helper
INFO - 2021-07-12 08:16:45 --> Helper loaded: form_helper
INFO - 2021-07-12 08:16:45 --> Helper loaded: my_helper
INFO - 2021-07-12 08:16:45 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:16:45 --> Controller Class Initialized
DEBUG - 2021-07-12 08:16:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 08:16:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:16:46 --> Final output sent to browser
DEBUG - 2021-07-12 08:16:46 --> Total execution time: 0.7322
INFO - 2021-07-12 08:16:50 --> Config Class Initialized
INFO - 2021-07-12 08:16:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:16:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:16:50 --> Utf8 Class Initialized
INFO - 2021-07-12 08:16:50 --> URI Class Initialized
INFO - 2021-07-12 08:16:50 --> Router Class Initialized
INFO - 2021-07-12 08:16:50 --> Output Class Initialized
INFO - 2021-07-12 08:16:50 --> Security Class Initialized
DEBUG - 2021-07-12 08:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:16:50 --> Input Class Initialized
INFO - 2021-07-12 08:16:50 --> Language Class Initialized
INFO - 2021-07-12 08:16:50 --> Language Class Initialized
INFO - 2021-07-12 08:16:50 --> Config Class Initialized
INFO - 2021-07-12 08:16:50 --> Loader Class Initialized
INFO - 2021-07-12 08:16:50 --> Helper loaded: url_helper
INFO - 2021-07-12 08:16:50 --> Helper loaded: file_helper
INFO - 2021-07-12 08:16:50 --> Helper loaded: form_helper
INFO - 2021-07-12 08:16:50 --> Helper loaded: my_helper
INFO - 2021-07-12 08:16:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:16:50 --> Controller Class Initialized
DEBUG - 2021-07-12 08:16:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-12 08:16:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:16:50 --> Final output sent to browser
DEBUG - 2021-07-12 08:16:50 --> Total execution time: 0.1006
INFO - 2021-07-12 08:22:48 --> Config Class Initialized
INFO - 2021-07-12 08:22:48 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:22:48 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:22:48 --> Utf8 Class Initialized
INFO - 2021-07-12 08:22:48 --> URI Class Initialized
INFO - 2021-07-12 08:22:48 --> Router Class Initialized
INFO - 2021-07-12 08:22:48 --> Output Class Initialized
INFO - 2021-07-12 08:22:48 --> Security Class Initialized
DEBUG - 2021-07-12 08:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:22:48 --> Input Class Initialized
INFO - 2021-07-12 08:22:48 --> Language Class Initialized
INFO - 2021-07-12 08:22:48 --> Language Class Initialized
INFO - 2021-07-12 08:22:48 --> Config Class Initialized
INFO - 2021-07-12 08:22:48 --> Loader Class Initialized
INFO - 2021-07-12 08:22:48 --> Helper loaded: url_helper
INFO - 2021-07-12 08:22:48 --> Helper loaded: file_helper
INFO - 2021-07-12 08:22:48 --> Helper loaded: form_helper
INFO - 2021-07-12 08:22:48 --> Helper loaded: my_helper
INFO - 2021-07-12 08:22:48 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:22:48 --> Controller Class Initialized
DEBUG - 2021-07-12 08:22:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xii.php
INFO - 2021-07-12 08:22:48 --> Final output sent to browser
DEBUG - 2021-07-12 08:22:48 --> Total execution time: 0.2863
INFO - 2021-07-12 08:24:15 --> Config Class Initialized
INFO - 2021-07-12 08:24:15 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:15 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:15 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:15 --> URI Class Initialized
INFO - 2021-07-12 08:24:15 --> Router Class Initialized
INFO - 2021-07-12 08:24:15 --> Output Class Initialized
INFO - 2021-07-12 08:24:15 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:15 --> Input Class Initialized
INFO - 2021-07-12 08:24:15 --> Language Class Initialized
INFO - 2021-07-12 08:24:15 --> Language Class Initialized
INFO - 2021-07-12 08:24:15 --> Config Class Initialized
INFO - 2021-07-12 08:24:15 --> Loader Class Initialized
INFO - 2021-07-12 08:24:15 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:15 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:15 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:15 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:15 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:15 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-07-12 08:24:15 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:15 --> Total execution time: 0.1382
INFO - 2021-07-12 08:24:19 --> Config Class Initialized
INFO - 2021-07-12 08:24:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:19 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:19 --> URI Class Initialized
INFO - 2021-07-12 08:24:19 --> Router Class Initialized
INFO - 2021-07-12 08:24:19 --> Output Class Initialized
INFO - 2021-07-12 08:24:19 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:19 --> Input Class Initialized
INFO - 2021-07-12 08:24:19 --> Language Class Initialized
INFO - 2021-07-12 08:24:19 --> Language Class Initialized
INFO - 2021-07-12 08:24:19 --> Config Class Initialized
INFO - 2021-07-12 08:24:19 --> Loader Class Initialized
INFO - 2021-07-12 08:24:19 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:19 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:19 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:19 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:19 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:19 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 08:24:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:24:19 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:19 --> Total execution time: 0.0656
INFO - 2021-07-12 08:24:29 --> Config Class Initialized
INFO - 2021-07-12 08:24:29 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:29 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:29 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:29 --> URI Class Initialized
INFO - 2021-07-12 08:24:29 --> Router Class Initialized
INFO - 2021-07-12 08:24:29 --> Output Class Initialized
INFO - 2021-07-12 08:24:29 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:29 --> Input Class Initialized
INFO - 2021-07-12 08:24:29 --> Language Class Initialized
INFO - 2021-07-12 08:24:29 --> Language Class Initialized
INFO - 2021-07-12 08:24:29 --> Config Class Initialized
INFO - 2021-07-12 08:24:29 --> Loader Class Initialized
INFO - 2021-07-12 08:24:29 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:29 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:29 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:29 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:29 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:29 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:29 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:29 --> Total execution time: 0.1955
INFO - 2021-07-12 08:24:31 --> Config Class Initialized
INFO - 2021-07-12 08:24:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:31 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:31 --> URI Class Initialized
INFO - 2021-07-12 08:24:31 --> Router Class Initialized
INFO - 2021-07-12 08:24:31 --> Output Class Initialized
INFO - 2021-07-12 08:24:31 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:31 --> Input Class Initialized
INFO - 2021-07-12 08:24:31 --> Language Class Initialized
INFO - 2021-07-12 08:24:31 --> Language Class Initialized
INFO - 2021-07-12 08:24:31 --> Config Class Initialized
INFO - 2021-07-12 08:24:31 --> Loader Class Initialized
INFO - 2021-07-12 08:24:31 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:31 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:31 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:31 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:31 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:31 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:31 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:31 --> Total execution time: 0.1203
INFO - 2021-07-12 08:24:33 --> Config Class Initialized
INFO - 2021-07-12 08:24:33 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:33 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:33 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:33 --> URI Class Initialized
INFO - 2021-07-12 08:24:33 --> Router Class Initialized
INFO - 2021-07-12 08:24:33 --> Output Class Initialized
INFO - 2021-07-12 08:24:33 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:33 --> Input Class Initialized
INFO - 2021-07-12 08:24:33 --> Language Class Initialized
INFO - 2021-07-12 08:24:33 --> Language Class Initialized
INFO - 2021-07-12 08:24:33 --> Config Class Initialized
INFO - 2021-07-12 08:24:33 --> Loader Class Initialized
INFO - 2021-07-12 08:24:33 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:33 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:33 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:33 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:33 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:33 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:33 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:33 --> Total execution time: 0.1173
INFO - 2021-07-12 08:24:35 --> Config Class Initialized
INFO - 2021-07-12 08:24:35 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:35 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:35 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:35 --> URI Class Initialized
INFO - 2021-07-12 08:24:35 --> Router Class Initialized
INFO - 2021-07-12 08:24:35 --> Output Class Initialized
INFO - 2021-07-12 08:24:35 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:35 --> Input Class Initialized
INFO - 2021-07-12 08:24:35 --> Language Class Initialized
INFO - 2021-07-12 08:24:35 --> Language Class Initialized
INFO - 2021-07-12 08:24:35 --> Config Class Initialized
INFO - 2021-07-12 08:24:35 --> Loader Class Initialized
INFO - 2021-07-12 08:24:35 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:35 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:35 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:35 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:35 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:35 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:35 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:35 --> Total execution time: 0.1272
INFO - 2021-07-12 08:24:37 --> Config Class Initialized
INFO - 2021-07-12 08:24:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:37 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:37 --> URI Class Initialized
INFO - 2021-07-12 08:24:37 --> Router Class Initialized
INFO - 2021-07-12 08:24:37 --> Output Class Initialized
INFO - 2021-07-12 08:24:37 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:37 --> Input Class Initialized
INFO - 2021-07-12 08:24:37 --> Language Class Initialized
INFO - 2021-07-12 08:24:37 --> Language Class Initialized
INFO - 2021-07-12 08:24:37 --> Config Class Initialized
INFO - 2021-07-12 08:24:37 --> Loader Class Initialized
INFO - 2021-07-12 08:24:37 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:37 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:37 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:37 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:37 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:37 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:37 --> Total execution time: 0.1232
INFO - 2021-07-12 08:24:39 --> Config Class Initialized
INFO - 2021-07-12 08:24:39 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:39 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:39 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:39 --> URI Class Initialized
INFO - 2021-07-12 08:24:39 --> Router Class Initialized
INFO - 2021-07-12 08:24:39 --> Output Class Initialized
INFO - 2021-07-12 08:24:39 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:39 --> Input Class Initialized
INFO - 2021-07-12 08:24:39 --> Language Class Initialized
INFO - 2021-07-12 08:24:39 --> Language Class Initialized
INFO - 2021-07-12 08:24:39 --> Config Class Initialized
INFO - 2021-07-12 08:24:39 --> Loader Class Initialized
INFO - 2021-07-12 08:24:39 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:39 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:39 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:39 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:39 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:39 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:39 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:39 --> Total execution time: 0.1151
INFO - 2021-07-12 08:24:40 --> Config Class Initialized
INFO - 2021-07-12 08:24:40 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:40 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:40 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:40 --> URI Class Initialized
INFO - 2021-07-12 08:24:40 --> Router Class Initialized
INFO - 2021-07-12 08:24:40 --> Output Class Initialized
INFO - 2021-07-12 08:24:40 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:40 --> Input Class Initialized
INFO - 2021-07-12 08:24:40 --> Language Class Initialized
INFO - 2021-07-12 08:24:40 --> Language Class Initialized
INFO - 2021-07-12 08:24:40 --> Config Class Initialized
INFO - 2021-07-12 08:24:40 --> Loader Class Initialized
INFO - 2021-07-12 08:24:40 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:40 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:40 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:40 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:40 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:40 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:40 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:40 --> Total execution time: 0.1169
INFO - 2021-07-12 08:24:42 --> Config Class Initialized
INFO - 2021-07-12 08:24:42 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:42 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:42 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:42 --> URI Class Initialized
INFO - 2021-07-12 08:24:42 --> Router Class Initialized
INFO - 2021-07-12 08:24:42 --> Output Class Initialized
INFO - 2021-07-12 08:24:42 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:42 --> Input Class Initialized
INFO - 2021-07-12 08:24:42 --> Language Class Initialized
INFO - 2021-07-12 08:24:43 --> Language Class Initialized
INFO - 2021-07-12 08:24:43 --> Config Class Initialized
INFO - 2021-07-12 08:24:43 --> Loader Class Initialized
INFO - 2021-07-12 08:24:43 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:43 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:43 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:43 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:43 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:43 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:43 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:43 --> Total execution time: 0.1344
INFO - 2021-07-12 08:24:44 --> Config Class Initialized
INFO - 2021-07-12 08:24:44 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:44 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:44 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:44 --> URI Class Initialized
INFO - 2021-07-12 08:24:44 --> Router Class Initialized
INFO - 2021-07-12 08:24:44 --> Output Class Initialized
INFO - 2021-07-12 08:24:44 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:44 --> Input Class Initialized
INFO - 2021-07-12 08:24:44 --> Language Class Initialized
INFO - 2021-07-12 08:24:44 --> Language Class Initialized
INFO - 2021-07-12 08:24:44 --> Config Class Initialized
INFO - 2021-07-12 08:24:44 --> Loader Class Initialized
INFO - 2021-07-12 08:24:44 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:44 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:44 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:44 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:44 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:44 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:44 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:44 --> Total execution time: 0.1167
INFO - 2021-07-12 08:24:46 --> Config Class Initialized
INFO - 2021-07-12 08:24:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:46 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:46 --> URI Class Initialized
INFO - 2021-07-12 08:24:46 --> Router Class Initialized
INFO - 2021-07-12 08:24:46 --> Output Class Initialized
INFO - 2021-07-12 08:24:46 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:46 --> Input Class Initialized
INFO - 2021-07-12 08:24:46 --> Language Class Initialized
INFO - 2021-07-12 08:24:46 --> Language Class Initialized
INFO - 2021-07-12 08:24:46 --> Config Class Initialized
INFO - 2021-07-12 08:24:46 --> Loader Class Initialized
INFO - 2021-07-12 08:24:46 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:46 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:46 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:46 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:46 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:46 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:46 --> Total execution time: 0.1194
INFO - 2021-07-12 08:24:49 --> Config Class Initialized
INFO - 2021-07-12 08:24:49 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:49 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:49 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:49 --> URI Class Initialized
INFO - 2021-07-12 08:24:49 --> Router Class Initialized
INFO - 2021-07-12 08:24:49 --> Output Class Initialized
INFO - 2021-07-12 08:24:49 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:49 --> Input Class Initialized
INFO - 2021-07-12 08:24:49 --> Language Class Initialized
INFO - 2021-07-12 08:24:49 --> Language Class Initialized
INFO - 2021-07-12 08:24:49 --> Config Class Initialized
INFO - 2021-07-12 08:24:49 --> Loader Class Initialized
INFO - 2021-07-12 08:24:49 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:49 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:49 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:49 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:49 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:49 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:49 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:49 --> Total execution time: 0.1336
INFO - 2021-07-12 08:24:50 --> Config Class Initialized
INFO - 2021-07-12 08:24:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:50 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:50 --> URI Class Initialized
INFO - 2021-07-12 08:24:50 --> Router Class Initialized
INFO - 2021-07-12 08:24:50 --> Output Class Initialized
INFO - 2021-07-12 08:24:50 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:50 --> Input Class Initialized
INFO - 2021-07-12 08:24:50 --> Language Class Initialized
INFO - 2021-07-12 08:24:50 --> Language Class Initialized
INFO - 2021-07-12 08:24:50 --> Config Class Initialized
INFO - 2021-07-12 08:24:50 --> Loader Class Initialized
INFO - 2021-07-12 08:24:50 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:50 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:50 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:50 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:51 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:51 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:51 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:51 --> Total execution time: 0.1219
INFO - 2021-07-12 08:24:52 --> Config Class Initialized
INFO - 2021-07-12 08:24:52 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:24:52 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:24:52 --> Utf8 Class Initialized
INFO - 2021-07-12 08:24:52 --> URI Class Initialized
INFO - 2021-07-12 08:24:52 --> Router Class Initialized
INFO - 2021-07-12 08:24:52 --> Output Class Initialized
INFO - 2021-07-12 08:24:52 --> Security Class Initialized
DEBUG - 2021-07-12 08:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:24:52 --> Input Class Initialized
INFO - 2021-07-12 08:24:52 --> Language Class Initialized
INFO - 2021-07-12 08:24:52 --> Language Class Initialized
INFO - 2021-07-12 08:24:52 --> Config Class Initialized
INFO - 2021-07-12 08:24:52 --> Loader Class Initialized
INFO - 2021-07-12 08:24:52 --> Helper loaded: url_helper
INFO - 2021-07-12 08:24:52 --> Helper loaded: file_helper
INFO - 2021-07-12 08:24:52 --> Helper loaded: form_helper
INFO - 2021-07-12 08:24:52 --> Helper loaded: my_helper
INFO - 2021-07-12 08:24:52 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:24:52 --> Controller Class Initialized
DEBUG - 2021-07-12 08:24:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:24:52 --> Final output sent to browser
DEBUG - 2021-07-12 08:24:52 --> Total execution time: 0.1196
INFO - 2021-07-12 08:30:53 --> Config Class Initialized
INFO - 2021-07-12 08:30:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:30:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:30:53 --> Utf8 Class Initialized
INFO - 2021-07-12 08:30:53 --> URI Class Initialized
INFO - 2021-07-12 08:30:53 --> Router Class Initialized
INFO - 2021-07-12 08:30:53 --> Output Class Initialized
INFO - 2021-07-12 08:30:53 --> Security Class Initialized
DEBUG - 2021-07-12 08:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:30:53 --> Input Class Initialized
INFO - 2021-07-12 08:30:53 --> Language Class Initialized
INFO - 2021-07-12 08:30:53 --> Language Class Initialized
INFO - 2021-07-12 08:30:53 --> Config Class Initialized
INFO - 2021-07-12 08:30:53 --> Loader Class Initialized
INFO - 2021-07-12 08:30:53 --> Helper loaded: url_helper
INFO - 2021-07-12 08:30:53 --> Helper loaded: file_helper
INFO - 2021-07-12 08:30:53 --> Helper loaded: form_helper
INFO - 2021-07-12 08:30:53 --> Helper loaded: my_helper
INFO - 2021-07-12 08:30:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:30:53 --> Controller Class Initialized
DEBUG - 2021-07-12 08:30:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:30:53 --> Final output sent to browser
DEBUG - 2021-07-12 08:30:53 --> Total execution time: 0.1506
INFO - 2021-07-12 08:31:28 --> Config Class Initialized
INFO - 2021-07-12 08:31:28 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:31:28 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:31:28 --> Utf8 Class Initialized
INFO - 2021-07-12 08:31:28 --> URI Class Initialized
INFO - 2021-07-12 08:31:28 --> Router Class Initialized
INFO - 2021-07-12 08:31:28 --> Output Class Initialized
INFO - 2021-07-12 08:31:28 --> Security Class Initialized
DEBUG - 2021-07-12 08:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:31:28 --> Input Class Initialized
INFO - 2021-07-12 08:31:28 --> Language Class Initialized
INFO - 2021-07-12 08:31:28 --> Language Class Initialized
INFO - 2021-07-12 08:31:28 --> Config Class Initialized
INFO - 2021-07-12 08:31:28 --> Loader Class Initialized
INFO - 2021-07-12 08:31:28 --> Helper loaded: url_helper
INFO - 2021-07-12 08:31:28 --> Helper loaded: file_helper
INFO - 2021-07-12 08:31:28 --> Helper loaded: form_helper
INFO - 2021-07-12 08:31:28 --> Helper loaded: my_helper
INFO - 2021-07-12 08:31:28 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:31:28 --> Controller Class Initialized
DEBUG - 2021-07-12 08:31:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:31:28 --> Final output sent to browser
DEBUG - 2021-07-12 08:31:28 --> Total execution time: 0.1511
INFO - 2021-07-12 08:32:28 --> Config Class Initialized
INFO - 2021-07-12 08:32:28 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:32:28 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:32:28 --> Utf8 Class Initialized
INFO - 2021-07-12 08:32:28 --> URI Class Initialized
INFO - 2021-07-12 08:32:28 --> Router Class Initialized
INFO - 2021-07-12 08:32:28 --> Output Class Initialized
INFO - 2021-07-12 08:32:28 --> Security Class Initialized
DEBUG - 2021-07-12 08:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:32:28 --> Input Class Initialized
INFO - 2021-07-12 08:32:28 --> Language Class Initialized
INFO - 2021-07-12 08:32:28 --> Language Class Initialized
INFO - 2021-07-12 08:32:28 --> Config Class Initialized
INFO - 2021-07-12 08:32:28 --> Loader Class Initialized
INFO - 2021-07-12 08:32:28 --> Helper loaded: url_helper
INFO - 2021-07-12 08:32:28 --> Helper loaded: file_helper
INFO - 2021-07-12 08:32:28 --> Helper loaded: form_helper
INFO - 2021-07-12 08:32:28 --> Helper loaded: my_helper
INFO - 2021-07-12 08:32:28 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:32:28 --> Controller Class Initialized
DEBUG - 2021-07-12 08:32:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:32:28 --> Final output sent to browser
DEBUG - 2021-07-12 08:32:28 --> Total execution time: 0.1557
INFO - 2021-07-12 08:32:57 --> Config Class Initialized
INFO - 2021-07-12 08:32:57 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:32:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:32:57 --> Utf8 Class Initialized
INFO - 2021-07-12 08:32:57 --> URI Class Initialized
INFO - 2021-07-12 08:32:57 --> Router Class Initialized
INFO - 2021-07-12 08:32:57 --> Output Class Initialized
INFO - 2021-07-12 08:32:57 --> Security Class Initialized
DEBUG - 2021-07-12 08:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:32:57 --> Input Class Initialized
INFO - 2021-07-12 08:32:57 --> Language Class Initialized
INFO - 2021-07-12 08:32:57 --> Language Class Initialized
INFO - 2021-07-12 08:32:57 --> Config Class Initialized
INFO - 2021-07-12 08:32:57 --> Loader Class Initialized
INFO - 2021-07-12 08:32:57 --> Helper loaded: url_helper
INFO - 2021-07-12 08:32:57 --> Helper loaded: file_helper
INFO - 2021-07-12 08:32:57 --> Helper loaded: form_helper
INFO - 2021-07-12 08:32:57 --> Helper loaded: my_helper
INFO - 2021-07-12 08:32:57 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:32:57 --> Controller Class Initialized
DEBUG - 2021-07-12 08:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:32:57 --> Final output sent to browser
DEBUG - 2021-07-12 08:32:57 --> Total execution time: 0.1313
INFO - 2021-07-12 08:32:59 --> Config Class Initialized
INFO - 2021-07-12 08:32:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:32:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:32:59 --> Utf8 Class Initialized
INFO - 2021-07-12 08:32:59 --> URI Class Initialized
INFO - 2021-07-12 08:32:59 --> Router Class Initialized
INFO - 2021-07-12 08:32:59 --> Output Class Initialized
INFO - 2021-07-12 08:32:59 --> Security Class Initialized
DEBUG - 2021-07-12 08:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:32:59 --> Input Class Initialized
INFO - 2021-07-12 08:32:59 --> Language Class Initialized
INFO - 2021-07-12 08:32:59 --> Language Class Initialized
INFO - 2021-07-12 08:32:59 --> Config Class Initialized
INFO - 2021-07-12 08:32:59 --> Loader Class Initialized
INFO - 2021-07-12 08:32:59 --> Helper loaded: url_helper
INFO - 2021-07-12 08:32:59 --> Helper loaded: file_helper
INFO - 2021-07-12 08:32:59 --> Helper loaded: form_helper
INFO - 2021-07-12 08:32:59 --> Helper loaded: my_helper
INFO - 2021-07-12 08:32:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:32:59 --> Controller Class Initialized
DEBUG - 2021-07-12 08:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:32:59 --> Final output sent to browser
DEBUG - 2021-07-12 08:32:59 --> Total execution time: 0.1562
INFO - 2021-07-12 08:33:01 --> Config Class Initialized
INFO - 2021-07-12 08:33:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:01 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:01 --> URI Class Initialized
INFO - 2021-07-12 08:33:01 --> Router Class Initialized
INFO - 2021-07-12 08:33:01 --> Output Class Initialized
INFO - 2021-07-12 08:33:01 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:01 --> Input Class Initialized
INFO - 2021-07-12 08:33:01 --> Language Class Initialized
INFO - 2021-07-12 08:33:01 --> Language Class Initialized
INFO - 2021-07-12 08:33:01 --> Config Class Initialized
INFO - 2021-07-12 08:33:01 --> Loader Class Initialized
INFO - 2021-07-12 08:33:01 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:01 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:01 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:01 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:01 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:01 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:01 --> Total execution time: 0.1358
INFO - 2021-07-12 08:33:05 --> Config Class Initialized
INFO - 2021-07-12 08:33:05 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:05 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:05 --> URI Class Initialized
INFO - 2021-07-12 08:33:05 --> Router Class Initialized
INFO - 2021-07-12 08:33:05 --> Output Class Initialized
INFO - 2021-07-12 08:33:05 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:05 --> Input Class Initialized
INFO - 2021-07-12 08:33:05 --> Language Class Initialized
INFO - 2021-07-12 08:33:05 --> Language Class Initialized
INFO - 2021-07-12 08:33:05 --> Config Class Initialized
INFO - 2021-07-12 08:33:05 --> Loader Class Initialized
INFO - 2021-07-12 08:33:05 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:05 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:05 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:05 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:05 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:05 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:05 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:05 --> Total execution time: 0.1298
INFO - 2021-07-12 08:33:07 --> Config Class Initialized
INFO - 2021-07-12 08:33:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:07 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:07 --> URI Class Initialized
INFO - 2021-07-12 08:33:07 --> Router Class Initialized
INFO - 2021-07-12 08:33:07 --> Output Class Initialized
INFO - 2021-07-12 08:33:07 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:07 --> Input Class Initialized
INFO - 2021-07-12 08:33:07 --> Language Class Initialized
INFO - 2021-07-12 08:33:07 --> Language Class Initialized
INFO - 2021-07-12 08:33:07 --> Config Class Initialized
INFO - 2021-07-12 08:33:07 --> Loader Class Initialized
INFO - 2021-07-12 08:33:07 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:07 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:07 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:07 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:07 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:07 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:07 --> Total execution time: 0.1321
INFO - 2021-07-12 08:33:09 --> Config Class Initialized
INFO - 2021-07-12 08:33:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:09 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:09 --> URI Class Initialized
INFO - 2021-07-12 08:33:09 --> Router Class Initialized
INFO - 2021-07-12 08:33:09 --> Output Class Initialized
INFO - 2021-07-12 08:33:09 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:09 --> Input Class Initialized
INFO - 2021-07-12 08:33:09 --> Language Class Initialized
INFO - 2021-07-12 08:33:09 --> Language Class Initialized
INFO - 2021-07-12 08:33:09 --> Config Class Initialized
INFO - 2021-07-12 08:33:09 --> Loader Class Initialized
INFO - 2021-07-12 08:33:09 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:09 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:09 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:09 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:09 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:09 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:09 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:09 --> Total execution time: 0.1449
INFO - 2021-07-12 08:33:11 --> Config Class Initialized
INFO - 2021-07-12 08:33:11 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:11 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:11 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:11 --> URI Class Initialized
INFO - 2021-07-12 08:33:11 --> Router Class Initialized
INFO - 2021-07-12 08:33:11 --> Output Class Initialized
INFO - 2021-07-12 08:33:11 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:11 --> Input Class Initialized
INFO - 2021-07-12 08:33:11 --> Language Class Initialized
INFO - 2021-07-12 08:33:11 --> Language Class Initialized
INFO - 2021-07-12 08:33:11 --> Config Class Initialized
INFO - 2021-07-12 08:33:11 --> Loader Class Initialized
INFO - 2021-07-12 08:33:11 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:11 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:11 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:11 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:11 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:11 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:11 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:11 --> Total execution time: 0.1288
INFO - 2021-07-12 08:33:15 --> Config Class Initialized
INFO - 2021-07-12 08:33:15 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:15 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:15 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:15 --> URI Class Initialized
INFO - 2021-07-12 08:33:15 --> Router Class Initialized
INFO - 2021-07-12 08:33:15 --> Output Class Initialized
INFO - 2021-07-12 08:33:15 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:15 --> Input Class Initialized
INFO - 2021-07-12 08:33:15 --> Language Class Initialized
INFO - 2021-07-12 08:33:15 --> Language Class Initialized
INFO - 2021-07-12 08:33:15 --> Config Class Initialized
INFO - 2021-07-12 08:33:15 --> Loader Class Initialized
INFO - 2021-07-12 08:33:15 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:15 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:15 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:15 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:15 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:15 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:15 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:15 --> Total execution time: 0.1425
INFO - 2021-07-12 08:33:18 --> Config Class Initialized
INFO - 2021-07-12 08:33:18 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:18 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:18 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:18 --> URI Class Initialized
INFO - 2021-07-12 08:33:18 --> Router Class Initialized
INFO - 2021-07-12 08:33:18 --> Output Class Initialized
INFO - 2021-07-12 08:33:18 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:18 --> Input Class Initialized
INFO - 2021-07-12 08:33:18 --> Language Class Initialized
INFO - 2021-07-12 08:33:18 --> Language Class Initialized
INFO - 2021-07-12 08:33:18 --> Config Class Initialized
INFO - 2021-07-12 08:33:18 --> Loader Class Initialized
INFO - 2021-07-12 08:33:18 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:18 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:18 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:18 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:18 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:18 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:18 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:18 --> Total execution time: 0.1327
INFO - 2021-07-12 08:33:20 --> Config Class Initialized
INFO - 2021-07-12 08:33:20 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:20 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:20 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:20 --> URI Class Initialized
INFO - 2021-07-12 08:33:20 --> Router Class Initialized
INFO - 2021-07-12 08:33:20 --> Output Class Initialized
INFO - 2021-07-12 08:33:20 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:20 --> Input Class Initialized
INFO - 2021-07-12 08:33:20 --> Language Class Initialized
INFO - 2021-07-12 08:33:20 --> Language Class Initialized
INFO - 2021-07-12 08:33:20 --> Config Class Initialized
INFO - 2021-07-12 08:33:20 --> Loader Class Initialized
INFO - 2021-07-12 08:33:20 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:20 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:20 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:20 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:20 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:20 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:20 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:20 --> Total execution time: 0.1480
INFO - 2021-07-12 08:33:23 --> Config Class Initialized
INFO - 2021-07-12 08:33:23 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:33:23 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:33:23 --> Utf8 Class Initialized
INFO - 2021-07-12 08:33:23 --> URI Class Initialized
INFO - 2021-07-12 08:33:23 --> Router Class Initialized
INFO - 2021-07-12 08:33:23 --> Output Class Initialized
INFO - 2021-07-12 08:33:23 --> Security Class Initialized
DEBUG - 2021-07-12 08:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:33:23 --> Input Class Initialized
INFO - 2021-07-12 08:33:23 --> Language Class Initialized
INFO - 2021-07-12 08:33:23 --> Language Class Initialized
INFO - 2021-07-12 08:33:23 --> Config Class Initialized
INFO - 2021-07-12 08:33:23 --> Loader Class Initialized
INFO - 2021-07-12 08:33:23 --> Helper loaded: url_helper
INFO - 2021-07-12 08:33:23 --> Helper loaded: file_helper
INFO - 2021-07-12 08:33:23 --> Helper loaded: form_helper
INFO - 2021-07-12 08:33:23 --> Helper loaded: my_helper
INFO - 2021-07-12 08:33:23 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:33:23 --> Controller Class Initialized
DEBUG - 2021-07-12 08:33:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-07-12 08:33:23 --> Final output sent to browser
DEBUG - 2021-07-12 08:33:23 --> Total execution time: 0.1259
INFO - 2021-07-12 08:36:09 --> Config Class Initialized
INFO - 2021-07-12 08:36:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:36:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:36:09 --> Utf8 Class Initialized
INFO - 2021-07-12 08:36:09 --> URI Class Initialized
INFO - 2021-07-12 08:36:09 --> Router Class Initialized
INFO - 2021-07-12 08:36:09 --> Output Class Initialized
INFO - 2021-07-12 08:36:09 --> Security Class Initialized
DEBUG - 2021-07-12 08:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:36:09 --> Input Class Initialized
INFO - 2021-07-12 08:36:09 --> Language Class Initialized
INFO - 2021-07-12 08:36:09 --> Language Class Initialized
INFO - 2021-07-12 08:36:09 --> Config Class Initialized
INFO - 2021-07-12 08:36:09 --> Loader Class Initialized
INFO - 2021-07-12 08:36:09 --> Helper loaded: url_helper
INFO - 2021-07-12 08:36:09 --> Helper loaded: file_helper
INFO - 2021-07-12 08:36:09 --> Helper loaded: form_helper
INFO - 2021-07-12 08:36:09 --> Helper loaded: my_helper
INFO - 2021-07-12 08:36:09 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:36:09 --> Controller Class Initialized
DEBUG - 2021-07-12 08:36:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-07-12 08:36:09 --> Final output sent to browser
DEBUG - 2021-07-12 08:36:09 --> Total execution time: 0.1419
INFO - 2021-07-12 08:38:59 --> Config Class Initialized
INFO - 2021-07-12 08:38:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:38:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:38:59 --> Utf8 Class Initialized
INFO - 2021-07-12 08:38:59 --> URI Class Initialized
INFO - 2021-07-12 08:38:59 --> Router Class Initialized
INFO - 2021-07-12 08:38:59 --> Output Class Initialized
INFO - 2021-07-12 08:38:59 --> Security Class Initialized
DEBUG - 2021-07-12 08:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:38:59 --> Input Class Initialized
INFO - 2021-07-12 08:38:59 --> Language Class Initialized
INFO - 2021-07-12 08:38:59 --> Language Class Initialized
INFO - 2021-07-12 08:38:59 --> Config Class Initialized
INFO - 2021-07-12 08:38:59 --> Loader Class Initialized
INFO - 2021-07-12 08:38:59 --> Helper loaded: url_helper
INFO - 2021-07-12 08:38:59 --> Helper loaded: file_helper
INFO - 2021-07-12 08:38:59 --> Helper loaded: form_helper
INFO - 2021-07-12 08:38:59 --> Helper loaded: my_helper
INFO - 2021-07-12 08:38:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:38:59 --> Controller Class Initialized
INFO - 2021-07-12 08:38:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:38:59 --> Config Class Initialized
INFO - 2021-07-12 08:38:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:38:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:38:59 --> Utf8 Class Initialized
INFO - 2021-07-12 08:38:59 --> URI Class Initialized
INFO - 2021-07-12 08:38:59 --> Router Class Initialized
INFO - 2021-07-12 08:38:59 --> Output Class Initialized
INFO - 2021-07-12 08:38:59 --> Security Class Initialized
DEBUG - 2021-07-12 08:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:38:59 --> Input Class Initialized
INFO - 2021-07-12 08:38:59 --> Language Class Initialized
INFO - 2021-07-12 08:38:59 --> Language Class Initialized
INFO - 2021-07-12 08:38:59 --> Config Class Initialized
INFO - 2021-07-12 08:38:59 --> Loader Class Initialized
INFO - 2021-07-12 08:38:59 --> Helper loaded: url_helper
INFO - 2021-07-12 08:38:59 --> Helper loaded: file_helper
INFO - 2021-07-12 08:38:59 --> Helper loaded: form_helper
INFO - 2021-07-12 08:38:59 --> Helper loaded: my_helper
INFO - 2021-07-12 08:38:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:38:59 --> Controller Class Initialized
DEBUG - 2021-07-12 08:38:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 08:38:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:38:59 --> Final output sent to browser
DEBUG - 2021-07-12 08:38:59 --> Total execution time: 0.0651
INFO - 2021-07-12 08:39:06 --> Config Class Initialized
INFO - 2021-07-12 08:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:39:06 --> Utf8 Class Initialized
INFO - 2021-07-12 08:39:06 --> URI Class Initialized
INFO - 2021-07-12 08:39:06 --> Router Class Initialized
INFO - 2021-07-12 08:39:06 --> Output Class Initialized
INFO - 2021-07-12 08:39:06 --> Security Class Initialized
DEBUG - 2021-07-12 08:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:39:06 --> Input Class Initialized
INFO - 2021-07-12 08:39:06 --> Language Class Initialized
INFO - 2021-07-12 08:39:06 --> Language Class Initialized
INFO - 2021-07-12 08:39:06 --> Config Class Initialized
INFO - 2021-07-12 08:39:06 --> Loader Class Initialized
INFO - 2021-07-12 08:39:06 --> Helper loaded: url_helper
INFO - 2021-07-12 08:39:06 --> Helper loaded: file_helper
INFO - 2021-07-12 08:39:06 --> Helper loaded: form_helper
INFO - 2021-07-12 08:39:06 --> Helper loaded: my_helper
INFO - 2021-07-12 08:39:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:39:06 --> Controller Class Initialized
INFO - 2021-07-12 08:39:06 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:39:06 --> Final output sent to browser
DEBUG - 2021-07-12 08:39:06 --> Total execution time: 0.0666
INFO - 2021-07-12 08:39:06 --> Config Class Initialized
INFO - 2021-07-12 08:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:39:06 --> Utf8 Class Initialized
INFO - 2021-07-12 08:39:06 --> URI Class Initialized
INFO - 2021-07-12 08:39:06 --> Router Class Initialized
INFO - 2021-07-12 08:39:06 --> Output Class Initialized
INFO - 2021-07-12 08:39:06 --> Security Class Initialized
DEBUG - 2021-07-12 08:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:39:06 --> Input Class Initialized
INFO - 2021-07-12 08:39:06 --> Language Class Initialized
INFO - 2021-07-12 08:39:06 --> Language Class Initialized
INFO - 2021-07-12 08:39:06 --> Config Class Initialized
INFO - 2021-07-12 08:39:06 --> Loader Class Initialized
INFO - 2021-07-12 08:39:06 --> Helper loaded: url_helper
INFO - 2021-07-12 08:39:06 --> Helper loaded: file_helper
INFO - 2021-07-12 08:39:06 --> Helper loaded: form_helper
INFO - 2021-07-12 08:39:06 --> Helper loaded: my_helper
INFO - 2021-07-12 08:39:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:39:06 --> Controller Class Initialized
DEBUG - 2021-07-12 08:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 08:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:39:07 --> Final output sent to browser
DEBUG - 2021-07-12 08:39:07 --> Total execution time: 0.7359
INFO - 2021-07-12 08:39:40 --> Config Class Initialized
INFO - 2021-07-12 08:39:40 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:39:40 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:39:40 --> Utf8 Class Initialized
INFO - 2021-07-12 08:39:40 --> URI Class Initialized
INFO - 2021-07-12 08:39:40 --> Router Class Initialized
INFO - 2021-07-12 08:39:40 --> Output Class Initialized
INFO - 2021-07-12 08:39:40 --> Security Class Initialized
DEBUG - 2021-07-12 08:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:39:40 --> Input Class Initialized
INFO - 2021-07-12 08:39:40 --> Language Class Initialized
INFO - 2021-07-12 08:39:40 --> Language Class Initialized
INFO - 2021-07-12 08:39:40 --> Config Class Initialized
INFO - 2021-07-12 08:39:40 --> Loader Class Initialized
INFO - 2021-07-12 08:39:40 --> Helper loaded: url_helper
INFO - 2021-07-12 08:39:40 --> Helper loaded: file_helper
INFO - 2021-07-12 08:39:40 --> Helper loaded: form_helper
INFO - 2021-07-12 08:39:40 --> Helper loaded: my_helper
INFO - 2021-07-12 08:39:40 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:39:41 --> Controller Class Initialized
DEBUG - 2021-07-12 08:39:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 08:39:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:39:41 --> Final output sent to browser
DEBUG - 2021-07-12 08:39:41 --> Total execution time: 0.0681
INFO - 2021-07-12 08:39:42 --> Config Class Initialized
INFO - 2021-07-12 08:39:42 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:39:42 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:39:42 --> Utf8 Class Initialized
INFO - 2021-07-12 08:39:42 --> URI Class Initialized
INFO - 2021-07-12 08:39:42 --> Router Class Initialized
INFO - 2021-07-12 08:39:42 --> Output Class Initialized
INFO - 2021-07-12 08:39:42 --> Security Class Initialized
DEBUG - 2021-07-12 08:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:39:42 --> Input Class Initialized
INFO - 2021-07-12 08:39:42 --> Language Class Initialized
INFO - 2021-07-12 08:39:42 --> Language Class Initialized
INFO - 2021-07-12 08:39:42 --> Config Class Initialized
INFO - 2021-07-12 08:39:42 --> Loader Class Initialized
INFO - 2021-07-12 08:39:42 --> Helper loaded: url_helper
INFO - 2021-07-12 08:39:42 --> Helper loaded: file_helper
INFO - 2021-07-12 08:39:42 --> Helper loaded: form_helper
INFO - 2021-07-12 08:39:42 --> Helper loaded: my_helper
INFO - 2021-07-12 08:39:42 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:39:42 --> Controller Class Initialized
DEBUG - 2021-07-12 08:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-07-12 08:39:42 --> Final output sent to browser
DEBUG - 2021-07-12 08:39:42 --> Total execution time: 0.2337
INFO - 2021-07-12 08:39:54 --> Config Class Initialized
INFO - 2021-07-12 08:39:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:39:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:39:54 --> Utf8 Class Initialized
INFO - 2021-07-12 08:39:54 --> URI Class Initialized
INFO - 2021-07-12 08:39:54 --> Router Class Initialized
INFO - 2021-07-12 08:39:54 --> Output Class Initialized
INFO - 2021-07-12 08:39:54 --> Security Class Initialized
DEBUG - 2021-07-12 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:39:54 --> Input Class Initialized
INFO - 2021-07-12 08:39:54 --> Language Class Initialized
INFO - 2021-07-12 08:39:54 --> Language Class Initialized
INFO - 2021-07-12 08:39:54 --> Config Class Initialized
INFO - 2021-07-12 08:39:54 --> Loader Class Initialized
INFO - 2021-07-12 08:39:54 --> Helper loaded: url_helper
INFO - 2021-07-12 08:39:54 --> Helper loaded: file_helper
INFO - 2021-07-12 08:39:54 --> Helper loaded: form_helper
INFO - 2021-07-12 08:39:54 --> Helper loaded: my_helper
INFO - 2021-07-12 08:39:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:39:54 --> Controller Class Initialized
INFO - 2021-07-12 08:39:54 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:39:54 --> Config Class Initialized
INFO - 2021-07-12 08:39:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:39:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:39:54 --> Utf8 Class Initialized
INFO - 2021-07-12 08:39:54 --> URI Class Initialized
INFO - 2021-07-12 08:39:54 --> Router Class Initialized
INFO - 2021-07-12 08:39:54 --> Output Class Initialized
INFO - 2021-07-12 08:39:54 --> Security Class Initialized
DEBUG - 2021-07-12 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:39:54 --> Input Class Initialized
INFO - 2021-07-12 08:39:54 --> Language Class Initialized
INFO - 2021-07-12 08:39:54 --> Language Class Initialized
INFO - 2021-07-12 08:39:54 --> Config Class Initialized
INFO - 2021-07-12 08:39:54 --> Loader Class Initialized
INFO - 2021-07-12 08:39:54 --> Helper loaded: url_helper
INFO - 2021-07-12 08:39:54 --> Helper loaded: file_helper
INFO - 2021-07-12 08:39:54 --> Helper loaded: form_helper
INFO - 2021-07-12 08:39:54 --> Helper loaded: my_helper
INFO - 2021-07-12 08:39:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:39:54 --> Controller Class Initialized
DEBUG - 2021-07-12 08:39:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 08:39:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:39:54 --> Final output sent to browser
DEBUG - 2021-07-12 08:39:54 --> Total execution time: 0.0547
INFO - 2021-07-12 08:43:01 --> Config Class Initialized
INFO - 2021-07-12 08:43:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:43:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:43:01 --> Utf8 Class Initialized
INFO - 2021-07-12 08:43:01 --> URI Class Initialized
INFO - 2021-07-12 08:43:01 --> Router Class Initialized
INFO - 2021-07-12 08:43:01 --> Output Class Initialized
INFO - 2021-07-12 08:43:01 --> Security Class Initialized
DEBUG - 2021-07-12 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:43:01 --> Input Class Initialized
INFO - 2021-07-12 08:43:01 --> Language Class Initialized
INFO - 2021-07-12 08:43:01 --> Language Class Initialized
INFO - 2021-07-12 08:43:01 --> Config Class Initialized
INFO - 2021-07-12 08:43:01 --> Loader Class Initialized
INFO - 2021-07-12 08:43:01 --> Helper loaded: url_helper
INFO - 2021-07-12 08:43:01 --> Helper loaded: file_helper
INFO - 2021-07-12 08:43:01 --> Helper loaded: form_helper
INFO - 2021-07-12 08:43:01 --> Helper loaded: my_helper
INFO - 2021-07-12 08:43:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:43:01 --> Controller Class Initialized
INFO - 2021-07-12 08:43:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:43:01 --> Final output sent to browser
DEBUG - 2021-07-12 08:43:01 --> Total execution time: 0.0542
INFO - 2021-07-12 08:43:01 --> Config Class Initialized
INFO - 2021-07-12 08:43:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:43:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:43:01 --> Utf8 Class Initialized
INFO - 2021-07-12 08:43:01 --> URI Class Initialized
INFO - 2021-07-12 08:43:01 --> Router Class Initialized
INFO - 2021-07-12 08:43:01 --> Output Class Initialized
INFO - 2021-07-12 08:43:01 --> Security Class Initialized
DEBUG - 2021-07-12 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:43:01 --> Input Class Initialized
INFO - 2021-07-12 08:43:01 --> Language Class Initialized
INFO - 2021-07-12 08:43:01 --> Language Class Initialized
INFO - 2021-07-12 08:43:01 --> Config Class Initialized
INFO - 2021-07-12 08:43:01 --> Loader Class Initialized
INFO - 2021-07-12 08:43:01 --> Helper loaded: url_helper
INFO - 2021-07-12 08:43:01 --> Helper loaded: file_helper
INFO - 2021-07-12 08:43:01 --> Helper loaded: form_helper
INFO - 2021-07-12 08:43:01 --> Helper loaded: my_helper
INFO - 2021-07-12 08:43:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:43:01 --> Controller Class Initialized
DEBUG - 2021-07-12 08:43:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 08:43:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:43:02 --> Final output sent to browser
DEBUG - 2021-07-12 08:43:02 --> Total execution time: 0.7222
INFO - 2021-07-12 08:43:07 --> Config Class Initialized
INFO - 2021-07-12 08:43:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:43:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:43:07 --> Utf8 Class Initialized
INFO - 2021-07-12 08:43:07 --> URI Class Initialized
INFO - 2021-07-12 08:43:07 --> Router Class Initialized
INFO - 2021-07-12 08:43:07 --> Output Class Initialized
INFO - 2021-07-12 08:43:07 --> Security Class Initialized
DEBUG - 2021-07-12 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:43:07 --> Input Class Initialized
INFO - 2021-07-12 08:43:07 --> Language Class Initialized
INFO - 2021-07-12 08:43:07 --> Language Class Initialized
INFO - 2021-07-12 08:43:07 --> Config Class Initialized
INFO - 2021-07-12 08:43:07 --> Loader Class Initialized
INFO - 2021-07-12 08:43:07 --> Helper loaded: url_helper
INFO - 2021-07-12 08:43:07 --> Helper loaded: file_helper
INFO - 2021-07-12 08:43:07 --> Helper loaded: form_helper
INFO - 2021-07-12 08:43:07 --> Helper loaded: my_helper
INFO - 2021-07-12 08:43:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:43:07 --> Controller Class Initialized
DEBUG - 2021-07-12 08:43:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-12 08:43:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:43:07 --> Final output sent to browser
DEBUG - 2021-07-12 08:43:07 --> Total execution time: 0.0727
INFO - 2021-07-12 08:43:10 --> Config Class Initialized
INFO - 2021-07-12 08:43:10 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:43:10 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:43:10 --> Utf8 Class Initialized
INFO - 2021-07-12 08:43:10 --> URI Class Initialized
INFO - 2021-07-12 08:43:10 --> Router Class Initialized
INFO - 2021-07-12 08:43:10 --> Output Class Initialized
INFO - 2021-07-12 08:43:10 --> Security Class Initialized
DEBUG - 2021-07-12 08:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:43:10 --> Input Class Initialized
INFO - 2021-07-12 08:43:10 --> Language Class Initialized
INFO - 2021-07-12 08:43:10 --> Language Class Initialized
INFO - 2021-07-12 08:43:10 --> Config Class Initialized
INFO - 2021-07-12 08:43:10 --> Loader Class Initialized
INFO - 2021-07-12 08:43:10 --> Helper loaded: url_helper
INFO - 2021-07-12 08:43:10 --> Helper loaded: file_helper
INFO - 2021-07-12 08:43:10 --> Helper loaded: form_helper
INFO - 2021-07-12 08:43:10 --> Helper loaded: my_helper
INFO - 2021-07-12 08:43:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:43:10 --> Controller Class Initialized
DEBUG - 2021-07-12 08:43:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-07-12 08:43:10 --> Final output sent to browser
DEBUG - 2021-07-12 08:43:10 --> Total execution time: 0.2364
INFO - 2021-07-12 08:43:56 --> Config Class Initialized
INFO - 2021-07-12 08:43:56 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:43:56 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:43:56 --> Utf8 Class Initialized
INFO - 2021-07-12 08:43:56 --> URI Class Initialized
INFO - 2021-07-12 08:43:56 --> Router Class Initialized
INFO - 2021-07-12 08:43:56 --> Output Class Initialized
INFO - 2021-07-12 08:43:56 --> Security Class Initialized
DEBUG - 2021-07-12 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:43:56 --> Input Class Initialized
INFO - 2021-07-12 08:43:56 --> Language Class Initialized
INFO - 2021-07-12 08:43:56 --> Language Class Initialized
INFO - 2021-07-12 08:43:56 --> Config Class Initialized
INFO - 2021-07-12 08:43:56 --> Loader Class Initialized
INFO - 2021-07-12 08:43:56 --> Helper loaded: url_helper
INFO - 2021-07-12 08:43:56 --> Helper loaded: file_helper
INFO - 2021-07-12 08:43:56 --> Helper loaded: form_helper
INFO - 2021-07-12 08:43:56 --> Helper loaded: my_helper
INFO - 2021-07-12 08:43:56 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:43:56 --> Controller Class Initialized
DEBUG - 2021-07-12 08:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 08:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:43:56 --> Final output sent to browser
DEBUG - 2021-07-12 08:43:56 --> Total execution time: 0.0770
INFO - 2021-07-12 08:44:01 --> Config Class Initialized
INFO - 2021-07-12 08:44:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:01 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:01 --> URI Class Initialized
INFO - 2021-07-12 08:44:01 --> Router Class Initialized
INFO - 2021-07-12 08:44:01 --> Output Class Initialized
INFO - 2021-07-12 08:44:01 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:01 --> Input Class Initialized
INFO - 2021-07-12 08:44:01 --> Language Class Initialized
INFO - 2021-07-12 08:44:01 --> Language Class Initialized
INFO - 2021-07-12 08:44:01 --> Config Class Initialized
INFO - 2021-07-12 08:44:01 --> Loader Class Initialized
INFO - 2021-07-12 08:44:01 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:01 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:01 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:01 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:01 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:01 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:01 --> Total execution time: 0.2029
INFO - 2021-07-12 08:44:02 --> Config Class Initialized
INFO - 2021-07-12 08:44:02 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:02 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:02 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:02 --> URI Class Initialized
INFO - 2021-07-12 08:44:02 --> Router Class Initialized
INFO - 2021-07-12 08:44:02 --> Output Class Initialized
INFO - 2021-07-12 08:44:02 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:02 --> Input Class Initialized
INFO - 2021-07-12 08:44:02 --> Language Class Initialized
INFO - 2021-07-12 08:44:02 --> Language Class Initialized
INFO - 2021-07-12 08:44:02 --> Config Class Initialized
INFO - 2021-07-12 08:44:02 --> Loader Class Initialized
INFO - 2021-07-12 08:44:02 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:02 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:02 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:02 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:02 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:02 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:03 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:03 --> Total execution time: 0.1285
INFO - 2021-07-12 08:44:04 --> Config Class Initialized
INFO - 2021-07-12 08:44:04 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:04 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:04 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:04 --> URI Class Initialized
INFO - 2021-07-12 08:44:04 --> Router Class Initialized
INFO - 2021-07-12 08:44:04 --> Output Class Initialized
INFO - 2021-07-12 08:44:04 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:04 --> Input Class Initialized
INFO - 2021-07-12 08:44:04 --> Language Class Initialized
INFO - 2021-07-12 08:44:04 --> Language Class Initialized
INFO - 2021-07-12 08:44:04 --> Config Class Initialized
INFO - 2021-07-12 08:44:04 --> Loader Class Initialized
INFO - 2021-07-12 08:44:04 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:04 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:04 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:04 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:04 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:04 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:04 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:04 --> Total execution time: 0.1217
INFO - 2021-07-12 08:44:06 --> Config Class Initialized
INFO - 2021-07-12 08:44:06 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:06 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:06 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:06 --> URI Class Initialized
INFO - 2021-07-12 08:44:06 --> Router Class Initialized
INFO - 2021-07-12 08:44:06 --> Output Class Initialized
INFO - 2021-07-12 08:44:06 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:06 --> Input Class Initialized
INFO - 2021-07-12 08:44:06 --> Language Class Initialized
INFO - 2021-07-12 08:44:06 --> Language Class Initialized
INFO - 2021-07-12 08:44:06 --> Config Class Initialized
INFO - 2021-07-12 08:44:06 --> Loader Class Initialized
INFO - 2021-07-12 08:44:06 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:06 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:06 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:06 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:06 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:06 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:06 --> Total execution time: 0.1200
INFO - 2021-07-12 08:44:08 --> Config Class Initialized
INFO - 2021-07-12 08:44:08 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:08 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:08 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:08 --> URI Class Initialized
INFO - 2021-07-12 08:44:08 --> Router Class Initialized
INFO - 2021-07-12 08:44:08 --> Output Class Initialized
INFO - 2021-07-12 08:44:08 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:08 --> Input Class Initialized
INFO - 2021-07-12 08:44:08 --> Language Class Initialized
INFO - 2021-07-12 08:44:08 --> Language Class Initialized
INFO - 2021-07-12 08:44:08 --> Config Class Initialized
INFO - 2021-07-12 08:44:08 --> Loader Class Initialized
INFO - 2021-07-12 08:44:08 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:08 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:08 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:08 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:08 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:08 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:08 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:08 --> Total execution time: 0.1252
INFO - 2021-07-12 08:44:09 --> Config Class Initialized
INFO - 2021-07-12 08:44:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:09 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:09 --> URI Class Initialized
INFO - 2021-07-12 08:44:09 --> Router Class Initialized
INFO - 2021-07-12 08:44:09 --> Output Class Initialized
INFO - 2021-07-12 08:44:09 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:09 --> Input Class Initialized
INFO - 2021-07-12 08:44:09 --> Language Class Initialized
INFO - 2021-07-12 08:44:09 --> Language Class Initialized
INFO - 2021-07-12 08:44:09 --> Config Class Initialized
INFO - 2021-07-12 08:44:09 --> Loader Class Initialized
INFO - 2021-07-12 08:44:09 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:09 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:09 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:09 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:09 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:09 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:10 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:10 --> Total execution time: 0.1213
INFO - 2021-07-12 08:44:11 --> Config Class Initialized
INFO - 2021-07-12 08:44:11 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:11 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:11 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:11 --> URI Class Initialized
INFO - 2021-07-12 08:44:11 --> Router Class Initialized
INFO - 2021-07-12 08:44:11 --> Output Class Initialized
INFO - 2021-07-12 08:44:11 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:11 --> Input Class Initialized
INFO - 2021-07-12 08:44:11 --> Language Class Initialized
INFO - 2021-07-12 08:44:11 --> Language Class Initialized
INFO - 2021-07-12 08:44:11 --> Config Class Initialized
INFO - 2021-07-12 08:44:11 --> Loader Class Initialized
INFO - 2021-07-12 08:44:11 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:11 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:11 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:11 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:11 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:11 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:11 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:11 --> Total execution time: 0.1129
INFO - 2021-07-12 08:44:14 --> Config Class Initialized
INFO - 2021-07-12 08:44:14 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:14 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:14 --> URI Class Initialized
INFO - 2021-07-12 08:44:14 --> Router Class Initialized
INFO - 2021-07-12 08:44:14 --> Output Class Initialized
INFO - 2021-07-12 08:44:14 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:14 --> Input Class Initialized
INFO - 2021-07-12 08:44:14 --> Language Class Initialized
INFO - 2021-07-12 08:44:14 --> Language Class Initialized
INFO - 2021-07-12 08:44:14 --> Config Class Initialized
INFO - 2021-07-12 08:44:14 --> Loader Class Initialized
INFO - 2021-07-12 08:44:14 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:14 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:14 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:14 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:14 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:14 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:14 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:14 --> Total execution time: 0.1155
INFO - 2021-07-12 08:44:15 --> Config Class Initialized
INFO - 2021-07-12 08:44:15 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:15 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:15 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:15 --> URI Class Initialized
INFO - 2021-07-12 08:44:15 --> Router Class Initialized
INFO - 2021-07-12 08:44:15 --> Output Class Initialized
INFO - 2021-07-12 08:44:15 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:15 --> Input Class Initialized
INFO - 2021-07-12 08:44:15 --> Language Class Initialized
INFO - 2021-07-12 08:44:15 --> Language Class Initialized
INFO - 2021-07-12 08:44:15 --> Config Class Initialized
INFO - 2021-07-12 08:44:15 --> Loader Class Initialized
INFO - 2021-07-12 08:44:15 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:15 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:15 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:15 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:15 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:15 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:15 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:15 --> Total execution time: 0.1320
INFO - 2021-07-12 08:44:17 --> Config Class Initialized
INFO - 2021-07-12 08:44:17 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:17 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:17 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:17 --> URI Class Initialized
INFO - 2021-07-12 08:44:17 --> Router Class Initialized
INFO - 2021-07-12 08:44:17 --> Output Class Initialized
INFO - 2021-07-12 08:44:17 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:17 --> Input Class Initialized
INFO - 2021-07-12 08:44:17 --> Language Class Initialized
INFO - 2021-07-12 08:44:17 --> Language Class Initialized
INFO - 2021-07-12 08:44:17 --> Config Class Initialized
INFO - 2021-07-12 08:44:17 --> Loader Class Initialized
INFO - 2021-07-12 08:44:17 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:17 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:17 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:17 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:17 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:17 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:17 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:17 --> Total execution time: 0.1165
INFO - 2021-07-12 08:44:19 --> Config Class Initialized
INFO - 2021-07-12 08:44:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:19 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:19 --> URI Class Initialized
INFO - 2021-07-12 08:44:19 --> Router Class Initialized
INFO - 2021-07-12 08:44:19 --> Output Class Initialized
INFO - 2021-07-12 08:44:19 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:19 --> Input Class Initialized
INFO - 2021-07-12 08:44:19 --> Language Class Initialized
INFO - 2021-07-12 08:44:19 --> Language Class Initialized
INFO - 2021-07-12 08:44:19 --> Config Class Initialized
INFO - 2021-07-12 08:44:19 --> Loader Class Initialized
INFO - 2021-07-12 08:44:19 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:19 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:19 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:19 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:19 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:19 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:19 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:19 --> Total execution time: 0.1437
INFO - 2021-07-12 08:44:20 --> Config Class Initialized
INFO - 2021-07-12 08:44:20 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:20 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:20 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:20 --> URI Class Initialized
INFO - 2021-07-12 08:44:20 --> Router Class Initialized
INFO - 2021-07-12 08:44:20 --> Output Class Initialized
INFO - 2021-07-12 08:44:20 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:20 --> Input Class Initialized
INFO - 2021-07-12 08:44:20 --> Language Class Initialized
INFO - 2021-07-12 08:44:20 --> Language Class Initialized
INFO - 2021-07-12 08:44:20 --> Config Class Initialized
INFO - 2021-07-12 08:44:20 --> Loader Class Initialized
INFO - 2021-07-12 08:44:20 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:20 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:20 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:20 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:20 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:20 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:21 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:21 --> Total execution time: 0.1326
INFO - 2021-07-12 08:44:23 --> Config Class Initialized
INFO - 2021-07-12 08:44:23 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:23 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:23 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:23 --> URI Class Initialized
INFO - 2021-07-12 08:44:23 --> Router Class Initialized
INFO - 2021-07-12 08:44:23 --> Output Class Initialized
INFO - 2021-07-12 08:44:23 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:23 --> Input Class Initialized
INFO - 2021-07-12 08:44:23 --> Language Class Initialized
INFO - 2021-07-12 08:44:23 --> Language Class Initialized
INFO - 2021-07-12 08:44:23 --> Config Class Initialized
INFO - 2021-07-12 08:44:23 --> Loader Class Initialized
INFO - 2021-07-12 08:44:23 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:23 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:23 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:23 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:23 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:23 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:23 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:23 --> Total execution time: 0.1344
INFO - 2021-07-12 08:44:25 --> Config Class Initialized
INFO - 2021-07-12 08:44:25 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:25 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:25 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:25 --> URI Class Initialized
INFO - 2021-07-12 08:44:25 --> Router Class Initialized
INFO - 2021-07-12 08:44:25 --> Output Class Initialized
INFO - 2021-07-12 08:44:25 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:25 --> Input Class Initialized
INFO - 2021-07-12 08:44:25 --> Language Class Initialized
INFO - 2021-07-12 08:44:25 --> Language Class Initialized
INFO - 2021-07-12 08:44:25 --> Config Class Initialized
INFO - 2021-07-12 08:44:25 --> Loader Class Initialized
INFO - 2021-07-12 08:44:25 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:25 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:25 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:25 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:25 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:25 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:25 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:25 --> Total execution time: 0.1171
INFO - 2021-07-12 08:44:27 --> Config Class Initialized
INFO - 2021-07-12 08:44:27 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:27 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:27 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:27 --> URI Class Initialized
INFO - 2021-07-12 08:44:27 --> Router Class Initialized
INFO - 2021-07-12 08:44:27 --> Output Class Initialized
INFO - 2021-07-12 08:44:27 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:27 --> Input Class Initialized
INFO - 2021-07-12 08:44:27 --> Language Class Initialized
INFO - 2021-07-12 08:44:27 --> Language Class Initialized
INFO - 2021-07-12 08:44:27 --> Config Class Initialized
INFO - 2021-07-12 08:44:27 --> Loader Class Initialized
INFO - 2021-07-12 08:44:27 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:27 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:27 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:27 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:27 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:27 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:27 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:27 --> Total execution time: 0.1451
INFO - 2021-07-12 08:44:29 --> Config Class Initialized
INFO - 2021-07-12 08:44:29 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:29 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:29 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:29 --> URI Class Initialized
INFO - 2021-07-12 08:44:29 --> Router Class Initialized
INFO - 2021-07-12 08:44:29 --> Output Class Initialized
INFO - 2021-07-12 08:44:29 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:29 --> Input Class Initialized
INFO - 2021-07-12 08:44:29 --> Language Class Initialized
INFO - 2021-07-12 08:44:29 --> Language Class Initialized
INFO - 2021-07-12 08:44:29 --> Config Class Initialized
INFO - 2021-07-12 08:44:29 --> Loader Class Initialized
INFO - 2021-07-12 08:44:29 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:29 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:29 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:29 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:29 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:29 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:29 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:29 --> Total execution time: 0.1434
INFO - 2021-07-12 08:44:31 --> Config Class Initialized
INFO - 2021-07-12 08:44:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:44:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:44:31 --> Utf8 Class Initialized
INFO - 2021-07-12 08:44:31 --> URI Class Initialized
INFO - 2021-07-12 08:44:31 --> Router Class Initialized
INFO - 2021-07-12 08:44:31 --> Output Class Initialized
INFO - 2021-07-12 08:44:31 --> Security Class Initialized
DEBUG - 2021-07-12 08:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:44:31 --> Input Class Initialized
INFO - 2021-07-12 08:44:31 --> Language Class Initialized
INFO - 2021-07-12 08:44:31 --> Language Class Initialized
INFO - 2021-07-12 08:44:31 --> Config Class Initialized
INFO - 2021-07-12 08:44:31 --> Loader Class Initialized
INFO - 2021-07-12 08:44:31 --> Helper loaded: url_helper
INFO - 2021-07-12 08:44:31 --> Helper loaded: file_helper
INFO - 2021-07-12 08:44:31 --> Helper loaded: form_helper
INFO - 2021-07-12 08:44:31 --> Helper loaded: my_helper
INFO - 2021-07-12 08:44:31 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:44:31 --> Controller Class Initialized
DEBUG - 2021-07-12 08:44:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-12 08:44:31 --> Final output sent to browser
DEBUG - 2021-07-12 08:44:31 --> Total execution time: 0.1192
INFO - 2021-07-12 08:47:08 --> Config Class Initialized
INFO - 2021-07-12 08:47:08 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:47:08 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:47:08 --> Utf8 Class Initialized
INFO - 2021-07-12 08:47:08 --> URI Class Initialized
INFO - 2021-07-12 08:47:08 --> Router Class Initialized
INFO - 2021-07-12 08:47:08 --> Output Class Initialized
INFO - 2021-07-12 08:47:08 --> Security Class Initialized
DEBUG - 2021-07-12 08:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:47:08 --> Input Class Initialized
INFO - 2021-07-12 08:47:08 --> Language Class Initialized
INFO - 2021-07-12 08:47:08 --> Language Class Initialized
INFO - 2021-07-12 08:47:08 --> Config Class Initialized
INFO - 2021-07-12 08:47:08 --> Loader Class Initialized
INFO - 2021-07-12 08:47:08 --> Helper loaded: url_helper
INFO - 2021-07-12 08:47:08 --> Helper loaded: file_helper
INFO - 2021-07-12 08:47:08 --> Helper loaded: form_helper
INFO - 2021-07-12 08:47:08 --> Helper loaded: my_helper
INFO - 2021-07-12 08:47:08 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:47:08 --> Controller Class Initialized
INFO - 2021-07-12 08:47:08 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:47:08 --> Config Class Initialized
INFO - 2021-07-12 08:47:08 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:47:08 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:47:08 --> Utf8 Class Initialized
INFO - 2021-07-12 08:47:08 --> URI Class Initialized
INFO - 2021-07-12 08:47:08 --> Router Class Initialized
INFO - 2021-07-12 08:47:08 --> Output Class Initialized
INFO - 2021-07-12 08:47:08 --> Security Class Initialized
DEBUG - 2021-07-12 08:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:47:08 --> Input Class Initialized
INFO - 2021-07-12 08:47:08 --> Language Class Initialized
INFO - 2021-07-12 08:47:08 --> Language Class Initialized
INFO - 2021-07-12 08:47:08 --> Config Class Initialized
INFO - 2021-07-12 08:47:08 --> Loader Class Initialized
INFO - 2021-07-12 08:47:08 --> Helper loaded: url_helper
INFO - 2021-07-12 08:47:08 --> Helper loaded: file_helper
INFO - 2021-07-12 08:47:08 --> Helper loaded: form_helper
INFO - 2021-07-12 08:47:08 --> Helper loaded: my_helper
INFO - 2021-07-12 08:47:08 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:47:08 --> Controller Class Initialized
DEBUG - 2021-07-12 08:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 08:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:47:08 --> Final output sent to browser
DEBUG - 2021-07-12 08:47:08 --> Total execution time: 0.0541
INFO - 2021-07-12 08:47:12 --> Config Class Initialized
INFO - 2021-07-12 08:47:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:47:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:47:12 --> Utf8 Class Initialized
INFO - 2021-07-12 08:47:12 --> URI Class Initialized
INFO - 2021-07-12 08:47:12 --> Router Class Initialized
INFO - 2021-07-12 08:47:12 --> Output Class Initialized
INFO - 2021-07-12 08:47:12 --> Security Class Initialized
DEBUG - 2021-07-12 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:47:12 --> Input Class Initialized
INFO - 2021-07-12 08:47:12 --> Language Class Initialized
INFO - 2021-07-12 08:47:12 --> Language Class Initialized
INFO - 2021-07-12 08:47:12 --> Config Class Initialized
INFO - 2021-07-12 08:47:12 --> Loader Class Initialized
INFO - 2021-07-12 08:47:12 --> Helper loaded: url_helper
INFO - 2021-07-12 08:47:12 --> Helper loaded: file_helper
INFO - 2021-07-12 08:47:12 --> Helper loaded: form_helper
INFO - 2021-07-12 08:47:12 --> Helper loaded: my_helper
INFO - 2021-07-12 08:47:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:47:12 --> Controller Class Initialized
INFO - 2021-07-12 08:47:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:47:12 --> Final output sent to browser
DEBUG - 2021-07-12 08:47:12 --> Total execution time: 0.0628
INFO - 2021-07-12 08:47:13 --> Config Class Initialized
INFO - 2021-07-12 08:47:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:47:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:47:13 --> Utf8 Class Initialized
INFO - 2021-07-12 08:47:13 --> URI Class Initialized
INFO - 2021-07-12 08:47:13 --> Router Class Initialized
INFO - 2021-07-12 08:47:13 --> Output Class Initialized
INFO - 2021-07-12 08:47:13 --> Security Class Initialized
DEBUG - 2021-07-12 08:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:47:13 --> Input Class Initialized
INFO - 2021-07-12 08:47:13 --> Language Class Initialized
INFO - 2021-07-12 08:47:13 --> Language Class Initialized
INFO - 2021-07-12 08:47:13 --> Config Class Initialized
INFO - 2021-07-12 08:47:13 --> Loader Class Initialized
INFO - 2021-07-12 08:47:13 --> Helper loaded: url_helper
INFO - 2021-07-12 08:47:13 --> Helper loaded: file_helper
INFO - 2021-07-12 08:47:13 --> Helper loaded: form_helper
INFO - 2021-07-12 08:47:13 --> Helper loaded: my_helper
INFO - 2021-07-12 08:47:13 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:47:13 --> Controller Class Initialized
DEBUG - 2021-07-12 08:47:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 08:47:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:47:13 --> Final output sent to browser
DEBUG - 2021-07-12 08:47:13 --> Total execution time: 0.7382
INFO - 2021-07-12 08:47:17 --> Config Class Initialized
INFO - 2021-07-12 08:47:17 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:47:17 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:47:17 --> Utf8 Class Initialized
INFO - 2021-07-12 08:47:17 --> URI Class Initialized
INFO - 2021-07-12 08:47:17 --> Router Class Initialized
INFO - 2021-07-12 08:47:17 --> Output Class Initialized
INFO - 2021-07-12 08:47:17 --> Security Class Initialized
DEBUG - 2021-07-12 08:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:47:17 --> Input Class Initialized
INFO - 2021-07-12 08:47:17 --> Language Class Initialized
INFO - 2021-07-12 08:47:17 --> Language Class Initialized
INFO - 2021-07-12 08:47:17 --> Config Class Initialized
INFO - 2021-07-12 08:47:17 --> Loader Class Initialized
INFO - 2021-07-12 08:47:17 --> Helper loaded: url_helper
INFO - 2021-07-12 08:47:17 --> Helper loaded: file_helper
INFO - 2021-07-12 08:47:17 --> Helper loaded: form_helper
INFO - 2021-07-12 08:47:17 --> Helper loaded: my_helper
INFO - 2021-07-12 08:47:17 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:47:17 --> Controller Class Initialized
DEBUG - 2021-07-12 08:47:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-12 08:47:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:47:17 --> Final output sent to browser
DEBUG - 2021-07-12 08:47:17 --> Total execution time: 0.0736
INFO - 2021-07-12 08:47:20 --> Config Class Initialized
INFO - 2021-07-12 08:47:20 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:47:20 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:47:20 --> Utf8 Class Initialized
INFO - 2021-07-12 08:47:20 --> URI Class Initialized
INFO - 2021-07-12 08:47:20 --> Router Class Initialized
INFO - 2021-07-12 08:47:20 --> Output Class Initialized
INFO - 2021-07-12 08:47:20 --> Security Class Initialized
DEBUG - 2021-07-12 08:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:47:20 --> Input Class Initialized
INFO - 2021-07-12 08:47:20 --> Language Class Initialized
INFO - 2021-07-12 08:47:20 --> Language Class Initialized
INFO - 2021-07-12 08:47:20 --> Config Class Initialized
INFO - 2021-07-12 08:47:20 --> Loader Class Initialized
INFO - 2021-07-12 08:47:20 --> Helper loaded: url_helper
INFO - 2021-07-12 08:47:20 --> Helper loaded: file_helper
INFO - 2021-07-12 08:47:20 --> Helper loaded: form_helper
INFO - 2021-07-12 08:47:20 --> Helper loaded: my_helper
INFO - 2021-07-12 08:47:20 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:47:20 --> Controller Class Initialized
DEBUG - 2021-07-12 08:47:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:47:20 --> Final output sent to browser
DEBUG - 2021-07-12 08:47:20 --> Total execution time: 0.2407
INFO - 2021-07-12 08:48:52 --> Config Class Initialized
INFO - 2021-07-12 08:48:52 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:48:52 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:48:52 --> Utf8 Class Initialized
INFO - 2021-07-12 08:48:52 --> URI Class Initialized
INFO - 2021-07-12 08:48:52 --> Router Class Initialized
INFO - 2021-07-12 08:48:52 --> Output Class Initialized
INFO - 2021-07-12 08:48:52 --> Security Class Initialized
DEBUG - 2021-07-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:48:52 --> Input Class Initialized
INFO - 2021-07-12 08:48:52 --> Language Class Initialized
INFO - 2021-07-12 08:48:52 --> Language Class Initialized
INFO - 2021-07-12 08:48:52 --> Config Class Initialized
INFO - 2021-07-12 08:48:52 --> Loader Class Initialized
INFO - 2021-07-12 08:48:52 --> Helper loaded: url_helper
INFO - 2021-07-12 08:48:52 --> Helper loaded: file_helper
INFO - 2021-07-12 08:48:52 --> Helper loaded: form_helper
INFO - 2021-07-12 08:48:52 --> Helper loaded: my_helper
INFO - 2021-07-12 08:48:52 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:48:52 --> Controller Class Initialized
DEBUG - 2021-07-12 08:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 08:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:48:52 --> Final output sent to browser
DEBUG - 2021-07-12 08:48:52 --> Total execution time: 0.0575
INFO - 2021-07-12 08:48:56 --> Config Class Initialized
INFO - 2021-07-12 08:48:56 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:48:56 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:48:56 --> Utf8 Class Initialized
INFO - 2021-07-12 08:48:56 --> URI Class Initialized
INFO - 2021-07-12 08:48:56 --> Router Class Initialized
INFO - 2021-07-12 08:48:56 --> Output Class Initialized
INFO - 2021-07-12 08:48:56 --> Security Class Initialized
DEBUG - 2021-07-12 08:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:48:56 --> Input Class Initialized
INFO - 2021-07-12 08:48:56 --> Language Class Initialized
INFO - 2021-07-12 08:48:56 --> Language Class Initialized
INFO - 2021-07-12 08:48:56 --> Config Class Initialized
INFO - 2021-07-12 08:48:56 --> Loader Class Initialized
INFO - 2021-07-12 08:48:56 --> Helper loaded: url_helper
INFO - 2021-07-12 08:48:56 --> Helper loaded: file_helper
INFO - 2021-07-12 08:48:56 --> Helper loaded: form_helper
INFO - 2021-07-12 08:48:56 --> Helper loaded: my_helper
INFO - 2021-07-12 08:48:56 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:48:56 --> Controller Class Initialized
DEBUG - 2021-07-12 08:48:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:48:56 --> Final output sent to browser
DEBUG - 2021-07-12 08:48:56 --> Total execution time: 0.2072
INFO - 2021-07-12 08:48:57 --> Config Class Initialized
INFO - 2021-07-12 08:48:57 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:48:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:48:57 --> Utf8 Class Initialized
INFO - 2021-07-12 08:48:57 --> URI Class Initialized
INFO - 2021-07-12 08:48:57 --> Router Class Initialized
INFO - 2021-07-12 08:48:57 --> Output Class Initialized
INFO - 2021-07-12 08:48:57 --> Security Class Initialized
DEBUG - 2021-07-12 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:48:57 --> Input Class Initialized
INFO - 2021-07-12 08:48:57 --> Language Class Initialized
INFO - 2021-07-12 08:48:57 --> Language Class Initialized
INFO - 2021-07-12 08:48:58 --> Config Class Initialized
INFO - 2021-07-12 08:48:58 --> Loader Class Initialized
INFO - 2021-07-12 08:48:58 --> Helper loaded: url_helper
INFO - 2021-07-12 08:48:58 --> Helper loaded: file_helper
INFO - 2021-07-12 08:48:58 --> Helper loaded: form_helper
INFO - 2021-07-12 08:48:58 --> Helper loaded: my_helper
INFO - 2021-07-12 08:48:58 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:48:58 --> Controller Class Initialized
DEBUG - 2021-07-12 08:48:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:48:58 --> Final output sent to browser
DEBUG - 2021-07-12 08:48:58 --> Total execution time: 0.1258
INFO - 2021-07-12 08:49:00 --> Config Class Initialized
INFO - 2021-07-12 08:49:00 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:00 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:00 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:00 --> URI Class Initialized
INFO - 2021-07-12 08:49:00 --> Router Class Initialized
INFO - 2021-07-12 08:49:00 --> Output Class Initialized
INFO - 2021-07-12 08:49:00 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:00 --> Input Class Initialized
INFO - 2021-07-12 08:49:00 --> Language Class Initialized
INFO - 2021-07-12 08:49:00 --> Language Class Initialized
INFO - 2021-07-12 08:49:00 --> Config Class Initialized
INFO - 2021-07-12 08:49:00 --> Loader Class Initialized
INFO - 2021-07-12 08:49:00 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:00 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:00 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:00 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:00 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:00 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:00 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:00 --> Total execution time: 0.1218
INFO - 2021-07-12 08:49:01 --> Config Class Initialized
INFO - 2021-07-12 08:49:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:01 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:01 --> URI Class Initialized
INFO - 2021-07-12 08:49:01 --> Router Class Initialized
INFO - 2021-07-12 08:49:01 --> Output Class Initialized
INFO - 2021-07-12 08:49:01 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:01 --> Input Class Initialized
INFO - 2021-07-12 08:49:01 --> Language Class Initialized
INFO - 2021-07-12 08:49:01 --> Language Class Initialized
INFO - 2021-07-12 08:49:01 --> Config Class Initialized
INFO - 2021-07-12 08:49:01 --> Loader Class Initialized
INFO - 2021-07-12 08:49:01 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:01 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:01 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:01 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:01 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:01 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:01 --> Total execution time: 0.1317
INFO - 2021-07-12 08:49:03 --> Config Class Initialized
INFO - 2021-07-12 08:49:03 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:03 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:03 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:03 --> URI Class Initialized
INFO - 2021-07-12 08:49:03 --> Router Class Initialized
INFO - 2021-07-12 08:49:03 --> Output Class Initialized
INFO - 2021-07-12 08:49:03 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:03 --> Input Class Initialized
INFO - 2021-07-12 08:49:03 --> Language Class Initialized
INFO - 2021-07-12 08:49:03 --> Language Class Initialized
INFO - 2021-07-12 08:49:03 --> Config Class Initialized
INFO - 2021-07-12 08:49:03 --> Loader Class Initialized
INFO - 2021-07-12 08:49:03 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:03 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:03 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:03 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:03 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:03 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:03 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:03 --> Total execution time: 0.1199
INFO - 2021-07-12 08:49:05 --> Config Class Initialized
INFO - 2021-07-12 08:49:05 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:05 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:05 --> URI Class Initialized
INFO - 2021-07-12 08:49:05 --> Router Class Initialized
INFO - 2021-07-12 08:49:05 --> Output Class Initialized
INFO - 2021-07-12 08:49:05 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:05 --> Input Class Initialized
INFO - 2021-07-12 08:49:05 --> Language Class Initialized
INFO - 2021-07-12 08:49:05 --> Language Class Initialized
INFO - 2021-07-12 08:49:05 --> Config Class Initialized
INFO - 2021-07-12 08:49:05 --> Loader Class Initialized
INFO - 2021-07-12 08:49:05 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:05 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:05 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:05 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:05 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:05 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:05 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:05 --> Total execution time: 0.1494
INFO - 2021-07-12 08:49:08 --> Config Class Initialized
INFO - 2021-07-12 08:49:08 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:08 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:08 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:08 --> URI Class Initialized
INFO - 2021-07-12 08:49:08 --> Router Class Initialized
INFO - 2021-07-12 08:49:08 --> Output Class Initialized
INFO - 2021-07-12 08:49:08 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:08 --> Input Class Initialized
INFO - 2021-07-12 08:49:08 --> Language Class Initialized
INFO - 2021-07-12 08:49:08 --> Language Class Initialized
INFO - 2021-07-12 08:49:08 --> Config Class Initialized
INFO - 2021-07-12 08:49:08 --> Loader Class Initialized
INFO - 2021-07-12 08:49:08 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:08 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:08 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:08 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:08 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:08 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:08 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:08 --> Total execution time: 0.1170
INFO - 2021-07-12 08:49:10 --> Config Class Initialized
INFO - 2021-07-12 08:49:10 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:10 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:10 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:10 --> URI Class Initialized
INFO - 2021-07-12 08:49:10 --> Router Class Initialized
INFO - 2021-07-12 08:49:10 --> Output Class Initialized
INFO - 2021-07-12 08:49:10 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:10 --> Input Class Initialized
INFO - 2021-07-12 08:49:10 --> Language Class Initialized
INFO - 2021-07-12 08:49:10 --> Language Class Initialized
INFO - 2021-07-12 08:49:10 --> Config Class Initialized
INFO - 2021-07-12 08:49:10 --> Loader Class Initialized
INFO - 2021-07-12 08:49:10 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:10 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:10 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:10 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:10 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:10 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:10 --> Total execution time: 0.1113
INFO - 2021-07-12 08:49:12 --> Config Class Initialized
INFO - 2021-07-12 08:49:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:12 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:12 --> URI Class Initialized
INFO - 2021-07-12 08:49:12 --> Router Class Initialized
INFO - 2021-07-12 08:49:12 --> Output Class Initialized
INFO - 2021-07-12 08:49:12 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:12 --> Input Class Initialized
INFO - 2021-07-12 08:49:12 --> Language Class Initialized
INFO - 2021-07-12 08:49:12 --> Language Class Initialized
INFO - 2021-07-12 08:49:12 --> Config Class Initialized
INFO - 2021-07-12 08:49:12 --> Loader Class Initialized
INFO - 2021-07-12 08:49:12 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:12 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:12 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:12 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:12 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:12 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:12 --> Total execution time: 0.1272
INFO - 2021-07-12 08:49:13 --> Config Class Initialized
INFO - 2021-07-12 08:49:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:13 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:13 --> URI Class Initialized
INFO - 2021-07-12 08:49:13 --> Router Class Initialized
INFO - 2021-07-12 08:49:13 --> Output Class Initialized
INFO - 2021-07-12 08:49:13 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:13 --> Input Class Initialized
INFO - 2021-07-12 08:49:13 --> Language Class Initialized
INFO - 2021-07-12 08:49:13 --> Language Class Initialized
INFO - 2021-07-12 08:49:13 --> Config Class Initialized
INFO - 2021-07-12 08:49:13 --> Loader Class Initialized
INFO - 2021-07-12 08:49:13 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:13 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:13 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:13 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:13 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:13 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:13 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:13 --> Total execution time: 0.1147
INFO - 2021-07-12 08:49:16 --> Config Class Initialized
INFO - 2021-07-12 08:49:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:16 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:16 --> URI Class Initialized
INFO - 2021-07-12 08:49:16 --> Router Class Initialized
INFO - 2021-07-12 08:49:16 --> Output Class Initialized
INFO - 2021-07-12 08:49:16 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:16 --> Input Class Initialized
INFO - 2021-07-12 08:49:16 --> Language Class Initialized
INFO - 2021-07-12 08:49:16 --> Language Class Initialized
INFO - 2021-07-12 08:49:16 --> Config Class Initialized
INFO - 2021-07-12 08:49:16 --> Loader Class Initialized
INFO - 2021-07-12 08:49:16 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:16 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:16 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:16 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:16 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:16 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:16 --> Total execution time: 0.1122
INFO - 2021-07-12 08:49:17 --> Config Class Initialized
INFO - 2021-07-12 08:49:17 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:17 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:17 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:17 --> URI Class Initialized
INFO - 2021-07-12 08:49:17 --> Router Class Initialized
INFO - 2021-07-12 08:49:17 --> Output Class Initialized
INFO - 2021-07-12 08:49:17 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:17 --> Input Class Initialized
INFO - 2021-07-12 08:49:17 --> Language Class Initialized
INFO - 2021-07-12 08:49:17 --> Language Class Initialized
INFO - 2021-07-12 08:49:17 --> Config Class Initialized
INFO - 2021-07-12 08:49:17 --> Loader Class Initialized
INFO - 2021-07-12 08:49:17 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:17 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:17 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:17 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:17 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:17 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:17 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:17 --> Total execution time: 0.1316
INFO - 2021-07-12 08:49:19 --> Config Class Initialized
INFO - 2021-07-12 08:49:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:19 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:19 --> URI Class Initialized
INFO - 2021-07-12 08:49:19 --> Router Class Initialized
INFO - 2021-07-12 08:49:19 --> Output Class Initialized
INFO - 2021-07-12 08:49:19 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:19 --> Input Class Initialized
INFO - 2021-07-12 08:49:19 --> Language Class Initialized
INFO - 2021-07-12 08:49:19 --> Language Class Initialized
INFO - 2021-07-12 08:49:19 --> Config Class Initialized
INFO - 2021-07-12 08:49:19 --> Loader Class Initialized
INFO - 2021-07-12 08:49:19 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:19 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:19 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:19 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:19 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:19 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:19 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:19 --> Total execution time: 0.1277
INFO - 2021-07-12 08:49:21 --> Config Class Initialized
INFO - 2021-07-12 08:49:21 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:21 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:21 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:21 --> URI Class Initialized
INFO - 2021-07-12 08:49:21 --> Router Class Initialized
INFO - 2021-07-12 08:49:21 --> Output Class Initialized
INFO - 2021-07-12 08:49:21 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:21 --> Input Class Initialized
INFO - 2021-07-12 08:49:21 --> Language Class Initialized
INFO - 2021-07-12 08:49:21 --> Language Class Initialized
INFO - 2021-07-12 08:49:21 --> Config Class Initialized
INFO - 2021-07-12 08:49:21 --> Loader Class Initialized
INFO - 2021-07-12 08:49:21 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:21 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:21 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:21 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:21 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:21 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:21 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:21 --> Total execution time: 0.1146
INFO - 2021-07-12 08:49:24 --> Config Class Initialized
INFO - 2021-07-12 08:49:24 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:24 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:24 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:24 --> URI Class Initialized
INFO - 2021-07-12 08:49:24 --> Router Class Initialized
INFO - 2021-07-12 08:49:24 --> Output Class Initialized
INFO - 2021-07-12 08:49:24 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:24 --> Input Class Initialized
INFO - 2021-07-12 08:49:24 --> Language Class Initialized
INFO - 2021-07-12 08:49:24 --> Language Class Initialized
INFO - 2021-07-12 08:49:24 --> Config Class Initialized
INFO - 2021-07-12 08:49:24 --> Loader Class Initialized
INFO - 2021-07-12 08:49:24 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:24 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:24 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:24 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:24 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:24 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:24 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:24 --> Total execution time: 0.1105
INFO - 2021-07-12 08:49:25 --> Config Class Initialized
INFO - 2021-07-12 08:49:25 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:25 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:25 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:25 --> URI Class Initialized
INFO - 2021-07-12 08:49:25 --> Router Class Initialized
INFO - 2021-07-12 08:49:25 --> Output Class Initialized
INFO - 2021-07-12 08:49:25 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:25 --> Input Class Initialized
INFO - 2021-07-12 08:49:25 --> Language Class Initialized
INFO - 2021-07-12 08:49:25 --> Language Class Initialized
INFO - 2021-07-12 08:49:25 --> Config Class Initialized
INFO - 2021-07-12 08:49:25 --> Loader Class Initialized
INFO - 2021-07-12 08:49:25 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:25 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:25 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:25 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:25 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:25 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:25 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:25 --> Total execution time: 0.1274
INFO - 2021-07-12 08:49:26 --> Config Class Initialized
INFO - 2021-07-12 08:49:26 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:26 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:26 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:26 --> URI Class Initialized
INFO - 2021-07-12 08:49:26 --> Router Class Initialized
INFO - 2021-07-12 08:49:26 --> Output Class Initialized
INFO - 2021-07-12 08:49:26 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:26 --> Input Class Initialized
INFO - 2021-07-12 08:49:26 --> Language Class Initialized
INFO - 2021-07-12 08:49:26 --> Language Class Initialized
INFO - 2021-07-12 08:49:26 --> Config Class Initialized
INFO - 2021-07-12 08:49:26 --> Loader Class Initialized
INFO - 2021-07-12 08:49:26 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:26 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:26 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:26 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:26 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:26 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:27 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:27 --> Total execution time: 0.1297
INFO - 2021-07-12 08:49:29 --> Config Class Initialized
INFO - 2021-07-12 08:49:29 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:29 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:29 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:29 --> URI Class Initialized
INFO - 2021-07-12 08:49:29 --> Router Class Initialized
INFO - 2021-07-12 08:49:29 --> Output Class Initialized
INFO - 2021-07-12 08:49:29 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:29 --> Input Class Initialized
INFO - 2021-07-12 08:49:29 --> Language Class Initialized
INFO - 2021-07-12 08:49:29 --> Language Class Initialized
INFO - 2021-07-12 08:49:29 --> Config Class Initialized
INFO - 2021-07-12 08:49:29 --> Loader Class Initialized
INFO - 2021-07-12 08:49:29 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:29 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:29 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:29 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:29 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:29 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:29 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:29 --> Total execution time: 0.1145
INFO - 2021-07-12 08:49:31 --> Config Class Initialized
INFO - 2021-07-12 08:49:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:31 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:31 --> URI Class Initialized
INFO - 2021-07-12 08:49:31 --> Router Class Initialized
INFO - 2021-07-12 08:49:31 --> Output Class Initialized
INFO - 2021-07-12 08:49:31 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:31 --> Input Class Initialized
INFO - 2021-07-12 08:49:31 --> Language Class Initialized
INFO - 2021-07-12 08:49:31 --> Language Class Initialized
INFO - 2021-07-12 08:49:31 --> Config Class Initialized
INFO - 2021-07-12 08:49:31 --> Loader Class Initialized
INFO - 2021-07-12 08:49:31 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:31 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:31 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:31 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:31 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:31 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:31 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:31 --> Total execution time: 0.1276
INFO - 2021-07-12 08:49:32 --> Config Class Initialized
INFO - 2021-07-12 08:49:32 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:32 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:32 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:32 --> URI Class Initialized
INFO - 2021-07-12 08:49:32 --> Router Class Initialized
INFO - 2021-07-12 08:49:32 --> Output Class Initialized
INFO - 2021-07-12 08:49:32 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:32 --> Input Class Initialized
INFO - 2021-07-12 08:49:32 --> Language Class Initialized
INFO - 2021-07-12 08:49:32 --> Language Class Initialized
INFO - 2021-07-12 08:49:32 --> Config Class Initialized
INFO - 2021-07-12 08:49:32 --> Loader Class Initialized
INFO - 2021-07-12 08:49:32 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:32 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:32 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:32 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:32 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:32 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:32 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:32 --> Total execution time: 0.1231
INFO - 2021-07-12 08:49:35 --> Config Class Initialized
INFO - 2021-07-12 08:49:35 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:35 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:35 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:35 --> URI Class Initialized
INFO - 2021-07-12 08:49:35 --> Router Class Initialized
INFO - 2021-07-12 08:49:35 --> Output Class Initialized
INFO - 2021-07-12 08:49:35 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:35 --> Input Class Initialized
INFO - 2021-07-12 08:49:35 --> Language Class Initialized
INFO - 2021-07-12 08:49:35 --> Language Class Initialized
INFO - 2021-07-12 08:49:35 --> Config Class Initialized
INFO - 2021-07-12 08:49:35 --> Loader Class Initialized
INFO - 2021-07-12 08:49:35 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:35 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:35 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:35 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:35 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:35 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:35 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:35 --> Total execution time: 0.1559
INFO - 2021-07-12 08:49:36 --> Config Class Initialized
INFO - 2021-07-12 08:49:36 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:36 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:36 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:36 --> URI Class Initialized
INFO - 2021-07-12 08:49:36 --> Router Class Initialized
INFO - 2021-07-12 08:49:36 --> Output Class Initialized
INFO - 2021-07-12 08:49:36 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:36 --> Input Class Initialized
INFO - 2021-07-12 08:49:36 --> Language Class Initialized
INFO - 2021-07-12 08:49:36 --> Language Class Initialized
INFO - 2021-07-12 08:49:36 --> Config Class Initialized
INFO - 2021-07-12 08:49:36 --> Loader Class Initialized
INFO - 2021-07-12 08:49:36 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:36 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:36 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:36 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:36 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:36 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:36 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:36 --> Total execution time: 0.1169
INFO - 2021-07-12 08:49:38 --> Config Class Initialized
INFO - 2021-07-12 08:49:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:38 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:38 --> URI Class Initialized
INFO - 2021-07-12 08:49:38 --> Router Class Initialized
INFO - 2021-07-12 08:49:38 --> Output Class Initialized
INFO - 2021-07-12 08:49:38 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:38 --> Input Class Initialized
INFO - 2021-07-12 08:49:38 --> Language Class Initialized
INFO - 2021-07-12 08:49:38 --> Language Class Initialized
INFO - 2021-07-12 08:49:38 --> Config Class Initialized
INFO - 2021-07-12 08:49:38 --> Loader Class Initialized
INFO - 2021-07-12 08:49:38 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:38 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:38 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:38 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:38 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:38 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:38 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:38 --> Total execution time: 0.1255
INFO - 2021-07-12 08:49:40 --> Config Class Initialized
INFO - 2021-07-12 08:49:40 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:40 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:40 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:40 --> URI Class Initialized
INFO - 2021-07-12 08:49:40 --> Router Class Initialized
INFO - 2021-07-12 08:49:40 --> Output Class Initialized
INFO - 2021-07-12 08:49:40 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:40 --> Input Class Initialized
INFO - 2021-07-12 08:49:40 --> Language Class Initialized
INFO - 2021-07-12 08:49:40 --> Language Class Initialized
INFO - 2021-07-12 08:49:40 --> Config Class Initialized
INFO - 2021-07-12 08:49:40 --> Loader Class Initialized
INFO - 2021-07-12 08:49:40 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:40 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:40 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:40 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:40 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:40 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:40 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:40 --> Total execution time: 0.1210
INFO - 2021-07-12 08:49:41 --> Config Class Initialized
INFO - 2021-07-12 08:49:41 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:41 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:41 --> URI Class Initialized
INFO - 2021-07-12 08:49:41 --> Router Class Initialized
INFO - 2021-07-12 08:49:41 --> Output Class Initialized
INFO - 2021-07-12 08:49:41 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:41 --> Input Class Initialized
INFO - 2021-07-12 08:49:41 --> Language Class Initialized
INFO - 2021-07-12 08:49:41 --> Language Class Initialized
INFO - 2021-07-12 08:49:41 --> Config Class Initialized
INFO - 2021-07-12 08:49:41 --> Loader Class Initialized
INFO - 2021-07-12 08:49:41 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:41 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:41 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:41 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:41 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:41 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:41 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:41 --> Total execution time: 0.1292
INFO - 2021-07-12 08:49:43 --> Config Class Initialized
INFO - 2021-07-12 08:49:43 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:43 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:43 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:43 --> URI Class Initialized
INFO - 2021-07-12 08:49:43 --> Router Class Initialized
INFO - 2021-07-12 08:49:43 --> Output Class Initialized
INFO - 2021-07-12 08:49:43 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:43 --> Input Class Initialized
INFO - 2021-07-12 08:49:43 --> Language Class Initialized
INFO - 2021-07-12 08:49:43 --> Language Class Initialized
INFO - 2021-07-12 08:49:43 --> Config Class Initialized
INFO - 2021-07-12 08:49:43 --> Loader Class Initialized
INFO - 2021-07-12 08:49:43 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:43 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:43 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:43 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:43 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:43 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:43 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:43 --> Total execution time: 0.1176
INFO - 2021-07-12 08:49:45 --> Config Class Initialized
INFO - 2021-07-12 08:49:45 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:45 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:45 --> URI Class Initialized
INFO - 2021-07-12 08:49:45 --> Router Class Initialized
INFO - 2021-07-12 08:49:45 --> Output Class Initialized
INFO - 2021-07-12 08:49:45 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:45 --> Input Class Initialized
INFO - 2021-07-12 08:49:45 --> Language Class Initialized
INFO - 2021-07-12 08:49:45 --> Language Class Initialized
INFO - 2021-07-12 08:49:45 --> Config Class Initialized
INFO - 2021-07-12 08:49:45 --> Loader Class Initialized
INFO - 2021-07-12 08:49:45 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:45 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:45 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:45 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:45 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:45 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:45 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:45 --> Total execution time: 0.1493
INFO - 2021-07-12 08:49:46 --> Config Class Initialized
INFO - 2021-07-12 08:49:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:46 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:46 --> URI Class Initialized
INFO - 2021-07-12 08:49:46 --> Router Class Initialized
INFO - 2021-07-12 08:49:46 --> Output Class Initialized
INFO - 2021-07-12 08:49:46 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:46 --> Input Class Initialized
INFO - 2021-07-12 08:49:46 --> Language Class Initialized
INFO - 2021-07-12 08:49:46 --> Language Class Initialized
INFO - 2021-07-12 08:49:46 --> Config Class Initialized
INFO - 2021-07-12 08:49:46 --> Loader Class Initialized
INFO - 2021-07-12 08:49:46 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:46 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:46 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:46 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:46 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:47 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:47 --> Total execution time: 0.1196
INFO - 2021-07-12 08:49:48 --> Config Class Initialized
INFO - 2021-07-12 08:49:48 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:48 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:48 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:48 --> URI Class Initialized
INFO - 2021-07-12 08:49:48 --> Router Class Initialized
INFO - 2021-07-12 08:49:48 --> Output Class Initialized
INFO - 2021-07-12 08:49:48 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:48 --> Input Class Initialized
INFO - 2021-07-12 08:49:48 --> Language Class Initialized
INFO - 2021-07-12 08:49:48 --> Language Class Initialized
INFO - 2021-07-12 08:49:48 --> Config Class Initialized
INFO - 2021-07-12 08:49:48 --> Loader Class Initialized
INFO - 2021-07-12 08:49:48 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:48 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:48 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:48 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:48 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:48 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:48 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:48 --> Total execution time: 0.1300
INFO - 2021-07-12 08:49:50 --> Config Class Initialized
INFO - 2021-07-12 08:49:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:50 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:50 --> URI Class Initialized
INFO - 2021-07-12 08:49:50 --> Router Class Initialized
INFO - 2021-07-12 08:49:50 --> Output Class Initialized
INFO - 2021-07-12 08:49:50 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:50 --> Input Class Initialized
INFO - 2021-07-12 08:49:50 --> Language Class Initialized
INFO - 2021-07-12 08:49:50 --> Language Class Initialized
INFO - 2021-07-12 08:49:50 --> Config Class Initialized
INFO - 2021-07-12 08:49:50 --> Loader Class Initialized
INFO - 2021-07-12 08:49:50 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:50 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:50 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:50 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:50 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:50 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:50 --> Total execution time: 0.1167
INFO - 2021-07-12 08:49:53 --> Config Class Initialized
INFO - 2021-07-12 08:49:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:53 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:53 --> URI Class Initialized
INFO - 2021-07-12 08:49:53 --> Router Class Initialized
INFO - 2021-07-12 08:49:53 --> Output Class Initialized
INFO - 2021-07-12 08:49:53 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:53 --> Input Class Initialized
INFO - 2021-07-12 08:49:53 --> Language Class Initialized
INFO - 2021-07-12 08:49:53 --> Language Class Initialized
INFO - 2021-07-12 08:49:53 --> Config Class Initialized
INFO - 2021-07-12 08:49:53 --> Loader Class Initialized
INFO - 2021-07-12 08:49:53 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:53 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:53 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:53 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:53 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:53 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:53 --> Total execution time: 0.1267
INFO - 2021-07-12 08:49:54 --> Config Class Initialized
INFO - 2021-07-12 08:49:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:54 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:54 --> URI Class Initialized
INFO - 2021-07-12 08:49:54 --> Router Class Initialized
INFO - 2021-07-12 08:49:54 --> Output Class Initialized
INFO - 2021-07-12 08:49:54 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:54 --> Input Class Initialized
INFO - 2021-07-12 08:49:54 --> Language Class Initialized
INFO - 2021-07-12 08:49:54 --> Language Class Initialized
INFO - 2021-07-12 08:49:54 --> Config Class Initialized
INFO - 2021-07-12 08:49:54 --> Loader Class Initialized
INFO - 2021-07-12 08:49:54 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:54 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:54 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:54 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:54 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:54 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:54 --> Total execution time: 0.1209
INFO - 2021-07-12 08:49:56 --> Config Class Initialized
INFO - 2021-07-12 08:49:56 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:56 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:56 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:56 --> URI Class Initialized
INFO - 2021-07-12 08:49:56 --> Router Class Initialized
INFO - 2021-07-12 08:49:56 --> Output Class Initialized
INFO - 2021-07-12 08:49:56 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:56 --> Input Class Initialized
INFO - 2021-07-12 08:49:56 --> Language Class Initialized
INFO - 2021-07-12 08:49:56 --> Language Class Initialized
INFO - 2021-07-12 08:49:56 --> Config Class Initialized
INFO - 2021-07-12 08:49:56 --> Loader Class Initialized
INFO - 2021-07-12 08:49:56 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:56 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:56 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:56 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:56 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:56 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:56 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:56 --> Total execution time: 0.1489
INFO - 2021-07-12 08:49:58 --> Config Class Initialized
INFO - 2021-07-12 08:49:58 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:49:58 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:49:58 --> Utf8 Class Initialized
INFO - 2021-07-12 08:49:58 --> URI Class Initialized
INFO - 2021-07-12 08:49:58 --> Router Class Initialized
INFO - 2021-07-12 08:49:58 --> Output Class Initialized
INFO - 2021-07-12 08:49:58 --> Security Class Initialized
DEBUG - 2021-07-12 08:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:49:58 --> Input Class Initialized
INFO - 2021-07-12 08:49:58 --> Language Class Initialized
INFO - 2021-07-12 08:49:58 --> Language Class Initialized
INFO - 2021-07-12 08:49:58 --> Config Class Initialized
INFO - 2021-07-12 08:49:58 --> Loader Class Initialized
INFO - 2021-07-12 08:49:58 --> Helper loaded: url_helper
INFO - 2021-07-12 08:49:58 --> Helper loaded: file_helper
INFO - 2021-07-12 08:49:58 --> Helper loaded: form_helper
INFO - 2021-07-12 08:49:58 --> Helper loaded: my_helper
INFO - 2021-07-12 08:49:58 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:49:58 --> Controller Class Initialized
DEBUG - 2021-07-12 08:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:49:58 --> Final output sent to browser
DEBUG - 2021-07-12 08:49:58 --> Total execution time: 0.1164
INFO - 2021-07-12 08:50:00 --> Config Class Initialized
INFO - 2021-07-12 08:50:00 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:50:00 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:50:00 --> Utf8 Class Initialized
INFO - 2021-07-12 08:50:00 --> URI Class Initialized
INFO - 2021-07-12 08:50:00 --> Router Class Initialized
INFO - 2021-07-12 08:50:00 --> Output Class Initialized
INFO - 2021-07-12 08:50:00 --> Security Class Initialized
DEBUG - 2021-07-12 08:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:50:00 --> Input Class Initialized
INFO - 2021-07-12 08:50:00 --> Language Class Initialized
INFO - 2021-07-12 08:50:00 --> Language Class Initialized
INFO - 2021-07-12 08:50:00 --> Config Class Initialized
INFO - 2021-07-12 08:50:00 --> Loader Class Initialized
INFO - 2021-07-12 08:50:00 --> Helper loaded: url_helper
INFO - 2021-07-12 08:50:00 --> Helper loaded: file_helper
INFO - 2021-07-12 08:50:00 --> Helper loaded: form_helper
INFO - 2021-07-12 08:50:00 --> Helper loaded: my_helper
INFO - 2021-07-12 08:50:00 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:50:00 --> Controller Class Initialized
DEBUG - 2021-07-12 08:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:50:00 --> Final output sent to browser
DEBUG - 2021-07-12 08:50:00 --> Total execution time: 0.1290
INFO - 2021-07-12 08:50:02 --> Config Class Initialized
INFO - 2021-07-12 08:50:02 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:50:02 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:50:02 --> Utf8 Class Initialized
INFO - 2021-07-12 08:50:02 --> URI Class Initialized
INFO - 2021-07-12 08:50:02 --> Router Class Initialized
INFO - 2021-07-12 08:50:02 --> Output Class Initialized
INFO - 2021-07-12 08:50:02 --> Security Class Initialized
DEBUG - 2021-07-12 08:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:50:02 --> Input Class Initialized
INFO - 2021-07-12 08:50:02 --> Language Class Initialized
INFO - 2021-07-12 08:50:02 --> Language Class Initialized
INFO - 2021-07-12 08:50:02 --> Config Class Initialized
INFO - 2021-07-12 08:50:02 --> Loader Class Initialized
INFO - 2021-07-12 08:50:02 --> Helper loaded: url_helper
INFO - 2021-07-12 08:50:02 --> Helper loaded: file_helper
INFO - 2021-07-12 08:50:02 --> Helper loaded: form_helper
INFO - 2021-07-12 08:50:02 --> Helper loaded: my_helper
INFO - 2021-07-12 08:50:02 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:50:02 --> Controller Class Initialized
DEBUG - 2021-07-12 08:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:50:02 --> Final output sent to browser
DEBUG - 2021-07-12 08:50:02 --> Total execution time: 0.1208
INFO - 2021-07-12 08:50:03 --> Config Class Initialized
INFO - 2021-07-12 08:50:03 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:50:03 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:50:03 --> Utf8 Class Initialized
INFO - 2021-07-12 08:50:03 --> URI Class Initialized
INFO - 2021-07-12 08:50:03 --> Router Class Initialized
INFO - 2021-07-12 08:50:03 --> Output Class Initialized
INFO - 2021-07-12 08:50:03 --> Security Class Initialized
DEBUG - 2021-07-12 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:50:03 --> Input Class Initialized
INFO - 2021-07-12 08:50:03 --> Language Class Initialized
INFO - 2021-07-12 08:50:03 --> Language Class Initialized
INFO - 2021-07-12 08:50:03 --> Config Class Initialized
INFO - 2021-07-12 08:50:03 --> Loader Class Initialized
INFO - 2021-07-12 08:50:03 --> Helper loaded: url_helper
INFO - 2021-07-12 08:50:03 --> Helper loaded: file_helper
INFO - 2021-07-12 08:50:03 --> Helper loaded: form_helper
INFO - 2021-07-12 08:50:03 --> Helper loaded: my_helper
INFO - 2021-07-12 08:50:03 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:50:03 --> Controller Class Initialized
DEBUG - 2021-07-12 08:50:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:50:03 --> Final output sent to browser
DEBUG - 2021-07-12 08:50:03 --> Total execution time: 0.1472
INFO - 2021-07-12 08:50:06 --> Config Class Initialized
INFO - 2021-07-12 08:50:06 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:50:06 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:50:06 --> Utf8 Class Initialized
INFO - 2021-07-12 08:50:06 --> URI Class Initialized
INFO - 2021-07-12 08:50:06 --> Router Class Initialized
INFO - 2021-07-12 08:50:06 --> Output Class Initialized
INFO - 2021-07-12 08:50:06 --> Security Class Initialized
DEBUG - 2021-07-12 08:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:50:06 --> Input Class Initialized
INFO - 2021-07-12 08:50:06 --> Language Class Initialized
INFO - 2021-07-12 08:50:06 --> Language Class Initialized
INFO - 2021-07-12 08:50:06 --> Config Class Initialized
INFO - 2021-07-12 08:50:06 --> Loader Class Initialized
INFO - 2021-07-12 08:50:06 --> Helper loaded: url_helper
INFO - 2021-07-12 08:50:06 --> Helper loaded: file_helper
INFO - 2021-07-12 08:50:06 --> Helper loaded: form_helper
INFO - 2021-07-12 08:50:06 --> Helper loaded: my_helper
INFO - 2021-07-12 08:50:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:50:06 --> Controller Class Initialized
DEBUG - 2021-07-12 08:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:50:06 --> Final output sent to browser
DEBUG - 2021-07-12 08:50:06 --> Total execution time: 0.1157
INFO - 2021-07-12 08:55:06 --> Config Class Initialized
INFO - 2021-07-12 08:55:06 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:55:06 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:55:06 --> Utf8 Class Initialized
INFO - 2021-07-12 08:55:06 --> URI Class Initialized
INFO - 2021-07-12 08:55:06 --> Router Class Initialized
INFO - 2021-07-12 08:55:06 --> Output Class Initialized
INFO - 2021-07-12 08:55:06 --> Security Class Initialized
DEBUG - 2021-07-12 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:55:06 --> Input Class Initialized
INFO - 2021-07-12 08:55:06 --> Language Class Initialized
INFO - 2021-07-12 08:55:06 --> Language Class Initialized
INFO - 2021-07-12 08:55:06 --> Config Class Initialized
INFO - 2021-07-12 08:55:06 --> Loader Class Initialized
INFO - 2021-07-12 08:55:06 --> Helper loaded: url_helper
INFO - 2021-07-12 08:55:06 --> Helper loaded: file_helper
INFO - 2021-07-12 08:55:06 --> Helper loaded: form_helper
INFO - 2021-07-12 08:55:06 --> Helper loaded: my_helper
INFO - 2021-07-12 08:55:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:55:06 --> Controller Class Initialized
INFO - 2021-07-12 08:55:06 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:55:06 --> Config Class Initialized
INFO - 2021-07-12 08:55:06 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:55:06 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:55:06 --> Utf8 Class Initialized
INFO - 2021-07-12 08:55:06 --> URI Class Initialized
INFO - 2021-07-12 08:55:06 --> Router Class Initialized
INFO - 2021-07-12 08:55:06 --> Output Class Initialized
INFO - 2021-07-12 08:55:06 --> Security Class Initialized
DEBUG - 2021-07-12 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:55:06 --> Input Class Initialized
INFO - 2021-07-12 08:55:06 --> Language Class Initialized
INFO - 2021-07-12 08:55:06 --> Language Class Initialized
INFO - 2021-07-12 08:55:06 --> Config Class Initialized
INFO - 2021-07-12 08:55:06 --> Loader Class Initialized
INFO - 2021-07-12 08:55:06 --> Helper loaded: url_helper
INFO - 2021-07-12 08:55:06 --> Helper loaded: file_helper
INFO - 2021-07-12 08:55:06 --> Helper loaded: form_helper
INFO - 2021-07-12 08:55:06 --> Helper loaded: my_helper
INFO - 2021-07-12 08:55:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:55:06 --> Controller Class Initialized
DEBUG - 2021-07-12 08:55:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 08:55:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:55:06 --> Final output sent to browser
DEBUG - 2021-07-12 08:55:06 --> Total execution time: 0.0413
INFO - 2021-07-12 08:56:13 --> Config Class Initialized
INFO - 2021-07-12 08:56:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:13 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:13 --> URI Class Initialized
INFO - 2021-07-12 08:56:13 --> Router Class Initialized
INFO - 2021-07-12 08:56:13 --> Output Class Initialized
INFO - 2021-07-12 08:56:13 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:13 --> Input Class Initialized
INFO - 2021-07-12 08:56:13 --> Language Class Initialized
INFO - 2021-07-12 08:56:13 --> Language Class Initialized
INFO - 2021-07-12 08:56:13 --> Config Class Initialized
INFO - 2021-07-12 08:56:13 --> Loader Class Initialized
INFO - 2021-07-12 08:56:13 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:13 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:13 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:13 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:13 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:13 --> Controller Class Initialized
INFO - 2021-07-12 08:56:13 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:56:13 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:13 --> Total execution time: 0.0581
INFO - 2021-07-12 08:56:13 --> Config Class Initialized
INFO - 2021-07-12 08:56:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:13 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:13 --> URI Class Initialized
INFO - 2021-07-12 08:56:13 --> Router Class Initialized
INFO - 2021-07-12 08:56:13 --> Output Class Initialized
INFO - 2021-07-12 08:56:13 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:13 --> Input Class Initialized
INFO - 2021-07-12 08:56:13 --> Language Class Initialized
INFO - 2021-07-12 08:56:13 --> Language Class Initialized
INFO - 2021-07-12 08:56:13 --> Config Class Initialized
INFO - 2021-07-12 08:56:13 --> Loader Class Initialized
INFO - 2021-07-12 08:56:13 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:13 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:13 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:13 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:13 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:13 --> Controller Class Initialized
DEBUG - 2021-07-12 08:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 08:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:56:14 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:14 --> Total execution time: 0.7268
INFO - 2021-07-12 08:56:16 --> Config Class Initialized
INFO - 2021-07-12 08:56:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:16 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:16 --> URI Class Initialized
INFO - 2021-07-12 08:56:16 --> Router Class Initialized
INFO - 2021-07-12 08:56:16 --> Output Class Initialized
INFO - 2021-07-12 08:56:16 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:16 --> Input Class Initialized
INFO - 2021-07-12 08:56:16 --> Language Class Initialized
INFO - 2021-07-12 08:56:16 --> Language Class Initialized
INFO - 2021-07-12 08:56:16 --> Config Class Initialized
INFO - 2021-07-12 08:56:16 --> Loader Class Initialized
INFO - 2021-07-12 08:56:16 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:16 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:16 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:16 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:16 --> Controller Class Initialized
DEBUG - 2021-07-12 08:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-12 08:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:56:16 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:16 --> Total execution time: 0.0762
INFO - 2021-07-12 08:56:19 --> Config Class Initialized
INFO - 2021-07-12 08:56:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:19 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:19 --> URI Class Initialized
INFO - 2021-07-12 08:56:19 --> Router Class Initialized
INFO - 2021-07-12 08:56:19 --> Output Class Initialized
INFO - 2021-07-12 08:56:19 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:19 --> Input Class Initialized
INFO - 2021-07-12 08:56:19 --> Language Class Initialized
INFO - 2021-07-12 08:56:19 --> Language Class Initialized
INFO - 2021-07-12 08:56:19 --> Config Class Initialized
INFO - 2021-07-12 08:56:19 --> Loader Class Initialized
INFO - 2021-07-12 08:56:19 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:19 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:19 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:19 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:19 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:19 --> Controller Class Initialized
DEBUG - 2021-07-12 08:56:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:56:19 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:19 --> Total execution time: 0.2337
INFO - 2021-07-12 08:56:50 --> Config Class Initialized
INFO - 2021-07-12 08:56:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:50 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:50 --> URI Class Initialized
INFO - 2021-07-12 08:56:51 --> Router Class Initialized
INFO - 2021-07-12 08:56:51 --> Output Class Initialized
INFO - 2021-07-12 08:56:51 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:51 --> Input Class Initialized
INFO - 2021-07-12 08:56:51 --> Language Class Initialized
INFO - 2021-07-12 08:56:51 --> Language Class Initialized
INFO - 2021-07-12 08:56:51 --> Config Class Initialized
INFO - 2021-07-12 08:56:51 --> Loader Class Initialized
INFO - 2021-07-12 08:56:51 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:51 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:51 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:51 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:51 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:51 --> Controller Class Initialized
DEBUG - 2021-07-12 08:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 08:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:56:51 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:51 --> Total execution time: 0.0539
INFO - 2021-07-12 08:56:54 --> Config Class Initialized
INFO - 2021-07-12 08:56:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:54 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:54 --> URI Class Initialized
INFO - 2021-07-12 08:56:54 --> Router Class Initialized
INFO - 2021-07-12 08:56:54 --> Output Class Initialized
INFO - 2021-07-12 08:56:54 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:54 --> Input Class Initialized
INFO - 2021-07-12 08:56:54 --> Language Class Initialized
INFO - 2021-07-12 08:56:54 --> Language Class Initialized
INFO - 2021-07-12 08:56:54 --> Config Class Initialized
INFO - 2021-07-12 08:56:54 --> Loader Class Initialized
INFO - 2021-07-12 08:56:54 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:54 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:54 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:54 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:54 --> Controller Class Initialized
DEBUG - 2021-07-12 08:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:56:54 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:54 --> Total execution time: 0.1278
INFO - 2021-07-12 08:56:55 --> Config Class Initialized
INFO - 2021-07-12 08:56:55 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:55 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:55 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:55 --> URI Class Initialized
INFO - 2021-07-12 08:56:55 --> Router Class Initialized
INFO - 2021-07-12 08:56:55 --> Output Class Initialized
INFO - 2021-07-12 08:56:55 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:55 --> Input Class Initialized
INFO - 2021-07-12 08:56:55 --> Language Class Initialized
INFO - 2021-07-12 08:56:55 --> Language Class Initialized
INFO - 2021-07-12 08:56:55 --> Config Class Initialized
INFO - 2021-07-12 08:56:55 --> Loader Class Initialized
INFO - 2021-07-12 08:56:55 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:55 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:55 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:55 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:55 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:55 --> Controller Class Initialized
DEBUG - 2021-07-12 08:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:56:55 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:55 --> Total execution time: 0.1256
INFO - 2021-07-12 08:56:57 --> Config Class Initialized
INFO - 2021-07-12 08:56:57 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:57 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:57 --> URI Class Initialized
INFO - 2021-07-12 08:56:57 --> Router Class Initialized
INFO - 2021-07-12 08:56:57 --> Output Class Initialized
INFO - 2021-07-12 08:56:57 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:57 --> Input Class Initialized
INFO - 2021-07-12 08:56:57 --> Language Class Initialized
INFO - 2021-07-12 08:56:57 --> Language Class Initialized
INFO - 2021-07-12 08:56:57 --> Config Class Initialized
INFO - 2021-07-12 08:56:57 --> Loader Class Initialized
INFO - 2021-07-12 08:56:57 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:57 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:57 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:57 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:57 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:57 --> Controller Class Initialized
DEBUG - 2021-07-12 08:56:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:56:57 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:57 --> Total execution time: 0.1188
INFO - 2021-07-12 08:56:59 --> Config Class Initialized
INFO - 2021-07-12 08:56:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:56:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:56:59 --> Utf8 Class Initialized
INFO - 2021-07-12 08:56:59 --> URI Class Initialized
INFO - 2021-07-12 08:56:59 --> Router Class Initialized
INFO - 2021-07-12 08:56:59 --> Output Class Initialized
INFO - 2021-07-12 08:56:59 --> Security Class Initialized
DEBUG - 2021-07-12 08:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:56:59 --> Input Class Initialized
INFO - 2021-07-12 08:56:59 --> Language Class Initialized
INFO - 2021-07-12 08:56:59 --> Language Class Initialized
INFO - 2021-07-12 08:56:59 --> Config Class Initialized
INFO - 2021-07-12 08:56:59 --> Loader Class Initialized
INFO - 2021-07-12 08:56:59 --> Helper loaded: url_helper
INFO - 2021-07-12 08:56:59 --> Helper loaded: file_helper
INFO - 2021-07-12 08:56:59 --> Helper loaded: form_helper
INFO - 2021-07-12 08:56:59 --> Helper loaded: my_helper
INFO - 2021-07-12 08:56:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:56:59 --> Controller Class Initialized
DEBUG - 2021-07-12 08:56:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:56:59 --> Final output sent to browser
DEBUG - 2021-07-12 08:56:59 --> Total execution time: 0.1135
INFO - 2021-07-12 08:57:00 --> Config Class Initialized
INFO - 2021-07-12 08:57:00 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:00 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:00 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:00 --> URI Class Initialized
INFO - 2021-07-12 08:57:00 --> Router Class Initialized
INFO - 2021-07-12 08:57:00 --> Output Class Initialized
INFO - 2021-07-12 08:57:00 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:00 --> Input Class Initialized
INFO - 2021-07-12 08:57:00 --> Language Class Initialized
INFO - 2021-07-12 08:57:00 --> Language Class Initialized
INFO - 2021-07-12 08:57:00 --> Config Class Initialized
INFO - 2021-07-12 08:57:00 --> Loader Class Initialized
INFO - 2021-07-12 08:57:00 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:00 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:00 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:00 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:00 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:00 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:01 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:01 --> Total execution time: 0.1473
INFO - 2021-07-12 08:57:03 --> Config Class Initialized
INFO - 2021-07-12 08:57:03 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:03 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:03 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:03 --> URI Class Initialized
INFO - 2021-07-12 08:57:03 --> Router Class Initialized
INFO - 2021-07-12 08:57:03 --> Output Class Initialized
INFO - 2021-07-12 08:57:03 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:03 --> Input Class Initialized
INFO - 2021-07-12 08:57:03 --> Language Class Initialized
INFO - 2021-07-12 08:57:03 --> Language Class Initialized
INFO - 2021-07-12 08:57:03 --> Config Class Initialized
INFO - 2021-07-12 08:57:03 --> Loader Class Initialized
INFO - 2021-07-12 08:57:03 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:03 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:03 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:03 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:03 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:03 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:03 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:03 --> Total execution time: 0.1349
INFO - 2021-07-12 08:57:05 --> Config Class Initialized
INFO - 2021-07-12 08:57:05 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:05 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:05 --> URI Class Initialized
INFO - 2021-07-12 08:57:05 --> Router Class Initialized
INFO - 2021-07-12 08:57:05 --> Output Class Initialized
INFO - 2021-07-12 08:57:05 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:05 --> Input Class Initialized
INFO - 2021-07-12 08:57:05 --> Language Class Initialized
INFO - 2021-07-12 08:57:05 --> Language Class Initialized
INFO - 2021-07-12 08:57:05 --> Config Class Initialized
INFO - 2021-07-12 08:57:05 --> Loader Class Initialized
INFO - 2021-07-12 08:57:05 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:05 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:05 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:05 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:05 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:05 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:05 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:05 --> Total execution time: 0.1191
INFO - 2021-07-12 08:57:07 --> Config Class Initialized
INFO - 2021-07-12 08:57:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:07 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:07 --> URI Class Initialized
INFO - 2021-07-12 08:57:07 --> Router Class Initialized
INFO - 2021-07-12 08:57:07 --> Output Class Initialized
INFO - 2021-07-12 08:57:07 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:07 --> Input Class Initialized
INFO - 2021-07-12 08:57:07 --> Language Class Initialized
INFO - 2021-07-12 08:57:07 --> Language Class Initialized
INFO - 2021-07-12 08:57:07 --> Config Class Initialized
INFO - 2021-07-12 08:57:07 --> Loader Class Initialized
INFO - 2021-07-12 08:57:07 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:07 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:07 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:07 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:07 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:07 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:07 --> Total execution time: 0.1331
INFO - 2021-07-12 08:57:09 --> Config Class Initialized
INFO - 2021-07-12 08:57:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:09 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:09 --> URI Class Initialized
INFO - 2021-07-12 08:57:09 --> Router Class Initialized
INFO - 2021-07-12 08:57:09 --> Output Class Initialized
INFO - 2021-07-12 08:57:09 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:09 --> Input Class Initialized
INFO - 2021-07-12 08:57:09 --> Language Class Initialized
INFO - 2021-07-12 08:57:10 --> Language Class Initialized
INFO - 2021-07-12 08:57:10 --> Config Class Initialized
INFO - 2021-07-12 08:57:10 --> Loader Class Initialized
INFO - 2021-07-12 08:57:10 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:10 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:10 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:10 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:10 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:10 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:10 --> Total execution time: 0.1349
INFO - 2021-07-12 08:57:11 --> Config Class Initialized
INFO - 2021-07-12 08:57:11 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:11 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:11 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:11 --> URI Class Initialized
INFO - 2021-07-12 08:57:11 --> Router Class Initialized
INFO - 2021-07-12 08:57:11 --> Output Class Initialized
INFO - 2021-07-12 08:57:11 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:11 --> Input Class Initialized
INFO - 2021-07-12 08:57:11 --> Language Class Initialized
INFO - 2021-07-12 08:57:11 --> Language Class Initialized
INFO - 2021-07-12 08:57:11 --> Config Class Initialized
INFO - 2021-07-12 08:57:11 --> Loader Class Initialized
INFO - 2021-07-12 08:57:11 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:11 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:11 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:11 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:11 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:11 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:11 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:11 --> Total execution time: 0.1181
INFO - 2021-07-12 08:57:14 --> Config Class Initialized
INFO - 2021-07-12 08:57:14 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:14 --> URI Class Initialized
INFO - 2021-07-12 08:57:14 --> Router Class Initialized
INFO - 2021-07-12 08:57:14 --> Output Class Initialized
INFO - 2021-07-12 08:57:14 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:14 --> Input Class Initialized
INFO - 2021-07-12 08:57:14 --> Language Class Initialized
INFO - 2021-07-12 08:57:14 --> Language Class Initialized
INFO - 2021-07-12 08:57:14 --> Config Class Initialized
INFO - 2021-07-12 08:57:14 --> Loader Class Initialized
INFO - 2021-07-12 08:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:14 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:14 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:14 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:14 --> Total execution time: 0.1305
INFO - 2021-07-12 08:57:16 --> Config Class Initialized
INFO - 2021-07-12 08:57:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:16 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:16 --> URI Class Initialized
INFO - 2021-07-12 08:57:16 --> Router Class Initialized
INFO - 2021-07-12 08:57:16 --> Output Class Initialized
INFO - 2021-07-12 08:57:16 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:16 --> Input Class Initialized
INFO - 2021-07-12 08:57:16 --> Language Class Initialized
INFO - 2021-07-12 08:57:16 --> Language Class Initialized
INFO - 2021-07-12 08:57:16 --> Config Class Initialized
INFO - 2021-07-12 08:57:16 --> Loader Class Initialized
INFO - 2021-07-12 08:57:16 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:16 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:16 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:16 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:16 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:16 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:16 --> Total execution time: 0.1511
INFO - 2021-07-12 08:57:18 --> Config Class Initialized
INFO - 2021-07-12 08:57:18 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:18 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:18 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:18 --> URI Class Initialized
INFO - 2021-07-12 08:57:18 --> Router Class Initialized
INFO - 2021-07-12 08:57:18 --> Output Class Initialized
INFO - 2021-07-12 08:57:18 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:18 --> Input Class Initialized
INFO - 2021-07-12 08:57:18 --> Language Class Initialized
INFO - 2021-07-12 08:57:18 --> Language Class Initialized
INFO - 2021-07-12 08:57:18 --> Config Class Initialized
INFO - 2021-07-12 08:57:18 --> Loader Class Initialized
INFO - 2021-07-12 08:57:18 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:18 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:18 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:18 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:18 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:18 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:18 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:18 --> Total execution time: 0.1172
INFO - 2021-07-12 08:57:19 --> Config Class Initialized
INFO - 2021-07-12 08:57:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:19 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:19 --> URI Class Initialized
INFO - 2021-07-12 08:57:19 --> Router Class Initialized
INFO - 2021-07-12 08:57:19 --> Output Class Initialized
INFO - 2021-07-12 08:57:19 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:19 --> Input Class Initialized
INFO - 2021-07-12 08:57:19 --> Language Class Initialized
INFO - 2021-07-12 08:57:20 --> Language Class Initialized
INFO - 2021-07-12 08:57:20 --> Config Class Initialized
INFO - 2021-07-12 08:57:20 --> Loader Class Initialized
INFO - 2021-07-12 08:57:20 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:20 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:20 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:20 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:20 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:20 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:20 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:20 --> Total execution time: 0.1344
INFO - 2021-07-12 08:57:22 --> Config Class Initialized
INFO - 2021-07-12 08:57:22 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:22 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:22 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:22 --> URI Class Initialized
INFO - 2021-07-12 08:57:22 --> Router Class Initialized
INFO - 2021-07-12 08:57:22 --> Output Class Initialized
INFO - 2021-07-12 08:57:22 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:22 --> Input Class Initialized
INFO - 2021-07-12 08:57:22 --> Language Class Initialized
INFO - 2021-07-12 08:57:22 --> Language Class Initialized
INFO - 2021-07-12 08:57:22 --> Config Class Initialized
INFO - 2021-07-12 08:57:22 --> Loader Class Initialized
INFO - 2021-07-12 08:57:22 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:22 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:22 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:22 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:22 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:22 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:22 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:22 --> Total execution time: 0.1317
INFO - 2021-07-12 08:57:24 --> Config Class Initialized
INFO - 2021-07-12 08:57:24 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:24 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:24 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:24 --> URI Class Initialized
INFO - 2021-07-12 08:57:24 --> Router Class Initialized
INFO - 2021-07-12 08:57:24 --> Output Class Initialized
INFO - 2021-07-12 08:57:24 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:24 --> Input Class Initialized
INFO - 2021-07-12 08:57:24 --> Language Class Initialized
INFO - 2021-07-12 08:57:24 --> Language Class Initialized
INFO - 2021-07-12 08:57:24 --> Config Class Initialized
INFO - 2021-07-12 08:57:24 --> Loader Class Initialized
INFO - 2021-07-12 08:57:24 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:24 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:24 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:24 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:24 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:24 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:24 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:24 --> Total execution time: 0.1213
INFO - 2021-07-12 08:57:25 --> Config Class Initialized
INFO - 2021-07-12 08:57:25 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:25 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:25 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:25 --> URI Class Initialized
INFO - 2021-07-12 08:57:25 --> Router Class Initialized
INFO - 2021-07-12 08:57:25 --> Output Class Initialized
INFO - 2021-07-12 08:57:25 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:25 --> Input Class Initialized
INFO - 2021-07-12 08:57:25 --> Language Class Initialized
INFO - 2021-07-12 08:57:25 --> Language Class Initialized
INFO - 2021-07-12 08:57:25 --> Config Class Initialized
INFO - 2021-07-12 08:57:25 --> Loader Class Initialized
INFO - 2021-07-12 08:57:25 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:25 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:25 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:25 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:25 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:25 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:25 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:25 --> Total execution time: 0.1314
INFO - 2021-07-12 08:57:28 --> Config Class Initialized
INFO - 2021-07-12 08:57:28 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:28 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:28 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:28 --> URI Class Initialized
INFO - 2021-07-12 08:57:28 --> Router Class Initialized
INFO - 2021-07-12 08:57:28 --> Output Class Initialized
INFO - 2021-07-12 08:57:28 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:28 --> Input Class Initialized
INFO - 2021-07-12 08:57:28 --> Language Class Initialized
INFO - 2021-07-12 08:57:28 --> Language Class Initialized
INFO - 2021-07-12 08:57:28 --> Config Class Initialized
INFO - 2021-07-12 08:57:28 --> Loader Class Initialized
INFO - 2021-07-12 08:57:28 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:28 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:28 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:28 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:28 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:28 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:28 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:28 --> Total execution time: 0.1340
INFO - 2021-07-12 08:57:30 --> Config Class Initialized
INFO - 2021-07-12 08:57:30 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:30 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:30 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:30 --> URI Class Initialized
INFO - 2021-07-12 08:57:30 --> Router Class Initialized
INFO - 2021-07-12 08:57:30 --> Output Class Initialized
INFO - 2021-07-12 08:57:30 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:30 --> Input Class Initialized
INFO - 2021-07-12 08:57:30 --> Language Class Initialized
INFO - 2021-07-12 08:57:30 --> Language Class Initialized
INFO - 2021-07-12 08:57:30 --> Config Class Initialized
INFO - 2021-07-12 08:57:30 --> Loader Class Initialized
INFO - 2021-07-12 08:57:30 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:30 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:30 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:30 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:30 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:30 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:30 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:30 --> Total execution time: 0.1223
INFO - 2021-07-12 08:57:32 --> Config Class Initialized
INFO - 2021-07-12 08:57:32 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:32 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:32 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:32 --> URI Class Initialized
INFO - 2021-07-12 08:57:32 --> Router Class Initialized
INFO - 2021-07-12 08:57:32 --> Output Class Initialized
INFO - 2021-07-12 08:57:32 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:32 --> Input Class Initialized
INFO - 2021-07-12 08:57:32 --> Language Class Initialized
INFO - 2021-07-12 08:57:32 --> Language Class Initialized
INFO - 2021-07-12 08:57:32 --> Config Class Initialized
INFO - 2021-07-12 08:57:32 --> Loader Class Initialized
INFO - 2021-07-12 08:57:32 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:32 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:32 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:32 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:32 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:32 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:32 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:32 --> Total execution time: 0.1325
INFO - 2021-07-12 08:57:35 --> Config Class Initialized
INFO - 2021-07-12 08:57:35 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:35 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:35 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:35 --> URI Class Initialized
INFO - 2021-07-12 08:57:35 --> Router Class Initialized
INFO - 2021-07-12 08:57:35 --> Output Class Initialized
INFO - 2021-07-12 08:57:35 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:35 --> Input Class Initialized
INFO - 2021-07-12 08:57:35 --> Language Class Initialized
INFO - 2021-07-12 08:57:36 --> Language Class Initialized
INFO - 2021-07-12 08:57:36 --> Config Class Initialized
INFO - 2021-07-12 08:57:36 --> Loader Class Initialized
INFO - 2021-07-12 08:57:36 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:36 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:36 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:36 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:36 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:36 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:36 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:36 --> Total execution time: 0.1318
INFO - 2021-07-12 08:57:37 --> Config Class Initialized
INFO - 2021-07-12 08:57:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:37 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:37 --> URI Class Initialized
INFO - 2021-07-12 08:57:37 --> Router Class Initialized
INFO - 2021-07-12 08:57:37 --> Output Class Initialized
INFO - 2021-07-12 08:57:37 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:37 --> Input Class Initialized
INFO - 2021-07-12 08:57:37 --> Language Class Initialized
INFO - 2021-07-12 08:57:37 --> Language Class Initialized
INFO - 2021-07-12 08:57:37 --> Config Class Initialized
INFO - 2021-07-12 08:57:37 --> Loader Class Initialized
INFO - 2021-07-12 08:57:37 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:37 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:37 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:37 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:37 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:37 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:37 --> Total execution time: 0.1217
INFO - 2021-07-12 08:57:39 --> Config Class Initialized
INFO - 2021-07-12 08:57:39 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:39 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:39 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:39 --> URI Class Initialized
INFO - 2021-07-12 08:57:39 --> Router Class Initialized
INFO - 2021-07-12 08:57:39 --> Output Class Initialized
INFO - 2021-07-12 08:57:39 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:39 --> Input Class Initialized
INFO - 2021-07-12 08:57:39 --> Language Class Initialized
INFO - 2021-07-12 08:57:39 --> Language Class Initialized
INFO - 2021-07-12 08:57:39 --> Config Class Initialized
INFO - 2021-07-12 08:57:39 --> Loader Class Initialized
INFO - 2021-07-12 08:57:39 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:39 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:39 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:39 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:39 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:39 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:39 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:39 --> Total execution time: 0.1324
INFO - 2021-07-12 08:57:42 --> Config Class Initialized
INFO - 2021-07-12 08:57:42 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:42 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:42 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:42 --> URI Class Initialized
INFO - 2021-07-12 08:57:42 --> Router Class Initialized
INFO - 2021-07-12 08:57:42 --> Output Class Initialized
INFO - 2021-07-12 08:57:42 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:42 --> Input Class Initialized
INFO - 2021-07-12 08:57:42 --> Language Class Initialized
INFO - 2021-07-12 08:57:42 --> Language Class Initialized
INFO - 2021-07-12 08:57:42 --> Config Class Initialized
INFO - 2021-07-12 08:57:42 --> Loader Class Initialized
INFO - 2021-07-12 08:57:42 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:42 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:42 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:42 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:42 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:42 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:42 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:42 --> Total execution time: 0.1330
INFO - 2021-07-12 08:57:44 --> Config Class Initialized
INFO - 2021-07-12 08:57:44 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:44 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:44 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:44 --> URI Class Initialized
INFO - 2021-07-12 08:57:44 --> Router Class Initialized
INFO - 2021-07-12 08:57:44 --> Output Class Initialized
INFO - 2021-07-12 08:57:44 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:44 --> Input Class Initialized
INFO - 2021-07-12 08:57:44 --> Language Class Initialized
INFO - 2021-07-12 08:57:44 --> Language Class Initialized
INFO - 2021-07-12 08:57:44 --> Config Class Initialized
INFO - 2021-07-12 08:57:44 --> Loader Class Initialized
INFO - 2021-07-12 08:57:44 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:44 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:44 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:44 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:44 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:44 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:45 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:45 --> Total execution time: 0.1212
INFO - 2021-07-12 08:57:46 --> Config Class Initialized
INFO - 2021-07-12 08:57:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:46 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:46 --> URI Class Initialized
INFO - 2021-07-12 08:57:46 --> Router Class Initialized
INFO - 2021-07-12 08:57:46 --> Output Class Initialized
INFO - 2021-07-12 08:57:46 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:46 --> Input Class Initialized
INFO - 2021-07-12 08:57:46 --> Language Class Initialized
INFO - 2021-07-12 08:57:46 --> Language Class Initialized
INFO - 2021-07-12 08:57:46 --> Config Class Initialized
INFO - 2021-07-12 08:57:46 --> Loader Class Initialized
INFO - 2021-07-12 08:57:46 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:46 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:46 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:46 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:46 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:46 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:46 --> Total execution time: 0.1300
INFO - 2021-07-12 08:57:48 --> Config Class Initialized
INFO - 2021-07-12 08:57:48 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:48 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:48 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:48 --> URI Class Initialized
INFO - 2021-07-12 08:57:48 --> Router Class Initialized
INFO - 2021-07-12 08:57:48 --> Output Class Initialized
INFO - 2021-07-12 08:57:48 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:48 --> Input Class Initialized
INFO - 2021-07-12 08:57:48 --> Language Class Initialized
INFO - 2021-07-12 08:57:48 --> Language Class Initialized
INFO - 2021-07-12 08:57:48 --> Config Class Initialized
INFO - 2021-07-12 08:57:48 --> Loader Class Initialized
INFO - 2021-07-12 08:57:48 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:48 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:48 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:48 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:48 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:48 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:48 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:48 --> Total execution time: 0.1332
INFO - 2021-07-12 08:57:53 --> Config Class Initialized
INFO - 2021-07-12 08:57:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:53 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:53 --> URI Class Initialized
INFO - 2021-07-12 08:57:53 --> Router Class Initialized
INFO - 2021-07-12 08:57:53 --> Output Class Initialized
INFO - 2021-07-12 08:57:53 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:53 --> Input Class Initialized
INFO - 2021-07-12 08:57:53 --> Language Class Initialized
INFO - 2021-07-12 08:57:53 --> Language Class Initialized
INFO - 2021-07-12 08:57:53 --> Config Class Initialized
INFO - 2021-07-12 08:57:53 --> Loader Class Initialized
INFO - 2021-07-12 08:57:53 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:53 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:53 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:53 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:53 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:53 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:53 --> Total execution time: 0.1445
INFO - 2021-07-12 08:57:57 --> Config Class Initialized
INFO - 2021-07-12 08:57:57 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:57 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:57 --> URI Class Initialized
INFO - 2021-07-12 08:57:57 --> Router Class Initialized
INFO - 2021-07-12 08:57:57 --> Output Class Initialized
INFO - 2021-07-12 08:57:57 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:57 --> Input Class Initialized
INFO - 2021-07-12 08:57:57 --> Language Class Initialized
INFO - 2021-07-12 08:57:57 --> Language Class Initialized
INFO - 2021-07-12 08:57:57 --> Config Class Initialized
INFO - 2021-07-12 08:57:57 --> Loader Class Initialized
INFO - 2021-07-12 08:57:57 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:57 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:57 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:57 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:57 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:57 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:57 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:57 --> Total execution time: 0.1288
INFO - 2021-07-12 08:57:58 --> Config Class Initialized
INFO - 2021-07-12 08:57:58 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:57:58 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:57:58 --> Utf8 Class Initialized
INFO - 2021-07-12 08:57:58 --> URI Class Initialized
INFO - 2021-07-12 08:57:58 --> Router Class Initialized
INFO - 2021-07-12 08:57:58 --> Output Class Initialized
INFO - 2021-07-12 08:57:58 --> Security Class Initialized
DEBUG - 2021-07-12 08:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:57:58 --> Input Class Initialized
INFO - 2021-07-12 08:57:58 --> Language Class Initialized
INFO - 2021-07-12 08:57:58 --> Language Class Initialized
INFO - 2021-07-12 08:57:58 --> Config Class Initialized
INFO - 2021-07-12 08:57:58 --> Loader Class Initialized
INFO - 2021-07-12 08:57:58 --> Helper loaded: url_helper
INFO - 2021-07-12 08:57:58 --> Helper loaded: file_helper
INFO - 2021-07-12 08:57:58 --> Helper loaded: form_helper
INFO - 2021-07-12 08:57:58 --> Helper loaded: my_helper
INFO - 2021-07-12 08:57:58 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:57:58 --> Controller Class Initialized
DEBUG - 2021-07-12 08:57:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:57:58 --> Final output sent to browser
DEBUG - 2021-07-12 08:57:58 --> Total execution time: 0.1328
INFO - 2021-07-12 08:58:01 --> Config Class Initialized
INFO - 2021-07-12 08:58:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:01 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:01 --> URI Class Initialized
INFO - 2021-07-12 08:58:01 --> Router Class Initialized
INFO - 2021-07-12 08:58:01 --> Output Class Initialized
INFO - 2021-07-12 08:58:01 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:01 --> Input Class Initialized
INFO - 2021-07-12 08:58:01 --> Language Class Initialized
INFO - 2021-07-12 08:58:01 --> Language Class Initialized
INFO - 2021-07-12 08:58:01 --> Config Class Initialized
INFO - 2021-07-12 08:58:01 --> Loader Class Initialized
INFO - 2021-07-12 08:58:01 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:01 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:01 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:01 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:01 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:01 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:01 --> Total execution time: 0.1192
INFO - 2021-07-12 08:58:03 --> Config Class Initialized
INFO - 2021-07-12 08:58:03 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:03 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:03 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:03 --> URI Class Initialized
INFO - 2021-07-12 08:58:03 --> Router Class Initialized
INFO - 2021-07-12 08:58:03 --> Output Class Initialized
INFO - 2021-07-12 08:58:03 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:03 --> Input Class Initialized
INFO - 2021-07-12 08:58:03 --> Language Class Initialized
INFO - 2021-07-12 08:58:03 --> Language Class Initialized
INFO - 2021-07-12 08:58:03 --> Config Class Initialized
INFO - 2021-07-12 08:58:03 --> Loader Class Initialized
INFO - 2021-07-12 08:58:03 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:03 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:03 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:03 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:03 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:03 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:03 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:03 --> Total execution time: 0.1315
INFO - 2021-07-12 08:58:05 --> Config Class Initialized
INFO - 2021-07-12 08:58:05 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:05 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:05 --> URI Class Initialized
INFO - 2021-07-12 08:58:05 --> Router Class Initialized
INFO - 2021-07-12 08:58:05 --> Output Class Initialized
INFO - 2021-07-12 08:58:05 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:05 --> Input Class Initialized
INFO - 2021-07-12 08:58:05 --> Language Class Initialized
INFO - 2021-07-12 08:58:05 --> Language Class Initialized
INFO - 2021-07-12 08:58:05 --> Config Class Initialized
INFO - 2021-07-12 08:58:05 --> Loader Class Initialized
INFO - 2021-07-12 08:58:05 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:05 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:05 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:05 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:05 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:05 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:05 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:05 --> Total execution time: 0.1320
INFO - 2021-07-12 08:58:07 --> Config Class Initialized
INFO - 2021-07-12 08:58:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:07 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:07 --> URI Class Initialized
INFO - 2021-07-12 08:58:07 --> Router Class Initialized
INFO - 2021-07-12 08:58:07 --> Output Class Initialized
INFO - 2021-07-12 08:58:07 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:07 --> Input Class Initialized
INFO - 2021-07-12 08:58:07 --> Language Class Initialized
INFO - 2021-07-12 08:58:07 --> Language Class Initialized
INFO - 2021-07-12 08:58:07 --> Config Class Initialized
INFO - 2021-07-12 08:58:07 --> Loader Class Initialized
INFO - 2021-07-12 08:58:07 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:07 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:07 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:07 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:07 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:07 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:07 --> Total execution time: 0.1185
INFO - 2021-07-12 08:58:09 --> Config Class Initialized
INFO - 2021-07-12 08:58:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:09 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:09 --> URI Class Initialized
INFO - 2021-07-12 08:58:09 --> Router Class Initialized
INFO - 2021-07-12 08:58:09 --> Output Class Initialized
INFO - 2021-07-12 08:58:09 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:09 --> Input Class Initialized
INFO - 2021-07-12 08:58:09 --> Language Class Initialized
INFO - 2021-07-12 08:58:09 --> Language Class Initialized
INFO - 2021-07-12 08:58:09 --> Config Class Initialized
INFO - 2021-07-12 08:58:09 --> Loader Class Initialized
INFO - 2021-07-12 08:58:09 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:09 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:09 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:09 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:09 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:09 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:09 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:09 --> Total execution time: 0.1329
INFO - 2021-07-12 08:58:11 --> Config Class Initialized
INFO - 2021-07-12 08:58:11 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:11 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:11 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:11 --> URI Class Initialized
INFO - 2021-07-12 08:58:11 --> Router Class Initialized
INFO - 2021-07-12 08:58:11 --> Output Class Initialized
INFO - 2021-07-12 08:58:11 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:11 --> Input Class Initialized
INFO - 2021-07-12 08:58:11 --> Language Class Initialized
INFO - 2021-07-12 08:58:11 --> Language Class Initialized
INFO - 2021-07-12 08:58:11 --> Config Class Initialized
INFO - 2021-07-12 08:58:11 --> Loader Class Initialized
INFO - 2021-07-12 08:58:11 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:11 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:11 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:11 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:11 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:11 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:11 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:11 --> Total execution time: 0.1320
INFO - 2021-07-12 08:58:13 --> Config Class Initialized
INFO - 2021-07-12 08:58:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:13 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:13 --> URI Class Initialized
INFO - 2021-07-12 08:58:13 --> Router Class Initialized
INFO - 2021-07-12 08:58:13 --> Output Class Initialized
INFO - 2021-07-12 08:58:13 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:13 --> Input Class Initialized
INFO - 2021-07-12 08:58:13 --> Language Class Initialized
INFO - 2021-07-12 08:58:13 --> Language Class Initialized
INFO - 2021-07-12 08:58:13 --> Config Class Initialized
INFO - 2021-07-12 08:58:13 --> Loader Class Initialized
INFO - 2021-07-12 08:58:13 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:13 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:13 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:13 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:13 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:13 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:13 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:13 --> Total execution time: 0.1326
INFO - 2021-07-12 08:58:15 --> Config Class Initialized
INFO - 2021-07-12 08:58:15 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:15 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:15 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:15 --> URI Class Initialized
INFO - 2021-07-12 08:58:15 --> Router Class Initialized
INFO - 2021-07-12 08:58:15 --> Output Class Initialized
INFO - 2021-07-12 08:58:15 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:15 --> Input Class Initialized
INFO - 2021-07-12 08:58:15 --> Language Class Initialized
INFO - 2021-07-12 08:58:15 --> Language Class Initialized
INFO - 2021-07-12 08:58:15 --> Config Class Initialized
INFO - 2021-07-12 08:58:15 --> Loader Class Initialized
INFO - 2021-07-12 08:58:15 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:15 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:15 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:16 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:16 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:16 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:16 --> Total execution time: 0.1414
INFO - 2021-07-12 08:58:17 --> Config Class Initialized
INFO - 2021-07-12 08:58:17 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:58:17 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:58:17 --> Utf8 Class Initialized
INFO - 2021-07-12 08:58:17 --> URI Class Initialized
INFO - 2021-07-12 08:58:17 --> Router Class Initialized
INFO - 2021-07-12 08:58:17 --> Output Class Initialized
INFO - 2021-07-12 08:58:17 --> Security Class Initialized
DEBUG - 2021-07-12 08:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:58:17 --> Input Class Initialized
INFO - 2021-07-12 08:58:17 --> Language Class Initialized
INFO - 2021-07-12 08:58:17 --> Language Class Initialized
INFO - 2021-07-12 08:58:17 --> Config Class Initialized
INFO - 2021-07-12 08:58:17 --> Loader Class Initialized
INFO - 2021-07-12 08:58:17 --> Helper loaded: url_helper
INFO - 2021-07-12 08:58:17 --> Helper loaded: file_helper
INFO - 2021-07-12 08:58:17 --> Helper loaded: form_helper
INFO - 2021-07-12 08:58:17 --> Helper loaded: my_helper
INFO - 2021-07-12 08:58:17 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:58:17 --> Controller Class Initialized
DEBUG - 2021-07-12 08:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-12 08:58:17 --> Final output sent to browser
DEBUG - 2021-07-12 08:58:17 --> Total execution time: 0.1227
INFO - 2021-07-12 10:02:33 --> Config Class Initialized
INFO - 2021-07-12 10:02:33 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:02:33 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:02:33 --> Utf8 Class Initialized
INFO - 2021-07-12 10:02:33 --> URI Class Initialized
DEBUG - 2021-07-12 10:02:33 --> No URI present. Default controller set.
INFO - 2021-07-12 10:02:33 --> Router Class Initialized
INFO - 2021-07-12 10:02:33 --> Output Class Initialized
INFO - 2021-07-12 10:02:33 --> Security Class Initialized
DEBUG - 2021-07-12 10:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:02:33 --> Input Class Initialized
INFO - 2021-07-12 10:02:33 --> Language Class Initialized
INFO - 2021-07-12 10:02:34 --> Language Class Initialized
INFO - 2021-07-12 10:02:34 --> Config Class Initialized
INFO - 2021-07-12 10:02:34 --> Loader Class Initialized
INFO - 2021-07-12 10:02:34 --> Helper loaded: url_helper
INFO - 2021-07-12 10:02:34 --> Helper loaded: file_helper
INFO - 2021-07-12 10:02:34 --> Helper loaded: form_helper
INFO - 2021-07-12 10:02:34 --> Helper loaded: my_helper
INFO - 2021-07-12 10:02:34 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:02:34 --> Controller Class Initialized
DEBUG - 2021-07-12 10:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 10:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:02:34 --> Final output sent to browser
DEBUG - 2021-07-12 10:02:34 --> Total execution time: 0.7068
INFO - 2021-07-12 10:07:27 --> Config Class Initialized
INFO - 2021-07-12 10:07:27 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:07:27 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:07:27 --> Utf8 Class Initialized
INFO - 2021-07-12 10:07:27 --> URI Class Initialized
INFO - 2021-07-12 10:07:27 --> Router Class Initialized
INFO - 2021-07-12 10:07:27 --> Output Class Initialized
INFO - 2021-07-12 10:07:27 --> Security Class Initialized
DEBUG - 2021-07-12 10:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:07:27 --> Input Class Initialized
INFO - 2021-07-12 10:07:27 --> Language Class Initialized
INFO - 2021-07-12 10:07:27 --> Language Class Initialized
INFO - 2021-07-12 10:07:27 --> Config Class Initialized
INFO - 2021-07-12 10:07:27 --> Loader Class Initialized
INFO - 2021-07-12 10:07:27 --> Helper loaded: url_helper
INFO - 2021-07-12 10:07:27 --> Helper loaded: file_helper
INFO - 2021-07-12 10:07:27 --> Helper loaded: form_helper
INFO - 2021-07-12 10:07:27 --> Helper loaded: my_helper
INFO - 2021-07-12 10:07:27 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:07:27 --> Controller Class Initialized
INFO - 2021-07-12 10:07:27 --> Helper loaded: cookie_helper
INFO - 2021-07-12 10:07:27 --> Config Class Initialized
INFO - 2021-07-12 10:07:27 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:07:27 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:07:27 --> Utf8 Class Initialized
INFO - 2021-07-12 10:07:27 --> URI Class Initialized
INFO - 2021-07-12 10:07:27 --> Router Class Initialized
INFO - 2021-07-12 10:07:27 --> Output Class Initialized
INFO - 2021-07-12 10:07:27 --> Security Class Initialized
DEBUG - 2021-07-12 10:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:07:27 --> Input Class Initialized
INFO - 2021-07-12 10:07:27 --> Language Class Initialized
INFO - 2021-07-12 10:07:27 --> Language Class Initialized
INFO - 2021-07-12 10:07:27 --> Config Class Initialized
INFO - 2021-07-12 10:07:27 --> Loader Class Initialized
INFO - 2021-07-12 10:07:27 --> Helper loaded: url_helper
INFO - 2021-07-12 10:07:27 --> Helper loaded: file_helper
INFO - 2021-07-12 10:07:27 --> Helper loaded: form_helper
INFO - 2021-07-12 10:07:27 --> Helper loaded: my_helper
INFO - 2021-07-12 10:07:27 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:07:27 --> Controller Class Initialized
DEBUG - 2021-07-12 10:07:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 10:07:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:07:27 --> Final output sent to browser
DEBUG - 2021-07-12 10:07:27 --> Total execution time: 0.0435
INFO - 2021-07-12 10:47:36 --> Config Class Initialized
INFO - 2021-07-12 10:47:36 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:47:36 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:47:36 --> Utf8 Class Initialized
INFO - 2021-07-12 10:47:36 --> URI Class Initialized
INFO - 2021-07-12 10:47:36 --> Router Class Initialized
INFO - 2021-07-12 10:47:36 --> Output Class Initialized
INFO - 2021-07-12 10:47:36 --> Security Class Initialized
DEBUG - 2021-07-12 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:47:36 --> Input Class Initialized
INFO - 2021-07-12 10:47:36 --> Language Class Initialized
INFO - 2021-07-12 10:47:36 --> Language Class Initialized
INFO - 2021-07-12 10:47:36 --> Config Class Initialized
INFO - 2021-07-12 10:47:36 --> Loader Class Initialized
INFO - 2021-07-12 10:47:36 --> Helper loaded: url_helper
INFO - 2021-07-12 10:47:36 --> Helper loaded: file_helper
INFO - 2021-07-12 10:47:36 --> Helper loaded: form_helper
INFO - 2021-07-12 10:47:36 --> Helper loaded: my_helper
INFO - 2021-07-12 10:47:36 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:47:36 --> Controller Class Initialized
INFO - 2021-07-12 10:47:36 --> Helper loaded: cookie_helper
INFO - 2021-07-12 10:47:36 --> Final output sent to browser
DEBUG - 2021-07-12 10:47:36 --> Total execution time: 0.0529
INFO - 2021-07-12 10:47:36 --> Config Class Initialized
INFO - 2021-07-12 10:47:36 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:47:36 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:47:36 --> Utf8 Class Initialized
INFO - 2021-07-12 10:47:36 --> URI Class Initialized
INFO - 2021-07-12 10:47:36 --> Router Class Initialized
INFO - 2021-07-12 10:47:36 --> Output Class Initialized
INFO - 2021-07-12 10:47:36 --> Security Class Initialized
DEBUG - 2021-07-12 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:47:36 --> Input Class Initialized
INFO - 2021-07-12 10:47:36 --> Language Class Initialized
INFO - 2021-07-12 10:47:36 --> Language Class Initialized
INFO - 2021-07-12 10:47:36 --> Config Class Initialized
INFO - 2021-07-12 10:47:36 --> Loader Class Initialized
INFO - 2021-07-12 10:47:36 --> Helper loaded: url_helper
INFO - 2021-07-12 10:47:36 --> Helper loaded: file_helper
INFO - 2021-07-12 10:47:36 --> Helper loaded: form_helper
INFO - 2021-07-12 10:47:36 --> Helper loaded: my_helper
INFO - 2021-07-12 10:47:36 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:47:36 --> Controller Class Initialized
DEBUG - 2021-07-12 10:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 10:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:47:37 --> Final output sent to browser
DEBUG - 2021-07-12 10:47:37 --> Total execution time: 0.6221
INFO - 2021-07-12 10:47:39 --> Config Class Initialized
INFO - 2021-07-12 10:47:39 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:47:39 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:47:39 --> Utf8 Class Initialized
INFO - 2021-07-12 10:47:39 --> URI Class Initialized
INFO - 2021-07-12 10:47:39 --> Router Class Initialized
INFO - 2021-07-12 10:47:39 --> Output Class Initialized
INFO - 2021-07-12 10:47:39 --> Security Class Initialized
DEBUG - 2021-07-12 10:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:47:39 --> Input Class Initialized
INFO - 2021-07-12 10:47:39 --> Language Class Initialized
INFO - 2021-07-12 10:47:39 --> Language Class Initialized
INFO - 2021-07-12 10:47:39 --> Config Class Initialized
INFO - 2021-07-12 10:47:39 --> Loader Class Initialized
INFO - 2021-07-12 10:47:39 --> Helper loaded: url_helper
INFO - 2021-07-12 10:47:39 --> Helper loaded: file_helper
INFO - 2021-07-12 10:47:39 --> Helper loaded: form_helper
INFO - 2021-07-12 10:47:39 --> Helper loaded: my_helper
INFO - 2021-07-12 10:47:39 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:47:39 --> Controller Class Initialized
DEBUG - 2021-07-12 10:47:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-12 10:47:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:47:39 --> Final output sent to browser
DEBUG - 2021-07-12 10:47:39 --> Total execution time: 0.0717
INFO - 2021-07-12 10:48:24 --> Config Class Initialized
INFO - 2021-07-12 10:48:24 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:48:24 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:48:24 --> Utf8 Class Initialized
INFO - 2021-07-12 10:48:24 --> URI Class Initialized
INFO - 2021-07-12 10:48:24 --> Router Class Initialized
INFO - 2021-07-12 10:48:24 --> Output Class Initialized
INFO - 2021-07-12 10:48:24 --> Security Class Initialized
DEBUG - 2021-07-12 10:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:48:24 --> Input Class Initialized
INFO - 2021-07-12 10:48:24 --> Language Class Initialized
INFO - 2021-07-12 10:48:24 --> Language Class Initialized
INFO - 2021-07-12 10:48:24 --> Config Class Initialized
INFO - 2021-07-12 10:48:24 --> Loader Class Initialized
INFO - 2021-07-12 10:48:24 --> Helper loaded: url_helper
INFO - 2021-07-12 10:48:24 --> Helper loaded: file_helper
INFO - 2021-07-12 10:48:24 --> Helper loaded: form_helper
INFO - 2021-07-12 10:48:24 --> Helper loaded: my_helper
INFO - 2021-07-12 10:48:24 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:48:24 --> Controller Class Initialized
DEBUG - 2021-07-12 10:48:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:48:24 --> Final output sent to browser
DEBUG - 2021-07-12 10:48:24 --> Total execution time: 0.3045
INFO - 2021-07-12 10:49:06 --> Config Class Initialized
INFO - 2021-07-12 10:49:06 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:06 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:06 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:06 --> URI Class Initialized
INFO - 2021-07-12 10:49:06 --> Router Class Initialized
INFO - 2021-07-12 10:49:06 --> Output Class Initialized
INFO - 2021-07-12 10:49:06 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:06 --> Input Class Initialized
INFO - 2021-07-12 10:49:06 --> Language Class Initialized
INFO - 2021-07-12 10:49:06 --> Language Class Initialized
INFO - 2021-07-12 10:49:06 --> Config Class Initialized
INFO - 2021-07-12 10:49:06 --> Loader Class Initialized
INFO - 2021-07-12 10:49:06 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:06 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:06 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:06 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:06 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 10:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:49:06 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:06 --> Total execution time: 0.0784
INFO - 2021-07-12 10:49:31 --> Config Class Initialized
INFO - 2021-07-12 10:49:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:31 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:31 --> URI Class Initialized
INFO - 2021-07-12 10:49:31 --> Router Class Initialized
INFO - 2021-07-12 10:49:31 --> Output Class Initialized
INFO - 2021-07-12 10:49:31 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:31 --> Input Class Initialized
INFO - 2021-07-12 10:49:31 --> Language Class Initialized
INFO - 2021-07-12 10:49:31 --> Language Class Initialized
INFO - 2021-07-12 10:49:31 --> Config Class Initialized
INFO - 2021-07-12 10:49:31 --> Loader Class Initialized
INFO - 2021-07-12 10:49:31 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:31 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:31 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:31 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:31 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:31 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:31 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:31 --> Total execution time: 0.2083
INFO - 2021-07-12 10:49:33 --> Config Class Initialized
INFO - 2021-07-12 10:49:33 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:33 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:33 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:33 --> URI Class Initialized
INFO - 2021-07-12 10:49:33 --> Router Class Initialized
INFO - 2021-07-12 10:49:33 --> Output Class Initialized
INFO - 2021-07-12 10:49:33 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:33 --> Input Class Initialized
INFO - 2021-07-12 10:49:33 --> Language Class Initialized
INFO - 2021-07-12 10:49:33 --> Language Class Initialized
INFO - 2021-07-12 10:49:33 --> Config Class Initialized
INFO - 2021-07-12 10:49:33 --> Loader Class Initialized
INFO - 2021-07-12 10:49:33 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:33 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:33 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:33 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:33 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:33 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:33 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:33 --> Total execution time: 0.1342
INFO - 2021-07-12 10:49:34 --> Config Class Initialized
INFO - 2021-07-12 10:49:34 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:34 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:34 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:34 --> URI Class Initialized
INFO - 2021-07-12 10:49:34 --> Router Class Initialized
INFO - 2021-07-12 10:49:34 --> Output Class Initialized
INFO - 2021-07-12 10:49:34 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:34 --> Input Class Initialized
INFO - 2021-07-12 10:49:34 --> Language Class Initialized
INFO - 2021-07-12 10:49:34 --> Language Class Initialized
INFO - 2021-07-12 10:49:34 --> Config Class Initialized
INFO - 2021-07-12 10:49:34 --> Loader Class Initialized
INFO - 2021-07-12 10:49:34 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:34 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:34 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:34 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:34 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:34 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:34 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:34 --> Total execution time: 0.1142
INFO - 2021-07-12 10:49:37 --> Config Class Initialized
INFO - 2021-07-12 10:49:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:37 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:37 --> URI Class Initialized
INFO - 2021-07-12 10:49:37 --> Router Class Initialized
INFO - 2021-07-12 10:49:37 --> Output Class Initialized
INFO - 2021-07-12 10:49:37 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:37 --> Input Class Initialized
INFO - 2021-07-12 10:49:37 --> Language Class Initialized
INFO - 2021-07-12 10:49:37 --> Language Class Initialized
INFO - 2021-07-12 10:49:37 --> Config Class Initialized
INFO - 2021-07-12 10:49:37 --> Loader Class Initialized
INFO - 2021-07-12 10:49:37 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:37 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:37 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:37 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:37 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:37 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:37 --> Total execution time: 0.1261
INFO - 2021-07-12 10:49:39 --> Config Class Initialized
INFO - 2021-07-12 10:49:39 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:39 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:39 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:39 --> URI Class Initialized
INFO - 2021-07-12 10:49:39 --> Router Class Initialized
INFO - 2021-07-12 10:49:39 --> Output Class Initialized
INFO - 2021-07-12 10:49:39 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:39 --> Input Class Initialized
INFO - 2021-07-12 10:49:39 --> Language Class Initialized
INFO - 2021-07-12 10:49:39 --> Language Class Initialized
INFO - 2021-07-12 10:49:39 --> Config Class Initialized
INFO - 2021-07-12 10:49:39 --> Loader Class Initialized
INFO - 2021-07-12 10:49:39 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:39 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:39 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:39 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:39 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:39 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:39 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:39 --> Total execution time: 0.1352
INFO - 2021-07-12 10:49:40 --> Config Class Initialized
INFO - 2021-07-12 10:49:40 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:40 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:40 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:40 --> URI Class Initialized
INFO - 2021-07-12 10:49:40 --> Router Class Initialized
INFO - 2021-07-12 10:49:40 --> Output Class Initialized
INFO - 2021-07-12 10:49:40 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:40 --> Input Class Initialized
INFO - 2021-07-12 10:49:40 --> Language Class Initialized
INFO - 2021-07-12 10:49:40 --> Language Class Initialized
INFO - 2021-07-12 10:49:40 --> Config Class Initialized
INFO - 2021-07-12 10:49:40 --> Loader Class Initialized
INFO - 2021-07-12 10:49:40 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:40 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:40 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:40 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:40 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:40 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:41 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:41 --> Total execution time: 0.1129
INFO - 2021-07-12 10:49:42 --> Config Class Initialized
INFO - 2021-07-12 10:49:42 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:42 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:42 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:42 --> URI Class Initialized
INFO - 2021-07-12 10:49:42 --> Router Class Initialized
INFO - 2021-07-12 10:49:42 --> Output Class Initialized
INFO - 2021-07-12 10:49:42 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:42 --> Input Class Initialized
INFO - 2021-07-12 10:49:42 --> Language Class Initialized
INFO - 2021-07-12 10:49:42 --> Language Class Initialized
INFO - 2021-07-12 10:49:42 --> Config Class Initialized
INFO - 2021-07-12 10:49:42 --> Loader Class Initialized
INFO - 2021-07-12 10:49:42 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:42 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:42 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:42 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:42 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:42 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:42 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:42 --> Total execution time: 0.1154
INFO - 2021-07-12 10:49:45 --> Config Class Initialized
INFO - 2021-07-12 10:49:45 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:45 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:45 --> URI Class Initialized
INFO - 2021-07-12 10:49:45 --> Router Class Initialized
INFO - 2021-07-12 10:49:45 --> Output Class Initialized
INFO - 2021-07-12 10:49:45 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:45 --> Input Class Initialized
INFO - 2021-07-12 10:49:45 --> Language Class Initialized
INFO - 2021-07-12 10:49:45 --> Language Class Initialized
INFO - 2021-07-12 10:49:45 --> Config Class Initialized
INFO - 2021-07-12 10:49:45 --> Loader Class Initialized
INFO - 2021-07-12 10:49:45 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:45 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:45 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:45 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:45 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:45 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:45 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:45 --> Total execution time: 0.1354
INFO - 2021-07-12 10:49:46 --> Config Class Initialized
INFO - 2021-07-12 10:49:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:46 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:46 --> URI Class Initialized
INFO - 2021-07-12 10:49:46 --> Router Class Initialized
INFO - 2021-07-12 10:49:46 --> Output Class Initialized
INFO - 2021-07-12 10:49:46 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:46 --> Input Class Initialized
INFO - 2021-07-12 10:49:46 --> Language Class Initialized
INFO - 2021-07-12 10:49:46 --> Language Class Initialized
INFO - 2021-07-12 10:49:46 --> Config Class Initialized
INFO - 2021-07-12 10:49:46 --> Loader Class Initialized
INFO - 2021-07-12 10:49:46 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:46 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:46 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:46 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:46 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:46 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:46 --> Total execution time: 0.1150
INFO - 2021-07-12 10:49:47 --> Config Class Initialized
INFO - 2021-07-12 10:49:47 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:47 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:47 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:47 --> URI Class Initialized
INFO - 2021-07-12 10:49:47 --> Router Class Initialized
INFO - 2021-07-12 10:49:47 --> Output Class Initialized
INFO - 2021-07-12 10:49:47 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:47 --> Input Class Initialized
INFO - 2021-07-12 10:49:47 --> Language Class Initialized
INFO - 2021-07-12 10:49:47 --> Language Class Initialized
INFO - 2021-07-12 10:49:47 --> Config Class Initialized
INFO - 2021-07-12 10:49:47 --> Loader Class Initialized
INFO - 2021-07-12 10:49:48 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:48 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:48 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:48 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:48 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:48 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:48 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:48 --> Total execution time: 0.1170
INFO - 2021-07-12 10:49:50 --> Config Class Initialized
INFO - 2021-07-12 10:49:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:50 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:50 --> URI Class Initialized
INFO - 2021-07-12 10:49:50 --> Router Class Initialized
INFO - 2021-07-12 10:49:50 --> Output Class Initialized
INFO - 2021-07-12 10:49:50 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:50 --> Input Class Initialized
INFO - 2021-07-12 10:49:50 --> Language Class Initialized
INFO - 2021-07-12 10:49:50 --> Language Class Initialized
INFO - 2021-07-12 10:49:50 --> Config Class Initialized
INFO - 2021-07-12 10:49:50 --> Loader Class Initialized
INFO - 2021-07-12 10:49:50 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:50 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:50 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:50 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:50 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:50 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:50 --> Total execution time: 0.1294
INFO - 2021-07-12 10:49:51 --> Config Class Initialized
INFO - 2021-07-12 10:49:51 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:51 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:51 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:51 --> URI Class Initialized
INFO - 2021-07-12 10:49:51 --> Router Class Initialized
INFO - 2021-07-12 10:49:51 --> Output Class Initialized
INFO - 2021-07-12 10:49:51 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:51 --> Input Class Initialized
INFO - 2021-07-12 10:49:51 --> Language Class Initialized
INFO - 2021-07-12 10:49:51 --> Language Class Initialized
INFO - 2021-07-12 10:49:51 --> Config Class Initialized
INFO - 2021-07-12 10:49:51 --> Loader Class Initialized
INFO - 2021-07-12 10:49:51 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:51 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:51 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:51 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:51 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:51 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:51 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:51 --> Total execution time: 0.1137
INFO - 2021-07-12 10:49:53 --> Config Class Initialized
INFO - 2021-07-12 10:49:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:53 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:53 --> URI Class Initialized
INFO - 2021-07-12 10:49:53 --> Router Class Initialized
INFO - 2021-07-12 10:49:53 --> Output Class Initialized
INFO - 2021-07-12 10:49:53 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:53 --> Input Class Initialized
INFO - 2021-07-12 10:49:53 --> Language Class Initialized
INFO - 2021-07-12 10:49:53 --> Language Class Initialized
INFO - 2021-07-12 10:49:53 --> Config Class Initialized
INFO - 2021-07-12 10:49:53 --> Loader Class Initialized
INFO - 2021-07-12 10:49:53 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:53 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:53 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:53 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:53 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:53 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:53 --> Total execution time: 0.1175
INFO - 2021-07-12 10:49:54 --> Config Class Initialized
INFO - 2021-07-12 10:49:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:54 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:54 --> URI Class Initialized
INFO - 2021-07-12 10:49:54 --> Router Class Initialized
INFO - 2021-07-12 10:49:54 --> Output Class Initialized
INFO - 2021-07-12 10:49:54 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:54 --> Input Class Initialized
INFO - 2021-07-12 10:49:54 --> Language Class Initialized
INFO - 2021-07-12 10:49:54 --> Language Class Initialized
INFO - 2021-07-12 10:49:54 --> Config Class Initialized
INFO - 2021-07-12 10:49:54 --> Loader Class Initialized
INFO - 2021-07-12 10:49:54 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:54 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:54 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:54 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:54 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:55 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:55 --> Total execution time: 0.1312
INFO - 2021-07-12 10:49:56 --> Config Class Initialized
INFO - 2021-07-12 10:49:56 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:56 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:56 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:56 --> URI Class Initialized
INFO - 2021-07-12 10:49:56 --> Router Class Initialized
INFO - 2021-07-12 10:49:56 --> Output Class Initialized
INFO - 2021-07-12 10:49:56 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:56 --> Input Class Initialized
INFO - 2021-07-12 10:49:56 --> Language Class Initialized
INFO - 2021-07-12 10:49:56 --> Language Class Initialized
INFO - 2021-07-12 10:49:56 --> Config Class Initialized
INFO - 2021-07-12 10:49:56 --> Loader Class Initialized
INFO - 2021-07-12 10:49:56 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:56 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:56 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:56 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:56 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:56 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:56 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:56 --> Total execution time: 0.1154
INFO - 2021-07-12 10:49:59 --> Config Class Initialized
INFO - 2021-07-12 10:49:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:49:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:49:59 --> Utf8 Class Initialized
INFO - 2021-07-12 10:49:59 --> URI Class Initialized
INFO - 2021-07-12 10:49:59 --> Router Class Initialized
INFO - 2021-07-12 10:49:59 --> Output Class Initialized
INFO - 2021-07-12 10:49:59 --> Security Class Initialized
DEBUG - 2021-07-12 10:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:49:59 --> Input Class Initialized
INFO - 2021-07-12 10:49:59 --> Language Class Initialized
INFO - 2021-07-12 10:49:59 --> Language Class Initialized
INFO - 2021-07-12 10:49:59 --> Config Class Initialized
INFO - 2021-07-12 10:49:59 --> Loader Class Initialized
INFO - 2021-07-12 10:49:59 --> Helper loaded: url_helper
INFO - 2021-07-12 10:49:59 --> Helper loaded: file_helper
INFO - 2021-07-12 10:49:59 --> Helper loaded: form_helper
INFO - 2021-07-12 10:49:59 --> Helper loaded: my_helper
INFO - 2021-07-12 10:49:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:49:59 --> Controller Class Initialized
DEBUG - 2021-07-12 10:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:49:59 --> Final output sent to browser
DEBUG - 2021-07-12 10:49:59 --> Total execution time: 0.1389
INFO - 2021-07-12 10:50:01 --> Config Class Initialized
INFO - 2021-07-12 10:50:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:01 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:01 --> URI Class Initialized
INFO - 2021-07-12 10:50:01 --> Router Class Initialized
INFO - 2021-07-12 10:50:01 --> Output Class Initialized
INFO - 2021-07-12 10:50:01 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:01 --> Input Class Initialized
INFO - 2021-07-12 10:50:01 --> Language Class Initialized
INFO - 2021-07-12 10:50:01 --> Language Class Initialized
INFO - 2021-07-12 10:50:01 --> Config Class Initialized
INFO - 2021-07-12 10:50:01 --> Loader Class Initialized
INFO - 2021-07-12 10:50:01 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:01 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:01 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:01 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:01 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:01 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:01 --> Total execution time: 0.1333
INFO - 2021-07-12 10:50:02 --> Config Class Initialized
INFO - 2021-07-12 10:50:02 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:02 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:02 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:02 --> URI Class Initialized
INFO - 2021-07-12 10:50:02 --> Router Class Initialized
INFO - 2021-07-12 10:50:02 --> Output Class Initialized
INFO - 2021-07-12 10:50:02 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:02 --> Input Class Initialized
INFO - 2021-07-12 10:50:02 --> Language Class Initialized
INFO - 2021-07-12 10:50:02 --> Language Class Initialized
INFO - 2021-07-12 10:50:02 --> Config Class Initialized
INFO - 2021-07-12 10:50:02 --> Loader Class Initialized
INFO - 2021-07-12 10:50:02 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:02 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:02 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:02 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:02 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:02 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:02 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:02 --> Total execution time: 0.1179
INFO - 2021-07-12 10:50:04 --> Config Class Initialized
INFO - 2021-07-12 10:50:04 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:04 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:04 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:04 --> URI Class Initialized
INFO - 2021-07-12 10:50:04 --> Router Class Initialized
INFO - 2021-07-12 10:50:04 --> Output Class Initialized
INFO - 2021-07-12 10:50:04 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:04 --> Input Class Initialized
INFO - 2021-07-12 10:50:04 --> Language Class Initialized
INFO - 2021-07-12 10:50:04 --> Language Class Initialized
INFO - 2021-07-12 10:50:04 --> Config Class Initialized
INFO - 2021-07-12 10:50:04 --> Loader Class Initialized
INFO - 2021-07-12 10:50:04 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:04 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:04 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:04 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:04 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:04 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:04 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:04 --> Total execution time: 0.1335
INFO - 2021-07-12 10:50:06 --> Config Class Initialized
INFO - 2021-07-12 10:50:06 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:06 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:06 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:06 --> URI Class Initialized
INFO - 2021-07-12 10:50:06 --> Router Class Initialized
INFO - 2021-07-12 10:50:06 --> Output Class Initialized
INFO - 2021-07-12 10:50:06 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:06 --> Input Class Initialized
INFO - 2021-07-12 10:50:06 --> Language Class Initialized
INFO - 2021-07-12 10:50:06 --> Language Class Initialized
INFO - 2021-07-12 10:50:06 --> Config Class Initialized
INFO - 2021-07-12 10:50:06 --> Loader Class Initialized
INFO - 2021-07-12 10:50:06 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:06 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:06 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:06 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:06 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:06 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:06 --> Total execution time: 0.1320
INFO - 2021-07-12 10:50:08 --> Config Class Initialized
INFO - 2021-07-12 10:50:08 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:08 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:08 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:08 --> URI Class Initialized
INFO - 2021-07-12 10:50:08 --> Router Class Initialized
INFO - 2021-07-12 10:50:08 --> Output Class Initialized
INFO - 2021-07-12 10:50:08 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:08 --> Input Class Initialized
INFO - 2021-07-12 10:50:08 --> Language Class Initialized
INFO - 2021-07-12 10:50:08 --> Language Class Initialized
INFO - 2021-07-12 10:50:08 --> Config Class Initialized
INFO - 2021-07-12 10:50:08 --> Loader Class Initialized
INFO - 2021-07-12 10:50:08 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:08 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:08 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:08 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:08 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:08 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:08 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:08 --> Total execution time: 0.1218
INFO - 2021-07-12 10:50:09 --> Config Class Initialized
INFO - 2021-07-12 10:50:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:09 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:09 --> URI Class Initialized
INFO - 2021-07-12 10:50:09 --> Router Class Initialized
INFO - 2021-07-12 10:50:09 --> Output Class Initialized
INFO - 2021-07-12 10:50:09 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:09 --> Input Class Initialized
INFO - 2021-07-12 10:50:09 --> Language Class Initialized
INFO - 2021-07-12 10:50:09 --> Language Class Initialized
INFO - 2021-07-12 10:50:09 --> Config Class Initialized
INFO - 2021-07-12 10:50:09 --> Loader Class Initialized
INFO - 2021-07-12 10:50:09 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:09 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:09 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:09 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:09 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:09 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:09 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:09 --> Total execution time: 0.1344
INFO - 2021-07-12 10:50:12 --> Config Class Initialized
INFO - 2021-07-12 10:50:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:12 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:12 --> URI Class Initialized
INFO - 2021-07-12 10:50:12 --> Router Class Initialized
INFO - 2021-07-12 10:50:12 --> Output Class Initialized
INFO - 2021-07-12 10:50:12 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:12 --> Input Class Initialized
INFO - 2021-07-12 10:50:12 --> Language Class Initialized
INFO - 2021-07-12 10:50:12 --> Language Class Initialized
INFO - 2021-07-12 10:50:12 --> Config Class Initialized
INFO - 2021-07-12 10:50:12 --> Loader Class Initialized
INFO - 2021-07-12 10:50:12 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:12 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:12 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:12 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:12 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:12 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:12 --> Total execution time: 0.1317
INFO - 2021-07-12 10:50:13 --> Config Class Initialized
INFO - 2021-07-12 10:50:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:13 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:13 --> URI Class Initialized
INFO - 2021-07-12 10:50:13 --> Router Class Initialized
INFO - 2021-07-12 10:50:13 --> Output Class Initialized
INFO - 2021-07-12 10:50:13 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:13 --> Input Class Initialized
INFO - 2021-07-12 10:50:13 --> Language Class Initialized
INFO - 2021-07-12 10:50:13 --> Language Class Initialized
INFO - 2021-07-12 10:50:13 --> Config Class Initialized
INFO - 2021-07-12 10:50:13 --> Loader Class Initialized
INFO - 2021-07-12 10:50:13 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:13 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:13 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:13 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:13 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:13 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:13 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:13 --> Total execution time: 0.1155
INFO - 2021-07-12 10:50:26 --> Config Class Initialized
INFO - 2021-07-12 10:50:26 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:26 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:26 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:26 --> URI Class Initialized
INFO - 2021-07-12 10:50:26 --> Router Class Initialized
INFO - 2021-07-12 10:50:26 --> Output Class Initialized
INFO - 2021-07-12 10:50:26 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:26 --> Input Class Initialized
INFO - 2021-07-12 10:50:26 --> Language Class Initialized
INFO - 2021-07-12 10:50:26 --> Language Class Initialized
INFO - 2021-07-12 10:50:26 --> Config Class Initialized
INFO - 2021-07-12 10:50:26 --> Loader Class Initialized
INFO - 2021-07-12 10:50:26 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:26 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:26 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:26 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:26 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:26 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:26 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:26 --> Total execution time: 0.1305
INFO - 2021-07-12 10:50:29 --> Config Class Initialized
INFO - 2021-07-12 10:50:29 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:29 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:29 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:29 --> URI Class Initialized
INFO - 2021-07-12 10:50:29 --> Router Class Initialized
INFO - 2021-07-12 10:50:29 --> Output Class Initialized
INFO - 2021-07-12 10:50:29 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:29 --> Input Class Initialized
INFO - 2021-07-12 10:50:29 --> Language Class Initialized
INFO - 2021-07-12 10:50:29 --> Language Class Initialized
INFO - 2021-07-12 10:50:29 --> Config Class Initialized
INFO - 2021-07-12 10:50:29 --> Loader Class Initialized
INFO - 2021-07-12 10:50:29 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:29 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:29 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:29 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:29 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:29 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:29 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:29 --> Total execution time: 0.1321
INFO - 2021-07-12 10:50:31 --> Config Class Initialized
INFO - 2021-07-12 10:50:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:31 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:31 --> URI Class Initialized
INFO - 2021-07-12 10:50:31 --> Router Class Initialized
INFO - 2021-07-12 10:50:31 --> Output Class Initialized
INFO - 2021-07-12 10:50:31 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:31 --> Input Class Initialized
INFO - 2021-07-12 10:50:31 --> Language Class Initialized
INFO - 2021-07-12 10:50:31 --> Language Class Initialized
INFO - 2021-07-12 10:50:31 --> Config Class Initialized
INFO - 2021-07-12 10:50:31 --> Loader Class Initialized
INFO - 2021-07-12 10:50:31 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:31 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:31 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:31 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:31 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:31 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:32 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:32 --> Total execution time: 0.1162
INFO - 2021-07-12 10:50:34 --> Config Class Initialized
INFO - 2021-07-12 10:50:34 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:34 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:34 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:34 --> URI Class Initialized
INFO - 2021-07-12 10:50:34 --> Router Class Initialized
INFO - 2021-07-12 10:50:34 --> Output Class Initialized
INFO - 2021-07-12 10:50:34 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:34 --> Input Class Initialized
INFO - 2021-07-12 10:50:34 --> Language Class Initialized
INFO - 2021-07-12 10:50:34 --> Language Class Initialized
INFO - 2021-07-12 10:50:34 --> Config Class Initialized
INFO - 2021-07-12 10:50:34 --> Loader Class Initialized
INFO - 2021-07-12 10:50:34 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:34 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:34 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:34 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:34 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:34 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:34 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:34 --> Total execution time: 0.1319
INFO - 2021-07-12 10:50:35 --> Config Class Initialized
INFO - 2021-07-12 10:50:35 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:35 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:35 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:35 --> URI Class Initialized
INFO - 2021-07-12 10:50:35 --> Router Class Initialized
INFO - 2021-07-12 10:50:35 --> Output Class Initialized
INFO - 2021-07-12 10:50:35 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:35 --> Input Class Initialized
INFO - 2021-07-12 10:50:35 --> Language Class Initialized
INFO - 2021-07-12 10:50:35 --> Language Class Initialized
INFO - 2021-07-12 10:50:35 --> Config Class Initialized
INFO - 2021-07-12 10:50:35 --> Loader Class Initialized
INFO - 2021-07-12 10:50:35 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:35 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:35 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:35 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:35 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:35 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:35 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:35 --> Total execution time: 0.1292
INFO - 2021-07-12 10:50:37 --> Config Class Initialized
INFO - 2021-07-12 10:50:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:37 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:37 --> URI Class Initialized
INFO - 2021-07-12 10:50:37 --> Router Class Initialized
INFO - 2021-07-12 10:50:37 --> Output Class Initialized
INFO - 2021-07-12 10:50:37 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:37 --> Input Class Initialized
INFO - 2021-07-12 10:50:37 --> Language Class Initialized
INFO - 2021-07-12 10:50:37 --> Language Class Initialized
INFO - 2021-07-12 10:50:37 --> Config Class Initialized
INFO - 2021-07-12 10:50:37 --> Loader Class Initialized
INFO - 2021-07-12 10:50:37 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:37 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:37 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:37 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:37 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:37 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:37 --> Total execution time: 0.1162
INFO - 2021-07-12 10:50:40 --> Config Class Initialized
INFO - 2021-07-12 10:50:40 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:40 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:40 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:40 --> URI Class Initialized
INFO - 2021-07-12 10:50:40 --> Router Class Initialized
INFO - 2021-07-12 10:50:40 --> Output Class Initialized
INFO - 2021-07-12 10:50:40 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:40 --> Input Class Initialized
INFO - 2021-07-12 10:50:40 --> Language Class Initialized
INFO - 2021-07-12 10:50:40 --> Language Class Initialized
INFO - 2021-07-12 10:50:40 --> Config Class Initialized
INFO - 2021-07-12 10:50:40 --> Loader Class Initialized
INFO - 2021-07-12 10:50:40 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:40 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:40 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:40 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:40 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:40 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:40 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:40 --> Total execution time: 0.1295
INFO - 2021-07-12 10:50:41 --> Config Class Initialized
INFO - 2021-07-12 10:50:41 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:50:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:50:41 --> Utf8 Class Initialized
INFO - 2021-07-12 10:50:41 --> URI Class Initialized
INFO - 2021-07-12 10:50:41 --> Router Class Initialized
INFO - 2021-07-12 10:50:41 --> Output Class Initialized
INFO - 2021-07-12 10:50:41 --> Security Class Initialized
DEBUG - 2021-07-12 10:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:50:41 --> Input Class Initialized
INFO - 2021-07-12 10:50:41 --> Language Class Initialized
INFO - 2021-07-12 10:50:41 --> Language Class Initialized
INFO - 2021-07-12 10:50:41 --> Config Class Initialized
INFO - 2021-07-12 10:50:41 --> Loader Class Initialized
INFO - 2021-07-12 10:50:41 --> Helper loaded: url_helper
INFO - 2021-07-12 10:50:41 --> Helper loaded: file_helper
INFO - 2021-07-12 10:50:41 --> Helper loaded: form_helper
INFO - 2021-07-12 10:50:41 --> Helper loaded: my_helper
INFO - 2021-07-12 10:50:41 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:50:41 --> Controller Class Initialized
DEBUG - 2021-07-12 10:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 10:50:42 --> Final output sent to browser
DEBUG - 2021-07-12 10:50:42 --> Total execution time: 0.1263
INFO - 2021-07-12 10:56:38 --> Config Class Initialized
INFO - 2021-07-12 10:56:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:56:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:56:38 --> Utf8 Class Initialized
INFO - 2021-07-12 10:56:38 --> URI Class Initialized
INFO - 2021-07-12 10:56:38 --> Router Class Initialized
INFO - 2021-07-12 10:56:38 --> Output Class Initialized
INFO - 2021-07-12 10:56:38 --> Security Class Initialized
DEBUG - 2021-07-12 10:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:56:38 --> Input Class Initialized
INFO - 2021-07-12 10:56:38 --> Language Class Initialized
INFO - 2021-07-12 10:56:38 --> Language Class Initialized
INFO - 2021-07-12 10:56:38 --> Config Class Initialized
INFO - 2021-07-12 10:56:38 --> Loader Class Initialized
INFO - 2021-07-12 10:56:38 --> Helper loaded: url_helper
INFO - 2021-07-12 10:56:38 --> Helper loaded: file_helper
INFO - 2021-07-12 10:56:38 --> Helper loaded: form_helper
INFO - 2021-07-12 10:56:38 --> Helper loaded: my_helper
INFO - 2021-07-12 10:56:38 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:56:38 --> Controller Class Initialized
INFO - 2021-07-12 10:56:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 10:56:38 --> Config Class Initialized
INFO - 2021-07-12 10:56:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:56:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:56:38 --> Utf8 Class Initialized
INFO - 2021-07-12 10:56:38 --> URI Class Initialized
INFO - 2021-07-12 10:56:38 --> Router Class Initialized
INFO - 2021-07-12 10:56:38 --> Output Class Initialized
INFO - 2021-07-12 10:56:38 --> Security Class Initialized
DEBUG - 2021-07-12 10:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:56:38 --> Input Class Initialized
INFO - 2021-07-12 10:56:38 --> Language Class Initialized
INFO - 2021-07-12 10:56:38 --> Language Class Initialized
INFO - 2021-07-12 10:56:38 --> Config Class Initialized
INFO - 2021-07-12 10:56:38 --> Loader Class Initialized
INFO - 2021-07-12 10:56:38 --> Helper loaded: url_helper
INFO - 2021-07-12 10:56:38 --> Helper loaded: file_helper
INFO - 2021-07-12 10:56:38 --> Helper loaded: form_helper
INFO - 2021-07-12 10:56:38 --> Helper loaded: my_helper
INFO - 2021-07-12 10:56:38 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:56:38 --> Controller Class Initialized
DEBUG - 2021-07-12 10:56:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 10:56:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:56:38 --> Final output sent to browser
DEBUG - 2021-07-12 10:56:38 --> Total execution time: 0.0591
INFO - 2021-07-12 10:56:57 --> Config Class Initialized
INFO - 2021-07-12 10:56:57 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:56:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:56:57 --> Utf8 Class Initialized
INFO - 2021-07-12 10:56:57 --> URI Class Initialized
INFO - 2021-07-12 10:56:57 --> Router Class Initialized
INFO - 2021-07-12 10:56:57 --> Output Class Initialized
INFO - 2021-07-12 10:56:57 --> Security Class Initialized
DEBUG - 2021-07-12 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:56:57 --> Input Class Initialized
INFO - 2021-07-12 10:56:57 --> Language Class Initialized
INFO - 2021-07-12 10:56:57 --> Language Class Initialized
INFO - 2021-07-12 10:56:57 --> Config Class Initialized
INFO - 2021-07-12 10:56:57 --> Loader Class Initialized
INFO - 2021-07-12 10:56:57 --> Helper loaded: url_helper
INFO - 2021-07-12 10:56:57 --> Helper loaded: file_helper
INFO - 2021-07-12 10:56:57 --> Helper loaded: form_helper
INFO - 2021-07-12 10:56:57 --> Helper loaded: my_helper
INFO - 2021-07-12 10:56:57 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:56:57 --> Controller Class Initialized
INFO - 2021-07-12 10:56:57 --> Helper loaded: cookie_helper
INFO - 2021-07-12 10:56:57 --> Final output sent to browser
DEBUG - 2021-07-12 10:56:57 --> Total execution time: 0.0439
INFO - 2021-07-12 10:56:59 --> Config Class Initialized
INFO - 2021-07-12 10:56:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:56:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:56:59 --> Utf8 Class Initialized
INFO - 2021-07-12 10:56:59 --> URI Class Initialized
INFO - 2021-07-12 10:56:59 --> Router Class Initialized
INFO - 2021-07-12 10:56:59 --> Output Class Initialized
INFO - 2021-07-12 10:56:59 --> Security Class Initialized
DEBUG - 2021-07-12 10:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:56:59 --> Input Class Initialized
INFO - 2021-07-12 10:56:59 --> Language Class Initialized
INFO - 2021-07-12 10:56:59 --> Language Class Initialized
INFO - 2021-07-12 10:56:59 --> Config Class Initialized
INFO - 2021-07-12 10:56:59 --> Loader Class Initialized
INFO - 2021-07-12 10:56:59 --> Helper loaded: url_helper
INFO - 2021-07-12 10:56:59 --> Helper loaded: file_helper
INFO - 2021-07-12 10:56:59 --> Helper loaded: form_helper
INFO - 2021-07-12 10:56:59 --> Helper loaded: my_helper
INFO - 2021-07-12 10:56:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:56:59 --> Controller Class Initialized
DEBUG - 2021-07-12 10:57:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 10:57:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:57:00 --> Final output sent to browser
DEBUG - 2021-07-12 10:57:00 --> Total execution time: 0.7382
INFO - 2021-07-12 10:57:34 --> Config Class Initialized
INFO - 2021-07-12 10:57:34 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:57:34 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:57:34 --> Utf8 Class Initialized
INFO - 2021-07-12 10:57:34 --> URI Class Initialized
INFO - 2021-07-12 10:57:34 --> Router Class Initialized
INFO - 2021-07-12 10:57:34 --> Output Class Initialized
INFO - 2021-07-12 10:57:34 --> Security Class Initialized
DEBUG - 2021-07-12 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:57:34 --> Input Class Initialized
INFO - 2021-07-12 10:57:34 --> Language Class Initialized
INFO - 2021-07-12 10:57:34 --> Language Class Initialized
INFO - 2021-07-12 10:57:34 --> Config Class Initialized
INFO - 2021-07-12 10:57:34 --> Loader Class Initialized
INFO - 2021-07-12 10:57:34 --> Helper loaded: url_helper
INFO - 2021-07-12 10:57:34 --> Helper loaded: file_helper
INFO - 2021-07-12 10:57:34 --> Helper loaded: form_helper
INFO - 2021-07-12 10:57:34 --> Helper loaded: my_helper
INFO - 2021-07-12 10:57:34 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:57:34 --> Controller Class Initialized
DEBUG - 2021-07-12 10:57:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-12 10:57:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:57:34 --> Final output sent to browser
DEBUG - 2021-07-12 10:57:34 --> Total execution time: 0.0515
INFO - 2021-07-12 10:57:34 --> Config Class Initialized
INFO - 2021-07-12 10:57:34 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:57:34 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:57:34 --> Utf8 Class Initialized
INFO - 2021-07-12 10:57:34 --> URI Class Initialized
INFO - 2021-07-12 10:57:34 --> Router Class Initialized
INFO - 2021-07-12 10:57:34 --> Output Class Initialized
INFO - 2021-07-12 10:57:34 --> Security Class Initialized
DEBUG - 2021-07-12 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:57:34 --> Input Class Initialized
INFO - 2021-07-12 10:57:34 --> Language Class Initialized
INFO - 2021-07-12 10:57:34 --> Language Class Initialized
INFO - 2021-07-12 10:57:34 --> Config Class Initialized
INFO - 2021-07-12 10:57:34 --> Loader Class Initialized
INFO - 2021-07-12 10:57:34 --> Helper loaded: url_helper
INFO - 2021-07-12 10:57:34 --> Helper loaded: file_helper
INFO - 2021-07-12 10:57:34 --> Helper loaded: form_helper
INFO - 2021-07-12 10:57:34 --> Helper loaded: my_helper
INFO - 2021-07-12 10:57:34 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:57:34 --> Controller Class Initialized
INFO - 2021-07-12 10:57:36 --> Config Class Initialized
INFO - 2021-07-12 10:57:36 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:57:36 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:57:36 --> Utf8 Class Initialized
INFO - 2021-07-12 10:57:36 --> URI Class Initialized
INFO - 2021-07-12 10:57:36 --> Router Class Initialized
INFO - 2021-07-12 10:57:36 --> Output Class Initialized
INFO - 2021-07-12 10:57:36 --> Security Class Initialized
DEBUG - 2021-07-12 10:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:57:36 --> Input Class Initialized
INFO - 2021-07-12 10:57:36 --> Language Class Initialized
INFO - 2021-07-12 10:57:36 --> Language Class Initialized
INFO - 2021-07-12 10:57:36 --> Config Class Initialized
INFO - 2021-07-12 10:57:36 --> Loader Class Initialized
INFO - 2021-07-12 10:57:36 --> Helper loaded: url_helper
INFO - 2021-07-12 10:57:36 --> Helper loaded: file_helper
INFO - 2021-07-12 10:57:36 --> Helper loaded: form_helper
INFO - 2021-07-12 10:57:36 --> Helper loaded: my_helper
INFO - 2021-07-12 10:57:36 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:57:36 --> Controller Class Initialized
INFO - 2021-07-12 10:57:37 --> Config Class Initialized
INFO - 2021-07-12 10:57:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:57:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:57:37 --> Utf8 Class Initialized
INFO - 2021-07-12 10:57:37 --> URI Class Initialized
INFO - 2021-07-12 10:57:37 --> Router Class Initialized
INFO - 2021-07-12 10:57:37 --> Output Class Initialized
INFO - 2021-07-12 10:57:37 --> Security Class Initialized
DEBUG - 2021-07-12 10:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:57:37 --> Input Class Initialized
INFO - 2021-07-12 10:57:37 --> Language Class Initialized
INFO - 2021-07-12 10:57:37 --> Language Class Initialized
INFO - 2021-07-12 10:57:37 --> Config Class Initialized
INFO - 2021-07-12 10:57:37 --> Loader Class Initialized
INFO - 2021-07-12 10:57:37 --> Helper loaded: url_helper
INFO - 2021-07-12 10:57:37 --> Helper loaded: file_helper
INFO - 2021-07-12 10:57:37 --> Helper loaded: form_helper
INFO - 2021-07-12 10:57:37 --> Helper loaded: my_helper
INFO - 2021-07-12 10:57:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:57:37 --> Controller Class Initialized
ERROR - 2021-07-12 10:57:37 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-12 10:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-12 10:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:57:37 --> Final output sent to browser
DEBUG - 2021-07-12 10:57:37 --> Total execution time: 0.0615
INFO - 2021-07-12 10:59:32 --> Config Class Initialized
INFO - 2021-07-12 10:59:32 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:32 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:32 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:32 --> URI Class Initialized
INFO - 2021-07-12 10:59:32 --> Router Class Initialized
INFO - 2021-07-12 10:59:32 --> Output Class Initialized
INFO - 2021-07-12 10:59:32 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:32 --> Input Class Initialized
INFO - 2021-07-12 10:59:32 --> Language Class Initialized
INFO - 2021-07-12 10:59:32 --> Language Class Initialized
INFO - 2021-07-12 10:59:32 --> Config Class Initialized
INFO - 2021-07-12 10:59:32 --> Loader Class Initialized
INFO - 2021-07-12 10:59:32 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:32 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:32 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:32 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:32 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:32 --> Controller Class Initialized
INFO - 2021-07-12 10:59:33 --> Upload Class Initialized
INFO - 2021-07-12 10:59:33 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-12 10:59:33 --> The upload path does not appear to be valid.
INFO - 2021-07-12 10:59:33 --> Config Class Initialized
INFO - 2021-07-12 10:59:33 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:33 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:33 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:33 --> URI Class Initialized
INFO - 2021-07-12 10:59:33 --> Router Class Initialized
INFO - 2021-07-12 10:59:33 --> Output Class Initialized
INFO - 2021-07-12 10:59:33 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:33 --> Input Class Initialized
INFO - 2021-07-12 10:59:33 --> Language Class Initialized
INFO - 2021-07-12 10:59:33 --> Language Class Initialized
INFO - 2021-07-12 10:59:33 --> Config Class Initialized
INFO - 2021-07-12 10:59:33 --> Loader Class Initialized
INFO - 2021-07-12 10:59:33 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:33 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:33 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:33 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:33 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:33 --> Controller Class Initialized
DEBUG - 2021-07-12 10:59:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-12 10:59:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:59:33 --> Final output sent to browser
DEBUG - 2021-07-12 10:59:33 --> Total execution time: 0.0640
INFO - 2021-07-12 10:59:33 --> Config Class Initialized
INFO - 2021-07-12 10:59:33 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:33 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:33 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:33 --> URI Class Initialized
INFO - 2021-07-12 10:59:33 --> Router Class Initialized
INFO - 2021-07-12 10:59:33 --> Output Class Initialized
INFO - 2021-07-12 10:59:33 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:33 --> Input Class Initialized
INFO - 2021-07-12 10:59:33 --> Language Class Initialized
INFO - 2021-07-12 10:59:33 --> Language Class Initialized
INFO - 2021-07-12 10:59:33 --> Config Class Initialized
INFO - 2021-07-12 10:59:33 --> Loader Class Initialized
INFO - 2021-07-12 10:59:33 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:33 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:33 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:33 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:33 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:33 --> Controller Class Initialized
INFO - 2021-07-12 10:59:47 --> Config Class Initialized
INFO - 2021-07-12 10:59:47 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:47 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:47 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:47 --> URI Class Initialized
INFO - 2021-07-12 10:59:47 --> Router Class Initialized
INFO - 2021-07-12 10:59:47 --> Output Class Initialized
INFO - 2021-07-12 10:59:47 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:47 --> Input Class Initialized
INFO - 2021-07-12 10:59:47 --> Language Class Initialized
INFO - 2021-07-12 10:59:47 --> Language Class Initialized
INFO - 2021-07-12 10:59:47 --> Config Class Initialized
INFO - 2021-07-12 10:59:47 --> Loader Class Initialized
INFO - 2021-07-12 10:59:47 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:47 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:47 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:47 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:47 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:47 --> Controller Class Initialized
INFO - 2021-07-12 10:59:48 --> Config Class Initialized
INFO - 2021-07-12 10:59:48 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:48 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:48 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:48 --> URI Class Initialized
INFO - 2021-07-12 10:59:48 --> Router Class Initialized
INFO - 2021-07-12 10:59:48 --> Output Class Initialized
INFO - 2021-07-12 10:59:48 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:48 --> Input Class Initialized
INFO - 2021-07-12 10:59:48 --> Language Class Initialized
INFO - 2021-07-12 10:59:48 --> Language Class Initialized
INFO - 2021-07-12 10:59:48 --> Config Class Initialized
INFO - 2021-07-12 10:59:48 --> Loader Class Initialized
INFO - 2021-07-12 10:59:48 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:48 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:48 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:48 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:48 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:48 --> Controller Class Initialized
INFO - 2021-07-12 10:59:50 --> Config Class Initialized
INFO - 2021-07-12 10:59:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:50 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:50 --> URI Class Initialized
INFO - 2021-07-12 10:59:50 --> Router Class Initialized
INFO - 2021-07-12 10:59:50 --> Output Class Initialized
INFO - 2021-07-12 10:59:50 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:50 --> Input Class Initialized
INFO - 2021-07-12 10:59:50 --> Language Class Initialized
INFO - 2021-07-12 10:59:50 --> Language Class Initialized
INFO - 2021-07-12 10:59:50 --> Config Class Initialized
INFO - 2021-07-12 10:59:50 --> Loader Class Initialized
INFO - 2021-07-12 10:59:50 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:50 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:50 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:50 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:50 --> Controller Class Initialized
ERROR - 2021-07-12 10:59:50 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-12 10:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-12 10:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:59:50 --> Final output sent to browser
DEBUG - 2021-07-12 10:59:50 --> Total execution time: 0.0449
INFO - 2021-07-12 10:59:53 --> Config Class Initialized
INFO - 2021-07-12 10:59:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:53 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:53 --> URI Class Initialized
INFO - 2021-07-12 10:59:53 --> Router Class Initialized
INFO - 2021-07-12 10:59:53 --> Output Class Initialized
INFO - 2021-07-12 10:59:53 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:53 --> Input Class Initialized
INFO - 2021-07-12 10:59:53 --> Language Class Initialized
INFO - 2021-07-12 10:59:53 --> Language Class Initialized
INFO - 2021-07-12 10:59:53 --> Config Class Initialized
INFO - 2021-07-12 10:59:53 --> Loader Class Initialized
INFO - 2021-07-12 10:59:53 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:53 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:53 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:53 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:53 --> Controller Class Initialized
DEBUG - 2021-07-12 10:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-12 10:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:59:53 --> Final output sent to browser
DEBUG - 2021-07-12 10:59:53 --> Total execution time: 0.0427
INFO - 2021-07-12 10:59:53 --> Config Class Initialized
INFO - 2021-07-12 10:59:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:53 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:53 --> URI Class Initialized
INFO - 2021-07-12 10:59:53 --> Router Class Initialized
INFO - 2021-07-12 10:59:53 --> Output Class Initialized
INFO - 2021-07-12 10:59:53 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:53 --> Input Class Initialized
INFO - 2021-07-12 10:59:53 --> Language Class Initialized
INFO - 2021-07-12 10:59:53 --> Language Class Initialized
INFO - 2021-07-12 10:59:53 --> Config Class Initialized
INFO - 2021-07-12 10:59:53 --> Loader Class Initialized
INFO - 2021-07-12 10:59:53 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:53 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:53 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:53 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:53 --> Controller Class Initialized
INFO - 2021-07-12 10:59:56 --> Config Class Initialized
INFO - 2021-07-12 10:59:56 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:56 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:56 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:56 --> URI Class Initialized
INFO - 2021-07-12 10:59:56 --> Router Class Initialized
INFO - 2021-07-12 10:59:56 --> Output Class Initialized
INFO - 2021-07-12 10:59:56 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:56 --> Input Class Initialized
INFO - 2021-07-12 10:59:56 --> Language Class Initialized
INFO - 2021-07-12 10:59:56 --> Language Class Initialized
INFO - 2021-07-12 10:59:56 --> Config Class Initialized
INFO - 2021-07-12 10:59:56 --> Loader Class Initialized
INFO - 2021-07-12 10:59:56 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:56 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:56 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:56 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:56 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:56 --> Controller Class Initialized
INFO - 2021-07-12 10:59:57 --> Config Class Initialized
INFO - 2021-07-12 10:59:57 --> Hooks Class Initialized
DEBUG - 2021-07-12 10:59:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 10:59:57 --> Utf8 Class Initialized
INFO - 2021-07-12 10:59:57 --> URI Class Initialized
INFO - 2021-07-12 10:59:57 --> Router Class Initialized
INFO - 2021-07-12 10:59:57 --> Output Class Initialized
INFO - 2021-07-12 10:59:57 --> Security Class Initialized
DEBUG - 2021-07-12 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 10:59:57 --> Input Class Initialized
INFO - 2021-07-12 10:59:57 --> Language Class Initialized
INFO - 2021-07-12 10:59:57 --> Language Class Initialized
INFO - 2021-07-12 10:59:57 --> Config Class Initialized
INFO - 2021-07-12 10:59:57 --> Loader Class Initialized
INFO - 2021-07-12 10:59:57 --> Helper loaded: url_helper
INFO - 2021-07-12 10:59:57 --> Helper loaded: file_helper
INFO - 2021-07-12 10:59:57 --> Helper loaded: form_helper
INFO - 2021-07-12 10:59:57 --> Helper loaded: my_helper
INFO - 2021-07-12 10:59:57 --> Database Driver Class Initialized
DEBUG - 2021-07-12 10:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 10:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 10:59:57 --> Controller Class Initialized
ERROR - 2021-07-12 10:59:57 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-12 10:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-12 10:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 10:59:57 --> Final output sent to browser
DEBUG - 2021-07-12 10:59:57 --> Total execution time: 0.0452
INFO - 2021-07-12 11:00:27 --> Config Class Initialized
INFO - 2021-07-12 11:00:27 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:00:27 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:00:27 --> Utf8 Class Initialized
INFO - 2021-07-12 11:00:27 --> URI Class Initialized
INFO - 2021-07-12 11:00:27 --> Router Class Initialized
INFO - 2021-07-12 11:00:27 --> Output Class Initialized
INFO - 2021-07-12 11:00:27 --> Security Class Initialized
DEBUG - 2021-07-12 11:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:00:27 --> Input Class Initialized
INFO - 2021-07-12 11:00:27 --> Language Class Initialized
INFO - 2021-07-12 11:00:27 --> Language Class Initialized
INFO - 2021-07-12 11:00:27 --> Config Class Initialized
INFO - 2021-07-12 11:00:27 --> Loader Class Initialized
INFO - 2021-07-12 11:00:27 --> Helper loaded: url_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: file_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: form_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: my_helper
INFO - 2021-07-12 11:00:27 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:00:27 --> Controller Class Initialized
INFO - 2021-07-12 11:00:27 --> Upload Class Initialized
INFO - 2021-07-12 11:00:27 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-12 11:00:27 --> The upload path does not appear to be valid.
INFO - 2021-07-12 11:00:27 --> Config Class Initialized
INFO - 2021-07-12 11:00:27 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:00:27 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:00:27 --> Utf8 Class Initialized
INFO - 2021-07-12 11:00:27 --> URI Class Initialized
INFO - 2021-07-12 11:00:27 --> Router Class Initialized
INFO - 2021-07-12 11:00:27 --> Output Class Initialized
INFO - 2021-07-12 11:00:27 --> Security Class Initialized
DEBUG - 2021-07-12 11:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:00:27 --> Input Class Initialized
INFO - 2021-07-12 11:00:27 --> Language Class Initialized
INFO - 2021-07-12 11:00:27 --> Language Class Initialized
INFO - 2021-07-12 11:00:27 --> Config Class Initialized
INFO - 2021-07-12 11:00:27 --> Loader Class Initialized
INFO - 2021-07-12 11:00:27 --> Helper loaded: url_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: file_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: form_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: my_helper
INFO - 2021-07-12 11:00:27 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:00:27 --> Controller Class Initialized
DEBUG - 2021-07-12 11:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-12 11:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 11:00:27 --> Final output sent to browser
DEBUG - 2021-07-12 11:00:27 --> Total execution time: 0.0656
INFO - 2021-07-12 11:00:27 --> Config Class Initialized
INFO - 2021-07-12 11:00:27 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:00:27 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:00:27 --> Utf8 Class Initialized
INFO - 2021-07-12 11:00:27 --> URI Class Initialized
INFO - 2021-07-12 11:00:27 --> Router Class Initialized
INFO - 2021-07-12 11:00:27 --> Output Class Initialized
INFO - 2021-07-12 11:00:27 --> Security Class Initialized
DEBUG - 2021-07-12 11:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:00:27 --> Input Class Initialized
INFO - 2021-07-12 11:00:27 --> Language Class Initialized
INFO - 2021-07-12 11:00:27 --> Language Class Initialized
INFO - 2021-07-12 11:00:27 --> Config Class Initialized
INFO - 2021-07-12 11:00:27 --> Loader Class Initialized
INFO - 2021-07-12 11:00:27 --> Helper loaded: url_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: file_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: form_helper
INFO - 2021-07-12 11:00:27 --> Helper loaded: my_helper
INFO - 2021-07-12 11:00:27 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:00:27 --> Controller Class Initialized
INFO - 2021-07-12 08:59:04 --> Config Class Initialized
INFO - 2021-07-12 08:59:04 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:59:04 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:59:04 --> Utf8 Class Initialized
INFO - 2021-07-12 08:59:04 --> URI Class Initialized
DEBUG - 2021-07-12 08:59:04 --> No URI present. Default controller set.
INFO - 2021-07-12 08:59:04 --> Router Class Initialized
INFO - 2021-07-12 08:59:04 --> Output Class Initialized
INFO - 2021-07-12 08:59:04 --> Security Class Initialized
DEBUG - 2021-07-12 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:59:04 --> Input Class Initialized
INFO - 2021-07-12 08:59:04 --> Language Class Initialized
INFO - 2021-07-12 08:59:05 --> Language Class Initialized
INFO - 2021-07-12 08:59:05 --> Config Class Initialized
INFO - 2021-07-12 08:59:05 --> Loader Class Initialized
INFO - 2021-07-12 08:59:05 --> Helper loaded: url_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: file_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: form_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: my_helper
INFO - 2021-07-12 08:59:05 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:59:05 --> Controller Class Initialized
INFO - 2021-07-12 08:59:05 --> Config Class Initialized
INFO - 2021-07-12 08:59:05 --> Hooks Class Initialized
INFO - 2021-07-12 08:59:05 --> Config Class Initialized
INFO - 2021-07-12 08:59:05 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:59:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:59:05 --> Utf8 Class Initialized
INFO - 2021-07-12 08:59:05 --> URI Class Initialized
DEBUG - 2021-07-12 08:59:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:59:05 --> Utf8 Class Initialized
INFO - 2021-07-12 08:59:05 --> URI Class Initialized
DEBUG - 2021-07-12 08:59:05 --> No URI present. Default controller set.
INFO - 2021-07-12 08:59:05 --> Router Class Initialized
INFO - 2021-07-12 08:59:05 --> Output Class Initialized
INFO - 2021-07-12 08:59:05 --> Router Class Initialized
INFO - 2021-07-12 08:59:05 --> Security Class Initialized
INFO - 2021-07-12 08:59:05 --> Output Class Initialized
DEBUG - 2021-07-12 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:59:05 --> Security Class Initialized
INFO - 2021-07-12 08:59:05 --> Input Class Initialized
INFO - 2021-07-12 08:59:05 --> Language Class Initialized
DEBUG - 2021-07-12 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:59:05 --> Input Class Initialized
INFO - 2021-07-12 08:59:05 --> Language Class Initialized
INFO - 2021-07-12 08:59:05 --> Language Class Initialized
INFO - 2021-07-12 08:59:05 --> Config Class Initialized
INFO - 2021-07-12 08:59:05 --> Loader Class Initialized
INFO - 2021-07-12 08:59:05 --> Helper loaded: url_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: file_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: form_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: my_helper
INFO - 2021-07-12 08:59:05 --> Language Class Initialized
INFO - 2021-07-12 08:59:05 --> Config Class Initialized
INFO - 2021-07-12 08:59:05 --> Loader Class Initialized
INFO - 2021-07-12 08:59:05 --> Database Driver Class Initialized
INFO - 2021-07-12 08:59:05 --> Helper loaded: url_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: file_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: form_helper
DEBUG - 2021-07-12 08:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:59:05 --> Controller Class Initialized
INFO - 2021-07-12 08:59:05 --> Helper loaded: my_helper
INFO - 2021-07-12 08:59:05 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:59:05 --> Controller Class Initialized
DEBUG - 2021-07-12 08:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 08:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:59:05 --> Final output sent to browser
DEBUG - 2021-07-12 08:59:05 --> Total execution time: 0.0888
INFO - 2021-07-12 08:59:05 --> Config Class Initialized
INFO - 2021-07-12 08:59:05 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:59:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:59:05 --> Utf8 Class Initialized
INFO - 2021-07-12 08:59:05 --> URI Class Initialized
INFO - 2021-07-12 08:59:05 --> Router Class Initialized
INFO - 2021-07-12 08:59:05 --> Output Class Initialized
INFO - 2021-07-12 08:59:05 --> Security Class Initialized
DEBUG - 2021-07-12 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:59:05 --> Input Class Initialized
INFO - 2021-07-12 08:59:05 --> Language Class Initialized
INFO - 2021-07-12 08:59:05 --> Language Class Initialized
INFO - 2021-07-12 08:59:05 --> Config Class Initialized
INFO - 2021-07-12 08:59:05 --> Loader Class Initialized
INFO - 2021-07-12 08:59:05 --> Helper loaded: url_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: file_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: form_helper
INFO - 2021-07-12 08:59:05 --> Helper loaded: my_helper
INFO - 2021-07-12 08:59:05 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:59:05 --> Controller Class Initialized
DEBUG - 2021-07-12 08:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 08:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:59:05 --> Final output sent to browser
DEBUG - 2021-07-12 08:59:05 --> Total execution time: 0.0452
INFO - 2021-07-12 08:59:15 --> Config Class Initialized
INFO - 2021-07-12 08:59:15 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:59:15 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:59:15 --> Utf8 Class Initialized
INFO - 2021-07-12 08:59:15 --> URI Class Initialized
INFO - 2021-07-12 08:59:15 --> Router Class Initialized
INFO - 2021-07-12 08:59:15 --> Output Class Initialized
INFO - 2021-07-12 08:59:15 --> Security Class Initialized
DEBUG - 2021-07-12 08:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:59:15 --> Input Class Initialized
INFO - 2021-07-12 08:59:15 --> Language Class Initialized
INFO - 2021-07-12 08:59:15 --> Language Class Initialized
INFO - 2021-07-12 08:59:15 --> Config Class Initialized
INFO - 2021-07-12 08:59:15 --> Loader Class Initialized
INFO - 2021-07-12 08:59:15 --> Helper loaded: url_helper
INFO - 2021-07-12 08:59:15 --> Helper loaded: file_helper
INFO - 2021-07-12 08:59:15 --> Helper loaded: form_helper
INFO - 2021-07-12 08:59:15 --> Helper loaded: my_helper
INFO - 2021-07-12 08:59:15 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:59:15 --> Controller Class Initialized
INFO - 2021-07-12 08:59:15 --> Helper loaded: cookie_helper
INFO - 2021-07-12 08:59:15 --> Final output sent to browser
DEBUG - 2021-07-12 08:59:15 --> Total execution time: 0.0668
INFO - 2021-07-12 08:59:15 --> Config Class Initialized
INFO - 2021-07-12 08:59:15 --> Hooks Class Initialized
DEBUG - 2021-07-12 08:59:15 --> UTF-8 Support Enabled
INFO - 2021-07-12 08:59:15 --> Utf8 Class Initialized
INFO - 2021-07-12 08:59:15 --> URI Class Initialized
INFO - 2021-07-12 08:59:15 --> Router Class Initialized
INFO - 2021-07-12 08:59:15 --> Output Class Initialized
INFO - 2021-07-12 08:59:15 --> Security Class Initialized
DEBUG - 2021-07-12 08:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 08:59:15 --> Input Class Initialized
INFO - 2021-07-12 08:59:15 --> Language Class Initialized
INFO - 2021-07-12 08:59:15 --> Language Class Initialized
INFO - 2021-07-12 08:59:15 --> Config Class Initialized
INFO - 2021-07-12 08:59:15 --> Loader Class Initialized
INFO - 2021-07-12 08:59:15 --> Helper loaded: url_helper
INFO - 2021-07-12 08:59:15 --> Helper loaded: file_helper
INFO - 2021-07-12 08:59:15 --> Helper loaded: form_helper
INFO - 2021-07-12 08:59:15 --> Helper loaded: my_helper
INFO - 2021-07-12 08:59:15 --> Database Driver Class Initialized
DEBUG - 2021-07-12 08:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 08:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 08:59:15 --> Controller Class Initialized
DEBUG - 2021-07-12 08:59:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 08:59:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 08:59:16 --> Final output sent to browser
DEBUG - 2021-07-12 08:59:16 --> Total execution time: 0.6301
INFO - 2021-07-12 09:00:04 --> Config Class Initialized
INFO - 2021-07-12 09:00:04 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:04 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:04 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:04 --> URI Class Initialized
INFO - 2021-07-12 09:00:04 --> Router Class Initialized
INFO - 2021-07-12 09:00:04 --> Output Class Initialized
INFO - 2021-07-12 09:00:04 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:04 --> Input Class Initialized
INFO - 2021-07-12 09:00:04 --> Language Class Initialized
INFO - 2021-07-12 09:00:04 --> Language Class Initialized
INFO - 2021-07-12 09:00:04 --> Config Class Initialized
INFO - 2021-07-12 09:00:04 --> Loader Class Initialized
INFO - 2021-07-12 09:00:04 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:04 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:04 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:04 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:04 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:04 --> Controller Class Initialized
DEBUG - 2021-07-12 09:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-07-12 09:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:00:04 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:04 --> Total execution time: 0.1013
INFO - 2021-07-12 09:00:04 --> Config Class Initialized
INFO - 2021-07-12 09:00:04 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:04 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:04 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:04 --> URI Class Initialized
INFO - 2021-07-12 09:00:04 --> Router Class Initialized
INFO - 2021-07-12 09:00:04 --> Output Class Initialized
INFO - 2021-07-12 09:00:04 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:04 --> Input Class Initialized
INFO - 2021-07-12 09:00:04 --> Language Class Initialized
INFO - 2021-07-12 09:00:04 --> Language Class Initialized
INFO - 2021-07-12 09:00:04 --> Config Class Initialized
INFO - 2021-07-12 09:00:04 --> Loader Class Initialized
INFO - 2021-07-12 09:00:04 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:04 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:04 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:04 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:04 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:04 --> Controller Class Initialized
DEBUG - 2021-07-12 09:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-07-12 09:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:00:04 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:04 --> Total execution time: 0.0536
INFO - 2021-07-12 09:00:24 --> Config Class Initialized
INFO - 2021-07-12 09:00:24 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:24 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:24 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:24 --> URI Class Initialized
INFO - 2021-07-12 09:00:24 --> Router Class Initialized
INFO - 2021-07-12 09:00:24 --> Output Class Initialized
INFO - 2021-07-12 09:00:24 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:24 --> Input Class Initialized
INFO - 2021-07-12 09:00:24 --> Language Class Initialized
INFO - 2021-07-12 09:00:24 --> Language Class Initialized
INFO - 2021-07-12 09:00:24 --> Config Class Initialized
INFO - 2021-07-12 09:00:24 --> Loader Class Initialized
INFO - 2021-07-12 09:00:24 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:24 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:24 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:24 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:24 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:24 --> Controller Class Initialized
INFO - 2021-07-12 09:00:24 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:24 --> Total execution time: 0.2281
INFO - 2021-07-12 09:00:26 --> Config Class Initialized
INFO - 2021-07-12 09:00:26 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:26 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:26 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:26 --> URI Class Initialized
INFO - 2021-07-12 09:00:26 --> Router Class Initialized
INFO - 2021-07-12 09:00:26 --> Output Class Initialized
INFO - 2021-07-12 09:00:26 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:26 --> Input Class Initialized
INFO - 2021-07-12 09:00:26 --> Language Class Initialized
INFO - 2021-07-12 09:00:26 --> Language Class Initialized
INFO - 2021-07-12 09:00:26 --> Config Class Initialized
INFO - 2021-07-12 09:00:26 --> Loader Class Initialized
INFO - 2021-07-12 09:00:26 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:26 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:26 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:26 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:26 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:26 --> Controller Class Initialized
INFO - 2021-07-12 09:00:26 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:26 --> Total execution time: 0.1659
INFO - 2021-07-12 09:00:27 --> Config Class Initialized
INFO - 2021-07-12 09:00:27 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:27 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:27 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:27 --> URI Class Initialized
INFO - 2021-07-12 09:00:27 --> Router Class Initialized
INFO - 2021-07-12 09:00:27 --> Output Class Initialized
INFO - 2021-07-12 09:00:27 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:27 --> Input Class Initialized
INFO - 2021-07-12 09:00:27 --> Language Class Initialized
INFO - 2021-07-12 09:00:27 --> Language Class Initialized
INFO - 2021-07-12 09:00:27 --> Config Class Initialized
INFO - 2021-07-12 09:00:27 --> Loader Class Initialized
INFO - 2021-07-12 09:00:27 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:27 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:27 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:27 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:27 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:27 --> Controller Class Initialized
INFO - 2021-07-12 09:00:28 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:28 --> Total execution time: 0.1407
INFO - 2021-07-12 09:00:29 --> Config Class Initialized
INFO - 2021-07-12 09:00:29 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:29 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:29 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:29 --> URI Class Initialized
INFO - 2021-07-12 09:00:29 --> Router Class Initialized
INFO - 2021-07-12 09:00:29 --> Output Class Initialized
INFO - 2021-07-12 09:00:29 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:29 --> Input Class Initialized
INFO - 2021-07-12 09:00:29 --> Language Class Initialized
INFO - 2021-07-12 09:00:29 --> Language Class Initialized
INFO - 2021-07-12 09:00:29 --> Config Class Initialized
INFO - 2021-07-12 09:00:29 --> Loader Class Initialized
INFO - 2021-07-12 09:00:29 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:29 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:29 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:29 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:29 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:29 --> Controller Class Initialized
INFO - 2021-07-12 09:00:29 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:29 --> Total execution time: 0.1584
INFO - 2021-07-12 09:00:31 --> Config Class Initialized
INFO - 2021-07-12 09:00:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:31 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:31 --> URI Class Initialized
INFO - 2021-07-12 09:00:31 --> Router Class Initialized
INFO - 2021-07-12 09:00:31 --> Output Class Initialized
INFO - 2021-07-12 09:00:31 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:31 --> Input Class Initialized
INFO - 2021-07-12 09:00:31 --> Language Class Initialized
INFO - 2021-07-12 09:00:31 --> Language Class Initialized
INFO - 2021-07-12 09:00:31 --> Config Class Initialized
INFO - 2021-07-12 09:00:31 --> Loader Class Initialized
INFO - 2021-07-12 09:00:31 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:31 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:31 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:31 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:31 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:31 --> Controller Class Initialized
INFO - 2021-07-12 09:00:31 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:31 --> Total execution time: 0.1433
INFO - 2021-07-12 09:00:32 --> Config Class Initialized
INFO - 2021-07-12 09:00:32 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:32 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:32 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:32 --> URI Class Initialized
INFO - 2021-07-12 09:00:32 --> Router Class Initialized
INFO - 2021-07-12 09:00:32 --> Output Class Initialized
INFO - 2021-07-12 09:00:32 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:32 --> Input Class Initialized
INFO - 2021-07-12 09:00:32 --> Language Class Initialized
INFO - 2021-07-12 09:00:32 --> Language Class Initialized
INFO - 2021-07-12 09:00:32 --> Config Class Initialized
INFO - 2021-07-12 09:00:32 --> Loader Class Initialized
INFO - 2021-07-12 09:00:32 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:32 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:32 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:32 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:32 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:32 --> Controller Class Initialized
INFO - 2021-07-12 09:00:33 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:33 --> Total execution time: 0.1341
INFO - 2021-07-12 09:00:37 --> Config Class Initialized
INFO - 2021-07-12 09:00:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:37 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:37 --> URI Class Initialized
INFO - 2021-07-12 09:00:37 --> Router Class Initialized
INFO - 2021-07-12 09:00:37 --> Output Class Initialized
INFO - 2021-07-12 09:00:37 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:37 --> Input Class Initialized
INFO - 2021-07-12 09:00:37 --> Language Class Initialized
INFO - 2021-07-12 09:00:37 --> Language Class Initialized
INFO - 2021-07-12 09:00:37 --> Config Class Initialized
INFO - 2021-07-12 09:00:37 --> Loader Class Initialized
INFO - 2021-07-12 09:00:37 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:37 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:37 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:37 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:37 --> Controller Class Initialized
INFO - 2021-07-12 09:00:37 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:37 --> Total execution time: 0.1424
INFO - 2021-07-12 09:00:39 --> Config Class Initialized
INFO - 2021-07-12 09:00:39 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:39 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:39 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:39 --> URI Class Initialized
INFO - 2021-07-12 09:00:39 --> Router Class Initialized
INFO - 2021-07-12 09:00:39 --> Output Class Initialized
INFO - 2021-07-12 09:00:39 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:39 --> Input Class Initialized
INFO - 2021-07-12 09:00:39 --> Language Class Initialized
INFO - 2021-07-12 09:00:39 --> Language Class Initialized
INFO - 2021-07-12 09:00:39 --> Config Class Initialized
INFO - 2021-07-12 09:00:39 --> Loader Class Initialized
INFO - 2021-07-12 09:00:39 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:39 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:39 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:39 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:39 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:39 --> Controller Class Initialized
INFO - 2021-07-12 09:00:39 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:39 --> Total execution time: 0.1422
INFO - 2021-07-12 09:00:42 --> Config Class Initialized
INFO - 2021-07-12 09:00:42 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:42 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:42 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:42 --> URI Class Initialized
INFO - 2021-07-12 09:00:42 --> Router Class Initialized
INFO - 2021-07-12 09:00:42 --> Output Class Initialized
INFO - 2021-07-12 09:00:42 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:42 --> Input Class Initialized
INFO - 2021-07-12 09:00:42 --> Language Class Initialized
INFO - 2021-07-12 09:00:42 --> Language Class Initialized
INFO - 2021-07-12 09:00:42 --> Config Class Initialized
INFO - 2021-07-12 09:00:42 --> Loader Class Initialized
INFO - 2021-07-12 09:00:42 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:42 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:42 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:42 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:42 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:42 --> Controller Class Initialized
INFO - 2021-07-12 09:00:42 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:42 --> Total execution time: 0.7529
INFO - 2021-07-12 09:00:44 --> Config Class Initialized
INFO - 2021-07-12 09:00:44 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:44 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:44 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:44 --> URI Class Initialized
INFO - 2021-07-12 09:00:44 --> Router Class Initialized
INFO - 2021-07-12 09:00:44 --> Output Class Initialized
INFO - 2021-07-12 09:00:44 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:44 --> Input Class Initialized
INFO - 2021-07-12 09:00:44 --> Language Class Initialized
INFO - 2021-07-12 09:00:44 --> Language Class Initialized
INFO - 2021-07-12 09:00:44 --> Config Class Initialized
INFO - 2021-07-12 09:00:44 --> Loader Class Initialized
INFO - 2021-07-12 09:00:44 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:44 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:44 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:44 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:44 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:44 --> Controller Class Initialized
INFO - 2021-07-12 09:00:45 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:45 --> Total execution time: 0.8303
INFO - 2021-07-12 09:00:47 --> Config Class Initialized
INFO - 2021-07-12 09:00:47 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:47 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:47 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:47 --> URI Class Initialized
INFO - 2021-07-12 09:00:47 --> Router Class Initialized
INFO - 2021-07-12 09:00:47 --> Output Class Initialized
INFO - 2021-07-12 09:00:47 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:47 --> Input Class Initialized
INFO - 2021-07-12 09:00:47 --> Language Class Initialized
INFO - 2021-07-12 09:00:47 --> Language Class Initialized
INFO - 2021-07-12 09:00:47 --> Config Class Initialized
INFO - 2021-07-12 09:00:47 --> Loader Class Initialized
INFO - 2021-07-12 09:00:47 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:47 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:47 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:47 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:47 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:47 --> Controller Class Initialized
INFO - 2021-07-12 09:00:50 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:50 --> Total execution time: 2.6268
INFO - 2021-07-12 09:00:50 --> Config Class Initialized
INFO - 2021-07-12 09:00:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:50 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:50 --> URI Class Initialized
INFO - 2021-07-12 09:00:50 --> Router Class Initialized
INFO - 2021-07-12 09:00:50 --> Output Class Initialized
INFO - 2021-07-12 09:00:50 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:50 --> Input Class Initialized
INFO - 2021-07-12 09:00:50 --> Language Class Initialized
INFO - 2021-07-12 09:00:50 --> Language Class Initialized
INFO - 2021-07-12 09:00:50 --> Config Class Initialized
INFO - 2021-07-12 09:00:50 --> Loader Class Initialized
INFO - 2021-07-12 09:00:50 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:50 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:50 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:50 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:50 --> Controller Class Initialized
INFO - 2021-07-12 09:00:50 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:50 --> Total execution time: 0.5251
INFO - 2021-07-12 09:00:55 --> Config Class Initialized
INFO - 2021-07-12 09:00:55 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:55 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:55 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:55 --> URI Class Initialized
INFO - 2021-07-12 09:00:55 --> Router Class Initialized
INFO - 2021-07-12 09:00:55 --> Output Class Initialized
INFO - 2021-07-12 09:00:55 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:55 --> Input Class Initialized
INFO - 2021-07-12 09:00:55 --> Language Class Initialized
INFO - 2021-07-12 09:00:55 --> Language Class Initialized
INFO - 2021-07-12 09:00:55 --> Config Class Initialized
INFO - 2021-07-12 09:00:55 --> Loader Class Initialized
INFO - 2021-07-12 09:00:55 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:55 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:55 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:55 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:55 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:55 --> Controller Class Initialized
INFO - 2021-07-12 09:00:55 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:55 --> Total execution time: 0.1855
INFO - 2021-07-12 09:00:59 --> Config Class Initialized
INFO - 2021-07-12 09:00:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:00:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:00:59 --> Utf8 Class Initialized
INFO - 2021-07-12 09:00:59 --> URI Class Initialized
INFO - 2021-07-12 09:00:59 --> Router Class Initialized
INFO - 2021-07-12 09:00:59 --> Output Class Initialized
INFO - 2021-07-12 09:00:59 --> Security Class Initialized
DEBUG - 2021-07-12 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:00:59 --> Input Class Initialized
INFO - 2021-07-12 09:00:59 --> Language Class Initialized
INFO - 2021-07-12 09:00:59 --> Language Class Initialized
INFO - 2021-07-12 09:00:59 --> Config Class Initialized
INFO - 2021-07-12 09:00:59 --> Loader Class Initialized
INFO - 2021-07-12 09:00:59 --> Helper loaded: url_helper
INFO - 2021-07-12 09:00:59 --> Helper loaded: file_helper
INFO - 2021-07-12 09:00:59 --> Helper loaded: form_helper
INFO - 2021-07-12 09:00:59 --> Helper loaded: my_helper
INFO - 2021-07-12 09:00:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:00:59 --> Controller Class Initialized
INFO - 2021-07-12 09:00:59 --> Final output sent to browser
DEBUG - 2021-07-12 09:00:59 --> Total execution time: 0.1289
INFO - 2021-07-12 09:01:01 --> Config Class Initialized
INFO - 2021-07-12 09:01:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:01 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:01 --> URI Class Initialized
INFO - 2021-07-12 09:01:01 --> Router Class Initialized
INFO - 2021-07-12 09:01:01 --> Output Class Initialized
INFO - 2021-07-12 09:01:01 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:01 --> Input Class Initialized
INFO - 2021-07-12 09:01:01 --> Language Class Initialized
INFO - 2021-07-12 09:01:01 --> Language Class Initialized
INFO - 2021-07-12 09:01:01 --> Config Class Initialized
INFO - 2021-07-12 09:01:01 --> Loader Class Initialized
INFO - 2021-07-12 09:01:01 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:01 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:01 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:01 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:01 --> Controller Class Initialized
INFO - 2021-07-12 09:01:01 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:01 --> Total execution time: 0.1412
INFO - 2021-07-12 09:01:04 --> Config Class Initialized
INFO - 2021-07-12 09:01:04 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:04 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:04 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:04 --> URI Class Initialized
INFO - 2021-07-12 09:01:04 --> Router Class Initialized
INFO - 2021-07-12 09:01:04 --> Output Class Initialized
INFO - 2021-07-12 09:01:04 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:04 --> Input Class Initialized
INFO - 2021-07-12 09:01:04 --> Language Class Initialized
INFO - 2021-07-12 09:01:04 --> Language Class Initialized
INFO - 2021-07-12 09:01:04 --> Config Class Initialized
INFO - 2021-07-12 09:01:04 --> Loader Class Initialized
INFO - 2021-07-12 09:01:04 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:04 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:04 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:04 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:04 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:04 --> Controller Class Initialized
INFO - 2021-07-12 09:01:04 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:04 --> Total execution time: 0.1406
INFO - 2021-07-12 09:01:07 --> Config Class Initialized
INFO - 2021-07-12 09:01:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:07 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:07 --> URI Class Initialized
INFO - 2021-07-12 09:01:07 --> Router Class Initialized
INFO - 2021-07-12 09:01:07 --> Output Class Initialized
INFO - 2021-07-12 09:01:07 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:07 --> Input Class Initialized
INFO - 2021-07-12 09:01:07 --> Language Class Initialized
INFO - 2021-07-12 09:01:07 --> Language Class Initialized
INFO - 2021-07-12 09:01:07 --> Config Class Initialized
INFO - 2021-07-12 09:01:07 --> Loader Class Initialized
INFO - 2021-07-12 09:01:07 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:07 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:07 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:07 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:07 --> Controller Class Initialized
INFO - 2021-07-12 09:01:07 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:07 --> Total execution time: 0.1350
INFO - 2021-07-12 09:01:09 --> Config Class Initialized
INFO - 2021-07-12 09:01:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:09 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:09 --> URI Class Initialized
INFO - 2021-07-12 09:01:09 --> Router Class Initialized
INFO - 2021-07-12 09:01:09 --> Output Class Initialized
INFO - 2021-07-12 09:01:09 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:09 --> Input Class Initialized
INFO - 2021-07-12 09:01:09 --> Language Class Initialized
INFO - 2021-07-12 09:01:09 --> Language Class Initialized
INFO - 2021-07-12 09:01:09 --> Config Class Initialized
INFO - 2021-07-12 09:01:09 --> Loader Class Initialized
INFO - 2021-07-12 09:01:09 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:09 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:09 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:09 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:09 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:09 --> Controller Class Initialized
INFO - 2021-07-12 09:01:09 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:09 --> Total execution time: 0.1425
INFO - 2021-07-12 09:01:15 --> Config Class Initialized
INFO - 2021-07-12 09:01:15 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:15 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:15 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:15 --> URI Class Initialized
INFO - 2021-07-12 09:01:15 --> Router Class Initialized
INFO - 2021-07-12 09:01:15 --> Output Class Initialized
INFO - 2021-07-12 09:01:15 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:15 --> Input Class Initialized
INFO - 2021-07-12 09:01:15 --> Language Class Initialized
INFO - 2021-07-12 09:01:15 --> Language Class Initialized
INFO - 2021-07-12 09:01:15 --> Config Class Initialized
INFO - 2021-07-12 09:01:15 --> Loader Class Initialized
INFO - 2021-07-12 09:01:15 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:15 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:15 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:15 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:15 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:15 --> Controller Class Initialized
INFO - 2021-07-12 09:01:16 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:16 --> Total execution time: 0.1365
INFO - 2021-07-12 09:01:20 --> Config Class Initialized
INFO - 2021-07-12 09:01:20 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:20 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:20 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:20 --> URI Class Initialized
INFO - 2021-07-12 09:01:20 --> Router Class Initialized
INFO - 2021-07-12 09:01:20 --> Output Class Initialized
INFO - 2021-07-12 09:01:20 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:20 --> Input Class Initialized
INFO - 2021-07-12 09:01:20 --> Language Class Initialized
INFO - 2021-07-12 09:01:20 --> Language Class Initialized
INFO - 2021-07-12 09:01:20 --> Config Class Initialized
INFO - 2021-07-12 09:01:20 --> Loader Class Initialized
INFO - 2021-07-12 09:01:20 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:20 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:20 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:20 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:20 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:20 --> Controller Class Initialized
INFO - 2021-07-12 09:01:21 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:21 --> Total execution time: 0.1401
INFO - 2021-07-12 09:01:22 --> Config Class Initialized
INFO - 2021-07-12 09:01:22 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:22 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:22 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:22 --> URI Class Initialized
INFO - 2021-07-12 09:01:22 --> Router Class Initialized
INFO - 2021-07-12 09:01:22 --> Output Class Initialized
INFO - 2021-07-12 09:01:22 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:22 --> Input Class Initialized
INFO - 2021-07-12 09:01:22 --> Language Class Initialized
INFO - 2021-07-12 09:01:22 --> Language Class Initialized
INFO - 2021-07-12 09:01:22 --> Config Class Initialized
INFO - 2021-07-12 09:01:22 --> Loader Class Initialized
INFO - 2021-07-12 09:01:22 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:22 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:22 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:22 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:22 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:22 --> Controller Class Initialized
INFO - 2021-07-12 09:01:22 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:22 --> Total execution time: 0.1321
INFO - 2021-07-12 09:01:24 --> Config Class Initialized
INFO - 2021-07-12 09:01:24 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:24 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:24 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:24 --> URI Class Initialized
INFO - 2021-07-12 09:01:24 --> Router Class Initialized
INFO - 2021-07-12 09:01:24 --> Output Class Initialized
INFO - 2021-07-12 09:01:24 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:24 --> Input Class Initialized
INFO - 2021-07-12 09:01:24 --> Language Class Initialized
INFO - 2021-07-12 09:01:24 --> Language Class Initialized
INFO - 2021-07-12 09:01:24 --> Config Class Initialized
INFO - 2021-07-12 09:01:24 --> Loader Class Initialized
INFO - 2021-07-12 09:01:24 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:24 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:24 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:24 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:24 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:24 --> Controller Class Initialized
INFO - 2021-07-12 09:01:24 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:24 --> Total execution time: 0.1341
INFO - 2021-07-12 09:01:26 --> Config Class Initialized
INFO - 2021-07-12 09:01:26 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:26 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:26 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:26 --> URI Class Initialized
INFO - 2021-07-12 09:01:26 --> Router Class Initialized
INFO - 2021-07-12 09:01:26 --> Output Class Initialized
INFO - 2021-07-12 09:01:26 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:26 --> Input Class Initialized
INFO - 2021-07-12 09:01:26 --> Language Class Initialized
INFO - 2021-07-12 09:01:26 --> Language Class Initialized
INFO - 2021-07-12 09:01:26 --> Config Class Initialized
INFO - 2021-07-12 09:01:26 --> Loader Class Initialized
INFO - 2021-07-12 09:01:26 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:26 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:26 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:26 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:26 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:26 --> Controller Class Initialized
INFO - 2021-07-12 09:01:26 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:26 --> Total execution time: 0.1334
INFO - 2021-07-12 09:01:27 --> Config Class Initialized
INFO - 2021-07-12 09:01:27 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:27 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:27 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:27 --> URI Class Initialized
INFO - 2021-07-12 09:01:27 --> Router Class Initialized
INFO - 2021-07-12 09:01:27 --> Output Class Initialized
INFO - 2021-07-12 09:01:27 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:27 --> Input Class Initialized
INFO - 2021-07-12 09:01:27 --> Language Class Initialized
INFO - 2021-07-12 09:01:27 --> Language Class Initialized
INFO - 2021-07-12 09:01:27 --> Config Class Initialized
INFO - 2021-07-12 09:01:27 --> Loader Class Initialized
INFO - 2021-07-12 09:01:27 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:27 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:27 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:27 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:27 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:27 --> Controller Class Initialized
INFO - 2021-07-12 09:01:27 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:27 --> Total execution time: 0.1763
INFO - 2021-07-12 09:01:32 --> Config Class Initialized
INFO - 2021-07-12 09:01:32 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:32 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:32 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:32 --> URI Class Initialized
INFO - 2021-07-12 09:01:32 --> Router Class Initialized
INFO - 2021-07-12 09:01:32 --> Output Class Initialized
INFO - 2021-07-12 09:01:32 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:32 --> Input Class Initialized
INFO - 2021-07-12 09:01:32 --> Language Class Initialized
INFO - 2021-07-12 09:01:32 --> Language Class Initialized
INFO - 2021-07-12 09:01:32 --> Config Class Initialized
INFO - 2021-07-12 09:01:32 --> Loader Class Initialized
INFO - 2021-07-12 09:01:32 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:32 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:32 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:32 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:32 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:32 --> Controller Class Initialized
DEBUG - 2021-07-12 09:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-07-12 09:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:01:32 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:32 --> Total execution time: 0.0737
INFO - 2021-07-12 09:01:49 --> Config Class Initialized
INFO - 2021-07-12 09:01:49 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:49 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:49 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:49 --> URI Class Initialized
INFO - 2021-07-12 09:01:49 --> Router Class Initialized
INFO - 2021-07-12 09:01:49 --> Output Class Initialized
INFO - 2021-07-12 09:01:49 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:49 --> Input Class Initialized
INFO - 2021-07-12 09:01:49 --> Language Class Initialized
INFO - 2021-07-12 09:01:49 --> Language Class Initialized
INFO - 2021-07-12 09:01:49 --> Config Class Initialized
INFO - 2021-07-12 09:01:49 --> Loader Class Initialized
INFO - 2021-07-12 09:01:49 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:49 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:49 --> Controller Class Initialized
DEBUG - 2021-07-12 09:01:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-07-12 09:01:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:01:49 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:49 --> Total execution time: 0.0641
INFO - 2021-07-12 09:01:49 --> Config Class Initialized
INFO - 2021-07-12 09:01:49 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:49 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:49 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:49 --> URI Class Initialized
INFO - 2021-07-12 09:01:49 --> Router Class Initialized
INFO - 2021-07-12 09:01:49 --> Output Class Initialized
INFO - 2021-07-12 09:01:49 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:49 --> Input Class Initialized
INFO - 2021-07-12 09:01:49 --> Language Class Initialized
INFO - 2021-07-12 09:01:49 --> Language Class Initialized
INFO - 2021-07-12 09:01:49 --> Config Class Initialized
INFO - 2021-07-12 09:01:49 --> Loader Class Initialized
INFO - 2021-07-12 09:01:49 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:49 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:49 --> Controller Class Initialized
DEBUG - 2021-07-12 09:01:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-07-12 09:01:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:01:49 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:49 --> Total execution time: 0.0565
INFO - 2021-07-12 09:01:49 --> Config Class Initialized
INFO - 2021-07-12 09:01:49 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:01:49 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:01:49 --> Utf8 Class Initialized
INFO - 2021-07-12 09:01:49 --> URI Class Initialized
INFO - 2021-07-12 09:01:49 --> Router Class Initialized
INFO - 2021-07-12 09:01:49 --> Output Class Initialized
INFO - 2021-07-12 09:01:49 --> Security Class Initialized
DEBUG - 2021-07-12 09:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:01:49 --> Input Class Initialized
INFO - 2021-07-12 09:01:49 --> Language Class Initialized
INFO - 2021-07-12 09:01:49 --> Language Class Initialized
INFO - 2021-07-12 09:01:49 --> Config Class Initialized
INFO - 2021-07-12 09:01:49 --> Loader Class Initialized
INFO - 2021-07-12 09:01:49 --> Helper loaded: url_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: file_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: form_helper
INFO - 2021-07-12 09:01:49 --> Helper loaded: my_helper
INFO - 2021-07-12 09:01:49 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:01:49 --> Controller Class Initialized
DEBUG - 2021-07-12 09:01:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-07-12 09:01:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:01:49 --> Final output sent to browser
DEBUG - 2021-07-12 09:01:49 --> Total execution time: 0.0431
INFO - 2021-07-12 09:03:29 --> Config Class Initialized
INFO - 2021-07-12 09:03:29 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:29 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:29 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:29 --> URI Class Initialized
INFO - 2021-07-12 09:03:29 --> Router Class Initialized
INFO - 2021-07-12 09:03:29 --> Output Class Initialized
INFO - 2021-07-12 09:03:29 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:29 --> Input Class Initialized
INFO - 2021-07-12 09:03:29 --> Language Class Initialized
INFO - 2021-07-12 09:03:29 --> Language Class Initialized
INFO - 2021-07-12 09:03:29 --> Config Class Initialized
INFO - 2021-07-12 09:03:29 --> Loader Class Initialized
INFO - 2021-07-12 09:03:29 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:29 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:29 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:29 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:29 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:29 --> Controller Class Initialized
INFO - 2021-07-12 09:03:29 --> Config Class Initialized
INFO - 2021-07-12 09:03:29 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:29 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:29 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:29 --> URI Class Initialized
INFO - 2021-07-12 09:03:29 --> Router Class Initialized
INFO - 2021-07-12 09:03:29 --> Output Class Initialized
INFO - 2021-07-12 09:03:29 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:29 --> Input Class Initialized
INFO - 2021-07-12 09:03:29 --> Language Class Initialized
INFO - 2021-07-12 09:03:29 --> Language Class Initialized
INFO - 2021-07-12 09:03:29 --> Config Class Initialized
INFO - 2021-07-12 09:03:29 --> Loader Class Initialized
INFO - 2021-07-12 09:03:29 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:29 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:29 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:29 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:29 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:29 --> Controller Class Initialized
DEBUG - 2021-07-12 09:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-07-12 09:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:03:29 --> Final output sent to browser
DEBUG - 2021-07-12 09:03:29 --> Total execution time: 0.0777
INFO - 2021-07-12 09:03:46 --> Config Class Initialized
INFO - 2021-07-12 09:03:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:46 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:46 --> URI Class Initialized
INFO - 2021-07-12 09:03:46 --> Router Class Initialized
INFO - 2021-07-12 09:03:46 --> Output Class Initialized
INFO - 2021-07-12 09:03:46 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:46 --> Input Class Initialized
INFO - 2021-07-12 09:03:46 --> Language Class Initialized
INFO - 2021-07-12 09:03:46 --> Language Class Initialized
INFO - 2021-07-12 09:03:46 --> Config Class Initialized
INFO - 2021-07-12 09:03:46 --> Loader Class Initialized
INFO - 2021-07-12 09:03:46 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:46 --> Controller Class Initialized
INFO - 2021-07-12 09:03:46 --> Helper loaded: cookie_helper
INFO - 2021-07-12 09:03:46 --> Config Class Initialized
INFO - 2021-07-12 09:03:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:46 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:46 --> URI Class Initialized
INFO - 2021-07-12 09:03:46 --> Router Class Initialized
INFO - 2021-07-12 09:03:46 --> Output Class Initialized
INFO - 2021-07-12 09:03:46 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:46 --> Input Class Initialized
INFO - 2021-07-12 09:03:46 --> Language Class Initialized
INFO - 2021-07-12 09:03:46 --> Language Class Initialized
INFO - 2021-07-12 09:03:46 --> Config Class Initialized
INFO - 2021-07-12 09:03:46 --> Loader Class Initialized
INFO - 2021-07-12 09:03:46 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:46 --> Controller Class Initialized
DEBUG - 2021-07-12 09:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 09:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:03:46 --> Final output sent to browser
DEBUG - 2021-07-12 09:03:46 --> Total execution time: 0.0449
INFO - 2021-07-12 09:03:46 --> Config Class Initialized
INFO - 2021-07-12 09:03:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:46 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:46 --> URI Class Initialized
INFO - 2021-07-12 09:03:46 --> Router Class Initialized
INFO - 2021-07-12 09:03:46 --> Output Class Initialized
INFO - 2021-07-12 09:03:46 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:46 --> Input Class Initialized
INFO - 2021-07-12 09:03:46 --> Language Class Initialized
INFO - 2021-07-12 09:03:46 --> Language Class Initialized
INFO - 2021-07-12 09:03:46 --> Config Class Initialized
INFO - 2021-07-12 09:03:46 --> Loader Class Initialized
INFO - 2021-07-12 09:03:46 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:46 --> Controller Class Initialized
INFO - 2021-07-12 09:03:46 --> Helper loaded: cookie_helper
INFO - 2021-07-12 09:03:46 --> Config Class Initialized
INFO - 2021-07-12 09:03:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:46 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:46 --> URI Class Initialized
INFO - 2021-07-12 09:03:46 --> Router Class Initialized
INFO - 2021-07-12 09:03:46 --> Output Class Initialized
INFO - 2021-07-12 09:03:46 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:46 --> Input Class Initialized
INFO - 2021-07-12 09:03:46 --> Language Class Initialized
INFO - 2021-07-12 09:03:46 --> Language Class Initialized
INFO - 2021-07-12 09:03:46 --> Config Class Initialized
INFO - 2021-07-12 09:03:46 --> Loader Class Initialized
INFO - 2021-07-12 09:03:46 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:46 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:46 --> Controller Class Initialized
DEBUG - 2021-07-12 09:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-12 09:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:03:46 --> Final output sent to browser
DEBUG - 2021-07-12 09:03:46 --> Total execution time: 0.0407
INFO - 2021-07-12 09:03:50 --> Config Class Initialized
INFO - 2021-07-12 09:03:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:50 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:50 --> URI Class Initialized
INFO - 2021-07-12 09:03:50 --> Router Class Initialized
INFO - 2021-07-12 09:03:50 --> Output Class Initialized
INFO - 2021-07-12 09:03:50 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:50 --> Input Class Initialized
INFO - 2021-07-12 09:03:50 --> Language Class Initialized
INFO - 2021-07-12 09:03:50 --> Language Class Initialized
INFO - 2021-07-12 09:03:50 --> Config Class Initialized
INFO - 2021-07-12 09:03:50 --> Loader Class Initialized
INFO - 2021-07-12 09:03:50 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:50 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:50 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:50 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:50 --> Controller Class Initialized
INFO - 2021-07-12 09:03:50 --> Helper loaded: cookie_helper
INFO - 2021-07-12 09:03:50 --> Final output sent to browser
DEBUG - 2021-07-12 09:03:50 --> Total execution time: 0.0773
INFO - 2021-07-12 09:03:51 --> Config Class Initialized
INFO - 2021-07-12 09:03:51 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:51 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:51 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:51 --> URI Class Initialized
INFO - 2021-07-12 09:03:51 --> Router Class Initialized
INFO - 2021-07-12 09:03:51 --> Output Class Initialized
INFO - 2021-07-12 09:03:51 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:51 --> Input Class Initialized
INFO - 2021-07-12 09:03:51 --> Language Class Initialized
INFO - 2021-07-12 09:03:51 --> Language Class Initialized
INFO - 2021-07-12 09:03:51 --> Config Class Initialized
INFO - 2021-07-12 09:03:51 --> Loader Class Initialized
INFO - 2021-07-12 09:03:51 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:51 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:51 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:51 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:51 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:51 --> Controller Class Initialized
DEBUG - 2021-07-12 09:03:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-12 09:03:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:03:51 --> Final output sent to browser
DEBUG - 2021-07-12 09:03:51 --> Total execution time: 0.5441
INFO - 2021-07-12 09:03:55 --> Config Class Initialized
INFO - 2021-07-12 09:03:55 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:03:55 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:03:55 --> Utf8 Class Initialized
INFO - 2021-07-12 09:03:55 --> URI Class Initialized
INFO - 2021-07-12 09:03:55 --> Router Class Initialized
INFO - 2021-07-12 09:03:55 --> Output Class Initialized
INFO - 2021-07-12 09:03:55 --> Security Class Initialized
DEBUG - 2021-07-12 09:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:03:55 --> Input Class Initialized
INFO - 2021-07-12 09:03:55 --> Language Class Initialized
INFO - 2021-07-12 09:03:55 --> Language Class Initialized
INFO - 2021-07-12 09:03:55 --> Config Class Initialized
INFO - 2021-07-12 09:03:55 --> Loader Class Initialized
INFO - 2021-07-12 09:03:55 --> Helper loaded: url_helper
INFO - 2021-07-12 09:03:55 --> Helper loaded: file_helper
INFO - 2021-07-12 09:03:55 --> Helper loaded: form_helper
INFO - 2021-07-12 09:03:55 --> Helper loaded: my_helper
INFO - 2021-07-12 09:03:55 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:03:55 --> Controller Class Initialized
DEBUG - 2021-07-12 09:03:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-12 09:03:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:03:55 --> Final output sent to browser
DEBUG - 2021-07-12 09:03:55 --> Total execution time: 0.1061
INFO - 2021-07-12 09:04:16 --> Config Class Initialized
INFO - 2021-07-12 09:04:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:04:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:04:16 --> Utf8 Class Initialized
INFO - 2021-07-12 09:04:16 --> URI Class Initialized
INFO - 2021-07-12 09:04:16 --> Router Class Initialized
INFO - 2021-07-12 09:04:16 --> Output Class Initialized
INFO - 2021-07-12 09:04:16 --> Security Class Initialized
DEBUG - 2021-07-12 09:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:04:16 --> Input Class Initialized
INFO - 2021-07-12 09:04:16 --> Language Class Initialized
INFO - 2021-07-12 09:04:16 --> Language Class Initialized
INFO - 2021-07-12 09:04:16 --> Config Class Initialized
INFO - 2021-07-12 09:04:16 --> Loader Class Initialized
INFO - 2021-07-12 09:04:16 --> Helper loaded: url_helper
INFO - 2021-07-12 09:04:16 --> Helper loaded: file_helper
INFO - 2021-07-12 09:04:16 --> Helper loaded: form_helper
INFO - 2021-07-12 09:04:16 --> Helper loaded: my_helper
INFO - 2021-07-12 09:04:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:04:16 --> Controller Class Initialized
DEBUG - 2021-07-12 09:04:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 09:04:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:04:16 --> Final output sent to browser
DEBUG - 2021-07-12 09:04:16 --> Total execution time: 0.1235
INFO - 2021-07-12 09:04:23 --> Config Class Initialized
INFO - 2021-07-12 09:04:23 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:04:23 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:04:23 --> Utf8 Class Initialized
INFO - 2021-07-12 09:04:23 --> URI Class Initialized
INFO - 2021-07-12 09:04:23 --> Router Class Initialized
INFO - 2021-07-12 09:04:23 --> Output Class Initialized
INFO - 2021-07-12 09:04:23 --> Security Class Initialized
DEBUG - 2021-07-12 09:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:04:23 --> Input Class Initialized
INFO - 2021-07-12 09:04:23 --> Language Class Initialized
INFO - 2021-07-12 09:04:23 --> Language Class Initialized
INFO - 2021-07-12 09:04:23 --> Config Class Initialized
INFO - 2021-07-12 09:04:23 --> Loader Class Initialized
INFO - 2021-07-12 09:04:23 --> Helper loaded: url_helper
INFO - 2021-07-12 09:04:23 --> Helper loaded: file_helper
INFO - 2021-07-12 09:04:23 --> Helper loaded: form_helper
INFO - 2021-07-12 09:04:23 --> Helper loaded: my_helper
INFO - 2021-07-12 09:04:23 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:04:23 --> Controller Class Initialized
DEBUG - 2021-07-12 09:04:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 09:04:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:04:23 --> Final output sent to browser
DEBUG - 2021-07-12 09:04:23 --> Total execution time: 0.0542
INFO - 2021-07-12 09:04:44 --> Config Class Initialized
INFO - 2021-07-12 09:04:44 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:04:44 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:04:44 --> Utf8 Class Initialized
INFO - 2021-07-12 09:04:44 --> URI Class Initialized
INFO - 2021-07-12 09:04:44 --> Router Class Initialized
INFO - 2021-07-12 09:04:44 --> Output Class Initialized
INFO - 2021-07-12 09:04:44 --> Security Class Initialized
DEBUG - 2021-07-12 09:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:04:44 --> Input Class Initialized
INFO - 2021-07-12 09:04:44 --> Language Class Initialized
INFO - 2021-07-12 09:04:44 --> Language Class Initialized
INFO - 2021-07-12 09:04:44 --> Config Class Initialized
INFO - 2021-07-12 09:04:44 --> Loader Class Initialized
INFO - 2021-07-12 09:04:44 --> Helper loaded: url_helper
INFO - 2021-07-12 09:04:44 --> Helper loaded: file_helper
INFO - 2021-07-12 09:04:44 --> Helper loaded: form_helper
INFO - 2021-07-12 09:04:44 --> Helper loaded: my_helper
INFO - 2021-07-12 09:04:44 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:04:44 --> Controller Class Initialized
DEBUG - 2021-07-12 09:04:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 09:04:44 --> Final output sent to browser
DEBUG - 2021-07-12 09:04:44 --> Total execution time: 0.2583
INFO - 2021-07-12 09:05:00 --> Config Class Initialized
INFO - 2021-07-12 09:05:00 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:05:00 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:05:00 --> Utf8 Class Initialized
INFO - 2021-07-12 09:05:00 --> URI Class Initialized
INFO - 2021-07-12 09:05:00 --> Router Class Initialized
INFO - 2021-07-12 09:05:00 --> Output Class Initialized
INFO - 2021-07-12 09:05:00 --> Security Class Initialized
DEBUG - 2021-07-12 09:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:05:00 --> Input Class Initialized
INFO - 2021-07-12 09:05:00 --> Language Class Initialized
INFO - 2021-07-12 09:05:00 --> Language Class Initialized
INFO - 2021-07-12 09:05:00 --> Config Class Initialized
INFO - 2021-07-12 09:05:00 --> Loader Class Initialized
INFO - 2021-07-12 09:05:00 --> Helper loaded: url_helper
INFO - 2021-07-12 09:05:00 --> Helper loaded: file_helper
INFO - 2021-07-12 09:05:00 --> Helper loaded: form_helper
INFO - 2021-07-12 09:05:00 --> Helper loaded: my_helper
INFO - 2021-07-12 09:05:00 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:05:00 --> Controller Class Initialized
DEBUG - 2021-07-12 09:05:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-07-12 09:05:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:05:00 --> Final output sent to browser
DEBUG - 2021-07-12 09:05:00 --> Total execution time: 0.0968
INFO - 2021-07-12 09:05:01 --> Config Class Initialized
INFO - 2021-07-12 09:05:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:05:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:05:01 --> Utf8 Class Initialized
INFO - 2021-07-12 09:05:01 --> URI Class Initialized
INFO - 2021-07-12 09:05:01 --> Router Class Initialized
INFO - 2021-07-12 09:05:01 --> Output Class Initialized
INFO - 2021-07-12 09:05:01 --> Security Class Initialized
DEBUG - 2021-07-12 09:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:05:01 --> Input Class Initialized
INFO - 2021-07-12 09:05:01 --> Language Class Initialized
INFO - 2021-07-12 09:05:01 --> Language Class Initialized
INFO - 2021-07-12 09:05:01 --> Config Class Initialized
INFO - 2021-07-12 09:05:01 --> Loader Class Initialized
INFO - 2021-07-12 09:05:01 --> Helper loaded: url_helper
INFO - 2021-07-12 09:05:01 --> Helper loaded: file_helper
INFO - 2021-07-12 09:05:01 --> Helper loaded: form_helper
INFO - 2021-07-12 09:05:01 --> Helper loaded: my_helper
INFO - 2021-07-12 09:05:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:05:01 --> Controller Class Initialized
DEBUG - 2021-07-12 09:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-07-12 09:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:05:01 --> Final output sent to browser
DEBUG - 2021-07-12 09:05:01 --> Total execution time: 0.1061
INFO - 2021-07-12 09:05:03 --> Config Class Initialized
INFO - 2021-07-12 09:05:03 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:05:03 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:05:03 --> Utf8 Class Initialized
INFO - 2021-07-12 09:05:03 --> URI Class Initialized
INFO - 2021-07-12 09:05:03 --> Router Class Initialized
INFO - 2021-07-12 09:05:03 --> Output Class Initialized
INFO - 2021-07-12 09:05:03 --> Security Class Initialized
DEBUG - 2021-07-12 09:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:05:03 --> Input Class Initialized
INFO - 2021-07-12 09:05:03 --> Language Class Initialized
INFO - 2021-07-12 09:05:03 --> Language Class Initialized
INFO - 2021-07-12 09:05:03 --> Config Class Initialized
INFO - 2021-07-12 09:05:03 --> Loader Class Initialized
INFO - 2021-07-12 09:05:03 --> Helper loaded: url_helper
INFO - 2021-07-12 09:05:03 --> Helper loaded: file_helper
INFO - 2021-07-12 09:05:03 --> Helper loaded: form_helper
INFO - 2021-07-12 09:05:03 --> Helper loaded: my_helper
INFO - 2021-07-12 09:05:03 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:05:03 --> Controller Class Initialized
DEBUG - 2021-07-12 09:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-12 09:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:05:03 --> Final output sent to browser
DEBUG - 2021-07-12 09:05:03 --> Total execution time: 0.0648
INFO - 2021-07-12 09:07:21 --> Config Class Initialized
INFO - 2021-07-12 09:07:21 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:07:21 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:07:21 --> Utf8 Class Initialized
INFO - 2021-07-12 09:07:21 --> URI Class Initialized
INFO - 2021-07-12 09:07:21 --> Router Class Initialized
INFO - 2021-07-12 09:07:21 --> Output Class Initialized
INFO - 2021-07-12 09:07:21 --> Security Class Initialized
DEBUG - 2021-07-12 09:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:07:21 --> Input Class Initialized
INFO - 2021-07-12 09:07:21 --> Language Class Initialized
INFO - 2021-07-12 09:07:21 --> Language Class Initialized
INFO - 2021-07-12 09:07:21 --> Config Class Initialized
INFO - 2021-07-12 09:07:21 --> Loader Class Initialized
INFO - 2021-07-12 09:07:21 --> Helper loaded: url_helper
INFO - 2021-07-12 09:07:21 --> Helper loaded: file_helper
INFO - 2021-07-12 09:07:21 --> Helper loaded: form_helper
INFO - 2021-07-12 09:07:21 --> Helper loaded: my_helper
INFO - 2021-07-12 09:07:21 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:07:21 --> Controller Class Initialized
DEBUG - 2021-07-12 09:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-12 09:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:07:21 --> Final output sent to browser
DEBUG - 2021-07-12 09:07:21 --> Total execution time: 0.0578
INFO - 2021-07-12 09:11:37 --> Config Class Initialized
INFO - 2021-07-12 09:11:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:11:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:11:37 --> Utf8 Class Initialized
INFO - 2021-07-12 09:11:37 --> URI Class Initialized
INFO - 2021-07-12 09:11:37 --> Router Class Initialized
INFO - 2021-07-12 09:11:37 --> Output Class Initialized
INFO - 2021-07-12 09:11:37 --> Security Class Initialized
DEBUG - 2021-07-12 09:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:11:37 --> Input Class Initialized
INFO - 2021-07-12 09:11:37 --> Language Class Initialized
INFO - 2021-07-12 09:11:37 --> Language Class Initialized
INFO - 2021-07-12 09:11:37 --> Config Class Initialized
INFO - 2021-07-12 09:11:37 --> Loader Class Initialized
INFO - 2021-07-12 09:11:37 --> Helper loaded: url_helper
INFO - 2021-07-12 09:11:37 --> Helper loaded: file_helper
INFO - 2021-07-12 09:11:37 --> Helper loaded: form_helper
INFO - 2021-07-12 09:11:37 --> Helper loaded: my_helper
INFO - 2021-07-12 09:11:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:11:37 --> Controller Class Initialized
DEBUG - 2021-07-12 09:11:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-12 09:11:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:11:37 --> Final output sent to browser
DEBUG - 2021-07-12 09:11:37 --> Total execution time: 0.0726
INFO - 2021-07-12 09:12:16 --> Config Class Initialized
INFO - 2021-07-12 09:12:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:12:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:12:16 --> Utf8 Class Initialized
INFO - 2021-07-12 09:12:16 --> URI Class Initialized
INFO - 2021-07-12 09:12:16 --> Router Class Initialized
INFO - 2021-07-12 09:12:16 --> Output Class Initialized
INFO - 2021-07-12 09:12:16 --> Security Class Initialized
DEBUG - 2021-07-12 09:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:12:16 --> Input Class Initialized
INFO - 2021-07-12 09:12:16 --> Language Class Initialized
INFO - 2021-07-12 09:12:16 --> Language Class Initialized
INFO - 2021-07-12 09:12:16 --> Config Class Initialized
INFO - 2021-07-12 09:12:16 --> Loader Class Initialized
INFO - 2021-07-12 09:12:16 --> Helper loaded: url_helper
INFO - 2021-07-12 09:12:16 --> Helper loaded: file_helper
INFO - 2021-07-12 09:12:16 --> Helper loaded: form_helper
INFO - 2021-07-12 09:12:16 --> Helper loaded: my_helper
INFO - 2021-07-12 09:12:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:12:16 --> Controller Class Initialized
DEBUG - 2021-07-12 09:12:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-12 09:12:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:12:16 --> Final output sent to browser
DEBUG - 2021-07-12 09:12:16 --> Total execution time: 0.0510
INFO - 2021-07-12 09:19:09 --> Config Class Initialized
INFO - 2021-07-12 09:19:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:19:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:19:09 --> Utf8 Class Initialized
INFO - 2021-07-12 09:19:09 --> URI Class Initialized
INFO - 2021-07-12 09:19:09 --> Router Class Initialized
INFO - 2021-07-12 09:19:09 --> Output Class Initialized
INFO - 2021-07-12 09:19:09 --> Security Class Initialized
DEBUG - 2021-07-12 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:19:09 --> Input Class Initialized
INFO - 2021-07-12 09:19:09 --> Language Class Initialized
INFO - 2021-07-12 09:19:09 --> Language Class Initialized
INFO - 2021-07-12 09:19:09 --> Config Class Initialized
INFO - 2021-07-12 09:19:09 --> Loader Class Initialized
INFO - 2021-07-12 09:19:09 --> Helper loaded: url_helper
INFO - 2021-07-12 09:19:09 --> Helper loaded: file_helper
INFO - 2021-07-12 09:19:09 --> Helper loaded: form_helper
INFO - 2021-07-12 09:19:09 --> Helper loaded: my_helper
INFO - 2021-07-12 09:19:09 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:19:09 --> Controller Class Initialized
INFO - 2021-07-12 09:19:09 --> Final output sent to browser
DEBUG - 2021-07-12 09:19:09 --> Total execution time: 0.0882
INFO - 2021-07-12 09:19:37 --> Config Class Initialized
INFO - 2021-07-12 09:19:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:19:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:19:37 --> Utf8 Class Initialized
INFO - 2021-07-12 09:19:37 --> URI Class Initialized
INFO - 2021-07-12 09:19:37 --> Router Class Initialized
INFO - 2021-07-12 09:19:37 --> Output Class Initialized
INFO - 2021-07-12 09:19:37 --> Security Class Initialized
DEBUG - 2021-07-12 09:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:19:37 --> Input Class Initialized
INFO - 2021-07-12 09:19:37 --> Language Class Initialized
INFO - 2021-07-12 09:19:37 --> Language Class Initialized
INFO - 2021-07-12 09:19:37 --> Config Class Initialized
INFO - 2021-07-12 09:19:37 --> Loader Class Initialized
INFO - 2021-07-12 09:19:37 --> Helper loaded: url_helper
INFO - 2021-07-12 09:19:37 --> Helper loaded: file_helper
INFO - 2021-07-12 09:19:37 --> Helper loaded: form_helper
INFO - 2021-07-12 09:19:37 --> Helper loaded: my_helper
INFO - 2021-07-12 09:19:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:19:37 --> Controller Class Initialized
INFO - 2021-07-12 09:19:37 --> Final output sent to browser
DEBUG - 2021-07-12 09:19:37 --> Total execution time: 0.0970
INFO - 2021-07-12 09:19:48 --> Config Class Initialized
INFO - 2021-07-12 09:19:48 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:19:48 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:19:48 --> Utf8 Class Initialized
INFO - 2021-07-12 09:19:48 --> URI Class Initialized
INFO - 2021-07-12 09:19:48 --> Router Class Initialized
INFO - 2021-07-12 09:19:48 --> Output Class Initialized
INFO - 2021-07-12 09:19:48 --> Security Class Initialized
DEBUG - 2021-07-12 09:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:19:48 --> Input Class Initialized
INFO - 2021-07-12 09:19:48 --> Language Class Initialized
INFO - 2021-07-12 09:19:48 --> Language Class Initialized
INFO - 2021-07-12 09:19:48 --> Config Class Initialized
INFO - 2021-07-12 09:19:48 --> Loader Class Initialized
INFO - 2021-07-12 09:19:48 --> Helper loaded: url_helper
INFO - 2021-07-12 09:19:48 --> Helper loaded: file_helper
INFO - 2021-07-12 09:19:48 --> Helper loaded: form_helper
INFO - 2021-07-12 09:19:48 --> Helper loaded: my_helper
INFO - 2021-07-12 09:19:48 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:19:48 --> Controller Class Initialized
DEBUG - 2021-07-12 09:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-12 09:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:19:48 --> Final output sent to browser
DEBUG - 2021-07-12 09:19:48 --> Total execution time: 0.0635
INFO - 2021-07-12 09:20:04 --> Config Class Initialized
INFO - 2021-07-12 09:20:04 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:20:04 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:20:04 --> Utf8 Class Initialized
INFO - 2021-07-12 09:20:04 --> URI Class Initialized
INFO - 2021-07-12 09:20:04 --> Router Class Initialized
INFO - 2021-07-12 09:20:04 --> Output Class Initialized
INFO - 2021-07-12 09:20:04 --> Security Class Initialized
DEBUG - 2021-07-12 09:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:20:04 --> Input Class Initialized
INFO - 2021-07-12 09:20:04 --> Language Class Initialized
INFO - 2021-07-12 09:20:04 --> Language Class Initialized
INFO - 2021-07-12 09:20:04 --> Config Class Initialized
INFO - 2021-07-12 09:20:04 --> Loader Class Initialized
INFO - 2021-07-12 09:20:04 --> Helper loaded: url_helper
INFO - 2021-07-12 09:20:04 --> Helper loaded: file_helper
INFO - 2021-07-12 09:20:04 --> Helper loaded: form_helper
INFO - 2021-07-12 09:20:04 --> Helper loaded: my_helper
INFO - 2021-07-12 09:20:04 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:20:04 --> Controller Class Initialized
DEBUG - 2021-07-12 09:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 09:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:20:04 --> Final output sent to browser
DEBUG - 2021-07-12 09:20:04 --> Total execution time: 0.0520
INFO - 2021-07-12 09:22:44 --> Config Class Initialized
INFO - 2021-07-12 09:22:44 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:22:44 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:22:44 --> Utf8 Class Initialized
INFO - 2021-07-12 09:22:44 --> URI Class Initialized
INFO - 2021-07-12 09:22:44 --> Router Class Initialized
INFO - 2021-07-12 09:22:44 --> Output Class Initialized
INFO - 2021-07-12 09:22:44 --> Security Class Initialized
DEBUG - 2021-07-12 09:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:22:44 --> Input Class Initialized
INFO - 2021-07-12 09:22:44 --> Language Class Initialized
INFO - 2021-07-12 09:22:44 --> Language Class Initialized
INFO - 2021-07-12 09:22:44 --> Config Class Initialized
INFO - 2021-07-12 09:22:44 --> Loader Class Initialized
INFO - 2021-07-12 09:22:44 --> Helper loaded: url_helper
INFO - 2021-07-12 09:22:44 --> Helper loaded: file_helper
INFO - 2021-07-12 09:22:44 --> Helper loaded: form_helper
INFO - 2021-07-12 09:22:44 --> Helper loaded: my_helper
INFO - 2021-07-12 09:22:44 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:22:44 --> Controller Class Initialized
DEBUG - 2021-07-12 09:22:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-12 09:22:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-12 09:22:44 --> Final output sent to browser
DEBUG - 2021-07-12 09:22:44 --> Total execution time: 0.0713
INFO - 2021-07-12 09:22:48 --> Config Class Initialized
INFO - 2021-07-12 09:22:48 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:22:48 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:22:48 --> Utf8 Class Initialized
INFO - 2021-07-12 09:22:48 --> URI Class Initialized
INFO - 2021-07-12 09:22:48 --> Router Class Initialized
INFO - 2021-07-12 09:22:48 --> Output Class Initialized
INFO - 2021-07-12 09:22:48 --> Security Class Initialized
DEBUG - 2021-07-12 09:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:22:48 --> Input Class Initialized
INFO - 2021-07-12 09:22:48 --> Language Class Initialized
INFO - 2021-07-12 09:22:48 --> Language Class Initialized
INFO - 2021-07-12 09:22:48 --> Config Class Initialized
INFO - 2021-07-12 09:22:48 --> Loader Class Initialized
INFO - 2021-07-12 09:22:48 --> Helper loaded: url_helper
INFO - 2021-07-12 09:22:48 --> Helper loaded: file_helper
INFO - 2021-07-12 09:22:48 --> Helper loaded: form_helper
INFO - 2021-07-12 09:22:48 --> Helper loaded: my_helper
INFO - 2021-07-12 09:22:48 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:22:48 --> Controller Class Initialized
DEBUG - 2021-07-12 09:22:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 09:22:48 --> Final output sent to browser
DEBUG - 2021-07-12 09:22:48 --> Total execution time: 0.2248
INFO - 2021-07-12 09:23:05 --> Config Class Initialized
INFO - 2021-07-12 09:23:05 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:23:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:23:05 --> Utf8 Class Initialized
INFO - 2021-07-12 09:23:05 --> URI Class Initialized
INFO - 2021-07-12 09:23:06 --> Router Class Initialized
INFO - 2021-07-12 09:23:06 --> Output Class Initialized
INFO - 2021-07-12 09:23:06 --> Security Class Initialized
DEBUG - 2021-07-12 09:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:23:06 --> Input Class Initialized
INFO - 2021-07-12 09:23:06 --> Language Class Initialized
INFO - 2021-07-12 09:23:06 --> Language Class Initialized
INFO - 2021-07-12 09:23:06 --> Config Class Initialized
INFO - 2021-07-12 09:23:06 --> Loader Class Initialized
INFO - 2021-07-12 09:23:06 --> Helper loaded: url_helper
INFO - 2021-07-12 09:23:06 --> Helper loaded: file_helper
INFO - 2021-07-12 09:23:06 --> Helper loaded: form_helper
INFO - 2021-07-12 09:23:06 --> Helper loaded: my_helper
INFO - 2021-07-12 09:23:06 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:23:06 --> Controller Class Initialized
DEBUG - 2021-07-12 09:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 09:23:06 --> Final output sent to browser
DEBUG - 2021-07-12 09:23:06 --> Total execution time: 0.1489
INFO - 2021-07-12 09:23:10 --> Config Class Initialized
INFO - 2021-07-12 09:23:10 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:23:10 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:23:10 --> Utf8 Class Initialized
INFO - 2021-07-12 09:23:10 --> URI Class Initialized
INFO - 2021-07-12 09:23:10 --> Router Class Initialized
INFO - 2021-07-12 09:23:10 --> Output Class Initialized
INFO - 2021-07-12 09:23:10 --> Security Class Initialized
DEBUG - 2021-07-12 09:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:23:10 --> Input Class Initialized
INFO - 2021-07-12 09:23:10 --> Language Class Initialized
INFO - 2021-07-12 09:23:10 --> Language Class Initialized
INFO - 2021-07-12 09:23:10 --> Config Class Initialized
INFO - 2021-07-12 09:23:10 --> Loader Class Initialized
INFO - 2021-07-12 09:23:10 --> Helper loaded: url_helper
INFO - 2021-07-12 09:23:10 --> Helper loaded: file_helper
INFO - 2021-07-12 09:23:10 --> Helper loaded: form_helper
INFO - 2021-07-12 09:23:10 --> Helper loaded: my_helper
INFO - 2021-07-12 09:23:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:23:10 --> Controller Class Initialized
DEBUG - 2021-07-12 09:23:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 09:23:10 --> Final output sent to browser
DEBUG - 2021-07-12 09:23:10 --> Total execution time: 0.1327
INFO - 2021-07-12 09:23:14 --> Config Class Initialized
INFO - 2021-07-12 09:23:14 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:23:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:23:14 --> Utf8 Class Initialized
INFO - 2021-07-12 09:23:14 --> URI Class Initialized
INFO - 2021-07-12 09:23:14 --> Router Class Initialized
INFO - 2021-07-12 09:23:14 --> Output Class Initialized
INFO - 2021-07-12 09:23:14 --> Security Class Initialized
DEBUG - 2021-07-12 09:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:23:14 --> Input Class Initialized
INFO - 2021-07-12 09:23:14 --> Language Class Initialized
INFO - 2021-07-12 09:23:14 --> Language Class Initialized
INFO - 2021-07-12 09:23:14 --> Config Class Initialized
INFO - 2021-07-12 09:23:14 --> Loader Class Initialized
INFO - 2021-07-12 09:23:14 --> Helper loaded: url_helper
INFO - 2021-07-12 09:23:14 --> Helper loaded: file_helper
INFO - 2021-07-12 09:23:14 --> Helper loaded: form_helper
INFO - 2021-07-12 09:23:14 --> Helper loaded: my_helper
INFO - 2021-07-12 09:23:14 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:23:14 --> Controller Class Initialized
DEBUG - 2021-07-12 09:23:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 09:23:14 --> Final output sent to browser
DEBUG - 2021-07-12 09:23:14 --> Total execution time: 0.1844
INFO - 2021-07-12 09:23:59 --> Config Class Initialized
INFO - 2021-07-12 09:23:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:23:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:23:59 --> Utf8 Class Initialized
INFO - 2021-07-12 09:23:59 --> URI Class Initialized
INFO - 2021-07-12 09:23:59 --> Router Class Initialized
INFO - 2021-07-12 09:23:59 --> Output Class Initialized
INFO - 2021-07-12 09:23:59 --> Security Class Initialized
DEBUG - 2021-07-12 09:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:23:59 --> Input Class Initialized
INFO - 2021-07-12 09:23:59 --> Language Class Initialized
INFO - 2021-07-12 09:23:59 --> Language Class Initialized
INFO - 2021-07-12 09:23:59 --> Config Class Initialized
INFO - 2021-07-12 09:23:59 --> Loader Class Initialized
INFO - 2021-07-12 09:23:59 --> Helper loaded: url_helper
INFO - 2021-07-12 09:23:59 --> Helper loaded: file_helper
INFO - 2021-07-12 09:23:59 --> Helper loaded: form_helper
INFO - 2021-07-12 09:23:59 --> Helper loaded: my_helper
INFO - 2021-07-12 09:23:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:23:59 --> Controller Class Initialized
DEBUG - 2021-07-12 09:23:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-07-12 09:23:59 --> Final output sent to browser
DEBUG - 2021-07-12 09:23:59 --> Total execution time: 0.2428
