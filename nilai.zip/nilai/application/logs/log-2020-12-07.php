<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-07 05:08:22 --> Config Class Initialized
INFO - 2020-12-07 05:08:22 --> Hooks Class Initialized
DEBUG - 2020-12-07 05:08:22 --> UTF-8 Support Enabled
INFO - 2020-12-07 05:08:22 --> Utf8 Class Initialized
INFO - 2020-12-07 05:08:22 --> URI Class Initialized
DEBUG - 2020-12-07 05:08:23 --> No URI present. Default controller set.
INFO - 2020-12-07 05:08:23 --> Router Class Initialized
INFO - 2020-12-07 05:08:23 --> Output Class Initialized
INFO - 2020-12-07 05:08:23 --> Security Class Initialized
DEBUG - 2020-12-07 05:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 05:08:23 --> Input Class Initialized
INFO - 2020-12-07 05:08:23 --> Language Class Initialized
INFO - 2020-12-07 05:08:23 --> Language Class Initialized
INFO - 2020-12-07 05:08:23 --> Config Class Initialized
INFO - 2020-12-07 05:08:23 --> Loader Class Initialized
INFO - 2020-12-07 05:08:23 --> Helper loaded: url_helper
INFO - 2020-12-07 05:08:23 --> Helper loaded: file_helper
INFO - 2020-12-07 05:08:23 --> Helper loaded: form_helper
INFO - 2020-12-07 05:08:23 --> Helper loaded: my_helper
INFO - 2020-12-07 05:08:23 --> Database Driver Class Initialized
DEBUG - 2020-12-07 05:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 05:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 05:08:23 --> Controller Class Initialized
INFO - 2020-12-07 05:08:23 --> Config Class Initialized
INFO - 2020-12-07 05:08:23 --> Hooks Class Initialized
DEBUG - 2020-12-07 05:08:23 --> UTF-8 Support Enabled
INFO - 2020-12-07 05:08:23 --> Utf8 Class Initialized
INFO - 2020-12-07 05:08:23 --> URI Class Initialized
INFO - 2020-12-07 05:08:23 --> Router Class Initialized
INFO - 2020-12-07 05:08:23 --> Output Class Initialized
INFO - 2020-12-07 05:08:23 --> Security Class Initialized
DEBUG - 2020-12-07 05:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 05:08:23 --> Input Class Initialized
INFO - 2020-12-07 05:08:23 --> Language Class Initialized
INFO - 2020-12-07 05:08:23 --> Language Class Initialized
INFO - 2020-12-07 05:08:24 --> Config Class Initialized
INFO - 2020-12-07 05:08:24 --> Loader Class Initialized
INFO - 2020-12-07 05:08:24 --> Helper loaded: url_helper
INFO - 2020-12-07 05:08:24 --> Helper loaded: file_helper
INFO - 2020-12-07 05:08:24 --> Helper loaded: form_helper
INFO - 2020-12-07 05:08:24 --> Helper loaded: my_helper
INFO - 2020-12-07 05:08:24 --> Database Driver Class Initialized
DEBUG - 2020-12-07 05:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 05:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 05:08:24 --> Controller Class Initialized
DEBUG - 2020-12-07 05:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-07 05:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 05:08:24 --> Final output sent to browser
DEBUG - 2020-12-07 05:08:24 --> Total execution time: 0.2643
INFO - 2020-12-07 05:19:12 --> Config Class Initialized
INFO - 2020-12-07 05:19:12 --> Hooks Class Initialized
DEBUG - 2020-12-07 05:19:12 --> UTF-8 Support Enabled
INFO - 2020-12-07 05:19:12 --> Utf8 Class Initialized
INFO - 2020-12-07 05:19:12 --> URI Class Initialized
INFO - 2020-12-07 05:19:12 --> Router Class Initialized
INFO - 2020-12-07 05:19:12 --> Output Class Initialized
INFO - 2020-12-07 05:19:12 --> Security Class Initialized
DEBUG - 2020-12-07 05:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 05:19:12 --> Input Class Initialized
INFO - 2020-12-07 05:19:12 --> Language Class Initialized
INFO - 2020-12-07 05:19:12 --> Language Class Initialized
INFO - 2020-12-07 05:19:12 --> Config Class Initialized
INFO - 2020-12-07 05:19:12 --> Loader Class Initialized
INFO - 2020-12-07 05:19:12 --> Helper loaded: url_helper
INFO - 2020-12-07 05:19:12 --> Helper loaded: file_helper
INFO - 2020-12-07 05:19:12 --> Helper loaded: form_helper
INFO - 2020-12-07 05:19:12 --> Helper loaded: my_helper
INFO - 2020-12-07 05:19:12 --> Database Driver Class Initialized
DEBUG - 2020-12-07 05:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 05:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 05:19:12 --> Controller Class Initialized
INFO - 2020-12-07 05:19:12 --> Helper loaded: cookie_helper
INFO - 2020-12-07 05:19:12 --> Final output sent to browser
DEBUG - 2020-12-07 05:19:12 --> Total execution time: 0.2481
INFO - 2020-12-07 05:19:12 --> Config Class Initialized
INFO - 2020-12-07 05:19:12 --> Hooks Class Initialized
DEBUG - 2020-12-07 05:19:12 --> UTF-8 Support Enabled
INFO - 2020-12-07 05:19:12 --> Utf8 Class Initialized
INFO - 2020-12-07 05:19:12 --> URI Class Initialized
INFO - 2020-12-07 05:19:12 --> Router Class Initialized
INFO - 2020-12-07 05:19:12 --> Output Class Initialized
INFO - 2020-12-07 05:19:12 --> Security Class Initialized
DEBUG - 2020-12-07 05:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 05:19:12 --> Input Class Initialized
INFO - 2020-12-07 05:19:12 --> Language Class Initialized
INFO - 2020-12-07 05:19:12 --> Language Class Initialized
INFO - 2020-12-07 05:19:12 --> Config Class Initialized
INFO - 2020-12-07 05:19:12 --> Loader Class Initialized
INFO - 2020-12-07 05:19:12 --> Helper loaded: url_helper
INFO - 2020-12-07 05:19:12 --> Helper loaded: file_helper
INFO - 2020-12-07 05:19:12 --> Helper loaded: form_helper
INFO - 2020-12-07 05:19:12 --> Helper loaded: my_helper
INFO - 2020-12-07 05:19:12 --> Database Driver Class Initialized
DEBUG - 2020-12-07 05:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 05:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 05:19:13 --> Controller Class Initialized
DEBUG - 2020-12-07 05:19:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-07 05:19:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 05:19:13 --> Final output sent to browser
DEBUG - 2020-12-07 05:19:13 --> Total execution time: 0.2200
INFO - 2020-12-07 05:19:14 --> Config Class Initialized
INFO - 2020-12-07 05:19:14 --> Hooks Class Initialized
DEBUG - 2020-12-07 05:19:14 --> UTF-8 Support Enabled
INFO - 2020-12-07 05:19:14 --> Utf8 Class Initialized
INFO - 2020-12-07 05:19:14 --> URI Class Initialized
INFO - 2020-12-07 05:19:14 --> Router Class Initialized
INFO - 2020-12-07 05:19:14 --> Output Class Initialized
INFO - 2020-12-07 05:19:14 --> Security Class Initialized
DEBUG - 2020-12-07 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 05:19:14 --> Input Class Initialized
INFO - 2020-12-07 05:19:14 --> Language Class Initialized
INFO - 2020-12-07 05:19:14 --> Language Class Initialized
INFO - 2020-12-07 05:19:14 --> Config Class Initialized
INFO - 2020-12-07 05:19:14 --> Loader Class Initialized
INFO - 2020-12-07 05:19:14 --> Helper loaded: url_helper
INFO - 2020-12-07 05:19:14 --> Helper loaded: file_helper
INFO - 2020-12-07 05:19:14 --> Helper loaded: form_helper
INFO - 2020-12-07 05:19:14 --> Helper loaded: my_helper
INFO - 2020-12-07 05:19:14 --> Database Driver Class Initialized
DEBUG - 2020-12-07 05:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 05:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 05:19:14 --> Controller Class Initialized
DEBUG - 2020-12-07 05:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 05:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 05:19:14 --> Final output sent to browser
DEBUG - 2020-12-07 05:19:14 --> Total execution time: 0.2683
INFO - 2020-12-07 09:44:01 --> Config Class Initialized
INFO - 2020-12-07 09:44:01 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:44:01 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:44:01 --> Utf8 Class Initialized
INFO - 2020-12-07 09:44:01 --> URI Class Initialized
INFO - 2020-12-07 09:44:01 --> Router Class Initialized
INFO - 2020-12-07 09:44:01 --> Output Class Initialized
INFO - 2020-12-07 09:44:01 --> Security Class Initialized
DEBUG - 2020-12-07 09:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:44:01 --> Input Class Initialized
INFO - 2020-12-07 09:44:01 --> Language Class Initialized
INFO - 2020-12-07 09:44:01 --> Language Class Initialized
INFO - 2020-12-07 09:44:01 --> Config Class Initialized
INFO - 2020-12-07 09:44:01 --> Loader Class Initialized
INFO - 2020-12-07 09:44:01 --> Helper loaded: url_helper
INFO - 2020-12-07 09:44:01 --> Helper loaded: file_helper
INFO - 2020-12-07 09:44:01 --> Helper loaded: form_helper
INFO - 2020-12-07 09:44:01 --> Helper loaded: my_helper
INFO - 2020-12-07 09:44:01 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:44:01 --> Controller Class Initialized
DEBUG - 2020-12-07 09:44:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 09:44:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 09:44:01 --> Final output sent to browser
DEBUG - 2020-12-07 09:44:01 --> Total execution time: 0.2431
INFO - 2020-12-07 09:46:47 --> Config Class Initialized
INFO - 2020-12-07 09:46:47 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:46:47 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:46:47 --> Utf8 Class Initialized
INFO - 2020-12-07 09:46:47 --> URI Class Initialized
INFO - 2020-12-07 09:46:47 --> Router Class Initialized
INFO - 2020-12-07 09:46:47 --> Output Class Initialized
INFO - 2020-12-07 09:46:47 --> Security Class Initialized
DEBUG - 2020-12-07 09:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:46:47 --> Input Class Initialized
INFO - 2020-12-07 09:46:47 --> Language Class Initialized
INFO - 2020-12-07 09:46:47 --> Language Class Initialized
INFO - 2020-12-07 09:46:47 --> Config Class Initialized
INFO - 2020-12-07 09:46:47 --> Loader Class Initialized
INFO - 2020-12-07 09:46:47 --> Helper loaded: url_helper
INFO - 2020-12-07 09:46:47 --> Helper loaded: file_helper
INFO - 2020-12-07 09:46:47 --> Helper loaded: form_helper
INFO - 2020-12-07 09:46:47 --> Helper loaded: my_helper
INFO - 2020-12-07 09:46:47 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:46:47 --> Controller Class Initialized
DEBUG - 2020-12-07 09:46:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-12-07 09:46:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 09:46:47 --> Final output sent to browser
DEBUG - 2020-12-07 09:46:47 --> Total execution time: 0.3135
INFO - 2020-12-07 09:46:48 --> Config Class Initialized
INFO - 2020-12-07 09:46:48 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:46:48 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:46:48 --> Utf8 Class Initialized
INFO - 2020-12-07 09:46:48 --> URI Class Initialized
INFO - 2020-12-07 09:46:48 --> Router Class Initialized
INFO - 2020-12-07 09:46:48 --> Output Class Initialized
INFO - 2020-12-07 09:46:48 --> Security Class Initialized
DEBUG - 2020-12-07 09:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:46:48 --> Input Class Initialized
INFO - 2020-12-07 09:46:48 --> Language Class Initialized
INFO - 2020-12-07 09:46:48 --> Language Class Initialized
INFO - 2020-12-07 09:46:48 --> Config Class Initialized
INFO - 2020-12-07 09:46:48 --> Loader Class Initialized
INFO - 2020-12-07 09:46:48 --> Helper loaded: url_helper
INFO - 2020-12-07 09:46:48 --> Helper loaded: file_helper
INFO - 2020-12-07 09:46:48 --> Helper loaded: form_helper
INFO - 2020-12-07 09:46:48 --> Helper loaded: my_helper
INFO - 2020-12-07 09:46:48 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:46:49 --> Controller Class Initialized
DEBUG - 2020-12-07 09:46:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 09:46:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 09:46:49 --> Final output sent to browser
DEBUG - 2020-12-07 09:46:49 --> Total execution time: 0.1986
INFO - 2020-12-07 09:49:00 --> Config Class Initialized
INFO - 2020-12-07 09:49:00 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:49:00 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:49:00 --> Utf8 Class Initialized
INFO - 2020-12-07 09:49:00 --> URI Class Initialized
INFO - 2020-12-07 09:49:00 --> Router Class Initialized
INFO - 2020-12-07 09:49:00 --> Output Class Initialized
INFO - 2020-12-07 09:49:00 --> Security Class Initialized
DEBUG - 2020-12-07 09:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:49:00 --> Input Class Initialized
INFO - 2020-12-07 09:49:00 --> Language Class Initialized
INFO - 2020-12-07 09:49:00 --> Language Class Initialized
INFO - 2020-12-07 09:49:00 --> Config Class Initialized
INFO - 2020-12-07 09:49:00 --> Loader Class Initialized
INFO - 2020-12-07 09:49:00 --> Helper loaded: url_helper
INFO - 2020-12-07 09:49:01 --> Helper loaded: file_helper
INFO - 2020-12-07 09:49:01 --> Helper loaded: form_helper
INFO - 2020-12-07 09:49:01 --> Helper loaded: my_helper
INFO - 2020-12-07 09:49:01 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:49:01 --> Controller Class Initialized
DEBUG - 2020-12-07 09:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 09:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 09:49:01 --> Final output sent to browser
DEBUG - 2020-12-07 09:49:01 --> Total execution time: 0.2362
INFO - 2020-12-07 09:50:53 --> Config Class Initialized
INFO - 2020-12-07 09:50:53 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:50:53 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:50:53 --> Utf8 Class Initialized
INFO - 2020-12-07 09:50:53 --> URI Class Initialized
INFO - 2020-12-07 09:50:53 --> Router Class Initialized
INFO - 2020-12-07 09:50:53 --> Output Class Initialized
INFO - 2020-12-07 09:50:53 --> Security Class Initialized
DEBUG - 2020-12-07 09:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:50:53 --> Input Class Initialized
INFO - 2020-12-07 09:50:53 --> Language Class Initialized
INFO - 2020-12-07 09:50:53 --> Language Class Initialized
INFO - 2020-12-07 09:50:53 --> Config Class Initialized
INFO - 2020-12-07 09:50:53 --> Loader Class Initialized
INFO - 2020-12-07 09:50:53 --> Helper loaded: url_helper
INFO - 2020-12-07 09:50:53 --> Helper loaded: file_helper
INFO - 2020-12-07 09:50:53 --> Helper loaded: form_helper
INFO - 2020-12-07 09:50:53 --> Helper loaded: my_helper
INFO - 2020-12-07 09:50:53 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:50:53 --> Controller Class Initialized
DEBUG - 2020-12-07 09:50:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 09:50:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 09:50:53 --> Final output sent to browser
DEBUG - 2020-12-07 09:50:53 --> Total execution time: 0.2183
INFO - 2020-12-07 09:50:55 --> Config Class Initialized
INFO - 2020-12-07 09:50:55 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:50:55 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:50:55 --> Utf8 Class Initialized
INFO - 2020-12-07 09:50:55 --> URI Class Initialized
INFO - 2020-12-07 09:50:55 --> Router Class Initialized
INFO - 2020-12-07 09:50:55 --> Output Class Initialized
INFO - 2020-12-07 09:50:55 --> Security Class Initialized
DEBUG - 2020-12-07 09:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:50:55 --> Input Class Initialized
INFO - 2020-12-07 09:50:55 --> Language Class Initialized
INFO - 2020-12-07 09:50:55 --> Language Class Initialized
INFO - 2020-12-07 09:50:55 --> Config Class Initialized
INFO - 2020-12-07 09:50:55 --> Loader Class Initialized
INFO - 2020-12-07 09:50:55 --> Helper loaded: url_helper
INFO - 2020-12-07 09:50:55 --> Helper loaded: file_helper
INFO - 2020-12-07 09:50:55 --> Helper loaded: form_helper
INFO - 2020-12-07 09:50:55 --> Helper loaded: my_helper
INFO - 2020-12-07 09:50:55 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:50:55 --> Controller Class Initialized
DEBUG - 2020-12-07 09:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 09:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 09:50:55 --> Final output sent to browser
DEBUG - 2020-12-07 09:50:55 --> Total execution time: 0.1907
INFO - 2020-12-07 09:53:19 --> Config Class Initialized
INFO - 2020-12-07 09:53:19 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:53:19 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:53:19 --> Utf8 Class Initialized
INFO - 2020-12-07 09:53:19 --> URI Class Initialized
INFO - 2020-12-07 09:53:19 --> Router Class Initialized
INFO - 2020-12-07 09:53:19 --> Output Class Initialized
INFO - 2020-12-07 09:53:19 --> Security Class Initialized
DEBUG - 2020-12-07 09:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:53:19 --> Input Class Initialized
INFO - 2020-12-07 09:53:19 --> Language Class Initialized
INFO - 2020-12-07 09:53:19 --> Language Class Initialized
INFO - 2020-12-07 09:53:19 --> Config Class Initialized
INFO - 2020-12-07 09:53:19 --> Loader Class Initialized
INFO - 2020-12-07 09:53:19 --> Helper loaded: url_helper
INFO - 2020-12-07 09:53:19 --> Helper loaded: file_helper
INFO - 2020-12-07 09:53:19 --> Helper loaded: form_helper
INFO - 2020-12-07 09:53:19 --> Helper loaded: my_helper
INFO - 2020-12-07 09:53:19 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:53:19 --> Controller Class Initialized
DEBUG - 2020-12-07 09:53:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 09:53:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 09:53:19 --> Final output sent to browser
DEBUG - 2020-12-07 09:53:19 --> Total execution time: 0.2347
INFO - 2020-12-07 09:54:36 --> Config Class Initialized
INFO - 2020-12-07 09:54:36 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:54:36 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:54:36 --> Utf8 Class Initialized
INFO - 2020-12-07 09:54:36 --> URI Class Initialized
INFO - 2020-12-07 09:54:36 --> Router Class Initialized
INFO - 2020-12-07 09:54:36 --> Output Class Initialized
INFO - 2020-12-07 09:54:36 --> Security Class Initialized
DEBUG - 2020-12-07 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:54:36 --> Input Class Initialized
INFO - 2020-12-07 09:54:36 --> Language Class Initialized
INFO - 2020-12-07 09:54:36 --> Language Class Initialized
INFO - 2020-12-07 09:54:36 --> Config Class Initialized
INFO - 2020-12-07 09:54:36 --> Loader Class Initialized
INFO - 2020-12-07 09:54:36 --> Helper loaded: url_helper
INFO - 2020-12-07 09:54:36 --> Helper loaded: file_helper
INFO - 2020-12-07 09:54:36 --> Helper loaded: form_helper
INFO - 2020-12-07 09:54:36 --> Helper loaded: my_helper
INFO - 2020-12-07 09:54:36 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:54:36 --> Controller Class Initialized
DEBUG - 2020-12-07 09:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 09:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 09:54:37 --> Final output sent to browser
DEBUG - 2020-12-07 09:54:37 --> Total execution time: 0.2075
INFO - 2020-12-07 09:57:16 --> Config Class Initialized
INFO - 2020-12-07 09:57:16 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:57:16 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:57:16 --> Utf8 Class Initialized
INFO - 2020-12-07 09:57:16 --> URI Class Initialized
INFO - 2020-12-07 09:57:16 --> Router Class Initialized
INFO - 2020-12-07 09:57:16 --> Output Class Initialized
INFO - 2020-12-07 09:57:16 --> Security Class Initialized
DEBUG - 2020-12-07 09:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:57:16 --> Input Class Initialized
INFO - 2020-12-07 09:57:16 --> Language Class Initialized
INFO - 2020-12-07 09:57:16 --> Language Class Initialized
INFO - 2020-12-07 09:57:16 --> Config Class Initialized
INFO - 2020-12-07 09:57:16 --> Loader Class Initialized
INFO - 2020-12-07 09:57:16 --> Helper loaded: url_helper
INFO - 2020-12-07 09:57:16 --> Helper loaded: file_helper
INFO - 2020-12-07 09:57:16 --> Helper loaded: form_helper
INFO - 2020-12-07 09:57:16 --> Helper loaded: my_helper
INFO - 2020-12-07 09:57:16 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:57:16 --> Controller Class Initialized
ERROR - 2020-12-07 09:57:16 --> Severity: Parsing Error --> syntax error, unexpected 'form' (T_STRING) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
INFO - 2020-12-07 09:59:37 --> Config Class Initialized
INFO - 2020-12-07 09:59:37 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:59:37 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:59:37 --> Utf8 Class Initialized
INFO - 2020-12-07 09:59:37 --> URI Class Initialized
INFO - 2020-12-07 09:59:37 --> Router Class Initialized
INFO - 2020-12-07 09:59:37 --> Output Class Initialized
INFO - 2020-12-07 09:59:37 --> Security Class Initialized
DEBUG - 2020-12-07 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:59:37 --> Input Class Initialized
INFO - 2020-12-07 09:59:37 --> Language Class Initialized
INFO - 2020-12-07 09:59:37 --> Language Class Initialized
INFO - 2020-12-07 09:59:37 --> Config Class Initialized
INFO - 2020-12-07 09:59:37 --> Loader Class Initialized
INFO - 2020-12-07 09:59:37 --> Helper loaded: url_helper
INFO - 2020-12-07 09:59:37 --> Helper loaded: file_helper
INFO - 2020-12-07 09:59:37 --> Helper loaded: form_helper
INFO - 2020-12-07 09:59:37 --> Helper loaded: my_helper
INFO - 2020-12-07 09:59:37 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:59:37 --> Controller Class Initialized
ERROR - 2020-12-07 09:59:37 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
INFO - 2020-12-07 09:59:55 --> Config Class Initialized
INFO - 2020-12-07 09:59:55 --> Hooks Class Initialized
DEBUG - 2020-12-07 09:59:55 --> UTF-8 Support Enabled
INFO - 2020-12-07 09:59:55 --> Utf8 Class Initialized
INFO - 2020-12-07 09:59:55 --> URI Class Initialized
INFO - 2020-12-07 09:59:55 --> Router Class Initialized
INFO - 2020-12-07 09:59:55 --> Output Class Initialized
INFO - 2020-12-07 09:59:55 --> Security Class Initialized
DEBUG - 2020-12-07 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 09:59:55 --> Input Class Initialized
INFO - 2020-12-07 09:59:55 --> Language Class Initialized
INFO - 2020-12-07 09:59:55 --> Language Class Initialized
INFO - 2020-12-07 09:59:55 --> Config Class Initialized
INFO - 2020-12-07 09:59:55 --> Loader Class Initialized
INFO - 2020-12-07 09:59:55 --> Helper loaded: url_helper
INFO - 2020-12-07 09:59:55 --> Helper loaded: file_helper
INFO - 2020-12-07 09:59:55 --> Helper loaded: form_helper
INFO - 2020-12-07 09:59:55 --> Helper loaded: my_helper
INFO - 2020-12-07 09:59:55 --> Database Driver Class Initialized
DEBUG - 2020-12-07 09:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 09:59:55 --> Controller Class Initialized
ERROR - 2020-12-07 09:59:55 --> Severity: Parsing Error --> syntax error, unexpected '?' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
INFO - 2020-12-07 10:00:50 --> Config Class Initialized
INFO - 2020-12-07 10:00:50 --> Hooks Class Initialized
DEBUG - 2020-12-07 10:00:50 --> UTF-8 Support Enabled
INFO - 2020-12-07 10:00:50 --> Utf8 Class Initialized
INFO - 2020-12-07 10:00:50 --> URI Class Initialized
INFO - 2020-12-07 10:00:50 --> Router Class Initialized
INFO - 2020-12-07 10:00:50 --> Output Class Initialized
INFO - 2020-12-07 10:00:50 --> Security Class Initialized
DEBUG - 2020-12-07 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 10:00:50 --> Input Class Initialized
INFO - 2020-12-07 10:00:50 --> Language Class Initialized
INFO - 2020-12-07 10:00:50 --> Language Class Initialized
INFO - 2020-12-07 10:00:50 --> Config Class Initialized
INFO - 2020-12-07 10:00:50 --> Loader Class Initialized
INFO - 2020-12-07 10:00:50 --> Helper loaded: url_helper
INFO - 2020-12-07 10:00:50 --> Helper loaded: file_helper
INFO - 2020-12-07 10:00:50 --> Helper loaded: form_helper
INFO - 2020-12-07 10:00:50 --> Helper loaded: my_helper
INFO - 2020-12-07 10:00:50 --> Database Driver Class Initialized
DEBUG - 2020-12-07 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 10:00:50 --> Controller Class Initialized
ERROR - 2020-12-07 10:00:50 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
INFO - 2020-12-07 10:01:47 --> Config Class Initialized
INFO - 2020-12-07 10:01:47 --> Hooks Class Initialized
DEBUG - 2020-12-07 10:01:47 --> UTF-8 Support Enabled
INFO - 2020-12-07 10:01:47 --> Utf8 Class Initialized
INFO - 2020-12-07 10:01:47 --> URI Class Initialized
INFO - 2020-12-07 10:01:47 --> Router Class Initialized
INFO - 2020-12-07 10:01:47 --> Output Class Initialized
INFO - 2020-12-07 10:01:47 --> Security Class Initialized
DEBUG - 2020-12-07 10:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-07 10:01:47 --> Input Class Initialized
INFO - 2020-12-07 10:01:47 --> Language Class Initialized
INFO - 2020-12-07 10:01:47 --> Language Class Initialized
INFO - 2020-12-07 10:01:47 --> Config Class Initialized
INFO - 2020-12-07 10:01:47 --> Loader Class Initialized
INFO - 2020-12-07 10:01:47 --> Helper loaded: url_helper
INFO - 2020-12-07 10:01:47 --> Helper loaded: file_helper
INFO - 2020-12-07 10:01:47 --> Helper loaded: form_helper
INFO - 2020-12-07 10:01:47 --> Helper loaded: my_helper
INFO - 2020-12-07 10:01:47 --> Database Driver Class Initialized
DEBUG - 2020-12-07 10:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-07 10:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-07 10:01:47 --> Controller Class Initialized
DEBUG - 2020-12-07 10:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-07 10:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-07 10:01:47 --> Final output sent to browser
DEBUG - 2020-12-07 10:01:47 --> Total execution time: 0.2170
