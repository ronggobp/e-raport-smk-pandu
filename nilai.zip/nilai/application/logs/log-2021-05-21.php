<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-21 09:06:38 --> Config Class Initialized
INFO - 2021-05-21 09:06:38 --> Hooks Class Initialized
DEBUG - 2021-05-21 09:06:38 --> UTF-8 Support Enabled
INFO - 2021-05-21 09:06:38 --> Utf8 Class Initialized
INFO - 2021-05-21 09:06:38 --> URI Class Initialized
DEBUG - 2021-05-21 09:06:38 --> No URI present. Default controller set.
INFO - 2021-05-21 09:06:38 --> Router Class Initialized
INFO - 2021-05-21 09:06:38 --> Output Class Initialized
INFO - 2021-05-21 09:06:38 --> Security Class Initialized
DEBUG - 2021-05-21 09:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 09:06:38 --> Input Class Initialized
INFO - 2021-05-21 09:06:38 --> Language Class Initialized
INFO - 2021-05-21 09:06:38 --> Language Class Initialized
INFO - 2021-05-21 09:06:38 --> Config Class Initialized
INFO - 2021-05-21 09:06:38 --> Loader Class Initialized
INFO - 2021-05-21 09:06:39 --> Helper loaded: url_helper
INFO - 2021-05-21 09:06:39 --> Helper loaded: file_helper
INFO - 2021-05-21 09:06:39 --> Helper loaded: form_helper
INFO - 2021-05-21 09:06:39 --> Helper loaded: my_helper
INFO - 2021-05-21 09:06:39 --> Database Driver Class Initialized
DEBUG - 2021-05-21 09:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-21 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-21 09:06:39 --> Controller Class Initialized
INFO - 2021-05-21 09:06:39 --> Config Class Initialized
INFO - 2021-05-21 09:06:39 --> Hooks Class Initialized
DEBUG - 2021-05-21 09:06:39 --> UTF-8 Support Enabled
INFO - 2021-05-21 09:06:39 --> Utf8 Class Initialized
INFO - 2021-05-21 09:06:39 --> URI Class Initialized
INFO - 2021-05-21 09:06:39 --> Router Class Initialized
INFO - 2021-05-21 09:06:39 --> Output Class Initialized
INFO - 2021-05-21 09:06:39 --> Security Class Initialized
DEBUG - 2021-05-21 09:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 09:06:39 --> Input Class Initialized
INFO - 2021-05-21 09:06:39 --> Language Class Initialized
INFO - 2021-05-21 09:06:39 --> Language Class Initialized
INFO - 2021-05-21 09:06:39 --> Config Class Initialized
INFO - 2021-05-21 09:06:39 --> Loader Class Initialized
INFO - 2021-05-21 09:06:39 --> Helper loaded: url_helper
INFO - 2021-05-21 09:06:39 --> Helper loaded: file_helper
INFO - 2021-05-21 09:06:39 --> Helper loaded: form_helper
INFO - 2021-05-21 09:06:39 --> Helper loaded: my_helper
INFO - 2021-05-21 09:06:39 --> Database Driver Class Initialized
DEBUG - 2021-05-21 09:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-21 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-21 09:06:39 --> Controller Class Initialized
DEBUG - 2021-05-21 09:06:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-05-21 09:06:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-05-21 09:06:39 --> Final output sent to browser
DEBUG - 2021-05-21 09:06:39 --> Total execution time: 0.1479
