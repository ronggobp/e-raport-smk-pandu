<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-09 01:17:18 --> Config Class Initialized
INFO - 2020-11-09 01:17:18 --> Hooks Class Initialized
DEBUG - 2020-11-09 01:17:18 --> UTF-8 Support Enabled
INFO - 2020-11-09 01:17:18 --> Utf8 Class Initialized
INFO - 2020-11-09 01:17:18 --> URI Class Initialized
DEBUG - 2020-11-09 01:17:19 --> No URI present. Default controller set.
INFO - 2020-11-09 01:17:19 --> Router Class Initialized
INFO - 2020-11-09 01:17:19 --> Output Class Initialized
INFO - 2020-11-09 01:17:19 --> Security Class Initialized
DEBUG - 2020-11-09 01:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 01:17:19 --> Input Class Initialized
INFO - 2020-11-09 01:17:19 --> Language Class Initialized
INFO - 2020-11-09 01:17:19 --> Language Class Initialized
INFO - 2020-11-09 01:17:19 --> Config Class Initialized
INFO - 2020-11-09 01:17:19 --> Loader Class Initialized
INFO - 2020-11-09 01:17:19 --> Helper loaded: url_helper
INFO - 2020-11-09 01:17:19 --> Helper loaded: file_helper
INFO - 2020-11-09 01:17:19 --> Helper loaded: form_helper
INFO - 2020-11-09 01:17:19 --> Helper loaded: my_helper
INFO - 2020-11-09 01:17:19 --> Database Driver Class Initialized
DEBUG - 2020-11-09 01:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 01:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 01:17:19 --> Controller Class Initialized
INFO - 2020-11-09 01:17:19 --> Config Class Initialized
INFO - 2020-11-09 01:17:19 --> Hooks Class Initialized
DEBUG - 2020-11-09 01:17:19 --> UTF-8 Support Enabled
INFO - 2020-11-09 01:17:19 --> Utf8 Class Initialized
INFO - 2020-11-09 01:17:19 --> URI Class Initialized
INFO - 2020-11-09 01:17:19 --> Router Class Initialized
INFO - 2020-11-09 01:17:19 --> Output Class Initialized
INFO - 2020-11-09 01:17:19 --> Security Class Initialized
DEBUG - 2020-11-09 01:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 01:17:19 --> Input Class Initialized
INFO - 2020-11-09 01:17:20 --> Language Class Initialized
INFO - 2020-11-09 01:17:20 --> Language Class Initialized
INFO - 2020-11-09 01:17:20 --> Config Class Initialized
INFO - 2020-11-09 01:17:20 --> Loader Class Initialized
INFO - 2020-11-09 01:17:20 --> Helper loaded: url_helper
INFO - 2020-11-09 01:17:20 --> Helper loaded: file_helper
INFO - 2020-11-09 01:17:20 --> Helper loaded: form_helper
INFO - 2020-11-09 01:17:20 --> Helper loaded: my_helper
INFO - 2020-11-09 01:17:20 --> Database Driver Class Initialized
DEBUG - 2020-11-09 01:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 01:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 01:17:20 --> Controller Class Initialized
DEBUG - 2020-11-09 01:17:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-09 01:17:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 01:17:20 --> Final output sent to browser
DEBUG - 2020-11-09 01:17:20 --> Total execution time: 0.2762
INFO - 2020-11-09 01:39:38 --> Config Class Initialized
INFO - 2020-11-09 01:39:38 --> Hooks Class Initialized
DEBUG - 2020-11-09 01:39:38 --> UTF-8 Support Enabled
INFO - 2020-11-09 01:39:38 --> Utf8 Class Initialized
INFO - 2020-11-09 01:39:38 --> URI Class Initialized
INFO - 2020-11-09 01:39:38 --> Router Class Initialized
INFO - 2020-11-09 01:39:38 --> Output Class Initialized
INFO - 2020-11-09 01:39:38 --> Security Class Initialized
DEBUG - 2020-11-09 01:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 01:39:38 --> Input Class Initialized
INFO - 2020-11-09 01:39:38 --> Language Class Initialized
INFO - 2020-11-09 01:39:38 --> Language Class Initialized
INFO - 2020-11-09 01:39:38 --> Config Class Initialized
INFO - 2020-11-09 01:39:38 --> Loader Class Initialized
INFO - 2020-11-09 01:39:38 --> Helper loaded: url_helper
INFO - 2020-11-09 01:39:38 --> Helper loaded: file_helper
INFO - 2020-11-09 01:39:38 --> Helper loaded: form_helper
INFO - 2020-11-09 01:39:38 --> Helper loaded: my_helper
INFO - 2020-11-09 01:39:38 --> Database Driver Class Initialized
DEBUG - 2020-11-09 01:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 01:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 01:39:39 --> Controller Class Initialized
DEBUG - 2020-11-09 01:39:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-09 01:39:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 01:39:39 --> Final output sent to browser
DEBUG - 2020-11-09 01:39:39 --> Total execution time: 0.2225
INFO - 2020-11-09 01:40:43 --> Config Class Initialized
INFO - 2020-11-09 01:40:43 --> Hooks Class Initialized
DEBUG - 2020-11-09 01:40:43 --> UTF-8 Support Enabled
INFO - 2020-11-09 01:40:43 --> Utf8 Class Initialized
INFO - 2020-11-09 01:40:43 --> URI Class Initialized
INFO - 2020-11-09 01:40:43 --> Router Class Initialized
INFO - 2020-11-09 01:40:43 --> Output Class Initialized
INFO - 2020-11-09 01:40:43 --> Security Class Initialized
DEBUG - 2020-11-09 01:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 01:40:43 --> Input Class Initialized
INFO - 2020-11-09 01:40:43 --> Language Class Initialized
INFO - 2020-11-09 01:40:43 --> Language Class Initialized
INFO - 2020-11-09 01:40:43 --> Config Class Initialized
INFO - 2020-11-09 01:40:43 --> Loader Class Initialized
INFO - 2020-11-09 01:40:43 --> Helper loaded: url_helper
INFO - 2020-11-09 01:40:43 --> Helper loaded: file_helper
INFO - 2020-11-09 01:40:43 --> Helper loaded: form_helper
INFO - 2020-11-09 01:40:43 --> Helper loaded: my_helper
INFO - 2020-11-09 01:40:43 --> Database Driver Class Initialized
DEBUG - 2020-11-09 01:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 01:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 01:40:43 --> Controller Class Initialized
INFO - 2020-11-09 01:40:43 --> Helper loaded: cookie_helper
INFO - 2020-11-09 01:40:43 --> Final output sent to browser
DEBUG - 2020-11-09 01:40:43 --> Total execution time: 0.3278
INFO - 2020-11-09 01:40:44 --> Config Class Initialized
INFO - 2020-11-09 01:40:44 --> Hooks Class Initialized
DEBUG - 2020-11-09 01:40:44 --> UTF-8 Support Enabled
INFO - 2020-11-09 01:40:44 --> Utf8 Class Initialized
INFO - 2020-11-09 01:40:44 --> URI Class Initialized
INFO - 2020-11-09 01:40:44 --> Router Class Initialized
INFO - 2020-11-09 01:40:44 --> Output Class Initialized
INFO - 2020-11-09 01:40:44 --> Security Class Initialized
DEBUG - 2020-11-09 01:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 01:40:44 --> Input Class Initialized
INFO - 2020-11-09 01:40:44 --> Language Class Initialized
INFO - 2020-11-09 01:40:44 --> Language Class Initialized
INFO - 2020-11-09 01:40:44 --> Config Class Initialized
INFO - 2020-11-09 01:40:44 --> Loader Class Initialized
INFO - 2020-11-09 01:40:44 --> Helper loaded: url_helper
INFO - 2020-11-09 01:40:44 --> Helper loaded: file_helper
INFO - 2020-11-09 01:40:44 --> Helper loaded: form_helper
INFO - 2020-11-09 01:40:44 --> Helper loaded: my_helper
INFO - 2020-11-09 01:40:44 --> Database Driver Class Initialized
DEBUG - 2020-11-09 01:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 01:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 01:40:44 --> Controller Class Initialized
DEBUG - 2020-11-09 01:40:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-09 01:40:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 01:40:44 --> Final output sent to browser
DEBUG - 2020-11-09 01:40:44 --> Total execution time: 0.3846
INFO - 2020-11-09 02:05:40 --> Config Class Initialized
INFO - 2020-11-09 02:05:40 --> Hooks Class Initialized
DEBUG - 2020-11-09 02:05:40 --> UTF-8 Support Enabled
INFO - 2020-11-09 02:05:40 --> Utf8 Class Initialized
INFO - 2020-11-09 02:05:40 --> URI Class Initialized
INFO - 2020-11-09 02:05:40 --> Router Class Initialized
INFO - 2020-11-09 02:05:40 --> Output Class Initialized
INFO - 2020-11-09 02:05:40 --> Security Class Initialized
DEBUG - 2020-11-09 02:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 02:05:40 --> Input Class Initialized
INFO - 2020-11-09 02:05:40 --> Language Class Initialized
INFO - 2020-11-09 02:05:40 --> Language Class Initialized
INFO - 2020-11-09 02:05:40 --> Config Class Initialized
INFO - 2020-11-09 02:05:40 --> Loader Class Initialized
INFO - 2020-11-09 02:05:40 --> Helper loaded: url_helper
INFO - 2020-11-09 02:05:40 --> Helper loaded: file_helper
INFO - 2020-11-09 02:05:40 --> Helper loaded: form_helper
INFO - 2020-11-09 02:05:40 --> Helper loaded: my_helper
INFO - 2020-11-09 02:05:40 --> Database Driver Class Initialized
DEBUG - 2020-11-09 02:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 02:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 02:05:41 --> Controller Class Initialized
DEBUG - 2020-11-09 02:05:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-09 02:05:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 02:05:41 --> Final output sent to browser
DEBUG - 2020-11-09 02:05:41 --> Total execution time: 0.6445
INFO - 2020-11-09 02:07:01 --> Config Class Initialized
INFO - 2020-11-09 02:07:01 --> Hooks Class Initialized
DEBUG - 2020-11-09 02:07:01 --> UTF-8 Support Enabled
INFO - 2020-11-09 02:07:01 --> Utf8 Class Initialized
INFO - 2020-11-09 02:07:01 --> URI Class Initialized
INFO - 2020-11-09 02:07:01 --> Router Class Initialized
INFO - 2020-11-09 02:07:01 --> Output Class Initialized
INFO - 2020-11-09 02:07:01 --> Security Class Initialized
DEBUG - 2020-11-09 02:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 02:07:01 --> Input Class Initialized
INFO - 2020-11-09 02:07:01 --> Language Class Initialized
INFO - 2020-11-09 02:07:01 --> Language Class Initialized
INFO - 2020-11-09 02:07:01 --> Config Class Initialized
INFO - 2020-11-09 02:07:01 --> Loader Class Initialized
INFO - 2020-11-09 02:07:01 --> Helper loaded: url_helper
INFO - 2020-11-09 02:07:02 --> Helper loaded: file_helper
INFO - 2020-11-09 02:07:02 --> Helper loaded: form_helper
INFO - 2020-11-09 02:07:02 --> Helper loaded: my_helper
INFO - 2020-11-09 02:07:02 --> Database Driver Class Initialized
DEBUG - 2020-11-09 02:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 02:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 02:07:02 --> Controller Class Initialized
DEBUG - 2020-11-09 02:07:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-09 02:07:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 02:07:02 --> Final output sent to browser
DEBUG - 2020-11-09 02:07:02 --> Total execution time: 0.7712
INFO - 2020-11-09 02:09:08 --> Config Class Initialized
INFO - 2020-11-09 02:09:08 --> Hooks Class Initialized
DEBUG - 2020-11-09 02:09:08 --> UTF-8 Support Enabled
INFO - 2020-11-09 02:09:08 --> Utf8 Class Initialized
INFO - 2020-11-09 02:09:08 --> URI Class Initialized
INFO - 2020-11-09 02:09:08 --> Router Class Initialized
INFO - 2020-11-09 02:09:08 --> Output Class Initialized
INFO - 2020-11-09 02:09:08 --> Security Class Initialized
DEBUG - 2020-11-09 02:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 02:09:08 --> Input Class Initialized
INFO - 2020-11-09 02:09:08 --> Language Class Initialized
INFO - 2020-11-09 02:09:08 --> Language Class Initialized
INFO - 2020-11-09 02:09:08 --> Config Class Initialized
INFO - 2020-11-09 02:09:08 --> Loader Class Initialized
INFO - 2020-11-09 02:09:08 --> Helper loaded: url_helper
INFO - 2020-11-09 02:09:08 --> Helper loaded: file_helper
INFO - 2020-11-09 02:09:08 --> Helper loaded: form_helper
INFO - 2020-11-09 02:09:08 --> Helper loaded: my_helper
INFO - 2020-11-09 02:09:08 --> Database Driver Class Initialized
DEBUG - 2020-11-09 02:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 02:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 02:09:08 --> Controller Class Initialized
DEBUG - 2020-11-09 02:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-09 02:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 02:09:09 --> Final output sent to browser
DEBUG - 2020-11-09 02:09:09 --> Total execution time: 0.8134
INFO - 2020-11-09 02:09:12 --> Config Class Initialized
INFO - 2020-11-09 02:09:12 --> Hooks Class Initialized
DEBUG - 2020-11-09 02:09:12 --> UTF-8 Support Enabled
INFO - 2020-11-09 02:09:12 --> Utf8 Class Initialized
INFO - 2020-11-09 02:09:12 --> URI Class Initialized
INFO - 2020-11-09 02:09:12 --> Router Class Initialized
INFO - 2020-11-09 02:09:12 --> Output Class Initialized
INFO - 2020-11-09 02:09:12 --> Security Class Initialized
DEBUG - 2020-11-09 02:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 02:09:12 --> Input Class Initialized
INFO - 2020-11-09 02:09:12 --> Language Class Initialized
INFO - 2020-11-09 02:09:12 --> Language Class Initialized
INFO - 2020-11-09 02:09:12 --> Config Class Initialized
INFO - 2020-11-09 02:09:12 --> Loader Class Initialized
INFO - 2020-11-09 02:09:12 --> Helper loaded: url_helper
INFO - 2020-11-09 02:09:12 --> Helper loaded: file_helper
INFO - 2020-11-09 02:09:12 --> Helper loaded: form_helper
INFO - 2020-11-09 02:09:12 --> Helper loaded: my_helper
INFO - 2020-11-09 02:09:12 --> Database Driver Class Initialized
DEBUG - 2020-11-09 02:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 02:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 02:09:13 --> Controller Class Initialized
DEBUG - 2020-11-09 02:09:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-09 02:09:13 --> Final output sent to browser
DEBUG - 2020-11-09 02:09:13 --> Total execution time: 0.8665
INFO - 2020-11-09 03:04:26 --> Config Class Initialized
INFO - 2020-11-09 03:04:26 --> Hooks Class Initialized
DEBUG - 2020-11-09 03:04:26 --> UTF-8 Support Enabled
INFO - 2020-11-09 03:04:26 --> Utf8 Class Initialized
INFO - 2020-11-09 03:04:26 --> URI Class Initialized
INFO - 2020-11-09 03:04:26 --> Router Class Initialized
INFO - 2020-11-09 03:04:26 --> Output Class Initialized
INFO - 2020-11-09 03:04:26 --> Security Class Initialized
DEBUG - 2020-11-09 03:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 03:04:26 --> Input Class Initialized
INFO - 2020-11-09 03:04:26 --> Language Class Initialized
INFO - 2020-11-09 03:04:27 --> Language Class Initialized
INFO - 2020-11-09 03:04:27 --> Config Class Initialized
INFO - 2020-11-09 03:04:27 --> Loader Class Initialized
INFO - 2020-11-09 03:04:27 --> Helper loaded: url_helper
INFO - 2020-11-09 03:04:27 --> Helper loaded: file_helper
INFO - 2020-11-09 03:04:27 --> Helper loaded: form_helper
INFO - 2020-11-09 03:04:27 --> Helper loaded: my_helper
INFO - 2020-11-09 03:04:27 --> Database Driver Class Initialized
DEBUG - 2020-11-09 03:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 03:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 03:04:27 --> Controller Class Initialized
DEBUG - 2020-11-09 03:04:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-09 03:04:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 03:04:27 --> Final output sent to browser
DEBUG - 2020-11-09 03:04:27 --> Total execution time: 0.6616
INFO - 2020-11-09 03:05:25 --> Config Class Initialized
INFO - 2020-11-09 03:05:25 --> Hooks Class Initialized
DEBUG - 2020-11-09 03:05:25 --> UTF-8 Support Enabled
INFO - 2020-11-09 03:05:25 --> Utf8 Class Initialized
INFO - 2020-11-09 03:05:25 --> URI Class Initialized
INFO - 2020-11-09 03:05:25 --> Router Class Initialized
INFO - 2020-11-09 03:05:25 --> Output Class Initialized
INFO - 2020-11-09 03:05:25 --> Security Class Initialized
DEBUG - 2020-11-09 03:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 03:05:25 --> Input Class Initialized
INFO - 2020-11-09 03:05:25 --> Language Class Initialized
INFO - 2020-11-09 03:05:25 --> Language Class Initialized
INFO - 2020-11-09 03:05:25 --> Config Class Initialized
INFO - 2020-11-09 03:05:25 --> Loader Class Initialized
INFO - 2020-11-09 03:05:25 --> Helper loaded: url_helper
INFO - 2020-11-09 03:05:25 --> Helper loaded: file_helper
INFO - 2020-11-09 03:05:25 --> Helper loaded: form_helper
INFO - 2020-11-09 03:05:25 --> Helper loaded: my_helper
INFO - 2020-11-09 03:05:25 --> Database Driver Class Initialized
DEBUG - 2020-11-09 03:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 03:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 03:05:26 --> Controller Class Initialized
DEBUG - 2020-11-09 03:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-09 03:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 03:05:26 --> Final output sent to browser
DEBUG - 2020-11-09 03:05:26 --> Total execution time: 0.8097
INFO - 2020-11-09 03:05:42 --> Config Class Initialized
INFO - 2020-11-09 03:05:42 --> Hooks Class Initialized
DEBUG - 2020-11-09 03:05:42 --> UTF-8 Support Enabled
INFO - 2020-11-09 03:05:42 --> Utf8 Class Initialized
INFO - 2020-11-09 03:05:42 --> URI Class Initialized
INFO - 2020-11-09 03:05:42 --> Router Class Initialized
INFO - 2020-11-09 03:05:42 --> Output Class Initialized
INFO - 2020-11-09 03:05:42 --> Security Class Initialized
DEBUG - 2020-11-09 03:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 03:05:42 --> Input Class Initialized
INFO - 2020-11-09 03:05:42 --> Language Class Initialized
INFO - 2020-11-09 03:05:43 --> Language Class Initialized
INFO - 2020-11-09 03:05:43 --> Config Class Initialized
INFO - 2020-11-09 03:05:43 --> Loader Class Initialized
INFO - 2020-11-09 03:05:43 --> Helper loaded: url_helper
INFO - 2020-11-09 03:05:43 --> Helper loaded: file_helper
INFO - 2020-11-09 03:05:43 --> Helper loaded: form_helper
INFO - 2020-11-09 03:05:43 --> Helper loaded: my_helper
INFO - 2020-11-09 03:05:43 --> Database Driver Class Initialized
DEBUG - 2020-11-09 03:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 03:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 03:05:43 --> Controller Class Initialized
DEBUG - 2020-11-09 03:05:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-09 03:05:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 03:05:43 --> Final output sent to browser
DEBUG - 2020-11-09 03:05:43 --> Total execution time: 0.7215
INFO - 2020-11-09 03:06:16 --> Config Class Initialized
INFO - 2020-11-09 03:06:16 --> Hooks Class Initialized
DEBUG - 2020-11-09 03:06:16 --> UTF-8 Support Enabled
INFO - 2020-11-09 03:06:16 --> Utf8 Class Initialized
INFO - 2020-11-09 03:06:16 --> URI Class Initialized
INFO - 2020-11-09 03:06:16 --> Router Class Initialized
INFO - 2020-11-09 03:06:16 --> Output Class Initialized
INFO - 2020-11-09 03:06:16 --> Security Class Initialized
DEBUG - 2020-11-09 03:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 03:06:16 --> Input Class Initialized
INFO - 2020-11-09 03:06:16 --> Language Class Initialized
INFO - 2020-11-09 03:06:17 --> Language Class Initialized
INFO - 2020-11-09 03:06:17 --> Config Class Initialized
INFO - 2020-11-09 03:06:17 --> Loader Class Initialized
INFO - 2020-11-09 03:06:17 --> Helper loaded: url_helper
INFO - 2020-11-09 03:06:17 --> Helper loaded: file_helper
INFO - 2020-11-09 03:06:17 --> Helper loaded: form_helper
INFO - 2020-11-09 03:06:17 --> Helper loaded: my_helper
INFO - 2020-11-09 03:06:17 --> Database Driver Class Initialized
DEBUG - 2020-11-09 03:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 03:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 03:06:17 --> Controller Class Initialized
DEBUG - 2020-11-09 03:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-09 03:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 03:06:17 --> Final output sent to browser
DEBUG - 2020-11-09 03:06:17 --> Total execution time: 0.9523
INFO - 2020-11-09 03:06:26 --> Config Class Initialized
INFO - 2020-11-09 03:06:26 --> Hooks Class Initialized
DEBUG - 2020-11-09 03:06:26 --> UTF-8 Support Enabled
INFO - 2020-11-09 03:06:26 --> Utf8 Class Initialized
INFO - 2020-11-09 03:06:26 --> URI Class Initialized
INFO - 2020-11-09 03:06:26 --> Router Class Initialized
INFO - 2020-11-09 03:06:26 --> Output Class Initialized
INFO - 2020-11-09 03:06:26 --> Security Class Initialized
DEBUG - 2020-11-09 03:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 03:06:26 --> Input Class Initialized
INFO - 2020-11-09 03:06:26 --> Language Class Initialized
INFO - 2020-11-09 03:06:26 --> Language Class Initialized
INFO - 2020-11-09 03:06:26 --> Config Class Initialized
INFO - 2020-11-09 03:06:27 --> Loader Class Initialized
INFO - 2020-11-09 03:06:27 --> Helper loaded: url_helper
INFO - 2020-11-09 03:06:27 --> Helper loaded: file_helper
INFO - 2020-11-09 03:06:27 --> Helper loaded: form_helper
INFO - 2020-11-09 03:06:27 --> Helper loaded: my_helper
INFO - 2020-11-09 03:06:27 --> Database Driver Class Initialized
DEBUG - 2020-11-09 03:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 03:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 03:06:27 --> Controller Class Initialized
DEBUG - 2020-11-09 03:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-11-09 03:06:27 --> Final output sent to browser
DEBUG - 2020-11-09 03:06:27 --> Total execution time: 0.5550
INFO - 2020-11-09 03:06:40 --> Config Class Initialized
INFO - 2020-11-09 03:06:40 --> Hooks Class Initialized
DEBUG - 2020-11-09 03:06:40 --> UTF-8 Support Enabled
INFO - 2020-11-09 03:06:40 --> Utf8 Class Initialized
INFO - 2020-11-09 03:06:40 --> URI Class Initialized
INFO - 2020-11-09 03:06:40 --> Router Class Initialized
INFO - 2020-11-09 03:06:40 --> Output Class Initialized
INFO - 2020-11-09 03:06:40 --> Security Class Initialized
DEBUG - 2020-11-09 03:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 03:06:40 --> Input Class Initialized
INFO - 2020-11-09 03:06:40 --> Language Class Initialized
INFO - 2020-11-09 03:06:40 --> Language Class Initialized
INFO - 2020-11-09 03:06:40 --> Config Class Initialized
INFO - 2020-11-09 03:06:40 --> Loader Class Initialized
INFO - 2020-11-09 03:06:41 --> Helper loaded: url_helper
INFO - 2020-11-09 03:06:41 --> Helper loaded: file_helper
INFO - 2020-11-09 03:06:41 --> Helper loaded: form_helper
INFO - 2020-11-09 03:06:41 --> Helper loaded: my_helper
INFO - 2020-11-09 03:06:41 --> Database Driver Class Initialized
DEBUG - 2020-11-09 03:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 03:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 03:06:41 --> Controller Class Initialized
DEBUG - 2020-11-09 03:06:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-11-09 03:06:41 --> Final output sent to browser
DEBUG - 2020-11-09 03:06:41 --> Total execution time: 0.5934
INFO - 2020-11-09 08:51:47 --> Config Class Initialized
INFO - 2020-11-09 08:51:47 --> Hooks Class Initialized
DEBUG - 2020-11-09 08:51:47 --> UTF-8 Support Enabled
INFO - 2020-11-09 08:51:47 --> Utf8 Class Initialized
INFO - 2020-11-09 08:51:47 --> URI Class Initialized
INFO - 2020-11-09 08:51:47 --> Router Class Initialized
INFO - 2020-11-09 08:51:47 --> Output Class Initialized
INFO - 2020-11-09 08:51:47 --> Security Class Initialized
DEBUG - 2020-11-09 08:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 08:51:47 --> Input Class Initialized
INFO - 2020-11-09 08:51:47 --> Language Class Initialized
INFO - 2020-11-09 08:51:47 --> Language Class Initialized
INFO - 2020-11-09 08:51:47 --> Config Class Initialized
INFO - 2020-11-09 08:51:47 --> Loader Class Initialized
INFO - 2020-11-09 08:51:47 --> Helper loaded: url_helper
INFO - 2020-11-09 08:51:47 --> Helper loaded: file_helper
INFO - 2020-11-09 08:51:47 --> Helper loaded: form_helper
INFO - 2020-11-09 08:51:47 --> Helper loaded: my_helper
INFO - 2020-11-09 08:51:47 --> Database Driver Class Initialized
DEBUG - 2020-11-09 08:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 08:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 08:51:47 --> Controller Class Initialized
DEBUG - 2020-11-09 08:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-09 08:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 08:51:47 --> Final output sent to browser
DEBUG - 2020-11-09 08:51:47 --> Total execution time: 0.3074
INFO - 2020-11-09 08:51:50 --> Config Class Initialized
INFO - 2020-11-09 08:51:50 --> Hooks Class Initialized
DEBUG - 2020-11-09 08:51:50 --> UTF-8 Support Enabled
INFO - 2020-11-09 08:51:50 --> Utf8 Class Initialized
INFO - 2020-11-09 08:51:50 --> URI Class Initialized
INFO - 2020-11-09 08:51:50 --> Router Class Initialized
INFO - 2020-11-09 08:51:50 --> Output Class Initialized
INFO - 2020-11-09 08:51:50 --> Security Class Initialized
DEBUG - 2020-11-09 08:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 08:51:50 --> Input Class Initialized
INFO - 2020-11-09 08:51:50 --> Language Class Initialized
INFO - 2020-11-09 08:51:50 --> Language Class Initialized
INFO - 2020-11-09 08:51:50 --> Config Class Initialized
INFO - 2020-11-09 08:51:50 --> Loader Class Initialized
INFO - 2020-11-09 08:51:50 --> Helper loaded: url_helper
INFO - 2020-11-09 08:51:50 --> Helper loaded: file_helper
INFO - 2020-11-09 08:51:50 --> Helper loaded: form_helper
INFO - 2020-11-09 08:51:50 --> Helper loaded: my_helper
INFO - 2020-11-09 08:51:50 --> Database Driver Class Initialized
DEBUG - 2020-11-09 08:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 08:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 08:51:51 --> Controller Class Initialized
DEBUG - 2020-11-09 08:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/cetak.php
INFO - 2020-11-09 08:51:51 --> Final output sent to browser
DEBUG - 2020-11-09 08:51:51 --> Total execution time: 0.2524
INFO - 2020-11-09 08:53:22 --> Config Class Initialized
INFO - 2020-11-09 08:53:22 --> Hooks Class Initialized
DEBUG - 2020-11-09 08:53:22 --> UTF-8 Support Enabled
INFO - 2020-11-09 08:53:22 --> Utf8 Class Initialized
INFO - 2020-11-09 08:53:22 --> URI Class Initialized
INFO - 2020-11-09 08:53:22 --> Router Class Initialized
INFO - 2020-11-09 08:53:22 --> Output Class Initialized
INFO - 2020-11-09 08:53:22 --> Security Class Initialized
DEBUG - 2020-11-09 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 08:53:22 --> Input Class Initialized
INFO - 2020-11-09 08:53:22 --> Language Class Initialized
INFO - 2020-11-09 08:53:22 --> Language Class Initialized
INFO - 2020-11-09 08:53:22 --> Config Class Initialized
INFO - 2020-11-09 08:53:22 --> Loader Class Initialized
INFO - 2020-11-09 08:53:22 --> Helper loaded: url_helper
INFO - 2020-11-09 08:53:22 --> Helper loaded: file_helper
INFO - 2020-11-09 08:53:22 --> Helper loaded: form_helper
INFO - 2020-11-09 08:53:22 --> Helper loaded: my_helper
INFO - 2020-11-09 08:53:22 --> Database Driver Class Initialized
DEBUG - 2020-11-09 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 08:53:22 --> Controller Class Initialized
DEBUG - 2020-11-09 08:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-09 08:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 08:53:22 --> Final output sent to browser
DEBUG - 2020-11-09 08:53:22 --> Total execution time: 0.2484
INFO - 2020-11-09 08:53:25 --> Config Class Initialized
INFO - 2020-11-09 08:53:25 --> Hooks Class Initialized
DEBUG - 2020-11-09 08:53:25 --> UTF-8 Support Enabled
INFO - 2020-11-09 08:53:25 --> Utf8 Class Initialized
INFO - 2020-11-09 08:53:25 --> URI Class Initialized
INFO - 2020-11-09 08:53:25 --> Router Class Initialized
INFO - 2020-11-09 08:53:25 --> Output Class Initialized
INFO - 2020-11-09 08:53:25 --> Security Class Initialized
DEBUG - 2020-11-09 08:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 08:53:25 --> Input Class Initialized
INFO - 2020-11-09 08:53:25 --> Language Class Initialized
INFO - 2020-11-09 08:53:26 --> Language Class Initialized
INFO - 2020-11-09 08:53:26 --> Config Class Initialized
INFO - 2020-11-09 08:53:26 --> Loader Class Initialized
INFO - 2020-11-09 08:53:26 --> Helper loaded: url_helper
INFO - 2020-11-09 08:53:26 --> Helper loaded: file_helper
INFO - 2020-11-09 08:53:26 --> Helper loaded: form_helper
INFO - 2020-11-09 08:53:26 --> Helper loaded: my_helper
INFO - 2020-11-09 08:53:26 --> Database Driver Class Initialized
DEBUG - 2020-11-09 08:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 08:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 08:53:26 --> Controller Class Initialized
DEBUG - 2020-11-09 08:53:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-11-09 08:53:26 --> Final output sent to browser
DEBUG - 2020-11-09 08:53:26 --> Total execution time: 0.2382
INFO - 2020-11-09 08:55:52 --> Config Class Initialized
INFO - 2020-11-09 08:55:52 --> Hooks Class Initialized
DEBUG - 2020-11-09 08:55:52 --> UTF-8 Support Enabled
INFO - 2020-11-09 08:55:52 --> Utf8 Class Initialized
INFO - 2020-11-09 08:55:52 --> URI Class Initialized
INFO - 2020-11-09 08:55:52 --> Router Class Initialized
INFO - 2020-11-09 08:55:52 --> Output Class Initialized
INFO - 2020-11-09 08:55:52 --> Security Class Initialized
DEBUG - 2020-11-09 08:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 08:55:52 --> Input Class Initialized
INFO - 2020-11-09 08:55:52 --> Language Class Initialized
INFO - 2020-11-09 08:55:52 --> Language Class Initialized
INFO - 2020-11-09 08:55:52 --> Config Class Initialized
INFO - 2020-11-09 08:55:52 --> Loader Class Initialized
INFO - 2020-11-09 08:55:52 --> Helper loaded: url_helper
INFO - 2020-11-09 08:55:52 --> Helper loaded: file_helper
INFO - 2020-11-09 08:55:52 --> Helper loaded: form_helper
INFO - 2020-11-09 08:55:52 --> Helper loaded: my_helper
INFO - 2020-11-09 08:55:52 --> Database Driver Class Initialized
DEBUG - 2020-11-09 08:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 08:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 08:55:52 --> Controller Class Initialized
DEBUG - 2020-11-09 08:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-09 08:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 08:55:52 --> Final output sent to browser
DEBUG - 2020-11-09 08:55:52 --> Total execution time: 0.2394
INFO - 2020-11-09 08:55:58 --> Config Class Initialized
INFO - 2020-11-09 08:55:59 --> Hooks Class Initialized
DEBUG - 2020-11-09 08:55:59 --> UTF-8 Support Enabled
INFO - 2020-11-09 08:55:59 --> Utf8 Class Initialized
INFO - 2020-11-09 08:55:59 --> URI Class Initialized
INFO - 2020-11-09 08:55:59 --> Router Class Initialized
INFO - 2020-11-09 08:55:59 --> Output Class Initialized
INFO - 2020-11-09 08:55:59 --> Security Class Initialized
DEBUG - 2020-11-09 08:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 08:55:59 --> Input Class Initialized
INFO - 2020-11-09 08:55:59 --> Language Class Initialized
INFO - 2020-11-09 08:55:59 --> Language Class Initialized
INFO - 2020-11-09 08:55:59 --> Config Class Initialized
INFO - 2020-11-09 08:55:59 --> Loader Class Initialized
INFO - 2020-11-09 08:55:59 --> Helper loaded: url_helper
INFO - 2020-11-09 08:55:59 --> Helper loaded: file_helper
INFO - 2020-11-09 08:55:59 --> Helper loaded: form_helper
INFO - 2020-11-09 08:55:59 --> Helper loaded: my_helper
INFO - 2020-11-09 08:55:59 --> Database Driver Class Initialized
DEBUG - 2020-11-09 08:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 08:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 08:55:59 --> Controller Class Initialized
DEBUG - 2020-11-09 08:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-09 08:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 08:55:59 --> Final output sent to browser
DEBUG - 2020-11-09 08:55:59 --> Total execution time: 0.2844
INFO - 2020-11-09 09:24:55 --> Config Class Initialized
INFO - 2020-11-09 09:24:55 --> Hooks Class Initialized
DEBUG - 2020-11-09 09:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-09 09:24:55 --> Utf8 Class Initialized
INFO - 2020-11-09 09:24:55 --> URI Class Initialized
INFO - 2020-11-09 09:24:55 --> Router Class Initialized
INFO - 2020-11-09 09:24:55 --> Output Class Initialized
INFO - 2020-11-09 09:24:55 --> Security Class Initialized
DEBUG - 2020-11-09 09:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 09:24:55 --> Input Class Initialized
INFO - 2020-11-09 09:24:55 --> Language Class Initialized
INFO - 2020-11-09 09:24:55 --> Language Class Initialized
INFO - 2020-11-09 09:24:55 --> Config Class Initialized
INFO - 2020-11-09 09:24:55 --> Loader Class Initialized
INFO - 2020-11-09 09:24:55 --> Helper loaded: url_helper
INFO - 2020-11-09 09:24:55 --> Helper loaded: file_helper
INFO - 2020-11-09 09:24:55 --> Helper loaded: form_helper
INFO - 2020-11-09 09:24:55 --> Helper loaded: my_helper
INFO - 2020-11-09 09:24:55 --> Database Driver Class Initialized
DEBUG - 2020-11-09 09:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 09:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 09:24:55 --> Controller Class Initialized
DEBUG - 2020-11-09 09:24:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-11-09 09:24:55 --> Final output sent to browser
DEBUG - 2020-11-09 09:24:55 --> Total execution time: 0.2342
INFO - 2020-11-09 09:25:43 --> Config Class Initialized
INFO - 2020-11-09 09:25:43 --> Hooks Class Initialized
DEBUG - 2020-11-09 09:25:43 --> UTF-8 Support Enabled
INFO - 2020-11-09 09:25:43 --> Utf8 Class Initialized
INFO - 2020-11-09 09:25:43 --> URI Class Initialized
INFO - 2020-11-09 09:25:43 --> Router Class Initialized
INFO - 2020-11-09 09:25:43 --> Output Class Initialized
INFO - 2020-11-09 09:25:43 --> Security Class Initialized
DEBUG - 2020-11-09 09:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 09:25:43 --> Input Class Initialized
INFO - 2020-11-09 09:25:43 --> Language Class Initialized
INFO - 2020-11-09 09:25:43 --> Language Class Initialized
INFO - 2020-11-09 09:25:43 --> Config Class Initialized
INFO - 2020-11-09 09:25:43 --> Loader Class Initialized
INFO - 2020-11-09 09:25:43 --> Helper loaded: url_helper
INFO - 2020-11-09 09:25:43 --> Helper loaded: file_helper
INFO - 2020-11-09 09:25:43 --> Helper loaded: form_helper
INFO - 2020-11-09 09:25:43 --> Helper loaded: my_helper
INFO - 2020-11-09 09:25:43 --> Database Driver Class Initialized
DEBUG - 2020-11-09 09:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 09:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 09:25:43 --> Controller Class Initialized
DEBUG - 2020-11-09 09:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-09 09:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 09:25:43 --> Final output sent to browser
DEBUG - 2020-11-09 09:25:43 --> Total execution time: 0.2438
INFO - 2020-11-09 09:26:27 --> Config Class Initialized
INFO - 2020-11-09 09:26:27 --> Hooks Class Initialized
DEBUG - 2020-11-09 09:26:27 --> UTF-8 Support Enabled
INFO - 2020-11-09 09:26:27 --> Utf8 Class Initialized
INFO - 2020-11-09 09:26:27 --> URI Class Initialized
INFO - 2020-11-09 09:26:27 --> Router Class Initialized
INFO - 2020-11-09 09:26:27 --> Output Class Initialized
INFO - 2020-11-09 09:26:27 --> Security Class Initialized
DEBUG - 2020-11-09 09:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 09:26:27 --> Input Class Initialized
INFO - 2020-11-09 09:26:27 --> Language Class Initialized
INFO - 2020-11-09 09:26:27 --> Language Class Initialized
INFO - 2020-11-09 09:26:27 --> Config Class Initialized
INFO - 2020-11-09 09:26:27 --> Loader Class Initialized
INFO - 2020-11-09 09:26:27 --> Helper loaded: url_helper
INFO - 2020-11-09 09:26:27 --> Helper loaded: file_helper
INFO - 2020-11-09 09:26:27 --> Helper loaded: form_helper
INFO - 2020-11-09 09:26:27 --> Helper loaded: my_helper
INFO - 2020-11-09 09:26:27 --> Database Driver Class Initialized
DEBUG - 2020-11-09 09:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 09:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 09:26:27 --> Controller Class Initialized
DEBUG - 2020-11-09 09:26:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-09 09:26:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-09 09:26:27 --> Final output sent to browser
DEBUG - 2020-11-09 09:26:27 --> Total execution time: 0.2935
INFO - 2020-11-09 09:26:28 --> Config Class Initialized
INFO - 2020-11-09 09:26:28 --> Hooks Class Initialized
DEBUG - 2020-11-09 09:26:28 --> UTF-8 Support Enabled
INFO - 2020-11-09 09:26:28 --> Utf8 Class Initialized
INFO - 2020-11-09 09:26:28 --> URI Class Initialized
INFO - 2020-11-09 09:26:28 --> Router Class Initialized
INFO - 2020-11-09 09:26:28 --> Output Class Initialized
INFO - 2020-11-09 09:26:28 --> Security Class Initialized
DEBUG - 2020-11-09 09:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 09:26:28 --> Input Class Initialized
INFO - 2020-11-09 09:26:28 --> Language Class Initialized
INFO - 2020-11-09 09:26:28 --> Language Class Initialized
INFO - 2020-11-09 09:26:28 --> Config Class Initialized
INFO - 2020-11-09 09:26:28 --> Loader Class Initialized
INFO - 2020-11-09 09:26:28 --> Helper loaded: url_helper
INFO - 2020-11-09 09:26:28 --> Helper loaded: file_helper
INFO - 2020-11-09 09:26:28 --> Helper loaded: form_helper
INFO - 2020-11-09 09:26:28 --> Helper loaded: my_helper
INFO - 2020-11-09 09:26:28 --> Database Driver Class Initialized
DEBUG - 2020-11-09 09:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-09 09:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 09:26:28 --> Controller Class Initialized
DEBUG - 2020-11-09 09:26:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-11-09 09:26:28 --> Final output sent to browser
DEBUG - 2020-11-09 09:26:28 --> Total execution time: 0.2437
