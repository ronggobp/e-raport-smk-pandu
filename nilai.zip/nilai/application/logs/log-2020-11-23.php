<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-23 01:30:18 --> Config Class Initialized
INFO - 2020-11-23 01:30:18 --> Hooks Class Initialized
DEBUG - 2020-11-23 01:30:18 --> UTF-8 Support Enabled
INFO - 2020-11-23 01:30:18 --> Utf8 Class Initialized
INFO - 2020-11-23 01:30:18 --> URI Class Initialized
DEBUG - 2020-11-23 01:30:18 --> No URI present. Default controller set.
INFO - 2020-11-23 01:30:18 --> Router Class Initialized
INFO - 2020-11-23 01:30:18 --> Output Class Initialized
INFO - 2020-11-23 01:30:18 --> Security Class Initialized
DEBUG - 2020-11-23 01:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 01:30:18 --> Input Class Initialized
INFO - 2020-11-23 01:30:18 --> Language Class Initialized
INFO - 2020-11-23 01:30:18 --> Language Class Initialized
INFO - 2020-11-23 01:30:19 --> Config Class Initialized
INFO - 2020-11-23 01:30:19 --> Loader Class Initialized
INFO - 2020-11-23 01:30:19 --> Helper loaded: url_helper
INFO - 2020-11-23 01:30:19 --> Helper loaded: file_helper
INFO - 2020-11-23 01:30:19 --> Helper loaded: form_helper
INFO - 2020-11-23 01:30:19 --> Helper loaded: my_helper
INFO - 2020-11-23 01:30:19 --> Database Driver Class Initialized
DEBUG - 2020-11-23 01:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 01:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 01:30:19 --> Controller Class Initialized
INFO - 2020-11-23 01:30:19 --> Config Class Initialized
INFO - 2020-11-23 01:30:19 --> Hooks Class Initialized
DEBUG - 2020-11-23 01:30:19 --> UTF-8 Support Enabled
INFO - 2020-11-23 01:30:19 --> Utf8 Class Initialized
INFO - 2020-11-23 01:30:19 --> URI Class Initialized
INFO - 2020-11-23 01:30:19 --> Router Class Initialized
INFO - 2020-11-23 01:30:19 --> Output Class Initialized
INFO - 2020-11-23 01:30:19 --> Security Class Initialized
DEBUG - 2020-11-23 01:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 01:30:19 --> Input Class Initialized
INFO - 2020-11-23 01:30:19 --> Language Class Initialized
INFO - 2020-11-23 01:30:19 --> Language Class Initialized
INFO - 2020-11-23 01:30:19 --> Config Class Initialized
INFO - 2020-11-23 01:30:19 --> Loader Class Initialized
INFO - 2020-11-23 01:30:19 --> Helper loaded: url_helper
INFO - 2020-11-23 01:30:19 --> Helper loaded: file_helper
INFO - 2020-11-23 01:30:19 --> Helper loaded: form_helper
INFO - 2020-11-23 01:30:19 --> Helper loaded: my_helper
INFO - 2020-11-23 01:30:19 --> Database Driver Class Initialized
DEBUG - 2020-11-23 01:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 01:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 01:30:19 --> Controller Class Initialized
DEBUG - 2020-11-23 01:30:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 01:30:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 01:30:19 --> Final output sent to browser
DEBUG - 2020-11-23 01:30:19 --> Total execution time: 0.1868
INFO - 2020-11-23 01:30:27 --> Config Class Initialized
INFO - 2020-11-23 01:30:27 --> Hooks Class Initialized
DEBUG - 2020-11-23 01:30:27 --> UTF-8 Support Enabled
INFO - 2020-11-23 01:30:27 --> Utf8 Class Initialized
INFO - 2020-11-23 01:30:27 --> URI Class Initialized
INFO - 2020-11-23 01:30:27 --> Router Class Initialized
INFO - 2020-11-23 01:30:27 --> Output Class Initialized
INFO - 2020-11-23 01:30:27 --> Security Class Initialized
DEBUG - 2020-11-23 01:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 01:30:27 --> Input Class Initialized
INFO - 2020-11-23 01:30:27 --> Language Class Initialized
INFO - 2020-11-23 01:30:27 --> Language Class Initialized
INFO - 2020-11-23 01:30:27 --> Config Class Initialized
INFO - 2020-11-23 01:30:27 --> Loader Class Initialized
INFO - 2020-11-23 01:30:27 --> Helper loaded: url_helper
INFO - 2020-11-23 01:30:27 --> Helper loaded: file_helper
INFO - 2020-11-23 01:30:27 --> Helper loaded: form_helper
INFO - 2020-11-23 01:30:27 --> Helper loaded: my_helper
INFO - 2020-11-23 01:30:27 --> Database Driver Class Initialized
DEBUG - 2020-11-23 01:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 01:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 01:30:27 --> Controller Class Initialized
INFO - 2020-11-23 01:30:27 --> Helper loaded: cookie_helper
INFO - 2020-11-23 01:30:27 --> Final output sent to browser
DEBUG - 2020-11-23 01:30:27 --> Total execution time: 0.2038
INFO - 2020-11-23 01:30:28 --> Config Class Initialized
INFO - 2020-11-23 01:30:28 --> Hooks Class Initialized
DEBUG - 2020-11-23 01:30:28 --> UTF-8 Support Enabled
INFO - 2020-11-23 01:30:28 --> Utf8 Class Initialized
INFO - 2020-11-23 01:30:28 --> URI Class Initialized
INFO - 2020-11-23 01:30:28 --> Router Class Initialized
INFO - 2020-11-23 01:30:28 --> Output Class Initialized
INFO - 2020-11-23 01:30:28 --> Security Class Initialized
DEBUG - 2020-11-23 01:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 01:30:28 --> Input Class Initialized
INFO - 2020-11-23 01:30:28 --> Language Class Initialized
INFO - 2020-11-23 01:30:28 --> Language Class Initialized
INFO - 2020-11-23 01:30:28 --> Config Class Initialized
INFO - 2020-11-23 01:30:28 --> Loader Class Initialized
INFO - 2020-11-23 01:30:28 --> Helper loaded: url_helper
INFO - 2020-11-23 01:30:28 --> Helper loaded: file_helper
INFO - 2020-11-23 01:30:28 --> Helper loaded: form_helper
INFO - 2020-11-23 01:30:28 --> Helper loaded: my_helper
INFO - 2020-11-23 01:30:28 --> Database Driver Class Initialized
DEBUG - 2020-11-23 01:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 01:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 01:30:28 --> Controller Class Initialized
DEBUG - 2020-11-23 01:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 01:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 01:30:28 --> Final output sent to browser
DEBUG - 2020-11-23 01:30:28 --> Total execution time: 0.3228
INFO - 2020-11-23 01:42:00 --> Config Class Initialized
INFO - 2020-11-23 01:42:00 --> Hooks Class Initialized
DEBUG - 2020-11-23 01:42:00 --> UTF-8 Support Enabled
INFO - 2020-11-23 01:42:00 --> Utf8 Class Initialized
INFO - 2020-11-23 01:42:00 --> URI Class Initialized
INFO - 2020-11-23 01:42:00 --> Router Class Initialized
INFO - 2020-11-23 01:42:00 --> Output Class Initialized
INFO - 2020-11-23 01:42:00 --> Security Class Initialized
DEBUG - 2020-11-23 01:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 01:42:00 --> Input Class Initialized
INFO - 2020-11-23 01:42:00 --> Language Class Initialized
INFO - 2020-11-23 01:42:00 --> Language Class Initialized
INFO - 2020-11-23 01:42:00 --> Config Class Initialized
INFO - 2020-11-23 01:42:00 --> Loader Class Initialized
INFO - 2020-11-23 01:42:00 --> Helper loaded: url_helper
INFO - 2020-11-23 01:42:00 --> Helper loaded: file_helper
INFO - 2020-11-23 01:42:00 --> Helper loaded: form_helper
INFO - 2020-11-23 01:42:00 --> Helper loaded: my_helper
INFO - 2020-11-23 01:42:00 --> Database Driver Class Initialized
DEBUG - 2020-11-23 01:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 01:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 01:42:00 --> Controller Class Initialized
DEBUG - 2020-11-23 01:42:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-23 01:42:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 01:42:00 --> Final output sent to browser
DEBUG - 2020-11-23 01:42:00 --> Total execution time: 0.2631
INFO - 2020-11-23 02:10:27 --> Config Class Initialized
INFO - 2020-11-23 02:10:27 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:27 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:27 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:27 --> URI Class Initialized
INFO - 2020-11-23 02:10:27 --> Router Class Initialized
INFO - 2020-11-23 02:10:27 --> Output Class Initialized
INFO - 2020-11-23 02:10:27 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:27 --> Input Class Initialized
INFO - 2020-11-23 02:10:27 --> Language Class Initialized
INFO - 2020-11-23 02:10:27 --> Language Class Initialized
INFO - 2020-11-23 02:10:27 --> Config Class Initialized
INFO - 2020-11-23 02:10:27 --> Loader Class Initialized
INFO - 2020-11-23 02:10:27 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:27 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:27 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:27 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:27 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:27 --> Controller Class Initialized
INFO - 2020-11-23 02:10:27 --> Helper loaded: cookie_helper
INFO - 2020-11-23 02:10:27 --> Config Class Initialized
INFO - 2020-11-23 02:10:27 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:27 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:27 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:27 --> URI Class Initialized
INFO - 2020-11-23 02:10:27 --> Router Class Initialized
INFO - 2020-11-23 02:10:27 --> Output Class Initialized
INFO - 2020-11-23 02:10:27 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:27 --> Input Class Initialized
INFO - 2020-11-23 02:10:27 --> Language Class Initialized
INFO - 2020-11-23 02:10:27 --> Language Class Initialized
INFO - 2020-11-23 02:10:27 --> Config Class Initialized
INFO - 2020-11-23 02:10:27 --> Loader Class Initialized
INFO - 2020-11-23 02:10:27 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:27 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:27 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:27 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:27 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:27 --> Controller Class Initialized
DEBUG - 2020-11-23 02:10:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 02:10:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:10:27 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:27 --> Total execution time: 0.1596
INFO - 2020-11-23 02:10:33 --> Config Class Initialized
INFO - 2020-11-23 02:10:33 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:33 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:33 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:33 --> URI Class Initialized
INFO - 2020-11-23 02:10:33 --> Router Class Initialized
INFO - 2020-11-23 02:10:33 --> Output Class Initialized
INFO - 2020-11-23 02:10:33 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:33 --> Input Class Initialized
INFO - 2020-11-23 02:10:33 --> Language Class Initialized
INFO - 2020-11-23 02:10:33 --> Language Class Initialized
INFO - 2020-11-23 02:10:33 --> Config Class Initialized
INFO - 2020-11-23 02:10:33 --> Loader Class Initialized
INFO - 2020-11-23 02:10:33 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:33 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:33 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:33 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:33 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:33 --> Controller Class Initialized
INFO - 2020-11-23 02:10:33 --> Helper loaded: cookie_helper
INFO - 2020-11-23 02:10:33 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:33 --> Total execution time: 0.1716
INFO - 2020-11-23 02:10:34 --> Config Class Initialized
INFO - 2020-11-23 02:10:34 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:34 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:34 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:34 --> URI Class Initialized
INFO - 2020-11-23 02:10:34 --> Router Class Initialized
INFO - 2020-11-23 02:10:34 --> Output Class Initialized
INFO - 2020-11-23 02:10:34 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:34 --> Input Class Initialized
INFO - 2020-11-23 02:10:34 --> Language Class Initialized
INFO - 2020-11-23 02:10:34 --> Language Class Initialized
INFO - 2020-11-23 02:10:34 --> Config Class Initialized
INFO - 2020-11-23 02:10:34 --> Loader Class Initialized
INFO - 2020-11-23 02:10:34 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:34 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:34 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:34 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:34 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:34 --> Controller Class Initialized
DEBUG - 2020-11-23 02:10:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 02:10:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:10:34 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:34 --> Total execution time: 0.2031
INFO - 2020-11-23 02:10:36 --> Config Class Initialized
INFO - 2020-11-23 02:10:36 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:36 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:36 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:36 --> URI Class Initialized
INFO - 2020-11-23 02:10:36 --> Router Class Initialized
INFO - 2020-11-23 02:10:36 --> Output Class Initialized
INFO - 2020-11-23 02:10:36 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:36 --> Input Class Initialized
INFO - 2020-11-23 02:10:36 --> Language Class Initialized
INFO - 2020-11-23 02:10:36 --> Language Class Initialized
INFO - 2020-11-23 02:10:36 --> Config Class Initialized
INFO - 2020-11-23 02:10:36 --> Loader Class Initialized
INFO - 2020-11-23 02:10:36 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:36 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:36 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:36 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:36 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:36 --> Controller Class Initialized
DEBUG - 2020-11-23 02:10:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-23 02:10:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:10:36 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:36 --> Total execution time: 0.1932
INFO - 2020-11-23 02:10:36 --> Config Class Initialized
INFO - 2020-11-23 02:10:36 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:36 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:36 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:36 --> URI Class Initialized
INFO - 2020-11-23 02:10:36 --> Router Class Initialized
INFO - 2020-11-23 02:10:36 --> Output Class Initialized
INFO - 2020-11-23 02:10:36 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:36 --> Input Class Initialized
INFO - 2020-11-23 02:10:36 --> Language Class Initialized
INFO - 2020-11-23 02:10:36 --> Language Class Initialized
INFO - 2020-11-23 02:10:36 --> Config Class Initialized
INFO - 2020-11-23 02:10:36 --> Loader Class Initialized
INFO - 2020-11-23 02:10:36 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:36 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:36 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:36 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:36 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:36 --> Controller Class Initialized
INFO - 2020-11-23 02:10:37 --> Config Class Initialized
INFO - 2020-11-23 02:10:37 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:37 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:37 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:37 --> URI Class Initialized
INFO - 2020-11-23 02:10:37 --> Router Class Initialized
INFO - 2020-11-23 02:10:37 --> Output Class Initialized
INFO - 2020-11-23 02:10:37 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:37 --> Input Class Initialized
INFO - 2020-11-23 02:10:37 --> Language Class Initialized
INFO - 2020-11-23 02:10:38 --> Language Class Initialized
INFO - 2020-11-23 02:10:38 --> Config Class Initialized
INFO - 2020-11-23 02:10:38 --> Loader Class Initialized
INFO - 2020-11-23 02:10:38 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:38 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:38 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:38 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:38 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:38 --> Controller Class Initialized
DEBUG - 2020-11-23 02:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-23 02:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:10:38 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:38 --> Total execution time: 0.2294
INFO - 2020-11-23 02:10:38 --> Config Class Initialized
INFO - 2020-11-23 02:10:38 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:38 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:38 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:38 --> URI Class Initialized
INFO - 2020-11-23 02:10:38 --> Router Class Initialized
INFO - 2020-11-23 02:10:38 --> Output Class Initialized
INFO - 2020-11-23 02:10:38 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:38 --> Input Class Initialized
INFO - 2020-11-23 02:10:38 --> Language Class Initialized
INFO - 2020-11-23 02:10:38 --> Language Class Initialized
INFO - 2020-11-23 02:10:38 --> Config Class Initialized
INFO - 2020-11-23 02:10:38 --> Loader Class Initialized
INFO - 2020-11-23 02:10:38 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:38 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:38 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:38 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:38 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:38 --> Controller Class Initialized
INFO - 2020-11-23 02:10:40 --> Config Class Initialized
INFO - 2020-11-23 02:10:40 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:40 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:40 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:40 --> URI Class Initialized
INFO - 2020-11-23 02:10:40 --> Router Class Initialized
INFO - 2020-11-23 02:10:40 --> Output Class Initialized
INFO - 2020-11-23 02:10:40 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:40 --> Input Class Initialized
INFO - 2020-11-23 02:10:40 --> Language Class Initialized
INFO - 2020-11-23 02:10:40 --> Language Class Initialized
INFO - 2020-11-23 02:10:40 --> Config Class Initialized
INFO - 2020-11-23 02:10:40 --> Loader Class Initialized
INFO - 2020-11-23 02:10:40 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:40 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:40 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:40 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:40 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:40 --> Controller Class Initialized
INFO - 2020-11-23 02:10:40 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:40 --> Total execution time: 0.1692
INFO - 2020-11-23 02:10:45 --> Config Class Initialized
INFO - 2020-11-23 02:10:45 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:45 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:45 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:45 --> URI Class Initialized
INFO - 2020-11-23 02:10:45 --> Router Class Initialized
INFO - 2020-11-23 02:10:45 --> Output Class Initialized
INFO - 2020-11-23 02:10:45 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:45 --> Input Class Initialized
INFO - 2020-11-23 02:10:45 --> Language Class Initialized
INFO - 2020-11-23 02:10:45 --> Language Class Initialized
INFO - 2020-11-23 02:10:45 --> Config Class Initialized
INFO - 2020-11-23 02:10:46 --> Loader Class Initialized
INFO - 2020-11-23 02:10:46 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:46 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:46 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:46 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:46 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:46 --> Controller Class Initialized
INFO - 2020-11-23 02:10:46 --> Helper loaded: cookie_helper
INFO - 2020-11-23 02:10:46 --> Config Class Initialized
INFO - 2020-11-23 02:10:46 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:46 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:46 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:46 --> URI Class Initialized
INFO - 2020-11-23 02:10:46 --> Router Class Initialized
INFO - 2020-11-23 02:10:46 --> Output Class Initialized
INFO - 2020-11-23 02:10:46 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:46 --> Input Class Initialized
INFO - 2020-11-23 02:10:46 --> Language Class Initialized
INFO - 2020-11-23 02:10:46 --> Language Class Initialized
INFO - 2020-11-23 02:10:46 --> Config Class Initialized
INFO - 2020-11-23 02:10:46 --> Loader Class Initialized
INFO - 2020-11-23 02:10:46 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:46 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:46 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:46 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:46 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:46 --> Controller Class Initialized
DEBUG - 2020-11-23 02:10:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 02:10:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:10:46 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:46 --> Total execution time: 0.1804
INFO - 2020-11-23 02:10:52 --> Config Class Initialized
INFO - 2020-11-23 02:10:52 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:52 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:52 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:52 --> URI Class Initialized
INFO - 2020-11-23 02:10:52 --> Router Class Initialized
INFO - 2020-11-23 02:10:52 --> Output Class Initialized
INFO - 2020-11-23 02:10:52 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:52 --> Input Class Initialized
INFO - 2020-11-23 02:10:52 --> Language Class Initialized
INFO - 2020-11-23 02:10:52 --> Language Class Initialized
INFO - 2020-11-23 02:10:52 --> Config Class Initialized
INFO - 2020-11-23 02:10:52 --> Loader Class Initialized
INFO - 2020-11-23 02:10:52 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:52 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:52 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:52 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:52 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:52 --> Controller Class Initialized
INFO - 2020-11-23 02:10:52 --> Helper loaded: cookie_helper
INFO - 2020-11-23 02:10:52 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:52 --> Total execution time: 0.1774
INFO - 2020-11-23 02:10:53 --> Config Class Initialized
INFO - 2020-11-23 02:10:53 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:10:53 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:10:53 --> Utf8 Class Initialized
INFO - 2020-11-23 02:10:53 --> URI Class Initialized
INFO - 2020-11-23 02:10:53 --> Router Class Initialized
INFO - 2020-11-23 02:10:53 --> Output Class Initialized
INFO - 2020-11-23 02:10:53 --> Security Class Initialized
DEBUG - 2020-11-23 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:10:53 --> Input Class Initialized
INFO - 2020-11-23 02:10:53 --> Language Class Initialized
INFO - 2020-11-23 02:10:53 --> Language Class Initialized
INFO - 2020-11-23 02:10:53 --> Config Class Initialized
INFO - 2020-11-23 02:10:53 --> Loader Class Initialized
INFO - 2020-11-23 02:10:53 --> Helper loaded: url_helper
INFO - 2020-11-23 02:10:53 --> Helper loaded: file_helper
INFO - 2020-11-23 02:10:53 --> Helper loaded: form_helper
INFO - 2020-11-23 02:10:53 --> Helper loaded: my_helper
INFO - 2020-11-23 02:10:53 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:10:53 --> Controller Class Initialized
DEBUG - 2020-11-23 02:10:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 02:10:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:10:53 --> Final output sent to browser
DEBUG - 2020-11-23 02:10:53 --> Total execution time: 0.2114
INFO - 2020-11-23 02:36:52 --> Config Class Initialized
INFO - 2020-11-23 02:36:52 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:36:52 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:36:52 --> Utf8 Class Initialized
INFO - 2020-11-23 02:36:52 --> URI Class Initialized
INFO - 2020-11-23 02:36:52 --> Router Class Initialized
INFO - 2020-11-23 02:36:52 --> Output Class Initialized
INFO - 2020-11-23 02:36:52 --> Security Class Initialized
DEBUG - 2020-11-23 02:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:36:52 --> Input Class Initialized
INFO - 2020-11-23 02:36:52 --> Language Class Initialized
INFO - 2020-11-23 02:36:52 --> Language Class Initialized
INFO - 2020-11-23 02:36:52 --> Config Class Initialized
INFO - 2020-11-23 02:36:52 --> Loader Class Initialized
INFO - 2020-11-23 02:36:52 --> Helper loaded: url_helper
INFO - 2020-11-23 02:36:52 --> Helper loaded: file_helper
INFO - 2020-11-23 02:36:52 --> Helper loaded: form_helper
INFO - 2020-11-23 02:36:52 --> Helper loaded: my_helper
INFO - 2020-11-23 02:36:52 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:36:53 --> Controller Class Initialized
INFO - 2020-11-23 02:36:53 --> Helper loaded: cookie_helper
INFO - 2020-11-23 02:36:53 --> Config Class Initialized
INFO - 2020-11-23 02:36:53 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:36:53 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:36:53 --> Utf8 Class Initialized
INFO - 2020-11-23 02:36:53 --> URI Class Initialized
INFO - 2020-11-23 02:36:53 --> Router Class Initialized
INFO - 2020-11-23 02:36:53 --> Output Class Initialized
INFO - 2020-11-23 02:36:53 --> Security Class Initialized
DEBUG - 2020-11-23 02:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:36:53 --> Input Class Initialized
INFO - 2020-11-23 02:36:53 --> Language Class Initialized
INFO - 2020-11-23 02:36:53 --> Language Class Initialized
INFO - 2020-11-23 02:36:53 --> Config Class Initialized
INFO - 2020-11-23 02:36:53 --> Loader Class Initialized
INFO - 2020-11-23 02:36:53 --> Helper loaded: url_helper
INFO - 2020-11-23 02:36:53 --> Helper loaded: file_helper
INFO - 2020-11-23 02:36:53 --> Helper loaded: form_helper
INFO - 2020-11-23 02:36:53 --> Helper loaded: my_helper
INFO - 2020-11-23 02:36:53 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:36:53 --> Controller Class Initialized
DEBUG - 2020-11-23 02:36:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 02:36:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:36:53 --> Final output sent to browser
DEBUG - 2020-11-23 02:36:53 --> Total execution time: 0.1702
INFO - 2020-11-23 02:36:59 --> Config Class Initialized
INFO - 2020-11-23 02:36:59 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:36:59 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:36:59 --> Utf8 Class Initialized
INFO - 2020-11-23 02:36:59 --> URI Class Initialized
INFO - 2020-11-23 02:36:59 --> Router Class Initialized
INFO - 2020-11-23 02:36:59 --> Output Class Initialized
INFO - 2020-11-23 02:36:59 --> Security Class Initialized
DEBUG - 2020-11-23 02:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:36:59 --> Input Class Initialized
INFO - 2020-11-23 02:36:59 --> Language Class Initialized
INFO - 2020-11-23 02:36:59 --> Language Class Initialized
INFO - 2020-11-23 02:36:59 --> Config Class Initialized
INFO - 2020-11-23 02:36:59 --> Loader Class Initialized
INFO - 2020-11-23 02:36:59 --> Helper loaded: url_helper
INFO - 2020-11-23 02:36:59 --> Helper loaded: file_helper
INFO - 2020-11-23 02:36:59 --> Helper loaded: form_helper
INFO - 2020-11-23 02:36:59 --> Helper loaded: my_helper
INFO - 2020-11-23 02:36:59 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:36:59 --> Controller Class Initialized
INFO - 2020-11-23 02:36:59 --> Helper loaded: cookie_helper
INFO - 2020-11-23 02:36:59 --> Final output sent to browser
DEBUG - 2020-11-23 02:36:59 --> Total execution time: 0.1827
INFO - 2020-11-23 02:37:00 --> Config Class Initialized
INFO - 2020-11-23 02:37:00 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:37:00 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:37:00 --> Utf8 Class Initialized
INFO - 2020-11-23 02:37:00 --> URI Class Initialized
INFO - 2020-11-23 02:37:00 --> Router Class Initialized
INFO - 2020-11-23 02:37:00 --> Output Class Initialized
INFO - 2020-11-23 02:37:00 --> Security Class Initialized
DEBUG - 2020-11-23 02:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:37:00 --> Input Class Initialized
INFO - 2020-11-23 02:37:00 --> Language Class Initialized
INFO - 2020-11-23 02:37:00 --> Language Class Initialized
INFO - 2020-11-23 02:37:00 --> Config Class Initialized
INFO - 2020-11-23 02:37:00 --> Loader Class Initialized
INFO - 2020-11-23 02:37:00 --> Helper loaded: url_helper
INFO - 2020-11-23 02:37:00 --> Helper loaded: file_helper
INFO - 2020-11-23 02:37:00 --> Helper loaded: form_helper
INFO - 2020-11-23 02:37:00 --> Helper loaded: my_helper
INFO - 2020-11-23 02:37:00 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:37:00 --> Controller Class Initialized
DEBUG - 2020-11-23 02:37:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 02:37:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:37:00 --> Final output sent to browser
DEBUG - 2020-11-23 02:37:00 --> Total execution time: 0.2143
INFO - 2020-11-23 02:37:02 --> Config Class Initialized
INFO - 2020-11-23 02:37:02 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:37:02 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:37:02 --> Utf8 Class Initialized
INFO - 2020-11-23 02:37:02 --> URI Class Initialized
INFO - 2020-11-23 02:37:02 --> Router Class Initialized
INFO - 2020-11-23 02:37:02 --> Output Class Initialized
INFO - 2020-11-23 02:37:02 --> Security Class Initialized
DEBUG - 2020-11-23 02:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:37:02 --> Input Class Initialized
INFO - 2020-11-23 02:37:02 --> Language Class Initialized
INFO - 2020-11-23 02:37:02 --> Language Class Initialized
INFO - 2020-11-23 02:37:02 --> Config Class Initialized
INFO - 2020-11-23 02:37:02 --> Loader Class Initialized
INFO - 2020-11-23 02:37:02 --> Helper loaded: url_helper
INFO - 2020-11-23 02:37:02 --> Helper loaded: file_helper
INFO - 2020-11-23 02:37:02 --> Helper loaded: form_helper
INFO - 2020-11-23 02:37:02 --> Helper loaded: my_helper
INFO - 2020-11-23 02:37:02 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:37:02 --> Controller Class Initialized
DEBUG - 2020-11-23 02:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-23 02:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:37:02 --> Final output sent to browser
DEBUG - 2020-11-23 02:37:02 --> Total execution time: 0.1872
INFO - 2020-11-23 02:37:02 --> Config Class Initialized
INFO - 2020-11-23 02:37:02 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:37:02 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:37:02 --> Utf8 Class Initialized
INFO - 2020-11-23 02:37:02 --> URI Class Initialized
INFO - 2020-11-23 02:37:02 --> Router Class Initialized
INFO - 2020-11-23 02:37:02 --> Output Class Initialized
INFO - 2020-11-23 02:37:02 --> Security Class Initialized
DEBUG - 2020-11-23 02:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:37:02 --> Input Class Initialized
INFO - 2020-11-23 02:37:02 --> Language Class Initialized
INFO - 2020-11-23 02:37:02 --> Language Class Initialized
INFO - 2020-11-23 02:37:02 --> Config Class Initialized
INFO - 2020-11-23 02:37:02 --> Loader Class Initialized
INFO - 2020-11-23 02:37:02 --> Helper loaded: url_helper
INFO - 2020-11-23 02:37:02 --> Helper loaded: file_helper
INFO - 2020-11-23 02:37:02 --> Helper loaded: form_helper
INFO - 2020-11-23 02:37:02 --> Helper loaded: my_helper
INFO - 2020-11-23 02:37:02 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:37:02 --> Controller Class Initialized
INFO - 2020-11-23 02:37:03 --> Config Class Initialized
INFO - 2020-11-23 02:37:03 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:37:03 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:37:03 --> Utf8 Class Initialized
INFO - 2020-11-23 02:37:03 --> URI Class Initialized
INFO - 2020-11-23 02:37:03 --> Router Class Initialized
INFO - 2020-11-23 02:37:03 --> Output Class Initialized
INFO - 2020-11-23 02:37:03 --> Security Class Initialized
DEBUG - 2020-11-23 02:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:37:04 --> Input Class Initialized
INFO - 2020-11-23 02:37:04 --> Language Class Initialized
INFO - 2020-11-23 02:37:04 --> Language Class Initialized
INFO - 2020-11-23 02:37:04 --> Config Class Initialized
INFO - 2020-11-23 02:37:04 --> Loader Class Initialized
INFO - 2020-11-23 02:37:04 --> Helper loaded: url_helper
INFO - 2020-11-23 02:37:04 --> Helper loaded: file_helper
INFO - 2020-11-23 02:37:04 --> Helper loaded: form_helper
INFO - 2020-11-23 02:37:04 --> Helper loaded: my_helper
INFO - 2020-11-23 02:37:04 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:37:04 --> Controller Class Initialized
DEBUG - 2020-11-23 02:37:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-23 02:37:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:37:04 --> Final output sent to browser
DEBUG - 2020-11-23 02:37:04 --> Total execution time: 0.2057
INFO - 2020-11-23 02:37:04 --> Config Class Initialized
INFO - 2020-11-23 02:37:04 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:37:04 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:37:04 --> Utf8 Class Initialized
INFO - 2020-11-23 02:37:04 --> URI Class Initialized
INFO - 2020-11-23 02:37:04 --> Router Class Initialized
INFO - 2020-11-23 02:37:04 --> Output Class Initialized
INFO - 2020-11-23 02:37:04 --> Security Class Initialized
DEBUG - 2020-11-23 02:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:37:04 --> Input Class Initialized
INFO - 2020-11-23 02:37:04 --> Language Class Initialized
INFO - 2020-11-23 02:37:04 --> Language Class Initialized
INFO - 2020-11-23 02:37:04 --> Config Class Initialized
INFO - 2020-11-23 02:37:04 --> Loader Class Initialized
INFO - 2020-11-23 02:37:04 --> Helper loaded: url_helper
INFO - 2020-11-23 02:37:04 --> Helper loaded: file_helper
INFO - 2020-11-23 02:37:04 --> Helper loaded: form_helper
INFO - 2020-11-23 02:37:04 --> Helper loaded: my_helper
INFO - 2020-11-23 02:37:04 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:37:04 --> Controller Class Initialized
INFO - 2020-11-23 02:37:05 --> Config Class Initialized
INFO - 2020-11-23 02:37:05 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:37:05 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:37:05 --> Utf8 Class Initialized
INFO - 2020-11-23 02:37:05 --> URI Class Initialized
INFO - 2020-11-23 02:37:05 --> Router Class Initialized
INFO - 2020-11-23 02:37:05 --> Output Class Initialized
INFO - 2020-11-23 02:37:05 --> Security Class Initialized
DEBUG - 2020-11-23 02:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:37:05 --> Input Class Initialized
INFO - 2020-11-23 02:37:05 --> Language Class Initialized
INFO - 2020-11-23 02:37:05 --> Language Class Initialized
INFO - 2020-11-23 02:37:05 --> Config Class Initialized
INFO - 2020-11-23 02:37:05 --> Loader Class Initialized
INFO - 2020-11-23 02:37:05 --> Helper loaded: url_helper
INFO - 2020-11-23 02:37:05 --> Helper loaded: file_helper
INFO - 2020-11-23 02:37:05 --> Helper loaded: form_helper
INFO - 2020-11-23 02:37:05 --> Helper loaded: my_helper
INFO - 2020-11-23 02:37:05 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:37:05 --> Controller Class Initialized
DEBUG - 2020-11-23 02:37:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-23 02:37:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:37:05 --> Final output sent to browser
DEBUG - 2020-11-23 02:37:05 --> Total execution time: 0.1714
INFO - 2020-11-23 02:37:05 --> Config Class Initialized
INFO - 2020-11-23 02:37:05 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:37:05 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:37:05 --> Utf8 Class Initialized
INFO - 2020-11-23 02:37:05 --> URI Class Initialized
INFO - 2020-11-23 02:37:05 --> Router Class Initialized
INFO - 2020-11-23 02:37:05 --> Output Class Initialized
INFO - 2020-11-23 02:37:05 --> Security Class Initialized
DEBUG - 2020-11-23 02:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:37:05 --> Input Class Initialized
INFO - 2020-11-23 02:37:05 --> Language Class Initialized
INFO - 2020-11-23 02:37:05 --> Language Class Initialized
INFO - 2020-11-23 02:37:05 --> Config Class Initialized
INFO - 2020-11-23 02:37:05 --> Loader Class Initialized
INFO - 2020-11-23 02:37:05 --> Helper loaded: url_helper
INFO - 2020-11-23 02:37:05 --> Helper loaded: file_helper
INFO - 2020-11-23 02:37:05 --> Helper loaded: form_helper
INFO - 2020-11-23 02:37:05 --> Helper loaded: my_helper
INFO - 2020-11-23 02:37:05 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:37:05 --> Controller Class Initialized
INFO - 2020-11-23 02:37:06 --> Config Class Initialized
INFO - 2020-11-23 02:37:06 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:37:06 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:37:06 --> Utf8 Class Initialized
INFO - 2020-11-23 02:37:06 --> URI Class Initialized
INFO - 2020-11-23 02:37:06 --> Router Class Initialized
INFO - 2020-11-23 02:37:06 --> Output Class Initialized
INFO - 2020-11-23 02:37:06 --> Security Class Initialized
DEBUG - 2020-11-23 02:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:37:06 --> Input Class Initialized
INFO - 2020-11-23 02:37:06 --> Language Class Initialized
INFO - 2020-11-23 02:37:06 --> Language Class Initialized
INFO - 2020-11-23 02:37:06 --> Config Class Initialized
INFO - 2020-11-23 02:37:06 --> Loader Class Initialized
INFO - 2020-11-23 02:37:06 --> Helper loaded: url_helper
INFO - 2020-11-23 02:37:06 --> Helper loaded: file_helper
INFO - 2020-11-23 02:37:06 --> Helper loaded: form_helper
INFO - 2020-11-23 02:37:06 --> Helper loaded: my_helper
INFO - 2020-11-23 02:37:06 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:37:06 --> Controller Class Initialized
INFO - 2020-11-23 02:37:06 --> Final output sent to browser
DEBUG - 2020-11-23 02:37:06 --> Total execution time: 0.1744
INFO - 2020-11-23 02:44:42 --> Config Class Initialized
INFO - 2020-11-23 02:44:42 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:44:42 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:44:42 --> Utf8 Class Initialized
INFO - 2020-11-23 02:44:42 --> URI Class Initialized
INFO - 2020-11-23 02:44:42 --> Router Class Initialized
INFO - 2020-11-23 02:44:42 --> Output Class Initialized
INFO - 2020-11-23 02:44:42 --> Security Class Initialized
DEBUG - 2020-11-23 02:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:44:42 --> Input Class Initialized
INFO - 2020-11-23 02:44:42 --> Language Class Initialized
INFO - 2020-11-23 02:44:42 --> Language Class Initialized
INFO - 2020-11-23 02:44:42 --> Config Class Initialized
INFO - 2020-11-23 02:44:42 --> Loader Class Initialized
INFO - 2020-11-23 02:44:42 --> Helper loaded: url_helper
INFO - 2020-11-23 02:44:42 --> Helper loaded: file_helper
INFO - 2020-11-23 02:44:42 --> Helper loaded: form_helper
INFO - 2020-11-23 02:44:42 --> Helper loaded: my_helper
INFO - 2020-11-23 02:44:42 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:44:42 --> Controller Class Initialized
INFO - 2020-11-23 02:44:42 --> Helper loaded: cookie_helper
INFO - 2020-11-23 02:44:42 --> Config Class Initialized
INFO - 2020-11-23 02:44:42 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:44:42 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:44:42 --> Utf8 Class Initialized
INFO - 2020-11-23 02:44:42 --> URI Class Initialized
INFO - 2020-11-23 02:44:42 --> Router Class Initialized
INFO - 2020-11-23 02:44:42 --> Output Class Initialized
INFO - 2020-11-23 02:44:42 --> Security Class Initialized
DEBUG - 2020-11-23 02:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:44:42 --> Input Class Initialized
INFO - 2020-11-23 02:44:42 --> Language Class Initialized
INFO - 2020-11-23 02:44:42 --> Language Class Initialized
INFO - 2020-11-23 02:44:42 --> Config Class Initialized
INFO - 2020-11-23 02:44:42 --> Loader Class Initialized
INFO - 2020-11-23 02:44:42 --> Helper loaded: url_helper
INFO - 2020-11-23 02:44:42 --> Helper loaded: file_helper
INFO - 2020-11-23 02:44:42 --> Helper loaded: form_helper
INFO - 2020-11-23 02:44:42 --> Helper loaded: my_helper
INFO - 2020-11-23 02:44:42 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:44:42 --> Controller Class Initialized
DEBUG - 2020-11-23 02:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 02:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:44:42 --> Final output sent to browser
DEBUG - 2020-11-23 02:44:42 --> Total execution time: 0.1770
INFO - 2020-11-23 02:44:47 --> Config Class Initialized
INFO - 2020-11-23 02:44:47 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:44:47 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:44:47 --> Utf8 Class Initialized
INFO - 2020-11-23 02:44:47 --> URI Class Initialized
INFO - 2020-11-23 02:44:47 --> Router Class Initialized
INFO - 2020-11-23 02:44:47 --> Output Class Initialized
INFO - 2020-11-23 02:44:47 --> Security Class Initialized
DEBUG - 2020-11-23 02:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:44:47 --> Input Class Initialized
INFO - 2020-11-23 02:44:47 --> Language Class Initialized
INFO - 2020-11-23 02:44:47 --> Language Class Initialized
INFO - 2020-11-23 02:44:47 --> Config Class Initialized
INFO - 2020-11-23 02:44:47 --> Loader Class Initialized
INFO - 2020-11-23 02:44:47 --> Helper loaded: url_helper
INFO - 2020-11-23 02:44:47 --> Helper loaded: file_helper
INFO - 2020-11-23 02:44:47 --> Helper loaded: form_helper
INFO - 2020-11-23 02:44:47 --> Helper loaded: my_helper
INFO - 2020-11-23 02:44:47 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:44:47 --> Controller Class Initialized
INFO - 2020-11-23 02:44:47 --> Helper loaded: cookie_helper
INFO - 2020-11-23 02:44:47 --> Final output sent to browser
DEBUG - 2020-11-23 02:44:47 --> Total execution time: 0.2050
INFO - 2020-11-23 02:44:49 --> Config Class Initialized
INFO - 2020-11-23 02:44:49 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:44:49 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:44:49 --> Utf8 Class Initialized
INFO - 2020-11-23 02:44:49 --> URI Class Initialized
INFO - 2020-11-23 02:44:49 --> Router Class Initialized
INFO - 2020-11-23 02:44:49 --> Output Class Initialized
INFO - 2020-11-23 02:44:49 --> Security Class Initialized
DEBUG - 2020-11-23 02:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:44:49 --> Input Class Initialized
INFO - 2020-11-23 02:44:49 --> Language Class Initialized
INFO - 2020-11-23 02:44:49 --> Language Class Initialized
INFO - 2020-11-23 02:44:49 --> Config Class Initialized
INFO - 2020-11-23 02:44:49 --> Loader Class Initialized
INFO - 2020-11-23 02:44:49 --> Helper loaded: url_helper
INFO - 2020-11-23 02:44:49 --> Helper loaded: file_helper
INFO - 2020-11-23 02:44:49 --> Helper loaded: form_helper
INFO - 2020-11-23 02:44:49 --> Helper loaded: my_helper
INFO - 2020-11-23 02:44:49 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:44:49 --> Controller Class Initialized
DEBUG - 2020-11-23 02:44:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 02:44:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:44:49 --> Final output sent to browser
DEBUG - 2020-11-23 02:44:49 --> Total execution time: 0.2227
INFO - 2020-11-23 02:47:49 --> Config Class Initialized
INFO - 2020-11-23 02:47:49 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:47:49 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:47:49 --> Utf8 Class Initialized
INFO - 2020-11-23 02:47:49 --> URI Class Initialized
INFO - 2020-11-23 02:47:49 --> Router Class Initialized
INFO - 2020-11-23 02:47:49 --> Output Class Initialized
INFO - 2020-11-23 02:47:49 --> Security Class Initialized
DEBUG - 2020-11-23 02:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:47:49 --> Input Class Initialized
INFO - 2020-11-23 02:47:49 --> Language Class Initialized
INFO - 2020-11-23 02:47:49 --> Language Class Initialized
INFO - 2020-11-23 02:47:49 --> Config Class Initialized
INFO - 2020-11-23 02:47:49 --> Loader Class Initialized
INFO - 2020-11-23 02:47:49 --> Helper loaded: url_helper
INFO - 2020-11-23 02:47:49 --> Helper loaded: file_helper
INFO - 2020-11-23 02:47:49 --> Helper loaded: form_helper
INFO - 2020-11-23 02:47:49 --> Helper loaded: my_helper
INFO - 2020-11-23 02:47:49 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:47:49 --> Controller Class Initialized
DEBUG - 2020-11-23 02:47:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-23 02:47:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:47:49 --> Final output sent to browser
DEBUG - 2020-11-23 02:47:49 --> Total execution time: 0.1783
INFO - 2020-11-23 02:55:06 --> Config Class Initialized
INFO - 2020-11-23 02:55:06 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:55:06 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:55:06 --> Utf8 Class Initialized
INFO - 2020-11-23 02:55:06 --> URI Class Initialized
INFO - 2020-11-23 02:55:07 --> Router Class Initialized
INFO - 2020-11-23 02:55:07 --> Output Class Initialized
INFO - 2020-11-23 02:55:07 --> Security Class Initialized
DEBUG - 2020-11-23 02:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:55:07 --> Input Class Initialized
INFO - 2020-11-23 02:55:07 --> Language Class Initialized
INFO - 2020-11-23 02:55:07 --> Language Class Initialized
INFO - 2020-11-23 02:55:07 --> Config Class Initialized
INFO - 2020-11-23 02:55:07 --> Loader Class Initialized
INFO - 2020-11-23 02:55:07 --> Helper loaded: url_helper
INFO - 2020-11-23 02:55:07 --> Helper loaded: file_helper
INFO - 2020-11-23 02:55:07 --> Helper loaded: form_helper
INFO - 2020-11-23 02:55:07 --> Helper loaded: my_helper
INFO - 2020-11-23 02:55:07 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:55:07 --> Controller Class Initialized
DEBUG - 2020-11-23 02:55:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-23 02:55:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:55:07 --> Final output sent to browser
DEBUG - 2020-11-23 02:55:07 --> Total execution time: 0.2051
INFO - 2020-11-23 02:55:09 --> Config Class Initialized
INFO - 2020-11-23 02:55:09 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:55:09 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:55:09 --> Utf8 Class Initialized
INFO - 2020-11-23 02:55:09 --> URI Class Initialized
INFO - 2020-11-23 02:55:09 --> Router Class Initialized
INFO - 2020-11-23 02:55:09 --> Output Class Initialized
INFO - 2020-11-23 02:55:09 --> Security Class Initialized
DEBUG - 2020-11-23 02:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:55:09 --> Input Class Initialized
INFO - 2020-11-23 02:55:09 --> Language Class Initialized
ERROR - 2020-11-23 02:55:09 --> 404 Page Not Found: ../modules/n_karakter/controllers/N_karakter/index
INFO - 2020-11-23 02:55:47 --> Config Class Initialized
INFO - 2020-11-23 02:55:47 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:55:47 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:55:47 --> Utf8 Class Initialized
INFO - 2020-11-23 02:55:47 --> URI Class Initialized
INFO - 2020-11-23 02:55:47 --> Router Class Initialized
INFO - 2020-11-23 02:55:47 --> Output Class Initialized
INFO - 2020-11-23 02:55:47 --> Security Class Initialized
DEBUG - 2020-11-23 02:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:55:47 --> Input Class Initialized
INFO - 2020-11-23 02:55:47 --> Language Class Initialized
ERROR - 2020-11-23 02:55:47 --> 404 Page Not Found: ../modules/n_karakter/controllers/N_karakter/index
INFO - 2020-11-23 02:55:47 --> Config Class Initialized
INFO - 2020-11-23 02:55:47 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:55:47 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:55:47 --> Utf8 Class Initialized
INFO - 2020-11-23 02:55:47 --> URI Class Initialized
INFO - 2020-11-23 02:55:47 --> Router Class Initialized
INFO - 2020-11-23 02:55:47 --> Output Class Initialized
INFO - 2020-11-23 02:55:47 --> Security Class Initialized
DEBUG - 2020-11-23 02:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:55:47 --> Input Class Initialized
INFO - 2020-11-23 02:55:47 --> Language Class Initialized
ERROR - 2020-11-23 02:55:47 --> 404 Page Not Found: ../modules/n_karakter/controllers/N_karakter/index
INFO - 2020-11-23 02:56:38 --> Config Class Initialized
INFO - 2020-11-23 02:56:38 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:56:38 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:56:38 --> Utf8 Class Initialized
INFO - 2020-11-23 02:56:38 --> URI Class Initialized
DEBUG - 2020-11-23 02:56:38 --> No URI present. Default controller set.
INFO - 2020-11-23 02:56:38 --> Router Class Initialized
INFO - 2020-11-23 02:56:38 --> Output Class Initialized
INFO - 2020-11-23 02:56:38 --> Security Class Initialized
DEBUG - 2020-11-23 02:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:56:39 --> Input Class Initialized
INFO - 2020-11-23 02:56:39 --> Language Class Initialized
INFO - 2020-11-23 02:56:39 --> Language Class Initialized
INFO - 2020-11-23 02:56:39 --> Config Class Initialized
INFO - 2020-11-23 02:56:39 --> Loader Class Initialized
INFO - 2020-11-23 02:56:39 --> Helper loaded: url_helper
INFO - 2020-11-23 02:56:39 --> Helper loaded: file_helper
INFO - 2020-11-23 02:56:39 --> Helper loaded: form_helper
INFO - 2020-11-23 02:56:39 --> Helper loaded: my_helper
INFO - 2020-11-23 02:56:39 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:56:39 --> Controller Class Initialized
DEBUG - 2020-11-23 02:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 02:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:56:39 --> Final output sent to browser
DEBUG - 2020-11-23 02:56:39 --> Total execution time: 0.2073
INFO - 2020-11-23 02:56:40 --> Config Class Initialized
INFO - 2020-11-23 02:56:40 --> Hooks Class Initialized
DEBUG - 2020-11-23 02:56:40 --> UTF-8 Support Enabled
INFO - 2020-11-23 02:56:40 --> Utf8 Class Initialized
INFO - 2020-11-23 02:56:40 --> URI Class Initialized
INFO - 2020-11-23 02:56:40 --> Router Class Initialized
INFO - 2020-11-23 02:56:40 --> Output Class Initialized
INFO - 2020-11-23 02:56:40 --> Security Class Initialized
DEBUG - 2020-11-23 02:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 02:56:40 --> Input Class Initialized
INFO - 2020-11-23 02:56:40 --> Language Class Initialized
INFO - 2020-11-23 02:56:40 --> Language Class Initialized
INFO - 2020-11-23 02:56:40 --> Config Class Initialized
INFO - 2020-11-23 02:56:40 --> Loader Class Initialized
INFO - 2020-11-23 02:56:40 --> Helper loaded: url_helper
INFO - 2020-11-23 02:56:40 --> Helper loaded: file_helper
INFO - 2020-11-23 02:56:40 --> Helper loaded: form_helper
INFO - 2020-11-23 02:56:40 --> Helper loaded: my_helper
INFO - 2020-11-23 02:56:40 --> Database Driver Class Initialized
DEBUG - 2020-11-23 02:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 02:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 02:56:40 --> Controller Class Initialized
DEBUG - 2020-11-23 02:56:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-23 02:56:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 02:56:40 --> Final output sent to browser
DEBUG - 2020-11-23 02:56:40 --> Total execution time: 0.1907
INFO - 2020-11-23 03:02:55 --> Config Class Initialized
INFO - 2020-11-23 03:02:55 --> Hooks Class Initialized
DEBUG - 2020-11-23 03:02:55 --> UTF-8 Support Enabled
INFO - 2020-11-23 03:02:55 --> Utf8 Class Initialized
INFO - 2020-11-23 03:02:55 --> URI Class Initialized
INFO - 2020-11-23 03:02:55 --> Router Class Initialized
INFO - 2020-11-23 03:02:55 --> Output Class Initialized
INFO - 2020-11-23 03:02:55 --> Security Class Initialized
DEBUG - 2020-11-23 03:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 03:02:55 --> Input Class Initialized
INFO - 2020-11-23 03:02:55 --> Language Class Initialized
ERROR - 2020-11-23 03:02:55 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 52
INFO - 2020-11-23 03:02:56 --> Config Class Initialized
INFO - 2020-11-23 03:02:56 --> Hooks Class Initialized
DEBUG - 2020-11-23 03:02:56 --> UTF-8 Support Enabled
INFO - 2020-11-23 03:02:56 --> Utf8 Class Initialized
INFO - 2020-11-23 03:02:56 --> URI Class Initialized
INFO - 2020-11-23 03:02:56 --> Router Class Initialized
INFO - 2020-11-23 03:02:56 --> Output Class Initialized
INFO - 2020-11-23 03:02:56 --> Security Class Initialized
DEBUG - 2020-11-23 03:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 03:02:56 --> Input Class Initialized
INFO - 2020-11-23 03:02:56 --> Language Class Initialized
ERROR - 2020-11-23 03:02:56 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 52
INFO - 2020-11-23 03:03:47 --> Config Class Initialized
INFO - 2020-11-23 03:03:47 --> Hooks Class Initialized
DEBUG - 2020-11-23 03:03:47 --> UTF-8 Support Enabled
INFO - 2020-11-23 03:03:47 --> Utf8 Class Initialized
INFO - 2020-11-23 03:03:47 --> URI Class Initialized
INFO - 2020-11-23 03:03:47 --> Router Class Initialized
INFO - 2020-11-23 03:03:47 --> Output Class Initialized
INFO - 2020-11-23 03:03:47 --> Security Class Initialized
DEBUG - 2020-11-23 03:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 03:03:47 --> Input Class Initialized
INFO - 2020-11-23 03:03:47 --> Language Class Initialized
ERROR - 2020-11-23 03:03:47 --> 404 Page Not Found: ../modules/n_karakter/controllers/N_karakter/index
INFO - 2020-11-23 03:03:49 --> Config Class Initialized
INFO - 2020-11-23 03:03:49 --> Hooks Class Initialized
DEBUG - 2020-11-23 03:03:49 --> UTF-8 Support Enabled
INFO - 2020-11-23 03:03:49 --> Utf8 Class Initialized
INFO - 2020-11-23 03:03:49 --> URI Class Initialized
INFO - 2020-11-23 03:03:49 --> Router Class Initialized
INFO - 2020-11-23 03:03:49 --> Output Class Initialized
INFO - 2020-11-23 03:03:49 --> Security Class Initialized
DEBUG - 2020-11-23 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 03:03:49 --> Input Class Initialized
INFO - 2020-11-23 03:03:49 --> Language Class Initialized
INFO - 2020-11-23 03:03:49 --> Language Class Initialized
INFO - 2020-11-23 03:03:49 --> Config Class Initialized
INFO - 2020-11-23 03:03:49 --> Loader Class Initialized
INFO - 2020-11-23 03:03:49 --> Helper loaded: url_helper
INFO - 2020-11-23 03:03:49 --> Helper loaded: file_helper
INFO - 2020-11-23 03:03:49 --> Helper loaded: form_helper
INFO - 2020-11-23 03:03:49 --> Helper loaded: my_helper
INFO - 2020-11-23 03:03:49 --> Database Driver Class Initialized
DEBUG - 2020-11-23 03:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 03:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 03:03:49 --> Controller Class Initialized
DEBUG - 2020-11-23 03:03:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-23 03:03:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 03:03:49 --> Final output sent to browser
DEBUG - 2020-11-23 03:03:49 --> Total execution time: 0.1947
INFO - 2020-11-23 03:03:51 --> Config Class Initialized
INFO - 2020-11-23 03:03:51 --> Hooks Class Initialized
DEBUG - 2020-11-23 03:03:51 --> UTF-8 Support Enabled
INFO - 2020-11-23 03:03:51 --> Utf8 Class Initialized
INFO - 2020-11-23 03:03:51 --> URI Class Initialized
INFO - 2020-11-23 03:03:51 --> Router Class Initialized
INFO - 2020-11-23 03:03:51 --> Output Class Initialized
INFO - 2020-11-23 03:03:51 --> Security Class Initialized
DEBUG - 2020-11-23 03:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 03:03:51 --> Input Class Initialized
INFO - 2020-11-23 03:03:51 --> Language Class Initialized
ERROR - 2020-11-23 03:03:51 --> 404 Page Not Found: ../modules/n_karakter/controllers/N_karakter/index
INFO - 2020-11-23 03:03:59 --> Config Class Initialized
INFO - 2020-11-23 03:03:59 --> Hooks Class Initialized
DEBUG - 2020-11-23 03:03:59 --> UTF-8 Support Enabled
INFO - 2020-11-23 03:03:59 --> Utf8 Class Initialized
INFO - 2020-11-23 03:03:59 --> URI Class Initialized
INFO - 2020-11-23 03:03:59 --> Router Class Initialized
INFO - 2020-11-23 03:03:59 --> Output Class Initialized
INFO - 2020-11-23 03:03:59 --> Security Class Initialized
DEBUG - 2020-11-23 03:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 03:03:59 --> Input Class Initialized
INFO - 2020-11-23 03:04:00 --> Language Class Initialized
ERROR - 2020-11-23 03:04:00 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 52
INFO - 2020-11-23 03:05:28 --> Config Class Initialized
INFO - 2020-11-23 03:05:28 --> Hooks Class Initialized
DEBUG - 2020-11-23 03:05:28 --> UTF-8 Support Enabled
INFO - 2020-11-23 03:05:28 --> Utf8 Class Initialized
INFO - 2020-11-23 03:05:28 --> URI Class Initialized
INFO - 2020-11-23 03:05:28 --> Router Class Initialized
INFO - 2020-11-23 03:05:28 --> Output Class Initialized
INFO - 2020-11-23 03:05:28 --> Security Class Initialized
DEBUG - 2020-11-23 03:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 03:05:28 --> Input Class Initialized
INFO - 2020-11-23 03:05:28 --> Language Class Initialized
ERROR - 2020-11-23 03:05:28 --> 404 Page Not Found: ../modules/n_karakter/controllers/N_karakter/index
INFO - 2020-11-23 03:07:50 --> Config Class Initialized
INFO - 2020-11-23 03:07:50 --> Hooks Class Initialized
DEBUG - 2020-11-23 03:07:50 --> UTF-8 Support Enabled
INFO - 2020-11-23 03:07:51 --> Utf8 Class Initialized
INFO - 2020-11-23 03:07:51 --> URI Class Initialized
INFO - 2020-11-23 03:07:51 --> Router Class Initialized
INFO - 2020-11-23 03:07:51 --> Output Class Initialized
INFO - 2020-11-23 03:07:51 --> Security Class Initialized
DEBUG - 2020-11-23 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 03:07:51 --> Input Class Initialized
INFO - 2020-11-23 03:07:51 --> Language Class Initialized
INFO - 2020-11-23 03:07:51 --> Language Class Initialized
INFO - 2020-11-23 03:07:51 --> Config Class Initialized
INFO - 2020-11-23 03:07:51 --> Loader Class Initialized
INFO - 2020-11-23 03:07:51 --> Helper loaded: url_helper
INFO - 2020-11-23 03:07:51 --> Helper loaded: file_helper
INFO - 2020-11-23 03:07:51 --> Helper loaded: form_helper
INFO - 2020-11-23 03:07:51 --> Helper loaded: my_helper
INFO - 2020-11-23 03:07:51 --> Database Driver Class Initialized
DEBUG - 2020-11-23 03:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 03:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 03:07:51 --> Controller Class Initialized
DEBUG - 2020-11-23 03:07:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 03:07:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 03:07:51 --> Final output sent to browser
DEBUG - 2020-11-23 03:07:51 --> Total execution time: 0.2176
INFO - 2020-11-23 05:37:10 --> Config Class Initialized
INFO - 2020-11-23 05:37:10 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:37:10 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:37:10 --> Utf8 Class Initialized
INFO - 2020-11-23 05:37:10 --> URI Class Initialized
INFO - 2020-11-23 05:37:10 --> Router Class Initialized
INFO - 2020-11-23 05:37:10 --> Output Class Initialized
INFO - 2020-11-23 05:37:10 --> Security Class Initialized
DEBUG - 2020-11-23 05:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:37:10 --> Input Class Initialized
INFO - 2020-11-23 05:37:10 --> Language Class Initialized
INFO - 2020-11-23 05:37:10 --> Language Class Initialized
INFO - 2020-11-23 05:37:10 --> Config Class Initialized
INFO - 2020-11-23 05:37:10 --> Loader Class Initialized
INFO - 2020-11-23 05:37:10 --> Helper loaded: url_helper
INFO - 2020-11-23 05:37:10 --> Helper loaded: file_helper
INFO - 2020-11-23 05:37:10 --> Helper loaded: form_helper
INFO - 2020-11-23 05:37:10 --> Helper loaded: my_helper
INFO - 2020-11-23 05:37:10 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:37:10 --> Controller Class Initialized
DEBUG - 2020-11-23 05:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:37:10 --> Final output sent to browser
DEBUG - 2020-11-23 05:37:10 --> Total execution time: 0.2259
INFO - 2020-11-23 05:38:17 --> Config Class Initialized
INFO - 2020-11-23 05:38:17 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:38:17 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:38:17 --> Utf8 Class Initialized
INFO - 2020-11-23 05:38:17 --> URI Class Initialized
INFO - 2020-11-23 05:38:17 --> Router Class Initialized
INFO - 2020-11-23 05:38:17 --> Output Class Initialized
INFO - 2020-11-23 05:38:17 --> Security Class Initialized
DEBUG - 2020-11-23 05:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:38:17 --> Input Class Initialized
INFO - 2020-11-23 05:38:17 --> Language Class Initialized
INFO - 2020-11-23 05:38:17 --> Language Class Initialized
INFO - 2020-11-23 05:38:17 --> Config Class Initialized
INFO - 2020-11-23 05:38:17 --> Loader Class Initialized
INFO - 2020-11-23 05:38:17 --> Helper loaded: url_helper
INFO - 2020-11-23 05:38:17 --> Helper loaded: file_helper
INFO - 2020-11-23 05:38:17 --> Helper loaded: form_helper
INFO - 2020-11-23 05:38:17 --> Helper loaded: my_helper
INFO - 2020-11-23 05:38:17 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:38:17 --> Controller Class Initialized
DEBUG - 2020-11-23 05:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:38:17 --> Final output sent to browser
DEBUG - 2020-11-23 05:38:17 --> Total execution time: 0.2207
INFO - 2020-11-23 05:38:53 --> Config Class Initialized
INFO - 2020-11-23 05:38:53 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:38:53 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:38:53 --> Utf8 Class Initialized
INFO - 2020-11-23 05:38:53 --> URI Class Initialized
INFO - 2020-11-23 05:38:53 --> Router Class Initialized
INFO - 2020-11-23 05:38:53 --> Output Class Initialized
INFO - 2020-11-23 05:38:53 --> Security Class Initialized
DEBUG - 2020-11-23 05:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:38:53 --> Input Class Initialized
INFO - 2020-11-23 05:38:53 --> Language Class Initialized
INFO - 2020-11-23 05:38:53 --> Language Class Initialized
INFO - 2020-11-23 05:38:53 --> Config Class Initialized
INFO - 2020-11-23 05:38:53 --> Loader Class Initialized
INFO - 2020-11-23 05:38:53 --> Helper loaded: url_helper
INFO - 2020-11-23 05:38:53 --> Helper loaded: file_helper
INFO - 2020-11-23 05:38:53 --> Helper loaded: form_helper
INFO - 2020-11-23 05:38:53 --> Helper loaded: my_helper
INFO - 2020-11-23 05:38:53 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:38:53 --> Controller Class Initialized
DEBUG - 2020-11-23 05:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:38:53 --> Final output sent to browser
DEBUG - 2020-11-23 05:38:53 --> Total execution time: 0.2175
INFO - 2020-11-23 05:39:14 --> Config Class Initialized
INFO - 2020-11-23 05:39:14 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:39:14 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:39:14 --> Utf8 Class Initialized
INFO - 2020-11-23 05:39:14 --> URI Class Initialized
INFO - 2020-11-23 05:39:14 --> Router Class Initialized
INFO - 2020-11-23 05:39:14 --> Output Class Initialized
INFO - 2020-11-23 05:39:14 --> Security Class Initialized
DEBUG - 2020-11-23 05:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:39:14 --> Input Class Initialized
INFO - 2020-11-23 05:39:14 --> Language Class Initialized
INFO - 2020-11-23 05:39:14 --> Language Class Initialized
INFO - 2020-11-23 05:39:14 --> Config Class Initialized
INFO - 2020-11-23 05:39:14 --> Loader Class Initialized
INFO - 2020-11-23 05:39:14 --> Helper loaded: url_helper
INFO - 2020-11-23 05:39:14 --> Helper loaded: file_helper
INFO - 2020-11-23 05:39:14 --> Helper loaded: form_helper
INFO - 2020-11-23 05:39:14 --> Helper loaded: my_helper
INFO - 2020-11-23 05:39:14 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:39:14 --> Controller Class Initialized
DEBUG - 2020-11-23 05:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:39:14 --> Final output sent to browser
DEBUG - 2020-11-23 05:39:14 --> Total execution time: 0.2164
INFO - 2020-11-23 05:41:17 --> Config Class Initialized
INFO - 2020-11-23 05:41:17 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:41:17 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:41:17 --> Utf8 Class Initialized
INFO - 2020-11-23 05:41:17 --> URI Class Initialized
INFO - 2020-11-23 05:41:17 --> Router Class Initialized
INFO - 2020-11-23 05:41:17 --> Output Class Initialized
INFO - 2020-11-23 05:41:17 --> Security Class Initialized
DEBUG - 2020-11-23 05:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:41:17 --> Input Class Initialized
INFO - 2020-11-23 05:41:17 --> Language Class Initialized
INFO - 2020-11-23 05:41:17 --> Language Class Initialized
INFO - 2020-11-23 05:41:17 --> Config Class Initialized
INFO - 2020-11-23 05:41:17 --> Loader Class Initialized
INFO - 2020-11-23 05:41:17 --> Helper loaded: url_helper
INFO - 2020-11-23 05:41:17 --> Helper loaded: file_helper
INFO - 2020-11-23 05:41:17 --> Helper loaded: form_helper
INFO - 2020-11-23 05:41:17 --> Helper loaded: my_helper
INFO - 2020-11-23 05:41:17 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:41:17 --> Controller Class Initialized
DEBUG - 2020-11-23 05:41:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:41:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:41:17 --> Final output sent to browser
DEBUG - 2020-11-23 05:41:17 --> Total execution time: 0.2197
INFO - 2020-11-23 05:41:55 --> Config Class Initialized
INFO - 2020-11-23 05:41:55 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:41:55 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:41:55 --> Utf8 Class Initialized
INFO - 2020-11-23 05:41:55 --> URI Class Initialized
INFO - 2020-11-23 05:41:55 --> Router Class Initialized
INFO - 2020-11-23 05:41:55 --> Output Class Initialized
INFO - 2020-11-23 05:41:55 --> Security Class Initialized
DEBUG - 2020-11-23 05:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:41:55 --> Input Class Initialized
INFO - 2020-11-23 05:41:55 --> Language Class Initialized
INFO - 2020-11-23 05:41:55 --> Language Class Initialized
INFO - 2020-11-23 05:41:55 --> Config Class Initialized
INFO - 2020-11-23 05:41:55 --> Loader Class Initialized
INFO - 2020-11-23 05:41:55 --> Helper loaded: url_helper
INFO - 2020-11-23 05:41:55 --> Helper loaded: file_helper
INFO - 2020-11-23 05:41:55 --> Helper loaded: form_helper
INFO - 2020-11-23 05:41:55 --> Helper loaded: my_helper
INFO - 2020-11-23 05:41:55 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:41:55 --> Controller Class Initialized
DEBUG - 2020-11-23 05:41:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:41:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:41:55 --> Final output sent to browser
DEBUG - 2020-11-23 05:41:55 --> Total execution time: 0.2229
INFO - 2020-11-23 05:42:13 --> Config Class Initialized
INFO - 2020-11-23 05:42:13 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:42:13 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:42:13 --> Utf8 Class Initialized
INFO - 2020-11-23 05:42:13 --> URI Class Initialized
INFO - 2020-11-23 05:42:13 --> Router Class Initialized
INFO - 2020-11-23 05:42:13 --> Output Class Initialized
INFO - 2020-11-23 05:42:13 --> Security Class Initialized
DEBUG - 2020-11-23 05:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:42:13 --> Input Class Initialized
INFO - 2020-11-23 05:42:13 --> Language Class Initialized
INFO - 2020-11-23 05:42:13 --> Language Class Initialized
INFO - 2020-11-23 05:42:13 --> Config Class Initialized
INFO - 2020-11-23 05:42:13 --> Loader Class Initialized
INFO - 2020-11-23 05:42:13 --> Helper loaded: url_helper
INFO - 2020-11-23 05:42:13 --> Helper loaded: file_helper
INFO - 2020-11-23 05:42:13 --> Helper loaded: form_helper
INFO - 2020-11-23 05:42:13 --> Helper loaded: my_helper
INFO - 2020-11-23 05:42:13 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:42:13 --> Controller Class Initialized
DEBUG - 2020-11-23 05:42:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:42:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:42:13 --> Final output sent to browser
DEBUG - 2020-11-23 05:42:13 --> Total execution time: 0.2338
INFO - 2020-11-23 05:42:26 --> Config Class Initialized
INFO - 2020-11-23 05:42:26 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:42:26 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:42:26 --> Utf8 Class Initialized
INFO - 2020-11-23 05:42:26 --> URI Class Initialized
INFO - 2020-11-23 05:42:26 --> Router Class Initialized
INFO - 2020-11-23 05:42:26 --> Output Class Initialized
INFO - 2020-11-23 05:42:26 --> Security Class Initialized
DEBUG - 2020-11-23 05:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:42:26 --> Input Class Initialized
INFO - 2020-11-23 05:42:26 --> Language Class Initialized
INFO - 2020-11-23 05:42:26 --> Language Class Initialized
INFO - 2020-11-23 05:42:26 --> Config Class Initialized
INFO - 2020-11-23 05:42:26 --> Loader Class Initialized
INFO - 2020-11-23 05:42:26 --> Helper loaded: url_helper
INFO - 2020-11-23 05:42:26 --> Helper loaded: file_helper
INFO - 2020-11-23 05:42:26 --> Helper loaded: form_helper
INFO - 2020-11-23 05:42:26 --> Helper loaded: my_helper
INFO - 2020-11-23 05:42:26 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:42:26 --> Controller Class Initialized
DEBUG - 2020-11-23 05:42:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:42:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:42:26 --> Final output sent to browser
DEBUG - 2020-11-23 05:42:26 --> Total execution time: 0.2197
INFO - 2020-11-23 05:42:35 --> Config Class Initialized
INFO - 2020-11-23 05:42:35 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:42:35 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:42:35 --> Utf8 Class Initialized
INFO - 2020-11-23 05:42:35 --> URI Class Initialized
INFO - 2020-11-23 05:42:35 --> Router Class Initialized
INFO - 2020-11-23 05:42:35 --> Output Class Initialized
INFO - 2020-11-23 05:42:35 --> Security Class Initialized
DEBUG - 2020-11-23 05:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:42:35 --> Input Class Initialized
INFO - 2020-11-23 05:42:35 --> Language Class Initialized
INFO - 2020-11-23 05:42:35 --> Language Class Initialized
INFO - 2020-11-23 05:42:35 --> Config Class Initialized
INFO - 2020-11-23 05:42:35 --> Loader Class Initialized
INFO - 2020-11-23 05:42:35 --> Helper loaded: url_helper
INFO - 2020-11-23 05:42:35 --> Helper loaded: file_helper
INFO - 2020-11-23 05:42:35 --> Helper loaded: form_helper
INFO - 2020-11-23 05:42:35 --> Helper loaded: my_helper
INFO - 2020-11-23 05:42:35 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:42:35 --> Controller Class Initialized
DEBUG - 2020-11-23 05:42:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:42:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:42:35 --> Final output sent to browser
DEBUG - 2020-11-23 05:42:35 --> Total execution time: 0.2194
INFO - 2020-11-23 05:42:48 --> Config Class Initialized
INFO - 2020-11-23 05:42:48 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:42:48 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:42:48 --> Utf8 Class Initialized
INFO - 2020-11-23 05:42:48 --> URI Class Initialized
INFO - 2020-11-23 05:42:48 --> Router Class Initialized
INFO - 2020-11-23 05:42:48 --> Output Class Initialized
INFO - 2020-11-23 05:42:48 --> Security Class Initialized
DEBUG - 2020-11-23 05:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:42:48 --> Input Class Initialized
INFO - 2020-11-23 05:42:48 --> Language Class Initialized
INFO - 2020-11-23 05:42:48 --> Language Class Initialized
INFO - 2020-11-23 05:42:48 --> Config Class Initialized
INFO - 2020-11-23 05:42:48 --> Loader Class Initialized
INFO - 2020-11-23 05:42:48 --> Helper loaded: url_helper
INFO - 2020-11-23 05:42:48 --> Helper loaded: file_helper
INFO - 2020-11-23 05:42:48 --> Helper loaded: form_helper
INFO - 2020-11-23 05:42:48 --> Helper loaded: my_helper
INFO - 2020-11-23 05:42:48 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:42:48 --> Controller Class Initialized
DEBUG - 2020-11-23 05:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:42:48 --> Final output sent to browser
DEBUG - 2020-11-23 05:42:48 --> Total execution time: 0.2225
INFO - 2020-11-23 05:43:25 --> Config Class Initialized
INFO - 2020-11-23 05:43:25 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:43:25 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:43:25 --> Utf8 Class Initialized
INFO - 2020-11-23 05:43:25 --> URI Class Initialized
INFO - 2020-11-23 05:43:25 --> Router Class Initialized
INFO - 2020-11-23 05:43:25 --> Output Class Initialized
INFO - 2020-11-23 05:43:25 --> Security Class Initialized
DEBUG - 2020-11-23 05:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:43:25 --> Input Class Initialized
INFO - 2020-11-23 05:43:25 --> Language Class Initialized
INFO - 2020-11-23 05:43:25 --> Language Class Initialized
INFO - 2020-11-23 05:43:25 --> Config Class Initialized
INFO - 2020-11-23 05:43:25 --> Loader Class Initialized
INFO - 2020-11-23 05:43:25 --> Helper loaded: url_helper
INFO - 2020-11-23 05:43:25 --> Helper loaded: file_helper
INFO - 2020-11-23 05:43:25 --> Helper loaded: form_helper
INFO - 2020-11-23 05:43:25 --> Helper loaded: my_helper
INFO - 2020-11-23 05:43:25 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:43:25 --> Controller Class Initialized
DEBUG - 2020-11-23 05:43:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:43:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:43:25 --> Final output sent to browser
DEBUG - 2020-11-23 05:43:25 --> Total execution time: 0.2195
INFO - 2020-11-23 05:44:11 --> Config Class Initialized
INFO - 2020-11-23 05:44:11 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:44:11 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:44:11 --> Utf8 Class Initialized
INFO - 2020-11-23 05:44:11 --> URI Class Initialized
INFO - 2020-11-23 05:44:11 --> Router Class Initialized
INFO - 2020-11-23 05:44:11 --> Output Class Initialized
INFO - 2020-11-23 05:44:11 --> Security Class Initialized
DEBUG - 2020-11-23 05:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:44:11 --> Input Class Initialized
INFO - 2020-11-23 05:44:11 --> Language Class Initialized
INFO - 2020-11-23 05:44:11 --> Language Class Initialized
INFO - 2020-11-23 05:44:11 --> Config Class Initialized
INFO - 2020-11-23 05:44:11 --> Loader Class Initialized
INFO - 2020-11-23 05:44:11 --> Helper loaded: url_helper
INFO - 2020-11-23 05:44:11 --> Helper loaded: file_helper
INFO - 2020-11-23 05:44:11 --> Helper loaded: form_helper
INFO - 2020-11-23 05:44:11 --> Helper loaded: my_helper
INFO - 2020-11-23 05:44:11 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:44:11 --> Controller Class Initialized
DEBUG - 2020-11-23 05:44:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:44:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:44:11 --> Final output sent to browser
DEBUG - 2020-11-23 05:44:11 --> Total execution time: 0.2373
INFO - 2020-11-23 05:45:02 --> Config Class Initialized
INFO - 2020-11-23 05:45:02 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:45:02 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:45:02 --> Utf8 Class Initialized
INFO - 2020-11-23 05:45:02 --> URI Class Initialized
INFO - 2020-11-23 05:45:02 --> Router Class Initialized
INFO - 2020-11-23 05:45:02 --> Output Class Initialized
INFO - 2020-11-23 05:45:02 --> Security Class Initialized
DEBUG - 2020-11-23 05:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:45:02 --> Input Class Initialized
INFO - 2020-11-23 05:45:02 --> Language Class Initialized
INFO - 2020-11-23 05:45:02 --> Language Class Initialized
INFO - 2020-11-23 05:45:02 --> Config Class Initialized
INFO - 2020-11-23 05:45:02 --> Loader Class Initialized
INFO - 2020-11-23 05:45:02 --> Helper loaded: url_helper
INFO - 2020-11-23 05:45:02 --> Helper loaded: file_helper
INFO - 2020-11-23 05:45:02 --> Helper loaded: form_helper
INFO - 2020-11-23 05:45:02 --> Helper loaded: my_helper
INFO - 2020-11-23 05:45:02 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:45:02 --> Controller Class Initialized
DEBUG - 2020-11-23 05:45:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:45:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:45:02 --> Final output sent to browser
DEBUG - 2020-11-23 05:45:02 --> Total execution time: 0.2237
INFO - 2020-11-23 05:45:49 --> Config Class Initialized
INFO - 2020-11-23 05:45:49 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:45:49 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:45:49 --> Utf8 Class Initialized
INFO - 2020-11-23 05:45:49 --> URI Class Initialized
INFO - 2020-11-23 05:45:49 --> Router Class Initialized
INFO - 2020-11-23 05:45:49 --> Output Class Initialized
INFO - 2020-11-23 05:45:49 --> Security Class Initialized
DEBUG - 2020-11-23 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:45:49 --> Input Class Initialized
INFO - 2020-11-23 05:45:49 --> Language Class Initialized
INFO - 2020-11-23 05:45:49 --> Language Class Initialized
INFO - 2020-11-23 05:45:49 --> Config Class Initialized
INFO - 2020-11-23 05:45:49 --> Loader Class Initialized
INFO - 2020-11-23 05:45:49 --> Helper loaded: url_helper
INFO - 2020-11-23 05:45:49 --> Helper loaded: file_helper
INFO - 2020-11-23 05:45:49 --> Helper loaded: form_helper
INFO - 2020-11-23 05:45:49 --> Helper loaded: my_helper
INFO - 2020-11-23 05:45:49 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:45:49 --> Controller Class Initialized
DEBUG - 2020-11-23 05:45:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:45:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:45:49 --> Final output sent to browser
DEBUG - 2020-11-23 05:45:49 --> Total execution time: 0.2198
INFO - 2020-11-23 05:46:07 --> Config Class Initialized
INFO - 2020-11-23 05:46:07 --> Hooks Class Initialized
DEBUG - 2020-11-23 05:46:07 --> UTF-8 Support Enabled
INFO - 2020-11-23 05:46:07 --> Utf8 Class Initialized
INFO - 2020-11-23 05:46:07 --> URI Class Initialized
INFO - 2020-11-23 05:46:07 --> Router Class Initialized
INFO - 2020-11-23 05:46:07 --> Output Class Initialized
INFO - 2020-11-23 05:46:07 --> Security Class Initialized
DEBUG - 2020-11-23 05:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 05:46:07 --> Input Class Initialized
INFO - 2020-11-23 05:46:07 --> Language Class Initialized
INFO - 2020-11-23 05:46:07 --> Language Class Initialized
INFO - 2020-11-23 05:46:07 --> Config Class Initialized
INFO - 2020-11-23 05:46:07 --> Loader Class Initialized
INFO - 2020-11-23 05:46:07 --> Helper loaded: url_helper
INFO - 2020-11-23 05:46:07 --> Helper loaded: file_helper
INFO - 2020-11-23 05:46:07 --> Helper loaded: form_helper
INFO - 2020-11-23 05:46:07 --> Helper loaded: my_helper
INFO - 2020-11-23 05:46:07 --> Database Driver Class Initialized
DEBUG - 2020-11-23 05:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 05:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 05:46:07 --> Controller Class Initialized
DEBUG - 2020-11-23 05:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 05:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 05:46:07 --> Final output sent to browser
DEBUG - 2020-11-23 05:46:07 --> Total execution time: 0.2228
INFO - 2020-11-23 07:08:39 --> Config Class Initialized
INFO - 2020-11-23 07:08:39 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:08:39 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:08:39 --> Utf8 Class Initialized
INFO - 2020-11-23 07:08:39 --> URI Class Initialized
INFO - 2020-11-23 07:08:39 --> Router Class Initialized
INFO - 2020-11-23 07:08:39 --> Output Class Initialized
INFO - 2020-11-23 07:08:39 --> Security Class Initialized
DEBUG - 2020-11-23 07:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:08:39 --> Input Class Initialized
INFO - 2020-11-23 07:08:39 --> Language Class Initialized
INFO - 2020-11-23 07:08:39 --> Language Class Initialized
INFO - 2020-11-23 07:08:39 --> Config Class Initialized
INFO - 2020-11-23 07:08:39 --> Loader Class Initialized
INFO - 2020-11-23 07:08:39 --> Helper loaded: url_helper
INFO - 2020-11-23 07:08:39 --> Helper loaded: file_helper
INFO - 2020-11-23 07:08:39 --> Helper loaded: form_helper
INFO - 2020-11-23 07:08:39 --> Helper loaded: my_helper
INFO - 2020-11-23 07:08:39 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:08:39 --> Controller Class Initialized
ERROR - 2020-11-23 07:08:39 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
INFO - 2020-11-23 07:09:25 --> Config Class Initialized
INFO - 2020-11-23 07:09:25 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:09:25 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:09:25 --> Utf8 Class Initialized
INFO - 2020-11-23 07:09:25 --> URI Class Initialized
INFO - 2020-11-23 07:09:25 --> Router Class Initialized
INFO - 2020-11-23 07:09:25 --> Output Class Initialized
INFO - 2020-11-23 07:09:25 --> Security Class Initialized
DEBUG - 2020-11-23 07:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:09:25 --> Input Class Initialized
INFO - 2020-11-23 07:09:25 --> Language Class Initialized
INFO - 2020-11-23 07:09:25 --> Language Class Initialized
INFO - 2020-11-23 07:09:26 --> Config Class Initialized
INFO - 2020-11-23 07:09:26 --> Loader Class Initialized
INFO - 2020-11-23 07:09:26 --> Helper loaded: url_helper
INFO - 2020-11-23 07:09:26 --> Helper loaded: file_helper
INFO - 2020-11-23 07:09:26 --> Helper loaded: form_helper
INFO - 2020-11-23 07:09:26 --> Helper loaded: my_helper
INFO - 2020-11-23 07:09:26 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:09:26 --> Controller Class Initialized
DEBUG - 2020-11-23 07:09:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 07:09:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:09:26 --> Final output sent to browser
DEBUG - 2020-11-23 07:09:26 --> Total execution time: 0.2190
INFO - 2020-11-23 07:13:52 --> Config Class Initialized
INFO - 2020-11-23 07:13:52 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:13:52 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:13:52 --> Utf8 Class Initialized
INFO - 2020-11-23 07:13:52 --> URI Class Initialized
INFO - 2020-11-23 07:13:52 --> Router Class Initialized
INFO - 2020-11-23 07:13:52 --> Output Class Initialized
INFO - 2020-11-23 07:13:52 --> Security Class Initialized
DEBUG - 2020-11-23 07:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:13:52 --> Input Class Initialized
INFO - 2020-11-23 07:13:52 --> Language Class Initialized
INFO - 2020-11-23 07:13:52 --> Language Class Initialized
INFO - 2020-11-23 07:13:52 --> Config Class Initialized
INFO - 2020-11-23 07:13:52 --> Loader Class Initialized
INFO - 2020-11-23 07:13:52 --> Helper loaded: url_helper
INFO - 2020-11-23 07:13:52 --> Helper loaded: file_helper
INFO - 2020-11-23 07:13:52 --> Helper loaded: form_helper
INFO - 2020-11-23 07:13:52 --> Helper loaded: my_helper
INFO - 2020-11-23 07:13:52 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:13:52 --> Controller Class Initialized
ERROR - 2020-11-23 07:13:52 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 49
INFO - 2020-11-23 07:14:34 --> Config Class Initialized
INFO - 2020-11-23 07:14:34 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:14:34 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:14:34 --> Utf8 Class Initialized
INFO - 2020-11-23 07:14:34 --> URI Class Initialized
INFO - 2020-11-23 07:14:34 --> Router Class Initialized
INFO - 2020-11-23 07:14:34 --> Output Class Initialized
INFO - 2020-11-23 07:14:34 --> Security Class Initialized
DEBUG - 2020-11-23 07:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:14:34 --> Input Class Initialized
INFO - 2020-11-23 07:14:34 --> Language Class Initialized
INFO - 2020-11-23 07:14:34 --> Language Class Initialized
INFO - 2020-11-23 07:14:34 --> Config Class Initialized
INFO - 2020-11-23 07:14:34 --> Loader Class Initialized
INFO - 2020-11-23 07:14:34 --> Helper loaded: url_helper
INFO - 2020-11-23 07:14:34 --> Helper loaded: file_helper
INFO - 2020-11-23 07:14:34 --> Helper loaded: form_helper
INFO - 2020-11-23 07:14:34 --> Helper loaded: my_helper
INFO - 2020-11-23 07:14:34 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:14:34 --> Controller Class Initialized
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
DEBUG - 2020-11-23 07:14:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 07:14:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:14:35 --> Final output sent to browser
DEBUG - 2020-11-23 07:14:35 --> Total execution time: 0.5157
INFO - 2020-11-23 07:14:57 --> Config Class Initialized
INFO - 2020-11-23 07:14:57 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:14:57 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:14:57 --> Utf8 Class Initialized
INFO - 2020-11-23 07:14:57 --> URI Class Initialized
INFO - 2020-11-23 07:14:57 --> Router Class Initialized
INFO - 2020-11-23 07:14:57 --> Output Class Initialized
INFO - 2020-11-23 07:14:57 --> Security Class Initialized
DEBUG - 2020-11-23 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:14:57 --> Input Class Initialized
INFO - 2020-11-23 07:14:57 --> Language Class Initialized
INFO - 2020-11-23 07:14:57 --> Language Class Initialized
INFO - 2020-11-23 07:14:57 --> Config Class Initialized
INFO - 2020-11-23 07:14:57 --> Loader Class Initialized
INFO - 2020-11-23 07:14:57 --> Helper loaded: url_helper
INFO - 2020-11-23 07:14:57 --> Helper loaded: file_helper
INFO - 2020-11-23 07:14:57 --> Helper loaded: form_helper
INFO - 2020-11-23 07:14:57 --> Helper loaded: my_helper
INFO - 2020-11-23 07:14:57 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:14:57 --> Controller Class Initialized
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
ERROR - 2020-11-23 07:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 46
DEBUG - 2020-11-23 07:14:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 07:14:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:14:57 --> Final output sent to browser
DEBUG - 2020-11-23 07:14:57 --> Total execution time: 0.5949
INFO - 2020-11-23 07:16:16 --> Config Class Initialized
INFO - 2020-11-23 07:16:16 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:16:16 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:16:16 --> Utf8 Class Initialized
INFO - 2020-11-23 07:16:16 --> URI Class Initialized
INFO - 2020-11-23 07:16:16 --> Router Class Initialized
INFO - 2020-11-23 07:16:16 --> Output Class Initialized
INFO - 2020-11-23 07:16:16 --> Security Class Initialized
DEBUG - 2020-11-23 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:16:16 --> Input Class Initialized
INFO - 2020-11-23 07:16:16 --> Language Class Initialized
INFO - 2020-11-23 07:16:16 --> Language Class Initialized
INFO - 2020-11-23 07:16:16 --> Config Class Initialized
INFO - 2020-11-23 07:16:16 --> Loader Class Initialized
INFO - 2020-11-23 07:16:16 --> Helper loaded: url_helper
INFO - 2020-11-23 07:16:16 --> Helper loaded: file_helper
INFO - 2020-11-23 07:16:16 --> Helper loaded: form_helper
INFO - 2020-11-23 07:16:16 --> Helper loaded: my_helper
INFO - 2020-11-23 07:16:16 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:16:17 --> Controller Class Initialized
DEBUG - 2020-11-23 07:16:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 07:16:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:16:17 --> Final output sent to browser
DEBUG - 2020-11-23 07:16:17 --> Total execution time: 0.2367
INFO - 2020-11-23 07:35:51 --> Config Class Initialized
INFO - 2020-11-23 07:35:51 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:35:51 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:35:51 --> Utf8 Class Initialized
INFO - 2020-11-23 07:35:51 --> URI Class Initialized
INFO - 2020-11-23 07:35:51 --> Router Class Initialized
INFO - 2020-11-23 07:35:51 --> Output Class Initialized
INFO - 2020-11-23 07:35:51 --> Security Class Initialized
DEBUG - 2020-11-23 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:35:51 --> Input Class Initialized
INFO - 2020-11-23 07:35:51 --> Language Class Initialized
INFO - 2020-11-23 07:35:51 --> Language Class Initialized
INFO - 2020-11-23 07:35:51 --> Config Class Initialized
INFO - 2020-11-23 07:35:51 --> Loader Class Initialized
INFO - 2020-11-23 07:35:51 --> Helper loaded: url_helper
INFO - 2020-11-23 07:35:51 --> Helper loaded: file_helper
INFO - 2020-11-23 07:35:51 --> Helper loaded: form_helper
INFO - 2020-11-23 07:35:51 --> Helper loaded: my_helper
INFO - 2020-11-23 07:35:51 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:35:51 --> Controller Class Initialized
DEBUG - 2020-11-23 07:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-23 07:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:35:51 --> Final output sent to browser
DEBUG - 2020-11-23 07:35:51 --> Total execution time: 0.2307
INFO - 2020-11-23 07:35:53 --> Config Class Initialized
INFO - 2020-11-23 07:35:53 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:35:53 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:35:53 --> Utf8 Class Initialized
INFO - 2020-11-23 07:35:53 --> URI Class Initialized
INFO - 2020-11-23 07:35:53 --> Router Class Initialized
INFO - 2020-11-23 07:35:53 --> Output Class Initialized
INFO - 2020-11-23 07:35:53 --> Security Class Initialized
DEBUG - 2020-11-23 07:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:35:53 --> Input Class Initialized
INFO - 2020-11-23 07:35:53 --> Language Class Initialized
INFO - 2020-11-23 07:35:53 --> Language Class Initialized
INFO - 2020-11-23 07:35:53 --> Config Class Initialized
INFO - 2020-11-23 07:35:53 --> Loader Class Initialized
INFO - 2020-11-23 07:35:53 --> Helper loaded: url_helper
INFO - 2020-11-23 07:35:53 --> Helper loaded: file_helper
INFO - 2020-11-23 07:35:53 --> Helper loaded: form_helper
INFO - 2020-11-23 07:35:53 --> Helper loaded: my_helper
INFO - 2020-11-23 07:35:53 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:35:53 --> Controller Class Initialized
INFO - 2020-11-23 07:35:53 --> Final output sent to browser
DEBUG - 2020-11-23 07:35:53 --> Total execution time: 0.2023
INFO - 2020-11-23 07:37:41 --> Config Class Initialized
INFO - 2020-11-23 07:37:41 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:41 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:41 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:41 --> URI Class Initialized
INFO - 2020-11-23 07:37:41 --> Router Class Initialized
INFO - 2020-11-23 07:37:41 --> Output Class Initialized
INFO - 2020-11-23 07:37:41 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:41 --> Input Class Initialized
INFO - 2020-11-23 07:37:41 --> Language Class Initialized
INFO - 2020-11-23 07:37:41 --> Language Class Initialized
INFO - 2020-11-23 07:37:41 --> Config Class Initialized
INFO - 2020-11-23 07:37:41 --> Loader Class Initialized
INFO - 2020-11-23 07:37:41 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:41 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:41 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:41 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:41 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:41 --> Controller Class Initialized
DEBUG - 2020-11-23 07:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-23 07:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:37:41 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:41 --> Total execution time: 0.2528
INFO - 2020-11-23 07:37:44 --> Config Class Initialized
INFO - 2020-11-23 07:37:44 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:45 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:45 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:45 --> URI Class Initialized
INFO - 2020-11-23 07:37:45 --> Router Class Initialized
INFO - 2020-11-23 07:37:45 --> Output Class Initialized
INFO - 2020-11-23 07:37:45 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:45 --> Input Class Initialized
INFO - 2020-11-23 07:37:45 --> Language Class Initialized
INFO - 2020-11-23 07:37:45 --> Language Class Initialized
INFO - 2020-11-23 07:37:45 --> Config Class Initialized
INFO - 2020-11-23 07:37:45 --> Loader Class Initialized
INFO - 2020-11-23 07:37:45 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:45 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:45 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:45 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:45 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:45 --> Controller Class Initialized
INFO - 2020-11-23 07:37:45 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:45 --> Total execution time: 0.1780
INFO - 2020-11-23 07:37:46 --> Config Class Initialized
INFO - 2020-11-23 07:37:46 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:46 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:46 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:46 --> URI Class Initialized
INFO - 2020-11-23 07:37:46 --> Router Class Initialized
INFO - 2020-11-23 07:37:46 --> Output Class Initialized
INFO - 2020-11-23 07:37:46 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:46 --> Input Class Initialized
INFO - 2020-11-23 07:37:46 --> Language Class Initialized
INFO - 2020-11-23 07:37:46 --> Language Class Initialized
INFO - 2020-11-23 07:37:46 --> Config Class Initialized
INFO - 2020-11-23 07:37:46 --> Loader Class Initialized
INFO - 2020-11-23 07:37:46 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:46 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:46 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:46 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:46 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:46 --> Controller Class Initialized
INFO - 2020-11-23 07:37:46 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:46 --> Total execution time: 0.1805
INFO - 2020-11-23 07:37:47 --> Config Class Initialized
INFO - 2020-11-23 07:37:47 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:47 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:47 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:47 --> URI Class Initialized
INFO - 2020-11-23 07:37:47 --> Router Class Initialized
INFO - 2020-11-23 07:37:47 --> Output Class Initialized
INFO - 2020-11-23 07:37:47 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:47 --> Input Class Initialized
INFO - 2020-11-23 07:37:47 --> Language Class Initialized
INFO - 2020-11-23 07:37:47 --> Language Class Initialized
INFO - 2020-11-23 07:37:47 --> Config Class Initialized
INFO - 2020-11-23 07:37:47 --> Loader Class Initialized
INFO - 2020-11-23 07:37:47 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:47 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:47 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:47 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:47 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:47 --> Controller Class Initialized
INFO - 2020-11-23 07:37:47 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:47 --> Total execution time: 0.1788
INFO - 2020-11-23 07:37:49 --> Config Class Initialized
INFO - 2020-11-23 07:37:49 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:49 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:49 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:49 --> URI Class Initialized
INFO - 2020-11-23 07:37:49 --> Router Class Initialized
INFO - 2020-11-23 07:37:49 --> Output Class Initialized
INFO - 2020-11-23 07:37:49 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:49 --> Input Class Initialized
INFO - 2020-11-23 07:37:49 --> Language Class Initialized
INFO - 2020-11-23 07:37:49 --> Language Class Initialized
INFO - 2020-11-23 07:37:49 --> Config Class Initialized
INFO - 2020-11-23 07:37:49 --> Loader Class Initialized
INFO - 2020-11-23 07:37:49 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:49 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:49 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:49 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:49 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:49 --> Controller Class Initialized
INFO - 2020-11-23 07:37:49 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:49 --> Total execution time: 0.1894
INFO - 2020-11-23 07:37:50 --> Config Class Initialized
INFO - 2020-11-23 07:37:50 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:50 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:50 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:50 --> URI Class Initialized
INFO - 2020-11-23 07:37:50 --> Router Class Initialized
INFO - 2020-11-23 07:37:50 --> Output Class Initialized
INFO - 2020-11-23 07:37:50 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:50 --> Input Class Initialized
INFO - 2020-11-23 07:37:50 --> Language Class Initialized
INFO - 2020-11-23 07:37:50 --> Language Class Initialized
INFO - 2020-11-23 07:37:50 --> Config Class Initialized
INFO - 2020-11-23 07:37:50 --> Loader Class Initialized
INFO - 2020-11-23 07:37:50 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:50 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:50 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:50 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:50 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:50 --> Controller Class Initialized
INFO - 2020-11-23 07:37:50 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:50 --> Total execution time: 0.1920
INFO - 2020-11-23 07:37:51 --> Config Class Initialized
INFO - 2020-11-23 07:37:51 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:51 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:51 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:51 --> URI Class Initialized
INFO - 2020-11-23 07:37:51 --> Router Class Initialized
INFO - 2020-11-23 07:37:51 --> Output Class Initialized
INFO - 2020-11-23 07:37:51 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:51 --> Input Class Initialized
INFO - 2020-11-23 07:37:51 --> Language Class Initialized
INFO - 2020-11-23 07:37:51 --> Language Class Initialized
INFO - 2020-11-23 07:37:51 --> Config Class Initialized
INFO - 2020-11-23 07:37:51 --> Loader Class Initialized
INFO - 2020-11-23 07:37:51 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:51 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:51 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:51 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:51 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:51 --> Controller Class Initialized
INFO - 2020-11-23 07:37:51 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:51 --> Total execution time: 0.1978
INFO - 2020-11-23 07:37:52 --> Config Class Initialized
INFO - 2020-11-23 07:37:52 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:52 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:52 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:52 --> URI Class Initialized
INFO - 2020-11-23 07:37:52 --> Router Class Initialized
INFO - 2020-11-23 07:37:52 --> Output Class Initialized
INFO - 2020-11-23 07:37:52 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:52 --> Input Class Initialized
INFO - 2020-11-23 07:37:52 --> Language Class Initialized
INFO - 2020-11-23 07:37:52 --> Language Class Initialized
INFO - 2020-11-23 07:37:52 --> Config Class Initialized
INFO - 2020-11-23 07:37:52 --> Loader Class Initialized
INFO - 2020-11-23 07:37:52 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:52 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:52 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:52 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:52 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:52 --> Controller Class Initialized
INFO - 2020-11-23 07:37:52 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:52 --> Total execution time: 0.1971
INFO - 2020-11-23 07:37:53 --> Config Class Initialized
INFO - 2020-11-23 07:37:53 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:37:53 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:37:53 --> Utf8 Class Initialized
INFO - 2020-11-23 07:37:53 --> URI Class Initialized
INFO - 2020-11-23 07:37:53 --> Router Class Initialized
INFO - 2020-11-23 07:37:53 --> Output Class Initialized
INFO - 2020-11-23 07:37:53 --> Security Class Initialized
DEBUG - 2020-11-23 07:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:37:53 --> Input Class Initialized
INFO - 2020-11-23 07:37:53 --> Language Class Initialized
INFO - 2020-11-23 07:37:53 --> Language Class Initialized
INFO - 2020-11-23 07:37:53 --> Config Class Initialized
INFO - 2020-11-23 07:37:53 --> Loader Class Initialized
INFO - 2020-11-23 07:37:53 --> Helper loaded: url_helper
INFO - 2020-11-23 07:37:53 --> Helper loaded: file_helper
INFO - 2020-11-23 07:37:53 --> Helper loaded: form_helper
INFO - 2020-11-23 07:37:53 --> Helper loaded: my_helper
INFO - 2020-11-23 07:37:53 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:37:53 --> Controller Class Initialized
INFO - 2020-11-23 07:37:53 --> Final output sent to browser
DEBUG - 2020-11-23 07:37:53 --> Total execution time: 0.1869
INFO - 2020-11-23 07:38:24 --> Config Class Initialized
INFO - 2020-11-23 07:38:24 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:38:24 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:38:24 --> Utf8 Class Initialized
INFO - 2020-11-23 07:38:24 --> URI Class Initialized
INFO - 2020-11-23 07:38:24 --> Router Class Initialized
INFO - 2020-11-23 07:38:24 --> Output Class Initialized
INFO - 2020-11-23 07:38:24 --> Security Class Initialized
DEBUG - 2020-11-23 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:38:24 --> Input Class Initialized
INFO - 2020-11-23 07:38:24 --> Language Class Initialized
INFO - 2020-11-23 07:38:24 --> Language Class Initialized
INFO - 2020-11-23 07:38:24 --> Config Class Initialized
INFO - 2020-11-23 07:38:24 --> Loader Class Initialized
INFO - 2020-11-23 07:38:24 --> Helper loaded: url_helper
INFO - 2020-11-23 07:38:24 --> Helper loaded: file_helper
INFO - 2020-11-23 07:38:24 --> Helper loaded: form_helper
INFO - 2020-11-23 07:38:24 --> Helper loaded: my_helper
INFO - 2020-11-23 07:38:24 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:38:24 --> Controller Class Initialized
DEBUG - 2020-11-23 07:38:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-23 07:38:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:38:24 --> Final output sent to browser
DEBUG - 2020-11-23 07:38:24 --> Total execution time: 0.2307
INFO - 2020-11-23 07:38:25 --> Config Class Initialized
INFO - 2020-11-23 07:38:25 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:38:25 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:38:25 --> Utf8 Class Initialized
INFO - 2020-11-23 07:38:25 --> URI Class Initialized
INFO - 2020-11-23 07:38:25 --> Router Class Initialized
INFO - 2020-11-23 07:38:25 --> Output Class Initialized
INFO - 2020-11-23 07:38:25 --> Security Class Initialized
DEBUG - 2020-11-23 07:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:38:25 --> Input Class Initialized
INFO - 2020-11-23 07:38:26 --> Language Class Initialized
INFO - 2020-11-23 07:38:26 --> Language Class Initialized
INFO - 2020-11-23 07:38:26 --> Config Class Initialized
INFO - 2020-11-23 07:38:26 --> Loader Class Initialized
INFO - 2020-11-23 07:38:26 --> Helper loaded: url_helper
INFO - 2020-11-23 07:38:26 --> Helper loaded: file_helper
INFO - 2020-11-23 07:38:26 --> Helper loaded: form_helper
INFO - 2020-11-23 07:38:26 --> Helper loaded: my_helper
INFO - 2020-11-23 07:38:26 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:38:26 --> Controller Class Initialized
INFO - 2020-11-23 07:38:26 --> Final output sent to browser
DEBUG - 2020-11-23 07:38:26 --> Total execution time: 0.1903
INFO - 2020-11-23 07:38:40 --> Config Class Initialized
INFO - 2020-11-23 07:38:40 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:38:40 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:38:40 --> Utf8 Class Initialized
INFO - 2020-11-23 07:38:40 --> URI Class Initialized
INFO - 2020-11-23 07:38:40 --> Router Class Initialized
INFO - 2020-11-23 07:38:40 --> Output Class Initialized
INFO - 2020-11-23 07:38:40 --> Security Class Initialized
DEBUG - 2020-11-23 07:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:38:40 --> Input Class Initialized
INFO - 2020-11-23 07:38:40 --> Language Class Initialized
INFO - 2020-11-23 07:38:40 --> Language Class Initialized
INFO - 2020-11-23 07:38:40 --> Config Class Initialized
INFO - 2020-11-23 07:38:40 --> Loader Class Initialized
INFO - 2020-11-23 07:38:40 --> Helper loaded: url_helper
INFO - 2020-11-23 07:38:40 --> Helper loaded: file_helper
INFO - 2020-11-23 07:38:40 --> Helper loaded: form_helper
INFO - 2020-11-23 07:38:40 --> Helper loaded: my_helper
INFO - 2020-11-23 07:38:40 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:38:40 --> Controller Class Initialized
DEBUG - 2020-11-23 07:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-23 07:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:38:40 --> Final output sent to browser
DEBUG - 2020-11-23 07:38:40 --> Total execution time: 0.2268
INFO - 2020-11-23 07:38:41 --> Config Class Initialized
INFO - 2020-11-23 07:38:41 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:38:41 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:38:41 --> Utf8 Class Initialized
INFO - 2020-11-23 07:38:41 --> URI Class Initialized
INFO - 2020-11-23 07:38:41 --> Router Class Initialized
INFO - 2020-11-23 07:38:41 --> Output Class Initialized
INFO - 2020-11-23 07:38:41 --> Security Class Initialized
DEBUG - 2020-11-23 07:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:38:41 --> Input Class Initialized
INFO - 2020-11-23 07:38:41 --> Language Class Initialized
INFO - 2020-11-23 07:38:41 --> Language Class Initialized
INFO - 2020-11-23 07:38:41 --> Config Class Initialized
INFO - 2020-11-23 07:38:41 --> Loader Class Initialized
INFO - 2020-11-23 07:38:41 --> Helper loaded: url_helper
INFO - 2020-11-23 07:38:41 --> Helper loaded: file_helper
INFO - 2020-11-23 07:38:41 --> Helper loaded: form_helper
INFO - 2020-11-23 07:38:41 --> Helper loaded: my_helper
INFO - 2020-11-23 07:38:41 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:38:41 --> Controller Class Initialized
INFO - 2020-11-23 07:38:41 --> Final output sent to browser
DEBUG - 2020-11-23 07:38:41 --> Total execution time: 0.1943
INFO - 2020-11-23 07:42:01 --> Config Class Initialized
INFO - 2020-11-23 07:42:01 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:42:01 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:42:01 --> Utf8 Class Initialized
INFO - 2020-11-23 07:42:01 --> URI Class Initialized
INFO - 2020-11-23 07:42:01 --> Router Class Initialized
INFO - 2020-11-23 07:42:01 --> Output Class Initialized
INFO - 2020-11-23 07:42:01 --> Security Class Initialized
DEBUG - 2020-11-23 07:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:42:01 --> Input Class Initialized
INFO - 2020-11-23 07:42:01 --> Language Class Initialized
INFO - 2020-11-23 07:42:01 --> Language Class Initialized
INFO - 2020-11-23 07:42:01 --> Config Class Initialized
INFO - 2020-11-23 07:42:01 --> Loader Class Initialized
INFO - 2020-11-23 07:42:01 --> Helper loaded: url_helper
INFO - 2020-11-23 07:42:01 --> Helper loaded: file_helper
INFO - 2020-11-23 07:42:01 --> Helper loaded: form_helper
INFO - 2020-11-23 07:42:01 --> Helper loaded: my_helper
INFO - 2020-11-23 07:42:01 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:42:01 --> Controller Class Initialized
DEBUG - 2020-11-23 07:42:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-23 07:42:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:42:01 --> Final output sent to browser
DEBUG - 2020-11-23 07:42:01 --> Total execution time: 0.2299
INFO - 2020-11-23 07:53:10 --> Config Class Initialized
INFO - 2020-11-23 07:53:10 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:53:10 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:53:10 --> Utf8 Class Initialized
INFO - 2020-11-23 07:53:10 --> URI Class Initialized
INFO - 2020-11-23 07:53:10 --> Router Class Initialized
INFO - 2020-11-23 07:53:10 --> Output Class Initialized
INFO - 2020-11-23 07:53:10 --> Security Class Initialized
DEBUG - 2020-11-23 07:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:53:10 --> Input Class Initialized
INFO - 2020-11-23 07:53:10 --> Language Class Initialized
INFO - 2020-11-23 07:53:10 --> Language Class Initialized
INFO - 2020-11-23 07:53:10 --> Config Class Initialized
INFO - 2020-11-23 07:53:10 --> Loader Class Initialized
INFO - 2020-11-23 07:53:10 --> Helper loaded: url_helper
INFO - 2020-11-23 07:53:10 --> Helper loaded: file_helper
INFO - 2020-11-23 07:53:10 --> Helper loaded: form_helper
INFO - 2020-11-23 07:53:10 --> Helper loaded: my_helper
INFO - 2020-11-23 07:53:10 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:53:10 --> Controller Class Initialized
DEBUG - 2020-11-23 07:53:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 07:53:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:53:10 --> Final output sent to browser
DEBUG - 2020-11-23 07:53:10 --> Total execution time: 0.2285
INFO - 2020-11-23 07:55:18 --> Config Class Initialized
INFO - 2020-11-23 07:55:18 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:55:18 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:55:18 --> Utf8 Class Initialized
INFO - 2020-11-23 07:55:18 --> URI Class Initialized
INFO - 2020-11-23 07:55:18 --> Router Class Initialized
INFO - 2020-11-23 07:55:18 --> Output Class Initialized
INFO - 2020-11-23 07:55:18 --> Security Class Initialized
DEBUG - 2020-11-23 07:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:55:18 --> Input Class Initialized
INFO - 2020-11-23 07:55:18 --> Language Class Initialized
INFO - 2020-11-23 07:55:18 --> Language Class Initialized
INFO - 2020-11-23 07:55:18 --> Config Class Initialized
INFO - 2020-11-23 07:55:18 --> Loader Class Initialized
INFO - 2020-11-23 07:55:18 --> Helper loaded: url_helper
INFO - 2020-11-23 07:55:18 --> Helper loaded: file_helper
INFO - 2020-11-23 07:55:18 --> Helper loaded: form_helper
INFO - 2020-11-23 07:55:18 --> Helper loaded: my_helper
INFO - 2020-11-23 07:55:18 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:55:18 --> Controller Class Initialized
DEBUG - 2020-11-23 07:55:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 07:55:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:55:18 --> Final output sent to browser
DEBUG - 2020-11-23 07:55:18 --> Total execution time: 0.2486
INFO - 2020-11-23 07:59:57 --> Config Class Initialized
INFO - 2020-11-23 07:59:57 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:59:57 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:59:57 --> Utf8 Class Initialized
INFO - 2020-11-23 07:59:57 --> URI Class Initialized
INFO - 2020-11-23 07:59:57 --> Router Class Initialized
INFO - 2020-11-23 07:59:58 --> Output Class Initialized
INFO - 2020-11-23 07:59:58 --> Security Class Initialized
DEBUG - 2020-11-23 07:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:59:58 --> Input Class Initialized
INFO - 2020-11-23 07:59:58 --> Language Class Initialized
INFO - 2020-11-23 07:59:58 --> Language Class Initialized
INFO - 2020-11-23 07:59:58 --> Config Class Initialized
INFO - 2020-11-23 07:59:58 --> Loader Class Initialized
INFO - 2020-11-23 07:59:58 --> Helper loaded: url_helper
INFO - 2020-11-23 07:59:58 --> Helper loaded: file_helper
INFO - 2020-11-23 07:59:58 --> Helper loaded: form_helper
INFO - 2020-11-23 07:59:58 --> Helper loaded: my_helper
INFO - 2020-11-23 07:59:58 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:59:58 --> Controller Class Initialized
DEBUG - 2020-11-23 07:59:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 07:59:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:59:58 --> Final output sent to browser
DEBUG - 2020-11-23 07:59:58 --> Total execution time: 0.2458
INFO - 2020-11-23 08:00:24 --> Config Class Initialized
INFO - 2020-11-23 08:00:24 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:00:24 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:00:24 --> Utf8 Class Initialized
INFO - 2020-11-23 08:00:24 --> URI Class Initialized
INFO - 2020-11-23 08:00:24 --> Router Class Initialized
INFO - 2020-11-23 08:00:24 --> Output Class Initialized
INFO - 2020-11-23 08:00:24 --> Security Class Initialized
DEBUG - 2020-11-23 08:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:00:24 --> Input Class Initialized
INFO - 2020-11-23 08:00:24 --> Language Class Initialized
INFO - 2020-11-23 08:00:24 --> Language Class Initialized
INFO - 2020-11-23 08:00:24 --> Config Class Initialized
INFO - 2020-11-23 08:00:24 --> Loader Class Initialized
INFO - 2020-11-23 08:00:24 --> Helper loaded: url_helper
INFO - 2020-11-23 08:00:24 --> Helper loaded: file_helper
INFO - 2020-11-23 08:00:24 --> Helper loaded: form_helper
INFO - 2020-11-23 08:00:25 --> Helper loaded: my_helper
INFO - 2020-11-23 08:00:25 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:00:25 --> Controller Class Initialized
DEBUG - 2020-11-23 08:00:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:00:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:00:25 --> Final output sent to browser
DEBUG - 2020-11-23 08:00:25 --> Total execution time: 0.2644
INFO - 2020-11-23 08:00:35 --> Config Class Initialized
INFO - 2020-11-23 08:00:35 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:00:35 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:00:35 --> Utf8 Class Initialized
INFO - 2020-11-23 08:00:35 --> URI Class Initialized
INFO - 2020-11-23 08:00:35 --> Router Class Initialized
INFO - 2020-11-23 08:00:35 --> Output Class Initialized
INFO - 2020-11-23 08:00:35 --> Security Class Initialized
DEBUG - 2020-11-23 08:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:00:35 --> Input Class Initialized
INFO - 2020-11-23 08:00:35 --> Language Class Initialized
INFO - 2020-11-23 08:00:35 --> Language Class Initialized
INFO - 2020-11-23 08:00:35 --> Config Class Initialized
INFO - 2020-11-23 08:00:35 --> Loader Class Initialized
INFO - 2020-11-23 08:00:35 --> Helper loaded: url_helper
INFO - 2020-11-23 08:00:35 --> Helper loaded: file_helper
INFO - 2020-11-23 08:00:35 --> Helper loaded: form_helper
INFO - 2020-11-23 08:00:35 --> Helper loaded: my_helper
INFO - 2020-11-23 08:00:35 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:00:35 --> Controller Class Initialized
DEBUG - 2020-11-23 08:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:00:35 --> Final output sent to browser
DEBUG - 2020-11-23 08:00:35 --> Total execution time: 0.2418
INFO - 2020-11-23 08:00:36 --> Config Class Initialized
INFO - 2020-11-23 08:00:37 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:00:37 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:00:37 --> Utf8 Class Initialized
INFO - 2020-11-23 08:00:37 --> URI Class Initialized
INFO - 2020-11-23 08:00:37 --> Router Class Initialized
INFO - 2020-11-23 08:00:37 --> Output Class Initialized
INFO - 2020-11-23 08:00:37 --> Security Class Initialized
DEBUG - 2020-11-23 08:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:00:37 --> Input Class Initialized
INFO - 2020-11-23 08:00:37 --> Language Class Initialized
INFO - 2020-11-23 08:00:37 --> Language Class Initialized
INFO - 2020-11-23 08:00:37 --> Config Class Initialized
INFO - 2020-11-23 08:00:37 --> Loader Class Initialized
INFO - 2020-11-23 08:00:37 --> Helper loaded: url_helper
INFO - 2020-11-23 08:00:37 --> Helper loaded: file_helper
INFO - 2020-11-23 08:00:37 --> Helper loaded: form_helper
INFO - 2020-11-23 08:00:37 --> Helper loaded: my_helper
INFO - 2020-11-23 08:00:37 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:00:37 --> Controller Class Initialized
DEBUG - 2020-11-23 08:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:00:37 --> Final output sent to browser
DEBUG - 2020-11-23 08:00:37 --> Total execution time: 0.2507
INFO - 2020-11-23 08:08:05 --> Config Class Initialized
INFO - 2020-11-23 08:08:05 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:08:05 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:08:05 --> Utf8 Class Initialized
INFO - 2020-11-23 08:08:05 --> URI Class Initialized
INFO - 2020-11-23 08:08:05 --> Router Class Initialized
INFO - 2020-11-23 08:08:05 --> Output Class Initialized
INFO - 2020-11-23 08:08:05 --> Security Class Initialized
DEBUG - 2020-11-23 08:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:08:05 --> Input Class Initialized
INFO - 2020-11-23 08:08:05 --> Language Class Initialized
INFO - 2020-11-23 08:08:05 --> Language Class Initialized
INFO - 2020-11-23 08:08:05 --> Config Class Initialized
INFO - 2020-11-23 08:08:05 --> Loader Class Initialized
INFO - 2020-11-23 08:08:05 --> Helper loaded: url_helper
INFO - 2020-11-23 08:08:05 --> Helper loaded: file_helper
INFO - 2020-11-23 08:08:05 --> Helper loaded: form_helper
INFO - 2020-11-23 08:08:05 --> Helper loaded: my_helper
INFO - 2020-11-23 08:08:05 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:08:05 --> Controller Class Initialized
INFO - 2020-11-23 08:08:05 --> Helper loaded: cookie_helper
INFO - 2020-11-23 08:08:05 --> Config Class Initialized
INFO - 2020-11-23 08:08:05 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:08:05 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:08:05 --> Utf8 Class Initialized
INFO - 2020-11-23 08:08:05 --> URI Class Initialized
INFO - 2020-11-23 08:08:05 --> Router Class Initialized
INFO - 2020-11-23 08:08:05 --> Output Class Initialized
INFO - 2020-11-23 08:08:05 --> Security Class Initialized
DEBUG - 2020-11-23 08:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:08:05 --> Input Class Initialized
INFO - 2020-11-23 08:08:05 --> Language Class Initialized
INFO - 2020-11-23 08:08:05 --> Language Class Initialized
INFO - 2020-11-23 08:08:05 --> Config Class Initialized
INFO - 2020-11-23 08:08:05 --> Loader Class Initialized
INFO - 2020-11-23 08:08:05 --> Helper loaded: url_helper
INFO - 2020-11-23 08:08:05 --> Helper loaded: file_helper
INFO - 2020-11-23 08:08:05 --> Helper loaded: form_helper
INFO - 2020-11-23 08:08:05 --> Helper loaded: my_helper
INFO - 2020-11-23 08:08:05 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:08:05 --> Controller Class Initialized
DEBUG - 2020-11-23 08:08:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 08:08:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:08:05 --> Final output sent to browser
DEBUG - 2020-11-23 08:08:05 --> Total execution time: 0.2317
INFO - 2020-11-23 08:08:12 --> Config Class Initialized
INFO - 2020-11-23 08:08:12 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:08:12 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:08:12 --> Utf8 Class Initialized
INFO - 2020-11-23 08:08:12 --> URI Class Initialized
INFO - 2020-11-23 08:08:12 --> Router Class Initialized
INFO - 2020-11-23 08:08:12 --> Output Class Initialized
INFO - 2020-11-23 08:08:12 --> Security Class Initialized
DEBUG - 2020-11-23 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:08:12 --> Input Class Initialized
INFO - 2020-11-23 08:08:12 --> Language Class Initialized
INFO - 2020-11-23 08:08:12 --> Language Class Initialized
INFO - 2020-11-23 08:08:12 --> Config Class Initialized
INFO - 2020-11-23 08:08:12 --> Loader Class Initialized
INFO - 2020-11-23 08:08:12 --> Helper loaded: url_helper
INFO - 2020-11-23 08:08:12 --> Helper loaded: file_helper
INFO - 2020-11-23 08:08:12 --> Helper loaded: form_helper
INFO - 2020-11-23 08:08:12 --> Helper loaded: my_helper
INFO - 2020-11-23 08:08:12 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:08:12 --> Controller Class Initialized
INFO - 2020-11-23 08:08:12 --> Helper loaded: cookie_helper
INFO - 2020-11-23 08:08:12 --> Final output sent to browser
DEBUG - 2020-11-23 08:08:12 --> Total execution time: 0.2288
INFO - 2020-11-23 08:08:12 --> Config Class Initialized
INFO - 2020-11-23 08:08:12 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:08:12 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:08:12 --> Utf8 Class Initialized
INFO - 2020-11-23 08:08:12 --> URI Class Initialized
INFO - 2020-11-23 08:08:12 --> Router Class Initialized
INFO - 2020-11-23 08:08:12 --> Output Class Initialized
INFO - 2020-11-23 08:08:12 --> Security Class Initialized
DEBUG - 2020-11-23 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:08:12 --> Input Class Initialized
INFO - 2020-11-23 08:08:12 --> Language Class Initialized
INFO - 2020-11-23 08:08:12 --> Language Class Initialized
INFO - 2020-11-23 08:08:12 --> Config Class Initialized
INFO - 2020-11-23 08:08:12 --> Loader Class Initialized
INFO - 2020-11-23 08:08:12 --> Helper loaded: url_helper
INFO - 2020-11-23 08:08:12 --> Helper loaded: file_helper
INFO - 2020-11-23 08:08:12 --> Helper loaded: form_helper
INFO - 2020-11-23 08:08:12 --> Helper loaded: my_helper
INFO - 2020-11-23 08:08:12 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:08:12 --> Controller Class Initialized
DEBUG - 2020-11-23 08:08:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 08:08:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:08:13 --> Final output sent to browser
DEBUG - 2020-11-23 08:08:13 --> Total execution time: 0.2523
INFO - 2020-11-23 08:09:51 --> Config Class Initialized
INFO - 2020-11-23 08:09:51 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:09:51 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:09:51 --> Utf8 Class Initialized
INFO - 2020-11-23 08:09:51 --> URI Class Initialized
INFO - 2020-11-23 08:09:51 --> Router Class Initialized
INFO - 2020-11-23 08:09:51 --> Output Class Initialized
INFO - 2020-11-23 08:09:52 --> Security Class Initialized
DEBUG - 2020-11-23 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:09:52 --> Input Class Initialized
INFO - 2020-11-23 08:09:52 --> Language Class Initialized
INFO - 2020-11-23 08:09:52 --> Language Class Initialized
INFO - 2020-11-23 08:09:52 --> Config Class Initialized
INFO - 2020-11-23 08:09:52 --> Loader Class Initialized
INFO - 2020-11-23 08:09:52 --> Helper loaded: url_helper
INFO - 2020-11-23 08:09:52 --> Helper loaded: file_helper
INFO - 2020-11-23 08:09:52 --> Helper loaded: form_helper
INFO - 2020-11-23 08:09:52 --> Helper loaded: my_helper
INFO - 2020-11-23 08:09:52 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:09:52 --> Controller Class Initialized
DEBUG - 2020-11-23 08:09:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 08:09:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:09:52 --> Final output sent to browser
DEBUG - 2020-11-23 08:09:52 --> Total execution time: 0.2701
INFO - 2020-11-23 08:09:56 --> Config Class Initialized
INFO - 2020-11-23 08:09:56 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:09:56 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:09:56 --> Utf8 Class Initialized
INFO - 2020-11-23 08:09:56 --> URI Class Initialized
INFO - 2020-11-23 08:09:56 --> Router Class Initialized
INFO - 2020-11-23 08:09:56 --> Output Class Initialized
INFO - 2020-11-23 08:09:56 --> Security Class Initialized
DEBUG - 2020-11-23 08:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:09:56 --> Input Class Initialized
INFO - 2020-11-23 08:09:56 --> Language Class Initialized
ERROR - 2020-11-23 08:09:56 --> 404 Page Not Found: /index
INFO - 2020-11-23 08:09:58 --> Config Class Initialized
INFO - 2020-11-23 08:09:58 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:09:58 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:09:58 --> Utf8 Class Initialized
INFO - 2020-11-23 08:09:58 --> URI Class Initialized
INFO - 2020-11-23 08:09:58 --> Router Class Initialized
INFO - 2020-11-23 08:09:58 --> Output Class Initialized
INFO - 2020-11-23 08:09:58 --> Security Class Initialized
DEBUG - 2020-11-23 08:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:09:58 --> Input Class Initialized
INFO - 2020-11-23 08:09:58 --> Language Class Initialized
INFO - 2020-11-23 08:09:58 --> Language Class Initialized
INFO - 2020-11-23 08:09:58 --> Config Class Initialized
INFO - 2020-11-23 08:09:58 --> Loader Class Initialized
INFO - 2020-11-23 08:09:58 --> Helper loaded: url_helper
INFO - 2020-11-23 08:09:58 --> Helper loaded: file_helper
INFO - 2020-11-23 08:09:58 --> Helper loaded: form_helper
INFO - 2020-11-23 08:09:58 --> Helper loaded: my_helper
INFO - 2020-11-23 08:09:58 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:09:58 --> Controller Class Initialized
DEBUG - 2020-11-23 08:09:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 08:09:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:09:58 --> Final output sent to browser
DEBUG - 2020-11-23 08:09:58 --> Total execution time: 0.2456
INFO - 2020-11-23 08:10:01 --> Config Class Initialized
INFO - 2020-11-23 08:10:01 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:10:01 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:10:01 --> Utf8 Class Initialized
INFO - 2020-11-23 08:10:01 --> URI Class Initialized
INFO - 2020-11-23 08:10:01 --> Router Class Initialized
INFO - 2020-11-23 08:10:01 --> Output Class Initialized
INFO - 2020-11-23 08:10:01 --> Security Class Initialized
DEBUG - 2020-11-23 08:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:10:01 --> Input Class Initialized
INFO - 2020-11-23 08:10:01 --> Language Class Initialized
INFO - 2020-11-23 08:10:01 --> Language Class Initialized
INFO - 2020-11-23 08:10:01 --> Config Class Initialized
INFO - 2020-11-23 08:10:01 --> Loader Class Initialized
INFO - 2020-11-23 08:10:01 --> Helper loaded: url_helper
INFO - 2020-11-23 08:10:01 --> Helper loaded: file_helper
INFO - 2020-11-23 08:10:01 --> Helper loaded: form_helper
INFO - 2020-11-23 08:10:01 --> Helper loaded: my_helper
INFO - 2020-11-23 08:10:01 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:10:01 --> Controller Class Initialized
DEBUG - 2020-11-23 08:10:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-23 08:10:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:10:01 --> Final output sent to browser
DEBUG - 2020-11-23 08:10:01 --> Total execution time: 0.2317
INFO - 2020-11-23 08:10:01 --> Config Class Initialized
INFO - 2020-11-23 08:10:01 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:10:01 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:10:01 --> Utf8 Class Initialized
INFO - 2020-11-23 08:10:01 --> URI Class Initialized
INFO - 2020-11-23 08:10:01 --> Router Class Initialized
INFO - 2020-11-23 08:10:01 --> Output Class Initialized
INFO - 2020-11-23 08:10:01 --> Security Class Initialized
DEBUG - 2020-11-23 08:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:10:01 --> Input Class Initialized
INFO - 2020-11-23 08:10:01 --> Language Class Initialized
INFO - 2020-11-23 08:10:01 --> Language Class Initialized
INFO - 2020-11-23 08:10:01 --> Config Class Initialized
INFO - 2020-11-23 08:10:01 --> Loader Class Initialized
INFO - 2020-11-23 08:10:01 --> Helper loaded: url_helper
INFO - 2020-11-23 08:10:01 --> Helper loaded: file_helper
INFO - 2020-11-23 08:10:01 --> Helper loaded: form_helper
INFO - 2020-11-23 08:10:01 --> Helper loaded: my_helper
INFO - 2020-11-23 08:10:01 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:10:01 --> Controller Class Initialized
INFO - 2020-11-23 08:10:04 --> Config Class Initialized
INFO - 2020-11-23 08:10:04 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:10:04 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:10:04 --> Utf8 Class Initialized
INFO - 2020-11-23 08:10:04 --> URI Class Initialized
INFO - 2020-11-23 08:10:04 --> Router Class Initialized
INFO - 2020-11-23 08:10:04 --> Output Class Initialized
INFO - 2020-11-23 08:10:04 --> Security Class Initialized
DEBUG - 2020-11-23 08:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:10:04 --> Input Class Initialized
INFO - 2020-11-23 08:10:04 --> Language Class Initialized
INFO - 2020-11-23 08:10:04 --> Language Class Initialized
INFO - 2020-11-23 08:10:04 --> Config Class Initialized
INFO - 2020-11-23 08:10:04 --> Loader Class Initialized
INFO - 2020-11-23 08:10:04 --> Helper loaded: url_helper
INFO - 2020-11-23 08:10:04 --> Helper loaded: file_helper
INFO - 2020-11-23 08:10:04 --> Helper loaded: form_helper
INFO - 2020-11-23 08:10:04 --> Helper loaded: my_helper
INFO - 2020-11-23 08:10:04 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:10:04 --> Controller Class Initialized
DEBUG - 2020-11-23 08:10:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-23 08:10:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:10:04 --> Final output sent to browser
DEBUG - 2020-11-23 08:10:04 --> Total execution time: 0.2273
INFO - 2020-11-23 08:10:04 --> Config Class Initialized
INFO - 2020-11-23 08:10:04 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:10:04 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:10:04 --> Utf8 Class Initialized
INFO - 2020-11-23 08:10:04 --> URI Class Initialized
INFO - 2020-11-23 08:10:04 --> Router Class Initialized
INFO - 2020-11-23 08:10:04 --> Output Class Initialized
INFO - 2020-11-23 08:10:05 --> Security Class Initialized
DEBUG - 2020-11-23 08:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:10:05 --> Input Class Initialized
INFO - 2020-11-23 08:10:05 --> Language Class Initialized
INFO - 2020-11-23 08:10:05 --> Language Class Initialized
INFO - 2020-11-23 08:10:05 --> Config Class Initialized
INFO - 2020-11-23 08:10:05 --> Loader Class Initialized
INFO - 2020-11-23 08:10:05 --> Helper loaded: url_helper
INFO - 2020-11-23 08:10:05 --> Helper loaded: file_helper
INFO - 2020-11-23 08:10:05 --> Helper loaded: form_helper
INFO - 2020-11-23 08:10:05 --> Helper loaded: my_helper
INFO - 2020-11-23 08:10:05 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:10:05 --> Controller Class Initialized
INFO - 2020-11-23 08:15:08 --> Config Class Initialized
INFO - 2020-11-23 08:15:08 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:15:08 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:15:08 --> Utf8 Class Initialized
INFO - 2020-11-23 08:15:08 --> URI Class Initialized
INFO - 2020-11-23 08:15:08 --> Router Class Initialized
INFO - 2020-11-23 08:15:08 --> Output Class Initialized
INFO - 2020-11-23 08:15:08 --> Security Class Initialized
DEBUG - 2020-11-23 08:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:15:08 --> Input Class Initialized
INFO - 2020-11-23 08:15:08 --> Language Class Initialized
INFO - 2020-11-23 08:15:08 --> Language Class Initialized
INFO - 2020-11-23 08:15:08 --> Config Class Initialized
INFO - 2020-11-23 08:15:08 --> Loader Class Initialized
INFO - 2020-11-23 08:15:08 --> Helper loaded: url_helper
INFO - 2020-11-23 08:15:08 --> Helper loaded: file_helper
INFO - 2020-11-23 08:15:08 --> Helper loaded: form_helper
INFO - 2020-11-23 08:15:09 --> Helper loaded: my_helper
INFO - 2020-11-23 08:15:09 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:15:09 --> Controller Class Initialized
INFO - 2020-11-23 08:15:09 --> Helper loaded: cookie_helper
INFO - 2020-11-23 08:15:09 --> Config Class Initialized
INFO - 2020-11-23 08:15:09 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:15:09 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:15:09 --> Utf8 Class Initialized
INFO - 2020-11-23 08:15:09 --> URI Class Initialized
INFO - 2020-11-23 08:15:09 --> Router Class Initialized
INFO - 2020-11-23 08:15:09 --> Output Class Initialized
INFO - 2020-11-23 08:15:09 --> Security Class Initialized
DEBUG - 2020-11-23 08:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:15:09 --> Input Class Initialized
INFO - 2020-11-23 08:15:09 --> Language Class Initialized
INFO - 2020-11-23 08:15:09 --> Language Class Initialized
INFO - 2020-11-23 08:15:09 --> Config Class Initialized
INFO - 2020-11-23 08:15:09 --> Loader Class Initialized
INFO - 2020-11-23 08:15:09 --> Helper loaded: url_helper
INFO - 2020-11-23 08:15:09 --> Helper loaded: file_helper
INFO - 2020-11-23 08:15:09 --> Helper loaded: form_helper
INFO - 2020-11-23 08:15:09 --> Helper loaded: my_helper
INFO - 2020-11-23 08:15:09 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:15:09 --> Controller Class Initialized
DEBUG - 2020-11-23 08:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 08:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:15:09 --> Final output sent to browser
DEBUG - 2020-11-23 08:15:09 --> Total execution time: 0.2338
INFO - 2020-11-23 08:15:15 --> Config Class Initialized
INFO - 2020-11-23 08:15:15 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:15:15 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:15:15 --> Utf8 Class Initialized
INFO - 2020-11-23 08:15:15 --> URI Class Initialized
INFO - 2020-11-23 08:15:15 --> Router Class Initialized
INFO - 2020-11-23 08:15:15 --> Output Class Initialized
INFO - 2020-11-23 08:15:15 --> Security Class Initialized
DEBUG - 2020-11-23 08:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:15:15 --> Input Class Initialized
INFO - 2020-11-23 08:15:15 --> Language Class Initialized
INFO - 2020-11-23 08:15:15 --> Language Class Initialized
INFO - 2020-11-23 08:15:15 --> Config Class Initialized
INFO - 2020-11-23 08:15:15 --> Loader Class Initialized
INFO - 2020-11-23 08:15:15 --> Helper loaded: url_helper
INFO - 2020-11-23 08:15:15 --> Helper loaded: file_helper
INFO - 2020-11-23 08:15:15 --> Helper loaded: form_helper
INFO - 2020-11-23 08:15:15 --> Helper loaded: my_helper
INFO - 2020-11-23 08:15:15 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:15:15 --> Controller Class Initialized
INFO - 2020-11-23 08:15:15 --> Helper loaded: cookie_helper
INFO - 2020-11-23 08:15:15 --> Final output sent to browser
DEBUG - 2020-11-23 08:15:15 --> Total execution time: 0.2239
INFO - 2020-11-23 08:15:16 --> Config Class Initialized
INFO - 2020-11-23 08:15:16 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:15:16 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:15:16 --> Utf8 Class Initialized
INFO - 2020-11-23 08:15:16 --> URI Class Initialized
INFO - 2020-11-23 08:15:16 --> Router Class Initialized
INFO - 2020-11-23 08:15:16 --> Output Class Initialized
INFO - 2020-11-23 08:15:16 --> Security Class Initialized
DEBUG - 2020-11-23 08:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:15:16 --> Input Class Initialized
INFO - 2020-11-23 08:15:16 --> Language Class Initialized
INFO - 2020-11-23 08:15:16 --> Language Class Initialized
INFO - 2020-11-23 08:15:16 --> Config Class Initialized
INFO - 2020-11-23 08:15:16 --> Loader Class Initialized
INFO - 2020-11-23 08:15:16 --> Helper loaded: url_helper
INFO - 2020-11-23 08:15:16 --> Helper loaded: file_helper
INFO - 2020-11-23 08:15:16 --> Helper loaded: form_helper
INFO - 2020-11-23 08:15:16 --> Helper loaded: my_helper
INFO - 2020-11-23 08:15:16 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:15:16 --> Controller Class Initialized
DEBUG - 2020-11-23 08:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 08:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:15:16 --> Final output sent to browser
DEBUG - 2020-11-23 08:15:16 --> Total execution time: 0.2629
INFO - 2020-11-23 08:15:18 --> Config Class Initialized
INFO - 2020-11-23 08:15:18 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:15:18 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:15:18 --> Utf8 Class Initialized
INFO - 2020-11-23 08:15:19 --> URI Class Initialized
INFO - 2020-11-23 08:15:19 --> Router Class Initialized
INFO - 2020-11-23 08:15:19 --> Output Class Initialized
INFO - 2020-11-23 08:15:19 --> Security Class Initialized
DEBUG - 2020-11-23 08:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:15:19 --> Input Class Initialized
INFO - 2020-11-23 08:15:19 --> Language Class Initialized
INFO - 2020-11-23 08:15:19 --> Language Class Initialized
INFO - 2020-11-23 08:15:19 --> Config Class Initialized
INFO - 2020-11-23 08:15:19 --> Loader Class Initialized
INFO - 2020-11-23 08:15:19 --> Helper loaded: url_helper
INFO - 2020-11-23 08:15:19 --> Helper loaded: file_helper
INFO - 2020-11-23 08:15:19 --> Helper loaded: form_helper
INFO - 2020-11-23 08:15:19 --> Helper loaded: my_helper
INFO - 2020-11-23 08:15:19 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:15:19 --> Controller Class Initialized
DEBUG - 2020-11-23 08:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-23 08:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:15:19 --> Final output sent to browser
DEBUG - 2020-11-23 08:15:19 --> Total execution time: 0.2382
INFO - 2020-11-23 08:15:20 --> Config Class Initialized
INFO - 2020-11-23 08:15:20 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:15:20 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:15:20 --> Utf8 Class Initialized
INFO - 2020-11-23 08:15:20 --> URI Class Initialized
INFO - 2020-11-23 08:15:20 --> Router Class Initialized
INFO - 2020-11-23 08:15:20 --> Output Class Initialized
INFO - 2020-11-23 08:15:20 --> Security Class Initialized
DEBUG - 2020-11-23 08:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:15:20 --> Input Class Initialized
INFO - 2020-11-23 08:15:20 --> Language Class Initialized
INFO - 2020-11-23 08:15:20 --> Language Class Initialized
INFO - 2020-11-23 08:15:20 --> Config Class Initialized
INFO - 2020-11-23 08:15:20 --> Loader Class Initialized
INFO - 2020-11-23 08:15:20 --> Helper loaded: url_helper
INFO - 2020-11-23 08:15:20 --> Helper loaded: file_helper
INFO - 2020-11-23 08:15:20 --> Helper loaded: form_helper
INFO - 2020-11-23 08:15:20 --> Helper loaded: my_helper
INFO - 2020-11-23 08:15:20 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:15:20 --> Controller Class Initialized
INFO - 2020-11-23 08:15:20 --> Final output sent to browser
DEBUG - 2020-11-23 08:15:20 --> Total execution time: 0.1990
INFO - 2020-11-23 08:21:41 --> Config Class Initialized
INFO - 2020-11-23 08:21:41 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:21:41 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:21:41 --> Utf8 Class Initialized
INFO - 2020-11-23 08:21:41 --> URI Class Initialized
INFO - 2020-11-23 08:21:41 --> Router Class Initialized
INFO - 2020-11-23 08:21:41 --> Output Class Initialized
INFO - 2020-11-23 08:21:41 --> Security Class Initialized
DEBUG - 2020-11-23 08:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:21:41 --> Input Class Initialized
INFO - 2020-11-23 08:21:41 --> Language Class Initialized
INFO - 2020-11-23 08:21:41 --> Language Class Initialized
INFO - 2020-11-23 08:21:41 --> Config Class Initialized
INFO - 2020-11-23 08:21:41 --> Loader Class Initialized
INFO - 2020-11-23 08:21:41 --> Helper loaded: url_helper
INFO - 2020-11-23 08:21:41 --> Helper loaded: file_helper
INFO - 2020-11-23 08:21:41 --> Helper loaded: form_helper
INFO - 2020-11-23 08:21:41 --> Helper loaded: my_helper
INFO - 2020-11-23 08:21:41 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:21:41 --> Controller Class Initialized
DEBUG - 2020-11-23 08:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:21:41 --> Final output sent to browser
DEBUG - 2020-11-23 08:21:41 --> Total execution time: 0.2288
INFO - 2020-11-23 08:24:14 --> Config Class Initialized
INFO - 2020-11-23 08:24:14 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:24:14 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:24:14 --> Utf8 Class Initialized
INFO - 2020-11-23 08:24:14 --> URI Class Initialized
INFO - 2020-11-23 08:24:14 --> Router Class Initialized
INFO - 2020-11-23 08:24:14 --> Output Class Initialized
INFO - 2020-11-23 08:24:14 --> Security Class Initialized
DEBUG - 2020-11-23 08:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:24:14 --> Input Class Initialized
INFO - 2020-11-23 08:24:14 --> Language Class Initialized
INFO - 2020-11-23 08:24:14 --> Language Class Initialized
INFO - 2020-11-23 08:24:14 --> Config Class Initialized
INFO - 2020-11-23 08:24:14 --> Loader Class Initialized
INFO - 2020-11-23 08:24:14 --> Helper loaded: url_helper
INFO - 2020-11-23 08:24:14 --> Helper loaded: file_helper
INFO - 2020-11-23 08:24:14 --> Helper loaded: form_helper
INFO - 2020-11-23 08:24:14 --> Helper loaded: my_helper
INFO - 2020-11-23 08:24:14 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:24:14 --> Controller Class Initialized
DEBUG - 2020-11-23 08:24:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:24:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:24:14 --> Final output sent to browser
DEBUG - 2020-11-23 08:24:14 --> Total execution time: 0.2680
INFO - 2020-11-23 08:35:23 --> Config Class Initialized
INFO - 2020-11-23 08:35:23 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:35:23 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:35:23 --> Utf8 Class Initialized
INFO - 2020-11-23 08:35:23 --> URI Class Initialized
INFO - 2020-11-23 08:35:23 --> Router Class Initialized
INFO - 2020-11-23 08:35:23 --> Output Class Initialized
INFO - 2020-11-23 08:35:23 --> Security Class Initialized
DEBUG - 2020-11-23 08:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:35:23 --> Input Class Initialized
INFO - 2020-11-23 08:35:23 --> Language Class Initialized
INFO - 2020-11-23 08:35:23 --> Language Class Initialized
INFO - 2020-11-23 08:35:23 --> Config Class Initialized
INFO - 2020-11-23 08:35:23 --> Loader Class Initialized
INFO - 2020-11-23 08:35:23 --> Helper loaded: url_helper
INFO - 2020-11-23 08:35:23 --> Helper loaded: file_helper
INFO - 2020-11-23 08:35:23 --> Helper loaded: form_helper
INFO - 2020-11-23 08:35:23 --> Helper loaded: my_helper
INFO - 2020-11-23 08:35:23 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:35:23 --> Controller Class Initialized
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:23 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:35:24 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
DEBUG - 2020-11-23 08:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:35:24 --> Final output sent to browser
DEBUG - 2020-11-23 08:35:24 --> Total execution time: 0.5988
INFO - 2020-11-23 08:39:37 --> Config Class Initialized
INFO - 2020-11-23 08:39:37 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:39:37 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:39:37 --> Utf8 Class Initialized
INFO - 2020-11-23 08:39:37 --> URI Class Initialized
INFO - 2020-11-23 08:39:37 --> Router Class Initialized
INFO - 2020-11-23 08:39:37 --> Output Class Initialized
INFO - 2020-11-23 08:39:37 --> Security Class Initialized
DEBUG - 2020-11-23 08:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:39:37 --> Input Class Initialized
INFO - 2020-11-23 08:39:37 --> Language Class Initialized
INFO - 2020-11-23 08:39:37 --> Language Class Initialized
INFO - 2020-11-23 08:39:37 --> Config Class Initialized
INFO - 2020-11-23 08:39:37 --> Loader Class Initialized
INFO - 2020-11-23 08:39:37 --> Helper loaded: url_helper
INFO - 2020-11-23 08:39:37 --> Helper loaded: file_helper
INFO - 2020-11-23 08:39:37 --> Helper loaded: form_helper
INFO - 2020-11-23 08:39:37 --> Helper loaded: my_helper
INFO - 2020-11-23 08:39:37 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:39:37 --> Controller Class Initialized
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
ERROR - 2020-11-23 08:39:37 --> Severity: Notice --> Undefined variable: p_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 45
DEBUG - 2020-11-23 08:39:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:39:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:39:37 --> Final output sent to browser
DEBUG - 2020-11-23 08:39:37 --> Total execution time: 0.6752
INFO - 2020-11-23 08:40:02 --> Config Class Initialized
INFO - 2020-11-23 08:40:02 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:40:02 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:40:02 --> Utf8 Class Initialized
INFO - 2020-11-23 08:40:02 --> URI Class Initialized
INFO - 2020-11-23 08:40:02 --> Router Class Initialized
INFO - 2020-11-23 08:40:02 --> Output Class Initialized
INFO - 2020-11-23 08:40:02 --> Security Class Initialized
DEBUG - 2020-11-23 08:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:40:02 --> Input Class Initialized
INFO - 2020-11-23 08:40:02 --> Language Class Initialized
INFO - 2020-11-23 08:40:02 --> Language Class Initialized
INFO - 2020-11-23 08:40:02 --> Config Class Initialized
INFO - 2020-11-23 08:40:02 --> Loader Class Initialized
INFO - 2020-11-23 08:40:02 --> Helper loaded: url_helper
INFO - 2020-11-23 08:40:02 --> Helper loaded: file_helper
INFO - 2020-11-23 08:40:02 --> Helper loaded: form_helper
INFO - 2020-11-23 08:40:02 --> Helper loaded: my_helper
INFO - 2020-11-23 08:40:02 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:40:02 --> Controller Class Initialized
DEBUG - 2020-11-23 08:40:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:40:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:40:02 --> Final output sent to browser
DEBUG - 2020-11-23 08:40:02 --> Total execution time: 0.2724
INFO - 2020-11-23 08:56:06 --> Config Class Initialized
INFO - 2020-11-23 08:56:06 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:56:06 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:56:06 --> Utf8 Class Initialized
INFO - 2020-11-23 08:56:06 --> URI Class Initialized
INFO - 2020-11-23 08:56:06 --> Router Class Initialized
INFO - 2020-11-23 08:56:06 --> Output Class Initialized
INFO - 2020-11-23 08:56:06 --> Security Class Initialized
DEBUG - 2020-11-23 08:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:56:06 --> Input Class Initialized
INFO - 2020-11-23 08:56:06 --> Language Class Initialized
INFO - 2020-11-23 08:56:06 --> Language Class Initialized
INFO - 2020-11-23 08:56:06 --> Config Class Initialized
INFO - 2020-11-23 08:56:06 --> Loader Class Initialized
INFO - 2020-11-23 08:56:06 --> Helper loaded: url_helper
INFO - 2020-11-23 08:56:06 --> Helper loaded: file_helper
INFO - 2020-11-23 08:56:06 --> Helper loaded: form_helper
INFO - 2020-11-23 08:56:06 --> Helper loaded: my_helper
INFO - 2020-11-23 08:56:06 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:56:06 --> Controller Class Initialized
INFO - 2020-11-23 08:56:06 --> Helper loaded: cookie_helper
INFO - 2020-11-23 08:56:06 --> Config Class Initialized
INFO - 2020-11-23 08:56:06 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:56:06 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:56:06 --> Utf8 Class Initialized
INFO - 2020-11-23 08:56:06 --> URI Class Initialized
INFO - 2020-11-23 08:56:06 --> Router Class Initialized
INFO - 2020-11-23 08:56:06 --> Output Class Initialized
INFO - 2020-11-23 08:56:06 --> Security Class Initialized
DEBUG - 2020-11-23 08:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:56:06 --> Input Class Initialized
INFO - 2020-11-23 08:56:06 --> Language Class Initialized
INFO - 2020-11-23 08:56:06 --> Language Class Initialized
INFO - 2020-11-23 08:56:06 --> Config Class Initialized
INFO - 2020-11-23 08:56:06 --> Loader Class Initialized
INFO - 2020-11-23 08:56:06 --> Helper loaded: url_helper
INFO - 2020-11-23 08:56:06 --> Helper loaded: file_helper
INFO - 2020-11-23 08:56:06 --> Helper loaded: form_helper
INFO - 2020-11-23 08:56:06 --> Helper loaded: my_helper
INFO - 2020-11-23 08:56:06 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:56:06 --> Controller Class Initialized
DEBUG - 2020-11-23 08:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 08:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:56:06 --> Final output sent to browser
DEBUG - 2020-11-23 08:56:06 --> Total execution time: 0.2415
INFO - 2020-11-23 08:56:12 --> Config Class Initialized
INFO - 2020-11-23 08:56:12 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:56:12 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:56:12 --> Utf8 Class Initialized
INFO - 2020-11-23 08:56:12 --> URI Class Initialized
INFO - 2020-11-23 08:56:12 --> Router Class Initialized
INFO - 2020-11-23 08:56:12 --> Output Class Initialized
INFO - 2020-11-23 08:56:12 --> Security Class Initialized
DEBUG - 2020-11-23 08:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:56:12 --> Input Class Initialized
INFO - 2020-11-23 08:56:12 --> Language Class Initialized
INFO - 2020-11-23 08:56:12 --> Language Class Initialized
INFO - 2020-11-23 08:56:12 --> Config Class Initialized
INFO - 2020-11-23 08:56:12 --> Loader Class Initialized
INFO - 2020-11-23 08:56:12 --> Helper loaded: url_helper
INFO - 2020-11-23 08:56:12 --> Helper loaded: file_helper
INFO - 2020-11-23 08:56:12 --> Helper loaded: form_helper
INFO - 2020-11-23 08:56:12 --> Helper loaded: my_helper
INFO - 2020-11-23 08:56:12 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:56:12 --> Controller Class Initialized
INFO - 2020-11-23 08:56:12 --> Helper loaded: cookie_helper
INFO - 2020-11-23 08:56:12 --> Final output sent to browser
DEBUG - 2020-11-23 08:56:12 --> Total execution time: 0.2509
INFO - 2020-11-23 08:56:12 --> Config Class Initialized
INFO - 2020-11-23 08:56:12 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:56:12 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:56:12 --> Utf8 Class Initialized
INFO - 2020-11-23 08:56:12 --> URI Class Initialized
INFO - 2020-11-23 08:56:12 --> Router Class Initialized
INFO - 2020-11-23 08:56:12 --> Output Class Initialized
INFO - 2020-11-23 08:56:12 --> Security Class Initialized
DEBUG - 2020-11-23 08:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:56:12 --> Input Class Initialized
INFO - 2020-11-23 08:56:12 --> Language Class Initialized
INFO - 2020-11-23 08:56:12 --> Language Class Initialized
INFO - 2020-11-23 08:56:12 --> Config Class Initialized
INFO - 2020-11-23 08:56:12 --> Loader Class Initialized
INFO - 2020-11-23 08:56:12 --> Helper loaded: url_helper
INFO - 2020-11-23 08:56:12 --> Helper loaded: file_helper
INFO - 2020-11-23 08:56:12 --> Helper loaded: form_helper
INFO - 2020-11-23 08:56:12 --> Helper loaded: my_helper
INFO - 2020-11-23 08:56:12 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:56:13 --> Controller Class Initialized
DEBUG - 2020-11-23 08:56:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 08:56:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:56:13 --> Final output sent to browser
DEBUG - 2020-11-23 08:56:13 --> Total execution time: 0.2988
INFO - 2020-11-23 08:56:14 --> Config Class Initialized
INFO - 2020-11-23 08:56:14 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:56:14 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:56:14 --> Utf8 Class Initialized
INFO - 2020-11-23 08:56:14 --> URI Class Initialized
INFO - 2020-11-23 08:56:14 --> Router Class Initialized
INFO - 2020-11-23 08:56:14 --> Output Class Initialized
INFO - 2020-11-23 08:56:14 --> Security Class Initialized
DEBUG - 2020-11-23 08:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:56:14 --> Input Class Initialized
INFO - 2020-11-23 08:56:14 --> Language Class Initialized
INFO - 2020-11-23 08:56:14 --> Language Class Initialized
INFO - 2020-11-23 08:56:14 --> Config Class Initialized
INFO - 2020-11-23 08:56:14 --> Loader Class Initialized
INFO - 2020-11-23 08:56:14 --> Helper loaded: url_helper
INFO - 2020-11-23 08:56:14 --> Helper loaded: file_helper
INFO - 2020-11-23 08:56:14 --> Helper loaded: form_helper
INFO - 2020-11-23 08:56:14 --> Helper loaded: my_helper
INFO - 2020-11-23 08:56:14 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:56:14 --> Controller Class Initialized
DEBUG - 2020-11-23 08:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-23 08:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:56:14 --> Final output sent to browser
DEBUG - 2020-11-23 08:56:14 --> Total execution time: 0.2450
INFO - 2020-11-23 08:56:14 --> Config Class Initialized
INFO - 2020-11-23 08:56:14 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:56:14 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:56:14 --> Utf8 Class Initialized
INFO - 2020-11-23 08:56:15 --> URI Class Initialized
INFO - 2020-11-23 08:56:15 --> Router Class Initialized
INFO - 2020-11-23 08:56:15 --> Output Class Initialized
INFO - 2020-11-23 08:56:15 --> Security Class Initialized
DEBUG - 2020-11-23 08:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:56:15 --> Input Class Initialized
INFO - 2020-11-23 08:56:15 --> Language Class Initialized
INFO - 2020-11-23 08:56:15 --> Language Class Initialized
INFO - 2020-11-23 08:56:15 --> Config Class Initialized
INFO - 2020-11-23 08:56:15 --> Loader Class Initialized
INFO - 2020-11-23 08:56:15 --> Helper loaded: url_helper
INFO - 2020-11-23 08:56:15 --> Helper loaded: file_helper
INFO - 2020-11-23 08:56:15 --> Helper loaded: form_helper
INFO - 2020-11-23 08:56:15 --> Helper loaded: my_helper
INFO - 2020-11-23 08:56:15 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:56:15 --> Controller Class Initialized
INFO - 2020-11-23 08:57:06 --> Config Class Initialized
INFO - 2020-11-23 08:57:06 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:57:06 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:57:06 --> Utf8 Class Initialized
INFO - 2020-11-23 08:57:06 --> URI Class Initialized
INFO - 2020-11-23 08:57:06 --> Router Class Initialized
INFO - 2020-11-23 08:57:06 --> Output Class Initialized
INFO - 2020-11-23 08:57:06 --> Security Class Initialized
DEBUG - 2020-11-23 08:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:57:06 --> Input Class Initialized
INFO - 2020-11-23 08:57:06 --> Language Class Initialized
INFO - 2020-11-23 08:57:06 --> Language Class Initialized
INFO - 2020-11-23 08:57:06 --> Config Class Initialized
INFO - 2020-11-23 08:57:06 --> Loader Class Initialized
INFO - 2020-11-23 08:57:06 --> Helper loaded: url_helper
INFO - 2020-11-23 08:57:06 --> Helper loaded: file_helper
INFO - 2020-11-23 08:57:06 --> Helper loaded: form_helper
INFO - 2020-11-23 08:57:06 --> Helper loaded: my_helper
INFO - 2020-11-23 08:57:06 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:57:06 --> Controller Class Initialized
INFO - 2020-11-23 08:57:06 --> Final output sent to browser
DEBUG - 2020-11-23 08:57:06 --> Total execution time: 0.2180
INFO - 2020-11-23 08:57:17 --> Config Class Initialized
INFO - 2020-11-23 08:57:17 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:57:17 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:57:17 --> Utf8 Class Initialized
INFO - 2020-11-23 08:57:17 --> URI Class Initialized
INFO - 2020-11-23 08:57:17 --> Router Class Initialized
INFO - 2020-11-23 08:57:17 --> Output Class Initialized
INFO - 2020-11-23 08:57:17 --> Security Class Initialized
DEBUG - 2020-11-23 08:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:57:17 --> Input Class Initialized
INFO - 2020-11-23 08:57:17 --> Language Class Initialized
INFO - 2020-11-23 08:57:17 --> Language Class Initialized
INFO - 2020-11-23 08:57:17 --> Config Class Initialized
INFO - 2020-11-23 08:57:17 --> Loader Class Initialized
INFO - 2020-11-23 08:57:17 --> Helper loaded: url_helper
INFO - 2020-11-23 08:57:17 --> Helper loaded: file_helper
INFO - 2020-11-23 08:57:17 --> Helper loaded: form_helper
INFO - 2020-11-23 08:57:17 --> Helper loaded: my_helper
INFO - 2020-11-23 08:57:17 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:57:17 --> Controller Class Initialized
INFO - 2020-11-23 08:57:17 --> Helper loaded: cookie_helper
INFO - 2020-11-23 08:57:17 --> Config Class Initialized
INFO - 2020-11-23 08:57:17 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:57:17 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:57:17 --> Utf8 Class Initialized
INFO - 2020-11-23 08:57:17 --> URI Class Initialized
INFO - 2020-11-23 08:57:17 --> Router Class Initialized
INFO - 2020-11-23 08:57:17 --> Output Class Initialized
INFO - 2020-11-23 08:57:17 --> Security Class Initialized
DEBUG - 2020-11-23 08:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:57:17 --> Input Class Initialized
INFO - 2020-11-23 08:57:17 --> Language Class Initialized
INFO - 2020-11-23 08:57:17 --> Language Class Initialized
INFO - 2020-11-23 08:57:17 --> Config Class Initialized
INFO - 2020-11-23 08:57:17 --> Loader Class Initialized
INFO - 2020-11-23 08:57:17 --> Helper loaded: url_helper
INFO - 2020-11-23 08:57:17 --> Helper loaded: file_helper
INFO - 2020-11-23 08:57:17 --> Helper loaded: form_helper
INFO - 2020-11-23 08:57:17 --> Helper loaded: my_helper
INFO - 2020-11-23 08:57:17 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:57:17 --> Controller Class Initialized
DEBUG - 2020-11-23 08:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 08:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:57:17 --> Final output sent to browser
DEBUG - 2020-11-23 08:57:17 --> Total execution time: 0.2361
INFO - 2020-11-23 08:57:22 --> Config Class Initialized
INFO - 2020-11-23 08:57:22 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:57:22 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:57:22 --> Utf8 Class Initialized
INFO - 2020-11-23 08:57:22 --> URI Class Initialized
INFO - 2020-11-23 08:57:22 --> Router Class Initialized
INFO - 2020-11-23 08:57:22 --> Output Class Initialized
INFO - 2020-11-23 08:57:22 --> Security Class Initialized
DEBUG - 2020-11-23 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:57:22 --> Input Class Initialized
INFO - 2020-11-23 08:57:22 --> Language Class Initialized
INFO - 2020-11-23 08:57:22 --> Language Class Initialized
INFO - 2020-11-23 08:57:22 --> Config Class Initialized
INFO - 2020-11-23 08:57:22 --> Loader Class Initialized
INFO - 2020-11-23 08:57:22 --> Helper loaded: url_helper
INFO - 2020-11-23 08:57:22 --> Helper loaded: file_helper
INFO - 2020-11-23 08:57:22 --> Helper loaded: form_helper
INFO - 2020-11-23 08:57:22 --> Helper loaded: my_helper
INFO - 2020-11-23 08:57:22 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:57:22 --> Controller Class Initialized
INFO - 2020-11-23 08:57:22 --> Helper loaded: cookie_helper
INFO - 2020-11-23 08:57:22 --> Final output sent to browser
DEBUG - 2020-11-23 08:57:22 --> Total execution time: 0.2707
INFO - 2020-11-23 08:57:22 --> Config Class Initialized
INFO - 2020-11-23 08:57:22 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:57:22 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:57:22 --> Utf8 Class Initialized
INFO - 2020-11-23 08:57:22 --> URI Class Initialized
INFO - 2020-11-23 08:57:22 --> Router Class Initialized
INFO - 2020-11-23 08:57:22 --> Output Class Initialized
INFO - 2020-11-23 08:57:22 --> Security Class Initialized
DEBUG - 2020-11-23 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:57:22 --> Input Class Initialized
INFO - 2020-11-23 08:57:23 --> Language Class Initialized
INFO - 2020-11-23 08:57:23 --> Language Class Initialized
INFO - 2020-11-23 08:57:23 --> Config Class Initialized
INFO - 2020-11-23 08:57:23 --> Loader Class Initialized
INFO - 2020-11-23 08:57:23 --> Helper loaded: url_helper
INFO - 2020-11-23 08:57:23 --> Helper loaded: file_helper
INFO - 2020-11-23 08:57:23 --> Helper loaded: form_helper
INFO - 2020-11-23 08:57:23 --> Helper loaded: my_helper
INFO - 2020-11-23 08:57:23 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:57:23 --> Controller Class Initialized
DEBUG - 2020-11-23 08:57:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 08:57:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:57:23 --> Final output sent to browser
DEBUG - 2020-11-23 08:57:23 --> Total execution time: 0.2660
INFO - 2020-11-23 08:57:29 --> Config Class Initialized
INFO - 2020-11-23 08:57:29 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:57:29 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:57:29 --> Utf8 Class Initialized
INFO - 2020-11-23 08:57:29 --> URI Class Initialized
INFO - 2020-11-23 08:57:29 --> Router Class Initialized
INFO - 2020-11-23 08:57:29 --> Output Class Initialized
INFO - 2020-11-23 08:57:29 --> Security Class Initialized
DEBUG - 2020-11-23 08:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:57:29 --> Input Class Initialized
INFO - 2020-11-23 08:57:29 --> Language Class Initialized
INFO - 2020-11-23 08:57:29 --> Language Class Initialized
INFO - 2020-11-23 08:57:29 --> Config Class Initialized
INFO - 2020-11-23 08:57:29 --> Loader Class Initialized
INFO - 2020-11-23 08:57:29 --> Helper loaded: url_helper
INFO - 2020-11-23 08:57:29 --> Helper loaded: file_helper
INFO - 2020-11-23 08:57:29 --> Helper loaded: form_helper
INFO - 2020-11-23 08:57:29 --> Helper loaded: my_helper
INFO - 2020-11-23 08:57:29 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:57:29 --> Controller Class Initialized
DEBUG - 2020-11-23 08:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:57:29 --> Final output sent to browser
DEBUG - 2020-11-23 08:57:29 --> Total execution time: 0.2733
INFO - 2020-11-23 08:59:43 --> Config Class Initialized
INFO - 2020-11-23 08:59:43 --> Hooks Class Initialized
DEBUG - 2020-11-23 08:59:43 --> UTF-8 Support Enabled
INFO - 2020-11-23 08:59:43 --> Utf8 Class Initialized
INFO - 2020-11-23 08:59:43 --> URI Class Initialized
INFO - 2020-11-23 08:59:43 --> Router Class Initialized
INFO - 2020-11-23 08:59:43 --> Output Class Initialized
INFO - 2020-11-23 08:59:43 --> Security Class Initialized
DEBUG - 2020-11-23 08:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 08:59:43 --> Input Class Initialized
INFO - 2020-11-23 08:59:43 --> Language Class Initialized
INFO - 2020-11-23 08:59:44 --> Language Class Initialized
INFO - 2020-11-23 08:59:44 --> Config Class Initialized
INFO - 2020-11-23 08:59:44 --> Loader Class Initialized
INFO - 2020-11-23 08:59:44 --> Helper loaded: url_helper
INFO - 2020-11-23 08:59:44 --> Helper loaded: file_helper
INFO - 2020-11-23 08:59:44 --> Helper loaded: form_helper
INFO - 2020-11-23 08:59:44 --> Helper loaded: my_helper
INFO - 2020-11-23 08:59:44 --> Database Driver Class Initialized
DEBUG - 2020-11-23 08:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 08:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 08:59:44 --> Controller Class Initialized
DEBUG - 2020-11-23 08:59:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-23 08:59:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 08:59:44 --> Final output sent to browser
DEBUG - 2020-11-23 08:59:44 --> Total execution time: 0.2683
INFO - 2020-11-23 07:05:22 --> Config Class Initialized
INFO - 2020-11-23 07:05:22 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:05:22 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:05:22 --> Utf8 Class Initialized
INFO - 2020-11-23 07:05:22 --> URI Class Initialized
INFO - 2020-11-23 07:05:22 --> Router Class Initialized
INFO - 2020-11-23 07:05:22 --> Output Class Initialized
INFO - 2020-11-23 07:05:22 --> Security Class Initialized
DEBUG - 2020-11-23 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:05:22 --> Input Class Initialized
INFO - 2020-11-23 07:05:22 --> Language Class Initialized
INFO - 2020-11-23 07:05:22 --> Language Class Initialized
INFO - 2020-11-23 07:05:22 --> Config Class Initialized
INFO - 2020-11-23 07:05:22 --> Loader Class Initialized
INFO - 2020-11-23 07:05:22 --> Helper loaded: url_helper
INFO - 2020-11-23 07:05:22 --> Helper loaded: file_helper
INFO - 2020-11-23 07:05:22 --> Helper loaded: form_helper
INFO - 2020-11-23 07:05:22 --> Helper loaded: my_helper
INFO - 2020-11-23 07:05:22 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:05:22 --> Controller Class Initialized
INFO - 2020-11-23 07:05:22 --> Helper loaded: cookie_helper
INFO - 2020-11-23 07:05:22 --> Config Class Initialized
INFO - 2020-11-23 07:05:22 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:05:22 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:05:22 --> Utf8 Class Initialized
INFO - 2020-11-23 07:05:22 --> URI Class Initialized
INFO - 2020-11-23 07:05:22 --> Router Class Initialized
INFO - 2020-11-23 07:05:22 --> Output Class Initialized
INFO - 2020-11-23 07:05:22 --> Security Class Initialized
DEBUG - 2020-11-23 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:05:22 --> Input Class Initialized
INFO - 2020-11-23 07:05:22 --> Language Class Initialized
INFO - 2020-11-23 07:05:22 --> Language Class Initialized
INFO - 2020-11-23 07:05:22 --> Config Class Initialized
INFO - 2020-11-23 07:05:22 --> Loader Class Initialized
INFO - 2020-11-23 07:05:22 --> Helper loaded: url_helper
INFO - 2020-11-23 07:05:22 --> Helper loaded: file_helper
INFO - 2020-11-23 07:05:22 --> Helper loaded: form_helper
INFO - 2020-11-23 07:05:22 --> Helper loaded: my_helper
INFO - 2020-11-23 07:05:22 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:05:22 --> Controller Class Initialized
DEBUG - 2020-11-23 07:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 07:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:05:22 --> Final output sent to browser
DEBUG - 2020-11-23 07:05:22 --> Total execution time: 0.0402
INFO - 2020-11-23 07:05:29 --> Config Class Initialized
INFO - 2020-11-23 07:05:29 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:05:29 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:05:29 --> Utf8 Class Initialized
INFO - 2020-11-23 07:05:29 --> URI Class Initialized
INFO - 2020-11-23 07:05:29 --> Router Class Initialized
INFO - 2020-11-23 07:05:29 --> Output Class Initialized
INFO - 2020-11-23 07:05:29 --> Security Class Initialized
DEBUG - 2020-11-23 07:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:05:29 --> Input Class Initialized
INFO - 2020-11-23 07:05:29 --> Language Class Initialized
INFO - 2020-11-23 07:05:29 --> Language Class Initialized
INFO - 2020-11-23 07:05:29 --> Config Class Initialized
INFO - 2020-11-23 07:05:29 --> Loader Class Initialized
INFO - 2020-11-23 07:05:29 --> Helper loaded: url_helper
INFO - 2020-11-23 07:05:29 --> Helper loaded: file_helper
INFO - 2020-11-23 07:05:29 --> Helper loaded: form_helper
INFO - 2020-11-23 07:05:29 --> Helper loaded: my_helper
INFO - 2020-11-23 07:05:29 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:05:29 --> Controller Class Initialized
INFO - 2020-11-23 07:05:29 --> Helper loaded: cookie_helper
INFO - 2020-11-23 07:05:29 --> Final output sent to browser
DEBUG - 2020-11-23 07:05:29 --> Total execution time: 0.0511
INFO - 2020-11-23 07:05:29 --> Config Class Initialized
INFO - 2020-11-23 07:05:29 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:05:29 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:05:29 --> Utf8 Class Initialized
INFO - 2020-11-23 07:05:29 --> URI Class Initialized
INFO - 2020-11-23 07:05:29 --> Router Class Initialized
INFO - 2020-11-23 07:05:29 --> Output Class Initialized
INFO - 2020-11-23 07:05:29 --> Security Class Initialized
DEBUG - 2020-11-23 07:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:05:29 --> Input Class Initialized
INFO - 2020-11-23 07:05:29 --> Language Class Initialized
INFO - 2020-11-23 07:05:29 --> Language Class Initialized
INFO - 2020-11-23 07:05:29 --> Config Class Initialized
INFO - 2020-11-23 07:05:29 --> Loader Class Initialized
INFO - 2020-11-23 07:05:29 --> Helper loaded: url_helper
INFO - 2020-11-23 07:05:29 --> Helper loaded: file_helper
INFO - 2020-11-23 07:05:29 --> Helper loaded: form_helper
INFO - 2020-11-23 07:05:29 --> Helper loaded: my_helper
INFO - 2020-11-23 07:05:29 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:05:29 --> Controller Class Initialized
DEBUG - 2020-11-23 07:05:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-23 07:05:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:05:30 --> Final output sent to browser
DEBUG - 2020-11-23 07:05:30 --> Total execution time: 0.6471
INFO - 2020-11-23 07:05:34 --> Config Class Initialized
INFO - 2020-11-23 07:05:34 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:05:34 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:05:34 --> Utf8 Class Initialized
INFO - 2020-11-23 07:05:34 --> URI Class Initialized
INFO - 2020-11-23 07:05:34 --> Router Class Initialized
INFO - 2020-11-23 07:05:34 --> Output Class Initialized
INFO - 2020-11-23 07:05:34 --> Security Class Initialized
DEBUG - 2020-11-23 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:05:34 --> Input Class Initialized
INFO - 2020-11-23 07:05:34 --> Language Class Initialized
INFO - 2020-11-23 07:05:34 --> Language Class Initialized
INFO - 2020-11-23 07:05:34 --> Config Class Initialized
INFO - 2020-11-23 07:05:34 --> Loader Class Initialized
INFO - 2020-11-23 07:05:34 --> Helper loaded: url_helper
INFO - 2020-11-23 07:05:34 --> Helper loaded: file_helper
INFO - 2020-11-23 07:05:34 --> Helper loaded: form_helper
INFO - 2020-11-23 07:05:34 --> Helper loaded: my_helper
INFO - 2020-11-23 07:05:34 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:05:34 --> Controller Class Initialized
INFO - 2020-11-23 07:05:34 --> Helper loaded: cookie_helper
INFO - 2020-11-23 07:05:34 --> Config Class Initialized
INFO - 2020-11-23 07:05:34 --> Hooks Class Initialized
DEBUG - 2020-11-23 07:05:34 --> UTF-8 Support Enabled
INFO - 2020-11-23 07:05:34 --> Utf8 Class Initialized
INFO - 2020-11-23 07:05:34 --> URI Class Initialized
INFO - 2020-11-23 07:05:34 --> Router Class Initialized
INFO - 2020-11-23 07:05:34 --> Output Class Initialized
INFO - 2020-11-23 07:05:34 --> Security Class Initialized
DEBUG - 2020-11-23 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-23 07:05:34 --> Input Class Initialized
INFO - 2020-11-23 07:05:34 --> Language Class Initialized
INFO - 2020-11-23 07:05:34 --> Language Class Initialized
INFO - 2020-11-23 07:05:34 --> Config Class Initialized
INFO - 2020-11-23 07:05:34 --> Loader Class Initialized
INFO - 2020-11-23 07:05:34 --> Helper loaded: url_helper
INFO - 2020-11-23 07:05:34 --> Helper loaded: file_helper
INFO - 2020-11-23 07:05:34 --> Helper loaded: form_helper
INFO - 2020-11-23 07:05:34 --> Helper loaded: my_helper
INFO - 2020-11-23 07:05:34 --> Database Driver Class Initialized
DEBUG - 2020-11-23 07:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-23 07:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-23 07:05:34 --> Controller Class Initialized
DEBUG - 2020-11-23 07:05:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-23 07:05:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-23 07:05:34 --> Final output sent to browser
DEBUG - 2020-11-23 07:05:34 --> Total execution time: 0.0479
