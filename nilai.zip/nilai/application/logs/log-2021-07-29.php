<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-29 02:34:15 --> Config Class Initialized
INFO - 2021-07-29 02:34:15 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:34:15 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:34:15 --> Utf8 Class Initialized
INFO - 2021-07-29 02:34:15 --> URI Class Initialized
INFO - 2021-07-29 02:34:15 --> Router Class Initialized
INFO - 2021-07-29 02:34:15 --> Output Class Initialized
INFO - 2021-07-29 02:34:15 --> Security Class Initialized
DEBUG - 2021-07-29 02:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:34:15 --> Input Class Initialized
INFO - 2021-07-29 02:34:15 --> Language Class Initialized
INFO - 2021-07-29 02:34:15 --> Language Class Initialized
INFO - 2021-07-29 02:34:15 --> Config Class Initialized
INFO - 2021-07-29 02:34:15 --> Loader Class Initialized
INFO - 2021-07-29 02:34:15 --> Helper loaded: url_helper
INFO - 2021-07-29 02:34:15 --> Helper loaded: file_helper
INFO - 2021-07-29 02:34:15 --> Helper loaded: form_helper
INFO - 2021-07-29 02:34:15 --> Helper loaded: my_helper
INFO - 2021-07-29 02:34:15 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:34:15 --> Controller Class Initialized
INFO - 2021-07-29 02:34:15 --> Config Class Initialized
INFO - 2021-07-29 02:34:15 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:34:15 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:34:15 --> Utf8 Class Initialized
INFO - 2021-07-29 02:34:15 --> URI Class Initialized
INFO - 2021-07-29 02:34:15 --> Router Class Initialized
INFO - 2021-07-29 02:34:15 --> Output Class Initialized
INFO - 2021-07-29 02:34:15 --> Security Class Initialized
DEBUG - 2021-07-29 02:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:34:15 --> Input Class Initialized
INFO - 2021-07-29 02:34:15 --> Language Class Initialized
INFO - 2021-07-29 02:34:15 --> Language Class Initialized
INFO - 2021-07-29 02:34:15 --> Config Class Initialized
INFO - 2021-07-29 02:34:15 --> Loader Class Initialized
INFO - 2021-07-29 02:34:15 --> Helper loaded: url_helper
INFO - 2021-07-29 02:34:15 --> Helper loaded: file_helper
INFO - 2021-07-29 02:34:15 --> Helper loaded: form_helper
INFO - 2021-07-29 02:34:15 --> Helper loaded: my_helper
INFO - 2021-07-29 02:34:15 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:34:15 --> Controller Class Initialized
DEBUG - 2021-07-29 02:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-29 02:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:34:15 --> Final output sent to browser
DEBUG - 2021-07-29 02:34:15 --> Total execution time: 0.0447
INFO - 2021-07-29 02:34:20 --> Config Class Initialized
INFO - 2021-07-29 02:34:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:34:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:34:20 --> Utf8 Class Initialized
INFO - 2021-07-29 02:34:20 --> URI Class Initialized
INFO - 2021-07-29 02:34:20 --> Router Class Initialized
INFO - 2021-07-29 02:34:20 --> Output Class Initialized
INFO - 2021-07-29 02:34:20 --> Security Class Initialized
DEBUG - 2021-07-29 02:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:34:20 --> Input Class Initialized
INFO - 2021-07-29 02:34:20 --> Language Class Initialized
INFO - 2021-07-29 02:34:20 --> Language Class Initialized
INFO - 2021-07-29 02:34:20 --> Config Class Initialized
INFO - 2021-07-29 02:34:20 --> Loader Class Initialized
INFO - 2021-07-29 02:34:20 --> Helper loaded: url_helper
INFO - 2021-07-29 02:34:20 --> Helper loaded: file_helper
INFO - 2021-07-29 02:34:20 --> Helper loaded: form_helper
INFO - 2021-07-29 02:34:20 --> Helper loaded: my_helper
INFO - 2021-07-29 02:34:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:34:20 --> Controller Class Initialized
INFO - 2021-07-29 02:34:20 --> Helper loaded: cookie_helper
INFO - 2021-07-29 02:34:20 --> Final output sent to browser
DEBUG - 2021-07-29 02:34:20 --> Total execution time: 0.0604
INFO - 2021-07-29 02:34:20 --> Config Class Initialized
INFO - 2021-07-29 02:34:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:34:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:34:20 --> Utf8 Class Initialized
INFO - 2021-07-29 02:34:20 --> URI Class Initialized
INFO - 2021-07-29 02:34:20 --> Router Class Initialized
INFO - 2021-07-29 02:34:20 --> Output Class Initialized
INFO - 2021-07-29 02:34:20 --> Security Class Initialized
DEBUG - 2021-07-29 02:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:34:20 --> Input Class Initialized
INFO - 2021-07-29 02:34:20 --> Language Class Initialized
INFO - 2021-07-29 02:34:20 --> Language Class Initialized
INFO - 2021-07-29 02:34:20 --> Config Class Initialized
INFO - 2021-07-29 02:34:20 --> Loader Class Initialized
INFO - 2021-07-29 02:34:20 --> Helper loaded: url_helper
INFO - 2021-07-29 02:34:20 --> Helper loaded: file_helper
INFO - 2021-07-29 02:34:20 --> Helper loaded: form_helper
INFO - 2021-07-29 02:34:20 --> Helper loaded: my_helper
INFO - 2021-07-29 02:34:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:34:20 --> Controller Class Initialized
DEBUG - 2021-07-29 02:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-29 02:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:34:21 --> Final output sent to browser
DEBUG - 2021-07-29 02:34:21 --> Total execution time: 0.5522
INFO - 2021-07-29 02:34:23 --> Config Class Initialized
INFO - 2021-07-29 02:34:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:34:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:34:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:34:23 --> URI Class Initialized
INFO - 2021-07-29 02:34:23 --> Router Class Initialized
INFO - 2021-07-29 02:34:23 --> Output Class Initialized
INFO - 2021-07-29 02:34:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:34:23 --> Input Class Initialized
INFO - 2021-07-29 02:34:23 --> Language Class Initialized
INFO - 2021-07-29 02:34:23 --> Language Class Initialized
INFO - 2021-07-29 02:34:23 --> Config Class Initialized
INFO - 2021-07-29 02:34:23 --> Loader Class Initialized
INFO - 2021-07-29 02:34:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:34:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:34:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:34:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:34:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:34:23 --> Controller Class Initialized
DEBUG - 2021-07-29 02:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-07-29 02:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:34:23 --> Final output sent to browser
DEBUG - 2021-07-29 02:34:23 --> Total execution time: 0.0815
INFO - 2021-07-29 02:34:23 --> Config Class Initialized
INFO - 2021-07-29 02:34:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:34:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:34:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:34:23 --> URI Class Initialized
INFO - 2021-07-29 02:34:23 --> Router Class Initialized
INFO - 2021-07-29 02:34:23 --> Output Class Initialized
INFO - 2021-07-29 02:34:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:34:23 --> Input Class Initialized
INFO - 2021-07-29 02:34:23 --> Language Class Initialized
INFO - 2021-07-29 02:34:23 --> Language Class Initialized
INFO - 2021-07-29 02:34:23 --> Config Class Initialized
INFO - 2021-07-29 02:34:23 --> Loader Class Initialized
INFO - 2021-07-29 02:34:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:34:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:34:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:34:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:34:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:34:23 --> Controller Class Initialized
INFO - 2021-07-29 02:34:27 --> Config Class Initialized
INFO - 2021-07-29 02:34:27 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:34:27 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:34:27 --> Utf8 Class Initialized
INFO - 2021-07-29 02:34:27 --> URI Class Initialized
INFO - 2021-07-29 02:34:27 --> Router Class Initialized
INFO - 2021-07-29 02:34:27 --> Output Class Initialized
INFO - 2021-07-29 02:34:27 --> Security Class Initialized
DEBUG - 2021-07-29 02:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:34:27 --> Input Class Initialized
INFO - 2021-07-29 02:34:27 --> Language Class Initialized
INFO - 2021-07-29 02:34:27 --> Language Class Initialized
INFO - 2021-07-29 02:34:27 --> Config Class Initialized
INFO - 2021-07-29 02:34:27 --> Loader Class Initialized
INFO - 2021-07-29 02:34:27 --> Helper loaded: url_helper
INFO - 2021-07-29 02:34:27 --> Helper loaded: file_helper
INFO - 2021-07-29 02:34:27 --> Helper loaded: form_helper
INFO - 2021-07-29 02:34:27 --> Helper loaded: my_helper
INFO - 2021-07-29 02:34:27 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:34:27 --> Controller Class Initialized
INFO - 2021-07-29 02:34:27 --> Final output sent to browser
DEBUG - 2021-07-29 02:34:27 --> Total execution time: 0.0414
INFO - 2021-07-29 02:35:24 --> Config Class Initialized
INFO - 2021-07-29 02:35:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:24 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:24 --> URI Class Initialized
INFO - 2021-07-29 02:35:24 --> Router Class Initialized
INFO - 2021-07-29 02:35:24 --> Output Class Initialized
INFO - 2021-07-29 02:35:24 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:24 --> Input Class Initialized
INFO - 2021-07-29 02:35:24 --> Language Class Initialized
INFO - 2021-07-29 02:35:24 --> Language Class Initialized
INFO - 2021-07-29 02:35:24 --> Config Class Initialized
INFO - 2021-07-29 02:35:24 --> Loader Class Initialized
INFO - 2021-07-29 02:35:24 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:24 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:24 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:24 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:24 --> Controller Class Initialized
INFO - 2021-07-29 02:35:24 --> Final output sent to browser
DEBUG - 2021-07-29 02:35:24 --> Total execution time: 0.0447
INFO - 2021-07-29 02:35:24 --> Config Class Initialized
INFO - 2021-07-29 02:35:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:24 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:24 --> URI Class Initialized
INFO - 2021-07-29 02:35:24 --> Router Class Initialized
INFO - 2021-07-29 02:35:24 --> Output Class Initialized
INFO - 2021-07-29 02:35:24 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:24 --> Input Class Initialized
INFO - 2021-07-29 02:35:24 --> Language Class Initialized
INFO - 2021-07-29 02:35:24 --> Language Class Initialized
INFO - 2021-07-29 02:35:24 --> Config Class Initialized
INFO - 2021-07-29 02:35:24 --> Loader Class Initialized
INFO - 2021-07-29 02:35:24 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:24 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:24 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:24 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:24 --> Controller Class Initialized
INFO - 2021-07-29 02:35:26 --> Config Class Initialized
INFO - 2021-07-29 02:35:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:26 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:26 --> URI Class Initialized
INFO - 2021-07-29 02:35:26 --> Router Class Initialized
INFO - 2021-07-29 02:35:26 --> Output Class Initialized
INFO - 2021-07-29 02:35:26 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:26 --> Input Class Initialized
INFO - 2021-07-29 02:35:26 --> Language Class Initialized
INFO - 2021-07-29 02:35:26 --> Language Class Initialized
INFO - 2021-07-29 02:35:26 --> Config Class Initialized
INFO - 2021-07-29 02:35:26 --> Loader Class Initialized
INFO - 2021-07-29 02:35:26 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:26 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:26 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:26 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:26 --> Controller Class Initialized
INFO - 2021-07-29 02:35:26 --> Final output sent to browser
DEBUG - 2021-07-29 02:35:26 --> Total execution time: 0.0460
INFO - 2021-07-29 02:35:26 --> Config Class Initialized
INFO - 2021-07-29 02:35:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:26 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:26 --> URI Class Initialized
INFO - 2021-07-29 02:35:26 --> Router Class Initialized
INFO - 2021-07-29 02:35:26 --> Output Class Initialized
INFO - 2021-07-29 02:35:26 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:26 --> Input Class Initialized
INFO - 2021-07-29 02:35:26 --> Language Class Initialized
INFO - 2021-07-29 02:35:26 --> Language Class Initialized
INFO - 2021-07-29 02:35:26 --> Config Class Initialized
INFO - 2021-07-29 02:35:26 --> Loader Class Initialized
INFO - 2021-07-29 02:35:26 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:26 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:26 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:26 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:26 --> Controller Class Initialized
INFO - 2021-07-29 02:35:31 --> Config Class Initialized
INFO - 2021-07-29 02:35:31 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:31 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:31 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:31 --> URI Class Initialized
INFO - 2021-07-29 02:35:31 --> Router Class Initialized
INFO - 2021-07-29 02:35:31 --> Output Class Initialized
INFO - 2021-07-29 02:35:31 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:31 --> Input Class Initialized
INFO - 2021-07-29 02:35:31 --> Language Class Initialized
INFO - 2021-07-29 02:35:31 --> Language Class Initialized
INFO - 2021-07-29 02:35:31 --> Config Class Initialized
INFO - 2021-07-29 02:35:31 --> Loader Class Initialized
INFO - 2021-07-29 02:35:31 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:31 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:31 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:31 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:31 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:31 --> Controller Class Initialized
INFO - 2021-07-29 02:35:31 --> Helper loaded: cookie_helper
INFO - 2021-07-29 02:35:31 --> Config Class Initialized
INFO - 2021-07-29 02:35:31 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:31 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:31 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:31 --> URI Class Initialized
INFO - 2021-07-29 02:35:31 --> Router Class Initialized
INFO - 2021-07-29 02:35:31 --> Output Class Initialized
INFO - 2021-07-29 02:35:31 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:31 --> Input Class Initialized
INFO - 2021-07-29 02:35:31 --> Language Class Initialized
INFO - 2021-07-29 02:35:31 --> Language Class Initialized
INFO - 2021-07-29 02:35:31 --> Config Class Initialized
INFO - 2021-07-29 02:35:31 --> Loader Class Initialized
INFO - 2021-07-29 02:35:31 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:31 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:31 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:31 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:31 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:31 --> Controller Class Initialized
DEBUG - 2021-07-29 02:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-29 02:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:35:31 --> Final output sent to browser
DEBUG - 2021-07-29 02:35:31 --> Total execution time: 0.0632
INFO - 2021-07-29 02:35:36 --> Config Class Initialized
INFO - 2021-07-29 02:35:36 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:36 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:36 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:36 --> URI Class Initialized
INFO - 2021-07-29 02:35:36 --> Router Class Initialized
INFO - 2021-07-29 02:35:36 --> Output Class Initialized
INFO - 2021-07-29 02:35:36 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:36 --> Input Class Initialized
INFO - 2021-07-29 02:35:36 --> Language Class Initialized
INFO - 2021-07-29 02:35:36 --> Language Class Initialized
INFO - 2021-07-29 02:35:36 --> Config Class Initialized
INFO - 2021-07-29 02:35:36 --> Loader Class Initialized
INFO - 2021-07-29 02:35:36 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:36 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:36 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:36 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:36 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:36 --> Controller Class Initialized
INFO - 2021-07-29 02:35:36 --> Helper loaded: cookie_helper
INFO - 2021-07-29 02:35:36 --> Final output sent to browser
DEBUG - 2021-07-29 02:35:36 --> Total execution time: 0.0420
INFO - 2021-07-29 02:35:36 --> Config Class Initialized
INFO - 2021-07-29 02:35:36 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:36 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:36 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:36 --> URI Class Initialized
INFO - 2021-07-29 02:35:36 --> Router Class Initialized
INFO - 2021-07-29 02:35:36 --> Output Class Initialized
INFO - 2021-07-29 02:35:36 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:36 --> Input Class Initialized
INFO - 2021-07-29 02:35:36 --> Language Class Initialized
INFO - 2021-07-29 02:35:36 --> Language Class Initialized
INFO - 2021-07-29 02:35:36 --> Config Class Initialized
INFO - 2021-07-29 02:35:36 --> Loader Class Initialized
INFO - 2021-07-29 02:35:36 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:36 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:36 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:36 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:36 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:36 --> Controller Class Initialized
DEBUG - 2021-07-29 02:35:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-29 02:35:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:35:36 --> Final output sent to browser
DEBUG - 2021-07-29 02:35:36 --> Total execution time: 0.0820
INFO - 2021-07-29 02:35:39 --> Config Class Initialized
INFO - 2021-07-29 02:35:39 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:39 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:39 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:39 --> URI Class Initialized
INFO - 2021-07-29 02:35:39 --> Router Class Initialized
INFO - 2021-07-29 02:35:39 --> Output Class Initialized
INFO - 2021-07-29 02:35:39 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:39 --> Input Class Initialized
INFO - 2021-07-29 02:35:39 --> Language Class Initialized
INFO - 2021-07-29 02:35:39 --> Language Class Initialized
INFO - 2021-07-29 02:35:39 --> Config Class Initialized
INFO - 2021-07-29 02:35:39 --> Loader Class Initialized
INFO - 2021-07-29 02:35:39 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:39 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:39 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:39 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:39 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:39 --> Controller Class Initialized
DEBUG - 2021-07-29 02:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:35:39 --> Final output sent to browser
DEBUG - 2021-07-29 02:35:39 --> Total execution time: 0.0914
INFO - 2021-07-29 02:35:39 --> Config Class Initialized
INFO - 2021-07-29 02:35:39 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:39 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:39 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:39 --> URI Class Initialized
INFO - 2021-07-29 02:35:39 --> Router Class Initialized
INFO - 2021-07-29 02:35:39 --> Output Class Initialized
INFO - 2021-07-29 02:35:39 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:39 --> Input Class Initialized
INFO - 2021-07-29 02:35:39 --> Language Class Initialized
INFO - 2021-07-29 02:35:39 --> Language Class Initialized
INFO - 2021-07-29 02:35:39 --> Config Class Initialized
INFO - 2021-07-29 02:35:39 --> Loader Class Initialized
INFO - 2021-07-29 02:35:39 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:39 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:39 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:39 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:39 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:39 --> Controller Class Initialized
INFO - 2021-07-29 02:35:42 --> Config Class Initialized
INFO - 2021-07-29 02:35:42 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:42 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:42 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:42 --> URI Class Initialized
INFO - 2021-07-29 02:35:42 --> Router Class Initialized
INFO - 2021-07-29 02:35:42 --> Output Class Initialized
INFO - 2021-07-29 02:35:42 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:42 --> Input Class Initialized
INFO - 2021-07-29 02:35:42 --> Language Class Initialized
INFO - 2021-07-29 02:35:42 --> Language Class Initialized
INFO - 2021-07-29 02:35:42 --> Config Class Initialized
INFO - 2021-07-29 02:35:42 --> Loader Class Initialized
INFO - 2021-07-29 02:35:42 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:42 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:42 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:42 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:42 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:42 --> Controller Class Initialized
DEBUG - 2021-07-29 02:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:35:42 --> Final output sent to browser
DEBUG - 2021-07-29 02:35:42 --> Total execution time: 0.0760
INFO - 2021-07-29 02:35:57 --> Config Class Initialized
INFO - 2021-07-29 02:35:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:57 --> URI Class Initialized
INFO - 2021-07-29 02:35:57 --> Router Class Initialized
INFO - 2021-07-29 02:35:57 --> Output Class Initialized
INFO - 2021-07-29 02:35:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:57 --> Input Class Initialized
INFO - 2021-07-29 02:35:57 --> Language Class Initialized
INFO - 2021-07-29 02:35:57 --> Language Class Initialized
INFO - 2021-07-29 02:35:57 --> Config Class Initialized
INFO - 2021-07-29 02:35:57 --> Loader Class Initialized
INFO - 2021-07-29 02:35:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:57 --> Controller Class Initialized
INFO - 2021-07-29 02:35:57 --> Config Class Initialized
INFO - 2021-07-29 02:35:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:57 --> URI Class Initialized
INFO - 2021-07-29 02:35:57 --> Router Class Initialized
INFO - 2021-07-29 02:35:57 --> Output Class Initialized
INFO - 2021-07-29 02:35:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:57 --> Input Class Initialized
INFO - 2021-07-29 02:35:57 --> Language Class Initialized
INFO - 2021-07-29 02:35:57 --> Language Class Initialized
INFO - 2021-07-29 02:35:57 --> Config Class Initialized
INFO - 2021-07-29 02:35:57 --> Loader Class Initialized
INFO - 2021-07-29 02:35:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:57 --> Controller Class Initialized
DEBUG - 2021-07-29 02:35:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:35:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:35:57 --> Final output sent to browser
DEBUG - 2021-07-29 02:35:57 --> Total execution time: 0.0656
INFO - 2021-07-29 02:35:57 --> Config Class Initialized
INFO - 2021-07-29 02:35:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:35:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:35:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:35:57 --> URI Class Initialized
INFO - 2021-07-29 02:35:57 --> Router Class Initialized
INFO - 2021-07-29 02:35:57 --> Output Class Initialized
INFO - 2021-07-29 02:35:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:35:57 --> Input Class Initialized
INFO - 2021-07-29 02:35:57 --> Language Class Initialized
INFO - 2021-07-29 02:35:57 --> Language Class Initialized
INFO - 2021-07-29 02:35:57 --> Config Class Initialized
INFO - 2021-07-29 02:35:57 --> Loader Class Initialized
INFO - 2021-07-29 02:35:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:35:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:35:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:35:57 --> Controller Class Initialized
INFO - 2021-07-29 02:36:01 --> Config Class Initialized
INFO - 2021-07-29 02:36:01 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:01 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:01 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:01 --> URI Class Initialized
INFO - 2021-07-29 02:36:01 --> Router Class Initialized
INFO - 2021-07-29 02:36:01 --> Output Class Initialized
INFO - 2021-07-29 02:36:01 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:01 --> Input Class Initialized
INFO - 2021-07-29 02:36:01 --> Language Class Initialized
INFO - 2021-07-29 02:36:01 --> Language Class Initialized
INFO - 2021-07-29 02:36:01 --> Config Class Initialized
INFO - 2021-07-29 02:36:01 --> Loader Class Initialized
INFO - 2021-07-29 02:36:01 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:01 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:01 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:01 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:01 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:01 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:01 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:01 --> Total execution time: 0.0457
INFO - 2021-07-29 02:36:11 --> Config Class Initialized
INFO - 2021-07-29 02:36:11 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:11 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:11 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:11 --> URI Class Initialized
INFO - 2021-07-29 02:36:11 --> Router Class Initialized
INFO - 2021-07-29 02:36:11 --> Output Class Initialized
INFO - 2021-07-29 02:36:11 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:11 --> Input Class Initialized
INFO - 2021-07-29 02:36:11 --> Language Class Initialized
INFO - 2021-07-29 02:36:11 --> Language Class Initialized
INFO - 2021-07-29 02:36:11 --> Config Class Initialized
INFO - 2021-07-29 02:36:11 --> Loader Class Initialized
INFO - 2021-07-29 02:36:11 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:11 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:11 --> Controller Class Initialized
INFO - 2021-07-29 02:36:11 --> Config Class Initialized
INFO - 2021-07-29 02:36:11 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:11 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:11 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:11 --> URI Class Initialized
INFO - 2021-07-29 02:36:11 --> Router Class Initialized
INFO - 2021-07-29 02:36:11 --> Output Class Initialized
INFO - 2021-07-29 02:36:11 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:11 --> Input Class Initialized
INFO - 2021-07-29 02:36:11 --> Language Class Initialized
INFO - 2021-07-29 02:36:11 --> Language Class Initialized
INFO - 2021-07-29 02:36:11 --> Config Class Initialized
INFO - 2021-07-29 02:36:11 --> Loader Class Initialized
INFO - 2021-07-29 02:36:11 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:11 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:11 --> Controller Class Initialized
INFO - 2021-07-29 02:36:11 --> Config Class Initialized
INFO - 2021-07-29 02:36:11 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:11 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:11 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:11 --> URI Class Initialized
INFO - 2021-07-29 02:36:11 --> Router Class Initialized
INFO - 2021-07-29 02:36:11 --> Output Class Initialized
INFO - 2021-07-29 02:36:11 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:11 --> Input Class Initialized
INFO - 2021-07-29 02:36:11 --> Language Class Initialized
INFO - 2021-07-29 02:36:11 --> Language Class Initialized
INFO - 2021-07-29 02:36:11 --> Config Class Initialized
INFO - 2021-07-29 02:36:11 --> Loader Class Initialized
INFO - 2021-07-29 02:36:11 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:11 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:11 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:11 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:36:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:11 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:11 --> Total execution time: 0.0416
INFO - 2021-07-29 02:36:12 --> Config Class Initialized
INFO - 2021-07-29 02:36:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:12 --> URI Class Initialized
INFO - 2021-07-29 02:36:12 --> Router Class Initialized
INFO - 2021-07-29 02:36:12 --> Output Class Initialized
INFO - 2021-07-29 02:36:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:12 --> Input Class Initialized
INFO - 2021-07-29 02:36:12 --> Language Class Initialized
INFO - 2021-07-29 02:36:12 --> Language Class Initialized
INFO - 2021-07-29 02:36:12 --> Config Class Initialized
INFO - 2021-07-29 02:36:12 --> Loader Class Initialized
INFO - 2021-07-29 02:36:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:12 --> Controller Class Initialized
INFO - 2021-07-29 02:36:12 --> Config Class Initialized
INFO - 2021-07-29 02:36:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:12 --> URI Class Initialized
INFO - 2021-07-29 02:36:12 --> Router Class Initialized
INFO - 2021-07-29 02:36:12 --> Output Class Initialized
INFO - 2021-07-29 02:36:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:12 --> Input Class Initialized
INFO - 2021-07-29 02:36:12 --> Language Class Initialized
INFO - 2021-07-29 02:36:12 --> Language Class Initialized
INFO - 2021-07-29 02:36:12 --> Config Class Initialized
INFO - 2021-07-29 02:36:12 --> Loader Class Initialized
INFO - 2021-07-29 02:36:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:12 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:36:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:12 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:12 --> Total execution time: 0.0686
INFO - 2021-07-29 02:36:23 --> Config Class Initialized
INFO - 2021-07-29 02:36:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:23 --> URI Class Initialized
INFO - 2021-07-29 02:36:23 --> Router Class Initialized
INFO - 2021-07-29 02:36:24 --> Output Class Initialized
INFO - 2021-07-29 02:36:24 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:24 --> Input Class Initialized
INFO - 2021-07-29 02:36:24 --> Language Class Initialized
INFO - 2021-07-29 02:36:24 --> Language Class Initialized
INFO - 2021-07-29 02:36:24 --> Config Class Initialized
INFO - 2021-07-29 02:36:24 --> Loader Class Initialized
INFO - 2021-07-29 02:36:24 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:24 --> Controller Class Initialized
INFO - 2021-07-29 02:36:24 --> Config Class Initialized
INFO - 2021-07-29 02:36:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:24 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:24 --> URI Class Initialized
INFO - 2021-07-29 02:36:24 --> Router Class Initialized
INFO - 2021-07-29 02:36:24 --> Output Class Initialized
INFO - 2021-07-29 02:36:24 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:24 --> Input Class Initialized
INFO - 2021-07-29 02:36:24 --> Language Class Initialized
INFO - 2021-07-29 02:36:24 --> Language Class Initialized
INFO - 2021-07-29 02:36:24 --> Config Class Initialized
INFO - 2021-07-29 02:36:24 --> Loader Class Initialized
INFO - 2021-07-29 02:36:24 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:24 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:24 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:24 --> Total execution time: 0.0672
INFO - 2021-07-29 02:36:24 --> Config Class Initialized
INFO - 2021-07-29 02:36:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:24 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:24 --> URI Class Initialized
INFO - 2021-07-29 02:36:24 --> Router Class Initialized
INFO - 2021-07-29 02:36:24 --> Output Class Initialized
INFO - 2021-07-29 02:36:24 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:24 --> Input Class Initialized
INFO - 2021-07-29 02:36:24 --> Language Class Initialized
INFO - 2021-07-29 02:36:24 --> Language Class Initialized
INFO - 2021-07-29 02:36:24 --> Config Class Initialized
INFO - 2021-07-29 02:36:24 --> Loader Class Initialized
INFO - 2021-07-29 02:36:24 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:24 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:24 --> Controller Class Initialized
INFO - 2021-07-29 02:36:25 --> Config Class Initialized
INFO - 2021-07-29 02:36:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:25 --> URI Class Initialized
INFO - 2021-07-29 02:36:25 --> Router Class Initialized
INFO - 2021-07-29 02:36:25 --> Output Class Initialized
INFO - 2021-07-29 02:36:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:25 --> Input Class Initialized
INFO - 2021-07-29 02:36:25 --> Language Class Initialized
INFO - 2021-07-29 02:36:25 --> Language Class Initialized
INFO - 2021-07-29 02:36:25 --> Config Class Initialized
INFO - 2021-07-29 02:36:25 --> Loader Class Initialized
INFO - 2021-07-29 02:36:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:25 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:36:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:25 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:25 --> Total execution time: 0.0587
INFO - 2021-07-29 02:36:34 --> Config Class Initialized
INFO - 2021-07-29 02:36:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:34 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:34 --> URI Class Initialized
INFO - 2021-07-29 02:36:34 --> Router Class Initialized
INFO - 2021-07-29 02:36:34 --> Output Class Initialized
INFO - 2021-07-29 02:36:34 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:34 --> Input Class Initialized
INFO - 2021-07-29 02:36:34 --> Language Class Initialized
INFO - 2021-07-29 02:36:34 --> Language Class Initialized
INFO - 2021-07-29 02:36:34 --> Config Class Initialized
INFO - 2021-07-29 02:36:34 --> Loader Class Initialized
INFO - 2021-07-29 02:36:34 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:34 --> Controller Class Initialized
INFO - 2021-07-29 02:36:34 --> Config Class Initialized
INFO - 2021-07-29 02:36:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:34 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:34 --> URI Class Initialized
INFO - 2021-07-29 02:36:34 --> Router Class Initialized
INFO - 2021-07-29 02:36:34 --> Output Class Initialized
INFO - 2021-07-29 02:36:34 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:34 --> Input Class Initialized
INFO - 2021-07-29 02:36:34 --> Language Class Initialized
INFO - 2021-07-29 02:36:34 --> Language Class Initialized
INFO - 2021-07-29 02:36:34 --> Config Class Initialized
INFO - 2021-07-29 02:36:34 --> Loader Class Initialized
INFO - 2021-07-29 02:36:34 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:34 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:36:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:34 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:34 --> Total execution time: 0.0428
INFO - 2021-07-29 02:36:34 --> Config Class Initialized
INFO - 2021-07-29 02:36:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:34 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:34 --> URI Class Initialized
INFO - 2021-07-29 02:36:34 --> Router Class Initialized
INFO - 2021-07-29 02:36:34 --> Output Class Initialized
INFO - 2021-07-29 02:36:34 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:34 --> Input Class Initialized
INFO - 2021-07-29 02:36:34 --> Language Class Initialized
INFO - 2021-07-29 02:36:34 --> Language Class Initialized
INFO - 2021-07-29 02:36:34 --> Config Class Initialized
INFO - 2021-07-29 02:36:34 --> Loader Class Initialized
INFO - 2021-07-29 02:36:34 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:34 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:34 --> Controller Class Initialized
INFO - 2021-07-29 02:36:37 --> Config Class Initialized
INFO - 2021-07-29 02:36:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:37 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:37 --> URI Class Initialized
INFO - 2021-07-29 02:36:37 --> Router Class Initialized
INFO - 2021-07-29 02:36:37 --> Output Class Initialized
INFO - 2021-07-29 02:36:37 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:37 --> Input Class Initialized
INFO - 2021-07-29 02:36:37 --> Language Class Initialized
INFO - 2021-07-29 02:36:37 --> Language Class Initialized
INFO - 2021-07-29 02:36:37 --> Config Class Initialized
INFO - 2021-07-29 02:36:37 --> Loader Class Initialized
INFO - 2021-07-29 02:36:37 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:37 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:37 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:37 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:37 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:37 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:37 --> Total execution time: 0.0449
INFO - 2021-07-29 02:36:46 --> Config Class Initialized
INFO - 2021-07-29 02:36:46 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:46 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:46 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:46 --> URI Class Initialized
INFO - 2021-07-29 02:36:46 --> Router Class Initialized
INFO - 2021-07-29 02:36:46 --> Output Class Initialized
INFO - 2021-07-29 02:36:46 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:46 --> Input Class Initialized
INFO - 2021-07-29 02:36:46 --> Language Class Initialized
INFO - 2021-07-29 02:36:46 --> Language Class Initialized
INFO - 2021-07-29 02:36:46 --> Config Class Initialized
INFO - 2021-07-29 02:36:46 --> Loader Class Initialized
INFO - 2021-07-29 02:36:46 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:46 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:46 --> Controller Class Initialized
INFO - 2021-07-29 02:36:46 --> Config Class Initialized
INFO - 2021-07-29 02:36:46 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:46 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:46 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:46 --> URI Class Initialized
INFO - 2021-07-29 02:36:46 --> Router Class Initialized
INFO - 2021-07-29 02:36:46 --> Output Class Initialized
INFO - 2021-07-29 02:36:46 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:46 --> Input Class Initialized
INFO - 2021-07-29 02:36:46 --> Language Class Initialized
INFO - 2021-07-29 02:36:46 --> Language Class Initialized
INFO - 2021-07-29 02:36:46 --> Config Class Initialized
INFO - 2021-07-29 02:36:46 --> Loader Class Initialized
INFO - 2021-07-29 02:36:46 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:46 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:46 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:36:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:46 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:46 --> Total execution time: 0.0679
INFO - 2021-07-29 02:36:46 --> Config Class Initialized
INFO - 2021-07-29 02:36:46 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:46 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:46 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:46 --> URI Class Initialized
INFO - 2021-07-29 02:36:46 --> Router Class Initialized
INFO - 2021-07-29 02:36:46 --> Output Class Initialized
INFO - 2021-07-29 02:36:46 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:46 --> Input Class Initialized
INFO - 2021-07-29 02:36:46 --> Language Class Initialized
INFO - 2021-07-29 02:36:46 --> Language Class Initialized
INFO - 2021-07-29 02:36:46 --> Config Class Initialized
INFO - 2021-07-29 02:36:46 --> Loader Class Initialized
INFO - 2021-07-29 02:36:46 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:46 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:46 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:46 --> Controller Class Initialized
INFO - 2021-07-29 02:36:48 --> Config Class Initialized
INFO - 2021-07-29 02:36:48 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:49 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:49 --> URI Class Initialized
INFO - 2021-07-29 02:36:49 --> Router Class Initialized
INFO - 2021-07-29 02:36:49 --> Output Class Initialized
INFO - 2021-07-29 02:36:49 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:49 --> Input Class Initialized
INFO - 2021-07-29 02:36:49 --> Language Class Initialized
INFO - 2021-07-29 02:36:49 --> Language Class Initialized
INFO - 2021-07-29 02:36:49 --> Config Class Initialized
INFO - 2021-07-29 02:36:49 --> Loader Class Initialized
INFO - 2021-07-29 02:36:49 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:49 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:49 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:49 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:49 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:49 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:49 --> Total execution time: 0.0541
INFO - 2021-07-29 02:36:56 --> Config Class Initialized
INFO - 2021-07-29 02:36:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:56 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:56 --> URI Class Initialized
INFO - 2021-07-29 02:36:57 --> Router Class Initialized
INFO - 2021-07-29 02:36:57 --> Output Class Initialized
INFO - 2021-07-29 02:36:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:57 --> Input Class Initialized
INFO - 2021-07-29 02:36:57 --> Language Class Initialized
INFO - 2021-07-29 02:36:57 --> Language Class Initialized
INFO - 2021-07-29 02:36:57 --> Config Class Initialized
INFO - 2021-07-29 02:36:57 --> Loader Class Initialized
INFO - 2021-07-29 02:36:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:57 --> Controller Class Initialized
INFO - 2021-07-29 02:36:57 --> Config Class Initialized
INFO - 2021-07-29 02:36:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:57 --> URI Class Initialized
INFO - 2021-07-29 02:36:57 --> Router Class Initialized
INFO - 2021-07-29 02:36:57 --> Output Class Initialized
INFO - 2021-07-29 02:36:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:57 --> Input Class Initialized
INFO - 2021-07-29 02:36:57 --> Language Class Initialized
INFO - 2021-07-29 02:36:57 --> Language Class Initialized
INFO - 2021-07-29 02:36:57 --> Config Class Initialized
INFO - 2021-07-29 02:36:57 --> Loader Class Initialized
INFO - 2021-07-29 02:36:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:57 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:57 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:57 --> Total execution time: 0.0536
INFO - 2021-07-29 02:36:57 --> Config Class Initialized
INFO - 2021-07-29 02:36:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:57 --> URI Class Initialized
INFO - 2021-07-29 02:36:57 --> Router Class Initialized
INFO - 2021-07-29 02:36:57 --> Output Class Initialized
INFO - 2021-07-29 02:36:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:57 --> Input Class Initialized
INFO - 2021-07-29 02:36:57 --> Language Class Initialized
INFO - 2021-07-29 02:36:57 --> Language Class Initialized
INFO - 2021-07-29 02:36:57 --> Config Class Initialized
INFO - 2021-07-29 02:36:57 --> Loader Class Initialized
INFO - 2021-07-29 02:36:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:57 --> Controller Class Initialized
INFO - 2021-07-29 02:36:58 --> Config Class Initialized
INFO - 2021-07-29 02:36:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:36:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:36:58 --> Utf8 Class Initialized
INFO - 2021-07-29 02:36:58 --> URI Class Initialized
INFO - 2021-07-29 02:36:58 --> Router Class Initialized
INFO - 2021-07-29 02:36:58 --> Output Class Initialized
INFO - 2021-07-29 02:36:58 --> Security Class Initialized
DEBUG - 2021-07-29 02:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:36:58 --> Input Class Initialized
INFO - 2021-07-29 02:36:58 --> Language Class Initialized
INFO - 2021-07-29 02:36:58 --> Language Class Initialized
INFO - 2021-07-29 02:36:58 --> Config Class Initialized
INFO - 2021-07-29 02:36:58 --> Loader Class Initialized
INFO - 2021-07-29 02:36:58 --> Helper loaded: url_helper
INFO - 2021-07-29 02:36:58 --> Helper loaded: file_helper
INFO - 2021-07-29 02:36:58 --> Helper loaded: form_helper
INFO - 2021-07-29 02:36:58 --> Helper loaded: my_helper
INFO - 2021-07-29 02:36:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:36:58 --> Controller Class Initialized
DEBUG - 2021-07-29 02:36:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:36:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:36:58 --> Final output sent to browser
DEBUG - 2021-07-29 02:36:58 --> Total execution time: 0.0559
INFO - 2021-07-29 02:37:09 --> Config Class Initialized
INFO - 2021-07-29 02:37:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:37:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:37:09 --> Utf8 Class Initialized
INFO - 2021-07-29 02:37:09 --> URI Class Initialized
INFO - 2021-07-29 02:37:09 --> Router Class Initialized
INFO - 2021-07-29 02:37:09 --> Output Class Initialized
INFO - 2021-07-29 02:37:09 --> Security Class Initialized
DEBUG - 2021-07-29 02:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:37:09 --> Input Class Initialized
INFO - 2021-07-29 02:37:09 --> Language Class Initialized
INFO - 2021-07-29 02:37:09 --> Language Class Initialized
INFO - 2021-07-29 02:37:09 --> Config Class Initialized
INFO - 2021-07-29 02:37:09 --> Loader Class Initialized
INFO - 2021-07-29 02:37:09 --> Helper loaded: url_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: file_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: form_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: my_helper
INFO - 2021-07-29 02:37:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:37:09 --> Controller Class Initialized
INFO - 2021-07-29 02:37:09 --> Config Class Initialized
INFO - 2021-07-29 02:37:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:37:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:37:09 --> Utf8 Class Initialized
INFO - 2021-07-29 02:37:09 --> URI Class Initialized
INFO - 2021-07-29 02:37:09 --> Router Class Initialized
INFO - 2021-07-29 02:37:09 --> Output Class Initialized
INFO - 2021-07-29 02:37:09 --> Security Class Initialized
DEBUG - 2021-07-29 02:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:37:09 --> Input Class Initialized
INFO - 2021-07-29 02:37:09 --> Language Class Initialized
INFO - 2021-07-29 02:37:09 --> Language Class Initialized
INFO - 2021-07-29 02:37:09 --> Config Class Initialized
INFO - 2021-07-29 02:37:09 --> Loader Class Initialized
INFO - 2021-07-29 02:37:09 --> Helper loaded: url_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: file_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: form_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: my_helper
INFO - 2021-07-29 02:37:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:37:09 --> Controller Class Initialized
DEBUG - 2021-07-29 02:37:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:37:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:37:09 --> Final output sent to browser
DEBUG - 2021-07-29 02:37:09 --> Total execution time: 0.0429
INFO - 2021-07-29 02:37:09 --> Config Class Initialized
INFO - 2021-07-29 02:37:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:37:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:37:09 --> Utf8 Class Initialized
INFO - 2021-07-29 02:37:09 --> URI Class Initialized
INFO - 2021-07-29 02:37:09 --> Router Class Initialized
INFO - 2021-07-29 02:37:09 --> Output Class Initialized
INFO - 2021-07-29 02:37:09 --> Security Class Initialized
DEBUG - 2021-07-29 02:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:37:09 --> Input Class Initialized
INFO - 2021-07-29 02:37:09 --> Language Class Initialized
INFO - 2021-07-29 02:37:09 --> Language Class Initialized
INFO - 2021-07-29 02:37:09 --> Config Class Initialized
INFO - 2021-07-29 02:37:09 --> Loader Class Initialized
INFO - 2021-07-29 02:37:09 --> Helper loaded: url_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: file_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: form_helper
INFO - 2021-07-29 02:37:09 --> Helper loaded: my_helper
INFO - 2021-07-29 02:37:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:37:09 --> Controller Class Initialized
INFO - 2021-07-29 02:39:06 --> Config Class Initialized
INFO - 2021-07-29 02:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:06 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:06 --> URI Class Initialized
INFO - 2021-07-29 02:39:06 --> Router Class Initialized
INFO - 2021-07-29 02:39:06 --> Output Class Initialized
INFO - 2021-07-29 02:39:06 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:06 --> Input Class Initialized
INFO - 2021-07-29 02:39:06 --> Language Class Initialized
INFO - 2021-07-29 02:39:06 --> Language Class Initialized
INFO - 2021-07-29 02:39:06 --> Config Class Initialized
INFO - 2021-07-29 02:39:06 --> Loader Class Initialized
INFO - 2021-07-29 02:39:06 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:06 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:06 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:06 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:06 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:06 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:39:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:06 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:06 --> Total execution time: 0.0681
INFO - 2021-07-29 02:39:13 --> Config Class Initialized
INFO - 2021-07-29 02:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:13 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:13 --> URI Class Initialized
INFO - 2021-07-29 02:39:13 --> Router Class Initialized
INFO - 2021-07-29 02:39:13 --> Output Class Initialized
INFO - 2021-07-29 02:39:13 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:13 --> Input Class Initialized
INFO - 2021-07-29 02:39:13 --> Language Class Initialized
INFO - 2021-07-29 02:39:13 --> Language Class Initialized
INFO - 2021-07-29 02:39:13 --> Config Class Initialized
INFO - 2021-07-29 02:39:13 --> Loader Class Initialized
INFO - 2021-07-29 02:39:13 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:13 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:13 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:13 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:13 --> Controller Class Initialized
INFO - 2021-07-29 02:39:13 --> Config Class Initialized
INFO - 2021-07-29 02:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:13 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:13 --> URI Class Initialized
INFO - 2021-07-29 02:39:13 --> Router Class Initialized
INFO - 2021-07-29 02:39:13 --> Output Class Initialized
INFO - 2021-07-29 02:39:13 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:13 --> Input Class Initialized
INFO - 2021-07-29 02:39:13 --> Language Class Initialized
INFO - 2021-07-29 02:39:13 --> Language Class Initialized
INFO - 2021-07-29 02:39:13 --> Config Class Initialized
INFO - 2021-07-29 02:39:13 --> Loader Class Initialized
INFO - 2021-07-29 02:39:13 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:13 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:13 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:13 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:14 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:14 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:14 --> Total execution time: 0.0564
INFO - 2021-07-29 02:39:14 --> Config Class Initialized
INFO - 2021-07-29 02:39:14 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:14 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:14 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:14 --> URI Class Initialized
INFO - 2021-07-29 02:39:14 --> Router Class Initialized
INFO - 2021-07-29 02:39:14 --> Output Class Initialized
INFO - 2021-07-29 02:39:14 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:14 --> Input Class Initialized
INFO - 2021-07-29 02:39:14 --> Language Class Initialized
INFO - 2021-07-29 02:39:14 --> Language Class Initialized
INFO - 2021-07-29 02:39:14 --> Config Class Initialized
INFO - 2021-07-29 02:39:14 --> Loader Class Initialized
INFO - 2021-07-29 02:39:14 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:14 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:14 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:14 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:14 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:14 --> Controller Class Initialized
INFO - 2021-07-29 02:39:15 --> Config Class Initialized
INFO - 2021-07-29 02:39:15 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:15 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:15 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:15 --> URI Class Initialized
INFO - 2021-07-29 02:39:15 --> Router Class Initialized
INFO - 2021-07-29 02:39:15 --> Output Class Initialized
INFO - 2021-07-29 02:39:15 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:15 --> Input Class Initialized
INFO - 2021-07-29 02:39:15 --> Language Class Initialized
INFO - 2021-07-29 02:39:15 --> Language Class Initialized
INFO - 2021-07-29 02:39:15 --> Config Class Initialized
INFO - 2021-07-29 02:39:15 --> Loader Class Initialized
INFO - 2021-07-29 02:39:15 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:15 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:15 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:15 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:15 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:15 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:15 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:15 --> Total execution time: 0.0443
INFO - 2021-07-29 02:39:25 --> Config Class Initialized
INFO - 2021-07-29 02:39:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:25 --> URI Class Initialized
INFO - 2021-07-29 02:39:25 --> Router Class Initialized
INFO - 2021-07-29 02:39:25 --> Output Class Initialized
INFO - 2021-07-29 02:39:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:25 --> Input Class Initialized
INFO - 2021-07-29 02:39:25 --> Language Class Initialized
INFO - 2021-07-29 02:39:25 --> Language Class Initialized
INFO - 2021-07-29 02:39:25 --> Config Class Initialized
INFO - 2021-07-29 02:39:25 --> Loader Class Initialized
INFO - 2021-07-29 02:39:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:25 --> Controller Class Initialized
INFO - 2021-07-29 02:39:25 --> Config Class Initialized
INFO - 2021-07-29 02:39:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:25 --> URI Class Initialized
INFO - 2021-07-29 02:39:25 --> Router Class Initialized
INFO - 2021-07-29 02:39:25 --> Output Class Initialized
INFO - 2021-07-29 02:39:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:25 --> Input Class Initialized
INFO - 2021-07-29 02:39:25 --> Language Class Initialized
INFO - 2021-07-29 02:39:25 --> Language Class Initialized
INFO - 2021-07-29 02:39:25 --> Config Class Initialized
INFO - 2021-07-29 02:39:25 --> Loader Class Initialized
INFO - 2021-07-29 02:39:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:25 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:39:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:25 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:25 --> Total execution time: 0.0665
INFO - 2021-07-29 02:39:25 --> Config Class Initialized
INFO - 2021-07-29 02:39:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:25 --> URI Class Initialized
INFO - 2021-07-29 02:39:25 --> Router Class Initialized
INFO - 2021-07-29 02:39:25 --> Output Class Initialized
INFO - 2021-07-29 02:39:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:25 --> Input Class Initialized
INFO - 2021-07-29 02:39:25 --> Language Class Initialized
INFO - 2021-07-29 02:39:25 --> Language Class Initialized
INFO - 2021-07-29 02:39:25 --> Config Class Initialized
INFO - 2021-07-29 02:39:25 --> Loader Class Initialized
INFO - 2021-07-29 02:39:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:25 --> Controller Class Initialized
INFO - 2021-07-29 02:39:26 --> Config Class Initialized
INFO - 2021-07-29 02:39:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:26 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:26 --> URI Class Initialized
INFO - 2021-07-29 02:39:26 --> Router Class Initialized
INFO - 2021-07-29 02:39:26 --> Output Class Initialized
INFO - 2021-07-29 02:39:26 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:26 --> Input Class Initialized
INFO - 2021-07-29 02:39:26 --> Language Class Initialized
INFO - 2021-07-29 02:39:26 --> Language Class Initialized
INFO - 2021-07-29 02:39:26 --> Config Class Initialized
INFO - 2021-07-29 02:39:26 --> Loader Class Initialized
INFO - 2021-07-29 02:39:26 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:26 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:26 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:26 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:26 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:39:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:26 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:26 --> Total execution time: 0.0657
INFO - 2021-07-29 02:39:34 --> Config Class Initialized
INFO - 2021-07-29 02:39:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:34 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:34 --> URI Class Initialized
INFO - 2021-07-29 02:39:34 --> Router Class Initialized
INFO - 2021-07-29 02:39:34 --> Output Class Initialized
INFO - 2021-07-29 02:39:34 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:34 --> Input Class Initialized
INFO - 2021-07-29 02:39:34 --> Language Class Initialized
INFO - 2021-07-29 02:39:34 --> Language Class Initialized
INFO - 2021-07-29 02:39:34 --> Config Class Initialized
INFO - 2021-07-29 02:39:34 --> Loader Class Initialized
INFO - 2021-07-29 02:39:34 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:34 --> Controller Class Initialized
INFO - 2021-07-29 02:39:34 --> Config Class Initialized
INFO - 2021-07-29 02:39:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:34 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:34 --> URI Class Initialized
INFO - 2021-07-29 02:39:34 --> Router Class Initialized
INFO - 2021-07-29 02:39:34 --> Output Class Initialized
INFO - 2021-07-29 02:39:34 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:34 --> Input Class Initialized
INFO - 2021-07-29 02:39:34 --> Language Class Initialized
INFO - 2021-07-29 02:39:34 --> Language Class Initialized
INFO - 2021-07-29 02:39:34 --> Config Class Initialized
INFO - 2021-07-29 02:39:34 --> Loader Class Initialized
INFO - 2021-07-29 02:39:34 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:34 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:39:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:34 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:34 --> Total execution time: 0.0428
INFO - 2021-07-29 02:39:34 --> Config Class Initialized
INFO - 2021-07-29 02:39:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:34 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:34 --> URI Class Initialized
INFO - 2021-07-29 02:39:34 --> Router Class Initialized
INFO - 2021-07-29 02:39:34 --> Output Class Initialized
INFO - 2021-07-29 02:39:34 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:34 --> Input Class Initialized
INFO - 2021-07-29 02:39:34 --> Language Class Initialized
INFO - 2021-07-29 02:39:34 --> Language Class Initialized
INFO - 2021-07-29 02:39:34 --> Config Class Initialized
INFO - 2021-07-29 02:39:34 --> Loader Class Initialized
INFO - 2021-07-29 02:39:34 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:34 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:34 --> Controller Class Initialized
INFO - 2021-07-29 02:39:35 --> Config Class Initialized
INFO - 2021-07-29 02:39:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:35 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:35 --> URI Class Initialized
INFO - 2021-07-29 02:39:35 --> Router Class Initialized
INFO - 2021-07-29 02:39:35 --> Output Class Initialized
INFO - 2021-07-29 02:39:35 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:35 --> Input Class Initialized
INFO - 2021-07-29 02:39:35 --> Language Class Initialized
INFO - 2021-07-29 02:39:35 --> Language Class Initialized
INFO - 2021-07-29 02:39:35 --> Config Class Initialized
INFO - 2021-07-29 02:39:35 --> Loader Class Initialized
INFO - 2021-07-29 02:39:35 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:35 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:35 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:35 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:35 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:39:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:35 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:35 --> Total execution time: 0.0680
INFO - 2021-07-29 02:39:48 --> Config Class Initialized
INFO - 2021-07-29 02:39:48 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:48 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:48 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:48 --> URI Class Initialized
INFO - 2021-07-29 02:39:48 --> Router Class Initialized
INFO - 2021-07-29 02:39:48 --> Output Class Initialized
INFO - 2021-07-29 02:39:48 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:48 --> Input Class Initialized
INFO - 2021-07-29 02:39:48 --> Language Class Initialized
INFO - 2021-07-29 02:39:48 --> Language Class Initialized
INFO - 2021-07-29 02:39:48 --> Config Class Initialized
INFO - 2021-07-29 02:39:48 --> Loader Class Initialized
INFO - 2021-07-29 02:39:48 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:48 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:48 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:48 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:48 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:48 --> Controller Class Initialized
INFO - 2021-07-29 02:39:49 --> Config Class Initialized
INFO - 2021-07-29 02:39:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:49 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:49 --> URI Class Initialized
INFO - 2021-07-29 02:39:49 --> Router Class Initialized
INFO - 2021-07-29 02:39:49 --> Output Class Initialized
INFO - 2021-07-29 02:39:49 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:49 --> Input Class Initialized
INFO - 2021-07-29 02:39:49 --> Language Class Initialized
INFO - 2021-07-29 02:39:49 --> Language Class Initialized
INFO - 2021-07-29 02:39:49 --> Config Class Initialized
INFO - 2021-07-29 02:39:49 --> Loader Class Initialized
INFO - 2021-07-29 02:39:49 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:49 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:49 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:49 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:49 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:49 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:49 --> Total execution time: 0.1282
INFO - 2021-07-29 02:39:49 --> Config Class Initialized
INFO - 2021-07-29 02:39:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:49 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:49 --> URI Class Initialized
INFO - 2021-07-29 02:39:49 --> Router Class Initialized
INFO - 2021-07-29 02:39:49 --> Output Class Initialized
INFO - 2021-07-29 02:39:49 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:49 --> Input Class Initialized
INFO - 2021-07-29 02:39:49 --> Language Class Initialized
INFO - 2021-07-29 02:39:49 --> Language Class Initialized
INFO - 2021-07-29 02:39:49 --> Config Class Initialized
INFO - 2021-07-29 02:39:49 --> Loader Class Initialized
INFO - 2021-07-29 02:39:49 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:49 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:49 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:49 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:49 --> Controller Class Initialized
INFO - 2021-07-29 02:39:50 --> Config Class Initialized
INFO - 2021-07-29 02:39:50 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:50 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:50 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:50 --> URI Class Initialized
INFO - 2021-07-29 02:39:50 --> Router Class Initialized
INFO - 2021-07-29 02:39:50 --> Output Class Initialized
INFO - 2021-07-29 02:39:50 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:50 --> Input Class Initialized
INFO - 2021-07-29 02:39:50 --> Language Class Initialized
INFO - 2021-07-29 02:39:50 --> Language Class Initialized
INFO - 2021-07-29 02:39:50 --> Config Class Initialized
INFO - 2021-07-29 02:39:50 --> Loader Class Initialized
INFO - 2021-07-29 02:39:50 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:50 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:50 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:50 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:50 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:50 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:39:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:50 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:50 --> Total execution time: 0.0481
INFO - 2021-07-29 02:39:57 --> Config Class Initialized
INFO - 2021-07-29 02:39:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:57 --> URI Class Initialized
INFO - 2021-07-29 02:39:57 --> Router Class Initialized
INFO - 2021-07-29 02:39:57 --> Output Class Initialized
INFO - 2021-07-29 02:39:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:57 --> Input Class Initialized
INFO - 2021-07-29 02:39:57 --> Language Class Initialized
INFO - 2021-07-29 02:39:57 --> Language Class Initialized
INFO - 2021-07-29 02:39:57 --> Config Class Initialized
INFO - 2021-07-29 02:39:57 --> Loader Class Initialized
INFO - 2021-07-29 02:39:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:57 --> Controller Class Initialized
INFO - 2021-07-29 02:39:57 --> Config Class Initialized
INFO - 2021-07-29 02:39:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:57 --> URI Class Initialized
INFO - 2021-07-29 02:39:57 --> Router Class Initialized
INFO - 2021-07-29 02:39:57 --> Output Class Initialized
INFO - 2021-07-29 02:39:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:57 --> Input Class Initialized
INFO - 2021-07-29 02:39:57 --> Language Class Initialized
INFO - 2021-07-29 02:39:57 --> Language Class Initialized
INFO - 2021-07-29 02:39:57 --> Config Class Initialized
INFO - 2021-07-29 02:39:57 --> Loader Class Initialized
INFO - 2021-07-29 02:39:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:57 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:39:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:57 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:57 --> Total execution time: 0.0526
INFO - 2021-07-29 02:39:57 --> Config Class Initialized
INFO - 2021-07-29 02:39:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:57 --> URI Class Initialized
INFO - 2021-07-29 02:39:57 --> Router Class Initialized
INFO - 2021-07-29 02:39:57 --> Output Class Initialized
INFO - 2021-07-29 02:39:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:57 --> Input Class Initialized
INFO - 2021-07-29 02:39:57 --> Language Class Initialized
INFO - 2021-07-29 02:39:57 --> Language Class Initialized
INFO - 2021-07-29 02:39:57 --> Config Class Initialized
INFO - 2021-07-29 02:39:57 --> Loader Class Initialized
INFO - 2021-07-29 02:39:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:57 --> Controller Class Initialized
INFO - 2021-07-29 02:39:58 --> Config Class Initialized
INFO - 2021-07-29 02:39:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:39:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:39:58 --> Utf8 Class Initialized
INFO - 2021-07-29 02:39:58 --> URI Class Initialized
INFO - 2021-07-29 02:39:58 --> Router Class Initialized
INFO - 2021-07-29 02:39:58 --> Output Class Initialized
INFO - 2021-07-29 02:39:58 --> Security Class Initialized
DEBUG - 2021-07-29 02:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:39:58 --> Input Class Initialized
INFO - 2021-07-29 02:39:58 --> Language Class Initialized
INFO - 2021-07-29 02:39:58 --> Language Class Initialized
INFO - 2021-07-29 02:39:58 --> Config Class Initialized
INFO - 2021-07-29 02:39:58 --> Loader Class Initialized
INFO - 2021-07-29 02:39:58 --> Helper loaded: url_helper
INFO - 2021-07-29 02:39:58 --> Helper loaded: file_helper
INFO - 2021-07-29 02:39:58 --> Helper loaded: form_helper
INFO - 2021-07-29 02:39:58 --> Helper loaded: my_helper
INFO - 2021-07-29 02:39:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:39:58 --> Controller Class Initialized
DEBUG - 2021-07-29 02:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:39:58 --> Final output sent to browser
DEBUG - 2021-07-29 02:39:58 --> Total execution time: 0.0646
INFO - 2021-07-29 02:40:11 --> Config Class Initialized
INFO - 2021-07-29 02:40:11 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:11 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:11 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:11 --> URI Class Initialized
INFO - 2021-07-29 02:40:11 --> Router Class Initialized
INFO - 2021-07-29 02:40:11 --> Output Class Initialized
INFO - 2021-07-29 02:40:11 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:11 --> Input Class Initialized
INFO - 2021-07-29 02:40:11 --> Language Class Initialized
INFO - 2021-07-29 02:40:11 --> Language Class Initialized
INFO - 2021-07-29 02:40:11 --> Config Class Initialized
INFO - 2021-07-29 02:40:11 --> Loader Class Initialized
INFO - 2021-07-29 02:40:11 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:11 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:11 --> Controller Class Initialized
INFO - 2021-07-29 02:40:11 --> Config Class Initialized
INFO - 2021-07-29 02:40:11 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:11 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:11 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:11 --> URI Class Initialized
INFO - 2021-07-29 02:40:11 --> Router Class Initialized
INFO - 2021-07-29 02:40:11 --> Output Class Initialized
INFO - 2021-07-29 02:40:11 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:11 --> Input Class Initialized
INFO - 2021-07-29 02:40:11 --> Language Class Initialized
INFO - 2021-07-29 02:40:11 --> Language Class Initialized
INFO - 2021-07-29 02:40:11 --> Config Class Initialized
INFO - 2021-07-29 02:40:11 --> Loader Class Initialized
INFO - 2021-07-29 02:40:11 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:11 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:11 --> Controller Class Initialized
DEBUG - 2021-07-29 02:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:40:11 --> Final output sent to browser
DEBUG - 2021-07-29 02:40:11 --> Total execution time: 0.0680
INFO - 2021-07-29 02:40:11 --> Config Class Initialized
INFO - 2021-07-29 02:40:11 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:11 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:11 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:11 --> URI Class Initialized
INFO - 2021-07-29 02:40:11 --> Router Class Initialized
INFO - 2021-07-29 02:40:11 --> Output Class Initialized
INFO - 2021-07-29 02:40:11 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:11 --> Input Class Initialized
INFO - 2021-07-29 02:40:11 --> Language Class Initialized
INFO - 2021-07-29 02:40:11 --> Language Class Initialized
INFO - 2021-07-29 02:40:11 --> Config Class Initialized
INFO - 2021-07-29 02:40:11 --> Loader Class Initialized
INFO - 2021-07-29 02:40:11 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:11 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:11 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:11 --> Controller Class Initialized
INFO - 2021-07-29 02:40:12 --> Config Class Initialized
INFO - 2021-07-29 02:40:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:12 --> URI Class Initialized
INFO - 2021-07-29 02:40:12 --> Router Class Initialized
INFO - 2021-07-29 02:40:12 --> Output Class Initialized
INFO - 2021-07-29 02:40:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:12 --> Input Class Initialized
INFO - 2021-07-29 02:40:12 --> Language Class Initialized
INFO - 2021-07-29 02:40:12 --> Language Class Initialized
INFO - 2021-07-29 02:40:12 --> Config Class Initialized
INFO - 2021-07-29 02:40:12 --> Loader Class Initialized
INFO - 2021-07-29 02:40:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:12 --> Controller Class Initialized
DEBUG - 2021-07-29 02:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:40:12 --> Final output sent to browser
DEBUG - 2021-07-29 02:40:12 --> Total execution time: 0.0565
INFO - 2021-07-29 02:40:25 --> Config Class Initialized
INFO - 2021-07-29 02:40:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:25 --> URI Class Initialized
INFO - 2021-07-29 02:40:25 --> Router Class Initialized
INFO - 2021-07-29 02:40:25 --> Output Class Initialized
INFO - 2021-07-29 02:40:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:25 --> Input Class Initialized
INFO - 2021-07-29 02:40:25 --> Language Class Initialized
INFO - 2021-07-29 02:40:25 --> Language Class Initialized
INFO - 2021-07-29 02:40:25 --> Config Class Initialized
INFO - 2021-07-29 02:40:25 --> Loader Class Initialized
INFO - 2021-07-29 02:40:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:25 --> Controller Class Initialized
INFO - 2021-07-29 02:40:25 --> Config Class Initialized
INFO - 2021-07-29 02:40:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:25 --> URI Class Initialized
INFO - 2021-07-29 02:40:25 --> Router Class Initialized
INFO - 2021-07-29 02:40:25 --> Output Class Initialized
INFO - 2021-07-29 02:40:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:25 --> Input Class Initialized
INFO - 2021-07-29 02:40:25 --> Language Class Initialized
INFO - 2021-07-29 02:40:25 --> Language Class Initialized
INFO - 2021-07-29 02:40:25 --> Config Class Initialized
INFO - 2021-07-29 02:40:25 --> Loader Class Initialized
INFO - 2021-07-29 02:40:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:25 --> Controller Class Initialized
DEBUG - 2021-07-29 02:40:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:40:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:40:25 --> Final output sent to browser
DEBUG - 2021-07-29 02:40:25 --> Total execution time: 0.0418
INFO - 2021-07-29 02:40:25 --> Config Class Initialized
INFO - 2021-07-29 02:40:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:25 --> URI Class Initialized
INFO - 2021-07-29 02:40:25 --> Router Class Initialized
INFO - 2021-07-29 02:40:25 --> Output Class Initialized
INFO - 2021-07-29 02:40:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:25 --> Input Class Initialized
INFO - 2021-07-29 02:40:25 --> Language Class Initialized
INFO - 2021-07-29 02:40:25 --> Language Class Initialized
INFO - 2021-07-29 02:40:25 --> Config Class Initialized
INFO - 2021-07-29 02:40:25 --> Loader Class Initialized
INFO - 2021-07-29 02:40:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:25 --> Controller Class Initialized
INFO - 2021-07-29 02:40:26 --> Config Class Initialized
INFO - 2021-07-29 02:40:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:26 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:26 --> URI Class Initialized
INFO - 2021-07-29 02:40:26 --> Router Class Initialized
INFO - 2021-07-29 02:40:26 --> Output Class Initialized
INFO - 2021-07-29 02:40:26 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:26 --> Input Class Initialized
INFO - 2021-07-29 02:40:26 --> Language Class Initialized
INFO - 2021-07-29 02:40:26 --> Language Class Initialized
INFO - 2021-07-29 02:40:26 --> Config Class Initialized
INFO - 2021-07-29 02:40:26 --> Loader Class Initialized
INFO - 2021-07-29 02:40:26 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:26 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:26 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:26 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:26 --> Controller Class Initialized
DEBUG - 2021-07-29 02:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:40:26 --> Final output sent to browser
DEBUG - 2021-07-29 02:40:26 --> Total execution time: 0.0681
INFO - 2021-07-29 02:40:37 --> Config Class Initialized
INFO - 2021-07-29 02:40:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:37 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:37 --> URI Class Initialized
INFO - 2021-07-29 02:40:37 --> Router Class Initialized
INFO - 2021-07-29 02:40:37 --> Output Class Initialized
INFO - 2021-07-29 02:40:37 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:37 --> Input Class Initialized
INFO - 2021-07-29 02:40:37 --> Language Class Initialized
INFO - 2021-07-29 02:40:37 --> Language Class Initialized
INFO - 2021-07-29 02:40:37 --> Config Class Initialized
INFO - 2021-07-29 02:40:37 --> Loader Class Initialized
INFO - 2021-07-29 02:40:37 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:37 --> Controller Class Initialized
INFO - 2021-07-29 02:40:37 --> Config Class Initialized
INFO - 2021-07-29 02:40:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:37 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:37 --> URI Class Initialized
INFO - 2021-07-29 02:40:37 --> Router Class Initialized
INFO - 2021-07-29 02:40:37 --> Output Class Initialized
INFO - 2021-07-29 02:40:37 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:37 --> Input Class Initialized
INFO - 2021-07-29 02:40:37 --> Language Class Initialized
INFO - 2021-07-29 02:40:37 --> Language Class Initialized
INFO - 2021-07-29 02:40:37 --> Config Class Initialized
INFO - 2021-07-29 02:40:37 --> Loader Class Initialized
INFO - 2021-07-29 02:40:37 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:37 --> Controller Class Initialized
DEBUG - 2021-07-29 02:40:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:40:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:40:37 --> Final output sent to browser
DEBUG - 2021-07-29 02:40:37 --> Total execution time: 0.0421
INFO - 2021-07-29 02:40:37 --> Config Class Initialized
INFO - 2021-07-29 02:40:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:37 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:37 --> URI Class Initialized
INFO - 2021-07-29 02:40:37 --> Router Class Initialized
INFO - 2021-07-29 02:40:37 --> Output Class Initialized
INFO - 2021-07-29 02:40:37 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:37 --> Input Class Initialized
INFO - 2021-07-29 02:40:37 --> Language Class Initialized
INFO - 2021-07-29 02:40:37 --> Language Class Initialized
INFO - 2021-07-29 02:40:37 --> Config Class Initialized
INFO - 2021-07-29 02:40:37 --> Loader Class Initialized
INFO - 2021-07-29 02:40:37 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:37 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:37 --> Controller Class Initialized
INFO - 2021-07-29 02:40:38 --> Config Class Initialized
INFO - 2021-07-29 02:40:38 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:38 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:38 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:38 --> URI Class Initialized
INFO - 2021-07-29 02:40:38 --> Router Class Initialized
INFO - 2021-07-29 02:40:38 --> Output Class Initialized
INFO - 2021-07-29 02:40:38 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:38 --> Input Class Initialized
INFO - 2021-07-29 02:40:38 --> Language Class Initialized
INFO - 2021-07-29 02:40:38 --> Language Class Initialized
INFO - 2021-07-29 02:40:38 --> Config Class Initialized
INFO - 2021-07-29 02:40:38 --> Loader Class Initialized
INFO - 2021-07-29 02:40:38 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:38 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:38 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:38 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:38 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:38 --> Controller Class Initialized
DEBUG - 2021-07-29 02:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-07-29 02:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:40:38 --> Final output sent to browser
DEBUG - 2021-07-29 02:40:38 --> Total execution time: 0.0455
INFO - 2021-07-29 02:40:55 --> Config Class Initialized
INFO - 2021-07-29 02:40:55 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:55 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:55 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:55 --> URI Class Initialized
INFO - 2021-07-29 02:40:55 --> Router Class Initialized
INFO - 2021-07-29 02:40:55 --> Output Class Initialized
INFO - 2021-07-29 02:40:55 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:55 --> Input Class Initialized
INFO - 2021-07-29 02:40:55 --> Language Class Initialized
INFO - 2021-07-29 02:40:55 --> Language Class Initialized
INFO - 2021-07-29 02:40:55 --> Config Class Initialized
INFO - 2021-07-29 02:40:55 --> Loader Class Initialized
INFO - 2021-07-29 02:40:55 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:55 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:55 --> Controller Class Initialized
INFO - 2021-07-29 02:40:55 --> Config Class Initialized
INFO - 2021-07-29 02:40:55 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:55 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:55 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:55 --> URI Class Initialized
INFO - 2021-07-29 02:40:55 --> Router Class Initialized
INFO - 2021-07-29 02:40:55 --> Output Class Initialized
INFO - 2021-07-29 02:40:55 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:55 --> Input Class Initialized
INFO - 2021-07-29 02:40:55 --> Language Class Initialized
INFO - 2021-07-29 02:40:55 --> Language Class Initialized
INFO - 2021-07-29 02:40:55 --> Config Class Initialized
INFO - 2021-07-29 02:40:55 --> Loader Class Initialized
INFO - 2021-07-29 02:40:55 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:55 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:55 --> Controller Class Initialized
DEBUG - 2021-07-29 02:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-07-29 02:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:40:55 --> Final output sent to browser
DEBUG - 2021-07-29 02:40:55 --> Total execution time: 0.0541
INFO - 2021-07-29 02:40:55 --> Config Class Initialized
INFO - 2021-07-29 02:40:55 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:55 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:55 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:55 --> URI Class Initialized
INFO - 2021-07-29 02:40:55 --> Router Class Initialized
INFO - 2021-07-29 02:40:55 --> Output Class Initialized
INFO - 2021-07-29 02:40:55 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:55 --> Input Class Initialized
INFO - 2021-07-29 02:40:55 --> Language Class Initialized
INFO - 2021-07-29 02:40:55 --> Language Class Initialized
INFO - 2021-07-29 02:40:55 --> Config Class Initialized
INFO - 2021-07-29 02:40:55 --> Loader Class Initialized
INFO - 2021-07-29 02:40:55 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:55 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:55 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:55 --> Controller Class Initialized
INFO - 2021-07-29 02:40:58 --> Config Class Initialized
INFO - 2021-07-29 02:40:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:58 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:58 --> URI Class Initialized
INFO - 2021-07-29 02:40:58 --> Router Class Initialized
INFO - 2021-07-29 02:40:58 --> Output Class Initialized
INFO - 2021-07-29 02:40:58 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:58 --> Input Class Initialized
INFO - 2021-07-29 02:40:58 --> Language Class Initialized
INFO - 2021-07-29 02:40:58 --> Language Class Initialized
INFO - 2021-07-29 02:40:58 --> Config Class Initialized
INFO - 2021-07-29 02:40:58 --> Loader Class Initialized
INFO - 2021-07-29 02:40:58 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:58 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:58 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:58 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:58 --> Controller Class Initialized
INFO - 2021-07-29 02:40:58 --> Helper loaded: cookie_helper
INFO - 2021-07-29 02:40:58 --> Config Class Initialized
INFO - 2021-07-29 02:40:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:40:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:40:58 --> Utf8 Class Initialized
INFO - 2021-07-29 02:40:58 --> URI Class Initialized
INFO - 2021-07-29 02:40:58 --> Router Class Initialized
INFO - 2021-07-29 02:40:58 --> Output Class Initialized
INFO - 2021-07-29 02:40:58 --> Security Class Initialized
DEBUG - 2021-07-29 02:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:40:58 --> Input Class Initialized
INFO - 2021-07-29 02:40:58 --> Language Class Initialized
INFO - 2021-07-29 02:40:58 --> Language Class Initialized
INFO - 2021-07-29 02:40:58 --> Config Class Initialized
INFO - 2021-07-29 02:40:58 --> Loader Class Initialized
INFO - 2021-07-29 02:40:58 --> Helper loaded: url_helper
INFO - 2021-07-29 02:40:58 --> Helper loaded: file_helper
INFO - 2021-07-29 02:40:58 --> Helper loaded: form_helper
INFO - 2021-07-29 02:40:58 --> Helper loaded: my_helper
INFO - 2021-07-29 02:40:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:40:58 --> Controller Class Initialized
DEBUG - 2021-07-29 02:40:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-29 02:40:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:40:58 --> Final output sent to browser
DEBUG - 2021-07-29 02:40:58 --> Total execution time: 0.0536
INFO - 2021-07-29 02:41:12 --> Config Class Initialized
INFO - 2021-07-29 02:41:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:12 --> URI Class Initialized
INFO - 2021-07-29 02:41:12 --> Router Class Initialized
INFO - 2021-07-29 02:41:12 --> Output Class Initialized
INFO - 2021-07-29 02:41:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:12 --> Input Class Initialized
INFO - 2021-07-29 02:41:12 --> Language Class Initialized
INFO - 2021-07-29 02:41:12 --> Language Class Initialized
INFO - 2021-07-29 02:41:12 --> Config Class Initialized
INFO - 2021-07-29 02:41:12 --> Loader Class Initialized
INFO - 2021-07-29 02:41:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:12 --> Controller Class Initialized
INFO - 2021-07-29 02:41:12 --> Helper loaded: cookie_helper
INFO - 2021-07-29 02:41:12 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:12 --> Total execution time: 0.0654
INFO - 2021-07-29 02:41:12 --> Config Class Initialized
INFO - 2021-07-29 02:41:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:12 --> URI Class Initialized
INFO - 2021-07-29 02:41:12 --> Router Class Initialized
INFO - 2021-07-29 02:41:12 --> Output Class Initialized
INFO - 2021-07-29 02:41:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:12 --> Input Class Initialized
INFO - 2021-07-29 02:41:12 --> Language Class Initialized
INFO - 2021-07-29 02:41:12 --> Language Class Initialized
INFO - 2021-07-29 02:41:12 --> Config Class Initialized
INFO - 2021-07-29 02:41:12 --> Loader Class Initialized
INFO - 2021-07-29 02:41:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:12 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-29 02:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:12 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:12 --> Total execution time: 0.0707
INFO - 2021-07-29 02:41:18 --> Config Class Initialized
INFO - 2021-07-29 02:41:18 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:18 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:18 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:18 --> URI Class Initialized
INFO - 2021-07-29 02:41:18 --> Router Class Initialized
INFO - 2021-07-29 02:41:18 --> Output Class Initialized
INFO - 2021-07-29 02:41:18 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:18 --> Input Class Initialized
INFO - 2021-07-29 02:41:18 --> Language Class Initialized
INFO - 2021-07-29 02:41:18 --> Language Class Initialized
INFO - 2021-07-29 02:41:18 --> Config Class Initialized
INFO - 2021-07-29 02:41:18 --> Loader Class Initialized
INFO - 2021-07-29 02:41:18 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:18 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:18 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:18 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:18 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:18 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-29 02:41:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:18 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:18 --> Total execution time: 0.0780
INFO - 2021-07-29 02:41:22 --> Config Class Initialized
INFO - 2021-07-29 02:41:22 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:22 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:22 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:22 --> URI Class Initialized
INFO - 2021-07-29 02:41:22 --> Router Class Initialized
INFO - 2021-07-29 02:41:22 --> Output Class Initialized
INFO - 2021-07-29 02:41:22 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:22 --> Input Class Initialized
INFO - 2021-07-29 02:41:22 --> Language Class Initialized
INFO - 2021-07-29 02:41:22 --> Language Class Initialized
INFO - 2021-07-29 02:41:22 --> Config Class Initialized
INFO - 2021-07-29 02:41:22 --> Loader Class Initialized
INFO - 2021-07-29 02:41:22 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:22 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:22 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:22 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:22 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:22 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:22 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:22 --> Total execution time: 0.1018
INFO - 2021-07-29 02:41:22 --> Config Class Initialized
INFO - 2021-07-29 02:41:22 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:22 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:22 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:22 --> URI Class Initialized
INFO - 2021-07-29 02:41:22 --> Router Class Initialized
INFO - 2021-07-29 02:41:22 --> Output Class Initialized
INFO - 2021-07-29 02:41:22 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:22 --> Input Class Initialized
INFO - 2021-07-29 02:41:22 --> Language Class Initialized
INFO - 2021-07-29 02:41:22 --> Language Class Initialized
INFO - 2021-07-29 02:41:22 --> Config Class Initialized
INFO - 2021-07-29 02:41:22 --> Loader Class Initialized
INFO - 2021-07-29 02:41:22 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:22 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:22 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:22 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:22 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:22 --> Controller Class Initialized
INFO - 2021-07-29 02:41:23 --> Config Class Initialized
INFO - 2021-07-29 02:41:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:23 --> URI Class Initialized
INFO - 2021-07-29 02:41:23 --> Router Class Initialized
INFO - 2021-07-29 02:41:23 --> Output Class Initialized
INFO - 2021-07-29 02:41:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:23 --> Input Class Initialized
INFO - 2021-07-29 02:41:23 --> Language Class Initialized
INFO - 2021-07-29 02:41:23 --> Language Class Initialized
INFO - 2021-07-29 02:41:23 --> Config Class Initialized
INFO - 2021-07-29 02:41:23 --> Loader Class Initialized
INFO - 2021-07-29 02:41:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:23 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:23 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:23 --> Total execution time: 0.1075
INFO - 2021-07-29 02:41:36 --> Config Class Initialized
INFO - 2021-07-29 02:41:36 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:36 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:36 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:36 --> URI Class Initialized
INFO - 2021-07-29 02:41:36 --> Router Class Initialized
INFO - 2021-07-29 02:41:36 --> Output Class Initialized
INFO - 2021-07-29 02:41:36 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:36 --> Input Class Initialized
INFO - 2021-07-29 02:41:36 --> Language Class Initialized
INFO - 2021-07-29 02:41:36 --> Language Class Initialized
INFO - 2021-07-29 02:41:36 --> Config Class Initialized
INFO - 2021-07-29 02:41:36 --> Loader Class Initialized
INFO - 2021-07-29 02:41:36 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:36 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:36 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:36 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:36 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:36 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:36 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:36 --> Total execution time: 0.0486
INFO - 2021-07-29 02:41:36 --> Config Class Initialized
INFO - 2021-07-29 02:41:36 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:36 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:36 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:36 --> URI Class Initialized
INFO - 2021-07-29 02:41:36 --> Router Class Initialized
INFO - 2021-07-29 02:41:36 --> Output Class Initialized
INFO - 2021-07-29 02:41:36 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:36 --> Input Class Initialized
INFO - 2021-07-29 02:41:36 --> Language Class Initialized
INFO - 2021-07-29 02:41:36 --> Language Class Initialized
INFO - 2021-07-29 02:41:36 --> Config Class Initialized
INFO - 2021-07-29 02:41:36 --> Loader Class Initialized
INFO - 2021-07-29 02:41:36 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:36 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:36 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:36 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:36 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:36 --> Controller Class Initialized
INFO - 2021-07-29 02:41:37 --> Config Class Initialized
INFO - 2021-07-29 02:41:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:37 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:37 --> URI Class Initialized
INFO - 2021-07-29 02:41:37 --> Router Class Initialized
INFO - 2021-07-29 02:41:37 --> Output Class Initialized
INFO - 2021-07-29 02:41:37 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:37 --> Input Class Initialized
INFO - 2021-07-29 02:41:37 --> Language Class Initialized
INFO - 2021-07-29 02:41:37 --> Language Class Initialized
INFO - 2021-07-29 02:41:37 --> Config Class Initialized
INFO - 2021-07-29 02:41:37 --> Loader Class Initialized
INFO - 2021-07-29 02:41:37 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:37 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:37 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:37 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:37 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:37 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:37 --> Total execution time: 0.0673
INFO - 2021-07-29 02:41:39 --> Config Class Initialized
INFO - 2021-07-29 02:41:39 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:39 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:39 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:39 --> URI Class Initialized
INFO - 2021-07-29 02:41:39 --> Router Class Initialized
INFO - 2021-07-29 02:41:39 --> Output Class Initialized
INFO - 2021-07-29 02:41:39 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:39 --> Input Class Initialized
INFO - 2021-07-29 02:41:39 --> Language Class Initialized
INFO - 2021-07-29 02:41:39 --> Language Class Initialized
INFO - 2021-07-29 02:41:39 --> Config Class Initialized
INFO - 2021-07-29 02:41:39 --> Loader Class Initialized
INFO - 2021-07-29 02:41:39 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:39 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:39 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:39 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:39 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:39 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:39 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:39 --> Total execution time: 0.0467
INFO - 2021-07-29 02:41:39 --> Config Class Initialized
INFO - 2021-07-29 02:41:39 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:39 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:39 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:39 --> URI Class Initialized
INFO - 2021-07-29 02:41:39 --> Router Class Initialized
INFO - 2021-07-29 02:41:39 --> Output Class Initialized
INFO - 2021-07-29 02:41:39 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:39 --> Input Class Initialized
INFO - 2021-07-29 02:41:39 --> Language Class Initialized
INFO - 2021-07-29 02:41:39 --> Language Class Initialized
INFO - 2021-07-29 02:41:39 --> Config Class Initialized
INFO - 2021-07-29 02:41:39 --> Loader Class Initialized
INFO - 2021-07-29 02:41:39 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:39 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:39 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:39 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:39 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:39 --> Controller Class Initialized
INFO - 2021-07-29 02:41:40 --> Config Class Initialized
INFO - 2021-07-29 02:41:40 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:40 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:40 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:40 --> URI Class Initialized
INFO - 2021-07-29 02:41:40 --> Router Class Initialized
INFO - 2021-07-29 02:41:40 --> Output Class Initialized
INFO - 2021-07-29 02:41:40 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:40 --> Input Class Initialized
INFO - 2021-07-29 02:41:40 --> Language Class Initialized
INFO - 2021-07-29 02:41:40 --> Language Class Initialized
INFO - 2021-07-29 02:41:40 --> Config Class Initialized
INFO - 2021-07-29 02:41:40 --> Loader Class Initialized
INFO - 2021-07-29 02:41:40 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:40 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:40 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:40 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:40 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:40 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:40 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:40 --> Total execution time: 0.0467
INFO - 2021-07-29 02:41:42 --> Config Class Initialized
INFO - 2021-07-29 02:41:42 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:42 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:42 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:42 --> URI Class Initialized
INFO - 2021-07-29 02:41:42 --> Router Class Initialized
INFO - 2021-07-29 02:41:42 --> Output Class Initialized
INFO - 2021-07-29 02:41:42 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:42 --> Input Class Initialized
INFO - 2021-07-29 02:41:42 --> Language Class Initialized
INFO - 2021-07-29 02:41:42 --> Language Class Initialized
INFO - 2021-07-29 02:41:42 --> Config Class Initialized
INFO - 2021-07-29 02:41:42 --> Loader Class Initialized
INFO - 2021-07-29 02:41:42 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:42 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:42 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:42 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:42 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:42 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:42 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:42 --> Total execution time: 0.0470
INFO - 2021-07-29 02:41:43 --> Config Class Initialized
INFO - 2021-07-29 02:41:43 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:43 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:43 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:43 --> URI Class Initialized
INFO - 2021-07-29 02:41:43 --> Router Class Initialized
INFO - 2021-07-29 02:41:43 --> Output Class Initialized
INFO - 2021-07-29 02:41:43 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:43 --> Input Class Initialized
INFO - 2021-07-29 02:41:43 --> Language Class Initialized
INFO - 2021-07-29 02:41:43 --> Language Class Initialized
INFO - 2021-07-29 02:41:43 --> Config Class Initialized
INFO - 2021-07-29 02:41:43 --> Loader Class Initialized
INFO - 2021-07-29 02:41:43 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:43 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:43 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:43 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:43 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:43 --> Controller Class Initialized
INFO - 2021-07-29 02:41:44 --> Config Class Initialized
INFO - 2021-07-29 02:41:44 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:44 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:44 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:44 --> URI Class Initialized
INFO - 2021-07-29 02:41:44 --> Router Class Initialized
INFO - 2021-07-29 02:41:44 --> Output Class Initialized
INFO - 2021-07-29 02:41:44 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:44 --> Input Class Initialized
INFO - 2021-07-29 02:41:44 --> Language Class Initialized
INFO - 2021-07-29 02:41:44 --> Language Class Initialized
INFO - 2021-07-29 02:41:44 --> Config Class Initialized
INFO - 2021-07-29 02:41:44 --> Loader Class Initialized
INFO - 2021-07-29 02:41:44 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:44 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:44 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:44 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:44 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:44 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:44 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:44 --> Total execution time: 0.0475
INFO - 2021-07-29 02:41:45 --> Config Class Initialized
INFO - 2021-07-29 02:41:45 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:45 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:45 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:45 --> URI Class Initialized
INFO - 2021-07-29 02:41:45 --> Router Class Initialized
INFO - 2021-07-29 02:41:45 --> Output Class Initialized
INFO - 2021-07-29 02:41:45 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:45 --> Input Class Initialized
INFO - 2021-07-29 02:41:45 --> Language Class Initialized
INFO - 2021-07-29 02:41:45 --> Language Class Initialized
INFO - 2021-07-29 02:41:45 --> Config Class Initialized
INFO - 2021-07-29 02:41:45 --> Loader Class Initialized
INFO - 2021-07-29 02:41:45 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:45 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:45 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:45 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:45 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:45 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:45 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:45 --> Total execution time: 0.0540
INFO - 2021-07-29 02:41:45 --> Config Class Initialized
INFO - 2021-07-29 02:41:45 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:45 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:45 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:45 --> URI Class Initialized
INFO - 2021-07-29 02:41:45 --> Router Class Initialized
INFO - 2021-07-29 02:41:45 --> Output Class Initialized
INFO - 2021-07-29 02:41:45 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:45 --> Input Class Initialized
INFO - 2021-07-29 02:41:45 --> Language Class Initialized
INFO - 2021-07-29 02:41:45 --> Language Class Initialized
INFO - 2021-07-29 02:41:45 --> Config Class Initialized
INFO - 2021-07-29 02:41:45 --> Loader Class Initialized
INFO - 2021-07-29 02:41:45 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:45 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:45 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:45 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:45 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:45 --> Controller Class Initialized
INFO - 2021-07-29 02:41:47 --> Config Class Initialized
INFO - 2021-07-29 02:41:47 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:47 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:47 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:47 --> URI Class Initialized
INFO - 2021-07-29 02:41:47 --> Router Class Initialized
INFO - 2021-07-29 02:41:47 --> Output Class Initialized
INFO - 2021-07-29 02:41:47 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:47 --> Input Class Initialized
INFO - 2021-07-29 02:41:47 --> Language Class Initialized
INFO - 2021-07-29 02:41:47 --> Language Class Initialized
INFO - 2021-07-29 02:41:47 --> Config Class Initialized
INFO - 2021-07-29 02:41:47 --> Loader Class Initialized
INFO - 2021-07-29 02:41:47 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:47 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:47 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:47 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:47 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:47 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:47 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:47 --> Total execution time: 0.0474
INFO - 2021-07-29 02:41:48 --> Config Class Initialized
INFO - 2021-07-29 02:41:48 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:48 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:48 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:48 --> URI Class Initialized
INFO - 2021-07-29 02:41:48 --> Router Class Initialized
INFO - 2021-07-29 02:41:48 --> Output Class Initialized
INFO - 2021-07-29 02:41:48 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:48 --> Input Class Initialized
INFO - 2021-07-29 02:41:48 --> Language Class Initialized
INFO - 2021-07-29 02:41:48 --> Language Class Initialized
INFO - 2021-07-29 02:41:48 --> Config Class Initialized
INFO - 2021-07-29 02:41:48 --> Loader Class Initialized
INFO - 2021-07-29 02:41:48 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:48 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:48 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:48 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:48 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:48 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:48 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:48 --> Total execution time: 0.0465
INFO - 2021-07-29 02:41:48 --> Config Class Initialized
INFO - 2021-07-29 02:41:48 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:48 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:48 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:48 --> URI Class Initialized
INFO - 2021-07-29 02:41:48 --> Router Class Initialized
INFO - 2021-07-29 02:41:48 --> Output Class Initialized
INFO - 2021-07-29 02:41:48 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:48 --> Input Class Initialized
INFO - 2021-07-29 02:41:48 --> Language Class Initialized
INFO - 2021-07-29 02:41:49 --> Language Class Initialized
INFO - 2021-07-29 02:41:49 --> Config Class Initialized
INFO - 2021-07-29 02:41:49 --> Loader Class Initialized
INFO - 2021-07-29 02:41:49 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:49 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:49 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:49 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:49 --> Controller Class Initialized
INFO - 2021-07-29 02:41:50 --> Config Class Initialized
INFO - 2021-07-29 02:41:50 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:50 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:50 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:50 --> URI Class Initialized
INFO - 2021-07-29 02:41:50 --> Router Class Initialized
INFO - 2021-07-29 02:41:50 --> Output Class Initialized
INFO - 2021-07-29 02:41:50 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:50 --> Input Class Initialized
INFO - 2021-07-29 02:41:50 --> Language Class Initialized
INFO - 2021-07-29 02:41:50 --> Language Class Initialized
INFO - 2021-07-29 02:41:50 --> Config Class Initialized
INFO - 2021-07-29 02:41:50 --> Loader Class Initialized
INFO - 2021-07-29 02:41:50 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:50 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:50 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:50 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:50 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:50 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:50 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:50 --> Total execution time: 0.0476
INFO - 2021-07-29 02:41:52 --> Config Class Initialized
INFO - 2021-07-29 02:41:52 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:52 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:52 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:52 --> URI Class Initialized
INFO - 2021-07-29 02:41:52 --> Router Class Initialized
INFO - 2021-07-29 02:41:52 --> Output Class Initialized
INFO - 2021-07-29 02:41:52 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:52 --> Input Class Initialized
INFO - 2021-07-29 02:41:52 --> Language Class Initialized
INFO - 2021-07-29 02:41:52 --> Language Class Initialized
INFO - 2021-07-29 02:41:52 --> Config Class Initialized
INFO - 2021-07-29 02:41:52 --> Loader Class Initialized
INFO - 2021-07-29 02:41:52 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:52 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:52 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:52 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:52 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:52 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:52 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:52 --> Total execution time: 0.0475
INFO - 2021-07-29 02:41:52 --> Config Class Initialized
INFO - 2021-07-29 02:41:52 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:52 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:52 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:52 --> URI Class Initialized
INFO - 2021-07-29 02:41:52 --> Router Class Initialized
INFO - 2021-07-29 02:41:52 --> Output Class Initialized
INFO - 2021-07-29 02:41:52 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:52 --> Input Class Initialized
INFO - 2021-07-29 02:41:52 --> Language Class Initialized
INFO - 2021-07-29 02:41:52 --> Language Class Initialized
INFO - 2021-07-29 02:41:52 --> Config Class Initialized
INFO - 2021-07-29 02:41:52 --> Loader Class Initialized
INFO - 2021-07-29 02:41:52 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:52 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:52 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:52 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:52 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:52 --> Controller Class Initialized
INFO - 2021-07-29 02:41:53 --> Config Class Initialized
INFO - 2021-07-29 02:41:53 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:53 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:53 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:53 --> URI Class Initialized
INFO - 2021-07-29 02:41:53 --> Router Class Initialized
INFO - 2021-07-29 02:41:53 --> Output Class Initialized
INFO - 2021-07-29 02:41:53 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:53 --> Input Class Initialized
INFO - 2021-07-29 02:41:53 --> Language Class Initialized
INFO - 2021-07-29 02:41:53 --> Language Class Initialized
INFO - 2021-07-29 02:41:53 --> Config Class Initialized
INFO - 2021-07-29 02:41:53 --> Loader Class Initialized
INFO - 2021-07-29 02:41:53 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:53 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:53 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:53 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:53 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:53 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:53 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:53 --> Total execution time: 0.0789
INFO - 2021-07-29 02:41:55 --> Config Class Initialized
INFO - 2021-07-29 02:41:55 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:55 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:55 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:55 --> URI Class Initialized
INFO - 2021-07-29 02:41:55 --> Router Class Initialized
INFO - 2021-07-29 02:41:55 --> Output Class Initialized
INFO - 2021-07-29 02:41:55 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:55 --> Input Class Initialized
INFO - 2021-07-29 02:41:55 --> Language Class Initialized
INFO - 2021-07-29 02:41:55 --> Language Class Initialized
INFO - 2021-07-29 02:41:55 --> Config Class Initialized
INFO - 2021-07-29 02:41:55 --> Loader Class Initialized
INFO - 2021-07-29 02:41:55 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:55 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:55 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:55 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:55 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:55 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:55 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:55 --> Total execution time: 0.0476
INFO - 2021-07-29 02:41:55 --> Config Class Initialized
INFO - 2021-07-29 02:41:55 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:55 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:55 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:55 --> URI Class Initialized
INFO - 2021-07-29 02:41:55 --> Router Class Initialized
INFO - 2021-07-29 02:41:55 --> Output Class Initialized
INFO - 2021-07-29 02:41:55 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:55 --> Input Class Initialized
INFO - 2021-07-29 02:41:55 --> Language Class Initialized
INFO - 2021-07-29 02:41:55 --> Language Class Initialized
INFO - 2021-07-29 02:41:55 --> Config Class Initialized
INFO - 2021-07-29 02:41:55 --> Loader Class Initialized
INFO - 2021-07-29 02:41:55 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:55 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:55 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:55 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:55 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:55 --> Controller Class Initialized
INFO - 2021-07-29 02:41:56 --> Config Class Initialized
INFO - 2021-07-29 02:41:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:56 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:56 --> URI Class Initialized
INFO - 2021-07-29 02:41:56 --> Router Class Initialized
INFO - 2021-07-29 02:41:56 --> Output Class Initialized
INFO - 2021-07-29 02:41:56 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:56 --> Input Class Initialized
INFO - 2021-07-29 02:41:56 --> Language Class Initialized
INFO - 2021-07-29 02:41:56 --> Language Class Initialized
INFO - 2021-07-29 02:41:56 --> Config Class Initialized
INFO - 2021-07-29 02:41:56 --> Loader Class Initialized
INFO - 2021-07-29 02:41:56 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:56 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:56 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:56 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:56 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:56 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:56 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:56 --> Total execution time: 0.0483
INFO - 2021-07-29 02:41:58 --> Config Class Initialized
INFO - 2021-07-29 02:41:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:58 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:58 --> URI Class Initialized
INFO - 2021-07-29 02:41:58 --> Router Class Initialized
INFO - 2021-07-29 02:41:58 --> Output Class Initialized
INFO - 2021-07-29 02:41:58 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:58 --> Input Class Initialized
INFO - 2021-07-29 02:41:58 --> Language Class Initialized
INFO - 2021-07-29 02:41:58 --> Language Class Initialized
INFO - 2021-07-29 02:41:58 --> Config Class Initialized
INFO - 2021-07-29 02:41:58 --> Loader Class Initialized
INFO - 2021-07-29 02:41:58 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:58 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:58 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:58 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:58 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:41:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:58 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:58 --> Total execution time: 0.0552
INFO - 2021-07-29 02:41:58 --> Config Class Initialized
INFO - 2021-07-29 02:41:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:58 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:58 --> URI Class Initialized
INFO - 2021-07-29 02:41:58 --> Router Class Initialized
INFO - 2021-07-29 02:41:58 --> Output Class Initialized
INFO - 2021-07-29 02:41:58 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:58 --> Input Class Initialized
INFO - 2021-07-29 02:41:58 --> Language Class Initialized
INFO - 2021-07-29 02:41:58 --> Language Class Initialized
INFO - 2021-07-29 02:41:58 --> Config Class Initialized
INFO - 2021-07-29 02:41:58 --> Loader Class Initialized
INFO - 2021-07-29 02:41:58 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:58 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:58 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:58 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:58 --> Controller Class Initialized
INFO - 2021-07-29 02:41:59 --> Config Class Initialized
INFO - 2021-07-29 02:41:59 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:41:59 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:41:59 --> Utf8 Class Initialized
INFO - 2021-07-29 02:41:59 --> URI Class Initialized
INFO - 2021-07-29 02:41:59 --> Router Class Initialized
INFO - 2021-07-29 02:41:59 --> Output Class Initialized
INFO - 2021-07-29 02:41:59 --> Security Class Initialized
DEBUG - 2021-07-29 02:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:41:59 --> Input Class Initialized
INFO - 2021-07-29 02:41:59 --> Language Class Initialized
INFO - 2021-07-29 02:41:59 --> Language Class Initialized
INFO - 2021-07-29 02:41:59 --> Config Class Initialized
INFO - 2021-07-29 02:41:59 --> Loader Class Initialized
INFO - 2021-07-29 02:41:59 --> Helper loaded: url_helper
INFO - 2021-07-29 02:41:59 --> Helper loaded: file_helper
INFO - 2021-07-29 02:41:59 --> Helper loaded: form_helper
INFO - 2021-07-29 02:41:59 --> Helper loaded: my_helper
INFO - 2021-07-29 02:41:59 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:41:59 --> Controller Class Initialized
DEBUG - 2021-07-29 02:41:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:41:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:41:59 --> Final output sent to browser
DEBUG - 2021-07-29 02:41:59 --> Total execution time: 0.0482
INFO - 2021-07-29 02:42:02 --> Config Class Initialized
INFO - 2021-07-29 02:42:02 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:02 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:02 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:02 --> URI Class Initialized
INFO - 2021-07-29 02:42:02 --> Router Class Initialized
INFO - 2021-07-29 02:42:02 --> Output Class Initialized
INFO - 2021-07-29 02:42:02 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:02 --> Input Class Initialized
INFO - 2021-07-29 02:42:02 --> Language Class Initialized
INFO - 2021-07-29 02:42:02 --> Language Class Initialized
INFO - 2021-07-29 02:42:02 --> Config Class Initialized
INFO - 2021-07-29 02:42:02 --> Loader Class Initialized
INFO - 2021-07-29 02:42:02 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:02 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:02 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:02 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:02 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:02 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:02 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:02 --> Total execution time: 0.0560
INFO - 2021-07-29 02:42:03 --> Config Class Initialized
INFO - 2021-07-29 02:42:03 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:03 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:03 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:03 --> URI Class Initialized
INFO - 2021-07-29 02:42:03 --> Router Class Initialized
INFO - 2021-07-29 02:42:03 --> Output Class Initialized
INFO - 2021-07-29 02:42:03 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:03 --> Input Class Initialized
INFO - 2021-07-29 02:42:03 --> Language Class Initialized
INFO - 2021-07-29 02:42:03 --> Language Class Initialized
INFO - 2021-07-29 02:42:03 --> Config Class Initialized
INFO - 2021-07-29 02:42:03 --> Loader Class Initialized
INFO - 2021-07-29 02:42:03 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:03 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:03 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:03 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:03 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:03 --> Controller Class Initialized
INFO - 2021-07-29 02:42:04 --> Config Class Initialized
INFO - 2021-07-29 02:42:04 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:04 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:04 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:04 --> URI Class Initialized
INFO - 2021-07-29 02:42:04 --> Router Class Initialized
INFO - 2021-07-29 02:42:04 --> Output Class Initialized
INFO - 2021-07-29 02:42:04 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:04 --> Input Class Initialized
INFO - 2021-07-29 02:42:04 --> Language Class Initialized
INFO - 2021-07-29 02:42:04 --> Language Class Initialized
INFO - 2021-07-29 02:42:04 --> Config Class Initialized
INFO - 2021-07-29 02:42:04 --> Loader Class Initialized
INFO - 2021-07-29 02:42:04 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:04 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:04 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:04 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:04 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:04 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:04 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:04 --> Total execution time: 0.0485
INFO - 2021-07-29 02:42:05 --> Config Class Initialized
INFO - 2021-07-29 02:42:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:05 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:05 --> URI Class Initialized
INFO - 2021-07-29 02:42:05 --> Router Class Initialized
INFO - 2021-07-29 02:42:05 --> Output Class Initialized
INFO - 2021-07-29 02:42:05 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:05 --> Input Class Initialized
INFO - 2021-07-29 02:42:05 --> Language Class Initialized
INFO - 2021-07-29 02:42:05 --> Language Class Initialized
INFO - 2021-07-29 02:42:05 --> Config Class Initialized
INFO - 2021-07-29 02:42:05 --> Loader Class Initialized
INFO - 2021-07-29 02:42:05 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:05 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:05 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:05 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:05 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:05 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:05 --> Total execution time: 0.0479
INFO - 2021-07-29 02:42:05 --> Config Class Initialized
INFO - 2021-07-29 02:42:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:05 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:05 --> URI Class Initialized
INFO - 2021-07-29 02:42:05 --> Router Class Initialized
INFO - 2021-07-29 02:42:05 --> Output Class Initialized
INFO - 2021-07-29 02:42:05 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:05 --> Input Class Initialized
INFO - 2021-07-29 02:42:05 --> Language Class Initialized
INFO - 2021-07-29 02:42:05 --> Language Class Initialized
INFO - 2021-07-29 02:42:05 --> Config Class Initialized
INFO - 2021-07-29 02:42:05 --> Loader Class Initialized
INFO - 2021-07-29 02:42:05 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:05 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:05 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:05 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:05 --> Controller Class Initialized
INFO - 2021-07-29 02:42:06 --> Config Class Initialized
INFO - 2021-07-29 02:42:06 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:06 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:06 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:06 --> URI Class Initialized
INFO - 2021-07-29 02:42:06 --> Router Class Initialized
INFO - 2021-07-29 02:42:06 --> Output Class Initialized
INFO - 2021-07-29 02:42:06 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:06 --> Input Class Initialized
INFO - 2021-07-29 02:42:06 --> Language Class Initialized
INFO - 2021-07-29 02:42:06 --> Language Class Initialized
INFO - 2021-07-29 02:42:06 --> Config Class Initialized
INFO - 2021-07-29 02:42:06 --> Loader Class Initialized
INFO - 2021-07-29 02:42:06 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:06 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:06 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:06 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:06 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:06 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:06 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:06 --> Total execution time: 0.0731
INFO - 2021-07-29 02:42:08 --> Config Class Initialized
INFO - 2021-07-29 02:42:08 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:08 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:08 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:08 --> URI Class Initialized
INFO - 2021-07-29 02:42:08 --> Router Class Initialized
INFO - 2021-07-29 02:42:08 --> Output Class Initialized
INFO - 2021-07-29 02:42:08 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:08 --> Input Class Initialized
INFO - 2021-07-29 02:42:08 --> Language Class Initialized
INFO - 2021-07-29 02:42:08 --> Language Class Initialized
INFO - 2021-07-29 02:42:08 --> Config Class Initialized
INFO - 2021-07-29 02:42:08 --> Loader Class Initialized
INFO - 2021-07-29 02:42:08 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:08 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:08 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:08 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:08 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:08 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:42:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:08 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:08 --> Total execution time: 0.0472
INFO - 2021-07-29 02:42:08 --> Config Class Initialized
INFO - 2021-07-29 02:42:08 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:08 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:08 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:08 --> URI Class Initialized
INFO - 2021-07-29 02:42:08 --> Router Class Initialized
INFO - 2021-07-29 02:42:08 --> Output Class Initialized
INFO - 2021-07-29 02:42:08 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:08 --> Input Class Initialized
INFO - 2021-07-29 02:42:08 --> Language Class Initialized
INFO - 2021-07-29 02:42:08 --> Language Class Initialized
INFO - 2021-07-29 02:42:08 --> Config Class Initialized
INFO - 2021-07-29 02:42:08 --> Loader Class Initialized
INFO - 2021-07-29 02:42:08 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:08 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:08 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:08 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:08 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:08 --> Controller Class Initialized
INFO - 2021-07-29 02:42:09 --> Config Class Initialized
INFO - 2021-07-29 02:42:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:09 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:09 --> URI Class Initialized
INFO - 2021-07-29 02:42:09 --> Router Class Initialized
INFO - 2021-07-29 02:42:09 --> Output Class Initialized
INFO - 2021-07-29 02:42:09 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:09 --> Input Class Initialized
INFO - 2021-07-29 02:42:09 --> Language Class Initialized
INFO - 2021-07-29 02:42:09 --> Language Class Initialized
INFO - 2021-07-29 02:42:09 --> Config Class Initialized
INFO - 2021-07-29 02:42:09 --> Loader Class Initialized
INFO - 2021-07-29 02:42:09 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:09 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:09 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:09 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:09 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:09 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:09 --> Total execution time: 0.0559
INFO - 2021-07-29 02:42:12 --> Config Class Initialized
INFO - 2021-07-29 02:42:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:12 --> URI Class Initialized
INFO - 2021-07-29 02:42:12 --> Router Class Initialized
INFO - 2021-07-29 02:42:12 --> Output Class Initialized
INFO - 2021-07-29 02:42:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:12 --> Input Class Initialized
INFO - 2021-07-29 02:42:12 --> Language Class Initialized
INFO - 2021-07-29 02:42:12 --> Language Class Initialized
INFO - 2021-07-29 02:42:12 --> Config Class Initialized
INFO - 2021-07-29 02:42:12 --> Loader Class Initialized
INFO - 2021-07-29 02:42:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:12 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:42:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:12 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:12 --> Total execution time: 0.0488
INFO - 2021-07-29 02:42:12 --> Config Class Initialized
INFO - 2021-07-29 02:42:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:12 --> URI Class Initialized
INFO - 2021-07-29 02:42:12 --> Router Class Initialized
INFO - 2021-07-29 02:42:12 --> Output Class Initialized
INFO - 2021-07-29 02:42:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:12 --> Input Class Initialized
INFO - 2021-07-29 02:42:12 --> Language Class Initialized
INFO - 2021-07-29 02:42:12 --> Language Class Initialized
INFO - 2021-07-29 02:42:12 --> Config Class Initialized
INFO - 2021-07-29 02:42:12 --> Loader Class Initialized
INFO - 2021-07-29 02:42:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:12 --> Controller Class Initialized
INFO - 2021-07-29 02:42:14 --> Config Class Initialized
INFO - 2021-07-29 02:42:14 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:14 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:14 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:14 --> URI Class Initialized
INFO - 2021-07-29 02:42:14 --> Router Class Initialized
INFO - 2021-07-29 02:42:14 --> Output Class Initialized
INFO - 2021-07-29 02:42:14 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:14 --> Input Class Initialized
INFO - 2021-07-29 02:42:14 --> Language Class Initialized
INFO - 2021-07-29 02:42:14 --> Language Class Initialized
INFO - 2021-07-29 02:42:14 --> Config Class Initialized
INFO - 2021-07-29 02:42:14 --> Loader Class Initialized
INFO - 2021-07-29 02:42:14 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:14 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:14 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:14 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:14 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:14 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:42:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:14 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:14 --> Total execution time: 0.0474
INFO - 2021-07-29 02:42:16 --> Config Class Initialized
INFO - 2021-07-29 02:42:16 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:16 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:16 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:16 --> URI Class Initialized
INFO - 2021-07-29 02:42:16 --> Router Class Initialized
INFO - 2021-07-29 02:42:16 --> Output Class Initialized
INFO - 2021-07-29 02:42:16 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:16 --> Input Class Initialized
INFO - 2021-07-29 02:42:16 --> Language Class Initialized
INFO - 2021-07-29 02:42:16 --> Language Class Initialized
INFO - 2021-07-29 02:42:16 --> Config Class Initialized
INFO - 2021-07-29 02:42:16 --> Loader Class Initialized
INFO - 2021-07-29 02:42:16 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:16 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:16 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:16 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:16 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:16 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:16 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:16 --> Total execution time: 0.0477
INFO - 2021-07-29 02:42:16 --> Config Class Initialized
INFO - 2021-07-29 02:42:16 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:16 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:16 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:16 --> URI Class Initialized
INFO - 2021-07-29 02:42:16 --> Router Class Initialized
INFO - 2021-07-29 02:42:16 --> Output Class Initialized
INFO - 2021-07-29 02:42:16 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:16 --> Input Class Initialized
INFO - 2021-07-29 02:42:16 --> Language Class Initialized
INFO - 2021-07-29 02:42:16 --> Language Class Initialized
INFO - 2021-07-29 02:42:16 --> Config Class Initialized
INFO - 2021-07-29 02:42:16 --> Loader Class Initialized
INFO - 2021-07-29 02:42:16 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:16 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:16 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:16 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:16 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:16 --> Controller Class Initialized
INFO - 2021-07-29 02:42:18 --> Config Class Initialized
INFO - 2021-07-29 02:42:18 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:18 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:18 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:18 --> URI Class Initialized
INFO - 2021-07-29 02:42:18 --> Router Class Initialized
INFO - 2021-07-29 02:42:18 --> Output Class Initialized
INFO - 2021-07-29 02:42:18 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:18 --> Input Class Initialized
INFO - 2021-07-29 02:42:18 --> Language Class Initialized
INFO - 2021-07-29 02:42:18 --> Language Class Initialized
INFO - 2021-07-29 02:42:18 --> Config Class Initialized
INFO - 2021-07-29 02:42:18 --> Loader Class Initialized
INFO - 2021-07-29 02:42:18 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:18 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:18 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:18 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:18 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:18 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:18 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:18 --> Total execution time: 0.0503
INFO - 2021-07-29 02:42:20 --> Config Class Initialized
INFO - 2021-07-29 02:42:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:20 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:20 --> URI Class Initialized
INFO - 2021-07-29 02:42:20 --> Router Class Initialized
INFO - 2021-07-29 02:42:20 --> Output Class Initialized
INFO - 2021-07-29 02:42:20 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:20 --> Input Class Initialized
INFO - 2021-07-29 02:42:20 --> Language Class Initialized
INFO - 2021-07-29 02:42:20 --> Language Class Initialized
INFO - 2021-07-29 02:42:20 --> Config Class Initialized
INFO - 2021-07-29 02:42:20 --> Loader Class Initialized
INFO - 2021-07-29 02:42:20 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:20 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:20 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:20 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:20 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:42:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:20 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:20 --> Total execution time: 0.0475
INFO - 2021-07-29 02:42:21 --> Config Class Initialized
INFO - 2021-07-29 02:42:21 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:21 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:21 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:21 --> URI Class Initialized
INFO - 2021-07-29 02:42:21 --> Router Class Initialized
INFO - 2021-07-29 02:42:21 --> Output Class Initialized
INFO - 2021-07-29 02:42:21 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:21 --> Input Class Initialized
INFO - 2021-07-29 02:42:21 --> Language Class Initialized
INFO - 2021-07-29 02:42:21 --> Language Class Initialized
INFO - 2021-07-29 02:42:21 --> Config Class Initialized
INFO - 2021-07-29 02:42:21 --> Loader Class Initialized
INFO - 2021-07-29 02:42:21 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:21 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:21 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:21 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:21 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:21 --> Controller Class Initialized
INFO - 2021-07-29 02:42:23 --> Config Class Initialized
INFO - 2021-07-29 02:42:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:23 --> URI Class Initialized
INFO - 2021-07-29 02:42:23 --> Router Class Initialized
INFO - 2021-07-29 02:42:23 --> Output Class Initialized
INFO - 2021-07-29 02:42:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:23 --> Input Class Initialized
INFO - 2021-07-29 02:42:23 --> Language Class Initialized
INFO - 2021-07-29 02:42:23 --> Language Class Initialized
INFO - 2021-07-29 02:42:23 --> Config Class Initialized
INFO - 2021-07-29 02:42:23 --> Loader Class Initialized
INFO - 2021-07-29 02:42:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:23 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:42:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:23 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:23 --> Total execution time: 0.0479
INFO - 2021-07-29 02:42:26 --> Config Class Initialized
INFO - 2021-07-29 02:42:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:26 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:26 --> URI Class Initialized
INFO - 2021-07-29 02:42:26 --> Router Class Initialized
INFO - 2021-07-29 02:42:26 --> Output Class Initialized
INFO - 2021-07-29 02:42:26 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:26 --> Input Class Initialized
INFO - 2021-07-29 02:42:26 --> Language Class Initialized
INFO - 2021-07-29 02:42:26 --> Language Class Initialized
INFO - 2021-07-29 02:42:26 --> Config Class Initialized
INFO - 2021-07-29 02:42:26 --> Loader Class Initialized
INFO - 2021-07-29 02:42:26 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:26 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:26 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:26 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:26 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:42:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:26 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:26 --> Total execution time: 0.0464
INFO - 2021-07-29 02:42:26 --> Config Class Initialized
INFO - 2021-07-29 02:42:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:26 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:26 --> URI Class Initialized
INFO - 2021-07-29 02:42:26 --> Router Class Initialized
INFO - 2021-07-29 02:42:26 --> Output Class Initialized
INFO - 2021-07-29 02:42:26 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:26 --> Input Class Initialized
INFO - 2021-07-29 02:42:26 --> Language Class Initialized
INFO - 2021-07-29 02:42:26 --> Language Class Initialized
INFO - 2021-07-29 02:42:26 --> Config Class Initialized
INFO - 2021-07-29 02:42:26 --> Loader Class Initialized
INFO - 2021-07-29 02:42:26 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:26 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:26 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:26 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:26 --> Controller Class Initialized
INFO - 2021-07-29 02:42:28 --> Config Class Initialized
INFO - 2021-07-29 02:42:28 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:42:28 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:42:28 --> Utf8 Class Initialized
INFO - 2021-07-29 02:42:28 --> URI Class Initialized
INFO - 2021-07-29 02:42:28 --> Router Class Initialized
INFO - 2021-07-29 02:42:28 --> Output Class Initialized
INFO - 2021-07-29 02:42:28 --> Security Class Initialized
DEBUG - 2021-07-29 02:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:42:28 --> Input Class Initialized
INFO - 2021-07-29 02:42:28 --> Language Class Initialized
INFO - 2021-07-29 02:42:28 --> Language Class Initialized
INFO - 2021-07-29 02:42:28 --> Config Class Initialized
INFO - 2021-07-29 02:42:28 --> Loader Class Initialized
INFO - 2021-07-29 02:42:28 --> Helper loaded: url_helper
INFO - 2021-07-29 02:42:28 --> Helper loaded: file_helper
INFO - 2021-07-29 02:42:28 --> Helper loaded: form_helper
INFO - 2021-07-29 02:42:28 --> Helper loaded: my_helper
INFO - 2021-07-29 02:42:28 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:42:28 --> Controller Class Initialized
DEBUG - 2021-07-29 02:42:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:42:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:42:28 --> Final output sent to browser
DEBUG - 2021-07-29 02:42:28 --> Total execution time: 0.0480
INFO - 2021-07-29 02:43:06 --> Config Class Initialized
INFO - 2021-07-29 02:43:06 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:06 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:06 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:06 --> URI Class Initialized
INFO - 2021-07-29 02:43:06 --> Router Class Initialized
INFO - 2021-07-29 02:43:06 --> Output Class Initialized
INFO - 2021-07-29 02:43:06 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:06 --> Input Class Initialized
INFO - 2021-07-29 02:43:06 --> Language Class Initialized
INFO - 2021-07-29 02:43:06 --> Language Class Initialized
INFO - 2021-07-29 02:43:06 --> Config Class Initialized
INFO - 2021-07-29 02:43:06 --> Loader Class Initialized
INFO - 2021-07-29 02:43:06 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:06 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:06 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:06 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:06 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:06 --> Controller Class Initialized
INFO - 2021-07-29 02:43:08 --> Config Class Initialized
INFO - 2021-07-29 02:43:08 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:08 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:08 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:08 --> URI Class Initialized
INFO - 2021-07-29 02:43:08 --> Router Class Initialized
INFO - 2021-07-29 02:43:08 --> Output Class Initialized
INFO - 2021-07-29 02:43:08 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:08 --> Input Class Initialized
INFO - 2021-07-29 02:43:08 --> Language Class Initialized
INFO - 2021-07-29 02:43:08 --> Language Class Initialized
INFO - 2021-07-29 02:43:08 --> Config Class Initialized
INFO - 2021-07-29 02:43:08 --> Loader Class Initialized
INFO - 2021-07-29 02:43:08 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:08 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:08 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:08 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:08 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:08 --> Controller Class Initialized
DEBUG - 2021-07-29 02:43:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 02:43:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:43:08 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:08 --> Total execution time: 0.0467
INFO - 2021-07-29 02:43:08 --> Config Class Initialized
INFO - 2021-07-29 02:43:08 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:08 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:08 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:08 --> URI Class Initialized
INFO - 2021-07-29 02:43:08 --> Router Class Initialized
INFO - 2021-07-29 02:43:08 --> Output Class Initialized
INFO - 2021-07-29 02:43:08 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:08 --> Input Class Initialized
INFO - 2021-07-29 02:43:08 --> Language Class Initialized
INFO - 2021-07-29 02:43:08 --> Language Class Initialized
INFO - 2021-07-29 02:43:08 --> Config Class Initialized
INFO - 2021-07-29 02:43:08 --> Loader Class Initialized
INFO - 2021-07-29 02:43:09 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:09 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:09 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:09 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:09 --> Controller Class Initialized
INFO - 2021-07-29 02:43:12 --> Config Class Initialized
INFO - 2021-07-29 02:43:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:12 --> URI Class Initialized
INFO - 2021-07-29 02:43:12 --> Router Class Initialized
INFO - 2021-07-29 02:43:12 --> Output Class Initialized
INFO - 2021-07-29 02:43:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:12 --> Input Class Initialized
INFO - 2021-07-29 02:43:12 --> Language Class Initialized
INFO - 2021-07-29 02:43:12 --> Language Class Initialized
INFO - 2021-07-29 02:43:12 --> Config Class Initialized
INFO - 2021-07-29 02:43:12 --> Loader Class Initialized
INFO - 2021-07-29 02:43:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:12 --> Controller Class Initialized
INFO - 2021-07-29 02:43:12 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:12 --> Total execution time: 0.0523
INFO - 2021-07-29 02:43:18 --> Config Class Initialized
INFO - 2021-07-29 02:43:18 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:18 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:18 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:18 --> URI Class Initialized
INFO - 2021-07-29 02:43:18 --> Router Class Initialized
INFO - 2021-07-29 02:43:18 --> Output Class Initialized
INFO - 2021-07-29 02:43:18 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:18 --> Input Class Initialized
INFO - 2021-07-29 02:43:18 --> Language Class Initialized
INFO - 2021-07-29 02:43:18 --> Language Class Initialized
INFO - 2021-07-29 02:43:18 --> Config Class Initialized
INFO - 2021-07-29 02:43:18 --> Loader Class Initialized
INFO - 2021-07-29 02:43:18 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:18 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:18 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:18 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:18 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:18 --> Controller Class Initialized
INFO - 2021-07-29 02:43:18 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:18 --> Total execution time: 0.0435
INFO - 2021-07-29 02:43:18 --> Config Class Initialized
INFO - 2021-07-29 02:43:18 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:18 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:18 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:18 --> URI Class Initialized
INFO - 2021-07-29 02:43:18 --> Router Class Initialized
INFO - 2021-07-29 02:43:18 --> Output Class Initialized
INFO - 2021-07-29 02:43:18 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:18 --> Input Class Initialized
INFO - 2021-07-29 02:43:18 --> Language Class Initialized
INFO - 2021-07-29 02:43:18 --> Language Class Initialized
INFO - 2021-07-29 02:43:18 --> Config Class Initialized
INFO - 2021-07-29 02:43:18 --> Loader Class Initialized
INFO - 2021-07-29 02:43:18 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:18 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:18 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:18 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:18 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:18 --> Controller Class Initialized
INFO - 2021-07-29 02:43:20 --> Config Class Initialized
INFO - 2021-07-29 02:43:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:20 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:20 --> URI Class Initialized
INFO - 2021-07-29 02:43:20 --> Router Class Initialized
INFO - 2021-07-29 02:43:20 --> Output Class Initialized
INFO - 2021-07-29 02:43:20 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:20 --> Input Class Initialized
INFO - 2021-07-29 02:43:20 --> Language Class Initialized
INFO - 2021-07-29 02:43:20 --> Language Class Initialized
INFO - 2021-07-29 02:43:20 --> Config Class Initialized
INFO - 2021-07-29 02:43:20 --> Loader Class Initialized
INFO - 2021-07-29 02:43:20 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:20 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:20 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:20 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:20 --> Controller Class Initialized
INFO - 2021-07-29 02:43:20 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:20 --> Total execution time: 0.0437
INFO - 2021-07-29 02:43:23 --> Config Class Initialized
INFO - 2021-07-29 02:43:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:23 --> URI Class Initialized
INFO - 2021-07-29 02:43:23 --> Router Class Initialized
INFO - 2021-07-29 02:43:23 --> Output Class Initialized
INFO - 2021-07-29 02:43:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:23 --> Input Class Initialized
INFO - 2021-07-29 02:43:23 --> Language Class Initialized
INFO - 2021-07-29 02:43:23 --> Language Class Initialized
INFO - 2021-07-29 02:43:23 --> Config Class Initialized
INFO - 2021-07-29 02:43:23 --> Loader Class Initialized
INFO - 2021-07-29 02:43:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:23 --> Controller Class Initialized
INFO - 2021-07-29 02:43:23 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:23 --> Total execution time: 0.0430
INFO - 2021-07-29 02:43:23 --> Config Class Initialized
INFO - 2021-07-29 02:43:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:23 --> URI Class Initialized
INFO - 2021-07-29 02:43:23 --> Router Class Initialized
INFO - 2021-07-29 02:43:23 --> Output Class Initialized
INFO - 2021-07-29 02:43:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:23 --> Input Class Initialized
INFO - 2021-07-29 02:43:23 --> Language Class Initialized
INFO - 2021-07-29 02:43:23 --> Language Class Initialized
INFO - 2021-07-29 02:43:23 --> Config Class Initialized
INFO - 2021-07-29 02:43:23 --> Loader Class Initialized
INFO - 2021-07-29 02:43:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:23 --> Controller Class Initialized
DEBUG - 2021-07-29 02:43:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:43:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:43:23 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:23 --> Total execution time: 0.0440
INFO - 2021-07-29 02:43:27 --> Config Class Initialized
INFO - 2021-07-29 02:43:27 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:27 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:27 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:27 --> URI Class Initialized
INFO - 2021-07-29 02:43:27 --> Router Class Initialized
INFO - 2021-07-29 02:43:27 --> Output Class Initialized
INFO - 2021-07-29 02:43:27 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:27 --> Input Class Initialized
INFO - 2021-07-29 02:43:27 --> Language Class Initialized
INFO - 2021-07-29 02:43:27 --> Language Class Initialized
INFO - 2021-07-29 02:43:27 --> Config Class Initialized
INFO - 2021-07-29 02:43:27 --> Loader Class Initialized
INFO - 2021-07-29 02:43:27 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:27 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:27 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:27 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:27 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:27 --> Controller Class Initialized
INFO - 2021-07-29 02:43:27 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:27 --> Total execution time: 0.0417
INFO - 2021-07-29 02:43:29 --> Config Class Initialized
INFO - 2021-07-29 02:43:29 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:29 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:29 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:29 --> URI Class Initialized
INFO - 2021-07-29 02:43:29 --> Router Class Initialized
INFO - 2021-07-29 02:43:29 --> Output Class Initialized
INFO - 2021-07-29 02:43:29 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:29 --> Input Class Initialized
INFO - 2021-07-29 02:43:29 --> Language Class Initialized
INFO - 2021-07-29 02:43:29 --> Language Class Initialized
INFO - 2021-07-29 02:43:29 --> Config Class Initialized
INFO - 2021-07-29 02:43:29 --> Loader Class Initialized
INFO - 2021-07-29 02:43:29 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:29 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:29 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:29 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:29 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:29 --> Controller Class Initialized
INFO - 2021-07-29 02:43:29 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:29 --> Total execution time: 0.0423
INFO - 2021-07-29 02:43:29 --> Config Class Initialized
INFO - 2021-07-29 02:43:29 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:29 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:29 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:29 --> URI Class Initialized
INFO - 2021-07-29 02:43:29 --> Router Class Initialized
INFO - 2021-07-29 02:43:29 --> Output Class Initialized
INFO - 2021-07-29 02:43:29 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:29 --> Input Class Initialized
INFO - 2021-07-29 02:43:29 --> Language Class Initialized
INFO - 2021-07-29 02:43:29 --> Language Class Initialized
INFO - 2021-07-29 02:43:29 --> Config Class Initialized
INFO - 2021-07-29 02:43:29 --> Loader Class Initialized
INFO - 2021-07-29 02:43:29 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:29 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:29 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:29 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:29 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:29 --> Controller Class Initialized
INFO - 2021-07-29 02:43:31 --> Config Class Initialized
INFO - 2021-07-29 02:43:31 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:31 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:31 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:31 --> URI Class Initialized
INFO - 2021-07-29 02:43:31 --> Router Class Initialized
INFO - 2021-07-29 02:43:31 --> Output Class Initialized
INFO - 2021-07-29 02:43:31 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:31 --> Input Class Initialized
INFO - 2021-07-29 02:43:31 --> Language Class Initialized
INFO - 2021-07-29 02:43:31 --> Language Class Initialized
INFO - 2021-07-29 02:43:31 --> Config Class Initialized
INFO - 2021-07-29 02:43:31 --> Loader Class Initialized
INFO - 2021-07-29 02:43:31 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:31 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:31 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:31 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:31 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:31 --> Controller Class Initialized
INFO - 2021-07-29 02:43:31 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:31 --> Total execution time: 0.0527
INFO - 2021-07-29 02:43:35 --> Config Class Initialized
INFO - 2021-07-29 02:43:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:35 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:35 --> URI Class Initialized
INFO - 2021-07-29 02:43:35 --> Router Class Initialized
INFO - 2021-07-29 02:43:35 --> Output Class Initialized
INFO - 2021-07-29 02:43:35 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:35 --> Input Class Initialized
INFO - 2021-07-29 02:43:35 --> Language Class Initialized
INFO - 2021-07-29 02:43:35 --> Language Class Initialized
INFO - 2021-07-29 02:43:35 --> Config Class Initialized
INFO - 2021-07-29 02:43:35 --> Loader Class Initialized
INFO - 2021-07-29 02:43:35 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:35 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:35 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:35 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:35 --> Controller Class Initialized
INFO - 2021-07-29 02:43:35 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:35 --> Total execution time: 0.0429
INFO - 2021-07-29 02:43:35 --> Config Class Initialized
INFO - 2021-07-29 02:43:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:35 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:35 --> URI Class Initialized
INFO - 2021-07-29 02:43:35 --> Router Class Initialized
INFO - 2021-07-29 02:43:35 --> Output Class Initialized
INFO - 2021-07-29 02:43:35 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:35 --> Input Class Initialized
INFO - 2021-07-29 02:43:35 --> Language Class Initialized
INFO - 2021-07-29 02:43:35 --> Language Class Initialized
INFO - 2021-07-29 02:43:35 --> Config Class Initialized
INFO - 2021-07-29 02:43:35 --> Loader Class Initialized
INFO - 2021-07-29 02:43:35 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:35 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:35 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:35 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:35 --> Controller Class Initialized
DEBUG - 2021-07-29 02:43:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:43:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:43:35 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:35 --> Total execution time: 0.0443
INFO - 2021-07-29 02:43:37 --> Config Class Initialized
INFO - 2021-07-29 02:43:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:37 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:37 --> URI Class Initialized
INFO - 2021-07-29 02:43:37 --> Router Class Initialized
INFO - 2021-07-29 02:43:37 --> Output Class Initialized
INFO - 2021-07-29 02:43:37 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:37 --> Input Class Initialized
INFO - 2021-07-29 02:43:37 --> Language Class Initialized
INFO - 2021-07-29 02:43:37 --> Language Class Initialized
INFO - 2021-07-29 02:43:37 --> Config Class Initialized
INFO - 2021-07-29 02:43:37 --> Loader Class Initialized
INFO - 2021-07-29 02:43:37 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:37 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:37 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:37 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:37 --> Controller Class Initialized
INFO - 2021-07-29 02:43:37 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:37 --> Total execution time: 0.0423
INFO - 2021-07-29 02:43:40 --> Config Class Initialized
INFO - 2021-07-29 02:43:40 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:40 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:40 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:40 --> URI Class Initialized
INFO - 2021-07-29 02:43:40 --> Router Class Initialized
INFO - 2021-07-29 02:43:40 --> Output Class Initialized
INFO - 2021-07-29 02:43:40 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:40 --> Input Class Initialized
INFO - 2021-07-29 02:43:40 --> Language Class Initialized
INFO - 2021-07-29 02:43:40 --> Language Class Initialized
INFO - 2021-07-29 02:43:40 --> Config Class Initialized
INFO - 2021-07-29 02:43:40 --> Loader Class Initialized
INFO - 2021-07-29 02:43:40 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:40 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:40 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:40 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:40 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:40 --> Controller Class Initialized
INFO - 2021-07-29 02:43:40 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:40 --> Total execution time: 0.0423
INFO - 2021-07-29 02:43:40 --> Config Class Initialized
INFO - 2021-07-29 02:43:40 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:40 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:40 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:40 --> URI Class Initialized
INFO - 2021-07-29 02:43:40 --> Router Class Initialized
INFO - 2021-07-29 02:43:40 --> Output Class Initialized
INFO - 2021-07-29 02:43:40 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:40 --> Input Class Initialized
INFO - 2021-07-29 02:43:40 --> Language Class Initialized
INFO - 2021-07-29 02:43:40 --> Language Class Initialized
INFO - 2021-07-29 02:43:40 --> Config Class Initialized
INFO - 2021-07-29 02:43:40 --> Loader Class Initialized
INFO - 2021-07-29 02:43:40 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:40 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:40 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:40 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:40 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:40 --> Controller Class Initialized
INFO - 2021-07-29 02:43:43 --> Config Class Initialized
INFO - 2021-07-29 02:43:43 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:43 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:43 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:43 --> URI Class Initialized
INFO - 2021-07-29 02:43:43 --> Router Class Initialized
INFO - 2021-07-29 02:43:43 --> Output Class Initialized
INFO - 2021-07-29 02:43:43 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:43 --> Input Class Initialized
INFO - 2021-07-29 02:43:43 --> Language Class Initialized
INFO - 2021-07-29 02:43:43 --> Language Class Initialized
INFO - 2021-07-29 02:43:43 --> Config Class Initialized
INFO - 2021-07-29 02:43:43 --> Loader Class Initialized
INFO - 2021-07-29 02:43:43 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:43 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:43 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:43 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:43 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:43 --> Controller Class Initialized
INFO - 2021-07-29 02:43:43 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:43 --> Total execution time: 0.0416
INFO - 2021-07-29 02:43:45 --> Config Class Initialized
INFO - 2021-07-29 02:43:45 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:45 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:45 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:45 --> URI Class Initialized
INFO - 2021-07-29 02:43:45 --> Router Class Initialized
INFO - 2021-07-29 02:43:45 --> Output Class Initialized
INFO - 2021-07-29 02:43:45 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:45 --> Input Class Initialized
INFO - 2021-07-29 02:43:45 --> Language Class Initialized
INFO - 2021-07-29 02:43:45 --> Language Class Initialized
INFO - 2021-07-29 02:43:45 --> Config Class Initialized
INFO - 2021-07-29 02:43:45 --> Loader Class Initialized
INFO - 2021-07-29 02:43:45 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:45 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:45 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:45 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:45 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:46 --> Controller Class Initialized
INFO - 2021-07-29 02:43:46 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:46 --> Total execution time: 0.0654
INFO - 2021-07-29 02:43:46 --> Config Class Initialized
INFO - 2021-07-29 02:43:46 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:46 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:46 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:46 --> URI Class Initialized
INFO - 2021-07-29 02:43:46 --> Router Class Initialized
INFO - 2021-07-29 02:43:46 --> Output Class Initialized
INFO - 2021-07-29 02:43:46 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:46 --> Input Class Initialized
INFO - 2021-07-29 02:43:46 --> Language Class Initialized
INFO - 2021-07-29 02:43:46 --> Language Class Initialized
INFO - 2021-07-29 02:43:46 --> Config Class Initialized
INFO - 2021-07-29 02:43:46 --> Loader Class Initialized
INFO - 2021-07-29 02:43:46 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:46 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:46 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:46 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:46 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:46 --> Controller Class Initialized
DEBUG - 2021-07-29 02:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:43:46 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:46 --> Total execution time: 0.0596
INFO - 2021-07-29 02:43:48 --> Config Class Initialized
INFO - 2021-07-29 02:43:48 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:48 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:48 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:48 --> URI Class Initialized
INFO - 2021-07-29 02:43:48 --> Router Class Initialized
INFO - 2021-07-29 02:43:48 --> Output Class Initialized
INFO - 2021-07-29 02:43:48 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:48 --> Input Class Initialized
INFO - 2021-07-29 02:43:48 --> Language Class Initialized
INFO - 2021-07-29 02:43:48 --> Language Class Initialized
INFO - 2021-07-29 02:43:48 --> Config Class Initialized
INFO - 2021-07-29 02:43:48 --> Loader Class Initialized
INFO - 2021-07-29 02:43:48 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:48 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:48 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:48 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:48 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:48 --> Controller Class Initialized
INFO - 2021-07-29 02:43:48 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:48 --> Total execution time: 0.0422
INFO - 2021-07-29 02:43:53 --> Config Class Initialized
INFO - 2021-07-29 02:43:53 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:53 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:53 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:53 --> URI Class Initialized
INFO - 2021-07-29 02:43:53 --> Router Class Initialized
INFO - 2021-07-29 02:43:53 --> Output Class Initialized
INFO - 2021-07-29 02:43:53 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:53 --> Input Class Initialized
INFO - 2021-07-29 02:43:53 --> Language Class Initialized
INFO - 2021-07-29 02:43:53 --> Language Class Initialized
INFO - 2021-07-29 02:43:53 --> Config Class Initialized
INFO - 2021-07-29 02:43:53 --> Loader Class Initialized
INFO - 2021-07-29 02:43:53 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:53 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:53 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:53 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:53 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:53 --> Controller Class Initialized
INFO - 2021-07-29 02:43:53 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:53 --> Total execution time: 0.0430
INFO - 2021-07-29 02:43:53 --> Config Class Initialized
INFO - 2021-07-29 02:43:53 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:53 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:53 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:53 --> URI Class Initialized
INFO - 2021-07-29 02:43:53 --> Router Class Initialized
INFO - 2021-07-29 02:43:53 --> Output Class Initialized
INFO - 2021-07-29 02:43:53 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:53 --> Input Class Initialized
INFO - 2021-07-29 02:43:53 --> Language Class Initialized
INFO - 2021-07-29 02:43:53 --> Language Class Initialized
INFO - 2021-07-29 02:43:53 --> Config Class Initialized
INFO - 2021-07-29 02:43:53 --> Loader Class Initialized
INFO - 2021-07-29 02:43:53 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:53 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:53 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:53 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:53 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:53 --> Controller Class Initialized
INFO - 2021-07-29 02:43:56 --> Config Class Initialized
INFO - 2021-07-29 02:43:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:56 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:56 --> URI Class Initialized
INFO - 2021-07-29 02:43:56 --> Router Class Initialized
INFO - 2021-07-29 02:43:56 --> Output Class Initialized
INFO - 2021-07-29 02:43:56 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:56 --> Input Class Initialized
INFO - 2021-07-29 02:43:56 --> Language Class Initialized
INFO - 2021-07-29 02:43:56 --> Language Class Initialized
INFO - 2021-07-29 02:43:56 --> Config Class Initialized
INFO - 2021-07-29 02:43:56 --> Loader Class Initialized
INFO - 2021-07-29 02:43:56 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:56 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:56 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:56 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:56 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:56 --> Controller Class Initialized
INFO - 2021-07-29 02:43:56 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:56 --> Total execution time: 0.0427
INFO - 2021-07-29 02:43:57 --> Config Class Initialized
INFO - 2021-07-29 02:43:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:43:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:43:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:43:57 --> URI Class Initialized
INFO - 2021-07-29 02:43:57 --> Router Class Initialized
INFO - 2021-07-29 02:43:57 --> Output Class Initialized
INFO - 2021-07-29 02:43:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:43:57 --> Input Class Initialized
INFO - 2021-07-29 02:43:57 --> Language Class Initialized
INFO - 2021-07-29 02:43:57 --> Language Class Initialized
INFO - 2021-07-29 02:43:57 --> Config Class Initialized
INFO - 2021-07-29 02:43:57 --> Loader Class Initialized
INFO - 2021-07-29 02:43:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:43:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:43:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:43:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:43:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:43:57 --> Controller Class Initialized
INFO - 2021-07-29 02:43:57 --> Final output sent to browser
DEBUG - 2021-07-29 02:43:57 --> Total execution time: 0.0417
INFO - 2021-07-29 02:44:00 --> Config Class Initialized
INFO - 2021-07-29 02:44:00 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:00 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:00 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:00 --> URI Class Initialized
INFO - 2021-07-29 02:44:00 --> Router Class Initialized
INFO - 2021-07-29 02:44:00 --> Output Class Initialized
INFO - 2021-07-29 02:44:00 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:00 --> Input Class Initialized
INFO - 2021-07-29 02:44:00 --> Language Class Initialized
INFO - 2021-07-29 02:44:00 --> Language Class Initialized
INFO - 2021-07-29 02:44:00 --> Config Class Initialized
INFO - 2021-07-29 02:44:00 --> Loader Class Initialized
INFO - 2021-07-29 02:44:00 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:00 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:00 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:00 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:00 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:00 --> Controller Class Initialized
INFO - 2021-07-29 02:44:00 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:00 --> Total execution time: 0.0426
INFO - 2021-07-29 02:44:00 --> Config Class Initialized
INFO - 2021-07-29 02:44:00 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:00 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:00 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:00 --> URI Class Initialized
INFO - 2021-07-29 02:44:00 --> Router Class Initialized
INFO - 2021-07-29 02:44:00 --> Output Class Initialized
INFO - 2021-07-29 02:44:00 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:00 --> Input Class Initialized
INFO - 2021-07-29 02:44:00 --> Language Class Initialized
INFO - 2021-07-29 02:44:00 --> Language Class Initialized
INFO - 2021-07-29 02:44:00 --> Config Class Initialized
INFO - 2021-07-29 02:44:00 --> Loader Class Initialized
INFO - 2021-07-29 02:44:00 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:00 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:00 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:00 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:00 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:00 --> Controller Class Initialized
DEBUG - 2021-07-29 02:44:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:44:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:44:00 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:00 --> Total execution time: 0.0445
INFO - 2021-07-29 02:44:03 --> Config Class Initialized
INFO - 2021-07-29 02:44:03 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:03 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:03 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:03 --> URI Class Initialized
INFO - 2021-07-29 02:44:03 --> Router Class Initialized
INFO - 2021-07-29 02:44:03 --> Output Class Initialized
INFO - 2021-07-29 02:44:03 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:03 --> Input Class Initialized
INFO - 2021-07-29 02:44:03 --> Language Class Initialized
INFO - 2021-07-29 02:44:03 --> Language Class Initialized
INFO - 2021-07-29 02:44:03 --> Config Class Initialized
INFO - 2021-07-29 02:44:03 --> Loader Class Initialized
INFO - 2021-07-29 02:44:03 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:03 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:03 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:03 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:03 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:03 --> Controller Class Initialized
INFO - 2021-07-29 02:44:03 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:03 --> Total execution time: 0.0427
INFO - 2021-07-29 02:44:05 --> Config Class Initialized
INFO - 2021-07-29 02:44:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:05 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:05 --> URI Class Initialized
INFO - 2021-07-29 02:44:05 --> Router Class Initialized
INFO - 2021-07-29 02:44:05 --> Output Class Initialized
INFO - 2021-07-29 02:44:05 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:05 --> Input Class Initialized
INFO - 2021-07-29 02:44:05 --> Language Class Initialized
INFO - 2021-07-29 02:44:05 --> Language Class Initialized
INFO - 2021-07-29 02:44:05 --> Config Class Initialized
INFO - 2021-07-29 02:44:05 --> Loader Class Initialized
INFO - 2021-07-29 02:44:05 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:05 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:05 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:05 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:05 --> Controller Class Initialized
INFO - 2021-07-29 02:44:06 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:06 --> Total execution time: 0.0427
INFO - 2021-07-29 02:44:06 --> Config Class Initialized
INFO - 2021-07-29 02:44:06 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:06 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:06 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:06 --> URI Class Initialized
INFO - 2021-07-29 02:44:06 --> Router Class Initialized
INFO - 2021-07-29 02:44:06 --> Output Class Initialized
INFO - 2021-07-29 02:44:06 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:06 --> Input Class Initialized
INFO - 2021-07-29 02:44:06 --> Language Class Initialized
INFO - 2021-07-29 02:44:06 --> Language Class Initialized
INFO - 2021-07-29 02:44:06 --> Config Class Initialized
INFO - 2021-07-29 02:44:06 --> Loader Class Initialized
INFO - 2021-07-29 02:44:06 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:06 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:06 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:06 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:06 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:06 --> Controller Class Initialized
INFO - 2021-07-29 02:44:08 --> Config Class Initialized
INFO - 2021-07-29 02:44:08 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:08 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:08 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:08 --> URI Class Initialized
INFO - 2021-07-29 02:44:08 --> Router Class Initialized
INFO - 2021-07-29 02:44:08 --> Output Class Initialized
INFO - 2021-07-29 02:44:08 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:08 --> Input Class Initialized
INFO - 2021-07-29 02:44:08 --> Language Class Initialized
INFO - 2021-07-29 02:44:08 --> Language Class Initialized
INFO - 2021-07-29 02:44:08 --> Config Class Initialized
INFO - 2021-07-29 02:44:08 --> Loader Class Initialized
INFO - 2021-07-29 02:44:08 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:08 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:08 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:08 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:08 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:08 --> Controller Class Initialized
INFO - 2021-07-29 02:44:08 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:08 --> Total execution time: 0.0413
INFO - 2021-07-29 02:44:10 --> Config Class Initialized
INFO - 2021-07-29 02:44:10 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:10 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:10 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:10 --> URI Class Initialized
INFO - 2021-07-29 02:44:10 --> Router Class Initialized
INFO - 2021-07-29 02:44:10 --> Output Class Initialized
INFO - 2021-07-29 02:44:10 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:10 --> Input Class Initialized
INFO - 2021-07-29 02:44:10 --> Language Class Initialized
INFO - 2021-07-29 02:44:10 --> Language Class Initialized
INFO - 2021-07-29 02:44:10 --> Config Class Initialized
INFO - 2021-07-29 02:44:10 --> Loader Class Initialized
INFO - 2021-07-29 02:44:10 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:10 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:10 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:10 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:10 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:10 --> Controller Class Initialized
INFO - 2021-07-29 02:44:10 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:10 --> Total execution time: 0.0426
INFO - 2021-07-29 02:44:10 --> Config Class Initialized
INFO - 2021-07-29 02:44:10 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:10 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:10 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:10 --> URI Class Initialized
INFO - 2021-07-29 02:44:10 --> Router Class Initialized
INFO - 2021-07-29 02:44:10 --> Output Class Initialized
INFO - 2021-07-29 02:44:10 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:10 --> Input Class Initialized
INFO - 2021-07-29 02:44:10 --> Language Class Initialized
INFO - 2021-07-29 02:44:10 --> Language Class Initialized
INFO - 2021-07-29 02:44:10 --> Config Class Initialized
INFO - 2021-07-29 02:44:10 --> Loader Class Initialized
INFO - 2021-07-29 02:44:10 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:10 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:10 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:10 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:10 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:10 --> Controller Class Initialized
DEBUG - 2021-07-29 02:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:44:10 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:10 --> Total execution time: 0.0460
INFO - 2021-07-29 02:44:13 --> Config Class Initialized
INFO - 2021-07-29 02:44:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:13 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:13 --> URI Class Initialized
INFO - 2021-07-29 02:44:13 --> Router Class Initialized
INFO - 2021-07-29 02:44:13 --> Output Class Initialized
INFO - 2021-07-29 02:44:13 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:13 --> Input Class Initialized
INFO - 2021-07-29 02:44:13 --> Language Class Initialized
INFO - 2021-07-29 02:44:13 --> Language Class Initialized
INFO - 2021-07-29 02:44:13 --> Config Class Initialized
INFO - 2021-07-29 02:44:13 --> Loader Class Initialized
INFO - 2021-07-29 02:44:13 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:13 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:13 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:13 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:13 --> Controller Class Initialized
INFO - 2021-07-29 02:44:13 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:13 --> Total execution time: 0.0414
INFO - 2021-07-29 02:44:15 --> Config Class Initialized
INFO - 2021-07-29 02:44:15 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:15 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:15 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:15 --> URI Class Initialized
INFO - 2021-07-29 02:44:15 --> Router Class Initialized
INFO - 2021-07-29 02:44:15 --> Output Class Initialized
INFO - 2021-07-29 02:44:15 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:15 --> Input Class Initialized
INFO - 2021-07-29 02:44:15 --> Language Class Initialized
INFO - 2021-07-29 02:44:15 --> Language Class Initialized
INFO - 2021-07-29 02:44:15 --> Config Class Initialized
INFO - 2021-07-29 02:44:15 --> Loader Class Initialized
INFO - 2021-07-29 02:44:15 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:15 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:15 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:15 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:15 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:15 --> Controller Class Initialized
INFO - 2021-07-29 02:44:15 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:15 --> Total execution time: 0.0431
INFO - 2021-07-29 02:44:15 --> Config Class Initialized
INFO - 2021-07-29 02:44:15 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:15 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:15 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:15 --> URI Class Initialized
INFO - 2021-07-29 02:44:15 --> Router Class Initialized
INFO - 2021-07-29 02:44:15 --> Output Class Initialized
INFO - 2021-07-29 02:44:15 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:15 --> Input Class Initialized
INFO - 2021-07-29 02:44:15 --> Language Class Initialized
INFO - 2021-07-29 02:44:15 --> Language Class Initialized
INFO - 2021-07-29 02:44:15 --> Config Class Initialized
INFO - 2021-07-29 02:44:15 --> Loader Class Initialized
INFO - 2021-07-29 02:44:15 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:15 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:15 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:15 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:15 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:15 --> Controller Class Initialized
INFO - 2021-07-29 02:44:17 --> Config Class Initialized
INFO - 2021-07-29 02:44:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:17 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:17 --> URI Class Initialized
INFO - 2021-07-29 02:44:17 --> Router Class Initialized
INFO - 2021-07-29 02:44:17 --> Output Class Initialized
INFO - 2021-07-29 02:44:17 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:17 --> Input Class Initialized
INFO - 2021-07-29 02:44:17 --> Language Class Initialized
INFO - 2021-07-29 02:44:17 --> Language Class Initialized
INFO - 2021-07-29 02:44:17 --> Config Class Initialized
INFO - 2021-07-29 02:44:17 --> Loader Class Initialized
INFO - 2021-07-29 02:44:17 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:17 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:17 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:17 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:17 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:17 --> Controller Class Initialized
INFO - 2021-07-29 02:44:17 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:17 --> Total execution time: 0.0415
INFO - 2021-07-29 02:44:20 --> Config Class Initialized
INFO - 2021-07-29 02:44:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:20 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:20 --> URI Class Initialized
INFO - 2021-07-29 02:44:20 --> Router Class Initialized
INFO - 2021-07-29 02:44:20 --> Output Class Initialized
INFO - 2021-07-29 02:44:20 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:20 --> Input Class Initialized
INFO - 2021-07-29 02:44:20 --> Language Class Initialized
INFO - 2021-07-29 02:44:20 --> Language Class Initialized
INFO - 2021-07-29 02:44:20 --> Config Class Initialized
INFO - 2021-07-29 02:44:20 --> Loader Class Initialized
INFO - 2021-07-29 02:44:20 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:20 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:20 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:20 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:20 --> Controller Class Initialized
INFO - 2021-07-29 02:44:20 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:20 --> Total execution time: 0.0429
INFO - 2021-07-29 02:44:20 --> Config Class Initialized
INFO - 2021-07-29 02:44:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:20 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:20 --> URI Class Initialized
INFO - 2021-07-29 02:44:20 --> Router Class Initialized
INFO - 2021-07-29 02:44:20 --> Output Class Initialized
INFO - 2021-07-29 02:44:20 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:20 --> Input Class Initialized
INFO - 2021-07-29 02:44:20 --> Language Class Initialized
INFO - 2021-07-29 02:44:20 --> Language Class Initialized
INFO - 2021-07-29 02:44:20 --> Config Class Initialized
INFO - 2021-07-29 02:44:20 --> Loader Class Initialized
INFO - 2021-07-29 02:44:20 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:20 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:20 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:20 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:20 --> Controller Class Initialized
DEBUG - 2021-07-29 02:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:44:20 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:20 --> Total execution time: 0.0436
INFO - 2021-07-29 02:44:22 --> Config Class Initialized
INFO - 2021-07-29 02:44:22 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:22 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:22 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:22 --> URI Class Initialized
INFO - 2021-07-29 02:44:22 --> Router Class Initialized
INFO - 2021-07-29 02:44:22 --> Output Class Initialized
INFO - 2021-07-29 02:44:22 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:22 --> Input Class Initialized
INFO - 2021-07-29 02:44:22 --> Language Class Initialized
INFO - 2021-07-29 02:44:22 --> Language Class Initialized
INFO - 2021-07-29 02:44:22 --> Config Class Initialized
INFO - 2021-07-29 02:44:22 --> Loader Class Initialized
INFO - 2021-07-29 02:44:22 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:22 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:22 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:22 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:22 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:22 --> Controller Class Initialized
INFO - 2021-07-29 02:44:22 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:22 --> Total execution time: 0.0416
INFO - 2021-07-29 02:44:24 --> Config Class Initialized
INFO - 2021-07-29 02:44:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:24 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:24 --> URI Class Initialized
INFO - 2021-07-29 02:44:24 --> Router Class Initialized
INFO - 2021-07-29 02:44:24 --> Output Class Initialized
INFO - 2021-07-29 02:44:24 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:24 --> Input Class Initialized
INFO - 2021-07-29 02:44:24 --> Language Class Initialized
INFO - 2021-07-29 02:44:24 --> Language Class Initialized
INFO - 2021-07-29 02:44:24 --> Config Class Initialized
INFO - 2021-07-29 02:44:24 --> Loader Class Initialized
INFO - 2021-07-29 02:44:24 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:24 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:24 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:24 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:24 --> Controller Class Initialized
INFO - 2021-07-29 02:44:24 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:24 --> Total execution time: 0.0427
INFO - 2021-07-29 02:44:24 --> Config Class Initialized
INFO - 2021-07-29 02:44:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:24 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:24 --> URI Class Initialized
INFO - 2021-07-29 02:44:24 --> Router Class Initialized
INFO - 2021-07-29 02:44:24 --> Output Class Initialized
INFO - 2021-07-29 02:44:24 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:24 --> Input Class Initialized
INFO - 2021-07-29 02:44:24 --> Language Class Initialized
INFO - 2021-07-29 02:44:24 --> Language Class Initialized
INFO - 2021-07-29 02:44:24 --> Config Class Initialized
INFO - 2021-07-29 02:44:24 --> Loader Class Initialized
INFO - 2021-07-29 02:44:24 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:24 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:24 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:24 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:24 --> Controller Class Initialized
INFO - 2021-07-29 02:44:26 --> Config Class Initialized
INFO - 2021-07-29 02:44:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:26 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:26 --> URI Class Initialized
INFO - 2021-07-29 02:44:26 --> Router Class Initialized
INFO - 2021-07-29 02:44:26 --> Output Class Initialized
INFO - 2021-07-29 02:44:26 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:26 --> Input Class Initialized
INFO - 2021-07-29 02:44:26 --> Language Class Initialized
INFO - 2021-07-29 02:44:26 --> Language Class Initialized
INFO - 2021-07-29 02:44:26 --> Config Class Initialized
INFO - 2021-07-29 02:44:26 --> Loader Class Initialized
INFO - 2021-07-29 02:44:26 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:26 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:26 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:26 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:26 --> Controller Class Initialized
INFO - 2021-07-29 02:44:26 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:26 --> Total execution time: 0.0411
INFO - 2021-07-29 02:44:28 --> Config Class Initialized
INFO - 2021-07-29 02:44:28 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:28 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:28 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:28 --> URI Class Initialized
INFO - 2021-07-29 02:44:28 --> Router Class Initialized
INFO - 2021-07-29 02:44:28 --> Output Class Initialized
INFO - 2021-07-29 02:44:28 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:28 --> Input Class Initialized
INFO - 2021-07-29 02:44:28 --> Language Class Initialized
INFO - 2021-07-29 02:44:28 --> Language Class Initialized
INFO - 2021-07-29 02:44:28 --> Config Class Initialized
INFO - 2021-07-29 02:44:28 --> Loader Class Initialized
INFO - 2021-07-29 02:44:28 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:28 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:28 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:28 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:28 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:28 --> Controller Class Initialized
INFO - 2021-07-29 02:44:28 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:28 --> Total execution time: 0.0493
INFO - 2021-07-29 02:44:28 --> Config Class Initialized
INFO - 2021-07-29 02:44:28 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:44:28 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:44:28 --> Utf8 Class Initialized
INFO - 2021-07-29 02:44:28 --> URI Class Initialized
INFO - 2021-07-29 02:44:28 --> Router Class Initialized
INFO - 2021-07-29 02:44:28 --> Output Class Initialized
INFO - 2021-07-29 02:44:28 --> Security Class Initialized
DEBUG - 2021-07-29 02:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:44:28 --> Input Class Initialized
INFO - 2021-07-29 02:44:28 --> Language Class Initialized
INFO - 2021-07-29 02:44:28 --> Language Class Initialized
INFO - 2021-07-29 02:44:28 --> Config Class Initialized
INFO - 2021-07-29 02:44:28 --> Loader Class Initialized
INFO - 2021-07-29 02:44:28 --> Helper loaded: url_helper
INFO - 2021-07-29 02:44:28 --> Helper loaded: file_helper
INFO - 2021-07-29 02:44:28 --> Helper loaded: form_helper
INFO - 2021-07-29 02:44:28 --> Helper loaded: my_helper
INFO - 2021-07-29 02:44:28 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:44:28 --> Controller Class Initialized
DEBUG - 2021-07-29 02:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:44:28 --> Final output sent to browser
DEBUG - 2021-07-29 02:44:28 --> Total execution time: 0.0689
INFO - 2021-07-29 02:50:47 --> Config Class Initialized
INFO - 2021-07-29 02:50:47 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:50:47 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:50:47 --> Utf8 Class Initialized
INFO - 2021-07-29 02:50:47 --> URI Class Initialized
INFO - 2021-07-29 02:50:47 --> Router Class Initialized
INFO - 2021-07-29 02:50:47 --> Output Class Initialized
INFO - 2021-07-29 02:50:47 --> Security Class Initialized
DEBUG - 2021-07-29 02:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:50:47 --> Input Class Initialized
INFO - 2021-07-29 02:50:47 --> Language Class Initialized
INFO - 2021-07-29 02:50:47 --> Language Class Initialized
INFO - 2021-07-29 02:50:47 --> Config Class Initialized
INFO - 2021-07-29 02:50:47 --> Loader Class Initialized
INFO - 2021-07-29 02:50:47 --> Helper loaded: url_helper
INFO - 2021-07-29 02:50:47 --> Helper loaded: file_helper
INFO - 2021-07-29 02:50:47 --> Helper loaded: form_helper
INFO - 2021-07-29 02:50:47 --> Helper loaded: my_helper
INFO - 2021-07-29 02:50:47 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:50:47 --> Controller Class Initialized
INFO - 2021-07-29 02:50:47 --> Final output sent to browser
DEBUG - 2021-07-29 02:50:47 --> Total execution time: 0.0540
INFO - 2021-07-29 02:50:51 --> Config Class Initialized
INFO - 2021-07-29 02:50:51 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:50:51 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:50:51 --> Utf8 Class Initialized
INFO - 2021-07-29 02:50:51 --> URI Class Initialized
INFO - 2021-07-29 02:50:51 --> Router Class Initialized
INFO - 2021-07-29 02:50:51 --> Output Class Initialized
INFO - 2021-07-29 02:50:51 --> Security Class Initialized
DEBUG - 2021-07-29 02:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:50:51 --> Input Class Initialized
INFO - 2021-07-29 02:50:51 --> Language Class Initialized
INFO - 2021-07-29 02:50:51 --> Language Class Initialized
INFO - 2021-07-29 02:50:51 --> Config Class Initialized
INFO - 2021-07-29 02:50:51 --> Loader Class Initialized
INFO - 2021-07-29 02:50:51 --> Helper loaded: url_helper
INFO - 2021-07-29 02:50:51 --> Helper loaded: file_helper
INFO - 2021-07-29 02:50:51 --> Helper loaded: form_helper
INFO - 2021-07-29 02:50:51 --> Helper loaded: my_helper
INFO - 2021-07-29 02:50:51 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:50:51 --> Controller Class Initialized
INFO - 2021-07-29 02:50:51 --> Final output sent to browser
DEBUG - 2021-07-29 02:50:51 --> Total execution time: 0.0641
INFO - 2021-07-29 02:50:51 --> Config Class Initialized
INFO - 2021-07-29 02:50:51 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:50:51 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:50:51 --> Utf8 Class Initialized
INFO - 2021-07-29 02:50:51 --> URI Class Initialized
INFO - 2021-07-29 02:50:51 --> Router Class Initialized
INFO - 2021-07-29 02:50:51 --> Output Class Initialized
INFO - 2021-07-29 02:50:51 --> Security Class Initialized
DEBUG - 2021-07-29 02:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:50:51 --> Input Class Initialized
INFO - 2021-07-29 02:50:51 --> Language Class Initialized
INFO - 2021-07-29 02:50:51 --> Language Class Initialized
INFO - 2021-07-29 02:50:51 --> Config Class Initialized
INFO - 2021-07-29 02:50:51 --> Loader Class Initialized
INFO - 2021-07-29 02:50:51 --> Helper loaded: url_helper
INFO - 2021-07-29 02:50:51 --> Helper loaded: file_helper
INFO - 2021-07-29 02:50:51 --> Helper loaded: form_helper
INFO - 2021-07-29 02:50:51 --> Helper loaded: my_helper
INFO - 2021-07-29 02:50:51 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:50:51 --> Controller Class Initialized
INFO - 2021-07-29 02:50:54 --> Config Class Initialized
INFO - 2021-07-29 02:50:54 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:50:54 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:50:54 --> Utf8 Class Initialized
INFO - 2021-07-29 02:50:54 --> URI Class Initialized
INFO - 2021-07-29 02:50:54 --> Router Class Initialized
INFO - 2021-07-29 02:50:54 --> Output Class Initialized
INFO - 2021-07-29 02:50:54 --> Security Class Initialized
DEBUG - 2021-07-29 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:50:54 --> Input Class Initialized
INFO - 2021-07-29 02:50:54 --> Language Class Initialized
INFO - 2021-07-29 02:50:54 --> Language Class Initialized
INFO - 2021-07-29 02:50:54 --> Config Class Initialized
INFO - 2021-07-29 02:50:54 --> Loader Class Initialized
INFO - 2021-07-29 02:50:54 --> Helper loaded: url_helper
INFO - 2021-07-29 02:50:54 --> Helper loaded: file_helper
INFO - 2021-07-29 02:50:54 --> Helper loaded: form_helper
INFO - 2021-07-29 02:50:54 --> Helper loaded: my_helper
INFO - 2021-07-29 02:50:54 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:50:54 --> Controller Class Initialized
INFO - 2021-07-29 02:50:54 --> Final output sent to browser
DEBUG - 2021-07-29 02:50:54 --> Total execution time: 0.0639
INFO - 2021-07-29 02:50:56 --> Config Class Initialized
INFO - 2021-07-29 02:50:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:50:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:50:56 --> Utf8 Class Initialized
INFO - 2021-07-29 02:50:56 --> URI Class Initialized
INFO - 2021-07-29 02:50:56 --> Router Class Initialized
INFO - 2021-07-29 02:50:56 --> Output Class Initialized
INFO - 2021-07-29 02:50:56 --> Security Class Initialized
DEBUG - 2021-07-29 02:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:50:56 --> Input Class Initialized
INFO - 2021-07-29 02:50:56 --> Language Class Initialized
INFO - 2021-07-29 02:50:56 --> Language Class Initialized
INFO - 2021-07-29 02:50:56 --> Config Class Initialized
INFO - 2021-07-29 02:50:56 --> Loader Class Initialized
INFO - 2021-07-29 02:50:56 --> Helper loaded: url_helper
INFO - 2021-07-29 02:50:56 --> Helper loaded: file_helper
INFO - 2021-07-29 02:50:56 --> Helper loaded: form_helper
INFO - 2021-07-29 02:50:56 --> Helper loaded: my_helper
INFO - 2021-07-29 02:50:56 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:50:56 --> Controller Class Initialized
INFO - 2021-07-29 02:50:56 --> Final output sent to browser
DEBUG - 2021-07-29 02:50:56 --> Total execution time: 0.0608
INFO - 2021-07-29 02:50:56 --> Config Class Initialized
INFO - 2021-07-29 02:50:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:50:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:50:56 --> Utf8 Class Initialized
INFO - 2021-07-29 02:50:56 --> URI Class Initialized
INFO - 2021-07-29 02:50:56 --> Router Class Initialized
INFO - 2021-07-29 02:50:56 --> Output Class Initialized
INFO - 2021-07-29 02:50:56 --> Security Class Initialized
DEBUG - 2021-07-29 02:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:50:56 --> Input Class Initialized
INFO - 2021-07-29 02:50:56 --> Language Class Initialized
INFO - 2021-07-29 02:50:56 --> Language Class Initialized
INFO - 2021-07-29 02:50:56 --> Config Class Initialized
INFO - 2021-07-29 02:50:56 --> Loader Class Initialized
INFO - 2021-07-29 02:50:56 --> Helper loaded: url_helper
INFO - 2021-07-29 02:50:56 --> Helper loaded: file_helper
INFO - 2021-07-29 02:50:56 --> Helper loaded: form_helper
INFO - 2021-07-29 02:50:56 --> Helper loaded: my_helper
INFO - 2021-07-29 02:50:56 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:50:56 --> Controller Class Initialized
DEBUG - 2021-07-29 02:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:50:56 --> Final output sent to browser
DEBUG - 2021-07-29 02:50:56 --> Total execution time: 0.0685
INFO - 2021-07-29 02:50:58 --> Config Class Initialized
INFO - 2021-07-29 02:50:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:50:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:50:58 --> Utf8 Class Initialized
INFO - 2021-07-29 02:50:58 --> URI Class Initialized
INFO - 2021-07-29 02:50:58 --> Router Class Initialized
INFO - 2021-07-29 02:50:58 --> Output Class Initialized
INFO - 2021-07-29 02:50:58 --> Security Class Initialized
DEBUG - 2021-07-29 02:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:50:58 --> Input Class Initialized
INFO - 2021-07-29 02:50:58 --> Language Class Initialized
INFO - 2021-07-29 02:50:58 --> Language Class Initialized
INFO - 2021-07-29 02:50:58 --> Config Class Initialized
INFO - 2021-07-29 02:50:58 --> Loader Class Initialized
INFO - 2021-07-29 02:50:58 --> Helper loaded: url_helper
INFO - 2021-07-29 02:50:58 --> Helper loaded: file_helper
INFO - 2021-07-29 02:50:58 --> Helper loaded: form_helper
INFO - 2021-07-29 02:50:58 --> Helper loaded: my_helper
INFO - 2021-07-29 02:50:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:50:58 --> Controller Class Initialized
INFO - 2021-07-29 02:50:58 --> Final output sent to browser
DEBUG - 2021-07-29 02:50:58 --> Total execution time: 0.0606
INFO - 2021-07-29 02:51:01 --> Config Class Initialized
INFO - 2021-07-29 02:51:01 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:01 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:01 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:01 --> URI Class Initialized
INFO - 2021-07-29 02:51:01 --> Router Class Initialized
INFO - 2021-07-29 02:51:01 --> Output Class Initialized
INFO - 2021-07-29 02:51:01 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:01 --> Input Class Initialized
INFO - 2021-07-29 02:51:01 --> Language Class Initialized
INFO - 2021-07-29 02:51:01 --> Language Class Initialized
INFO - 2021-07-29 02:51:01 --> Config Class Initialized
INFO - 2021-07-29 02:51:01 --> Loader Class Initialized
INFO - 2021-07-29 02:51:01 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:01 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:01 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:01 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:01 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:01 --> Controller Class Initialized
INFO - 2021-07-29 02:51:01 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:01 --> Total execution time: 0.0430
INFO - 2021-07-29 02:51:01 --> Config Class Initialized
INFO - 2021-07-29 02:51:01 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:01 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:01 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:01 --> URI Class Initialized
INFO - 2021-07-29 02:51:01 --> Router Class Initialized
INFO - 2021-07-29 02:51:01 --> Output Class Initialized
INFO - 2021-07-29 02:51:01 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:01 --> Input Class Initialized
INFO - 2021-07-29 02:51:01 --> Language Class Initialized
INFO - 2021-07-29 02:51:01 --> Language Class Initialized
INFO - 2021-07-29 02:51:01 --> Config Class Initialized
INFO - 2021-07-29 02:51:01 --> Loader Class Initialized
INFO - 2021-07-29 02:51:01 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:01 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:01 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:01 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:01 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:01 --> Controller Class Initialized
INFO - 2021-07-29 02:51:02 --> Config Class Initialized
INFO - 2021-07-29 02:51:02 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:02 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:02 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:02 --> URI Class Initialized
INFO - 2021-07-29 02:51:02 --> Router Class Initialized
INFO - 2021-07-29 02:51:02 --> Output Class Initialized
INFO - 2021-07-29 02:51:02 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:02 --> Input Class Initialized
INFO - 2021-07-29 02:51:02 --> Language Class Initialized
INFO - 2021-07-29 02:51:02 --> Language Class Initialized
INFO - 2021-07-29 02:51:02 --> Config Class Initialized
INFO - 2021-07-29 02:51:02 --> Loader Class Initialized
INFO - 2021-07-29 02:51:02 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:02 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:02 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:02 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:02 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:02 --> Controller Class Initialized
INFO - 2021-07-29 02:51:02 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:02 --> Total execution time: 0.0600
INFO - 2021-07-29 02:51:05 --> Config Class Initialized
INFO - 2021-07-29 02:51:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:05 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:05 --> URI Class Initialized
INFO - 2021-07-29 02:51:05 --> Router Class Initialized
INFO - 2021-07-29 02:51:05 --> Output Class Initialized
INFO - 2021-07-29 02:51:05 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:05 --> Input Class Initialized
INFO - 2021-07-29 02:51:05 --> Language Class Initialized
INFO - 2021-07-29 02:51:05 --> Language Class Initialized
INFO - 2021-07-29 02:51:05 --> Config Class Initialized
INFO - 2021-07-29 02:51:05 --> Loader Class Initialized
INFO - 2021-07-29 02:51:05 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:05 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:05 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:05 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:05 --> Controller Class Initialized
INFO - 2021-07-29 02:51:05 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:05 --> Total execution time: 0.0441
INFO - 2021-07-29 02:51:05 --> Config Class Initialized
INFO - 2021-07-29 02:51:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:05 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:05 --> URI Class Initialized
INFO - 2021-07-29 02:51:05 --> Router Class Initialized
INFO - 2021-07-29 02:51:05 --> Output Class Initialized
INFO - 2021-07-29 02:51:05 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:05 --> Input Class Initialized
INFO - 2021-07-29 02:51:05 --> Language Class Initialized
INFO - 2021-07-29 02:51:05 --> Language Class Initialized
INFO - 2021-07-29 02:51:05 --> Config Class Initialized
INFO - 2021-07-29 02:51:05 --> Loader Class Initialized
INFO - 2021-07-29 02:51:05 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:05 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:05 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:05 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:05 --> Controller Class Initialized
DEBUG - 2021-07-29 02:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:51:05 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:05 --> Total execution time: 0.0459
INFO - 2021-07-29 02:51:08 --> Config Class Initialized
INFO - 2021-07-29 02:51:08 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:08 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:08 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:08 --> URI Class Initialized
INFO - 2021-07-29 02:51:08 --> Router Class Initialized
INFO - 2021-07-29 02:51:08 --> Output Class Initialized
INFO - 2021-07-29 02:51:08 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:08 --> Input Class Initialized
INFO - 2021-07-29 02:51:08 --> Language Class Initialized
INFO - 2021-07-29 02:51:08 --> Language Class Initialized
INFO - 2021-07-29 02:51:08 --> Config Class Initialized
INFO - 2021-07-29 02:51:08 --> Loader Class Initialized
INFO - 2021-07-29 02:51:08 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:08 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:08 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:08 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:08 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:08 --> Controller Class Initialized
INFO - 2021-07-29 02:51:08 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:08 --> Total execution time: 0.0666
INFO - 2021-07-29 02:51:10 --> Config Class Initialized
INFO - 2021-07-29 02:51:10 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:10 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:10 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:10 --> URI Class Initialized
INFO - 2021-07-29 02:51:10 --> Router Class Initialized
INFO - 2021-07-29 02:51:10 --> Output Class Initialized
INFO - 2021-07-29 02:51:10 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:10 --> Input Class Initialized
INFO - 2021-07-29 02:51:10 --> Language Class Initialized
INFO - 2021-07-29 02:51:10 --> Language Class Initialized
INFO - 2021-07-29 02:51:10 --> Config Class Initialized
INFO - 2021-07-29 02:51:10 --> Loader Class Initialized
INFO - 2021-07-29 02:51:10 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:10 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:10 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:10 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:10 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:10 --> Controller Class Initialized
INFO - 2021-07-29 02:51:10 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:10 --> Total execution time: 0.0684
INFO - 2021-07-29 02:51:10 --> Config Class Initialized
INFO - 2021-07-29 02:51:10 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:10 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:10 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:10 --> URI Class Initialized
INFO - 2021-07-29 02:51:10 --> Router Class Initialized
INFO - 2021-07-29 02:51:10 --> Output Class Initialized
INFO - 2021-07-29 02:51:10 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:10 --> Input Class Initialized
INFO - 2021-07-29 02:51:10 --> Language Class Initialized
INFO - 2021-07-29 02:51:10 --> Language Class Initialized
INFO - 2021-07-29 02:51:10 --> Config Class Initialized
INFO - 2021-07-29 02:51:10 --> Loader Class Initialized
INFO - 2021-07-29 02:51:10 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:10 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:10 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:10 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:10 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:10 --> Controller Class Initialized
INFO - 2021-07-29 02:51:12 --> Config Class Initialized
INFO - 2021-07-29 02:51:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:12 --> URI Class Initialized
INFO - 2021-07-29 02:51:12 --> Router Class Initialized
INFO - 2021-07-29 02:51:12 --> Output Class Initialized
INFO - 2021-07-29 02:51:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:12 --> Input Class Initialized
INFO - 2021-07-29 02:51:12 --> Language Class Initialized
INFO - 2021-07-29 02:51:12 --> Language Class Initialized
INFO - 2021-07-29 02:51:12 --> Config Class Initialized
INFO - 2021-07-29 02:51:12 --> Loader Class Initialized
INFO - 2021-07-29 02:51:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:12 --> Controller Class Initialized
INFO - 2021-07-29 02:51:12 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:12 --> Total execution time: 0.0627
INFO - 2021-07-29 02:51:17 --> Config Class Initialized
INFO - 2021-07-29 02:51:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:17 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:17 --> URI Class Initialized
INFO - 2021-07-29 02:51:17 --> Router Class Initialized
INFO - 2021-07-29 02:51:17 --> Output Class Initialized
INFO - 2021-07-29 02:51:17 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:17 --> Input Class Initialized
INFO - 2021-07-29 02:51:17 --> Language Class Initialized
INFO - 2021-07-29 02:51:17 --> Language Class Initialized
INFO - 2021-07-29 02:51:17 --> Config Class Initialized
INFO - 2021-07-29 02:51:17 --> Loader Class Initialized
INFO - 2021-07-29 02:51:17 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:17 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:17 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:17 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:17 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:17 --> Controller Class Initialized
INFO - 2021-07-29 02:51:17 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:17 --> Total execution time: 0.0426
INFO - 2021-07-29 02:51:17 --> Config Class Initialized
INFO - 2021-07-29 02:51:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:51:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:51:17 --> Utf8 Class Initialized
INFO - 2021-07-29 02:51:17 --> URI Class Initialized
INFO - 2021-07-29 02:51:17 --> Router Class Initialized
INFO - 2021-07-29 02:51:17 --> Output Class Initialized
INFO - 2021-07-29 02:51:17 --> Security Class Initialized
DEBUG - 2021-07-29 02:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:51:17 --> Input Class Initialized
INFO - 2021-07-29 02:51:17 --> Language Class Initialized
INFO - 2021-07-29 02:51:17 --> Language Class Initialized
INFO - 2021-07-29 02:51:17 --> Config Class Initialized
INFO - 2021-07-29 02:51:17 --> Loader Class Initialized
INFO - 2021-07-29 02:51:17 --> Helper loaded: url_helper
INFO - 2021-07-29 02:51:17 --> Helper loaded: file_helper
INFO - 2021-07-29 02:51:17 --> Helper loaded: form_helper
INFO - 2021-07-29 02:51:17 --> Helper loaded: my_helper
INFO - 2021-07-29 02:51:17 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:51:17 --> Controller Class Initialized
DEBUG - 2021-07-29 02:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:51:17 --> Final output sent to browser
DEBUG - 2021-07-29 02:51:17 --> Total execution time: 0.0450
INFO - 2021-07-29 02:52:19 --> Config Class Initialized
INFO - 2021-07-29 02:52:19 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:19 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:19 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:19 --> URI Class Initialized
INFO - 2021-07-29 02:52:19 --> Router Class Initialized
INFO - 2021-07-29 02:52:19 --> Output Class Initialized
INFO - 2021-07-29 02:52:19 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:19 --> Input Class Initialized
INFO - 2021-07-29 02:52:19 --> Language Class Initialized
INFO - 2021-07-29 02:52:19 --> Language Class Initialized
INFO - 2021-07-29 02:52:19 --> Config Class Initialized
INFO - 2021-07-29 02:52:19 --> Loader Class Initialized
INFO - 2021-07-29 02:52:19 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:19 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:19 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:19 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:19 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:19 --> Controller Class Initialized
INFO - 2021-07-29 02:52:19 --> Final output sent to browser
DEBUG - 2021-07-29 02:52:19 --> Total execution time: 0.0419
INFO - 2021-07-29 02:52:23 --> Config Class Initialized
INFO - 2021-07-29 02:52:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:23 --> URI Class Initialized
INFO - 2021-07-29 02:52:23 --> Router Class Initialized
INFO - 2021-07-29 02:52:23 --> Output Class Initialized
INFO - 2021-07-29 02:52:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:23 --> Input Class Initialized
INFO - 2021-07-29 02:52:23 --> Language Class Initialized
INFO - 2021-07-29 02:52:23 --> Language Class Initialized
INFO - 2021-07-29 02:52:23 --> Config Class Initialized
INFO - 2021-07-29 02:52:23 --> Loader Class Initialized
INFO - 2021-07-29 02:52:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:23 --> Controller Class Initialized
INFO - 2021-07-29 02:52:23 --> Final output sent to browser
DEBUG - 2021-07-29 02:52:23 --> Total execution time: 0.0650
INFO - 2021-07-29 02:52:23 --> Config Class Initialized
INFO - 2021-07-29 02:52:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:23 --> URI Class Initialized
INFO - 2021-07-29 02:52:23 --> Router Class Initialized
INFO - 2021-07-29 02:52:23 --> Output Class Initialized
INFO - 2021-07-29 02:52:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:23 --> Input Class Initialized
INFO - 2021-07-29 02:52:23 --> Language Class Initialized
INFO - 2021-07-29 02:52:23 --> Language Class Initialized
INFO - 2021-07-29 02:52:23 --> Config Class Initialized
INFO - 2021-07-29 02:52:23 --> Loader Class Initialized
INFO - 2021-07-29 02:52:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:23 --> Controller Class Initialized
INFO - 2021-07-29 02:52:25 --> Config Class Initialized
INFO - 2021-07-29 02:52:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:25 --> URI Class Initialized
INFO - 2021-07-29 02:52:25 --> Router Class Initialized
INFO - 2021-07-29 02:52:25 --> Output Class Initialized
INFO - 2021-07-29 02:52:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:25 --> Input Class Initialized
INFO - 2021-07-29 02:52:25 --> Language Class Initialized
INFO - 2021-07-29 02:52:25 --> Language Class Initialized
INFO - 2021-07-29 02:52:25 --> Config Class Initialized
INFO - 2021-07-29 02:52:25 --> Loader Class Initialized
INFO - 2021-07-29 02:52:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:25 --> Controller Class Initialized
INFO - 2021-07-29 02:52:25 --> Final output sent to browser
DEBUG - 2021-07-29 02:52:25 --> Total execution time: 0.0413
INFO - 2021-07-29 02:52:27 --> Config Class Initialized
INFO - 2021-07-29 02:52:27 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:27 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:27 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:27 --> URI Class Initialized
INFO - 2021-07-29 02:52:27 --> Router Class Initialized
INFO - 2021-07-29 02:52:27 --> Output Class Initialized
INFO - 2021-07-29 02:52:27 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:27 --> Input Class Initialized
INFO - 2021-07-29 02:52:27 --> Language Class Initialized
INFO - 2021-07-29 02:52:27 --> Language Class Initialized
INFO - 2021-07-29 02:52:27 --> Config Class Initialized
INFO - 2021-07-29 02:52:27 --> Loader Class Initialized
INFO - 2021-07-29 02:52:27 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:27 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:27 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:27 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:27 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:27 --> Controller Class Initialized
INFO - 2021-07-29 02:52:27 --> Final output sent to browser
DEBUG - 2021-07-29 02:52:27 --> Total execution time: 0.0623
INFO - 2021-07-29 02:52:27 --> Config Class Initialized
INFO - 2021-07-29 02:52:27 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:27 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:27 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:27 --> URI Class Initialized
INFO - 2021-07-29 02:52:27 --> Router Class Initialized
INFO - 2021-07-29 02:52:27 --> Output Class Initialized
INFO - 2021-07-29 02:52:27 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:27 --> Input Class Initialized
INFO - 2021-07-29 02:52:27 --> Language Class Initialized
INFO - 2021-07-29 02:52:27 --> Language Class Initialized
INFO - 2021-07-29 02:52:27 --> Config Class Initialized
INFO - 2021-07-29 02:52:27 --> Loader Class Initialized
INFO - 2021-07-29 02:52:27 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:27 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:27 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:27 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:27 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:27 --> Controller Class Initialized
DEBUG - 2021-07-29 02:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:52:27 --> Final output sent to browser
DEBUG - 2021-07-29 02:52:27 --> Total execution time: 0.0453
INFO - 2021-07-29 02:52:29 --> Config Class Initialized
INFO - 2021-07-29 02:52:29 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:29 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:29 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:29 --> URI Class Initialized
INFO - 2021-07-29 02:52:29 --> Router Class Initialized
INFO - 2021-07-29 02:52:29 --> Output Class Initialized
INFO - 2021-07-29 02:52:29 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:29 --> Input Class Initialized
INFO - 2021-07-29 02:52:29 --> Language Class Initialized
INFO - 2021-07-29 02:52:29 --> Language Class Initialized
INFO - 2021-07-29 02:52:29 --> Config Class Initialized
INFO - 2021-07-29 02:52:29 --> Loader Class Initialized
INFO - 2021-07-29 02:52:29 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:29 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:29 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:29 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:29 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:29 --> Controller Class Initialized
INFO - 2021-07-29 02:52:29 --> Final output sent to browser
DEBUG - 2021-07-29 02:52:29 --> Total execution time: 0.0556
INFO - 2021-07-29 02:52:31 --> Config Class Initialized
INFO - 2021-07-29 02:52:31 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:31 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:31 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:31 --> URI Class Initialized
INFO - 2021-07-29 02:52:31 --> Router Class Initialized
INFO - 2021-07-29 02:52:31 --> Output Class Initialized
INFO - 2021-07-29 02:52:31 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:31 --> Input Class Initialized
INFO - 2021-07-29 02:52:31 --> Language Class Initialized
INFO - 2021-07-29 02:52:31 --> Language Class Initialized
INFO - 2021-07-29 02:52:31 --> Config Class Initialized
INFO - 2021-07-29 02:52:31 --> Loader Class Initialized
INFO - 2021-07-29 02:52:31 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:31 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:31 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:31 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:31 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:31 --> Controller Class Initialized
INFO - 2021-07-29 02:52:31 --> Final output sent to browser
DEBUG - 2021-07-29 02:52:31 --> Total execution time: 0.0543
INFO - 2021-07-29 02:52:31 --> Config Class Initialized
INFO - 2021-07-29 02:52:31 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:52:31 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:52:31 --> Utf8 Class Initialized
INFO - 2021-07-29 02:52:31 --> URI Class Initialized
INFO - 2021-07-29 02:52:31 --> Router Class Initialized
INFO - 2021-07-29 02:52:31 --> Output Class Initialized
INFO - 2021-07-29 02:52:31 --> Security Class Initialized
DEBUG - 2021-07-29 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:52:31 --> Input Class Initialized
INFO - 2021-07-29 02:52:31 --> Language Class Initialized
INFO - 2021-07-29 02:52:31 --> Language Class Initialized
INFO - 2021-07-29 02:52:31 --> Config Class Initialized
INFO - 2021-07-29 02:52:31 --> Loader Class Initialized
INFO - 2021-07-29 02:52:31 --> Helper loaded: url_helper
INFO - 2021-07-29 02:52:31 --> Helper loaded: file_helper
INFO - 2021-07-29 02:52:31 --> Helper loaded: form_helper
INFO - 2021-07-29 02:52:31 --> Helper loaded: my_helper
INFO - 2021-07-29 02:52:31 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:52:31 --> Controller Class Initialized
INFO - 2021-07-29 02:53:54 --> Config Class Initialized
INFO - 2021-07-29 02:53:54 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:53:54 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:53:54 --> Utf8 Class Initialized
INFO - 2021-07-29 02:53:54 --> URI Class Initialized
INFO - 2021-07-29 02:53:54 --> Router Class Initialized
INFO - 2021-07-29 02:53:54 --> Output Class Initialized
INFO - 2021-07-29 02:53:54 --> Security Class Initialized
DEBUG - 2021-07-29 02:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:53:54 --> Input Class Initialized
INFO - 2021-07-29 02:53:54 --> Language Class Initialized
INFO - 2021-07-29 02:53:54 --> Language Class Initialized
INFO - 2021-07-29 02:53:54 --> Config Class Initialized
INFO - 2021-07-29 02:53:54 --> Loader Class Initialized
INFO - 2021-07-29 02:53:54 --> Helper loaded: url_helper
INFO - 2021-07-29 02:53:54 --> Helper loaded: file_helper
INFO - 2021-07-29 02:53:54 --> Helper loaded: form_helper
INFO - 2021-07-29 02:53:54 --> Helper loaded: my_helper
INFO - 2021-07-29 02:53:54 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:53:54 --> Controller Class Initialized
INFO - 2021-07-29 02:53:54 --> Final output sent to browser
DEBUG - 2021-07-29 02:53:54 --> Total execution time: 0.0604
INFO - 2021-07-29 02:53:57 --> Config Class Initialized
INFO - 2021-07-29 02:53:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:53:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:53:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:53:57 --> URI Class Initialized
INFO - 2021-07-29 02:53:57 --> Router Class Initialized
INFO - 2021-07-29 02:53:57 --> Output Class Initialized
INFO - 2021-07-29 02:53:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:53:57 --> Input Class Initialized
INFO - 2021-07-29 02:53:57 --> Language Class Initialized
INFO - 2021-07-29 02:53:57 --> Language Class Initialized
INFO - 2021-07-29 02:53:57 --> Config Class Initialized
INFO - 2021-07-29 02:53:57 --> Loader Class Initialized
INFO - 2021-07-29 02:53:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:53:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:53:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:53:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:53:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:53:57 --> Controller Class Initialized
INFO - 2021-07-29 02:53:57 --> Final output sent to browser
DEBUG - 2021-07-29 02:53:57 --> Total execution time: 0.0441
INFO - 2021-07-29 02:53:57 --> Config Class Initialized
INFO - 2021-07-29 02:53:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:53:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:53:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:53:57 --> URI Class Initialized
INFO - 2021-07-29 02:53:57 --> Router Class Initialized
INFO - 2021-07-29 02:53:57 --> Output Class Initialized
INFO - 2021-07-29 02:53:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:53:57 --> Input Class Initialized
INFO - 2021-07-29 02:53:57 --> Language Class Initialized
INFO - 2021-07-29 02:53:57 --> Language Class Initialized
INFO - 2021-07-29 02:53:57 --> Config Class Initialized
INFO - 2021-07-29 02:53:57 --> Loader Class Initialized
INFO - 2021-07-29 02:53:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:53:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:53:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:53:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:53:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:53:57 --> Controller Class Initialized
DEBUG - 2021-07-29 02:53:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:53:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:53:57 --> Final output sent to browser
DEBUG - 2021-07-29 02:53:57 --> Total execution time: 0.0551
INFO - 2021-07-29 02:54:00 --> Config Class Initialized
INFO - 2021-07-29 02:54:00 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:00 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:00 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:00 --> URI Class Initialized
INFO - 2021-07-29 02:54:00 --> Router Class Initialized
INFO - 2021-07-29 02:54:00 --> Output Class Initialized
INFO - 2021-07-29 02:54:00 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:00 --> Input Class Initialized
INFO - 2021-07-29 02:54:00 --> Language Class Initialized
INFO - 2021-07-29 02:54:00 --> Language Class Initialized
INFO - 2021-07-29 02:54:00 --> Config Class Initialized
INFO - 2021-07-29 02:54:00 --> Loader Class Initialized
INFO - 2021-07-29 02:54:00 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:00 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:00 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:00 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:00 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:00 --> Controller Class Initialized
INFO - 2021-07-29 02:54:00 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:00 --> Total execution time: 0.0614
INFO - 2021-07-29 02:54:03 --> Config Class Initialized
INFO - 2021-07-29 02:54:03 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:03 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:03 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:03 --> URI Class Initialized
INFO - 2021-07-29 02:54:03 --> Router Class Initialized
INFO - 2021-07-29 02:54:03 --> Output Class Initialized
INFO - 2021-07-29 02:54:03 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:03 --> Input Class Initialized
INFO - 2021-07-29 02:54:03 --> Language Class Initialized
INFO - 2021-07-29 02:54:03 --> Language Class Initialized
INFO - 2021-07-29 02:54:03 --> Config Class Initialized
INFO - 2021-07-29 02:54:03 --> Loader Class Initialized
INFO - 2021-07-29 02:54:03 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:03 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:03 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:03 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:03 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:03 --> Controller Class Initialized
INFO - 2021-07-29 02:54:03 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:03 --> Total execution time: 0.0659
INFO - 2021-07-29 02:54:03 --> Config Class Initialized
INFO - 2021-07-29 02:54:03 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:03 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:03 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:03 --> URI Class Initialized
INFO - 2021-07-29 02:54:03 --> Router Class Initialized
INFO - 2021-07-29 02:54:03 --> Output Class Initialized
INFO - 2021-07-29 02:54:03 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:03 --> Input Class Initialized
INFO - 2021-07-29 02:54:03 --> Language Class Initialized
INFO - 2021-07-29 02:54:03 --> Language Class Initialized
INFO - 2021-07-29 02:54:03 --> Config Class Initialized
INFO - 2021-07-29 02:54:03 --> Loader Class Initialized
INFO - 2021-07-29 02:54:03 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:03 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:03 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:03 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:03 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:03 --> Controller Class Initialized
INFO - 2021-07-29 02:54:05 --> Config Class Initialized
INFO - 2021-07-29 02:54:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:05 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:05 --> URI Class Initialized
INFO - 2021-07-29 02:54:05 --> Router Class Initialized
INFO - 2021-07-29 02:54:05 --> Output Class Initialized
INFO - 2021-07-29 02:54:05 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:05 --> Input Class Initialized
INFO - 2021-07-29 02:54:05 --> Language Class Initialized
INFO - 2021-07-29 02:54:05 --> Language Class Initialized
INFO - 2021-07-29 02:54:05 --> Config Class Initialized
INFO - 2021-07-29 02:54:05 --> Loader Class Initialized
INFO - 2021-07-29 02:54:05 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:05 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:05 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:05 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:05 --> Controller Class Initialized
INFO - 2021-07-29 02:54:05 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:05 --> Total execution time: 0.0527
INFO - 2021-07-29 02:54:07 --> Config Class Initialized
INFO - 2021-07-29 02:54:07 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:07 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:07 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:07 --> URI Class Initialized
INFO - 2021-07-29 02:54:07 --> Router Class Initialized
INFO - 2021-07-29 02:54:07 --> Output Class Initialized
INFO - 2021-07-29 02:54:07 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:07 --> Input Class Initialized
INFO - 2021-07-29 02:54:07 --> Language Class Initialized
INFO - 2021-07-29 02:54:07 --> Language Class Initialized
INFO - 2021-07-29 02:54:07 --> Config Class Initialized
INFO - 2021-07-29 02:54:07 --> Loader Class Initialized
INFO - 2021-07-29 02:54:07 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:07 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:07 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:07 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:07 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:07 --> Controller Class Initialized
INFO - 2021-07-29 02:54:07 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:07 --> Total execution time: 0.0678
INFO - 2021-07-29 02:54:07 --> Config Class Initialized
INFO - 2021-07-29 02:54:07 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:07 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:07 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:07 --> URI Class Initialized
INFO - 2021-07-29 02:54:07 --> Router Class Initialized
INFO - 2021-07-29 02:54:07 --> Output Class Initialized
INFO - 2021-07-29 02:54:07 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:07 --> Input Class Initialized
INFO - 2021-07-29 02:54:07 --> Language Class Initialized
INFO - 2021-07-29 02:54:07 --> Language Class Initialized
INFO - 2021-07-29 02:54:07 --> Config Class Initialized
INFO - 2021-07-29 02:54:07 --> Loader Class Initialized
INFO - 2021-07-29 02:54:07 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:07 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:07 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:07 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:07 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:07 --> Controller Class Initialized
DEBUG - 2021-07-29 02:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:54:07 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:07 --> Total execution time: 0.0594
INFO - 2021-07-29 02:54:09 --> Config Class Initialized
INFO - 2021-07-29 02:54:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:09 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:09 --> URI Class Initialized
INFO - 2021-07-29 02:54:09 --> Router Class Initialized
INFO - 2021-07-29 02:54:09 --> Output Class Initialized
INFO - 2021-07-29 02:54:09 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:09 --> Input Class Initialized
INFO - 2021-07-29 02:54:09 --> Language Class Initialized
INFO - 2021-07-29 02:54:09 --> Language Class Initialized
INFO - 2021-07-29 02:54:09 --> Config Class Initialized
INFO - 2021-07-29 02:54:09 --> Loader Class Initialized
INFO - 2021-07-29 02:54:09 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:09 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:09 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:09 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:09 --> Controller Class Initialized
INFO - 2021-07-29 02:54:09 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:09 --> Total execution time: 0.0593
INFO - 2021-07-29 02:54:11 --> Config Class Initialized
INFO - 2021-07-29 02:54:11 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:11 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:11 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:11 --> URI Class Initialized
INFO - 2021-07-29 02:54:11 --> Router Class Initialized
INFO - 2021-07-29 02:54:11 --> Output Class Initialized
INFO - 2021-07-29 02:54:11 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:11 --> Input Class Initialized
INFO - 2021-07-29 02:54:11 --> Language Class Initialized
INFO - 2021-07-29 02:54:11 --> Language Class Initialized
INFO - 2021-07-29 02:54:11 --> Config Class Initialized
INFO - 2021-07-29 02:54:11 --> Loader Class Initialized
INFO - 2021-07-29 02:54:11 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:11 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:11 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:11 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:11 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:11 --> Controller Class Initialized
INFO - 2021-07-29 02:54:11 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:11 --> Total execution time: 0.0636
INFO - 2021-07-29 02:54:11 --> Config Class Initialized
INFO - 2021-07-29 02:54:11 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:11 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:11 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:11 --> URI Class Initialized
INFO - 2021-07-29 02:54:11 --> Router Class Initialized
INFO - 2021-07-29 02:54:11 --> Output Class Initialized
INFO - 2021-07-29 02:54:11 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:11 --> Input Class Initialized
INFO - 2021-07-29 02:54:11 --> Language Class Initialized
INFO - 2021-07-29 02:54:11 --> Language Class Initialized
INFO - 2021-07-29 02:54:11 --> Config Class Initialized
INFO - 2021-07-29 02:54:11 --> Loader Class Initialized
INFO - 2021-07-29 02:54:11 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:11 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:11 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:11 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:11 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:11 --> Controller Class Initialized
INFO - 2021-07-29 02:54:13 --> Config Class Initialized
INFO - 2021-07-29 02:54:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:13 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:13 --> URI Class Initialized
INFO - 2021-07-29 02:54:13 --> Router Class Initialized
INFO - 2021-07-29 02:54:13 --> Output Class Initialized
INFO - 2021-07-29 02:54:13 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:13 --> Input Class Initialized
INFO - 2021-07-29 02:54:13 --> Language Class Initialized
INFO - 2021-07-29 02:54:13 --> Language Class Initialized
INFO - 2021-07-29 02:54:13 --> Config Class Initialized
INFO - 2021-07-29 02:54:13 --> Loader Class Initialized
INFO - 2021-07-29 02:54:13 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:13 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:13 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:13 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:13 --> Controller Class Initialized
INFO - 2021-07-29 02:54:13 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:13 --> Total execution time: 0.0553
INFO - 2021-07-29 02:54:16 --> Config Class Initialized
INFO - 2021-07-29 02:54:16 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:16 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:16 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:16 --> URI Class Initialized
INFO - 2021-07-29 02:54:16 --> Router Class Initialized
INFO - 2021-07-29 02:54:16 --> Output Class Initialized
INFO - 2021-07-29 02:54:16 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:16 --> Input Class Initialized
INFO - 2021-07-29 02:54:16 --> Language Class Initialized
INFO - 2021-07-29 02:54:16 --> Language Class Initialized
INFO - 2021-07-29 02:54:16 --> Config Class Initialized
INFO - 2021-07-29 02:54:16 --> Loader Class Initialized
INFO - 2021-07-29 02:54:16 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:16 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:16 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:16 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:16 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:16 --> Controller Class Initialized
INFO - 2021-07-29 02:54:16 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:16 --> Total execution time: 0.0434
INFO - 2021-07-29 02:54:16 --> Config Class Initialized
INFO - 2021-07-29 02:54:16 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:16 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:16 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:16 --> URI Class Initialized
INFO - 2021-07-29 02:54:16 --> Router Class Initialized
INFO - 2021-07-29 02:54:16 --> Output Class Initialized
INFO - 2021-07-29 02:54:16 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:16 --> Input Class Initialized
INFO - 2021-07-29 02:54:16 --> Language Class Initialized
INFO - 2021-07-29 02:54:16 --> Language Class Initialized
INFO - 2021-07-29 02:54:16 --> Config Class Initialized
INFO - 2021-07-29 02:54:16 --> Loader Class Initialized
INFO - 2021-07-29 02:54:16 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:16 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:16 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:16 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:16 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:16 --> Controller Class Initialized
DEBUG - 2021-07-29 02:54:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:54:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:54:16 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:16 --> Total execution time: 0.0587
INFO - 2021-07-29 02:54:18 --> Config Class Initialized
INFO - 2021-07-29 02:54:18 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:18 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:18 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:18 --> URI Class Initialized
INFO - 2021-07-29 02:54:18 --> Router Class Initialized
INFO - 2021-07-29 02:54:18 --> Output Class Initialized
INFO - 2021-07-29 02:54:18 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:18 --> Input Class Initialized
INFO - 2021-07-29 02:54:18 --> Language Class Initialized
INFO - 2021-07-29 02:54:18 --> Language Class Initialized
INFO - 2021-07-29 02:54:18 --> Config Class Initialized
INFO - 2021-07-29 02:54:18 --> Loader Class Initialized
INFO - 2021-07-29 02:54:18 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:18 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:18 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:18 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:18 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:18 --> Controller Class Initialized
INFO - 2021-07-29 02:54:18 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:18 --> Total execution time: 0.0530
INFO - 2021-07-29 02:54:21 --> Config Class Initialized
INFO - 2021-07-29 02:54:21 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:21 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:21 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:21 --> URI Class Initialized
INFO - 2021-07-29 02:54:21 --> Router Class Initialized
INFO - 2021-07-29 02:54:21 --> Output Class Initialized
INFO - 2021-07-29 02:54:21 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:21 --> Input Class Initialized
INFO - 2021-07-29 02:54:21 --> Language Class Initialized
INFO - 2021-07-29 02:54:21 --> Language Class Initialized
INFO - 2021-07-29 02:54:21 --> Config Class Initialized
INFO - 2021-07-29 02:54:21 --> Loader Class Initialized
INFO - 2021-07-29 02:54:21 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:21 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:21 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:21 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:21 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:21 --> Controller Class Initialized
INFO - 2021-07-29 02:54:21 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:21 --> Total execution time: 0.0432
INFO - 2021-07-29 02:54:21 --> Config Class Initialized
INFO - 2021-07-29 02:54:21 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:21 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:21 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:21 --> URI Class Initialized
INFO - 2021-07-29 02:54:21 --> Router Class Initialized
INFO - 2021-07-29 02:54:21 --> Output Class Initialized
INFO - 2021-07-29 02:54:21 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:21 --> Input Class Initialized
INFO - 2021-07-29 02:54:21 --> Language Class Initialized
INFO - 2021-07-29 02:54:21 --> Language Class Initialized
INFO - 2021-07-29 02:54:21 --> Config Class Initialized
INFO - 2021-07-29 02:54:21 --> Loader Class Initialized
INFO - 2021-07-29 02:54:21 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:21 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:21 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:21 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:21 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:21 --> Controller Class Initialized
INFO - 2021-07-29 02:54:23 --> Config Class Initialized
INFO - 2021-07-29 02:54:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:23 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:23 --> URI Class Initialized
INFO - 2021-07-29 02:54:23 --> Router Class Initialized
INFO - 2021-07-29 02:54:23 --> Output Class Initialized
INFO - 2021-07-29 02:54:23 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:23 --> Input Class Initialized
INFO - 2021-07-29 02:54:23 --> Language Class Initialized
INFO - 2021-07-29 02:54:23 --> Language Class Initialized
INFO - 2021-07-29 02:54:23 --> Config Class Initialized
INFO - 2021-07-29 02:54:23 --> Loader Class Initialized
INFO - 2021-07-29 02:54:23 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:23 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:23 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:23 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:23 --> Controller Class Initialized
INFO - 2021-07-29 02:54:23 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:23 --> Total execution time: 0.0561
INFO - 2021-07-29 02:54:25 --> Config Class Initialized
INFO - 2021-07-29 02:54:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:25 --> URI Class Initialized
INFO - 2021-07-29 02:54:25 --> Router Class Initialized
INFO - 2021-07-29 02:54:25 --> Output Class Initialized
INFO - 2021-07-29 02:54:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:25 --> Input Class Initialized
INFO - 2021-07-29 02:54:25 --> Language Class Initialized
INFO - 2021-07-29 02:54:25 --> Language Class Initialized
INFO - 2021-07-29 02:54:25 --> Config Class Initialized
INFO - 2021-07-29 02:54:25 --> Loader Class Initialized
INFO - 2021-07-29 02:54:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:25 --> Controller Class Initialized
INFO - 2021-07-29 02:54:25 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:25 --> Total execution time: 0.0431
INFO - 2021-07-29 02:54:25 --> Config Class Initialized
INFO - 2021-07-29 02:54:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:25 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:25 --> URI Class Initialized
INFO - 2021-07-29 02:54:25 --> Router Class Initialized
INFO - 2021-07-29 02:54:25 --> Output Class Initialized
INFO - 2021-07-29 02:54:25 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:25 --> Input Class Initialized
INFO - 2021-07-29 02:54:25 --> Language Class Initialized
INFO - 2021-07-29 02:54:25 --> Language Class Initialized
INFO - 2021-07-29 02:54:25 --> Config Class Initialized
INFO - 2021-07-29 02:54:25 --> Loader Class Initialized
INFO - 2021-07-29 02:54:25 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:25 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:25 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:25 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:25 --> Controller Class Initialized
DEBUG - 2021-07-29 02:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:54:25 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:25 --> Total execution time: 0.0467
INFO - 2021-07-29 02:54:28 --> Config Class Initialized
INFO - 2021-07-29 02:54:28 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:28 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:28 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:28 --> URI Class Initialized
INFO - 2021-07-29 02:54:28 --> Router Class Initialized
INFO - 2021-07-29 02:54:28 --> Output Class Initialized
INFO - 2021-07-29 02:54:28 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:28 --> Input Class Initialized
INFO - 2021-07-29 02:54:28 --> Language Class Initialized
INFO - 2021-07-29 02:54:28 --> Language Class Initialized
INFO - 2021-07-29 02:54:28 --> Config Class Initialized
INFO - 2021-07-29 02:54:28 --> Loader Class Initialized
INFO - 2021-07-29 02:54:28 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:28 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:28 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:28 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:28 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:28 --> Controller Class Initialized
INFO - 2021-07-29 02:54:28 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:28 --> Total execution time: 0.0677
INFO - 2021-07-29 02:54:30 --> Config Class Initialized
INFO - 2021-07-29 02:54:30 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:30 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:30 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:30 --> URI Class Initialized
INFO - 2021-07-29 02:54:30 --> Router Class Initialized
INFO - 2021-07-29 02:54:30 --> Output Class Initialized
INFO - 2021-07-29 02:54:30 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:30 --> Input Class Initialized
INFO - 2021-07-29 02:54:30 --> Language Class Initialized
INFO - 2021-07-29 02:54:30 --> Language Class Initialized
INFO - 2021-07-29 02:54:30 --> Config Class Initialized
INFO - 2021-07-29 02:54:30 --> Loader Class Initialized
INFO - 2021-07-29 02:54:30 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:30 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:30 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:30 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:30 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:30 --> Controller Class Initialized
INFO - 2021-07-29 02:54:30 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:30 --> Total execution time: 0.0439
INFO - 2021-07-29 02:54:30 --> Config Class Initialized
INFO - 2021-07-29 02:54:30 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:30 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:30 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:30 --> URI Class Initialized
INFO - 2021-07-29 02:54:30 --> Router Class Initialized
INFO - 2021-07-29 02:54:30 --> Output Class Initialized
INFO - 2021-07-29 02:54:30 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:30 --> Input Class Initialized
INFO - 2021-07-29 02:54:30 --> Language Class Initialized
INFO - 2021-07-29 02:54:30 --> Language Class Initialized
INFO - 2021-07-29 02:54:30 --> Config Class Initialized
INFO - 2021-07-29 02:54:30 --> Loader Class Initialized
INFO - 2021-07-29 02:54:30 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:30 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:30 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:30 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:30 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:30 --> Controller Class Initialized
INFO - 2021-07-29 02:54:32 --> Config Class Initialized
INFO - 2021-07-29 02:54:32 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:32 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:32 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:32 --> URI Class Initialized
INFO - 2021-07-29 02:54:32 --> Router Class Initialized
INFO - 2021-07-29 02:54:32 --> Output Class Initialized
INFO - 2021-07-29 02:54:32 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:32 --> Input Class Initialized
INFO - 2021-07-29 02:54:32 --> Language Class Initialized
INFO - 2021-07-29 02:54:32 --> Language Class Initialized
INFO - 2021-07-29 02:54:32 --> Config Class Initialized
INFO - 2021-07-29 02:54:32 --> Loader Class Initialized
INFO - 2021-07-29 02:54:32 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:32 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:32 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:32 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:32 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:32 --> Controller Class Initialized
INFO - 2021-07-29 02:54:32 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:32 --> Total execution time: 0.0599
INFO - 2021-07-29 02:54:36 --> Config Class Initialized
INFO - 2021-07-29 02:54:36 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:36 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:36 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:36 --> URI Class Initialized
INFO - 2021-07-29 02:54:36 --> Router Class Initialized
INFO - 2021-07-29 02:54:36 --> Output Class Initialized
INFO - 2021-07-29 02:54:36 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:36 --> Input Class Initialized
INFO - 2021-07-29 02:54:36 --> Language Class Initialized
INFO - 2021-07-29 02:54:36 --> Language Class Initialized
INFO - 2021-07-29 02:54:36 --> Config Class Initialized
INFO - 2021-07-29 02:54:36 --> Loader Class Initialized
INFO - 2021-07-29 02:54:36 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:36 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:36 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:36 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:36 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:36 --> Controller Class Initialized
INFO - 2021-07-29 02:54:36 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:36 --> Total execution time: 0.0601
INFO - 2021-07-29 02:54:36 --> Config Class Initialized
INFO - 2021-07-29 02:54:36 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:36 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:36 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:36 --> URI Class Initialized
INFO - 2021-07-29 02:54:36 --> Router Class Initialized
INFO - 2021-07-29 02:54:36 --> Output Class Initialized
INFO - 2021-07-29 02:54:36 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:36 --> Input Class Initialized
INFO - 2021-07-29 02:54:36 --> Language Class Initialized
INFO - 2021-07-29 02:54:36 --> Language Class Initialized
INFO - 2021-07-29 02:54:36 --> Config Class Initialized
INFO - 2021-07-29 02:54:36 --> Loader Class Initialized
INFO - 2021-07-29 02:54:36 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:36 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:36 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:36 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:36 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:36 --> Controller Class Initialized
DEBUG - 2021-07-29 02:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 02:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 02:54:36 --> Final output sent to browser
DEBUG - 2021-07-29 02:54:36 --> Total execution time: 0.0591
INFO - 2021-07-29 02:54:41 --> Config Class Initialized
INFO - 2021-07-29 02:54:41 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:41 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:41 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:41 --> URI Class Initialized
INFO - 2021-07-29 02:54:41 --> Router Class Initialized
INFO - 2021-07-29 02:54:41 --> Output Class Initialized
INFO - 2021-07-29 02:54:41 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:41 --> Input Class Initialized
INFO - 2021-07-29 02:54:41 --> Language Class Initialized
INFO - 2021-07-29 02:54:41 --> Language Class Initialized
INFO - 2021-07-29 02:54:41 --> Config Class Initialized
INFO - 2021-07-29 02:54:41 --> Loader Class Initialized
INFO - 2021-07-29 02:54:41 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:41 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:41 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:41 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:41 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:41 --> Controller Class Initialized
INFO - 2021-07-29 02:54:43 --> Config Class Initialized
INFO - 2021-07-29 02:54:43 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:43 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:43 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:43 --> URI Class Initialized
INFO - 2021-07-29 02:54:43 --> Router Class Initialized
INFO - 2021-07-29 02:54:43 --> Output Class Initialized
INFO - 2021-07-29 02:54:43 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:43 --> Input Class Initialized
INFO - 2021-07-29 02:54:43 --> Language Class Initialized
INFO - 2021-07-29 02:54:43 --> Language Class Initialized
INFO - 2021-07-29 02:54:43 --> Config Class Initialized
INFO - 2021-07-29 02:54:43 --> Loader Class Initialized
INFO - 2021-07-29 02:54:43 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:43 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:43 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:43 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:43 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:43 --> Controller Class Initialized
INFO - 2021-07-29 02:54:45 --> Config Class Initialized
INFO - 2021-07-29 02:54:45 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:45 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:45 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:45 --> URI Class Initialized
INFO - 2021-07-29 02:54:45 --> Router Class Initialized
INFO - 2021-07-29 02:54:45 --> Output Class Initialized
INFO - 2021-07-29 02:54:45 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:45 --> Input Class Initialized
INFO - 2021-07-29 02:54:45 --> Language Class Initialized
INFO - 2021-07-29 02:54:45 --> Language Class Initialized
INFO - 2021-07-29 02:54:45 --> Config Class Initialized
INFO - 2021-07-29 02:54:45 --> Loader Class Initialized
INFO - 2021-07-29 02:54:45 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:45 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:45 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:45 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:45 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:45 --> Controller Class Initialized
INFO - 2021-07-29 02:54:47 --> Config Class Initialized
INFO - 2021-07-29 02:54:47 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:47 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:47 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:47 --> URI Class Initialized
INFO - 2021-07-29 02:54:47 --> Router Class Initialized
INFO - 2021-07-29 02:54:47 --> Output Class Initialized
INFO - 2021-07-29 02:54:47 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:47 --> Input Class Initialized
INFO - 2021-07-29 02:54:47 --> Language Class Initialized
INFO - 2021-07-29 02:54:47 --> Language Class Initialized
INFO - 2021-07-29 02:54:47 --> Config Class Initialized
INFO - 2021-07-29 02:54:47 --> Loader Class Initialized
INFO - 2021-07-29 02:54:47 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:47 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:47 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:47 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:47 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:47 --> Controller Class Initialized
INFO - 2021-07-29 02:54:49 --> Config Class Initialized
INFO - 2021-07-29 02:54:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:49 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:49 --> URI Class Initialized
INFO - 2021-07-29 02:54:49 --> Router Class Initialized
INFO - 2021-07-29 02:54:49 --> Output Class Initialized
INFO - 2021-07-29 02:54:49 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:49 --> Input Class Initialized
INFO - 2021-07-29 02:54:49 --> Language Class Initialized
INFO - 2021-07-29 02:54:49 --> Language Class Initialized
INFO - 2021-07-29 02:54:49 --> Config Class Initialized
INFO - 2021-07-29 02:54:49 --> Loader Class Initialized
INFO - 2021-07-29 02:54:49 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:49 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:49 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:49 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:49 --> Controller Class Initialized
INFO - 2021-07-29 02:54:50 --> Config Class Initialized
INFO - 2021-07-29 02:54:50 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:50 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:50 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:50 --> URI Class Initialized
INFO - 2021-07-29 02:54:50 --> Router Class Initialized
INFO - 2021-07-29 02:54:50 --> Output Class Initialized
INFO - 2021-07-29 02:54:50 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:50 --> Input Class Initialized
INFO - 2021-07-29 02:54:50 --> Language Class Initialized
INFO - 2021-07-29 02:54:50 --> Language Class Initialized
INFO - 2021-07-29 02:54:50 --> Config Class Initialized
INFO - 2021-07-29 02:54:50 --> Loader Class Initialized
INFO - 2021-07-29 02:54:50 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:50 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:50 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:50 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:51 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:51 --> Controller Class Initialized
INFO - 2021-07-29 02:54:52 --> Config Class Initialized
INFO - 2021-07-29 02:54:52 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:52 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:52 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:52 --> URI Class Initialized
INFO - 2021-07-29 02:54:52 --> Router Class Initialized
INFO - 2021-07-29 02:54:52 --> Output Class Initialized
INFO - 2021-07-29 02:54:52 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:52 --> Input Class Initialized
INFO - 2021-07-29 02:54:52 --> Language Class Initialized
INFO - 2021-07-29 02:54:52 --> Language Class Initialized
INFO - 2021-07-29 02:54:52 --> Config Class Initialized
INFO - 2021-07-29 02:54:52 --> Loader Class Initialized
INFO - 2021-07-29 02:54:52 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:52 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:52 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:52 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:52 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:52 --> Controller Class Initialized
INFO - 2021-07-29 02:54:54 --> Config Class Initialized
INFO - 2021-07-29 02:54:54 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:54 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:54 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:54 --> URI Class Initialized
INFO - 2021-07-29 02:54:54 --> Router Class Initialized
INFO - 2021-07-29 02:54:54 --> Output Class Initialized
INFO - 2021-07-29 02:54:54 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:54 --> Input Class Initialized
INFO - 2021-07-29 02:54:54 --> Language Class Initialized
INFO - 2021-07-29 02:54:54 --> Language Class Initialized
INFO - 2021-07-29 02:54:54 --> Config Class Initialized
INFO - 2021-07-29 02:54:54 --> Loader Class Initialized
INFO - 2021-07-29 02:54:54 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:54 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:54 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:54 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:54 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:54 --> Controller Class Initialized
INFO - 2021-07-29 02:54:56 --> Config Class Initialized
INFO - 2021-07-29 02:54:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:56 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:56 --> URI Class Initialized
INFO - 2021-07-29 02:54:56 --> Router Class Initialized
INFO - 2021-07-29 02:54:56 --> Output Class Initialized
INFO - 2021-07-29 02:54:56 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:56 --> Input Class Initialized
INFO - 2021-07-29 02:54:56 --> Language Class Initialized
INFO - 2021-07-29 02:54:56 --> Language Class Initialized
INFO - 2021-07-29 02:54:56 --> Config Class Initialized
INFO - 2021-07-29 02:54:56 --> Loader Class Initialized
INFO - 2021-07-29 02:54:56 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:56 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:56 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:56 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:56 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:56 --> Controller Class Initialized
INFO - 2021-07-29 02:54:57 --> Config Class Initialized
INFO - 2021-07-29 02:54:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:57 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:57 --> URI Class Initialized
INFO - 2021-07-29 02:54:57 --> Router Class Initialized
INFO - 2021-07-29 02:54:57 --> Output Class Initialized
INFO - 2021-07-29 02:54:57 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:57 --> Input Class Initialized
INFO - 2021-07-29 02:54:57 --> Language Class Initialized
INFO - 2021-07-29 02:54:57 --> Language Class Initialized
INFO - 2021-07-29 02:54:57 --> Config Class Initialized
INFO - 2021-07-29 02:54:57 --> Loader Class Initialized
INFO - 2021-07-29 02:54:57 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:57 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:57 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:57 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:57 --> Controller Class Initialized
INFO - 2021-07-29 02:54:59 --> Config Class Initialized
INFO - 2021-07-29 02:54:59 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:54:59 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:54:59 --> Utf8 Class Initialized
INFO - 2021-07-29 02:54:59 --> URI Class Initialized
INFO - 2021-07-29 02:54:59 --> Router Class Initialized
INFO - 2021-07-29 02:54:59 --> Output Class Initialized
INFO - 2021-07-29 02:54:59 --> Security Class Initialized
DEBUG - 2021-07-29 02:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:54:59 --> Input Class Initialized
INFO - 2021-07-29 02:54:59 --> Language Class Initialized
INFO - 2021-07-29 02:54:59 --> Language Class Initialized
INFO - 2021-07-29 02:54:59 --> Config Class Initialized
INFO - 2021-07-29 02:54:59 --> Loader Class Initialized
INFO - 2021-07-29 02:54:59 --> Helper loaded: url_helper
INFO - 2021-07-29 02:54:59 --> Helper loaded: file_helper
INFO - 2021-07-29 02:54:59 --> Helper loaded: form_helper
INFO - 2021-07-29 02:54:59 --> Helper loaded: my_helper
INFO - 2021-07-29 02:54:59 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:54:59 --> Controller Class Initialized
INFO - 2021-07-29 02:55:00 --> Config Class Initialized
INFO - 2021-07-29 02:55:00 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:00 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:00 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:00 --> URI Class Initialized
INFO - 2021-07-29 02:55:00 --> Router Class Initialized
INFO - 2021-07-29 02:55:00 --> Output Class Initialized
INFO - 2021-07-29 02:55:00 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:00 --> Input Class Initialized
INFO - 2021-07-29 02:55:00 --> Language Class Initialized
INFO - 2021-07-29 02:55:00 --> Language Class Initialized
INFO - 2021-07-29 02:55:00 --> Config Class Initialized
INFO - 2021-07-29 02:55:00 --> Loader Class Initialized
INFO - 2021-07-29 02:55:00 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:00 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:00 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:00 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:00 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:00 --> Controller Class Initialized
INFO - 2021-07-29 02:55:02 --> Config Class Initialized
INFO - 2021-07-29 02:55:02 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:02 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:02 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:02 --> URI Class Initialized
INFO - 2021-07-29 02:55:02 --> Router Class Initialized
INFO - 2021-07-29 02:55:02 --> Output Class Initialized
INFO - 2021-07-29 02:55:02 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:02 --> Input Class Initialized
INFO - 2021-07-29 02:55:02 --> Language Class Initialized
INFO - 2021-07-29 02:55:02 --> Language Class Initialized
INFO - 2021-07-29 02:55:02 --> Config Class Initialized
INFO - 2021-07-29 02:55:02 --> Loader Class Initialized
INFO - 2021-07-29 02:55:02 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:02 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:02 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:02 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:02 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:02 --> Controller Class Initialized
INFO - 2021-07-29 02:55:04 --> Config Class Initialized
INFO - 2021-07-29 02:55:04 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:04 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:04 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:04 --> URI Class Initialized
INFO - 2021-07-29 02:55:04 --> Router Class Initialized
INFO - 2021-07-29 02:55:04 --> Output Class Initialized
INFO - 2021-07-29 02:55:04 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:04 --> Input Class Initialized
INFO - 2021-07-29 02:55:04 --> Language Class Initialized
INFO - 2021-07-29 02:55:04 --> Language Class Initialized
INFO - 2021-07-29 02:55:04 --> Config Class Initialized
INFO - 2021-07-29 02:55:04 --> Loader Class Initialized
INFO - 2021-07-29 02:55:04 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:04 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:04 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:04 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:04 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:04 --> Controller Class Initialized
INFO - 2021-07-29 02:55:05 --> Config Class Initialized
INFO - 2021-07-29 02:55:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:05 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:05 --> URI Class Initialized
INFO - 2021-07-29 02:55:05 --> Router Class Initialized
INFO - 2021-07-29 02:55:05 --> Output Class Initialized
INFO - 2021-07-29 02:55:05 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:05 --> Input Class Initialized
INFO - 2021-07-29 02:55:05 --> Language Class Initialized
INFO - 2021-07-29 02:55:05 --> Language Class Initialized
INFO - 2021-07-29 02:55:05 --> Config Class Initialized
INFO - 2021-07-29 02:55:05 --> Loader Class Initialized
INFO - 2021-07-29 02:55:05 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:05 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:05 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:05 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:05 --> Controller Class Initialized
INFO - 2021-07-29 02:55:07 --> Config Class Initialized
INFO - 2021-07-29 02:55:07 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:07 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:07 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:07 --> URI Class Initialized
INFO - 2021-07-29 02:55:07 --> Router Class Initialized
INFO - 2021-07-29 02:55:07 --> Output Class Initialized
INFO - 2021-07-29 02:55:07 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:07 --> Input Class Initialized
INFO - 2021-07-29 02:55:07 --> Language Class Initialized
INFO - 2021-07-29 02:55:07 --> Language Class Initialized
INFO - 2021-07-29 02:55:07 --> Config Class Initialized
INFO - 2021-07-29 02:55:07 --> Loader Class Initialized
INFO - 2021-07-29 02:55:07 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:07 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:07 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:07 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:07 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:07 --> Controller Class Initialized
INFO - 2021-07-29 02:55:09 --> Config Class Initialized
INFO - 2021-07-29 02:55:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:09 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:09 --> URI Class Initialized
INFO - 2021-07-29 02:55:09 --> Router Class Initialized
INFO - 2021-07-29 02:55:09 --> Output Class Initialized
INFO - 2021-07-29 02:55:09 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:09 --> Input Class Initialized
INFO - 2021-07-29 02:55:09 --> Language Class Initialized
INFO - 2021-07-29 02:55:09 --> Language Class Initialized
INFO - 2021-07-29 02:55:09 --> Config Class Initialized
INFO - 2021-07-29 02:55:09 --> Loader Class Initialized
INFO - 2021-07-29 02:55:09 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:09 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:09 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:09 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:09 --> Controller Class Initialized
INFO - 2021-07-29 02:55:10 --> Config Class Initialized
INFO - 2021-07-29 02:55:10 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:10 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:10 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:10 --> URI Class Initialized
INFO - 2021-07-29 02:55:10 --> Router Class Initialized
INFO - 2021-07-29 02:55:10 --> Output Class Initialized
INFO - 2021-07-29 02:55:10 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:10 --> Input Class Initialized
INFO - 2021-07-29 02:55:10 --> Language Class Initialized
INFO - 2021-07-29 02:55:10 --> Language Class Initialized
INFO - 2021-07-29 02:55:10 --> Config Class Initialized
INFO - 2021-07-29 02:55:10 --> Loader Class Initialized
INFO - 2021-07-29 02:55:10 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:10 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:10 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:10 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:10 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:10 --> Controller Class Initialized
INFO - 2021-07-29 02:55:12 --> Config Class Initialized
INFO - 2021-07-29 02:55:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:12 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:12 --> URI Class Initialized
INFO - 2021-07-29 02:55:12 --> Router Class Initialized
INFO - 2021-07-29 02:55:12 --> Output Class Initialized
INFO - 2021-07-29 02:55:12 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:12 --> Input Class Initialized
INFO - 2021-07-29 02:55:12 --> Language Class Initialized
INFO - 2021-07-29 02:55:12 --> Language Class Initialized
INFO - 2021-07-29 02:55:12 --> Config Class Initialized
INFO - 2021-07-29 02:55:12 --> Loader Class Initialized
INFO - 2021-07-29 02:55:12 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:12 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:12 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:12 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:12 --> Controller Class Initialized
INFO - 2021-07-29 02:55:14 --> Config Class Initialized
INFO - 2021-07-29 02:55:14 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:14 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:14 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:14 --> URI Class Initialized
INFO - 2021-07-29 02:55:14 --> Router Class Initialized
INFO - 2021-07-29 02:55:14 --> Output Class Initialized
INFO - 2021-07-29 02:55:14 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:14 --> Input Class Initialized
INFO - 2021-07-29 02:55:14 --> Language Class Initialized
INFO - 2021-07-29 02:55:14 --> Language Class Initialized
INFO - 2021-07-29 02:55:14 --> Config Class Initialized
INFO - 2021-07-29 02:55:14 --> Loader Class Initialized
INFO - 2021-07-29 02:55:14 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:14 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:14 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:14 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:14 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:14 --> Controller Class Initialized
INFO - 2021-07-29 02:55:16 --> Config Class Initialized
INFO - 2021-07-29 02:55:16 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:16 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:16 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:16 --> URI Class Initialized
INFO - 2021-07-29 02:55:16 --> Router Class Initialized
INFO - 2021-07-29 02:55:16 --> Output Class Initialized
INFO - 2021-07-29 02:55:16 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:16 --> Input Class Initialized
INFO - 2021-07-29 02:55:16 --> Language Class Initialized
INFO - 2021-07-29 02:55:16 --> Language Class Initialized
INFO - 2021-07-29 02:55:16 --> Config Class Initialized
INFO - 2021-07-29 02:55:16 --> Loader Class Initialized
INFO - 2021-07-29 02:55:16 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:16 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:16 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:16 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:16 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:16 --> Controller Class Initialized
INFO - 2021-07-29 02:55:19 --> Config Class Initialized
INFO - 2021-07-29 02:55:19 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:19 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:19 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:19 --> URI Class Initialized
INFO - 2021-07-29 02:55:19 --> Router Class Initialized
INFO - 2021-07-29 02:55:19 --> Output Class Initialized
INFO - 2021-07-29 02:55:19 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:19 --> Input Class Initialized
INFO - 2021-07-29 02:55:19 --> Language Class Initialized
INFO - 2021-07-29 02:55:19 --> Language Class Initialized
INFO - 2021-07-29 02:55:19 --> Config Class Initialized
INFO - 2021-07-29 02:55:19 --> Loader Class Initialized
INFO - 2021-07-29 02:55:19 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:19 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:19 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:19 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:19 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:19 --> Controller Class Initialized
INFO - 2021-07-29 02:55:20 --> Config Class Initialized
INFO - 2021-07-29 02:55:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:20 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:20 --> URI Class Initialized
INFO - 2021-07-29 02:55:20 --> Router Class Initialized
INFO - 2021-07-29 02:55:20 --> Output Class Initialized
INFO - 2021-07-29 02:55:20 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:20 --> Input Class Initialized
INFO - 2021-07-29 02:55:20 --> Language Class Initialized
INFO - 2021-07-29 02:55:20 --> Language Class Initialized
INFO - 2021-07-29 02:55:20 --> Config Class Initialized
INFO - 2021-07-29 02:55:20 --> Loader Class Initialized
INFO - 2021-07-29 02:55:20 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:20 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:20 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:20 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:20 --> Controller Class Initialized
INFO - 2021-07-29 02:55:22 --> Config Class Initialized
INFO - 2021-07-29 02:55:22 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:22 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:22 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:22 --> URI Class Initialized
INFO - 2021-07-29 02:55:22 --> Router Class Initialized
INFO - 2021-07-29 02:55:22 --> Output Class Initialized
INFO - 2021-07-29 02:55:22 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:22 --> Input Class Initialized
INFO - 2021-07-29 02:55:22 --> Language Class Initialized
INFO - 2021-07-29 02:55:22 --> Language Class Initialized
INFO - 2021-07-29 02:55:22 --> Config Class Initialized
INFO - 2021-07-29 02:55:22 --> Loader Class Initialized
INFO - 2021-07-29 02:55:22 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:22 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:22 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:22 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:22 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:22 --> Controller Class Initialized
INFO - 2021-07-29 02:55:24 --> Config Class Initialized
INFO - 2021-07-29 02:55:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:24 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:24 --> URI Class Initialized
INFO - 2021-07-29 02:55:24 --> Router Class Initialized
INFO - 2021-07-29 02:55:24 --> Output Class Initialized
INFO - 2021-07-29 02:55:24 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:24 --> Input Class Initialized
INFO - 2021-07-29 02:55:24 --> Language Class Initialized
INFO - 2021-07-29 02:55:24 --> Language Class Initialized
INFO - 2021-07-29 02:55:24 --> Config Class Initialized
INFO - 2021-07-29 02:55:24 --> Loader Class Initialized
INFO - 2021-07-29 02:55:24 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:24 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:24 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:24 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:24 --> Controller Class Initialized
INFO - 2021-07-29 02:55:26 --> Config Class Initialized
INFO - 2021-07-29 02:55:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:26 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:26 --> URI Class Initialized
INFO - 2021-07-29 02:55:26 --> Router Class Initialized
INFO - 2021-07-29 02:55:26 --> Output Class Initialized
INFO - 2021-07-29 02:55:26 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:26 --> Input Class Initialized
INFO - 2021-07-29 02:55:26 --> Language Class Initialized
INFO - 2021-07-29 02:55:26 --> Language Class Initialized
INFO - 2021-07-29 02:55:26 --> Config Class Initialized
INFO - 2021-07-29 02:55:26 --> Loader Class Initialized
INFO - 2021-07-29 02:55:26 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:26 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:26 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:26 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:27 --> Controller Class Initialized
INFO - 2021-07-29 02:55:29 --> Config Class Initialized
INFO - 2021-07-29 02:55:29 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:29 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:29 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:29 --> URI Class Initialized
INFO - 2021-07-29 02:55:29 --> Router Class Initialized
INFO - 2021-07-29 02:55:29 --> Output Class Initialized
INFO - 2021-07-29 02:55:29 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:29 --> Input Class Initialized
INFO - 2021-07-29 02:55:29 --> Language Class Initialized
INFO - 2021-07-29 02:55:29 --> Language Class Initialized
INFO - 2021-07-29 02:55:29 --> Config Class Initialized
INFO - 2021-07-29 02:55:29 --> Loader Class Initialized
INFO - 2021-07-29 02:55:29 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:29 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:29 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:29 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:29 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:29 --> Controller Class Initialized
INFO - 2021-07-29 02:55:31 --> Config Class Initialized
INFO - 2021-07-29 02:55:31 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:31 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:31 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:31 --> URI Class Initialized
INFO - 2021-07-29 02:55:31 --> Router Class Initialized
INFO - 2021-07-29 02:55:31 --> Output Class Initialized
INFO - 2021-07-29 02:55:31 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:31 --> Input Class Initialized
INFO - 2021-07-29 02:55:31 --> Language Class Initialized
INFO - 2021-07-29 02:55:31 --> Language Class Initialized
INFO - 2021-07-29 02:55:31 --> Config Class Initialized
INFO - 2021-07-29 02:55:31 --> Loader Class Initialized
INFO - 2021-07-29 02:55:31 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:31 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:31 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:31 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:31 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:31 --> Controller Class Initialized
INFO - 2021-07-29 02:55:33 --> Config Class Initialized
INFO - 2021-07-29 02:55:33 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:33 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:33 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:33 --> URI Class Initialized
INFO - 2021-07-29 02:55:33 --> Router Class Initialized
INFO - 2021-07-29 02:55:33 --> Output Class Initialized
INFO - 2021-07-29 02:55:33 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:33 --> Input Class Initialized
INFO - 2021-07-29 02:55:33 --> Language Class Initialized
INFO - 2021-07-29 02:55:33 --> Language Class Initialized
INFO - 2021-07-29 02:55:33 --> Config Class Initialized
INFO - 2021-07-29 02:55:33 --> Loader Class Initialized
INFO - 2021-07-29 02:55:33 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:33 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:33 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:33 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:33 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:33 --> Controller Class Initialized
INFO - 2021-07-29 02:55:35 --> Config Class Initialized
INFO - 2021-07-29 02:55:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:35 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:35 --> URI Class Initialized
INFO - 2021-07-29 02:55:35 --> Router Class Initialized
INFO - 2021-07-29 02:55:35 --> Output Class Initialized
INFO - 2021-07-29 02:55:35 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:35 --> Input Class Initialized
INFO - 2021-07-29 02:55:35 --> Language Class Initialized
INFO - 2021-07-29 02:55:35 --> Language Class Initialized
INFO - 2021-07-29 02:55:35 --> Config Class Initialized
INFO - 2021-07-29 02:55:35 --> Loader Class Initialized
INFO - 2021-07-29 02:55:35 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:35 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:35 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:35 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:35 --> Controller Class Initialized
INFO - 2021-07-29 02:55:39 --> Config Class Initialized
INFO - 2021-07-29 02:55:39 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:55:39 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:55:39 --> Utf8 Class Initialized
INFO - 2021-07-29 02:55:39 --> URI Class Initialized
INFO - 2021-07-29 02:55:39 --> Router Class Initialized
INFO - 2021-07-29 02:55:39 --> Output Class Initialized
INFO - 2021-07-29 02:55:39 --> Security Class Initialized
DEBUG - 2021-07-29 02:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:55:39 --> Input Class Initialized
INFO - 2021-07-29 02:55:39 --> Language Class Initialized
INFO - 2021-07-29 02:55:39 --> Language Class Initialized
INFO - 2021-07-29 02:55:39 --> Config Class Initialized
INFO - 2021-07-29 02:55:39 --> Loader Class Initialized
INFO - 2021-07-29 02:55:39 --> Helper loaded: url_helper
INFO - 2021-07-29 02:55:39 --> Helper loaded: file_helper
INFO - 2021-07-29 02:55:39 --> Helper loaded: form_helper
INFO - 2021-07-29 02:55:39 --> Helper loaded: my_helper
INFO - 2021-07-29 02:55:39 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:55:39 --> Controller Class Initialized
INFO - 2021-07-29 02:59:21 --> Config Class Initialized
INFO - 2021-07-29 02:59:21 --> Hooks Class Initialized
DEBUG - 2021-07-29 02:59:21 --> UTF-8 Support Enabled
INFO - 2021-07-29 02:59:21 --> Utf8 Class Initialized
INFO - 2021-07-29 02:59:21 --> URI Class Initialized
INFO - 2021-07-29 02:59:21 --> Router Class Initialized
INFO - 2021-07-29 02:59:21 --> Output Class Initialized
INFO - 2021-07-29 02:59:21 --> Security Class Initialized
DEBUG - 2021-07-29 02:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 02:59:21 --> Input Class Initialized
INFO - 2021-07-29 02:59:21 --> Language Class Initialized
INFO - 2021-07-29 02:59:21 --> Language Class Initialized
INFO - 2021-07-29 02:59:21 --> Config Class Initialized
INFO - 2021-07-29 02:59:21 --> Loader Class Initialized
INFO - 2021-07-29 02:59:21 --> Helper loaded: url_helper
INFO - 2021-07-29 02:59:21 --> Helper loaded: file_helper
INFO - 2021-07-29 02:59:21 --> Helper loaded: form_helper
INFO - 2021-07-29 02:59:21 --> Helper loaded: my_helper
INFO - 2021-07-29 02:59:21 --> Database Driver Class Initialized
DEBUG - 2021-07-29 02:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 02:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 02:59:21 --> Controller Class Initialized
INFO - 2021-07-29 03:00:43 --> Config Class Initialized
INFO - 2021-07-29 03:00:43 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:00:43 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:00:43 --> Utf8 Class Initialized
INFO - 2021-07-29 03:00:43 --> URI Class Initialized
INFO - 2021-07-29 03:00:43 --> Router Class Initialized
INFO - 2021-07-29 03:00:43 --> Output Class Initialized
INFO - 2021-07-29 03:00:43 --> Security Class Initialized
DEBUG - 2021-07-29 03:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:00:43 --> Input Class Initialized
INFO - 2021-07-29 03:00:43 --> Language Class Initialized
INFO - 2021-07-29 03:00:43 --> Language Class Initialized
INFO - 2021-07-29 03:00:43 --> Config Class Initialized
INFO - 2021-07-29 03:00:43 --> Loader Class Initialized
INFO - 2021-07-29 03:00:43 --> Helper loaded: url_helper
INFO - 2021-07-29 03:00:43 --> Helper loaded: file_helper
INFO - 2021-07-29 03:00:43 --> Helper loaded: form_helper
INFO - 2021-07-29 03:00:43 --> Helper loaded: my_helper
INFO - 2021-07-29 03:00:43 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:00:43 --> Controller Class Initialized
DEBUG - 2021-07-29 03:00:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:00:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:00:43 --> Final output sent to browser
DEBUG - 2021-07-29 03:00:43 --> Total execution time: 0.0487
INFO - 2021-07-29 03:00:44 --> Config Class Initialized
INFO - 2021-07-29 03:00:44 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:00:44 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:00:44 --> Utf8 Class Initialized
INFO - 2021-07-29 03:00:44 --> URI Class Initialized
INFO - 2021-07-29 03:00:44 --> Router Class Initialized
INFO - 2021-07-29 03:00:44 --> Output Class Initialized
INFO - 2021-07-29 03:00:44 --> Security Class Initialized
DEBUG - 2021-07-29 03:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:00:44 --> Input Class Initialized
INFO - 2021-07-29 03:00:44 --> Language Class Initialized
INFO - 2021-07-29 03:00:44 --> Language Class Initialized
INFO - 2021-07-29 03:00:44 --> Config Class Initialized
INFO - 2021-07-29 03:00:44 --> Loader Class Initialized
INFO - 2021-07-29 03:00:44 --> Helper loaded: url_helper
INFO - 2021-07-29 03:00:44 --> Helper loaded: file_helper
INFO - 2021-07-29 03:00:44 --> Helper loaded: form_helper
INFO - 2021-07-29 03:00:44 --> Helper loaded: my_helper
INFO - 2021-07-29 03:00:44 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:00:44 --> Controller Class Initialized
INFO - 2021-07-29 03:00:49 --> Config Class Initialized
INFO - 2021-07-29 03:00:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:00:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:00:49 --> Utf8 Class Initialized
INFO - 2021-07-29 03:00:49 --> URI Class Initialized
INFO - 2021-07-29 03:00:49 --> Router Class Initialized
INFO - 2021-07-29 03:00:49 --> Output Class Initialized
INFO - 2021-07-29 03:00:49 --> Security Class Initialized
DEBUG - 2021-07-29 03:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:00:49 --> Input Class Initialized
INFO - 2021-07-29 03:00:49 --> Language Class Initialized
INFO - 2021-07-29 03:00:49 --> Language Class Initialized
INFO - 2021-07-29 03:00:49 --> Config Class Initialized
INFO - 2021-07-29 03:00:49 --> Loader Class Initialized
INFO - 2021-07-29 03:00:49 --> Helper loaded: url_helper
INFO - 2021-07-29 03:00:49 --> Helper loaded: file_helper
INFO - 2021-07-29 03:00:49 --> Helper loaded: form_helper
INFO - 2021-07-29 03:00:49 --> Helper loaded: my_helper
INFO - 2021-07-29 03:00:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:00:49 --> Controller Class Initialized
INFO - 2021-07-29 03:01:01 --> Config Class Initialized
INFO - 2021-07-29 03:01:01 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:01:01 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:01:01 --> Utf8 Class Initialized
INFO - 2021-07-29 03:01:01 --> URI Class Initialized
INFO - 2021-07-29 03:01:01 --> Router Class Initialized
INFO - 2021-07-29 03:01:01 --> Output Class Initialized
INFO - 2021-07-29 03:01:01 --> Security Class Initialized
DEBUG - 2021-07-29 03:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:01:01 --> Input Class Initialized
INFO - 2021-07-29 03:01:01 --> Language Class Initialized
INFO - 2021-07-29 03:01:01 --> Language Class Initialized
INFO - 2021-07-29 03:01:01 --> Config Class Initialized
INFO - 2021-07-29 03:01:01 --> Loader Class Initialized
INFO - 2021-07-29 03:01:01 --> Helper loaded: url_helper
INFO - 2021-07-29 03:01:01 --> Helper loaded: file_helper
INFO - 2021-07-29 03:01:01 --> Helper loaded: form_helper
INFO - 2021-07-29 03:01:01 --> Helper loaded: my_helper
INFO - 2021-07-29 03:01:01 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:01:01 --> Controller Class Initialized
INFO - 2021-07-29 03:23:24 --> Config Class Initialized
INFO - 2021-07-29 03:23:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:24 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:24 --> URI Class Initialized
INFO - 2021-07-29 03:23:24 --> Router Class Initialized
INFO - 2021-07-29 03:23:24 --> Output Class Initialized
INFO - 2021-07-29 03:23:24 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:24 --> Input Class Initialized
INFO - 2021-07-29 03:23:24 --> Language Class Initialized
INFO - 2021-07-29 03:23:24 --> Language Class Initialized
INFO - 2021-07-29 03:23:24 --> Config Class Initialized
INFO - 2021-07-29 03:23:24 --> Loader Class Initialized
INFO - 2021-07-29 03:23:24 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:24 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:24 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:24 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:24 --> Controller Class Initialized
DEBUG - 2021-07-29 03:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:23:24 --> Final output sent to browser
DEBUG - 2021-07-29 03:23:24 --> Total execution time: 0.0578
INFO - 2021-07-29 03:23:30 --> Config Class Initialized
INFO - 2021-07-29 03:23:30 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:30 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:30 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:30 --> URI Class Initialized
INFO - 2021-07-29 03:23:30 --> Router Class Initialized
INFO - 2021-07-29 03:23:30 --> Output Class Initialized
INFO - 2021-07-29 03:23:30 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:30 --> Input Class Initialized
INFO - 2021-07-29 03:23:30 --> Language Class Initialized
INFO - 2021-07-29 03:23:30 --> Language Class Initialized
INFO - 2021-07-29 03:23:30 --> Config Class Initialized
INFO - 2021-07-29 03:23:30 --> Loader Class Initialized
INFO - 2021-07-29 03:23:30 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:30 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:30 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:30 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:30 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:30 --> Controller Class Initialized
INFO - 2021-07-29 03:23:30 --> Config Class Initialized
INFO - 2021-07-29 03:23:30 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:30 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:30 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:30 --> URI Class Initialized
INFO - 2021-07-29 03:23:30 --> Router Class Initialized
INFO - 2021-07-29 03:23:30 --> Output Class Initialized
INFO - 2021-07-29 03:23:30 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:30 --> Input Class Initialized
INFO - 2021-07-29 03:23:30 --> Language Class Initialized
INFO - 2021-07-29 03:23:30 --> Language Class Initialized
INFO - 2021-07-29 03:23:30 --> Config Class Initialized
INFO - 2021-07-29 03:23:30 --> Loader Class Initialized
INFO - 2021-07-29 03:23:30 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:30 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:30 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:30 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:30 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:31 --> Controller Class Initialized
DEBUG - 2021-07-29 03:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:23:31 --> Final output sent to browser
DEBUG - 2021-07-29 03:23:31 --> Total execution time: 0.0743
INFO - 2021-07-29 03:23:31 --> Config Class Initialized
INFO - 2021-07-29 03:23:31 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:31 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:31 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:31 --> URI Class Initialized
INFO - 2021-07-29 03:23:31 --> Router Class Initialized
INFO - 2021-07-29 03:23:31 --> Output Class Initialized
INFO - 2021-07-29 03:23:31 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:31 --> Input Class Initialized
INFO - 2021-07-29 03:23:31 --> Language Class Initialized
INFO - 2021-07-29 03:23:31 --> Language Class Initialized
INFO - 2021-07-29 03:23:31 --> Config Class Initialized
INFO - 2021-07-29 03:23:31 --> Loader Class Initialized
INFO - 2021-07-29 03:23:31 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:31 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:31 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:31 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:31 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:31 --> Controller Class Initialized
INFO - 2021-07-29 03:23:37 --> Config Class Initialized
INFO - 2021-07-29 03:23:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:37 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:37 --> URI Class Initialized
INFO - 2021-07-29 03:23:37 --> Router Class Initialized
INFO - 2021-07-29 03:23:37 --> Output Class Initialized
INFO - 2021-07-29 03:23:37 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:37 --> Input Class Initialized
INFO - 2021-07-29 03:23:37 --> Language Class Initialized
INFO - 2021-07-29 03:23:37 --> Language Class Initialized
INFO - 2021-07-29 03:23:37 --> Config Class Initialized
INFO - 2021-07-29 03:23:37 --> Loader Class Initialized
INFO - 2021-07-29 03:23:37 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:37 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:37 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:37 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:37 --> Controller Class Initialized
DEBUG - 2021-07-29 03:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:23:37 --> Final output sent to browser
DEBUG - 2021-07-29 03:23:37 --> Total execution time: 0.0882
INFO - 2021-07-29 03:23:41 --> Config Class Initialized
INFO - 2021-07-29 03:23:41 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:41 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:41 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:41 --> URI Class Initialized
INFO - 2021-07-29 03:23:41 --> Router Class Initialized
INFO - 2021-07-29 03:23:41 --> Output Class Initialized
INFO - 2021-07-29 03:23:41 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:41 --> Input Class Initialized
INFO - 2021-07-29 03:23:41 --> Language Class Initialized
INFO - 2021-07-29 03:23:41 --> Language Class Initialized
INFO - 2021-07-29 03:23:41 --> Config Class Initialized
INFO - 2021-07-29 03:23:41 --> Loader Class Initialized
INFO - 2021-07-29 03:23:41 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:41 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:41 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:41 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:41 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:41 --> Controller Class Initialized
INFO - 2021-07-29 03:23:41 --> Config Class Initialized
INFO - 2021-07-29 03:23:41 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:41 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:41 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:41 --> URI Class Initialized
INFO - 2021-07-29 03:23:41 --> Router Class Initialized
INFO - 2021-07-29 03:23:41 --> Output Class Initialized
INFO - 2021-07-29 03:23:41 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:41 --> Input Class Initialized
INFO - 2021-07-29 03:23:41 --> Language Class Initialized
INFO - 2021-07-29 03:23:41 --> Language Class Initialized
INFO - 2021-07-29 03:23:41 --> Config Class Initialized
INFO - 2021-07-29 03:23:41 --> Loader Class Initialized
INFO - 2021-07-29 03:23:41 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:41 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:41 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:41 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:41 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:41 --> Controller Class Initialized
DEBUG - 2021-07-29 03:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:23:41 --> Final output sent to browser
DEBUG - 2021-07-29 03:23:41 --> Total execution time: 0.0593
INFO - 2021-07-29 03:23:43 --> Config Class Initialized
INFO - 2021-07-29 03:23:43 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:43 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:43 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:43 --> URI Class Initialized
INFO - 2021-07-29 03:23:43 --> Router Class Initialized
INFO - 2021-07-29 03:23:43 --> Output Class Initialized
INFO - 2021-07-29 03:23:43 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:43 --> Input Class Initialized
INFO - 2021-07-29 03:23:43 --> Language Class Initialized
INFO - 2021-07-29 03:23:43 --> Language Class Initialized
INFO - 2021-07-29 03:23:43 --> Config Class Initialized
INFO - 2021-07-29 03:23:43 --> Loader Class Initialized
INFO - 2021-07-29 03:23:43 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:43 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:43 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:43 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:43 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:43 --> Controller Class Initialized
DEBUG - 2021-07-29 03:23:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:23:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:23:43 --> Final output sent to browser
DEBUG - 2021-07-29 03:23:43 --> Total execution time: 0.0549
INFO - 2021-07-29 03:23:49 --> Config Class Initialized
INFO - 2021-07-29 03:23:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:49 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:49 --> URI Class Initialized
INFO - 2021-07-29 03:23:49 --> Router Class Initialized
INFO - 2021-07-29 03:23:49 --> Output Class Initialized
INFO - 2021-07-29 03:23:49 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:49 --> Input Class Initialized
INFO - 2021-07-29 03:23:49 --> Language Class Initialized
INFO - 2021-07-29 03:23:49 --> Language Class Initialized
INFO - 2021-07-29 03:23:49 --> Config Class Initialized
INFO - 2021-07-29 03:23:49 --> Loader Class Initialized
INFO - 2021-07-29 03:23:49 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:49 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:49 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:49 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:49 --> Controller Class Initialized
INFO - 2021-07-29 03:23:49 --> Config Class Initialized
INFO - 2021-07-29 03:23:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:49 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:49 --> URI Class Initialized
INFO - 2021-07-29 03:23:49 --> Router Class Initialized
INFO - 2021-07-29 03:23:49 --> Output Class Initialized
INFO - 2021-07-29 03:23:49 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:49 --> Input Class Initialized
INFO - 2021-07-29 03:23:49 --> Language Class Initialized
INFO - 2021-07-29 03:23:49 --> Language Class Initialized
INFO - 2021-07-29 03:23:49 --> Config Class Initialized
INFO - 2021-07-29 03:23:49 --> Loader Class Initialized
INFO - 2021-07-29 03:23:49 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:49 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:49 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:49 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:49 --> Controller Class Initialized
DEBUG - 2021-07-29 03:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:23:49 --> Final output sent to browser
DEBUG - 2021-07-29 03:23:49 --> Total execution time: 0.0580
INFO - 2021-07-29 03:23:50 --> Config Class Initialized
INFO - 2021-07-29 03:23:50 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:50 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:50 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:50 --> URI Class Initialized
INFO - 2021-07-29 03:23:50 --> Router Class Initialized
INFO - 2021-07-29 03:23:50 --> Output Class Initialized
INFO - 2021-07-29 03:23:50 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:50 --> Input Class Initialized
INFO - 2021-07-29 03:23:50 --> Language Class Initialized
INFO - 2021-07-29 03:23:50 --> Language Class Initialized
INFO - 2021-07-29 03:23:50 --> Config Class Initialized
INFO - 2021-07-29 03:23:50 --> Loader Class Initialized
INFO - 2021-07-29 03:23:50 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:50 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:50 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:50 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:50 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:50 --> Controller Class Initialized
INFO - 2021-07-29 03:23:51 --> Config Class Initialized
INFO - 2021-07-29 03:23:51 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:51 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:51 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:51 --> URI Class Initialized
INFO - 2021-07-29 03:23:51 --> Router Class Initialized
INFO - 2021-07-29 03:23:51 --> Output Class Initialized
INFO - 2021-07-29 03:23:51 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:51 --> Input Class Initialized
INFO - 2021-07-29 03:23:51 --> Language Class Initialized
INFO - 2021-07-29 03:23:51 --> Language Class Initialized
INFO - 2021-07-29 03:23:51 --> Config Class Initialized
INFO - 2021-07-29 03:23:51 --> Loader Class Initialized
INFO - 2021-07-29 03:23:51 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:51 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:51 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:51 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:51 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:51 --> Controller Class Initialized
DEBUG - 2021-07-29 03:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:23:51 --> Final output sent to browser
DEBUG - 2021-07-29 03:23:51 --> Total execution time: 0.0681
INFO - 2021-07-29 03:23:57 --> Config Class Initialized
INFO - 2021-07-29 03:23:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:57 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:57 --> URI Class Initialized
INFO - 2021-07-29 03:23:57 --> Router Class Initialized
INFO - 2021-07-29 03:23:57 --> Output Class Initialized
INFO - 2021-07-29 03:23:57 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:57 --> Input Class Initialized
INFO - 2021-07-29 03:23:57 --> Language Class Initialized
INFO - 2021-07-29 03:23:57 --> Language Class Initialized
INFO - 2021-07-29 03:23:57 --> Config Class Initialized
INFO - 2021-07-29 03:23:57 --> Loader Class Initialized
INFO - 2021-07-29 03:23:57 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:57 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:57 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:57 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:57 --> Controller Class Initialized
INFO - 2021-07-29 03:23:58 --> Config Class Initialized
INFO - 2021-07-29 03:23:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:23:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:23:58 --> Utf8 Class Initialized
INFO - 2021-07-29 03:23:58 --> URI Class Initialized
INFO - 2021-07-29 03:23:58 --> Router Class Initialized
INFO - 2021-07-29 03:23:58 --> Output Class Initialized
INFO - 2021-07-29 03:23:58 --> Security Class Initialized
DEBUG - 2021-07-29 03:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:23:58 --> Input Class Initialized
INFO - 2021-07-29 03:23:58 --> Language Class Initialized
INFO - 2021-07-29 03:23:58 --> Language Class Initialized
INFO - 2021-07-29 03:23:58 --> Config Class Initialized
INFO - 2021-07-29 03:23:58 --> Loader Class Initialized
INFO - 2021-07-29 03:23:58 --> Helper loaded: url_helper
INFO - 2021-07-29 03:23:58 --> Helper loaded: file_helper
INFO - 2021-07-29 03:23:58 --> Helper loaded: form_helper
INFO - 2021-07-29 03:23:58 --> Helper loaded: my_helper
INFO - 2021-07-29 03:23:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:23:58 --> Controller Class Initialized
DEBUG - 2021-07-29 03:23:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:23:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:23:58 --> Final output sent to browser
DEBUG - 2021-07-29 03:23:58 --> Total execution time: 0.0684
INFO - 2021-07-29 03:24:00 --> Config Class Initialized
INFO - 2021-07-29 03:24:00 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:00 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:00 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:00 --> URI Class Initialized
INFO - 2021-07-29 03:24:00 --> Router Class Initialized
INFO - 2021-07-29 03:24:00 --> Output Class Initialized
INFO - 2021-07-29 03:24:00 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:00 --> Input Class Initialized
INFO - 2021-07-29 03:24:00 --> Language Class Initialized
INFO - 2021-07-29 03:24:00 --> Language Class Initialized
INFO - 2021-07-29 03:24:00 --> Config Class Initialized
INFO - 2021-07-29 03:24:00 --> Loader Class Initialized
INFO - 2021-07-29 03:24:00 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:00 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:00 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:00 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:00 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:00 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:24:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:00 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:00 --> Total execution time: 0.0642
INFO - 2021-07-29 03:24:07 --> Config Class Initialized
INFO - 2021-07-29 03:24:07 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:07 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:07 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:07 --> URI Class Initialized
INFO - 2021-07-29 03:24:07 --> Router Class Initialized
INFO - 2021-07-29 03:24:07 --> Output Class Initialized
INFO - 2021-07-29 03:24:07 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:07 --> Input Class Initialized
INFO - 2021-07-29 03:24:07 --> Language Class Initialized
INFO - 2021-07-29 03:24:07 --> Language Class Initialized
INFO - 2021-07-29 03:24:07 --> Config Class Initialized
INFO - 2021-07-29 03:24:07 --> Loader Class Initialized
INFO - 2021-07-29 03:24:07 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:07 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:07 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:07 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:07 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:07 --> Controller Class Initialized
INFO - 2021-07-29 03:24:08 --> Config Class Initialized
INFO - 2021-07-29 03:24:08 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:08 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:08 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:08 --> URI Class Initialized
INFO - 2021-07-29 03:24:08 --> Router Class Initialized
INFO - 2021-07-29 03:24:08 --> Output Class Initialized
INFO - 2021-07-29 03:24:08 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:08 --> Input Class Initialized
INFO - 2021-07-29 03:24:08 --> Language Class Initialized
INFO - 2021-07-29 03:24:08 --> Language Class Initialized
INFO - 2021-07-29 03:24:08 --> Config Class Initialized
INFO - 2021-07-29 03:24:08 --> Loader Class Initialized
INFO - 2021-07-29 03:24:08 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:08 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:08 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:08 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:08 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:08 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:24:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:08 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:08 --> Total execution time: 0.0454
INFO - 2021-07-29 03:24:08 --> Config Class Initialized
INFO - 2021-07-29 03:24:08 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:08 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:08 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:08 --> URI Class Initialized
INFO - 2021-07-29 03:24:08 --> Router Class Initialized
INFO - 2021-07-29 03:24:08 --> Output Class Initialized
INFO - 2021-07-29 03:24:08 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:08 --> Input Class Initialized
INFO - 2021-07-29 03:24:08 --> Language Class Initialized
INFO - 2021-07-29 03:24:08 --> Language Class Initialized
INFO - 2021-07-29 03:24:08 --> Config Class Initialized
INFO - 2021-07-29 03:24:08 --> Loader Class Initialized
INFO - 2021-07-29 03:24:08 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:08 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:08 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:08 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:08 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:08 --> Controller Class Initialized
INFO - 2021-07-29 03:24:10 --> Config Class Initialized
INFO - 2021-07-29 03:24:10 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:10 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:10 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:10 --> URI Class Initialized
INFO - 2021-07-29 03:24:10 --> Router Class Initialized
INFO - 2021-07-29 03:24:10 --> Output Class Initialized
INFO - 2021-07-29 03:24:10 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:10 --> Input Class Initialized
INFO - 2021-07-29 03:24:10 --> Language Class Initialized
INFO - 2021-07-29 03:24:10 --> Language Class Initialized
INFO - 2021-07-29 03:24:10 --> Config Class Initialized
INFO - 2021-07-29 03:24:10 --> Loader Class Initialized
INFO - 2021-07-29 03:24:10 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:10 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:10 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:10 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:10 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:10 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:24:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:10 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:10 --> Total execution time: 0.0571
INFO - 2021-07-29 03:24:16 --> Config Class Initialized
INFO - 2021-07-29 03:24:16 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:16 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:16 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:16 --> URI Class Initialized
INFO - 2021-07-29 03:24:16 --> Router Class Initialized
INFO - 2021-07-29 03:24:16 --> Output Class Initialized
INFO - 2021-07-29 03:24:16 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:16 --> Input Class Initialized
INFO - 2021-07-29 03:24:16 --> Language Class Initialized
INFO - 2021-07-29 03:24:16 --> Language Class Initialized
INFO - 2021-07-29 03:24:16 --> Config Class Initialized
INFO - 2021-07-29 03:24:16 --> Loader Class Initialized
INFO - 2021-07-29 03:24:16 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:16 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:16 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:16 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:16 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:16 --> Controller Class Initialized
INFO - 2021-07-29 03:24:16 --> Config Class Initialized
INFO - 2021-07-29 03:24:16 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:16 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:16 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:16 --> URI Class Initialized
INFO - 2021-07-29 03:24:16 --> Router Class Initialized
INFO - 2021-07-29 03:24:16 --> Output Class Initialized
INFO - 2021-07-29 03:24:16 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:16 --> Input Class Initialized
INFO - 2021-07-29 03:24:16 --> Language Class Initialized
INFO - 2021-07-29 03:24:16 --> Language Class Initialized
INFO - 2021-07-29 03:24:16 --> Config Class Initialized
INFO - 2021-07-29 03:24:16 --> Loader Class Initialized
INFO - 2021-07-29 03:24:16 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:16 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:16 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:16 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:16 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:16 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:16 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:16 --> Total execution time: 0.0539
INFO - 2021-07-29 03:24:18 --> Config Class Initialized
INFO - 2021-07-29 03:24:18 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:18 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:18 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:18 --> URI Class Initialized
INFO - 2021-07-29 03:24:18 --> Router Class Initialized
INFO - 2021-07-29 03:24:18 --> Output Class Initialized
INFO - 2021-07-29 03:24:18 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:18 --> Input Class Initialized
INFO - 2021-07-29 03:24:18 --> Language Class Initialized
INFO - 2021-07-29 03:24:18 --> Language Class Initialized
INFO - 2021-07-29 03:24:18 --> Config Class Initialized
INFO - 2021-07-29 03:24:18 --> Loader Class Initialized
INFO - 2021-07-29 03:24:18 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:18 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:18 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:18 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:18 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:18 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:24:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:18 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:18 --> Total execution time: 0.0562
INFO - 2021-07-29 03:24:24 --> Config Class Initialized
INFO - 2021-07-29 03:24:24 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:24 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:24 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:24 --> URI Class Initialized
INFO - 2021-07-29 03:24:24 --> Router Class Initialized
INFO - 2021-07-29 03:24:24 --> Output Class Initialized
INFO - 2021-07-29 03:24:24 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:24 --> Input Class Initialized
INFO - 2021-07-29 03:24:24 --> Language Class Initialized
INFO - 2021-07-29 03:24:24 --> Language Class Initialized
INFO - 2021-07-29 03:24:24 --> Config Class Initialized
INFO - 2021-07-29 03:24:24 --> Loader Class Initialized
INFO - 2021-07-29 03:24:24 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:24 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:24 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:24 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:24 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:25 --> Controller Class Initialized
INFO - 2021-07-29 03:24:25 --> Config Class Initialized
INFO - 2021-07-29 03:24:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:25 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:25 --> URI Class Initialized
INFO - 2021-07-29 03:24:25 --> Router Class Initialized
INFO - 2021-07-29 03:24:25 --> Output Class Initialized
INFO - 2021-07-29 03:24:25 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:25 --> Input Class Initialized
INFO - 2021-07-29 03:24:25 --> Language Class Initialized
INFO - 2021-07-29 03:24:25 --> Language Class Initialized
INFO - 2021-07-29 03:24:25 --> Config Class Initialized
INFO - 2021-07-29 03:24:25 --> Loader Class Initialized
INFO - 2021-07-29 03:24:25 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:25 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:25 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:25 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:25 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:24:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:25 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:25 --> Total execution time: 0.0665
INFO - 2021-07-29 03:24:25 --> Config Class Initialized
INFO - 2021-07-29 03:24:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:25 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:25 --> URI Class Initialized
INFO - 2021-07-29 03:24:25 --> Router Class Initialized
INFO - 2021-07-29 03:24:25 --> Output Class Initialized
INFO - 2021-07-29 03:24:25 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:25 --> Input Class Initialized
INFO - 2021-07-29 03:24:25 --> Language Class Initialized
INFO - 2021-07-29 03:24:25 --> Language Class Initialized
INFO - 2021-07-29 03:24:25 --> Config Class Initialized
INFO - 2021-07-29 03:24:25 --> Loader Class Initialized
INFO - 2021-07-29 03:24:25 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:25 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:25 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:25 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:25 --> Controller Class Initialized
INFO - 2021-07-29 03:24:29 --> Config Class Initialized
INFO - 2021-07-29 03:24:29 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:29 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:29 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:29 --> URI Class Initialized
INFO - 2021-07-29 03:24:29 --> Router Class Initialized
INFO - 2021-07-29 03:24:29 --> Output Class Initialized
INFO - 2021-07-29 03:24:29 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:29 --> Input Class Initialized
INFO - 2021-07-29 03:24:29 --> Language Class Initialized
INFO - 2021-07-29 03:24:29 --> Language Class Initialized
INFO - 2021-07-29 03:24:29 --> Config Class Initialized
INFO - 2021-07-29 03:24:29 --> Loader Class Initialized
INFO - 2021-07-29 03:24:29 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:29 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:29 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:29 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:29 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:29 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:24:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:29 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:29 --> Total execution time: 0.0612
INFO - 2021-07-29 03:24:34 --> Config Class Initialized
INFO - 2021-07-29 03:24:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:34 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:34 --> URI Class Initialized
INFO - 2021-07-29 03:24:34 --> Router Class Initialized
INFO - 2021-07-29 03:24:34 --> Output Class Initialized
INFO - 2021-07-29 03:24:34 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:34 --> Input Class Initialized
INFO - 2021-07-29 03:24:34 --> Language Class Initialized
INFO - 2021-07-29 03:24:34 --> Language Class Initialized
INFO - 2021-07-29 03:24:34 --> Config Class Initialized
INFO - 2021-07-29 03:24:34 --> Loader Class Initialized
INFO - 2021-07-29 03:24:34 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:34 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:34 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:34 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:34 --> Controller Class Initialized
INFO - 2021-07-29 03:24:34 --> Config Class Initialized
INFO - 2021-07-29 03:24:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:34 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:34 --> URI Class Initialized
INFO - 2021-07-29 03:24:34 --> Router Class Initialized
INFO - 2021-07-29 03:24:34 --> Output Class Initialized
INFO - 2021-07-29 03:24:34 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:34 --> Input Class Initialized
INFO - 2021-07-29 03:24:34 --> Language Class Initialized
INFO - 2021-07-29 03:24:34 --> Language Class Initialized
INFO - 2021-07-29 03:24:34 --> Config Class Initialized
INFO - 2021-07-29 03:24:34 --> Loader Class Initialized
INFO - 2021-07-29 03:24:34 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:34 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:34 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:34 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:34 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:34 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:34 --> Total execution time: 0.0571
INFO - 2021-07-29 03:24:37 --> Config Class Initialized
INFO - 2021-07-29 03:24:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:37 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:37 --> URI Class Initialized
INFO - 2021-07-29 03:24:37 --> Router Class Initialized
INFO - 2021-07-29 03:24:37 --> Output Class Initialized
INFO - 2021-07-29 03:24:37 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:37 --> Input Class Initialized
INFO - 2021-07-29 03:24:37 --> Language Class Initialized
INFO - 2021-07-29 03:24:37 --> Language Class Initialized
INFO - 2021-07-29 03:24:37 --> Config Class Initialized
INFO - 2021-07-29 03:24:37 --> Loader Class Initialized
INFO - 2021-07-29 03:24:37 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:37 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:37 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:37 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:37 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:37 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:37 --> Total execution time: 0.0646
INFO - 2021-07-29 03:24:48 --> Config Class Initialized
INFO - 2021-07-29 03:24:48 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:48 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:48 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:48 --> URI Class Initialized
INFO - 2021-07-29 03:24:48 --> Router Class Initialized
INFO - 2021-07-29 03:24:48 --> Output Class Initialized
INFO - 2021-07-29 03:24:48 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:48 --> Input Class Initialized
INFO - 2021-07-29 03:24:48 --> Language Class Initialized
INFO - 2021-07-29 03:24:48 --> Language Class Initialized
INFO - 2021-07-29 03:24:48 --> Config Class Initialized
INFO - 2021-07-29 03:24:48 --> Loader Class Initialized
INFO - 2021-07-29 03:24:48 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:48 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:48 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:48 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:48 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:48 --> Controller Class Initialized
INFO - 2021-07-29 03:24:49 --> Config Class Initialized
INFO - 2021-07-29 03:24:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:49 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:49 --> URI Class Initialized
INFO - 2021-07-29 03:24:49 --> Router Class Initialized
INFO - 2021-07-29 03:24:49 --> Output Class Initialized
INFO - 2021-07-29 03:24:49 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:49 --> Input Class Initialized
INFO - 2021-07-29 03:24:49 --> Language Class Initialized
INFO - 2021-07-29 03:24:49 --> Language Class Initialized
INFO - 2021-07-29 03:24:49 --> Config Class Initialized
INFO - 2021-07-29 03:24:49 --> Loader Class Initialized
INFO - 2021-07-29 03:24:49 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:49 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:49 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:49 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:49 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:24:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:49 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:49 --> Total execution time: 0.0676
INFO - 2021-07-29 03:24:49 --> Config Class Initialized
INFO - 2021-07-29 03:24:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:49 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:49 --> URI Class Initialized
INFO - 2021-07-29 03:24:49 --> Router Class Initialized
INFO - 2021-07-29 03:24:49 --> Output Class Initialized
INFO - 2021-07-29 03:24:49 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:49 --> Input Class Initialized
INFO - 2021-07-29 03:24:49 --> Language Class Initialized
INFO - 2021-07-29 03:24:49 --> Language Class Initialized
INFO - 2021-07-29 03:24:49 --> Config Class Initialized
INFO - 2021-07-29 03:24:49 --> Loader Class Initialized
INFO - 2021-07-29 03:24:49 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:49 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:49 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:49 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:49 --> Controller Class Initialized
INFO - 2021-07-29 03:24:52 --> Config Class Initialized
INFO - 2021-07-29 03:24:52 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:52 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:52 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:52 --> URI Class Initialized
INFO - 2021-07-29 03:24:52 --> Router Class Initialized
INFO - 2021-07-29 03:24:52 --> Output Class Initialized
INFO - 2021-07-29 03:24:52 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:52 --> Input Class Initialized
INFO - 2021-07-29 03:24:52 --> Language Class Initialized
INFO - 2021-07-29 03:24:52 --> Language Class Initialized
INFO - 2021-07-29 03:24:52 --> Config Class Initialized
INFO - 2021-07-29 03:24:52 --> Loader Class Initialized
INFO - 2021-07-29 03:24:52 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:52 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:52 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:52 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:52 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:52 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:24:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:52 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:52 --> Total execution time: 0.0605
INFO - 2021-07-29 03:24:56 --> Config Class Initialized
INFO - 2021-07-29 03:24:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:56 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:56 --> URI Class Initialized
INFO - 2021-07-29 03:24:56 --> Router Class Initialized
INFO - 2021-07-29 03:24:56 --> Output Class Initialized
INFO - 2021-07-29 03:24:56 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:56 --> Input Class Initialized
INFO - 2021-07-29 03:24:56 --> Language Class Initialized
INFO - 2021-07-29 03:24:56 --> Language Class Initialized
INFO - 2021-07-29 03:24:56 --> Config Class Initialized
INFO - 2021-07-29 03:24:56 --> Loader Class Initialized
INFO - 2021-07-29 03:24:56 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:56 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:56 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:56 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:56 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:56 --> Controller Class Initialized
INFO - 2021-07-29 03:24:56 --> Config Class Initialized
INFO - 2021-07-29 03:24:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:56 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:56 --> URI Class Initialized
INFO - 2021-07-29 03:24:56 --> Router Class Initialized
INFO - 2021-07-29 03:24:56 --> Output Class Initialized
INFO - 2021-07-29 03:24:56 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:56 --> Input Class Initialized
INFO - 2021-07-29 03:24:56 --> Language Class Initialized
INFO - 2021-07-29 03:24:56 --> Language Class Initialized
INFO - 2021-07-29 03:24:56 --> Config Class Initialized
INFO - 2021-07-29 03:24:56 --> Loader Class Initialized
INFO - 2021-07-29 03:24:56 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:56 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:56 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:56 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:56 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:56 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:24:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:56 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:56 --> Total execution time: 0.0610
INFO - 2021-07-29 03:24:58 --> Config Class Initialized
INFO - 2021-07-29 03:24:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:24:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:24:58 --> Utf8 Class Initialized
INFO - 2021-07-29 03:24:58 --> URI Class Initialized
INFO - 2021-07-29 03:24:58 --> Router Class Initialized
INFO - 2021-07-29 03:24:58 --> Output Class Initialized
INFO - 2021-07-29 03:24:58 --> Security Class Initialized
DEBUG - 2021-07-29 03:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:24:58 --> Input Class Initialized
INFO - 2021-07-29 03:24:58 --> Language Class Initialized
INFO - 2021-07-29 03:24:58 --> Language Class Initialized
INFO - 2021-07-29 03:24:58 --> Config Class Initialized
INFO - 2021-07-29 03:24:58 --> Loader Class Initialized
INFO - 2021-07-29 03:24:58 --> Helper loaded: url_helper
INFO - 2021-07-29 03:24:58 --> Helper loaded: file_helper
INFO - 2021-07-29 03:24:58 --> Helper loaded: form_helper
INFO - 2021-07-29 03:24:58 --> Helper loaded: my_helper
INFO - 2021-07-29 03:24:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:24:58 --> Controller Class Initialized
DEBUG - 2021-07-29 03:24:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:24:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:24:58 --> Final output sent to browser
DEBUG - 2021-07-29 03:24:58 --> Total execution time: 0.0454
INFO - 2021-07-29 03:25:03 --> Config Class Initialized
INFO - 2021-07-29 03:25:03 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:03 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:03 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:03 --> URI Class Initialized
INFO - 2021-07-29 03:25:03 --> Router Class Initialized
INFO - 2021-07-29 03:25:03 --> Output Class Initialized
INFO - 2021-07-29 03:25:03 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:03 --> Input Class Initialized
INFO - 2021-07-29 03:25:03 --> Language Class Initialized
INFO - 2021-07-29 03:25:03 --> Language Class Initialized
INFO - 2021-07-29 03:25:03 --> Config Class Initialized
INFO - 2021-07-29 03:25:03 --> Loader Class Initialized
INFO - 2021-07-29 03:25:03 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:03 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:03 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:03 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:03 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:03 --> Controller Class Initialized
INFO - 2021-07-29 03:25:04 --> Config Class Initialized
INFO - 2021-07-29 03:25:04 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:04 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:04 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:04 --> URI Class Initialized
INFO - 2021-07-29 03:25:04 --> Router Class Initialized
INFO - 2021-07-29 03:25:04 --> Output Class Initialized
INFO - 2021-07-29 03:25:04 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:04 --> Input Class Initialized
INFO - 2021-07-29 03:25:04 --> Language Class Initialized
INFO - 2021-07-29 03:25:04 --> Language Class Initialized
INFO - 2021-07-29 03:25:04 --> Config Class Initialized
INFO - 2021-07-29 03:25:04 --> Loader Class Initialized
INFO - 2021-07-29 03:25:04 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:04 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:04 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:04 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:04 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:04 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:04 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:04 --> Total execution time: 0.0452
INFO - 2021-07-29 03:25:04 --> Config Class Initialized
INFO - 2021-07-29 03:25:04 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:04 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:04 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:04 --> URI Class Initialized
INFO - 2021-07-29 03:25:04 --> Router Class Initialized
INFO - 2021-07-29 03:25:04 --> Output Class Initialized
INFO - 2021-07-29 03:25:04 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:04 --> Input Class Initialized
INFO - 2021-07-29 03:25:04 --> Language Class Initialized
INFO - 2021-07-29 03:25:04 --> Language Class Initialized
INFO - 2021-07-29 03:25:04 --> Config Class Initialized
INFO - 2021-07-29 03:25:04 --> Loader Class Initialized
INFO - 2021-07-29 03:25:04 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:04 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:04 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:04 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:04 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:04 --> Controller Class Initialized
INFO - 2021-07-29 03:25:06 --> Config Class Initialized
INFO - 2021-07-29 03:25:06 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:06 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:06 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:06 --> URI Class Initialized
INFO - 2021-07-29 03:25:06 --> Router Class Initialized
INFO - 2021-07-29 03:25:06 --> Output Class Initialized
INFO - 2021-07-29 03:25:06 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:06 --> Input Class Initialized
INFO - 2021-07-29 03:25:06 --> Language Class Initialized
INFO - 2021-07-29 03:25:06 --> Language Class Initialized
INFO - 2021-07-29 03:25:06 --> Config Class Initialized
INFO - 2021-07-29 03:25:06 --> Loader Class Initialized
INFO - 2021-07-29 03:25:06 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:06 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:06 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:06 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:06 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:06 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:06 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:06 --> Total execution time: 0.0456
INFO - 2021-07-29 03:25:09 --> Config Class Initialized
INFO - 2021-07-29 03:25:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:09 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:09 --> URI Class Initialized
INFO - 2021-07-29 03:25:09 --> Router Class Initialized
INFO - 2021-07-29 03:25:09 --> Output Class Initialized
INFO - 2021-07-29 03:25:09 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:09 --> Input Class Initialized
INFO - 2021-07-29 03:25:09 --> Language Class Initialized
INFO - 2021-07-29 03:25:09 --> Language Class Initialized
INFO - 2021-07-29 03:25:09 --> Config Class Initialized
INFO - 2021-07-29 03:25:09 --> Loader Class Initialized
INFO - 2021-07-29 03:25:09 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:09 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:09 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:09 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:09 --> Controller Class Initialized
INFO - 2021-07-29 03:25:09 --> Config Class Initialized
INFO - 2021-07-29 03:25:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:09 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:09 --> URI Class Initialized
INFO - 2021-07-29 03:25:09 --> Router Class Initialized
INFO - 2021-07-29 03:25:09 --> Output Class Initialized
INFO - 2021-07-29 03:25:09 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:09 --> Input Class Initialized
INFO - 2021-07-29 03:25:09 --> Language Class Initialized
INFO - 2021-07-29 03:25:09 --> Language Class Initialized
INFO - 2021-07-29 03:25:09 --> Config Class Initialized
INFO - 2021-07-29 03:25:09 --> Loader Class Initialized
INFO - 2021-07-29 03:25:09 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:09 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:09 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:09 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:09 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:25:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:09 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:09 --> Total execution time: 0.0562
INFO - 2021-07-29 03:25:13 --> Config Class Initialized
INFO - 2021-07-29 03:25:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:13 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:13 --> URI Class Initialized
INFO - 2021-07-29 03:25:13 --> Router Class Initialized
INFO - 2021-07-29 03:25:13 --> Output Class Initialized
INFO - 2021-07-29 03:25:13 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:13 --> Input Class Initialized
INFO - 2021-07-29 03:25:13 --> Language Class Initialized
INFO - 2021-07-29 03:25:13 --> Language Class Initialized
INFO - 2021-07-29 03:25:13 --> Config Class Initialized
INFO - 2021-07-29 03:25:13 --> Loader Class Initialized
INFO - 2021-07-29 03:25:13 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:13 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:13 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:13 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:13 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:25:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:13 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:13 --> Total execution time: 0.0453
INFO - 2021-07-29 03:25:21 --> Config Class Initialized
INFO - 2021-07-29 03:25:21 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:21 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:21 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:21 --> URI Class Initialized
INFO - 2021-07-29 03:25:21 --> Router Class Initialized
INFO - 2021-07-29 03:25:21 --> Output Class Initialized
INFO - 2021-07-29 03:25:21 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:21 --> Input Class Initialized
INFO - 2021-07-29 03:25:21 --> Language Class Initialized
INFO - 2021-07-29 03:25:21 --> Language Class Initialized
INFO - 2021-07-29 03:25:21 --> Config Class Initialized
INFO - 2021-07-29 03:25:21 --> Loader Class Initialized
INFO - 2021-07-29 03:25:21 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:21 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:21 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:21 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:21 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:21 --> Controller Class Initialized
INFO - 2021-07-29 03:25:22 --> Config Class Initialized
INFO - 2021-07-29 03:25:22 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:22 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:22 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:22 --> URI Class Initialized
INFO - 2021-07-29 03:25:22 --> Router Class Initialized
INFO - 2021-07-29 03:25:22 --> Output Class Initialized
INFO - 2021-07-29 03:25:22 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:22 --> Input Class Initialized
INFO - 2021-07-29 03:25:22 --> Language Class Initialized
INFO - 2021-07-29 03:25:22 --> Language Class Initialized
INFO - 2021-07-29 03:25:22 --> Config Class Initialized
INFO - 2021-07-29 03:25:22 --> Loader Class Initialized
INFO - 2021-07-29 03:25:22 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:22 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:22 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:22 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:22 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:22 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:22 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:22 --> Total execution time: 0.0498
INFO - 2021-07-29 03:25:22 --> Config Class Initialized
INFO - 2021-07-29 03:25:22 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:22 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:22 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:22 --> URI Class Initialized
INFO - 2021-07-29 03:25:22 --> Router Class Initialized
INFO - 2021-07-29 03:25:22 --> Output Class Initialized
INFO - 2021-07-29 03:25:22 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:22 --> Input Class Initialized
INFO - 2021-07-29 03:25:22 --> Language Class Initialized
INFO - 2021-07-29 03:25:22 --> Language Class Initialized
INFO - 2021-07-29 03:25:22 --> Config Class Initialized
INFO - 2021-07-29 03:25:22 --> Loader Class Initialized
INFO - 2021-07-29 03:25:22 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:22 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:22 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:22 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:22 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:22 --> Controller Class Initialized
INFO - 2021-07-29 03:25:23 --> Config Class Initialized
INFO - 2021-07-29 03:25:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:23 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:23 --> URI Class Initialized
INFO - 2021-07-29 03:25:23 --> Router Class Initialized
INFO - 2021-07-29 03:25:23 --> Output Class Initialized
INFO - 2021-07-29 03:25:23 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:23 --> Input Class Initialized
INFO - 2021-07-29 03:25:23 --> Language Class Initialized
INFO - 2021-07-29 03:25:23 --> Language Class Initialized
INFO - 2021-07-29 03:25:23 --> Config Class Initialized
INFO - 2021-07-29 03:25:23 --> Loader Class Initialized
INFO - 2021-07-29 03:25:23 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:23 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:23 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:23 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:23 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:25:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:23 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:23 --> Total execution time: 0.0538
INFO - 2021-07-29 03:25:29 --> Config Class Initialized
INFO - 2021-07-29 03:25:29 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:29 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:29 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:29 --> URI Class Initialized
INFO - 2021-07-29 03:25:29 --> Router Class Initialized
INFO - 2021-07-29 03:25:29 --> Output Class Initialized
INFO - 2021-07-29 03:25:29 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:29 --> Input Class Initialized
INFO - 2021-07-29 03:25:29 --> Language Class Initialized
INFO - 2021-07-29 03:25:29 --> Language Class Initialized
INFO - 2021-07-29 03:25:29 --> Config Class Initialized
INFO - 2021-07-29 03:25:29 --> Loader Class Initialized
INFO - 2021-07-29 03:25:29 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:29 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:29 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:29 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:29 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:29 --> Controller Class Initialized
INFO - 2021-07-29 03:25:29 --> Config Class Initialized
INFO - 2021-07-29 03:25:29 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:29 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:29 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:29 --> URI Class Initialized
INFO - 2021-07-29 03:25:29 --> Router Class Initialized
INFO - 2021-07-29 03:25:29 --> Output Class Initialized
INFO - 2021-07-29 03:25:29 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:29 --> Input Class Initialized
INFO - 2021-07-29 03:25:29 --> Language Class Initialized
INFO - 2021-07-29 03:25:29 --> Language Class Initialized
INFO - 2021-07-29 03:25:29 --> Config Class Initialized
INFO - 2021-07-29 03:25:29 --> Loader Class Initialized
INFO - 2021-07-29 03:25:29 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:29 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:29 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:29 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:29 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:29 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:25:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:29 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:29 --> Total execution time: 0.0697
INFO - 2021-07-29 03:25:41 --> Config Class Initialized
INFO - 2021-07-29 03:25:41 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:41 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:41 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:41 --> URI Class Initialized
INFO - 2021-07-29 03:25:41 --> Router Class Initialized
INFO - 2021-07-29 03:25:41 --> Output Class Initialized
INFO - 2021-07-29 03:25:41 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:41 --> Input Class Initialized
INFO - 2021-07-29 03:25:41 --> Language Class Initialized
INFO - 2021-07-29 03:25:41 --> Language Class Initialized
INFO - 2021-07-29 03:25:41 --> Config Class Initialized
INFO - 2021-07-29 03:25:41 --> Loader Class Initialized
INFO - 2021-07-29 03:25:41 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:41 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:41 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:41 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:41 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:41 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:41 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:41 --> Total execution time: 0.0639
INFO - 2021-07-29 03:25:46 --> Config Class Initialized
INFO - 2021-07-29 03:25:46 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:46 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:46 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:46 --> URI Class Initialized
INFO - 2021-07-29 03:25:46 --> Router Class Initialized
INFO - 2021-07-29 03:25:46 --> Output Class Initialized
INFO - 2021-07-29 03:25:46 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:46 --> Input Class Initialized
INFO - 2021-07-29 03:25:46 --> Language Class Initialized
INFO - 2021-07-29 03:25:46 --> Language Class Initialized
INFO - 2021-07-29 03:25:46 --> Config Class Initialized
INFO - 2021-07-29 03:25:46 --> Loader Class Initialized
INFO - 2021-07-29 03:25:46 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:46 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:46 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:46 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:46 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:46 --> Controller Class Initialized
INFO - 2021-07-29 03:25:46 --> Config Class Initialized
INFO - 2021-07-29 03:25:46 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:46 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:46 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:46 --> URI Class Initialized
INFO - 2021-07-29 03:25:46 --> Router Class Initialized
INFO - 2021-07-29 03:25:46 --> Output Class Initialized
INFO - 2021-07-29 03:25:46 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:46 --> Input Class Initialized
INFO - 2021-07-29 03:25:46 --> Language Class Initialized
INFO - 2021-07-29 03:25:46 --> Language Class Initialized
INFO - 2021-07-29 03:25:46 --> Config Class Initialized
INFO - 2021-07-29 03:25:46 --> Loader Class Initialized
INFO - 2021-07-29 03:25:46 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:46 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:46 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:46 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:46 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:46 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:46 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:46 --> Total execution time: 0.0456
INFO - 2021-07-29 03:25:51 --> Config Class Initialized
INFO - 2021-07-29 03:25:51 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:51 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:51 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:51 --> URI Class Initialized
INFO - 2021-07-29 03:25:51 --> Router Class Initialized
INFO - 2021-07-29 03:25:51 --> Output Class Initialized
INFO - 2021-07-29 03:25:51 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:51 --> Input Class Initialized
INFO - 2021-07-29 03:25:51 --> Language Class Initialized
INFO - 2021-07-29 03:25:51 --> Language Class Initialized
INFO - 2021-07-29 03:25:51 --> Config Class Initialized
INFO - 2021-07-29 03:25:51 --> Loader Class Initialized
INFO - 2021-07-29 03:25:51 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:51 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:51 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:51 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:51 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:51 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:51 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:51 --> Total execution time: 0.0475
INFO - 2021-07-29 03:25:58 --> Config Class Initialized
INFO - 2021-07-29 03:25:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:58 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:58 --> URI Class Initialized
INFO - 2021-07-29 03:25:58 --> Router Class Initialized
INFO - 2021-07-29 03:25:58 --> Output Class Initialized
INFO - 2021-07-29 03:25:58 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:58 --> Input Class Initialized
INFO - 2021-07-29 03:25:58 --> Language Class Initialized
INFO - 2021-07-29 03:25:58 --> Language Class Initialized
INFO - 2021-07-29 03:25:58 --> Config Class Initialized
INFO - 2021-07-29 03:25:58 --> Loader Class Initialized
INFO - 2021-07-29 03:25:58 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:58 --> Controller Class Initialized
INFO - 2021-07-29 03:25:58 --> Config Class Initialized
INFO - 2021-07-29 03:25:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:58 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:58 --> URI Class Initialized
INFO - 2021-07-29 03:25:58 --> Router Class Initialized
INFO - 2021-07-29 03:25:58 --> Output Class Initialized
INFO - 2021-07-29 03:25:58 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:58 --> Input Class Initialized
INFO - 2021-07-29 03:25:58 --> Language Class Initialized
INFO - 2021-07-29 03:25:58 --> Language Class Initialized
INFO - 2021-07-29 03:25:58 --> Config Class Initialized
INFO - 2021-07-29 03:25:58 --> Loader Class Initialized
INFO - 2021-07-29 03:25:58 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:58 --> Controller Class Initialized
DEBUG - 2021-07-29 03:25:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:25:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:25:58 --> Final output sent to browser
DEBUG - 2021-07-29 03:25:58 --> Total execution time: 0.0703
INFO - 2021-07-29 03:25:58 --> Config Class Initialized
INFO - 2021-07-29 03:25:58 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:25:58 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:25:58 --> Utf8 Class Initialized
INFO - 2021-07-29 03:25:58 --> URI Class Initialized
INFO - 2021-07-29 03:25:58 --> Router Class Initialized
INFO - 2021-07-29 03:25:58 --> Output Class Initialized
INFO - 2021-07-29 03:25:58 --> Security Class Initialized
DEBUG - 2021-07-29 03:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:25:58 --> Input Class Initialized
INFO - 2021-07-29 03:25:58 --> Language Class Initialized
INFO - 2021-07-29 03:25:58 --> Language Class Initialized
INFO - 2021-07-29 03:25:58 --> Config Class Initialized
INFO - 2021-07-29 03:25:58 --> Loader Class Initialized
INFO - 2021-07-29 03:25:58 --> Helper loaded: url_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: file_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: form_helper
INFO - 2021-07-29 03:25:58 --> Helper loaded: my_helper
INFO - 2021-07-29 03:25:58 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:25:58 --> Controller Class Initialized
INFO - 2021-07-29 03:26:00 --> Config Class Initialized
INFO - 2021-07-29 03:26:00 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:00 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:00 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:00 --> URI Class Initialized
INFO - 2021-07-29 03:26:00 --> Router Class Initialized
INFO - 2021-07-29 03:26:00 --> Output Class Initialized
INFO - 2021-07-29 03:26:00 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:00 --> Input Class Initialized
INFO - 2021-07-29 03:26:00 --> Language Class Initialized
INFO - 2021-07-29 03:26:00 --> Language Class Initialized
INFO - 2021-07-29 03:26:00 --> Config Class Initialized
INFO - 2021-07-29 03:26:00 --> Loader Class Initialized
INFO - 2021-07-29 03:26:00 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:00 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:00 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:00 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:00 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:00 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:26:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:00 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:00 --> Total execution time: 0.0656
INFO - 2021-07-29 03:26:05 --> Config Class Initialized
INFO - 2021-07-29 03:26:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:05 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:05 --> URI Class Initialized
INFO - 2021-07-29 03:26:05 --> Router Class Initialized
INFO - 2021-07-29 03:26:05 --> Output Class Initialized
INFO - 2021-07-29 03:26:05 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:05 --> Input Class Initialized
INFO - 2021-07-29 03:26:05 --> Language Class Initialized
INFO - 2021-07-29 03:26:05 --> Language Class Initialized
INFO - 2021-07-29 03:26:05 --> Config Class Initialized
INFO - 2021-07-29 03:26:05 --> Loader Class Initialized
INFO - 2021-07-29 03:26:05 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:05 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:05 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:05 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:05 --> Controller Class Initialized
INFO - 2021-07-29 03:26:05 --> Config Class Initialized
INFO - 2021-07-29 03:26:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:05 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:05 --> URI Class Initialized
INFO - 2021-07-29 03:26:05 --> Router Class Initialized
INFO - 2021-07-29 03:26:05 --> Output Class Initialized
INFO - 2021-07-29 03:26:05 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:05 --> Input Class Initialized
INFO - 2021-07-29 03:26:05 --> Language Class Initialized
INFO - 2021-07-29 03:26:05 --> Language Class Initialized
INFO - 2021-07-29 03:26:05 --> Config Class Initialized
INFO - 2021-07-29 03:26:05 --> Loader Class Initialized
INFO - 2021-07-29 03:26:05 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:05 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:05 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:05 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:05 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:05 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:05 --> Total execution time: 0.0579
INFO - 2021-07-29 03:26:09 --> Config Class Initialized
INFO - 2021-07-29 03:26:09 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:09 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:09 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:09 --> URI Class Initialized
INFO - 2021-07-29 03:26:09 --> Router Class Initialized
INFO - 2021-07-29 03:26:09 --> Output Class Initialized
INFO - 2021-07-29 03:26:09 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:09 --> Input Class Initialized
INFO - 2021-07-29 03:26:09 --> Language Class Initialized
INFO - 2021-07-29 03:26:09 --> Language Class Initialized
INFO - 2021-07-29 03:26:09 --> Config Class Initialized
INFO - 2021-07-29 03:26:09 --> Loader Class Initialized
INFO - 2021-07-29 03:26:09 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:09 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:09 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:09 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:09 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:09 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:26:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:09 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:09 --> Total execution time: 0.0675
INFO - 2021-07-29 03:26:17 --> Config Class Initialized
INFO - 2021-07-29 03:26:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:17 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:17 --> URI Class Initialized
INFO - 2021-07-29 03:26:17 --> Router Class Initialized
INFO - 2021-07-29 03:26:17 --> Output Class Initialized
INFO - 2021-07-29 03:26:17 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:17 --> Input Class Initialized
INFO - 2021-07-29 03:26:17 --> Language Class Initialized
INFO - 2021-07-29 03:26:17 --> Language Class Initialized
INFO - 2021-07-29 03:26:17 --> Config Class Initialized
INFO - 2021-07-29 03:26:17 --> Loader Class Initialized
INFO - 2021-07-29 03:26:17 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:17 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:17 --> Controller Class Initialized
INFO - 2021-07-29 03:26:17 --> Config Class Initialized
INFO - 2021-07-29 03:26:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:17 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:17 --> URI Class Initialized
INFO - 2021-07-29 03:26:17 --> Router Class Initialized
INFO - 2021-07-29 03:26:17 --> Output Class Initialized
INFO - 2021-07-29 03:26:17 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:17 --> Input Class Initialized
INFO - 2021-07-29 03:26:17 --> Language Class Initialized
INFO - 2021-07-29 03:26:17 --> Language Class Initialized
INFO - 2021-07-29 03:26:17 --> Config Class Initialized
INFO - 2021-07-29 03:26:17 --> Loader Class Initialized
INFO - 2021-07-29 03:26:17 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:17 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:17 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:17 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:17 --> Total execution time: 0.0678
INFO - 2021-07-29 03:26:17 --> Config Class Initialized
INFO - 2021-07-29 03:26:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:17 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:17 --> URI Class Initialized
INFO - 2021-07-29 03:26:17 --> Router Class Initialized
INFO - 2021-07-29 03:26:17 --> Output Class Initialized
INFO - 2021-07-29 03:26:17 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:17 --> Input Class Initialized
INFO - 2021-07-29 03:26:17 --> Language Class Initialized
INFO - 2021-07-29 03:26:17 --> Language Class Initialized
INFO - 2021-07-29 03:26:17 --> Config Class Initialized
INFO - 2021-07-29 03:26:17 --> Loader Class Initialized
INFO - 2021-07-29 03:26:17 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:17 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:17 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:17 --> Controller Class Initialized
INFO - 2021-07-29 03:26:19 --> Config Class Initialized
INFO - 2021-07-29 03:26:19 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:19 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:19 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:19 --> URI Class Initialized
INFO - 2021-07-29 03:26:19 --> Router Class Initialized
INFO - 2021-07-29 03:26:19 --> Output Class Initialized
INFO - 2021-07-29 03:26:19 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:19 --> Input Class Initialized
INFO - 2021-07-29 03:26:19 --> Language Class Initialized
INFO - 2021-07-29 03:26:19 --> Language Class Initialized
INFO - 2021-07-29 03:26:19 --> Config Class Initialized
INFO - 2021-07-29 03:26:19 --> Loader Class Initialized
INFO - 2021-07-29 03:26:19 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:19 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:19 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:19 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:19 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:19 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:26:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:19 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:19 --> Total execution time: 0.0677
INFO - 2021-07-29 03:26:25 --> Config Class Initialized
INFO - 2021-07-29 03:26:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:25 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:25 --> URI Class Initialized
INFO - 2021-07-29 03:26:25 --> Router Class Initialized
INFO - 2021-07-29 03:26:25 --> Output Class Initialized
INFO - 2021-07-29 03:26:25 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:25 --> Input Class Initialized
INFO - 2021-07-29 03:26:25 --> Language Class Initialized
INFO - 2021-07-29 03:26:25 --> Language Class Initialized
INFO - 2021-07-29 03:26:25 --> Config Class Initialized
INFO - 2021-07-29 03:26:25 --> Loader Class Initialized
INFO - 2021-07-29 03:26:25 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:25 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:25 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:25 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:25 --> Controller Class Initialized
INFO - 2021-07-29 03:26:25 --> Config Class Initialized
INFO - 2021-07-29 03:26:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:25 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:25 --> URI Class Initialized
INFO - 2021-07-29 03:26:25 --> Router Class Initialized
INFO - 2021-07-29 03:26:25 --> Output Class Initialized
INFO - 2021-07-29 03:26:25 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:25 --> Input Class Initialized
INFO - 2021-07-29 03:26:25 --> Language Class Initialized
INFO - 2021-07-29 03:26:25 --> Language Class Initialized
INFO - 2021-07-29 03:26:25 --> Config Class Initialized
INFO - 2021-07-29 03:26:25 --> Loader Class Initialized
INFO - 2021-07-29 03:26:25 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:25 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:25 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:25 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:26 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:26:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:26 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:26 --> Total execution time: 0.0571
INFO - 2021-07-29 03:26:28 --> Config Class Initialized
INFO - 2021-07-29 03:26:28 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:28 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:28 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:28 --> URI Class Initialized
INFO - 2021-07-29 03:26:28 --> Router Class Initialized
INFO - 2021-07-29 03:26:28 --> Output Class Initialized
INFO - 2021-07-29 03:26:28 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:28 --> Input Class Initialized
INFO - 2021-07-29 03:26:28 --> Language Class Initialized
INFO - 2021-07-29 03:26:28 --> Language Class Initialized
INFO - 2021-07-29 03:26:28 --> Config Class Initialized
INFO - 2021-07-29 03:26:28 --> Loader Class Initialized
INFO - 2021-07-29 03:26:28 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:28 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:28 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:28 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:28 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:28 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:26:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:28 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:28 --> Total execution time: 0.0680
INFO - 2021-07-29 03:26:34 --> Config Class Initialized
INFO - 2021-07-29 03:26:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:34 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:34 --> URI Class Initialized
INFO - 2021-07-29 03:26:34 --> Router Class Initialized
INFO - 2021-07-29 03:26:34 --> Output Class Initialized
INFO - 2021-07-29 03:26:34 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:34 --> Input Class Initialized
INFO - 2021-07-29 03:26:34 --> Language Class Initialized
INFO - 2021-07-29 03:26:34 --> Language Class Initialized
INFO - 2021-07-29 03:26:34 --> Config Class Initialized
INFO - 2021-07-29 03:26:34 --> Loader Class Initialized
INFO - 2021-07-29 03:26:34 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:34 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:34 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:34 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:34 --> Controller Class Initialized
INFO - 2021-07-29 03:26:35 --> Config Class Initialized
INFO - 2021-07-29 03:26:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:35 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:35 --> URI Class Initialized
INFO - 2021-07-29 03:26:35 --> Router Class Initialized
INFO - 2021-07-29 03:26:35 --> Output Class Initialized
INFO - 2021-07-29 03:26:35 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:35 --> Input Class Initialized
INFO - 2021-07-29 03:26:35 --> Language Class Initialized
INFO - 2021-07-29 03:26:35 --> Language Class Initialized
INFO - 2021-07-29 03:26:35 --> Config Class Initialized
INFO - 2021-07-29 03:26:35 --> Loader Class Initialized
INFO - 2021-07-29 03:26:35 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:35 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:35 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:35 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:35 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:35 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:35 --> Total execution time: 0.0460
INFO - 2021-07-29 03:26:35 --> Config Class Initialized
INFO - 2021-07-29 03:26:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:35 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:35 --> URI Class Initialized
INFO - 2021-07-29 03:26:35 --> Router Class Initialized
INFO - 2021-07-29 03:26:35 --> Output Class Initialized
INFO - 2021-07-29 03:26:35 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:35 --> Input Class Initialized
INFO - 2021-07-29 03:26:35 --> Language Class Initialized
INFO - 2021-07-29 03:26:35 --> Language Class Initialized
INFO - 2021-07-29 03:26:35 --> Config Class Initialized
INFO - 2021-07-29 03:26:35 --> Loader Class Initialized
INFO - 2021-07-29 03:26:35 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:35 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:35 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:35 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:35 --> Controller Class Initialized
INFO - 2021-07-29 03:26:37 --> Config Class Initialized
INFO - 2021-07-29 03:26:37 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:37 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:37 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:37 --> URI Class Initialized
INFO - 2021-07-29 03:26:37 --> Router Class Initialized
INFO - 2021-07-29 03:26:37 --> Output Class Initialized
INFO - 2021-07-29 03:26:37 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:37 --> Input Class Initialized
INFO - 2021-07-29 03:26:37 --> Language Class Initialized
INFO - 2021-07-29 03:26:37 --> Language Class Initialized
INFO - 2021-07-29 03:26:37 --> Config Class Initialized
INFO - 2021-07-29 03:26:37 --> Loader Class Initialized
INFO - 2021-07-29 03:26:37 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:37 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:37 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:37 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:37 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:37 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:37 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:37 --> Total execution time: 0.0455
INFO - 2021-07-29 03:26:42 --> Config Class Initialized
INFO - 2021-07-29 03:26:42 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:42 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:42 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:42 --> URI Class Initialized
INFO - 2021-07-29 03:26:42 --> Router Class Initialized
INFO - 2021-07-29 03:26:42 --> Output Class Initialized
INFO - 2021-07-29 03:26:42 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:42 --> Input Class Initialized
INFO - 2021-07-29 03:26:42 --> Language Class Initialized
INFO - 2021-07-29 03:26:42 --> Language Class Initialized
INFO - 2021-07-29 03:26:42 --> Config Class Initialized
INFO - 2021-07-29 03:26:42 --> Loader Class Initialized
INFO - 2021-07-29 03:26:42 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:42 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:42 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:42 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:42 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:42 --> Controller Class Initialized
INFO - 2021-07-29 03:26:42 --> Config Class Initialized
INFO - 2021-07-29 03:26:42 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:42 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:42 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:42 --> URI Class Initialized
INFO - 2021-07-29 03:26:42 --> Router Class Initialized
INFO - 2021-07-29 03:26:42 --> Output Class Initialized
INFO - 2021-07-29 03:26:42 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:42 --> Input Class Initialized
INFO - 2021-07-29 03:26:42 --> Language Class Initialized
INFO - 2021-07-29 03:26:42 --> Language Class Initialized
INFO - 2021-07-29 03:26:42 --> Config Class Initialized
INFO - 2021-07-29 03:26:42 --> Loader Class Initialized
INFO - 2021-07-29 03:26:42 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:42 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:42 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:42 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:42 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:42 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:42 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:42 --> Total execution time: 0.0692
INFO - 2021-07-29 03:26:45 --> Config Class Initialized
INFO - 2021-07-29 03:26:45 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:26:45 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:26:45 --> Utf8 Class Initialized
INFO - 2021-07-29 03:26:45 --> URI Class Initialized
INFO - 2021-07-29 03:26:45 --> Router Class Initialized
INFO - 2021-07-29 03:26:45 --> Output Class Initialized
INFO - 2021-07-29 03:26:45 --> Security Class Initialized
DEBUG - 2021-07-29 03:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:26:45 --> Input Class Initialized
INFO - 2021-07-29 03:26:45 --> Language Class Initialized
INFO - 2021-07-29 03:26:45 --> Language Class Initialized
INFO - 2021-07-29 03:26:45 --> Config Class Initialized
INFO - 2021-07-29 03:26:45 --> Loader Class Initialized
INFO - 2021-07-29 03:26:45 --> Helper loaded: url_helper
INFO - 2021-07-29 03:26:45 --> Helper loaded: file_helper
INFO - 2021-07-29 03:26:45 --> Helper loaded: form_helper
INFO - 2021-07-29 03:26:45 --> Helper loaded: my_helper
INFO - 2021-07-29 03:26:45 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:26:45 --> Controller Class Initialized
DEBUG - 2021-07-29 03:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:26:45 --> Final output sent to browser
DEBUG - 2021-07-29 03:26:45 --> Total execution time: 0.0452
INFO - 2021-07-29 03:27:12 --> Config Class Initialized
INFO - 2021-07-29 03:27:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:12 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:12 --> URI Class Initialized
INFO - 2021-07-29 03:27:12 --> Router Class Initialized
INFO - 2021-07-29 03:27:12 --> Output Class Initialized
INFO - 2021-07-29 03:27:12 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:12 --> Input Class Initialized
INFO - 2021-07-29 03:27:12 --> Language Class Initialized
INFO - 2021-07-29 03:27:12 --> Language Class Initialized
INFO - 2021-07-29 03:27:12 --> Config Class Initialized
INFO - 2021-07-29 03:27:12 --> Loader Class Initialized
INFO - 2021-07-29 03:27:12 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:12 --> Controller Class Initialized
INFO - 2021-07-29 03:27:12 --> Config Class Initialized
INFO - 2021-07-29 03:27:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:12 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:12 --> URI Class Initialized
INFO - 2021-07-29 03:27:12 --> Router Class Initialized
INFO - 2021-07-29 03:27:12 --> Output Class Initialized
INFO - 2021-07-29 03:27:12 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:12 --> Input Class Initialized
INFO - 2021-07-29 03:27:12 --> Language Class Initialized
INFO - 2021-07-29 03:27:12 --> Language Class Initialized
INFO - 2021-07-29 03:27:12 --> Config Class Initialized
INFO - 2021-07-29 03:27:12 --> Loader Class Initialized
INFO - 2021-07-29 03:27:12 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:12 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:12 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:12 --> Total execution time: 0.0633
INFO - 2021-07-29 03:27:12 --> Config Class Initialized
INFO - 2021-07-29 03:27:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:12 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:12 --> URI Class Initialized
INFO - 2021-07-29 03:27:12 --> Router Class Initialized
INFO - 2021-07-29 03:27:12 --> Output Class Initialized
INFO - 2021-07-29 03:27:12 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:12 --> Input Class Initialized
INFO - 2021-07-29 03:27:12 --> Language Class Initialized
INFO - 2021-07-29 03:27:12 --> Language Class Initialized
INFO - 2021-07-29 03:27:12 --> Config Class Initialized
INFO - 2021-07-29 03:27:12 --> Loader Class Initialized
INFO - 2021-07-29 03:27:12 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:12 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:12 --> Controller Class Initialized
INFO - 2021-07-29 03:27:14 --> Config Class Initialized
INFO - 2021-07-29 03:27:14 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:14 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:14 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:14 --> URI Class Initialized
INFO - 2021-07-29 03:27:14 --> Router Class Initialized
INFO - 2021-07-29 03:27:14 --> Output Class Initialized
INFO - 2021-07-29 03:27:14 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:14 --> Input Class Initialized
INFO - 2021-07-29 03:27:14 --> Language Class Initialized
INFO - 2021-07-29 03:27:14 --> Language Class Initialized
INFO - 2021-07-29 03:27:14 --> Config Class Initialized
INFO - 2021-07-29 03:27:14 --> Loader Class Initialized
INFO - 2021-07-29 03:27:14 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:14 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:14 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:14 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:14 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:14 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:27:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:14 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:14 --> Total execution time: 0.0622
INFO - 2021-07-29 03:27:20 --> Config Class Initialized
INFO - 2021-07-29 03:27:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:20 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:20 --> URI Class Initialized
INFO - 2021-07-29 03:27:20 --> Router Class Initialized
INFO - 2021-07-29 03:27:20 --> Output Class Initialized
INFO - 2021-07-29 03:27:20 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:20 --> Input Class Initialized
INFO - 2021-07-29 03:27:20 --> Language Class Initialized
INFO - 2021-07-29 03:27:20 --> Language Class Initialized
INFO - 2021-07-29 03:27:20 --> Config Class Initialized
INFO - 2021-07-29 03:27:20 --> Loader Class Initialized
INFO - 2021-07-29 03:27:20 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:20 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:20 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:20 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:20 --> Controller Class Initialized
INFO - 2021-07-29 03:27:20 --> Config Class Initialized
INFO - 2021-07-29 03:27:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:20 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:20 --> URI Class Initialized
INFO - 2021-07-29 03:27:20 --> Router Class Initialized
INFO - 2021-07-29 03:27:20 --> Output Class Initialized
INFO - 2021-07-29 03:27:20 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:20 --> Input Class Initialized
INFO - 2021-07-29 03:27:20 --> Language Class Initialized
INFO - 2021-07-29 03:27:20 --> Language Class Initialized
INFO - 2021-07-29 03:27:20 --> Config Class Initialized
INFO - 2021-07-29 03:27:20 --> Loader Class Initialized
INFO - 2021-07-29 03:27:20 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:20 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:20 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:20 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:20 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:27:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:20 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:20 --> Total execution time: 0.0600
INFO - 2021-07-29 03:27:23 --> Config Class Initialized
INFO - 2021-07-29 03:27:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:23 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:23 --> URI Class Initialized
INFO - 2021-07-29 03:27:23 --> Router Class Initialized
INFO - 2021-07-29 03:27:23 --> Output Class Initialized
INFO - 2021-07-29 03:27:23 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:23 --> Input Class Initialized
INFO - 2021-07-29 03:27:23 --> Language Class Initialized
INFO - 2021-07-29 03:27:23 --> Language Class Initialized
INFO - 2021-07-29 03:27:23 --> Config Class Initialized
INFO - 2021-07-29 03:27:23 --> Loader Class Initialized
INFO - 2021-07-29 03:27:23 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:23 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:23 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:23 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:23 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:27:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:23 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:23 --> Total execution time: 0.0472
INFO - 2021-07-29 03:27:34 --> Config Class Initialized
INFO - 2021-07-29 03:27:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:34 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:34 --> URI Class Initialized
INFO - 2021-07-29 03:27:34 --> Router Class Initialized
INFO - 2021-07-29 03:27:34 --> Output Class Initialized
INFO - 2021-07-29 03:27:34 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:34 --> Input Class Initialized
INFO - 2021-07-29 03:27:34 --> Language Class Initialized
INFO - 2021-07-29 03:27:34 --> Language Class Initialized
INFO - 2021-07-29 03:27:34 --> Config Class Initialized
INFO - 2021-07-29 03:27:34 --> Loader Class Initialized
INFO - 2021-07-29 03:27:34 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:34 --> Controller Class Initialized
INFO - 2021-07-29 03:27:34 --> Config Class Initialized
INFO - 2021-07-29 03:27:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:34 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:34 --> URI Class Initialized
INFO - 2021-07-29 03:27:34 --> Router Class Initialized
INFO - 2021-07-29 03:27:34 --> Output Class Initialized
INFO - 2021-07-29 03:27:34 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:34 --> Input Class Initialized
INFO - 2021-07-29 03:27:34 --> Language Class Initialized
INFO - 2021-07-29 03:27:34 --> Language Class Initialized
INFO - 2021-07-29 03:27:34 --> Config Class Initialized
INFO - 2021-07-29 03:27:34 --> Loader Class Initialized
INFO - 2021-07-29 03:27:34 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:34 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:34 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:34 --> Total execution time: 0.0500
INFO - 2021-07-29 03:27:34 --> Config Class Initialized
INFO - 2021-07-29 03:27:34 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:34 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:34 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:34 --> URI Class Initialized
INFO - 2021-07-29 03:27:34 --> Router Class Initialized
INFO - 2021-07-29 03:27:34 --> Output Class Initialized
INFO - 2021-07-29 03:27:34 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:34 --> Input Class Initialized
INFO - 2021-07-29 03:27:34 --> Language Class Initialized
INFO - 2021-07-29 03:27:34 --> Language Class Initialized
INFO - 2021-07-29 03:27:34 --> Config Class Initialized
INFO - 2021-07-29 03:27:34 --> Loader Class Initialized
INFO - 2021-07-29 03:27:34 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:34 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:34 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:34 --> Controller Class Initialized
INFO - 2021-07-29 03:27:36 --> Config Class Initialized
INFO - 2021-07-29 03:27:36 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:36 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:36 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:36 --> URI Class Initialized
INFO - 2021-07-29 03:27:36 --> Router Class Initialized
INFO - 2021-07-29 03:27:36 --> Output Class Initialized
INFO - 2021-07-29 03:27:36 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:36 --> Input Class Initialized
INFO - 2021-07-29 03:27:36 --> Language Class Initialized
INFO - 2021-07-29 03:27:36 --> Language Class Initialized
INFO - 2021-07-29 03:27:36 --> Config Class Initialized
INFO - 2021-07-29 03:27:36 --> Loader Class Initialized
INFO - 2021-07-29 03:27:36 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:36 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:36 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:36 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:36 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:36 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:36 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:36 --> Total execution time: 0.0575
INFO - 2021-07-29 03:27:40 --> Config Class Initialized
INFO - 2021-07-29 03:27:40 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:40 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:40 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:40 --> URI Class Initialized
INFO - 2021-07-29 03:27:40 --> Router Class Initialized
INFO - 2021-07-29 03:27:40 --> Output Class Initialized
INFO - 2021-07-29 03:27:40 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:40 --> Input Class Initialized
INFO - 2021-07-29 03:27:40 --> Language Class Initialized
INFO - 2021-07-29 03:27:40 --> Language Class Initialized
INFO - 2021-07-29 03:27:40 --> Config Class Initialized
INFO - 2021-07-29 03:27:40 --> Loader Class Initialized
INFO - 2021-07-29 03:27:40 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:40 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:40 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:40 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:40 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:40 --> Controller Class Initialized
INFO - 2021-07-29 03:27:40 --> Config Class Initialized
INFO - 2021-07-29 03:27:40 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:40 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:40 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:40 --> URI Class Initialized
INFO - 2021-07-29 03:27:40 --> Router Class Initialized
INFO - 2021-07-29 03:27:40 --> Output Class Initialized
INFO - 2021-07-29 03:27:40 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:40 --> Input Class Initialized
INFO - 2021-07-29 03:27:40 --> Language Class Initialized
INFO - 2021-07-29 03:27:40 --> Language Class Initialized
INFO - 2021-07-29 03:27:40 --> Config Class Initialized
INFO - 2021-07-29 03:27:40 --> Loader Class Initialized
INFO - 2021-07-29 03:27:40 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:40 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:40 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:40 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:40 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:41 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:41 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:41 --> Total execution time: 0.0699
INFO - 2021-07-29 03:27:43 --> Config Class Initialized
INFO - 2021-07-29 03:27:43 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:43 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:43 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:43 --> URI Class Initialized
INFO - 2021-07-29 03:27:43 --> Router Class Initialized
INFO - 2021-07-29 03:27:43 --> Output Class Initialized
INFO - 2021-07-29 03:27:43 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:43 --> Input Class Initialized
INFO - 2021-07-29 03:27:43 --> Language Class Initialized
INFO - 2021-07-29 03:27:43 --> Language Class Initialized
INFO - 2021-07-29 03:27:43 --> Config Class Initialized
INFO - 2021-07-29 03:27:43 --> Loader Class Initialized
INFO - 2021-07-29 03:27:43 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:43 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:43 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:43 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:43 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:43 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:43 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:43 --> Total execution time: 0.0676
INFO - 2021-07-29 03:27:47 --> Config Class Initialized
INFO - 2021-07-29 03:27:47 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:47 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:47 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:47 --> URI Class Initialized
INFO - 2021-07-29 03:27:47 --> Router Class Initialized
INFO - 2021-07-29 03:27:47 --> Output Class Initialized
INFO - 2021-07-29 03:27:47 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:47 --> Input Class Initialized
INFO - 2021-07-29 03:27:47 --> Language Class Initialized
INFO - 2021-07-29 03:27:47 --> Language Class Initialized
INFO - 2021-07-29 03:27:47 --> Config Class Initialized
INFO - 2021-07-29 03:27:47 --> Loader Class Initialized
INFO - 2021-07-29 03:27:47 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:47 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:47 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:47 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:47 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:47 --> Controller Class Initialized
INFO - 2021-07-29 03:27:47 --> Config Class Initialized
INFO - 2021-07-29 03:27:47 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:47 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:47 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:47 --> URI Class Initialized
INFO - 2021-07-29 03:27:47 --> Router Class Initialized
INFO - 2021-07-29 03:27:47 --> Output Class Initialized
INFO - 2021-07-29 03:27:47 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:47 --> Input Class Initialized
INFO - 2021-07-29 03:27:47 --> Language Class Initialized
INFO - 2021-07-29 03:27:47 --> Language Class Initialized
INFO - 2021-07-29 03:27:47 --> Config Class Initialized
INFO - 2021-07-29 03:27:47 --> Loader Class Initialized
INFO - 2021-07-29 03:27:47 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:47 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:47 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:47 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:47 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:47 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:27:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:47 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:47 --> Total execution time: 0.0678
INFO - 2021-07-29 03:27:47 --> Config Class Initialized
INFO - 2021-07-29 03:27:47 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:47 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:47 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:47 --> URI Class Initialized
INFO - 2021-07-29 03:27:47 --> Router Class Initialized
INFO - 2021-07-29 03:27:47 --> Output Class Initialized
INFO - 2021-07-29 03:27:47 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:47 --> Input Class Initialized
INFO - 2021-07-29 03:27:47 --> Language Class Initialized
INFO - 2021-07-29 03:27:48 --> Language Class Initialized
INFO - 2021-07-29 03:27:48 --> Config Class Initialized
INFO - 2021-07-29 03:27:48 --> Loader Class Initialized
INFO - 2021-07-29 03:27:48 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:48 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:48 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:48 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:48 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:48 --> Controller Class Initialized
INFO - 2021-07-29 03:27:49 --> Config Class Initialized
INFO - 2021-07-29 03:27:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:49 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:49 --> URI Class Initialized
INFO - 2021-07-29 03:27:49 --> Router Class Initialized
INFO - 2021-07-29 03:27:49 --> Output Class Initialized
INFO - 2021-07-29 03:27:49 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:49 --> Input Class Initialized
INFO - 2021-07-29 03:27:49 --> Language Class Initialized
INFO - 2021-07-29 03:27:49 --> Language Class Initialized
INFO - 2021-07-29 03:27:49 --> Config Class Initialized
INFO - 2021-07-29 03:27:49 --> Loader Class Initialized
INFO - 2021-07-29 03:27:49 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:49 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:49 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:49 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:49 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:27:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:49 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:49 --> Total execution time: 0.0640
INFO - 2021-07-29 03:27:54 --> Config Class Initialized
INFO - 2021-07-29 03:27:54 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:54 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:54 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:54 --> URI Class Initialized
INFO - 2021-07-29 03:27:54 --> Router Class Initialized
INFO - 2021-07-29 03:27:54 --> Output Class Initialized
INFO - 2021-07-29 03:27:54 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:54 --> Input Class Initialized
INFO - 2021-07-29 03:27:54 --> Language Class Initialized
INFO - 2021-07-29 03:27:54 --> Language Class Initialized
INFO - 2021-07-29 03:27:54 --> Config Class Initialized
INFO - 2021-07-29 03:27:54 --> Loader Class Initialized
INFO - 2021-07-29 03:27:54 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:54 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:54 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:54 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:54 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:54 --> Controller Class Initialized
INFO - 2021-07-29 03:27:54 --> Config Class Initialized
INFO - 2021-07-29 03:27:54 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:54 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:54 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:54 --> URI Class Initialized
INFO - 2021-07-29 03:27:54 --> Router Class Initialized
INFO - 2021-07-29 03:27:54 --> Output Class Initialized
INFO - 2021-07-29 03:27:54 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:54 --> Input Class Initialized
INFO - 2021-07-29 03:27:54 --> Language Class Initialized
INFO - 2021-07-29 03:27:54 --> Language Class Initialized
INFO - 2021-07-29 03:27:54 --> Config Class Initialized
INFO - 2021-07-29 03:27:54 --> Loader Class Initialized
INFO - 2021-07-29 03:27:54 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:54 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:54 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:54 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:54 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:54 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:54 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:54 --> Total execution time: 0.0647
INFO - 2021-07-29 03:27:59 --> Config Class Initialized
INFO - 2021-07-29 03:27:59 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:27:59 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:27:59 --> Utf8 Class Initialized
INFO - 2021-07-29 03:27:59 --> URI Class Initialized
INFO - 2021-07-29 03:27:59 --> Router Class Initialized
INFO - 2021-07-29 03:27:59 --> Output Class Initialized
INFO - 2021-07-29 03:27:59 --> Security Class Initialized
DEBUG - 2021-07-29 03:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:27:59 --> Input Class Initialized
INFO - 2021-07-29 03:27:59 --> Language Class Initialized
INFO - 2021-07-29 03:27:59 --> Language Class Initialized
INFO - 2021-07-29 03:27:59 --> Config Class Initialized
INFO - 2021-07-29 03:27:59 --> Loader Class Initialized
INFO - 2021-07-29 03:27:59 --> Helper loaded: url_helper
INFO - 2021-07-29 03:27:59 --> Helper loaded: file_helper
INFO - 2021-07-29 03:27:59 --> Helper loaded: form_helper
INFO - 2021-07-29 03:27:59 --> Helper loaded: my_helper
INFO - 2021-07-29 03:27:59 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:27:59 --> Controller Class Initialized
DEBUG - 2021-07-29 03:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:27:59 --> Final output sent to browser
DEBUG - 2021-07-29 03:27:59 --> Total execution time: 0.0661
INFO - 2021-07-29 03:28:05 --> Config Class Initialized
INFO - 2021-07-29 03:28:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:05 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:05 --> URI Class Initialized
INFO - 2021-07-29 03:28:05 --> Router Class Initialized
INFO - 2021-07-29 03:28:05 --> Output Class Initialized
INFO - 2021-07-29 03:28:05 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:05 --> Input Class Initialized
INFO - 2021-07-29 03:28:05 --> Language Class Initialized
INFO - 2021-07-29 03:28:05 --> Language Class Initialized
INFO - 2021-07-29 03:28:05 --> Config Class Initialized
INFO - 2021-07-29 03:28:05 --> Loader Class Initialized
INFO - 2021-07-29 03:28:05 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:05 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:05 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:05 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:06 --> Controller Class Initialized
INFO - 2021-07-29 03:28:06 --> Config Class Initialized
INFO - 2021-07-29 03:28:06 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:06 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:06 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:06 --> URI Class Initialized
INFO - 2021-07-29 03:28:06 --> Router Class Initialized
INFO - 2021-07-29 03:28:06 --> Output Class Initialized
INFO - 2021-07-29 03:28:06 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:06 --> Input Class Initialized
INFO - 2021-07-29 03:28:06 --> Language Class Initialized
INFO - 2021-07-29 03:28:06 --> Language Class Initialized
INFO - 2021-07-29 03:28:06 --> Config Class Initialized
INFO - 2021-07-29 03:28:06 --> Loader Class Initialized
INFO - 2021-07-29 03:28:06 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:06 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:06 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:06 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:06 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:06 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:06 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:06 --> Total execution time: 0.0644
INFO - 2021-07-29 03:28:06 --> Config Class Initialized
INFO - 2021-07-29 03:28:06 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:06 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:06 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:06 --> URI Class Initialized
INFO - 2021-07-29 03:28:06 --> Router Class Initialized
INFO - 2021-07-29 03:28:06 --> Output Class Initialized
INFO - 2021-07-29 03:28:06 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:06 --> Input Class Initialized
INFO - 2021-07-29 03:28:06 --> Language Class Initialized
INFO - 2021-07-29 03:28:06 --> Language Class Initialized
INFO - 2021-07-29 03:28:06 --> Config Class Initialized
INFO - 2021-07-29 03:28:06 --> Loader Class Initialized
INFO - 2021-07-29 03:28:06 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:06 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:06 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:06 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:06 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:06 --> Controller Class Initialized
INFO - 2021-07-29 03:28:07 --> Config Class Initialized
INFO - 2021-07-29 03:28:07 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:07 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:07 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:07 --> URI Class Initialized
INFO - 2021-07-29 03:28:07 --> Router Class Initialized
INFO - 2021-07-29 03:28:07 --> Output Class Initialized
INFO - 2021-07-29 03:28:07 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:07 --> Input Class Initialized
INFO - 2021-07-29 03:28:07 --> Language Class Initialized
INFO - 2021-07-29 03:28:07 --> Language Class Initialized
INFO - 2021-07-29 03:28:07 --> Config Class Initialized
INFO - 2021-07-29 03:28:07 --> Loader Class Initialized
INFO - 2021-07-29 03:28:07 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:07 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:07 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:07 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:07 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:07 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:28:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:07 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:07 --> Total execution time: 0.0693
INFO - 2021-07-29 03:28:13 --> Config Class Initialized
INFO - 2021-07-29 03:28:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:13 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:13 --> URI Class Initialized
INFO - 2021-07-29 03:28:13 --> Router Class Initialized
INFO - 2021-07-29 03:28:13 --> Output Class Initialized
INFO - 2021-07-29 03:28:13 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:13 --> Input Class Initialized
INFO - 2021-07-29 03:28:13 --> Language Class Initialized
INFO - 2021-07-29 03:28:13 --> Language Class Initialized
INFO - 2021-07-29 03:28:13 --> Config Class Initialized
INFO - 2021-07-29 03:28:13 --> Loader Class Initialized
INFO - 2021-07-29 03:28:13 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:13 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:13 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:13 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:13 --> Controller Class Initialized
INFO - 2021-07-29 03:28:13 --> Config Class Initialized
INFO - 2021-07-29 03:28:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:13 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:13 --> URI Class Initialized
INFO - 2021-07-29 03:28:13 --> Router Class Initialized
INFO - 2021-07-29 03:28:13 --> Output Class Initialized
INFO - 2021-07-29 03:28:13 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:13 --> Input Class Initialized
INFO - 2021-07-29 03:28:13 --> Language Class Initialized
INFO - 2021-07-29 03:28:13 --> Language Class Initialized
INFO - 2021-07-29 03:28:13 --> Config Class Initialized
INFO - 2021-07-29 03:28:13 --> Loader Class Initialized
INFO - 2021-07-29 03:28:13 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:13 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:13 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:13 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:13 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:28:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:13 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:13 --> Total execution time: 0.0637
INFO - 2021-07-29 03:28:14 --> Config Class Initialized
INFO - 2021-07-29 03:28:14 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:14 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:14 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:14 --> URI Class Initialized
INFO - 2021-07-29 03:28:14 --> Router Class Initialized
INFO - 2021-07-29 03:28:14 --> Output Class Initialized
INFO - 2021-07-29 03:28:14 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:14 --> Input Class Initialized
INFO - 2021-07-29 03:28:14 --> Language Class Initialized
INFO - 2021-07-29 03:28:14 --> Language Class Initialized
INFO - 2021-07-29 03:28:14 --> Config Class Initialized
INFO - 2021-07-29 03:28:14 --> Loader Class Initialized
INFO - 2021-07-29 03:28:14 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:14 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:14 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:14 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:14 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:14 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:14 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:14 --> Total execution time: 0.0659
INFO - 2021-07-29 03:28:19 --> Config Class Initialized
INFO - 2021-07-29 03:28:19 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:19 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:19 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:19 --> URI Class Initialized
INFO - 2021-07-29 03:28:19 --> Router Class Initialized
INFO - 2021-07-29 03:28:19 --> Output Class Initialized
INFO - 2021-07-29 03:28:19 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:19 --> Input Class Initialized
INFO - 2021-07-29 03:28:19 --> Language Class Initialized
INFO - 2021-07-29 03:28:19 --> Language Class Initialized
INFO - 2021-07-29 03:28:19 --> Config Class Initialized
INFO - 2021-07-29 03:28:19 --> Loader Class Initialized
INFO - 2021-07-29 03:28:19 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:19 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:19 --> Controller Class Initialized
INFO - 2021-07-29 03:28:19 --> Config Class Initialized
INFO - 2021-07-29 03:28:19 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:19 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:19 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:19 --> URI Class Initialized
INFO - 2021-07-29 03:28:19 --> Router Class Initialized
INFO - 2021-07-29 03:28:19 --> Output Class Initialized
INFO - 2021-07-29 03:28:19 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:19 --> Input Class Initialized
INFO - 2021-07-29 03:28:19 --> Language Class Initialized
INFO - 2021-07-29 03:28:19 --> Language Class Initialized
INFO - 2021-07-29 03:28:19 --> Config Class Initialized
INFO - 2021-07-29 03:28:19 --> Loader Class Initialized
INFO - 2021-07-29 03:28:19 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:19 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:19 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:19 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:19 --> Total execution time: 0.0473
INFO - 2021-07-29 03:28:19 --> Config Class Initialized
INFO - 2021-07-29 03:28:19 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:19 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:19 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:19 --> URI Class Initialized
INFO - 2021-07-29 03:28:19 --> Router Class Initialized
INFO - 2021-07-29 03:28:19 --> Output Class Initialized
INFO - 2021-07-29 03:28:19 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:19 --> Input Class Initialized
INFO - 2021-07-29 03:28:19 --> Language Class Initialized
INFO - 2021-07-29 03:28:19 --> Language Class Initialized
INFO - 2021-07-29 03:28:19 --> Config Class Initialized
INFO - 2021-07-29 03:28:19 --> Loader Class Initialized
INFO - 2021-07-29 03:28:19 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:19 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:19 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:19 --> Controller Class Initialized
INFO - 2021-07-29 03:28:20 --> Config Class Initialized
INFO - 2021-07-29 03:28:20 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:20 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:20 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:20 --> URI Class Initialized
INFO - 2021-07-29 03:28:20 --> Router Class Initialized
INFO - 2021-07-29 03:28:20 --> Output Class Initialized
INFO - 2021-07-29 03:28:20 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:20 --> Input Class Initialized
INFO - 2021-07-29 03:28:20 --> Language Class Initialized
INFO - 2021-07-29 03:28:20 --> Language Class Initialized
INFO - 2021-07-29 03:28:20 --> Config Class Initialized
INFO - 2021-07-29 03:28:20 --> Loader Class Initialized
INFO - 2021-07-29 03:28:20 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:20 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:20 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:20 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:20 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:20 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:20 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:20 --> Total execution time: 0.0555
INFO - 2021-07-29 03:28:26 --> Config Class Initialized
INFO - 2021-07-29 03:28:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:26 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:26 --> URI Class Initialized
INFO - 2021-07-29 03:28:26 --> Router Class Initialized
INFO - 2021-07-29 03:28:26 --> Output Class Initialized
INFO - 2021-07-29 03:28:26 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:26 --> Input Class Initialized
INFO - 2021-07-29 03:28:26 --> Language Class Initialized
INFO - 2021-07-29 03:28:26 --> Language Class Initialized
INFO - 2021-07-29 03:28:26 --> Config Class Initialized
INFO - 2021-07-29 03:28:26 --> Loader Class Initialized
INFO - 2021-07-29 03:28:26 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:26 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:26 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:26 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:26 --> Controller Class Initialized
INFO - 2021-07-29 03:28:26 --> Config Class Initialized
INFO - 2021-07-29 03:28:26 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:26 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:26 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:26 --> URI Class Initialized
INFO - 2021-07-29 03:28:26 --> Router Class Initialized
INFO - 2021-07-29 03:28:26 --> Output Class Initialized
INFO - 2021-07-29 03:28:26 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:26 --> Input Class Initialized
INFO - 2021-07-29 03:28:26 --> Language Class Initialized
INFO - 2021-07-29 03:28:26 --> Language Class Initialized
INFO - 2021-07-29 03:28:26 --> Config Class Initialized
INFO - 2021-07-29 03:28:26 --> Loader Class Initialized
INFO - 2021-07-29 03:28:26 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:26 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:26 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:26 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:26 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:26 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:26 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:26 --> Total execution time: 0.0628
INFO - 2021-07-29 03:28:28 --> Config Class Initialized
INFO - 2021-07-29 03:28:28 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:28 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:28 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:28 --> URI Class Initialized
INFO - 2021-07-29 03:28:28 --> Router Class Initialized
INFO - 2021-07-29 03:28:28 --> Output Class Initialized
INFO - 2021-07-29 03:28:28 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:28 --> Input Class Initialized
INFO - 2021-07-29 03:28:28 --> Language Class Initialized
INFO - 2021-07-29 03:28:28 --> Language Class Initialized
INFO - 2021-07-29 03:28:28 --> Config Class Initialized
INFO - 2021-07-29 03:28:28 --> Loader Class Initialized
INFO - 2021-07-29 03:28:28 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:28 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:28 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:28 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:28 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:28 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-07-29 03:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:28 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:28 --> Total execution time: 0.0465
INFO - 2021-07-29 03:28:32 --> Config Class Initialized
INFO - 2021-07-29 03:28:32 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:32 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:32 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:32 --> URI Class Initialized
INFO - 2021-07-29 03:28:32 --> Router Class Initialized
INFO - 2021-07-29 03:28:32 --> Output Class Initialized
INFO - 2021-07-29 03:28:32 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:32 --> Input Class Initialized
INFO - 2021-07-29 03:28:32 --> Language Class Initialized
INFO - 2021-07-29 03:28:32 --> Language Class Initialized
INFO - 2021-07-29 03:28:32 --> Config Class Initialized
INFO - 2021-07-29 03:28:32 --> Loader Class Initialized
INFO - 2021-07-29 03:28:32 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:32 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:32 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:32 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:32 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:32 --> Controller Class Initialized
INFO - 2021-07-29 03:28:32 --> Config Class Initialized
INFO - 2021-07-29 03:28:32 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:32 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:32 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:32 --> URI Class Initialized
INFO - 2021-07-29 03:28:32 --> Router Class Initialized
INFO - 2021-07-29 03:28:32 --> Output Class Initialized
INFO - 2021-07-29 03:28:32 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:32 --> Input Class Initialized
INFO - 2021-07-29 03:28:32 --> Language Class Initialized
INFO - 2021-07-29 03:28:32 --> Language Class Initialized
INFO - 2021-07-29 03:28:32 --> Config Class Initialized
INFO - 2021-07-29 03:28:32 --> Loader Class Initialized
INFO - 2021-07-29 03:28:32 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:32 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:32 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:32 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:32 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:33 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-29 03:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:33 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:33 --> Total execution time: 0.0594
INFO - 2021-07-29 03:28:33 --> Config Class Initialized
INFO - 2021-07-29 03:28:33 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:33 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:33 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:33 --> URI Class Initialized
INFO - 2021-07-29 03:28:33 --> Router Class Initialized
INFO - 2021-07-29 03:28:33 --> Output Class Initialized
INFO - 2021-07-29 03:28:33 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:33 --> Input Class Initialized
INFO - 2021-07-29 03:28:33 --> Language Class Initialized
INFO - 2021-07-29 03:28:33 --> Language Class Initialized
INFO - 2021-07-29 03:28:33 --> Config Class Initialized
INFO - 2021-07-29 03:28:33 --> Loader Class Initialized
INFO - 2021-07-29 03:28:33 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:33 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:33 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:33 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:33 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:33 --> Controller Class Initialized
INFO - 2021-07-29 03:28:35 --> Config Class Initialized
INFO - 2021-07-29 03:28:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:35 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:35 --> URI Class Initialized
INFO - 2021-07-29 03:28:35 --> Router Class Initialized
INFO - 2021-07-29 03:28:35 --> Output Class Initialized
INFO - 2021-07-29 03:28:35 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:35 --> Input Class Initialized
INFO - 2021-07-29 03:28:35 --> Language Class Initialized
INFO - 2021-07-29 03:28:35 --> Language Class Initialized
INFO - 2021-07-29 03:28:35 --> Config Class Initialized
INFO - 2021-07-29 03:28:35 --> Loader Class Initialized
INFO - 2021-07-29 03:28:35 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:35 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:35 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:35 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:35 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-07-29 03:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:35 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:35 --> Total execution time: 0.0681
INFO - 2021-07-29 03:28:41 --> Config Class Initialized
INFO - 2021-07-29 03:28:41 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:41 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:41 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:41 --> URI Class Initialized
INFO - 2021-07-29 03:28:41 --> Router Class Initialized
INFO - 2021-07-29 03:28:41 --> Output Class Initialized
INFO - 2021-07-29 03:28:41 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:41 --> Input Class Initialized
INFO - 2021-07-29 03:28:41 --> Language Class Initialized
INFO - 2021-07-29 03:28:41 --> Language Class Initialized
INFO - 2021-07-29 03:28:41 --> Config Class Initialized
INFO - 2021-07-29 03:28:41 --> Loader Class Initialized
INFO - 2021-07-29 03:28:41 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:41 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:41 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:41 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:41 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:41 --> Controller Class Initialized
INFO - 2021-07-29 03:28:41 --> Config Class Initialized
INFO - 2021-07-29 03:28:41 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:41 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:41 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:41 --> URI Class Initialized
INFO - 2021-07-29 03:28:41 --> Router Class Initialized
INFO - 2021-07-29 03:28:41 --> Output Class Initialized
INFO - 2021-07-29 03:28:41 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:41 --> Input Class Initialized
INFO - 2021-07-29 03:28:41 --> Language Class Initialized
INFO - 2021-07-29 03:28:41 --> Language Class Initialized
INFO - 2021-07-29 03:28:41 --> Config Class Initialized
INFO - 2021-07-29 03:28:41 --> Loader Class Initialized
INFO - 2021-07-29 03:28:41 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:41 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:41 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:41 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:41 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:41 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-29 03:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:41 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:41 --> Total execution time: 0.0636
INFO - 2021-07-29 03:28:45 --> Config Class Initialized
INFO - 2021-07-29 03:28:45 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:45 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:45 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:45 --> URI Class Initialized
INFO - 2021-07-29 03:28:45 --> Router Class Initialized
INFO - 2021-07-29 03:28:45 --> Output Class Initialized
INFO - 2021-07-29 03:28:45 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:45 --> Input Class Initialized
INFO - 2021-07-29 03:28:45 --> Language Class Initialized
INFO - 2021-07-29 03:28:45 --> Language Class Initialized
INFO - 2021-07-29 03:28:45 --> Config Class Initialized
INFO - 2021-07-29 03:28:45 --> Loader Class Initialized
INFO - 2021-07-29 03:28:45 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:45 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:45 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:45 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:45 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:45 --> Controller Class Initialized
INFO - 2021-07-29 03:28:45 --> Helper loaded: cookie_helper
INFO - 2021-07-29 03:28:45 --> Config Class Initialized
INFO - 2021-07-29 03:28:45 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:45 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:45 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:45 --> URI Class Initialized
INFO - 2021-07-29 03:28:45 --> Router Class Initialized
INFO - 2021-07-29 03:28:45 --> Output Class Initialized
INFO - 2021-07-29 03:28:45 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:45 --> Input Class Initialized
INFO - 2021-07-29 03:28:45 --> Language Class Initialized
INFO - 2021-07-29 03:28:45 --> Language Class Initialized
INFO - 2021-07-29 03:28:45 --> Config Class Initialized
INFO - 2021-07-29 03:28:45 --> Loader Class Initialized
INFO - 2021-07-29 03:28:45 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:45 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:45 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:45 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:45 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:45 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-29 03:28:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:45 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:45 --> Total execution time: 0.0530
INFO - 2021-07-29 03:28:49 --> Config Class Initialized
INFO - 2021-07-29 03:28:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:49 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:49 --> URI Class Initialized
INFO - 2021-07-29 03:28:49 --> Router Class Initialized
INFO - 2021-07-29 03:28:49 --> Output Class Initialized
INFO - 2021-07-29 03:28:49 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:49 --> Input Class Initialized
INFO - 2021-07-29 03:28:49 --> Language Class Initialized
INFO - 2021-07-29 03:28:49 --> Language Class Initialized
INFO - 2021-07-29 03:28:49 --> Config Class Initialized
INFO - 2021-07-29 03:28:49 --> Loader Class Initialized
INFO - 2021-07-29 03:28:49 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:49 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:49 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:49 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:49 --> Controller Class Initialized
INFO - 2021-07-29 03:28:49 --> Helper loaded: cookie_helper
INFO - 2021-07-29 03:28:49 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:49 --> Total execution time: 0.0545
INFO - 2021-07-29 03:28:49 --> Config Class Initialized
INFO - 2021-07-29 03:28:49 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:49 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:49 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:49 --> URI Class Initialized
INFO - 2021-07-29 03:28:49 --> Router Class Initialized
INFO - 2021-07-29 03:28:49 --> Output Class Initialized
INFO - 2021-07-29 03:28:49 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:49 --> Input Class Initialized
INFO - 2021-07-29 03:28:49 --> Language Class Initialized
INFO - 2021-07-29 03:28:49 --> Language Class Initialized
INFO - 2021-07-29 03:28:49 --> Config Class Initialized
INFO - 2021-07-29 03:28:49 --> Loader Class Initialized
INFO - 2021-07-29 03:28:49 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:49 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:49 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:49 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:49 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:49 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-29 03:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:49 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:49 --> Total execution time: 0.1078
INFO - 2021-07-29 03:28:51 --> Config Class Initialized
INFO - 2021-07-29 03:28:51 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:51 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:51 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:51 --> URI Class Initialized
INFO - 2021-07-29 03:28:51 --> Router Class Initialized
INFO - 2021-07-29 03:28:51 --> Output Class Initialized
INFO - 2021-07-29 03:28:51 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:51 --> Input Class Initialized
INFO - 2021-07-29 03:28:51 --> Language Class Initialized
INFO - 2021-07-29 03:28:51 --> Language Class Initialized
INFO - 2021-07-29 03:28:51 --> Config Class Initialized
INFO - 2021-07-29 03:28:51 --> Loader Class Initialized
INFO - 2021-07-29 03:28:51 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:51 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:51 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:51 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:51 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:51 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-29 03:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:28:51 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:51 --> Total execution time: 0.0530
INFO - 2021-07-29 03:28:57 --> Config Class Initialized
INFO - 2021-07-29 03:28:57 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:28:57 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:28:57 --> Utf8 Class Initialized
INFO - 2021-07-29 03:28:57 --> URI Class Initialized
INFO - 2021-07-29 03:28:57 --> Router Class Initialized
INFO - 2021-07-29 03:28:57 --> Output Class Initialized
INFO - 2021-07-29 03:28:57 --> Security Class Initialized
DEBUG - 2021-07-29 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:28:57 --> Input Class Initialized
INFO - 2021-07-29 03:28:57 --> Language Class Initialized
INFO - 2021-07-29 03:28:57 --> Language Class Initialized
INFO - 2021-07-29 03:28:57 --> Config Class Initialized
INFO - 2021-07-29 03:28:57 --> Loader Class Initialized
INFO - 2021-07-29 03:28:57 --> Helper loaded: url_helper
INFO - 2021-07-29 03:28:57 --> Helper loaded: file_helper
INFO - 2021-07-29 03:28:57 --> Helper loaded: form_helper
INFO - 2021-07-29 03:28:57 --> Helper loaded: my_helper
INFO - 2021-07-29 03:28:57 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:28:57 --> Controller Class Initialized
DEBUG - 2021-07-29 03:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-07-29 03:28:57 --> Final output sent to browser
DEBUG - 2021-07-29 03:28:57 --> Total execution time: 0.0928
INFO - 2021-07-29 03:29:12 --> Config Class Initialized
INFO - 2021-07-29 03:29:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:12 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:12 --> URI Class Initialized
INFO - 2021-07-29 03:29:12 --> Router Class Initialized
INFO - 2021-07-29 03:29:12 --> Output Class Initialized
INFO - 2021-07-29 03:29:12 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:12 --> Input Class Initialized
INFO - 2021-07-29 03:29:12 --> Language Class Initialized
INFO - 2021-07-29 03:29:12 --> Language Class Initialized
INFO - 2021-07-29 03:29:12 --> Config Class Initialized
INFO - 2021-07-29 03:29:12 --> Loader Class Initialized
INFO - 2021-07-29 03:29:12 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:12 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:12 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:12 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:12 --> Controller Class Initialized
DEBUG - 2021-07-29 03:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-07-29 03:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:29:12 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:12 --> Total execution time: 0.1245
INFO - 2021-07-29 03:29:13 --> Config Class Initialized
INFO - 2021-07-29 03:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:13 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:13 --> URI Class Initialized
INFO - 2021-07-29 03:29:13 --> Router Class Initialized
INFO - 2021-07-29 03:29:13 --> Output Class Initialized
INFO - 2021-07-29 03:29:13 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:13 --> Input Class Initialized
INFO - 2021-07-29 03:29:13 --> Language Class Initialized
INFO - 2021-07-29 03:29:13 --> Language Class Initialized
INFO - 2021-07-29 03:29:13 --> Config Class Initialized
INFO - 2021-07-29 03:29:13 --> Loader Class Initialized
INFO - 2021-07-29 03:29:13 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:13 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:13 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:13 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:13 --> Controller Class Initialized
DEBUG - 2021-07-29 03:29:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-07-29 03:29:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:29:13 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:13 --> Total execution time: 0.1728
INFO - 2021-07-29 03:29:15 --> Config Class Initialized
INFO - 2021-07-29 03:29:15 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:15 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:15 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:15 --> URI Class Initialized
INFO - 2021-07-29 03:29:15 --> Router Class Initialized
INFO - 2021-07-29 03:29:15 --> Output Class Initialized
INFO - 2021-07-29 03:29:15 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:15 --> Input Class Initialized
INFO - 2021-07-29 03:29:15 --> Language Class Initialized
INFO - 2021-07-29 03:29:15 --> Language Class Initialized
INFO - 2021-07-29 03:29:15 --> Config Class Initialized
INFO - 2021-07-29 03:29:15 --> Loader Class Initialized
INFO - 2021-07-29 03:29:15 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:15 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:15 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:15 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:15 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:15 --> Controller Class Initialized
DEBUG - 2021-07-29 03:29:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-07-29 03:29:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:29:15 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:15 --> Total execution time: 0.0884
INFO - 2021-07-29 03:29:16 --> Config Class Initialized
INFO - 2021-07-29 03:29:16 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:16 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:16 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:16 --> URI Class Initialized
INFO - 2021-07-29 03:29:16 --> Router Class Initialized
INFO - 2021-07-29 03:29:16 --> Output Class Initialized
INFO - 2021-07-29 03:29:16 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:16 --> Input Class Initialized
INFO - 2021-07-29 03:29:16 --> Language Class Initialized
INFO - 2021-07-29 03:29:16 --> Language Class Initialized
INFO - 2021-07-29 03:29:16 --> Config Class Initialized
INFO - 2021-07-29 03:29:16 --> Loader Class Initialized
INFO - 2021-07-29 03:29:16 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:16 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:16 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:16 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:16 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:16 --> Controller Class Initialized
DEBUG - 2021-07-29 03:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-07-29 03:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:29:16 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:16 --> Total execution time: 0.1065
INFO - 2021-07-29 03:29:17 --> Config Class Initialized
INFO - 2021-07-29 03:29:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:17 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:17 --> URI Class Initialized
INFO - 2021-07-29 03:29:17 --> Router Class Initialized
INFO - 2021-07-29 03:29:17 --> Output Class Initialized
INFO - 2021-07-29 03:29:17 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:17 --> Input Class Initialized
INFO - 2021-07-29 03:29:17 --> Language Class Initialized
INFO - 2021-07-29 03:29:17 --> Language Class Initialized
INFO - 2021-07-29 03:29:17 --> Config Class Initialized
INFO - 2021-07-29 03:29:17 --> Loader Class Initialized
INFO - 2021-07-29 03:29:17 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:17 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:17 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:17 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:17 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:17 --> Controller Class Initialized
DEBUG - 2021-07-29 03:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-29 03:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:29:17 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:17 --> Total execution time: 0.0794
INFO - 2021-07-29 03:29:17 --> Config Class Initialized
INFO - 2021-07-29 03:29:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:17 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:17 --> URI Class Initialized
INFO - 2021-07-29 03:29:17 --> Router Class Initialized
INFO - 2021-07-29 03:29:17 --> Output Class Initialized
INFO - 2021-07-29 03:29:17 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:17 --> Input Class Initialized
INFO - 2021-07-29 03:29:17 --> Language Class Initialized
INFO - 2021-07-29 03:29:17 --> Language Class Initialized
INFO - 2021-07-29 03:29:17 --> Config Class Initialized
INFO - 2021-07-29 03:29:17 --> Loader Class Initialized
INFO - 2021-07-29 03:29:17 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:17 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:17 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:17 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:17 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:17 --> Controller Class Initialized
DEBUG - 2021-07-29 03:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-29 03:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:29:17 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:17 --> Total execution time: 0.1173
INFO - 2021-07-29 03:29:31 --> Config Class Initialized
INFO - 2021-07-29 03:29:31 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:31 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:31 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:31 --> URI Class Initialized
INFO - 2021-07-29 03:29:31 --> Router Class Initialized
INFO - 2021-07-29 03:29:31 --> Output Class Initialized
INFO - 2021-07-29 03:29:31 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:31 --> Input Class Initialized
INFO - 2021-07-29 03:29:31 --> Language Class Initialized
INFO - 2021-07-29 03:29:31 --> Language Class Initialized
INFO - 2021-07-29 03:29:31 --> Config Class Initialized
INFO - 2021-07-29 03:29:31 --> Loader Class Initialized
INFO - 2021-07-29 03:29:31 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:31 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:31 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:31 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:31 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:31 --> Controller Class Initialized
INFO - 2021-07-29 03:29:31 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:31 --> Total execution time: 0.1035
INFO - 2021-07-29 03:29:35 --> Config Class Initialized
INFO - 2021-07-29 03:29:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:35 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:35 --> URI Class Initialized
INFO - 2021-07-29 03:29:35 --> Router Class Initialized
INFO - 2021-07-29 03:29:35 --> Output Class Initialized
INFO - 2021-07-29 03:29:35 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:35 --> Input Class Initialized
INFO - 2021-07-29 03:29:35 --> Language Class Initialized
INFO - 2021-07-29 03:29:35 --> Language Class Initialized
INFO - 2021-07-29 03:29:35 --> Config Class Initialized
INFO - 2021-07-29 03:29:35 --> Loader Class Initialized
INFO - 2021-07-29 03:29:35 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:35 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:35 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:35 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:35 --> Controller Class Initialized
DEBUG - 2021-07-29 03:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-07-29 03:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:29:35 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:35 --> Total execution time: 0.0582
INFO - 2021-07-29 03:29:36 --> Config Class Initialized
INFO - 2021-07-29 03:29:36 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:36 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:36 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:36 --> URI Class Initialized
INFO - 2021-07-29 03:29:36 --> Router Class Initialized
INFO - 2021-07-29 03:29:36 --> Output Class Initialized
INFO - 2021-07-29 03:29:36 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:36 --> Input Class Initialized
INFO - 2021-07-29 03:29:36 --> Language Class Initialized
INFO - 2021-07-29 03:29:36 --> Language Class Initialized
INFO - 2021-07-29 03:29:36 --> Config Class Initialized
INFO - 2021-07-29 03:29:36 --> Loader Class Initialized
INFO - 2021-07-29 03:29:36 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:36 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:36 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:36 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:36 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:36 --> Controller Class Initialized
INFO - 2021-07-29 03:29:36 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:36 --> Total execution time: 0.0719
INFO - 2021-07-29 03:29:47 --> Config Class Initialized
INFO - 2021-07-29 03:29:47 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:29:47 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:29:47 --> Utf8 Class Initialized
INFO - 2021-07-29 03:29:47 --> URI Class Initialized
INFO - 2021-07-29 03:29:47 --> Router Class Initialized
INFO - 2021-07-29 03:29:47 --> Output Class Initialized
INFO - 2021-07-29 03:29:47 --> Security Class Initialized
DEBUG - 2021-07-29 03:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:29:47 --> Input Class Initialized
INFO - 2021-07-29 03:29:47 --> Language Class Initialized
INFO - 2021-07-29 03:29:47 --> Language Class Initialized
INFO - 2021-07-29 03:29:47 --> Config Class Initialized
INFO - 2021-07-29 03:29:47 --> Loader Class Initialized
INFO - 2021-07-29 03:29:47 --> Helper loaded: url_helper
INFO - 2021-07-29 03:29:47 --> Helper loaded: file_helper
INFO - 2021-07-29 03:29:47 --> Helper loaded: form_helper
INFO - 2021-07-29 03:29:47 --> Helper loaded: my_helper
INFO - 2021-07-29 03:29:47 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:29:47 --> Controller Class Initialized
INFO - 2021-07-29 03:29:47 --> Final output sent to browser
DEBUG - 2021-07-29 03:29:47 --> Total execution time: 0.1189
INFO - 2021-07-29 03:30:12 --> Config Class Initialized
INFO - 2021-07-29 03:30:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:30:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:30:12 --> Utf8 Class Initialized
INFO - 2021-07-29 03:30:12 --> URI Class Initialized
INFO - 2021-07-29 03:30:12 --> Router Class Initialized
INFO - 2021-07-29 03:30:12 --> Output Class Initialized
INFO - 2021-07-29 03:30:12 --> Security Class Initialized
DEBUG - 2021-07-29 03:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:30:12 --> Input Class Initialized
INFO - 2021-07-29 03:30:12 --> Language Class Initialized
INFO - 2021-07-29 03:30:12 --> Language Class Initialized
INFO - 2021-07-29 03:30:12 --> Config Class Initialized
INFO - 2021-07-29 03:30:12 --> Loader Class Initialized
INFO - 2021-07-29 03:30:12 --> Helper loaded: url_helper
INFO - 2021-07-29 03:30:12 --> Helper loaded: file_helper
INFO - 2021-07-29 03:30:12 --> Helper loaded: form_helper
INFO - 2021-07-29 03:30:12 --> Helper loaded: my_helper
INFO - 2021-07-29 03:30:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:30:12 --> Controller Class Initialized
DEBUG - 2021-07-29 03:30:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-07-29 03:30:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:30:12 --> Final output sent to browser
DEBUG - 2021-07-29 03:30:12 --> Total execution time: 0.0661
INFO - 2021-07-29 03:30:56 --> Config Class Initialized
INFO - 2021-07-29 03:30:56 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:30:56 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:30:56 --> Utf8 Class Initialized
INFO - 2021-07-29 03:30:56 --> URI Class Initialized
INFO - 2021-07-29 03:30:56 --> Router Class Initialized
INFO - 2021-07-29 03:30:56 --> Output Class Initialized
INFO - 2021-07-29 03:30:56 --> Security Class Initialized
DEBUG - 2021-07-29 03:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:30:56 --> Input Class Initialized
INFO - 2021-07-29 03:30:56 --> Language Class Initialized
INFO - 2021-07-29 03:30:56 --> Language Class Initialized
INFO - 2021-07-29 03:30:56 --> Config Class Initialized
INFO - 2021-07-29 03:30:56 --> Loader Class Initialized
INFO - 2021-07-29 03:30:56 --> Helper loaded: url_helper
INFO - 2021-07-29 03:30:56 --> Helper loaded: file_helper
INFO - 2021-07-29 03:30:56 --> Helper loaded: form_helper
INFO - 2021-07-29 03:30:56 --> Helper loaded: my_helper
INFO - 2021-07-29 03:30:56 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:30:56 --> Controller Class Initialized
INFO - 2021-07-29 03:30:56 --> Final output sent to browser
DEBUG - 2021-07-29 03:30:56 --> Total execution time: 0.0873
INFO - 2021-07-29 03:31:05 --> Config Class Initialized
INFO - 2021-07-29 03:31:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:31:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:31:05 --> Utf8 Class Initialized
INFO - 2021-07-29 03:31:05 --> URI Class Initialized
INFO - 2021-07-29 03:31:05 --> Router Class Initialized
INFO - 2021-07-29 03:31:05 --> Output Class Initialized
INFO - 2021-07-29 03:31:05 --> Security Class Initialized
DEBUG - 2021-07-29 03:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:31:05 --> Input Class Initialized
INFO - 2021-07-29 03:31:05 --> Language Class Initialized
INFO - 2021-07-29 03:31:05 --> Language Class Initialized
INFO - 2021-07-29 03:31:05 --> Config Class Initialized
INFO - 2021-07-29 03:31:05 --> Loader Class Initialized
INFO - 2021-07-29 03:31:05 --> Helper loaded: url_helper
INFO - 2021-07-29 03:31:05 --> Helper loaded: file_helper
INFO - 2021-07-29 03:31:05 --> Helper loaded: form_helper
INFO - 2021-07-29 03:31:05 --> Helper loaded: my_helper
INFO - 2021-07-29 03:31:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:31:05 --> Controller Class Initialized
DEBUG - 2021-07-29 03:31:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-07-29 03:31:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:31:05 --> Final output sent to browser
DEBUG - 2021-07-29 03:31:05 --> Total execution time: 0.0901
INFO - 2021-07-29 03:31:33 --> Config Class Initialized
INFO - 2021-07-29 03:31:33 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:31:33 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:31:33 --> Utf8 Class Initialized
INFO - 2021-07-29 03:31:33 --> URI Class Initialized
INFO - 2021-07-29 03:31:33 --> Router Class Initialized
INFO - 2021-07-29 03:31:33 --> Output Class Initialized
INFO - 2021-07-29 03:31:33 --> Security Class Initialized
DEBUG - 2021-07-29 03:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:31:33 --> Input Class Initialized
INFO - 2021-07-29 03:31:33 --> Language Class Initialized
INFO - 2021-07-29 03:31:33 --> Language Class Initialized
INFO - 2021-07-29 03:31:33 --> Config Class Initialized
INFO - 2021-07-29 03:31:33 --> Loader Class Initialized
INFO - 2021-07-29 03:31:33 --> Helper loaded: url_helper
INFO - 2021-07-29 03:31:33 --> Helper loaded: file_helper
INFO - 2021-07-29 03:31:33 --> Helper loaded: form_helper
INFO - 2021-07-29 03:31:33 --> Helper loaded: my_helper
INFO - 2021-07-29 03:31:33 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:31:33 --> Controller Class Initialized
INFO - 2021-07-29 03:31:33 --> Final output sent to browser
DEBUG - 2021-07-29 03:31:33 --> Total execution time: 0.0833
INFO - 2021-07-29 03:31:35 --> Config Class Initialized
INFO - 2021-07-29 03:31:35 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:31:35 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:31:35 --> Utf8 Class Initialized
INFO - 2021-07-29 03:31:35 --> URI Class Initialized
INFO - 2021-07-29 03:31:35 --> Router Class Initialized
INFO - 2021-07-29 03:31:35 --> Output Class Initialized
INFO - 2021-07-29 03:31:35 --> Security Class Initialized
DEBUG - 2021-07-29 03:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:31:35 --> Input Class Initialized
INFO - 2021-07-29 03:31:35 --> Language Class Initialized
INFO - 2021-07-29 03:31:35 --> Language Class Initialized
INFO - 2021-07-29 03:31:35 --> Config Class Initialized
INFO - 2021-07-29 03:31:35 --> Loader Class Initialized
INFO - 2021-07-29 03:31:35 --> Helper loaded: url_helper
INFO - 2021-07-29 03:31:35 --> Helper loaded: file_helper
INFO - 2021-07-29 03:31:35 --> Helper loaded: form_helper
INFO - 2021-07-29 03:31:35 --> Helper loaded: my_helper
INFO - 2021-07-29 03:31:35 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:31:35 --> Controller Class Initialized
DEBUG - 2021-07-29 03:31:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-07-29 03:31:35 --> Final output sent to browser
DEBUG - 2021-07-29 03:31:35 --> Total execution time: 0.0863
INFO - 2021-07-29 03:32:05 --> Config Class Initialized
INFO - 2021-07-29 03:32:05 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:32:05 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:32:05 --> Utf8 Class Initialized
INFO - 2021-07-29 03:32:05 --> URI Class Initialized
INFO - 2021-07-29 03:32:05 --> Router Class Initialized
INFO - 2021-07-29 03:32:05 --> Output Class Initialized
INFO - 2021-07-29 03:32:05 --> Security Class Initialized
DEBUG - 2021-07-29 03:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:32:05 --> Input Class Initialized
INFO - 2021-07-29 03:32:05 --> Language Class Initialized
INFO - 2021-07-29 03:32:05 --> Language Class Initialized
INFO - 2021-07-29 03:32:05 --> Config Class Initialized
INFO - 2021-07-29 03:32:05 --> Loader Class Initialized
INFO - 2021-07-29 03:32:05 --> Helper loaded: url_helper
INFO - 2021-07-29 03:32:05 --> Helper loaded: file_helper
INFO - 2021-07-29 03:32:05 --> Helper loaded: form_helper
INFO - 2021-07-29 03:32:05 --> Helper loaded: my_helper
INFO - 2021-07-29 03:32:05 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:32:05 --> Controller Class Initialized
DEBUG - 2021-07-29 03:32:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-29 03:32:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-29 03:32:05 --> Final output sent to browser
DEBUG - 2021-07-29 03:32:05 --> Total execution time: 0.0727
INFO - 2021-07-29 03:32:12 --> Config Class Initialized
INFO - 2021-07-29 03:32:12 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:32:12 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:32:12 --> Utf8 Class Initialized
INFO - 2021-07-29 03:32:12 --> URI Class Initialized
INFO - 2021-07-29 03:32:12 --> Router Class Initialized
INFO - 2021-07-29 03:32:12 --> Output Class Initialized
INFO - 2021-07-29 03:32:12 --> Security Class Initialized
DEBUG - 2021-07-29 03:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:32:12 --> Input Class Initialized
INFO - 2021-07-29 03:32:12 --> Language Class Initialized
INFO - 2021-07-29 03:32:12 --> Language Class Initialized
INFO - 2021-07-29 03:32:12 --> Config Class Initialized
INFO - 2021-07-29 03:32:12 --> Loader Class Initialized
INFO - 2021-07-29 03:32:12 --> Helper loaded: url_helper
INFO - 2021-07-29 03:32:12 --> Helper loaded: file_helper
INFO - 2021-07-29 03:32:12 --> Helper loaded: form_helper
INFO - 2021-07-29 03:32:12 --> Helper loaded: my_helper
INFO - 2021-07-29 03:32:12 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:32:12 --> Controller Class Initialized
DEBUG - 2021-07-29 03:32:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-07-29 03:32:12 --> Final output sent to browser
DEBUG - 2021-07-29 03:32:12 --> Total execution time: 0.0597
INFO - 2021-07-29 03:32:13 --> Config Class Initialized
INFO - 2021-07-29 03:32:13 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:32:13 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:32:13 --> Utf8 Class Initialized
INFO - 2021-07-29 03:32:13 --> URI Class Initialized
INFO - 2021-07-29 03:32:13 --> Router Class Initialized
INFO - 2021-07-29 03:32:13 --> Output Class Initialized
INFO - 2021-07-29 03:32:13 --> Security Class Initialized
DEBUG - 2021-07-29 03:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:32:13 --> Input Class Initialized
INFO - 2021-07-29 03:32:13 --> Language Class Initialized
INFO - 2021-07-29 03:32:13 --> Language Class Initialized
INFO - 2021-07-29 03:32:13 --> Config Class Initialized
INFO - 2021-07-29 03:32:13 --> Loader Class Initialized
INFO - 2021-07-29 03:32:13 --> Helper loaded: url_helper
INFO - 2021-07-29 03:32:13 --> Helper loaded: file_helper
INFO - 2021-07-29 03:32:13 --> Helper loaded: form_helper
INFO - 2021-07-29 03:32:13 --> Helper loaded: my_helper
INFO - 2021-07-29 03:32:13 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:32:13 --> Controller Class Initialized
DEBUG - 2021-07-29 03:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-07-29 03:32:13 --> Final output sent to browser
DEBUG - 2021-07-29 03:32:13 --> Total execution time: 0.0577
INFO - 2021-07-29 03:32:14 --> Config Class Initialized
INFO - 2021-07-29 03:32:14 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:32:14 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:32:14 --> Utf8 Class Initialized
INFO - 2021-07-29 03:32:14 --> URI Class Initialized
INFO - 2021-07-29 03:32:14 --> Router Class Initialized
INFO - 2021-07-29 03:32:14 --> Output Class Initialized
INFO - 2021-07-29 03:32:14 --> Security Class Initialized
DEBUG - 2021-07-29 03:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:32:14 --> Input Class Initialized
INFO - 2021-07-29 03:32:14 --> Language Class Initialized
INFO - 2021-07-29 03:32:14 --> Language Class Initialized
INFO - 2021-07-29 03:32:14 --> Config Class Initialized
INFO - 2021-07-29 03:32:14 --> Loader Class Initialized
INFO - 2021-07-29 03:32:14 --> Helper loaded: url_helper
INFO - 2021-07-29 03:32:14 --> Helper loaded: file_helper
INFO - 2021-07-29 03:32:14 --> Helper loaded: form_helper
INFO - 2021-07-29 03:32:14 --> Helper loaded: my_helper
INFO - 2021-07-29 03:32:14 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:32:14 --> Controller Class Initialized
DEBUG - 2021-07-29 03:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-07-29 03:32:15 --> Final output sent to browser
DEBUG - 2021-07-29 03:32:15 --> Total execution time: 0.0673
INFO - 2021-07-29 03:45:39 --> Config Class Initialized
INFO - 2021-07-29 03:45:39 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:45:39 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:45:39 --> Utf8 Class Initialized
INFO - 2021-07-29 03:45:39 --> URI Class Initialized
INFO - 2021-07-29 03:45:39 --> Router Class Initialized
INFO - 2021-07-29 03:45:39 --> Output Class Initialized
INFO - 2021-07-29 03:45:39 --> Security Class Initialized
DEBUG - 2021-07-29 03:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:45:39 --> Input Class Initialized
INFO - 2021-07-29 03:45:39 --> Language Class Initialized
INFO - 2021-07-29 03:45:39 --> Language Class Initialized
INFO - 2021-07-29 03:45:39 --> Config Class Initialized
INFO - 2021-07-29 03:45:39 --> Loader Class Initialized
INFO - 2021-07-29 03:45:39 --> Helper loaded: url_helper
INFO - 2021-07-29 03:45:39 --> Helper loaded: file_helper
INFO - 2021-07-29 03:45:39 --> Helper loaded: form_helper
INFO - 2021-07-29 03:45:39 --> Helper loaded: my_helper
INFO - 2021-07-29 03:45:39 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:45:39 --> Controller Class Initialized
DEBUG - 2021-07-29 03:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-07-29 03:45:39 --> Final output sent to browser
DEBUG - 2021-07-29 03:45:39 --> Total execution time: 0.0481
INFO - 2021-07-29 03:46:03 --> Config Class Initialized
INFO - 2021-07-29 03:46:03 --> Hooks Class Initialized
DEBUG - 2021-07-29 03:46:03 --> UTF-8 Support Enabled
INFO - 2021-07-29 03:46:03 --> Utf8 Class Initialized
INFO - 2021-07-29 03:46:03 --> URI Class Initialized
INFO - 2021-07-29 03:46:03 --> Router Class Initialized
INFO - 2021-07-29 03:46:03 --> Output Class Initialized
INFO - 2021-07-29 03:46:03 --> Security Class Initialized
DEBUG - 2021-07-29 03:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 03:46:03 --> Input Class Initialized
INFO - 2021-07-29 03:46:03 --> Language Class Initialized
INFO - 2021-07-29 03:46:03 --> Language Class Initialized
INFO - 2021-07-29 03:46:03 --> Config Class Initialized
INFO - 2021-07-29 03:46:03 --> Loader Class Initialized
INFO - 2021-07-29 03:46:03 --> Helper loaded: url_helper
INFO - 2021-07-29 03:46:03 --> Helper loaded: file_helper
INFO - 2021-07-29 03:46:03 --> Helper loaded: form_helper
INFO - 2021-07-29 03:46:03 --> Helper loaded: my_helper
INFO - 2021-07-29 03:46:03 --> Database Driver Class Initialized
DEBUG - 2021-07-29 03:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 03:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 03:46:03 --> Controller Class Initialized
DEBUG - 2021-07-29 03:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-07-29 03:46:03 --> Final output sent to browser
DEBUG - 2021-07-29 03:46:03 --> Total execution time: 0.0616
