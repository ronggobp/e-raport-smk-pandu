<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-14 05:27:40 --> Config Class Initialized
INFO - 2022-06-14 05:27:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:27:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:27:40 --> Utf8 Class Initialized
INFO - 2022-06-14 05:27:40 --> URI Class Initialized
DEBUG - 2022-06-14 05:27:40 --> No URI present. Default controller set.
INFO - 2022-06-14 05:27:40 --> Router Class Initialized
INFO - 2022-06-14 05:27:40 --> Output Class Initialized
INFO - 2022-06-14 05:27:40 --> Security Class Initialized
DEBUG - 2022-06-14 05:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:27:40 --> Input Class Initialized
INFO - 2022-06-14 05:27:40 --> Language Class Initialized
INFO - 2022-06-14 05:27:40 --> Language Class Initialized
INFO - 2022-06-14 05:27:40 --> Config Class Initialized
INFO - 2022-06-14 05:27:40 --> Loader Class Initialized
INFO - 2022-06-14 05:27:40 --> Helper loaded: url_helper
INFO - 2022-06-14 05:27:40 --> Helper loaded: file_helper
INFO - 2022-06-14 05:27:40 --> Helper loaded: form_helper
INFO - 2022-06-14 05:27:40 --> Helper loaded: my_helper
INFO - 2022-06-14 05:27:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:27:40 --> Controller Class Initialized
INFO - 2022-06-14 05:27:41 --> Config Class Initialized
INFO - 2022-06-14 05:27:41 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:27:41 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:27:41 --> Utf8 Class Initialized
INFO - 2022-06-14 05:27:41 --> URI Class Initialized
INFO - 2022-06-14 05:27:41 --> Router Class Initialized
INFO - 2022-06-14 05:27:41 --> Output Class Initialized
INFO - 2022-06-14 05:27:41 --> Security Class Initialized
DEBUG - 2022-06-14 05:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:27:41 --> Input Class Initialized
INFO - 2022-06-14 05:27:41 --> Language Class Initialized
INFO - 2022-06-14 05:27:41 --> Language Class Initialized
INFO - 2022-06-14 05:27:41 --> Config Class Initialized
INFO - 2022-06-14 05:27:41 --> Loader Class Initialized
INFO - 2022-06-14 05:27:41 --> Helper loaded: url_helper
INFO - 2022-06-14 05:27:41 --> Helper loaded: file_helper
INFO - 2022-06-14 05:27:41 --> Helper loaded: form_helper
INFO - 2022-06-14 05:27:41 --> Helper loaded: my_helper
INFO - 2022-06-14 05:27:41 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:27:41 --> Controller Class Initialized
DEBUG - 2022-06-14 05:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 05:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 05:27:41 --> Final output sent to browser
DEBUG - 2022-06-14 05:27:41 --> Total execution time: 0.0986
INFO - 2022-06-14 05:27:46 --> Config Class Initialized
INFO - 2022-06-14 05:27:46 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:27:46 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:27:46 --> Utf8 Class Initialized
INFO - 2022-06-14 05:27:46 --> URI Class Initialized
INFO - 2022-06-14 05:27:46 --> Router Class Initialized
INFO - 2022-06-14 05:27:46 --> Output Class Initialized
INFO - 2022-06-14 05:27:46 --> Security Class Initialized
DEBUG - 2022-06-14 05:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:27:46 --> Input Class Initialized
INFO - 2022-06-14 05:27:46 --> Language Class Initialized
INFO - 2022-06-14 05:27:46 --> Language Class Initialized
INFO - 2022-06-14 05:27:46 --> Config Class Initialized
INFO - 2022-06-14 05:27:46 --> Loader Class Initialized
INFO - 2022-06-14 05:27:46 --> Helper loaded: url_helper
INFO - 2022-06-14 05:27:46 --> Helper loaded: file_helper
INFO - 2022-06-14 05:27:46 --> Helper loaded: form_helper
INFO - 2022-06-14 05:27:46 --> Helper loaded: my_helper
INFO - 2022-06-14 05:27:46 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:27:46 --> Controller Class Initialized
INFO - 2022-06-14 05:27:46 --> Helper loaded: cookie_helper
INFO - 2022-06-14 05:27:46 --> Final output sent to browser
DEBUG - 2022-06-14 05:27:46 --> Total execution time: 0.1116
INFO - 2022-06-14 05:27:46 --> Config Class Initialized
INFO - 2022-06-14 05:27:46 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:27:46 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:27:46 --> Utf8 Class Initialized
INFO - 2022-06-14 05:27:46 --> URI Class Initialized
INFO - 2022-06-14 05:27:46 --> Router Class Initialized
INFO - 2022-06-14 05:27:46 --> Output Class Initialized
INFO - 2022-06-14 05:27:46 --> Security Class Initialized
DEBUG - 2022-06-14 05:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:27:46 --> Input Class Initialized
INFO - 2022-06-14 05:27:46 --> Language Class Initialized
INFO - 2022-06-14 05:27:46 --> Language Class Initialized
INFO - 2022-06-14 05:27:46 --> Config Class Initialized
INFO - 2022-06-14 05:27:46 --> Loader Class Initialized
INFO - 2022-06-14 05:27:46 --> Helper loaded: url_helper
INFO - 2022-06-14 05:27:46 --> Helper loaded: file_helper
INFO - 2022-06-14 05:27:46 --> Helper loaded: form_helper
INFO - 2022-06-14 05:27:46 --> Helper loaded: my_helper
INFO - 2022-06-14 05:27:46 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:27:46 --> Controller Class Initialized
DEBUG - 2022-06-14 05:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 05:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 05:27:46 --> Final output sent to browser
DEBUG - 2022-06-14 05:27:46 --> Total execution time: 0.0923
INFO - 2022-06-14 05:28:22 --> Config Class Initialized
INFO - 2022-06-14 05:28:22 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:22 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:22 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:22 --> URI Class Initialized
INFO - 2022-06-14 05:28:22 --> Router Class Initialized
INFO - 2022-06-14 05:28:22 --> Output Class Initialized
INFO - 2022-06-14 05:28:22 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:22 --> Input Class Initialized
INFO - 2022-06-14 05:28:22 --> Language Class Initialized
INFO - 2022-06-14 05:28:22 --> Language Class Initialized
INFO - 2022-06-14 05:28:22 --> Config Class Initialized
INFO - 2022-06-14 05:28:22 --> Loader Class Initialized
INFO - 2022-06-14 05:28:22 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:22 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:22 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:22 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:22 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:22 --> Controller Class Initialized
DEBUG - 2022-06-14 05:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 05:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 05:28:22 --> Final output sent to browser
DEBUG - 2022-06-14 05:28:22 --> Total execution time: 0.0708
INFO - 2022-06-14 05:28:27 --> Config Class Initialized
INFO - 2022-06-14 05:28:27 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:27 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:27 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:27 --> URI Class Initialized
INFO - 2022-06-14 05:28:27 --> Router Class Initialized
INFO - 2022-06-14 05:28:27 --> Output Class Initialized
INFO - 2022-06-14 05:28:27 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:27 --> Input Class Initialized
INFO - 2022-06-14 05:28:27 --> Language Class Initialized
INFO - 2022-06-14 05:28:27 --> Language Class Initialized
INFO - 2022-06-14 05:28:27 --> Config Class Initialized
INFO - 2022-06-14 05:28:27 --> Loader Class Initialized
INFO - 2022-06-14 05:28:27 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:27 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:27 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:27 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:27 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:27 --> Controller Class Initialized
DEBUG - 2022-06-14 05:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 05:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 05:28:27 --> Final output sent to browser
DEBUG - 2022-06-14 05:28:27 --> Total execution time: 0.0898
INFO - 2022-06-14 05:28:27 --> Config Class Initialized
INFO - 2022-06-14 05:28:27 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:27 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:27 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:27 --> URI Class Initialized
INFO - 2022-06-14 05:28:27 --> Router Class Initialized
INFO - 2022-06-14 05:28:27 --> Output Class Initialized
INFO - 2022-06-14 05:28:27 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:27 --> Input Class Initialized
INFO - 2022-06-14 05:28:27 --> Language Class Initialized
INFO - 2022-06-14 05:28:27 --> Language Class Initialized
INFO - 2022-06-14 05:28:27 --> Config Class Initialized
INFO - 2022-06-14 05:28:27 --> Loader Class Initialized
INFO - 2022-06-14 05:28:27 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:27 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:27 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:27 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:27 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:27 --> Controller Class Initialized
INFO - 2022-06-14 05:28:28 --> Config Class Initialized
INFO - 2022-06-14 05:28:28 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:28 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:28 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:28 --> URI Class Initialized
INFO - 2022-06-14 05:28:28 --> Router Class Initialized
INFO - 2022-06-14 05:28:28 --> Output Class Initialized
INFO - 2022-06-14 05:28:28 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:28 --> Input Class Initialized
INFO - 2022-06-14 05:28:28 --> Language Class Initialized
INFO - 2022-06-14 05:28:28 --> Language Class Initialized
INFO - 2022-06-14 05:28:28 --> Config Class Initialized
INFO - 2022-06-14 05:28:28 --> Loader Class Initialized
INFO - 2022-06-14 05:28:28 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:28 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:28 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:28 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:28 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:28 --> Controller Class Initialized
DEBUG - 2022-06-14 05:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 05:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 05:28:29 --> Final output sent to browser
DEBUG - 2022-06-14 05:28:29 --> Total execution time: 0.1001
INFO - 2022-06-14 05:28:30 --> Config Class Initialized
INFO - 2022-06-14 05:28:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:30 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:30 --> URI Class Initialized
INFO - 2022-06-14 05:28:30 --> Router Class Initialized
INFO - 2022-06-14 05:28:30 --> Output Class Initialized
INFO - 2022-06-14 05:28:30 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:30 --> Input Class Initialized
INFO - 2022-06-14 05:28:30 --> Language Class Initialized
INFO - 2022-06-14 05:28:30 --> Language Class Initialized
INFO - 2022-06-14 05:28:30 --> Config Class Initialized
INFO - 2022-06-14 05:28:30 --> Loader Class Initialized
INFO - 2022-06-14 05:28:30 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:30 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:30 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:30 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:30 --> Controller Class Initialized
DEBUG - 2022-06-14 05:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 05:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 05:28:30 --> Final output sent to browser
DEBUG - 2022-06-14 05:28:30 --> Total execution time: 0.0463
INFO - 2022-06-14 05:28:30 --> Config Class Initialized
INFO - 2022-06-14 05:28:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:30 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:30 --> URI Class Initialized
INFO - 2022-06-14 05:28:30 --> Router Class Initialized
INFO - 2022-06-14 05:28:30 --> Output Class Initialized
INFO - 2022-06-14 05:28:30 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:30 --> Input Class Initialized
INFO - 2022-06-14 05:28:30 --> Language Class Initialized
INFO - 2022-06-14 05:28:30 --> Language Class Initialized
INFO - 2022-06-14 05:28:30 --> Config Class Initialized
INFO - 2022-06-14 05:28:30 --> Loader Class Initialized
INFO - 2022-06-14 05:28:30 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:30 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:30 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:30 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:31 --> Controller Class Initialized
INFO - 2022-06-14 05:28:32 --> Config Class Initialized
INFO - 2022-06-14 05:28:32 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:32 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:32 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:32 --> URI Class Initialized
INFO - 2022-06-14 05:28:32 --> Router Class Initialized
INFO - 2022-06-14 05:28:32 --> Output Class Initialized
INFO - 2022-06-14 05:28:32 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:32 --> Input Class Initialized
INFO - 2022-06-14 05:28:32 --> Language Class Initialized
INFO - 2022-06-14 05:28:32 --> Language Class Initialized
INFO - 2022-06-14 05:28:32 --> Config Class Initialized
INFO - 2022-06-14 05:28:32 --> Loader Class Initialized
INFO - 2022-06-14 05:28:32 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:32 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:32 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:32 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:32 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:32 --> Controller Class Initialized
DEBUG - 2022-06-14 05:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 05:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 05:28:32 --> Final output sent to browser
DEBUG - 2022-06-14 05:28:32 --> Total execution time: 0.0477
INFO - 2022-06-14 05:28:43 --> Config Class Initialized
INFO - 2022-06-14 05:28:43 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:43 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:43 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:43 --> URI Class Initialized
INFO - 2022-06-14 05:28:43 --> Router Class Initialized
INFO - 2022-06-14 05:28:43 --> Output Class Initialized
INFO - 2022-06-14 05:28:43 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:43 --> Input Class Initialized
INFO - 2022-06-14 05:28:43 --> Language Class Initialized
INFO - 2022-06-14 05:28:43 --> Language Class Initialized
INFO - 2022-06-14 05:28:43 --> Config Class Initialized
INFO - 2022-06-14 05:28:43 --> Loader Class Initialized
INFO - 2022-06-14 05:28:43 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:43 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:43 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:43 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:43 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:43 --> Controller Class Initialized
INFO - 2022-06-14 05:28:44 --> Config Class Initialized
INFO - 2022-06-14 05:28:44 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:44 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:44 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:44 --> URI Class Initialized
INFO - 2022-06-14 05:28:44 --> Router Class Initialized
INFO - 2022-06-14 05:28:44 --> Output Class Initialized
INFO - 2022-06-14 05:28:44 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:44 --> Input Class Initialized
INFO - 2022-06-14 05:28:44 --> Language Class Initialized
INFO - 2022-06-14 05:28:44 --> Language Class Initialized
INFO - 2022-06-14 05:28:44 --> Config Class Initialized
INFO - 2022-06-14 05:28:44 --> Loader Class Initialized
INFO - 2022-06-14 05:28:44 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:44 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:44 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:44 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:44 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:44 --> Controller Class Initialized
INFO - 2022-06-14 05:28:45 --> Config Class Initialized
INFO - 2022-06-14 05:28:45 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:45 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:45 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:45 --> URI Class Initialized
INFO - 2022-06-14 05:28:45 --> Router Class Initialized
INFO - 2022-06-14 05:28:45 --> Output Class Initialized
INFO - 2022-06-14 05:28:45 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:45 --> Input Class Initialized
INFO - 2022-06-14 05:28:45 --> Language Class Initialized
INFO - 2022-06-14 05:28:45 --> Language Class Initialized
INFO - 2022-06-14 05:28:45 --> Config Class Initialized
INFO - 2022-06-14 05:28:45 --> Loader Class Initialized
INFO - 2022-06-14 05:28:45 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:45 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:45 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:45 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:45 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:45 --> Controller Class Initialized
INFO - 2022-06-14 05:28:47 --> Config Class Initialized
INFO - 2022-06-14 05:28:47 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:47 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:47 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:47 --> URI Class Initialized
INFO - 2022-06-14 05:28:47 --> Router Class Initialized
INFO - 2022-06-14 05:28:47 --> Output Class Initialized
INFO - 2022-06-14 05:28:47 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:47 --> Input Class Initialized
INFO - 2022-06-14 05:28:47 --> Language Class Initialized
INFO - 2022-06-14 05:28:47 --> Language Class Initialized
INFO - 2022-06-14 05:28:47 --> Config Class Initialized
INFO - 2022-06-14 05:28:47 --> Loader Class Initialized
INFO - 2022-06-14 05:28:47 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:47 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:47 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:47 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:47 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:47 --> Controller Class Initialized
INFO - 2022-06-14 05:28:53 --> Config Class Initialized
INFO - 2022-06-14 05:28:53 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:53 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:53 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:53 --> URI Class Initialized
INFO - 2022-06-14 05:28:53 --> Router Class Initialized
INFO - 2022-06-14 05:28:53 --> Output Class Initialized
INFO - 2022-06-14 05:28:53 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:53 --> Input Class Initialized
INFO - 2022-06-14 05:28:53 --> Language Class Initialized
INFO - 2022-06-14 05:28:53 --> Language Class Initialized
INFO - 2022-06-14 05:28:53 --> Config Class Initialized
INFO - 2022-06-14 05:28:53 --> Loader Class Initialized
INFO - 2022-06-14 05:28:53 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:53 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:53 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:53 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:53 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:53 --> Controller Class Initialized
INFO - 2022-06-14 05:28:53 --> Helper loaded: cookie_helper
INFO - 2022-06-14 05:28:53 --> Config Class Initialized
INFO - 2022-06-14 05:28:53 --> Hooks Class Initialized
DEBUG - 2022-06-14 05:28:53 --> UTF-8 Support Enabled
INFO - 2022-06-14 05:28:53 --> Utf8 Class Initialized
INFO - 2022-06-14 05:28:53 --> URI Class Initialized
INFO - 2022-06-14 05:28:53 --> Router Class Initialized
INFO - 2022-06-14 05:28:53 --> Output Class Initialized
INFO - 2022-06-14 05:28:53 --> Security Class Initialized
DEBUG - 2022-06-14 05:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 05:28:53 --> Input Class Initialized
INFO - 2022-06-14 05:28:53 --> Language Class Initialized
INFO - 2022-06-14 05:28:53 --> Language Class Initialized
INFO - 2022-06-14 05:28:53 --> Config Class Initialized
INFO - 2022-06-14 05:28:53 --> Loader Class Initialized
INFO - 2022-06-14 05:28:53 --> Helper loaded: url_helper
INFO - 2022-06-14 05:28:53 --> Helper loaded: file_helper
INFO - 2022-06-14 05:28:53 --> Helper loaded: form_helper
INFO - 2022-06-14 05:28:53 --> Helper loaded: my_helper
INFO - 2022-06-14 05:28:53 --> Database Driver Class Initialized
DEBUG - 2022-06-14 05:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 05:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 05:28:53 --> Controller Class Initialized
DEBUG - 2022-06-14 05:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 05:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 05:28:53 --> Final output sent to browser
DEBUG - 2022-06-14 05:28:53 --> Total execution time: 0.0484
INFO - 2022-06-14 06:17:09 --> Config Class Initialized
INFO - 2022-06-14 06:17:09 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:09 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:09 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:09 --> URI Class Initialized
DEBUG - 2022-06-14 06:17:09 --> No URI present. Default controller set.
INFO - 2022-06-14 06:17:09 --> Router Class Initialized
INFO - 2022-06-14 06:17:09 --> Output Class Initialized
INFO - 2022-06-14 06:17:09 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:09 --> Input Class Initialized
INFO - 2022-06-14 06:17:09 --> Language Class Initialized
INFO - 2022-06-14 06:17:09 --> Language Class Initialized
INFO - 2022-06-14 06:17:09 --> Config Class Initialized
INFO - 2022-06-14 06:17:09 --> Loader Class Initialized
INFO - 2022-06-14 06:17:09 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:09 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:09 --> Controller Class Initialized
INFO - 2022-06-14 06:17:09 --> Config Class Initialized
INFO - 2022-06-14 06:17:09 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:09 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:09 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:09 --> URI Class Initialized
INFO - 2022-06-14 06:17:09 --> Config Class Initialized
DEBUG - 2022-06-14 06:17:09 --> No URI present. Default controller set.
INFO - 2022-06-14 06:17:09 --> Hooks Class Initialized
INFO - 2022-06-14 06:17:09 --> Router Class Initialized
INFO - 2022-06-14 06:17:09 --> Output Class Initialized
DEBUG - 2022-06-14 06:17:09 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:09 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:09 --> Security Class Initialized
INFO - 2022-06-14 06:17:09 --> URI Class Initialized
DEBUG - 2022-06-14 06:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:09 --> Input Class Initialized
INFO - 2022-06-14 06:17:09 --> Language Class Initialized
INFO - 2022-06-14 06:17:09 --> Router Class Initialized
INFO - 2022-06-14 06:17:09 --> Output Class Initialized
INFO - 2022-06-14 06:17:09 --> Language Class Initialized
INFO - 2022-06-14 06:17:09 --> Config Class Initialized
INFO - 2022-06-14 06:17:09 --> Security Class Initialized
INFO - 2022-06-14 06:17:09 --> Loader Class Initialized
DEBUG - 2022-06-14 06:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:09 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:09 --> Input Class Initialized
INFO - 2022-06-14 06:17:09 --> Language Class Initialized
INFO - 2022-06-14 06:17:09 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:09 --> Language Class Initialized
INFO - 2022-06-14 06:17:09 --> Config Class Initialized
INFO - 2022-06-14 06:17:09 --> Loader Class Initialized
INFO - 2022-06-14 06:17:09 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:09 --> Database Driver Class Initialized
INFO - 2022-06-14 06:17:09 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: my_helper
DEBUG - 2022-06-14 06:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:09 --> Controller Class Initialized
INFO - 2022-06-14 06:17:09 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:09 --> Controller Class Initialized
DEBUG - 2022-06-14 06:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 06:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:17:09 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:09 --> Total execution time: 0.0500
INFO - 2022-06-14 06:17:09 --> Config Class Initialized
INFO - 2022-06-14 06:17:09 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:09 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:09 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:09 --> URI Class Initialized
INFO - 2022-06-14 06:17:09 --> Router Class Initialized
INFO - 2022-06-14 06:17:09 --> Output Class Initialized
INFO - 2022-06-14 06:17:09 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:09 --> Input Class Initialized
INFO - 2022-06-14 06:17:09 --> Language Class Initialized
INFO - 2022-06-14 06:17:09 --> Language Class Initialized
INFO - 2022-06-14 06:17:09 --> Config Class Initialized
INFO - 2022-06-14 06:17:09 --> Loader Class Initialized
INFO - 2022-06-14 06:17:09 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:09 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:09 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:09 --> Controller Class Initialized
DEBUG - 2022-06-14 06:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 06:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:17:09 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:09 --> Total execution time: 0.0448
INFO - 2022-06-14 06:17:16 --> Config Class Initialized
INFO - 2022-06-14 06:17:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:16 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:16 --> URI Class Initialized
INFO - 2022-06-14 06:17:16 --> Router Class Initialized
INFO - 2022-06-14 06:17:16 --> Output Class Initialized
INFO - 2022-06-14 06:17:16 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:16 --> Input Class Initialized
INFO - 2022-06-14 06:17:16 --> Language Class Initialized
INFO - 2022-06-14 06:17:16 --> Language Class Initialized
INFO - 2022-06-14 06:17:16 --> Config Class Initialized
INFO - 2022-06-14 06:17:16 --> Loader Class Initialized
INFO - 2022-06-14 06:17:16 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:16 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:16 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:16 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:16 --> Controller Class Initialized
INFO - 2022-06-14 06:17:16 --> Helper loaded: cookie_helper
INFO - 2022-06-14 06:17:16 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:16 --> Total execution time: 0.0491
INFO - 2022-06-14 06:17:16 --> Config Class Initialized
INFO - 2022-06-14 06:17:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:16 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:16 --> URI Class Initialized
INFO - 2022-06-14 06:17:16 --> Router Class Initialized
INFO - 2022-06-14 06:17:16 --> Output Class Initialized
INFO - 2022-06-14 06:17:16 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:16 --> Input Class Initialized
INFO - 2022-06-14 06:17:16 --> Language Class Initialized
INFO - 2022-06-14 06:17:16 --> Language Class Initialized
INFO - 2022-06-14 06:17:16 --> Config Class Initialized
INFO - 2022-06-14 06:17:16 --> Loader Class Initialized
INFO - 2022-06-14 06:17:16 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:16 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:16 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:16 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:16 --> Controller Class Initialized
DEBUG - 2022-06-14 06:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 06:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:17:16 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:16 --> Total execution time: 0.0565
INFO - 2022-06-14 06:17:18 --> Config Class Initialized
INFO - 2022-06-14 06:17:18 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:18 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:18 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:18 --> URI Class Initialized
INFO - 2022-06-14 06:17:18 --> Router Class Initialized
INFO - 2022-06-14 06:17:18 --> Output Class Initialized
INFO - 2022-06-14 06:17:18 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:18 --> Input Class Initialized
INFO - 2022-06-14 06:17:18 --> Language Class Initialized
INFO - 2022-06-14 06:17:18 --> Language Class Initialized
INFO - 2022-06-14 06:17:18 --> Config Class Initialized
INFO - 2022-06-14 06:17:18 --> Loader Class Initialized
INFO - 2022-06-14 06:17:18 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:18 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:18 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:18 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:18 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:18 --> Controller Class Initialized
DEBUG - 2022-06-14 06:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-14 06:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:17:18 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:18 --> Total execution time: 0.0893
INFO - 2022-06-14 06:17:24 --> Config Class Initialized
INFO - 2022-06-14 06:17:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:24 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:24 --> URI Class Initialized
INFO - 2022-06-14 06:17:24 --> Router Class Initialized
INFO - 2022-06-14 06:17:24 --> Output Class Initialized
INFO - 2022-06-14 06:17:24 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:24 --> Input Class Initialized
INFO - 2022-06-14 06:17:24 --> Language Class Initialized
INFO - 2022-06-14 06:17:24 --> Language Class Initialized
INFO - 2022-06-14 06:17:24 --> Config Class Initialized
INFO - 2022-06-14 06:17:24 --> Loader Class Initialized
INFO - 2022-06-14 06:17:24 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:24 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:24 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:24 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:24 --> Controller Class Initialized
DEBUG - 2022-06-14 06:17:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-06-14 06:17:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:17:24 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:24 --> Total execution time: 0.0570
INFO - 2022-06-14 06:17:39 --> Config Class Initialized
INFO - 2022-06-14 06:17:39 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:39 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:39 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:39 --> URI Class Initialized
INFO - 2022-06-14 06:17:39 --> Router Class Initialized
INFO - 2022-06-14 06:17:39 --> Output Class Initialized
INFO - 2022-06-14 06:17:39 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:39 --> Input Class Initialized
INFO - 2022-06-14 06:17:39 --> Language Class Initialized
INFO - 2022-06-14 06:17:39 --> Language Class Initialized
INFO - 2022-06-14 06:17:39 --> Config Class Initialized
INFO - 2022-06-14 06:17:39 --> Loader Class Initialized
INFO - 2022-06-14 06:17:39 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:39 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:39 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:39 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:39 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:39 --> Controller Class Initialized
DEBUG - 2022-06-14 06:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-14 06:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:17:39 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:39 --> Total execution time: 0.0621
INFO - 2022-06-14 06:17:50 --> Config Class Initialized
INFO - 2022-06-14 06:17:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:50 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:50 --> URI Class Initialized
INFO - 2022-06-14 06:17:50 --> Router Class Initialized
INFO - 2022-06-14 06:17:50 --> Output Class Initialized
INFO - 2022-06-14 06:17:50 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:50 --> Input Class Initialized
INFO - 2022-06-14 06:17:50 --> Language Class Initialized
INFO - 2022-06-14 06:17:50 --> Language Class Initialized
INFO - 2022-06-14 06:17:50 --> Config Class Initialized
INFO - 2022-06-14 06:17:50 --> Loader Class Initialized
INFO - 2022-06-14 06:17:50 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:50 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:50 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:50 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:50 --> Controller Class Initialized
INFO - 2022-06-14 06:17:50 --> Helper loaded: cookie_helper
INFO - 2022-06-14 06:17:50 --> Config Class Initialized
INFO - 2022-06-14 06:17:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:50 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:50 --> URI Class Initialized
INFO - 2022-06-14 06:17:50 --> Router Class Initialized
INFO - 2022-06-14 06:17:50 --> Output Class Initialized
INFO - 2022-06-14 06:17:50 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:50 --> Input Class Initialized
INFO - 2022-06-14 06:17:50 --> Language Class Initialized
INFO - 2022-06-14 06:17:50 --> Language Class Initialized
INFO - 2022-06-14 06:17:50 --> Config Class Initialized
INFO - 2022-06-14 06:17:50 --> Loader Class Initialized
INFO - 2022-06-14 06:17:50 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:50 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:50 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:50 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:50 --> Controller Class Initialized
DEBUG - 2022-06-14 06:17:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 06:17:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:17:50 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:50 --> Total execution time: 0.0489
INFO - 2022-06-14 06:17:54 --> Config Class Initialized
INFO - 2022-06-14 06:17:54 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:54 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:54 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:54 --> URI Class Initialized
INFO - 2022-06-14 06:17:54 --> Router Class Initialized
INFO - 2022-06-14 06:17:54 --> Output Class Initialized
INFO - 2022-06-14 06:17:54 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:54 --> Input Class Initialized
INFO - 2022-06-14 06:17:54 --> Language Class Initialized
INFO - 2022-06-14 06:17:54 --> Language Class Initialized
INFO - 2022-06-14 06:17:54 --> Config Class Initialized
INFO - 2022-06-14 06:17:54 --> Loader Class Initialized
INFO - 2022-06-14 06:17:54 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:54 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:54 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:54 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:54 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:54 --> Controller Class Initialized
INFO - 2022-06-14 06:17:54 --> Helper loaded: cookie_helper
INFO - 2022-06-14 06:17:54 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:54 --> Total execution time: 0.0411
INFO - 2022-06-14 06:17:54 --> Config Class Initialized
INFO - 2022-06-14 06:17:54 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:17:54 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:17:54 --> Utf8 Class Initialized
INFO - 2022-06-14 06:17:54 --> URI Class Initialized
INFO - 2022-06-14 06:17:54 --> Router Class Initialized
INFO - 2022-06-14 06:17:54 --> Output Class Initialized
INFO - 2022-06-14 06:17:54 --> Security Class Initialized
DEBUG - 2022-06-14 06:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:17:54 --> Input Class Initialized
INFO - 2022-06-14 06:17:54 --> Language Class Initialized
INFO - 2022-06-14 06:17:54 --> Language Class Initialized
INFO - 2022-06-14 06:17:54 --> Config Class Initialized
INFO - 2022-06-14 06:17:54 --> Loader Class Initialized
INFO - 2022-06-14 06:17:54 --> Helper loaded: url_helper
INFO - 2022-06-14 06:17:54 --> Helper loaded: file_helper
INFO - 2022-06-14 06:17:54 --> Helper loaded: form_helper
INFO - 2022-06-14 06:17:54 --> Helper loaded: my_helper
INFO - 2022-06-14 06:17:54 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:17:54 --> Controller Class Initialized
DEBUG - 2022-06-14 06:17:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 06:17:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:17:54 --> Final output sent to browser
DEBUG - 2022-06-14 06:17:54 --> Total execution time: 0.0539
INFO - 2022-06-14 06:18:02 --> Config Class Initialized
INFO - 2022-06-14 06:18:02 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:02 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:02 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:02 --> URI Class Initialized
INFO - 2022-06-14 06:18:02 --> Router Class Initialized
INFO - 2022-06-14 06:18:02 --> Output Class Initialized
INFO - 2022-06-14 06:18:02 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:02 --> Input Class Initialized
INFO - 2022-06-14 06:18:02 --> Language Class Initialized
INFO - 2022-06-14 06:18:02 --> Language Class Initialized
INFO - 2022-06-14 06:18:02 --> Config Class Initialized
INFO - 2022-06-14 06:18:02 --> Loader Class Initialized
INFO - 2022-06-14 06:18:02 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:02 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:02 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:02 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:02 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:02 --> Controller Class Initialized
DEBUG - 2022-06-14 06:18:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 06:18:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:18:02 --> Final output sent to browser
DEBUG - 2022-06-14 06:18:02 --> Total execution time: 0.0417
INFO - 2022-06-14 06:18:08 --> Config Class Initialized
INFO - 2022-06-14 06:18:08 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:08 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:08 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:08 --> URI Class Initialized
INFO - 2022-06-14 06:18:08 --> Router Class Initialized
INFO - 2022-06-14 06:18:08 --> Output Class Initialized
INFO - 2022-06-14 06:18:08 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:08 --> Input Class Initialized
INFO - 2022-06-14 06:18:08 --> Language Class Initialized
INFO - 2022-06-14 06:18:08 --> Language Class Initialized
INFO - 2022-06-14 06:18:08 --> Config Class Initialized
INFO - 2022-06-14 06:18:08 --> Loader Class Initialized
INFO - 2022-06-14 06:18:08 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:08 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:08 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:08 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:08 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:08 --> Controller Class Initialized
DEBUG - 2022-06-14 06:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 06:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:18:08 --> Final output sent to browser
DEBUG - 2022-06-14 06:18:08 --> Total execution time: 0.0444
INFO - 2022-06-14 06:18:08 --> Config Class Initialized
INFO - 2022-06-14 06:18:08 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:08 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:08 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:08 --> URI Class Initialized
INFO - 2022-06-14 06:18:08 --> Router Class Initialized
INFO - 2022-06-14 06:18:08 --> Output Class Initialized
INFO - 2022-06-14 06:18:08 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:08 --> Input Class Initialized
INFO - 2022-06-14 06:18:08 --> Language Class Initialized
INFO - 2022-06-14 06:18:08 --> Language Class Initialized
INFO - 2022-06-14 06:18:08 --> Config Class Initialized
INFO - 2022-06-14 06:18:08 --> Loader Class Initialized
INFO - 2022-06-14 06:18:08 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:08 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:08 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:08 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:08 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:08 --> Controller Class Initialized
INFO - 2022-06-14 06:18:11 --> Config Class Initialized
INFO - 2022-06-14 06:18:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:11 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:11 --> URI Class Initialized
INFO - 2022-06-14 06:18:11 --> Router Class Initialized
INFO - 2022-06-14 06:18:11 --> Output Class Initialized
INFO - 2022-06-14 06:18:11 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:11 --> Input Class Initialized
INFO - 2022-06-14 06:18:11 --> Language Class Initialized
INFO - 2022-06-14 06:18:11 --> Language Class Initialized
INFO - 2022-06-14 06:18:11 --> Config Class Initialized
INFO - 2022-06-14 06:18:11 --> Loader Class Initialized
INFO - 2022-06-14 06:18:11 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:11 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:11 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:11 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:11 --> Controller Class Initialized
INFO - 2022-06-14 06:18:11 --> Final output sent to browser
DEBUG - 2022-06-14 06:18:11 --> Total execution time: 0.0411
INFO - 2022-06-14 06:18:23 --> Config Class Initialized
INFO - 2022-06-14 06:18:23 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:23 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:23 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:23 --> URI Class Initialized
INFO - 2022-06-14 06:18:23 --> Router Class Initialized
INFO - 2022-06-14 06:18:23 --> Output Class Initialized
INFO - 2022-06-14 06:18:23 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:23 --> Input Class Initialized
INFO - 2022-06-14 06:18:23 --> Language Class Initialized
INFO - 2022-06-14 06:18:23 --> Language Class Initialized
INFO - 2022-06-14 06:18:23 --> Config Class Initialized
INFO - 2022-06-14 06:18:23 --> Loader Class Initialized
INFO - 2022-06-14 06:18:23 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:23 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:23 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:23 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:23 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:23 --> Controller Class Initialized
DEBUG - 2022-06-14 06:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 06:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:18:23 --> Final output sent to browser
DEBUG - 2022-06-14 06:18:23 --> Total execution time: 0.0410
INFO - 2022-06-14 06:18:29 --> Config Class Initialized
INFO - 2022-06-14 06:18:29 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:29 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:29 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:29 --> URI Class Initialized
INFO - 2022-06-14 06:18:29 --> Router Class Initialized
INFO - 2022-06-14 06:18:29 --> Output Class Initialized
INFO - 2022-06-14 06:18:29 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:29 --> Input Class Initialized
INFO - 2022-06-14 06:18:29 --> Language Class Initialized
INFO - 2022-06-14 06:18:29 --> Language Class Initialized
INFO - 2022-06-14 06:18:29 --> Config Class Initialized
INFO - 2022-06-14 06:18:29 --> Loader Class Initialized
INFO - 2022-06-14 06:18:29 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:29 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:29 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:29 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:29 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:29 --> Controller Class Initialized
DEBUG - 2022-06-14 06:18:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 06:18:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:18:29 --> Final output sent to browser
DEBUG - 2022-06-14 06:18:29 --> Total execution time: 0.0566
INFO - 2022-06-14 06:18:31 --> Config Class Initialized
INFO - 2022-06-14 06:18:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:31 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:31 --> URI Class Initialized
INFO - 2022-06-14 06:18:31 --> Router Class Initialized
INFO - 2022-06-14 06:18:31 --> Output Class Initialized
INFO - 2022-06-14 06:18:31 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:31 --> Input Class Initialized
INFO - 2022-06-14 06:18:31 --> Language Class Initialized
INFO - 2022-06-14 06:18:31 --> Language Class Initialized
INFO - 2022-06-14 06:18:31 --> Config Class Initialized
INFO - 2022-06-14 06:18:31 --> Loader Class Initialized
INFO - 2022-06-14 06:18:31 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:31 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:31 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:31 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:31 --> Controller Class Initialized
INFO - 2022-06-14 06:18:31 --> Final output sent to browser
DEBUG - 2022-06-14 06:18:31 --> Total execution time: 0.0501
INFO - 2022-06-14 06:18:37 --> Config Class Initialized
INFO - 2022-06-14 06:18:37 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:37 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:37 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:37 --> URI Class Initialized
INFO - 2022-06-14 06:18:37 --> Router Class Initialized
INFO - 2022-06-14 06:18:37 --> Output Class Initialized
INFO - 2022-06-14 06:18:37 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:37 --> Input Class Initialized
INFO - 2022-06-14 06:18:37 --> Language Class Initialized
INFO - 2022-06-14 06:18:37 --> Language Class Initialized
INFO - 2022-06-14 06:18:37 --> Config Class Initialized
INFO - 2022-06-14 06:18:37 --> Loader Class Initialized
INFO - 2022-06-14 06:18:37 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:37 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:37 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:37 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:37 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:37 --> Controller Class Initialized
DEBUG - 2022-06-14 06:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 06:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:18:37 --> Final output sent to browser
DEBUG - 2022-06-14 06:18:37 --> Total execution time: 0.0442
INFO - 2022-06-14 06:18:37 --> Config Class Initialized
INFO - 2022-06-14 06:18:37 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:37 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:37 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:37 --> URI Class Initialized
INFO - 2022-06-14 06:18:37 --> Router Class Initialized
INFO - 2022-06-14 06:18:37 --> Output Class Initialized
INFO - 2022-06-14 06:18:37 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:37 --> Input Class Initialized
INFO - 2022-06-14 06:18:37 --> Language Class Initialized
INFO - 2022-06-14 06:18:37 --> Language Class Initialized
INFO - 2022-06-14 06:18:37 --> Config Class Initialized
INFO - 2022-06-14 06:18:37 --> Loader Class Initialized
INFO - 2022-06-14 06:18:37 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:37 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:37 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:37 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:37 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:37 --> Controller Class Initialized
INFO - 2022-06-14 06:18:38 --> Config Class Initialized
INFO - 2022-06-14 06:18:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:38 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:38 --> URI Class Initialized
INFO - 2022-06-14 06:18:38 --> Router Class Initialized
INFO - 2022-06-14 06:18:38 --> Output Class Initialized
INFO - 2022-06-14 06:18:38 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:38 --> Input Class Initialized
INFO - 2022-06-14 06:18:38 --> Language Class Initialized
INFO - 2022-06-14 06:18:38 --> Language Class Initialized
INFO - 2022-06-14 06:18:38 --> Config Class Initialized
INFO - 2022-06-14 06:18:38 --> Loader Class Initialized
INFO - 2022-06-14 06:18:38 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:38 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:38 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:38 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:38 --> Controller Class Initialized
INFO - 2022-06-14 06:18:38 --> Final output sent to browser
DEBUG - 2022-06-14 06:18:38 --> Total execution time: 0.0492
INFO - 2022-06-14 06:18:42 --> Config Class Initialized
INFO - 2022-06-14 06:18:42 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:18:42 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:18:42 --> Utf8 Class Initialized
INFO - 2022-06-14 06:18:42 --> URI Class Initialized
INFO - 2022-06-14 06:18:42 --> Router Class Initialized
INFO - 2022-06-14 06:18:42 --> Output Class Initialized
INFO - 2022-06-14 06:18:42 --> Security Class Initialized
DEBUG - 2022-06-14 06:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:18:42 --> Input Class Initialized
INFO - 2022-06-14 06:18:42 --> Language Class Initialized
INFO - 2022-06-14 06:18:42 --> Language Class Initialized
INFO - 2022-06-14 06:18:42 --> Config Class Initialized
INFO - 2022-06-14 06:18:42 --> Loader Class Initialized
INFO - 2022-06-14 06:18:42 --> Helper loaded: url_helper
INFO - 2022-06-14 06:18:42 --> Helper loaded: file_helper
INFO - 2022-06-14 06:18:42 --> Helper loaded: form_helper
INFO - 2022-06-14 06:18:42 --> Helper loaded: my_helper
INFO - 2022-06-14 06:18:42 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:18:42 --> Controller Class Initialized
INFO - 2022-06-14 06:19:12 --> Config Class Initialized
INFO - 2022-06-14 06:19:12 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:19:12 --> Utf8 Class Initialized
INFO - 2022-06-14 06:19:12 --> URI Class Initialized
INFO - 2022-06-14 06:19:12 --> Router Class Initialized
INFO - 2022-06-14 06:19:12 --> Output Class Initialized
INFO - 2022-06-14 06:19:12 --> Security Class Initialized
DEBUG - 2022-06-14 06:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:19:12 --> Input Class Initialized
INFO - 2022-06-14 06:19:12 --> Language Class Initialized
INFO - 2022-06-14 06:19:12 --> Language Class Initialized
INFO - 2022-06-14 06:19:12 --> Config Class Initialized
INFO - 2022-06-14 06:19:12 --> Loader Class Initialized
INFO - 2022-06-14 06:19:12 --> Helper loaded: url_helper
INFO - 2022-06-14 06:19:12 --> Helper loaded: file_helper
INFO - 2022-06-14 06:19:12 --> Helper loaded: form_helper
INFO - 2022-06-14 06:19:12 --> Helper loaded: my_helper
INFO - 2022-06-14 06:19:12 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:19:12 --> Controller Class Initialized
DEBUG - 2022-06-14 06:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 06:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:19:12 --> Final output sent to browser
DEBUG - 2022-06-14 06:19:12 --> Total execution time: 0.0457
INFO - 2022-06-14 06:19:12 --> Config Class Initialized
INFO - 2022-06-14 06:19:12 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:19:12 --> Utf8 Class Initialized
INFO - 2022-06-14 06:19:12 --> URI Class Initialized
INFO - 2022-06-14 06:19:12 --> Router Class Initialized
INFO - 2022-06-14 06:19:12 --> Output Class Initialized
INFO - 2022-06-14 06:19:12 --> Security Class Initialized
DEBUG - 2022-06-14 06:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:19:12 --> Input Class Initialized
INFO - 2022-06-14 06:19:12 --> Language Class Initialized
INFO - 2022-06-14 06:19:12 --> Language Class Initialized
INFO - 2022-06-14 06:19:12 --> Config Class Initialized
INFO - 2022-06-14 06:19:12 --> Loader Class Initialized
INFO - 2022-06-14 06:19:12 --> Helper loaded: url_helper
INFO - 2022-06-14 06:19:12 --> Helper loaded: file_helper
INFO - 2022-06-14 06:19:12 --> Helper loaded: form_helper
INFO - 2022-06-14 06:19:12 --> Helper loaded: my_helper
INFO - 2022-06-14 06:19:12 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:19:12 --> Controller Class Initialized
INFO - 2022-06-14 06:19:16 --> Config Class Initialized
INFO - 2022-06-14 06:19:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:19:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:19:16 --> Utf8 Class Initialized
INFO - 2022-06-14 06:19:16 --> URI Class Initialized
INFO - 2022-06-14 06:19:16 --> Router Class Initialized
INFO - 2022-06-14 06:19:16 --> Output Class Initialized
INFO - 2022-06-14 06:19:16 --> Security Class Initialized
DEBUG - 2022-06-14 06:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:19:16 --> Input Class Initialized
INFO - 2022-06-14 06:19:16 --> Language Class Initialized
INFO - 2022-06-14 06:19:16 --> Language Class Initialized
INFO - 2022-06-14 06:19:16 --> Config Class Initialized
INFO - 2022-06-14 06:19:16 --> Loader Class Initialized
INFO - 2022-06-14 06:19:16 --> Helper loaded: url_helper
INFO - 2022-06-14 06:19:16 --> Helper loaded: file_helper
INFO - 2022-06-14 06:19:16 --> Helper loaded: form_helper
INFO - 2022-06-14 06:19:16 --> Helper loaded: my_helper
INFO - 2022-06-14 06:19:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:19:16 --> Controller Class Initialized
INFO - 2022-06-14 06:19:16 --> Final output sent to browser
DEBUG - 2022-06-14 06:19:16 --> Total execution time: 0.0490
INFO - 2022-06-14 06:19:19 --> Config Class Initialized
INFO - 2022-06-14 06:19:19 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:19:19 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:19:19 --> Utf8 Class Initialized
INFO - 2022-06-14 06:19:19 --> URI Class Initialized
INFO - 2022-06-14 06:19:19 --> Router Class Initialized
INFO - 2022-06-14 06:19:19 --> Output Class Initialized
INFO - 2022-06-14 06:19:19 --> Security Class Initialized
DEBUG - 2022-06-14 06:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:19:19 --> Input Class Initialized
INFO - 2022-06-14 06:19:19 --> Language Class Initialized
INFO - 2022-06-14 06:19:19 --> Language Class Initialized
INFO - 2022-06-14 06:19:19 --> Config Class Initialized
INFO - 2022-06-14 06:19:19 --> Loader Class Initialized
INFO - 2022-06-14 06:19:19 --> Helper loaded: url_helper
INFO - 2022-06-14 06:19:19 --> Helper loaded: file_helper
INFO - 2022-06-14 06:19:19 --> Helper loaded: form_helper
INFO - 2022-06-14 06:19:19 --> Helper loaded: my_helper
INFO - 2022-06-14 06:19:20 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:19:20 --> Controller Class Initialized
INFO - 2022-06-14 06:19:43 --> Config Class Initialized
INFO - 2022-06-14 06:19:43 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:19:43 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:19:43 --> Utf8 Class Initialized
INFO - 2022-06-14 06:19:43 --> URI Class Initialized
INFO - 2022-06-14 06:19:43 --> Router Class Initialized
INFO - 2022-06-14 06:19:43 --> Output Class Initialized
INFO - 2022-06-14 06:19:43 --> Security Class Initialized
DEBUG - 2022-06-14 06:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:19:43 --> Input Class Initialized
INFO - 2022-06-14 06:19:43 --> Language Class Initialized
INFO - 2022-06-14 06:19:43 --> Language Class Initialized
INFO - 2022-06-14 06:19:43 --> Config Class Initialized
INFO - 2022-06-14 06:19:43 --> Loader Class Initialized
INFO - 2022-06-14 06:19:43 --> Helper loaded: url_helper
INFO - 2022-06-14 06:19:43 --> Helper loaded: file_helper
INFO - 2022-06-14 06:19:43 --> Helper loaded: form_helper
INFO - 2022-06-14 06:19:43 --> Helper loaded: my_helper
INFO - 2022-06-14 06:19:43 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:19:43 --> Controller Class Initialized
INFO - 2022-06-14 06:19:43 --> Helper loaded: cookie_helper
INFO - 2022-06-14 06:19:43 --> Config Class Initialized
INFO - 2022-06-14 06:19:43 --> Hooks Class Initialized
DEBUG - 2022-06-14 06:19:43 --> UTF-8 Support Enabled
INFO - 2022-06-14 06:19:43 --> Utf8 Class Initialized
INFO - 2022-06-14 06:19:43 --> URI Class Initialized
INFO - 2022-06-14 06:19:43 --> Router Class Initialized
INFO - 2022-06-14 06:19:43 --> Output Class Initialized
INFO - 2022-06-14 06:19:43 --> Security Class Initialized
DEBUG - 2022-06-14 06:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 06:19:43 --> Input Class Initialized
INFO - 2022-06-14 06:19:43 --> Language Class Initialized
INFO - 2022-06-14 06:19:43 --> Language Class Initialized
INFO - 2022-06-14 06:19:43 --> Config Class Initialized
INFO - 2022-06-14 06:19:43 --> Loader Class Initialized
INFO - 2022-06-14 06:19:43 --> Helper loaded: url_helper
INFO - 2022-06-14 06:19:43 --> Helper loaded: file_helper
INFO - 2022-06-14 06:19:43 --> Helper loaded: form_helper
INFO - 2022-06-14 06:19:43 --> Helper loaded: my_helper
INFO - 2022-06-14 06:19:43 --> Database Driver Class Initialized
DEBUG - 2022-06-14 06:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 06:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 06:19:43 --> Controller Class Initialized
DEBUG - 2022-06-14 06:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 06:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 06:19:43 --> Final output sent to browser
DEBUG - 2022-06-14 06:19:43 --> Total execution time: 0.0492
INFO - 2022-06-14 09:12:23 --> Config Class Initialized
INFO - 2022-06-14 09:12:23 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:12:23 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:12:23 --> Utf8 Class Initialized
INFO - 2022-06-14 09:12:23 --> URI Class Initialized
DEBUG - 2022-06-14 09:12:23 --> No URI present. Default controller set.
INFO - 2022-06-14 09:12:23 --> Router Class Initialized
INFO - 2022-06-14 09:12:23 --> Output Class Initialized
INFO - 2022-06-14 09:12:23 --> Security Class Initialized
DEBUG - 2022-06-14 09:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:12:23 --> Input Class Initialized
INFO - 2022-06-14 09:12:23 --> Language Class Initialized
INFO - 2022-06-14 09:12:23 --> Language Class Initialized
INFO - 2022-06-14 09:12:23 --> Config Class Initialized
INFO - 2022-06-14 09:12:23 --> Loader Class Initialized
INFO - 2022-06-14 09:12:23 --> Helper loaded: url_helper
INFO - 2022-06-14 09:12:23 --> Helper loaded: file_helper
INFO - 2022-06-14 09:12:23 --> Helper loaded: form_helper
INFO - 2022-06-14 09:12:23 --> Helper loaded: my_helper
INFO - 2022-06-14 09:12:23 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:12:23 --> Controller Class Initialized
INFO - 2022-06-14 09:12:23 --> Config Class Initialized
INFO - 2022-06-14 09:12:23 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:12:23 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:12:23 --> Utf8 Class Initialized
INFO - 2022-06-14 09:12:23 --> URI Class Initialized
INFO - 2022-06-14 09:12:23 --> Router Class Initialized
INFO - 2022-06-14 09:12:23 --> Output Class Initialized
INFO - 2022-06-14 09:12:23 --> Security Class Initialized
DEBUG - 2022-06-14 09:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:12:23 --> Input Class Initialized
INFO - 2022-06-14 09:12:23 --> Language Class Initialized
INFO - 2022-06-14 09:12:23 --> Language Class Initialized
INFO - 2022-06-14 09:12:23 --> Config Class Initialized
INFO - 2022-06-14 09:12:23 --> Loader Class Initialized
INFO - 2022-06-14 09:12:23 --> Helper loaded: url_helper
INFO - 2022-06-14 09:12:23 --> Helper loaded: file_helper
INFO - 2022-06-14 09:12:23 --> Helper loaded: form_helper
INFO - 2022-06-14 09:12:23 --> Helper loaded: my_helper
INFO - 2022-06-14 09:12:23 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:12:23 --> Controller Class Initialized
DEBUG - 2022-06-14 09:12:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:12:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:12:23 --> Final output sent to browser
DEBUG - 2022-06-14 09:12:23 --> Total execution time: 0.0520
INFO - 2022-06-14 09:14:47 --> Config Class Initialized
INFO - 2022-06-14 09:14:47 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:14:47 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:14:47 --> Utf8 Class Initialized
INFO - 2022-06-14 09:14:47 --> URI Class Initialized
INFO - 2022-06-14 09:14:47 --> Router Class Initialized
INFO - 2022-06-14 09:14:47 --> Output Class Initialized
INFO - 2022-06-14 09:14:47 --> Security Class Initialized
DEBUG - 2022-06-14 09:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:14:47 --> Input Class Initialized
INFO - 2022-06-14 09:14:47 --> Language Class Initialized
INFO - 2022-06-14 09:14:47 --> Language Class Initialized
INFO - 2022-06-14 09:14:47 --> Config Class Initialized
INFO - 2022-06-14 09:14:47 --> Loader Class Initialized
INFO - 2022-06-14 09:14:47 --> Helper loaded: url_helper
INFO - 2022-06-14 09:14:47 --> Helper loaded: file_helper
INFO - 2022-06-14 09:14:47 --> Helper loaded: form_helper
INFO - 2022-06-14 09:14:47 --> Helper loaded: my_helper
INFO - 2022-06-14 09:14:47 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:14:47 --> Controller Class Initialized
INFO - 2022-06-14 09:14:47 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:14:47 --> Final output sent to browser
DEBUG - 2022-06-14 09:14:47 --> Total execution time: 0.0600
INFO - 2022-06-14 09:14:56 --> Config Class Initialized
INFO - 2022-06-14 09:14:56 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:14:56 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:14:56 --> Utf8 Class Initialized
INFO - 2022-06-14 09:14:56 --> URI Class Initialized
INFO - 2022-06-14 09:14:56 --> Router Class Initialized
INFO - 2022-06-14 09:14:56 --> Output Class Initialized
INFO - 2022-06-14 09:14:56 --> Security Class Initialized
DEBUG - 2022-06-14 09:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:14:56 --> Input Class Initialized
INFO - 2022-06-14 09:14:56 --> Language Class Initialized
INFO - 2022-06-14 09:14:56 --> Language Class Initialized
INFO - 2022-06-14 09:14:56 --> Config Class Initialized
INFO - 2022-06-14 09:14:56 --> Loader Class Initialized
INFO - 2022-06-14 09:14:56 --> Helper loaded: url_helper
INFO - 2022-06-14 09:14:56 --> Helper loaded: file_helper
INFO - 2022-06-14 09:14:56 --> Helper loaded: form_helper
INFO - 2022-06-14 09:14:56 --> Helper loaded: my_helper
INFO - 2022-06-14 09:14:56 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:14:56 --> Controller Class Initialized
DEBUG - 2022-06-14 09:14:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:14:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:14:56 --> Final output sent to browser
DEBUG - 2022-06-14 09:14:56 --> Total execution time: 0.0440
INFO - 2022-06-14 09:15:05 --> Config Class Initialized
INFO - 2022-06-14 09:15:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:15:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:15:05 --> Utf8 Class Initialized
INFO - 2022-06-14 09:15:05 --> URI Class Initialized
INFO - 2022-06-14 09:15:05 --> Router Class Initialized
INFO - 2022-06-14 09:15:05 --> Output Class Initialized
INFO - 2022-06-14 09:15:05 --> Security Class Initialized
DEBUG - 2022-06-14 09:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:15:05 --> Input Class Initialized
INFO - 2022-06-14 09:15:05 --> Language Class Initialized
INFO - 2022-06-14 09:15:05 --> Language Class Initialized
INFO - 2022-06-14 09:15:05 --> Config Class Initialized
INFO - 2022-06-14 09:15:05 --> Loader Class Initialized
INFO - 2022-06-14 09:15:05 --> Helper loaded: url_helper
INFO - 2022-06-14 09:15:05 --> Helper loaded: file_helper
INFO - 2022-06-14 09:15:05 --> Helper loaded: form_helper
INFO - 2022-06-14 09:15:05 --> Helper loaded: my_helper
INFO - 2022-06-14 09:15:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:15:05 --> Controller Class Initialized
DEBUG - 2022-06-14 09:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:15:05 --> Final output sent to browser
DEBUG - 2022-06-14 09:15:05 --> Total execution time: 0.0914
INFO - 2022-06-14 09:15:11 --> Config Class Initialized
INFO - 2022-06-14 09:15:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:15:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:15:11 --> Utf8 Class Initialized
INFO - 2022-06-14 09:15:11 --> URI Class Initialized
INFO - 2022-06-14 09:15:11 --> Router Class Initialized
INFO - 2022-06-14 09:15:11 --> Output Class Initialized
INFO - 2022-06-14 09:15:11 --> Security Class Initialized
DEBUG - 2022-06-14 09:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:15:11 --> Input Class Initialized
INFO - 2022-06-14 09:15:11 --> Language Class Initialized
INFO - 2022-06-14 09:15:11 --> Language Class Initialized
INFO - 2022-06-14 09:15:11 --> Config Class Initialized
INFO - 2022-06-14 09:15:11 --> Loader Class Initialized
INFO - 2022-06-14 09:15:11 --> Helper loaded: url_helper
INFO - 2022-06-14 09:15:11 --> Helper loaded: file_helper
INFO - 2022-06-14 09:15:11 --> Helper loaded: form_helper
INFO - 2022-06-14 09:15:11 --> Helper loaded: my_helper
INFO - 2022-06-14 09:15:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:15:11 --> Controller Class Initialized
INFO - 2022-06-14 09:15:11 --> Final output sent to browser
DEBUG - 2022-06-14 09:15:11 --> Total execution time: 0.0470
INFO - 2022-06-14 09:15:17 --> Config Class Initialized
INFO - 2022-06-14 09:15:17 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:15:17 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:15:17 --> Utf8 Class Initialized
INFO - 2022-06-14 09:15:17 --> URI Class Initialized
INFO - 2022-06-14 09:15:17 --> Router Class Initialized
INFO - 2022-06-14 09:15:17 --> Output Class Initialized
INFO - 2022-06-14 09:15:17 --> Security Class Initialized
DEBUG - 2022-06-14 09:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:15:17 --> Input Class Initialized
INFO - 2022-06-14 09:15:17 --> Language Class Initialized
INFO - 2022-06-14 09:15:17 --> Language Class Initialized
INFO - 2022-06-14 09:15:17 --> Config Class Initialized
INFO - 2022-06-14 09:15:17 --> Loader Class Initialized
INFO - 2022-06-14 09:15:17 --> Helper loaded: url_helper
INFO - 2022-06-14 09:15:17 --> Helper loaded: file_helper
INFO - 2022-06-14 09:15:17 --> Helper loaded: form_helper
INFO - 2022-06-14 09:15:17 --> Helper loaded: my_helper
INFO - 2022-06-14 09:15:17 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:15:17 --> Controller Class Initialized
DEBUG - 2022-06-14 09:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:15:17 --> Final output sent to browser
DEBUG - 2022-06-14 09:15:17 --> Total execution time: 0.0790
INFO - 2022-06-14 09:15:19 --> Config Class Initialized
INFO - 2022-06-14 09:15:19 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:15:19 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:15:19 --> Utf8 Class Initialized
INFO - 2022-06-14 09:15:19 --> URI Class Initialized
INFO - 2022-06-14 09:15:19 --> Router Class Initialized
INFO - 2022-06-14 09:15:19 --> Output Class Initialized
INFO - 2022-06-14 09:15:19 --> Security Class Initialized
DEBUG - 2022-06-14 09:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:15:19 --> Input Class Initialized
INFO - 2022-06-14 09:15:19 --> Language Class Initialized
INFO - 2022-06-14 09:15:19 --> Language Class Initialized
INFO - 2022-06-14 09:15:19 --> Config Class Initialized
INFO - 2022-06-14 09:15:19 --> Loader Class Initialized
INFO - 2022-06-14 09:15:19 --> Helper loaded: url_helper
INFO - 2022-06-14 09:15:19 --> Helper loaded: file_helper
INFO - 2022-06-14 09:15:19 --> Helper loaded: form_helper
INFO - 2022-06-14 09:15:19 --> Helper loaded: my_helper
INFO - 2022-06-14 09:15:19 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:15:19 --> Controller Class Initialized
DEBUG - 2022-06-14 09:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 09:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:15:19 --> Final output sent to browser
DEBUG - 2022-06-14 09:15:19 --> Total execution time: 0.0984
INFO - 2022-06-14 09:15:23 --> Config Class Initialized
INFO - 2022-06-14 09:15:23 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:15:23 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:15:23 --> Utf8 Class Initialized
INFO - 2022-06-14 09:15:23 --> URI Class Initialized
INFO - 2022-06-14 09:15:23 --> Router Class Initialized
INFO - 2022-06-14 09:15:23 --> Output Class Initialized
INFO - 2022-06-14 09:15:23 --> Security Class Initialized
DEBUG - 2022-06-14 09:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:15:23 --> Input Class Initialized
INFO - 2022-06-14 09:15:23 --> Language Class Initialized
INFO - 2022-06-14 09:15:23 --> Language Class Initialized
INFO - 2022-06-14 09:15:23 --> Config Class Initialized
INFO - 2022-06-14 09:15:23 --> Loader Class Initialized
INFO - 2022-06-14 09:15:23 --> Helper loaded: url_helper
INFO - 2022-06-14 09:15:23 --> Helper loaded: file_helper
INFO - 2022-06-14 09:15:23 --> Helper loaded: form_helper
INFO - 2022-06-14 09:15:23 --> Helper loaded: my_helper
INFO - 2022-06-14 09:15:23 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:15:23 --> Controller Class Initialized
DEBUG - 2022-06-14 09:15:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:15:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:15:23 --> Final output sent to browser
DEBUG - 2022-06-14 09:15:23 --> Total execution time: 0.0511
INFO - 2022-06-14 09:15:29 --> Config Class Initialized
INFO - 2022-06-14 09:15:29 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:15:29 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:15:29 --> Utf8 Class Initialized
INFO - 2022-06-14 09:15:29 --> URI Class Initialized
INFO - 2022-06-14 09:15:29 --> Router Class Initialized
INFO - 2022-06-14 09:15:29 --> Output Class Initialized
INFO - 2022-06-14 09:15:29 --> Security Class Initialized
DEBUG - 2022-06-14 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:15:29 --> Input Class Initialized
INFO - 2022-06-14 09:15:29 --> Language Class Initialized
INFO - 2022-06-14 09:15:29 --> Language Class Initialized
INFO - 2022-06-14 09:15:29 --> Config Class Initialized
INFO - 2022-06-14 09:15:29 --> Loader Class Initialized
INFO - 2022-06-14 09:15:29 --> Helper loaded: url_helper
INFO - 2022-06-14 09:15:29 --> Helper loaded: file_helper
INFO - 2022-06-14 09:15:29 --> Helper loaded: form_helper
INFO - 2022-06-14 09:15:29 --> Helper loaded: my_helper
INFO - 2022-06-14 09:15:29 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:15:29 --> Controller Class Initialized
DEBUG - 2022-06-14 09:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:15:29 --> Final output sent to browser
DEBUG - 2022-06-14 09:15:29 --> Total execution time: 0.0482
INFO - 2022-06-14 09:15:31 --> Config Class Initialized
INFO - 2022-06-14 09:15:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:15:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:15:31 --> Utf8 Class Initialized
INFO - 2022-06-14 09:15:31 --> URI Class Initialized
INFO - 2022-06-14 09:15:31 --> Router Class Initialized
INFO - 2022-06-14 09:15:31 --> Output Class Initialized
INFO - 2022-06-14 09:15:31 --> Security Class Initialized
DEBUG - 2022-06-14 09:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:15:31 --> Input Class Initialized
INFO - 2022-06-14 09:15:31 --> Language Class Initialized
INFO - 2022-06-14 09:15:31 --> Language Class Initialized
INFO - 2022-06-14 09:15:31 --> Config Class Initialized
INFO - 2022-06-14 09:15:31 --> Loader Class Initialized
INFO - 2022-06-14 09:15:31 --> Helper loaded: url_helper
INFO - 2022-06-14 09:15:31 --> Helper loaded: file_helper
INFO - 2022-06-14 09:15:31 --> Helper loaded: form_helper
INFO - 2022-06-14 09:15:31 --> Helper loaded: my_helper
INFO - 2022-06-14 09:15:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:15:31 --> Controller Class Initialized
DEBUG - 2022-06-14 09:15:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 09:15:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:15:31 --> Final output sent to browser
DEBUG - 2022-06-14 09:15:31 --> Total execution time: 0.0507
INFO - 2022-06-14 09:15:32 --> Config Class Initialized
INFO - 2022-06-14 09:15:32 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:15:32 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:15:32 --> Utf8 Class Initialized
INFO - 2022-06-14 09:15:32 --> URI Class Initialized
INFO - 2022-06-14 09:15:32 --> Router Class Initialized
INFO - 2022-06-14 09:15:32 --> Output Class Initialized
INFO - 2022-06-14 09:15:32 --> Security Class Initialized
DEBUG - 2022-06-14 09:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:15:32 --> Input Class Initialized
INFO - 2022-06-14 09:15:32 --> Language Class Initialized
INFO - 2022-06-14 09:15:32 --> Language Class Initialized
INFO - 2022-06-14 09:15:32 --> Config Class Initialized
INFO - 2022-06-14 09:15:32 --> Loader Class Initialized
INFO - 2022-06-14 09:15:32 --> Helper loaded: url_helper
INFO - 2022-06-14 09:15:32 --> Helper loaded: file_helper
INFO - 2022-06-14 09:15:32 --> Helper loaded: form_helper
INFO - 2022-06-14 09:15:32 --> Helper loaded: my_helper
INFO - 2022-06-14 09:15:32 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:15:32 --> Controller Class Initialized
DEBUG - 2022-06-14 09:15:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:15:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:15:32 --> Final output sent to browser
DEBUG - 2022-06-14 09:15:32 --> Total execution time: 0.0430
INFO - 2022-06-14 09:23:13 --> Config Class Initialized
INFO - 2022-06-14 09:23:13 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:23:13 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:23:13 --> Utf8 Class Initialized
INFO - 2022-06-14 09:23:13 --> URI Class Initialized
INFO - 2022-06-14 09:23:13 --> Router Class Initialized
INFO - 2022-06-14 09:23:13 --> Output Class Initialized
INFO - 2022-06-14 09:23:13 --> Security Class Initialized
DEBUG - 2022-06-14 09:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:23:13 --> Input Class Initialized
INFO - 2022-06-14 09:23:13 --> Language Class Initialized
INFO - 2022-06-14 09:23:13 --> Language Class Initialized
INFO - 2022-06-14 09:23:13 --> Config Class Initialized
INFO - 2022-06-14 09:23:13 --> Loader Class Initialized
INFO - 2022-06-14 09:23:13 --> Helper loaded: url_helper
INFO - 2022-06-14 09:23:13 --> Helper loaded: file_helper
INFO - 2022-06-14 09:23:13 --> Helper loaded: form_helper
INFO - 2022-06-14 09:23:13 --> Helper loaded: my_helper
INFO - 2022-06-14 09:23:13 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:23:13 --> Controller Class Initialized
INFO - 2022-06-14 09:23:13 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:23:13 --> Config Class Initialized
INFO - 2022-06-14 09:23:13 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:23:13 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:23:13 --> Utf8 Class Initialized
INFO - 2022-06-14 09:23:13 --> URI Class Initialized
INFO - 2022-06-14 09:23:13 --> Router Class Initialized
INFO - 2022-06-14 09:23:13 --> Output Class Initialized
INFO - 2022-06-14 09:23:13 --> Security Class Initialized
DEBUG - 2022-06-14 09:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:23:13 --> Input Class Initialized
INFO - 2022-06-14 09:23:13 --> Language Class Initialized
INFO - 2022-06-14 09:23:13 --> Language Class Initialized
INFO - 2022-06-14 09:23:13 --> Config Class Initialized
INFO - 2022-06-14 09:23:13 --> Loader Class Initialized
INFO - 2022-06-14 09:23:13 --> Helper loaded: url_helper
INFO - 2022-06-14 09:23:13 --> Helper loaded: file_helper
INFO - 2022-06-14 09:23:13 --> Helper loaded: form_helper
INFO - 2022-06-14 09:23:13 --> Helper loaded: my_helper
INFO - 2022-06-14 09:23:13 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:23:13 --> Controller Class Initialized
DEBUG - 2022-06-14 09:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:23:13 --> Final output sent to browser
DEBUG - 2022-06-14 09:23:13 --> Total execution time: 0.0519
INFO - 2022-06-14 09:25:34 --> Config Class Initialized
INFO - 2022-06-14 09:25:34 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:25:34 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:25:34 --> Utf8 Class Initialized
INFO - 2022-06-14 09:25:34 --> URI Class Initialized
DEBUG - 2022-06-14 09:25:34 --> No URI present. Default controller set.
INFO - 2022-06-14 09:25:34 --> Router Class Initialized
INFO - 2022-06-14 09:25:34 --> Output Class Initialized
INFO - 2022-06-14 09:25:34 --> Security Class Initialized
DEBUG - 2022-06-14 09:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:25:34 --> Input Class Initialized
INFO - 2022-06-14 09:25:34 --> Language Class Initialized
INFO - 2022-06-14 09:25:34 --> Language Class Initialized
INFO - 2022-06-14 09:25:34 --> Config Class Initialized
INFO - 2022-06-14 09:25:34 --> Loader Class Initialized
INFO - 2022-06-14 09:25:34 --> Helper loaded: url_helper
INFO - 2022-06-14 09:25:34 --> Helper loaded: file_helper
INFO - 2022-06-14 09:25:34 --> Helper loaded: form_helper
INFO - 2022-06-14 09:25:34 --> Helper loaded: my_helper
INFO - 2022-06-14 09:25:34 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:25:34 --> Controller Class Initialized
INFO - 2022-06-14 09:25:34 --> Config Class Initialized
INFO - 2022-06-14 09:25:34 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:25:34 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:25:34 --> Utf8 Class Initialized
INFO - 2022-06-14 09:25:34 --> URI Class Initialized
INFO - 2022-06-14 09:25:34 --> Router Class Initialized
INFO - 2022-06-14 09:25:34 --> Output Class Initialized
INFO - 2022-06-14 09:25:34 --> Security Class Initialized
DEBUG - 2022-06-14 09:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:25:34 --> Input Class Initialized
INFO - 2022-06-14 09:25:34 --> Language Class Initialized
INFO - 2022-06-14 09:25:34 --> Language Class Initialized
INFO - 2022-06-14 09:25:34 --> Config Class Initialized
INFO - 2022-06-14 09:25:34 --> Loader Class Initialized
INFO - 2022-06-14 09:25:34 --> Helper loaded: url_helper
INFO - 2022-06-14 09:25:34 --> Helper loaded: file_helper
INFO - 2022-06-14 09:25:34 --> Helper loaded: form_helper
INFO - 2022-06-14 09:25:34 --> Helper loaded: my_helper
INFO - 2022-06-14 09:25:34 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:25:34 --> Controller Class Initialized
DEBUG - 2022-06-14 09:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:25:34 --> Final output sent to browser
DEBUG - 2022-06-14 09:25:34 --> Total execution time: 0.0382
INFO - 2022-06-14 09:25:50 --> Config Class Initialized
INFO - 2022-06-14 09:25:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:25:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:25:50 --> Utf8 Class Initialized
INFO - 2022-06-14 09:25:50 --> URI Class Initialized
INFO - 2022-06-14 09:25:50 --> Router Class Initialized
INFO - 2022-06-14 09:25:50 --> Output Class Initialized
INFO - 2022-06-14 09:25:50 --> Security Class Initialized
DEBUG - 2022-06-14 09:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:25:50 --> Input Class Initialized
INFO - 2022-06-14 09:25:50 --> Language Class Initialized
INFO - 2022-06-14 09:25:50 --> Language Class Initialized
INFO - 2022-06-14 09:25:50 --> Config Class Initialized
INFO - 2022-06-14 09:25:50 --> Loader Class Initialized
INFO - 2022-06-14 09:25:50 --> Helper loaded: url_helper
INFO - 2022-06-14 09:25:50 --> Helper loaded: file_helper
INFO - 2022-06-14 09:25:50 --> Helper loaded: form_helper
INFO - 2022-06-14 09:25:50 --> Helper loaded: my_helper
INFO - 2022-06-14 09:25:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:25:50 --> Controller Class Initialized
INFO - 2022-06-14 09:25:50 --> Final output sent to browser
DEBUG - 2022-06-14 09:25:50 --> Total execution time: 0.0445
INFO - 2022-06-14 09:26:02 --> Config Class Initialized
INFO - 2022-06-14 09:26:02 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:26:02 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:26:02 --> Utf8 Class Initialized
INFO - 2022-06-14 09:26:02 --> URI Class Initialized
INFO - 2022-06-14 09:26:02 --> Router Class Initialized
INFO - 2022-06-14 09:26:02 --> Output Class Initialized
INFO - 2022-06-14 09:26:02 --> Security Class Initialized
DEBUG - 2022-06-14 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:26:02 --> Input Class Initialized
INFO - 2022-06-14 09:26:02 --> Language Class Initialized
INFO - 2022-06-14 09:26:03 --> Language Class Initialized
INFO - 2022-06-14 09:26:03 --> Config Class Initialized
INFO - 2022-06-14 09:26:03 --> Loader Class Initialized
INFO - 2022-06-14 09:26:03 --> Helper loaded: url_helper
INFO - 2022-06-14 09:26:03 --> Helper loaded: file_helper
INFO - 2022-06-14 09:26:03 --> Helper loaded: form_helper
INFO - 2022-06-14 09:26:03 --> Helper loaded: my_helper
INFO - 2022-06-14 09:26:03 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:26:03 --> Controller Class Initialized
INFO - 2022-06-14 09:26:03 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:26:03 --> Final output sent to browser
DEBUG - 2022-06-14 09:26:03 --> Total execution time: 0.0397
INFO - 2022-06-14 09:26:07 --> Config Class Initialized
INFO - 2022-06-14 09:26:07 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:26:07 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:26:07 --> Utf8 Class Initialized
INFO - 2022-06-14 09:26:07 --> URI Class Initialized
INFO - 2022-06-14 09:26:07 --> Router Class Initialized
INFO - 2022-06-14 09:26:07 --> Output Class Initialized
INFO - 2022-06-14 09:26:07 --> Security Class Initialized
DEBUG - 2022-06-14 09:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:26:07 --> Input Class Initialized
INFO - 2022-06-14 09:26:07 --> Language Class Initialized
INFO - 2022-06-14 09:26:07 --> Language Class Initialized
INFO - 2022-06-14 09:26:07 --> Config Class Initialized
INFO - 2022-06-14 09:26:07 --> Loader Class Initialized
INFO - 2022-06-14 09:26:07 --> Helper loaded: url_helper
INFO - 2022-06-14 09:26:07 --> Helper loaded: file_helper
INFO - 2022-06-14 09:26:07 --> Helper loaded: form_helper
INFO - 2022-06-14 09:26:07 --> Helper loaded: my_helper
INFO - 2022-06-14 09:26:07 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:26:07 --> Controller Class Initialized
DEBUG - 2022-06-14 09:26:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:26:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:26:07 --> Final output sent to browser
DEBUG - 2022-06-14 09:26:07 --> Total execution time: 0.0412
INFO - 2022-06-14 09:26:18 --> Config Class Initialized
INFO - 2022-06-14 09:26:18 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:26:18 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:26:18 --> Utf8 Class Initialized
INFO - 2022-06-14 09:26:18 --> URI Class Initialized
DEBUG - 2022-06-14 09:26:18 --> No URI present. Default controller set.
INFO - 2022-06-14 09:26:18 --> Router Class Initialized
INFO - 2022-06-14 09:26:18 --> Output Class Initialized
INFO - 2022-06-14 09:26:18 --> Security Class Initialized
DEBUG - 2022-06-14 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:26:18 --> Input Class Initialized
INFO - 2022-06-14 09:26:18 --> Language Class Initialized
INFO - 2022-06-14 09:26:18 --> Language Class Initialized
INFO - 2022-06-14 09:26:18 --> Config Class Initialized
INFO - 2022-06-14 09:26:18 --> Loader Class Initialized
INFO - 2022-06-14 09:26:18 --> Helper loaded: url_helper
INFO - 2022-06-14 09:26:18 --> Helper loaded: file_helper
INFO - 2022-06-14 09:26:18 --> Helper loaded: form_helper
INFO - 2022-06-14 09:26:18 --> Helper loaded: my_helper
INFO - 2022-06-14 09:26:18 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:26:18 --> Controller Class Initialized
INFO - 2022-06-14 09:26:18 --> Config Class Initialized
INFO - 2022-06-14 09:26:18 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:26:18 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:26:18 --> Utf8 Class Initialized
INFO - 2022-06-14 09:26:18 --> URI Class Initialized
INFO - 2022-06-14 09:26:18 --> Router Class Initialized
INFO - 2022-06-14 09:26:18 --> Output Class Initialized
INFO - 2022-06-14 09:26:18 --> Security Class Initialized
DEBUG - 2022-06-14 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:26:18 --> Input Class Initialized
INFO - 2022-06-14 09:26:18 --> Language Class Initialized
INFO - 2022-06-14 09:26:18 --> Language Class Initialized
INFO - 2022-06-14 09:26:18 --> Config Class Initialized
INFO - 2022-06-14 09:26:18 --> Loader Class Initialized
INFO - 2022-06-14 09:26:18 --> Helper loaded: url_helper
INFO - 2022-06-14 09:26:18 --> Helper loaded: file_helper
INFO - 2022-06-14 09:26:18 --> Helper loaded: form_helper
INFO - 2022-06-14 09:26:18 --> Helper loaded: my_helper
INFO - 2022-06-14 09:26:18 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:26:18 --> Controller Class Initialized
DEBUG - 2022-06-14 09:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:26:18 --> Final output sent to browser
DEBUG - 2022-06-14 09:26:18 --> Total execution time: 0.0460
INFO - 2022-06-14 09:26:55 --> Config Class Initialized
INFO - 2022-06-14 09:26:55 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:26:55 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:26:55 --> Utf8 Class Initialized
INFO - 2022-06-14 09:26:55 --> URI Class Initialized
INFO - 2022-06-14 09:26:56 --> Router Class Initialized
INFO - 2022-06-14 09:26:56 --> Output Class Initialized
INFO - 2022-06-14 09:26:56 --> Security Class Initialized
DEBUG - 2022-06-14 09:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:26:56 --> Input Class Initialized
INFO - 2022-06-14 09:26:56 --> Language Class Initialized
INFO - 2022-06-14 09:26:56 --> Language Class Initialized
INFO - 2022-06-14 09:26:56 --> Config Class Initialized
INFO - 2022-06-14 09:26:56 --> Loader Class Initialized
INFO - 2022-06-14 09:26:56 --> Helper loaded: url_helper
INFO - 2022-06-14 09:26:56 --> Helper loaded: file_helper
INFO - 2022-06-14 09:26:56 --> Helper loaded: form_helper
INFO - 2022-06-14 09:26:56 --> Helper loaded: my_helper
INFO - 2022-06-14 09:26:56 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:26:56 --> Controller Class Initialized
INFO - 2022-06-14 09:26:56 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:26:56 --> Final output sent to browser
DEBUG - 2022-06-14 09:26:56 --> Total execution time: 0.0439
INFO - 2022-06-14 09:27:00 --> Config Class Initialized
INFO - 2022-06-14 09:27:00 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:00 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:00 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:00 --> URI Class Initialized
INFO - 2022-06-14 09:27:00 --> Router Class Initialized
INFO - 2022-06-14 09:27:00 --> Output Class Initialized
INFO - 2022-06-14 09:27:00 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:00 --> Input Class Initialized
INFO - 2022-06-14 09:27:00 --> Language Class Initialized
INFO - 2022-06-14 09:27:00 --> Language Class Initialized
INFO - 2022-06-14 09:27:00 --> Config Class Initialized
INFO - 2022-06-14 09:27:00 --> Loader Class Initialized
INFO - 2022-06-14 09:27:00 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:00 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:00 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:00 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:00 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:00 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:00 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:00 --> Total execution time: 0.0405
INFO - 2022-06-14 09:27:07 --> Config Class Initialized
INFO - 2022-06-14 09:27:07 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:07 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:07 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:07 --> URI Class Initialized
DEBUG - 2022-06-14 09:27:07 --> No URI present. Default controller set.
INFO - 2022-06-14 09:27:07 --> Router Class Initialized
INFO - 2022-06-14 09:27:07 --> Output Class Initialized
INFO - 2022-06-14 09:27:07 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:07 --> Input Class Initialized
INFO - 2022-06-14 09:27:07 --> Language Class Initialized
INFO - 2022-06-14 09:27:07 --> Language Class Initialized
INFO - 2022-06-14 09:27:07 --> Config Class Initialized
INFO - 2022-06-14 09:27:07 --> Loader Class Initialized
INFO - 2022-06-14 09:27:07 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:07 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:07 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:07 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:07 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:07 --> Controller Class Initialized
INFO - 2022-06-14 09:27:07 --> Config Class Initialized
INFO - 2022-06-14 09:27:07 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:07 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:07 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:07 --> URI Class Initialized
INFO - 2022-06-14 09:27:07 --> Router Class Initialized
INFO - 2022-06-14 09:27:07 --> Output Class Initialized
INFO - 2022-06-14 09:27:07 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:07 --> Input Class Initialized
INFO - 2022-06-14 09:27:07 --> Language Class Initialized
INFO - 2022-06-14 09:27:07 --> Language Class Initialized
INFO - 2022-06-14 09:27:07 --> Config Class Initialized
INFO - 2022-06-14 09:27:07 --> Loader Class Initialized
INFO - 2022-06-14 09:27:07 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:07 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:07 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:07 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:07 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:07 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:27:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:07 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:07 --> Total execution time: 0.0461
INFO - 2022-06-14 09:27:16 --> Config Class Initialized
INFO - 2022-06-14 09:27:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:16 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:16 --> URI Class Initialized
INFO - 2022-06-14 09:27:16 --> Router Class Initialized
INFO - 2022-06-14 09:27:16 --> Output Class Initialized
INFO - 2022-06-14 09:27:16 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:16 --> Input Class Initialized
INFO - 2022-06-14 09:27:16 --> Language Class Initialized
INFO - 2022-06-14 09:27:16 --> Language Class Initialized
INFO - 2022-06-14 09:27:16 --> Config Class Initialized
INFO - 2022-06-14 09:27:16 --> Loader Class Initialized
INFO - 2022-06-14 09:27:16 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:16 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:16 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:16 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:16 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:27:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:16 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:16 --> Total execution time: 0.0414
INFO - 2022-06-14 09:27:22 --> Config Class Initialized
INFO - 2022-06-14 09:27:22 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:22 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:22 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:22 --> URI Class Initialized
INFO - 2022-06-14 09:27:22 --> Router Class Initialized
INFO - 2022-06-14 09:27:22 --> Output Class Initialized
INFO - 2022-06-14 09:27:22 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:22 --> Input Class Initialized
INFO - 2022-06-14 09:27:22 --> Language Class Initialized
INFO - 2022-06-14 09:27:22 --> Language Class Initialized
INFO - 2022-06-14 09:27:22 --> Config Class Initialized
INFO - 2022-06-14 09:27:22 --> Loader Class Initialized
INFO - 2022-06-14 09:27:22 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:22 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:22 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:22 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:22 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:22 --> Controller Class Initialized
INFO - 2022-06-14 09:27:22 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:27:22 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:22 --> Total execution time: 0.0424
INFO - 2022-06-14 09:27:22 --> Config Class Initialized
INFO - 2022-06-14 09:27:22 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:22 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:22 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:22 --> URI Class Initialized
INFO - 2022-06-14 09:27:22 --> Router Class Initialized
INFO - 2022-06-14 09:27:22 --> Output Class Initialized
INFO - 2022-06-14 09:27:22 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:22 --> Input Class Initialized
INFO - 2022-06-14 09:27:22 --> Language Class Initialized
INFO - 2022-06-14 09:27:22 --> Language Class Initialized
INFO - 2022-06-14 09:27:22 --> Config Class Initialized
INFO - 2022-06-14 09:27:22 --> Loader Class Initialized
INFO - 2022-06-14 09:27:22 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:22 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:22 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:22 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:22 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:22 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:27:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:22 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:22 --> Total execution time: 0.0560
INFO - 2022-06-14 09:27:28 --> Config Class Initialized
INFO - 2022-06-14 09:27:28 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:28 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:28 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:28 --> URI Class Initialized
INFO - 2022-06-14 09:27:28 --> Router Class Initialized
INFO - 2022-06-14 09:27:28 --> Output Class Initialized
INFO - 2022-06-14 09:27:28 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:28 --> Input Class Initialized
INFO - 2022-06-14 09:27:28 --> Language Class Initialized
INFO - 2022-06-14 09:27:28 --> Language Class Initialized
INFO - 2022-06-14 09:27:28 --> Config Class Initialized
INFO - 2022-06-14 09:27:28 --> Loader Class Initialized
INFO - 2022-06-14 09:27:28 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:28 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:28 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:28 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:28 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:28 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 09:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:28 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:28 --> Total execution time: 0.0503
INFO - 2022-06-14 09:27:31 --> Config Class Initialized
INFO - 2022-06-14 09:27:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:31 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:31 --> URI Class Initialized
INFO - 2022-06-14 09:27:31 --> Router Class Initialized
INFO - 2022-06-14 09:27:31 --> Output Class Initialized
INFO - 2022-06-14 09:27:31 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:31 --> Input Class Initialized
INFO - 2022-06-14 09:27:31 --> Language Class Initialized
INFO - 2022-06-14 09:27:31 --> Language Class Initialized
INFO - 2022-06-14 09:27:31 --> Config Class Initialized
INFO - 2022-06-14 09:27:31 --> Loader Class Initialized
INFO - 2022-06-14 09:27:31 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:31 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:31 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:31 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:31 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:27:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:31 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:31 --> Total execution time: 0.0465
INFO - 2022-06-14 09:27:31 --> Config Class Initialized
INFO - 2022-06-14 09:27:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:31 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:31 --> URI Class Initialized
INFO - 2022-06-14 09:27:31 --> Router Class Initialized
INFO - 2022-06-14 09:27:31 --> Output Class Initialized
INFO - 2022-06-14 09:27:31 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:31 --> Input Class Initialized
INFO - 2022-06-14 09:27:31 --> Language Class Initialized
INFO - 2022-06-14 09:27:31 --> Language Class Initialized
INFO - 2022-06-14 09:27:31 --> Config Class Initialized
INFO - 2022-06-14 09:27:31 --> Loader Class Initialized
INFO - 2022-06-14 09:27:31 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:31 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:31 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:31 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:31 --> Controller Class Initialized
INFO - 2022-06-14 09:27:32 --> Config Class Initialized
INFO - 2022-06-14 09:27:32 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:32 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:32 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:32 --> URI Class Initialized
INFO - 2022-06-14 09:27:32 --> Router Class Initialized
INFO - 2022-06-14 09:27:32 --> Output Class Initialized
INFO - 2022-06-14 09:27:32 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:32 --> Input Class Initialized
INFO - 2022-06-14 09:27:32 --> Language Class Initialized
INFO - 2022-06-14 09:27:32 --> Language Class Initialized
INFO - 2022-06-14 09:27:32 --> Config Class Initialized
INFO - 2022-06-14 09:27:32 --> Loader Class Initialized
INFO - 2022-06-14 09:27:32 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:32 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:32 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:32 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:32 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:32 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:27:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:32 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:32 --> Total execution time: 0.0458
INFO - 2022-06-14 09:27:33 --> Config Class Initialized
INFO - 2022-06-14 09:27:33 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:33 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:33 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:33 --> URI Class Initialized
INFO - 2022-06-14 09:27:33 --> Router Class Initialized
INFO - 2022-06-14 09:27:33 --> Output Class Initialized
INFO - 2022-06-14 09:27:33 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:33 --> Input Class Initialized
INFO - 2022-06-14 09:27:33 --> Language Class Initialized
INFO - 2022-06-14 09:27:33 --> Language Class Initialized
INFO - 2022-06-14 09:27:33 --> Config Class Initialized
INFO - 2022-06-14 09:27:33 --> Loader Class Initialized
INFO - 2022-06-14 09:27:33 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:33 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:33 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:33 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:33 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:33 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:33 --> Total execution time: 0.0458
INFO - 2022-06-14 09:27:34 --> Config Class Initialized
INFO - 2022-06-14 09:27:34 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:34 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:34 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:34 --> URI Class Initialized
INFO - 2022-06-14 09:27:34 --> Router Class Initialized
INFO - 2022-06-14 09:27:34 --> Output Class Initialized
INFO - 2022-06-14 09:27:34 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:34 --> Input Class Initialized
INFO - 2022-06-14 09:27:34 --> Language Class Initialized
INFO - 2022-06-14 09:27:34 --> Language Class Initialized
INFO - 2022-06-14 09:27:34 --> Config Class Initialized
INFO - 2022-06-14 09:27:34 --> Loader Class Initialized
INFO - 2022-06-14 09:27:34 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:34 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:34 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:34 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:34 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:34 --> Controller Class Initialized
INFO - 2022-06-14 09:27:35 --> Config Class Initialized
INFO - 2022-06-14 09:27:35 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:35 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:35 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:35 --> URI Class Initialized
INFO - 2022-06-14 09:27:35 --> Router Class Initialized
INFO - 2022-06-14 09:27:35 --> Output Class Initialized
INFO - 2022-06-14 09:27:35 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:35 --> Input Class Initialized
INFO - 2022-06-14 09:27:35 --> Language Class Initialized
INFO - 2022-06-14 09:27:35 --> Language Class Initialized
INFO - 2022-06-14 09:27:35 --> Config Class Initialized
INFO - 2022-06-14 09:27:35 --> Loader Class Initialized
INFO - 2022-06-14 09:27:35 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:35 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:35 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:35 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:35 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:35 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:27:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:35 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:35 --> Total execution time: 0.0453
INFO - 2022-06-14 09:27:36 --> Config Class Initialized
INFO - 2022-06-14 09:27:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:36 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:36 --> URI Class Initialized
INFO - 2022-06-14 09:27:36 --> Router Class Initialized
INFO - 2022-06-14 09:27:36 --> Output Class Initialized
INFO - 2022-06-14 09:27:36 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:36 --> Input Class Initialized
INFO - 2022-06-14 09:27:36 --> Language Class Initialized
INFO - 2022-06-14 09:27:36 --> Language Class Initialized
INFO - 2022-06-14 09:27:36 --> Config Class Initialized
INFO - 2022-06-14 09:27:36 --> Loader Class Initialized
INFO - 2022-06-14 09:27:36 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:36 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:36 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:36 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:36 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:36 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:36 --> Total execution time: 0.0552
INFO - 2022-06-14 09:27:36 --> Config Class Initialized
INFO - 2022-06-14 09:27:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:36 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:36 --> URI Class Initialized
INFO - 2022-06-14 09:27:36 --> Config Class Initialized
INFO - 2022-06-14 09:27:36 --> Router Class Initialized
INFO - 2022-06-14 09:27:36 --> Hooks Class Initialized
INFO - 2022-06-14 09:27:36 --> Output Class Initialized
DEBUG - 2022-06-14 09:27:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:36 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:36 --> Security Class Initialized
INFO - 2022-06-14 09:27:36 --> URI Class Initialized
DEBUG - 2022-06-14 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:36 --> Input Class Initialized
INFO - 2022-06-14 09:27:36 --> Language Class Initialized
INFO - 2022-06-14 09:27:36 --> Router Class Initialized
INFO - 2022-06-14 09:27:36 --> Output Class Initialized
INFO - 2022-06-14 09:27:36 --> Security Class Initialized
INFO - 2022-06-14 09:27:36 --> Language Class Initialized
INFO - 2022-06-14 09:27:36 --> Config Class Initialized
INFO - 2022-06-14 09:27:36 --> Loader Class Initialized
DEBUG - 2022-06-14 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:36 --> Input Class Initialized
INFO - 2022-06-14 09:27:36 --> Language Class Initialized
INFO - 2022-06-14 09:27:36 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:36 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:36 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:36 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:36 --> Language Class Initialized
INFO - 2022-06-14 09:27:36 --> Config Class Initialized
INFO - 2022-06-14 09:27:36 --> Loader Class Initialized
INFO - 2022-06-14 09:27:36 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:36 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:36 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:36 --> Database Driver Class Initialized
INFO - 2022-06-14 09:27:36 --> Helper loaded: my_helper
DEBUG - 2022-06-14 09:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:36 --> Controller Class Initialized
INFO - 2022-06-14 09:27:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:36 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:36 --> Total execution time: 0.0430
DEBUG - 2022-06-14 09:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:36 --> Controller Class Initialized
INFO - 2022-06-14 09:27:37 --> Config Class Initialized
INFO - 2022-06-14 09:27:37 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:37 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:37 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:37 --> URI Class Initialized
INFO - 2022-06-14 09:27:37 --> Router Class Initialized
INFO - 2022-06-14 09:27:37 --> Output Class Initialized
INFO - 2022-06-14 09:27:37 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:37 --> Input Class Initialized
INFO - 2022-06-14 09:27:37 --> Language Class Initialized
INFO - 2022-06-14 09:27:37 --> Language Class Initialized
INFO - 2022-06-14 09:27:37 --> Config Class Initialized
INFO - 2022-06-14 09:27:37 --> Loader Class Initialized
INFO - 2022-06-14 09:27:37 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:37 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:37 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:37 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:37 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:37 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:37 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:37 --> Total execution time: 0.0458
INFO - 2022-06-14 09:27:39 --> Config Class Initialized
INFO - 2022-06-14 09:27:39 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:39 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:39 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:39 --> URI Class Initialized
INFO - 2022-06-14 09:27:39 --> Router Class Initialized
INFO - 2022-06-14 09:27:39 --> Output Class Initialized
INFO - 2022-06-14 09:27:39 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:39 --> Input Class Initialized
INFO - 2022-06-14 09:27:39 --> Language Class Initialized
INFO - 2022-06-14 09:27:39 --> Language Class Initialized
INFO - 2022-06-14 09:27:39 --> Config Class Initialized
INFO - 2022-06-14 09:27:39 --> Loader Class Initialized
INFO - 2022-06-14 09:27:39 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:39 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:39 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:39 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:39 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:39 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:27:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:39 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:39 --> Total execution time: 0.0467
INFO - 2022-06-14 09:27:40 --> Config Class Initialized
INFO - 2022-06-14 09:27:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:40 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:40 --> URI Class Initialized
INFO - 2022-06-14 09:27:40 --> Router Class Initialized
INFO - 2022-06-14 09:27:40 --> Output Class Initialized
INFO - 2022-06-14 09:27:40 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:40 --> Input Class Initialized
INFO - 2022-06-14 09:27:40 --> Language Class Initialized
INFO - 2022-06-14 09:27:40 --> Language Class Initialized
INFO - 2022-06-14 09:27:40 --> Config Class Initialized
INFO - 2022-06-14 09:27:40 --> Loader Class Initialized
INFO - 2022-06-14 09:27:40 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:40 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:40 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:40 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:40 --> Controller Class Initialized
INFO - 2022-06-14 09:27:40 --> Config Class Initialized
INFO - 2022-06-14 09:27:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:40 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:40 --> URI Class Initialized
INFO - 2022-06-14 09:27:40 --> Router Class Initialized
INFO - 2022-06-14 09:27:40 --> Output Class Initialized
INFO - 2022-06-14 09:27:40 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:40 --> Input Class Initialized
INFO - 2022-06-14 09:27:40 --> Language Class Initialized
INFO - 2022-06-14 09:27:40 --> Language Class Initialized
INFO - 2022-06-14 09:27:40 --> Config Class Initialized
INFO - 2022-06-14 09:27:40 --> Loader Class Initialized
INFO - 2022-06-14 09:27:40 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:40 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:40 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:40 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:40 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:40 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:40 --> Total execution time: 0.0495
INFO - 2022-06-14 09:27:41 --> Config Class Initialized
INFO - 2022-06-14 09:27:41 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:41 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:41 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:41 --> URI Class Initialized
INFO - 2022-06-14 09:27:41 --> Router Class Initialized
INFO - 2022-06-14 09:27:41 --> Output Class Initialized
INFO - 2022-06-14 09:27:41 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:41 --> Input Class Initialized
INFO - 2022-06-14 09:27:41 --> Language Class Initialized
INFO - 2022-06-14 09:27:41 --> Language Class Initialized
INFO - 2022-06-14 09:27:41 --> Config Class Initialized
INFO - 2022-06-14 09:27:41 --> Loader Class Initialized
INFO - 2022-06-14 09:27:41 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:41 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:41 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:41 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:41 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:41 --> Controller Class Initialized
DEBUG - 2022-06-14 09:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:27:41 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:41 --> Total execution time: 0.0443
INFO - 2022-06-14 09:27:43 --> Config Class Initialized
INFO - 2022-06-14 09:27:43 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:27:43 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:27:43 --> Utf8 Class Initialized
INFO - 2022-06-14 09:27:43 --> URI Class Initialized
INFO - 2022-06-14 09:27:43 --> Router Class Initialized
INFO - 2022-06-14 09:27:43 --> Output Class Initialized
INFO - 2022-06-14 09:27:43 --> Security Class Initialized
DEBUG - 2022-06-14 09:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:27:43 --> Input Class Initialized
INFO - 2022-06-14 09:27:43 --> Language Class Initialized
INFO - 2022-06-14 09:27:43 --> Language Class Initialized
INFO - 2022-06-14 09:27:43 --> Config Class Initialized
INFO - 2022-06-14 09:27:43 --> Loader Class Initialized
INFO - 2022-06-14 09:27:43 --> Helper loaded: url_helper
INFO - 2022-06-14 09:27:43 --> Helper loaded: file_helper
INFO - 2022-06-14 09:27:43 --> Helper loaded: form_helper
INFO - 2022-06-14 09:27:43 --> Helper loaded: my_helper
INFO - 2022-06-14 09:27:43 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:27:43 --> Controller Class Initialized
INFO - 2022-06-14 09:27:43 --> Final output sent to browser
DEBUG - 2022-06-14 09:27:43 --> Total execution time: 0.0486
INFO - 2022-06-14 09:28:36 --> Config Class Initialized
INFO - 2022-06-14 09:28:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:36 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:36 --> URI Class Initialized
INFO - 2022-06-14 09:28:36 --> Router Class Initialized
INFO - 2022-06-14 09:28:36 --> Output Class Initialized
INFO - 2022-06-14 09:28:36 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:36 --> Input Class Initialized
INFO - 2022-06-14 09:28:36 --> Language Class Initialized
INFO - 2022-06-14 09:28:36 --> Language Class Initialized
INFO - 2022-06-14 09:28:36 --> Config Class Initialized
INFO - 2022-06-14 09:28:36 --> Loader Class Initialized
INFO - 2022-06-14 09:28:37 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:37 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:37 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:37 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:37 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:37 --> Controller Class Initialized
INFO - 2022-06-14 09:28:38 --> Config Class Initialized
INFO - 2022-06-14 09:28:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:38 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:38 --> URI Class Initialized
INFO - 2022-06-14 09:28:38 --> Router Class Initialized
INFO - 2022-06-14 09:28:38 --> Output Class Initialized
INFO - 2022-06-14 09:28:38 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:38 --> Input Class Initialized
INFO - 2022-06-14 09:28:38 --> Language Class Initialized
INFO - 2022-06-14 09:28:38 --> Language Class Initialized
INFO - 2022-06-14 09:28:38 --> Config Class Initialized
INFO - 2022-06-14 09:28:38 --> Loader Class Initialized
INFO - 2022-06-14 09:28:38 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:38 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:38 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:38 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:38 --> Controller Class Initialized
INFO - 2022-06-14 09:28:41 --> Config Class Initialized
INFO - 2022-06-14 09:28:41 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:41 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:41 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:41 --> URI Class Initialized
INFO - 2022-06-14 09:28:41 --> Router Class Initialized
INFO - 2022-06-14 09:28:41 --> Output Class Initialized
INFO - 2022-06-14 09:28:41 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:41 --> Input Class Initialized
INFO - 2022-06-14 09:28:41 --> Language Class Initialized
INFO - 2022-06-14 09:28:41 --> Language Class Initialized
INFO - 2022-06-14 09:28:41 --> Config Class Initialized
INFO - 2022-06-14 09:28:41 --> Loader Class Initialized
INFO - 2022-06-14 09:28:41 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:41 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:41 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:41 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:41 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:41 --> Controller Class Initialized
INFO - 2022-06-14 09:28:42 --> Config Class Initialized
INFO - 2022-06-14 09:28:42 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:42 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:42 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:42 --> URI Class Initialized
INFO - 2022-06-14 09:28:42 --> Router Class Initialized
INFO - 2022-06-14 09:28:42 --> Output Class Initialized
INFO - 2022-06-14 09:28:42 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:42 --> Input Class Initialized
INFO - 2022-06-14 09:28:42 --> Language Class Initialized
INFO - 2022-06-14 09:28:42 --> Language Class Initialized
INFO - 2022-06-14 09:28:42 --> Config Class Initialized
INFO - 2022-06-14 09:28:42 --> Loader Class Initialized
INFO - 2022-06-14 09:28:42 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:42 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:42 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:42 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:42 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:42 --> Controller Class Initialized
INFO - 2022-06-14 09:28:44 --> Config Class Initialized
INFO - 2022-06-14 09:28:44 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:44 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:44 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:44 --> URI Class Initialized
INFO - 2022-06-14 09:28:44 --> Router Class Initialized
INFO - 2022-06-14 09:28:44 --> Output Class Initialized
INFO - 2022-06-14 09:28:44 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:44 --> Input Class Initialized
INFO - 2022-06-14 09:28:44 --> Language Class Initialized
INFO - 2022-06-14 09:28:44 --> Language Class Initialized
INFO - 2022-06-14 09:28:44 --> Config Class Initialized
INFO - 2022-06-14 09:28:44 --> Loader Class Initialized
INFO - 2022-06-14 09:28:44 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:44 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:44 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:44 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:44 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:44 --> Controller Class Initialized
INFO - 2022-06-14 09:28:45 --> Config Class Initialized
INFO - 2022-06-14 09:28:45 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:45 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:45 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:45 --> URI Class Initialized
INFO - 2022-06-14 09:28:45 --> Router Class Initialized
INFO - 2022-06-14 09:28:45 --> Output Class Initialized
INFO - 2022-06-14 09:28:45 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:45 --> Input Class Initialized
INFO - 2022-06-14 09:28:45 --> Language Class Initialized
INFO - 2022-06-14 09:28:45 --> Language Class Initialized
INFO - 2022-06-14 09:28:45 --> Config Class Initialized
INFO - 2022-06-14 09:28:45 --> Loader Class Initialized
INFO - 2022-06-14 09:28:45 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:45 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:45 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:45 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:45 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:45 --> Controller Class Initialized
INFO - 2022-06-14 09:28:48 --> Config Class Initialized
INFO - 2022-06-14 09:28:48 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:48 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:48 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:48 --> URI Class Initialized
INFO - 2022-06-14 09:28:48 --> Router Class Initialized
INFO - 2022-06-14 09:28:48 --> Output Class Initialized
INFO - 2022-06-14 09:28:48 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:48 --> Input Class Initialized
INFO - 2022-06-14 09:28:48 --> Language Class Initialized
INFO - 2022-06-14 09:28:48 --> Language Class Initialized
INFO - 2022-06-14 09:28:48 --> Config Class Initialized
INFO - 2022-06-14 09:28:48 --> Loader Class Initialized
INFO - 2022-06-14 09:28:48 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:48 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:48 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:48 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:48 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:48 --> Controller Class Initialized
INFO - 2022-06-14 09:28:49 --> Config Class Initialized
INFO - 2022-06-14 09:28:49 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:49 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:49 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:49 --> URI Class Initialized
INFO - 2022-06-14 09:28:49 --> Router Class Initialized
INFO - 2022-06-14 09:28:49 --> Output Class Initialized
INFO - 2022-06-14 09:28:49 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:49 --> Input Class Initialized
INFO - 2022-06-14 09:28:49 --> Language Class Initialized
INFO - 2022-06-14 09:28:49 --> Language Class Initialized
INFO - 2022-06-14 09:28:49 --> Config Class Initialized
INFO - 2022-06-14 09:28:49 --> Loader Class Initialized
INFO - 2022-06-14 09:28:49 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:49 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:49 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:49 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:49 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:49 --> Controller Class Initialized
INFO - 2022-06-14 09:28:56 --> Config Class Initialized
INFO - 2022-06-14 09:28:56 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:28:56 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:28:56 --> Utf8 Class Initialized
INFO - 2022-06-14 09:28:56 --> URI Class Initialized
INFO - 2022-06-14 09:28:56 --> Router Class Initialized
INFO - 2022-06-14 09:28:56 --> Output Class Initialized
INFO - 2022-06-14 09:28:56 --> Security Class Initialized
DEBUG - 2022-06-14 09:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:28:56 --> Input Class Initialized
INFO - 2022-06-14 09:28:56 --> Language Class Initialized
INFO - 2022-06-14 09:28:56 --> Language Class Initialized
INFO - 2022-06-14 09:28:56 --> Config Class Initialized
INFO - 2022-06-14 09:28:56 --> Loader Class Initialized
INFO - 2022-06-14 09:28:56 --> Helper loaded: url_helper
INFO - 2022-06-14 09:28:56 --> Helper loaded: file_helper
INFO - 2022-06-14 09:28:56 --> Helper loaded: form_helper
INFO - 2022-06-14 09:28:56 --> Helper loaded: my_helper
INFO - 2022-06-14 09:28:56 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:28:56 --> Controller Class Initialized
INFO - 2022-06-14 09:28:56 --> Final output sent to browser
DEBUG - 2022-06-14 09:28:56 --> Total execution time: 0.0397
INFO - 2022-06-14 09:29:04 --> Config Class Initialized
INFO - 2022-06-14 09:29:04 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:29:04 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:29:04 --> Utf8 Class Initialized
INFO - 2022-06-14 09:29:04 --> URI Class Initialized
INFO - 2022-06-14 09:29:04 --> Router Class Initialized
INFO - 2022-06-14 09:29:04 --> Output Class Initialized
INFO - 2022-06-14 09:29:04 --> Security Class Initialized
DEBUG - 2022-06-14 09:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:29:04 --> Input Class Initialized
INFO - 2022-06-14 09:29:04 --> Language Class Initialized
INFO - 2022-06-14 09:29:04 --> Language Class Initialized
INFO - 2022-06-14 09:29:04 --> Config Class Initialized
INFO - 2022-06-14 09:29:04 --> Loader Class Initialized
INFO - 2022-06-14 09:29:04 --> Helper loaded: url_helper
INFO - 2022-06-14 09:29:04 --> Helper loaded: file_helper
INFO - 2022-06-14 09:29:04 --> Helper loaded: form_helper
INFO - 2022-06-14 09:29:04 --> Helper loaded: my_helper
INFO - 2022-06-14 09:29:04 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:29:04 --> Controller Class Initialized
DEBUG - 2022-06-14 09:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:29:04 --> Final output sent to browser
DEBUG - 2022-06-14 09:29:04 --> Total execution time: 0.0515
INFO - 2022-06-14 09:29:14 --> Config Class Initialized
INFO - 2022-06-14 09:29:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:29:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:29:14 --> Utf8 Class Initialized
INFO - 2022-06-14 09:29:14 --> URI Class Initialized
INFO - 2022-06-14 09:29:14 --> Router Class Initialized
INFO - 2022-06-14 09:29:14 --> Output Class Initialized
INFO - 2022-06-14 09:29:14 --> Security Class Initialized
DEBUG - 2022-06-14 09:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:29:14 --> Input Class Initialized
INFO - 2022-06-14 09:29:14 --> Language Class Initialized
INFO - 2022-06-14 09:29:14 --> Language Class Initialized
INFO - 2022-06-14 09:29:14 --> Config Class Initialized
INFO - 2022-06-14 09:29:14 --> Loader Class Initialized
INFO - 2022-06-14 09:29:14 --> Helper loaded: url_helper
INFO - 2022-06-14 09:29:14 --> Helper loaded: file_helper
INFO - 2022-06-14 09:29:14 --> Helper loaded: form_helper
INFO - 2022-06-14 09:29:14 --> Helper loaded: my_helper
INFO - 2022-06-14 09:29:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:29:14 --> Controller Class Initialized
INFO - 2022-06-14 09:29:14 --> Final output sent to browser
DEBUG - 2022-06-14 09:29:14 --> Total execution time: 0.0905
INFO - 2022-06-14 09:29:19 --> Config Class Initialized
INFO - 2022-06-14 09:29:19 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:29:19 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:29:19 --> Utf8 Class Initialized
INFO - 2022-06-14 09:29:19 --> URI Class Initialized
INFO - 2022-06-14 09:29:19 --> Router Class Initialized
INFO - 2022-06-14 09:29:19 --> Output Class Initialized
INFO - 2022-06-14 09:29:19 --> Security Class Initialized
DEBUG - 2022-06-14 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:29:19 --> Input Class Initialized
INFO - 2022-06-14 09:29:19 --> Language Class Initialized
INFO - 2022-06-14 09:29:19 --> Language Class Initialized
INFO - 2022-06-14 09:29:19 --> Config Class Initialized
INFO - 2022-06-14 09:29:19 --> Loader Class Initialized
INFO - 2022-06-14 09:29:19 --> Helper loaded: url_helper
INFO - 2022-06-14 09:29:19 --> Helper loaded: file_helper
INFO - 2022-06-14 09:29:19 --> Helper loaded: form_helper
INFO - 2022-06-14 09:29:19 --> Helper loaded: my_helper
INFO - 2022-06-14 09:29:19 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:29:19 --> Controller Class Initialized
DEBUG - 2022-06-14 09:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 09:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:29:19 --> Final output sent to browser
DEBUG - 2022-06-14 09:29:19 --> Total execution time: 0.0634
INFO - 2022-06-14 09:29:23 --> Config Class Initialized
INFO - 2022-06-14 09:29:23 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:29:23 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:29:23 --> Utf8 Class Initialized
INFO - 2022-06-14 09:29:23 --> URI Class Initialized
INFO - 2022-06-14 09:29:23 --> Router Class Initialized
INFO - 2022-06-14 09:29:23 --> Output Class Initialized
INFO - 2022-06-14 09:29:23 --> Security Class Initialized
DEBUG - 2022-06-14 09:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:29:23 --> Input Class Initialized
INFO - 2022-06-14 09:29:23 --> Language Class Initialized
INFO - 2022-06-14 09:29:23 --> Language Class Initialized
INFO - 2022-06-14 09:29:23 --> Config Class Initialized
INFO - 2022-06-14 09:29:23 --> Loader Class Initialized
INFO - 2022-06-14 09:29:23 --> Helper loaded: url_helper
INFO - 2022-06-14 09:29:23 --> Helper loaded: file_helper
INFO - 2022-06-14 09:29:23 --> Helper loaded: form_helper
INFO - 2022-06-14 09:29:23 --> Helper loaded: my_helper
INFO - 2022-06-14 09:29:23 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:29:23 --> Controller Class Initialized
DEBUG - 2022-06-14 09:29:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:29:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:29:23 --> Final output sent to browser
DEBUG - 2022-06-14 09:29:23 --> Total execution time: 0.0509
INFO - 2022-06-14 09:30:02 --> Config Class Initialized
INFO - 2022-06-14 09:30:02 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:30:02 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:30:02 --> Utf8 Class Initialized
INFO - 2022-06-14 09:30:02 --> URI Class Initialized
INFO - 2022-06-14 09:30:02 --> Router Class Initialized
INFO - 2022-06-14 09:30:02 --> Output Class Initialized
INFO - 2022-06-14 09:30:02 --> Security Class Initialized
DEBUG - 2022-06-14 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:30:02 --> Input Class Initialized
INFO - 2022-06-14 09:30:02 --> Language Class Initialized
INFO - 2022-06-14 09:30:02 --> Language Class Initialized
INFO - 2022-06-14 09:30:02 --> Config Class Initialized
INFO - 2022-06-14 09:30:02 --> Loader Class Initialized
INFO - 2022-06-14 09:30:02 --> Helper loaded: url_helper
INFO - 2022-06-14 09:30:02 --> Helper loaded: file_helper
INFO - 2022-06-14 09:30:02 --> Helper loaded: form_helper
INFO - 2022-06-14 09:30:02 --> Helper loaded: my_helper
INFO - 2022-06-14 09:30:02 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:30:02 --> Controller Class Initialized
INFO - 2022-06-14 09:30:02 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:30:02 --> Config Class Initialized
INFO - 2022-06-14 09:30:02 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:30:02 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:30:02 --> Utf8 Class Initialized
INFO - 2022-06-14 09:30:02 --> URI Class Initialized
INFO - 2022-06-14 09:30:02 --> Router Class Initialized
INFO - 2022-06-14 09:30:02 --> Output Class Initialized
INFO - 2022-06-14 09:30:02 --> Security Class Initialized
DEBUG - 2022-06-14 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:30:02 --> Input Class Initialized
INFO - 2022-06-14 09:30:02 --> Language Class Initialized
INFO - 2022-06-14 09:30:02 --> Language Class Initialized
INFO - 2022-06-14 09:30:02 --> Config Class Initialized
INFO - 2022-06-14 09:30:02 --> Loader Class Initialized
INFO - 2022-06-14 09:30:02 --> Helper loaded: url_helper
INFO - 2022-06-14 09:30:02 --> Helper loaded: file_helper
INFO - 2022-06-14 09:30:02 --> Helper loaded: form_helper
INFO - 2022-06-14 09:30:02 --> Helper loaded: my_helper
INFO - 2022-06-14 09:30:02 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:30:02 --> Controller Class Initialized
DEBUG - 2022-06-14 09:30:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:30:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:30:02 --> Final output sent to browser
DEBUG - 2022-06-14 09:30:02 --> Total execution time: 0.0408
INFO - 2022-06-14 09:38:29 --> Config Class Initialized
INFO - 2022-06-14 09:38:29 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:38:29 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:38:29 --> Utf8 Class Initialized
INFO - 2022-06-14 09:38:29 --> URI Class Initialized
INFO - 2022-06-14 09:38:29 --> Router Class Initialized
INFO - 2022-06-14 09:38:29 --> Output Class Initialized
INFO - 2022-06-14 09:38:29 --> Security Class Initialized
DEBUG - 2022-06-14 09:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:38:29 --> Input Class Initialized
INFO - 2022-06-14 09:38:29 --> Language Class Initialized
INFO - 2022-06-14 09:38:29 --> Language Class Initialized
INFO - 2022-06-14 09:38:29 --> Config Class Initialized
INFO - 2022-06-14 09:38:29 --> Loader Class Initialized
INFO - 2022-06-14 09:38:29 --> Helper loaded: url_helper
INFO - 2022-06-14 09:38:29 --> Helper loaded: file_helper
INFO - 2022-06-14 09:38:29 --> Helper loaded: form_helper
INFO - 2022-06-14 09:38:29 --> Helper loaded: my_helper
INFO - 2022-06-14 09:38:29 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:38:29 --> Controller Class Initialized
INFO - 2022-06-14 09:38:29 --> Final output sent to browser
DEBUG - 2022-06-14 09:38:29 --> Total execution time: 0.0810
INFO - 2022-06-14 09:38:32 --> Config Class Initialized
INFO - 2022-06-14 09:38:32 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:38:32 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:38:32 --> Utf8 Class Initialized
INFO - 2022-06-14 09:38:32 --> URI Class Initialized
INFO - 2022-06-14 09:38:32 --> Router Class Initialized
INFO - 2022-06-14 09:38:32 --> Output Class Initialized
INFO - 2022-06-14 09:38:32 --> Security Class Initialized
DEBUG - 2022-06-14 09:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:38:32 --> Input Class Initialized
INFO - 2022-06-14 09:38:32 --> Language Class Initialized
INFO - 2022-06-14 09:38:32 --> Language Class Initialized
INFO - 2022-06-14 09:38:32 --> Config Class Initialized
INFO - 2022-06-14 09:38:32 --> Loader Class Initialized
INFO - 2022-06-14 09:38:32 --> Helper loaded: url_helper
INFO - 2022-06-14 09:38:32 --> Helper loaded: file_helper
INFO - 2022-06-14 09:38:32 --> Helper loaded: form_helper
INFO - 2022-06-14 09:38:32 --> Helper loaded: my_helper
INFO - 2022-06-14 09:38:32 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:38:32 --> Controller Class Initialized
DEBUG - 2022-06-14 09:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:38:32 --> Final output sent to browser
DEBUG - 2022-06-14 09:38:32 --> Total execution time: 0.0514
INFO - 2022-06-14 09:39:06 --> Config Class Initialized
INFO - 2022-06-14 09:39:06 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:06 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:06 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:06 --> URI Class Initialized
INFO - 2022-06-14 09:39:06 --> Router Class Initialized
INFO - 2022-06-14 09:39:06 --> Output Class Initialized
INFO - 2022-06-14 09:39:06 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:06 --> Input Class Initialized
INFO - 2022-06-14 09:39:06 --> Language Class Initialized
INFO - 2022-06-14 09:39:06 --> Language Class Initialized
INFO - 2022-06-14 09:39:06 --> Config Class Initialized
INFO - 2022-06-14 09:39:06 --> Loader Class Initialized
INFO - 2022-06-14 09:39:06 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:06 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:06 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:06 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:06 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:06 --> Controller Class Initialized
INFO - 2022-06-14 09:39:06 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:39:06 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:06 --> Total execution time: 0.0525
INFO - 2022-06-14 09:39:06 --> Config Class Initialized
INFO - 2022-06-14 09:39:06 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:06 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:06 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:06 --> URI Class Initialized
INFO - 2022-06-14 09:39:06 --> Router Class Initialized
INFO - 2022-06-14 09:39:06 --> Output Class Initialized
INFO - 2022-06-14 09:39:06 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:06 --> Input Class Initialized
INFO - 2022-06-14 09:39:06 --> Language Class Initialized
INFO - 2022-06-14 09:39:06 --> Language Class Initialized
INFO - 2022-06-14 09:39:06 --> Config Class Initialized
INFO - 2022-06-14 09:39:06 --> Loader Class Initialized
INFO - 2022-06-14 09:39:06 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:06 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:06 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:06 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:06 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:06 --> Controller Class Initialized
DEBUG - 2022-06-14 09:39:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:39:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:39:06 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:06 --> Total execution time: 0.0459
INFO - 2022-06-14 09:39:08 --> Config Class Initialized
INFO - 2022-06-14 09:39:08 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:08 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:08 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:08 --> URI Class Initialized
INFO - 2022-06-14 09:39:08 --> Router Class Initialized
INFO - 2022-06-14 09:39:08 --> Output Class Initialized
INFO - 2022-06-14 09:39:08 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:08 --> Input Class Initialized
INFO - 2022-06-14 09:39:08 --> Language Class Initialized
INFO - 2022-06-14 09:39:08 --> Language Class Initialized
INFO - 2022-06-14 09:39:08 --> Config Class Initialized
INFO - 2022-06-14 09:39:08 --> Loader Class Initialized
INFO - 2022-06-14 09:39:08 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:08 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:08 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:08 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:08 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:08 --> Controller Class Initialized
DEBUG - 2022-06-14 09:39:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-14 09:39:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:39:08 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:08 --> Total execution time: 0.0952
INFO - 2022-06-14 09:39:32 --> Config Class Initialized
INFO - 2022-06-14 09:39:32 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:32 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:32 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:32 --> URI Class Initialized
INFO - 2022-06-14 09:39:32 --> Router Class Initialized
INFO - 2022-06-14 09:39:32 --> Output Class Initialized
INFO - 2022-06-14 09:39:32 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:32 --> Input Class Initialized
INFO - 2022-06-14 09:39:32 --> Language Class Initialized
INFO - 2022-06-14 09:39:32 --> Language Class Initialized
INFO - 2022-06-14 09:39:32 --> Config Class Initialized
INFO - 2022-06-14 09:39:32 --> Loader Class Initialized
INFO - 2022-06-14 09:39:32 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:32 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:32 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:32 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:32 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:32 --> Controller Class Initialized
INFO - 2022-06-14 09:39:32 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:39:32 --> Config Class Initialized
INFO - 2022-06-14 09:39:32 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:32 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:32 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:32 --> URI Class Initialized
INFO - 2022-06-14 09:39:32 --> Router Class Initialized
INFO - 2022-06-14 09:39:32 --> Output Class Initialized
INFO - 2022-06-14 09:39:32 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:32 --> Input Class Initialized
INFO - 2022-06-14 09:39:32 --> Language Class Initialized
INFO - 2022-06-14 09:39:32 --> Language Class Initialized
INFO - 2022-06-14 09:39:32 --> Config Class Initialized
INFO - 2022-06-14 09:39:32 --> Loader Class Initialized
INFO - 2022-06-14 09:39:32 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:32 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:32 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:32 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:32 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:32 --> Controller Class Initialized
DEBUG - 2022-06-14 09:39:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:39:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:39:32 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:32 --> Total execution time: 0.0493
INFO - 2022-06-14 09:39:35 --> Config Class Initialized
INFO - 2022-06-14 09:39:35 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:35 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:35 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:35 --> URI Class Initialized
INFO - 2022-06-14 09:39:35 --> Router Class Initialized
INFO - 2022-06-14 09:39:35 --> Output Class Initialized
INFO - 2022-06-14 09:39:35 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:35 --> Input Class Initialized
INFO - 2022-06-14 09:39:35 --> Language Class Initialized
INFO - 2022-06-14 09:39:35 --> Language Class Initialized
INFO - 2022-06-14 09:39:35 --> Config Class Initialized
INFO - 2022-06-14 09:39:35 --> Loader Class Initialized
INFO - 2022-06-14 09:39:35 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:35 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:35 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:35 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:35 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:35 --> Controller Class Initialized
INFO - 2022-06-14 09:39:35 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:39:35 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:35 --> Total execution time: 0.0528
INFO - 2022-06-14 09:39:36 --> Config Class Initialized
INFO - 2022-06-14 09:39:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:36 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:36 --> URI Class Initialized
INFO - 2022-06-14 09:39:36 --> Router Class Initialized
INFO - 2022-06-14 09:39:36 --> Output Class Initialized
INFO - 2022-06-14 09:39:36 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:36 --> Input Class Initialized
INFO - 2022-06-14 09:39:36 --> Language Class Initialized
INFO - 2022-06-14 09:39:36 --> Language Class Initialized
INFO - 2022-06-14 09:39:36 --> Config Class Initialized
INFO - 2022-06-14 09:39:36 --> Loader Class Initialized
INFO - 2022-06-14 09:39:36 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:36 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:36 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:36 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:36 --> Controller Class Initialized
DEBUG - 2022-06-14 09:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:39:36 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:36 --> Total execution time: 0.0457
INFO - 2022-06-14 09:39:37 --> Config Class Initialized
INFO - 2022-06-14 09:39:37 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:37 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:37 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:37 --> URI Class Initialized
INFO - 2022-06-14 09:39:37 --> Router Class Initialized
INFO - 2022-06-14 09:39:37 --> Output Class Initialized
INFO - 2022-06-14 09:39:37 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:37 --> Input Class Initialized
INFO - 2022-06-14 09:39:37 --> Language Class Initialized
INFO - 2022-06-14 09:39:37 --> Language Class Initialized
INFO - 2022-06-14 09:39:37 --> Config Class Initialized
INFO - 2022-06-14 09:39:37 --> Loader Class Initialized
INFO - 2022-06-14 09:39:37 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:37 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:37 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:37 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:37 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:37 --> Controller Class Initialized
DEBUG - 2022-06-14 09:39:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-14 09:39:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:39:37 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:37 --> Total execution time: 0.0599
INFO - 2022-06-14 09:39:42 --> Config Class Initialized
INFO - 2022-06-14 09:39:42 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:42 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:42 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:42 --> URI Class Initialized
INFO - 2022-06-14 09:39:42 --> Router Class Initialized
INFO - 2022-06-14 09:39:42 --> Output Class Initialized
INFO - 2022-06-14 09:39:42 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:42 --> Input Class Initialized
INFO - 2022-06-14 09:39:42 --> Language Class Initialized
INFO - 2022-06-14 09:39:42 --> Language Class Initialized
INFO - 2022-06-14 09:39:42 --> Config Class Initialized
INFO - 2022-06-14 09:39:42 --> Loader Class Initialized
INFO - 2022-06-14 09:39:42 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:42 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:42 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:42 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:42 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:42 --> Controller Class Initialized
INFO - 2022-06-14 09:39:42 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:39:42 --> Config Class Initialized
INFO - 2022-06-14 09:39:42 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:42 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:42 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:42 --> URI Class Initialized
INFO - 2022-06-14 09:39:42 --> Router Class Initialized
INFO - 2022-06-14 09:39:42 --> Output Class Initialized
INFO - 2022-06-14 09:39:42 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:42 --> Input Class Initialized
INFO - 2022-06-14 09:39:42 --> Language Class Initialized
INFO - 2022-06-14 09:39:42 --> Language Class Initialized
INFO - 2022-06-14 09:39:42 --> Config Class Initialized
INFO - 2022-06-14 09:39:42 --> Loader Class Initialized
INFO - 2022-06-14 09:39:42 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:42 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:42 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:42 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:42 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:42 --> Controller Class Initialized
DEBUG - 2022-06-14 09:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:39:42 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:42 --> Total execution time: 0.0489
INFO - 2022-06-14 09:39:47 --> Config Class Initialized
INFO - 2022-06-14 09:39:47 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:47 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:47 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:47 --> URI Class Initialized
INFO - 2022-06-14 09:39:47 --> Router Class Initialized
INFO - 2022-06-14 09:39:47 --> Output Class Initialized
INFO - 2022-06-14 09:39:47 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:47 --> Input Class Initialized
INFO - 2022-06-14 09:39:47 --> Language Class Initialized
INFO - 2022-06-14 09:39:47 --> Language Class Initialized
INFO - 2022-06-14 09:39:47 --> Config Class Initialized
INFO - 2022-06-14 09:39:47 --> Loader Class Initialized
INFO - 2022-06-14 09:39:47 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:47 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:47 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:47 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:47 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:47 --> Controller Class Initialized
INFO - 2022-06-14 09:39:47 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:39:47 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:47 --> Total execution time: 0.0500
INFO - 2022-06-14 09:39:47 --> Config Class Initialized
INFO - 2022-06-14 09:39:47 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:47 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:47 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:47 --> URI Class Initialized
INFO - 2022-06-14 09:39:47 --> Router Class Initialized
INFO - 2022-06-14 09:39:47 --> Output Class Initialized
INFO - 2022-06-14 09:39:47 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:47 --> Input Class Initialized
INFO - 2022-06-14 09:39:47 --> Language Class Initialized
INFO - 2022-06-14 09:39:47 --> Language Class Initialized
INFO - 2022-06-14 09:39:47 --> Config Class Initialized
INFO - 2022-06-14 09:39:47 --> Loader Class Initialized
INFO - 2022-06-14 09:39:47 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:47 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:47 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:47 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:47 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:47 --> Controller Class Initialized
DEBUG - 2022-06-14 09:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:39:47 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:47 --> Total execution time: 0.0423
INFO - 2022-06-14 09:39:49 --> Config Class Initialized
INFO - 2022-06-14 09:39:49 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:39:49 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:39:49 --> Utf8 Class Initialized
INFO - 2022-06-14 09:39:49 --> URI Class Initialized
INFO - 2022-06-14 09:39:49 --> Router Class Initialized
INFO - 2022-06-14 09:39:49 --> Output Class Initialized
INFO - 2022-06-14 09:39:49 --> Security Class Initialized
DEBUG - 2022-06-14 09:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:39:49 --> Input Class Initialized
INFO - 2022-06-14 09:39:49 --> Language Class Initialized
INFO - 2022-06-14 09:39:49 --> Language Class Initialized
INFO - 2022-06-14 09:39:49 --> Config Class Initialized
INFO - 2022-06-14 09:39:49 --> Loader Class Initialized
INFO - 2022-06-14 09:39:49 --> Helper loaded: url_helper
INFO - 2022-06-14 09:39:49 --> Helper loaded: file_helper
INFO - 2022-06-14 09:39:49 --> Helper loaded: form_helper
INFO - 2022-06-14 09:39:49 --> Helper loaded: my_helper
INFO - 2022-06-14 09:39:49 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:39:49 --> Controller Class Initialized
DEBUG - 2022-06-14 09:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-06-14 09:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:39:49 --> Final output sent to browser
DEBUG - 2022-06-14 09:39:49 --> Total execution time: 0.2082
INFO - 2022-06-14 09:41:25 --> Config Class Initialized
INFO - 2022-06-14 09:41:25 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:41:25 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:41:25 --> Utf8 Class Initialized
INFO - 2022-06-14 09:41:25 --> URI Class Initialized
INFO - 2022-06-14 09:41:25 --> Router Class Initialized
INFO - 2022-06-14 09:41:25 --> Output Class Initialized
INFO - 2022-06-14 09:41:25 --> Security Class Initialized
DEBUG - 2022-06-14 09:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:41:25 --> Input Class Initialized
INFO - 2022-06-14 09:41:25 --> Language Class Initialized
INFO - 2022-06-14 09:41:25 --> Language Class Initialized
INFO - 2022-06-14 09:41:25 --> Config Class Initialized
INFO - 2022-06-14 09:41:25 --> Loader Class Initialized
INFO - 2022-06-14 09:41:25 --> Helper loaded: url_helper
INFO - 2022-06-14 09:41:25 --> Helper loaded: file_helper
INFO - 2022-06-14 09:41:25 --> Helper loaded: form_helper
INFO - 2022-06-14 09:41:25 --> Helper loaded: my_helper
INFO - 2022-06-14 09:41:25 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:41:25 --> Controller Class Initialized
DEBUG - 2022-06-14 09:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-06-14 09:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:41:25 --> Final output sent to browser
DEBUG - 2022-06-14 09:41:25 --> Total execution time: 0.1486
INFO - 2022-06-14 09:41:30 --> Config Class Initialized
INFO - 2022-06-14 09:41:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:41:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:41:30 --> Utf8 Class Initialized
INFO - 2022-06-14 09:41:30 --> URI Class Initialized
INFO - 2022-06-14 09:41:30 --> Router Class Initialized
INFO - 2022-06-14 09:41:30 --> Output Class Initialized
INFO - 2022-06-14 09:41:30 --> Security Class Initialized
DEBUG - 2022-06-14 09:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:41:30 --> Input Class Initialized
INFO - 2022-06-14 09:41:30 --> Language Class Initialized
INFO - 2022-06-14 09:41:30 --> Language Class Initialized
INFO - 2022-06-14 09:41:30 --> Config Class Initialized
INFO - 2022-06-14 09:41:30 --> Loader Class Initialized
INFO - 2022-06-14 09:41:30 --> Helper loaded: url_helper
INFO - 2022-06-14 09:41:30 --> Helper loaded: file_helper
INFO - 2022-06-14 09:41:30 --> Helper loaded: form_helper
INFO - 2022-06-14 09:41:30 --> Helper loaded: my_helper
INFO - 2022-06-14 09:41:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:41:30 --> Controller Class Initialized
INFO - 2022-06-14 09:41:30 --> Final output sent to browser
DEBUG - 2022-06-14 09:41:30 --> Total execution time: 0.0767
INFO - 2022-06-14 09:41:40 --> Config Class Initialized
INFO - 2022-06-14 09:41:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:41:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:41:40 --> Utf8 Class Initialized
INFO - 2022-06-14 09:41:40 --> URI Class Initialized
INFO - 2022-06-14 09:41:40 --> Router Class Initialized
INFO - 2022-06-14 09:41:40 --> Output Class Initialized
INFO - 2022-06-14 09:41:40 --> Security Class Initialized
DEBUG - 2022-06-14 09:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:41:40 --> Input Class Initialized
INFO - 2022-06-14 09:41:40 --> Language Class Initialized
INFO - 2022-06-14 09:41:40 --> Language Class Initialized
INFO - 2022-06-14 09:41:40 --> Config Class Initialized
INFO - 2022-06-14 09:41:40 --> Loader Class Initialized
INFO - 2022-06-14 09:41:40 --> Helper loaded: url_helper
INFO - 2022-06-14 09:41:40 --> Helper loaded: file_helper
INFO - 2022-06-14 09:41:40 --> Helper loaded: form_helper
INFO - 2022-06-14 09:41:40 --> Helper loaded: my_helper
INFO - 2022-06-14 09:41:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:41:40 --> Controller Class Initialized
DEBUG - 2022-06-14 09:41:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-06-14 09:41:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:41:40 --> Final output sent to browser
DEBUG - 2022-06-14 09:41:40 --> Total execution time: 0.0839
INFO - 2022-06-14 09:42:03 --> Config Class Initialized
INFO - 2022-06-14 09:42:03 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:42:03 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:42:03 --> Utf8 Class Initialized
INFO - 2022-06-14 09:42:03 --> URI Class Initialized
INFO - 2022-06-14 09:42:03 --> Router Class Initialized
INFO - 2022-06-14 09:42:03 --> Output Class Initialized
INFO - 2022-06-14 09:42:03 --> Security Class Initialized
DEBUG - 2022-06-14 09:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:42:03 --> Input Class Initialized
INFO - 2022-06-14 09:42:03 --> Language Class Initialized
INFO - 2022-06-14 09:42:03 --> Language Class Initialized
INFO - 2022-06-14 09:42:03 --> Config Class Initialized
INFO - 2022-06-14 09:42:03 --> Loader Class Initialized
INFO - 2022-06-14 09:42:03 --> Helper loaded: url_helper
INFO - 2022-06-14 09:42:03 --> Helper loaded: file_helper
INFO - 2022-06-14 09:42:03 --> Helper loaded: form_helper
INFO - 2022-06-14 09:42:03 --> Helper loaded: my_helper
INFO - 2022-06-14 09:42:03 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:42:03 --> Controller Class Initialized
INFO - 2022-06-14 09:42:03 --> Final output sent to browser
DEBUG - 2022-06-14 09:42:03 --> Total execution time: 0.0848
INFO - 2022-06-14 09:42:05 --> Config Class Initialized
INFO - 2022-06-14 09:42:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:42:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:42:05 --> Utf8 Class Initialized
INFO - 2022-06-14 09:42:05 --> URI Class Initialized
INFO - 2022-06-14 09:42:05 --> Router Class Initialized
INFO - 2022-06-14 09:42:05 --> Output Class Initialized
INFO - 2022-06-14 09:42:05 --> Security Class Initialized
DEBUG - 2022-06-14 09:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:42:05 --> Input Class Initialized
INFO - 2022-06-14 09:42:05 --> Language Class Initialized
INFO - 2022-06-14 09:42:05 --> Language Class Initialized
INFO - 2022-06-14 09:42:05 --> Config Class Initialized
INFO - 2022-06-14 09:42:05 --> Loader Class Initialized
INFO - 2022-06-14 09:42:05 --> Helper loaded: url_helper
INFO - 2022-06-14 09:42:05 --> Helper loaded: file_helper
INFO - 2022-06-14 09:42:05 --> Helper loaded: form_helper
INFO - 2022-06-14 09:42:05 --> Helper loaded: my_helper
INFO - 2022-06-14 09:42:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:42:05 --> Controller Class Initialized
DEBUG - 2022-06-14 09:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-06-14 09:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:42:05 --> Final output sent to browser
DEBUG - 2022-06-14 09:42:05 --> Total execution time: 0.0469
INFO - 2022-06-14 09:42:08 --> Config Class Initialized
INFO - 2022-06-14 09:42:08 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:42:08 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:42:08 --> Utf8 Class Initialized
INFO - 2022-06-14 09:42:08 --> URI Class Initialized
INFO - 2022-06-14 09:42:08 --> Router Class Initialized
INFO - 2022-06-14 09:42:08 --> Output Class Initialized
INFO - 2022-06-14 09:42:08 --> Security Class Initialized
DEBUG - 2022-06-14 09:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:42:08 --> Input Class Initialized
INFO - 2022-06-14 09:42:08 --> Language Class Initialized
INFO - 2022-06-14 09:42:08 --> Language Class Initialized
INFO - 2022-06-14 09:42:08 --> Config Class Initialized
INFO - 2022-06-14 09:42:08 --> Loader Class Initialized
INFO - 2022-06-14 09:42:08 --> Helper loaded: url_helper
INFO - 2022-06-14 09:42:08 --> Helper loaded: file_helper
INFO - 2022-06-14 09:42:08 --> Helper loaded: form_helper
INFO - 2022-06-14 09:42:08 --> Helper loaded: my_helper
INFO - 2022-06-14 09:42:09 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:42:09 --> Controller Class Initialized
DEBUG - 2022-06-14 09:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:42:09 --> Final output sent to browser
DEBUG - 2022-06-14 09:42:09 --> Total execution time: 0.0417
INFO - 2022-06-14 09:42:10 --> Config Class Initialized
INFO - 2022-06-14 09:42:10 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:42:10 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:42:10 --> Utf8 Class Initialized
INFO - 2022-06-14 09:42:10 --> URI Class Initialized
INFO - 2022-06-14 09:42:10 --> Router Class Initialized
INFO - 2022-06-14 09:42:10 --> Output Class Initialized
INFO - 2022-06-14 09:42:10 --> Security Class Initialized
DEBUG - 2022-06-14 09:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:42:10 --> Input Class Initialized
INFO - 2022-06-14 09:42:10 --> Language Class Initialized
INFO - 2022-06-14 09:42:10 --> Language Class Initialized
INFO - 2022-06-14 09:42:10 --> Config Class Initialized
INFO - 2022-06-14 09:42:10 --> Loader Class Initialized
INFO - 2022-06-14 09:42:10 --> Helper loaded: url_helper
INFO - 2022-06-14 09:42:10 --> Helper loaded: file_helper
INFO - 2022-06-14 09:42:10 --> Helper loaded: form_helper
INFO - 2022-06-14 09:42:10 --> Helper loaded: my_helper
INFO - 2022-06-14 09:42:10 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:42:10 --> Controller Class Initialized
INFO - 2022-06-14 09:42:10 --> Final output sent to browser
DEBUG - 2022-06-14 09:42:10 --> Total execution time: 0.0416
INFO - 2022-06-14 09:42:24 --> Config Class Initialized
INFO - 2022-06-14 09:42:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:42:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:42:24 --> Utf8 Class Initialized
INFO - 2022-06-14 09:42:24 --> URI Class Initialized
INFO - 2022-06-14 09:42:24 --> Router Class Initialized
INFO - 2022-06-14 09:42:24 --> Output Class Initialized
INFO - 2022-06-14 09:42:24 --> Security Class Initialized
DEBUG - 2022-06-14 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:42:24 --> Input Class Initialized
INFO - 2022-06-14 09:42:24 --> Language Class Initialized
INFO - 2022-06-14 09:42:24 --> Language Class Initialized
INFO - 2022-06-14 09:42:24 --> Config Class Initialized
INFO - 2022-06-14 09:42:24 --> Loader Class Initialized
INFO - 2022-06-14 09:42:24 --> Helper loaded: url_helper
INFO - 2022-06-14 09:42:24 --> Helper loaded: file_helper
INFO - 2022-06-14 09:42:24 --> Helper loaded: form_helper
INFO - 2022-06-14 09:42:24 --> Helper loaded: my_helper
INFO - 2022-06-14 09:42:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:42:24 --> Controller Class Initialized
INFO - 2022-06-14 09:42:24 --> Final output sent to browser
DEBUG - 2022-06-14 09:42:24 --> Total execution time: 0.0861
INFO - 2022-06-14 09:43:13 --> Config Class Initialized
INFO - 2022-06-14 09:43:13 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:43:13 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:43:13 --> Utf8 Class Initialized
INFO - 2022-06-14 09:43:13 --> URI Class Initialized
INFO - 2022-06-14 09:43:13 --> Router Class Initialized
INFO - 2022-06-14 09:43:13 --> Output Class Initialized
INFO - 2022-06-14 09:43:13 --> Security Class Initialized
DEBUG - 2022-06-14 09:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:43:13 --> Input Class Initialized
INFO - 2022-06-14 09:43:13 --> Language Class Initialized
INFO - 2022-06-14 09:43:13 --> Language Class Initialized
INFO - 2022-06-14 09:43:13 --> Config Class Initialized
INFO - 2022-06-14 09:43:13 --> Loader Class Initialized
INFO - 2022-06-14 09:43:13 --> Helper loaded: url_helper
INFO - 2022-06-14 09:43:13 --> Helper loaded: file_helper
INFO - 2022-06-14 09:43:13 --> Helper loaded: form_helper
INFO - 2022-06-14 09:43:13 --> Helper loaded: my_helper
INFO - 2022-06-14 09:43:13 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:43:13 --> Controller Class Initialized
ERROR - 2022-06-14 09:43:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('457','20212','D'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3','Baik')
INFO - 2022-06-14 09:43:13 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-14 09:44:59 --> Config Class Initialized
INFO - 2022-06-14 09:44:59 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:44:59 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:44:59 --> Utf8 Class Initialized
INFO - 2022-06-14 09:44:59 --> URI Class Initialized
INFO - 2022-06-14 09:44:59 --> Router Class Initialized
INFO - 2022-06-14 09:44:59 --> Output Class Initialized
INFO - 2022-06-14 09:44:59 --> Security Class Initialized
DEBUG - 2022-06-14 09:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:44:59 --> Input Class Initialized
INFO - 2022-06-14 09:44:59 --> Language Class Initialized
INFO - 2022-06-14 09:44:59 --> Language Class Initialized
INFO - 2022-06-14 09:44:59 --> Config Class Initialized
INFO - 2022-06-14 09:44:59 --> Loader Class Initialized
INFO - 2022-06-14 09:44:59 --> Helper loaded: url_helper
INFO - 2022-06-14 09:44:59 --> Helper loaded: file_helper
INFO - 2022-06-14 09:44:59 --> Helper loaded: form_helper
INFO - 2022-06-14 09:44:59 --> Helper loaded: my_helper
INFO - 2022-06-14 09:44:59 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:44:59 --> Controller Class Initialized
DEBUG - 2022-06-14 09:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:44:59 --> Final output sent to browser
DEBUG - 2022-06-14 09:44:59 --> Total execution time: 0.0581
INFO - 2022-06-14 09:45:02 --> Config Class Initialized
INFO - 2022-06-14 09:45:02 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:45:02 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:45:02 --> Utf8 Class Initialized
INFO - 2022-06-14 09:45:02 --> URI Class Initialized
INFO - 2022-06-14 09:45:02 --> Router Class Initialized
INFO - 2022-06-14 09:45:02 --> Output Class Initialized
INFO - 2022-06-14 09:45:02 --> Security Class Initialized
DEBUG - 2022-06-14 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:45:02 --> Input Class Initialized
INFO - 2022-06-14 09:45:02 --> Language Class Initialized
INFO - 2022-06-14 09:45:02 --> Language Class Initialized
INFO - 2022-06-14 09:45:02 --> Config Class Initialized
INFO - 2022-06-14 09:45:02 --> Loader Class Initialized
INFO - 2022-06-14 09:45:02 --> Helper loaded: url_helper
INFO - 2022-06-14 09:45:02 --> Helper loaded: file_helper
INFO - 2022-06-14 09:45:02 --> Helper loaded: form_helper
INFO - 2022-06-14 09:45:02 --> Helper loaded: my_helper
INFO - 2022-06-14 09:45:02 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:45:02 --> Controller Class Initialized
DEBUG - 2022-06-14 09:45:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 09:45:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:45:02 --> Final output sent to browser
DEBUG - 2022-06-14 09:45:02 --> Total execution time: 0.0575
INFO - 2022-06-14 09:45:22 --> Config Class Initialized
INFO - 2022-06-14 09:45:22 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:45:22 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:45:22 --> Utf8 Class Initialized
INFO - 2022-06-14 09:45:22 --> URI Class Initialized
INFO - 2022-06-14 09:45:22 --> Router Class Initialized
INFO - 2022-06-14 09:45:22 --> Output Class Initialized
INFO - 2022-06-14 09:45:22 --> Security Class Initialized
DEBUG - 2022-06-14 09:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:45:22 --> Input Class Initialized
INFO - 2022-06-14 09:45:22 --> Language Class Initialized
INFO - 2022-06-14 09:45:22 --> Language Class Initialized
INFO - 2022-06-14 09:45:22 --> Config Class Initialized
INFO - 2022-06-14 09:45:22 --> Loader Class Initialized
INFO - 2022-06-14 09:45:22 --> Helper loaded: url_helper
INFO - 2022-06-14 09:45:22 --> Helper loaded: file_helper
INFO - 2022-06-14 09:45:22 --> Helper loaded: form_helper
INFO - 2022-06-14 09:45:22 --> Helper loaded: my_helper
INFO - 2022-06-14 09:45:23 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:45:23 --> Controller Class Initialized
ERROR - 2022-06-14 09:45:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('457','20212','D'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3','Baik')
INFO - 2022-06-14 09:45:23 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-14 09:45:38 --> Config Class Initialized
INFO - 2022-06-14 09:45:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:45:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:45:38 --> Utf8 Class Initialized
INFO - 2022-06-14 09:45:38 --> URI Class Initialized
INFO - 2022-06-14 09:45:38 --> Router Class Initialized
INFO - 2022-06-14 09:45:38 --> Output Class Initialized
INFO - 2022-06-14 09:45:38 --> Security Class Initialized
DEBUG - 2022-06-14 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:45:38 --> Input Class Initialized
INFO - 2022-06-14 09:45:38 --> Language Class Initialized
INFO - 2022-06-14 09:45:38 --> Language Class Initialized
INFO - 2022-06-14 09:45:38 --> Config Class Initialized
INFO - 2022-06-14 09:45:38 --> Loader Class Initialized
INFO - 2022-06-14 09:45:38 --> Helper loaded: url_helper
INFO - 2022-06-14 09:45:38 --> Helper loaded: file_helper
INFO - 2022-06-14 09:45:38 --> Helper loaded: form_helper
INFO - 2022-06-14 09:45:38 --> Helper loaded: my_helper
INFO - 2022-06-14 09:45:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:45:38 --> Controller Class Initialized
DEBUG - 2022-06-14 09:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 09:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:45:39 --> Final output sent to browser
DEBUG - 2022-06-14 09:45:39 --> Total execution time: 0.0683
INFO - 2022-06-14 09:45:44 --> Config Class Initialized
INFO - 2022-06-14 09:45:44 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:45:44 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:45:44 --> Utf8 Class Initialized
INFO - 2022-06-14 09:45:44 --> URI Class Initialized
INFO - 2022-06-14 09:45:44 --> Router Class Initialized
INFO - 2022-06-14 09:45:44 --> Output Class Initialized
INFO - 2022-06-14 09:45:44 --> Security Class Initialized
DEBUG - 2022-06-14 09:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:45:44 --> Input Class Initialized
INFO - 2022-06-14 09:45:44 --> Language Class Initialized
INFO - 2022-06-14 09:45:44 --> Language Class Initialized
INFO - 2022-06-14 09:45:44 --> Config Class Initialized
INFO - 2022-06-14 09:45:44 --> Loader Class Initialized
INFO - 2022-06-14 09:45:44 --> Helper loaded: url_helper
INFO - 2022-06-14 09:45:44 --> Helper loaded: file_helper
INFO - 2022-06-14 09:45:44 --> Helper loaded: form_helper
INFO - 2022-06-14 09:45:44 --> Helper loaded: my_helper
INFO - 2022-06-14 09:45:44 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:45:44 --> Controller Class Initialized
DEBUG - 2022-06-14 09:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-14 09:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:45:44 --> Final output sent to browser
DEBUG - 2022-06-14 09:45:44 --> Total execution time: 0.0604
INFO - 2022-06-14 09:45:54 --> Config Class Initialized
INFO - 2022-06-14 09:45:54 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:45:54 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:45:54 --> Utf8 Class Initialized
INFO - 2022-06-14 09:45:54 --> URI Class Initialized
INFO - 2022-06-14 09:45:54 --> Router Class Initialized
INFO - 2022-06-14 09:45:54 --> Output Class Initialized
INFO - 2022-06-14 09:45:54 --> Security Class Initialized
DEBUG - 2022-06-14 09:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:45:54 --> Input Class Initialized
INFO - 2022-06-14 09:45:54 --> Language Class Initialized
INFO - 2022-06-14 09:45:54 --> Language Class Initialized
INFO - 2022-06-14 09:45:54 --> Config Class Initialized
INFO - 2022-06-14 09:45:54 --> Loader Class Initialized
INFO - 2022-06-14 09:45:54 --> Helper loaded: url_helper
INFO - 2022-06-14 09:45:54 --> Helper loaded: file_helper
INFO - 2022-06-14 09:45:54 --> Helper loaded: form_helper
INFO - 2022-06-14 09:45:54 --> Helper loaded: my_helper
INFO - 2022-06-14 09:45:54 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:45:54 --> Controller Class Initialized
DEBUG - 2022-06-14 09:45:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:45:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:45:54 --> Final output sent to browser
DEBUG - 2022-06-14 09:45:54 --> Total execution time: 0.0502
INFO - 2022-06-14 09:45:55 --> Config Class Initialized
INFO - 2022-06-14 09:45:55 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:45:55 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:45:55 --> Utf8 Class Initialized
INFO - 2022-06-14 09:45:55 --> URI Class Initialized
INFO - 2022-06-14 09:45:55 --> Router Class Initialized
INFO - 2022-06-14 09:45:55 --> Output Class Initialized
INFO - 2022-06-14 09:45:55 --> Security Class Initialized
DEBUG - 2022-06-14 09:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:45:55 --> Input Class Initialized
INFO - 2022-06-14 09:45:55 --> Language Class Initialized
INFO - 2022-06-14 09:45:55 --> Language Class Initialized
INFO - 2022-06-14 09:45:55 --> Config Class Initialized
INFO - 2022-06-14 09:45:55 --> Loader Class Initialized
INFO - 2022-06-14 09:45:55 --> Helper loaded: url_helper
INFO - 2022-06-14 09:45:55 --> Helper loaded: file_helper
INFO - 2022-06-14 09:45:55 --> Helper loaded: form_helper
INFO - 2022-06-14 09:45:55 --> Helper loaded: my_helper
INFO - 2022-06-14 09:45:55 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:45:55 --> Controller Class Initialized
INFO - 2022-06-14 09:45:55 --> Final output sent to browser
DEBUG - 2022-06-14 09:45:55 --> Total execution time: 0.0485
INFO - 2022-06-14 09:46:06 --> Config Class Initialized
INFO - 2022-06-14 09:46:06 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:46:06 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:46:06 --> Utf8 Class Initialized
INFO - 2022-06-14 09:46:06 --> URI Class Initialized
INFO - 2022-06-14 09:46:06 --> Router Class Initialized
INFO - 2022-06-14 09:46:06 --> Output Class Initialized
INFO - 2022-06-14 09:46:06 --> Security Class Initialized
DEBUG - 2022-06-14 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:46:06 --> Input Class Initialized
INFO - 2022-06-14 09:46:06 --> Language Class Initialized
INFO - 2022-06-14 09:46:06 --> Language Class Initialized
INFO - 2022-06-14 09:46:06 --> Config Class Initialized
INFO - 2022-06-14 09:46:06 --> Loader Class Initialized
INFO - 2022-06-14 09:46:06 --> Helper loaded: url_helper
INFO - 2022-06-14 09:46:06 --> Helper loaded: file_helper
INFO - 2022-06-14 09:46:06 --> Helper loaded: form_helper
INFO - 2022-06-14 09:46:06 --> Helper loaded: my_helper
INFO - 2022-06-14 09:46:06 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:46:06 --> Controller Class Initialized
INFO - 2022-06-14 09:46:06 --> Final output sent to browser
DEBUG - 2022-06-14 09:46:06 --> Total execution time: 0.0788
INFO - 2022-06-14 09:48:27 --> Config Class Initialized
INFO - 2022-06-14 09:48:27 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:48:27 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:48:27 --> Utf8 Class Initialized
INFO - 2022-06-14 09:48:27 --> URI Class Initialized
INFO - 2022-06-14 09:48:27 --> Router Class Initialized
INFO - 2022-06-14 09:48:27 --> Output Class Initialized
INFO - 2022-06-14 09:48:27 --> Security Class Initialized
DEBUG - 2022-06-14 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:48:27 --> Input Class Initialized
INFO - 2022-06-14 09:48:27 --> Language Class Initialized
INFO - 2022-06-14 09:48:27 --> Language Class Initialized
INFO - 2022-06-14 09:48:27 --> Config Class Initialized
INFO - 2022-06-14 09:48:27 --> Loader Class Initialized
INFO - 2022-06-14 09:48:27 --> Helper loaded: url_helper
INFO - 2022-06-14 09:48:27 --> Helper loaded: file_helper
INFO - 2022-06-14 09:48:27 --> Helper loaded: form_helper
INFO - 2022-06-14 09:48:27 --> Helper loaded: my_helper
INFO - 2022-06-14 09:48:27 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:48:27 --> Controller Class Initialized
ERROR - 2022-06-14 09:48:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('457','20212','D'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3','Baik')
INFO - 2022-06-14 09:48:27 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-14 09:49:14 --> Config Class Initialized
INFO - 2022-06-14 09:49:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:49:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:49:14 --> Utf8 Class Initialized
INFO - 2022-06-14 09:49:14 --> URI Class Initialized
INFO - 2022-06-14 09:49:14 --> Router Class Initialized
INFO - 2022-06-14 09:49:14 --> Output Class Initialized
INFO - 2022-06-14 09:49:14 --> Security Class Initialized
DEBUG - 2022-06-14 09:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:49:14 --> Input Class Initialized
INFO - 2022-06-14 09:49:14 --> Language Class Initialized
INFO - 2022-06-14 09:49:14 --> Language Class Initialized
INFO - 2022-06-14 09:49:14 --> Config Class Initialized
INFO - 2022-06-14 09:49:14 --> Loader Class Initialized
INFO - 2022-06-14 09:49:14 --> Helper loaded: url_helper
INFO - 2022-06-14 09:49:14 --> Helper loaded: file_helper
INFO - 2022-06-14 09:49:14 --> Helper loaded: form_helper
INFO - 2022-06-14 09:49:14 --> Helper loaded: my_helper
INFO - 2022-06-14 09:49:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:49:14 --> Controller Class Initialized
INFO - 2022-06-14 09:49:14 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:49:14 --> Config Class Initialized
INFO - 2022-06-14 09:49:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:49:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:49:14 --> Utf8 Class Initialized
INFO - 2022-06-14 09:49:14 --> URI Class Initialized
INFO - 2022-06-14 09:49:14 --> Router Class Initialized
INFO - 2022-06-14 09:49:14 --> Output Class Initialized
INFO - 2022-06-14 09:49:14 --> Security Class Initialized
DEBUG - 2022-06-14 09:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:49:14 --> Input Class Initialized
INFO - 2022-06-14 09:49:14 --> Language Class Initialized
INFO - 2022-06-14 09:49:14 --> Language Class Initialized
INFO - 2022-06-14 09:49:14 --> Config Class Initialized
INFO - 2022-06-14 09:49:14 --> Loader Class Initialized
INFO - 2022-06-14 09:49:14 --> Helper loaded: url_helper
INFO - 2022-06-14 09:49:14 --> Helper loaded: file_helper
INFO - 2022-06-14 09:49:14 --> Helper loaded: form_helper
INFO - 2022-06-14 09:49:14 --> Helper loaded: my_helper
INFO - 2022-06-14 09:49:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:49:14 --> Controller Class Initialized
DEBUG - 2022-06-14 09:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:49:14 --> Final output sent to browser
DEBUG - 2022-06-14 09:49:14 --> Total execution time: 0.0504
INFO - 2022-06-14 09:49:19 --> Config Class Initialized
INFO - 2022-06-14 09:49:19 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:49:19 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:49:19 --> Utf8 Class Initialized
INFO - 2022-06-14 09:49:19 --> URI Class Initialized
INFO - 2022-06-14 09:49:19 --> Router Class Initialized
INFO - 2022-06-14 09:49:19 --> Output Class Initialized
INFO - 2022-06-14 09:49:19 --> Security Class Initialized
DEBUG - 2022-06-14 09:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:49:19 --> Input Class Initialized
INFO - 2022-06-14 09:49:19 --> Language Class Initialized
INFO - 2022-06-14 09:49:19 --> Language Class Initialized
INFO - 2022-06-14 09:49:19 --> Config Class Initialized
INFO - 2022-06-14 09:49:19 --> Loader Class Initialized
INFO - 2022-06-14 09:49:19 --> Helper loaded: url_helper
INFO - 2022-06-14 09:49:19 --> Helper loaded: file_helper
INFO - 2022-06-14 09:49:19 --> Helper loaded: form_helper
INFO - 2022-06-14 09:49:19 --> Helper loaded: my_helper
INFO - 2022-06-14 09:49:19 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:49:19 --> Controller Class Initialized
INFO - 2022-06-14 09:49:20 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:49:20 --> Final output sent to browser
DEBUG - 2022-06-14 09:49:20 --> Total execution time: 0.2689
INFO - 2022-06-14 09:49:21 --> Config Class Initialized
INFO - 2022-06-14 09:49:21 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:49:21 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:49:21 --> Utf8 Class Initialized
INFO - 2022-06-14 09:49:21 --> URI Class Initialized
INFO - 2022-06-14 09:49:21 --> Router Class Initialized
INFO - 2022-06-14 09:49:21 --> Output Class Initialized
INFO - 2022-06-14 09:49:21 --> Security Class Initialized
DEBUG - 2022-06-14 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:49:21 --> Input Class Initialized
INFO - 2022-06-14 09:49:21 --> Language Class Initialized
INFO - 2022-06-14 09:49:21 --> Language Class Initialized
INFO - 2022-06-14 09:49:21 --> Config Class Initialized
INFO - 2022-06-14 09:49:21 --> Loader Class Initialized
INFO - 2022-06-14 09:49:21 --> Helper loaded: url_helper
INFO - 2022-06-14 09:49:21 --> Helper loaded: file_helper
INFO - 2022-06-14 09:49:21 --> Helper loaded: form_helper
INFO - 2022-06-14 09:49:21 --> Helper loaded: my_helper
INFO - 2022-06-14 09:49:21 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:49:21 --> Controller Class Initialized
DEBUG - 2022-06-14 09:49:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:49:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:49:21 --> Final output sent to browser
DEBUG - 2022-06-14 09:49:21 --> Total execution time: 0.0594
INFO - 2022-06-14 09:49:25 --> Config Class Initialized
INFO - 2022-06-14 09:49:25 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:49:25 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:49:25 --> Utf8 Class Initialized
INFO - 2022-06-14 09:49:25 --> URI Class Initialized
INFO - 2022-06-14 09:49:25 --> Router Class Initialized
INFO - 2022-06-14 09:49:25 --> Output Class Initialized
INFO - 2022-06-14 09:49:25 --> Security Class Initialized
DEBUG - 2022-06-14 09:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:49:25 --> Input Class Initialized
INFO - 2022-06-14 09:49:25 --> Language Class Initialized
INFO - 2022-06-14 09:49:25 --> Language Class Initialized
INFO - 2022-06-14 09:49:25 --> Config Class Initialized
INFO - 2022-06-14 09:49:25 --> Loader Class Initialized
INFO - 2022-06-14 09:49:25 --> Helper loaded: url_helper
INFO - 2022-06-14 09:49:25 --> Helper loaded: file_helper
INFO - 2022-06-14 09:49:25 --> Helper loaded: form_helper
INFO - 2022-06-14 09:49:25 --> Helper loaded: my_helper
INFO - 2022-06-14 09:49:25 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:49:25 --> Controller Class Initialized
DEBUG - 2022-06-14 09:49:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 09:49:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:49:25 --> Final output sent to browser
DEBUG - 2022-06-14 09:49:25 --> Total execution time: 0.0541
INFO - 2022-06-14 09:50:24 --> Config Class Initialized
INFO - 2022-06-14 09:50:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:24 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:24 --> URI Class Initialized
INFO - 2022-06-14 09:50:24 --> Router Class Initialized
INFO - 2022-06-14 09:50:24 --> Output Class Initialized
INFO - 2022-06-14 09:50:24 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:24 --> Input Class Initialized
INFO - 2022-06-14 09:50:24 --> Language Class Initialized
INFO - 2022-06-14 09:50:24 --> Language Class Initialized
INFO - 2022-06-14 09:50:24 --> Config Class Initialized
INFO - 2022-06-14 09:50:24 --> Loader Class Initialized
INFO - 2022-06-14 09:50:24 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:24 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:24 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:24 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:24 --> Controller Class Initialized
DEBUG - 2022-06-14 09:50:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:50:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:50:24 --> Final output sent to browser
DEBUG - 2022-06-14 09:50:24 --> Total execution time: 0.0498
INFO - 2022-06-14 09:50:24 --> Config Class Initialized
INFO - 2022-06-14 09:50:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:24 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:24 --> URI Class Initialized
INFO - 2022-06-14 09:50:24 --> Router Class Initialized
INFO - 2022-06-14 09:50:24 --> Output Class Initialized
INFO - 2022-06-14 09:50:24 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:24 --> Input Class Initialized
INFO - 2022-06-14 09:50:24 --> Language Class Initialized
INFO - 2022-06-14 09:50:24 --> Language Class Initialized
INFO - 2022-06-14 09:50:24 --> Config Class Initialized
INFO - 2022-06-14 09:50:24 --> Loader Class Initialized
INFO - 2022-06-14 09:50:24 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:24 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:24 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:24 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:24 --> Controller Class Initialized
INFO - 2022-06-14 09:50:25 --> Config Class Initialized
INFO - 2022-06-14 09:50:25 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:25 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:25 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:25 --> URI Class Initialized
INFO - 2022-06-14 09:50:25 --> Router Class Initialized
INFO - 2022-06-14 09:50:25 --> Output Class Initialized
INFO - 2022-06-14 09:50:25 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:25 --> Input Class Initialized
INFO - 2022-06-14 09:50:25 --> Language Class Initialized
INFO - 2022-06-14 09:50:25 --> Language Class Initialized
INFO - 2022-06-14 09:50:25 --> Config Class Initialized
INFO - 2022-06-14 09:50:25 --> Loader Class Initialized
INFO - 2022-06-14 09:50:25 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:25 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:25 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:25 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:25 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:25 --> Controller Class Initialized
DEBUG - 2022-06-14 09:50:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:50:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:50:25 --> Final output sent to browser
DEBUG - 2022-06-14 09:50:25 --> Total execution time: 0.0473
INFO - 2022-06-14 09:50:28 --> Config Class Initialized
INFO - 2022-06-14 09:50:28 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:28 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:28 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:28 --> URI Class Initialized
INFO - 2022-06-14 09:50:28 --> Router Class Initialized
INFO - 2022-06-14 09:50:28 --> Output Class Initialized
INFO - 2022-06-14 09:50:28 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:28 --> Input Class Initialized
INFO - 2022-06-14 09:50:28 --> Language Class Initialized
INFO - 2022-06-14 09:50:28 --> Language Class Initialized
INFO - 2022-06-14 09:50:28 --> Config Class Initialized
INFO - 2022-06-14 09:50:28 --> Loader Class Initialized
INFO - 2022-06-14 09:50:28 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:28 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:28 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:28 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:28 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:28 --> Controller Class Initialized
DEBUG - 2022-06-14 09:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:50:28 --> Final output sent to browser
DEBUG - 2022-06-14 09:50:28 --> Total execution time: 0.0482
INFO - 2022-06-14 09:50:28 --> Config Class Initialized
INFO - 2022-06-14 09:50:28 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:28 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:28 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:28 --> URI Class Initialized
INFO - 2022-06-14 09:50:28 --> Router Class Initialized
INFO - 2022-06-14 09:50:28 --> Output Class Initialized
INFO - 2022-06-14 09:50:28 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:28 --> Input Class Initialized
INFO - 2022-06-14 09:50:28 --> Language Class Initialized
INFO - 2022-06-14 09:50:28 --> Language Class Initialized
INFO - 2022-06-14 09:50:28 --> Config Class Initialized
INFO - 2022-06-14 09:50:28 --> Loader Class Initialized
INFO - 2022-06-14 09:50:28 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:28 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:28 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:28 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:28 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:28 --> Controller Class Initialized
INFO - 2022-06-14 09:50:30 --> Config Class Initialized
INFO - 2022-06-14 09:50:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:30 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:30 --> URI Class Initialized
INFO - 2022-06-14 09:50:30 --> Router Class Initialized
INFO - 2022-06-14 09:50:30 --> Output Class Initialized
INFO - 2022-06-14 09:50:30 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:30 --> Input Class Initialized
INFO - 2022-06-14 09:50:30 --> Language Class Initialized
INFO - 2022-06-14 09:50:30 --> Language Class Initialized
INFO - 2022-06-14 09:50:30 --> Config Class Initialized
INFO - 2022-06-14 09:50:30 --> Loader Class Initialized
INFO - 2022-06-14 09:50:30 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:30 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:30 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:30 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:30 --> Controller Class Initialized
DEBUG - 2022-06-14 09:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:50:30 --> Final output sent to browser
DEBUG - 2022-06-14 09:50:30 --> Total execution time: 0.0495
INFO - 2022-06-14 09:50:33 --> Config Class Initialized
INFO - 2022-06-14 09:50:33 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:33 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:33 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:33 --> URI Class Initialized
INFO - 2022-06-14 09:50:33 --> Router Class Initialized
INFO - 2022-06-14 09:50:33 --> Output Class Initialized
INFO - 2022-06-14 09:50:33 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:33 --> Input Class Initialized
INFO - 2022-06-14 09:50:33 --> Language Class Initialized
INFO - 2022-06-14 09:50:33 --> Language Class Initialized
INFO - 2022-06-14 09:50:33 --> Config Class Initialized
INFO - 2022-06-14 09:50:33 --> Loader Class Initialized
INFO - 2022-06-14 09:50:33 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:33 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:33 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:33 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:33 --> Controller Class Initialized
DEBUG - 2022-06-14 09:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:50:33 --> Final output sent to browser
DEBUG - 2022-06-14 09:50:33 --> Total execution time: 0.0473
INFO - 2022-06-14 09:50:33 --> Config Class Initialized
INFO - 2022-06-14 09:50:33 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:33 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:33 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:33 --> URI Class Initialized
INFO - 2022-06-14 09:50:33 --> Router Class Initialized
INFO - 2022-06-14 09:50:33 --> Output Class Initialized
INFO - 2022-06-14 09:50:33 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:33 --> Input Class Initialized
INFO - 2022-06-14 09:50:33 --> Language Class Initialized
INFO - 2022-06-14 09:50:33 --> Language Class Initialized
INFO - 2022-06-14 09:50:33 --> Config Class Initialized
INFO - 2022-06-14 09:50:33 --> Loader Class Initialized
INFO - 2022-06-14 09:50:33 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:33 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:33 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:33 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:33 --> Controller Class Initialized
INFO - 2022-06-14 09:50:34 --> Config Class Initialized
INFO - 2022-06-14 09:50:34 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:50:34 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:50:34 --> Utf8 Class Initialized
INFO - 2022-06-14 09:50:34 --> URI Class Initialized
INFO - 2022-06-14 09:50:34 --> Router Class Initialized
INFO - 2022-06-14 09:50:34 --> Output Class Initialized
INFO - 2022-06-14 09:50:34 --> Security Class Initialized
DEBUG - 2022-06-14 09:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:50:34 --> Input Class Initialized
INFO - 2022-06-14 09:50:34 --> Language Class Initialized
INFO - 2022-06-14 09:50:34 --> Language Class Initialized
INFO - 2022-06-14 09:50:34 --> Config Class Initialized
INFO - 2022-06-14 09:50:34 --> Loader Class Initialized
INFO - 2022-06-14 09:50:34 --> Helper loaded: url_helper
INFO - 2022-06-14 09:50:34 --> Helper loaded: file_helper
INFO - 2022-06-14 09:50:34 --> Helper loaded: form_helper
INFO - 2022-06-14 09:50:34 --> Helper loaded: my_helper
INFO - 2022-06-14 09:50:34 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:50:34 --> Controller Class Initialized
DEBUG - 2022-06-14 09:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:50:34 --> Final output sent to browser
DEBUG - 2022-06-14 09:50:34 --> Total execution time: 0.0448
INFO - 2022-06-14 09:51:10 --> Config Class Initialized
INFO - 2022-06-14 09:51:10 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:10 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:10 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:10 --> URI Class Initialized
DEBUG - 2022-06-14 09:51:10 --> No URI present. Default controller set.
INFO - 2022-06-14 09:51:10 --> Router Class Initialized
INFO - 2022-06-14 09:51:10 --> Output Class Initialized
INFO - 2022-06-14 09:51:10 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:10 --> Input Class Initialized
INFO - 2022-06-14 09:51:10 --> Language Class Initialized
INFO - 2022-06-14 09:51:10 --> Language Class Initialized
INFO - 2022-06-14 09:51:10 --> Config Class Initialized
INFO - 2022-06-14 09:51:10 --> Loader Class Initialized
INFO - 2022-06-14 09:51:10 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:10 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:10 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:10 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:10 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:10 --> Controller Class Initialized
INFO - 2022-06-14 09:51:10 --> Config Class Initialized
INFO - 2022-06-14 09:51:10 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:10 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:10 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:10 --> URI Class Initialized
INFO - 2022-06-14 09:51:10 --> Router Class Initialized
INFO - 2022-06-14 09:51:10 --> Output Class Initialized
INFO - 2022-06-14 09:51:10 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:10 --> Input Class Initialized
INFO - 2022-06-14 09:51:10 --> Language Class Initialized
INFO - 2022-06-14 09:51:10 --> Language Class Initialized
INFO - 2022-06-14 09:51:10 --> Config Class Initialized
INFO - 2022-06-14 09:51:10 --> Loader Class Initialized
INFO - 2022-06-14 09:51:10 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:10 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:10 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:10 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:10 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:10 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:10 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:10 --> Total execution time: 0.0466
INFO - 2022-06-14 09:51:11 --> Config Class Initialized
INFO - 2022-06-14 09:51:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:11 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:11 --> URI Class Initialized
INFO - 2022-06-14 09:51:11 --> Router Class Initialized
INFO - 2022-06-14 09:51:11 --> Output Class Initialized
INFO - 2022-06-14 09:51:11 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:11 --> Input Class Initialized
INFO - 2022-06-14 09:51:11 --> Language Class Initialized
INFO - 2022-06-14 09:51:11 --> Language Class Initialized
INFO - 2022-06-14 09:51:11 --> Config Class Initialized
INFO - 2022-06-14 09:51:11 --> Loader Class Initialized
INFO - 2022-06-14 09:51:11 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:11 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:11 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:11 --> Total execution time: 0.0479
INFO - 2022-06-14 09:51:11 --> Config Class Initialized
INFO - 2022-06-14 09:51:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:11 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:11 --> URI Class Initialized
INFO - 2022-06-14 09:51:11 --> Router Class Initialized
INFO - 2022-06-14 09:51:11 --> Output Class Initialized
INFO - 2022-06-14 09:51:11 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:11 --> Input Class Initialized
INFO - 2022-06-14 09:51:11 --> Language Class Initialized
INFO - 2022-06-14 09:51:11 --> Language Class Initialized
INFO - 2022-06-14 09:51:11 --> Config Class Initialized
INFO - 2022-06-14 09:51:11 --> Loader Class Initialized
INFO - 2022-06-14 09:51:11 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:11 --> Controller Class Initialized
INFO - 2022-06-14 09:51:11 --> Config Class Initialized
INFO - 2022-06-14 09:51:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:11 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:11 --> URI Class Initialized
DEBUG - 2022-06-14 09:51:11 --> No URI present. Default controller set.
INFO - 2022-06-14 09:51:11 --> Router Class Initialized
INFO - 2022-06-14 09:51:11 --> Output Class Initialized
INFO - 2022-06-14 09:51:11 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:11 --> Input Class Initialized
INFO - 2022-06-14 09:51:11 --> Language Class Initialized
INFO - 2022-06-14 09:51:11 --> Language Class Initialized
INFO - 2022-06-14 09:51:11 --> Config Class Initialized
INFO - 2022-06-14 09:51:11 --> Loader Class Initialized
INFO - 2022-06-14 09:51:11 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:11 --> Controller Class Initialized
INFO - 2022-06-14 09:51:11 --> Config Class Initialized
INFO - 2022-06-14 09:51:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:11 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:11 --> URI Class Initialized
INFO - 2022-06-14 09:51:11 --> Router Class Initialized
INFO - 2022-06-14 09:51:11 --> Output Class Initialized
INFO - 2022-06-14 09:51:11 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:11 --> Input Class Initialized
INFO - 2022-06-14 09:51:11 --> Language Class Initialized
INFO - 2022-06-14 09:51:11 --> Language Class Initialized
INFO - 2022-06-14 09:51:11 --> Config Class Initialized
INFO - 2022-06-14 09:51:11 --> Loader Class Initialized
INFO - 2022-06-14 09:51:11 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:11 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:12 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:12 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:12 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:12 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:12 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:12 --> Total execution time: 0.0487
INFO - 2022-06-14 09:51:12 --> Config Class Initialized
INFO - 2022-06-14 09:51:12 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:12 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:12 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:12 --> URI Class Initialized
INFO - 2022-06-14 09:51:12 --> Router Class Initialized
INFO - 2022-06-14 09:51:12 --> Output Class Initialized
INFO - 2022-06-14 09:51:12 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:12 --> Input Class Initialized
INFO - 2022-06-14 09:51:12 --> Language Class Initialized
INFO - 2022-06-14 09:51:12 --> Language Class Initialized
INFO - 2022-06-14 09:51:12 --> Config Class Initialized
INFO - 2022-06-14 09:51:12 --> Loader Class Initialized
INFO - 2022-06-14 09:51:12 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:12 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:12 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:12 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:12 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:12 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:12 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:12 --> Total execution time: 0.0444
INFO - 2022-06-14 09:51:24 --> Config Class Initialized
INFO - 2022-06-14 09:51:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:24 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:24 --> URI Class Initialized
INFO - 2022-06-14 09:51:24 --> Router Class Initialized
INFO - 2022-06-14 09:51:24 --> Output Class Initialized
INFO - 2022-06-14 09:51:24 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:24 --> Input Class Initialized
INFO - 2022-06-14 09:51:24 --> Language Class Initialized
INFO - 2022-06-14 09:51:24 --> Language Class Initialized
INFO - 2022-06-14 09:51:24 --> Config Class Initialized
INFO - 2022-06-14 09:51:24 --> Loader Class Initialized
INFO - 2022-06-14 09:51:24 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:24 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:24 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:24 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:24 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:24 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:24 --> Total execution time: 0.0465
INFO - 2022-06-14 09:51:24 --> Config Class Initialized
INFO - 2022-06-14 09:51:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:24 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:24 --> URI Class Initialized
INFO - 2022-06-14 09:51:24 --> Router Class Initialized
INFO - 2022-06-14 09:51:24 --> Output Class Initialized
INFO - 2022-06-14 09:51:24 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:24 --> Input Class Initialized
INFO - 2022-06-14 09:51:24 --> Language Class Initialized
INFO - 2022-06-14 09:51:24 --> Language Class Initialized
INFO - 2022-06-14 09:51:24 --> Config Class Initialized
INFO - 2022-06-14 09:51:24 --> Loader Class Initialized
INFO - 2022-06-14 09:51:24 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:24 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:24 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:24 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:24 --> Controller Class Initialized
INFO - 2022-06-14 09:51:25 --> Config Class Initialized
INFO - 2022-06-14 09:51:25 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:25 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:25 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:25 --> URI Class Initialized
INFO - 2022-06-14 09:51:25 --> Router Class Initialized
INFO - 2022-06-14 09:51:25 --> Output Class Initialized
INFO - 2022-06-14 09:51:25 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:25 --> Input Class Initialized
INFO - 2022-06-14 09:51:25 --> Language Class Initialized
INFO - 2022-06-14 09:51:25 --> Language Class Initialized
INFO - 2022-06-14 09:51:25 --> Config Class Initialized
INFO - 2022-06-14 09:51:25 --> Loader Class Initialized
INFO - 2022-06-14 09:51:25 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:25 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:25 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:25 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:25 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:25 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:25 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:25 --> Total execution time: 0.0456
INFO - 2022-06-14 09:51:26 --> Config Class Initialized
INFO - 2022-06-14 09:51:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:26 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:26 --> URI Class Initialized
INFO - 2022-06-14 09:51:26 --> Router Class Initialized
INFO - 2022-06-14 09:51:26 --> Output Class Initialized
INFO - 2022-06-14 09:51:26 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:26 --> Input Class Initialized
INFO - 2022-06-14 09:51:26 --> Language Class Initialized
INFO - 2022-06-14 09:51:26 --> Language Class Initialized
INFO - 2022-06-14 09:51:26 --> Config Class Initialized
INFO - 2022-06-14 09:51:26 --> Loader Class Initialized
INFO - 2022-06-14 09:51:26 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:26 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:26 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:26 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:26 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:26 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:26 --> Total execution time: 0.0466
INFO - 2022-06-14 09:51:26 --> Config Class Initialized
INFO - 2022-06-14 09:51:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:26 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:26 --> URI Class Initialized
INFO - 2022-06-14 09:51:26 --> Router Class Initialized
INFO - 2022-06-14 09:51:26 --> Output Class Initialized
INFO - 2022-06-14 09:51:26 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:26 --> Input Class Initialized
INFO - 2022-06-14 09:51:26 --> Language Class Initialized
INFO - 2022-06-14 09:51:26 --> Language Class Initialized
INFO - 2022-06-14 09:51:26 --> Config Class Initialized
INFO - 2022-06-14 09:51:26 --> Loader Class Initialized
INFO - 2022-06-14 09:51:26 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:26 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:26 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:26 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:26 --> Controller Class Initialized
INFO - 2022-06-14 09:51:27 --> Config Class Initialized
INFO - 2022-06-14 09:51:27 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:27 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:27 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:27 --> URI Class Initialized
INFO - 2022-06-14 09:51:27 --> Router Class Initialized
INFO - 2022-06-14 09:51:27 --> Output Class Initialized
INFO - 2022-06-14 09:51:27 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:27 --> Input Class Initialized
INFO - 2022-06-14 09:51:27 --> Language Class Initialized
INFO - 2022-06-14 09:51:27 --> Language Class Initialized
INFO - 2022-06-14 09:51:27 --> Config Class Initialized
INFO - 2022-06-14 09:51:27 --> Loader Class Initialized
INFO - 2022-06-14 09:51:27 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:27 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:27 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:27 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:27 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:27 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:27 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:27 --> Total execution time: 0.0462
INFO - 2022-06-14 09:51:29 --> Config Class Initialized
INFO - 2022-06-14 09:51:29 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:29 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:29 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:29 --> URI Class Initialized
INFO - 2022-06-14 09:51:29 --> Router Class Initialized
INFO - 2022-06-14 09:51:29 --> Output Class Initialized
INFO - 2022-06-14 09:51:29 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:29 --> Input Class Initialized
INFO - 2022-06-14 09:51:29 --> Language Class Initialized
INFO - 2022-06-14 09:51:29 --> Language Class Initialized
INFO - 2022-06-14 09:51:29 --> Config Class Initialized
INFO - 2022-06-14 09:51:29 --> Loader Class Initialized
INFO - 2022-06-14 09:51:29 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:29 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:29 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:29 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:29 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:29 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:29 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:29 --> Total execution time: 0.0473
INFO - 2022-06-14 09:51:29 --> Config Class Initialized
INFO - 2022-06-14 09:51:29 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:29 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:29 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:29 --> URI Class Initialized
INFO - 2022-06-14 09:51:29 --> Router Class Initialized
INFO - 2022-06-14 09:51:29 --> Output Class Initialized
INFO - 2022-06-14 09:51:29 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:29 --> Input Class Initialized
INFO - 2022-06-14 09:51:29 --> Language Class Initialized
INFO - 2022-06-14 09:51:29 --> Language Class Initialized
INFO - 2022-06-14 09:51:29 --> Config Class Initialized
INFO - 2022-06-14 09:51:29 --> Loader Class Initialized
INFO - 2022-06-14 09:51:29 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:29 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:29 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:29 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:29 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:29 --> Controller Class Initialized
INFO - 2022-06-14 09:51:30 --> Config Class Initialized
INFO - 2022-06-14 09:51:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:30 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:30 --> URI Class Initialized
INFO - 2022-06-14 09:51:30 --> Router Class Initialized
INFO - 2022-06-14 09:51:30 --> Output Class Initialized
INFO - 2022-06-14 09:51:30 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:30 --> Input Class Initialized
INFO - 2022-06-14 09:51:30 --> Language Class Initialized
INFO - 2022-06-14 09:51:30 --> Language Class Initialized
INFO - 2022-06-14 09:51:30 --> Config Class Initialized
INFO - 2022-06-14 09:51:30 --> Loader Class Initialized
INFO - 2022-06-14 09:51:30 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:30 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:30 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:30 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:30 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:30 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:30 --> Total execution time: 0.0474
INFO - 2022-06-14 09:51:33 --> Config Class Initialized
INFO - 2022-06-14 09:51:33 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:33 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:33 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:33 --> URI Class Initialized
INFO - 2022-06-14 09:51:33 --> Router Class Initialized
INFO - 2022-06-14 09:51:33 --> Output Class Initialized
INFO - 2022-06-14 09:51:33 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:33 --> Input Class Initialized
INFO - 2022-06-14 09:51:33 --> Language Class Initialized
INFO - 2022-06-14 09:51:33 --> Language Class Initialized
INFO - 2022-06-14 09:51:33 --> Config Class Initialized
INFO - 2022-06-14 09:51:33 --> Loader Class Initialized
INFO - 2022-06-14 09:51:33 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:33 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:33 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:33 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:33 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:33 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:33 --> Total execution time: 0.0475
INFO - 2022-06-14 09:51:33 --> Config Class Initialized
INFO - 2022-06-14 09:51:33 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:33 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:33 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:33 --> URI Class Initialized
INFO - 2022-06-14 09:51:33 --> Router Class Initialized
INFO - 2022-06-14 09:51:33 --> Output Class Initialized
INFO - 2022-06-14 09:51:33 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:33 --> Input Class Initialized
INFO - 2022-06-14 09:51:33 --> Language Class Initialized
INFO - 2022-06-14 09:51:33 --> Language Class Initialized
INFO - 2022-06-14 09:51:33 --> Config Class Initialized
INFO - 2022-06-14 09:51:33 --> Loader Class Initialized
INFO - 2022-06-14 09:51:33 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:33 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:33 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:33 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:33 --> Controller Class Initialized
INFO - 2022-06-14 09:51:34 --> Config Class Initialized
INFO - 2022-06-14 09:51:34 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:34 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:34 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:34 --> URI Class Initialized
INFO - 2022-06-14 09:51:34 --> Router Class Initialized
INFO - 2022-06-14 09:51:34 --> Output Class Initialized
INFO - 2022-06-14 09:51:34 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:34 --> Input Class Initialized
INFO - 2022-06-14 09:51:34 --> Language Class Initialized
INFO - 2022-06-14 09:51:34 --> Language Class Initialized
INFO - 2022-06-14 09:51:34 --> Config Class Initialized
INFO - 2022-06-14 09:51:34 --> Loader Class Initialized
INFO - 2022-06-14 09:51:34 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:34 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:34 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:34 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:34 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:34 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:34 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:34 --> Total execution time: 0.0566
INFO - 2022-06-14 09:51:36 --> Config Class Initialized
INFO - 2022-06-14 09:51:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:36 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:36 --> URI Class Initialized
INFO - 2022-06-14 09:51:36 --> Router Class Initialized
INFO - 2022-06-14 09:51:36 --> Output Class Initialized
INFO - 2022-06-14 09:51:36 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:36 --> Input Class Initialized
INFO - 2022-06-14 09:51:36 --> Language Class Initialized
INFO - 2022-06-14 09:51:36 --> Language Class Initialized
INFO - 2022-06-14 09:51:36 --> Config Class Initialized
INFO - 2022-06-14 09:51:36 --> Loader Class Initialized
INFO - 2022-06-14 09:51:36 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:36 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:36 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:36 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:36 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:36 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:36 --> Total execution time: 0.0477
INFO - 2022-06-14 09:51:36 --> Config Class Initialized
INFO - 2022-06-14 09:51:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:36 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:36 --> URI Class Initialized
INFO - 2022-06-14 09:51:36 --> Router Class Initialized
INFO - 2022-06-14 09:51:36 --> Output Class Initialized
INFO - 2022-06-14 09:51:36 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:36 --> Input Class Initialized
INFO - 2022-06-14 09:51:36 --> Language Class Initialized
INFO - 2022-06-14 09:51:36 --> Language Class Initialized
INFO - 2022-06-14 09:51:36 --> Config Class Initialized
INFO - 2022-06-14 09:51:36 --> Loader Class Initialized
INFO - 2022-06-14 09:51:36 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:36 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:36 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:36 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:36 --> Controller Class Initialized
INFO - 2022-06-14 09:51:37 --> Config Class Initialized
INFO - 2022-06-14 09:51:37 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:37 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:37 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:37 --> URI Class Initialized
INFO - 2022-06-14 09:51:37 --> Router Class Initialized
INFO - 2022-06-14 09:51:37 --> Output Class Initialized
INFO - 2022-06-14 09:51:37 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:37 --> Input Class Initialized
INFO - 2022-06-14 09:51:37 --> Language Class Initialized
INFO - 2022-06-14 09:51:37 --> Language Class Initialized
INFO - 2022-06-14 09:51:37 --> Config Class Initialized
INFO - 2022-06-14 09:51:37 --> Loader Class Initialized
INFO - 2022-06-14 09:51:37 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:37 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:37 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:37 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:37 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:37 --> Controller Class Initialized
INFO - 2022-06-14 09:51:37 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:51:37 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:37 --> Total execution time: 0.0480
INFO - 2022-06-14 09:51:37 --> Config Class Initialized
INFO - 2022-06-14 09:51:37 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:37 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:37 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:37 --> URI Class Initialized
INFO - 2022-06-14 09:51:37 --> Router Class Initialized
INFO - 2022-06-14 09:51:37 --> Output Class Initialized
INFO - 2022-06-14 09:51:37 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:37 --> Input Class Initialized
INFO - 2022-06-14 09:51:37 --> Language Class Initialized
INFO - 2022-06-14 09:51:37 --> Language Class Initialized
INFO - 2022-06-14 09:51:37 --> Config Class Initialized
INFO - 2022-06-14 09:51:37 --> Loader Class Initialized
INFO - 2022-06-14 09:51:37 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:37 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:37 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:37 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:37 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:37 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:37 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:37 --> Total execution time: 0.0464
INFO - 2022-06-14 09:51:38 --> Config Class Initialized
INFO - 2022-06-14 09:51:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:38 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:38 --> URI Class Initialized
INFO - 2022-06-14 09:51:38 --> Router Class Initialized
INFO - 2022-06-14 09:51:38 --> Output Class Initialized
INFO - 2022-06-14 09:51:38 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:38 --> Input Class Initialized
INFO - 2022-06-14 09:51:38 --> Language Class Initialized
INFO - 2022-06-14 09:51:38 --> Language Class Initialized
INFO - 2022-06-14 09:51:38 --> Config Class Initialized
INFO - 2022-06-14 09:51:38 --> Loader Class Initialized
INFO - 2022-06-14 09:51:38 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:38 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:38 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:38 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:38 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:38 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:38 --> Total execution time: 0.0461
INFO - 2022-06-14 09:51:39 --> Config Class Initialized
INFO - 2022-06-14 09:51:39 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:39 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:39 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:39 --> URI Class Initialized
INFO - 2022-06-14 09:51:39 --> Router Class Initialized
INFO - 2022-06-14 09:51:39 --> Output Class Initialized
INFO - 2022-06-14 09:51:39 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:39 --> Input Class Initialized
INFO - 2022-06-14 09:51:39 --> Language Class Initialized
INFO - 2022-06-14 09:51:39 --> Language Class Initialized
INFO - 2022-06-14 09:51:39 --> Config Class Initialized
INFO - 2022-06-14 09:51:39 --> Loader Class Initialized
INFO - 2022-06-14 09:51:39 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:39 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:39 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:39 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:39 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:39 --> Controller Class Initialized
INFO - 2022-06-14 09:51:40 --> Config Class Initialized
INFO - 2022-06-14 09:51:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:40 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:40 --> URI Class Initialized
INFO - 2022-06-14 09:51:40 --> Router Class Initialized
INFO - 2022-06-14 09:51:40 --> Output Class Initialized
INFO - 2022-06-14 09:51:40 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:40 --> Input Class Initialized
INFO - 2022-06-14 09:51:40 --> Language Class Initialized
INFO - 2022-06-14 09:51:40 --> Language Class Initialized
INFO - 2022-06-14 09:51:40 --> Config Class Initialized
INFO - 2022-06-14 09:51:40 --> Loader Class Initialized
INFO - 2022-06-14 09:51:40 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:40 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:40 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:40 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:40 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:40 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:40 --> Total execution time: 0.0462
INFO - 2022-06-14 09:51:40 --> Config Class Initialized
INFO - 2022-06-14 09:51:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:40 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:40 --> URI Class Initialized
INFO - 2022-06-14 09:51:40 --> Router Class Initialized
INFO - 2022-06-14 09:51:40 --> Output Class Initialized
INFO - 2022-06-14 09:51:40 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:40 --> Input Class Initialized
INFO - 2022-06-14 09:51:40 --> Language Class Initialized
INFO - 2022-06-14 09:51:40 --> Language Class Initialized
INFO - 2022-06-14 09:51:40 --> Config Class Initialized
INFO - 2022-06-14 09:51:40 --> Loader Class Initialized
INFO - 2022-06-14 09:51:40 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:40 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:40 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:40 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:40 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:40 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:40 --> Total execution time: 0.0527
INFO - 2022-06-14 09:51:46 --> Config Class Initialized
INFO - 2022-06-14 09:51:46 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:46 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:46 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:46 --> URI Class Initialized
INFO - 2022-06-14 09:51:46 --> Router Class Initialized
INFO - 2022-06-14 09:51:46 --> Output Class Initialized
INFO - 2022-06-14 09:51:46 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:46 --> Input Class Initialized
INFO - 2022-06-14 09:51:46 --> Language Class Initialized
INFO - 2022-06-14 09:51:46 --> Language Class Initialized
INFO - 2022-06-14 09:51:46 --> Config Class Initialized
INFO - 2022-06-14 09:51:46 --> Loader Class Initialized
INFO - 2022-06-14 09:51:46 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:46 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:46 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:46 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:46 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:46 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:46 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:46 --> Total execution time: 0.0466
INFO - 2022-06-14 09:51:46 --> Config Class Initialized
INFO - 2022-06-14 09:51:46 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:46 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:46 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:46 --> URI Class Initialized
INFO - 2022-06-14 09:51:46 --> Router Class Initialized
INFO - 2022-06-14 09:51:46 --> Output Class Initialized
INFO - 2022-06-14 09:51:46 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:46 --> Input Class Initialized
INFO - 2022-06-14 09:51:46 --> Language Class Initialized
INFO - 2022-06-14 09:51:46 --> Language Class Initialized
INFO - 2022-06-14 09:51:46 --> Config Class Initialized
INFO - 2022-06-14 09:51:46 --> Loader Class Initialized
INFO - 2022-06-14 09:51:46 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:46 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:46 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:46 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:46 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:46 --> Controller Class Initialized
INFO - 2022-06-14 09:51:48 --> Config Class Initialized
INFO - 2022-06-14 09:51:48 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:48 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:48 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:48 --> URI Class Initialized
INFO - 2022-06-14 09:51:48 --> Router Class Initialized
INFO - 2022-06-14 09:51:48 --> Output Class Initialized
INFO - 2022-06-14 09:51:48 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:48 --> Input Class Initialized
INFO - 2022-06-14 09:51:48 --> Language Class Initialized
INFO - 2022-06-14 09:51:48 --> Language Class Initialized
INFO - 2022-06-14 09:51:48 --> Config Class Initialized
INFO - 2022-06-14 09:51:48 --> Loader Class Initialized
INFO - 2022-06-14 09:51:48 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:48 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:48 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:48 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:48 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:48 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:48 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:48 --> Total execution time: 0.0465
INFO - 2022-06-14 09:51:50 --> Config Class Initialized
INFO - 2022-06-14 09:51:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:50 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:50 --> URI Class Initialized
INFO - 2022-06-14 09:51:50 --> Router Class Initialized
INFO - 2022-06-14 09:51:50 --> Output Class Initialized
INFO - 2022-06-14 09:51:50 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:50 --> Input Class Initialized
INFO - 2022-06-14 09:51:50 --> Language Class Initialized
INFO - 2022-06-14 09:51:50 --> Language Class Initialized
INFO - 2022-06-14 09:51:50 --> Config Class Initialized
INFO - 2022-06-14 09:51:50 --> Loader Class Initialized
INFO - 2022-06-14 09:51:50 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:50 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:50 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:50 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:50 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:50 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:50 --> Total execution time: 0.0478
INFO - 2022-06-14 09:51:50 --> Config Class Initialized
INFO - 2022-06-14 09:51:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:50 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:50 --> URI Class Initialized
INFO - 2022-06-14 09:51:50 --> Router Class Initialized
INFO - 2022-06-14 09:51:50 --> Output Class Initialized
INFO - 2022-06-14 09:51:50 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:50 --> Input Class Initialized
INFO - 2022-06-14 09:51:50 --> Language Class Initialized
INFO - 2022-06-14 09:51:50 --> Language Class Initialized
INFO - 2022-06-14 09:51:50 --> Config Class Initialized
INFO - 2022-06-14 09:51:50 --> Loader Class Initialized
INFO - 2022-06-14 09:51:50 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:50 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:50 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:50 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:50 --> Controller Class Initialized
INFO - 2022-06-14 09:51:51 --> Config Class Initialized
INFO - 2022-06-14 09:51:51 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:51 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:51 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:51 --> URI Class Initialized
INFO - 2022-06-14 09:51:51 --> Config Class Initialized
INFO - 2022-06-14 09:51:51 --> Hooks Class Initialized
INFO - 2022-06-14 09:51:51 --> Router Class Initialized
DEBUG - 2022-06-14 09:51:51 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:51 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:51 --> URI Class Initialized
INFO - 2022-06-14 09:51:51 --> Output Class Initialized
INFO - 2022-06-14 09:51:51 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:51 --> Router Class Initialized
INFO - 2022-06-14 09:51:51 --> Input Class Initialized
INFO - 2022-06-14 09:51:51 --> Language Class Initialized
INFO - 2022-06-14 09:51:51 --> Output Class Initialized
INFO - 2022-06-14 09:51:51 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:51 --> Input Class Initialized
INFO - 2022-06-14 09:51:51 --> Language Class Initialized
INFO - 2022-06-14 09:51:51 --> Language Class Initialized
INFO - 2022-06-14 09:51:51 --> Config Class Initialized
INFO - 2022-06-14 09:51:51 --> Loader Class Initialized
INFO - 2022-06-14 09:51:51 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:51 --> Language Class Initialized
INFO - 2022-06-14 09:51:51 --> Config Class Initialized
INFO - 2022-06-14 09:51:51 --> Loader Class Initialized
INFO - 2022-06-14 09:51:51 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:51 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:51 --> Database Driver Class Initialized
INFO - 2022-06-14 09:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:51 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 09:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-14 09:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:51 --> Final output sent to browser
INFO - 2022-06-14 09:51:51 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:51 --> Total execution time: 0.0470
DEBUG - 2022-06-14 09:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:51 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:51 --> Total execution time: 0.0478
INFO - 2022-06-14 09:51:51 --> Config Class Initialized
INFO - 2022-06-14 09:51:51 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:51 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:51 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:51 --> URI Class Initialized
INFO - 2022-06-14 09:51:51 --> Router Class Initialized
INFO - 2022-06-14 09:51:51 --> Output Class Initialized
INFO - 2022-06-14 09:51:51 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:51 --> Input Class Initialized
INFO - 2022-06-14 09:51:51 --> Language Class Initialized
INFO - 2022-06-14 09:51:51 --> Language Class Initialized
INFO - 2022-06-14 09:51:51 --> Config Class Initialized
INFO - 2022-06-14 09:51:51 --> Loader Class Initialized
INFO - 2022-06-14 09:51:51 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:51 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:51 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:52 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 09:51:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:52 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:52 --> Total execution time: 0.0447
INFO - 2022-06-14 09:51:53 --> Config Class Initialized
INFO - 2022-06-14 09:51:53 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:53 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:53 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:53 --> URI Class Initialized
INFO - 2022-06-14 09:51:53 --> Router Class Initialized
INFO - 2022-06-14 09:51:53 --> Output Class Initialized
INFO - 2022-06-14 09:51:53 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:53 --> Input Class Initialized
INFO - 2022-06-14 09:51:53 --> Language Class Initialized
INFO - 2022-06-14 09:51:53 --> Language Class Initialized
INFO - 2022-06-14 09:51:53 --> Config Class Initialized
INFO - 2022-06-14 09:51:53 --> Loader Class Initialized
INFO - 2022-06-14 09:51:53 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:53 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:53 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:53 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:53 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:53 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:53 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:53 --> Total execution time: 0.0453
INFO - 2022-06-14 09:51:53 --> Config Class Initialized
INFO - 2022-06-14 09:51:53 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:53 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:53 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:53 --> URI Class Initialized
INFO - 2022-06-14 09:51:53 --> Router Class Initialized
INFO - 2022-06-14 09:51:53 --> Output Class Initialized
INFO - 2022-06-14 09:51:53 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:53 --> Input Class Initialized
INFO - 2022-06-14 09:51:53 --> Language Class Initialized
INFO - 2022-06-14 09:51:53 --> Language Class Initialized
INFO - 2022-06-14 09:51:53 --> Config Class Initialized
INFO - 2022-06-14 09:51:53 --> Loader Class Initialized
INFO - 2022-06-14 09:51:53 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:53 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:53 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:53 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:53 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:53 --> Controller Class Initialized
INFO - 2022-06-14 09:51:55 --> Config Class Initialized
INFO - 2022-06-14 09:51:55 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:55 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:55 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:55 --> URI Class Initialized
INFO - 2022-06-14 09:51:55 --> Router Class Initialized
INFO - 2022-06-14 09:51:55 --> Output Class Initialized
INFO - 2022-06-14 09:51:55 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:55 --> Input Class Initialized
INFO - 2022-06-14 09:51:55 --> Language Class Initialized
INFO - 2022-06-14 09:51:55 --> Language Class Initialized
INFO - 2022-06-14 09:51:55 --> Config Class Initialized
INFO - 2022-06-14 09:51:55 --> Loader Class Initialized
INFO - 2022-06-14 09:51:55 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:55 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:55 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:55 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:55 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:55 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:55 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:55 --> Total execution time: 0.0479
INFO - 2022-06-14 09:51:57 --> Config Class Initialized
INFO - 2022-06-14 09:51:57 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:57 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:57 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:57 --> URI Class Initialized
INFO - 2022-06-14 09:51:57 --> Router Class Initialized
INFO - 2022-06-14 09:51:57 --> Output Class Initialized
INFO - 2022-06-14 09:51:57 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:57 --> Input Class Initialized
INFO - 2022-06-14 09:51:57 --> Language Class Initialized
INFO - 2022-06-14 09:51:57 --> Language Class Initialized
INFO - 2022-06-14 09:51:57 --> Config Class Initialized
INFO - 2022-06-14 09:51:57 --> Loader Class Initialized
INFO - 2022-06-14 09:51:57 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:57 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:57 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:57 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:57 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:57 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:51:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:57 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:57 --> Total execution time: 0.0458
INFO - 2022-06-14 09:51:57 --> Config Class Initialized
INFO - 2022-06-14 09:51:57 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:57 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:57 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:57 --> URI Class Initialized
INFO - 2022-06-14 09:51:57 --> Router Class Initialized
INFO - 2022-06-14 09:51:57 --> Output Class Initialized
INFO - 2022-06-14 09:51:57 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:57 --> Input Class Initialized
INFO - 2022-06-14 09:51:57 --> Language Class Initialized
INFO - 2022-06-14 09:51:57 --> Language Class Initialized
INFO - 2022-06-14 09:51:57 --> Config Class Initialized
INFO - 2022-06-14 09:51:57 --> Loader Class Initialized
INFO - 2022-06-14 09:51:57 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:57 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:57 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:57 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:57 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:57 --> Controller Class Initialized
INFO - 2022-06-14 09:51:59 --> Config Class Initialized
INFO - 2022-06-14 09:51:59 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:51:59 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:51:59 --> Utf8 Class Initialized
INFO - 2022-06-14 09:51:59 --> URI Class Initialized
INFO - 2022-06-14 09:51:59 --> Router Class Initialized
INFO - 2022-06-14 09:51:59 --> Output Class Initialized
INFO - 2022-06-14 09:51:59 --> Security Class Initialized
DEBUG - 2022-06-14 09:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:51:59 --> Input Class Initialized
INFO - 2022-06-14 09:51:59 --> Language Class Initialized
INFO - 2022-06-14 09:51:59 --> Language Class Initialized
INFO - 2022-06-14 09:51:59 --> Config Class Initialized
INFO - 2022-06-14 09:51:59 --> Loader Class Initialized
INFO - 2022-06-14 09:51:59 --> Helper loaded: url_helper
INFO - 2022-06-14 09:51:59 --> Helper loaded: file_helper
INFO - 2022-06-14 09:51:59 --> Helper loaded: form_helper
INFO - 2022-06-14 09:51:59 --> Helper loaded: my_helper
INFO - 2022-06-14 09:51:59 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:51:59 --> Controller Class Initialized
DEBUG - 2022-06-14 09:51:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:51:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:51:59 --> Final output sent to browser
DEBUG - 2022-06-14 09:51:59 --> Total execution time: 0.0456
INFO - 2022-06-14 09:52:01 --> Config Class Initialized
INFO - 2022-06-14 09:52:01 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:01 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:01 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:01 --> URI Class Initialized
INFO - 2022-06-14 09:52:01 --> Router Class Initialized
INFO - 2022-06-14 09:52:01 --> Output Class Initialized
INFO - 2022-06-14 09:52:01 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:01 --> Input Class Initialized
INFO - 2022-06-14 09:52:01 --> Language Class Initialized
INFO - 2022-06-14 09:52:01 --> Language Class Initialized
INFO - 2022-06-14 09:52:01 --> Config Class Initialized
INFO - 2022-06-14 09:52:01 --> Loader Class Initialized
INFO - 2022-06-14 09:52:01 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:01 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:01 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:52:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:01 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:01 --> Total execution time: 0.0460
INFO - 2022-06-14 09:52:01 --> Config Class Initialized
INFO - 2022-06-14 09:52:01 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:01 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:01 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:01 --> URI Class Initialized
INFO - 2022-06-14 09:52:01 --> Router Class Initialized
INFO - 2022-06-14 09:52:01 --> Output Class Initialized
INFO - 2022-06-14 09:52:01 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:01 --> Input Class Initialized
INFO - 2022-06-14 09:52:01 --> Language Class Initialized
INFO - 2022-06-14 09:52:01 --> Language Class Initialized
INFO - 2022-06-14 09:52:01 --> Config Class Initialized
INFO - 2022-06-14 09:52:01 --> Loader Class Initialized
INFO - 2022-06-14 09:52:01 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:01 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:01 --> Controller Class Initialized
INFO - 2022-06-14 09:52:01 --> Config Class Initialized
INFO - 2022-06-14 09:52:01 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:01 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:01 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:01 --> URI Class Initialized
INFO - 2022-06-14 09:52:01 --> Router Class Initialized
INFO - 2022-06-14 09:52:01 --> Output Class Initialized
INFO - 2022-06-14 09:52:01 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:01 --> Input Class Initialized
INFO - 2022-06-14 09:52:01 --> Language Class Initialized
INFO - 2022-06-14 09:52:01 --> Language Class Initialized
INFO - 2022-06-14 09:52:01 --> Config Class Initialized
INFO - 2022-06-14 09:52:01 --> Loader Class Initialized
INFO - 2022-06-14 09:52:01 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:01 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:01 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:01 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:52:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:01 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:01 --> Total execution time: 0.0394
INFO - 2022-06-14 09:52:02 --> Config Class Initialized
INFO - 2022-06-14 09:52:02 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:02 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:02 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:02 --> URI Class Initialized
INFO - 2022-06-14 09:52:02 --> Router Class Initialized
INFO - 2022-06-14 09:52:02 --> Output Class Initialized
INFO - 2022-06-14 09:52:02 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:02 --> Input Class Initialized
INFO - 2022-06-14 09:52:02 --> Language Class Initialized
INFO - 2022-06-14 09:52:02 --> Language Class Initialized
INFO - 2022-06-14 09:52:02 --> Config Class Initialized
INFO - 2022-06-14 09:52:02 --> Loader Class Initialized
INFO - 2022-06-14 09:52:02 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:02 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:02 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:02 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:02 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:02 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:52:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:02 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:02 --> Total execution time: 0.0460
INFO - 2022-06-14 09:52:04 --> Config Class Initialized
INFO - 2022-06-14 09:52:04 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:04 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:04 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:04 --> URI Class Initialized
INFO - 2022-06-14 09:52:04 --> Router Class Initialized
INFO - 2022-06-14 09:52:04 --> Output Class Initialized
INFO - 2022-06-14 09:52:04 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:04 --> Input Class Initialized
INFO - 2022-06-14 09:52:04 --> Language Class Initialized
INFO - 2022-06-14 09:52:04 --> Language Class Initialized
INFO - 2022-06-14 09:52:04 --> Config Class Initialized
INFO - 2022-06-14 09:52:04 --> Loader Class Initialized
INFO - 2022-06-14 09:52:04 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:04 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:04 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:04 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:04 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:04 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-06-14 09:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:04 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:04 --> Total execution time: 0.0452
INFO - 2022-06-14 09:52:05 --> Config Class Initialized
INFO - 2022-06-14 09:52:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:05 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:05 --> URI Class Initialized
INFO - 2022-06-14 09:52:05 --> Router Class Initialized
INFO - 2022-06-14 09:52:05 --> Output Class Initialized
INFO - 2022-06-14 09:52:05 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:05 --> Input Class Initialized
INFO - 2022-06-14 09:52:05 --> Language Class Initialized
INFO - 2022-06-14 09:52:05 --> Language Class Initialized
INFO - 2022-06-14 09:52:05 --> Config Class Initialized
INFO - 2022-06-14 09:52:05 --> Loader Class Initialized
INFO - 2022-06-14 09:52:05 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:05 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:05 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:05 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:05 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-14 09:52:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:05 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:05 --> Total execution time: 0.0521
INFO - 2022-06-14 09:52:07 --> Config Class Initialized
INFO - 2022-06-14 09:52:07 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:07 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:07 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:07 --> URI Class Initialized
INFO - 2022-06-14 09:52:07 --> Router Class Initialized
INFO - 2022-06-14 09:52:07 --> Output Class Initialized
INFO - 2022-06-14 09:52:07 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:07 --> Input Class Initialized
INFO - 2022-06-14 09:52:07 --> Language Class Initialized
INFO - 2022-06-14 09:52:07 --> Language Class Initialized
INFO - 2022-06-14 09:52:07 --> Config Class Initialized
INFO - 2022-06-14 09:52:07 --> Loader Class Initialized
INFO - 2022-06-14 09:52:07 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:07 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:07 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:07 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:07 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:07 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 09:52:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:07 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:07 --> Total execution time: 0.0417
INFO - 2022-06-14 09:52:10 --> Config Class Initialized
INFO - 2022-06-14 09:52:10 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:10 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:10 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:10 --> URI Class Initialized
INFO - 2022-06-14 09:52:10 --> Router Class Initialized
INFO - 2022-06-14 09:52:10 --> Output Class Initialized
INFO - 2022-06-14 09:52:10 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:10 --> Input Class Initialized
INFO - 2022-06-14 09:52:10 --> Language Class Initialized
INFO - 2022-06-14 09:52:10 --> Language Class Initialized
INFO - 2022-06-14 09:52:10 --> Config Class Initialized
INFO - 2022-06-14 09:52:10 --> Loader Class Initialized
INFO - 2022-06-14 09:52:10 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:10 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:10 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:10 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:10 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:10 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:10 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:10 --> Total execution time: 0.0417
INFO - 2022-06-14 09:52:13 --> Config Class Initialized
INFO - 2022-06-14 09:52:13 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:13 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:13 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:13 --> URI Class Initialized
INFO - 2022-06-14 09:52:13 --> Router Class Initialized
INFO - 2022-06-14 09:52:13 --> Output Class Initialized
INFO - 2022-06-14 09:52:13 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:13 --> Input Class Initialized
INFO - 2022-06-14 09:52:13 --> Language Class Initialized
INFO - 2022-06-14 09:52:13 --> Language Class Initialized
INFO - 2022-06-14 09:52:13 --> Config Class Initialized
INFO - 2022-06-14 09:52:13 --> Loader Class Initialized
INFO - 2022-06-14 09:52:13 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:13 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:13 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:13 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:13 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:13 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-14 09:52:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:13 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:13 --> Total execution time: 0.0451
INFO - 2022-06-14 09:52:15 --> Config Class Initialized
INFO - 2022-06-14 09:52:15 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:15 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:15 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:15 --> URI Class Initialized
INFO - 2022-06-14 09:52:15 --> Router Class Initialized
INFO - 2022-06-14 09:52:15 --> Output Class Initialized
INFO - 2022-06-14 09:52:15 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:15 --> Input Class Initialized
INFO - 2022-06-14 09:52:15 --> Language Class Initialized
INFO - 2022-06-14 09:52:15 --> Language Class Initialized
INFO - 2022-06-14 09:52:15 --> Config Class Initialized
INFO - 2022-06-14 09:52:15 --> Loader Class Initialized
INFO - 2022-06-14 09:52:15 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:15 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:15 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:15 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:15 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:15 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-06-14 09:52:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:15 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:15 --> Total execution time: 0.0687
INFO - 2022-06-14 09:52:21 --> Config Class Initialized
INFO - 2022-06-14 09:52:21 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:21 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:21 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:21 --> URI Class Initialized
INFO - 2022-06-14 09:52:21 --> Router Class Initialized
INFO - 2022-06-14 09:52:21 --> Output Class Initialized
INFO - 2022-06-14 09:52:21 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:21 --> Input Class Initialized
INFO - 2022-06-14 09:52:21 --> Language Class Initialized
INFO - 2022-06-14 09:52:21 --> Language Class Initialized
INFO - 2022-06-14 09:52:21 --> Config Class Initialized
INFO - 2022-06-14 09:52:21 --> Loader Class Initialized
INFO - 2022-06-14 09:52:21 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:21 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:21 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:21 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:21 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:21 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:21 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:21 --> Total execution time: 0.0502
INFO - 2022-06-14 09:52:23 --> Config Class Initialized
INFO - 2022-06-14 09:52:23 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:23 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:23 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:23 --> URI Class Initialized
INFO - 2022-06-14 09:52:23 --> Router Class Initialized
INFO - 2022-06-14 09:52:23 --> Output Class Initialized
INFO - 2022-06-14 09:52:23 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:23 --> Input Class Initialized
INFO - 2022-06-14 09:52:23 --> Language Class Initialized
INFO - 2022-06-14 09:52:23 --> Language Class Initialized
INFO - 2022-06-14 09:52:23 --> Config Class Initialized
INFO - 2022-06-14 09:52:23 --> Loader Class Initialized
INFO - 2022-06-14 09:52:23 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:23 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:23 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:23 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:23 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:23 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-06-14 09:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:23 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:23 --> Total execution time: 0.0513
INFO - 2022-06-14 09:52:42 --> Config Class Initialized
INFO - 2022-06-14 09:52:42 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:42 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:42 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:42 --> URI Class Initialized
INFO - 2022-06-14 09:52:42 --> Router Class Initialized
INFO - 2022-06-14 09:52:42 --> Output Class Initialized
INFO - 2022-06-14 09:52:42 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:42 --> Input Class Initialized
INFO - 2022-06-14 09:52:42 --> Language Class Initialized
INFO - 2022-06-14 09:52:42 --> Language Class Initialized
INFO - 2022-06-14 09:52:42 --> Config Class Initialized
INFO - 2022-06-14 09:52:42 --> Loader Class Initialized
INFO - 2022-06-14 09:52:42 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:42 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:42 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:42 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:42 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:42 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:52:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:42 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:42 --> Total execution time: 0.0508
INFO - 2022-06-14 09:52:45 --> Config Class Initialized
INFO - 2022-06-14 09:52:45 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:45 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:45 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:45 --> URI Class Initialized
DEBUG - 2022-06-14 09:52:45 --> No URI present. Default controller set.
INFO - 2022-06-14 09:52:45 --> Router Class Initialized
INFO - 2022-06-14 09:52:45 --> Output Class Initialized
INFO - 2022-06-14 09:52:45 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:45 --> Input Class Initialized
INFO - 2022-06-14 09:52:45 --> Language Class Initialized
INFO - 2022-06-14 09:52:45 --> Language Class Initialized
INFO - 2022-06-14 09:52:45 --> Config Class Initialized
INFO - 2022-06-14 09:52:45 --> Loader Class Initialized
INFO - 2022-06-14 09:52:45 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:45 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:45 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:45 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:45 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:45 --> Controller Class Initialized
INFO - 2022-06-14 09:52:45 --> Config Class Initialized
INFO - 2022-06-14 09:52:45 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:45 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:45 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:45 --> URI Class Initialized
INFO - 2022-06-14 09:52:45 --> Router Class Initialized
INFO - 2022-06-14 09:52:45 --> Output Class Initialized
INFO - 2022-06-14 09:52:45 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:45 --> Input Class Initialized
INFO - 2022-06-14 09:52:45 --> Language Class Initialized
INFO - 2022-06-14 09:52:45 --> Language Class Initialized
INFO - 2022-06-14 09:52:45 --> Config Class Initialized
INFO - 2022-06-14 09:52:45 --> Loader Class Initialized
INFO - 2022-06-14 09:52:45 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:45 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:45 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:45 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:45 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:45 --> Controller Class Initialized
DEBUG - 2022-06-14 09:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:52:45 --> Final output sent to browser
DEBUG - 2022-06-14 09:52:45 --> Total execution time: 0.0469
INFO - 2022-06-14 09:52:46 --> Config Class Initialized
INFO - 2022-06-14 09:52:46 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:46 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:46 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:46 --> URI Class Initialized
INFO - 2022-06-14 09:52:46 --> Router Class Initialized
INFO - 2022-06-14 09:52:46 --> Output Class Initialized
INFO - 2022-06-14 09:52:46 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:46 --> Input Class Initialized
INFO - 2022-06-14 09:52:46 --> Language Class Initialized
INFO - 2022-06-14 09:52:46 --> Language Class Initialized
INFO - 2022-06-14 09:52:46 --> Config Class Initialized
INFO - 2022-06-14 09:52:46 --> Loader Class Initialized
INFO - 2022-06-14 09:52:46 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:46 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:46 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:46 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:46 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:46 --> Controller Class Initialized
ERROR - 2022-06-14 09:52:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('457','20212','D'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3','Baik')
INFO - 2022-06-14 09:52:46 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-14 09:52:49 --> Config Class Initialized
INFO - 2022-06-14 09:52:49 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:52:49 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:52:49 --> Utf8 Class Initialized
INFO - 2022-06-14 09:52:49 --> URI Class Initialized
INFO - 2022-06-14 09:52:49 --> Router Class Initialized
INFO - 2022-06-14 09:52:49 --> Output Class Initialized
INFO - 2022-06-14 09:52:49 --> Security Class Initialized
DEBUG - 2022-06-14 09:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:52:49 --> Input Class Initialized
INFO - 2022-06-14 09:52:49 --> Language Class Initialized
INFO - 2022-06-14 09:52:49 --> Language Class Initialized
INFO - 2022-06-14 09:52:49 --> Config Class Initialized
INFO - 2022-06-14 09:52:49 --> Loader Class Initialized
INFO - 2022-06-14 09:52:49 --> Helper loaded: url_helper
INFO - 2022-06-14 09:52:49 --> Helper loaded: file_helper
INFO - 2022-06-14 09:52:49 --> Helper loaded: form_helper
INFO - 2022-06-14 09:52:49 --> Helper loaded: my_helper
INFO - 2022-06-14 09:52:49 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:52:49 --> Controller Class Initialized
ERROR - 2022-06-14 09:52:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('457','20212','D'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3','Baik')
INFO - 2022-06-14 09:52:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-14 09:53:45 --> Config Class Initialized
INFO - 2022-06-14 09:53:45 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:53:45 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:53:45 --> Utf8 Class Initialized
INFO - 2022-06-14 09:53:45 --> URI Class Initialized
INFO - 2022-06-14 09:53:45 --> Router Class Initialized
INFO - 2022-06-14 09:53:45 --> Output Class Initialized
INFO - 2022-06-14 09:53:45 --> Security Class Initialized
DEBUG - 2022-06-14 09:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:53:45 --> Input Class Initialized
INFO - 2022-06-14 09:53:45 --> Language Class Initialized
INFO - 2022-06-14 09:53:45 --> Language Class Initialized
INFO - 2022-06-14 09:53:45 --> Config Class Initialized
INFO - 2022-06-14 09:53:45 --> Loader Class Initialized
INFO - 2022-06-14 09:53:45 --> Helper loaded: url_helper
INFO - 2022-06-14 09:53:45 --> Helper loaded: file_helper
INFO - 2022-06-14 09:53:45 --> Helper loaded: form_helper
INFO - 2022-06-14 09:53:45 --> Helper loaded: my_helper
INFO - 2022-06-14 09:53:45 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:53:45 --> Controller Class Initialized
INFO - 2022-06-14 09:53:45 --> Final output sent to browser
DEBUG - 2022-06-14 09:53:45 --> Total execution time: 0.0462
INFO - 2022-06-14 09:53:48 --> Config Class Initialized
INFO - 2022-06-14 09:53:48 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:53:48 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:53:48 --> Utf8 Class Initialized
INFO - 2022-06-14 09:53:48 --> URI Class Initialized
INFO - 2022-06-14 09:53:48 --> Router Class Initialized
INFO - 2022-06-14 09:53:48 --> Output Class Initialized
INFO - 2022-06-14 09:53:48 --> Security Class Initialized
DEBUG - 2022-06-14 09:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:53:48 --> Input Class Initialized
INFO - 2022-06-14 09:53:48 --> Language Class Initialized
INFO - 2022-06-14 09:53:48 --> Language Class Initialized
INFO - 2022-06-14 09:53:48 --> Config Class Initialized
INFO - 2022-06-14 09:53:48 --> Loader Class Initialized
INFO - 2022-06-14 09:53:48 --> Helper loaded: url_helper
INFO - 2022-06-14 09:53:48 --> Helper loaded: file_helper
INFO - 2022-06-14 09:53:48 --> Helper loaded: form_helper
INFO - 2022-06-14 09:53:48 --> Helper loaded: my_helper
INFO - 2022-06-14 09:53:48 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:53:48 --> Controller Class Initialized
ERROR - 2022-06-14 09:53:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('457','20212','D'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3','Baik')
INFO - 2022-06-14 09:53:48 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-14 09:54:16 --> Config Class Initialized
INFO - 2022-06-14 09:54:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:54:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:54:16 --> Utf8 Class Initialized
INFO - 2022-06-14 09:54:16 --> URI Class Initialized
INFO - 2022-06-14 09:54:16 --> Router Class Initialized
INFO - 2022-06-14 09:54:16 --> Output Class Initialized
INFO - 2022-06-14 09:54:16 --> Security Class Initialized
DEBUG - 2022-06-14 09:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:54:16 --> Input Class Initialized
INFO - 2022-06-14 09:54:16 --> Language Class Initialized
INFO - 2022-06-14 09:54:16 --> Language Class Initialized
INFO - 2022-06-14 09:54:16 --> Config Class Initialized
INFO - 2022-06-14 09:54:16 --> Loader Class Initialized
INFO - 2022-06-14 09:54:16 --> Helper loaded: url_helper
INFO - 2022-06-14 09:54:16 --> Helper loaded: file_helper
INFO - 2022-06-14 09:54:16 --> Helper loaded: form_helper
INFO - 2022-06-14 09:54:16 --> Helper loaded: my_helper
INFO - 2022-06-14 09:54:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:54:16 --> Controller Class Initialized
ERROR - 2022-06-14 09:54:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('457','20212','D'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3','Baik')
INFO - 2022-06-14 09:54:16 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-14 09:54:38 --> Config Class Initialized
INFO - 2022-06-14 09:54:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:54:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:54:38 --> Utf8 Class Initialized
INFO - 2022-06-14 09:54:38 --> URI Class Initialized
INFO - 2022-06-14 09:54:38 --> Router Class Initialized
INFO - 2022-06-14 09:54:38 --> Output Class Initialized
INFO - 2022-06-14 09:54:38 --> Security Class Initialized
DEBUG - 2022-06-14 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:54:38 --> Input Class Initialized
INFO - 2022-06-14 09:54:38 --> Language Class Initialized
INFO - 2022-06-14 09:54:38 --> Language Class Initialized
INFO - 2022-06-14 09:54:38 --> Config Class Initialized
INFO - 2022-06-14 09:54:38 --> Loader Class Initialized
INFO - 2022-06-14 09:54:38 --> Helper loaded: url_helper
INFO - 2022-06-14 09:54:38 --> Helper loaded: file_helper
INFO - 2022-06-14 09:54:38 --> Helper loaded: form_helper
INFO - 2022-06-14 09:54:38 --> Helper loaded: my_helper
INFO - 2022-06-14 09:54:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:54:38 --> Controller Class Initialized
ERROR - 2022-06-14 09:54:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('457','20212','D'ND JAYA MOTOR','Jl. Raya Cibungbulang, Cemplang, Kabupaten Bogor, Jawa Barat','3','Baik')
INFO - 2022-06-14 09:54:38 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-14 09:54:44 --> Config Class Initialized
INFO - 2022-06-14 09:54:44 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:54:44 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:54:44 --> Utf8 Class Initialized
INFO - 2022-06-14 09:54:44 --> URI Class Initialized
INFO - 2022-06-14 09:54:44 --> Router Class Initialized
INFO - 2022-06-14 09:54:44 --> Output Class Initialized
INFO - 2022-06-14 09:54:44 --> Security Class Initialized
DEBUG - 2022-06-14 09:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:54:44 --> Input Class Initialized
INFO - 2022-06-14 09:54:44 --> Language Class Initialized
INFO - 2022-06-14 09:54:44 --> Language Class Initialized
INFO - 2022-06-14 09:54:44 --> Config Class Initialized
INFO - 2022-06-14 09:54:44 --> Loader Class Initialized
INFO - 2022-06-14 09:54:44 --> Helper loaded: url_helper
INFO - 2022-06-14 09:54:44 --> Helper loaded: file_helper
INFO - 2022-06-14 09:54:44 --> Helper loaded: form_helper
INFO - 2022-06-14 09:54:44 --> Helper loaded: my_helper
INFO - 2022-06-14 09:54:44 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:54:44 --> Controller Class Initialized
DEBUG - 2022-06-14 09:54:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-14 09:54:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:54:44 --> Final output sent to browser
DEBUG - 2022-06-14 09:54:44 --> Total execution time: 0.0551
INFO - 2022-06-14 09:54:47 --> Config Class Initialized
INFO - 2022-06-14 09:54:47 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:54:47 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:54:47 --> Utf8 Class Initialized
INFO - 2022-06-14 09:54:47 --> URI Class Initialized
INFO - 2022-06-14 09:54:47 --> Router Class Initialized
INFO - 2022-06-14 09:54:47 --> Output Class Initialized
INFO - 2022-06-14 09:54:47 --> Security Class Initialized
DEBUG - 2022-06-14 09:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:54:47 --> Input Class Initialized
INFO - 2022-06-14 09:54:47 --> Language Class Initialized
INFO - 2022-06-14 09:54:47 --> Language Class Initialized
INFO - 2022-06-14 09:54:47 --> Config Class Initialized
INFO - 2022-06-14 09:54:47 --> Loader Class Initialized
INFO - 2022-06-14 09:54:47 --> Helper loaded: url_helper
INFO - 2022-06-14 09:54:47 --> Helper loaded: file_helper
INFO - 2022-06-14 09:54:47 --> Helper loaded: form_helper
INFO - 2022-06-14 09:54:47 --> Helper loaded: my_helper
INFO - 2022-06-14 09:54:47 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:54:47 --> Controller Class Initialized
INFO - 2022-06-14 09:54:47 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:54:47 --> Final output sent to browser
DEBUG - 2022-06-14 09:54:47 --> Total execution time: 0.0483
INFO - 2022-06-14 09:54:51 --> Config Class Initialized
INFO - 2022-06-14 09:54:51 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:54:51 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:54:51 --> Utf8 Class Initialized
INFO - 2022-06-14 09:54:51 --> URI Class Initialized
INFO - 2022-06-14 09:54:51 --> Router Class Initialized
INFO - 2022-06-14 09:54:51 --> Output Class Initialized
INFO - 2022-06-14 09:54:51 --> Security Class Initialized
DEBUG - 2022-06-14 09:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:54:51 --> Input Class Initialized
INFO - 2022-06-14 09:54:51 --> Language Class Initialized
INFO - 2022-06-14 09:54:51 --> Language Class Initialized
INFO - 2022-06-14 09:54:51 --> Config Class Initialized
INFO - 2022-06-14 09:54:51 --> Loader Class Initialized
INFO - 2022-06-14 09:54:51 --> Helper loaded: url_helper
INFO - 2022-06-14 09:54:51 --> Helper loaded: file_helper
INFO - 2022-06-14 09:54:51 --> Helper loaded: form_helper
INFO - 2022-06-14 09:54:51 --> Helper loaded: my_helper
INFO - 2022-06-14 09:54:51 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:54:51 --> Controller Class Initialized
DEBUG - 2022-06-14 09:54:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:54:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:54:51 --> Final output sent to browser
DEBUG - 2022-06-14 09:54:51 --> Total execution time: 0.0494
INFO - 2022-06-14 09:55:01 --> Config Class Initialized
INFO - 2022-06-14 09:55:01 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:55:01 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:55:01 --> Utf8 Class Initialized
INFO - 2022-06-14 09:55:01 --> URI Class Initialized
INFO - 2022-06-14 09:55:01 --> Router Class Initialized
INFO - 2022-06-14 09:55:01 --> Output Class Initialized
INFO - 2022-06-14 09:55:01 --> Security Class Initialized
DEBUG - 2022-06-14 09:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:55:01 --> Input Class Initialized
INFO - 2022-06-14 09:55:01 --> Language Class Initialized
INFO - 2022-06-14 09:55:01 --> Language Class Initialized
INFO - 2022-06-14 09:55:01 --> Config Class Initialized
INFO - 2022-06-14 09:55:01 --> Loader Class Initialized
INFO - 2022-06-14 09:55:01 --> Helper loaded: url_helper
INFO - 2022-06-14 09:55:01 --> Helper loaded: file_helper
INFO - 2022-06-14 09:55:01 --> Helper loaded: form_helper
INFO - 2022-06-14 09:55:01 --> Helper loaded: my_helper
INFO - 2022-06-14 09:55:01 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:55:01 --> Controller Class Initialized
DEBUG - 2022-06-14 09:55:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2022-06-14 09:55:01 --> Final output sent to browser
DEBUG - 2022-06-14 09:55:01 --> Total execution time: 0.1085
INFO - 2022-06-14 09:55:10 --> Config Class Initialized
INFO - 2022-06-14 09:55:10 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:55:10 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:55:10 --> Utf8 Class Initialized
INFO - 2022-06-14 09:55:10 --> URI Class Initialized
DEBUG - 2022-06-14 09:55:10 --> No URI present. Default controller set.
INFO - 2022-06-14 09:55:10 --> Router Class Initialized
INFO - 2022-06-14 09:55:10 --> Output Class Initialized
INFO - 2022-06-14 09:55:10 --> Security Class Initialized
DEBUG - 2022-06-14 09:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:55:10 --> Input Class Initialized
INFO - 2022-06-14 09:55:10 --> Language Class Initialized
INFO - 2022-06-14 09:55:10 --> Language Class Initialized
INFO - 2022-06-14 09:55:10 --> Config Class Initialized
INFO - 2022-06-14 09:55:10 --> Loader Class Initialized
INFO - 2022-06-14 09:55:10 --> Helper loaded: url_helper
INFO - 2022-06-14 09:55:10 --> Helper loaded: file_helper
INFO - 2022-06-14 09:55:10 --> Helper loaded: form_helper
INFO - 2022-06-14 09:55:10 --> Helper loaded: my_helper
INFO - 2022-06-14 09:55:10 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:55:10 --> Controller Class Initialized
DEBUG - 2022-06-14 09:55:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:55:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:55:10 --> Final output sent to browser
DEBUG - 2022-06-14 09:55:10 --> Total execution time: 0.0533
INFO - 2022-06-14 09:55:14 --> Config Class Initialized
INFO - 2022-06-14 09:55:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:55:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:55:14 --> Utf8 Class Initialized
INFO - 2022-06-14 09:55:14 --> URI Class Initialized
DEBUG - 2022-06-14 09:55:14 --> No URI present. Default controller set.
INFO - 2022-06-14 09:55:14 --> Router Class Initialized
INFO - 2022-06-14 09:55:14 --> Output Class Initialized
INFO - 2022-06-14 09:55:14 --> Security Class Initialized
DEBUG - 2022-06-14 09:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:55:14 --> Input Class Initialized
INFO - 2022-06-14 09:55:14 --> Language Class Initialized
INFO - 2022-06-14 09:55:14 --> Language Class Initialized
INFO - 2022-06-14 09:55:14 --> Config Class Initialized
INFO - 2022-06-14 09:55:14 --> Loader Class Initialized
INFO - 2022-06-14 09:55:14 --> Helper loaded: url_helper
INFO - 2022-06-14 09:55:14 --> Helper loaded: file_helper
INFO - 2022-06-14 09:55:14 --> Helper loaded: form_helper
INFO - 2022-06-14 09:55:14 --> Helper loaded: my_helper
INFO - 2022-06-14 09:55:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:55:14 --> Controller Class Initialized
DEBUG - 2022-06-14 09:55:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:55:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:55:14 --> Final output sent to browser
DEBUG - 2022-06-14 09:55:14 --> Total execution time: 0.0517
INFO - 2022-06-14 09:55:17 --> Config Class Initialized
INFO - 2022-06-14 09:55:17 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:55:17 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:55:17 --> Utf8 Class Initialized
INFO - 2022-06-14 09:55:17 --> URI Class Initialized
INFO - 2022-06-14 09:55:17 --> Router Class Initialized
INFO - 2022-06-14 09:55:17 --> Output Class Initialized
INFO - 2022-06-14 09:55:17 --> Security Class Initialized
DEBUG - 2022-06-14 09:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:55:17 --> Input Class Initialized
INFO - 2022-06-14 09:55:17 --> Language Class Initialized
INFO - 2022-06-14 09:55:17 --> Language Class Initialized
INFO - 2022-06-14 09:55:17 --> Config Class Initialized
INFO - 2022-06-14 09:55:17 --> Loader Class Initialized
INFO - 2022-06-14 09:55:17 --> Helper loaded: url_helper
INFO - 2022-06-14 09:55:17 --> Helper loaded: file_helper
INFO - 2022-06-14 09:55:17 --> Helper loaded: form_helper
INFO - 2022-06-14 09:55:17 --> Helper loaded: my_helper
INFO - 2022-06-14 09:55:17 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:55:17 --> Controller Class Initialized
DEBUG - 2022-06-14 09:55:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 09:55:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:55:17 --> Final output sent to browser
DEBUG - 2022-06-14 09:55:17 --> Total execution time: 0.0478
INFO - 2022-06-14 09:55:43 --> Config Class Initialized
INFO - 2022-06-14 09:55:43 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:55:43 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:55:43 --> Utf8 Class Initialized
INFO - 2022-06-14 09:55:43 --> URI Class Initialized
INFO - 2022-06-14 09:55:43 --> Router Class Initialized
INFO - 2022-06-14 09:55:43 --> Output Class Initialized
INFO - 2022-06-14 09:55:43 --> Security Class Initialized
DEBUG - 2022-06-14 09:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:55:43 --> Input Class Initialized
INFO - 2022-06-14 09:55:43 --> Language Class Initialized
INFO - 2022-06-14 09:55:43 --> Language Class Initialized
INFO - 2022-06-14 09:55:43 --> Config Class Initialized
INFO - 2022-06-14 09:55:43 --> Loader Class Initialized
INFO - 2022-06-14 09:55:43 --> Helper loaded: url_helper
INFO - 2022-06-14 09:55:43 --> Helper loaded: file_helper
INFO - 2022-06-14 09:55:43 --> Helper loaded: form_helper
INFO - 2022-06-14 09:55:43 --> Helper loaded: my_helper
INFO - 2022-06-14 09:55:43 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:55:43 --> Controller Class Initialized
DEBUG - 2022-06-14 09:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:55:43 --> Final output sent to browser
DEBUG - 2022-06-14 09:55:43 --> Total execution time: 0.0449
INFO - 2022-06-14 09:55:43 --> Config Class Initialized
INFO - 2022-06-14 09:55:43 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:55:43 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:55:43 --> Utf8 Class Initialized
INFO - 2022-06-14 09:55:43 --> URI Class Initialized
INFO - 2022-06-14 09:55:43 --> Router Class Initialized
INFO - 2022-06-14 09:55:43 --> Output Class Initialized
INFO - 2022-06-14 09:55:43 --> Security Class Initialized
DEBUG - 2022-06-14 09:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:55:43 --> Input Class Initialized
INFO - 2022-06-14 09:55:43 --> Language Class Initialized
INFO - 2022-06-14 09:55:43 --> Language Class Initialized
INFO - 2022-06-14 09:55:43 --> Config Class Initialized
INFO - 2022-06-14 09:55:43 --> Loader Class Initialized
INFO - 2022-06-14 09:55:43 --> Helper loaded: url_helper
INFO - 2022-06-14 09:55:43 --> Helper loaded: file_helper
INFO - 2022-06-14 09:55:43 --> Helper loaded: form_helper
INFO - 2022-06-14 09:55:43 --> Helper loaded: my_helper
INFO - 2022-06-14 09:55:43 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:55:43 --> Controller Class Initialized
INFO - 2022-06-14 09:56:03 --> Config Class Initialized
INFO - 2022-06-14 09:56:03 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:03 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:03 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:03 --> URI Class Initialized
INFO - 2022-06-14 09:56:03 --> Router Class Initialized
INFO - 2022-06-14 09:56:03 --> Output Class Initialized
INFO - 2022-06-14 09:56:03 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:03 --> Input Class Initialized
INFO - 2022-06-14 09:56:03 --> Language Class Initialized
INFO - 2022-06-14 09:56:03 --> Language Class Initialized
INFO - 2022-06-14 09:56:03 --> Config Class Initialized
INFO - 2022-06-14 09:56:03 --> Loader Class Initialized
INFO - 2022-06-14 09:56:03 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:03 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:03 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:03 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:03 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:03 --> Controller Class Initialized
DEBUG - 2022-06-14 09:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 09:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:56:03 --> Final output sent to browser
DEBUG - 2022-06-14 09:56:03 --> Total execution time: 0.0396
INFO - 2022-06-14 09:56:10 --> Config Class Initialized
INFO - 2022-06-14 09:56:10 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:10 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:10 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:10 --> URI Class Initialized
INFO - 2022-06-14 09:56:10 --> Router Class Initialized
INFO - 2022-06-14 09:56:10 --> Output Class Initialized
INFO - 2022-06-14 09:56:10 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:10 --> Input Class Initialized
INFO - 2022-06-14 09:56:10 --> Language Class Initialized
INFO - 2022-06-14 09:56:10 --> Language Class Initialized
INFO - 2022-06-14 09:56:10 --> Config Class Initialized
INFO - 2022-06-14 09:56:10 --> Loader Class Initialized
INFO - 2022-06-14 09:56:10 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:10 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:10 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:10 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:10 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:10 --> Controller Class Initialized
DEBUG - 2022-06-14 09:56:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:56:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:56:10 --> Final output sent to browser
DEBUG - 2022-06-14 09:56:10 --> Total execution time: 0.0503
INFO - 2022-06-14 09:56:10 --> Config Class Initialized
INFO - 2022-06-14 09:56:10 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:10 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:10 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:10 --> URI Class Initialized
INFO - 2022-06-14 09:56:10 --> Router Class Initialized
INFO - 2022-06-14 09:56:10 --> Output Class Initialized
INFO - 2022-06-14 09:56:10 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:10 --> Input Class Initialized
INFO - 2022-06-14 09:56:10 --> Language Class Initialized
INFO - 2022-06-14 09:56:10 --> Language Class Initialized
INFO - 2022-06-14 09:56:10 --> Config Class Initialized
INFO - 2022-06-14 09:56:10 --> Loader Class Initialized
INFO - 2022-06-14 09:56:10 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:10 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:10 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:10 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:10 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:10 --> Controller Class Initialized
INFO - 2022-06-14 09:56:12 --> Config Class Initialized
INFO - 2022-06-14 09:56:12 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:12 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:12 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:12 --> URI Class Initialized
INFO - 2022-06-14 09:56:12 --> Router Class Initialized
INFO - 2022-06-14 09:56:12 --> Output Class Initialized
INFO - 2022-06-14 09:56:12 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:12 --> Input Class Initialized
INFO - 2022-06-14 09:56:12 --> Language Class Initialized
INFO - 2022-06-14 09:56:12 --> Language Class Initialized
INFO - 2022-06-14 09:56:12 --> Config Class Initialized
INFO - 2022-06-14 09:56:12 --> Loader Class Initialized
INFO - 2022-06-14 09:56:12 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:12 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:12 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:12 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:12 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:12 --> Controller Class Initialized
DEBUG - 2022-06-14 09:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-06-14 09:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:56:12 --> Final output sent to browser
DEBUG - 2022-06-14 09:56:12 --> Total execution time: 0.0438
INFO - 2022-06-14 09:56:16 --> Config Class Initialized
INFO - 2022-06-14 09:56:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:16 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:16 --> URI Class Initialized
INFO - 2022-06-14 09:56:16 --> Router Class Initialized
INFO - 2022-06-14 09:56:16 --> Output Class Initialized
INFO - 2022-06-14 09:56:16 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:16 --> Input Class Initialized
INFO - 2022-06-14 09:56:16 --> Language Class Initialized
INFO - 2022-06-14 09:56:16 --> Language Class Initialized
INFO - 2022-06-14 09:56:16 --> Config Class Initialized
INFO - 2022-06-14 09:56:16 --> Loader Class Initialized
INFO - 2022-06-14 09:56:16 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:16 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:16 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:16 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:16 --> Controller Class Initialized
DEBUG - 2022-06-14 09:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:56:16 --> Final output sent to browser
DEBUG - 2022-06-14 09:56:16 --> Total execution time: 0.0411
INFO - 2022-06-14 09:56:16 --> Config Class Initialized
INFO - 2022-06-14 09:56:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:16 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:16 --> URI Class Initialized
INFO - 2022-06-14 09:56:16 --> Router Class Initialized
INFO - 2022-06-14 09:56:16 --> Output Class Initialized
INFO - 2022-06-14 09:56:16 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:16 --> Input Class Initialized
INFO - 2022-06-14 09:56:16 --> Language Class Initialized
INFO - 2022-06-14 09:56:16 --> Language Class Initialized
INFO - 2022-06-14 09:56:16 --> Config Class Initialized
INFO - 2022-06-14 09:56:16 --> Loader Class Initialized
INFO - 2022-06-14 09:56:16 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:16 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:16 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:16 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:16 --> Controller Class Initialized
INFO - 2022-06-14 09:56:18 --> Config Class Initialized
INFO - 2022-06-14 09:56:18 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:18 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:18 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:18 --> URI Class Initialized
INFO - 2022-06-14 09:56:18 --> Router Class Initialized
INFO - 2022-06-14 09:56:18 --> Output Class Initialized
INFO - 2022-06-14 09:56:18 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:18 --> Input Class Initialized
INFO - 2022-06-14 09:56:18 --> Language Class Initialized
INFO - 2022-06-14 09:56:18 --> Language Class Initialized
INFO - 2022-06-14 09:56:18 --> Config Class Initialized
INFO - 2022-06-14 09:56:18 --> Loader Class Initialized
INFO - 2022-06-14 09:56:18 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:18 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:18 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:18 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:18 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:18 --> Controller Class Initialized
DEBUG - 2022-06-14 09:56:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:56:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:56:18 --> Final output sent to browser
DEBUG - 2022-06-14 09:56:18 --> Total execution time: 0.0531
INFO - 2022-06-14 09:56:22 --> Config Class Initialized
INFO - 2022-06-14 09:56:22 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:22 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:22 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:22 --> URI Class Initialized
INFO - 2022-06-14 09:56:22 --> Router Class Initialized
INFO - 2022-06-14 09:56:22 --> Output Class Initialized
INFO - 2022-06-14 09:56:22 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:22 --> Input Class Initialized
INFO - 2022-06-14 09:56:22 --> Language Class Initialized
INFO - 2022-06-14 09:56:22 --> Language Class Initialized
INFO - 2022-06-14 09:56:22 --> Config Class Initialized
INFO - 2022-06-14 09:56:22 --> Loader Class Initialized
INFO - 2022-06-14 09:56:22 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:22 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:22 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:22 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:22 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:22 --> Controller Class Initialized
INFO - 2022-06-14 09:56:22 --> Final output sent to browser
DEBUG - 2022-06-14 09:56:22 --> Total execution time: 0.0480
INFO - 2022-06-14 09:56:46 --> Config Class Initialized
INFO - 2022-06-14 09:56:46 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:56:46 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:56:46 --> Utf8 Class Initialized
INFO - 2022-06-14 09:56:46 --> URI Class Initialized
INFO - 2022-06-14 09:56:46 --> Router Class Initialized
INFO - 2022-06-14 09:56:46 --> Output Class Initialized
INFO - 2022-06-14 09:56:46 --> Security Class Initialized
DEBUG - 2022-06-14 09:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:56:46 --> Input Class Initialized
INFO - 2022-06-14 09:56:46 --> Language Class Initialized
INFO - 2022-06-14 09:56:46 --> Language Class Initialized
INFO - 2022-06-14 09:56:46 --> Config Class Initialized
INFO - 2022-06-14 09:56:46 --> Loader Class Initialized
INFO - 2022-06-14 09:56:46 --> Helper loaded: url_helper
INFO - 2022-06-14 09:56:46 --> Helper loaded: file_helper
INFO - 2022-06-14 09:56:46 --> Helper loaded: form_helper
INFO - 2022-06-14 09:56:46 --> Helper loaded: my_helper
INFO - 2022-06-14 09:56:46 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:56:46 --> Controller Class Initialized
DEBUG - 2022-06-14 09:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:56:46 --> Final output sent to browser
DEBUG - 2022-06-14 09:56:46 --> Total execution time: 0.0521
INFO - 2022-06-14 09:57:06 --> Config Class Initialized
INFO - 2022-06-14 09:57:06 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:06 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:06 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:06 --> URI Class Initialized
INFO - 2022-06-14 09:57:06 --> Router Class Initialized
INFO - 2022-06-14 09:57:06 --> Output Class Initialized
INFO - 2022-06-14 09:57:06 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:06 --> Input Class Initialized
INFO - 2022-06-14 09:57:06 --> Language Class Initialized
INFO - 2022-06-14 09:57:06 --> Language Class Initialized
INFO - 2022-06-14 09:57:06 --> Config Class Initialized
INFO - 2022-06-14 09:57:06 --> Loader Class Initialized
INFO - 2022-06-14 09:57:06 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:06 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:06 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:06 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:06 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:06 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:06 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:06 --> Total execution time: 0.0445
INFO - 2022-06-14 09:57:06 --> Config Class Initialized
INFO - 2022-06-14 09:57:06 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:06 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:06 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:06 --> URI Class Initialized
INFO - 2022-06-14 09:57:06 --> Router Class Initialized
INFO - 2022-06-14 09:57:06 --> Output Class Initialized
INFO - 2022-06-14 09:57:06 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:06 --> Input Class Initialized
INFO - 2022-06-14 09:57:06 --> Language Class Initialized
INFO - 2022-06-14 09:57:06 --> Language Class Initialized
INFO - 2022-06-14 09:57:06 --> Config Class Initialized
INFO - 2022-06-14 09:57:06 --> Loader Class Initialized
INFO - 2022-06-14 09:57:06 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:06 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:06 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:06 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:06 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:06 --> Controller Class Initialized
INFO - 2022-06-14 09:57:08 --> Config Class Initialized
INFO - 2022-06-14 09:57:08 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:08 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:08 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:08 --> URI Class Initialized
INFO - 2022-06-14 09:57:08 --> Router Class Initialized
INFO - 2022-06-14 09:57:08 --> Output Class Initialized
INFO - 2022-06-14 09:57:08 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:08 --> Input Class Initialized
INFO - 2022-06-14 09:57:08 --> Language Class Initialized
INFO - 2022-06-14 09:57:08 --> Language Class Initialized
INFO - 2022-06-14 09:57:08 --> Config Class Initialized
INFO - 2022-06-14 09:57:08 --> Loader Class Initialized
INFO - 2022-06-14 09:57:08 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:08 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:08 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:08 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:08 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:08 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:57:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:08 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:08 --> Total execution time: 0.0460
INFO - 2022-06-14 09:57:09 --> Config Class Initialized
INFO - 2022-06-14 09:57:09 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:09 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:09 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:09 --> URI Class Initialized
INFO - 2022-06-14 09:57:09 --> Router Class Initialized
INFO - 2022-06-14 09:57:09 --> Output Class Initialized
INFO - 2022-06-14 09:57:09 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:09 --> Input Class Initialized
INFO - 2022-06-14 09:57:09 --> Language Class Initialized
INFO - 2022-06-14 09:57:09 --> Language Class Initialized
INFO - 2022-06-14 09:57:09 --> Config Class Initialized
INFO - 2022-06-14 09:57:09 --> Loader Class Initialized
INFO - 2022-06-14 09:57:09 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:09 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:09 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:09 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:09 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:09 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 09:57:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:09 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:09 --> Total execution time: 0.0490
INFO - 2022-06-14 09:57:11 --> Config Class Initialized
INFO - 2022-06-14 09:57:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:11 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:11 --> URI Class Initialized
INFO - 2022-06-14 09:57:11 --> Router Class Initialized
INFO - 2022-06-14 09:57:11 --> Output Class Initialized
INFO - 2022-06-14 09:57:11 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:11 --> Input Class Initialized
INFO - 2022-06-14 09:57:11 --> Language Class Initialized
INFO - 2022-06-14 09:57:11 --> Language Class Initialized
INFO - 2022-06-14 09:57:11 --> Config Class Initialized
INFO - 2022-06-14 09:57:11 --> Loader Class Initialized
INFO - 2022-06-14 09:57:11 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:11 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:11 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:11 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:11 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:11 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:11 --> Total execution time: 0.0486
INFO - 2022-06-14 09:57:11 --> Config Class Initialized
INFO - 2022-06-14 09:57:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:11 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:11 --> URI Class Initialized
INFO - 2022-06-14 09:57:11 --> Router Class Initialized
INFO - 2022-06-14 09:57:11 --> Output Class Initialized
INFO - 2022-06-14 09:57:11 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:11 --> Input Class Initialized
INFO - 2022-06-14 09:57:11 --> Language Class Initialized
INFO - 2022-06-14 09:57:11 --> Language Class Initialized
INFO - 2022-06-14 09:57:11 --> Config Class Initialized
INFO - 2022-06-14 09:57:11 --> Loader Class Initialized
INFO - 2022-06-14 09:57:11 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:11 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:11 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:11 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:11 --> Controller Class Initialized
INFO - 2022-06-14 09:57:13 --> Config Class Initialized
INFO - 2022-06-14 09:57:13 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:13 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:13 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:13 --> URI Class Initialized
INFO - 2022-06-14 09:57:13 --> Router Class Initialized
INFO - 2022-06-14 09:57:13 --> Output Class Initialized
INFO - 2022-06-14 09:57:13 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:13 --> Input Class Initialized
INFO - 2022-06-14 09:57:13 --> Language Class Initialized
INFO - 2022-06-14 09:57:13 --> Language Class Initialized
INFO - 2022-06-14 09:57:13 --> Config Class Initialized
INFO - 2022-06-14 09:57:13 --> Loader Class Initialized
INFO - 2022-06-14 09:57:13 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:13 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:13 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:13 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:13 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:13 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:57:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:13 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:13 --> Total execution time: 0.0481
INFO - 2022-06-14 09:57:14 --> Config Class Initialized
INFO - 2022-06-14 09:57:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:14 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:14 --> URI Class Initialized
INFO - 2022-06-14 09:57:14 --> Router Class Initialized
INFO - 2022-06-14 09:57:14 --> Output Class Initialized
INFO - 2022-06-14 09:57:14 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:14 --> Input Class Initialized
INFO - 2022-06-14 09:57:14 --> Language Class Initialized
INFO - 2022-06-14 09:57:14 --> Language Class Initialized
INFO - 2022-06-14 09:57:14 --> Config Class Initialized
INFO - 2022-06-14 09:57:14 --> Loader Class Initialized
INFO - 2022-06-14 09:57:14 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:14 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:14 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:14 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:14 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:57:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:14 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:14 --> Total execution time: 0.0477
INFO - 2022-06-14 09:57:14 --> Config Class Initialized
INFO - 2022-06-14 09:57:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:14 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:14 --> URI Class Initialized
INFO - 2022-06-14 09:57:14 --> Router Class Initialized
INFO - 2022-06-14 09:57:14 --> Output Class Initialized
INFO - 2022-06-14 09:57:14 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:14 --> Input Class Initialized
INFO - 2022-06-14 09:57:14 --> Language Class Initialized
INFO - 2022-06-14 09:57:15 --> Language Class Initialized
INFO - 2022-06-14 09:57:15 --> Config Class Initialized
INFO - 2022-06-14 09:57:15 --> Loader Class Initialized
INFO - 2022-06-14 09:57:15 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:15 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:15 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:15 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:15 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:15 --> Controller Class Initialized
INFO - 2022-06-14 09:57:16 --> Config Class Initialized
INFO - 2022-06-14 09:57:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:16 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:16 --> URI Class Initialized
INFO - 2022-06-14 09:57:16 --> Router Class Initialized
INFO - 2022-06-14 09:57:16 --> Output Class Initialized
INFO - 2022-06-14 09:57:16 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:16 --> Input Class Initialized
INFO - 2022-06-14 09:57:16 --> Language Class Initialized
INFO - 2022-06-14 09:57:16 --> Language Class Initialized
INFO - 2022-06-14 09:57:16 --> Config Class Initialized
INFO - 2022-06-14 09:57:16 --> Loader Class Initialized
INFO - 2022-06-14 09:57:16 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:16 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:16 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:16 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:16 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:57:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:16 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:16 --> Total execution time: 0.0460
INFO - 2022-06-14 09:57:18 --> Config Class Initialized
INFO - 2022-06-14 09:57:18 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:18 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:18 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:18 --> URI Class Initialized
INFO - 2022-06-14 09:57:18 --> Router Class Initialized
INFO - 2022-06-14 09:57:18 --> Output Class Initialized
INFO - 2022-06-14 09:57:18 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:18 --> Input Class Initialized
INFO - 2022-06-14 09:57:18 --> Language Class Initialized
INFO - 2022-06-14 09:57:18 --> Language Class Initialized
INFO - 2022-06-14 09:57:18 --> Config Class Initialized
INFO - 2022-06-14 09:57:18 --> Loader Class Initialized
INFO - 2022-06-14 09:57:18 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:18 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:18 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:18 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:18 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:18 --> Controller Class Initialized
INFO - 2022-06-14 09:57:18 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:57:18 --> Config Class Initialized
INFO - 2022-06-14 09:57:18 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:18 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:18 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:18 --> URI Class Initialized
INFO - 2022-06-14 09:57:18 --> Router Class Initialized
INFO - 2022-06-14 09:57:18 --> Output Class Initialized
INFO - 2022-06-14 09:57:18 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:18 --> Input Class Initialized
INFO - 2022-06-14 09:57:18 --> Language Class Initialized
INFO - 2022-06-14 09:57:18 --> Language Class Initialized
INFO - 2022-06-14 09:57:18 --> Config Class Initialized
INFO - 2022-06-14 09:57:18 --> Loader Class Initialized
INFO - 2022-06-14 09:57:18 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:18 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:18 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:18 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:18 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:18 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 09:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:18 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:18 --> Total execution time: 0.0387
INFO - 2022-06-14 09:57:20 --> Config Class Initialized
INFO - 2022-06-14 09:57:20 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:20 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:20 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:20 --> URI Class Initialized
INFO - 2022-06-14 09:57:20 --> Router Class Initialized
INFO - 2022-06-14 09:57:20 --> Output Class Initialized
INFO - 2022-06-14 09:57:20 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:20 --> Input Class Initialized
INFO - 2022-06-14 09:57:20 --> Language Class Initialized
INFO - 2022-06-14 09:57:20 --> Language Class Initialized
INFO - 2022-06-14 09:57:20 --> Config Class Initialized
INFO - 2022-06-14 09:57:20 --> Loader Class Initialized
INFO - 2022-06-14 09:57:20 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:20 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:20 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:20 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:20 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:20 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:57:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:20 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:20 --> Total execution time: 0.0462
INFO - 2022-06-14 09:57:20 --> Config Class Initialized
INFO - 2022-06-14 09:57:20 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:20 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:20 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:20 --> URI Class Initialized
INFO - 2022-06-14 09:57:20 --> Router Class Initialized
INFO - 2022-06-14 09:57:20 --> Output Class Initialized
INFO - 2022-06-14 09:57:20 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:20 --> Input Class Initialized
INFO - 2022-06-14 09:57:20 --> Language Class Initialized
INFO - 2022-06-14 09:57:20 --> Language Class Initialized
INFO - 2022-06-14 09:57:20 --> Config Class Initialized
INFO - 2022-06-14 09:57:20 --> Loader Class Initialized
INFO - 2022-06-14 09:57:20 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:20 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:20 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:20 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:20 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:20 --> Controller Class Initialized
INFO - 2022-06-14 09:57:21 --> Config Class Initialized
INFO - 2022-06-14 09:57:21 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:21 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:21 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:21 --> URI Class Initialized
INFO - 2022-06-14 09:57:21 --> Router Class Initialized
INFO - 2022-06-14 09:57:21 --> Output Class Initialized
INFO - 2022-06-14 09:57:21 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:21 --> Input Class Initialized
INFO - 2022-06-14 09:57:21 --> Language Class Initialized
INFO - 2022-06-14 09:57:21 --> Language Class Initialized
INFO - 2022-06-14 09:57:21 --> Config Class Initialized
INFO - 2022-06-14 09:57:21 --> Loader Class Initialized
INFO - 2022-06-14 09:57:21 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:21 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:21 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:21 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:21 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:21 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:57:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:21 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:21 --> Total execution time: 0.0458
INFO - 2022-06-14 09:57:24 --> Config Class Initialized
INFO - 2022-06-14 09:57:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:24 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:24 --> URI Class Initialized
INFO - 2022-06-14 09:57:24 --> Router Class Initialized
INFO - 2022-06-14 09:57:24 --> Output Class Initialized
INFO - 2022-06-14 09:57:24 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:24 --> Input Class Initialized
INFO - 2022-06-14 09:57:24 --> Language Class Initialized
INFO - 2022-06-14 09:57:24 --> Language Class Initialized
INFO - 2022-06-14 09:57:24 --> Config Class Initialized
INFO - 2022-06-14 09:57:24 --> Loader Class Initialized
INFO - 2022-06-14 09:57:24 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:24 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:24 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:24 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:24 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:57:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:24 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:24 --> Total execution time: 0.0465
INFO - 2022-06-14 09:57:24 --> Config Class Initialized
INFO - 2022-06-14 09:57:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:24 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:24 --> URI Class Initialized
INFO - 2022-06-14 09:57:24 --> Router Class Initialized
INFO - 2022-06-14 09:57:24 --> Output Class Initialized
INFO - 2022-06-14 09:57:24 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:24 --> Input Class Initialized
INFO - 2022-06-14 09:57:24 --> Language Class Initialized
INFO - 2022-06-14 09:57:24 --> Language Class Initialized
INFO - 2022-06-14 09:57:24 --> Config Class Initialized
INFO - 2022-06-14 09:57:24 --> Loader Class Initialized
INFO - 2022-06-14 09:57:24 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:24 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:24 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:24 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:24 --> Controller Class Initialized
INFO - 2022-06-14 09:57:26 --> Config Class Initialized
INFO - 2022-06-14 09:57:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:26 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:26 --> URI Class Initialized
INFO - 2022-06-14 09:57:26 --> Router Class Initialized
INFO - 2022-06-14 09:57:26 --> Output Class Initialized
INFO - 2022-06-14 09:57:26 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:26 --> Input Class Initialized
INFO - 2022-06-14 09:57:26 --> Language Class Initialized
INFO - 2022-06-14 09:57:26 --> Language Class Initialized
INFO - 2022-06-14 09:57:26 --> Config Class Initialized
INFO - 2022-06-14 09:57:26 --> Loader Class Initialized
INFO - 2022-06-14 09:57:26 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:26 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-14 09:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:26 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:26 --> Total execution time: 0.0460
INFO - 2022-06-14 09:57:26 --> Config Class Initialized
INFO - 2022-06-14 09:57:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:26 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:26 --> URI Class Initialized
INFO - 2022-06-14 09:57:26 --> Router Class Initialized
INFO - 2022-06-14 09:57:26 --> Output Class Initialized
INFO - 2022-06-14 09:57:26 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:26 --> Input Class Initialized
INFO - 2022-06-14 09:57:26 --> Language Class Initialized
INFO - 2022-06-14 09:57:26 --> Language Class Initialized
INFO - 2022-06-14 09:57:26 --> Config Class Initialized
INFO - 2022-06-14 09:57:26 --> Loader Class Initialized
INFO - 2022-06-14 09:57:26 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:26 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 09:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:26 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:26 --> Total execution time: 0.0441
INFO - 2022-06-14 09:57:26 --> Config Class Initialized
INFO - 2022-06-14 09:57:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:26 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:26 --> URI Class Initialized
INFO - 2022-06-14 09:57:26 --> Router Class Initialized
INFO - 2022-06-14 09:57:26 --> Output Class Initialized
INFO - 2022-06-14 09:57:26 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:26 --> Input Class Initialized
INFO - 2022-06-14 09:57:26 --> Language Class Initialized
INFO - 2022-06-14 09:57:26 --> Language Class Initialized
INFO - 2022-06-14 09:57:26 --> Config Class Initialized
INFO - 2022-06-14 09:57:26 --> Loader Class Initialized
INFO - 2022-06-14 09:57:26 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:26 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:26 --> Controller Class Initialized
INFO - 2022-06-14 09:57:38 --> Config Class Initialized
INFO - 2022-06-14 09:57:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:38 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:38 --> URI Class Initialized
INFO - 2022-06-14 09:57:38 --> Router Class Initialized
INFO - 2022-06-14 09:57:38 --> Output Class Initialized
INFO - 2022-06-14 09:57:38 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:38 --> Input Class Initialized
INFO - 2022-06-14 09:57:38 --> Language Class Initialized
INFO - 2022-06-14 09:57:38 --> Language Class Initialized
INFO - 2022-06-14 09:57:38 --> Config Class Initialized
INFO - 2022-06-14 09:57:38 --> Loader Class Initialized
INFO - 2022-06-14 09:57:38 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:38 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:38 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:38 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:38 --> Controller Class Initialized
INFO - 2022-06-14 09:57:38 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:38 --> Total execution time: 0.0493
INFO - 2022-06-14 09:57:38 --> Config Class Initialized
INFO - 2022-06-14 09:57:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:38 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:38 --> URI Class Initialized
INFO - 2022-06-14 09:57:38 --> Router Class Initialized
INFO - 2022-06-14 09:57:38 --> Output Class Initialized
INFO - 2022-06-14 09:57:38 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:38 --> Input Class Initialized
INFO - 2022-06-14 09:57:38 --> Language Class Initialized
INFO - 2022-06-14 09:57:38 --> Language Class Initialized
INFO - 2022-06-14 09:57:38 --> Config Class Initialized
INFO - 2022-06-14 09:57:38 --> Loader Class Initialized
INFO - 2022-06-14 09:57:38 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:38 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:38 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:38 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:38 --> Controller Class Initialized
INFO - 2022-06-14 09:57:38 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:38 --> Total execution time: 0.0481
INFO - 2022-06-14 09:57:44 --> Config Class Initialized
INFO - 2022-06-14 09:57:44 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:44 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:44 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:44 --> URI Class Initialized
INFO - 2022-06-14 09:57:44 --> Router Class Initialized
INFO - 2022-06-14 09:57:44 --> Output Class Initialized
INFO - 2022-06-14 09:57:44 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:44 --> Input Class Initialized
INFO - 2022-06-14 09:57:44 --> Language Class Initialized
INFO - 2022-06-14 09:57:44 --> Language Class Initialized
INFO - 2022-06-14 09:57:44 --> Config Class Initialized
INFO - 2022-06-14 09:57:44 --> Loader Class Initialized
INFO - 2022-06-14 09:57:44 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:44 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:44 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:44 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:44 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:44 --> Controller Class Initialized
INFO - 2022-06-14 09:57:44 --> Helper loaded: cookie_helper
INFO - 2022-06-14 09:57:44 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:44 --> Total execution time: 0.0482
INFO - 2022-06-14 09:57:56 --> Config Class Initialized
INFO - 2022-06-14 09:57:56 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:57:56 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:57:56 --> Utf8 Class Initialized
INFO - 2022-06-14 09:57:56 --> URI Class Initialized
INFO - 2022-06-14 09:57:56 --> Router Class Initialized
INFO - 2022-06-14 09:57:56 --> Output Class Initialized
INFO - 2022-06-14 09:57:56 --> Security Class Initialized
DEBUG - 2022-06-14 09:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:57:56 --> Input Class Initialized
INFO - 2022-06-14 09:57:56 --> Language Class Initialized
INFO - 2022-06-14 09:57:56 --> Language Class Initialized
INFO - 2022-06-14 09:57:56 --> Config Class Initialized
INFO - 2022-06-14 09:57:56 --> Loader Class Initialized
INFO - 2022-06-14 09:57:56 --> Helper loaded: url_helper
INFO - 2022-06-14 09:57:56 --> Helper loaded: file_helper
INFO - 2022-06-14 09:57:56 --> Helper loaded: form_helper
INFO - 2022-06-14 09:57:56 --> Helper loaded: my_helper
INFO - 2022-06-14 09:57:56 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:57:56 --> Controller Class Initialized
DEBUG - 2022-06-14 09:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 09:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:57:56 --> Final output sent to browser
DEBUG - 2022-06-14 09:57:56 --> Total execution time: 0.0496
INFO - 2022-06-14 09:58:14 --> Config Class Initialized
INFO - 2022-06-14 09:58:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:58:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:58:14 --> Utf8 Class Initialized
INFO - 2022-06-14 09:58:14 --> URI Class Initialized
INFO - 2022-06-14 09:58:14 --> Router Class Initialized
INFO - 2022-06-14 09:58:14 --> Output Class Initialized
INFO - 2022-06-14 09:58:14 --> Security Class Initialized
DEBUG - 2022-06-14 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:58:14 --> Input Class Initialized
INFO - 2022-06-14 09:58:14 --> Language Class Initialized
INFO - 2022-06-14 09:58:14 --> Language Class Initialized
INFO - 2022-06-14 09:58:14 --> Config Class Initialized
INFO - 2022-06-14 09:58:14 --> Loader Class Initialized
INFO - 2022-06-14 09:58:14 --> Helper loaded: url_helper
INFO - 2022-06-14 09:58:14 --> Helper loaded: file_helper
INFO - 2022-06-14 09:58:14 --> Helper loaded: form_helper
INFO - 2022-06-14 09:58:14 --> Helper loaded: my_helper
INFO - 2022-06-14 09:58:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:58:14 --> Controller Class Initialized
DEBUG - 2022-06-14 09:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:58:14 --> Final output sent to browser
DEBUG - 2022-06-14 09:58:14 --> Total execution time: 0.0443
INFO - 2022-06-14 09:58:43 --> Config Class Initialized
INFO - 2022-06-14 09:58:43 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:58:43 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:58:43 --> Utf8 Class Initialized
INFO - 2022-06-14 09:58:43 --> URI Class Initialized
INFO - 2022-06-14 09:58:43 --> Router Class Initialized
INFO - 2022-06-14 09:58:43 --> Output Class Initialized
INFO - 2022-06-14 09:58:43 --> Security Class Initialized
DEBUG - 2022-06-14 09:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:58:43 --> Input Class Initialized
INFO - 2022-06-14 09:58:43 --> Language Class Initialized
INFO - 2022-06-14 09:58:43 --> Language Class Initialized
INFO - 2022-06-14 09:58:43 --> Config Class Initialized
INFO - 2022-06-14 09:58:43 --> Loader Class Initialized
INFO - 2022-06-14 09:58:43 --> Helper loaded: url_helper
INFO - 2022-06-14 09:58:43 --> Helper loaded: file_helper
INFO - 2022-06-14 09:58:43 --> Helper loaded: form_helper
INFO - 2022-06-14 09:58:43 --> Helper loaded: my_helper
INFO - 2022-06-14 09:58:43 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:58:43 --> Controller Class Initialized
DEBUG - 2022-06-14 09:58:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 09:58:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:58:43 --> Final output sent to browser
DEBUG - 2022-06-14 09:58:43 --> Total execution time: 0.0524
INFO - 2022-06-14 09:59:05 --> Config Class Initialized
INFO - 2022-06-14 09:59:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:59:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:59:05 --> Utf8 Class Initialized
INFO - 2022-06-14 09:59:05 --> URI Class Initialized
INFO - 2022-06-14 09:59:05 --> Router Class Initialized
INFO - 2022-06-14 09:59:05 --> Output Class Initialized
INFO - 2022-06-14 09:59:05 --> Security Class Initialized
DEBUG - 2022-06-14 09:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:59:05 --> Input Class Initialized
INFO - 2022-06-14 09:59:05 --> Language Class Initialized
INFO - 2022-06-14 09:59:05 --> Language Class Initialized
INFO - 2022-06-14 09:59:05 --> Config Class Initialized
INFO - 2022-06-14 09:59:05 --> Loader Class Initialized
INFO - 2022-06-14 09:59:05 --> Helper loaded: url_helper
INFO - 2022-06-14 09:59:05 --> Helper loaded: file_helper
INFO - 2022-06-14 09:59:05 --> Helper loaded: form_helper
INFO - 2022-06-14 09:59:05 --> Helper loaded: my_helper
INFO - 2022-06-14 09:59:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:59:05 --> Controller Class Initialized
DEBUG - 2022-06-14 09:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-14 09:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 09:59:05 --> Final output sent to browser
DEBUG - 2022-06-14 09:59:05 --> Total execution time: 0.0542
INFO - 2022-06-14 09:59:26 --> Config Class Initialized
INFO - 2022-06-14 09:59:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 09:59:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 09:59:26 --> Utf8 Class Initialized
INFO - 2022-06-14 09:59:26 --> URI Class Initialized
INFO - 2022-06-14 09:59:26 --> Router Class Initialized
INFO - 2022-06-14 09:59:26 --> Output Class Initialized
INFO - 2022-06-14 09:59:26 --> Security Class Initialized
DEBUG - 2022-06-14 09:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 09:59:26 --> Input Class Initialized
INFO - 2022-06-14 09:59:26 --> Language Class Initialized
INFO - 2022-06-14 09:59:26 --> Language Class Initialized
INFO - 2022-06-14 09:59:26 --> Config Class Initialized
INFO - 2022-06-14 09:59:26 --> Loader Class Initialized
INFO - 2022-06-14 09:59:26 --> Helper loaded: url_helper
INFO - 2022-06-14 09:59:26 --> Helper loaded: file_helper
INFO - 2022-06-14 09:59:26 --> Helper loaded: form_helper
INFO - 2022-06-14 09:59:26 --> Helper loaded: my_helper
INFO - 2022-06-14 09:59:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 09:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 09:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 09:59:26 --> Controller Class Initialized
DEBUG - 2022-06-14 09:59:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2022-06-14 09:59:26 --> Final output sent to browser
DEBUG - 2022-06-14 09:59:26 --> Total execution time: 0.0591
INFO - 2022-06-14 10:00:07 --> Config Class Initialized
INFO - 2022-06-14 10:00:07 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:00:07 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:00:07 --> Utf8 Class Initialized
INFO - 2022-06-14 10:00:07 --> URI Class Initialized
INFO - 2022-06-14 10:00:07 --> Router Class Initialized
INFO - 2022-06-14 10:00:07 --> Output Class Initialized
INFO - 2022-06-14 10:00:07 --> Security Class Initialized
DEBUG - 2022-06-14 10:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:00:07 --> Input Class Initialized
INFO - 2022-06-14 10:00:07 --> Language Class Initialized
INFO - 2022-06-14 10:00:07 --> Language Class Initialized
INFO - 2022-06-14 10:00:07 --> Config Class Initialized
INFO - 2022-06-14 10:00:07 --> Loader Class Initialized
INFO - 2022-06-14 10:00:07 --> Helper loaded: url_helper
INFO - 2022-06-14 10:00:07 --> Helper loaded: file_helper
INFO - 2022-06-14 10:00:07 --> Helper loaded: form_helper
INFO - 2022-06-14 10:00:07 --> Helper loaded: my_helper
INFO - 2022-06-14 10:00:07 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:00:07 --> Controller Class Initialized
DEBUG - 2022-06-14 10:00:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2022-06-14 10:00:07 --> Final output sent to browser
DEBUG - 2022-06-14 10:00:07 --> Total execution time: 0.0497
INFO - 2022-06-14 10:00:09 --> Config Class Initialized
INFO - 2022-06-14 10:00:09 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:00:09 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:00:09 --> Utf8 Class Initialized
INFO - 2022-06-14 10:00:09 --> URI Class Initialized
INFO - 2022-06-14 10:00:09 --> Router Class Initialized
INFO - 2022-06-14 10:00:09 --> Output Class Initialized
INFO - 2022-06-14 10:00:09 --> Security Class Initialized
DEBUG - 2022-06-14 10:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:00:09 --> Input Class Initialized
INFO - 2022-06-14 10:00:09 --> Language Class Initialized
INFO - 2022-06-14 10:00:09 --> Language Class Initialized
INFO - 2022-06-14 10:00:09 --> Config Class Initialized
INFO - 2022-06-14 10:00:09 --> Loader Class Initialized
INFO - 2022-06-14 10:00:09 --> Helper loaded: url_helper
INFO - 2022-06-14 10:00:09 --> Helper loaded: file_helper
INFO - 2022-06-14 10:00:09 --> Helper loaded: form_helper
INFO - 2022-06-14 10:00:09 --> Helper loaded: my_helper
INFO - 2022-06-14 10:00:09 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:00:09 --> Controller Class Initialized
DEBUG - 2022-06-14 10:00:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2022-06-14 10:00:09 --> Final output sent to browser
DEBUG - 2022-06-14 10:00:09 --> Total execution time: 0.0494
INFO - 2022-06-14 10:00:14 --> Config Class Initialized
INFO - 2022-06-14 10:00:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:00:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:00:14 --> Utf8 Class Initialized
INFO - 2022-06-14 10:00:14 --> URI Class Initialized
INFO - 2022-06-14 10:00:14 --> Router Class Initialized
INFO - 2022-06-14 10:00:14 --> Output Class Initialized
INFO - 2022-06-14 10:00:14 --> Security Class Initialized
DEBUG - 2022-06-14 10:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:00:14 --> Input Class Initialized
INFO - 2022-06-14 10:00:14 --> Language Class Initialized
INFO - 2022-06-14 10:00:14 --> Language Class Initialized
INFO - 2022-06-14 10:00:14 --> Config Class Initialized
INFO - 2022-06-14 10:00:14 --> Loader Class Initialized
INFO - 2022-06-14 10:00:14 --> Helper loaded: url_helper
INFO - 2022-06-14 10:00:14 --> Helper loaded: file_helper
INFO - 2022-06-14 10:00:14 --> Helper loaded: form_helper
INFO - 2022-06-14 10:00:14 --> Helper loaded: my_helper
INFO - 2022-06-14 10:00:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:00:14 --> Controller Class Initialized
DEBUG - 2022-06-14 10:00:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2022-06-14 10:00:14 --> Final output sent to browser
DEBUG - 2022-06-14 10:00:14 --> Total execution time: 0.0503
INFO - 2022-06-14 10:00:29 --> Config Class Initialized
INFO - 2022-06-14 10:00:29 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:00:29 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:00:29 --> Utf8 Class Initialized
INFO - 2022-06-14 10:00:29 --> URI Class Initialized
INFO - 2022-06-14 10:00:29 --> Router Class Initialized
INFO - 2022-06-14 10:00:29 --> Output Class Initialized
INFO - 2022-06-14 10:00:29 --> Security Class Initialized
DEBUG - 2022-06-14 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:00:29 --> Input Class Initialized
INFO - 2022-06-14 10:00:29 --> Language Class Initialized
INFO - 2022-06-14 10:00:29 --> Language Class Initialized
INFO - 2022-06-14 10:00:29 --> Config Class Initialized
INFO - 2022-06-14 10:00:29 --> Loader Class Initialized
INFO - 2022-06-14 10:00:29 --> Helper loaded: url_helper
INFO - 2022-06-14 10:00:29 --> Helper loaded: file_helper
INFO - 2022-06-14 10:00:29 --> Helper loaded: form_helper
INFO - 2022-06-14 10:00:29 --> Helper loaded: my_helper
INFO - 2022-06-14 10:00:29 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:00:29 --> Controller Class Initialized
DEBUG - 2022-06-14 10:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:00:29 --> Final output sent to browser
DEBUG - 2022-06-14 10:00:29 --> Total execution time: 0.0522
INFO - 2022-06-14 10:01:05 --> Config Class Initialized
INFO - 2022-06-14 10:01:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:05 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:05 --> URI Class Initialized
INFO - 2022-06-14 10:01:05 --> Router Class Initialized
INFO - 2022-06-14 10:01:05 --> Output Class Initialized
INFO - 2022-06-14 10:01:05 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:05 --> Input Class Initialized
INFO - 2022-06-14 10:01:05 --> Language Class Initialized
INFO - 2022-06-14 10:01:05 --> Language Class Initialized
INFO - 2022-06-14 10:01:05 --> Config Class Initialized
INFO - 2022-06-14 10:01:05 --> Loader Class Initialized
INFO - 2022-06-14 10:01:05 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:05 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:05 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:05 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:05 --> Controller Class Initialized
INFO - 2022-06-14 10:01:05 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:05 --> Total execution time: 0.0926
INFO - 2022-06-14 10:01:19 --> Config Class Initialized
INFO - 2022-06-14 10:01:19 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:19 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:19 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:19 --> URI Class Initialized
INFO - 2022-06-14 10:01:19 --> Router Class Initialized
INFO - 2022-06-14 10:01:19 --> Output Class Initialized
INFO - 2022-06-14 10:01:19 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:19 --> Input Class Initialized
INFO - 2022-06-14 10:01:19 --> Language Class Initialized
INFO - 2022-06-14 10:01:19 --> Language Class Initialized
INFO - 2022-06-14 10:01:19 --> Config Class Initialized
INFO - 2022-06-14 10:01:19 --> Loader Class Initialized
INFO - 2022-06-14 10:01:19 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:19 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:19 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:19 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:19 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:19 --> Controller Class Initialized
INFO - 2022-06-14 10:01:19 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:19 --> Total execution time: 0.2375
INFO - 2022-06-14 10:01:19 --> Config Class Initialized
INFO - 2022-06-14 10:01:19 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:19 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:19 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:19 --> URI Class Initialized
INFO - 2022-06-14 10:01:19 --> Router Class Initialized
INFO - 2022-06-14 10:01:19 --> Output Class Initialized
INFO - 2022-06-14 10:01:20 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:20 --> Input Class Initialized
INFO - 2022-06-14 10:01:20 --> Language Class Initialized
INFO - 2022-06-14 10:01:20 --> Language Class Initialized
INFO - 2022-06-14 10:01:20 --> Config Class Initialized
INFO - 2022-06-14 10:01:20 --> Loader Class Initialized
INFO - 2022-06-14 10:01:20 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:20 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:20 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:20 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:20 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:20 --> Controller Class Initialized
INFO - 2022-06-14 10:01:20 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:20 --> Total execution time: 0.0757
INFO - 2022-06-14 10:01:21 --> Config Class Initialized
INFO - 2022-06-14 10:01:21 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:21 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:21 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:21 --> URI Class Initialized
INFO - 2022-06-14 10:01:21 --> Router Class Initialized
INFO - 2022-06-14 10:01:21 --> Output Class Initialized
INFO - 2022-06-14 10:01:21 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:21 --> Input Class Initialized
INFO - 2022-06-14 10:01:21 --> Language Class Initialized
INFO - 2022-06-14 10:01:21 --> Language Class Initialized
INFO - 2022-06-14 10:01:21 --> Config Class Initialized
INFO - 2022-06-14 10:01:21 --> Loader Class Initialized
INFO - 2022-06-14 10:01:21 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:21 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:21 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:21 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:21 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:21 --> Controller Class Initialized
DEBUG - 2022-06-14 10:01:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:01:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:01:21 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:21 --> Total execution time: 0.0535
INFO - 2022-06-14 10:01:25 --> Config Class Initialized
INFO - 2022-06-14 10:01:25 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:25 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:25 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:25 --> URI Class Initialized
INFO - 2022-06-14 10:01:25 --> Router Class Initialized
INFO - 2022-06-14 10:01:25 --> Output Class Initialized
INFO - 2022-06-14 10:01:25 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:25 --> Input Class Initialized
INFO - 2022-06-14 10:01:25 --> Language Class Initialized
INFO - 2022-06-14 10:01:25 --> Language Class Initialized
INFO - 2022-06-14 10:01:25 --> Config Class Initialized
INFO - 2022-06-14 10:01:25 --> Loader Class Initialized
INFO - 2022-06-14 10:01:25 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:25 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:25 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:25 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:25 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:25 --> Controller Class Initialized
INFO - 2022-06-14 10:01:25 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:01:25 --> Config Class Initialized
INFO - 2022-06-14 10:01:25 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:25 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:25 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:25 --> URI Class Initialized
INFO - 2022-06-14 10:01:25 --> Router Class Initialized
INFO - 2022-06-14 10:01:25 --> Output Class Initialized
INFO - 2022-06-14 10:01:25 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:25 --> Input Class Initialized
INFO - 2022-06-14 10:01:25 --> Language Class Initialized
INFO - 2022-06-14 10:01:25 --> Language Class Initialized
INFO - 2022-06-14 10:01:25 --> Config Class Initialized
INFO - 2022-06-14 10:01:25 --> Loader Class Initialized
INFO - 2022-06-14 10:01:25 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:25 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:25 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:25 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:25 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:25 --> Controller Class Initialized
DEBUG - 2022-06-14 10:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:01:25 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:25 --> Total execution time: 0.0470
INFO - 2022-06-14 10:01:26 --> Config Class Initialized
INFO - 2022-06-14 10:01:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:26 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:26 --> URI Class Initialized
INFO - 2022-06-14 10:01:26 --> Router Class Initialized
INFO - 2022-06-14 10:01:26 --> Output Class Initialized
INFO - 2022-06-14 10:01:26 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:26 --> Input Class Initialized
INFO - 2022-06-14 10:01:26 --> Language Class Initialized
INFO - 2022-06-14 10:01:26 --> Language Class Initialized
INFO - 2022-06-14 10:01:26 --> Config Class Initialized
INFO - 2022-06-14 10:01:26 --> Loader Class Initialized
INFO - 2022-06-14 10:01:26 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:26 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:26 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:26 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:26 --> Controller Class Initialized
INFO - 2022-06-14 10:01:26 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:26 --> Total execution time: 0.0685
INFO - 2022-06-14 10:01:36 --> Config Class Initialized
INFO - 2022-06-14 10:01:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:36 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:36 --> URI Class Initialized
INFO - 2022-06-14 10:01:36 --> Router Class Initialized
INFO - 2022-06-14 10:01:36 --> Output Class Initialized
INFO - 2022-06-14 10:01:36 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:36 --> Input Class Initialized
INFO - 2022-06-14 10:01:36 --> Language Class Initialized
INFO - 2022-06-14 10:01:36 --> Language Class Initialized
INFO - 2022-06-14 10:01:36 --> Config Class Initialized
INFO - 2022-06-14 10:01:36 --> Loader Class Initialized
INFO - 2022-06-14 10:01:36 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:36 --> Controller Class Initialized
INFO - 2022-06-14 10:01:36 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:01:36 --> Config Class Initialized
INFO - 2022-06-14 10:01:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:36 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:36 --> URI Class Initialized
INFO - 2022-06-14 10:01:36 --> Router Class Initialized
INFO - 2022-06-14 10:01:36 --> Output Class Initialized
INFO - 2022-06-14 10:01:36 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:36 --> Input Class Initialized
INFO - 2022-06-14 10:01:36 --> Language Class Initialized
INFO - 2022-06-14 10:01:36 --> Language Class Initialized
INFO - 2022-06-14 10:01:36 --> Config Class Initialized
INFO - 2022-06-14 10:01:36 --> Loader Class Initialized
INFO - 2022-06-14 10:01:36 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:36 --> Controller Class Initialized
DEBUG - 2022-06-14 10:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:01:36 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:36 --> Total execution time: 0.0469
INFO - 2022-06-14 10:01:36 --> Config Class Initialized
INFO - 2022-06-14 10:01:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:36 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:36 --> URI Class Initialized
INFO - 2022-06-14 10:01:36 --> Router Class Initialized
INFO - 2022-06-14 10:01:36 --> Output Class Initialized
INFO - 2022-06-14 10:01:36 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:36 --> Input Class Initialized
INFO - 2022-06-14 10:01:36 --> Language Class Initialized
INFO - 2022-06-14 10:01:36 --> Language Class Initialized
INFO - 2022-06-14 10:01:36 --> Config Class Initialized
INFO - 2022-06-14 10:01:36 --> Loader Class Initialized
INFO - 2022-06-14 10:01:36 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:36 --> Controller Class Initialized
INFO - 2022-06-14 10:01:36 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:01:36 --> Config Class Initialized
INFO - 2022-06-14 10:01:36 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:36 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:36 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:36 --> URI Class Initialized
INFO - 2022-06-14 10:01:36 --> Router Class Initialized
INFO - 2022-06-14 10:01:36 --> Output Class Initialized
INFO - 2022-06-14 10:01:36 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:36 --> Input Class Initialized
INFO - 2022-06-14 10:01:36 --> Language Class Initialized
INFO - 2022-06-14 10:01:36 --> Language Class Initialized
INFO - 2022-06-14 10:01:36 --> Config Class Initialized
INFO - 2022-06-14 10:01:36 --> Loader Class Initialized
INFO - 2022-06-14 10:01:36 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:36 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:36 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:36 --> Controller Class Initialized
DEBUG - 2022-06-14 10:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:01:36 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:36 --> Total execution time: 0.0472
INFO - 2022-06-14 10:01:40 --> Config Class Initialized
INFO - 2022-06-14 10:01:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:40 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:40 --> URI Class Initialized
INFO - 2022-06-14 10:01:40 --> Router Class Initialized
INFO - 2022-06-14 10:01:40 --> Output Class Initialized
INFO - 2022-06-14 10:01:40 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:40 --> Input Class Initialized
INFO - 2022-06-14 10:01:40 --> Language Class Initialized
INFO - 2022-06-14 10:01:40 --> Language Class Initialized
INFO - 2022-06-14 10:01:40 --> Config Class Initialized
INFO - 2022-06-14 10:01:40 --> Loader Class Initialized
INFO - 2022-06-14 10:01:40 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:40 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:40 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:40 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:40 --> Controller Class Initialized
INFO - 2022-06-14 10:01:40 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:01:40 --> Config Class Initialized
INFO - 2022-06-14 10:01:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:40 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:40 --> URI Class Initialized
INFO - 2022-06-14 10:01:40 --> Router Class Initialized
INFO - 2022-06-14 10:01:40 --> Output Class Initialized
INFO - 2022-06-14 10:01:40 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:40 --> Input Class Initialized
INFO - 2022-06-14 10:01:40 --> Language Class Initialized
INFO - 2022-06-14 10:01:40 --> Language Class Initialized
INFO - 2022-06-14 10:01:40 --> Config Class Initialized
INFO - 2022-06-14 10:01:40 --> Loader Class Initialized
INFO - 2022-06-14 10:01:40 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:40 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:40 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:40 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:40 --> Controller Class Initialized
DEBUG - 2022-06-14 10:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:01:40 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:40 --> Total execution time: 0.0460
INFO - 2022-06-14 10:01:50 --> Config Class Initialized
INFO - 2022-06-14 10:01:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:50 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:50 --> URI Class Initialized
INFO - 2022-06-14 10:01:50 --> Router Class Initialized
INFO - 2022-06-14 10:01:50 --> Output Class Initialized
INFO - 2022-06-14 10:01:50 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:50 --> Input Class Initialized
INFO - 2022-06-14 10:01:50 --> Language Class Initialized
INFO - 2022-06-14 10:01:50 --> Language Class Initialized
INFO - 2022-06-14 10:01:50 --> Config Class Initialized
INFO - 2022-06-14 10:01:50 --> Loader Class Initialized
INFO - 2022-06-14 10:01:50 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:50 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:50 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:50 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:50 --> Controller Class Initialized
INFO - 2022-06-14 10:01:50 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:01:50 --> Config Class Initialized
INFO - 2022-06-14 10:01:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:01:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:01:50 --> Utf8 Class Initialized
INFO - 2022-06-14 10:01:50 --> URI Class Initialized
INFO - 2022-06-14 10:01:50 --> Router Class Initialized
INFO - 2022-06-14 10:01:50 --> Output Class Initialized
INFO - 2022-06-14 10:01:50 --> Security Class Initialized
DEBUG - 2022-06-14 10:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:01:50 --> Input Class Initialized
INFO - 2022-06-14 10:01:50 --> Language Class Initialized
INFO - 2022-06-14 10:01:50 --> Language Class Initialized
INFO - 2022-06-14 10:01:50 --> Config Class Initialized
INFO - 2022-06-14 10:01:50 --> Loader Class Initialized
INFO - 2022-06-14 10:01:50 --> Helper loaded: url_helper
INFO - 2022-06-14 10:01:50 --> Helper loaded: file_helper
INFO - 2022-06-14 10:01:50 --> Helper loaded: form_helper
INFO - 2022-06-14 10:01:50 --> Helper loaded: my_helper
INFO - 2022-06-14 10:01:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:01:50 --> Controller Class Initialized
DEBUG - 2022-06-14 10:01:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:01:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:01:50 --> Final output sent to browser
DEBUG - 2022-06-14 10:01:50 --> Total execution time: 0.0510
INFO - 2022-06-14 10:28:26 --> Config Class Initialized
INFO - 2022-06-14 10:28:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:26 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:26 --> URI Class Initialized
INFO - 2022-06-14 10:28:26 --> Router Class Initialized
INFO - 2022-06-14 10:28:26 --> Output Class Initialized
INFO - 2022-06-14 10:28:26 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:26 --> Input Class Initialized
INFO - 2022-06-14 10:28:26 --> Language Class Initialized
INFO - 2022-06-14 10:28:26 --> Language Class Initialized
INFO - 2022-06-14 10:28:26 --> Config Class Initialized
INFO - 2022-06-14 10:28:26 --> Loader Class Initialized
INFO - 2022-06-14 10:28:26 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:26 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:26 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:26 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:27 --> Controller Class Initialized
INFO - 2022-06-14 10:28:27 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:28:27 --> Config Class Initialized
INFO - 2022-06-14 10:28:27 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:27 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:27 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:27 --> URI Class Initialized
INFO - 2022-06-14 10:28:27 --> Router Class Initialized
INFO - 2022-06-14 10:28:27 --> Output Class Initialized
INFO - 2022-06-14 10:28:27 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:27 --> Input Class Initialized
INFO - 2022-06-14 10:28:27 --> Language Class Initialized
INFO - 2022-06-14 10:28:27 --> Language Class Initialized
INFO - 2022-06-14 10:28:27 --> Config Class Initialized
INFO - 2022-06-14 10:28:27 --> Loader Class Initialized
INFO - 2022-06-14 10:28:27 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:27 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:27 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:27 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:27 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:27 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:27 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:27 --> Total execution time: 0.0511
INFO - 2022-06-14 10:28:29 --> Config Class Initialized
INFO - 2022-06-14 10:28:29 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:29 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:29 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:29 --> URI Class Initialized
INFO - 2022-06-14 10:28:29 --> Router Class Initialized
INFO - 2022-06-14 10:28:29 --> Output Class Initialized
INFO - 2022-06-14 10:28:29 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:29 --> Input Class Initialized
INFO - 2022-06-14 10:28:29 --> Language Class Initialized
INFO - 2022-06-14 10:28:29 --> Language Class Initialized
INFO - 2022-06-14 10:28:29 --> Config Class Initialized
INFO - 2022-06-14 10:28:29 --> Loader Class Initialized
INFO - 2022-06-14 10:28:29 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:29 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:29 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:29 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:29 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:29 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:29 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:29 --> Total execution time: 0.0527
INFO - 2022-06-14 10:28:29 --> Config Class Initialized
INFO - 2022-06-14 10:28:29 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:29 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:29 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:29 --> URI Class Initialized
INFO - 2022-06-14 10:28:29 --> Router Class Initialized
INFO - 2022-06-14 10:28:29 --> Output Class Initialized
INFO - 2022-06-14 10:28:29 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:29 --> Input Class Initialized
INFO - 2022-06-14 10:28:29 --> Language Class Initialized
INFO - 2022-06-14 10:28:29 --> Language Class Initialized
INFO - 2022-06-14 10:28:29 --> Config Class Initialized
INFO - 2022-06-14 10:28:29 --> Loader Class Initialized
INFO - 2022-06-14 10:28:29 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:29 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:29 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:29 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:29 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:29 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:29 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:29 --> Total execution time: 0.0496
INFO - 2022-06-14 10:28:30 --> Config Class Initialized
INFO - 2022-06-14 10:28:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:30 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:30 --> URI Class Initialized
INFO - 2022-06-14 10:28:30 --> Router Class Initialized
INFO - 2022-06-14 10:28:30 --> Output Class Initialized
INFO - 2022-06-14 10:28:30 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:30 --> Input Class Initialized
INFO - 2022-06-14 10:28:30 --> Language Class Initialized
INFO - 2022-06-14 10:28:30 --> Language Class Initialized
INFO - 2022-06-14 10:28:30 --> Config Class Initialized
INFO - 2022-06-14 10:28:30 --> Loader Class Initialized
INFO - 2022-06-14 10:28:30 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:30 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:30 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:30 --> Total execution time: 0.0418
INFO - 2022-06-14 10:28:30 --> Config Class Initialized
INFO - 2022-06-14 10:28:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:30 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:30 --> URI Class Initialized
INFO - 2022-06-14 10:28:30 --> Router Class Initialized
INFO - 2022-06-14 10:28:30 --> Output Class Initialized
INFO - 2022-06-14 10:28:30 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:30 --> Input Class Initialized
INFO - 2022-06-14 10:28:30 --> Language Class Initialized
INFO - 2022-06-14 10:28:30 --> Language Class Initialized
INFO - 2022-06-14 10:28:30 --> Config Class Initialized
INFO - 2022-06-14 10:28:30 --> Loader Class Initialized
INFO - 2022-06-14 10:28:30 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:30 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:30 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:30 --> Total execution time: 0.0497
INFO - 2022-06-14 10:28:30 --> Config Class Initialized
INFO - 2022-06-14 10:28:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:30 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:30 --> URI Class Initialized
INFO - 2022-06-14 10:28:30 --> Router Class Initialized
INFO - 2022-06-14 10:28:30 --> Output Class Initialized
INFO - 2022-06-14 10:28:30 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:30 --> Input Class Initialized
INFO - 2022-06-14 10:28:30 --> Language Class Initialized
INFO - 2022-06-14 10:28:30 --> Language Class Initialized
INFO - 2022-06-14 10:28:30 --> Config Class Initialized
INFO - 2022-06-14 10:28:30 --> Loader Class Initialized
INFO - 2022-06-14 10:28:30 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:30 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:30 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:30 --> Total execution time: 0.0519
INFO - 2022-06-14 10:28:30 --> Config Class Initialized
INFO - 2022-06-14 10:28:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:30 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:30 --> URI Class Initialized
INFO - 2022-06-14 10:28:30 --> Router Class Initialized
INFO - 2022-06-14 10:28:30 --> Output Class Initialized
INFO - 2022-06-14 10:28:30 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:30 --> Input Class Initialized
INFO - 2022-06-14 10:28:30 --> Language Class Initialized
INFO - 2022-06-14 10:28:30 --> Language Class Initialized
INFO - 2022-06-14 10:28:30 --> Config Class Initialized
INFO - 2022-06-14 10:28:30 --> Loader Class Initialized
INFO - 2022-06-14 10:28:30 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:30 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:30 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:30 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:30 --> Total execution time: 0.0508
INFO - 2022-06-14 10:28:31 --> Config Class Initialized
INFO - 2022-06-14 10:28:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:31 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:31 --> URI Class Initialized
INFO - 2022-06-14 10:28:31 --> Router Class Initialized
INFO - 2022-06-14 10:28:31 --> Output Class Initialized
INFO - 2022-06-14 10:28:31 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:31 --> Input Class Initialized
INFO - 2022-06-14 10:28:31 --> Language Class Initialized
INFO - 2022-06-14 10:28:31 --> Language Class Initialized
INFO - 2022-06-14 10:28:31 --> Config Class Initialized
INFO - 2022-06-14 10:28:31 --> Loader Class Initialized
INFO - 2022-06-14 10:28:31 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:31 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:31 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:31 --> Total execution time: 0.0502
INFO - 2022-06-14 10:28:31 --> Config Class Initialized
INFO - 2022-06-14 10:28:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:31 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:31 --> URI Class Initialized
INFO - 2022-06-14 10:28:31 --> Router Class Initialized
INFO - 2022-06-14 10:28:31 --> Output Class Initialized
INFO - 2022-06-14 10:28:31 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:31 --> Input Class Initialized
INFO - 2022-06-14 10:28:31 --> Language Class Initialized
INFO - 2022-06-14 10:28:31 --> Language Class Initialized
INFO - 2022-06-14 10:28:31 --> Config Class Initialized
INFO - 2022-06-14 10:28:31 --> Loader Class Initialized
INFO - 2022-06-14 10:28:31 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:31 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:31 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:31 --> Total execution time: 0.0506
INFO - 2022-06-14 10:28:31 --> Config Class Initialized
INFO - 2022-06-14 10:28:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:31 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:31 --> URI Class Initialized
INFO - 2022-06-14 10:28:31 --> Router Class Initialized
INFO - 2022-06-14 10:28:31 --> Output Class Initialized
INFO - 2022-06-14 10:28:31 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:31 --> Input Class Initialized
INFO - 2022-06-14 10:28:31 --> Language Class Initialized
INFO - 2022-06-14 10:28:31 --> Language Class Initialized
INFO - 2022-06-14 10:28:31 --> Config Class Initialized
INFO - 2022-06-14 10:28:31 --> Loader Class Initialized
INFO - 2022-06-14 10:28:31 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:31 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:31 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:31 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:31 --> Total execution time: 0.0415
INFO - 2022-06-14 10:28:49 --> Config Class Initialized
INFO - 2022-06-14 10:28:49 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:49 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:49 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:49 --> URI Class Initialized
INFO - 2022-06-14 10:28:49 --> Router Class Initialized
INFO - 2022-06-14 10:28:49 --> Output Class Initialized
INFO - 2022-06-14 10:28:49 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:49 --> Input Class Initialized
INFO - 2022-06-14 10:28:49 --> Language Class Initialized
INFO - 2022-06-14 10:28:49 --> Language Class Initialized
INFO - 2022-06-14 10:28:49 --> Config Class Initialized
INFO - 2022-06-14 10:28:49 --> Loader Class Initialized
INFO - 2022-06-14 10:28:49 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:49 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:49 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:49 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:49 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:49 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:49 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:49 --> Total execution time: 0.0463
INFO - 2022-06-14 10:28:49 --> Config Class Initialized
INFO - 2022-06-14 10:28:49 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:49 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:49 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:49 --> URI Class Initialized
INFO - 2022-06-14 10:28:49 --> Router Class Initialized
INFO - 2022-06-14 10:28:49 --> Output Class Initialized
INFO - 2022-06-14 10:28:49 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:49 --> Input Class Initialized
INFO - 2022-06-14 10:28:49 --> Language Class Initialized
INFO - 2022-06-14 10:28:49 --> Language Class Initialized
INFO - 2022-06-14 10:28:49 --> Config Class Initialized
INFO - 2022-06-14 10:28:49 --> Loader Class Initialized
INFO - 2022-06-14 10:28:49 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:49 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:49 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:49 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:49 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:49 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:49 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:49 --> Total execution time: 0.0392
INFO - 2022-06-14 10:28:54 --> Config Class Initialized
INFO - 2022-06-14 10:28:54 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:54 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:54 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:54 --> URI Class Initialized
DEBUG - 2022-06-14 10:28:54 --> No URI present. Default controller set.
INFO - 2022-06-14 10:28:54 --> Router Class Initialized
INFO - 2022-06-14 10:28:54 --> Output Class Initialized
INFO - 2022-06-14 10:28:54 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:54 --> Input Class Initialized
INFO - 2022-06-14 10:28:54 --> Language Class Initialized
INFO - 2022-06-14 10:28:54 --> Language Class Initialized
INFO - 2022-06-14 10:28:54 --> Config Class Initialized
INFO - 2022-06-14 10:28:54 --> Loader Class Initialized
INFO - 2022-06-14 10:28:54 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:54 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:54 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:54 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:54 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:54 --> Controller Class Initialized
INFO - 2022-06-14 10:28:54 --> Config Class Initialized
INFO - 2022-06-14 10:28:54 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:28:54 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:28:54 --> Utf8 Class Initialized
INFO - 2022-06-14 10:28:54 --> URI Class Initialized
INFO - 2022-06-14 10:28:54 --> Router Class Initialized
INFO - 2022-06-14 10:28:54 --> Output Class Initialized
INFO - 2022-06-14 10:28:54 --> Security Class Initialized
DEBUG - 2022-06-14 10:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:28:54 --> Input Class Initialized
INFO - 2022-06-14 10:28:54 --> Language Class Initialized
INFO - 2022-06-14 10:28:54 --> Language Class Initialized
INFO - 2022-06-14 10:28:54 --> Config Class Initialized
INFO - 2022-06-14 10:28:54 --> Loader Class Initialized
INFO - 2022-06-14 10:28:54 --> Helper loaded: url_helper
INFO - 2022-06-14 10:28:54 --> Helper loaded: file_helper
INFO - 2022-06-14 10:28:54 --> Helper loaded: form_helper
INFO - 2022-06-14 10:28:54 --> Helper loaded: my_helper
INFO - 2022-06-14 10:28:54 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:28:54 --> Controller Class Initialized
DEBUG - 2022-06-14 10:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:28:54 --> Final output sent to browser
DEBUG - 2022-06-14 10:28:54 --> Total execution time: 0.0481
INFO - 2022-06-14 10:31:50 --> Config Class Initialized
INFO - 2022-06-14 10:31:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:31:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:31:50 --> Utf8 Class Initialized
INFO - 2022-06-14 10:31:50 --> URI Class Initialized
INFO - 2022-06-14 10:31:50 --> Router Class Initialized
INFO - 2022-06-14 10:31:50 --> Output Class Initialized
INFO - 2022-06-14 10:31:50 --> Security Class Initialized
DEBUG - 2022-06-14 10:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:31:50 --> Input Class Initialized
INFO - 2022-06-14 10:31:50 --> Language Class Initialized
INFO - 2022-06-14 10:31:50 --> Language Class Initialized
INFO - 2022-06-14 10:31:50 --> Config Class Initialized
INFO - 2022-06-14 10:31:50 --> Loader Class Initialized
INFO - 2022-06-14 10:31:50 --> Helper loaded: url_helper
INFO - 2022-06-14 10:31:50 --> Helper loaded: file_helper
INFO - 2022-06-14 10:31:50 --> Helper loaded: form_helper
INFO - 2022-06-14 10:31:50 --> Helper loaded: my_helper
INFO - 2022-06-14 10:31:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:31:50 --> Controller Class Initialized
INFO - 2022-06-14 10:31:51 --> Final output sent to browser
DEBUG - 2022-06-14 10:31:51 --> Total execution time: 0.1049
INFO - 2022-06-14 10:31:57 --> Config Class Initialized
INFO - 2022-06-14 10:31:57 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:31:57 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:31:57 --> Utf8 Class Initialized
INFO - 2022-06-14 10:31:58 --> URI Class Initialized
INFO - 2022-06-14 10:31:58 --> Router Class Initialized
INFO - 2022-06-14 10:31:58 --> Output Class Initialized
INFO - 2022-06-14 10:31:58 --> Security Class Initialized
DEBUG - 2022-06-14 10:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:31:58 --> Input Class Initialized
INFO - 2022-06-14 10:31:58 --> Language Class Initialized
INFO - 2022-06-14 10:31:58 --> Language Class Initialized
INFO - 2022-06-14 10:31:58 --> Config Class Initialized
INFO - 2022-06-14 10:31:58 --> Loader Class Initialized
INFO - 2022-06-14 10:31:58 --> Helper loaded: url_helper
INFO - 2022-06-14 10:31:58 --> Helper loaded: file_helper
INFO - 2022-06-14 10:31:58 --> Helper loaded: form_helper
INFO - 2022-06-14 10:31:58 --> Helper loaded: my_helper
INFO - 2022-06-14 10:31:58 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:31:58 --> Controller Class Initialized
INFO - 2022-06-14 10:31:58 --> Final output sent to browser
DEBUG - 2022-06-14 10:31:58 --> Total execution time: 0.1106
INFO - 2022-06-14 10:32:06 --> Config Class Initialized
INFO - 2022-06-14 10:32:06 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:32:06 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:32:06 --> Utf8 Class Initialized
INFO - 2022-06-14 10:32:06 --> URI Class Initialized
INFO - 2022-06-14 10:32:06 --> Router Class Initialized
INFO - 2022-06-14 10:32:06 --> Output Class Initialized
INFO - 2022-06-14 10:32:06 --> Security Class Initialized
DEBUG - 2022-06-14 10:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:32:06 --> Input Class Initialized
INFO - 2022-06-14 10:32:06 --> Language Class Initialized
INFO - 2022-06-14 10:32:06 --> Language Class Initialized
INFO - 2022-06-14 10:32:06 --> Config Class Initialized
INFO - 2022-06-14 10:32:06 --> Loader Class Initialized
INFO - 2022-06-14 10:32:06 --> Helper loaded: url_helper
INFO - 2022-06-14 10:32:06 --> Helper loaded: file_helper
INFO - 2022-06-14 10:32:06 --> Helper loaded: form_helper
INFO - 2022-06-14 10:32:06 --> Helper loaded: my_helper
INFO - 2022-06-14 10:32:06 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:32:06 --> Controller Class Initialized
DEBUG - 2022-06-14 10:32:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 10:32:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:32:06 --> Final output sent to browser
DEBUG - 2022-06-14 10:32:06 --> Total execution time: 0.0461
INFO - 2022-06-14 10:32:12 --> Config Class Initialized
INFO - 2022-06-14 10:32:12 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:32:12 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:32:12 --> Utf8 Class Initialized
INFO - 2022-06-14 10:32:12 --> URI Class Initialized
INFO - 2022-06-14 10:32:12 --> Router Class Initialized
INFO - 2022-06-14 10:32:12 --> Output Class Initialized
INFO - 2022-06-14 10:32:12 --> Security Class Initialized
DEBUG - 2022-06-14 10:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:32:12 --> Input Class Initialized
INFO - 2022-06-14 10:32:12 --> Language Class Initialized
INFO - 2022-06-14 10:32:12 --> Language Class Initialized
INFO - 2022-06-14 10:32:12 --> Config Class Initialized
INFO - 2022-06-14 10:32:12 --> Loader Class Initialized
INFO - 2022-06-14 10:32:12 --> Helper loaded: url_helper
INFO - 2022-06-14 10:32:12 --> Helper loaded: file_helper
INFO - 2022-06-14 10:32:12 --> Helper loaded: form_helper
INFO - 2022-06-14 10:32:12 --> Helper loaded: my_helper
INFO - 2022-06-14 10:32:12 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:32:12 --> Controller Class Initialized
INFO - 2022-06-14 10:32:12 --> Final output sent to browser
DEBUG - 2022-06-14 10:32:12 --> Total execution time: 0.0547
INFO - 2022-06-14 10:34:13 --> Config Class Initialized
INFO - 2022-06-14 10:34:13 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:34:13 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:34:13 --> Utf8 Class Initialized
INFO - 2022-06-14 10:34:13 --> URI Class Initialized
INFO - 2022-06-14 10:34:13 --> Router Class Initialized
INFO - 2022-06-14 10:34:13 --> Output Class Initialized
INFO - 2022-06-14 10:34:13 --> Security Class Initialized
DEBUG - 2022-06-14 10:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:34:13 --> Input Class Initialized
INFO - 2022-06-14 10:34:13 --> Language Class Initialized
INFO - 2022-06-14 10:34:13 --> Language Class Initialized
INFO - 2022-06-14 10:34:13 --> Config Class Initialized
INFO - 2022-06-14 10:34:13 --> Loader Class Initialized
INFO - 2022-06-14 10:34:13 --> Helper loaded: url_helper
INFO - 2022-06-14 10:34:13 --> Helper loaded: file_helper
INFO - 2022-06-14 10:34:13 --> Helper loaded: form_helper
INFO - 2022-06-14 10:34:13 --> Helper loaded: my_helper
INFO - 2022-06-14 10:34:13 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:34:13 --> Controller Class Initialized
INFO - 2022-06-14 10:34:13 --> Final output sent to browser
DEBUG - 2022-06-14 10:34:13 --> Total execution time: 0.0972
INFO - 2022-06-14 10:34:14 --> Config Class Initialized
INFO - 2022-06-14 10:34:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:34:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:34:14 --> Utf8 Class Initialized
INFO - 2022-06-14 10:34:14 --> URI Class Initialized
INFO - 2022-06-14 10:34:14 --> Router Class Initialized
INFO - 2022-06-14 10:34:14 --> Output Class Initialized
INFO - 2022-06-14 10:34:14 --> Security Class Initialized
DEBUG - 2022-06-14 10:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:34:14 --> Input Class Initialized
INFO - 2022-06-14 10:34:14 --> Language Class Initialized
INFO - 2022-06-14 10:34:14 --> Language Class Initialized
INFO - 2022-06-14 10:34:14 --> Config Class Initialized
INFO - 2022-06-14 10:34:14 --> Loader Class Initialized
INFO - 2022-06-14 10:34:14 --> Helper loaded: url_helper
INFO - 2022-06-14 10:34:14 --> Helper loaded: file_helper
INFO - 2022-06-14 10:34:14 --> Helper loaded: form_helper
INFO - 2022-06-14 10:34:14 --> Helper loaded: my_helper
INFO - 2022-06-14 10:34:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:34:14 --> Controller Class Initialized
INFO - 2022-06-14 10:34:14 --> Final output sent to browser
DEBUG - 2022-06-14 10:34:14 --> Total execution time: 0.1159
INFO - 2022-06-14 10:34:28 --> Config Class Initialized
INFO - 2022-06-14 10:34:28 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:34:28 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:34:28 --> Utf8 Class Initialized
INFO - 2022-06-14 10:34:28 --> URI Class Initialized
INFO - 2022-06-14 10:34:28 --> Router Class Initialized
INFO - 2022-06-14 10:34:28 --> Output Class Initialized
INFO - 2022-06-14 10:34:28 --> Security Class Initialized
DEBUG - 2022-06-14 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:34:28 --> Input Class Initialized
INFO - 2022-06-14 10:34:28 --> Language Class Initialized
INFO - 2022-06-14 10:34:28 --> Language Class Initialized
INFO - 2022-06-14 10:34:28 --> Config Class Initialized
INFO - 2022-06-14 10:34:28 --> Loader Class Initialized
INFO - 2022-06-14 10:34:28 --> Helper loaded: url_helper
INFO - 2022-06-14 10:34:28 --> Helper loaded: file_helper
INFO - 2022-06-14 10:34:28 --> Helper loaded: form_helper
INFO - 2022-06-14 10:34:28 --> Helper loaded: my_helper
INFO - 2022-06-14 10:34:28 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:34:28 --> Controller Class Initialized
DEBUG - 2022-06-14 10:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-06-14 10:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:34:28 --> Final output sent to browser
DEBUG - 2022-06-14 10:34:28 --> Total execution time: 0.0512
INFO - 2022-06-14 10:34:47 --> Config Class Initialized
INFO - 2022-06-14 10:34:47 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:34:47 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:34:47 --> Utf8 Class Initialized
INFO - 2022-06-14 10:34:47 --> URI Class Initialized
INFO - 2022-06-14 10:34:47 --> Router Class Initialized
INFO - 2022-06-14 10:34:47 --> Output Class Initialized
INFO - 2022-06-14 10:34:47 --> Security Class Initialized
DEBUG - 2022-06-14 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:34:47 --> Input Class Initialized
INFO - 2022-06-14 10:34:47 --> Language Class Initialized
INFO - 2022-06-14 10:34:47 --> Language Class Initialized
INFO - 2022-06-14 10:34:47 --> Config Class Initialized
INFO - 2022-06-14 10:34:47 --> Loader Class Initialized
INFO - 2022-06-14 10:34:47 --> Helper loaded: url_helper
INFO - 2022-06-14 10:34:47 --> Helper loaded: file_helper
INFO - 2022-06-14 10:34:47 --> Helper loaded: form_helper
INFO - 2022-06-14 10:34:47 --> Helper loaded: my_helper
INFO - 2022-06-14 10:34:47 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:34:47 --> Controller Class Initialized
INFO - 2022-06-14 10:34:47 --> Final output sent to browser
DEBUG - 2022-06-14 10:34:47 --> Total execution time: 0.1270
INFO - 2022-06-14 10:34:50 --> Config Class Initialized
INFO - 2022-06-14 10:34:50 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:34:50 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:34:50 --> Utf8 Class Initialized
INFO - 2022-06-14 10:34:50 --> URI Class Initialized
INFO - 2022-06-14 10:34:50 --> Router Class Initialized
INFO - 2022-06-14 10:34:50 --> Output Class Initialized
INFO - 2022-06-14 10:34:50 --> Security Class Initialized
DEBUG - 2022-06-14 10:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:34:50 --> Input Class Initialized
INFO - 2022-06-14 10:34:50 --> Language Class Initialized
INFO - 2022-06-14 10:34:50 --> Language Class Initialized
INFO - 2022-06-14 10:34:50 --> Config Class Initialized
INFO - 2022-06-14 10:34:50 --> Loader Class Initialized
INFO - 2022-06-14 10:34:50 --> Helper loaded: url_helper
INFO - 2022-06-14 10:34:50 --> Helper loaded: file_helper
INFO - 2022-06-14 10:34:50 --> Helper loaded: form_helper
INFO - 2022-06-14 10:34:50 --> Helper loaded: my_helper
INFO - 2022-06-14 10:34:50 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:34:50 --> Controller Class Initialized
DEBUG - 2022-06-14 10:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 10:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:34:50 --> Final output sent to browser
DEBUG - 2022-06-14 10:34:50 --> Total execution time: 0.0384
INFO - 2022-06-14 10:34:56 --> Config Class Initialized
INFO - 2022-06-14 10:34:56 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:34:56 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:34:56 --> Utf8 Class Initialized
INFO - 2022-06-14 10:34:56 --> URI Class Initialized
INFO - 2022-06-14 10:34:56 --> Router Class Initialized
INFO - 2022-06-14 10:34:56 --> Output Class Initialized
INFO - 2022-06-14 10:34:56 --> Security Class Initialized
DEBUG - 2022-06-14 10:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:34:56 --> Input Class Initialized
INFO - 2022-06-14 10:34:56 --> Language Class Initialized
INFO - 2022-06-14 10:34:56 --> Language Class Initialized
INFO - 2022-06-14 10:34:56 --> Config Class Initialized
INFO - 2022-06-14 10:34:56 --> Loader Class Initialized
INFO - 2022-06-14 10:34:56 --> Helper loaded: url_helper
INFO - 2022-06-14 10:34:56 --> Helper loaded: file_helper
INFO - 2022-06-14 10:34:56 --> Helper loaded: form_helper
INFO - 2022-06-14 10:34:56 --> Helper loaded: my_helper
INFO - 2022-06-14 10:34:56 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:34:56 --> Controller Class Initialized
INFO - 2022-06-14 10:34:56 --> Final output sent to browser
DEBUG - 2022-06-14 10:34:56 --> Total execution time: 0.0430
INFO - 2022-06-14 10:37:31 --> Config Class Initialized
INFO - 2022-06-14 10:37:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:37:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:37:31 --> Utf8 Class Initialized
INFO - 2022-06-14 10:37:31 --> URI Class Initialized
INFO - 2022-06-14 10:37:31 --> Router Class Initialized
INFO - 2022-06-14 10:37:31 --> Output Class Initialized
INFO - 2022-06-14 10:37:31 --> Security Class Initialized
DEBUG - 2022-06-14 10:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:37:31 --> Input Class Initialized
INFO - 2022-06-14 10:37:31 --> Language Class Initialized
INFO - 2022-06-14 10:37:31 --> Language Class Initialized
INFO - 2022-06-14 10:37:31 --> Config Class Initialized
INFO - 2022-06-14 10:37:31 --> Loader Class Initialized
INFO - 2022-06-14 10:37:31 --> Helper loaded: url_helper
INFO - 2022-06-14 10:37:31 --> Helper loaded: file_helper
INFO - 2022-06-14 10:37:31 --> Helper loaded: form_helper
INFO - 2022-06-14 10:37:31 --> Helper loaded: my_helper
INFO - 2022-06-14 10:37:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:37:31 --> Controller Class Initialized
DEBUG - 2022-06-14 10:37:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 10:37:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:37:31 --> Final output sent to browser
DEBUG - 2022-06-14 10:37:31 --> Total execution time: 0.0665
INFO - 2022-06-14 10:37:31 --> Config Class Initialized
INFO - 2022-06-14 10:37:31 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:37:31 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:37:31 --> Utf8 Class Initialized
INFO - 2022-06-14 10:37:31 --> URI Class Initialized
INFO - 2022-06-14 10:37:31 --> Router Class Initialized
INFO - 2022-06-14 10:37:31 --> Output Class Initialized
INFO - 2022-06-14 10:37:31 --> Security Class Initialized
DEBUG - 2022-06-14 10:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:37:31 --> Input Class Initialized
INFO - 2022-06-14 10:37:31 --> Language Class Initialized
INFO - 2022-06-14 10:37:31 --> Language Class Initialized
INFO - 2022-06-14 10:37:31 --> Config Class Initialized
INFO - 2022-06-14 10:37:31 --> Loader Class Initialized
INFO - 2022-06-14 10:37:31 --> Helper loaded: url_helper
INFO - 2022-06-14 10:37:31 --> Helper loaded: file_helper
INFO - 2022-06-14 10:37:31 --> Helper loaded: form_helper
INFO - 2022-06-14 10:37:31 --> Helper loaded: my_helper
INFO - 2022-06-14 10:37:31 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:37:31 --> Controller Class Initialized
INFO - 2022-06-14 10:37:31 --> Final output sent to browser
DEBUG - 2022-06-14 10:37:31 --> Total execution time: 0.0877
INFO - 2022-06-14 10:38:27 --> Config Class Initialized
INFO - 2022-06-14 10:38:27 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:38:27 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:38:27 --> Utf8 Class Initialized
INFO - 2022-06-14 10:38:27 --> URI Class Initialized
INFO - 2022-06-14 10:38:27 --> Router Class Initialized
INFO - 2022-06-14 10:38:27 --> Output Class Initialized
INFO - 2022-06-14 10:38:27 --> Security Class Initialized
DEBUG - 2022-06-14 10:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:38:27 --> Input Class Initialized
INFO - 2022-06-14 10:38:27 --> Language Class Initialized
INFO - 2022-06-14 10:38:27 --> Language Class Initialized
INFO - 2022-06-14 10:38:27 --> Config Class Initialized
INFO - 2022-06-14 10:38:27 --> Loader Class Initialized
INFO - 2022-06-14 10:38:27 --> Helper loaded: url_helper
INFO - 2022-06-14 10:38:27 --> Helper loaded: file_helper
INFO - 2022-06-14 10:38:27 --> Helper loaded: form_helper
INFO - 2022-06-14 10:38:27 --> Helper loaded: my_helper
INFO - 2022-06-14 10:38:27 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:38:27 --> Controller Class Initialized
DEBUG - 2022-06-14 10:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 10:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:38:27 --> Final output sent to browser
DEBUG - 2022-06-14 10:38:27 --> Total execution time: 0.0490
INFO - 2022-06-14 10:38:32 --> Config Class Initialized
INFO - 2022-06-14 10:38:32 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:38:32 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:38:32 --> Utf8 Class Initialized
INFO - 2022-06-14 10:38:32 --> URI Class Initialized
INFO - 2022-06-14 10:38:32 --> Router Class Initialized
INFO - 2022-06-14 10:38:32 --> Output Class Initialized
INFO - 2022-06-14 10:38:32 --> Security Class Initialized
DEBUG - 2022-06-14 10:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:38:32 --> Input Class Initialized
INFO - 2022-06-14 10:38:32 --> Language Class Initialized
INFO - 2022-06-14 10:38:32 --> Language Class Initialized
INFO - 2022-06-14 10:38:32 --> Config Class Initialized
INFO - 2022-06-14 10:38:32 --> Loader Class Initialized
INFO - 2022-06-14 10:38:32 --> Helper loaded: url_helper
INFO - 2022-06-14 10:38:32 --> Helper loaded: file_helper
INFO - 2022-06-14 10:38:32 --> Helper loaded: form_helper
INFO - 2022-06-14 10:38:32 --> Helper loaded: my_helper
INFO - 2022-06-14 10:38:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:38:33 --> Controller Class Initialized
DEBUG - 2022-06-14 10:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-14 10:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:38:33 --> Final output sent to browser
DEBUG - 2022-06-14 10:38:33 --> Total execution time: 0.0569
INFO - 2022-06-14 10:38:33 --> Config Class Initialized
INFO - 2022-06-14 10:38:33 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:38:33 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:38:33 --> Utf8 Class Initialized
INFO - 2022-06-14 10:38:33 --> URI Class Initialized
INFO - 2022-06-14 10:38:33 --> Router Class Initialized
INFO - 2022-06-14 10:38:33 --> Output Class Initialized
INFO - 2022-06-14 10:38:33 --> Security Class Initialized
DEBUG - 2022-06-14 10:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:38:33 --> Input Class Initialized
INFO - 2022-06-14 10:38:33 --> Language Class Initialized
INFO - 2022-06-14 10:38:33 --> Language Class Initialized
INFO - 2022-06-14 10:38:33 --> Config Class Initialized
INFO - 2022-06-14 10:38:33 --> Loader Class Initialized
INFO - 2022-06-14 10:38:33 --> Helper loaded: url_helper
INFO - 2022-06-14 10:38:33 --> Helper loaded: file_helper
INFO - 2022-06-14 10:38:33 --> Helper loaded: form_helper
INFO - 2022-06-14 10:38:33 --> Helper loaded: my_helper
INFO - 2022-06-14 10:38:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:38:33 --> Controller Class Initialized
INFO - 2022-06-14 10:38:38 --> Config Class Initialized
INFO - 2022-06-14 10:38:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:38:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:38:38 --> Utf8 Class Initialized
INFO - 2022-06-14 10:38:38 --> URI Class Initialized
INFO - 2022-06-14 10:38:38 --> Router Class Initialized
INFO - 2022-06-14 10:38:38 --> Output Class Initialized
INFO - 2022-06-14 10:38:38 --> Security Class Initialized
DEBUG - 2022-06-14 10:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:38:38 --> Input Class Initialized
INFO - 2022-06-14 10:38:38 --> Language Class Initialized
INFO - 2022-06-14 10:38:38 --> Language Class Initialized
INFO - 2022-06-14 10:38:38 --> Config Class Initialized
INFO - 2022-06-14 10:38:38 --> Loader Class Initialized
INFO - 2022-06-14 10:38:38 --> Helper loaded: url_helper
INFO - 2022-06-14 10:38:38 --> Helper loaded: file_helper
INFO - 2022-06-14 10:38:38 --> Helper loaded: form_helper
INFO - 2022-06-14 10:38:38 --> Helper loaded: my_helper
INFO - 2022-06-14 10:38:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:38:38 --> Controller Class Initialized
INFO - 2022-06-14 10:38:38 --> Final output sent to browser
DEBUG - 2022-06-14 10:38:38 --> Total execution time: 0.0460
INFO - 2022-06-14 10:38:57 --> Config Class Initialized
INFO - 2022-06-14 10:38:57 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:38:57 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:38:57 --> Utf8 Class Initialized
INFO - 2022-06-14 10:38:57 --> URI Class Initialized
INFO - 2022-06-14 10:38:57 --> Router Class Initialized
INFO - 2022-06-14 10:38:57 --> Output Class Initialized
INFO - 2022-06-14 10:38:57 --> Security Class Initialized
DEBUG - 2022-06-14 10:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:38:57 --> Input Class Initialized
INFO - 2022-06-14 10:38:57 --> Language Class Initialized
INFO - 2022-06-14 10:38:57 --> Language Class Initialized
INFO - 2022-06-14 10:38:57 --> Config Class Initialized
INFO - 2022-06-14 10:38:57 --> Loader Class Initialized
INFO - 2022-06-14 10:38:57 --> Helper loaded: url_helper
INFO - 2022-06-14 10:38:57 --> Helper loaded: file_helper
INFO - 2022-06-14 10:38:57 --> Helper loaded: form_helper
INFO - 2022-06-14 10:38:57 --> Helper loaded: my_helper
INFO - 2022-06-14 10:38:57 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:38:57 --> Controller Class Initialized
DEBUG - 2022-06-14 10:38:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 10:38:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:38:57 --> Final output sent to browser
DEBUG - 2022-06-14 10:38:57 --> Total execution time: 0.0493
INFO - 2022-06-14 10:39:04 --> Config Class Initialized
INFO - 2022-06-14 10:39:04 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:39:04 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:39:04 --> Utf8 Class Initialized
INFO - 2022-06-14 10:39:04 --> URI Class Initialized
INFO - 2022-06-14 10:39:04 --> Router Class Initialized
INFO - 2022-06-14 10:39:04 --> Output Class Initialized
INFO - 2022-06-14 10:39:04 --> Security Class Initialized
DEBUG - 2022-06-14 10:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:39:04 --> Input Class Initialized
INFO - 2022-06-14 10:39:04 --> Language Class Initialized
INFO - 2022-06-14 10:39:04 --> Language Class Initialized
INFO - 2022-06-14 10:39:04 --> Config Class Initialized
INFO - 2022-06-14 10:39:04 --> Loader Class Initialized
INFO - 2022-06-14 10:39:04 --> Helper loaded: url_helper
INFO - 2022-06-14 10:39:04 --> Helper loaded: file_helper
INFO - 2022-06-14 10:39:04 --> Helper loaded: form_helper
INFO - 2022-06-14 10:39:04 --> Helper loaded: my_helper
INFO - 2022-06-14 10:39:04 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:39:04 --> Controller Class Initialized
DEBUG - 2022-06-14 10:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 10:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:39:04 --> Final output sent to browser
DEBUG - 2022-06-14 10:39:04 --> Total execution time: 0.0519
INFO - 2022-06-14 10:40:33 --> Config Class Initialized
INFO - 2022-06-14 10:40:33 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:40:33 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:40:33 --> Utf8 Class Initialized
INFO - 2022-06-14 10:40:33 --> URI Class Initialized
INFO - 2022-06-14 10:40:33 --> Router Class Initialized
INFO - 2022-06-14 10:40:33 --> Output Class Initialized
INFO - 2022-06-14 10:40:33 --> Security Class Initialized
DEBUG - 2022-06-14 10:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:40:33 --> Input Class Initialized
INFO - 2022-06-14 10:40:33 --> Language Class Initialized
INFO - 2022-06-14 10:40:33 --> Language Class Initialized
INFO - 2022-06-14 10:40:33 --> Config Class Initialized
INFO - 2022-06-14 10:40:33 --> Loader Class Initialized
INFO - 2022-06-14 10:40:33 --> Helper loaded: url_helper
INFO - 2022-06-14 10:40:33 --> Helper loaded: file_helper
INFO - 2022-06-14 10:40:33 --> Helper loaded: form_helper
INFO - 2022-06-14 10:40:33 --> Helper loaded: my_helper
INFO - 2022-06-14 10:40:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:40:33 --> Controller Class Initialized
INFO - 2022-06-14 10:40:33 --> Final output sent to browser
DEBUG - 2022-06-14 10:40:33 --> Total execution time: 0.1142
INFO - 2022-06-14 10:40:40 --> Config Class Initialized
INFO - 2022-06-14 10:40:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:40:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:40:40 --> Utf8 Class Initialized
INFO - 2022-06-14 10:40:40 --> URI Class Initialized
INFO - 2022-06-14 10:40:40 --> Router Class Initialized
INFO - 2022-06-14 10:40:40 --> Output Class Initialized
INFO - 2022-06-14 10:40:40 --> Security Class Initialized
DEBUG - 2022-06-14 10:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:40:40 --> Input Class Initialized
INFO - 2022-06-14 10:40:40 --> Language Class Initialized
INFO - 2022-06-14 10:40:40 --> Language Class Initialized
INFO - 2022-06-14 10:40:40 --> Config Class Initialized
INFO - 2022-06-14 10:40:40 --> Loader Class Initialized
INFO - 2022-06-14 10:40:40 --> Helper loaded: url_helper
INFO - 2022-06-14 10:40:40 --> Helper loaded: file_helper
INFO - 2022-06-14 10:40:40 --> Helper loaded: form_helper
INFO - 2022-06-14 10:40:40 --> Helper loaded: my_helper
INFO - 2022-06-14 10:40:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:40:40 --> Controller Class Initialized
INFO - 2022-06-14 10:40:40 --> Final output sent to browser
DEBUG - 2022-06-14 10:40:40 --> Total execution time: 0.0729
INFO - 2022-06-14 10:40:56 --> Config Class Initialized
INFO - 2022-06-14 10:40:56 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:40:56 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:40:56 --> Utf8 Class Initialized
INFO - 2022-06-14 10:40:56 --> URI Class Initialized
INFO - 2022-06-14 10:40:56 --> Router Class Initialized
INFO - 2022-06-14 10:40:56 --> Output Class Initialized
INFO - 2022-06-14 10:40:56 --> Security Class Initialized
DEBUG - 2022-06-14 10:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:40:56 --> Input Class Initialized
INFO - 2022-06-14 10:40:56 --> Language Class Initialized
INFO - 2022-06-14 10:40:56 --> Language Class Initialized
INFO - 2022-06-14 10:40:56 --> Config Class Initialized
INFO - 2022-06-14 10:40:56 --> Loader Class Initialized
INFO - 2022-06-14 10:40:56 --> Helper loaded: url_helper
INFO - 2022-06-14 10:40:56 --> Helper loaded: file_helper
INFO - 2022-06-14 10:40:56 --> Helper loaded: form_helper
INFO - 2022-06-14 10:40:56 --> Helper loaded: my_helper
INFO - 2022-06-14 10:40:56 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:40:56 --> Controller Class Initialized
INFO - 2022-06-14 10:40:56 --> Final output sent to browser
DEBUG - 2022-06-14 10:40:56 --> Total execution time: 0.1055
INFO - 2022-06-14 10:41:05 --> Config Class Initialized
INFO - 2022-06-14 10:41:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:05 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:05 --> URI Class Initialized
INFO - 2022-06-14 10:41:05 --> Router Class Initialized
INFO - 2022-06-14 10:41:05 --> Output Class Initialized
INFO - 2022-06-14 10:41:05 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:05 --> Input Class Initialized
INFO - 2022-06-14 10:41:05 --> Language Class Initialized
INFO - 2022-06-14 10:41:05 --> Language Class Initialized
INFO - 2022-06-14 10:41:05 --> Config Class Initialized
INFO - 2022-06-14 10:41:05 --> Loader Class Initialized
INFO - 2022-06-14 10:41:05 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:05 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:05 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:05 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:05 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 10:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:05 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:05 --> Total execution time: 0.0552
INFO - 2022-06-14 10:41:08 --> Config Class Initialized
INFO - 2022-06-14 10:41:08 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:08 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:08 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:08 --> URI Class Initialized
INFO - 2022-06-14 10:41:08 --> Router Class Initialized
INFO - 2022-06-14 10:41:08 --> Output Class Initialized
INFO - 2022-06-14 10:41:08 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:08 --> Input Class Initialized
INFO - 2022-06-14 10:41:08 --> Language Class Initialized
INFO - 2022-06-14 10:41:08 --> Language Class Initialized
INFO - 2022-06-14 10:41:08 --> Config Class Initialized
INFO - 2022-06-14 10:41:08 --> Loader Class Initialized
INFO - 2022-06-14 10:41:08 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:08 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:08 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:08 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:08 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:08 --> Controller Class Initialized
INFO - 2022-06-14 10:41:08 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:08 --> Total execution time: 0.0964
INFO - 2022-06-14 10:41:11 --> Config Class Initialized
INFO - 2022-06-14 10:41:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:11 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:11 --> URI Class Initialized
INFO - 2022-06-14 10:41:11 --> Router Class Initialized
INFO - 2022-06-14 10:41:11 --> Output Class Initialized
INFO - 2022-06-14 10:41:11 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:11 --> Input Class Initialized
INFO - 2022-06-14 10:41:11 --> Language Class Initialized
INFO - 2022-06-14 10:41:11 --> Language Class Initialized
INFO - 2022-06-14 10:41:11 --> Config Class Initialized
INFO - 2022-06-14 10:41:11 --> Loader Class Initialized
INFO - 2022-06-14 10:41:11 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:11 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:11 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:11 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:11 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:11 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:11 --> Total execution time: 0.0468
INFO - 2022-06-14 10:41:11 --> Config Class Initialized
INFO - 2022-06-14 10:41:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:11 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:11 --> URI Class Initialized
INFO - 2022-06-14 10:41:11 --> Router Class Initialized
INFO - 2022-06-14 10:41:11 --> Output Class Initialized
INFO - 2022-06-14 10:41:11 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:11 --> Input Class Initialized
INFO - 2022-06-14 10:41:11 --> Language Class Initialized
INFO - 2022-06-14 10:41:11 --> Language Class Initialized
INFO - 2022-06-14 10:41:11 --> Config Class Initialized
INFO - 2022-06-14 10:41:11 --> Loader Class Initialized
INFO - 2022-06-14 10:41:11 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:11 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:11 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:11 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:11 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-06-14 10:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:11 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:11 --> Total execution time: 0.2208
INFO - 2022-06-14 10:41:13 --> Config Class Initialized
INFO - 2022-06-14 10:41:13 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:13 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:13 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:13 --> URI Class Initialized
INFO - 2022-06-14 10:41:13 --> Router Class Initialized
INFO - 2022-06-14 10:41:13 --> Output Class Initialized
INFO - 2022-06-14 10:41:13 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:13 --> Input Class Initialized
INFO - 2022-06-14 10:41:13 --> Language Class Initialized
INFO - 2022-06-14 10:41:13 --> Language Class Initialized
INFO - 2022-06-14 10:41:13 --> Config Class Initialized
INFO - 2022-06-14 10:41:13 --> Loader Class Initialized
INFO - 2022-06-14 10:41:13 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:13 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:13 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:13 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:13 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:13 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-06-14 10:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:13 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:13 --> Total execution time: 0.3456
INFO - 2022-06-14 10:41:21 --> Config Class Initialized
INFO - 2022-06-14 10:41:21 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:21 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:21 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:21 --> URI Class Initialized
INFO - 2022-06-14 10:41:21 --> Router Class Initialized
INFO - 2022-06-14 10:41:21 --> Output Class Initialized
INFO - 2022-06-14 10:41:21 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:21 --> Input Class Initialized
INFO - 2022-06-14 10:41:21 --> Language Class Initialized
INFO - 2022-06-14 10:41:22 --> Language Class Initialized
INFO - 2022-06-14 10:41:22 --> Config Class Initialized
INFO - 2022-06-14 10:41:22 --> Loader Class Initialized
INFO - 2022-06-14 10:41:22 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:22 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:22 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:22 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:22 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:22 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-06-14 10:41:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:22 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:22 --> Total execution time: 0.3039
INFO - 2022-06-14 10:41:22 --> Config Class Initialized
INFO - 2022-06-14 10:41:22 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:22 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:22 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:22 --> URI Class Initialized
INFO - 2022-06-14 10:41:22 --> Router Class Initialized
INFO - 2022-06-14 10:41:22 --> Output Class Initialized
INFO - 2022-06-14 10:41:22 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:22 --> Input Class Initialized
INFO - 2022-06-14 10:41:22 --> Language Class Initialized
INFO - 2022-06-14 10:41:22 --> Language Class Initialized
INFO - 2022-06-14 10:41:22 --> Config Class Initialized
INFO - 2022-06-14 10:41:22 --> Loader Class Initialized
INFO - 2022-06-14 10:41:22 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:22 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:22 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:22 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:22 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:22 --> Controller Class Initialized
INFO - 2022-06-14 10:41:23 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:23 --> Total execution time: 1.2777
INFO - 2022-06-14 10:41:38 --> Config Class Initialized
INFO - 2022-06-14 10:41:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:38 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:38 --> URI Class Initialized
INFO - 2022-06-14 10:41:38 --> Router Class Initialized
INFO - 2022-06-14 10:41:38 --> Output Class Initialized
INFO - 2022-06-14 10:41:38 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:38 --> Input Class Initialized
INFO - 2022-06-14 10:41:38 --> Language Class Initialized
INFO - 2022-06-14 10:41:38 --> Language Class Initialized
INFO - 2022-06-14 10:41:38 --> Config Class Initialized
INFO - 2022-06-14 10:41:38 --> Loader Class Initialized
INFO - 2022-06-14 10:41:38 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:38 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:38 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:38 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:38 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 10:41:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:38 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:38 --> Total execution time: 0.0503
INFO - 2022-06-14 10:41:41 --> Config Class Initialized
INFO - 2022-06-14 10:41:41 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:41 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:41 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:41 --> URI Class Initialized
DEBUG - 2022-06-14 10:41:41 --> No URI present. Default controller set.
INFO - 2022-06-14 10:41:41 --> Router Class Initialized
INFO - 2022-06-14 10:41:41 --> Output Class Initialized
INFO - 2022-06-14 10:41:41 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:41 --> Input Class Initialized
INFO - 2022-06-14 10:41:41 --> Language Class Initialized
INFO - 2022-06-14 10:41:41 --> Language Class Initialized
INFO - 2022-06-14 10:41:41 --> Config Class Initialized
INFO - 2022-06-14 10:41:41 --> Loader Class Initialized
INFO - 2022-06-14 10:41:41 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:41 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:41 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:41 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:41 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:41 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 10:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:41 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:41 --> Total execution time: 0.0586
INFO - 2022-06-14 10:41:47 --> Config Class Initialized
INFO - 2022-06-14 10:41:47 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:47 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:47 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:47 --> URI Class Initialized
INFO - 2022-06-14 10:41:47 --> Router Class Initialized
INFO - 2022-06-14 10:41:47 --> Output Class Initialized
INFO - 2022-06-14 10:41:47 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:47 --> Input Class Initialized
INFO - 2022-06-14 10:41:47 --> Language Class Initialized
INFO - 2022-06-14 10:41:47 --> Language Class Initialized
INFO - 2022-06-14 10:41:47 --> Config Class Initialized
INFO - 2022-06-14 10:41:47 --> Loader Class Initialized
INFO - 2022-06-14 10:41:47 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:47 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:47 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:47 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:47 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:47 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-06-14 10:41:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:47 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:47 --> Total execution time: 0.0480
INFO - 2022-06-14 10:41:49 --> Config Class Initialized
INFO - 2022-06-14 10:41:49 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:41:49 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:41:49 --> Utf8 Class Initialized
INFO - 2022-06-14 10:41:49 --> URI Class Initialized
INFO - 2022-06-14 10:41:49 --> Router Class Initialized
INFO - 2022-06-14 10:41:49 --> Output Class Initialized
INFO - 2022-06-14 10:41:49 --> Security Class Initialized
DEBUG - 2022-06-14 10:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:41:49 --> Input Class Initialized
INFO - 2022-06-14 10:41:49 --> Language Class Initialized
INFO - 2022-06-14 10:41:49 --> Language Class Initialized
INFO - 2022-06-14 10:41:49 --> Config Class Initialized
INFO - 2022-06-14 10:41:49 --> Loader Class Initialized
INFO - 2022-06-14 10:41:49 --> Helper loaded: url_helper
INFO - 2022-06-14 10:41:49 --> Helper loaded: file_helper
INFO - 2022-06-14 10:41:49 --> Helper loaded: form_helper
INFO - 2022-06-14 10:41:49 --> Helper loaded: my_helper
INFO - 2022-06-14 10:41:49 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:41:49 --> Controller Class Initialized
DEBUG - 2022-06-14 10:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-14 10:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:41:49 --> Final output sent to browser
DEBUG - 2022-06-14 10:41:49 --> Total execution time: 0.0533
INFO - 2022-06-14 10:42:03 --> Config Class Initialized
INFO - 2022-06-14 10:42:03 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:03 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:03 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:03 --> URI Class Initialized
INFO - 2022-06-14 10:42:03 --> Router Class Initialized
INFO - 2022-06-14 10:42:03 --> Output Class Initialized
INFO - 2022-06-14 10:42:03 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:03 --> Input Class Initialized
INFO - 2022-06-14 10:42:03 --> Language Class Initialized
INFO - 2022-06-14 10:42:03 --> Language Class Initialized
INFO - 2022-06-14 10:42:03 --> Config Class Initialized
INFO - 2022-06-14 10:42:03 --> Loader Class Initialized
INFO - 2022-06-14 10:42:03 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:03 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:03 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:03 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:03 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:03 --> Controller Class Initialized
INFO - 2022-06-14 10:42:03 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:42:03 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:03 --> Total execution time: 0.0442
INFO - 2022-06-14 10:42:03 --> Config Class Initialized
INFO - 2022-06-14 10:42:03 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:03 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:03 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:03 --> URI Class Initialized
INFO - 2022-06-14 10:42:03 --> Router Class Initialized
INFO - 2022-06-14 10:42:03 --> Output Class Initialized
INFO - 2022-06-14 10:42:03 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:03 --> Input Class Initialized
INFO - 2022-06-14 10:42:03 --> Language Class Initialized
INFO - 2022-06-14 10:42:03 --> Language Class Initialized
INFO - 2022-06-14 10:42:03 --> Config Class Initialized
INFO - 2022-06-14 10:42:03 --> Loader Class Initialized
INFO - 2022-06-14 10:42:03 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:03 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:03 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:03 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:03 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:03 --> Controller Class Initialized
DEBUG - 2022-06-14 10:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 10:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:42:03 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:03 --> Total execution time: 0.0554
INFO - 2022-06-14 10:42:04 --> Config Class Initialized
INFO - 2022-06-14 10:42:04 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:04 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:04 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:04 --> URI Class Initialized
INFO - 2022-06-14 10:42:04 --> Router Class Initialized
INFO - 2022-06-14 10:42:04 --> Output Class Initialized
INFO - 2022-06-14 10:42:04 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:04 --> Input Class Initialized
INFO - 2022-06-14 10:42:04 --> Language Class Initialized
INFO - 2022-06-14 10:42:04 --> Language Class Initialized
INFO - 2022-06-14 10:42:04 --> Config Class Initialized
INFO - 2022-06-14 10:42:04 --> Loader Class Initialized
INFO - 2022-06-14 10:42:04 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:04 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:04 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:04 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:04 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:04 --> Controller Class Initialized
DEBUG - 2022-06-14 10:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 10:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:42:04 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:04 --> Total execution time: 0.0687
INFO - 2022-06-14 10:42:06 --> Config Class Initialized
INFO - 2022-06-14 10:42:06 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:06 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:06 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:06 --> URI Class Initialized
INFO - 2022-06-14 10:42:06 --> Router Class Initialized
INFO - 2022-06-14 10:42:06 --> Output Class Initialized
INFO - 2022-06-14 10:42:06 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:06 --> Input Class Initialized
INFO - 2022-06-14 10:42:06 --> Language Class Initialized
INFO - 2022-06-14 10:42:06 --> Language Class Initialized
INFO - 2022-06-14 10:42:06 --> Config Class Initialized
INFO - 2022-06-14 10:42:06 --> Loader Class Initialized
INFO - 2022-06-14 10:42:06 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:06 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:06 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:06 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:06 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:06 --> Controller Class Initialized
DEBUG - 2022-06-14 10:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:42:06 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:06 --> Total execution time: 0.0450
INFO - 2022-06-14 10:42:11 --> Config Class Initialized
INFO - 2022-06-14 10:42:11 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:11 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:11 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:11 --> URI Class Initialized
INFO - 2022-06-14 10:42:11 --> Router Class Initialized
INFO - 2022-06-14 10:42:11 --> Output Class Initialized
INFO - 2022-06-14 10:42:11 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:11 --> Input Class Initialized
INFO - 2022-06-14 10:42:11 --> Language Class Initialized
INFO - 2022-06-14 10:42:11 --> Language Class Initialized
INFO - 2022-06-14 10:42:11 --> Config Class Initialized
INFO - 2022-06-14 10:42:11 --> Loader Class Initialized
INFO - 2022-06-14 10:42:11 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:11 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:11 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:11 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:11 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:11 --> Controller Class Initialized
INFO - 2022-06-14 10:42:11 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:11 --> Total execution time: 0.1702
INFO - 2022-06-14 10:42:17 --> Config Class Initialized
INFO - 2022-06-14 10:42:17 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:17 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:17 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:17 --> URI Class Initialized
INFO - 2022-06-14 10:42:17 --> Router Class Initialized
INFO - 2022-06-14 10:42:17 --> Output Class Initialized
INFO - 2022-06-14 10:42:17 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:17 --> Input Class Initialized
INFO - 2022-06-14 10:42:17 --> Language Class Initialized
INFO - 2022-06-14 10:42:17 --> Language Class Initialized
INFO - 2022-06-14 10:42:17 --> Config Class Initialized
INFO - 2022-06-14 10:42:17 --> Loader Class Initialized
INFO - 2022-06-14 10:42:17 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:17 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:17 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:17 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:17 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:17 --> Controller Class Initialized
DEBUG - 2022-06-14 10:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:42:17 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:17 --> Total execution time: 0.0521
INFO - 2022-06-14 10:42:21 --> Config Class Initialized
INFO - 2022-06-14 10:42:21 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:21 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:21 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:21 --> URI Class Initialized
INFO - 2022-06-14 10:42:21 --> Router Class Initialized
INFO - 2022-06-14 10:42:21 --> Output Class Initialized
INFO - 2022-06-14 10:42:21 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:21 --> Input Class Initialized
INFO - 2022-06-14 10:42:21 --> Language Class Initialized
INFO - 2022-06-14 10:42:21 --> Language Class Initialized
INFO - 2022-06-14 10:42:21 --> Config Class Initialized
INFO - 2022-06-14 10:42:21 --> Loader Class Initialized
INFO - 2022-06-14 10:42:21 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:21 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:21 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:21 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:21 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:21 --> Controller Class Initialized
DEBUG - 2022-06-14 10:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 10:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:42:21 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:21 --> Total execution time: 0.0507
INFO - 2022-06-14 10:42:24 --> Config Class Initialized
INFO - 2022-06-14 10:42:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:24 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:24 --> URI Class Initialized
INFO - 2022-06-14 10:42:24 --> Router Class Initialized
INFO - 2022-06-14 10:42:24 --> Output Class Initialized
INFO - 2022-06-14 10:42:24 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:24 --> Input Class Initialized
INFO - 2022-06-14 10:42:24 --> Language Class Initialized
INFO - 2022-06-14 10:42:24 --> Language Class Initialized
INFO - 2022-06-14 10:42:24 --> Config Class Initialized
INFO - 2022-06-14 10:42:24 --> Loader Class Initialized
INFO - 2022-06-14 10:42:24 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:24 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:24 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:24 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:24 --> Controller Class Initialized
INFO - 2022-06-14 10:42:24 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:24 --> Total execution time: 0.0544
INFO - 2022-06-14 10:42:38 --> Config Class Initialized
INFO - 2022-06-14 10:42:38 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:38 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:38 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:38 --> URI Class Initialized
INFO - 2022-06-14 10:42:38 --> Router Class Initialized
INFO - 2022-06-14 10:42:38 --> Output Class Initialized
INFO - 2022-06-14 10:42:38 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:38 --> Input Class Initialized
INFO - 2022-06-14 10:42:38 --> Language Class Initialized
INFO - 2022-06-14 10:42:38 --> Language Class Initialized
INFO - 2022-06-14 10:42:38 --> Config Class Initialized
INFO - 2022-06-14 10:42:38 --> Loader Class Initialized
INFO - 2022-06-14 10:42:38 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:38 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:38 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:38 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:38 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:38 --> Controller Class Initialized
INFO - 2022-06-14 10:42:38 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:38 --> Total execution time: 0.1040
INFO - 2022-06-14 10:42:46 --> Config Class Initialized
INFO - 2022-06-14 10:42:46 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:42:46 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:42:46 --> Utf8 Class Initialized
INFO - 2022-06-14 10:42:46 --> URI Class Initialized
DEBUG - 2022-06-14 10:42:46 --> No URI present. Default controller set.
INFO - 2022-06-14 10:42:46 --> Router Class Initialized
INFO - 2022-06-14 10:42:46 --> Output Class Initialized
INFO - 2022-06-14 10:42:46 --> Security Class Initialized
DEBUG - 2022-06-14 10:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:42:46 --> Input Class Initialized
INFO - 2022-06-14 10:42:46 --> Language Class Initialized
INFO - 2022-06-14 10:42:46 --> Language Class Initialized
INFO - 2022-06-14 10:42:46 --> Config Class Initialized
INFO - 2022-06-14 10:42:46 --> Loader Class Initialized
INFO - 2022-06-14 10:42:46 --> Helper loaded: url_helper
INFO - 2022-06-14 10:42:46 --> Helper loaded: file_helper
INFO - 2022-06-14 10:42:46 --> Helper loaded: form_helper
INFO - 2022-06-14 10:42:46 --> Helper loaded: my_helper
INFO - 2022-06-14 10:42:46 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:42:46 --> Controller Class Initialized
DEBUG - 2022-06-14 10:42:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 10:42:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:42:46 --> Final output sent to browser
DEBUG - 2022-06-14 10:42:46 --> Total execution time: 0.0534
INFO - 2022-06-14 10:43:05 --> Config Class Initialized
INFO - 2022-06-14 10:43:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:43:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:43:05 --> Utf8 Class Initialized
INFO - 2022-06-14 10:43:05 --> URI Class Initialized
INFO - 2022-06-14 10:43:05 --> Router Class Initialized
INFO - 2022-06-14 10:43:05 --> Output Class Initialized
INFO - 2022-06-14 10:43:05 --> Security Class Initialized
DEBUG - 2022-06-14 10:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:43:05 --> Input Class Initialized
INFO - 2022-06-14 10:43:05 --> Language Class Initialized
INFO - 2022-06-14 10:43:05 --> Language Class Initialized
INFO - 2022-06-14 10:43:05 --> Config Class Initialized
INFO - 2022-06-14 10:43:05 --> Loader Class Initialized
INFO - 2022-06-14 10:43:05 --> Helper loaded: url_helper
INFO - 2022-06-14 10:43:05 --> Helper loaded: file_helper
INFO - 2022-06-14 10:43:05 --> Helper loaded: form_helper
INFO - 2022-06-14 10:43:05 --> Helper loaded: my_helper
INFO - 2022-06-14 10:43:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:43:05 --> Controller Class Initialized
INFO - 2022-06-14 10:43:05 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:43:05 --> Config Class Initialized
INFO - 2022-06-14 10:43:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:43:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:43:05 --> Utf8 Class Initialized
INFO - 2022-06-14 10:43:05 --> URI Class Initialized
INFO - 2022-06-14 10:43:05 --> Router Class Initialized
INFO - 2022-06-14 10:43:05 --> Output Class Initialized
INFO - 2022-06-14 10:43:05 --> Security Class Initialized
DEBUG - 2022-06-14 10:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:43:05 --> Input Class Initialized
INFO - 2022-06-14 10:43:05 --> Language Class Initialized
INFO - 2022-06-14 10:43:05 --> Language Class Initialized
INFO - 2022-06-14 10:43:05 --> Config Class Initialized
INFO - 2022-06-14 10:43:05 --> Loader Class Initialized
INFO - 2022-06-14 10:43:05 --> Helper loaded: url_helper
INFO - 2022-06-14 10:43:05 --> Helper loaded: file_helper
INFO - 2022-06-14 10:43:05 --> Helper loaded: form_helper
INFO - 2022-06-14 10:43:05 --> Helper loaded: my_helper
INFO - 2022-06-14 10:43:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:43:05 --> Controller Class Initialized
DEBUG - 2022-06-14 10:43:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:43:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:43:05 --> Final output sent to browser
DEBUG - 2022-06-14 10:43:05 --> Total execution time: 0.0393
INFO - 2022-06-14 10:46:24 --> Config Class Initialized
INFO - 2022-06-14 10:46:24 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:46:24 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:46:24 --> Utf8 Class Initialized
INFO - 2022-06-14 10:46:24 --> URI Class Initialized
INFO - 2022-06-14 10:46:24 --> Router Class Initialized
INFO - 2022-06-14 10:46:24 --> Output Class Initialized
INFO - 2022-06-14 10:46:24 --> Security Class Initialized
DEBUG - 2022-06-14 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:46:24 --> Input Class Initialized
INFO - 2022-06-14 10:46:24 --> Language Class Initialized
INFO - 2022-06-14 10:46:24 --> Language Class Initialized
INFO - 2022-06-14 10:46:24 --> Config Class Initialized
INFO - 2022-06-14 10:46:24 --> Loader Class Initialized
INFO - 2022-06-14 10:46:24 --> Helper loaded: url_helper
INFO - 2022-06-14 10:46:24 --> Helper loaded: file_helper
INFO - 2022-06-14 10:46:24 --> Helper loaded: form_helper
INFO - 2022-06-14 10:46:24 --> Helper loaded: my_helper
INFO - 2022-06-14 10:46:24 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:46:24 --> Controller Class Initialized
INFO - 2022-06-14 10:46:24 --> Final output sent to browser
DEBUG - 2022-06-14 10:46:24 --> Total execution time: 0.0962
INFO - 2022-06-14 10:46:27 --> Config Class Initialized
INFO - 2022-06-14 10:46:27 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:46:27 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:46:27 --> Utf8 Class Initialized
INFO - 2022-06-14 10:46:27 --> URI Class Initialized
INFO - 2022-06-14 10:46:27 --> Router Class Initialized
INFO - 2022-06-14 10:46:27 --> Output Class Initialized
INFO - 2022-06-14 10:46:27 --> Security Class Initialized
DEBUG - 2022-06-14 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:46:27 --> Input Class Initialized
INFO - 2022-06-14 10:46:27 --> Language Class Initialized
INFO - 2022-06-14 10:46:27 --> Language Class Initialized
INFO - 2022-06-14 10:46:27 --> Config Class Initialized
INFO - 2022-06-14 10:46:27 --> Loader Class Initialized
INFO - 2022-06-14 10:46:27 --> Helper loaded: url_helper
INFO - 2022-06-14 10:46:27 --> Helper loaded: file_helper
INFO - 2022-06-14 10:46:27 --> Helper loaded: form_helper
INFO - 2022-06-14 10:46:27 --> Helper loaded: my_helper
INFO - 2022-06-14 10:46:27 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:46:27 --> Controller Class Initialized
DEBUG - 2022-06-14 10:46:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:46:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:46:27 --> Final output sent to browser
DEBUG - 2022-06-14 10:46:27 --> Total execution time: 0.0458
INFO - 2022-06-14 10:50:30 --> Config Class Initialized
INFO - 2022-06-14 10:50:30 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:50:30 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:50:30 --> Utf8 Class Initialized
INFO - 2022-06-14 10:50:30 --> URI Class Initialized
INFO - 2022-06-14 10:50:30 --> Router Class Initialized
INFO - 2022-06-14 10:50:30 --> Output Class Initialized
INFO - 2022-06-14 10:50:30 --> Security Class Initialized
DEBUG - 2022-06-14 10:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:50:30 --> Input Class Initialized
INFO - 2022-06-14 10:50:30 --> Language Class Initialized
INFO - 2022-06-14 10:50:30 --> Language Class Initialized
INFO - 2022-06-14 10:50:30 --> Config Class Initialized
INFO - 2022-06-14 10:50:30 --> Loader Class Initialized
INFO - 2022-06-14 10:50:30 --> Helper loaded: url_helper
INFO - 2022-06-14 10:50:30 --> Helper loaded: file_helper
INFO - 2022-06-14 10:50:30 --> Helper loaded: form_helper
INFO - 2022-06-14 10:50:30 --> Helper loaded: my_helper
INFO - 2022-06-14 10:50:30 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:50:30 --> Controller Class Initialized
INFO - 2022-06-14 10:50:30 --> Final output sent to browser
DEBUG - 2022-06-14 10:50:30 --> Total execution time: 0.1175
INFO - 2022-06-14 10:50:33 --> Config Class Initialized
INFO - 2022-06-14 10:50:33 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:50:33 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:50:33 --> Utf8 Class Initialized
INFO - 2022-06-14 10:50:33 --> URI Class Initialized
INFO - 2022-06-14 10:50:33 --> Router Class Initialized
INFO - 2022-06-14 10:50:33 --> Output Class Initialized
INFO - 2022-06-14 10:50:33 --> Security Class Initialized
DEBUG - 2022-06-14 10:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:50:33 --> Input Class Initialized
INFO - 2022-06-14 10:50:33 --> Language Class Initialized
INFO - 2022-06-14 10:50:33 --> Language Class Initialized
INFO - 2022-06-14 10:50:33 --> Config Class Initialized
INFO - 2022-06-14 10:50:33 --> Loader Class Initialized
INFO - 2022-06-14 10:50:33 --> Helper loaded: url_helper
INFO - 2022-06-14 10:50:33 --> Helper loaded: file_helper
INFO - 2022-06-14 10:50:33 --> Helper loaded: form_helper
INFO - 2022-06-14 10:50:33 --> Helper loaded: my_helper
INFO - 2022-06-14 10:50:33 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:50:33 --> Controller Class Initialized
DEBUG - 2022-06-14 10:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:50:33 --> Final output sent to browser
DEBUG - 2022-06-14 10:50:33 --> Total execution time: 0.0437
INFO - 2022-06-14 10:50:58 --> Config Class Initialized
INFO - 2022-06-14 10:50:58 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:50:58 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:50:58 --> Utf8 Class Initialized
INFO - 2022-06-14 10:50:58 --> URI Class Initialized
INFO - 2022-06-14 10:50:58 --> Router Class Initialized
INFO - 2022-06-14 10:50:58 --> Output Class Initialized
INFO - 2022-06-14 10:50:58 --> Security Class Initialized
DEBUG - 2022-06-14 10:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:50:58 --> Input Class Initialized
INFO - 2022-06-14 10:50:58 --> Language Class Initialized
INFO - 2022-06-14 10:50:58 --> Language Class Initialized
INFO - 2022-06-14 10:50:58 --> Config Class Initialized
INFO - 2022-06-14 10:50:58 --> Loader Class Initialized
INFO - 2022-06-14 10:50:58 --> Helper loaded: url_helper
INFO - 2022-06-14 10:50:58 --> Helper loaded: file_helper
INFO - 2022-06-14 10:50:58 --> Helper loaded: form_helper
INFO - 2022-06-14 10:50:58 --> Helper loaded: my_helper
INFO - 2022-06-14 10:50:58 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:50:58 --> Controller Class Initialized
DEBUG - 2022-06-14 10:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:50:58 --> Final output sent to browser
DEBUG - 2022-06-14 10:50:58 --> Total execution time: 0.0459
INFO - 2022-06-14 10:50:59 --> Config Class Initialized
INFO - 2022-06-14 10:50:59 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:50:59 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:50:59 --> Utf8 Class Initialized
INFO - 2022-06-14 10:50:59 --> URI Class Initialized
INFO - 2022-06-14 10:50:59 --> Router Class Initialized
INFO - 2022-06-14 10:50:59 --> Output Class Initialized
INFO - 2022-06-14 10:50:59 --> Security Class Initialized
DEBUG - 2022-06-14 10:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:50:59 --> Input Class Initialized
INFO - 2022-06-14 10:50:59 --> Language Class Initialized
INFO - 2022-06-14 10:50:59 --> Language Class Initialized
INFO - 2022-06-14 10:50:59 --> Config Class Initialized
INFO - 2022-06-14 10:50:59 --> Loader Class Initialized
INFO - 2022-06-14 10:50:59 --> Helper loaded: url_helper
INFO - 2022-06-14 10:50:59 --> Helper loaded: file_helper
INFO - 2022-06-14 10:50:59 --> Helper loaded: form_helper
INFO - 2022-06-14 10:50:59 --> Helper loaded: my_helper
INFO - 2022-06-14 10:50:59 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:50:59 --> Controller Class Initialized
DEBUG - 2022-06-14 10:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-14 10:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:50:59 --> Final output sent to browser
DEBUG - 2022-06-14 10:50:59 --> Total execution time: 0.0495
INFO - 2022-06-14 10:51:00 --> Config Class Initialized
INFO - 2022-06-14 10:51:00 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:00 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:00 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:00 --> URI Class Initialized
INFO - 2022-06-14 10:51:00 --> Router Class Initialized
INFO - 2022-06-14 10:51:00 --> Output Class Initialized
INFO - 2022-06-14 10:51:00 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:00 --> Input Class Initialized
INFO - 2022-06-14 10:51:00 --> Language Class Initialized
INFO - 2022-06-14 10:51:00 --> Language Class Initialized
INFO - 2022-06-14 10:51:00 --> Config Class Initialized
INFO - 2022-06-14 10:51:00 --> Loader Class Initialized
INFO - 2022-06-14 10:51:00 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:00 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:00 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:00 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:00 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:00 --> Controller Class Initialized
INFO - 2022-06-14 10:51:00 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:00 --> Total execution time: 0.0387
INFO - 2022-06-14 10:51:02 --> Config Class Initialized
INFO - 2022-06-14 10:51:02 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:02 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:02 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:02 --> URI Class Initialized
INFO - 2022-06-14 10:51:02 --> Router Class Initialized
INFO - 2022-06-14 10:51:02 --> Output Class Initialized
INFO - 2022-06-14 10:51:02 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:02 --> Input Class Initialized
INFO - 2022-06-14 10:51:02 --> Language Class Initialized
INFO - 2022-06-14 10:51:02 --> Language Class Initialized
INFO - 2022-06-14 10:51:02 --> Config Class Initialized
INFO - 2022-06-14 10:51:02 --> Loader Class Initialized
INFO - 2022-06-14 10:51:02 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:02 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:02 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:02 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:02 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:02 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-06-14 10:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:02 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:02 --> Total execution time: 0.0452
INFO - 2022-06-14 10:51:03 --> Config Class Initialized
INFO - 2022-06-14 10:51:03 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:03 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:03 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:03 --> URI Class Initialized
INFO - 2022-06-14 10:51:03 --> Router Class Initialized
INFO - 2022-06-14 10:51:03 --> Output Class Initialized
INFO - 2022-06-14 10:51:03 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:03 --> Input Class Initialized
INFO - 2022-06-14 10:51:03 --> Language Class Initialized
INFO - 2022-06-14 10:51:03 --> Language Class Initialized
INFO - 2022-06-14 10:51:03 --> Config Class Initialized
INFO - 2022-06-14 10:51:03 --> Loader Class Initialized
INFO - 2022-06-14 10:51:03 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:03 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:03 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:03 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:03 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:03 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-06-14 10:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:03 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:03 --> Total execution time: 0.0957
INFO - 2022-06-14 10:51:05 --> Config Class Initialized
INFO - 2022-06-14 10:51:05 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:05 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:05 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:05 --> URI Class Initialized
INFO - 2022-06-14 10:51:05 --> Router Class Initialized
INFO - 2022-06-14 10:51:05 --> Output Class Initialized
INFO - 2022-06-14 10:51:05 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:05 --> Input Class Initialized
INFO - 2022-06-14 10:51:05 --> Language Class Initialized
INFO - 2022-06-14 10:51:05 --> Language Class Initialized
INFO - 2022-06-14 10:51:05 --> Config Class Initialized
INFO - 2022-06-14 10:51:05 --> Loader Class Initialized
INFO - 2022-06-14 10:51:05 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:05 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:05 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:05 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:05 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:05 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-06-14 10:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:05 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:05 --> Total execution time: 0.0403
INFO - 2022-06-14 10:51:06 --> Config Class Initialized
INFO - 2022-06-14 10:51:06 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:06 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:06 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:06 --> URI Class Initialized
INFO - 2022-06-14 10:51:06 --> Router Class Initialized
INFO - 2022-06-14 10:51:06 --> Output Class Initialized
INFO - 2022-06-14 10:51:06 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:06 --> Input Class Initialized
INFO - 2022-06-14 10:51:06 --> Language Class Initialized
INFO - 2022-06-14 10:51:06 --> Language Class Initialized
INFO - 2022-06-14 10:51:06 --> Config Class Initialized
INFO - 2022-06-14 10:51:06 --> Loader Class Initialized
INFO - 2022-06-14 10:51:06 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:06 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:06 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:06 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:06 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:06 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-06-14 10:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:06 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:06 --> Total execution time: 0.0829
INFO - 2022-06-14 10:51:09 --> Config Class Initialized
INFO - 2022-06-14 10:51:09 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:09 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:09 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:09 --> URI Class Initialized
INFO - 2022-06-14 10:51:09 --> Router Class Initialized
INFO - 2022-06-14 10:51:09 --> Output Class Initialized
INFO - 2022-06-14 10:51:09 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:09 --> Input Class Initialized
INFO - 2022-06-14 10:51:09 --> Language Class Initialized
INFO - 2022-06-14 10:51:09 --> Language Class Initialized
INFO - 2022-06-14 10:51:09 --> Config Class Initialized
INFO - 2022-06-14 10:51:09 --> Loader Class Initialized
INFO - 2022-06-14 10:51:09 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:09 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:09 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:09 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:09 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:09 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-06-14 10:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:09 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:09 --> Total execution time: 0.0644
INFO - 2022-06-14 10:51:10 --> Config Class Initialized
INFO - 2022-06-14 10:51:10 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:10 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:10 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:10 --> URI Class Initialized
INFO - 2022-06-14 10:51:10 --> Router Class Initialized
INFO - 2022-06-14 10:51:10 --> Output Class Initialized
INFO - 2022-06-14 10:51:10 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:10 --> Input Class Initialized
INFO - 2022-06-14 10:51:10 --> Language Class Initialized
INFO - 2022-06-14 10:51:10 --> Language Class Initialized
INFO - 2022-06-14 10:51:10 --> Config Class Initialized
INFO - 2022-06-14 10:51:10 --> Loader Class Initialized
INFO - 2022-06-14 10:51:10 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:10 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:10 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:10 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:10 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:10 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-14 10:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:10 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:10 --> Total execution time: 0.0467
INFO - 2022-06-14 10:51:14 --> Config Class Initialized
INFO - 2022-06-14 10:51:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:14 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:14 --> URI Class Initialized
INFO - 2022-06-14 10:51:14 --> Router Class Initialized
INFO - 2022-06-14 10:51:14 --> Output Class Initialized
INFO - 2022-06-14 10:51:14 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:14 --> Input Class Initialized
INFO - 2022-06-14 10:51:14 --> Language Class Initialized
INFO - 2022-06-14 10:51:14 --> Language Class Initialized
INFO - 2022-06-14 10:51:14 --> Config Class Initialized
INFO - 2022-06-14 10:51:14 --> Loader Class Initialized
INFO - 2022-06-14 10:51:14 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:14 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:14 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:14 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:14 --> Controller Class Initialized
INFO - 2022-06-14 10:51:14 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:51:14 --> Config Class Initialized
INFO - 2022-06-14 10:51:14 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:14 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:14 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:14 --> URI Class Initialized
INFO - 2022-06-14 10:51:14 --> Router Class Initialized
INFO - 2022-06-14 10:51:14 --> Output Class Initialized
INFO - 2022-06-14 10:51:14 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:14 --> Input Class Initialized
INFO - 2022-06-14 10:51:14 --> Language Class Initialized
INFO - 2022-06-14 10:51:14 --> Language Class Initialized
INFO - 2022-06-14 10:51:14 --> Config Class Initialized
INFO - 2022-06-14 10:51:14 --> Loader Class Initialized
INFO - 2022-06-14 10:51:14 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:14 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:14 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:14 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:14 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:14 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:14 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:14 --> Total execution time: 0.0386
INFO - 2022-06-14 10:51:20 --> Config Class Initialized
INFO - 2022-06-14 10:51:20 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:20 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:20 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:20 --> URI Class Initialized
INFO - 2022-06-14 10:51:20 --> Router Class Initialized
INFO - 2022-06-14 10:51:20 --> Output Class Initialized
INFO - 2022-06-14 10:51:20 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:20 --> Input Class Initialized
INFO - 2022-06-14 10:51:20 --> Language Class Initialized
INFO - 2022-06-14 10:51:20 --> Language Class Initialized
INFO - 2022-06-14 10:51:20 --> Config Class Initialized
INFO - 2022-06-14 10:51:20 --> Loader Class Initialized
INFO - 2022-06-14 10:51:20 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:20 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:20 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:20 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:20 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:21 --> Controller Class Initialized
INFO - 2022-06-14 10:51:21 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:51:21 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:21 --> Total execution time: 0.0528
INFO - 2022-06-14 10:51:21 --> Config Class Initialized
INFO - 2022-06-14 10:51:21 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:21 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:21 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:21 --> URI Class Initialized
INFO - 2022-06-14 10:51:21 --> Router Class Initialized
INFO - 2022-06-14 10:51:21 --> Output Class Initialized
INFO - 2022-06-14 10:51:21 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:21 --> Input Class Initialized
INFO - 2022-06-14 10:51:21 --> Language Class Initialized
INFO - 2022-06-14 10:51:21 --> Language Class Initialized
INFO - 2022-06-14 10:51:21 --> Config Class Initialized
INFO - 2022-06-14 10:51:21 --> Loader Class Initialized
INFO - 2022-06-14 10:51:21 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:21 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:21 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:21 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:21 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:21 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-14 10:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:21 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:21 --> Total execution time: 0.0575
INFO - 2022-06-14 10:51:26 --> Config Class Initialized
INFO - 2022-06-14 10:51:26 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:51:26 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:51:26 --> Utf8 Class Initialized
INFO - 2022-06-14 10:51:26 --> URI Class Initialized
INFO - 2022-06-14 10:51:26 --> Router Class Initialized
INFO - 2022-06-14 10:51:26 --> Output Class Initialized
INFO - 2022-06-14 10:51:26 --> Security Class Initialized
DEBUG - 2022-06-14 10:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:51:26 --> Input Class Initialized
INFO - 2022-06-14 10:51:26 --> Language Class Initialized
INFO - 2022-06-14 10:51:26 --> Language Class Initialized
INFO - 2022-06-14 10:51:26 --> Config Class Initialized
INFO - 2022-06-14 10:51:26 --> Loader Class Initialized
INFO - 2022-06-14 10:51:26 --> Helper loaded: url_helper
INFO - 2022-06-14 10:51:26 --> Helper loaded: file_helper
INFO - 2022-06-14 10:51:26 --> Helper loaded: form_helper
INFO - 2022-06-14 10:51:26 --> Helper loaded: my_helper
INFO - 2022-06-14 10:51:26 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:51:26 --> Controller Class Initialized
DEBUG - 2022-06-14 10:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:51:26 --> Final output sent to browser
DEBUG - 2022-06-14 10:51:26 --> Total execution time: 0.0468
INFO - 2022-06-14 10:53:16 --> Config Class Initialized
INFO - 2022-06-14 10:53:16 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:53:16 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:53:16 --> Utf8 Class Initialized
INFO - 2022-06-14 10:53:16 --> URI Class Initialized
INFO - 2022-06-14 10:53:16 --> Router Class Initialized
INFO - 2022-06-14 10:53:16 --> Output Class Initialized
INFO - 2022-06-14 10:53:16 --> Security Class Initialized
DEBUG - 2022-06-14 10:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:53:16 --> Input Class Initialized
INFO - 2022-06-14 10:53:16 --> Language Class Initialized
INFO - 2022-06-14 10:53:16 --> Language Class Initialized
INFO - 2022-06-14 10:53:16 --> Config Class Initialized
INFO - 2022-06-14 10:53:16 --> Loader Class Initialized
INFO - 2022-06-14 10:53:16 --> Helper loaded: url_helper
INFO - 2022-06-14 10:53:16 --> Helper loaded: file_helper
INFO - 2022-06-14 10:53:16 --> Helper loaded: form_helper
INFO - 2022-06-14 10:53:16 --> Helper loaded: my_helper
INFO - 2022-06-14 10:53:16 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:53:16 --> Controller Class Initialized
INFO - 2022-06-14 10:53:16 --> Final output sent to browser
DEBUG - 2022-06-14 10:53:16 --> Total execution time: 0.0734
INFO - 2022-06-14 10:53:17 --> Config Class Initialized
INFO - 2022-06-14 10:53:17 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:53:17 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:53:17 --> Utf8 Class Initialized
INFO - 2022-06-14 10:53:17 --> URI Class Initialized
INFO - 2022-06-14 10:53:17 --> Router Class Initialized
INFO - 2022-06-14 10:53:17 --> Output Class Initialized
INFO - 2022-06-14 10:53:17 --> Security Class Initialized
DEBUG - 2022-06-14 10:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:53:17 --> Input Class Initialized
INFO - 2022-06-14 10:53:17 --> Language Class Initialized
INFO - 2022-06-14 10:53:17 --> Language Class Initialized
INFO - 2022-06-14 10:53:17 --> Config Class Initialized
INFO - 2022-06-14 10:53:17 --> Loader Class Initialized
INFO - 2022-06-14 10:53:17 --> Helper loaded: url_helper
INFO - 2022-06-14 10:53:17 --> Helper loaded: file_helper
INFO - 2022-06-14 10:53:17 --> Helper loaded: form_helper
INFO - 2022-06-14 10:53:17 --> Helper loaded: my_helper
INFO - 2022-06-14 10:53:17 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:53:17 --> Controller Class Initialized
DEBUG - 2022-06-14 10:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-06-14 10:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:53:17 --> Final output sent to browser
DEBUG - 2022-06-14 10:53:17 --> Total execution time: 0.0428
INFO - 2022-06-14 10:53:40 --> Config Class Initialized
INFO - 2022-06-14 10:53:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:53:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:53:40 --> Utf8 Class Initialized
INFO - 2022-06-14 10:53:40 --> URI Class Initialized
INFO - 2022-06-14 10:53:40 --> Router Class Initialized
INFO - 2022-06-14 10:53:40 --> Output Class Initialized
INFO - 2022-06-14 10:53:40 --> Security Class Initialized
DEBUG - 2022-06-14 10:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:53:40 --> Input Class Initialized
INFO - 2022-06-14 10:53:40 --> Language Class Initialized
INFO - 2022-06-14 10:53:40 --> Language Class Initialized
INFO - 2022-06-14 10:53:40 --> Config Class Initialized
INFO - 2022-06-14 10:53:40 --> Loader Class Initialized
INFO - 2022-06-14 10:53:40 --> Helper loaded: url_helper
INFO - 2022-06-14 10:53:40 --> Helper loaded: file_helper
INFO - 2022-06-14 10:53:40 --> Helper loaded: form_helper
INFO - 2022-06-14 10:53:40 --> Helper loaded: my_helper
INFO - 2022-06-14 10:53:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:53:40 --> Controller Class Initialized
INFO - 2022-06-14 10:53:40 --> Helper loaded: cookie_helper
INFO - 2022-06-14 10:53:40 --> Config Class Initialized
INFO - 2022-06-14 10:53:40 --> Hooks Class Initialized
DEBUG - 2022-06-14 10:53:40 --> UTF-8 Support Enabled
INFO - 2022-06-14 10:53:40 --> Utf8 Class Initialized
INFO - 2022-06-14 10:53:40 --> URI Class Initialized
INFO - 2022-06-14 10:53:40 --> Router Class Initialized
INFO - 2022-06-14 10:53:40 --> Output Class Initialized
INFO - 2022-06-14 10:53:40 --> Security Class Initialized
DEBUG - 2022-06-14 10:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-14 10:53:40 --> Input Class Initialized
INFO - 2022-06-14 10:53:40 --> Language Class Initialized
INFO - 2022-06-14 10:53:40 --> Language Class Initialized
INFO - 2022-06-14 10:53:40 --> Config Class Initialized
INFO - 2022-06-14 10:53:40 --> Loader Class Initialized
INFO - 2022-06-14 10:53:40 --> Helper loaded: url_helper
INFO - 2022-06-14 10:53:40 --> Helper loaded: file_helper
INFO - 2022-06-14 10:53:40 --> Helper loaded: form_helper
INFO - 2022-06-14 10:53:40 --> Helper loaded: my_helper
INFO - 2022-06-14 10:53:40 --> Database Driver Class Initialized
DEBUG - 2022-06-14 10:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-14 10:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-14 10:53:40 --> Controller Class Initialized
DEBUG - 2022-06-14 10:53:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-14 10:53:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-14 10:53:40 --> Final output sent to browser
DEBUG - 2022-06-14 10:53:40 --> Total execution time: 0.0488
