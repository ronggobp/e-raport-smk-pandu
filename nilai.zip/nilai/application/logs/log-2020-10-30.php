<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-30 03:20:30 --> Config Class Initialized
INFO - 2020-10-30 03:20:30 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:20:30 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:20:30 --> Utf8 Class Initialized
INFO - 2020-10-30 03:20:30 --> URI Class Initialized
DEBUG - 2020-10-30 03:20:30 --> No URI present. Default controller set.
INFO - 2020-10-30 03:20:30 --> Router Class Initialized
INFO - 2020-10-30 03:20:30 --> Output Class Initialized
INFO - 2020-10-30 03:20:30 --> Security Class Initialized
DEBUG - 2020-10-30 03:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:20:30 --> Input Class Initialized
INFO - 2020-10-30 03:20:30 --> Language Class Initialized
INFO - 2020-10-30 03:20:31 --> Language Class Initialized
INFO - 2020-10-30 03:20:31 --> Config Class Initialized
INFO - 2020-10-30 03:20:31 --> Loader Class Initialized
INFO - 2020-10-30 03:20:31 --> Helper loaded: url_helper
INFO - 2020-10-30 03:20:31 --> Helper loaded: file_helper
INFO - 2020-10-30 03:20:31 --> Helper loaded: form_helper
INFO - 2020-10-30 03:20:31 --> Helper loaded: my_helper
INFO - 2020-10-30 03:20:31 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:20:31 --> Controller Class Initialized
INFO - 2020-10-30 03:20:31 --> Config Class Initialized
INFO - 2020-10-30 03:20:31 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:20:31 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:20:31 --> Utf8 Class Initialized
INFO - 2020-10-30 03:20:31 --> URI Class Initialized
INFO - 2020-10-30 03:20:31 --> Router Class Initialized
INFO - 2020-10-30 03:20:31 --> Output Class Initialized
INFO - 2020-10-30 03:20:31 --> Security Class Initialized
DEBUG - 2020-10-30 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:20:31 --> Input Class Initialized
INFO - 2020-10-30 03:20:31 --> Language Class Initialized
INFO - 2020-10-30 03:20:31 --> Language Class Initialized
INFO - 2020-10-30 03:20:31 --> Config Class Initialized
INFO - 2020-10-30 03:20:31 --> Loader Class Initialized
INFO - 2020-10-30 03:20:31 --> Helper loaded: url_helper
INFO - 2020-10-30 03:20:31 --> Helper loaded: file_helper
INFO - 2020-10-30 03:20:31 --> Helper loaded: form_helper
INFO - 2020-10-30 03:20:31 --> Helper loaded: my_helper
INFO - 2020-10-30 03:20:31 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:20:31 --> Controller Class Initialized
DEBUG - 2020-10-30 03:20:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 03:20:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:20:31 --> Final output sent to browser
DEBUG - 2020-10-30 03:20:31 --> Total execution time: 0.4504
INFO - 2020-10-30 03:20:52 --> Config Class Initialized
INFO - 2020-10-30 03:20:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:20:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:20:52 --> Utf8 Class Initialized
INFO - 2020-10-30 03:20:52 --> URI Class Initialized
INFO - 2020-10-30 03:20:52 --> Router Class Initialized
INFO - 2020-10-30 03:20:53 --> Output Class Initialized
INFO - 2020-10-30 03:20:53 --> Security Class Initialized
DEBUG - 2020-10-30 03:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:20:53 --> Input Class Initialized
INFO - 2020-10-30 03:20:53 --> Language Class Initialized
INFO - 2020-10-30 03:20:53 --> Language Class Initialized
INFO - 2020-10-30 03:20:53 --> Config Class Initialized
INFO - 2020-10-30 03:20:53 --> Loader Class Initialized
INFO - 2020-10-30 03:20:53 --> Helper loaded: url_helper
INFO - 2020-10-30 03:20:53 --> Helper loaded: file_helper
INFO - 2020-10-30 03:20:53 --> Helper loaded: form_helper
INFO - 2020-10-30 03:20:53 --> Helper loaded: my_helper
INFO - 2020-10-30 03:20:53 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:20:53 --> Controller Class Initialized
INFO - 2020-10-30 03:20:53 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:20:53 --> Final output sent to browser
DEBUG - 2020-10-30 03:20:53 --> Total execution time: 0.3415
INFO - 2020-10-30 03:20:54 --> Config Class Initialized
INFO - 2020-10-30 03:20:54 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:20:54 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:20:54 --> Utf8 Class Initialized
INFO - 2020-10-30 03:20:54 --> URI Class Initialized
INFO - 2020-10-30 03:20:54 --> Router Class Initialized
INFO - 2020-10-30 03:20:54 --> Output Class Initialized
INFO - 2020-10-30 03:20:54 --> Security Class Initialized
DEBUG - 2020-10-30 03:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:20:54 --> Input Class Initialized
INFO - 2020-10-30 03:20:54 --> Language Class Initialized
INFO - 2020-10-30 03:20:54 --> Language Class Initialized
INFO - 2020-10-30 03:20:54 --> Config Class Initialized
INFO - 2020-10-30 03:20:54 --> Loader Class Initialized
INFO - 2020-10-30 03:20:54 --> Helper loaded: url_helper
INFO - 2020-10-30 03:20:54 --> Helper loaded: file_helper
INFO - 2020-10-30 03:20:54 --> Helper loaded: form_helper
INFO - 2020-10-30 03:20:54 --> Helper loaded: my_helper
INFO - 2020-10-30 03:20:54 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:20:54 --> Controller Class Initialized
DEBUG - 2020-10-30 03:20:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 03:20:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:20:55 --> Final output sent to browser
DEBUG - 2020-10-30 03:20:55 --> Total execution time: 0.5466
INFO - 2020-10-30 03:20:56 --> Config Class Initialized
INFO - 2020-10-30 03:20:56 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:20:56 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:20:56 --> Utf8 Class Initialized
INFO - 2020-10-30 03:20:56 --> URI Class Initialized
INFO - 2020-10-30 03:20:56 --> Router Class Initialized
INFO - 2020-10-30 03:20:56 --> Output Class Initialized
INFO - 2020-10-30 03:20:56 --> Security Class Initialized
DEBUG - 2020-10-30 03:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:20:56 --> Input Class Initialized
INFO - 2020-10-30 03:20:56 --> Language Class Initialized
INFO - 2020-10-30 03:20:56 --> Language Class Initialized
INFO - 2020-10-30 03:20:56 --> Config Class Initialized
INFO - 2020-10-30 03:20:56 --> Loader Class Initialized
INFO - 2020-10-30 03:20:56 --> Helper loaded: url_helper
INFO - 2020-10-30 03:20:56 --> Helper loaded: file_helper
INFO - 2020-10-30 03:20:56 --> Helper loaded: form_helper
INFO - 2020-10-30 03:20:56 --> Helper loaded: my_helper
INFO - 2020-10-30 03:20:56 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:20:56 --> Controller Class Initialized
DEBUG - 2020-10-30 03:20:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-30 03:20:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:20:57 --> Final output sent to browser
DEBUG - 2020-10-30 03:20:57 --> Total execution time: 0.2247
INFO - 2020-10-30 03:20:57 --> Config Class Initialized
INFO - 2020-10-30 03:20:57 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:20:57 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:20:57 --> Utf8 Class Initialized
INFO - 2020-10-30 03:20:57 --> URI Class Initialized
INFO - 2020-10-30 03:20:57 --> Router Class Initialized
INFO - 2020-10-30 03:20:57 --> Output Class Initialized
INFO - 2020-10-30 03:20:57 --> Security Class Initialized
DEBUG - 2020-10-30 03:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:20:57 --> Input Class Initialized
INFO - 2020-10-30 03:20:57 --> Language Class Initialized
INFO - 2020-10-30 03:20:57 --> Language Class Initialized
INFO - 2020-10-30 03:20:57 --> Config Class Initialized
INFO - 2020-10-30 03:20:57 --> Loader Class Initialized
INFO - 2020-10-30 03:20:57 --> Helper loaded: url_helper
INFO - 2020-10-30 03:20:57 --> Helper loaded: file_helper
INFO - 2020-10-30 03:20:57 --> Helper loaded: form_helper
INFO - 2020-10-30 03:20:57 --> Helper loaded: my_helper
INFO - 2020-10-30 03:20:57 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:20:57 --> Controller Class Initialized
INFO - 2020-10-30 03:20:57 --> Config Class Initialized
INFO - 2020-10-30 03:20:57 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:20:57 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:20:57 --> Utf8 Class Initialized
INFO - 2020-10-30 03:20:57 --> URI Class Initialized
INFO - 2020-10-30 03:20:57 --> Router Class Initialized
INFO - 2020-10-30 03:20:57 --> Output Class Initialized
INFO - 2020-10-30 03:20:57 --> Security Class Initialized
DEBUG - 2020-10-30 03:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:20:57 --> Input Class Initialized
INFO - 2020-10-30 03:20:57 --> Language Class Initialized
INFO - 2020-10-30 03:20:57 --> Language Class Initialized
INFO - 2020-10-30 03:20:57 --> Config Class Initialized
INFO - 2020-10-30 03:20:57 --> Loader Class Initialized
INFO - 2020-10-30 03:20:57 --> Helper loaded: url_helper
INFO - 2020-10-30 03:20:57 --> Helper loaded: file_helper
INFO - 2020-10-30 03:20:57 --> Helper loaded: form_helper
INFO - 2020-10-30 03:20:57 --> Helper loaded: my_helper
INFO - 2020-10-30 03:20:57 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:20:57 --> Controller Class Initialized
DEBUG - 2020-10-30 03:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-30 03:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:20:58 --> Final output sent to browser
DEBUG - 2020-10-30 03:20:58 --> Total execution time: 0.2940
INFO - 2020-10-30 03:21:00 --> Config Class Initialized
INFO - 2020-10-30 03:21:00 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:00 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:00 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:00 --> URI Class Initialized
INFO - 2020-10-30 03:21:00 --> Router Class Initialized
INFO - 2020-10-30 03:21:00 --> Output Class Initialized
INFO - 2020-10-30 03:21:00 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:00 --> Input Class Initialized
INFO - 2020-10-30 03:21:00 --> Language Class Initialized
INFO - 2020-10-30 03:21:00 --> Language Class Initialized
INFO - 2020-10-30 03:21:00 --> Config Class Initialized
INFO - 2020-10-30 03:21:00 --> Loader Class Initialized
INFO - 2020-10-30 03:21:00 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:00 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:00 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:00 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:00 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:00 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-30 03:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:00 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:00 --> Total execution time: 0.1832
INFO - 2020-10-30 03:21:01 --> Config Class Initialized
INFO - 2020-10-30 03:21:01 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:01 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:01 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:01 --> URI Class Initialized
INFO - 2020-10-30 03:21:01 --> Router Class Initialized
INFO - 2020-10-30 03:21:01 --> Output Class Initialized
INFO - 2020-10-30 03:21:01 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:01 --> Input Class Initialized
INFO - 2020-10-30 03:21:01 --> Language Class Initialized
INFO - 2020-10-30 03:21:01 --> Language Class Initialized
INFO - 2020-10-30 03:21:01 --> Config Class Initialized
INFO - 2020-10-30 03:21:01 --> Loader Class Initialized
INFO - 2020-10-30 03:21:01 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:01 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:01 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:01 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:01 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:01 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-30 03:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:01 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:01 --> Total execution time: 0.2945
INFO - 2020-10-30 03:21:01 --> Config Class Initialized
INFO - 2020-10-30 03:21:01 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:01 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:01 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:01 --> URI Class Initialized
INFO - 2020-10-30 03:21:01 --> Router Class Initialized
INFO - 2020-10-30 03:21:01 --> Output Class Initialized
INFO - 2020-10-30 03:21:01 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:01 --> Input Class Initialized
INFO - 2020-10-30 03:21:01 --> Language Class Initialized
INFO - 2020-10-30 03:21:01 --> Language Class Initialized
INFO - 2020-10-30 03:21:01 --> Config Class Initialized
INFO - 2020-10-30 03:21:01 --> Loader Class Initialized
INFO - 2020-10-30 03:21:01 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:01 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:01 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:01 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:01 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:01 --> Controller Class Initialized
INFO - 2020-10-30 03:21:04 --> Config Class Initialized
INFO - 2020-10-30 03:21:04 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:04 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:04 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:04 --> URI Class Initialized
INFO - 2020-10-30 03:21:04 --> Router Class Initialized
INFO - 2020-10-30 03:21:04 --> Output Class Initialized
INFO - 2020-10-30 03:21:04 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:04 --> Input Class Initialized
INFO - 2020-10-30 03:21:04 --> Language Class Initialized
INFO - 2020-10-30 03:21:04 --> Language Class Initialized
INFO - 2020-10-30 03:21:04 --> Config Class Initialized
INFO - 2020-10-30 03:21:04 --> Loader Class Initialized
INFO - 2020-10-30 03:21:04 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:04 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:04 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:04 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:04 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:04 --> Controller Class Initialized
INFO - 2020-10-30 03:21:04 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:21:04 --> Config Class Initialized
INFO - 2020-10-30 03:21:04 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:04 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:04 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:04 --> URI Class Initialized
INFO - 2020-10-30 03:21:04 --> Router Class Initialized
INFO - 2020-10-30 03:21:04 --> Output Class Initialized
INFO - 2020-10-30 03:21:04 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:04 --> Input Class Initialized
INFO - 2020-10-30 03:21:04 --> Language Class Initialized
INFO - 2020-10-30 03:21:04 --> Language Class Initialized
INFO - 2020-10-30 03:21:04 --> Config Class Initialized
INFO - 2020-10-30 03:21:04 --> Loader Class Initialized
INFO - 2020-10-30 03:21:04 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:04 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:05 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:05 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:05 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:05 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 03:21:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:05 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:05 --> Total execution time: 0.1673
INFO - 2020-10-30 03:21:11 --> Config Class Initialized
INFO - 2020-10-30 03:21:11 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:11 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:11 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:11 --> URI Class Initialized
INFO - 2020-10-30 03:21:11 --> Router Class Initialized
INFO - 2020-10-30 03:21:11 --> Output Class Initialized
INFO - 2020-10-30 03:21:11 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:11 --> Input Class Initialized
INFO - 2020-10-30 03:21:11 --> Language Class Initialized
INFO - 2020-10-30 03:21:11 --> Language Class Initialized
INFO - 2020-10-30 03:21:11 --> Config Class Initialized
INFO - 2020-10-30 03:21:11 --> Loader Class Initialized
INFO - 2020-10-30 03:21:11 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:11 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:11 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:11 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:11 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:11 --> Controller Class Initialized
INFO - 2020-10-30 03:21:11 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:21:11 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:11 --> Total execution time: 0.2204
INFO - 2020-10-30 03:21:13 --> Config Class Initialized
INFO - 2020-10-30 03:21:13 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:13 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:13 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:13 --> URI Class Initialized
INFO - 2020-10-30 03:21:13 --> Router Class Initialized
INFO - 2020-10-30 03:21:13 --> Output Class Initialized
INFO - 2020-10-30 03:21:13 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:13 --> Input Class Initialized
INFO - 2020-10-30 03:21:13 --> Language Class Initialized
INFO - 2020-10-30 03:21:13 --> Language Class Initialized
INFO - 2020-10-30 03:21:13 --> Config Class Initialized
INFO - 2020-10-30 03:21:13 --> Loader Class Initialized
INFO - 2020-10-30 03:21:13 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:13 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:13 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:13 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:13 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:13 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 03:21:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:13 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:13 --> Total execution time: 0.2127
INFO - 2020-10-30 03:21:15 --> Config Class Initialized
INFO - 2020-10-30 03:21:15 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:15 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:15 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:15 --> URI Class Initialized
INFO - 2020-10-30 03:21:15 --> Router Class Initialized
INFO - 2020-10-30 03:21:15 --> Output Class Initialized
INFO - 2020-10-30 03:21:15 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:15 --> Input Class Initialized
INFO - 2020-10-30 03:21:15 --> Language Class Initialized
INFO - 2020-10-30 03:21:16 --> Language Class Initialized
INFO - 2020-10-30 03:21:16 --> Config Class Initialized
INFO - 2020-10-30 03:21:16 --> Loader Class Initialized
INFO - 2020-10-30 03:21:16 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:16 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:16 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:16 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:16 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:16 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-30 03:21:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:16 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:16 --> Total execution time: 0.2334
INFO - 2020-10-30 03:21:17 --> Config Class Initialized
INFO - 2020-10-30 03:21:17 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:17 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:17 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:17 --> URI Class Initialized
INFO - 2020-10-30 03:21:17 --> Router Class Initialized
INFO - 2020-10-30 03:21:17 --> Output Class Initialized
INFO - 2020-10-30 03:21:17 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:17 --> Input Class Initialized
INFO - 2020-10-30 03:21:17 --> Language Class Initialized
INFO - 2020-10-30 03:21:17 --> Language Class Initialized
INFO - 2020-10-30 03:21:17 --> Config Class Initialized
INFO - 2020-10-30 03:21:17 --> Loader Class Initialized
INFO - 2020-10-30 03:21:17 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:17 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:17 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:17 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:17 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:17 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-30 03:21:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:17 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:17 --> Total execution time: 0.3263
INFO - 2020-10-30 03:21:17 --> Config Class Initialized
INFO - 2020-10-30 03:21:17 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:17 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:17 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:17 --> URI Class Initialized
INFO - 2020-10-30 03:21:17 --> Router Class Initialized
INFO - 2020-10-30 03:21:17 --> Output Class Initialized
INFO - 2020-10-30 03:21:17 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:17 --> Input Class Initialized
INFO - 2020-10-30 03:21:17 --> Language Class Initialized
INFO - 2020-10-30 03:21:17 --> Language Class Initialized
INFO - 2020-10-30 03:21:17 --> Config Class Initialized
INFO - 2020-10-30 03:21:17 --> Loader Class Initialized
INFO - 2020-10-30 03:21:18 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:18 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:18 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:18 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:18 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:18 --> Controller Class Initialized
INFO - 2020-10-30 03:21:24 --> Config Class Initialized
INFO - 2020-10-30 03:21:24 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:24 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:24 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:24 --> URI Class Initialized
INFO - 2020-10-30 03:21:24 --> Router Class Initialized
INFO - 2020-10-30 03:21:24 --> Output Class Initialized
INFO - 2020-10-30 03:21:24 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:24 --> Input Class Initialized
INFO - 2020-10-30 03:21:24 --> Language Class Initialized
INFO - 2020-10-30 03:21:24 --> Language Class Initialized
INFO - 2020-10-30 03:21:24 --> Config Class Initialized
INFO - 2020-10-30 03:21:24 --> Loader Class Initialized
INFO - 2020-10-30 03:21:24 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:24 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:24 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:24 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:24 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:24 --> Controller Class Initialized
INFO - 2020-10-30 03:21:24 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:21:24 --> Config Class Initialized
INFO - 2020-10-30 03:21:24 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:24 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:24 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:24 --> URI Class Initialized
INFO - 2020-10-30 03:21:24 --> Router Class Initialized
INFO - 2020-10-30 03:21:24 --> Output Class Initialized
INFO - 2020-10-30 03:21:24 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:24 --> Input Class Initialized
INFO - 2020-10-30 03:21:24 --> Language Class Initialized
INFO - 2020-10-30 03:21:24 --> Language Class Initialized
INFO - 2020-10-30 03:21:24 --> Config Class Initialized
INFO - 2020-10-30 03:21:24 --> Loader Class Initialized
INFO - 2020-10-30 03:21:24 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:24 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:24 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:25 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:25 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:25 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 03:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:25 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:25 --> Total execution time: 0.1646
INFO - 2020-10-30 03:21:29 --> Config Class Initialized
INFO - 2020-10-30 03:21:29 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:29 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:29 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:29 --> URI Class Initialized
INFO - 2020-10-30 03:21:29 --> Router Class Initialized
INFO - 2020-10-30 03:21:29 --> Output Class Initialized
INFO - 2020-10-30 03:21:29 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:29 --> Input Class Initialized
INFO - 2020-10-30 03:21:29 --> Language Class Initialized
INFO - 2020-10-30 03:21:29 --> Language Class Initialized
INFO - 2020-10-30 03:21:29 --> Config Class Initialized
INFO - 2020-10-30 03:21:29 --> Loader Class Initialized
INFO - 2020-10-30 03:21:29 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:29 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:29 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:29 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:29 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:29 --> Controller Class Initialized
INFO - 2020-10-30 03:21:29 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:21:29 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:29 --> Total execution time: 0.1759
INFO - 2020-10-30 03:21:30 --> Config Class Initialized
INFO - 2020-10-30 03:21:30 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:30 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:30 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:30 --> URI Class Initialized
INFO - 2020-10-30 03:21:30 --> Router Class Initialized
INFO - 2020-10-30 03:21:30 --> Output Class Initialized
INFO - 2020-10-30 03:21:30 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:30 --> Input Class Initialized
INFO - 2020-10-30 03:21:30 --> Language Class Initialized
INFO - 2020-10-30 03:21:30 --> Language Class Initialized
INFO - 2020-10-30 03:21:30 --> Config Class Initialized
INFO - 2020-10-30 03:21:30 --> Loader Class Initialized
INFO - 2020-10-30 03:21:30 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:30 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:30 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:30 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:30 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:30 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 03:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:30 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:30 --> Total execution time: 0.2037
INFO - 2020-10-30 03:21:32 --> Config Class Initialized
INFO - 2020-10-30 03:21:32 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:32 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:32 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:32 --> URI Class Initialized
INFO - 2020-10-30 03:21:32 --> Router Class Initialized
INFO - 2020-10-30 03:21:32 --> Output Class Initialized
INFO - 2020-10-30 03:21:32 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:32 --> Input Class Initialized
INFO - 2020-10-30 03:21:32 --> Language Class Initialized
INFO - 2020-10-30 03:21:32 --> Language Class Initialized
INFO - 2020-10-30 03:21:32 --> Config Class Initialized
INFO - 2020-10-30 03:21:32 --> Loader Class Initialized
INFO - 2020-10-30 03:21:32 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:32 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:32 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:32 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:32 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:32 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-30 03:21:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:32 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:32 --> Total execution time: 0.1694
INFO - 2020-10-30 03:21:35 --> Config Class Initialized
INFO - 2020-10-30 03:21:35 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:35 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:35 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:35 --> URI Class Initialized
INFO - 2020-10-30 03:21:35 --> Router Class Initialized
INFO - 2020-10-30 03:21:35 --> Output Class Initialized
INFO - 2020-10-30 03:21:35 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:35 --> Input Class Initialized
INFO - 2020-10-30 03:21:35 --> Language Class Initialized
INFO - 2020-10-30 03:21:35 --> Language Class Initialized
INFO - 2020-10-30 03:21:35 --> Config Class Initialized
INFO - 2020-10-30 03:21:35 --> Loader Class Initialized
INFO - 2020-10-30 03:21:35 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:35 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:35 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:35 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:35 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:35 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-30 03:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:35 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:35 --> Total execution time: 0.1979
INFO - 2020-10-30 03:21:35 --> Config Class Initialized
INFO - 2020-10-30 03:21:35 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:35 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:35 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:35 --> URI Class Initialized
INFO - 2020-10-30 03:21:35 --> Router Class Initialized
INFO - 2020-10-30 03:21:35 --> Output Class Initialized
INFO - 2020-10-30 03:21:35 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:35 --> Input Class Initialized
INFO - 2020-10-30 03:21:35 --> Language Class Initialized
INFO - 2020-10-30 03:21:35 --> Language Class Initialized
INFO - 2020-10-30 03:21:35 --> Config Class Initialized
INFO - 2020-10-30 03:21:35 --> Loader Class Initialized
INFO - 2020-10-30 03:21:35 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:35 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:35 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:35 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:35 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:35 --> Controller Class Initialized
INFO - 2020-10-30 03:21:37 --> Config Class Initialized
INFO - 2020-10-30 03:21:37 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:37 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:37 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:37 --> URI Class Initialized
INFO - 2020-10-30 03:21:37 --> Router Class Initialized
INFO - 2020-10-30 03:21:37 --> Output Class Initialized
INFO - 2020-10-30 03:21:37 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:37 --> Input Class Initialized
INFO - 2020-10-30 03:21:37 --> Language Class Initialized
INFO - 2020-10-30 03:21:37 --> Language Class Initialized
INFO - 2020-10-30 03:21:37 --> Config Class Initialized
INFO - 2020-10-30 03:21:37 --> Loader Class Initialized
INFO - 2020-10-30 03:21:37 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:37 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:37 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:37 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:37 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:37 --> Controller Class Initialized
INFO - 2020-10-30 03:21:37 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:21:37 --> Config Class Initialized
INFO - 2020-10-30 03:21:37 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:37 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:37 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:37 --> URI Class Initialized
INFO - 2020-10-30 03:21:37 --> Router Class Initialized
INFO - 2020-10-30 03:21:37 --> Output Class Initialized
INFO - 2020-10-30 03:21:37 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:37 --> Input Class Initialized
INFO - 2020-10-30 03:21:37 --> Language Class Initialized
INFO - 2020-10-30 03:21:37 --> Language Class Initialized
INFO - 2020-10-30 03:21:38 --> Config Class Initialized
INFO - 2020-10-30 03:21:38 --> Loader Class Initialized
INFO - 2020-10-30 03:21:38 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:38 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:38 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:38 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:38 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:38 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 03:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:38 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:38 --> Total execution time: 0.1934
INFO - 2020-10-30 03:21:45 --> Config Class Initialized
INFO - 2020-10-30 03:21:45 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:45 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:45 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:45 --> URI Class Initialized
INFO - 2020-10-30 03:21:45 --> Router Class Initialized
INFO - 2020-10-30 03:21:45 --> Output Class Initialized
INFO - 2020-10-30 03:21:45 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:45 --> Input Class Initialized
INFO - 2020-10-30 03:21:45 --> Language Class Initialized
INFO - 2020-10-30 03:21:45 --> Language Class Initialized
INFO - 2020-10-30 03:21:45 --> Config Class Initialized
INFO - 2020-10-30 03:21:45 --> Loader Class Initialized
INFO - 2020-10-30 03:21:45 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:45 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:45 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:45 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:45 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:45 --> Controller Class Initialized
INFO - 2020-10-30 03:21:45 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:21:45 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:45 --> Total execution time: 0.1682
INFO - 2020-10-30 03:21:47 --> Config Class Initialized
INFO - 2020-10-30 03:21:47 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:47 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:47 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:47 --> URI Class Initialized
INFO - 2020-10-30 03:21:47 --> Router Class Initialized
INFO - 2020-10-30 03:21:47 --> Output Class Initialized
INFO - 2020-10-30 03:21:47 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:47 --> Input Class Initialized
INFO - 2020-10-30 03:21:47 --> Language Class Initialized
INFO - 2020-10-30 03:21:47 --> Language Class Initialized
INFO - 2020-10-30 03:21:47 --> Config Class Initialized
INFO - 2020-10-30 03:21:47 --> Loader Class Initialized
INFO - 2020-10-30 03:21:47 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:47 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:47 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:47 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:47 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:47 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 03:21:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:47 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:47 --> Total execution time: 0.2074
INFO - 2020-10-30 03:21:49 --> Config Class Initialized
INFO - 2020-10-30 03:21:49 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:49 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:49 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:49 --> URI Class Initialized
INFO - 2020-10-30 03:21:49 --> Router Class Initialized
INFO - 2020-10-30 03:21:49 --> Output Class Initialized
INFO - 2020-10-30 03:21:49 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:49 --> Input Class Initialized
INFO - 2020-10-30 03:21:49 --> Language Class Initialized
INFO - 2020-10-30 03:21:49 --> Language Class Initialized
INFO - 2020-10-30 03:21:49 --> Config Class Initialized
INFO - 2020-10-30 03:21:49 --> Loader Class Initialized
INFO - 2020-10-30 03:21:49 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:49 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:49 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:49 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:49 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:49 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-30 03:21:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:49 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:49 --> Total execution time: 0.1812
INFO - 2020-10-30 03:21:52 --> Config Class Initialized
INFO - 2020-10-30 03:21:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:52 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:52 --> URI Class Initialized
INFO - 2020-10-30 03:21:52 --> Router Class Initialized
INFO - 2020-10-30 03:21:52 --> Output Class Initialized
INFO - 2020-10-30 03:21:52 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:52 --> Input Class Initialized
INFO - 2020-10-30 03:21:52 --> Language Class Initialized
INFO - 2020-10-30 03:21:52 --> Language Class Initialized
INFO - 2020-10-30 03:21:52 --> Config Class Initialized
INFO - 2020-10-30 03:21:52 --> Loader Class Initialized
INFO - 2020-10-30 03:21:52 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:52 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:52 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:52 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:52 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:52 --> Controller Class Initialized
DEBUG - 2020-10-30 03:21:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-30 03:21:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:21:52 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:52 --> Total execution time: 0.1880
INFO - 2020-10-30 03:21:52 --> Config Class Initialized
INFO - 2020-10-30 03:21:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:52 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:52 --> URI Class Initialized
INFO - 2020-10-30 03:21:52 --> Router Class Initialized
INFO - 2020-10-30 03:21:52 --> Output Class Initialized
INFO - 2020-10-30 03:21:52 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:52 --> Input Class Initialized
INFO - 2020-10-30 03:21:52 --> Language Class Initialized
INFO - 2020-10-30 03:21:52 --> Language Class Initialized
INFO - 2020-10-30 03:21:52 --> Config Class Initialized
INFO - 2020-10-30 03:21:52 --> Loader Class Initialized
INFO - 2020-10-30 03:21:52 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:52 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:52 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:52 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:52 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:52 --> Controller Class Initialized
INFO - 2020-10-30 03:21:56 --> Config Class Initialized
INFO - 2020-10-30 03:21:56 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:21:56 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:21:56 --> Utf8 Class Initialized
INFO - 2020-10-30 03:21:56 --> URI Class Initialized
INFO - 2020-10-30 03:21:56 --> Router Class Initialized
INFO - 2020-10-30 03:21:56 --> Output Class Initialized
INFO - 2020-10-30 03:21:56 --> Security Class Initialized
DEBUG - 2020-10-30 03:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:21:57 --> Input Class Initialized
INFO - 2020-10-30 03:21:57 --> Language Class Initialized
INFO - 2020-10-30 03:21:57 --> Language Class Initialized
INFO - 2020-10-30 03:21:57 --> Config Class Initialized
INFO - 2020-10-30 03:21:57 --> Loader Class Initialized
INFO - 2020-10-30 03:21:57 --> Helper loaded: url_helper
INFO - 2020-10-30 03:21:57 --> Helper loaded: file_helper
INFO - 2020-10-30 03:21:57 --> Helper loaded: form_helper
INFO - 2020-10-30 03:21:57 --> Helper loaded: my_helper
INFO - 2020-10-30 03:21:57 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:21:57 --> Controller Class Initialized
INFO - 2020-10-30 03:21:57 --> Final output sent to browser
DEBUG - 2020-10-30 03:21:57 --> Total execution time: 0.2968
INFO - 2020-10-30 03:22:30 --> Config Class Initialized
INFO - 2020-10-30 03:22:30 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:22:30 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:22:30 --> Utf8 Class Initialized
INFO - 2020-10-30 03:22:30 --> URI Class Initialized
INFO - 2020-10-30 03:22:30 --> Router Class Initialized
INFO - 2020-10-30 03:22:30 --> Output Class Initialized
INFO - 2020-10-30 03:22:30 --> Security Class Initialized
DEBUG - 2020-10-30 03:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:22:31 --> Input Class Initialized
INFO - 2020-10-30 03:22:31 --> Language Class Initialized
INFO - 2020-10-30 03:22:31 --> Language Class Initialized
INFO - 2020-10-30 03:22:31 --> Config Class Initialized
INFO - 2020-10-30 03:22:31 --> Loader Class Initialized
INFO - 2020-10-30 03:22:31 --> Helper loaded: url_helper
INFO - 2020-10-30 03:22:31 --> Helper loaded: file_helper
INFO - 2020-10-30 03:22:31 --> Helper loaded: form_helper
INFO - 2020-10-30 03:22:31 --> Helper loaded: my_helper
INFO - 2020-10-30 03:22:31 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:22:31 --> Controller Class Initialized
INFO - 2020-10-30 03:22:31 --> Final output sent to browser
DEBUG - 2020-10-30 03:22:31 --> Total execution time: 0.2223
INFO - 2020-10-30 03:22:31 --> Config Class Initialized
INFO - 2020-10-30 03:22:31 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:22:31 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:22:31 --> Utf8 Class Initialized
INFO - 2020-10-30 03:22:31 --> URI Class Initialized
INFO - 2020-10-30 03:22:31 --> Router Class Initialized
INFO - 2020-10-30 03:22:31 --> Output Class Initialized
INFO - 2020-10-30 03:22:31 --> Security Class Initialized
DEBUG - 2020-10-30 03:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:22:31 --> Input Class Initialized
INFO - 2020-10-30 03:22:31 --> Language Class Initialized
INFO - 2020-10-30 03:22:31 --> Language Class Initialized
INFO - 2020-10-30 03:22:31 --> Config Class Initialized
INFO - 2020-10-30 03:22:31 --> Loader Class Initialized
INFO - 2020-10-30 03:22:31 --> Helper loaded: url_helper
INFO - 2020-10-30 03:22:31 --> Helper loaded: file_helper
INFO - 2020-10-30 03:22:31 --> Helper loaded: form_helper
INFO - 2020-10-30 03:22:31 --> Helper loaded: my_helper
INFO - 2020-10-30 03:22:31 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:22:31 --> Controller Class Initialized
INFO - 2020-10-30 03:22:34 --> Config Class Initialized
INFO - 2020-10-30 03:22:34 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:22:34 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:22:34 --> Utf8 Class Initialized
INFO - 2020-10-30 03:22:34 --> URI Class Initialized
INFO - 2020-10-30 03:22:34 --> Router Class Initialized
INFO - 2020-10-30 03:22:34 --> Output Class Initialized
INFO - 2020-10-30 03:22:34 --> Security Class Initialized
DEBUG - 2020-10-30 03:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:22:34 --> Input Class Initialized
INFO - 2020-10-30 03:22:34 --> Language Class Initialized
INFO - 2020-10-30 03:22:34 --> Language Class Initialized
INFO - 2020-10-30 03:22:34 --> Config Class Initialized
INFO - 2020-10-30 03:22:34 --> Loader Class Initialized
INFO - 2020-10-30 03:22:34 --> Helper loaded: url_helper
INFO - 2020-10-30 03:22:34 --> Helper loaded: file_helper
INFO - 2020-10-30 03:22:34 --> Helper loaded: form_helper
INFO - 2020-10-30 03:22:34 --> Helper loaded: my_helper
INFO - 2020-10-30 03:22:34 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:22:34 --> Controller Class Initialized
INFO - 2020-10-30 03:22:34 --> Final output sent to browser
DEBUG - 2020-10-30 03:22:34 --> Total execution time: 0.1581
INFO - 2020-10-30 03:22:43 --> Config Class Initialized
INFO - 2020-10-30 03:22:43 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:22:43 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:22:43 --> Utf8 Class Initialized
INFO - 2020-10-30 03:22:43 --> URI Class Initialized
INFO - 2020-10-30 03:22:43 --> Router Class Initialized
INFO - 2020-10-30 03:22:43 --> Output Class Initialized
INFO - 2020-10-30 03:22:43 --> Security Class Initialized
DEBUG - 2020-10-30 03:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:22:43 --> Input Class Initialized
INFO - 2020-10-30 03:22:43 --> Language Class Initialized
INFO - 2020-10-30 03:22:43 --> Language Class Initialized
INFO - 2020-10-30 03:22:43 --> Config Class Initialized
INFO - 2020-10-30 03:22:43 --> Loader Class Initialized
INFO - 2020-10-30 03:22:43 --> Helper loaded: url_helper
INFO - 2020-10-30 03:22:43 --> Helper loaded: file_helper
INFO - 2020-10-30 03:22:43 --> Helper loaded: form_helper
INFO - 2020-10-30 03:22:43 --> Helper loaded: my_helper
INFO - 2020-10-30 03:22:43 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:22:43 --> Controller Class Initialized
ERROR - 2020-10-30 03:22:43 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 857
ERROR - 2020-10-30 03:22:43 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 857
ERROR - 2020-10-30 03:22:43 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 857
INFO - 2020-10-30 03:22:43 --> Final output sent to browser
DEBUG - 2020-10-30 03:22:43 --> Total execution time: 0.3951
INFO - 2020-10-30 03:22:50 --> Config Class Initialized
INFO - 2020-10-30 03:22:50 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:22:50 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:22:50 --> Utf8 Class Initialized
INFO - 2020-10-30 03:22:50 --> URI Class Initialized
INFO - 2020-10-30 03:22:50 --> Router Class Initialized
INFO - 2020-10-30 03:22:50 --> Output Class Initialized
INFO - 2020-10-30 03:22:50 --> Security Class Initialized
DEBUG - 2020-10-30 03:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:22:50 --> Input Class Initialized
INFO - 2020-10-30 03:22:50 --> Language Class Initialized
INFO - 2020-10-30 03:22:50 --> Language Class Initialized
INFO - 2020-10-30 03:22:50 --> Config Class Initialized
INFO - 2020-10-30 03:22:50 --> Loader Class Initialized
INFO - 2020-10-30 03:22:50 --> Helper loaded: url_helper
INFO - 2020-10-30 03:22:50 --> Helper loaded: file_helper
INFO - 2020-10-30 03:22:50 --> Helper loaded: form_helper
INFO - 2020-10-30 03:22:50 --> Helper loaded: my_helper
INFO - 2020-10-30 03:22:50 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:22:50 --> Controller Class Initialized
DEBUG - 2020-10-30 03:22:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-30 03:22:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:22:50 --> Final output sent to browser
DEBUG - 2020-10-30 03:22:50 --> Total execution time: 0.1952
INFO - 2020-10-30 03:22:52 --> Config Class Initialized
INFO - 2020-10-30 03:22:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:22:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:22:52 --> Utf8 Class Initialized
INFO - 2020-10-30 03:22:52 --> URI Class Initialized
INFO - 2020-10-30 03:22:52 --> Router Class Initialized
INFO - 2020-10-30 03:22:52 --> Output Class Initialized
INFO - 2020-10-30 03:22:52 --> Security Class Initialized
DEBUG - 2020-10-30 03:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:22:52 --> Input Class Initialized
INFO - 2020-10-30 03:22:52 --> Language Class Initialized
INFO - 2020-10-30 03:22:52 --> Language Class Initialized
INFO - 2020-10-30 03:22:52 --> Config Class Initialized
INFO - 2020-10-30 03:22:52 --> Loader Class Initialized
INFO - 2020-10-30 03:22:52 --> Helper loaded: url_helper
INFO - 2020-10-30 03:22:52 --> Helper loaded: file_helper
INFO - 2020-10-30 03:22:52 --> Helper loaded: form_helper
INFO - 2020-10-30 03:22:52 --> Helper loaded: my_helper
INFO - 2020-10-30 03:22:52 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:22:52 --> Controller Class Initialized
DEBUG - 2020-10-30 03:22:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-30 03:22:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:22:52 --> Final output sent to browser
DEBUG - 2020-10-30 03:22:52 --> Total execution time: 0.1889
INFO - 2020-10-30 03:22:52 --> Config Class Initialized
INFO - 2020-10-30 03:22:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:22:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:22:52 --> Utf8 Class Initialized
INFO - 2020-10-30 03:22:52 --> URI Class Initialized
INFO - 2020-10-30 03:22:52 --> Router Class Initialized
INFO - 2020-10-30 03:22:52 --> Output Class Initialized
INFO - 2020-10-30 03:22:52 --> Security Class Initialized
DEBUG - 2020-10-30 03:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:22:52 --> Input Class Initialized
INFO - 2020-10-30 03:22:52 --> Language Class Initialized
INFO - 2020-10-30 03:22:52 --> Language Class Initialized
INFO - 2020-10-30 03:22:52 --> Config Class Initialized
INFO - 2020-10-30 03:22:52 --> Loader Class Initialized
INFO - 2020-10-30 03:22:52 --> Helper loaded: url_helper
INFO - 2020-10-30 03:22:52 --> Helper loaded: file_helper
INFO - 2020-10-30 03:22:52 --> Helper loaded: form_helper
INFO - 2020-10-30 03:22:52 --> Helper loaded: my_helper
INFO - 2020-10-30 03:22:52 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:22:52 --> Controller Class Initialized
INFO - 2020-10-30 03:22:54 --> Config Class Initialized
INFO - 2020-10-30 03:22:54 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:22:54 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:22:54 --> Utf8 Class Initialized
INFO - 2020-10-30 03:22:54 --> URI Class Initialized
INFO - 2020-10-30 03:22:54 --> Router Class Initialized
INFO - 2020-10-30 03:22:54 --> Output Class Initialized
INFO - 2020-10-30 03:22:54 --> Security Class Initialized
DEBUG - 2020-10-30 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:22:54 --> Input Class Initialized
INFO - 2020-10-30 03:22:54 --> Language Class Initialized
INFO - 2020-10-30 03:22:54 --> Language Class Initialized
INFO - 2020-10-30 03:22:54 --> Config Class Initialized
INFO - 2020-10-30 03:22:54 --> Loader Class Initialized
INFO - 2020-10-30 03:22:54 --> Helper loaded: url_helper
INFO - 2020-10-30 03:22:54 --> Helper loaded: file_helper
INFO - 2020-10-30 03:22:54 --> Helper loaded: form_helper
INFO - 2020-10-30 03:22:54 --> Helper loaded: my_helper
INFO - 2020-10-30 03:22:54 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:22:54 --> Controller Class Initialized
INFO - 2020-10-30 03:22:54 --> Final output sent to browser
DEBUG - 2020-10-30 03:22:54 --> Total execution time: 0.1913
INFO - 2020-10-30 03:23:02 --> Config Class Initialized
INFO - 2020-10-30 03:23:02 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:02 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:02 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:02 --> URI Class Initialized
INFO - 2020-10-30 03:23:02 --> Router Class Initialized
INFO - 2020-10-30 03:23:02 --> Output Class Initialized
INFO - 2020-10-30 03:23:02 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:02 --> Input Class Initialized
INFO - 2020-10-30 03:23:02 --> Language Class Initialized
INFO - 2020-10-30 03:23:02 --> Language Class Initialized
INFO - 2020-10-30 03:23:02 --> Config Class Initialized
INFO - 2020-10-30 03:23:02 --> Loader Class Initialized
INFO - 2020-10-30 03:23:02 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:02 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:02 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:02 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:02 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:02 --> Controller Class Initialized
INFO - 2020-10-30 03:23:28 --> Config Class Initialized
INFO - 2020-10-30 03:23:28 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:28 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:28 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:28 --> URI Class Initialized
INFO - 2020-10-30 03:23:28 --> Router Class Initialized
INFO - 2020-10-30 03:23:28 --> Output Class Initialized
INFO - 2020-10-30 03:23:28 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:28 --> Input Class Initialized
INFO - 2020-10-30 03:23:28 --> Language Class Initialized
INFO - 2020-10-30 03:23:28 --> Language Class Initialized
INFO - 2020-10-30 03:23:28 --> Config Class Initialized
INFO - 2020-10-30 03:23:28 --> Loader Class Initialized
INFO - 2020-10-30 03:23:28 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:28 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:28 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:28 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:28 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:28 --> Controller Class Initialized
INFO - 2020-10-30 03:23:28 --> Final output sent to browser
DEBUG - 2020-10-30 03:23:28 --> Total execution time: 0.2939
INFO - 2020-10-30 03:23:31 --> Config Class Initialized
INFO - 2020-10-30 03:23:31 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:31 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:31 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:31 --> URI Class Initialized
INFO - 2020-10-30 03:23:31 --> Router Class Initialized
INFO - 2020-10-30 03:23:31 --> Output Class Initialized
INFO - 2020-10-30 03:23:31 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:31 --> Input Class Initialized
INFO - 2020-10-30 03:23:31 --> Language Class Initialized
INFO - 2020-10-30 03:23:31 --> Language Class Initialized
INFO - 2020-10-30 03:23:31 --> Config Class Initialized
INFO - 2020-10-30 03:23:31 --> Loader Class Initialized
INFO - 2020-10-30 03:23:31 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:31 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:31 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:31 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:31 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:31 --> Controller Class Initialized
DEBUG - 2020-10-30 03:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-30 03:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:23:31 --> Final output sent to browser
DEBUG - 2020-10-30 03:23:31 --> Total execution time: 0.2136
INFO - 2020-10-30 03:23:31 --> Config Class Initialized
INFO - 2020-10-30 03:23:31 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:31 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:31 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:31 --> URI Class Initialized
INFO - 2020-10-30 03:23:31 --> Router Class Initialized
INFO - 2020-10-30 03:23:31 --> Output Class Initialized
INFO - 2020-10-30 03:23:31 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:31 --> Input Class Initialized
INFO - 2020-10-30 03:23:31 --> Language Class Initialized
INFO - 2020-10-30 03:23:31 --> Language Class Initialized
INFO - 2020-10-30 03:23:31 --> Config Class Initialized
INFO - 2020-10-30 03:23:31 --> Loader Class Initialized
INFO - 2020-10-30 03:23:31 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:31 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:31 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:31 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:31 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:31 --> Controller Class Initialized
INFO - 2020-10-30 03:23:33 --> Config Class Initialized
INFO - 2020-10-30 03:23:33 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:33 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:33 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:33 --> URI Class Initialized
INFO - 2020-10-30 03:23:33 --> Router Class Initialized
INFO - 2020-10-30 03:23:33 --> Output Class Initialized
INFO - 2020-10-30 03:23:33 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:33 --> Input Class Initialized
INFO - 2020-10-30 03:23:33 --> Language Class Initialized
INFO - 2020-10-30 03:23:33 --> Language Class Initialized
INFO - 2020-10-30 03:23:33 --> Config Class Initialized
INFO - 2020-10-30 03:23:33 --> Loader Class Initialized
INFO - 2020-10-30 03:23:33 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:33 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:33 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:33 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:33 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:33 --> Controller Class Initialized
INFO - 2020-10-30 03:23:33 --> Final output sent to browser
DEBUG - 2020-10-30 03:23:33 --> Total execution time: 0.2034
INFO - 2020-10-30 03:23:35 --> Config Class Initialized
INFO - 2020-10-30 03:23:35 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:35 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:35 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:35 --> URI Class Initialized
INFO - 2020-10-30 03:23:35 --> Router Class Initialized
INFO - 2020-10-30 03:23:35 --> Output Class Initialized
INFO - 2020-10-30 03:23:35 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:35 --> Input Class Initialized
INFO - 2020-10-30 03:23:35 --> Language Class Initialized
INFO - 2020-10-30 03:23:35 --> Language Class Initialized
INFO - 2020-10-30 03:23:35 --> Config Class Initialized
INFO - 2020-10-30 03:23:35 --> Loader Class Initialized
INFO - 2020-10-30 03:23:35 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:35 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:35 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:35 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:35 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:35 --> Controller Class Initialized
INFO - 2020-10-30 03:23:49 --> Config Class Initialized
INFO - 2020-10-30 03:23:49 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:49 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:49 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:49 --> URI Class Initialized
INFO - 2020-10-30 03:23:49 --> Router Class Initialized
INFO - 2020-10-30 03:23:49 --> Output Class Initialized
INFO - 2020-10-30 03:23:49 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:49 --> Input Class Initialized
INFO - 2020-10-30 03:23:49 --> Language Class Initialized
INFO - 2020-10-30 03:23:49 --> Language Class Initialized
INFO - 2020-10-30 03:23:49 --> Config Class Initialized
INFO - 2020-10-30 03:23:49 --> Loader Class Initialized
INFO - 2020-10-30 03:23:49 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:49 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:49 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:49 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:49 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:49 --> Controller Class Initialized
DEBUG - 2020-10-30 03:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-30 03:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:23:49 --> Final output sent to browser
DEBUG - 2020-10-30 03:23:49 --> Total execution time: 0.2234
INFO - 2020-10-30 03:23:50 --> Config Class Initialized
INFO - 2020-10-30 03:23:50 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:50 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:50 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:50 --> URI Class Initialized
INFO - 2020-10-30 03:23:50 --> Router Class Initialized
INFO - 2020-10-30 03:23:50 --> Output Class Initialized
INFO - 2020-10-30 03:23:50 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:50 --> Input Class Initialized
INFO - 2020-10-30 03:23:50 --> Language Class Initialized
INFO - 2020-10-30 03:23:50 --> Language Class Initialized
INFO - 2020-10-30 03:23:50 --> Config Class Initialized
INFO - 2020-10-30 03:23:50 --> Loader Class Initialized
INFO - 2020-10-30 03:23:50 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:50 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:51 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:51 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:51 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:51 --> Controller Class Initialized
DEBUG - 2020-10-30 03:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-10-30 03:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:23:51 --> Final output sent to browser
DEBUG - 2020-10-30 03:23:51 --> Total execution time: 0.3092
INFO - 2020-10-30 03:23:52 --> Config Class Initialized
INFO - 2020-10-30 03:23:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:52 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:52 --> URI Class Initialized
INFO - 2020-10-30 03:23:52 --> Router Class Initialized
INFO - 2020-10-30 03:23:52 --> Output Class Initialized
INFO - 2020-10-30 03:23:52 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:52 --> Input Class Initialized
INFO - 2020-10-30 03:23:52 --> Language Class Initialized
INFO - 2020-10-30 03:23:52 --> Language Class Initialized
INFO - 2020-10-30 03:23:52 --> Config Class Initialized
INFO - 2020-10-30 03:23:52 --> Loader Class Initialized
INFO - 2020-10-30 03:23:52 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:52 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:52 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:52 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:52 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:52 --> Controller Class Initialized
INFO - 2020-10-30 03:23:52 --> Final output sent to browser
DEBUG - 2020-10-30 03:23:52 --> Total execution time: 0.1984
INFO - 2020-10-30 03:23:58 --> Config Class Initialized
INFO - 2020-10-30 03:23:58 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:23:58 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:23:58 --> Utf8 Class Initialized
INFO - 2020-10-30 03:23:58 --> URI Class Initialized
INFO - 2020-10-30 03:23:58 --> Router Class Initialized
INFO - 2020-10-30 03:23:58 --> Output Class Initialized
INFO - 2020-10-30 03:23:58 --> Security Class Initialized
DEBUG - 2020-10-30 03:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:23:58 --> Input Class Initialized
INFO - 2020-10-30 03:23:58 --> Language Class Initialized
INFO - 2020-10-30 03:23:58 --> Language Class Initialized
INFO - 2020-10-30 03:23:58 --> Config Class Initialized
INFO - 2020-10-30 03:23:58 --> Loader Class Initialized
INFO - 2020-10-30 03:23:58 --> Helper loaded: url_helper
INFO - 2020-10-30 03:23:58 --> Helper loaded: file_helper
INFO - 2020-10-30 03:23:58 --> Helper loaded: form_helper
INFO - 2020-10-30 03:23:58 --> Helper loaded: my_helper
INFO - 2020-10-30 03:23:58 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:23:58 --> Controller Class Initialized
DEBUG - 2020-10-30 03:23:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-30 03:23:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:23:58 --> Final output sent to browser
DEBUG - 2020-10-30 03:23:58 --> Total execution time: 0.2458
INFO - 2020-10-30 03:24:06 --> Config Class Initialized
INFO - 2020-10-30 03:24:06 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:24:06 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:24:06 --> Utf8 Class Initialized
INFO - 2020-10-30 03:24:06 --> URI Class Initialized
INFO - 2020-10-30 03:24:06 --> Router Class Initialized
INFO - 2020-10-30 03:24:06 --> Output Class Initialized
INFO - 2020-10-30 03:24:06 --> Security Class Initialized
DEBUG - 2020-10-30 03:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:24:06 --> Input Class Initialized
INFO - 2020-10-30 03:24:06 --> Language Class Initialized
INFO - 2020-10-30 03:24:06 --> Language Class Initialized
INFO - 2020-10-30 03:24:06 --> Config Class Initialized
INFO - 2020-10-30 03:24:06 --> Loader Class Initialized
INFO - 2020-10-30 03:24:06 --> Helper loaded: url_helper
INFO - 2020-10-30 03:24:06 --> Helper loaded: file_helper
INFO - 2020-10-30 03:24:06 --> Helper loaded: form_helper
INFO - 2020-10-30 03:24:06 --> Helper loaded: my_helper
INFO - 2020-10-30 03:24:06 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:24:07 --> Controller Class Initialized
INFO - 2020-10-30 03:24:07 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:24:07 --> Config Class Initialized
INFO - 2020-10-30 03:24:07 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:24:07 --> Utf8 Class Initialized
INFO - 2020-10-30 03:24:07 --> URI Class Initialized
INFO - 2020-10-30 03:24:07 --> Router Class Initialized
INFO - 2020-10-30 03:24:07 --> Output Class Initialized
INFO - 2020-10-30 03:24:07 --> Security Class Initialized
DEBUG - 2020-10-30 03:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:24:07 --> Input Class Initialized
INFO - 2020-10-30 03:24:07 --> Language Class Initialized
INFO - 2020-10-30 03:24:07 --> Language Class Initialized
INFO - 2020-10-30 03:24:07 --> Config Class Initialized
INFO - 2020-10-30 03:24:07 --> Loader Class Initialized
INFO - 2020-10-30 03:24:07 --> Helper loaded: url_helper
INFO - 2020-10-30 03:24:07 --> Helper loaded: file_helper
INFO - 2020-10-30 03:24:07 --> Helper loaded: form_helper
INFO - 2020-10-30 03:24:07 --> Helper loaded: my_helper
INFO - 2020-10-30 03:24:07 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:24:07 --> Controller Class Initialized
DEBUG - 2020-10-30 03:24:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 03:24:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:24:07 --> Final output sent to browser
DEBUG - 2020-10-30 03:24:07 --> Total execution time: 0.2095
INFO - 2020-10-30 03:24:12 --> Config Class Initialized
INFO - 2020-10-30 03:24:12 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:24:12 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:24:12 --> Utf8 Class Initialized
INFO - 2020-10-30 03:24:12 --> URI Class Initialized
INFO - 2020-10-30 03:24:12 --> Router Class Initialized
INFO - 2020-10-30 03:24:12 --> Output Class Initialized
INFO - 2020-10-30 03:24:12 --> Security Class Initialized
DEBUG - 2020-10-30 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:24:12 --> Input Class Initialized
INFO - 2020-10-30 03:24:12 --> Language Class Initialized
INFO - 2020-10-30 03:24:12 --> Language Class Initialized
INFO - 2020-10-30 03:24:12 --> Config Class Initialized
INFO - 2020-10-30 03:24:12 --> Loader Class Initialized
INFO - 2020-10-30 03:24:12 --> Helper loaded: url_helper
INFO - 2020-10-30 03:24:12 --> Helper loaded: file_helper
INFO - 2020-10-30 03:24:12 --> Helper loaded: form_helper
INFO - 2020-10-30 03:24:12 --> Helper loaded: my_helper
INFO - 2020-10-30 03:24:12 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:24:13 --> Controller Class Initialized
INFO - 2020-10-30 03:24:13 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:24:13 --> Final output sent to browser
DEBUG - 2020-10-30 03:24:13 --> Total execution time: 0.2028
INFO - 2020-10-30 03:24:14 --> Config Class Initialized
INFO - 2020-10-30 03:24:14 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:24:14 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:24:14 --> Utf8 Class Initialized
INFO - 2020-10-30 03:24:14 --> URI Class Initialized
INFO - 2020-10-30 03:24:14 --> Router Class Initialized
INFO - 2020-10-30 03:24:14 --> Output Class Initialized
INFO - 2020-10-30 03:24:14 --> Security Class Initialized
DEBUG - 2020-10-30 03:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:24:14 --> Input Class Initialized
INFO - 2020-10-30 03:24:14 --> Language Class Initialized
INFO - 2020-10-30 03:24:14 --> Language Class Initialized
INFO - 2020-10-30 03:24:14 --> Config Class Initialized
INFO - 2020-10-30 03:24:14 --> Loader Class Initialized
INFO - 2020-10-30 03:24:14 --> Helper loaded: url_helper
INFO - 2020-10-30 03:24:14 --> Helper loaded: file_helper
INFO - 2020-10-30 03:24:14 --> Helper loaded: form_helper
INFO - 2020-10-30 03:24:14 --> Helper loaded: my_helper
INFO - 2020-10-30 03:24:14 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:24:14 --> Controller Class Initialized
DEBUG - 2020-10-30 03:24:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 03:24:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:24:14 --> Final output sent to browser
DEBUG - 2020-10-30 03:24:14 --> Total execution time: 0.2357
INFO - 2020-10-30 03:28:07 --> Config Class Initialized
INFO - 2020-10-30 03:28:07 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:07 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:07 --> URI Class Initialized
INFO - 2020-10-30 03:28:07 --> Router Class Initialized
INFO - 2020-10-30 03:28:07 --> Output Class Initialized
INFO - 2020-10-30 03:28:07 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:07 --> Input Class Initialized
INFO - 2020-10-30 03:28:07 --> Language Class Initialized
INFO - 2020-10-30 03:28:07 --> Language Class Initialized
INFO - 2020-10-30 03:28:07 --> Config Class Initialized
INFO - 2020-10-30 03:28:07 --> Loader Class Initialized
INFO - 2020-10-30 03:28:07 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:07 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:07 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:07 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:07 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:07 --> Controller Class Initialized
DEBUG - 2020-10-30 03:28:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-30 03:28:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:28:07 --> Final output sent to browser
DEBUG - 2020-10-30 03:28:07 --> Total execution time: 0.2531
INFO - 2020-10-30 03:28:08 --> Config Class Initialized
INFO - 2020-10-30 03:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:08 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:08 --> URI Class Initialized
INFO - 2020-10-30 03:28:08 --> Router Class Initialized
INFO - 2020-10-30 03:28:08 --> Output Class Initialized
INFO - 2020-10-30 03:28:08 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:08 --> Input Class Initialized
INFO - 2020-10-30 03:28:08 --> Language Class Initialized
INFO - 2020-10-30 03:28:08 --> Language Class Initialized
INFO - 2020-10-30 03:28:08 --> Config Class Initialized
INFO - 2020-10-30 03:28:08 --> Loader Class Initialized
INFO - 2020-10-30 03:28:08 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:08 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:08 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:08 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:08 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:08 --> Controller Class Initialized
INFO - 2020-10-30 03:28:37 --> Config Class Initialized
INFO - 2020-10-30 03:28:37 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:37 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:37 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:37 --> URI Class Initialized
INFO - 2020-10-30 03:28:37 --> Router Class Initialized
INFO - 2020-10-30 03:28:37 --> Output Class Initialized
INFO - 2020-10-30 03:28:37 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:37 --> Input Class Initialized
INFO - 2020-10-30 03:28:37 --> Language Class Initialized
INFO - 2020-10-30 03:28:37 --> Language Class Initialized
INFO - 2020-10-30 03:28:37 --> Config Class Initialized
INFO - 2020-10-30 03:28:37 --> Loader Class Initialized
INFO - 2020-10-30 03:28:37 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:37 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:37 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:37 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:37 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:37 --> Controller Class Initialized
INFO - 2020-10-30 03:28:39 --> Config Class Initialized
INFO - 2020-10-30 03:28:39 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:39 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:39 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:39 --> URI Class Initialized
INFO - 2020-10-30 03:28:39 --> Router Class Initialized
INFO - 2020-10-30 03:28:39 --> Output Class Initialized
INFO - 2020-10-30 03:28:39 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:39 --> Input Class Initialized
INFO - 2020-10-30 03:28:39 --> Language Class Initialized
INFO - 2020-10-30 03:28:39 --> Language Class Initialized
INFO - 2020-10-30 03:28:39 --> Config Class Initialized
INFO - 2020-10-30 03:28:39 --> Loader Class Initialized
INFO - 2020-10-30 03:28:39 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:39 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:39 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:39 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:39 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:39 --> Controller Class Initialized
INFO - 2020-10-30 03:28:40 --> Config Class Initialized
INFO - 2020-10-30 03:28:40 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:40 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:40 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:40 --> URI Class Initialized
INFO - 2020-10-30 03:28:40 --> Router Class Initialized
INFO - 2020-10-30 03:28:40 --> Output Class Initialized
INFO - 2020-10-30 03:28:40 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:40 --> Input Class Initialized
INFO - 2020-10-30 03:28:40 --> Language Class Initialized
INFO - 2020-10-30 03:28:40 --> Language Class Initialized
INFO - 2020-10-30 03:28:40 --> Config Class Initialized
INFO - 2020-10-30 03:28:40 --> Loader Class Initialized
INFO - 2020-10-30 03:28:41 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:41 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:41 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:41 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:41 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:41 --> Controller Class Initialized
INFO - 2020-10-30 03:28:42 --> Config Class Initialized
INFO - 2020-10-30 03:28:42 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:42 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:42 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:42 --> URI Class Initialized
INFO - 2020-10-30 03:28:42 --> Router Class Initialized
INFO - 2020-10-30 03:28:42 --> Output Class Initialized
INFO - 2020-10-30 03:28:42 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:42 --> Input Class Initialized
INFO - 2020-10-30 03:28:42 --> Language Class Initialized
INFO - 2020-10-30 03:28:42 --> Language Class Initialized
INFO - 2020-10-30 03:28:42 --> Config Class Initialized
INFO - 2020-10-30 03:28:43 --> Loader Class Initialized
INFO - 2020-10-30 03:28:43 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:43 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:43 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:43 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:43 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:43 --> Controller Class Initialized
INFO - 2020-10-30 03:28:43 --> Final output sent to browser
DEBUG - 2020-10-30 03:28:43 --> Total execution time: 0.2475
INFO - 2020-10-30 03:28:43 --> Config Class Initialized
INFO - 2020-10-30 03:28:43 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:43 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:43 --> URI Class Initialized
INFO - 2020-10-30 03:28:43 --> Router Class Initialized
INFO - 2020-10-30 03:28:43 --> Output Class Initialized
INFO - 2020-10-30 03:28:43 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:43 --> Input Class Initialized
INFO - 2020-10-30 03:28:43 --> Language Class Initialized
INFO - 2020-10-30 03:28:43 --> Language Class Initialized
INFO - 2020-10-30 03:28:43 --> Config Class Initialized
INFO - 2020-10-30 03:28:43 --> Loader Class Initialized
INFO - 2020-10-30 03:28:43 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:43 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:43 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:43 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:43 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:43 --> Controller Class Initialized
INFO - 2020-10-30 03:28:44 --> Config Class Initialized
INFO - 2020-10-30 03:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:44 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:44 --> URI Class Initialized
INFO - 2020-10-30 03:28:44 --> Router Class Initialized
INFO - 2020-10-30 03:28:44 --> Output Class Initialized
INFO - 2020-10-30 03:28:44 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:44 --> Input Class Initialized
INFO - 2020-10-30 03:28:44 --> Language Class Initialized
INFO - 2020-10-30 03:28:44 --> Language Class Initialized
INFO - 2020-10-30 03:28:44 --> Config Class Initialized
INFO - 2020-10-30 03:28:44 --> Loader Class Initialized
INFO - 2020-10-30 03:28:44 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:44 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:44 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:44 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:44 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:45 --> Controller Class Initialized
INFO - 2020-10-30 03:28:48 --> Config Class Initialized
INFO - 2020-10-30 03:28:48 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:48 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:48 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:48 --> URI Class Initialized
INFO - 2020-10-30 03:28:48 --> Router Class Initialized
INFO - 2020-10-30 03:28:48 --> Output Class Initialized
INFO - 2020-10-30 03:28:48 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:48 --> Input Class Initialized
INFO - 2020-10-30 03:28:48 --> Language Class Initialized
INFO - 2020-10-30 03:28:48 --> Language Class Initialized
INFO - 2020-10-30 03:28:48 --> Config Class Initialized
INFO - 2020-10-30 03:28:48 --> Loader Class Initialized
INFO - 2020-10-30 03:28:48 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:48 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:48 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:48 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:48 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:48 --> Controller Class Initialized
INFO - 2020-10-30 03:28:48 --> Final output sent to browser
DEBUG - 2020-10-30 03:28:48 --> Total execution time: 0.2565
INFO - 2020-10-30 03:28:48 --> Config Class Initialized
INFO - 2020-10-30 03:28:48 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:28:48 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:28:48 --> Utf8 Class Initialized
INFO - 2020-10-30 03:28:48 --> URI Class Initialized
INFO - 2020-10-30 03:28:48 --> Router Class Initialized
INFO - 2020-10-30 03:28:48 --> Output Class Initialized
INFO - 2020-10-30 03:28:48 --> Security Class Initialized
DEBUG - 2020-10-30 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:28:48 --> Input Class Initialized
INFO - 2020-10-30 03:28:48 --> Language Class Initialized
INFO - 2020-10-30 03:28:48 --> Language Class Initialized
INFO - 2020-10-30 03:28:48 --> Config Class Initialized
INFO - 2020-10-30 03:28:48 --> Loader Class Initialized
INFO - 2020-10-30 03:28:48 --> Helper loaded: url_helper
INFO - 2020-10-30 03:28:48 --> Helper loaded: file_helper
INFO - 2020-10-30 03:28:48 --> Helper loaded: form_helper
INFO - 2020-10-30 03:28:48 --> Helper loaded: my_helper
INFO - 2020-10-30 03:28:48 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:28:48 --> Controller Class Initialized
INFO - 2020-10-30 03:29:04 --> Config Class Initialized
INFO - 2020-10-30 03:29:04 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:29:04 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:29:04 --> Utf8 Class Initialized
INFO - 2020-10-30 03:29:04 --> URI Class Initialized
INFO - 2020-10-30 03:29:04 --> Router Class Initialized
INFO - 2020-10-30 03:29:04 --> Output Class Initialized
INFO - 2020-10-30 03:29:04 --> Security Class Initialized
DEBUG - 2020-10-30 03:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:29:04 --> Input Class Initialized
INFO - 2020-10-30 03:29:04 --> Language Class Initialized
INFO - 2020-10-30 03:29:04 --> Language Class Initialized
INFO - 2020-10-30 03:29:04 --> Config Class Initialized
INFO - 2020-10-30 03:29:04 --> Loader Class Initialized
INFO - 2020-10-30 03:29:04 --> Helper loaded: url_helper
INFO - 2020-10-30 03:29:04 --> Helper loaded: file_helper
INFO - 2020-10-30 03:29:04 --> Helper loaded: form_helper
INFO - 2020-10-30 03:29:04 --> Helper loaded: my_helper
INFO - 2020-10-30 03:29:04 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:29:04 --> Controller Class Initialized
INFO - 2020-10-30 03:29:04 --> Final output sent to browser
DEBUG - 2020-10-30 03:29:04 --> Total execution time: 0.1884
INFO - 2020-10-30 03:29:18 --> Config Class Initialized
INFO - 2020-10-30 03:29:18 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:29:18 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:29:18 --> Utf8 Class Initialized
INFO - 2020-10-30 03:29:18 --> URI Class Initialized
INFO - 2020-10-30 03:29:18 --> Router Class Initialized
INFO - 2020-10-30 03:29:18 --> Output Class Initialized
INFO - 2020-10-30 03:29:18 --> Security Class Initialized
DEBUG - 2020-10-30 03:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:29:18 --> Input Class Initialized
INFO - 2020-10-30 03:29:18 --> Language Class Initialized
INFO - 2020-10-30 03:29:18 --> Language Class Initialized
INFO - 2020-10-30 03:29:18 --> Config Class Initialized
INFO - 2020-10-30 03:29:18 --> Loader Class Initialized
INFO - 2020-10-30 03:29:18 --> Helper loaded: url_helper
INFO - 2020-10-30 03:29:18 --> Helper loaded: file_helper
INFO - 2020-10-30 03:29:18 --> Helper loaded: form_helper
INFO - 2020-10-30 03:29:18 --> Helper loaded: my_helper
INFO - 2020-10-30 03:29:18 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:29:18 --> Controller Class Initialized
INFO - 2020-10-30 03:29:18 --> Final output sent to browser
DEBUG - 2020-10-30 03:29:18 --> Total execution time: 0.2074
INFO - 2020-10-30 03:29:35 --> Config Class Initialized
INFO - 2020-10-30 03:29:35 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:29:35 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:29:35 --> Utf8 Class Initialized
INFO - 2020-10-30 03:29:35 --> URI Class Initialized
INFO - 2020-10-30 03:29:35 --> Router Class Initialized
INFO - 2020-10-30 03:29:35 --> Output Class Initialized
INFO - 2020-10-30 03:29:35 --> Security Class Initialized
DEBUG - 2020-10-30 03:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:29:35 --> Input Class Initialized
INFO - 2020-10-30 03:29:35 --> Language Class Initialized
INFO - 2020-10-30 03:29:35 --> Language Class Initialized
INFO - 2020-10-30 03:29:35 --> Config Class Initialized
INFO - 2020-10-30 03:29:35 --> Loader Class Initialized
INFO - 2020-10-30 03:29:35 --> Helper loaded: url_helper
INFO - 2020-10-30 03:29:35 --> Helper loaded: file_helper
INFO - 2020-10-30 03:29:35 --> Helper loaded: form_helper
INFO - 2020-10-30 03:29:35 --> Helper loaded: my_helper
INFO - 2020-10-30 03:29:35 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:29:35 --> Controller Class Initialized
INFO - 2020-10-30 03:29:35 --> Final output sent to browser
DEBUG - 2020-10-30 03:29:35 --> Total execution time: 0.2272
INFO - 2020-10-30 03:29:35 --> Config Class Initialized
INFO - 2020-10-30 03:29:35 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:29:35 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:29:35 --> Utf8 Class Initialized
INFO - 2020-10-30 03:29:36 --> URI Class Initialized
INFO - 2020-10-30 03:29:36 --> Router Class Initialized
INFO - 2020-10-30 03:29:36 --> Output Class Initialized
INFO - 2020-10-30 03:29:36 --> Security Class Initialized
DEBUG - 2020-10-30 03:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:29:36 --> Input Class Initialized
INFO - 2020-10-30 03:29:36 --> Language Class Initialized
INFO - 2020-10-30 03:29:36 --> Language Class Initialized
INFO - 2020-10-30 03:29:36 --> Config Class Initialized
INFO - 2020-10-30 03:29:36 --> Loader Class Initialized
INFO - 2020-10-30 03:29:36 --> Helper loaded: url_helper
INFO - 2020-10-30 03:29:36 --> Helper loaded: file_helper
INFO - 2020-10-30 03:29:36 --> Helper loaded: form_helper
INFO - 2020-10-30 03:29:36 --> Helper loaded: my_helper
INFO - 2020-10-30 03:29:36 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:29:36 --> Controller Class Initialized
INFO - 2020-10-30 03:30:47 --> Config Class Initialized
INFO - 2020-10-30 03:30:47 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:30:47 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:30:47 --> Utf8 Class Initialized
INFO - 2020-10-30 03:30:47 --> URI Class Initialized
INFO - 2020-10-30 03:30:47 --> Router Class Initialized
INFO - 2020-10-30 03:30:47 --> Output Class Initialized
INFO - 2020-10-30 03:30:47 --> Security Class Initialized
DEBUG - 2020-10-30 03:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:30:47 --> Input Class Initialized
INFO - 2020-10-30 03:30:47 --> Language Class Initialized
INFO - 2020-10-30 03:30:47 --> Language Class Initialized
INFO - 2020-10-30 03:30:47 --> Config Class Initialized
INFO - 2020-10-30 03:30:47 --> Loader Class Initialized
INFO - 2020-10-30 03:30:47 --> Helper loaded: url_helper
INFO - 2020-10-30 03:30:47 --> Helper loaded: file_helper
INFO - 2020-10-30 03:30:47 --> Helper loaded: form_helper
INFO - 2020-10-30 03:30:47 --> Helper loaded: my_helper
INFO - 2020-10-30 03:30:47 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:30:47 --> Controller Class Initialized
INFO - 2020-10-30 03:30:47 --> Final output sent to browser
DEBUG - 2020-10-30 03:30:47 --> Total execution time: 0.1927
INFO - 2020-10-30 03:31:11 --> Config Class Initialized
INFO - 2020-10-30 03:31:11 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:31:11 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:31:11 --> Utf8 Class Initialized
INFO - 2020-10-30 03:31:11 --> URI Class Initialized
INFO - 2020-10-30 03:31:11 --> Router Class Initialized
INFO - 2020-10-30 03:31:11 --> Output Class Initialized
INFO - 2020-10-30 03:31:11 --> Security Class Initialized
DEBUG - 2020-10-30 03:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:31:11 --> Input Class Initialized
INFO - 2020-10-30 03:31:11 --> Language Class Initialized
INFO - 2020-10-30 03:31:11 --> Language Class Initialized
INFO - 2020-10-30 03:31:11 --> Config Class Initialized
INFO - 2020-10-30 03:31:11 --> Loader Class Initialized
INFO - 2020-10-30 03:31:11 --> Helper loaded: url_helper
INFO - 2020-10-30 03:31:11 --> Helper loaded: file_helper
INFO - 2020-10-30 03:31:11 --> Helper loaded: form_helper
INFO - 2020-10-30 03:31:11 --> Helper loaded: my_helper
INFO - 2020-10-30 03:31:11 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:31:11 --> Controller Class Initialized
INFO - 2020-10-30 03:31:11 --> Final output sent to browser
DEBUG - 2020-10-30 03:31:11 --> Total execution time: 0.2132
INFO - 2020-10-30 03:31:11 --> Config Class Initialized
INFO - 2020-10-30 03:31:11 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:31:11 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:31:11 --> Utf8 Class Initialized
INFO - 2020-10-30 03:31:11 --> URI Class Initialized
INFO - 2020-10-30 03:31:11 --> Router Class Initialized
INFO - 2020-10-30 03:31:11 --> Output Class Initialized
INFO - 2020-10-30 03:31:11 --> Security Class Initialized
DEBUG - 2020-10-30 03:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:31:11 --> Input Class Initialized
INFO - 2020-10-30 03:31:11 --> Language Class Initialized
INFO - 2020-10-30 03:31:11 --> Language Class Initialized
INFO - 2020-10-30 03:31:11 --> Config Class Initialized
INFO - 2020-10-30 03:31:11 --> Loader Class Initialized
INFO - 2020-10-30 03:31:11 --> Helper loaded: url_helper
INFO - 2020-10-30 03:31:11 --> Helper loaded: file_helper
INFO - 2020-10-30 03:31:11 --> Helper loaded: form_helper
INFO - 2020-10-30 03:31:11 --> Helper loaded: my_helper
INFO - 2020-10-30 03:31:11 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:31:11 --> Controller Class Initialized
INFO - 2020-10-30 03:31:22 --> Config Class Initialized
INFO - 2020-10-30 03:31:22 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:31:22 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:31:22 --> Utf8 Class Initialized
INFO - 2020-10-30 03:31:22 --> URI Class Initialized
INFO - 2020-10-30 03:31:22 --> Router Class Initialized
INFO - 2020-10-30 03:31:22 --> Output Class Initialized
INFO - 2020-10-30 03:31:22 --> Security Class Initialized
DEBUG - 2020-10-30 03:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:31:22 --> Input Class Initialized
INFO - 2020-10-30 03:31:22 --> Language Class Initialized
INFO - 2020-10-30 03:31:22 --> Language Class Initialized
INFO - 2020-10-30 03:31:22 --> Config Class Initialized
INFO - 2020-10-30 03:31:22 --> Loader Class Initialized
INFO - 2020-10-30 03:31:22 --> Helper loaded: url_helper
INFO - 2020-10-30 03:31:22 --> Helper loaded: file_helper
INFO - 2020-10-30 03:31:22 --> Helper loaded: form_helper
INFO - 2020-10-30 03:31:22 --> Helper loaded: my_helper
INFO - 2020-10-30 03:31:22 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:31:22 --> Controller Class Initialized
INFO - 2020-10-30 03:31:25 --> Config Class Initialized
INFO - 2020-10-30 03:31:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:31:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:31:25 --> Utf8 Class Initialized
INFO - 2020-10-30 03:31:25 --> URI Class Initialized
INFO - 2020-10-30 03:31:25 --> Router Class Initialized
INFO - 2020-10-30 03:31:25 --> Output Class Initialized
INFO - 2020-10-30 03:31:25 --> Security Class Initialized
DEBUG - 2020-10-30 03:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:31:25 --> Input Class Initialized
INFO - 2020-10-30 03:31:25 --> Language Class Initialized
INFO - 2020-10-30 03:31:25 --> Language Class Initialized
INFO - 2020-10-30 03:31:25 --> Config Class Initialized
INFO - 2020-10-30 03:31:25 --> Loader Class Initialized
INFO - 2020-10-30 03:31:25 --> Helper loaded: url_helper
INFO - 2020-10-30 03:31:25 --> Helper loaded: file_helper
INFO - 2020-10-30 03:31:25 --> Helper loaded: form_helper
INFO - 2020-10-30 03:31:25 --> Helper loaded: my_helper
INFO - 2020-10-30 03:31:25 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:31:25 --> Controller Class Initialized
INFO - 2020-10-30 03:31:29 --> Config Class Initialized
INFO - 2020-10-30 03:31:29 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:31:29 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:31:29 --> Utf8 Class Initialized
INFO - 2020-10-30 03:31:29 --> URI Class Initialized
INFO - 2020-10-30 03:31:29 --> Router Class Initialized
INFO - 2020-10-30 03:31:29 --> Output Class Initialized
INFO - 2020-10-30 03:31:29 --> Security Class Initialized
DEBUG - 2020-10-30 03:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:31:29 --> Input Class Initialized
INFO - 2020-10-30 03:31:29 --> Language Class Initialized
INFO - 2020-10-30 03:31:29 --> Language Class Initialized
INFO - 2020-10-30 03:31:29 --> Config Class Initialized
INFO - 2020-10-30 03:31:29 --> Loader Class Initialized
INFO - 2020-10-30 03:31:29 --> Helper loaded: url_helper
INFO - 2020-10-30 03:31:29 --> Helper loaded: file_helper
INFO - 2020-10-30 03:31:29 --> Helper loaded: form_helper
INFO - 2020-10-30 03:31:29 --> Helper loaded: my_helper
INFO - 2020-10-30 03:31:29 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:31:29 --> Controller Class Initialized
INFO - 2020-10-30 03:31:30 --> Final output sent to browser
DEBUG - 2020-10-30 03:31:30 --> Total execution time: 0.2643
INFO - 2020-10-30 03:31:30 --> Config Class Initialized
INFO - 2020-10-30 03:31:30 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:31:30 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:31:30 --> Utf8 Class Initialized
INFO - 2020-10-30 03:31:30 --> URI Class Initialized
INFO - 2020-10-30 03:31:30 --> Router Class Initialized
INFO - 2020-10-30 03:31:30 --> Output Class Initialized
INFO - 2020-10-30 03:31:30 --> Security Class Initialized
DEBUG - 2020-10-30 03:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:31:30 --> Input Class Initialized
INFO - 2020-10-30 03:31:30 --> Language Class Initialized
INFO - 2020-10-30 03:31:30 --> Language Class Initialized
INFO - 2020-10-30 03:31:30 --> Config Class Initialized
INFO - 2020-10-30 03:31:30 --> Loader Class Initialized
INFO - 2020-10-30 03:31:30 --> Helper loaded: url_helper
INFO - 2020-10-30 03:31:30 --> Helper loaded: file_helper
INFO - 2020-10-30 03:31:30 --> Helper loaded: form_helper
INFO - 2020-10-30 03:31:30 --> Helper loaded: my_helper
INFO - 2020-10-30 03:31:30 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:31:30 --> Controller Class Initialized
INFO - 2020-10-30 03:31:31 --> Config Class Initialized
INFO - 2020-10-30 03:31:31 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:31:31 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:31:31 --> Utf8 Class Initialized
INFO - 2020-10-30 03:31:31 --> URI Class Initialized
INFO - 2020-10-30 03:31:31 --> Router Class Initialized
INFO - 2020-10-30 03:31:31 --> Output Class Initialized
INFO - 2020-10-30 03:31:31 --> Security Class Initialized
DEBUG - 2020-10-30 03:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:31:31 --> Input Class Initialized
INFO - 2020-10-30 03:31:31 --> Language Class Initialized
INFO - 2020-10-30 03:31:31 --> Language Class Initialized
INFO - 2020-10-30 03:31:31 --> Config Class Initialized
INFO - 2020-10-30 03:31:31 --> Loader Class Initialized
INFO - 2020-10-30 03:31:31 --> Helper loaded: url_helper
INFO - 2020-10-30 03:31:31 --> Helper loaded: file_helper
INFO - 2020-10-30 03:31:31 --> Helper loaded: form_helper
INFO - 2020-10-30 03:31:31 --> Helper loaded: my_helper
INFO - 2020-10-30 03:31:31 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:31:31 --> Controller Class Initialized
INFO - 2020-10-30 03:31:45 --> Config Class Initialized
INFO - 2020-10-30 03:31:45 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:31:45 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:31:45 --> Utf8 Class Initialized
INFO - 2020-10-30 03:31:45 --> URI Class Initialized
INFO - 2020-10-30 03:31:45 --> Router Class Initialized
INFO - 2020-10-30 03:31:45 --> Output Class Initialized
INFO - 2020-10-30 03:31:45 --> Security Class Initialized
DEBUG - 2020-10-30 03:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:31:45 --> Input Class Initialized
INFO - 2020-10-30 03:31:45 --> Language Class Initialized
INFO - 2020-10-30 03:31:45 --> Language Class Initialized
INFO - 2020-10-30 03:31:45 --> Config Class Initialized
INFO - 2020-10-30 03:31:45 --> Loader Class Initialized
INFO - 2020-10-30 03:31:45 --> Helper loaded: url_helper
INFO - 2020-10-30 03:31:45 --> Helper loaded: file_helper
INFO - 2020-10-30 03:31:45 --> Helper loaded: form_helper
INFO - 2020-10-30 03:31:45 --> Helper loaded: my_helper
INFO - 2020-10-30 03:31:45 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:31:45 --> Controller Class Initialized
INFO - 2020-10-30 03:32:45 --> Config Class Initialized
INFO - 2020-10-30 03:32:45 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:32:45 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:32:45 --> Utf8 Class Initialized
INFO - 2020-10-30 03:32:45 --> URI Class Initialized
INFO - 2020-10-30 03:32:46 --> Router Class Initialized
INFO - 2020-10-30 03:32:46 --> Output Class Initialized
INFO - 2020-10-30 03:32:46 --> Security Class Initialized
DEBUG - 2020-10-30 03:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:32:46 --> Input Class Initialized
INFO - 2020-10-30 03:32:46 --> Language Class Initialized
INFO - 2020-10-30 03:32:46 --> Language Class Initialized
INFO - 2020-10-30 03:32:46 --> Config Class Initialized
INFO - 2020-10-30 03:32:46 --> Loader Class Initialized
INFO - 2020-10-30 03:32:46 --> Helper loaded: url_helper
INFO - 2020-10-30 03:32:46 --> Helper loaded: file_helper
INFO - 2020-10-30 03:32:46 --> Helper loaded: form_helper
INFO - 2020-10-30 03:32:46 --> Helper loaded: my_helper
INFO - 2020-10-30 03:32:46 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:32:46 --> Controller Class Initialized
INFO - 2020-10-30 03:32:46 --> Final output sent to browser
DEBUG - 2020-10-30 03:32:46 --> Total execution time: 0.2070
INFO - 2020-10-30 03:33:06 --> Config Class Initialized
INFO - 2020-10-30 03:33:06 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:33:06 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:33:06 --> Utf8 Class Initialized
INFO - 2020-10-30 03:33:07 --> URI Class Initialized
INFO - 2020-10-30 03:33:07 --> Router Class Initialized
INFO - 2020-10-30 03:33:07 --> Output Class Initialized
INFO - 2020-10-30 03:33:07 --> Security Class Initialized
DEBUG - 2020-10-30 03:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:33:07 --> Input Class Initialized
INFO - 2020-10-30 03:33:07 --> Language Class Initialized
INFO - 2020-10-30 03:33:07 --> Language Class Initialized
INFO - 2020-10-30 03:33:07 --> Config Class Initialized
INFO - 2020-10-30 03:33:07 --> Loader Class Initialized
INFO - 2020-10-30 03:33:07 --> Helper loaded: url_helper
INFO - 2020-10-30 03:33:07 --> Helper loaded: file_helper
INFO - 2020-10-30 03:33:07 --> Helper loaded: form_helper
INFO - 2020-10-30 03:33:07 --> Helper loaded: my_helper
INFO - 2020-10-30 03:33:07 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:33:07 --> Controller Class Initialized
INFO - 2020-10-30 03:33:07 --> Final output sent to browser
DEBUG - 2020-10-30 03:33:07 --> Total execution time: 0.2749
INFO - 2020-10-30 03:33:07 --> Config Class Initialized
INFO - 2020-10-30 03:33:07 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:33:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:33:07 --> Utf8 Class Initialized
INFO - 2020-10-30 03:33:07 --> URI Class Initialized
INFO - 2020-10-30 03:33:07 --> Router Class Initialized
INFO - 2020-10-30 03:33:07 --> Output Class Initialized
INFO - 2020-10-30 03:33:07 --> Security Class Initialized
DEBUG - 2020-10-30 03:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:33:07 --> Input Class Initialized
INFO - 2020-10-30 03:33:07 --> Language Class Initialized
INFO - 2020-10-30 03:33:07 --> Language Class Initialized
INFO - 2020-10-30 03:33:07 --> Config Class Initialized
INFO - 2020-10-30 03:33:07 --> Loader Class Initialized
INFO - 2020-10-30 03:33:07 --> Helper loaded: url_helper
INFO - 2020-10-30 03:33:07 --> Helper loaded: file_helper
INFO - 2020-10-30 03:33:07 --> Helper loaded: form_helper
INFO - 2020-10-30 03:33:07 --> Helper loaded: my_helper
INFO - 2020-10-30 03:33:07 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:33:07 --> Controller Class Initialized
INFO - 2020-10-30 03:33:08 --> Config Class Initialized
INFO - 2020-10-30 03:33:09 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:33:09 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:33:09 --> Utf8 Class Initialized
INFO - 2020-10-30 03:33:09 --> URI Class Initialized
INFO - 2020-10-30 03:33:09 --> Router Class Initialized
INFO - 2020-10-30 03:33:09 --> Output Class Initialized
INFO - 2020-10-30 03:33:09 --> Security Class Initialized
DEBUG - 2020-10-30 03:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:33:09 --> Input Class Initialized
INFO - 2020-10-30 03:33:09 --> Language Class Initialized
INFO - 2020-10-30 03:33:09 --> Language Class Initialized
INFO - 2020-10-30 03:33:09 --> Config Class Initialized
INFO - 2020-10-30 03:33:09 --> Loader Class Initialized
INFO - 2020-10-30 03:33:09 --> Helper loaded: url_helper
INFO - 2020-10-30 03:33:09 --> Helper loaded: file_helper
INFO - 2020-10-30 03:33:09 --> Helper loaded: form_helper
INFO - 2020-10-30 03:33:09 --> Helper loaded: my_helper
INFO - 2020-10-30 03:33:09 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:33:09 --> Controller Class Initialized
INFO - 2020-10-30 03:33:09 --> Final output sent to browser
DEBUG - 2020-10-30 03:33:09 --> Total execution time: 0.2093
INFO - 2020-10-30 03:33:23 --> Config Class Initialized
INFO - 2020-10-30 03:33:23 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:33:23 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:33:23 --> Utf8 Class Initialized
INFO - 2020-10-30 03:33:23 --> URI Class Initialized
INFO - 2020-10-30 03:33:23 --> Router Class Initialized
INFO - 2020-10-30 03:33:23 --> Output Class Initialized
INFO - 2020-10-30 03:33:23 --> Security Class Initialized
DEBUG - 2020-10-30 03:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:33:23 --> Input Class Initialized
INFO - 2020-10-30 03:33:23 --> Language Class Initialized
INFO - 2020-10-30 03:33:23 --> Language Class Initialized
INFO - 2020-10-30 03:33:23 --> Config Class Initialized
INFO - 2020-10-30 03:33:23 --> Loader Class Initialized
INFO - 2020-10-30 03:33:23 --> Helper loaded: url_helper
INFO - 2020-10-30 03:33:23 --> Helper loaded: file_helper
INFO - 2020-10-30 03:33:23 --> Helper loaded: form_helper
INFO - 2020-10-30 03:33:23 --> Helper loaded: my_helper
INFO - 2020-10-30 03:33:23 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:33:23 --> Controller Class Initialized
INFO - 2020-10-30 03:33:23 --> Final output sent to browser
DEBUG - 2020-10-30 03:33:23 --> Total execution time: 0.2370
INFO - 2020-10-30 03:33:23 --> Config Class Initialized
INFO - 2020-10-30 03:33:23 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:33:23 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:33:23 --> Utf8 Class Initialized
INFO - 2020-10-30 03:33:23 --> URI Class Initialized
INFO - 2020-10-30 03:33:23 --> Router Class Initialized
INFO - 2020-10-30 03:33:23 --> Output Class Initialized
INFO - 2020-10-30 03:33:23 --> Security Class Initialized
DEBUG - 2020-10-30 03:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:33:23 --> Input Class Initialized
INFO - 2020-10-30 03:33:23 --> Language Class Initialized
INFO - 2020-10-30 03:33:23 --> Language Class Initialized
INFO - 2020-10-30 03:33:23 --> Config Class Initialized
INFO - 2020-10-30 03:33:23 --> Loader Class Initialized
INFO - 2020-10-30 03:33:23 --> Helper loaded: url_helper
INFO - 2020-10-30 03:33:23 --> Helper loaded: file_helper
INFO - 2020-10-30 03:33:23 --> Helper loaded: form_helper
INFO - 2020-10-30 03:33:23 --> Helper loaded: my_helper
INFO - 2020-10-30 03:33:23 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:33:23 --> Controller Class Initialized
INFO - 2020-10-30 03:33:41 --> Config Class Initialized
INFO - 2020-10-30 03:33:41 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:33:41 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:33:41 --> Utf8 Class Initialized
INFO - 2020-10-30 03:33:41 --> URI Class Initialized
INFO - 2020-10-30 03:33:41 --> Router Class Initialized
INFO - 2020-10-30 03:33:41 --> Output Class Initialized
INFO - 2020-10-30 03:33:41 --> Security Class Initialized
DEBUG - 2020-10-30 03:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:33:41 --> Input Class Initialized
INFO - 2020-10-30 03:33:41 --> Language Class Initialized
INFO - 2020-10-30 03:33:41 --> Language Class Initialized
INFO - 2020-10-30 03:33:41 --> Config Class Initialized
INFO - 2020-10-30 03:33:41 --> Loader Class Initialized
INFO - 2020-10-30 03:33:41 --> Helper loaded: url_helper
INFO - 2020-10-30 03:33:41 --> Helper loaded: file_helper
INFO - 2020-10-30 03:33:41 --> Helper loaded: form_helper
INFO - 2020-10-30 03:33:41 --> Helper loaded: my_helper
INFO - 2020-10-30 03:33:41 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:33:41 --> Controller Class Initialized
INFO - 2020-10-30 03:33:41 --> Final output sent to browser
DEBUG - 2020-10-30 03:33:41 --> Total execution time: 0.2154
INFO - 2020-10-30 03:34:05 --> Config Class Initialized
INFO - 2020-10-30 03:34:05 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:05 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:05 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:05 --> URI Class Initialized
INFO - 2020-10-30 03:34:06 --> Router Class Initialized
INFO - 2020-10-30 03:34:06 --> Output Class Initialized
INFO - 2020-10-30 03:34:06 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:06 --> Input Class Initialized
INFO - 2020-10-30 03:34:06 --> Language Class Initialized
INFO - 2020-10-30 03:34:06 --> Language Class Initialized
INFO - 2020-10-30 03:34:06 --> Config Class Initialized
INFO - 2020-10-30 03:34:06 --> Loader Class Initialized
INFO - 2020-10-30 03:34:06 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:06 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:06 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:06 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:06 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:06 --> Controller Class Initialized
INFO - 2020-10-30 03:34:06 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:06 --> Total execution time: 0.1932
INFO - 2020-10-30 03:34:09 --> Config Class Initialized
INFO - 2020-10-30 03:34:09 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:09 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:09 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:09 --> URI Class Initialized
INFO - 2020-10-30 03:34:09 --> Router Class Initialized
INFO - 2020-10-30 03:34:09 --> Output Class Initialized
INFO - 2020-10-30 03:34:09 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:09 --> Input Class Initialized
INFO - 2020-10-30 03:34:09 --> Language Class Initialized
INFO - 2020-10-30 03:34:09 --> Language Class Initialized
INFO - 2020-10-30 03:34:09 --> Config Class Initialized
INFO - 2020-10-30 03:34:09 --> Loader Class Initialized
INFO - 2020-10-30 03:34:09 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:09 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:09 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:09 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:09 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:09 --> Controller Class Initialized
INFO - 2020-10-30 03:34:09 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:09 --> Total execution time: 0.2057
INFO - 2020-10-30 03:34:11 --> Config Class Initialized
INFO - 2020-10-30 03:34:11 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:11 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:11 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:11 --> URI Class Initialized
INFO - 2020-10-30 03:34:11 --> Router Class Initialized
INFO - 2020-10-30 03:34:11 --> Output Class Initialized
INFO - 2020-10-30 03:34:11 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:11 --> Input Class Initialized
INFO - 2020-10-30 03:34:11 --> Language Class Initialized
INFO - 2020-10-30 03:34:11 --> Language Class Initialized
INFO - 2020-10-30 03:34:11 --> Config Class Initialized
INFO - 2020-10-30 03:34:11 --> Loader Class Initialized
INFO - 2020-10-30 03:34:11 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:11 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:11 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:11 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:11 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:11 --> Controller Class Initialized
INFO - 2020-10-30 03:34:11 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:11 --> Total execution time: 0.2614
INFO - 2020-10-30 03:34:11 --> Config Class Initialized
INFO - 2020-10-30 03:34:11 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:11 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:11 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:12 --> URI Class Initialized
INFO - 2020-10-30 03:34:12 --> Router Class Initialized
INFO - 2020-10-30 03:34:12 --> Output Class Initialized
INFO - 2020-10-30 03:34:12 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:12 --> Input Class Initialized
INFO - 2020-10-30 03:34:12 --> Language Class Initialized
INFO - 2020-10-30 03:34:12 --> Language Class Initialized
INFO - 2020-10-30 03:34:12 --> Config Class Initialized
INFO - 2020-10-30 03:34:12 --> Loader Class Initialized
INFO - 2020-10-30 03:34:12 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:12 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:12 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:12 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:12 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:12 --> Controller Class Initialized
INFO - 2020-10-30 03:34:14 --> Config Class Initialized
INFO - 2020-10-30 03:34:14 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:14 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:14 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:14 --> URI Class Initialized
INFO - 2020-10-30 03:34:14 --> Router Class Initialized
INFO - 2020-10-30 03:34:14 --> Output Class Initialized
INFO - 2020-10-30 03:34:14 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:14 --> Input Class Initialized
INFO - 2020-10-30 03:34:14 --> Language Class Initialized
INFO - 2020-10-30 03:34:14 --> Language Class Initialized
INFO - 2020-10-30 03:34:14 --> Config Class Initialized
INFO - 2020-10-30 03:34:14 --> Loader Class Initialized
INFO - 2020-10-30 03:34:14 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:14 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:14 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:14 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:14 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:14 --> Controller Class Initialized
INFO - 2020-10-30 03:34:14 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:14 --> Total execution time: 0.2035
INFO - 2020-10-30 03:34:18 --> Config Class Initialized
INFO - 2020-10-30 03:34:18 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:18 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:18 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:18 --> URI Class Initialized
INFO - 2020-10-30 03:34:18 --> Router Class Initialized
INFO - 2020-10-30 03:34:18 --> Output Class Initialized
INFO - 2020-10-30 03:34:18 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:18 --> Input Class Initialized
INFO - 2020-10-30 03:34:18 --> Language Class Initialized
INFO - 2020-10-30 03:34:18 --> Language Class Initialized
INFO - 2020-10-30 03:34:18 --> Config Class Initialized
INFO - 2020-10-30 03:34:18 --> Loader Class Initialized
INFO - 2020-10-30 03:34:18 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:18 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:18 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:18 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:18 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:18 --> Controller Class Initialized
INFO - 2020-10-30 03:34:18 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:18 --> Total execution time: 0.2612
INFO - 2020-10-30 03:34:18 --> Config Class Initialized
INFO - 2020-10-30 03:34:18 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:18 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:18 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:18 --> URI Class Initialized
INFO - 2020-10-30 03:34:18 --> Router Class Initialized
INFO - 2020-10-30 03:34:18 --> Output Class Initialized
INFO - 2020-10-30 03:34:18 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:18 --> Input Class Initialized
INFO - 2020-10-30 03:34:18 --> Language Class Initialized
INFO - 2020-10-30 03:34:18 --> Language Class Initialized
INFO - 2020-10-30 03:34:18 --> Config Class Initialized
INFO - 2020-10-30 03:34:18 --> Loader Class Initialized
INFO - 2020-10-30 03:34:18 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:18 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:18 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:18 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:18 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:18 --> Controller Class Initialized
INFO - 2020-10-30 03:34:20 --> Config Class Initialized
INFO - 2020-10-30 03:34:20 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:20 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:20 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:20 --> URI Class Initialized
INFO - 2020-10-30 03:34:20 --> Router Class Initialized
INFO - 2020-10-30 03:34:20 --> Output Class Initialized
INFO - 2020-10-30 03:34:20 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:20 --> Input Class Initialized
INFO - 2020-10-30 03:34:20 --> Language Class Initialized
INFO - 2020-10-30 03:34:20 --> Language Class Initialized
INFO - 2020-10-30 03:34:20 --> Config Class Initialized
INFO - 2020-10-30 03:34:20 --> Loader Class Initialized
INFO - 2020-10-30 03:34:20 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:20 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:20 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:20 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:20 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:20 --> Controller Class Initialized
INFO - 2020-10-30 03:34:20 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:20 --> Total execution time: 0.2023
INFO - 2020-10-30 03:34:23 --> Config Class Initialized
INFO - 2020-10-30 03:34:23 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:23 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:23 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:23 --> URI Class Initialized
INFO - 2020-10-30 03:34:23 --> Router Class Initialized
INFO - 2020-10-30 03:34:23 --> Output Class Initialized
INFO - 2020-10-30 03:34:23 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:23 --> Input Class Initialized
INFO - 2020-10-30 03:34:23 --> Language Class Initialized
INFO - 2020-10-30 03:34:23 --> Language Class Initialized
INFO - 2020-10-30 03:34:23 --> Config Class Initialized
INFO - 2020-10-30 03:34:23 --> Loader Class Initialized
INFO - 2020-10-30 03:34:23 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:23 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:23 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:23 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:23 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:23 --> Controller Class Initialized
INFO - 2020-10-30 03:34:23 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:23 --> Total execution time: 0.2447
INFO - 2020-10-30 03:34:23 --> Config Class Initialized
INFO - 2020-10-30 03:34:23 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:23 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:23 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:23 --> URI Class Initialized
INFO - 2020-10-30 03:34:23 --> Router Class Initialized
INFO - 2020-10-30 03:34:23 --> Output Class Initialized
INFO - 2020-10-30 03:34:23 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:23 --> Input Class Initialized
INFO - 2020-10-30 03:34:23 --> Language Class Initialized
INFO - 2020-10-30 03:34:23 --> Language Class Initialized
INFO - 2020-10-30 03:34:23 --> Config Class Initialized
INFO - 2020-10-30 03:34:23 --> Loader Class Initialized
INFO - 2020-10-30 03:34:23 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:23 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:23 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:23 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:23 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:23 --> Controller Class Initialized
INFO - 2020-10-30 03:34:25 --> Config Class Initialized
INFO - 2020-10-30 03:34:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:25 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:25 --> URI Class Initialized
INFO - 2020-10-30 03:34:25 --> Router Class Initialized
INFO - 2020-10-30 03:34:25 --> Output Class Initialized
INFO - 2020-10-30 03:34:25 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:25 --> Input Class Initialized
INFO - 2020-10-30 03:34:25 --> Language Class Initialized
INFO - 2020-10-30 03:34:25 --> Language Class Initialized
INFO - 2020-10-30 03:34:25 --> Config Class Initialized
INFO - 2020-10-30 03:34:25 --> Loader Class Initialized
INFO - 2020-10-30 03:34:25 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:25 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:25 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:25 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:25 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:25 --> Controller Class Initialized
INFO - 2020-10-30 03:34:25 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:25 --> Total execution time: 0.2123
INFO - 2020-10-30 03:34:28 --> Config Class Initialized
INFO - 2020-10-30 03:34:28 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:28 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:28 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:28 --> URI Class Initialized
INFO - 2020-10-30 03:34:28 --> Router Class Initialized
INFO - 2020-10-30 03:34:28 --> Output Class Initialized
INFO - 2020-10-30 03:34:28 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:28 --> Input Class Initialized
INFO - 2020-10-30 03:34:28 --> Language Class Initialized
INFO - 2020-10-30 03:34:28 --> Language Class Initialized
INFO - 2020-10-30 03:34:28 --> Config Class Initialized
INFO - 2020-10-30 03:34:28 --> Loader Class Initialized
INFO - 2020-10-30 03:34:28 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:28 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:28 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:28 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:28 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:28 --> Controller Class Initialized
INFO - 2020-10-30 03:34:28 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:28 --> Total execution time: 0.2384
INFO - 2020-10-30 03:34:28 --> Config Class Initialized
INFO - 2020-10-30 03:34:28 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:28 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:28 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:28 --> URI Class Initialized
INFO - 2020-10-30 03:34:28 --> Router Class Initialized
INFO - 2020-10-30 03:34:28 --> Output Class Initialized
INFO - 2020-10-30 03:34:28 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:28 --> Input Class Initialized
INFO - 2020-10-30 03:34:28 --> Language Class Initialized
INFO - 2020-10-30 03:34:28 --> Language Class Initialized
INFO - 2020-10-30 03:34:28 --> Config Class Initialized
INFO - 2020-10-30 03:34:28 --> Loader Class Initialized
INFO - 2020-10-30 03:34:28 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:28 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:28 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:28 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:28 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:28 --> Controller Class Initialized
INFO - 2020-10-30 03:34:30 --> Config Class Initialized
INFO - 2020-10-30 03:34:30 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:30 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:30 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:30 --> URI Class Initialized
INFO - 2020-10-30 03:34:30 --> Router Class Initialized
INFO - 2020-10-30 03:34:30 --> Output Class Initialized
INFO - 2020-10-30 03:34:30 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:30 --> Input Class Initialized
INFO - 2020-10-30 03:34:30 --> Language Class Initialized
INFO - 2020-10-30 03:34:30 --> Language Class Initialized
INFO - 2020-10-30 03:34:30 --> Config Class Initialized
INFO - 2020-10-30 03:34:30 --> Loader Class Initialized
INFO - 2020-10-30 03:34:30 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:30 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:30 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:30 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:30 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:30 --> Controller Class Initialized
INFO - 2020-10-30 03:34:30 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:30 --> Total execution time: 0.2044
INFO - 2020-10-30 03:34:32 --> Config Class Initialized
INFO - 2020-10-30 03:34:32 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:32 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:32 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:32 --> URI Class Initialized
INFO - 2020-10-30 03:34:32 --> Router Class Initialized
INFO - 2020-10-30 03:34:32 --> Output Class Initialized
INFO - 2020-10-30 03:34:32 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:32 --> Input Class Initialized
INFO - 2020-10-30 03:34:32 --> Language Class Initialized
INFO - 2020-10-30 03:34:32 --> Language Class Initialized
INFO - 2020-10-30 03:34:32 --> Config Class Initialized
INFO - 2020-10-30 03:34:32 --> Loader Class Initialized
INFO - 2020-10-30 03:34:32 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:32 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:32 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:32 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:32 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:32 --> Controller Class Initialized
INFO - 2020-10-30 03:34:32 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:32 --> Total execution time: 0.2555
INFO - 2020-10-30 03:34:32 --> Config Class Initialized
INFO - 2020-10-30 03:34:32 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:32 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:32 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:33 --> URI Class Initialized
INFO - 2020-10-30 03:34:33 --> Router Class Initialized
INFO - 2020-10-30 03:34:33 --> Output Class Initialized
INFO - 2020-10-30 03:34:33 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:33 --> Input Class Initialized
INFO - 2020-10-30 03:34:33 --> Language Class Initialized
INFO - 2020-10-30 03:34:33 --> Language Class Initialized
INFO - 2020-10-30 03:34:33 --> Config Class Initialized
INFO - 2020-10-30 03:34:33 --> Loader Class Initialized
INFO - 2020-10-30 03:34:33 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:33 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:33 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:33 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:33 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:33 --> Controller Class Initialized
INFO - 2020-10-30 03:34:34 --> Config Class Initialized
INFO - 2020-10-30 03:34:34 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:34 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:34 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:34 --> URI Class Initialized
INFO - 2020-10-30 03:34:34 --> Router Class Initialized
INFO - 2020-10-30 03:34:34 --> Output Class Initialized
INFO - 2020-10-30 03:34:34 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:34 --> Input Class Initialized
INFO - 2020-10-30 03:34:34 --> Language Class Initialized
INFO - 2020-10-30 03:34:34 --> Language Class Initialized
INFO - 2020-10-30 03:34:34 --> Config Class Initialized
INFO - 2020-10-30 03:34:34 --> Loader Class Initialized
INFO - 2020-10-30 03:34:34 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:34 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:34 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:34 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:34 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:34 --> Controller Class Initialized
INFO - 2020-10-30 03:34:34 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:34 --> Total execution time: 0.2119
INFO - 2020-10-30 03:34:36 --> Config Class Initialized
INFO - 2020-10-30 03:34:36 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:36 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:36 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:36 --> URI Class Initialized
INFO - 2020-10-30 03:34:36 --> Router Class Initialized
INFO - 2020-10-30 03:34:36 --> Output Class Initialized
INFO - 2020-10-30 03:34:36 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:36 --> Input Class Initialized
INFO - 2020-10-30 03:34:36 --> Language Class Initialized
INFO - 2020-10-30 03:34:36 --> Language Class Initialized
INFO - 2020-10-30 03:34:36 --> Config Class Initialized
INFO - 2020-10-30 03:34:36 --> Loader Class Initialized
INFO - 2020-10-30 03:34:36 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:36 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:36 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:36 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:36 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:36 --> Controller Class Initialized
INFO - 2020-10-30 03:34:36 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:36 --> Total execution time: 0.2473
INFO - 2020-10-30 03:34:36 --> Config Class Initialized
INFO - 2020-10-30 03:34:36 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:36 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:36 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:36 --> URI Class Initialized
INFO - 2020-10-30 03:34:36 --> Router Class Initialized
INFO - 2020-10-30 03:34:36 --> Output Class Initialized
INFO - 2020-10-30 03:34:36 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:36 --> Input Class Initialized
INFO - 2020-10-30 03:34:36 --> Language Class Initialized
INFO - 2020-10-30 03:34:36 --> Language Class Initialized
INFO - 2020-10-30 03:34:36 --> Config Class Initialized
INFO - 2020-10-30 03:34:36 --> Loader Class Initialized
INFO - 2020-10-30 03:34:36 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:36 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:36 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:36 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:36 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:36 --> Controller Class Initialized
INFO - 2020-10-30 03:34:38 --> Config Class Initialized
INFO - 2020-10-30 03:34:38 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:38 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:38 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:38 --> URI Class Initialized
INFO - 2020-10-30 03:34:38 --> Router Class Initialized
INFO - 2020-10-30 03:34:38 --> Output Class Initialized
INFO - 2020-10-30 03:34:38 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:38 --> Input Class Initialized
INFO - 2020-10-30 03:34:38 --> Language Class Initialized
INFO - 2020-10-30 03:34:38 --> Language Class Initialized
INFO - 2020-10-30 03:34:38 --> Config Class Initialized
INFO - 2020-10-30 03:34:38 --> Loader Class Initialized
INFO - 2020-10-30 03:34:38 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:38 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:38 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:38 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:38 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:38 --> Controller Class Initialized
INFO - 2020-10-30 03:34:38 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:38 --> Total execution time: 0.2266
INFO - 2020-10-30 03:34:40 --> Config Class Initialized
INFO - 2020-10-30 03:34:40 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:40 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:40 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:40 --> URI Class Initialized
INFO - 2020-10-30 03:34:40 --> Router Class Initialized
INFO - 2020-10-30 03:34:40 --> Output Class Initialized
INFO - 2020-10-30 03:34:40 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:40 --> Input Class Initialized
INFO - 2020-10-30 03:34:40 --> Language Class Initialized
INFO - 2020-10-30 03:34:40 --> Language Class Initialized
INFO - 2020-10-30 03:34:40 --> Config Class Initialized
INFO - 2020-10-30 03:34:40 --> Loader Class Initialized
INFO - 2020-10-30 03:34:40 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:40 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:40 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:40 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:40 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:40 --> Controller Class Initialized
INFO - 2020-10-30 03:34:40 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:40 --> Total execution time: 0.2517
INFO - 2020-10-30 03:34:40 --> Config Class Initialized
INFO - 2020-10-30 03:34:40 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:40 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:41 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:41 --> URI Class Initialized
INFO - 2020-10-30 03:34:41 --> Router Class Initialized
INFO - 2020-10-30 03:34:41 --> Output Class Initialized
INFO - 2020-10-30 03:34:41 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:41 --> Input Class Initialized
INFO - 2020-10-30 03:34:41 --> Language Class Initialized
INFO - 2020-10-30 03:34:41 --> Language Class Initialized
INFO - 2020-10-30 03:34:41 --> Config Class Initialized
INFO - 2020-10-30 03:34:41 --> Loader Class Initialized
INFO - 2020-10-30 03:34:41 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:41 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:41 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:41 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:41 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:41 --> Controller Class Initialized
INFO - 2020-10-30 03:34:42 --> Config Class Initialized
INFO - 2020-10-30 03:34:42 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:42 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:42 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:42 --> URI Class Initialized
INFO - 2020-10-30 03:34:42 --> Router Class Initialized
INFO - 2020-10-30 03:34:42 --> Output Class Initialized
INFO - 2020-10-30 03:34:42 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:42 --> Input Class Initialized
INFO - 2020-10-30 03:34:42 --> Language Class Initialized
INFO - 2020-10-30 03:34:42 --> Language Class Initialized
INFO - 2020-10-30 03:34:42 --> Config Class Initialized
INFO - 2020-10-30 03:34:42 --> Loader Class Initialized
INFO - 2020-10-30 03:34:42 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:42 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:42 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:42 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:42 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:42 --> Controller Class Initialized
INFO - 2020-10-30 03:34:42 --> Config Class Initialized
INFO - 2020-10-30 03:34:42 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:42 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:42 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:42 --> URI Class Initialized
INFO - 2020-10-30 03:34:42 --> Router Class Initialized
INFO - 2020-10-30 03:34:42 --> Output Class Initialized
INFO - 2020-10-30 03:34:42 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:42 --> Input Class Initialized
INFO - 2020-10-30 03:34:42 --> Language Class Initialized
INFO - 2020-10-30 03:34:42 --> Language Class Initialized
INFO - 2020-10-30 03:34:42 --> Config Class Initialized
INFO - 2020-10-30 03:34:42 --> Loader Class Initialized
INFO - 2020-10-30 03:34:42 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:42 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:43 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:43 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:43 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:43 --> Controller Class Initialized
INFO - 2020-10-30 03:34:45 --> Config Class Initialized
INFO - 2020-10-30 03:34:45 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:45 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:45 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:45 --> URI Class Initialized
INFO - 2020-10-30 03:34:45 --> Router Class Initialized
INFO - 2020-10-30 03:34:45 --> Output Class Initialized
INFO - 2020-10-30 03:34:45 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:45 --> Input Class Initialized
INFO - 2020-10-30 03:34:45 --> Language Class Initialized
INFO - 2020-10-30 03:34:45 --> Language Class Initialized
INFO - 2020-10-30 03:34:45 --> Config Class Initialized
INFO - 2020-10-30 03:34:45 --> Loader Class Initialized
INFO - 2020-10-30 03:34:45 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:45 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:45 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:45 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:45 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:45 --> Controller Class Initialized
INFO - 2020-10-30 03:34:45 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:45 --> Total execution time: 0.1995
INFO - 2020-10-30 03:34:47 --> Config Class Initialized
INFO - 2020-10-30 03:34:47 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:47 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:47 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:47 --> URI Class Initialized
INFO - 2020-10-30 03:34:47 --> Router Class Initialized
INFO - 2020-10-30 03:34:47 --> Output Class Initialized
INFO - 2020-10-30 03:34:47 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:47 --> Input Class Initialized
INFO - 2020-10-30 03:34:47 --> Language Class Initialized
INFO - 2020-10-30 03:34:47 --> Language Class Initialized
INFO - 2020-10-30 03:34:47 --> Config Class Initialized
INFO - 2020-10-30 03:34:47 --> Loader Class Initialized
INFO - 2020-10-30 03:34:47 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:47 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:47 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:47 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:47 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:47 --> Controller Class Initialized
INFO - 2020-10-30 03:34:47 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:47 --> Total execution time: 0.2475
INFO - 2020-10-30 03:34:47 --> Config Class Initialized
INFO - 2020-10-30 03:34:47 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:47 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:47 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:47 --> URI Class Initialized
INFO - 2020-10-30 03:34:47 --> Router Class Initialized
INFO - 2020-10-30 03:34:47 --> Output Class Initialized
INFO - 2020-10-30 03:34:47 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:47 --> Input Class Initialized
INFO - 2020-10-30 03:34:47 --> Language Class Initialized
INFO - 2020-10-30 03:34:47 --> Language Class Initialized
INFO - 2020-10-30 03:34:47 --> Config Class Initialized
INFO - 2020-10-30 03:34:47 --> Loader Class Initialized
INFO - 2020-10-30 03:34:47 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:47 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:47 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:47 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:47 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:47 --> Controller Class Initialized
INFO - 2020-10-30 03:34:49 --> Config Class Initialized
INFO - 2020-10-30 03:34:49 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:49 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:49 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:49 --> URI Class Initialized
INFO - 2020-10-30 03:34:49 --> Router Class Initialized
INFO - 2020-10-30 03:34:49 --> Output Class Initialized
INFO - 2020-10-30 03:34:49 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:49 --> Input Class Initialized
INFO - 2020-10-30 03:34:49 --> Language Class Initialized
INFO - 2020-10-30 03:34:49 --> Language Class Initialized
INFO - 2020-10-30 03:34:49 --> Config Class Initialized
INFO - 2020-10-30 03:34:49 --> Loader Class Initialized
INFO - 2020-10-30 03:34:49 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:49 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:49 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:49 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:49 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:49 --> Controller Class Initialized
INFO - 2020-10-30 03:34:50 --> Config Class Initialized
INFO - 2020-10-30 03:34:50 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:50 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:50 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:50 --> URI Class Initialized
INFO - 2020-10-30 03:34:50 --> Router Class Initialized
INFO - 2020-10-30 03:34:50 --> Output Class Initialized
INFO - 2020-10-30 03:34:50 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:50 --> Input Class Initialized
INFO - 2020-10-30 03:34:50 --> Language Class Initialized
INFO - 2020-10-30 03:34:50 --> Language Class Initialized
INFO - 2020-10-30 03:34:50 --> Config Class Initialized
INFO - 2020-10-30 03:34:50 --> Loader Class Initialized
INFO - 2020-10-30 03:34:50 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:50 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:50 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:50 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:50 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:50 --> Controller Class Initialized
INFO - 2020-10-30 03:34:50 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:50 --> Total execution time: 0.2097
INFO - 2020-10-30 03:34:53 --> Config Class Initialized
INFO - 2020-10-30 03:34:53 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:53 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:53 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:53 --> URI Class Initialized
INFO - 2020-10-30 03:34:53 --> Router Class Initialized
INFO - 2020-10-30 03:34:53 --> Output Class Initialized
INFO - 2020-10-30 03:34:53 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:53 --> Input Class Initialized
INFO - 2020-10-30 03:34:53 --> Language Class Initialized
INFO - 2020-10-30 03:34:53 --> Language Class Initialized
INFO - 2020-10-30 03:34:53 --> Config Class Initialized
INFO - 2020-10-30 03:34:53 --> Loader Class Initialized
INFO - 2020-10-30 03:34:53 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:53 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:53 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:53 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:53 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:53 --> Controller Class Initialized
INFO - 2020-10-30 03:34:53 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:53 --> Total execution time: 0.2578
INFO - 2020-10-30 03:34:53 --> Config Class Initialized
INFO - 2020-10-30 03:34:53 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:53 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:53 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:53 --> URI Class Initialized
INFO - 2020-10-30 03:34:53 --> Router Class Initialized
INFO - 2020-10-30 03:34:53 --> Output Class Initialized
INFO - 2020-10-30 03:34:53 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:53 --> Input Class Initialized
INFO - 2020-10-30 03:34:53 --> Language Class Initialized
INFO - 2020-10-30 03:34:53 --> Language Class Initialized
INFO - 2020-10-30 03:34:53 --> Config Class Initialized
INFO - 2020-10-30 03:34:53 --> Loader Class Initialized
INFO - 2020-10-30 03:34:53 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:53 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:53 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:53 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:53 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:53 --> Controller Class Initialized
INFO - 2020-10-30 03:34:55 --> Config Class Initialized
INFO - 2020-10-30 03:34:55 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:55 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:55 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:55 --> URI Class Initialized
INFO - 2020-10-30 03:34:55 --> Router Class Initialized
INFO - 2020-10-30 03:34:55 --> Output Class Initialized
INFO - 2020-10-30 03:34:55 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:55 --> Input Class Initialized
INFO - 2020-10-30 03:34:55 --> Language Class Initialized
INFO - 2020-10-30 03:34:55 --> Language Class Initialized
INFO - 2020-10-30 03:34:55 --> Config Class Initialized
INFO - 2020-10-30 03:34:55 --> Loader Class Initialized
INFO - 2020-10-30 03:34:55 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:55 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:55 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:55 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:55 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:55 --> Controller Class Initialized
INFO - 2020-10-30 03:34:56 --> Config Class Initialized
INFO - 2020-10-30 03:34:56 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:34:56 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:34:56 --> Utf8 Class Initialized
INFO - 2020-10-30 03:34:56 --> URI Class Initialized
INFO - 2020-10-30 03:34:56 --> Router Class Initialized
INFO - 2020-10-30 03:34:56 --> Output Class Initialized
INFO - 2020-10-30 03:34:56 --> Security Class Initialized
DEBUG - 2020-10-30 03:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:34:56 --> Input Class Initialized
INFO - 2020-10-30 03:34:56 --> Language Class Initialized
INFO - 2020-10-30 03:34:56 --> Language Class Initialized
INFO - 2020-10-30 03:34:56 --> Config Class Initialized
INFO - 2020-10-30 03:34:56 --> Loader Class Initialized
INFO - 2020-10-30 03:34:56 --> Helper loaded: url_helper
INFO - 2020-10-30 03:34:56 --> Helper loaded: file_helper
INFO - 2020-10-30 03:34:56 --> Helper loaded: form_helper
INFO - 2020-10-30 03:34:56 --> Helper loaded: my_helper
INFO - 2020-10-30 03:34:56 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:34:56 --> Controller Class Initialized
INFO - 2020-10-30 03:34:56 --> Final output sent to browser
DEBUG - 2020-10-30 03:34:56 --> Total execution time: 0.2127
INFO - 2020-10-30 03:35:00 --> Config Class Initialized
INFO - 2020-10-30 03:35:00 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:35:00 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:35:00 --> Utf8 Class Initialized
INFO - 2020-10-30 03:35:00 --> URI Class Initialized
INFO - 2020-10-30 03:35:00 --> Router Class Initialized
INFO - 2020-10-30 03:35:00 --> Output Class Initialized
INFO - 2020-10-30 03:35:00 --> Security Class Initialized
DEBUG - 2020-10-30 03:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:35:00 --> Input Class Initialized
INFO - 2020-10-30 03:35:00 --> Language Class Initialized
INFO - 2020-10-30 03:35:00 --> Language Class Initialized
INFO - 2020-10-30 03:35:00 --> Config Class Initialized
INFO - 2020-10-30 03:35:00 --> Loader Class Initialized
INFO - 2020-10-30 03:35:00 --> Helper loaded: url_helper
INFO - 2020-10-30 03:35:00 --> Helper loaded: file_helper
INFO - 2020-10-30 03:35:00 --> Helper loaded: form_helper
INFO - 2020-10-30 03:35:00 --> Helper loaded: my_helper
INFO - 2020-10-30 03:35:00 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:35:00 --> Controller Class Initialized
INFO - 2020-10-30 03:35:25 --> Config Class Initialized
INFO - 2020-10-30 03:35:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:35:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:35:25 --> Utf8 Class Initialized
INFO - 2020-10-30 03:35:25 --> URI Class Initialized
INFO - 2020-10-30 03:35:25 --> Router Class Initialized
INFO - 2020-10-30 03:35:25 --> Output Class Initialized
INFO - 2020-10-30 03:35:25 --> Security Class Initialized
DEBUG - 2020-10-30 03:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:35:25 --> Input Class Initialized
INFO - 2020-10-30 03:35:25 --> Language Class Initialized
INFO - 2020-10-30 03:35:25 --> Language Class Initialized
INFO - 2020-10-30 03:35:25 --> Config Class Initialized
INFO - 2020-10-30 03:35:25 --> Loader Class Initialized
INFO - 2020-10-30 03:35:25 --> Helper loaded: url_helper
INFO - 2020-10-30 03:35:26 --> Helper loaded: file_helper
INFO - 2020-10-30 03:35:26 --> Helper loaded: form_helper
INFO - 2020-10-30 03:35:26 --> Helper loaded: my_helper
INFO - 2020-10-30 03:35:26 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:35:26 --> Controller Class Initialized
INFO - 2020-10-30 03:35:26 --> Final output sent to browser
DEBUG - 2020-10-30 03:35:26 --> Total execution time: 0.1983
INFO - 2020-10-30 03:36:48 --> Config Class Initialized
INFO - 2020-10-30 03:36:48 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:36:48 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:36:48 --> Utf8 Class Initialized
INFO - 2020-10-30 03:36:48 --> URI Class Initialized
INFO - 2020-10-30 03:36:48 --> Router Class Initialized
INFO - 2020-10-30 03:36:48 --> Output Class Initialized
INFO - 2020-10-30 03:36:48 --> Security Class Initialized
DEBUG - 2020-10-30 03:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:36:48 --> Input Class Initialized
INFO - 2020-10-30 03:36:48 --> Language Class Initialized
INFO - 2020-10-30 03:36:48 --> Language Class Initialized
INFO - 2020-10-30 03:36:48 --> Config Class Initialized
INFO - 2020-10-30 03:36:48 --> Loader Class Initialized
INFO - 2020-10-30 03:36:48 --> Helper loaded: url_helper
INFO - 2020-10-30 03:36:48 --> Helper loaded: file_helper
INFO - 2020-10-30 03:36:48 --> Helper loaded: form_helper
INFO - 2020-10-30 03:36:48 --> Helper loaded: my_helper
INFO - 2020-10-30 03:36:48 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:36:48 --> Controller Class Initialized
INFO - 2020-10-30 03:36:48 --> Final output sent to browser
DEBUG - 2020-10-30 03:36:48 --> Total execution time: 0.2200
INFO - 2020-10-30 03:47:28 --> Config Class Initialized
INFO - 2020-10-30 03:47:28 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:47:28 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:47:28 --> Utf8 Class Initialized
INFO - 2020-10-30 03:47:28 --> URI Class Initialized
INFO - 2020-10-30 03:47:28 --> Router Class Initialized
INFO - 2020-10-30 03:47:28 --> Output Class Initialized
INFO - 2020-10-30 03:47:28 --> Security Class Initialized
DEBUG - 2020-10-30 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:47:28 --> Input Class Initialized
INFO - 2020-10-30 03:47:28 --> Language Class Initialized
INFO - 2020-10-30 03:47:28 --> Language Class Initialized
INFO - 2020-10-30 03:47:28 --> Config Class Initialized
INFO - 2020-10-30 03:47:28 --> Loader Class Initialized
INFO - 2020-10-30 03:47:28 --> Helper loaded: url_helper
INFO - 2020-10-30 03:47:28 --> Helper loaded: file_helper
INFO - 2020-10-30 03:47:28 --> Helper loaded: form_helper
INFO - 2020-10-30 03:47:28 --> Helper loaded: my_helper
INFO - 2020-10-30 03:47:28 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:47:28 --> Controller Class Initialized
DEBUG - 2020-10-30 03:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-30 03:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:47:28 --> Final output sent to browser
DEBUG - 2020-10-30 03:47:28 --> Total execution time: 0.2906
INFO - 2020-10-30 03:47:28 --> Config Class Initialized
INFO - 2020-10-30 03:47:28 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:47:28 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:47:28 --> Utf8 Class Initialized
INFO - 2020-10-30 03:47:28 --> URI Class Initialized
INFO - 2020-10-30 03:47:28 --> Router Class Initialized
INFO - 2020-10-30 03:47:28 --> Output Class Initialized
INFO - 2020-10-30 03:47:28 --> Security Class Initialized
DEBUG - 2020-10-30 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:47:28 --> Input Class Initialized
INFO - 2020-10-30 03:47:28 --> Language Class Initialized
INFO - 2020-10-30 03:47:28 --> Language Class Initialized
INFO - 2020-10-30 03:47:28 --> Config Class Initialized
INFO - 2020-10-30 03:47:28 --> Loader Class Initialized
INFO - 2020-10-30 03:47:28 --> Helper loaded: url_helper
INFO - 2020-10-30 03:47:28 --> Helper loaded: file_helper
INFO - 2020-10-30 03:47:28 --> Helper loaded: form_helper
INFO - 2020-10-30 03:47:28 --> Helper loaded: my_helper
INFO - 2020-10-30 03:47:28 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:47:28 --> Controller Class Initialized
INFO - 2020-10-30 03:47:35 --> Config Class Initialized
INFO - 2020-10-30 03:47:35 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:47:35 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:47:35 --> Utf8 Class Initialized
INFO - 2020-10-30 03:47:35 --> URI Class Initialized
INFO - 2020-10-30 03:47:35 --> Router Class Initialized
INFO - 2020-10-30 03:47:35 --> Output Class Initialized
INFO - 2020-10-30 03:47:35 --> Security Class Initialized
DEBUG - 2020-10-30 03:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:47:35 --> Input Class Initialized
INFO - 2020-10-30 03:47:35 --> Language Class Initialized
INFO - 2020-10-30 03:47:35 --> Language Class Initialized
INFO - 2020-10-30 03:47:35 --> Config Class Initialized
INFO - 2020-10-30 03:47:35 --> Loader Class Initialized
INFO - 2020-10-30 03:47:35 --> Helper loaded: url_helper
INFO - 2020-10-30 03:47:35 --> Helper loaded: file_helper
INFO - 2020-10-30 03:47:35 --> Helper loaded: form_helper
INFO - 2020-10-30 03:47:35 --> Helper loaded: my_helper
INFO - 2020-10-30 03:47:35 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:47:35 --> Controller Class Initialized
ERROR - 2020-10-30 03:47:35 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-30 03:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-30 03:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:47:35 --> Final output sent to browser
DEBUG - 2020-10-30 03:47:35 --> Total execution time: 0.2931
INFO - 2020-10-30 03:50:37 --> Config Class Initialized
INFO - 2020-10-30 03:50:37 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:50:38 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:50:38 --> Utf8 Class Initialized
INFO - 2020-10-30 03:50:38 --> URI Class Initialized
INFO - 2020-10-30 03:50:38 --> Router Class Initialized
INFO - 2020-10-30 03:50:38 --> Output Class Initialized
INFO - 2020-10-30 03:50:38 --> Security Class Initialized
DEBUG - 2020-10-30 03:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:50:38 --> Input Class Initialized
INFO - 2020-10-30 03:50:38 --> Language Class Initialized
INFO - 2020-10-30 03:50:38 --> Language Class Initialized
INFO - 2020-10-30 03:50:38 --> Config Class Initialized
INFO - 2020-10-30 03:50:38 --> Loader Class Initialized
INFO - 2020-10-30 03:50:38 --> Helper loaded: url_helper
INFO - 2020-10-30 03:50:38 --> Helper loaded: file_helper
INFO - 2020-10-30 03:50:38 --> Helper loaded: form_helper
INFO - 2020-10-30 03:50:38 --> Helper loaded: my_helper
INFO - 2020-10-30 03:50:38 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:50:38 --> Controller Class Initialized
DEBUG - 2020-10-30 03:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-30 03:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:50:38 --> Final output sent to browser
DEBUG - 2020-10-30 03:50:38 --> Total execution time: 0.2455
INFO - 2020-10-30 03:50:38 --> Config Class Initialized
INFO - 2020-10-30 03:50:38 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:50:38 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:50:38 --> Utf8 Class Initialized
INFO - 2020-10-30 03:50:38 --> URI Class Initialized
INFO - 2020-10-30 03:50:38 --> Router Class Initialized
INFO - 2020-10-30 03:50:38 --> Output Class Initialized
INFO - 2020-10-30 03:50:38 --> Security Class Initialized
DEBUG - 2020-10-30 03:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:50:38 --> Input Class Initialized
INFO - 2020-10-30 03:50:38 --> Language Class Initialized
INFO - 2020-10-30 03:50:38 --> Language Class Initialized
INFO - 2020-10-30 03:50:38 --> Config Class Initialized
INFO - 2020-10-30 03:50:38 --> Loader Class Initialized
INFO - 2020-10-30 03:50:38 --> Helper loaded: url_helper
INFO - 2020-10-30 03:50:38 --> Helper loaded: file_helper
INFO - 2020-10-30 03:50:38 --> Helper loaded: form_helper
INFO - 2020-10-30 03:50:38 --> Helper loaded: my_helper
INFO - 2020-10-30 03:50:38 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:50:38 --> Controller Class Initialized
INFO - 2020-10-30 03:50:42 --> Config Class Initialized
INFO - 2020-10-30 03:50:42 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:50:42 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:50:42 --> Utf8 Class Initialized
INFO - 2020-10-30 03:50:42 --> URI Class Initialized
INFO - 2020-10-30 03:50:42 --> Router Class Initialized
INFO - 2020-10-30 03:50:42 --> Output Class Initialized
INFO - 2020-10-30 03:50:42 --> Security Class Initialized
DEBUG - 2020-10-30 03:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:50:42 --> Input Class Initialized
INFO - 2020-10-30 03:50:42 --> Language Class Initialized
INFO - 2020-10-30 03:50:42 --> Language Class Initialized
INFO - 2020-10-30 03:50:42 --> Config Class Initialized
INFO - 2020-10-30 03:50:42 --> Loader Class Initialized
INFO - 2020-10-30 03:50:42 --> Helper loaded: url_helper
INFO - 2020-10-30 03:50:42 --> Helper loaded: file_helper
INFO - 2020-10-30 03:50:42 --> Helper loaded: form_helper
INFO - 2020-10-30 03:50:42 --> Helper loaded: my_helper
INFO - 2020-10-30 03:50:42 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:50:42 --> Controller Class Initialized
INFO - 2020-10-30 03:50:42 --> Final output sent to browser
DEBUG - 2020-10-30 03:50:42 --> Total execution time: 0.2153
INFO - 2020-10-30 03:50:54 --> Config Class Initialized
INFO - 2020-10-30 03:50:54 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:50:54 --> Utf8 Class Initialized
INFO - 2020-10-30 03:50:54 --> URI Class Initialized
INFO - 2020-10-30 03:50:54 --> Router Class Initialized
INFO - 2020-10-30 03:50:54 --> Output Class Initialized
INFO - 2020-10-30 03:50:54 --> Security Class Initialized
DEBUG - 2020-10-30 03:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:50:54 --> Input Class Initialized
INFO - 2020-10-30 03:50:54 --> Language Class Initialized
INFO - 2020-10-30 03:50:54 --> Language Class Initialized
INFO - 2020-10-30 03:50:54 --> Config Class Initialized
INFO - 2020-10-30 03:50:54 --> Loader Class Initialized
INFO - 2020-10-30 03:50:54 --> Helper loaded: url_helper
INFO - 2020-10-30 03:50:54 --> Helper loaded: file_helper
INFO - 2020-10-30 03:50:54 --> Helper loaded: form_helper
INFO - 2020-10-30 03:50:54 --> Helper loaded: my_helper
INFO - 2020-10-30 03:50:54 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:50:54 --> Controller Class Initialized
INFO - 2020-10-30 03:50:54 --> Final output sent to browser
DEBUG - 2020-10-30 03:50:54 --> Total execution time: 0.2124
INFO - 2020-10-30 03:51:08 --> Config Class Initialized
INFO - 2020-10-30 03:51:08 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:08 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:08 --> URI Class Initialized
INFO - 2020-10-30 03:51:08 --> Router Class Initialized
INFO - 2020-10-30 03:51:08 --> Output Class Initialized
INFO - 2020-10-30 03:51:08 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:08 --> Input Class Initialized
INFO - 2020-10-30 03:51:08 --> Language Class Initialized
INFO - 2020-10-30 03:51:08 --> Language Class Initialized
INFO - 2020-10-30 03:51:08 --> Config Class Initialized
INFO - 2020-10-30 03:51:08 --> Loader Class Initialized
INFO - 2020-10-30 03:51:08 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:08 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:08 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:08 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:08 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:08 --> Controller Class Initialized
DEBUG - 2020-10-30 03:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-30 03:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:08 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:08 --> Total execution time: 0.2633
INFO - 2020-10-30 03:51:08 --> Config Class Initialized
INFO - 2020-10-30 03:51:08 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:08 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:08 --> URI Class Initialized
INFO - 2020-10-30 03:51:08 --> Router Class Initialized
INFO - 2020-10-30 03:51:08 --> Output Class Initialized
INFO - 2020-10-30 03:51:08 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:08 --> Input Class Initialized
INFO - 2020-10-30 03:51:08 --> Language Class Initialized
INFO - 2020-10-30 03:51:08 --> Language Class Initialized
INFO - 2020-10-30 03:51:08 --> Config Class Initialized
INFO - 2020-10-30 03:51:08 --> Loader Class Initialized
INFO - 2020-10-30 03:51:08 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:08 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:08 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:08 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:08 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:08 --> Controller Class Initialized
INFO - 2020-10-30 03:51:12 --> Config Class Initialized
INFO - 2020-10-30 03:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:12 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:12 --> URI Class Initialized
INFO - 2020-10-30 03:51:12 --> Router Class Initialized
INFO - 2020-10-30 03:51:12 --> Output Class Initialized
INFO - 2020-10-30 03:51:12 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:12 --> Input Class Initialized
INFO - 2020-10-30 03:51:12 --> Language Class Initialized
INFO - 2020-10-30 03:51:12 --> Language Class Initialized
INFO - 2020-10-30 03:51:12 --> Config Class Initialized
INFO - 2020-10-30 03:51:12 --> Loader Class Initialized
INFO - 2020-10-30 03:51:12 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:12 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:12 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:12 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:12 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:12 --> Controller Class Initialized
DEBUG - 2020-10-30 03:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-30 03:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:12 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:12 --> Total execution time: 0.2631
INFO - 2020-10-30 03:51:16 --> Config Class Initialized
INFO - 2020-10-30 03:51:16 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:16 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:16 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:16 --> URI Class Initialized
INFO - 2020-10-30 03:51:16 --> Router Class Initialized
INFO - 2020-10-30 03:51:16 --> Output Class Initialized
INFO - 2020-10-30 03:51:16 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:16 --> Input Class Initialized
INFO - 2020-10-30 03:51:16 --> Language Class Initialized
INFO - 2020-10-30 03:51:16 --> Language Class Initialized
INFO - 2020-10-30 03:51:16 --> Config Class Initialized
INFO - 2020-10-30 03:51:16 --> Loader Class Initialized
INFO - 2020-10-30 03:51:16 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:16 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:16 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:16 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:16 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:16 --> Controller Class Initialized
DEBUG - 2020-10-30 03:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-30 03:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:16 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:16 --> Total execution time: 0.2338
INFO - 2020-10-30 03:51:16 --> Config Class Initialized
INFO - 2020-10-30 03:51:16 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:16 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:16 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:16 --> URI Class Initialized
INFO - 2020-10-30 03:51:16 --> Router Class Initialized
INFO - 2020-10-30 03:51:16 --> Output Class Initialized
INFO - 2020-10-30 03:51:16 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:16 --> Input Class Initialized
INFO - 2020-10-30 03:51:16 --> Language Class Initialized
INFO - 2020-10-30 03:51:16 --> Language Class Initialized
INFO - 2020-10-30 03:51:16 --> Config Class Initialized
INFO - 2020-10-30 03:51:16 --> Loader Class Initialized
INFO - 2020-10-30 03:51:16 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:16 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:16 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:16 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:16 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:17 --> Controller Class Initialized
INFO - 2020-10-30 03:51:18 --> Config Class Initialized
INFO - 2020-10-30 03:51:18 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:18 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:18 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:18 --> URI Class Initialized
INFO - 2020-10-30 03:51:18 --> Router Class Initialized
INFO - 2020-10-30 03:51:18 --> Output Class Initialized
INFO - 2020-10-30 03:51:18 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:18 --> Input Class Initialized
INFO - 2020-10-30 03:51:18 --> Language Class Initialized
INFO - 2020-10-30 03:51:18 --> Language Class Initialized
INFO - 2020-10-30 03:51:18 --> Config Class Initialized
INFO - 2020-10-30 03:51:18 --> Loader Class Initialized
INFO - 2020-10-30 03:51:18 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:18 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:18 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:18 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:18 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:18 --> Controller Class Initialized
ERROR - 2020-10-30 03:51:18 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-30 03:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-30 03:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:18 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:18 --> Total execution time: 0.2494
INFO - 2020-10-30 03:51:45 --> Config Class Initialized
INFO - 2020-10-30 03:51:45 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:45 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:45 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:45 --> URI Class Initialized
INFO - 2020-10-30 03:51:45 --> Router Class Initialized
INFO - 2020-10-30 03:51:45 --> Output Class Initialized
INFO - 2020-10-30 03:51:45 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:45 --> Input Class Initialized
INFO - 2020-10-30 03:51:45 --> Language Class Initialized
INFO - 2020-10-30 03:51:45 --> Language Class Initialized
INFO - 2020-10-30 03:51:45 --> Config Class Initialized
INFO - 2020-10-30 03:51:45 --> Loader Class Initialized
INFO - 2020-10-30 03:51:45 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:45 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:45 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:45 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:45 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:45 --> Controller Class Initialized
INFO - 2020-10-30 03:51:45 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:51:45 --> Config Class Initialized
INFO - 2020-10-30 03:51:45 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:45 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:45 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:45 --> URI Class Initialized
INFO - 2020-10-30 03:51:45 --> Router Class Initialized
INFO - 2020-10-30 03:51:45 --> Output Class Initialized
INFO - 2020-10-30 03:51:45 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:45 --> Input Class Initialized
INFO - 2020-10-30 03:51:45 --> Language Class Initialized
INFO - 2020-10-30 03:51:45 --> Language Class Initialized
INFO - 2020-10-30 03:51:45 --> Config Class Initialized
INFO - 2020-10-30 03:51:45 --> Loader Class Initialized
INFO - 2020-10-30 03:51:45 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:45 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:45 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:45 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:45 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:45 --> Controller Class Initialized
DEBUG - 2020-10-30 03:51:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 03:51:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:45 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:45 --> Total execution time: 0.2336
INFO - 2020-10-30 03:51:51 --> Config Class Initialized
INFO - 2020-10-30 03:51:51 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:51 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:51 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:51 --> URI Class Initialized
INFO - 2020-10-30 03:51:51 --> Router Class Initialized
INFO - 2020-10-30 03:51:51 --> Output Class Initialized
INFO - 2020-10-30 03:51:51 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:51 --> Input Class Initialized
INFO - 2020-10-30 03:51:51 --> Language Class Initialized
INFO - 2020-10-30 03:51:51 --> Language Class Initialized
INFO - 2020-10-30 03:51:51 --> Config Class Initialized
INFO - 2020-10-30 03:51:51 --> Loader Class Initialized
INFO - 2020-10-30 03:51:51 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:51 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:51 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:51 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:51 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:51 --> Controller Class Initialized
INFO - 2020-10-30 03:51:51 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:51:51 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:51 --> Total execution time: 0.2370
INFO - 2020-10-30 03:51:52 --> Config Class Initialized
INFO - 2020-10-30 03:51:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:52 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:52 --> URI Class Initialized
INFO - 2020-10-30 03:51:52 --> Router Class Initialized
INFO - 2020-10-30 03:51:52 --> Output Class Initialized
INFO - 2020-10-30 03:51:52 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:52 --> Input Class Initialized
INFO - 2020-10-30 03:51:52 --> Language Class Initialized
INFO - 2020-10-30 03:51:52 --> Language Class Initialized
INFO - 2020-10-30 03:51:52 --> Config Class Initialized
INFO - 2020-10-30 03:51:52 --> Loader Class Initialized
INFO - 2020-10-30 03:51:52 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:52 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:52 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:52 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:52 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:52 --> Controller Class Initialized
DEBUG - 2020-10-30 03:51:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 03:51:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:52 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:52 --> Total execution time: 0.2580
INFO - 2020-10-30 03:51:55 --> Config Class Initialized
INFO - 2020-10-30 03:51:55 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:55 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:55 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:55 --> URI Class Initialized
INFO - 2020-10-30 03:51:55 --> Router Class Initialized
INFO - 2020-10-30 03:51:55 --> Output Class Initialized
INFO - 2020-10-30 03:51:55 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:55 --> Input Class Initialized
INFO - 2020-10-30 03:51:55 --> Language Class Initialized
INFO - 2020-10-30 03:51:55 --> Language Class Initialized
INFO - 2020-10-30 03:51:55 --> Config Class Initialized
INFO - 2020-10-30 03:51:55 --> Loader Class Initialized
INFO - 2020-10-30 03:51:55 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:55 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:55 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:55 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:55 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:55 --> Controller Class Initialized
DEBUG - 2020-10-30 03:51:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-30 03:51:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:55 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:55 --> Total execution time: 0.2418
INFO - 2020-10-30 03:51:57 --> Config Class Initialized
INFO - 2020-10-30 03:51:57 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:57 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:57 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:57 --> URI Class Initialized
INFO - 2020-10-30 03:51:57 --> Router Class Initialized
INFO - 2020-10-30 03:51:57 --> Output Class Initialized
INFO - 2020-10-30 03:51:57 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:57 --> Input Class Initialized
INFO - 2020-10-30 03:51:57 --> Language Class Initialized
INFO - 2020-10-30 03:51:57 --> Language Class Initialized
INFO - 2020-10-30 03:51:57 --> Config Class Initialized
INFO - 2020-10-30 03:51:57 --> Loader Class Initialized
INFO - 2020-10-30 03:51:57 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:57 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:57 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:57 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:57 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:57 --> Controller Class Initialized
DEBUG - 2020-10-30 03:51:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-30 03:51:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:57 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:57 --> Total execution time: 0.2564
INFO - 2020-10-30 03:51:59 --> Config Class Initialized
INFO - 2020-10-30 03:51:59 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:51:59 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:51:59 --> Utf8 Class Initialized
INFO - 2020-10-30 03:51:59 --> URI Class Initialized
INFO - 2020-10-30 03:51:59 --> Router Class Initialized
INFO - 2020-10-30 03:51:59 --> Output Class Initialized
INFO - 2020-10-30 03:51:59 --> Security Class Initialized
DEBUG - 2020-10-30 03:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:51:59 --> Input Class Initialized
INFO - 2020-10-30 03:51:59 --> Language Class Initialized
INFO - 2020-10-30 03:51:59 --> Language Class Initialized
INFO - 2020-10-30 03:51:59 --> Config Class Initialized
INFO - 2020-10-30 03:51:59 --> Loader Class Initialized
INFO - 2020-10-30 03:51:59 --> Helper loaded: url_helper
INFO - 2020-10-30 03:51:59 --> Helper loaded: file_helper
INFO - 2020-10-30 03:51:59 --> Helper loaded: form_helper
INFO - 2020-10-30 03:51:59 --> Helper loaded: my_helper
INFO - 2020-10-30 03:51:59 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:51:59 --> Controller Class Initialized
DEBUG - 2020-10-30 03:51:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-30 03:51:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:51:59 --> Final output sent to browser
DEBUG - 2020-10-30 03:51:59 --> Total execution time: 0.2266
INFO - 2020-10-30 03:52:00 --> Config Class Initialized
INFO - 2020-10-30 03:52:00 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:00 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:00 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:00 --> URI Class Initialized
INFO - 2020-10-30 03:52:00 --> Router Class Initialized
INFO - 2020-10-30 03:52:00 --> Output Class Initialized
INFO - 2020-10-30 03:52:00 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:00 --> Input Class Initialized
INFO - 2020-10-30 03:52:00 --> Language Class Initialized
INFO - 2020-10-30 03:52:00 --> Language Class Initialized
INFO - 2020-10-30 03:52:00 --> Config Class Initialized
INFO - 2020-10-30 03:52:00 --> Loader Class Initialized
INFO - 2020-10-30 03:52:00 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:00 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:00 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:00 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:00 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:00 --> Controller Class Initialized
INFO - 2020-10-30 03:52:02 --> Config Class Initialized
INFO - 2020-10-30 03:52:02 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:02 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:02 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:02 --> URI Class Initialized
INFO - 2020-10-30 03:52:02 --> Router Class Initialized
INFO - 2020-10-30 03:52:02 --> Output Class Initialized
INFO - 2020-10-30 03:52:02 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:02 --> Input Class Initialized
INFO - 2020-10-30 03:52:02 --> Language Class Initialized
INFO - 2020-10-30 03:52:02 --> Language Class Initialized
INFO - 2020-10-30 03:52:02 --> Config Class Initialized
INFO - 2020-10-30 03:52:02 --> Loader Class Initialized
INFO - 2020-10-30 03:52:02 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:02 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:02 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:02 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:02 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:02 --> Controller Class Initialized
DEBUG - 2020-10-30 03:52:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-30 03:52:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:52:02 --> Final output sent to browser
DEBUG - 2020-10-30 03:52:02 --> Total execution time: 0.2365
INFO - 2020-10-30 03:52:04 --> Config Class Initialized
INFO - 2020-10-30 03:52:04 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:04 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:04 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:04 --> URI Class Initialized
INFO - 2020-10-30 03:52:04 --> Router Class Initialized
INFO - 2020-10-30 03:52:04 --> Output Class Initialized
INFO - 2020-10-30 03:52:04 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:04 --> Input Class Initialized
INFO - 2020-10-30 03:52:04 --> Language Class Initialized
INFO - 2020-10-30 03:52:04 --> Language Class Initialized
INFO - 2020-10-30 03:52:04 --> Config Class Initialized
INFO - 2020-10-30 03:52:04 --> Loader Class Initialized
INFO - 2020-10-30 03:52:04 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:04 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:04 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:04 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:04 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:04 --> Controller Class Initialized
DEBUG - 2020-10-30 03:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-30 03:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:52:04 --> Final output sent to browser
DEBUG - 2020-10-30 03:52:04 --> Total execution time: 0.2285
INFO - 2020-10-30 03:52:04 --> Config Class Initialized
INFO - 2020-10-30 03:52:04 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:04 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:04 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:04 --> URI Class Initialized
INFO - 2020-10-30 03:52:04 --> Router Class Initialized
INFO - 2020-10-30 03:52:04 --> Output Class Initialized
INFO - 2020-10-30 03:52:04 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:04 --> Input Class Initialized
INFO - 2020-10-30 03:52:04 --> Language Class Initialized
INFO - 2020-10-30 03:52:04 --> Language Class Initialized
INFO - 2020-10-30 03:52:04 --> Config Class Initialized
INFO - 2020-10-30 03:52:04 --> Loader Class Initialized
INFO - 2020-10-30 03:52:04 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:04 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:04 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:04 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:05 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:05 --> Controller Class Initialized
INFO - 2020-10-30 03:52:13 --> Config Class Initialized
INFO - 2020-10-30 03:52:13 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:13 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:13 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:13 --> URI Class Initialized
INFO - 2020-10-30 03:52:13 --> Router Class Initialized
INFO - 2020-10-30 03:52:13 --> Output Class Initialized
INFO - 2020-10-30 03:52:13 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:13 --> Input Class Initialized
INFO - 2020-10-30 03:52:13 --> Language Class Initialized
INFO - 2020-10-30 03:52:13 --> Language Class Initialized
INFO - 2020-10-30 03:52:13 --> Config Class Initialized
INFO - 2020-10-30 03:52:13 --> Loader Class Initialized
INFO - 2020-10-30 03:52:13 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:13 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:13 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:13 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:13 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:13 --> Controller Class Initialized
INFO - 2020-10-30 03:52:13 --> Final output sent to browser
DEBUG - 2020-10-30 03:52:13 --> Total execution time: 0.2217
INFO - 2020-10-30 03:52:26 --> Config Class Initialized
INFO - 2020-10-30 03:52:26 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:26 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:26 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:26 --> URI Class Initialized
INFO - 2020-10-30 03:52:26 --> Router Class Initialized
INFO - 2020-10-30 03:52:26 --> Output Class Initialized
INFO - 2020-10-30 03:52:26 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:26 --> Input Class Initialized
INFO - 2020-10-30 03:52:26 --> Language Class Initialized
INFO - 2020-10-30 03:52:26 --> Language Class Initialized
INFO - 2020-10-30 03:52:26 --> Config Class Initialized
INFO - 2020-10-30 03:52:26 --> Loader Class Initialized
INFO - 2020-10-30 03:52:26 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:26 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:26 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:26 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:26 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:26 --> Controller Class Initialized
DEBUG - 2020-10-30 03:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-30 03:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:52:26 --> Final output sent to browser
DEBUG - 2020-10-30 03:52:26 --> Total execution time: 0.2437
INFO - 2020-10-30 03:52:27 --> Config Class Initialized
INFO - 2020-10-30 03:52:27 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:27 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:27 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:27 --> URI Class Initialized
INFO - 2020-10-30 03:52:27 --> Router Class Initialized
INFO - 2020-10-30 03:52:27 --> Output Class Initialized
INFO - 2020-10-30 03:52:27 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:27 --> Input Class Initialized
INFO - 2020-10-30 03:52:27 --> Language Class Initialized
INFO - 2020-10-30 03:52:27 --> Language Class Initialized
INFO - 2020-10-30 03:52:27 --> Config Class Initialized
INFO - 2020-10-30 03:52:27 --> Loader Class Initialized
INFO - 2020-10-30 03:52:27 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:27 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:27 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:27 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:27 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:27 --> Controller Class Initialized
DEBUG - 2020-10-30 03:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-30 03:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:52:27 --> Final output sent to browser
DEBUG - 2020-10-30 03:52:27 --> Total execution time: 0.2456
INFO - 2020-10-30 03:52:28 --> Config Class Initialized
INFO - 2020-10-30 03:52:28 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:28 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:28 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:28 --> URI Class Initialized
INFO - 2020-10-30 03:52:28 --> Router Class Initialized
INFO - 2020-10-30 03:52:28 --> Output Class Initialized
INFO - 2020-10-30 03:52:28 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:28 --> Input Class Initialized
INFO - 2020-10-30 03:52:28 --> Language Class Initialized
INFO - 2020-10-30 03:52:28 --> Language Class Initialized
INFO - 2020-10-30 03:52:28 --> Config Class Initialized
INFO - 2020-10-30 03:52:28 --> Loader Class Initialized
INFO - 2020-10-30 03:52:28 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:28 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:28 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:28 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:28 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:28 --> Controller Class Initialized
DEBUG - 2020-10-30 03:52:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-30 03:52:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:52:28 --> Final output sent to browser
DEBUG - 2020-10-30 03:52:28 --> Total execution time: 0.3076
INFO - 2020-10-30 03:52:35 --> Config Class Initialized
INFO - 2020-10-30 03:52:35 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:52:35 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:52:35 --> Utf8 Class Initialized
INFO - 2020-10-30 03:52:35 --> URI Class Initialized
INFO - 2020-10-30 03:52:35 --> Router Class Initialized
INFO - 2020-10-30 03:52:35 --> Output Class Initialized
INFO - 2020-10-30 03:52:35 --> Security Class Initialized
DEBUG - 2020-10-30 03:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:52:35 --> Input Class Initialized
INFO - 2020-10-30 03:52:35 --> Language Class Initialized
INFO - 2020-10-30 03:52:35 --> Language Class Initialized
INFO - 2020-10-30 03:52:35 --> Config Class Initialized
INFO - 2020-10-30 03:52:35 --> Loader Class Initialized
INFO - 2020-10-30 03:52:35 --> Helper loaded: url_helper
INFO - 2020-10-30 03:52:35 --> Helper loaded: file_helper
INFO - 2020-10-30 03:52:35 --> Helper loaded: form_helper
INFO - 2020-10-30 03:52:35 --> Helper loaded: my_helper
INFO - 2020-10-30 03:52:35 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:52:35 --> Controller Class Initialized
DEBUG - 2020-10-30 03:52:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-10-30 03:52:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:52:35 --> Final output sent to browser
DEBUG - 2020-10-30 03:52:35 --> Total execution time: 0.2758
INFO - 2020-10-30 03:53:30 --> Config Class Initialized
INFO - 2020-10-30 03:53:30 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:53:30 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:53:30 --> Utf8 Class Initialized
INFO - 2020-10-30 03:53:30 --> URI Class Initialized
INFO - 2020-10-30 03:53:30 --> Router Class Initialized
INFO - 2020-10-30 03:53:30 --> Output Class Initialized
INFO - 2020-10-30 03:53:30 --> Security Class Initialized
DEBUG - 2020-10-30 03:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:53:30 --> Input Class Initialized
INFO - 2020-10-30 03:53:30 --> Language Class Initialized
INFO - 2020-10-30 03:53:30 --> Language Class Initialized
INFO - 2020-10-30 03:53:30 --> Config Class Initialized
INFO - 2020-10-30 03:53:30 --> Loader Class Initialized
INFO - 2020-10-30 03:53:30 --> Helper loaded: url_helper
INFO - 2020-10-30 03:53:30 --> Helper loaded: file_helper
INFO - 2020-10-30 03:53:30 --> Helper loaded: form_helper
INFO - 2020-10-30 03:53:30 --> Helper loaded: my_helper
INFO - 2020-10-30 03:53:30 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:53:31 --> Controller Class Initialized
DEBUG - 2020-10-30 03:53:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-30 03:53:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:53:31 --> Final output sent to browser
DEBUG - 2020-10-30 03:53:31 --> Total execution time: 0.2515
INFO - 2020-10-30 03:53:37 --> Config Class Initialized
INFO - 2020-10-30 03:53:37 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:53:37 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:53:37 --> Utf8 Class Initialized
INFO - 2020-10-30 03:53:37 --> URI Class Initialized
INFO - 2020-10-30 03:53:37 --> Router Class Initialized
INFO - 2020-10-30 03:53:37 --> Output Class Initialized
INFO - 2020-10-30 03:53:37 --> Security Class Initialized
DEBUG - 2020-10-30 03:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:53:37 --> Input Class Initialized
INFO - 2020-10-30 03:53:37 --> Language Class Initialized
INFO - 2020-10-30 03:53:37 --> Language Class Initialized
INFO - 2020-10-30 03:53:37 --> Config Class Initialized
INFO - 2020-10-30 03:53:37 --> Loader Class Initialized
INFO - 2020-10-30 03:53:37 --> Helper loaded: url_helper
INFO - 2020-10-30 03:53:37 --> Helper loaded: file_helper
INFO - 2020-10-30 03:53:37 --> Helper loaded: form_helper
INFO - 2020-10-30 03:53:37 --> Helper loaded: my_helper
INFO - 2020-10-30 03:53:37 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:53:37 --> Controller Class Initialized
DEBUG - 2020-10-30 03:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-10-30 03:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:53:38 --> Final output sent to browser
DEBUG - 2020-10-30 03:53:38 --> Total execution time: 0.3264
INFO - 2020-10-30 03:53:43 --> Config Class Initialized
INFO - 2020-10-30 03:53:43 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:53:43 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:53:43 --> Utf8 Class Initialized
INFO - 2020-10-30 03:53:43 --> URI Class Initialized
INFO - 2020-10-30 03:53:43 --> Router Class Initialized
INFO - 2020-10-30 03:53:43 --> Output Class Initialized
INFO - 2020-10-30 03:53:43 --> Security Class Initialized
DEBUG - 2020-10-30 03:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:53:43 --> Input Class Initialized
INFO - 2020-10-30 03:53:43 --> Language Class Initialized
INFO - 2020-10-30 03:53:43 --> Language Class Initialized
INFO - 2020-10-30 03:53:43 --> Config Class Initialized
INFO - 2020-10-30 03:53:43 --> Loader Class Initialized
INFO - 2020-10-30 03:53:43 --> Helper loaded: url_helper
INFO - 2020-10-30 03:53:43 --> Helper loaded: file_helper
INFO - 2020-10-30 03:53:43 --> Helper loaded: form_helper
INFO - 2020-10-30 03:53:43 --> Helper loaded: my_helper
INFO - 2020-10-30 03:53:43 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:53:43 --> Controller Class Initialized
INFO - 2020-10-30 03:53:43 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:53:43 --> Config Class Initialized
INFO - 2020-10-30 03:53:43 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:53:43 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:53:43 --> Utf8 Class Initialized
INFO - 2020-10-30 03:53:43 --> URI Class Initialized
INFO - 2020-10-30 03:53:43 --> Router Class Initialized
INFO - 2020-10-30 03:53:43 --> Output Class Initialized
INFO - 2020-10-30 03:53:43 --> Security Class Initialized
DEBUG - 2020-10-30 03:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:53:44 --> Input Class Initialized
INFO - 2020-10-30 03:53:44 --> Language Class Initialized
INFO - 2020-10-30 03:53:44 --> Language Class Initialized
INFO - 2020-10-30 03:53:44 --> Config Class Initialized
INFO - 2020-10-30 03:53:44 --> Loader Class Initialized
INFO - 2020-10-30 03:53:44 --> Helper loaded: url_helper
INFO - 2020-10-30 03:53:44 --> Helper loaded: file_helper
INFO - 2020-10-30 03:53:44 --> Helper loaded: form_helper
INFO - 2020-10-30 03:53:44 --> Helper loaded: my_helper
INFO - 2020-10-30 03:53:44 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:53:44 --> Controller Class Initialized
DEBUG - 2020-10-30 03:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 03:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:53:44 --> Final output sent to browser
DEBUG - 2020-10-30 03:53:44 --> Total execution time: 0.2505
INFO - 2020-10-30 03:53:49 --> Config Class Initialized
INFO - 2020-10-30 03:53:49 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:53:49 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:53:49 --> Utf8 Class Initialized
INFO - 2020-10-30 03:53:49 --> URI Class Initialized
INFO - 2020-10-30 03:53:49 --> Router Class Initialized
INFO - 2020-10-30 03:53:49 --> Output Class Initialized
INFO - 2020-10-30 03:53:49 --> Security Class Initialized
DEBUG - 2020-10-30 03:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:53:49 --> Input Class Initialized
INFO - 2020-10-30 03:53:49 --> Language Class Initialized
INFO - 2020-10-30 03:53:49 --> Language Class Initialized
INFO - 2020-10-30 03:53:49 --> Config Class Initialized
INFO - 2020-10-30 03:53:49 --> Loader Class Initialized
INFO - 2020-10-30 03:53:49 --> Helper loaded: url_helper
INFO - 2020-10-30 03:53:49 --> Helper loaded: file_helper
INFO - 2020-10-30 03:53:49 --> Helper loaded: form_helper
INFO - 2020-10-30 03:53:49 --> Helper loaded: my_helper
INFO - 2020-10-30 03:53:49 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:53:49 --> Controller Class Initialized
INFO - 2020-10-30 03:53:49 --> Helper loaded: cookie_helper
INFO - 2020-10-30 03:53:49 --> Final output sent to browser
DEBUG - 2020-10-30 03:53:49 --> Total execution time: 0.2439
INFO - 2020-10-30 03:53:50 --> Config Class Initialized
INFO - 2020-10-30 03:53:50 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:53:50 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:53:50 --> Utf8 Class Initialized
INFO - 2020-10-30 03:53:50 --> URI Class Initialized
INFO - 2020-10-30 03:53:50 --> Router Class Initialized
INFO - 2020-10-30 03:53:50 --> Output Class Initialized
INFO - 2020-10-30 03:53:50 --> Security Class Initialized
DEBUG - 2020-10-30 03:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:53:50 --> Input Class Initialized
INFO - 2020-10-30 03:53:50 --> Language Class Initialized
INFO - 2020-10-30 03:53:50 --> Language Class Initialized
INFO - 2020-10-30 03:53:50 --> Config Class Initialized
INFO - 2020-10-30 03:53:50 --> Loader Class Initialized
INFO - 2020-10-30 03:53:50 --> Helper loaded: url_helper
INFO - 2020-10-30 03:53:50 --> Helper loaded: file_helper
INFO - 2020-10-30 03:53:50 --> Helper loaded: form_helper
INFO - 2020-10-30 03:53:50 --> Helper loaded: my_helper
INFO - 2020-10-30 03:53:50 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:53:50 --> Controller Class Initialized
DEBUG - 2020-10-30 03:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 03:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:53:50 --> Final output sent to browser
DEBUG - 2020-10-30 03:53:50 --> Total execution time: 0.2852
INFO - 2020-10-30 03:53:54 --> Config Class Initialized
INFO - 2020-10-30 03:53:54 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:53:54 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:53:54 --> Utf8 Class Initialized
INFO - 2020-10-30 03:53:54 --> URI Class Initialized
INFO - 2020-10-30 03:53:54 --> Router Class Initialized
INFO - 2020-10-30 03:53:54 --> Output Class Initialized
INFO - 2020-10-30 03:53:54 --> Security Class Initialized
DEBUG - 2020-10-30 03:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:53:54 --> Input Class Initialized
INFO - 2020-10-30 03:53:54 --> Language Class Initialized
INFO - 2020-10-30 03:53:54 --> Language Class Initialized
INFO - 2020-10-30 03:53:54 --> Config Class Initialized
INFO - 2020-10-30 03:53:54 --> Loader Class Initialized
INFO - 2020-10-30 03:53:54 --> Helper loaded: url_helper
INFO - 2020-10-30 03:53:54 --> Helper loaded: file_helper
INFO - 2020-10-30 03:53:54 --> Helper loaded: form_helper
INFO - 2020-10-30 03:53:54 --> Helper loaded: my_helper
INFO - 2020-10-30 03:53:54 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:53:54 --> Controller Class Initialized
DEBUG - 2020-10-30 03:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-30 03:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 03:53:55 --> Final output sent to browser
DEBUG - 2020-10-30 03:53:55 --> Total execution time: 0.2447
INFO - 2020-10-30 03:53:55 --> Config Class Initialized
INFO - 2020-10-30 03:53:55 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:53:55 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:53:55 --> Utf8 Class Initialized
INFO - 2020-10-30 03:53:55 --> URI Class Initialized
INFO - 2020-10-30 03:53:55 --> Router Class Initialized
INFO - 2020-10-30 03:53:55 --> Output Class Initialized
INFO - 2020-10-30 03:53:55 --> Security Class Initialized
DEBUG - 2020-10-30 03:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:53:55 --> Input Class Initialized
INFO - 2020-10-30 03:53:55 --> Language Class Initialized
INFO - 2020-10-30 03:53:55 --> Language Class Initialized
INFO - 2020-10-30 03:53:55 --> Config Class Initialized
INFO - 2020-10-30 03:53:55 --> Loader Class Initialized
INFO - 2020-10-30 03:53:55 --> Helper loaded: url_helper
INFO - 2020-10-30 03:53:55 --> Helper loaded: file_helper
INFO - 2020-10-30 03:53:55 --> Helper loaded: form_helper
INFO - 2020-10-30 03:53:55 --> Helper loaded: my_helper
INFO - 2020-10-30 03:53:55 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:53:55 --> Controller Class Initialized
INFO - 2020-10-30 03:55:19 --> Config Class Initialized
INFO - 2020-10-30 03:55:19 --> Hooks Class Initialized
DEBUG - 2020-10-30 03:55:19 --> UTF-8 Support Enabled
INFO - 2020-10-30 03:55:19 --> Utf8 Class Initialized
INFO - 2020-10-30 03:55:19 --> URI Class Initialized
INFO - 2020-10-30 03:55:19 --> Router Class Initialized
INFO - 2020-10-30 03:55:19 --> Output Class Initialized
INFO - 2020-10-30 03:55:19 --> Security Class Initialized
DEBUG - 2020-10-30 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 03:55:19 --> Input Class Initialized
INFO - 2020-10-30 03:55:19 --> Language Class Initialized
INFO - 2020-10-30 03:55:19 --> Language Class Initialized
INFO - 2020-10-30 03:55:19 --> Config Class Initialized
INFO - 2020-10-30 03:55:19 --> Loader Class Initialized
INFO - 2020-10-30 03:55:19 --> Helper loaded: url_helper
INFO - 2020-10-30 03:55:19 --> Helper loaded: file_helper
INFO - 2020-10-30 03:55:19 --> Helper loaded: form_helper
INFO - 2020-10-30 03:55:19 --> Helper loaded: my_helper
INFO - 2020-10-30 03:55:19 --> Database Driver Class Initialized
DEBUG - 2020-10-30 03:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 03:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 03:55:19 --> Controller Class Initialized
INFO - 2020-10-30 03:55:19 --> Final output sent to browser
DEBUG - 2020-10-30 03:55:19 --> Total execution time: 0.2397
INFO - 2020-10-30 04:29:53 --> Config Class Initialized
INFO - 2020-10-30 04:29:53 --> Hooks Class Initialized
DEBUG - 2020-10-30 04:29:53 --> UTF-8 Support Enabled
INFO - 2020-10-30 04:29:53 --> Utf8 Class Initialized
INFO - 2020-10-30 04:29:53 --> URI Class Initialized
INFO - 2020-10-30 04:29:53 --> Router Class Initialized
INFO - 2020-10-30 04:29:53 --> Output Class Initialized
INFO - 2020-10-30 04:29:53 --> Security Class Initialized
DEBUG - 2020-10-30 04:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 04:29:53 --> Input Class Initialized
INFO - 2020-10-30 04:29:53 --> Language Class Initialized
INFO - 2020-10-30 04:29:53 --> Language Class Initialized
INFO - 2020-10-30 04:29:53 --> Config Class Initialized
INFO - 2020-10-30 04:29:53 --> Loader Class Initialized
INFO - 2020-10-30 04:29:53 --> Helper loaded: url_helper
INFO - 2020-10-30 04:29:53 --> Helper loaded: file_helper
INFO - 2020-10-30 04:29:53 --> Helper loaded: form_helper
INFO - 2020-10-30 04:29:53 --> Helper loaded: my_helper
INFO - 2020-10-30 04:29:53 --> Database Driver Class Initialized
DEBUG - 2020-10-30 04:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 04:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 04:29:53 --> Controller Class Initialized
DEBUG - 2020-10-30 04:29:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-30 04:29:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 04:29:53 --> Final output sent to browser
DEBUG - 2020-10-30 04:29:53 --> Total execution time: 0.2374
INFO - 2020-10-30 04:29:54 --> Config Class Initialized
INFO - 2020-10-30 04:29:54 --> Hooks Class Initialized
DEBUG - 2020-10-30 04:29:54 --> UTF-8 Support Enabled
INFO - 2020-10-30 04:29:54 --> Utf8 Class Initialized
INFO - 2020-10-30 04:29:54 --> URI Class Initialized
INFO - 2020-10-30 04:29:54 --> Router Class Initialized
INFO - 2020-10-30 04:29:54 --> Output Class Initialized
INFO - 2020-10-30 04:29:54 --> Security Class Initialized
DEBUG - 2020-10-30 04:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 04:29:54 --> Input Class Initialized
INFO - 2020-10-30 04:29:54 --> Language Class Initialized
INFO - 2020-10-30 04:29:54 --> Language Class Initialized
INFO - 2020-10-30 04:29:54 --> Config Class Initialized
INFO - 2020-10-30 04:29:54 --> Loader Class Initialized
INFO - 2020-10-30 04:29:54 --> Helper loaded: url_helper
INFO - 2020-10-30 04:29:54 --> Helper loaded: file_helper
INFO - 2020-10-30 04:29:54 --> Helper loaded: form_helper
INFO - 2020-10-30 04:29:54 --> Helper loaded: my_helper
INFO - 2020-10-30 04:29:54 --> Database Driver Class Initialized
DEBUG - 2020-10-30 04:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 04:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 04:29:54 --> Controller Class Initialized
INFO - 2020-10-30 05:15:34 --> Config Class Initialized
INFO - 2020-10-30 05:15:34 --> Hooks Class Initialized
DEBUG - 2020-10-30 05:15:34 --> UTF-8 Support Enabled
INFO - 2020-10-30 05:15:34 --> Utf8 Class Initialized
INFO - 2020-10-30 05:15:34 --> URI Class Initialized
INFO - 2020-10-30 05:15:34 --> Router Class Initialized
INFO - 2020-10-30 05:15:34 --> Output Class Initialized
INFO - 2020-10-30 05:15:34 --> Security Class Initialized
DEBUG - 2020-10-30 05:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 05:15:34 --> Input Class Initialized
INFO - 2020-10-30 05:15:34 --> Language Class Initialized
INFO - 2020-10-30 05:15:34 --> Language Class Initialized
INFO - 2020-10-30 05:15:34 --> Config Class Initialized
INFO - 2020-10-30 05:15:34 --> Loader Class Initialized
INFO - 2020-10-30 05:15:34 --> Helper loaded: url_helper
INFO - 2020-10-30 05:15:34 --> Helper loaded: file_helper
INFO - 2020-10-30 05:15:34 --> Helper loaded: form_helper
INFO - 2020-10-30 05:15:34 --> Helper loaded: my_helper
INFO - 2020-10-30 05:15:34 --> Database Driver Class Initialized
DEBUG - 2020-10-30 05:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 05:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 05:15:34 --> Controller Class Initialized
ERROR - 2020-10-30 05:15:34 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-30 05:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-30 05:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 05:15:34 --> Final output sent to browser
DEBUG - 2020-10-30 05:15:34 --> Total execution time: 0.2639
INFO - 2020-10-30 08:19:43 --> Config Class Initialized
INFO - 2020-10-30 08:19:43 --> Hooks Class Initialized
DEBUG - 2020-10-30 08:19:44 --> UTF-8 Support Enabled
INFO - 2020-10-30 08:19:44 --> Utf8 Class Initialized
INFO - 2020-10-30 08:19:44 --> URI Class Initialized
DEBUG - 2020-10-30 08:19:44 --> No URI present. Default controller set.
INFO - 2020-10-30 08:19:44 --> Router Class Initialized
INFO - 2020-10-30 08:19:44 --> Output Class Initialized
INFO - 2020-10-30 08:19:44 --> Security Class Initialized
DEBUG - 2020-10-30 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 08:19:44 --> Input Class Initialized
INFO - 2020-10-30 08:19:44 --> Language Class Initialized
INFO - 2020-10-30 08:19:44 --> Language Class Initialized
INFO - 2020-10-30 08:19:44 --> Config Class Initialized
INFO - 2020-10-30 08:19:44 --> Loader Class Initialized
INFO - 2020-10-30 08:19:44 --> Helper loaded: url_helper
INFO - 2020-10-30 08:19:44 --> Helper loaded: file_helper
INFO - 2020-10-30 08:19:44 --> Helper loaded: form_helper
INFO - 2020-10-30 08:19:44 --> Helper loaded: my_helper
INFO - 2020-10-30 08:19:44 --> Database Driver Class Initialized
DEBUG - 2020-10-30 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 08:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 08:19:44 --> Controller Class Initialized
INFO - 2020-10-30 08:19:44 --> Config Class Initialized
INFO - 2020-10-30 08:19:44 --> Hooks Class Initialized
DEBUG - 2020-10-30 08:19:44 --> UTF-8 Support Enabled
INFO - 2020-10-30 08:19:44 --> Utf8 Class Initialized
INFO - 2020-10-30 08:19:44 --> URI Class Initialized
INFO - 2020-10-30 08:19:44 --> Router Class Initialized
INFO - 2020-10-30 08:19:44 --> Output Class Initialized
INFO - 2020-10-30 08:19:45 --> Security Class Initialized
DEBUG - 2020-10-30 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 08:19:45 --> Input Class Initialized
INFO - 2020-10-30 08:19:45 --> Language Class Initialized
INFO - 2020-10-30 08:19:45 --> Language Class Initialized
INFO - 2020-10-30 08:19:45 --> Config Class Initialized
INFO - 2020-10-30 08:19:45 --> Loader Class Initialized
INFO - 2020-10-30 08:19:45 --> Helper loaded: url_helper
INFO - 2020-10-30 08:19:45 --> Helper loaded: file_helper
INFO - 2020-10-30 08:19:45 --> Helper loaded: form_helper
INFO - 2020-10-30 08:19:45 --> Helper loaded: my_helper
INFO - 2020-10-30 08:19:45 --> Database Driver Class Initialized
DEBUG - 2020-10-30 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 08:19:45 --> Controller Class Initialized
DEBUG - 2020-10-30 08:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 08:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 08:19:45 --> Final output sent to browser
DEBUG - 2020-10-30 08:19:45 --> Total execution time: 0.3733
INFO - 2020-10-30 08:30:39 --> Config Class Initialized
INFO - 2020-10-30 08:30:39 --> Hooks Class Initialized
DEBUG - 2020-10-30 08:30:39 --> UTF-8 Support Enabled
INFO - 2020-10-30 08:30:39 --> Utf8 Class Initialized
INFO - 2020-10-30 08:30:39 --> URI Class Initialized
INFO - 2020-10-30 08:30:39 --> Router Class Initialized
INFO - 2020-10-30 08:30:39 --> Output Class Initialized
INFO - 2020-10-30 08:30:39 --> Security Class Initialized
DEBUG - 2020-10-30 08:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 08:30:39 --> Input Class Initialized
INFO - 2020-10-30 08:30:39 --> Language Class Initialized
INFO - 2020-10-30 08:30:39 --> Language Class Initialized
INFO - 2020-10-30 08:30:39 --> Config Class Initialized
INFO - 2020-10-30 08:30:39 --> Loader Class Initialized
INFO - 2020-10-30 08:30:39 --> Helper loaded: url_helper
INFO - 2020-10-30 08:30:39 --> Helper loaded: file_helper
INFO - 2020-10-30 08:30:39 --> Helper loaded: form_helper
INFO - 2020-10-30 08:30:39 --> Helper loaded: my_helper
INFO - 2020-10-30 08:30:39 --> Database Driver Class Initialized
DEBUG - 2020-10-30 08:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 08:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 08:30:39 --> Controller Class Initialized
INFO - 2020-10-30 08:30:39 --> Helper loaded: cookie_helper
INFO - 2020-10-30 08:30:39 --> Final output sent to browser
DEBUG - 2020-10-30 08:30:39 --> Total execution time: 0.6561
INFO - 2020-10-30 08:30:40 --> Config Class Initialized
INFO - 2020-10-30 08:30:40 --> Hooks Class Initialized
DEBUG - 2020-10-30 08:30:40 --> UTF-8 Support Enabled
INFO - 2020-10-30 08:30:40 --> Utf8 Class Initialized
INFO - 2020-10-30 08:30:40 --> URI Class Initialized
INFO - 2020-10-30 08:30:40 --> Router Class Initialized
INFO - 2020-10-30 08:30:40 --> Output Class Initialized
INFO - 2020-10-30 08:30:40 --> Security Class Initialized
DEBUG - 2020-10-30 08:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 08:30:40 --> Input Class Initialized
INFO - 2020-10-30 08:30:40 --> Language Class Initialized
INFO - 2020-10-30 08:30:40 --> Language Class Initialized
INFO - 2020-10-30 08:30:41 --> Config Class Initialized
INFO - 2020-10-30 08:30:41 --> Loader Class Initialized
INFO - 2020-10-30 08:30:41 --> Helper loaded: url_helper
INFO - 2020-10-30 08:30:41 --> Helper loaded: file_helper
INFO - 2020-10-30 08:30:41 --> Helper loaded: form_helper
INFO - 2020-10-30 08:30:41 --> Helper loaded: my_helper
INFO - 2020-10-30 08:30:41 --> Database Driver Class Initialized
DEBUG - 2020-10-30 08:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 08:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 08:30:41 --> Controller Class Initialized
DEBUG - 2020-10-30 08:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 08:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 08:30:41 --> Final output sent to browser
DEBUG - 2020-10-30 08:30:41 --> Total execution time: 0.3431
INFO - 2020-10-30 08:52:25 --> Config Class Initialized
INFO - 2020-10-30 08:52:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 08:52:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 08:52:25 --> Utf8 Class Initialized
INFO - 2020-10-30 08:52:25 --> URI Class Initialized
INFO - 2020-10-30 08:52:25 --> Router Class Initialized
INFO - 2020-10-30 08:52:25 --> Output Class Initialized
INFO - 2020-10-30 08:52:25 --> Security Class Initialized
DEBUG - 2020-10-30 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 08:52:25 --> Input Class Initialized
INFO - 2020-10-30 08:52:25 --> Language Class Initialized
INFO - 2020-10-30 08:52:25 --> Language Class Initialized
INFO - 2020-10-30 08:52:25 --> Config Class Initialized
INFO - 2020-10-30 08:52:25 --> Loader Class Initialized
INFO - 2020-10-30 08:52:25 --> Helper loaded: url_helper
INFO - 2020-10-30 08:52:25 --> Helper loaded: file_helper
INFO - 2020-10-30 08:52:25 --> Helper loaded: form_helper
INFO - 2020-10-30 08:52:25 --> Helper loaded: my_helper
INFO - 2020-10-30 08:52:25 --> Database Driver Class Initialized
DEBUG - 2020-10-30 08:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 08:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 08:52:25 --> Controller Class Initialized
INFO - 2020-10-30 08:52:25 --> Helper loaded: cookie_helper
INFO - 2020-10-30 08:52:25 --> Config Class Initialized
INFO - 2020-10-30 08:52:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 08:52:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 08:52:25 --> Utf8 Class Initialized
INFO - 2020-10-30 08:52:25 --> URI Class Initialized
INFO - 2020-10-30 08:52:25 --> Router Class Initialized
INFO - 2020-10-30 08:52:25 --> Output Class Initialized
INFO - 2020-10-30 08:52:25 --> Security Class Initialized
DEBUG - 2020-10-30 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 08:52:25 --> Input Class Initialized
INFO - 2020-10-30 08:52:25 --> Language Class Initialized
INFO - 2020-10-30 08:52:25 --> Language Class Initialized
INFO - 2020-10-30 08:52:25 --> Config Class Initialized
INFO - 2020-10-30 08:52:25 --> Loader Class Initialized
INFO - 2020-10-30 08:52:25 --> Helper loaded: url_helper
INFO - 2020-10-30 08:52:25 --> Helper loaded: file_helper
INFO - 2020-10-30 08:52:25 --> Helper loaded: form_helper
INFO - 2020-10-30 08:52:25 --> Helper loaded: my_helper
INFO - 2020-10-30 08:52:25 --> Database Driver Class Initialized
DEBUG - 2020-10-30 08:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 08:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 08:52:25 --> Controller Class Initialized
DEBUG - 2020-10-30 08:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-30 08:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 08:52:25 --> Final output sent to browser
DEBUG - 2020-10-30 08:52:25 --> Total execution time: 0.2729
INFO - 2020-10-30 09:23:27 --> Config Class Initialized
INFO - 2020-10-30 09:23:27 --> Hooks Class Initialized
DEBUG - 2020-10-30 09:23:27 --> UTF-8 Support Enabled
INFO - 2020-10-30 09:23:27 --> Utf8 Class Initialized
INFO - 2020-10-30 09:23:27 --> URI Class Initialized
INFO - 2020-10-30 09:23:27 --> Router Class Initialized
INFO - 2020-10-30 09:23:27 --> Output Class Initialized
INFO - 2020-10-30 09:23:27 --> Security Class Initialized
DEBUG - 2020-10-30 09:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 09:23:27 --> Input Class Initialized
INFO - 2020-10-30 09:23:27 --> Language Class Initialized
INFO - 2020-10-30 09:23:27 --> Language Class Initialized
INFO - 2020-10-30 09:23:27 --> Config Class Initialized
INFO - 2020-10-30 09:23:27 --> Loader Class Initialized
INFO - 2020-10-30 09:23:27 --> Helper loaded: url_helper
INFO - 2020-10-30 09:23:27 --> Helper loaded: file_helper
INFO - 2020-10-30 09:23:27 --> Helper loaded: form_helper
INFO - 2020-10-30 09:23:27 --> Helper loaded: my_helper
INFO - 2020-10-30 09:23:27 --> Database Driver Class Initialized
DEBUG - 2020-10-30 09:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 09:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 09:23:27 --> Controller Class Initialized
INFO - 2020-10-30 09:23:27 --> Final output sent to browser
DEBUG - 2020-10-30 09:23:27 --> Total execution time: 0.2492
INFO - 2020-10-30 09:23:35 --> Config Class Initialized
INFO - 2020-10-30 09:23:35 --> Hooks Class Initialized
DEBUG - 2020-10-30 09:23:35 --> UTF-8 Support Enabled
INFO - 2020-10-30 09:23:35 --> Utf8 Class Initialized
INFO - 2020-10-30 09:23:35 --> URI Class Initialized
INFO - 2020-10-30 09:23:35 --> Router Class Initialized
INFO - 2020-10-30 09:23:35 --> Output Class Initialized
INFO - 2020-10-30 09:23:35 --> Security Class Initialized
DEBUG - 2020-10-30 09:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 09:23:35 --> Input Class Initialized
INFO - 2020-10-30 09:23:35 --> Language Class Initialized
INFO - 2020-10-30 09:23:35 --> Language Class Initialized
INFO - 2020-10-30 09:23:35 --> Config Class Initialized
INFO - 2020-10-30 09:23:35 --> Loader Class Initialized
INFO - 2020-10-30 09:23:35 --> Helper loaded: url_helper
INFO - 2020-10-30 09:23:35 --> Helper loaded: file_helper
INFO - 2020-10-30 09:23:35 --> Helper loaded: form_helper
INFO - 2020-10-30 09:23:35 --> Helper loaded: my_helper
INFO - 2020-10-30 09:23:35 --> Database Driver Class Initialized
DEBUG - 2020-10-30 09:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 09:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 09:23:35 --> Controller Class Initialized
INFO - 2020-10-30 09:23:35 --> Helper loaded: cookie_helper
INFO - 2020-10-30 09:23:35 --> Final output sent to browser
DEBUG - 2020-10-30 09:23:35 --> Total execution time: 0.2527
INFO - 2020-10-30 09:23:36 --> Config Class Initialized
INFO - 2020-10-30 09:23:36 --> Hooks Class Initialized
DEBUG - 2020-10-30 09:23:36 --> UTF-8 Support Enabled
INFO - 2020-10-30 09:23:36 --> Utf8 Class Initialized
INFO - 2020-10-30 09:23:36 --> URI Class Initialized
INFO - 2020-10-30 09:23:36 --> Router Class Initialized
INFO - 2020-10-30 09:23:36 --> Output Class Initialized
INFO - 2020-10-30 09:23:36 --> Security Class Initialized
DEBUG - 2020-10-30 09:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 09:23:37 --> Input Class Initialized
INFO - 2020-10-30 09:23:37 --> Language Class Initialized
INFO - 2020-10-30 09:23:37 --> Language Class Initialized
INFO - 2020-10-30 09:23:37 --> Config Class Initialized
INFO - 2020-10-30 09:23:37 --> Loader Class Initialized
INFO - 2020-10-30 09:23:37 --> Helper loaded: url_helper
INFO - 2020-10-30 09:23:37 --> Helper loaded: file_helper
INFO - 2020-10-30 09:23:37 --> Helper loaded: form_helper
INFO - 2020-10-30 09:23:37 --> Helper loaded: my_helper
INFO - 2020-10-30 09:23:37 --> Database Driver Class Initialized
DEBUG - 2020-10-30 09:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-30 09:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 09:23:37 --> Controller Class Initialized
DEBUG - 2020-10-30 09:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-30 09:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-30 09:23:37 --> Final output sent to browser
DEBUG - 2020-10-30 09:23:37 --> Total execution time: 0.3179
