<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-18 01:40:18 --> Config Class Initialized
INFO - 2021-12-18 01:40:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:40:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:40:18 --> Utf8 Class Initialized
INFO - 2021-12-18 01:40:18 --> URI Class Initialized
DEBUG - 2021-12-18 01:40:18 --> No URI present. Default controller set.
INFO - 2021-12-18 01:40:18 --> Router Class Initialized
INFO - 2021-12-18 01:40:18 --> Output Class Initialized
INFO - 2021-12-18 01:40:18 --> Security Class Initialized
DEBUG - 2021-12-18 01:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:40:18 --> Input Class Initialized
INFO - 2021-12-18 01:40:18 --> Language Class Initialized
INFO - 2021-12-18 01:40:18 --> Language Class Initialized
INFO - 2021-12-18 01:40:18 --> Config Class Initialized
INFO - 2021-12-18 01:40:18 --> Loader Class Initialized
INFO - 2021-12-18 01:40:18 --> Helper loaded: url_helper
INFO - 2021-12-18 01:40:18 --> Helper loaded: file_helper
INFO - 2021-12-18 01:40:18 --> Helper loaded: form_helper
INFO - 2021-12-18 01:40:18 --> Helper loaded: my_helper
INFO - 2021-12-18 01:40:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:40:18 --> Controller Class Initialized
INFO - 2021-12-18 01:40:18 --> Config Class Initialized
INFO - 2021-12-18 01:40:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:40:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:40:18 --> Utf8 Class Initialized
INFO - 2021-12-18 01:40:18 --> URI Class Initialized
INFO - 2021-12-18 01:40:18 --> Router Class Initialized
INFO - 2021-12-18 01:40:18 --> Output Class Initialized
INFO - 2021-12-18 01:40:18 --> Security Class Initialized
DEBUG - 2021-12-18 01:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:40:18 --> Input Class Initialized
INFO - 2021-12-18 01:40:18 --> Language Class Initialized
INFO - 2021-12-18 01:40:18 --> Language Class Initialized
INFO - 2021-12-18 01:40:18 --> Config Class Initialized
INFO - 2021-12-18 01:40:18 --> Loader Class Initialized
INFO - 2021-12-18 01:40:18 --> Helper loaded: url_helper
INFO - 2021-12-18 01:40:18 --> Helper loaded: file_helper
INFO - 2021-12-18 01:40:18 --> Helper loaded: form_helper
INFO - 2021-12-18 01:40:18 --> Helper loaded: my_helper
INFO - 2021-12-18 01:40:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:40:18 --> Controller Class Initialized
DEBUG - 2021-12-18 01:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-18 01:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:40:18 --> Final output sent to browser
DEBUG - 2021-12-18 01:40:18 --> Total execution time: 0.0400
INFO - 2021-12-18 01:40:23 --> Config Class Initialized
INFO - 2021-12-18 01:40:23 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:40:23 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:40:23 --> Utf8 Class Initialized
INFO - 2021-12-18 01:40:23 --> URI Class Initialized
INFO - 2021-12-18 01:40:23 --> Router Class Initialized
INFO - 2021-12-18 01:40:23 --> Output Class Initialized
INFO - 2021-12-18 01:40:23 --> Security Class Initialized
DEBUG - 2021-12-18 01:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:40:23 --> Input Class Initialized
INFO - 2021-12-18 01:40:23 --> Language Class Initialized
INFO - 2021-12-18 01:40:23 --> Language Class Initialized
INFO - 2021-12-18 01:40:23 --> Config Class Initialized
INFO - 2021-12-18 01:40:23 --> Loader Class Initialized
INFO - 2021-12-18 01:40:23 --> Helper loaded: url_helper
INFO - 2021-12-18 01:40:23 --> Helper loaded: file_helper
INFO - 2021-12-18 01:40:23 --> Helper loaded: form_helper
INFO - 2021-12-18 01:40:23 --> Helper loaded: my_helper
INFO - 2021-12-18 01:40:23 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:40:23 --> Controller Class Initialized
INFO - 2021-12-18 01:40:23 --> Helper loaded: cookie_helper
INFO - 2021-12-18 01:40:23 --> Final output sent to browser
DEBUG - 2021-12-18 01:40:23 --> Total execution time: 0.0530
INFO - 2021-12-18 01:40:23 --> Config Class Initialized
INFO - 2021-12-18 01:40:23 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:40:23 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:40:23 --> Utf8 Class Initialized
INFO - 2021-12-18 01:40:23 --> URI Class Initialized
INFO - 2021-12-18 01:40:23 --> Router Class Initialized
INFO - 2021-12-18 01:40:23 --> Output Class Initialized
INFO - 2021-12-18 01:40:23 --> Security Class Initialized
DEBUG - 2021-12-18 01:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:40:23 --> Input Class Initialized
INFO - 2021-12-18 01:40:23 --> Language Class Initialized
INFO - 2021-12-18 01:40:23 --> Language Class Initialized
INFO - 2021-12-18 01:40:23 --> Config Class Initialized
INFO - 2021-12-18 01:40:23 --> Loader Class Initialized
INFO - 2021-12-18 01:40:23 --> Helper loaded: url_helper
INFO - 2021-12-18 01:40:23 --> Helper loaded: file_helper
INFO - 2021-12-18 01:40:23 --> Helper loaded: form_helper
INFO - 2021-12-18 01:40:23 --> Helper loaded: my_helper
INFO - 2021-12-18 01:40:23 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:40:23 --> Controller Class Initialized
DEBUG - 2021-12-18 01:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-18 01:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:40:24 --> Final output sent to browser
DEBUG - 2021-12-18 01:40:24 --> Total execution time: 0.2320
INFO - 2021-12-18 01:41:09 --> Config Class Initialized
INFO - 2021-12-18 01:41:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:41:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:41:09 --> Utf8 Class Initialized
INFO - 2021-12-18 01:41:09 --> URI Class Initialized
INFO - 2021-12-18 01:41:09 --> Router Class Initialized
INFO - 2021-12-18 01:41:09 --> Output Class Initialized
INFO - 2021-12-18 01:41:09 --> Security Class Initialized
DEBUG - 2021-12-18 01:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:41:09 --> Input Class Initialized
INFO - 2021-12-18 01:41:09 --> Language Class Initialized
INFO - 2021-12-18 01:41:09 --> Language Class Initialized
INFO - 2021-12-18 01:41:09 --> Config Class Initialized
INFO - 2021-12-18 01:41:09 --> Loader Class Initialized
INFO - 2021-12-18 01:41:09 --> Helper loaded: url_helper
INFO - 2021-12-18 01:41:09 --> Helper loaded: file_helper
INFO - 2021-12-18 01:41:09 --> Helper loaded: form_helper
INFO - 2021-12-18 01:41:09 --> Helper loaded: my_helper
INFO - 2021-12-18 01:41:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:41:09 --> Controller Class Initialized
DEBUG - 2021-12-18 01:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:41:09 --> Final output sent to browser
DEBUG - 2021-12-18 01:41:09 --> Total execution time: 0.0350
INFO - 2021-12-18 01:41:10 --> Config Class Initialized
INFO - 2021-12-18 01:41:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:41:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:41:10 --> Utf8 Class Initialized
INFO - 2021-12-18 01:41:10 --> URI Class Initialized
INFO - 2021-12-18 01:41:10 --> Router Class Initialized
INFO - 2021-12-18 01:41:10 --> Output Class Initialized
INFO - 2021-12-18 01:41:10 --> Security Class Initialized
DEBUG - 2021-12-18 01:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:41:10 --> Input Class Initialized
INFO - 2021-12-18 01:41:10 --> Language Class Initialized
INFO - 2021-12-18 01:41:10 --> Language Class Initialized
INFO - 2021-12-18 01:41:10 --> Config Class Initialized
INFO - 2021-12-18 01:41:10 --> Loader Class Initialized
INFO - 2021-12-18 01:41:10 --> Helper loaded: url_helper
INFO - 2021-12-18 01:41:10 --> Helper loaded: file_helper
INFO - 2021-12-18 01:41:10 --> Helper loaded: form_helper
INFO - 2021-12-18 01:41:10 --> Helper loaded: my_helper
INFO - 2021-12-18 01:41:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:41:10 --> Controller Class Initialized
INFO - 2021-12-18 01:41:17 --> Config Class Initialized
INFO - 2021-12-18 01:41:17 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:41:17 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:41:17 --> Utf8 Class Initialized
INFO - 2021-12-18 01:41:17 --> URI Class Initialized
INFO - 2021-12-18 01:41:17 --> Router Class Initialized
INFO - 2021-12-18 01:41:17 --> Output Class Initialized
INFO - 2021-12-18 01:41:17 --> Security Class Initialized
DEBUG - 2021-12-18 01:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:41:17 --> Input Class Initialized
INFO - 2021-12-18 01:41:17 --> Language Class Initialized
INFO - 2021-12-18 01:41:17 --> Language Class Initialized
INFO - 2021-12-18 01:41:17 --> Config Class Initialized
INFO - 2021-12-18 01:41:17 --> Loader Class Initialized
INFO - 2021-12-18 01:41:17 --> Helper loaded: url_helper
INFO - 2021-12-18 01:41:17 --> Helper loaded: file_helper
INFO - 2021-12-18 01:41:17 --> Helper loaded: form_helper
INFO - 2021-12-18 01:41:17 --> Helper loaded: my_helper
INFO - 2021-12-18 01:41:17 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:41:17 --> Controller Class Initialized
INFO - 2021-12-18 01:41:17 --> Config Class Initialized
INFO - 2021-12-18 01:41:17 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:41:17 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:41:17 --> Utf8 Class Initialized
INFO - 2021-12-18 01:41:17 --> URI Class Initialized
INFO - 2021-12-18 01:41:17 --> Router Class Initialized
INFO - 2021-12-18 01:41:17 --> Output Class Initialized
INFO - 2021-12-18 01:41:17 --> Security Class Initialized
DEBUG - 2021-12-18 01:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:41:17 --> Input Class Initialized
INFO - 2021-12-18 01:41:17 --> Language Class Initialized
INFO - 2021-12-18 01:41:17 --> Language Class Initialized
INFO - 2021-12-18 01:41:17 --> Config Class Initialized
INFO - 2021-12-18 01:41:17 --> Loader Class Initialized
INFO - 2021-12-18 01:41:17 --> Helper loaded: url_helper
INFO - 2021-12-18 01:41:17 --> Helper loaded: file_helper
INFO - 2021-12-18 01:41:17 --> Helper loaded: form_helper
INFO - 2021-12-18 01:41:17 --> Helper loaded: my_helper
INFO - 2021-12-18 01:41:17 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:41:17 --> Controller Class Initialized
INFO - 2021-12-18 01:41:18 --> Config Class Initialized
INFO - 2021-12-18 01:41:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:41:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:41:18 --> Utf8 Class Initialized
INFO - 2021-12-18 01:41:18 --> URI Class Initialized
INFO - 2021-12-18 01:41:18 --> Router Class Initialized
INFO - 2021-12-18 01:41:18 --> Output Class Initialized
INFO - 2021-12-18 01:41:18 --> Security Class Initialized
DEBUG - 2021-12-18 01:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:41:18 --> Input Class Initialized
INFO - 2021-12-18 01:41:18 --> Language Class Initialized
INFO - 2021-12-18 01:41:18 --> Language Class Initialized
INFO - 2021-12-18 01:41:18 --> Config Class Initialized
INFO - 2021-12-18 01:41:18 --> Loader Class Initialized
INFO - 2021-12-18 01:41:18 --> Helper loaded: url_helper
INFO - 2021-12-18 01:41:18 --> Helper loaded: file_helper
INFO - 2021-12-18 01:41:18 --> Helper loaded: form_helper
INFO - 2021-12-18 01:41:18 --> Helper loaded: my_helper
INFO - 2021-12-18 01:41:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:41:18 --> Controller Class Initialized
INFO - 2021-12-18 01:41:50 --> Config Class Initialized
INFO - 2021-12-18 01:41:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:41:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:41:50 --> Utf8 Class Initialized
INFO - 2021-12-18 01:41:50 --> URI Class Initialized
INFO - 2021-12-18 01:41:50 --> Router Class Initialized
INFO - 2021-12-18 01:41:50 --> Output Class Initialized
INFO - 2021-12-18 01:41:50 --> Security Class Initialized
DEBUG - 2021-12-18 01:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:41:50 --> Input Class Initialized
INFO - 2021-12-18 01:41:50 --> Language Class Initialized
INFO - 2021-12-18 01:41:50 --> Language Class Initialized
INFO - 2021-12-18 01:41:50 --> Config Class Initialized
INFO - 2021-12-18 01:41:50 --> Loader Class Initialized
INFO - 2021-12-18 01:41:50 --> Helper loaded: url_helper
INFO - 2021-12-18 01:41:50 --> Helper loaded: file_helper
INFO - 2021-12-18 01:41:50 --> Helper loaded: form_helper
INFO - 2021-12-18 01:41:50 --> Helper loaded: my_helper
INFO - 2021-12-18 01:41:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:41:50 --> Controller Class Initialized
INFO - 2021-12-18 01:42:03 --> Config Class Initialized
INFO - 2021-12-18 01:42:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:03 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:03 --> URI Class Initialized
INFO - 2021-12-18 01:42:03 --> Router Class Initialized
INFO - 2021-12-18 01:42:03 --> Output Class Initialized
INFO - 2021-12-18 01:42:03 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:03 --> Input Class Initialized
INFO - 2021-12-18 01:42:03 --> Language Class Initialized
INFO - 2021-12-18 01:42:03 --> Language Class Initialized
INFO - 2021-12-18 01:42:03 --> Config Class Initialized
INFO - 2021-12-18 01:42:03 --> Loader Class Initialized
INFO - 2021-12-18 01:42:03 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:03 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:03 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:03 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:03 --> Controller Class Initialized
INFO - 2021-12-18 01:42:04 --> Config Class Initialized
INFO - 2021-12-18 01:42:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:04 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:04 --> URI Class Initialized
INFO - 2021-12-18 01:42:04 --> Router Class Initialized
INFO - 2021-12-18 01:42:04 --> Output Class Initialized
INFO - 2021-12-18 01:42:04 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:04 --> Input Class Initialized
INFO - 2021-12-18 01:42:04 --> Language Class Initialized
INFO - 2021-12-18 01:42:04 --> Language Class Initialized
INFO - 2021-12-18 01:42:04 --> Config Class Initialized
INFO - 2021-12-18 01:42:04 --> Loader Class Initialized
INFO - 2021-12-18 01:42:04 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:04 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:04 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:04 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:04 --> Controller Class Initialized
INFO - 2021-12-18 01:42:05 --> Config Class Initialized
INFO - 2021-12-18 01:42:05 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:05 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:05 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:05 --> URI Class Initialized
INFO - 2021-12-18 01:42:05 --> Router Class Initialized
INFO - 2021-12-18 01:42:05 --> Output Class Initialized
INFO - 2021-12-18 01:42:05 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:05 --> Input Class Initialized
INFO - 2021-12-18 01:42:05 --> Language Class Initialized
INFO - 2021-12-18 01:42:05 --> Language Class Initialized
INFO - 2021-12-18 01:42:05 --> Config Class Initialized
INFO - 2021-12-18 01:42:05 --> Loader Class Initialized
INFO - 2021-12-18 01:42:05 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:05 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:05 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:05 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:05 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:05 --> Controller Class Initialized
INFO - 2021-12-18 01:42:13 --> Config Class Initialized
INFO - 2021-12-18 01:42:13 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:13 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:13 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:13 --> URI Class Initialized
INFO - 2021-12-18 01:42:13 --> Router Class Initialized
INFO - 2021-12-18 01:42:13 --> Output Class Initialized
INFO - 2021-12-18 01:42:13 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:13 --> Input Class Initialized
INFO - 2021-12-18 01:42:13 --> Language Class Initialized
INFO - 2021-12-18 01:42:13 --> Language Class Initialized
INFO - 2021-12-18 01:42:13 --> Config Class Initialized
INFO - 2021-12-18 01:42:13 --> Loader Class Initialized
INFO - 2021-12-18 01:42:13 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:13 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:13 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:13 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:13 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:13 --> Controller Class Initialized
INFO - 2021-12-18 01:42:26 --> Config Class Initialized
INFO - 2021-12-18 01:42:26 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:26 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:26 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:26 --> URI Class Initialized
INFO - 2021-12-18 01:42:26 --> Router Class Initialized
INFO - 2021-12-18 01:42:26 --> Output Class Initialized
INFO - 2021-12-18 01:42:26 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:26 --> Input Class Initialized
INFO - 2021-12-18 01:42:26 --> Language Class Initialized
INFO - 2021-12-18 01:42:26 --> Language Class Initialized
INFO - 2021-12-18 01:42:26 --> Config Class Initialized
INFO - 2021-12-18 01:42:26 --> Loader Class Initialized
INFO - 2021-12-18 01:42:26 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:26 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:26 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:26 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:26 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:26 --> Controller Class Initialized
INFO - 2021-12-18 01:42:26 --> Config Class Initialized
INFO - 2021-12-18 01:42:26 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:26 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:26 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:26 --> URI Class Initialized
INFO - 2021-12-18 01:42:26 --> Router Class Initialized
INFO - 2021-12-18 01:42:26 --> Output Class Initialized
INFO - 2021-12-18 01:42:26 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:26 --> Input Class Initialized
INFO - 2021-12-18 01:42:26 --> Language Class Initialized
INFO - 2021-12-18 01:42:26 --> Language Class Initialized
INFO - 2021-12-18 01:42:26 --> Config Class Initialized
INFO - 2021-12-18 01:42:26 --> Loader Class Initialized
INFO - 2021-12-18 01:42:26 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:26 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:26 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:26 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:26 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:26 --> Controller Class Initialized
INFO - 2021-12-18 01:42:27 --> Config Class Initialized
INFO - 2021-12-18 01:42:27 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:27 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:27 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:27 --> URI Class Initialized
INFO - 2021-12-18 01:42:27 --> Router Class Initialized
INFO - 2021-12-18 01:42:27 --> Output Class Initialized
INFO - 2021-12-18 01:42:27 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:27 --> Input Class Initialized
INFO - 2021-12-18 01:42:27 --> Language Class Initialized
INFO - 2021-12-18 01:42:27 --> Language Class Initialized
INFO - 2021-12-18 01:42:27 --> Config Class Initialized
INFO - 2021-12-18 01:42:27 --> Loader Class Initialized
INFO - 2021-12-18 01:42:27 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:27 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:27 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:27 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:27 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:27 --> Controller Class Initialized
INFO - 2021-12-18 01:42:27 --> Config Class Initialized
INFO - 2021-12-18 01:42:27 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:27 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:27 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:27 --> URI Class Initialized
INFO - 2021-12-18 01:42:27 --> Router Class Initialized
INFO - 2021-12-18 01:42:27 --> Output Class Initialized
INFO - 2021-12-18 01:42:27 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:27 --> Input Class Initialized
INFO - 2021-12-18 01:42:27 --> Language Class Initialized
INFO - 2021-12-18 01:42:27 --> Language Class Initialized
INFO - 2021-12-18 01:42:27 --> Config Class Initialized
INFO - 2021-12-18 01:42:27 --> Loader Class Initialized
INFO - 2021-12-18 01:42:27 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:27 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:27 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:27 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:27 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:27 --> Controller Class Initialized
INFO - 2021-12-18 01:42:28 --> Config Class Initialized
INFO - 2021-12-18 01:42:28 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:28 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:28 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:28 --> URI Class Initialized
INFO - 2021-12-18 01:42:28 --> Router Class Initialized
INFO - 2021-12-18 01:42:28 --> Output Class Initialized
INFO - 2021-12-18 01:42:28 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:28 --> Input Class Initialized
INFO - 2021-12-18 01:42:28 --> Language Class Initialized
INFO - 2021-12-18 01:42:28 --> Language Class Initialized
INFO - 2021-12-18 01:42:28 --> Config Class Initialized
INFO - 2021-12-18 01:42:28 --> Loader Class Initialized
INFO - 2021-12-18 01:42:28 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:28 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:28 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:28 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:28 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:28 --> Controller Class Initialized
INFO - 2021-12-18 01:42:28 --> Config Class Initialized
INFO - 2021-12-18 01:42:28 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:28 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:28 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:28 --> URI Class Initialized
INFO - 2021-12-18 01:42:28 --> Router Class Initialized
INFO - 2021-12-18 01:42:28 --> Output Class Initialized
INFO - 2021-12-18 01:42:28 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:28 --> Input Class Initialized
INFO - 2021-12-18 01:42:28 --> Language Class Initialized
INFO - 2021-12-18 01:42:28 --> Language Class Initialized
INFO - 2021-12-18 01:42:28 --> Config Class Initialized
INFO - 2021-12-18 01:42:28 --> Loader Class Initialized
INFO - 2021-12-18 01:42:28 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:28 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:28 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:28 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:28 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:28 --> Controller Class Initialized
INFO - 2021-12-18 01:42:28 --> Config Class Initialized
INFO - 2021-12-18 01:42:28 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:28 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:28 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:28 --> URI Class Initialized
INFO - 2021-12-18 01:42:29 --> Router Class Initialized
INFO - 2021-12-18 01:42:29 --> Output Class Initialized
INFO - 2021-12-18 01:42:29 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:29 --> Input Class Initialized
INFO - 2021-12-18 01:42:29 --> Language Class Initialized
INFO - 2021-12-18 01:42:29 --> Language Class Initialized
INFO - 2021-12-18 01:42:29 --> Config Class Initialized
INFO - 2021-12-18 01:42:29 --> Loader Class Initialized
INFO - 2021-12-18 01:42:29 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:29 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:29 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:29 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:29 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:29 --> Controller Class Initialized
INFO - 2021-12-18 01:42:29 --> Config Class Initialized
INFO - 2021-12-18 01:42:29 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:29 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:29 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:29 --> URI Class Initialized
INFO - 2021-12-18 01:42:29 --> Router Class Initialized
INFO - 2021-12-18 01:42:29 --> Output Class Initialized
INFO - 2021-12-18 01:42:29 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:29 --> Input Class Initialized
INFO - 2021-12-18 01:42:29 --> Language Class Initialized
INFO - 2021-12-18 01:42:29 --> Language Class Initialized
INFO - 2021-12-18 01:42:29 --> Config Class Initialized
INFO - 2021-12-18 01:42:29 --> Loader Class Initialized
INFO - 2021-12-18 01:42:29 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:29 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:29 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:29 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:29 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:29 --> Controller Class Initialized
INFO - 2021-12-18 01:42:30 --> Config Class Initialized
INFO - 2021-12-18 01:42:30 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:30 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:30 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:30 --> URI Class Initialized
INFO - 2021-12-18 01:42:30 --> Router Class Initialized
INFO - 2021-12-18 01:42:30 --> Output Class Initialized
INFO - 2021-12-18 01:42:30 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:30 --> Input Class Initialized
INFO - 2021-12-18 01:42:30 --> Language Class Initialized
INFO - 2021-12-18 01:42:30 --> Language Class Initialized
INFO - 2021-12-18 01:42:30 --> Config Class Initialized
INFO - 2021-12-18 01:42:30 --> Loader Class Initialized
INFO - 2021-12-18 01:42:30 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:30 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:30 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:30 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:30 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:30 --> Controller Class Initialized
INFO - 2021-12-18 01:42:36 --> Config Class Initialized
INFO - 2021-12-18 01:42:36 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:36 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:36 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:36 --> URI Class Initialized
INFO - 2021-12-18 01:42:36 --> Router Class Initialized
INFO - 2021-12-18 01:42:36 --> Output Class Initialized
INFO - 2021-12-18 01:42:36 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:36 --> Input Class Initialized
INFO - 2021-12-18 01:42:36 --> Language Class Initialized
INFO - 2021-12-18 01:42:36 --> Language Class Initialized
INFO - 2021-12-18 01:42:36 --> Config Class Initialized
INFO - 2021-12-18 01:42:36 --> Loader Class Initialized
INFO - 2021-12-18 01:42:36 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:36 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:36 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:36 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:36 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:36 --> Controller Class Initialized
INFO - 2021-12-18 01:42:36 --> Final output sent to browser
DEBUG - 2021-12-18 01:42:36 --> Total execution time: 0.0530
INFO - 2021-12-18 01:42:36 --> Config Class Initialized
INFO - 2021-12-18 01:42:36 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:36 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:36 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:36 --> URI Class Initialized
INFO - 2021-12-18 01:42:36 --> Router Class Initialized
INFO - 2021-12-18 01:42:36 --> Output Class Initialized
INFO - 2021-12-18 01:42:36 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:36 --> Input Class Initialized
INFO - 2021-12-18 01:42:36 --> Language Class Initialized
INFO - 2021-12-18 01:42:36 --> Language Class Initialized
INFO - 2021-12-18 01:42:36 --> Config Class Initialized
INFO - 2021-12-18 01:42:36 --> Loader Class Initialized
INFO - 2021-12-18 01:42:36 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:36 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:36 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:36 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:36 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:36 --> Controller Class Initialized
INFO - 2021-12-18 01:42:37 --> Config Class Initialized
INFO - 2021-12-18 01:42:37 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:42:37 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:42:37 --> Utf8 Class Initialized
INFO - 2021-12-18 01:42:37 --> URI Class Initialized
INFO - 2021-12-18 01:42:37 --> Router Class Initialized
INFO - 2021-12-18 01:42:37 --> Output Class Initialized
INFO - 2021-12-18 01:42:37 --> Security Class Initialized
DEBUG - 2021-12-18 01:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:42:37 --> Input Class Initialized
INFO - 2021-12-18 01:42:37 --> Language Class Initialized
INFO - 2021-12-18 01:42:37 --> Language Class Initialized
INFO - 2021-12-18 01:42:37 --> Config Class Initialized
INFO - 2021-12-18 01:42:37 --> Loader Class Initialized
INFO - 2021-12-18 01:42:37 --> Helper loaded: url_helper
INFO - 2021-12-18 01:42:37 --> Helper loaded: file_helper
INFO - 2021-12-18 01:42:37 --> Helper loaded: form_helper
INFO - 2021-12-18 01:42:37 --> Helper loaded: my_helper
INFO - 2021-12-18 01:42:37 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:42:37 --> Controller Class Initialized
DEBUG - 2021-12-18 01:42:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:42:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:42:37 --> Final output sent to browser
DEBUG - 2021-12-18 01:42:37 --> Total execution time: 0.0530
INFO - 2021-12-18 01:43:12 --> Config Class Initialized
INFO - 2021-12-18 01:43:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:12 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:12 --> URI Class Initialized
INFO - 2021-12-18 01:43:12 --> Router Class Initialized
INFO - 2021-12-18 01:43:12 --> Output Class Initialized
INFO - 2021-12-18 01:43:12 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:12 --> Input Class Initialized
INFO - 2021-12-18 01:43:12 --> Language Class Initialized
INFO - 2021-12-18 01:43:12 --> Language Class Initialized
INFO - 2021-12-18 01:43:12 --> Config Class Initialized
INFO - 2021-12-18 01:43:12 --> Loader Class Initialized
INFO - 2021-12-18 01:43:12 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:12 --> Controller Class Initialized
INFO - 2021-12-18 01:43:12 --> Config Class Initialized
INFO - 2021-12-18 01:43:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:12 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:12 --> URI Class Initialized
INFO - 2021-12-18 01:43:12 --> Router Class Initialized
INFO - 2021-12-18 01:43:12 --> Output Class Initialized
INFO - 2021-12-18 01:43:12 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:12 --> Input Class Initialized
INFO - 2021-12-18 01:43:12 --> Language Class Initialized
INFO - 2021-12-18 01:43:12 --> Language Class Initialized
INFO - 2021-12-18 01:43:12 --> Config Class Initialized
INFO - 2021-12-18 01:43:12 --> Loader Class Initialized
INFO - 2021-12-18 01:43:12 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:12 --> Controller Class Initialized
DEBUG - 2021-12-18 01:43:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:43:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:43:12 --> Final output sent to browser
DEBUG - 2021-12-18 01:43:12 --> Total execution time: 0.0370
INFO - 2021-12-18 01:43:12 --> Config Class Initialized
INFO - 2021-12-18 01:43:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:12 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:12 --> URI Class Initialized
INFO - 2021-12-18 01:43:12 --> Router Class Initialized
INFO - 2021-12-18 01:43:12 --> Output Class Initialized
INFO - 2021-12-18 01:43:12 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:12 --> Input Class Initialized
INFO - 2021-12-18 01:43:12 --> Language Class Initialized
INFO - 2021-12-18 01:43:12 --> Language Class Initialized
INFO - 2021-12-18 01:43:12 --> Config Class Initialized
INFO - 2021-12-18 01:43:12 --> Loader Class Initialized
INFO - 2021-12-18 01:43:12 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:12 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:12 --> Controller Class Initialized
INFO - 2021-12-18 01:43:23 --> Config Class Initialized
INFO - 2021-12-18 01:43:23 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:23 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:23 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:23 --> URI Class Initialized
INFO - 2021-12-18 01:43:23 --> Router Class Initialized
INFO - 2021-12-18 01:43:23 --> Output Class Initialized
INFO - 2021-12-18 01:43:23 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:23 --> Input Class Initialized
INFO - 2021-12-18 01:43:23 --> Language Class Initialized
INFO - 2021-12-18 01:43:23 --> Language Class Initialized
INFO - 2021-12-18 01:43:23 --> Config Class Initialized
INFO - 2021-12-18 01:43:23 --> Loader Class Initialized
INFO - 2021-12-18 01:43:23 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:23 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:23 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:23 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:23 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:23 --> Controller Class Initialized
INFO - 2021-12-18 01:43:24 --> Config Class Initialized
INFO - 2021-12-18 01:43:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:24 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:24 --> URI Class Initialized
INFO - 2021-12-18 01:43:24 --> Router Class Initialized
INFO - 2021-12-18 01:43:24 --> Output Class Initialized
INFO - 2021-12-18 01:43:24 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:24 --> Input Class Initialized
INFO - 2021-12-18 01:43:24 --> Language Class Initialized
INFO - 2021-12-18 01:43:24 --> Language Class Initialized
INFO - 2021-12-18 01:43:24 --> Config Class Initialized
INFO - 2021-12-18 01:43:24 --> Loader Class Initialized
INFO - 2021-12-18 01:43:24 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:24 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:24 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:24 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:24 --> Controller Class Initialized
INFO - 2021-12-18 01:43:31 --> Config Class Initialized
INFO - 2021-12-18 01:43:31 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:31 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:31 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:31 --> URI Class Initialized
INFO - 2021-12-18 01:43:31 --> Router Class Initialized
INFO - 2021-12-18 01:43:31 --> Output Class Initialized
INFO - 2021-12-18 01:43:31 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:31 --> Input Class Initialized
INFO - 2021-12-18 01:43:31 --> Language Class Initialized
INFO - 2021-12-18 01:43:31 --> Language Class Initialized
INFO - 2021-12-18 01:43:31 --> Config Class Initialized
INFO - 2021-12-18 01:43:31 --> Loader Class Initialized
INFO - 2021-12-18 01:43:31 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:31 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:31 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:31 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:31 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:31 --> Controller Class Initialized
DEBUG - 2021-12-18 01:43:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:43:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:43:31 --> Final output sent to browser
DEBUG - 2021-12-18 01:43:31 --> Total execution time: 0.0440
INFO - 2021-12-18 01:43:42 --> Config Class Initialized
INFO - 2021-12-18 01:43:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:42 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:42 --> URI Class Initialized
INFO - 2021-12-18 01:43:42 --> Router Class Initialized
INFO - 2021-12-18 01:43:42 --> Output Class Initialized
INFO - 2021-12-18 01:43:42 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:42 --> Input Class Initialized
INFO - 2021-12-18 01:43:42 --> Language Class Initialized
INFO - 2021-12-18 01:43:42 --> Language Class Initialized
INFO - 2021-12-18 01:43:42 --> Config Class Initialized
INFO - 2021-12-18 01:43:42 --> Loader Class Initialized
INFO - 2021-12-18 01:43:42 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:42 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:42 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:42 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:42 --> Controller Class Initialized
DEBUG - 2021-12-18 01:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-18 01:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:43:42 --> Final output sent to browser
DEBUG - 2021-12-18 01:43:42 --> Total execution time: 0.0630
INFO - 2021-12-18 01:43:42 --> Config Class Initialized
INFO - 2021-12-18 01:43:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:42 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:42 --> URI Class Initialized
INFO - 2021-12-18 01:43:42 --> Router Class Initialized
INFO - 2021-12-18 01:43:42 --> Output Class Initialized
INFO - 2021-12-18 01:43:42 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:42 --> Input Class Initialized
INFO - 2021-12-18 01:43:42 --> Language Class Initialized
INFO - 2021-12-18 01:43:42 --> Language Class Initialized
INFO - 2021-12-18 01:43:42 --> Config Class Initialized
INFO - 2021-12-18 01:43:42 --> Loader Class Initialized
INFO - 2021-12-18 01:43:42 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:42 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:42 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:42 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:42 --> Controller Class Initialized
INFO - 2021-12-18 01:43:44 --> Config Class Initialized
INFO - 2021-12-18 01:43:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:43:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:43:44 --> Utf8 Class Initialized
INFO - 2021-12-18 01:43:44 --> URI Class Initialized
INFO - 2021-12-18 01:43:44 --> Router Class Initialized
INFO - 2021-12-18 01:43:44 --> Output Class Initialized
INFO - 2021-12-18 01:43:44 --> Security Class Initialized
DEBUG - 2021-12-18 01:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:43:44 --> Input Class Initialized
INFO - 2021-12-18 01:43:44 --> Language Class Initialized
INFO - 2021-12-18 01:43:44 --> Language Class Initialized
INFO - 2021-12-18 01:43:44 --> Config Class Initialized
INFO - 2021-12-18 01:43:44 --> Loader Class Initialized
INFO - 2021-12-18 01:43:44 --> Helper loaded: url_helper
INFO - 2021-12-18 01:43:44 --> Helper loaded: file_helper
INFO - 2021-12-18 01:43:44 --> Helper loaded: form_helper
INFO - 2021-12-18 01:43:44 --> Helper loaded: my_helper
INFO - 2021-12-18 01:43:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:43:44 --> Controller Class Initialized
INFO - 2021-12-18 01:43:44 --> Final output sent to browser
DEBUG - 2021-12-18 01:43:44 --> Total execution time: 0.0380
INFO - 2021-12-18 01:44:19 --> Config Class Initialized
INFO - 2021-12-18 01:44:19 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:44:19 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:44:19 --> Utf8 Class Initialized
INFO - 2021-12-18 01:44:19 --> URI Class Initialized
INFO - 2021-12-18 01:44:19 --> Router Class Initialized
INFO - 2021-12-18 01:44:19 --> Output Class Initialized
INFO - 2021-12-18 01:44:19 --> Security Class Initialized
DEBUG - 2021-12-18 01:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:44:19 --> Input Class Initialized
INFO - 2021-12-18 01:44:19 --> Language Class Initialized
INFO - 2021-12-18 01:44:19 --> Language Class Initialized
INFO - 2021-12-18 01:44:19 --> Config Class Initialized
INFO - 2021-12-18 01:44:19 --> Loader Class Initialized
INFO - 2021-12-18 01:44:19 --> Helper loaded: url_helper
INFO - 2021-12-18 01:44:19 --> Helper loaded: file_helper
INFO - 2021-12-18 01:44:19 --> Helper loaded: form_helper
INFO - 2021-12-18 01:44:19 --> Helper loaded: my_helper
INFO - 2021-12-18 01:44:19 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:44:19 --> Controller Class Initialized
INFO - 2021-12-18 01:44:19 --> Final output sent to browser
DEBUG - 2021-12-18 01:44:19 --> Total execution time: 0.0440
INFO - 2021-12-18 01:44:19 --> Config Class Initialized
INFO - 2021-12-18 01:44:19 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:44:19 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:44:19 --> Utf8 Class Initialized
INFO - 2021-12-18 01:44:19 --> URI Class Initialized
INFO - 2021-12-18 01:44:19 --> Router Class Initialized
INFO - 2021-12-18 01:44:19 --> Output Class Initialized
INFO - 2021-12-18 01:44:19 --> Security Class Initialized
DEBUG - 2021-12-18 01:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:44:19 --> Input Class Initialized
INFO - 2021-12-18 01:44:19 --> Language Class Initialized
INFO - 2021-12-18 01:44:19 --> Language Class Initialized
INFO - 2021-12-18 01:44:19 --> Config Class Initialized
INFO - 2021-12-18 01:44:19 --> Loader Class Initialized
INFO - 2021-12-18 01:44:19 --> Helper loaded: url_helper
INFO - 2021-12-18 01:44:19 --> Helper loaded: file_helper
INFO - 2021-12-18 01:44:19 --> Helper loaded: form_helper
INFO - 2021-12-18 01:44:19 --> Helper loaded: my_helper
INFO - 2021-12-18 01:44:19 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:44:19 --> Controller Class Initialized
INFO - 2021-12-18 01:44:22 --> Config Class Initialized
INFO - 2021-12-18 01:44:22 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:44:22 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:44:22 --> Utf8 Class Initialized
INFO - 2021-12-18 01:44:22 --> URI Class Initialized
INFO - 2021-12-18 01:44:22 --> Router Class Initialized
INFO - 2021-12-18 01:44:22 --> Output Class Initialized
INFO - 2021-12-18 01:44:22 --> Security Class Initialized
DEBUG - 2021-12-18 01:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:44:22 --> Input Class Initialized
INFO - 2021-12-18 01:44:22 --> Language Class Initialized
INFO - 2021-12-18 01:44:22 --> Language Class Initialized
INFO - 2021-12-18 01:44:22 --> Config Class Initialized
INFO - 2021-12-18 01:44:22 --> Loader Class Initialized
INFO - 2021-12-18 01:44:22 --> Helper loaded: url_helper
INFO - 2021-12-18 01:44:22 --> Helper loaded: file_helper
INFO - 2021-12-18 01:44:22 --> Helper loaded: form_helper
INFO - 2021-12-18 01:44:22 --> Helper loaded: my_helper
INFO - 2021-12-18 01:44:22 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:44:22 --> Controller Class Initialized
INFO - 2021-12-18 01:44:22 --> Config Class Initialized
INFO - 2021-12-18 01:44:22 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:44:22 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:44:22 --> Utf8 Class Initialized
INFO - 2021-12-18 01:44:22 --> URI Class Initialized
INFO - 2021-12-18 01:44:22 --> Router Class Initialized
INFO - 2021-12-18 01:44:22 --> Output Class Initialized
INFO - 2021-12-18 01:44:22 --> Security Class Initialized
DEBUG - 2021-12-18 01:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:44:22 --> Input Class Initialized
INFO - 2021-12-18 01:44:22 --> Language Class Initialized
INFO - 2021-12-18 01:44:22 --> Language Class Initialized
INFO - 2021-12-18 01:44:22 --> Config Class Initialized
INFO - 2021-12-18 01:44:22 --> Loader Class Initialized
INFO - 2021-12-18 01:44:22 --> Helper loaded: url_helper
INFO - 2021-12-18 01:44:22 --> Helper loaded: file_helper
INFO - 2021-12-18 01:44:22 --> Helper loaded: form_helper
INFO - 2021-12-18 01:44:22 --> Helper loaded: my_helper
INFO - 2021-12-18 01:44:22 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:44:22 --> Controller Class Initialized
INFO - 2021-12-18 01:44:23 --> Config Class Initialized
INFO - 2021-12-18 01:44:23 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:44:23 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:44:23 --> Utf8 Class Initialized
INFO - 2021-12-18 01:44:23 --> URI Class Initialized
INFO - 2021-12-18 01:44:23 --> Router Class Initialized
INFO - 2021-12-18 01:44:23 --> Output Class Initialized
INFO - 2021-12-18 01:44:23 --> Security Class Initialized
DEBUG - 2021-12-18 01:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:44:23 --> Input Class Initialized
INFO - 2021-12-18 01:44:23 --> Language Class Initialized
INFO - 2021-12-18 01:44:23 --> Language Class Initialized
INFO - 2021-12-18 01:44:23 --> Config Class Initialized
INFO - 2021-12-18 01:44:23 --> Loader Class Initialized
INFO - 2021-12-18 01:44:23 --> Helper loaded: url_helper
INFO - 2021-12-18 01:44:23 --> Helper loaded: file_helper
INFO - 2021-12-18 01:44:23 --> Helper loaded: form_helper
INFO - 2021-12-18 01:44:23 --> Helper loaded: my_helper
INFO - 2021-12-18 01:44:23 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:44:23 --> Controller Class Initialized
INFO - 2021-12-18 01:44:27 --> Config Class Initialized
INFO - 2021-12-18 01:44:27 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:44:27 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:44:27 --> Utf8 Class Initialized
INFO - 2021-12-18 01:44:27 --> URI Class Initialized
INFO - 2021-12-18 01:44:27 --> Router Class Initialized
INFO - 2021-12-18 01:44:27 --> Output Class Initialized
INFO - 2021-12-18 01:44:27 --> Security Class Initialized
DEBUG - 2021-12-18 01:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:44:27 --> Input Class Initialized
INFO - 2021-12-18 01:44:27 --> Language Class Initialized
INFO - 2021-12-18 01:44:27 --> Language Class Initialized
INFO - 2021-12-18 01:44:27 --> Config Class Initialized
INFO - 2021-12-18 01:44:27 --> Loader Class Initialized
INFO - 2021-12-18 01:44:27 --> Helper loaded: url_helper
INFO - 2021-12-18 01:44:27 --> Helper loaded: file_helper
INFO - 2021-12-18 01:44:27 --> Helper loaded: form_helper
INFO - 2021-12-18 01:44:27 --> Helper loaded: my_helper
INFO - 2021-12-18 01:44:27 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:44:27 --> Controller Class Initialized
DEBUG - 2021-12-18 01:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:44:27 --> Final output sent to browser
DEBUG - 2021-12-18 01:44:27 --> Total execution time: 0.0480
INFO - 2021-12-18 01:44:27 --> Config Class Initialized
INFO - 2021-12-18 01:44:27 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:44:27 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:44:27 --> Utf8 Class Initialized
INFO - 2021-12-18 01:44:27 --> URI Class Initialized
INFO - 2021-12-18 01:44:27 --> Router Class Initialized
INFO - 2021-12-18 01:44:27 --> Output Class Initialized
INFO - 2021-12-18 01:44:27 --> Security Class Initialized
DEBUG - 2021-12-18 01:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:44:27 --> Input Class Initialized
INFO - 2021-12-18 01:44:27 --> Language Class Initialized
INFO - 2021-12-18 01:44:27 --> Language Class Initialized
INFO - 2021-12-18 01:44:27 --> Config Class Initialized
INFO - 2021-12-18 01:44:27 --> Loader Class Initialized
INFO - 2021-12-18 01:44:27 --> Helper loaded: url_helper
INFO - 2021-12-18 01:44:27 --> Helper loaded: file_helper
INFO - 2021-12-18 01:44:27 --> Helper loaded: form_helper
INFO - 2021-12-18 01:44:27 --> Helper loaded: my_helper
INFO - 2021-12-18 01:44:27 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:44:27 --> Controller Class Initialized
INFO - 2021-12-18 01:44:28 --> Config Class Initialized
INFO - 2021-12-18 01:44:28 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:44:28 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:44:28 --> Utf8 Class Initialized
INFO - 2021-12-18 01:44:28 --> URI Class Initialized
INFO - 2021-12-18 01:44:28 --> Router Class Initialized
INFO - 2021-12-18 01:44:28 --> Output Class Initialized
INFO - 2021-12-18 01:44:28 --> Security Class Initialized
DEBUG - 2021-12-18 01:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:44:28 --> Input Class Initialized
INFO - 2021-12-18 01:44:28 --> Language Class Initialized
INFO - 2021-12-18 01:44:28 --> Language Class Initialized
INFO - 2021-12-18 01:44:28 --> Config Class Initialized
INFO - 2021-12-18 01:44:28 --> Loader Class Initialized
INFO - 2021-12-18 01:44:28 --> Helper loaded: url_helper
INFO - 2021-12-18 01:44:28 --> Helper loaded: file_helper
INFO - 2021-12-18 01:44:28 --> Helper loaded: form_helper
INFO - 2021-12-18 01:44:28 --> Helper loaded: my_helper
INFO - 2021-12-18 01:44:28 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:44:28 --> Controller Class Initialized
DEBUG - 2021-12-18 01:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:44:28 --> Final output sent to browser
DEBUG - 2021-12-18 01:44:28 --> Total execution time: 0.0480
INFO - 2021-12-18 01:45:34 --> Config Class Initialized
INFO - 2021-12-18 01:45:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:34 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:34 --> URI Class Initialized
INFO - 2021-12-18 01:45:34 --> Router Class Initialized
INFO - 2021-12-18 01:45:34 --> Output Class Initialized
INFO - 2021-12-18 01:45:34 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:34 --> Input Class Initialized
INFO - 2021-12-18 01:45:34 --> Language Class Initialized
INFO - 2021-12-18 01:45:34 --> Language Class Initialized
INFO - 2021-12-18 01:45:34 --> Config Class Initialized
INFO - 2021-12-18 01:45:34 --> Loader Class Initialized
INFO - 2021-12-18 01:45:34 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:34 --> Controller Class Initialized
INFO - 2021-12-18 01:45:34 --> Config Class Initialized
INFO - 2021-12-18 01:45:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:34 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:34 --> URI Class Initialized
INFO - 2021-12-18 01:45:34 --> Router Class Initialized
INFO - 2021-12-18 01:45:34 --> Output Class Initialized
INFO - 2021-12-18 01:45:34 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:34 --> Input Class Initialized
INFO - 2021-12-18 01:45:34 --> Language Class Initialized
INFO - 2021-12-18 01:45:34 --> Language Class Initialized
INFO - 2021-12-18 01:45:34 --> Config Class Initialized
INFO - 2021-12-18 01:45:34 --> Loader Class Initialized
INFO - 2021-12-18 01:45:34 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:34 --> Controller Class Initialized
DEBUG - 2021-12-18 01:45:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:45:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:45:34 --> Final output sent to browser
DEBUG - 2021-12-18 01:45:34 --> Total execution time: 0.0370
INFO - 2021-12-18 01:45:34 --> Config Class Initialized
INFO - 2021-12-18 01:45:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:34 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:34 --> URI Class Initialized
INFO - 2021-12-18 01:45:34 --> Router Class Initialized
INFO - 2021-12-18 01:45:34 --> Output Class Initialized
INFO - 2021-12-18 01:45:34 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:34 --> Input Class Initialized
INFO - 2021-12-18 01:45:34 --> Language Class Initialized
INFO - 2021-12-18 01:45:34 --> Language Class Initialized
INFO - 2021-12-18 01:45:34 --> Config Class Initialized
INFO - 2021-12-18 01:45:34 --> Loader Class Initialized
INFO - 2021-12-18 01:45:34 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:34 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:34 --> Controller Class Initialized
INFO - 2021-12-18 01:45:36 --> Config Class Initialized
INFO - 2021-12-18 01:45:36 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:36 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:36 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:36 --> URI Class Initialized
INFO - 2021-12-18 01:45:36 --> Router Class Initialized
INFO - 2021-12-18 01:45:36 --> Output Class Initialized
INFO - 2021-12-18 01:45:36 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:36 --> Input Class Initialized
INFO - 2021-12-18 01:45:36 --> Language Class Initialized
INFO - 2021-12-18 01:45:36 --> Language Class Initialized
INFO - 2021-12-18 01:45:36 --> Config Class Initialized
INFO - 2021-12-18 01:45:36 --> Loader Class Initialized
INFO - 2021-12-18 01:45:36 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:36 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:36 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:36 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:36 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:36 --> Controller Class Initialized
INFO - 2021-12-18 01:45:37 --> Config Class Initialized
INFO - 2021-12-18 01:45:37 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:37 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:37 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:37 --> URI Class Initialized
INFO - 2021-12-18 01:45:37 --> Router Class Initialized
INFO - 2021-12-18 01:45:37 --> Output Class Initialized
INFO - 2021-12-18 01:45:37 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:37 --> Input Class Initialized
INFO - 2021-12-18 01:45:37 --> Language Class Initialized
INFO - 2021-12-18 01:45:37 --> Language Class Initialized
INFO - 2021-12-18 01:45:37 --> Config Class Initialized
INFO - 2021-12-18 01:45:37 --> Loader Class Initialized
INFO - 2021-12-18 01:45:37 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:37 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:37 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:37 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:37 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:37 --> Controller Class Initialized
INFO - 2021-12-18 01:45:37 --> Config Class Initialized
INFO - 2021-12-18 01:45:37 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:37 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:37 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:37 --> URI Class Initialized
INFO - 2021-12-18 01:45:37 --> Router Class Initialized
INFO - 2021-12-18 01:45:37 --> Output Class Initialized
INFO - 2021-12-18 01:45:37 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:37 --> Input Class Initialized
INFO - 2021-12-18 01:45:37 --> Language Class Initialized
INFO - 2021-12-18 01:45:37 --> Language Class Initialized
INFO - 2021-12-18 01:45:37 --> Config Class Initialized
INFO - 2021-12-18 01:45:37 --> Loader Class Initialized
INFO - 2021-12-18 01:45:37 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:37 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:37 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:37 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:37 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:37 --> Controller Class Initialized
INFO - 2021-12-18 01:45:41 --> Config Class Initialized
INFO - 2021-12-18 01:45:41 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:41 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:41 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:41 --> URI Class Initialized
INFO - 2021-12-18 01:45:41 --> Router Class Initialized
INFO - 2021-12-18 01:45:41 --> Output Class Initialized
INFO - 2021-12-18 01:45:41 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:41 --> Input Class Initialized
INFO - 2021-12-18 01:45:41 --> Language Class Initialized
INFO - 2021-12-18 01:45:41 --> Language Class Initialized
INFO - 2021-12-18 01:45:41 --> Config Class Initialized
INFO - 2021-12-18 01:45:41 --> Loader Class Initialized
INFO - 2021-12-18 01:45:41 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:41 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:41 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:41 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:41 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:41 --> Controller Class Initialized
INFO - 2021-12-18 01:45:42 --> Config Class Initialized
INFO - 2021-12-18 01:45:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:42 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:42 --> URI Class Initialized
INFO - 2021-12-18 01:45:42 --> Router Class Initialized
INFO - 2021-12-18 01:45:42 --> Output Class Initialized
INFO - 2021-12-18 01:45:42 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:42 --> Input Class Initialized
INFO - 2021-12-18 01:45:42 --> Language Class Initialized
INFO - 2021-12-18 01:45:42 --> Language Class Initialized
INFO - 2021-12-18 01:45:42 --> Config Class Initialized
INFO - 2021-12-18 01:45:42 --> Loader Class Initialized
INFO - 2021-12-18 01:45:42 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:42 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:42 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:42 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:42 --> Controller Class Initialized
INFO - 2021-12-18 01:45:43 --> Config Class Initialized
INFO - 2021-12-18 01:45:43 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:43 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:43 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:43 --> URI Class Initialized
INFO - 2021-12-18 01:45:43 --> Router Class Initialized
INFO - 2021-12-18 01:45:43 --> Output Class Initialized
INFO - 2021-12-18 01:45:43 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:43 --> Input Class Initialized
INFO - 2021-12-18 01:45:43 --> Language Class Initialized
INFO - 2021-12-18 01:45:43 --> Language Class Initialized
INFO - 2021-12-18 01:45:43 --> Config Class Initialized
INFO - 2021-12-18 01:45:43 --> Loader Class Initialized
INFO - 2021-12-18 01:45:43 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:43 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:43 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:43 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:43 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:43 --> Controller Class Initialized
INFO - 2021-12-18 01:45:43 --> Config Class Initialized
INFO - 2021-12-18 01:45:43 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:43 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:43 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:43 --> URI Class Initialized
INFO - 2021-12-18 01:45:43 --> Router Class Initialized
INFO - 2021-12-18 01:45:43 --> Output Class Initialized
INFO - 2021-12-18 01:45:43 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:43 --> Input Class Initialized
INFO - 2021-12-18 01:45:43 --> Language Class Initialized
INFO - 2021-12-18 01:45:43 --> Language Class Initialized
INFO - 2021-12-18 01:45:43 --> Config Class Initialized
INFO - 2021-12-18 01:45:43 --> Loader Class Initialized
INFO - 2021-12-18 01:45:43 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:43 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:43 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:43 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:43 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:43 --> Controller Class Initialized
INFO - 2021-12-18 01:45:44 --> Config Class Initialized
INFO - 2021-12-18 01:45:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:45:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:45:44 --> Utf8 Class Initialized
INFO - 2021-12-18 01:45:44 --> URI Class Initialized
INFO - 2021-12-18 01:45:44 --> Router Class Initialized
INFO - 2021-12-18 01:45:44 --> Output Class Initialized
INFO - 2021-12-18 01:45:44 --> Security Class Initialized
DEBUG - 2021-12-18 01:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:45:44 --> Input Class Initialized
INFO - 2021-12-18 01:45:44 --> Language Class Initialized
INFO - 2021-12-18 01:45:44 --> Language Class Initialized
INFO - 2021-12-18 01:45:44 --> Config Class Initialized
INFO - 2021-12-18 01:45:44 --> Loader Class Initialized
INFO - 2021-12-18 01:45:44 --> Helper loaded: url_helper
INFO - 2021-12-18 01:45:44 --> Helper loaded: file_helper
INFO - 2021-12-18 01:45:44 --> Helper loaded: form_helper
INFO - 2021-12-18 01:45:44 --> Helper loaded: my_helper
INFO - 2021-12-18 01:45:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:45:44 --> Controller Class Initialized
INFO - 2021-12-18 01:46:03 --> Config Class Initialized
INFO - 2021-12-18 01:46:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:03 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:03 --> URI Class Initialized
INFO - 2021-12-18 01:46:03 --> Router Class Initialized
INFO - 2021-12-18 01:46:03 --> Output Class Initialized
INFO - 2021-12-18 01:46:03 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:03 --> Input Class Initialized
INFO - 2021-12-18 01:46:03 --> Language Class Initialized
INFO - 2021-12-18 01:46:03 --> Language Class Initialized
INFO - 2021-12-18 01:46:03 --> Config Class Initialized
INFO - 2021-12-18 01:46:03 --> Loader Class Initialized
INFO - 2021-12-18 01:46:03 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:03 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:03 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:03 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:03 --> Controller Class Initialized
INFO - 2021-12-18 01:46:05 --> Config Class Initialized
INFO - 2021-12-18 01:46:05 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:05 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:05 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:05 --> URI Class Initialized
INFO - 2021-12-18 01:46:05 --> Router Class Initialized
INFO - 2021-12-18 01:46:05 --> Output Class Initialized
INFO - 2021-12-18 01:46:05 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:05 --> Input Class Initialized
INFO - 2021-12-18 01:46:05 --> Language Class Initialized
INFO - 2021-12-18 01:46:05 --> Language Class Initialized
INFO - 2021-12-18 01:46:05 --> Config Class Initialized
INFO - 2021-12-18 01:46:05 --> Loader Class Initialized
INFO - 2021-12-18 01:46:05 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:05 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:05 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:05 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:05 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:05 --> Controller Class Initialized
INFO - 2021-12-18 01:46:06 --> Config Class Initialized
INFO - 2021-12-18 01:46:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:06 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:06 --> URI Class Initialized
INFO - 2021-12-18 01:46:06 --> Router Class Initialized
INFO - 2021-12-18 01:46:06 --> Output Class Initialized
INFO - 2021-12-18 01:46:06 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:06 --> Input Class Initialized
INFO - 2021-12-18 01:46:06 --> Language Class Initialized
INFO - 2021-12-18 01:46:06 --> Language Class Initialized
INFO - 2021-12-18 01:46:06 --> Config Class Initialized
INFO - 2021-12-18 01:46:06 --> Loader Class Initialized
INFO - 2021-12-18 01:46:06 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:06 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:06 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:06 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:06 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:06 --> Controller Class Initialized
INFO - 2021-12-18 01:46:06 --> Config Class Initialized
INFO - 2021-12-18 01:46:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:06 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:06 --> URI Class Initialized
INFO - 2021-12-18 01:46:06 --> Router Class Initialized
INFO - 2021-12-18 01:46:06 --> Output Class Initialized
INFO - 2021-12-18 01:46:06 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:06 --> Input Class Initialized
INFO - 2021-12-18 01:46:06 --> Language Class Initialized
INFO - 2021-12-18 01:46:06 --> Language Class Initialized
INFO - 2021-12-18 01:46:06 --> Config Class Initialized
INFO - 2021-12-18 01:46:06 --> Loader Class Initialized
INFO - 2021-12-18 01:46:06 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:06 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:06 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:06 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:06 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:06 --> Controller Class Initialized
INFO - 2021-12-18 01:46:08 --> Config Class Initialized
INFO - 2021-12-18 01:46:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:08 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:08 --> URI Class Initialized
INFO - 2021-12-18 01:46:08 --> Router Class Initialized
INFO - 2021-12-18 01:46:08 --> Output Class Initialized
INFO - 2021-12-18 01:46:08 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:08 --> Input Class Initialized
INFO - 2021-12-18 01:46:08 --> Language Class Initialized
INFO - 2021-12-18 01:46:08 --> Language Class Initialized
INFO - 2021-12-18 01:46:08 --> Config Class Initialized
INFO - 2021-12-18 01:46:08 --> Loader Class Initialized
INFO - 2021-12-18 01:46:08 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:08 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:08 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:08 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:08 --> Controller Class Initialized
INFO - 2021-12-18 01:46:09 --> Config Class Initialized
INFO - 2021-12-18 01:46:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:09 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:09 --> URI Class Initialized
INFO - 2021-12-18 01:46:09 --> Router Class Initialized
INFO - 2021-12-18 01:46:09 --> Output Class Initialized
INFO - 2021-12-18 01:46:09 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:09 --> Input Class Initialized
INFO - 2021-12-18 01:46:09 --> Language Class Initialized
INFO - 2021-12-18 01:46:09 --> Language Class Initialized
INFO - 2021-12-18 01:46:09 --> Config Class Initialized
INFO - 2021-12-18 01:46:09 --> Loader Class Initialized
INFO - 2021-12-18 01:46:09 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:09 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:09 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:09 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:09 --> Controller Class Initialized
INFO - 2021-12-18 01:46:09 --> Config Class Initialized
INFO - 2021-12-18 01:46:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:09 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:09 --> URI Class Initialized
INFO - 2021-12-18 01:46:09 --> Router Class Initialized
INFO - 2021-12-18 01:46:09 --> Output Class Initialized
INFO - 2021-12-18 01:46:09 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:09 --> Input Class Initialized
INFO - 2021-12-18 01:46:09 --> Language Class Initialized
INFO - 2021-12-18 01:46:09 --> Language Class Initialized
INFO - 2021-12-18 01:46:09 --> Config Class Initialized
INFO - 2021-12-18 01:46:09 --> Loader Class Initialized
INFO - 2021-12-18 01:46:09 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:09 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:09 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:09 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:09 --> Controller Class Initialized
INFO - 2021-12-18 01:46:10 --> Config Class Initialized
INFO - 2021-12-18 01:46:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:10 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:10 --> URI Class Initialized
INFO - 2021-12-18 01:46:10 --> Router Class Initialized
INFO - 2021-12-18 01:46:10 --> Output Class Initialized
INFO - 2021-12-18 01:46:10 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:10 --> Input Class Initialized
INFO - 2021-12-18 01:46:10 --> Language Class Initialized
INFO - 2021-12-18 01:46:10 --> Language Class Initialized
INFO - 2021-12-18 01:46:10 --> Config Class Initialized
INFO - 2021-12-18 01:46:10 --> Loader Class Initialized
INFO - 2021-12-18 01:46:10 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:10 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:10 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:10 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:10 --> Controller Class Initialized
INFO - 2021-12-18 01:46:10 --> Config Class Initialized
INFO - 2021-12-18 01:46:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:10 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:10 --> URI Class Initialized
INFO - 2021-12-18 01:46:10 --> Router Class Initialized
INFO - 2021-12-18 01:46:10 --> Output Class Initialized
INFO - 2021-12-18 01:46:10 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:10 --> Input Class Initialized
INFO - 2021-12-18 01:46:10 --> Language Class Initialized
INFO - 2021-12-18 01:46:10 --> Language Class Initialized
INFO - 2021-12-18 01:46:10 --> Config Class Initialized
INFO - 2021-12-18 01:46:10 --> Loader Class Initialized
INFO - 2021-12-18 01:46:10 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:10 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:10 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:10 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:10 --> Controller Class Initialized
INFO - 2021-12-18 01:46:11 --> Config Class Initialized
INFO - 2021-12-18 01:46:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:11 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:11 --> URI Class Initialized
INFO - 2021-12-18 01:46:11 --> Router Class Initialized
INFO - 2021-12-18 01:46:11 --> Output Class Initialized
INFO - 2021-12-18 01:46:11 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:11 --> Input Class Initialized
INFO - 2021-12-18 01:46:11 --> Language Class Initialized
INFO - 2021-12-18 01:46:11 --> Language Class Initialized
INFO - 2021-12-18 01:46:11 --> Config Class Initialized
INFO - 2021-12-18 01:46:11 --> Loader Class Initialized
INFO - 2021-12-18 01:46:11 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:11 --> Controller Class Initialized
INFO - 2021-12-18 01:46:11 --> Config Class Initialized
INFO - 2021-12-18 01:46:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:11 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:11 --> URI Class Initialized
INFO - 2021-12-18 01:46:11 --> Router Class Initialized
INFO - 2021-12-18 01:46:11 --> Output Class Initialized
INFO - 2021-12-18 01:46:11 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:11 --> Input Class Initialized
INFO - 2021-12-18 01:46:11 --> Language Class Initialized
INFO - 2021-12-18 01:46:11 --> Language Class Initialized
INFO - 2021-12-18 01:46:11 --> Config Class Initialized
INFO - 2021-12-18 01:46:11 --> Loader Class Initialized
INFO - 2021-12-18 01:46:11 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:11 --> Controller Class Initialized
INFO - 2021-12-18 01:46:11 --> Config Class Initialized
INFO - 2021-12-18 01:46:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:11 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:11 --> URI Class Initialized
INFO - 2021-12-18 01:46:11 --> Router Class Initialized
INFO - 2021-12-18 01:46:11 --> Output Class Initialized
INFO - 2021-12-18 01:46:11 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:11 --> Input Class Initialized
INFO - 2021-12-18 01:46:11 --> Language Class Initialized
INFO - 2021-12-18 01:46:11 --> Language Class Initialized
INFO - 2021-12-18 01:46:11 --> Config Class Initialized
INFO - 2021-12-18 01:46:11 --> Loader Class Initialized
INFO - 2021-12-18 01:46:11 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:11 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:11 --> Controller Class Initialized
INFO - 2021-12-18 01:46:12 --> Config Class Initialized
INFO - 2021-12-18 01:46:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:12 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:12 --> URI Class Initialized
INFO - 2021-12-18 01:46:12 --> Router Class Initialized
INFO - 2021-12-18 01:46:12 --> Output Class Initialized
INFO - 2021-12-18 01:46:12 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:12 --> Input Class Initialized
INFO - 2021-12-18 01:46:12 --> Language Class Initialized
INFO - 2021-12-18 01:46:12 --> Language Class Initialized
INFO - 2021-12-18 01:46:12 --> Config Class Initialized
INFO - 2021-12-18 01:46:12 --> Loader Class Initialized
INFO - 2021-12-18 01:46:12 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:12 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:12 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:12 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:12 --> Controller Class Initialized
INFO - 2021-12-18 01:46:13 --> Config Class Initialized
INFO - 2021-12-18 01:46:13 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:13 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:13 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:13 --> URI Class Initialized
INFO - 2021-12-18 01:46:13 --> Router Class Initialized
INFO - 2021-12-18 01:46:13 --> Output Class Initialized
INFO - 2021-12-18 01:46:13 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:13 --> Input Class Initialized
INFO - 2021-12-18 01:46:13 --> Language Class Initialized
INFO - 2021-12-18 01:46:13 --> Language Class Initialized
INFO - 2021-12-18 01:46:13 --> Config Class Initialized
INFO - 2021-12-18 01:46:13 --> Loader Class Initialized
INFO - 2021-12-18 01:46:13 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:13 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:13 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:13 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:13 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:13 --> Controller Class Initialized
INFO - 2021-12-18 01:46:16 --> Config Class Initialized
INFO - 2021-12-18 01:46:16 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:16 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:16 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:16 --> URI Class Initialized
INFO - 2021-12-18 01:46:16 --> Router Class Initialized
INFO - 2021-12-18 01:46:16 --> Output Class Initialized
INFO - 2021-12-18 01:46:16 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:16 --> Input Class Initialized
INFO - 2021-12-18 01:46:16 --> Language Class Initialized
INFO - 2021-12-18 01:46:16 --> Language Class Initialized
INFO - 2021-12-18 01:46:16 --> Config Class Initialized
INFO - 2021-12-18 01:46:16 --> Loader Class Initialized
INFO - 2021-12-18 01:46:16 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:16 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:16 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:16 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:16 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:16 --> Controller Class Initialized
INFO - 2021-12-18 01:46:18 --> Config Class Initialized
INFO - 2021-12-18 01:46:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:18 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:18 --> URI Class Initialized
INFO - 2021-12-18 01:46:18 --> Router Class Initialized
INFO - 2021-12-18 01:46:18 --> Output Class Initialized
INFO - 2021-12-18 01:46:18 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:18 --> Input Class Initialized
INFO - 2021-12-18 01:46:18 --> Language Class Initialized
INFO - 2021-12-18 01:46:18 --> Language Class Initialized
INFO - 2021-12-18 01:46:18 --> Config Class Initialized
INFO - 2021-12-18 01:46:18 --> Loader Class Initialized
INFO - 2021-12-18 01:46:18 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:18 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:18 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:18 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:18 --> Controller Class Initialized
INFO - 2021-12-18 01:46:22 --> Config Class Initialized
INFO - 2021-12-18 01:46:22 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:22 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:22 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:22 --> URI Class Initialized
INFO - 2021-12-18 01:46:22 --> Router Class Initialized
INFO - 2021-12-18 01:46:22 --> Output Class Initialized
INFO - 2021-12-18 01:46:22 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:22 --> Input Class Initialized
INFO - 2021-12-18 01:46:22 --> Language Class Initialized
INFO - 2021-12-18 01:46:22 --> Language Class Initialized
INFO - 2021-12-18 01:46:22 --> Config Class Initialized
INFO - 2021-12-18 01:46:22 --> Loader Class Initialized
INFO - 2021-12-18 01:46:22 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:22 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:22 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:22 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:22 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:22 --> Controller Class Initialized
DEBUG - 2021-12-18 01:46:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:46:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:46:22 --> Final output sent to browser
DEBUG - 2021-12-18 01:46:22 --> Total execution time: 0.0410
INFO - 2021-12-18 01:46:42 --> Config Class Initialized
INFO - 2021-12-18 01:46:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:42 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:42 --> URI Class Initialized
INFO - 2021-12-18 01:46:42 --> Router Class Initialized
INFO - 2021-12-18 01:46:42 --> Output Class Initialized
INFO - 2021-12-18 01:46:42 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:42 --> Input Class Initialized
INFO - 2021-12-18 01:46:42 --> Language Class Initialized
INFO - 2021-12-18 01:46:42 --> Language Class Initialized
INFO - 2021-12-18 01:46:42 --> Config Class Initialized
INFO - 2021-12-18 01:46:42 --> Loader Class Initialized
INFO - 2021-12-18 01:46:42 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:42 --> Controller Class Initialized
INFO - 2021-12-18 01:46:42 --> Config Class Initialized
INFO - 2021-12-18 01:46:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:42 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:42 --> URI Class Initialized
INFO - 2021-12-18 01:46:42 --> Router Class Initialized
INFO - 2021-12-18 01:46:42 --> Output Class Initialized
INFO - 2021-12-18 01:46:42 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:42 --> Input Class Initialized
INFO - 2021-12-18 01:46:42 --> Language Class Initialized
INFO - 2021-12-18 01:46:42 --> Language Class Initialized
INFO - 2021-12-18 01:46:42 --> Config Class Initialized
INFO - 2021-12-18 01:46:42 --> Loader Class Initialized
INFO - 2021-12-18 01:46:42 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:42 --> Controller Class Initialized
DEBUG - 2021-12-18 01:46:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:46:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:46:42 --> Final output sent to browser
DEBUG - 2021-12-18 01:46:42 --> Total execution time: 0.0350
INFO - 2021-12-18 01:46:42 --> Config Class Initialized
INFO - 2021-12-18 01:46:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:42 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:42 --> URI Class Initialized
INFO - 2021-12-18 01:46:42 --> Router Class Initialized
INFO - 2021-12-18 01:46:42 --> Output Class Initialized
INFO - 2021-12-18 01:46:42 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:42 --> Input Class Initialized
INFO - 2021-12-18 01:46:42 --> Language Class Initialized
INFO - 2021-12-18 01:46:42 --> Language Class Initialized
INFO - 2021-12-18 01:46:42 --> Config Class Initialized
INFO - 2021-12-18 01:46:42 --> Loader Class Initialized
INFO - 2021-12-18 01:46:42 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:42 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:42 --> Controller Class Initialized
INFO - 2021-12-18 01:46:43 --> Config Class Initialized
INFO - 2021-12-18 01:46:43 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:43 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:43 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:43 --> URI Class Initialized
INFO - 2021-12-18 01:46:43 --> Router Class Initialized
INFO - 2021-12-18 01:46:43 --> Output Class Initialized
INFO - 2021-12-18 01:46:43 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:43 --> Input Class Initialized
INFO - 2021-12-18 01:46:43 --> Language Class Initialized
INFO - 2021-12-18 01:46:43 --> Language Class Initialized
INFO - 2021-12-18 01:46:43 --> Config Class Initialized
INFO - 2021-12-18 01:46:43 --> Loader Class Initialized
INFO - 2021-12-18 01:46:43 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:43 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:43 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:43 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:43 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:43 --> Controller Class Initialized
INFO - 2021-12-18 01:46:44 --> Config Class Initialized
INFO - 2021-12-18 01:46:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:44 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:44 --> URI Class Initialized
INFO - 2021-12-18 01:46:44 --> Router Class Initialized
INFO - 2021-12-18 01:46:44 --> Output Class Initialized
INFO - 2021-12-18 01:46:44 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:44 --> Input Class Initialized
INFO - 2021-12-18 01:46:44 --> Language Class Initialized
INFO - 2021-12-18 01:46:44 --> Language Class Initialized
INFO - 2021-12-18 01:46:44 --> Config Class Initialized
INFO - 2021-12-18 01:46:44 --> Loader Class Initialized
INFO - 2021-12-18 01:46:44 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:44 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:44 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:44 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:44 --> Controller Class Initialized
INFO - 2021-12-18 01:46:48 --> Config Class Initialized
INFO - 2021-12-18 01:46:48 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:48 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:48 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:48 --> URI Class Initialized
INFO - 2021-12-18 01:46:48 --> Router Class Initialized
INFO - 2021-12-18 01:46:48 --> Output Class Initialized
INFO - 2021-12-18 01:46:48 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:48 --> Input Class Initialized
INFO - 2021-12-18 01:46:48 --> Language Class Initialized
INFO - 2021-12-18 01:46:48 --> Language Class Initialized
INFO - 2021-12-18 01:46:48 --> Config Class Initialized
INFO - 2021-12-18 01:46:48 --> Loader Class Initialized
INFO - 2021-12-18 01:46:48 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:48 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:48 --> Controller Class Initialized
INFO - 2021-12-18 01:46:48 --> Config Class Initialized
INFO - 2021-12-18 01:46:48 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:48 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:48 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:48 --> URI Class Initialized
INFO - 2021-12-18 01:46:48 --> Router Class Initialized
INFO - 2021-12-18 01:46:48 --> Output Class Initialized
INFO - 2021-12-18 01:46:48 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:48 --> Input Class Initialized
INFO - 2021-12-18 01:46:48 --> Language Class Initialized
INFO - 2021-12-18 01:46:48 --> Language Class Initialized
INFO - 2021-12-18 01:46:48 --> Config Class Initialized
INFO - 2021-12-18 01:46:48 --> Loader Class Initialized
INFO - 2021-12-18 01:46:48 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:48 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:48 --> Controller Class Initialized
INFO - 2021-12-18 01:46:48 --> Config Class Initialized
INFO - 2021-12-18 01:46:48 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:46:48 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:46:48 --> Utf8 Class Initialized
INFO - 2021-12-18 01:46:48 --> URI Class Initialized
INFO - 2021-12-18 01:46:48 --> Router Class Initialized
INFO - 2021-12-18 01:46:48 --> Output Class Initialized
INFO - 2021-12-18 01:46:48 --> Security Class Initialized
DEBUG - 2021-12-18 01:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:46:48 --> Input Class Initialized
INFO - 2021-12-18 01:46:48 --> Language Class Initialized
INFO - 2021-12-18 01:46:48 --> Language Class Initialized
INFO - 2021-12-18 01:46:48 --> Config Class Initialized
INFO - 2021-12-18 01:46:48 --> Loader Class Initialized
INFO - 2021-12-18 01:46:48 --> Helper loaded: url_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: file_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: form_helper
INFO - 2021-12-18 01:46:48 --> Helper loaded: my_helper
INFO - 2021-12-18 01:46:49 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:46:49 --> Controller Class Initialized
INFO - 2021-12-18 01:47:14 --> Config Class Initialized
INFO - 2021-12-18 01:47:14 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:47:14 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:47:14 --> Utf8 Class Initialized
INFO - 2021-12-18 01:47:14 --> URI Class Initialized
INFO - 2021-12-18 01:47:14 --> Router Class Initialized
INFO - 2021-12-18 01:47:14 --> Output Class Initialized
INFO - 2021-12-18 01:47:14 --> Security Class Initialized
DEBUG - 2021-12-18 01:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:47:14 --> Input Class Initialized
INFO - 2021-12-18 01:47:14 --> Language Class Initialized
INFO - 2021-12-18 01:47:14 --> Language Class Initialized
INFO - 2021-12-18 01:47:14 --> Config Class Initialized
INFO - 2021-12-18 01:47:14 --> Loader Class Initialized
INFO - 2021-12-18 01:47:14 --> Helper loaded: url_helper
INFO - 2021-12-18 01:47:14 --> Helper loaded: file_helper
INFO - 2021-12-18 01:47:14 --> Helper loaded: form_helper
INFO - 2021-12-18 01:47:14 --> Helper loaded: my_helper
INFO - 2021-12-18 01:47:14 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:47:14 --> Controller Class Initialized
DEBUG - 2021-12-18 01:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:47:14 --> Final output sent to browser
DEBUG - 2021-12-18 01:47:14 --> Total execution time: 0.0430
INFO - 2021-12-18 01:47:36 --> Config Class Initialized
INFO - 2021-12-18 01:47:36 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:47:36 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:47:36 --> Utf8 Class Initialized
INFO - 2021-12-18 01:47:36 --> URI Class Initialized
INFO - 2021-12-18 01:47:36 --> Router Class Initialized
INFO - 2021-12-18 01:47:36 --> Output Class Initialized
INFO - 2021-12-18 01:47:36 --> Security Class Initialized
DEBUG - 2021-12-18 01:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:47:36 --> Input Class Initialized
INFO - 2021-12-18 01:47:36 --> Language Class Initialized
INFO - 2021-12-18 01:47:36 --> Language Class Initialized
INFO - 2021-12-18 01:47:36 --> Config Class Initialized
INFO - 2021-12-18 01:47:36 --> Loader Class Initialized
INFO - 2021-12-18 01:47:36 --> Helper loaded: url_helper
INFO - 2021-12-18 01:47:36 --> Helper loaded: file_helper
INFO - 2021-12-18 01:47:36 --> Helper loaded: form_helper
INFO - 2021-12-18 01:47:36 --> Helper loaded: my_helper
INFO - 2021-12-18 01:47:36 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:47:36 --> Controller Class Initialized
INFO - 2021-12-18 01:47:36 --> Config Class Initialized
INFO - 2021-12-18 01:47:36 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:47:36 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:47:36 --> Utf8 Class Initialized
INFO - 2021-12-18 01:47:36 --> URI Class Initialized
INFO - 2021-12-18 01:47:36 --> Router Class Initialized
INFO - 2021-12-18 01:47:36 --> Output Class Initialized
INFO - 2021-12-18 01:47:36 --> Security Class Initialized
DEBUG - 2021-12-18 01:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:47:36 --> Input Class Initialized
INFO - 2021-12-18 01:47:36 --> Language Class Initialized
INFO - 2021-12-18 01:47:36 --> Language Class Initialized
INFO - 2021-12-18 01:47:36 --> Config Class Initialized
INFO - 2021-12-18 01:47:36 --> Loader Class Initialized
INFO - 2021-12-18 01:47:36 --> Helper loaded: url_helper
INFO - 2021-12-18 01:47:36 --> Helper loaded: file_helper
INFO - 2021-12-18 01:47:36 --> Helper loaded: form_helper
INFO - 2021-12-18 01:47:36 --> Helper loaded: my_helper
INFO - 2021-12-18 01:47:36 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:47:37 --> Controller Class Initialized
DEBUG - 2021-12-18 01:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:47:37 --> Final output sent to browser
DEBUG - 2021-12-18 01:47:37 --> Total execution time: 0.0360
INFO - 2021-12-18 01:47:37 --> Config Class Initialized
INFO - 2021-12-18 01:47:37 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:47:37 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:47:37 --> Utf8 Class Initialized
INFO - 2021-12-18 01:47:37 --> URI Class Initialized
INFO - 2021-12-18 01:47:37 --> Router Class Initialized
INFO - 2021-12-18 01:47:37 --> Output Class Initialized
INFO - 2021-12-18 01:47:37 --> Security Class Initialized
DEBUG - 2021-12-18 01:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:47:37 --> Input Class Initialized
INFO - 2021-12-18 01:47:37 --> Language Class Initialized
INFO - 2021-12-18 01:47:37 --> Language Class Initialized
INFO - 2021-12-18 01:47:37 --> Config Class Initialized
INFO - 2021-12-18 01:47:37 --> Loader Class Initialized
INFO - 2021-12-18 01:47:37 --> Helper loaded: url_helper
INFO - 2021-12-18 01:47:37 --> Helper loaded: file_helper
INFO - 2021-12-18 01:47:37 --> Helper loaded: form_helper
INFO - 2021-12-18 01:47:37 --> Helper loaded: my_helper
INFO - 2021-12-18 01:47:37 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:47:37 --> Controller Class Initialized
INFO - 2021-12-18 01:47:39 --> Config Class Initialized
INFO - 2021-12-18 01:47:39 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:47:39 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:47:39 --> Utf8 Class Initialized
INFO - 2021-12-18 01:47:39 --> URI Class Initialized
INFO - 2021-12-18 01:47:39 --> Router Class Initialized
INFO - 2021-12-18 01:47:39 --> Output Class Initialized
INFO - 2021-12-18 01:47:39 --> Security Class Initialized
DEBUG - 2021-12-18 01:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:47:39 --> Input Class Initialized
INFO - 2021-12-18 01:47:39 --> Language Class Initialized
INFO - 2021-12-18 01:47:39 --> Language Class Initialized
INFO - 2021-12-18 01:47:39 --> Config Class Initialized
INFO - 2021-12-18 01:47:39 --> Loader Class Initialized
INFO - 2021-12-18 01:47:39 --> Helper loaded: url_helper
INFO - 2021-12-18 01:47:39 --> Helper loaded: file_helper
INFO - 2021-12-18 01:47:39 --> Helper loaded: form_helper
INFO - 2021-12-18 01:47:39 --> Helper loaded: my_helper
INFO - 2021-12-18 01:47:39 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:47:39 --> Controller Class Initialized
INFO - 2021-12-18 01:47:39 --> Config Class Initialized
INFO - 2021-12-18 01:47:39 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:47:39 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:47:39 --> Utf8 Class Initialized
INFO - 2021-12-18 01:47:39 --> URI Class Initialized
INFO - 2021-12-18 01:47:39 --> Router Class Initialized
INFO - 2021-12-18 01:47:39 --> Output Class Initialized
INFO - 2021-12-18 01:47:39 --> Security Class Initialized
DEBUG - 2021-12-18 01:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:47:39 --> Input Class Initialized
INFO - 2021-12-18 01:47:39 --> Language Class Initialized
INFO - 2021-12-18 01:47:39 --> Language Class Initialized
INFO - 2021-12-18 01:47:39 --> Config Class Initialized
INFO - 2021-12-18 01:47:39 --> Loader Class Initialized
INFO - 2021-12-18 01:47:39 --> Helper loaded: url_helper
INFO - 2021-12-18 01:47:39 --> Helper loaded: file_helper
INFO - 2021-12-18 01:47:39 --> Helper loaded: form_helper
INFO - 2021-12-18 01:47:39 --> Helper loaded: my_helper
INFO - 2021-12-18 01:47:39 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:47:39 --> Controller Class Initialized
INFO - 2021-12-18 01:47:40 --> Config Class Initialized
INFO - 2021-12-18 01:47:40 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:47:40 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:47:40 --> Utf8 Class Initialized
INFO - 2021-12-18 01:47:40 --> URI Class Initialized
INFO - 2021-12-18 01:47:40 --> Router Class Initialized
INFO - 2021-12-18 01:47:40 --> Output Class Initialized
INFO - 2021-12-18 01:47:40 --> Security Class Initialized
DEBUG - 2021-12-18 01:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:47:40 --> Input Class Initialized
INFO - 2021-12-18 01:47:40 --> Language Class Initialized
INFO - 2021-12-18 01:47:40 --> Language Class Initialized
INFO - 2021-12-18 01:47:40 --> Config Class Initialized
INFO - 2021-12-18 01:47:40 --> Loader Class Initialized
INFO - 2021-12-18 01:47:40 --> Helper loaded: url_helper
INFO - 2021-12-18 01:47:40 --> Helper loaded: file_helper
INFO - 2021-12-18 01:47:40 --> Helper loaded: form_helper
INFO - 2021-12-18 01:47:40 --> Helper loaded: my_helper
INFO - 2021-12-18 01:47:40 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:47:40 --> Controller Class Initialized
INFO - 2021-12-18 01:47:44 --> Config Class Initialized
INFO - 2021-12-18 01:47:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:47:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:47:44 --> Utf8 Class Initialized
INFO - 2021-12-18 01:47:44 --> URI Class Initialized
INFO - 2021-12-18 01:47:44 --> Router Class Initialized
INFO - 2021-12-18 01:47:44 --> Output Class Initialized
INFO - 2021-12-18 01:47:44 --> Security Class Initialized
DEBUG - 2021-12-18 01:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:47:44 --> Input Class Initialized
INFO - 2021-12-18 01:47:44 --> Language Class Initialized
INFO - 2021-12-18 01:47:44 --> Language Class Initialized
INFO - 2021-12-18 01:47:44 --> Config Class Initialized
INFO - 2021-12-18 01:47:44 --> Loader Class Initialized
INFO - 2021-12-18 01:47:44 --> Helper loaded: url_helper
INFO - 2021-12-18 01:47:44 --> Helper loaded: file_helper
INFO - 2021-12-18 01:47:44 --> Helper loaded: form_helper
INFO - 2021-12-18 01:47:44 --> Helper loaded: my_helper
INFO - 2021-12-18 01:47:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:47:44 --> Controller Class Initialized
INFO - 2021-12-18 01:48:06 --> Config Class Initialized
INFO - 2021-12-18 01:48:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:06 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:06 --> URI Class Initialized
INFO - 2021-12-18 01:48:06 --> Router Class Initialized
INFO - 2021-12-18 01:48:06 --> Output Class Initialized
INFO - 2021-12-18 01:48:06 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:06 --> Input Class Initialized
INFO - 2021-12-18 01:48:06 --> Language Class Initialized
INFO - 2021-12-18 01:48:06 --> Language Class Initialized
INFO - 2021-12-18 01:48:06 --> Config Class Initialized
INFO - 2021-12-18 01:48:06 --> Loader Class Initialized
INFO - 2021-12-18 01:48:06 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:06 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:06 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:06 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:06 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:06 --> Controller Class Initialized
DEBUG - 2021-12-18 01:48:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:48:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:48:06 --> Final output sent to browser
DEBUG - 2021-12-18 01:48:06 --> Total execution time: 0.0620
INFO - 2021-12-18 01:48:09 --> Config Class Initialized
INFO - 2021-12-18 01:48:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:09 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:09 --> URI Class Initialized
INFO - 2021-12-18 01:48:09 --> Router Class Initialized
INFO - 2021-12-18 01:48:09 --> Output Class Initialized
INFO - 2021-12-18 01:48:09 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:09 --> Input Class Initialized
INFO - 2021-12-18 01:48:09 --> Language Class Initialized
INFO - 2021-12-18 01:48:09 --> Language Class Initialized
INFO - 2021-12-18 01:48:09 --> Config Class Initialized
INFO - 2021-12-18 01:48:09 --> Loader Class Initialized
INFO - 2021-12-18 01:48:09 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:09 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:09 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:09 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:09 --> Controller Class Initialized
DEBUG - 2021-12-18 01:48:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:48:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:48:09 --> Final output sent to browser
DEBUG - 2021-12-18 01:48:09 --> Total execution time: 0.0430
INFO - 2021-12-18 01:48:09 --> Config Class Initialized
INFO - 2021-12-18 01:48:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:09 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:09 --> URI Class Initialized
INFO - 2021-12-18 01:48:09 --> Router Class Initialized
INFO - 2021-12-18 01:48:09 --> Output Class Initialized
INFO - 2021-12-18 01:48:09 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:09 --> Input Class Initialized
INFO - 2021-12-18 01:48:09 --> Language Class Initialized
INFO - 2021-12-18 01:48:09 --> Language Class Initialized
INFO - 2021-12-18 01:48:09 --> Config Class Initialized
INFO - 2021-12-18 01:48:09 --> Loader Class Initialized
INFO - 2021-12-18 01:48:09 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:09 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:09 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:09 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:09 --> Controller Class Initialized
INFO - 2021-12-18 01:48:13 --> Config Class Initialized
INFO - 2021-12-18 01:48:13 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:13 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:13 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:13 --> URI Class Initialized
INFO - 2021-12-18 01:48:13 --> Router Class Initialized
INFO - 2021-12-18 01:48:13 --> Output Class Initialized
INFO - 2021-12-18 01:48:13 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:13 --> Input Class Initialized
INFO - 2021-12-18 01:48:13 --> Language Class Initialized
INFO - 2021-12-18 01:48:13 --> Language Class Initialized
INFO - 2021-12-18 01:48:13 --> Config Class Initialized
INFO - 2021-12-18 01:48:13 --> Loader Class Initialized
INFO - 2021-12-18 01:48:13 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:13 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:13 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:13 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:13 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:13 --> Controller Class Initialized
INFO - 2021-12-18 01:48:14 --> Config Class Initialized
INFO - 2021-12-18 01:48:14 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:14 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:14 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:14 --> URI Class Initialized
INFO - 2021-12-18 01:48:14 --> Router Class Initialized
INFO - 2021-12-18 01:48:14 --> Output Class Initialized
INFO - 2021-12-18 01:48:14 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:14 --> Input Class Initialized
INFO - 2021-12-18 01:48:14 --> Language Class Initialized
INFO - 2021-12-18 01:48:14 --> Language Class Initialized
INFO - 2021-12-18 01:48:14 --> Config Class Initialized
INFO - 2021-12-18 01:48:14 --> Loader Class Initialized
INFO - 2021-12-18 01:48:14 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:14 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:14 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:14 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:14 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:14 --> Controller Class Initialized
INFO - 2021-12-18 01:48:14 --> Config Class Initialized
INFO - 2021-12-18 01:48:14 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:14 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:14 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:14 --> URI Class Initialized
INFO - 2021-12-18 01:48:14 --> Router Class Initialized
INFO - 2021-12-18 01:48:14 --> Output Class Initialized
INFO - 2021-12-18 01:48:14 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:14 --> Input Class Initialized
INFO - 2021-12-18 01:48:14 --> Language Class Initialized
INFO - 2021-12-18 01:48:14 --> Language Class Initialized
INFO - 2021-12-18 01:48:14 --> Config Class Initialized
INFO - 2021-12-18 01:48:14 --> Loader Class Initialized
INFO - 2021-12-18 01:48:14 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:14 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:14 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:14 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:14 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:14 --> Controller Class Initialized
INFO - 2021-12-18 01:48:15 --> Config Class Initialized
INFO - 2021-12-18 01:48:15 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:15 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:15 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:16 --> URI Class Initialized
INFO - 2021-12-18 01:48:16 --> Router Class Initialized
INFO - 2021-12-18 01:48:16 --> Output Class Initialized
INFO - 2021-12-18 01:48:16 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:16 --> Input Class Initialized
INFO - 2021-12-18 01:48:16 --> Language Class Initialized
INFO - 2021-12-18 01:48:16 --> Language Class Initialized
INFO - 2021-12-18 01:48:16 --> Config Class Initialized
INFO - 2021-12-18 01:48:16 --> Loader Class Initialized
INFO - 2021-12-18 01:48:16 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:16 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:16 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:16 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:16 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:16 --> Controller Class Initialized
INFO - 2021-12-18 01:48:16 --> Config Class Initialized
INFO - 2021-12-18 01:48:16 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:16 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:16 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:16 --> URI Class Initialized
INFO - 2021-12-18 01:48:16 --> Router Class Initialized
INFO - 2021-12-18 01:48:16 --> Output Class Initialized
INFO - 2021-12-18 01:48:16 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:16 --> Input Class Initialized
INFO - 2021-12-18 01:48:16 --> Language Class Initialized
INFO - 2021-12-18 01:48:16 --> Language Class Initialized
INFO - 2021-12-18 01:48:16 --> Config Class Initialized
INFO - 2021-12-18 01:48:16 --> Loader Class Initialized
INFO - 2021-12-18 01:48:16 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:16 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:16 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:16 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:16 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:16 --> Controller Class Initialized
INFO - 2021-12-18 01:48:18 --> Config Class Initialized
INFO - 2021-12-18 01:48:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:18 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:18 --> URI Class Initialized
INFO - 2021-12-18 01:48:18 --> Router Class Initialized
INFO - 2021-12-18 01:48:18 --> Output Class Initialized
INFO - 2021-12-18 01:48:18 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:18 --> Input Class Initialized
INFO - 2021-12-18 01:48:18 --> Language Class Initialized
INFO - 2021-12-18 01:48:18 --> Language Class Initialized
INFO - 2021-12-18 01:48:18 --> Config Class Initialized
INFO - 2021-12-18 01:48:18 --> Loader Class Initialized
INFO - 2021-12-18 01:48:18 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:18 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:18 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:18 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:18 --> Controller Class Initialized
INFO - 2021-12-18 01:48:38 --> Config Class Initialized
INFO - 2021-12-18 01:48:38 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:38 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:38 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:38 --> URI Class Initialized
INFO - 2021-12-18 01:48:38 --> Router Class Initialized
INFO - 2021-12-18 01:48:38 --> Output Class Initialized
INFO - 2021-12-18 01:48:38 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:38 --> Input Class Initialized
INFO - 2021-12-18 01:48:38 --> Language Class Initialized
INFO - 2021-12-18 01:48:38 --> Language Class Initialized
INFO - 2021-12-18 01:48:38 --> Config Class Initialized
INFO - 2021-12-18 01:48:38 --> Loader Class Initialized
INFO - 2021-12-18 01:48:38 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:38 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:38 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:38 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:38 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:38 --> Controller Class Initialized
DEBUG - 2021-12-18 01:48:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-18 01:48:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:48:38 --> Final output sent to browser
DEBUG - 2021-12-18 01:48:38 --> Total execution time: 0.0440
INFO - 2021-12-18 01:48:38 --> Config Class Initialized
INFO - 2021-12-18 01:48:38 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:38 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:38 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:38 --> URI Class Initialized
INFO - 2021-12-18 01:48:38 --> Router Class Initialized
INFO - 2021-12-18 01:48:38 --> Output Class Initialized
INFO - 2021-12-18 01:48:38 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:38 --> Input Class Initialized
INFO - 2021-12-18 01:48:38 --> Language Class Initialized
INFO - 2021-12-18 01:48:38 --> Language Class Initialized
INFO - 2021-12-18 01:48:38 --> Config Class Initialized
INFO - 2021-12-18 01:48:38 --> Loader Class Initialized
INFO - 2021-12-18 01:48:38 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:38 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:38 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:38 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:38 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:38 --> Controller Class Initialized
INFO - 2021-12-18 01:48:39 --> Config Class Initialized
INFO - 2021-12-18 01:48:39 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:39 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:39 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:39 --> URI Class Initialized
INFO - 2021-12-18 01:48:39 --> Router Class Initialized
INFO - 2021-12-18 01:48:39 --> Output Class Initialized
INFO - 2021-12-18 01:48:39 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:39 --> Input Class Initialized
INFO - 2021-12-18 01:48:39 --> Language Class Initialized
INFO - 2021-12-18 01:48:39 --> Language Class Initialized
INFO - 2021-12-18 01:48:39 --> Config Class Initialized
INFO - 2021-12-18 01:48:39 --> Loader Class Initialized
INFO - 2021-12-18 01:48:39 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:39 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:39 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:39 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:39 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:39 --> Controller Class Initialized
INFO - 2021-12-18 01:48:40 --> Config Class Initialized
INFO - 2021-12-18 01:48:40 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:40 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:40 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:40 --> URI Class Initialized
INFO - 2021-12-18 01:48:40 --> Router Class Initialized
INFO - 2021-12-18 01:48:40 --> Output Class Initialized
INFO - 2021-12-18 01:48:40 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:40 --> Input Class Initialized
INFO - 2021-12-18 01:48:40 --> Language Class Initialized
INFO - 2021-12-18 01:48:40 --> Language Class Initialized
INFO - 2021-12-18 01:48:40 --> Config Class Initialized
INFO - 2021-12-18 01:48:40 --> Loader Class Initialized
INFO - 2021-12-18 01:48:40 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:40 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:40 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:40 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:40 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:40 --> Controller Class Initialized
INFO - 2021-12-18 01:48:42 --> Config Class Initialized
INFO - 2021-12-18 01:48:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:48:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:48:42 --> Utf8 Class Initialized
INFO - 2021-12-18 01:48:42 --> URI Class Initialized
INFO - 2021-12-18 01:48:42 --> Router Class Initialized
INFO - 2021-12-18 01:48:42 --> Output Class Initialized
INFO - 2021-12-18 01:48:42 --> Security Class Initialized
DEBUG - 2021-12-18 01:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:48:42 --> Input Class Initialized
INFO - 2021-12-18 01:48:42 --> Language Class Initialized
INFO - 2021-12-18 01:48:43 --> Language Class Initialized
INFO - 2021-12-18 01:48:43 --> Config Class Initialized
INFO - 2021-12-18 01:48:43 --> Loader Class Initialized
INFO - 2021-12-18 01:48:43 --> Helper loaded: url_helper
INFO - 2021-12-18 01:48:43 --> Helper loaded: file_helper
INFO - 2021-12-18 01:48:43 --> Helper loaded: form_helper
INFO - 2021-12-18 01:48:43 --> Helper loaded: my_helper
INFO - 2021-12-18 01:48:43 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:48:43 --> Controller Class Initialized
INFO - 2021-12-18 01:48:43 --> Final output sent to browser
DEBUG - 2021-12-18 01:48:43 --> Total execution time: 0.0390
INFO - 2021-12-18 01:49:08 --> Config Class Initialized
INFO - 2021-12-18 01:49:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:08 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:08 --> URI Class Initialized
INFO - 2021-12-18 01:49:08 --> Router Class Initialized
INFO - 2021-12-18 01:49:08 --> Output Class Initialized
INFO - 2021-12-18 01:49:08 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:08 --> Input Class Initialized
INFO - 2021-12-18 01:49:08 --> Language Class Initialized
INFO - 2021-12-18 01:49:08 --> Language Class Initialized
INFO - 2021-12-18 01:49:08 --> Config Class Initialized
INFO - 2021-12-18 01:49:08 --> Loader Class Initialized
INFO - 2021-12-18 01:49:08 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:08 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:08 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:08 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:08 --> Controller Class Initialized
INFO - 2021-12-18 01:49:08 --> Final output sent to browser
DEBUG - 2021-12-18 01:49:08 --> Total execution time: 0.0470
INFO - 2021-12-18 01:49:08 --> Config Class Initialized
INFO - 2021-12-18 01:49:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:08 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:08 --> URI Class Initialized
INFO - 2021-12-18 01:49:08 --> Router Class Initialized
INFO - 2021-12-18 01:49:08 --> Output Class Initialized
INFO - 2021-12-18 01:49:08 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:08 --> Input Class Initialized
INFO - 2021-12-18 01:49:08 --> Language Class Initialized
INFO - 2021-12-18 01:49:08 --> Language Class Initialized
INFO - 2021-12-18 01:49:08 --> Config Class Initialized
INFO - 2021-12-18 01:49:08 --> Loader Class Initialized
INFO - 2021-12-18 01:49:08 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:08 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:08 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:08 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:08 --> Controller Class Initialized
INFO - 2021-12-18 01:49:18 --> Config Class Initialized
INFO - 2021-12-18 01:49:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:18 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:18 --> URI Class Initialized
INFO - 2021-12-18 01:49:18 --> Router Class Initialized
INFO - 2021-12-18 01:49:18 --> Output Class Initialized
INFO - 2021-12-18 01:49:18 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:18 --> Input Class Initialized
INFO - 2021-12-18 01:49:18 --> Language Class Initialized
INFO - 2021-12-18 01:49:18 --> Language Class Initialized
INFO - 2021-12-18 01:49:18 --> Config Class Initialized
INFO - 2021-12-18 01:49:18 --> Loader Class Initialized
INFO - 2021-12-18 01:49:18 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:18 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:18 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:18 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:18 --> Controller Class Initialized
DEBUG - 2021-12-18 01:49:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:49:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:49:18 --> Final output sent to browser
DEBUG - 2021-12-18 01:49:18 --> Total execution time: 0.0530
INFO - 2021-12-18 01:49:18 --> Config Class Initialized
INFO - 2021-12-18 01:49:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:18 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:18 --> URI Class Initialized
INFO - 2021-12-18 01:49:18 --> Router Class Initialized
INFO - 2021-12-18 01:49:18 --> Output Class Initialized
INFO - 2021-12-18 01:49:18 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:18 --> Input Class Initialized
INFO - 2021-12-18 01:49:18 --> Language Class Initialized
INFO - 2021-12-18 01:49:18 --> Language Class Initialized
INFO - 2021-12-18 01:49:18 --> Config Class Initialized
INFO - 2021-12-18 01:49:18 --> Loader Class Initialized
INFO - 2021-12-18 01:49:18 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:18 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:18 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:18 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:18 --> Controller Class Initialized
INFO - 2021-12-18 01:49:19 --> Config Class Initialized
INFO - 2021-12-18 01:49:19 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:19 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:19 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:19 --> URI Class Initialized
INFO - 2021-12-18 01:49:19 --> Router Class Initialized
INFO - 2021-12-18 01:49:19 --> Output Class Initialized
INFO - 2021-12-18 01:49:19 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:19 --> Input Class Initialized
INFO - 2021-12-18 01:49:19 --> Language Class Initialized
INFO - 2021-12-18 01:49:19 --> Language Class Initialized
INFO - 2021-12-18 01:49:19 --> Config Class Initialized
INFO - 2021-12-18 01:49:19 --> Loader Class Initialized
INFO - 2021-12-18 01:49:19 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:19 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:19 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:19 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:19 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:19 --> Controller Class Initialized
DEBUG - 2021-12-18 01:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:49:19 --> Final output sent to browser
DEBUG - 2021-12-18 01:49:19 --> Total execution time: 0.0490
INFO - 2021-12-18 01:49:44 --> Config Class Initialized
INFO - 2021-12-18 01:49:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:44 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:44 --> URI Class Initialized
INFO - 2021-12-18 01:49:44 --> Router Class Initialized
INFO - 2021-12-18 01:49:44 --> Output Class Initialized
INFO - 2021-12-18 01:49:44 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:44 --> Input Class Initialized
INFO - 2021-12-18 01:49:44 --> Language Class Initialized
INFO - 2021-12-18 01:49:44 --> Language Class Initialized
INFO - 2021-12-18 01:49:44 --> Config Class Initialized
INFO - 2021-12-18 01:49:44 --> Loader Class Initialized
INFO - 2021-12-18 01:49:44 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:44 --> Controller Class Initialized
INFO - 2021-12-18 01:49:44 --> Config Class Initialized
INFO - 2021-12-18 01:49:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:44 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:44 --> URI Class Initialized
INFO - 2021-12-18 01:49:44 --> Router Class Initialized
INFO - 2021-12-18 01:49:44 --> Output Class Initialized
INFO - 2021-12-18 01:49:44 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:44 --> Input Class Initialized
INFO - 2021-12-18 01:49:44 --> Language Class Initialized
INFO - 2021-12-18 01:49:44 --> Language Class Initialized
INFO - 2021-12-18 01:49:44 --> Config Class Initialized
INFO - 2021-12-18 01:49:44 --> Loader Class Initialized
INFO - 2021-12-18 01:49:44 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:44 --> Controller Class Initialized
DEBUG - 2021-12-18 01:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:49:44 --> Final output sent to browser
DEBUG - 2021-12-18 01:49:44 --> Total execution time: 0.0360
INFO - 2021-12-18 01:49:44 --> Config Class Initialized
INFO - 2021-12-18 01:49:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:44 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:44 --> URI Class Initialized
INFO - 2021-12-18 01:49:44 --> Router Class Initialized
INFO - 2021-12-18 01:49:44 --> Output Class Initialized
INFO - 2021-12-18 01:49:44 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:44 --> Input Class Initialized
INFO - 2021-12-18 01:49:44 --> Language Class Initialized
INFO - 2021-12-18 01:49:44 --> Language Class Initialized
INFO - 2021-12-18 01:49:44 --> Config Class Initialized
INFO - 2021-12-18 01:49:44 --> Loader Class Initialized
INFO - 2021-12-18 01:49:44 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:44 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:44 --> Controller Class Initialized
INFO - 2021-12-18 01:49:51 --> Config Class Initialized
INFO - 2021-12-18 01:49:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:51 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:51 --> URI Class Initialized
INFO - 2021-12-18 01:49:51 --> Router Class Initialized
INFO - 2021-12-18 01:49:51 --> Output Class Initialized
INFO - 2021-12-18 01:49:51 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:51 --> Input Class Initialized
INFO - 2021-12-18 01:49:51 --> Language Class Initialized
INFO - 2021-12-18 01:49:51 --> Language Class Initialized
INFO - 2021-12-18 01:49:51 --> Config Class Initialized
INFO - 2021-12-18 01:49:51 --> Loader Class Initialized
INFO - 2021-12-18 01:49:51 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:51 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:51 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:51 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:51 --> Controller Class Initialized
INFO - 2021-12-18 01:49:51 --> Config Class Initialized
INFO - 2021-12-18 01:49:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:51 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:51 --> URI Class Initialized
INFO - 2021-12-18 01:49:51 --> Router Class Initialized
INFO - 2021-12-18 01:49:51 --> Output Class Initialized
INFO - 2021-12-18 01:49:51 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:51 --> Input Class Initialized
INFO - 2021-12-18 01:49:51 --> Language Class Initialized
INFO - 2021-12-18 01:49:51 --> Language Class Initialized
INFO - 2021-12-18 01:49:51 --> Config Class Initialized
INFO - 2021-12-18 01:49:51 --> Loader Class Initialized
INFO - 2021-12-18 01:49:51 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:51 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:51 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:51 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:51 --> Controller Class Initialized
INFO - 2021-12-18 01:49:52 --> Config Class Initialized
INFO - 2021-12-18 01:49:52 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:49:52 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:49:52 --> Utf8 Class Initialized
INFO - 2021-12-18 01:49:52 --> URI Class Initialized
INFO - 2021-12-18 01:49:52 --> Router Class Initialized
INFO - 2021-12-18 01:49:52 --> Output Class Initialized
INFO - 2021-12-18 01:49:52 --> Security Class Initialized
DEBUG - 2021-12-18 01:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:49:52 --> Input Class Initialized
INFO - 2021-12-18 01:49:52 --> Language Class Initialized
INFO - 2021-12-18 01:49:52 --> Language Class Initialized
INFO - 2021-12-18 01:49:52 --> Config Class Initialized
INFO - 2021-12-18 01:49:52 --> Loader Class Initialized
INFO - 2021-12-18 01:49:52 --> Helper loaded: url_helper
INFO - 2021-12-18 01:49:52 --> Helper loaded: file_helper
INFO - 2021-12-18 01:49:52 --> Helper loaded: form_helper
INFO - 2021-12-18 01:49:52 --> Helper loaded: my_helper
INFO - 2021-12-18 01:49:52 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:49:52 --> Controller Class Initialized
INFO - 2021-12-18 01:50:01 --> Config Class Initialized
INFO - 2021-12-18 01:50:01 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:01 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:01 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:01 --> URI Class Initialized
INFO - 2021-12-18 01:50:01 --> Router Class Initialized
INFO - 2021-12-18 01:50:01 --> Output Class Initialized
INFO - 2021-12-18 01:50:01 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:01 --> Input Class Initialized
INFO - 2021-12-18 01:50:01 --> Language Class Initialized
INFO - 2021-12-18 01:50:01 --> Language Class Initialized
INFO - 2021-12-18 01:50:01 --> Config Class Initialized
INFO - 2021-12-18 01:50:01 --> Loader Class Initialized
INFO - 2021-12-18 01:50:01 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:01 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:01 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:01 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:01 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:01 --> Controller Class Initialized
INFO - 2021-12-18 01:50:02 --> Config Class Initialized
INFO - 2021-12-18 01:50:02 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:02 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:02 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:02 --> URI Class Initialized
INFO - 2021-12-18 01:50:02 --> Router Class Initialized
INFO - 2021-12-18 01:50:02 --> Output Class Initialized
INFO - 2021-12-18 01:50:02 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:02 --> Input Class Initialized
INFO - 2021-12-18 01:50:02 --> Language Class Initialized
INFO - 2021-12-18 01:50:02 --> Language Class Initialized
INFO - 2021-12-18 01:50:02 --> Config Class Initialized
INFO - 2021-12-18 01:50:02 --> Loader Class Initialized
INFO - 2021-12-18 01:50:02 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:02 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:02 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:02 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:02 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:02 --> Controller Class Initialized
INFO - 2021-12-18 01:50:02 --> Config Class Initialized
INFO - 2021-12-18 01:50:02 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:02 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:02 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:02 --> URI Class Initialized
INFO - 2021-12-18 01:50:02 --> Router Class Initialized
INFO - 2021-12-18 01:50:02 --> Output Class Initialized
INFO - 2021-12-18 01:50:02 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:02 --> Input Class Initialized
INFO - 2021-12-18 01:50:02 --> Language Class Initialized
INFO - 2021-12-18 01:50:02 --> Language Class Initialized
INFO - 2021-12-18 01:50:02 --> Config Class Initialized
INFO - 2021-12-18 01:50:02 --> Loader Class Initialized
INFO - 2021-12-18 01:50:02 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:02 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:02 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:02 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:02 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:02 --> Controller Class Initialized
INFO - 2021-12-18 01:50:12 --> Config Class Initialized
INFO - 2021-12-18 01:50:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:12 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:12 --> URI Class Initialized
INFO - 2021-12-18 01:50:12 --> Router Class Initialized
INFO - 2021-12-18 01:50:12 --> Output Class Initialized
INFO - 2021-12-18 01:50:12 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:12 --> Input Class Initialized
INFO - 2021-12-18 01:50:12 --> Language Class Initialized
INFO - 2021-12-18 01:50:12 --> Language Class Initialized
INFO - 2021-12-18 01:50:12 --> Config Class Initialized
INFO - 2021-12-18 01:50:12 --> Loader Class Initialized
INFO - 2021-12-18 01:50:12 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:12 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:12 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:12 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:12 --> Controller Class Initialized
INFO - 2021-12-18 01:50:12 --> Config Class Initialized
INFO - 2021-12-18 01:50:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:12 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:12 --> URI Class Initialized
INFO - 2021-12-18 01:50:12 --> Router Class Initialized
INFO - 2021-12-18 01:50:12 --> Output Class Initialized
INFO - 2021-12-18 01:50:12 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:12 --> Input Class Initialized
INFO - 2021-12-18 01:50:12 --> Language Class Initialized
INFO - 2021-12-18 01:50:12 --> Language Class Initialized
INFO - 2021-12-18 01:50:12 --> Config Class Initialized
INFO - 2021-12-18 01:50:12 --> Loader Class Initialized
INFO - 2021-12-18 01:50:12 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:12 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:12 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:12 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:12 --> Controller Class Initialized
INFO - 2021-12-18 01:50:15 --> Config Class Initialized
INFO - 2021-12-18 01:50:15 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:15 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:15 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:15 --> URI Class Initialized
INFO - 2021-12-18 01:50:15 --> Router Class Initialized
INFO - 2021-12-18 01:50:15 --> Output Class Initialized
INFO - 2021-12-18 01:50:15 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:15 --> Input Class Initialized
INFO - 2021-12-18 01:50:15 --> Language Class Initialized
INFO - 2021-12-18 01:50:15 --> Language Class Initialized
INFO - 2021-12-18 01:50:15 --> Config Class Initialized
INFO - 2021-12-18 01:50:15 --> Loader Class Initialized
INFO - 2021-12-18 01:50:15 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:15 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:15 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:15 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:15 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:15 --> Controller Class Initialized
DEBUG - 2021-12-18 01:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-18 01:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:50:15 --> Final output sent to browser
DEBUG - 2021-12-18 01:50:15 --> Total execution time: 0.0500
INFO - 2021-12-18 01:50:15 --> Config Class Initialized
INFO - 2021-12-18 01:50:15 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:15 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:15 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:15 --> URI Class Initialized
INFO - 2021-12-18 01:50:15 --> Router Class Initialized
INFO - 2021-12-18 01:50:15 --> Output Class Initialized
INFO - 2021-12-18 01:50:15 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:15 --> Input Class Initialized
INFO - 2021-12-18 01:50:15 --> Language Class Initialized
INFO - 2021-12-18 01:50:15 --> Language Class Initialized
INFO - 2021-12-18 01:50:15 --> Config Class Initialized
INFO - 2021-12-18 01:50:15 --> Loader Class Initialized
INFO - 2021-12-18 01:50:15 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:15 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:15 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:15 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:15 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:15 --> Controller Class Initialized
INFO - 2021-12-18 01:50:16 --> Config Class Initialized
INFO - 2021-12-18 01:50:16 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:16 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:16 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:16 --> URI Class Initialized
INFO - 2021-12-18 01:50:16 --> Router Class Initialized
INFO - 2021-12-18 01:50:16 --> Output Class Initialized
INFO - 2021-12-18 01:50:16 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:16 --> Input Class Initialized
INFO - 2021-12-18 01:50:16 --> Language Class Initialized
INFO - 2021-12-18 01:50:16 --> Language Class Initialized
INFO - 2021-12-18 01:50:16 --> Config Class Initialized
INFO - 2021-12-18 01:50:16 --> Loader Class Initialized
INFO - 2021-12-18 01:50:16 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:16 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:16 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:16 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:16 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:16 --> Controller Class Initialized
INFO - 2021-12-18 01:50:16 --> Final output sent to browser
DEBUG - 2021-12-18 01:50:16 --> Total execution time: 0.0450
INFO - 2021-12-18 01:50:38 --> Config Class Initialized
INFO - 2021-12-18 01:50:38 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:38 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:38 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:38 --> URI Class Initialized
INFO - 2021-12-18 01:50:38 --> Router Class Initialized
INFO - 2021-12-18 01:50:38 --> Output Class Initialized
INFO - 2021-12-18 01:50:38 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:38 --> Input Class Initialized
INFO - 2021-12-18 01:50:38 --> Language Class Initialized
INFO - 2021-12-18 01:50:38 --> Language Class Initialized
INFO - 2021-12-18 01:50:38 --> Config Class Initialized
INFO - 2021-12-18 01:50:38 --> Loader Class Initialized
INFO - 2021-12-18 01:50:38 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:38 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:38 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:38 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:38 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:39 --> Controller Class Initialized
INFO - 2021-12-18 01:50:39 --> Final output sent to browser
DEBUG - 2021-12-18 01:50:39 --> Total execution time: 0.0450
INFO - 2021-12-18 01:50:39 --> Config Class Initialized
INFO - 2021-12-18 01:50:39 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:39 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:39 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:39 --> URI Class Initialized
INFO - 2021-12-18 01:50:39 --> Router Class Initialized
INFO - 2021-12-18 01:50:39 --> Output Class Initialized
INFO - 2021-12-18 01:50:39 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:39 --> Input Class Initialized
INFO - 2021-12-18 01:50:39 --> Language Class Initialized
INFO - 2021-12-18 01:50:39 --> Language Class Initialized
INFO - 2021-12-18 01:50:39 --> Config Class Initialized
INFO - 2021-12-18 01:50:39 --> Loader Class Initialized
INFO - 2021-12-18 01:50:39 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:39 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:39 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:39 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:39 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:39 --> Controller Class Initialized
INFO - 2021-12-18 01:50:46 --> Config Class Initialized
INFO - 2021-12-18 01:50:46 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:46 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:46 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:46 --> URI Class Initialized
INFO - 2021-12-18 01:50:46 --> Router Class Initialized
INFO - 2021-12-18 01:50:46 --> Output Class Initialized
INFO - 2021-12-18 01:50:46 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:46 --> Input Class Initialized
INFO - 2021-12-18 01:50:46 --> Language Class Initialized
INFO - 2021-12-18 01:50:46 --> Language Class Initialized
INFO - 2021-12-18 01:50:46 --> Config Class Initialized
INFO - 2021-12-18 01:50:46 --> Loader Class Initialized
INFO - 2021-12-18 01:50:46 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:46 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:46 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:46 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:46 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:46 --> Controller Class Initialized
INFO - 2021-12-18 01:50:46 --> Final output sent to browser
DEBUG - 2021-12-18 01:50:46 --> Total execution time: 0.0520
INFO - 2021-12-18 01:50:46 --> Config Class Initialized
INFO - 2021-12-18 01:50:46 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:46 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:46 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:46 --> URI Class Initialized
INFO - 2021-12-18 01:50:46 --> Router Class Initialized
INFO - 2021-12-18 01:50:46 --> Output Class Initialized
INFO - 2021-12-18 01:50:46 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:46 --> Input Class Initialized
INFO - 2021-12-18 01:50:46 --> Language Class Initialized
INFO - 2021-12-18 01:50:46 --> Language Class Initialized
INFO - 2021-12-18 01:50:46 --> Config Class Initialized
INFO - 2021-12-18 01:50:46 --> Loader Class Initialized
INFO - 2021-12-18 01:50:46 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:46 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:46 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:46 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:46 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:46 --> Controller Class Initialized
INFO - 2021-12-18 01:50:54 --> Config Class Initialized
INFO - 2021-12-18 01:50:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:54 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:54 --> URI Class Initialized
INFO - 2021-12-18 01:50:54 --> Router Class Initialized
INFO - 2021-12-18 01:50:54 --> Output Class Initialized
INFO - 2021-12-18 01:50:54 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:54 --> Input Class Initialized
INFO - 2021-12-18 01:50:54 --> Language Class Initialized
INFO - 2021-12-18 01:50:54 --> Language Class Initialized
INFO - 2021-12-18 01:50:54 --> Config Class Initialized
INFO - 2021-12-18 01:50:54 --> Loader Class Initialized
INFO - 2021-12-18 01:50:54 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:54 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:54 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:54 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:54 --> Controller Class Initialized
INFO - 2021-12-18 01:50:56 --> Config Class Initialized
INFO - 2021-12-18 01:50:56 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:56 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:56 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:56 --> URI Class Initialized
INFO - 2021-12-18 01:50:56 --> Router Class Initialized
INFO - 2021-12-18 01:50:56 --> Output Class Initialized
INFO - 2021-12-18 01:50:56 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:56 --> Input Class Initialized
INFO - 2021-12-18 01:50:56 --> Language Class Initialized
INFO - 2021-12-18 01:50:56 --> Language Class Initialized
INFO - 2021-12-18 01:50:56 --> Config Class Initialized
INFO - 2021-12-18 01:50:56 --> Loader Class Initialized
INFO - 2021-12-18 01:50:56 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:56 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:56 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:56 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:56 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:56 --> Controller Class Initialized
INFO - 2021-12-18 01:50:58 --> Config Class Initialized
INFO - 2021-12-18 01:50:58 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:58 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:58 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:58 --> URI Class Initialized
INFO - 2021-12-18 01:50:58 --> Router Class Initialized
INFO - 2021-12-18 01:50:58 --> Output Class Initialized
INFO - 2021-12-18 01:50:58 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:58 --> Input Class Initialized
INFO - 2021-12-18 01:50:58 --> Language Class Initialized
INFO - 2021-12-18 01:50:58 --> Language Class Initialized
INFO - 2021-12-18 01:50:58 --> Config Class Initialized
INFO - 2021-12-18 01:50:58 --> Loader Class Initialized
INFO - 2021-12-18 01:50:58 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:58 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:58 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:58 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:58 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:58 --> Controller Class Initialized
INFO - 2021-12-18 01:50:58 --> Final output sent to browser
DEBUG - 2021-12-18 01:50:58 --> Total execution time: 0.0590
INFO - 2021-12-18 01:50:58 --> Config Class Initialized
INFO - 2021-12-18 01:50:58 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:50:58 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:50:58 --> Utf8 Class Initialized
INFO - 2021-12-18 01:50:58 --> URI Class Initialized
INFO - 2021-12-18 01:50:58 --> Router Class Initialized
INFO - 2021-12-18 01:50:58 --> Output Class Initialized
INFO - 2021-12-18 01:50:58 --> Security Class Initialized
DEBUG - 2021-12-18 01:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:50:58 --> Input Class Initialized
INFO - 2021-12-18 01:50:58 --> Language Class Initialized
INFO - 2021-12-18 01:50:58 --> Language Class Initialized
INFO - 2021-12-18 01:50:58 --> Config Class Initialized
INFO - 2021-12-18 01:50:58 --> Loader Class Initialized
INFO - 2021-12-18 01:50:58 --> Helper loaded: url_helper
INFO - 2021-12-18 01:50:58 --> Helper loaded: file_helper
INFO - 2021-12-18 01:50:58 --> Helper loaded: form_helper
INFO - 2021-12-18 01:50:58 --> Helper loaded: my_helper
INFO - 2021-12-18 01:50:58 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:50:58 --> Controller Class Initialized
INFO - 2021-12-18 01:51:00 --> Config Class Initialized
INFO - 2021-12-18 01:51:00 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:00 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:00 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:00 --> URI Class Initialized
INFO - 2021-12-18 01:51:00 --> Router Class Initialized
INFO - 2021-12-18 01:51:00 --> Output Class Initialized
INFO - 2021-12-18 01:51:00 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:00 --> Input Class Initialized
INFO - 2021-12-18 01:51:00 --> Language Class Initialized
INFO - 2021-12-18 01:51:00 --> Language Class Initialized
INFO - 2021-12-18 01:51:00 --> Config Class Initialized
INFO - 2021-12-18 01:51:00 --> Loader Class Initialized
INFO - 2021-12-18 01:51:00 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:00 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:00 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:00 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:00 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:00 --> Controller Class Initialized
INFO - 2021-12-18 01:51:01 --> Config Class Initialized
INFO - 2021-12-18 01:51:01 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:01 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:01 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:01 --> URI Class Initialized
INFO - 2021-12-18 01:51:01 --> Router Class Initialized
INFO - 2021-12-18 01:51:01 --> Output Class Initialized
INFO - 2021-12-18 01:51:01 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:01 --> Input Class Initialized
INFO - 2021-12-18 01:51:01 --> Language Class Initialized
INFO - 2021-12-18 01:51:01 --> Language Class Initialized
INFO - 2021-12-18 01:51:01 --> Config Class Initialized
INFO - 2021-12-18 01:51:01 --> Loader Class Initialized
INFO - 2021-12-18 01:51:01 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:01 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:01 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:01 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:01 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:01 --> Controller Class Initialized
INFO - 2021-12-18 01:51:04 --> Config Class Initialized
INFO - 2021-12-18 01:51:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:04 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:04 --> URI Class Initialized
INFO - 2021-12-18 01:51:04 --> Router Class Initialized
INFO - 2021-12-18 01:51:04 --> Output Class Initialized
INFO - 2021-12-18 01:51:04 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:04 --> Input Class Initialized
INFO - 2021-12-18 01:51:04 --> Language Class Initialized
INFO - 2021-12-18 01:51:04 --> Language Class Initialized
INFO - 2021-12-18 01:51:04 --> Config Class Initialized
INFO - 2021-12-18 01:51:04 --> Loader Class Initialized
INFO - 2021-12-18 01:51:04 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:04 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:04 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:04 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:04 --> Controller Class Initialized
INFO - 2021-12-18 01:51:04 --> Final output sent to browser
DEBUG - 2021-12-18 01:51:04 --> Total execution time: 0.0610
INFO - 2021-12-18 01:51:04 --> Config Class Initialized
INFO - 2021-12-18 01:51:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:04 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:04 --> URI Class Initialized
INFO - 2021-12-18 01:51:04 --> Router Class Initialized
INFO - 2021-12-18 01:51:04 --> Output Class Initialized
INFO - 2021-12-18 01:51:04 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:04 --> Input Class Initialized
INFO - 2021-12-18 01:51:04 --> Language Class Initialized
INFO - 2021-12-18 01:51:04 --> Language Class Initialized
INFO - 2021-12-18 01:51:04 --> Config Class Initialized
INFO - 2021-12-18 01:51:04 --> Loader Class Initialized
INFO - 2021-12-18 01:51:04 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:04 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:04 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:04 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:04 --> Controller Class Initialized
INFO - 2021-12-18 01:51:07 --> Config Class Initialized
INFO - 2021-12-18 01:51:07 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:07 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:07 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:07 --> URI Class Initialized
INFO - 2021-12-18 01:51:07 --> Router Class Initialized
INFO - 2021-12-18 01:51:07 --> Output Class Initialized
INFO - 2021-12-18 01:51:07 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:07 --> Input Class Initialized
INFO - 2021-12-18 01:51:07 --> Language Class Initialized
INFO - 2021-12-18 01:51:07 --> Language Class Initialized
INFO - 2021-12-18 01:51:07 --> Config Class Initialized
INFO - 2021-12-18 01:51:07 --> Loader Class Initialized
INFO - 2021-12-18 01:51:07 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:07 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:07 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:07 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:07 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:07 --> Controller Class Initialized
INFO - 2021-12-18 01:51:12 --> Config Class Initialized
INFO - 2021-12-18 01:51:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:12 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:12 --> URI Class Initialized
INFO - 2021-12-18 01:51:12 --> Router Class Initialized
INFO - 2021-12-18 01:51:12 --> Output Class Initialized
INFO - 2021-12-18 01:51:12 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:12 --> Input Class Initialized
INFO - 2021-12-18 01:51:12 --> Language Class Initialized
INFO - 2021-12-18 01:51:12 --> Language Class Initialized
INFO - 2021-12-18 01:51:12 --> Config Class Initialized
INFO - 2021-12-18 01:51:12 --> Loader Class Initialized
INFO - 2021-12-18 01:51:12 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:12 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:12 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:12 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:12 --> Controller Class Initialized
INFO - 2021-12-18 01:51:15 --> Config Class Initialized
INFO - 2021-12-18 01:51:15 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:15 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:15 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:15 --> URI Class Initialized
INFO - 2021-12-18 01:51:15 --> Router Class Initialized
INFO - 2021-12-18 01:51:15 --> Output Class Initialized
INFO - 2021-12-18 01:51:15 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:15 --> Input Class Initialized
INFO - 2021-12-18 01:51:15 --> Language Class Initialized
INFO - 2021-12-18 01:51:15 --> Language Class Initialized
INFO - 2021-12-18 01:51:15 --> Config Class Initialized
INFO - 2021-12-18 01:51:15 --> Loader Class Initialized
INFO - 2021-12-18 01:51:15 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:15 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:15 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:15 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:15 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:15 --> Controller Class Initialized
INFO - 2021-12-18 01:51:15 --> Final output sent to browser
DEBUG - 2021-12-18 01:51:15 --> Total execution time: 0.0520
INFO - 2021-12-18 01:51:16 --> Config Class Initialized
INFO - 2021-12-18 01:51:16 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:16 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:16 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:16 --> URI Class Initialized
INFO - 2021-12-18 01:51:16 --> Router Class Initialized
INFO - 2021-12-18 01:51:16 --> Output Class Initialized
INFO - 2021-12-18 01:51:16 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:16 --> Input Class Initialized
INFO - 2021-12-18 01:51:16 --> Language Class Initialized
INFO - 2021-12-18 01:51:16 --> Language Class Initialized
INFO - 2021-12-18 01:51:16 --> Config Class Initialized
INFO - 2021-12-18 01:51:16 --> Loader Class Initialized
INFO - 2021-12-18 01:51:16 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:16 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:16 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:16 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:16 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:16 --> Controller Class Initialized
INFO - 2021-12-18 01:51:18 --> Config Class Initialized
INFO - 2021-12-18 01:51:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:18 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:18 --> URI Class Initialized
INFO - 2021-12-18 01:51:18 --> Router Class Initialized
INFO - 2021-12-18 01:51:18 --> Output Class Initialized
INFO - 2021-12-18 01:51:18 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:18 --> Input Class Initialized
INFO - 2021-12-18 01:51:18 --> Language Class Initialized
INFO - 2021-12-18 01:51:18 --> Language Class Initialized
INFO - 2021-12-18 01:51:18 --> Config Class Initialized
INFO - 2021-12-18 01:51:18 --> Loader Class Initialized
INFO - 2021-12-18 01:51:18 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:18 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:18 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:18 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:18 --> Controller Class Initialized
INFO - 2021-12-18 01:51:30 --> Config Class Initialized
INFO - 2021-12-18 01:51:30 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:30 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:30 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:30 --> URI Class Initialized
INFO - 2021-12-18 01:51:30 --> Router Class Initialized
INFO - 2021-12-18 01:51:30 --> Output Class Initialized
INFO - 2021-12-18 01:51:30 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:30 --> Input Class Initialized
INFO - 2021-12-18 01:51:30 --> Language Class Initialized
INFO - 2021-12-18 01:51:30 --> Language Class Initialized
INFO - 2021-12-18 01:51:30 --> Config Class Initialized
INFO - 2021-12-18 01:51:30 --> Loader Class Initialized
INFO - 2021-12-18 01:51:30 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:30 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:30 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:30 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:30 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:30 --> Controller Class Initialized
DEBUG - 2021-12-18 01:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:51:30 --> Final output sent to browser
DEBUG - 2021-12-18 01:51:30 --> Total execution time: 0.0510
INFO - 2021-12-18 01:51:30 --> Config Class Initialized
INFO - 2021-12-18 01:51:30 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:30 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:30 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:30 --> URI Class Initialized
INFO - 2021-12-18 01:51:30 --> Router Class Initialized
INFO - 2021-12-18 01:51:30 --> Output Class Initialized
INFO - 2021-12-18 01:51:30 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:30 --> Input Class Initialized
INFO - 2021-12-18 01:51:30 --> Language Class Initialized
INFO - 2021-12-18 01:51:30 --> Language Class Initialized
INFO - 2021-12-18 01:51:30 --> Config Class Initialized
INFO - 2021-12-18 01:51:30 --> Loader Class Initialized
INFO - 2021-12-18 01:51:30 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:30 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:30 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:30 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:30 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:30 --> Controller Class Initialized
INFO - 2021-12-18 01:51:31 --> Config Class Initialized
INFO - 2021-12-18 01:51:31 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:31 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:31 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:31 --> URI Class Initialized
INFO - 2021-12-18 01:51:31 --> Router Class Initialized
INFO - 2021-12-18 01:51:31 --> Output Class Initialized
INFO - 2021-12-18 01:51:31 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:31 --> Input Class Initialized
INFO - 2021-12-18 01:51:31 --> Language Class Initialized
INFO - 2021-12-18 01:51:31 --> Language Class Initialized
INFO - 2021-12-18 01:51:31 --> Config Class Initialized
INFO - 2021-12-18 01:51:31 --> Loader Class Initialized
INFO - 2021-12-18 01:51:31 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:31 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:31 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:31 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:31 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:31 --> Controller Class Initialized
DEBUG - 2021-12-18 01:51:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:51:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:51:31 --> Final output sent to browser
DEBUG - 2021-12-18 01:51:31 --> Total execution time: 0.0650
INFO - 2021-12-18 01:51:51 --> Config Class Initialized
INFO - 2021-12-18 01:51:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:51 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:51 --> URI Class Initialized
INFO - 2021-12-18 01:51:51 --> Router Class Initialized
INFO - 2021-12-18 01:51:51 --> Output Class Initialized
INFO - 2021-12-18 01:51:51 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:51 --> Input Class Initialized
INFO - 2021-12-18 01:51:51 --> Language Class Initialized
INFO - 2021-12-18 01:51:51 --> Language Class Initialized
INFO - 2021-12-18 01:51:51 --> Config Class Initialized
INFO - 2021-12-18 01:51:51 --> Loader Class Initialized
INFO - 2021-12-18 01:51:51 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:51 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:51 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:51 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:51 --> Controller Class Initialized
INFO - 2021-12-18 01:51:51 --> Config Class Initialized
INFO - 2021-12-18 01:51:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:51 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:51 --> URI Class Initialized
INFO - 2021-12-18 01:51:51 --> Router Class Initialized
INFO - 2021-12-18 01:51:51 --> Output Class Initialized
INFO - 2021-12-18 01:51:51 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:51 --> Input Class Initialized
INFO - 2021-12-18 01:51:51 --> Language Class Initialized
INFO - 2021-12-18 01:51:51 --> Language Class Initialized
INFO - 2021-12-18 01:51:51 --> Config Class Initialized
INFO - 2021-12-18 01:51:51 --> Loader Class Initialized
INFO - 2021-12-18 01:51:51 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:51 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:51 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:51 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:51 --> Controller Class Initialized
DEBUG - 2021-12-18 01:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:51:51 --> Final output sent to browser
DEBUG - 2021-12-18 01:51:51 --> Total execution time: 0.0370
INFO - 2021-12-18 01:51:52 --> Config Class Initialized
INFO - 2021-12-18 01:51:52 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:51:52 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:51:52 --> Utf8 Class Initialized
INFO - 2021-12-18 01:51:52 --> URI Class Initialized
INFO - 2021-12-18 01:51:52 --> Router Class Initialized
INFO - 2021-12-18 01:51:52 --> Output Class Initialized
INFO - 2021-12-18 01:51:52 --> Security Class Initialized
DEBUG - 2021-12-18 01:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:51:52 --> Input Class Initialized
INFO - 2021-12-18 01:51:52 --> Language Class Initialized
INFO - 2021-12-18 01:51:52 --> Language Class Initialized
INFO - 2021-12-18 01:51:52 --> Config Class Initialized
INFO - 2021-12-18 01:51:52 --> Loader Class Initialized
INFO - 2021-12-18 01:51:52 --> Helper loaded: url_helper
INFO - 2021-12-18 01:51:52 --> Helper loaded: file_helper
INFO - 2021-12-18 01:51:52 --> Helper loaded: form_helper
INFO - 2021-12-18 01:51:52 --> Helper loaded: my_helper
INFO - 2021-12-18 01:51:52 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:51:52 --> Controller Class Initialized
INFO - 2021-12-18 01:52:10 --> Config Class Initialized
INFO - 2021-12-18 01:52:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:52:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:52:10 --> Utf8 Class Initialized
INFO - 2021-12-18 01:52:10 --> URI Class Initialized
INFO - 2021-12-18 01:52:10 --> Router Class Initialized
INFO - 2021-12-18 01:52:10 --> Output Class Initialized
INFO - 2021-12-18 01:52:10 --> Security Class Initialized
DEBUG - 2021-12-18 01:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:52:10 --> Input Class Initialized
INFO - 2021-12-18 01:52:10 --> Language Class Initialized
INFO - 2021-12-18 01:52:10 --> Language Class Initialized
INFO - 2021-12-18 01:52:10 --> Config Class Initialized
INFO - 2021-12-18 01:52:10 --> Loader Class Initialized
INFO - 2021-12-18 01:52:10 --> Helper loaded: url_helper
INFO - 2021-12-18 01:52:10 --> Helper loaded: file_helper
INFO - 2021-12-18 01:52:10 --> Helper loaded: form_helper
INFO - 2021-12-18 01:52:10 --> Helper loaded: my_helper
INFO - 2021-12-18 01:52:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:52:10 --> Controller Class Initialized
DEBUG - 2021-12-18 01:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:52:10 --> Final output sent to browser
DEBUG - 2021-12-18 01:52:10 --> Total execution time: 0.0430
INFO - 2021-12-18 01:52:32 --> Config Class Initialized
INFO - 2021-12-18 01:52:32 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:52:32 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:52:32 --> Utf8 Class Initialized
INFO - 2021-12-18 01:52:32 --> URI Class Initialized
INFO - 2021-12-18 01:52:32 --> Router Class Initialized
INFO - 2021-12-18 01:52:32 --> Output Class Initialized
INFO - 2021-12-18 01:52:32 --> Security Class Initialized
DEBUG - 2021-12-18 01:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:52:32 --> Input Class Initialized
INFO - 2021-12-18 01:52:32 --> Language Class Initialized
INFO - 2021-12-18 01:52:32 --> Language Class Initialized
INFO - 2021-12-18 01:52:32 --> Config Class Initialized
INFO - 2021-12-18 01:52:32 --> Loader Class Initialized
INFO - 2021-12-18 01:52:32 --> Helper loaded: url_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: file_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: form_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: my_helper
INFO - 2021-12-18 01:52:32 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:52:32 --> Controller Class Initialized
INFO - 2021-12-18 01:52:32 --> Config Class Initialized
INFO - 2021-12-18 01:52:32 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:52:32 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:52:32 --> Utf8 Class Initialized
INFO - 2021-12-18 01:52:32 --> URI Class Initialized
INFO - 2021-12-18 01:52:32 --> Router Class Initialized
INFO - 2021-12-18 01:52:32 --> Output Class Initialized
INFO - 2021-12-18 01:52:32 --> Security Class Initialized
DEBUG - 2021-12-18 01:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:52:32 --> Input Class Initialized
INFO - 2021-12-18 01:52:32 --> Language Class Initialized
INFO - 2021-12-18 01:52:32 --> Language Class Initialized
INFO - 2021-12-18 01:52:32 --> Config Class Initialized
INFO - 2021-12-18 01:52:32 --> Loader Class Initialized
INFO - 2021-12-18 01:52:32 --> Helper loaded: url_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: file_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: form_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: my_helper
INFO - 2021-12-18 01:52:32 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:52:32 --> Controller Class Initialized
DEBUG - 2021-12-18 01:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:52:32 --> Final output sent to browser
DEBUG - 2021-12-18 01:52:32 --> Total execution time: 0.0390
INFO - 2021-12-18 01:52:32 --> Config Class Initialized
INFO - 2021-12-18 01:52:32 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:52:32 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:52:32 --> Utf8 Class Initialized
INFO - 2021-12-18 01:52:32 --> URI Class Initialized
INFO - 2021-12-18 01:52:32 --> Router Class Initialized
INFO - 2021-12-18 01:52:32 --> Output Class Initialized
INFO - 2021-12-18 01:52:32 --> Security Class Initialized
DEBUG - 2021-12-18 01:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:52:32 --> Input Class Initialized
INFO - 2021-12-18 01:52:32 --> Language Class Initialized
INFO - 2021-12-18 01:52:32 --> Language Class Initialized
INFO - 2021-12-18 01:52:32 --> Config Class Initialized
INFO - 2021-12-18 01:52:32 --> Loader Class Initialized
INFO - 2021-12-18 01:52:32 --> Helper loaded: url_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: file_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: form_helper
INFO - 2021-12-18 01:52:32 --> Helper loaded: my_helper
INFO - 2021-12-18 01:52:32 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:52:32 --> Controller Class Initialized
INFO - 2021-12-18 01:52:34 --> Config Class Initialized
INFO - 2021-12-18 01:52:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:52:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:52:34 --> Utf8 Class Initialized
INFO - 2021-12-18 01:52:34 --> URI Class Initialized
INFO - 2021-12-18 01:52:34 --> Router Class Initialized
INFO - 2021-12-18 01:52:34 --> Output Class Initialized
INFO - 2021-12-18 01:52:34 --> Security Class Initialized
DEBUG - 2021-12-18 01:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:52:34 --> Input Class Initialized
INFO - 2021-12-18 01:52:34 --> Language Class Initialized
INFO - 2021-12-18 01:52:34 --> Language Class Initialized
INFO - 2021-12-18 01:52:34 --> Config Class Initialized
INFO - 2021-12-18 01:52:34 --> Loader Class Initialized
INFO - 2021-12-18 01:52:34 --> Helper loaded: url_helper
INFO - 2021-12-18 01:52:34 --> Helper loaded: file_helper
INFO - 2021-12-18 01:52:34 --> Helper loaded: form_helper
INFO - 2021-12-18 01:52:34 --> Helper loaded: my_helper
INFO - 2021-12-18 01:52:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:52:34 --> Controller Class Initialized
DEBUG - 2021-12-18 01:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:52:34 --> Final output sent to browser
DEBUG - 2021-12-18 01:52:34 --> Total execution time: 0.0530
INFO - 2021-12-18 01:53:00 --> Config Class Initialized
INFO - 2021-12-18 01:53:00 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:53:00 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:53:00 --> Utf8 Class Initialized
INFO - 2021-12-18 01:53:00 --> URI Class Initialized
INFO - 2021-12-18 01:53:00 --> Router Class Initialized
INFO - 2021-12-18 01:53:00 --> Output Class Initialized
INFO - 2021-12-18 01:53:00 --> Security Class Initialized
DEBUG - 2021-12-18 01:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:53:00 --> Input Class Initialized
INFO - 2021-12-18 01:53:00 --> Language Class Initialized
INFO - 2021-12-18 01:53:00 --> Language Class Initialized
INFO - 2021-12-18 01:53:00 --> Config Class Initialized
INFO - 2021-12-18 01:53:00 --> Loader Class Initialized
INFO - 2021-12-18 01:53:00 --> Helper loaded: url_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: file_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: form_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: my_helper
INFO - 2021-12-18 01:53:00 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:53:00 --> Controller Class Initialized
INFO - 2021-12-18 01:53:00 --> Config Class Initialized
INFO - 2021-12-18 01:53:00 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:53:00 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:53:00 --> Utf8 Class Initialized
INFO - 2021-12-18 01:53:00 --> URI Class Initialized
INFO - 2021-12-18 01:53:00 --> Router Class Initialized
INFO - 2021-12-18 01:53:00 --> Output Class Initialized
INFO - 2021-12-18 01:53:00 --> Security Class Initialized
DEBUG - 2021-12-18 01:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:53:00 --> Input Class Initialized
INFO - 2021-12-18 01:53:00 --> Language Class Initialized
INFO - 2021-12-18 01:53:00 --> Language Class Initialized
INFO - 2021-12-18 01:53:00 --> Config Class Initialized
INFO - 2021-12-18 01:53:00 --> Loader Class Initialized
INFO - 2021-12-18 01:53:00 --> Helper loaded: url_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: file_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: form_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: my_helper
INFO - 2021-12-18 01:53:00 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:53:00 --> Controller Class Initialized
DEBUG - 2021-12-18 01:53:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:53:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:53:00 --> Final output sent to browser
DEBUG - 2021-12-18 01:53:00 --> Total execution time: 0.0350
INFO - 2021-12-18 01:53:00 --> Config Class Initialized
INFO - 2021-12-18 01:53:00 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:53:00 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:53:00 --> Utf8 Class Initialized
INFO - 2021-12-18 01:53:00 --> URI Class Initialized
INFO - 2021-12-18 01:53:00 --> Router Class Initialized
INFO - 2021-12-18 01:53:00 --> Output Class Initialized
INFO - 2021-12-18 01:53:00 --> Security Class Initialized
DEBUG - 2021-12-18 01:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:53:00 --> Input Class Initialized
INFO - 2021-12-18 01:53:00 --> Language Class Initialized
INFO - 2021-12-18 01:53:00 --> Language Class Initialized
INFO - 2021-12-18 01:53:00 --> Config Class Initialized
INFO - 2021-12-18 01:53:00 --> Loader Class Initialized
INFO - 2021-12-18 01:53:00 --> Helper loaded: url_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: file_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: form_helper
INFO - 2021-12-18 01:53:00 --> Helper loaded: my_helper
INFO - 2021-12-18 01:53:00 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:53:00 --> Controller Class Initialized
INFO - 2021-12-18 01:53:29 --> Config Class Initialized
INFO - 2021-12-18 01:53:29 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:53:29 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:53:29 --> Utf8 Class Initialized
INFO - 2021-12-18 01:53:29 --> URI Class Initialized
INFO - 2021-12-18 01:53:29 --> Router Class Initialized
INFO - 2021-12-18 01:53:29 --> Output Class Initialized
INFO - 2021-12-18 01:53:29 --> Security Class Initialized
DEBUG - 2021-12-18 01:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:53:29 --> Input Class Initialized
INFO - 2021-12-18 01:53:29 --> Language Class Initialized
INFO - 2021-12-18 01:53:29 --> Language Class Initialized
INFO - 2021-12-18 01:53:29 --> Config Class Initialized
INFO - 2021-12-18 01:53:29 --> Loader Class Initialized
INFO - 2021-12-18 01:53:29 --> Helper loaded: url_helper
INFO - 2021-12-18 01:53:29 --> Helper loaded: file_helper
INFO - 2021-12-18 01:53:29 --> Helper loaded: form_helper
INFO - 2021-12-18 01:53:29 --> Helper loaded: my_helper
INFO - 2021-12-18 01:53:29 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:53:29 --> Controller Class Initialized
DEBUG - 2021-12-18 01:53:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:53:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:53:29 --> Final output sent to browser
DEBUG - 2021-12-18 01:53:29 --> Total execution time: 0.0460
INFO - 2021-12-18 01:53:57 --> Config Class Initialized
INFO - 2021-12-18 01:53:57 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:53:57 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:53:57 --> Utf8 Class Initialized
INFO - 2021-12-18 01:53:57 --> URI Class Initialized
INFO - 2021-12-18 01:53:57 --> Router Class Initialized
INFO - 2021-12-18 01:53:57 --> Output Class Initialized
INFO - 2021-12-18 01:53:57 --> Security Class Initialized
DEBUG - 2021-12-18 01:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:53:57 --> Input Class Initialized
INFO - 2021-12-18 01:53:57 --> Language Class Initialized
INFO - 2021-12-18 01:53:57 --> Language Class Initialized
INFO - 2021-12-18 01:53:57 --> Config Class Initialized
INFO - 2021-12-18 01:53:57 --> Loader Class Initialized
INFO - 2021-12-18 01:53:57 --> Helper loaded: url_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: file_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: form_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: my_helper
INFO - 2021-12-18 01:53:57 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:53:57 --> Controller Class Initialized
INFO - 2021-12-18 01:53:57 --> Config Class Initialized
INFO - 2021-12-18 01:53:57 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:53:57 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:53:57 --> Utf8 Class Initialized
INFO - 2021-12-18 01:53:57 --> URI Class Initialized
INFO - 2021-12-18 01:53:57 --> Router Class Initialized
INFO - 2021-12-18 01:53:57 --> Output Class Initialized
INFO - 2021-12-18 01:53:57 --> Security Class Initialized
DEBUG - 2021-12-18 01:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:53:57 --> Input Class Initialized
INFO - 2021-12-18 01:53:57 --> Language Class Initialized
INFO - 2021-12-18 01:53:57 --> Language Class Initialized
INFO - 2021-12-18 01:53:57 --> Config Class Initialized
INFO - 2021-12-18 01:53:57 --> Loader Class Initialized
INFO - 2021-12-18 01:53:57 --> Helper loaded: url_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: file_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: form_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: my_helper
INFO - 2021-12-18 01:53:57 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:53:57 --> Controller Class Initialized
DEBUG - 2021-12-18 01:53:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:53:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:53:57 --> Final output sent to browser
DEBUG - 2021-12-18 01:53:57 --> Total execution time: 0.0270
INFO - 2021-12-18 01:53:57 --> Config Class Initialized
INFO - 2021-12-18 01:53:57 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:53:57 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:53:57 --> Utf8 Class Initialized
INFO - 2021-12-18 01:53:57 --> URI Class Initialized
INFO - 2021-12-18 01:53:57 --> Router Class Initialized
INFO - 2021-12-18 01:53:57 --> Output Class Initialized
INFO - 2021-12-18 01:53:57 --> Security Class Initialized
DEBUG - 2021-12-18 01:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:53:57 --> Input Class Initialized
INFO - 2021-12-18 01:53:57 --> Language Class Initialized
INFO - 2021-12-18 01:53:57 --> Language Class Initialized
INFO - 2021-12-18 01:53:57 --> Config Class Initialized
INFO - 2021-12-18 01:53:57 --> Loader Class Initialized
INFO - 2021-12-18 01:53:57 --> Helper loaded: url_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: file_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: form_helper
INFO - 2021-12-18 01:53:57 --> Helper loaded: my_helper
INFO - 2021-12-18 01:53:57 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:53:57 --> Controller Class Initialized
INFO - 2021-12-18 01:54:11 --> Config Class Initialized
INFO - 2021-12-18 01:54:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:54:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:54:11 --> Utf8 Class Initialized
INFO - 2021-12-18 01:54:11 --> URI Class Initialized
INFO - 2021-12-18 01:54:11 --> Router Class Initialized
INFO - 2021-12-18 01:54:11 --> Output Class Initialized
INFO - 2021-12-18 01:54:11 --> Security Class Initialized
DEBUG - 2021-12-18 01:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:54:11 --> Input Class Initialized
INFO - 2021-12-18 01:54:11 --> Language Class Initialized
INFO - 2021-12-18 01:54:11 --> Language Class Initialized
INFO - 2021-12-18 01:54:11 --> Config Class Initialized
INFO - 2021-12-18 01:54:11 --> Loader Class Initialized
INFO - 2021-12-18 01:54:11 --> Helper loaded: url_helper
INFO - 2021-12-18 01:54:11 --> Helper loaded: file_helper
INFO - 2021-12-18 01:54:11 --> Helper loaded: form_helper
INFO - 2021-12-18 01:54:11 --> Helper loaded: my_helper
INFO - 2021-12-18 01:54:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:54:11 --> Controller Class Initialized
DEBUG - 2021-12-18 01:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:54:11 --> Final output sent to browser
DEBUG - 2021-12-18 01:54:11 --> Total execution time: 0.0360
INFO - 2021-12-18 01:54:54 --> Config Class Initialized
INFO - 2021-12-18 01:54:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:54:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:54:54 --> Utf8 Class Initialized
INFO - 2021-12-18 01:54:54 --> URI Class Initialized
INFO - 2021-12-18 01:54:54 --> Router Class Initialized
INFO - 2021-12-18 01:54:54 --> Output Class Initialized
INFO - 2021-12-18 01:54:54 --> Security Class Initialized
DEBUG - 2021-12-18 01:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:54:54 --> Input Class Initialized
INFO - 2021-12-18 01:54:54 --> Language Class Initialized
INFO - 2021-12-18 01:54:54 --> Language Class Initialized
INFO - 2021-12-18 01:54:54 --> Config Class Initialized
INFO - 2021-12-18 01:54:54 --> Loader Class Initialized
INFO - 2021-12-18 01:54:54 --> Helper loaded: url_helper
INFO - 2021-12-18 01:54:54 --> Helper loaded: file_helper
INFO - 2021-12-18 01:54:54 --> Helper loaded: form_helper
INFO - 2021-12-18 01:54:54 --> Helper loaded: my_helper
INFO - 2021-12-18 01:54:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:54:55 --> Controller Class Initialized
INFO - 2021-12-18 01:54:55 --> Config Class Initialized
INFO - 2021-12-18 01:54:55 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:54:55 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:54:55 --> Utf8 Class Initialized
INFO - 2021-12-18 01:54:55 --> URI Class Initialized
INFO - 2021-12-18 01:54:55 --> Router Class Initialized
INFO - 2021-12-18 01:54:55 --> Output Class Initialized
INFO - 2021-12-18 01:54:55 --> Security Class Initialized
DEBUG - 2021-12-18 01:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:54:55 --> Input Class Initialized
INFO - 2021-12-18 01:54:55 --> Language Class Initialized
INFO - 2021-12-18 01:54:55 --> Language Class Initialized
INFO - 2021-12-18 01:54:55 --> Config Class Initialized
INFO - 2021-12-18 01:54:55 --> Loader Class Initialized
INFO - 2021-12-18 01:54:55 --> Helper loaded: url_helper
INFO - 2021-12-18 01:54:55 --> Helper loaded: file_helper
INFO - 2021-12-18 01:54:55 --> Helper loaded: form_helper
INFO - 2021-12-18 01:54:55 --> Helper loaded: my_helper
INFO - 2021-12-18 01:54:55 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:54:55 --> Controller Class Initialized
DEBUG - 2021-12-18 01:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:54:55 --> Final output sent to browser
DEBUG - 2021-12-18 01:54:55 --> Total execution time: 0.0370
INFO - 2021-12-18 01:54:55 --> Config Class Initialized
INFO - 2021-12-18 01:54:55 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:54:55 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:54:55 --> Utf8 Class Initialized
INFO - 2021-12-18 01:54:55 --> URI Class Initialized
INFO - 2021-12-18 01:54:55 --> Router Class Initialized
INFO - 2021-12-18 01:54:55 --> Output Class Initialized
INFO - 2021-12-18 01:54:55 --> Security Class Initialized
DEBUG - 2021-12-18 01:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:54:55 --> Input Class Initialized
INFO - 2021-12-18 01:54:55 --> Language Class Initialized
INFO - 2021-12-18 01:54:55 --> Language Class Initialized
INFO - 2021-12-18 01:54:55 --> Config Class Initialized
INFO - 2021-12-18 01:54:55 --> Loader Class Initialized
INFO - 2021-12-18 01:54:55 --> Helper loaded: url_helper
INFO - 2021-12-18 01:54:55 --> Helper loaded: file_helper
INFO - 2021-12-18 01:54:55 --> Helper loaded: form_helper
INFO - 2021-12-18 01:54:55 --> Helper loaded: my_helper
INFO - 2021-12-18 01:54:55 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:54:55 --> Controller Class Initialized
INFO - 2021-12-18 01:54:56 --> Config Class Initialized
INFO - 2021-12-18 01:54:56 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:54:56 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:54:56 --> Utf8 Class Initialized
INFO - 2021-12-18 01:54:56 --> URI Class Initialized
INFO - 2021-12-18 01:54:56 --> Router Class Initialized
INFO - 2021-12-18 01:54:56 --> Output Class Initialized
INFO - 2021-12-18 01:54:56 --> Security Class Initialized
DEBUG - 2021-12-18 01:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:54:56 --> Input Class Initialized
INFO - 2021-12-18 01:54:56 --> Language Class Initialized
INFO - 2021-12-18 01:54:56 --> Language Class Initialized
INFO - 2021-12-18 01:54:56 --> Config Class Initialized
INFO - 2021-12-18 01:54:56 --> Loader Class Initialized
INFO - 2021-12-18 01:54:56 --> Helper loaded: url_helper
INFO - 2021-12-18 01:54:56 --> Helper loaded: file_helper
INFO - 2021-12-18 01:54:56 --> Helper loaded: form_helper
INFO - 2021-12-18 01:54:56 --> Helper loaded: my_helper
INFO - 2021-12-18 01:54:56 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:54:56 --> Controller Class Initialized
DEBUG - 2021-12-18 01:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:54:56 --> Final output sent to browser
DEBUG - 2021-12-18 01:54:56 --> Total execution time: 0.0370
INFO - 2021-12-18 01:55:11 --> Config Class Initialized
INFO - 2021-12-18 01:55:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:55:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:55:11 --> Utf8 Class Initialized
INFO - 2021-12-18 01:55:11 --> URI Class Initialized
INFO - 2021-12-18 01:55:11 --> Router Class Initialized
INFO - 2021-12-18 01:55:11 --> Output Class Initialized
INFO - 2021-12-18 01:55:11 --> Security Class Initialized
DEBUG - 2021-12-18 01:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:55:11 --> Input Class Initialized
INFO - 2021-12-18 01:55:11 --> Language Class Initialized
INFO - 2021-12-18 01:55:11 --> Language Class Initialized
INFO - 2021-12-18 01:55:11 --> Config Class Initialized
INFO - 2021-12-18 01:55:11 --> Loader Class Initialized
INFO - 2021-12-18 01:55:11 --> Helper loaded: url_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: file_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: form_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: my_helper
INFO - 2021-12-18 01:55:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:55:11 --> Controller Class Initialized
INFO - 2021-12-18 01:55:11 --> Config Class Initialized
INFO - 2021-12-18 01:55:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:55:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:55:11 --> Utf8 Class Initialized
INFO - 2021-12-18 01:55:11 --> URI Class Initialized
INFO - 2021-12-18 01:55:11 --> Router Class Initialized
INFO - 2021-12-18 01:55:11 --> Output Class Initialized
INFO - 2021-12-18 01:55:11 --> Security Class Initialized
DEBUG - 2021-12-18 01:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:55:11 --> Input Class Initialized
INFO - 2021-12-18 01:55:11 --> Language Class Initialized
INFO - 2021-12-18 01:55:11 --> Language Class Initialized
INFO - 2021-12-18 01:55:11 --> Config Class Initialized
INFO - 2021-12-18 01:55:11 --> Loader Class Initialized
INFO - 2021-12-18 01:55:11 --> Helper loaded: url_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: file_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: form_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: my_helper
INFO - 2021-12-18 01:55:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:55:11 --> Controller Class Initialized
DEBUG - 2021-12-18 01:55:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:55:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:55:11 --> Final output sent to browser
DEBUG - 2021-12-18 01:55:11 --> Total execution time: 0.0350
INFO - 2021-12-18 01:55:11 --> Config Class Initialized
INFO - 2021-12-18 01:55:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:55:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:55:11 --> Utf8 Class Initialized
INFO - 2021-12-18 01:55:11 --> URI Class Initialized
INFO - 2021-12-18 01:55:11 --> Router Class Initialized
INFO - 2021-12-18 01:55:11 --> Output Class Initialized
INFO - 2021-12-18 01:55:11 --> Security Class Initialized
DEBUG - 2021-12-18 01:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:55:11 --> Input Class Initialized
INFO - 2021-12-18 01:55:11 --> Language Class Initialized
INFO - 2021-12-18 01:55:11 --> Language Class Initialized
INFO - 2021-12-18 01:55:11 --> Config Class Initialized
INFO - 2021-12-18 01:55:11 --> Loader Class Initialized
INFO - 2021-12-18 01:55:11 --> Helper loaded: url_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: file_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: form_helper
INFO - 2021-12-18 01:55:11 --> Helper loaded: my_helper
INFO - 2021-12-18 01:55:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:55:11 --> Controller Class Initialized
INFO - 2021-12-18 01:55:14 --> Config Class Initialized
INFO - 2021-12-18 01:55:14 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:55:14 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:55:14 --> Utf8 Class Initialized
INFO - 2021-12-18 01:55:14 --> URI Class Initialized
INFO - 2021-12-18 01:55:14 --> Router Class Initialized
INFO - 2021-12-18 01:55:14 --> Output Class Initialized
INFO - 2021-12-18 01:55:14 --> Security Class Initialized
DEBUG - 2021-12-18 01:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:55:14 --> Input Class Initialized
INFO - 2021-12-18 01:55:14 --> Language Class Initialized
INFO - 2021-12-18 01:55:14 --> Language Class Initialized
INFO - 2021-12-18 01:55:14 --> Config Class Initialized
INFO - 2021-12-18 01:55:14 --> Loader Class Initialized
INFO - 2021-12-18 01:55:14 --> Helper loaded: url_helper
INFO - 2021-12-18 01:55:14 --> Helper loaded: file_helper
INFO - 2021-12-18 01:55:14 --> Helper loaded: form_helper
INFO - 2021-12-18 01:55:14 --> Helper loaded: my_helper
INFO - 2021-12-18 01:55:14 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:55:14 --> Controller Class Initialized
DEBUG - 2021-12-18 01:55:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:55:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:55:14 --> Final output sent to browser
DEBUG - 2021-12-18 01:55:14 --> Total execution time: 0.0400
INFO - 2021-12-18 01:55:31 --> Config Class Initialized
INFO - 2021-12-18 01:55:31 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:55:31 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:55:31 --> Utf8 Class Initialized
INFO - 2021-12-18 01:55:31 --> URI Class Initialized
INFO - 2021-12-18 01:55:31 --> Router Class Initialized
INFO - 2021-12-18 01:55:31 --> Output Class Initialized
INFO - 2021-12-18 01:55:31 --> Security Class Initialized
DEBUG - 2021-12-18 01:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:55:31 --> Input Class Initialized
INFO - 2021-12-18 01:55:31 --> Language Class Initialized
INFO - 2021-12-18 01:55:31 --> Language Class Initialized
INFO - 2021-12-18 01:55:31 --> Config Class Initialized
INFO - 2021-12-18 01:55:31 --> Loader Class Initialized
INFO - 2021-12-18 01:55:31 --> Helper loaded: url_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: file_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: form_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: my_helper
INFO - 2021-12-18 01:55:31 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:55:31 --> Controller Class Initialized
INFO - 2021-12-18 01:55:31 --> Config Class Initialized
INFO - 2021-12-18 01:55:31 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:55:31 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:55:31 --> Utf8 Class Initialized
INFO - 2021-12-18 01:55:31 --> URI Class Initialized
INFO - 2021-12-18 01:55:31 --> Router Class Initialized
INFO - 2021-12-18 01:55:31 --> Output Class Initialized
INFO - 2021-12-18 01:55:31 --> Security Class Initialized
DEBUG - 2021-12-18 01:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:55:31 --> Input Class Initialized
INFO - 2021-12-18 01:55:31 --> Language Class Initialized
INFO - 2021-12-18 01:55:31 --> Language Class Initialized
INFO - 2021-12-18 01:55:31 --> Config Class Initialized
INFO - 2021-12-18 01:55:31 --> Loader Class Initialized
INFO - 2021-12-18 01:55:31 --> Helper loaded: url_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: file_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: form_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: my_helper
INFO - 2021-12-18 01:55:31 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:55:31 --> Controller Class Initialized
DEBUG - 2021-12-18 01:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:55:31 --> Final output sent to browser
DEBUG - 2021-12-18 01:55:31 --> Total execution time: 0.0440
INFO - 2021-12-18 01:55:31 --> Config Class Initialized
INFO - 2021-12-18 01:55:31 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:55:31 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:55:31 --> Utf8 Class Initialized
INFO - 2021-12-18 01:55:31 --> URI Class Initialized
INFO - 2021-12-18 01:55:31 --> Router Class Initialized
INFO - 2021-12-18 01:55:31 --> Output Class Initialized
INFO - 2021-12-18 01:55:31 --> Security Class Initialized
DEBUG - 2021-12-18 01:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:55:31 --> Input Class Initialized
INFO - 2021-12-18 01:55:31 --> Language Class Initialized
INFO - 2021-12-18 01:55:31 --> Language Class Initialized
INFO - 2021-12-18 01:55:31 --> Config Class Initialized
INFO - 2021-12-18 01:55:31 --> Loader Class Initialized
INFO - 2021-12-18 01:55:31 --> Helper loaded: url_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: file_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: form_helper
INFO - 2021-12-18 01:55:31 --> Helper loaded: my_helper
INFO - 2021-12-18 01:55:31 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:55:31 --> Controller Class Initialized
INFO - 2021-12-18 01:55:32 --> Config Class Initialized
INFO - 2021-12-18 01:55:32 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:55:32 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:55:32 --> Utf8 Class Initialized
INFO - 2021-12-18 01:55:32 --> URI Class Initialized
INFO - 2021-12-18 01:55:33 --> Router Class Initialized
INFO - 2021-12-18 01:55:33 --> Output Class Initialized
INFO - 2021-12-18 01:55:33 --> Security Class Initialized
DEBUG - 2021-12-18 01:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:55:33 --> Input Class Initialized
INFO - 2021-12-18 01:55:33 --> Language Class Initialized
INFO - 2021-12-18 01:55:33 --> Language Class Initialized
INFO - 2021-12-18 01:55:33 --> Config Class Initialized
INFO - 2021-12-18 01:55:33 --> Loader Class Initialized
INFO - 2021-12-18 01:55:33 --> Helper loaded: url_helper
INFO - 2021-12-18 01:55:33 --> Helper loaded: file_helper
INFO - 2021-12-18 01:55:33 --> Helper loaded: form_helper
INFO - 2021-12-18 01:55:33 --> Helper loaded: my_helper
INFO - 2021-12-18 01:55:33 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:55:33 --> Controller Class Initialized
DEBUG - 2021-12-18 01:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:55:33 --> Final output sent to browser
DEBUG - 2021-12-18 01:55:33 --> Total execution time: 0.0410
INFO - 2021-12-18 01:56:09 --> Config Class Initialized
INFO - 2021-12-18 01:56:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:56:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:56:09 --> Utf8 Class Initialized
INFO - 2021-12-18 01:56:09 --> URI Class Initialized
INFO - 2021-12-18 01:56:09 --> Router Class Initialized
INFO - 2021-12-18 01:56:09 --> Output Class Initialized
INFO - 2021-12-18 01:56:09 --> Security Class Initialized
DEBUG - 2021-12-18 01:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:56:09 --> Input Class Initialized
INFO - 2021-12-18 01:56:09 --> Language Class Initialized
INFO - 2021-12-18 01:56:09 --> Language Class Initialized
INFO - 2021-12-18 01:56:09 --> Config Class Initialized
INFO - 2021-12-18 01:56:09 --> Loader Class Initialized
INFO - 2021-12-18 01:56:09 --> Helper loaded: url_helper
INFO - 2021-12-18 01:56:09 --> Helper loaded: file_helper
INFO - 2021-12-18 01:56:09 --> Helper loaded: form_helper
INFO - 2021-12-18 01:56:09 --> Helper loaded: my_helper
INFO - 2021-12-18 01:56:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:56:09 --> Controller Class Initialized
INFO - 2021-12-18 01:56:09 --> Config Class Initialized
INFO - 2021-12-18 01:56:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:56:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:56:09 --> Utf8 Class Initialized
INFO - 2021-12-18 01:56:09 --> URI Class Initialized
INFO - 2021-12-18 01:56:09 --> Router Class Initialized
INFO - 2021-12-18 01:56:09 --> Output Class Initialized
INFO - 2021-12-18 01:56:09 --> Security Class Initialized
DEBUG - 2021-12-18 01:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:56:09 --> Input Class Initialized
INFO - 2021-12-18 01:56:09 --> Language Class Initialized
INFO - 2021-12-18 01:56:09 --> Language Class Initialized
INFO - 2021-12-18 01:56:09 --> Config Class Initialized
INFO - 2021-12-18 01:56:09 --> Loader Class Initialized
INFO - 2021-12-18 01:56:09 --> Helper loaded: url_helper
INFO - 2021-12-18 01:56:09 --> Helper loaded: file_helper
INFO - 2021-12-18 01:56:09 --> Helper loaded: form_helper
INFO - 2021-12-18 01:56:09 --> Helper loaded: my_helper
INFO - 2021-12-18 01:56:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:56:09 --> Controller Class Initialized
DEBUG - 2021-12-18 01:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:56:09 --> Final output sent to browser
DEBUG - 2021-12-18 01:56:09 --> Total execution time: 0.0350
INFO - 2021-12-18 01:56:10 --> Config Class Initialized
INFO - 2021-12-18 01:56:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:56:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:56:10 --> Utf8 Class Initialized
INFO - 2021-12-18 01:56:10 --> URI Class Initialized
INFO - 2021-12-18 01:56:10 --> Router Class Initialized
INFO - 2021-12-18 01:56:10 --> Output Class Initialized
INFO - 2021-12-18 01:56:10 --> Security Class Initialized
DEBUG - 2021-12-18 01:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:56:10 --> Input Class Initialized
INFO - 2021-12-18 01:56:10 --> Language Class Initialized
INFO - 2021-12-18 01:56:10 --> Language Class Initialized
INFO - 2021-12-18 01:56:10 --> Config Class Initialized
INFO - 2021-12-18 01:56:10 --> Loader Class Initialized
INFO - 2021-12-18 01:56:10 --> Helper loaded: url_helper
INFO - 2021-12-18 01:56:10 --> Helper loaded: file_helper
INFO - 2021-12-18 01:56:10 --> Helper loaded: form_helper
INFO - 2021-12-18 01:56:10 --> Helper loaded: my_helper
INFO - 2021-12-18 01:56:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:56:10 --> Controller Class Initialized
INFO - 2021-12-18 01:56:11 --> Config Class Initialized
INFO - 2021-12-18 01:56:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:56:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:56:11 --> Utf8 Class Initialized
INFO - 2021-12-18 01:56:11 --> URI Class Initialized
INFO - 2021-12-18 01:56:11 --> Router Class Initialized
INFO - 2021-12-18 01:56:11 --> Output Class Initialized
INFO - 2021-12-18 01:56:11 --> Security Class Initialized
DEBUG - 2021-12-18 01:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:56:11 --> Input Class Initialized
INFO - 2021-12-18 01:56:11 --> Language Class Initialized
INFO - 2021-12-18 01:56:11 --> Language Class Initialized
INFO - 2021-12-18 01:56:11 --> Config Class Initialized
INFO - 2021-12-18 01:56:11 --> Loader Class Initialized
INFO - 2021-12-18 01:56:11 --> Helper loaded: url_helper
INFO - 2021-12-18 01:56:11 --> Helper loaded: file_helper
INFO - 2021-12-18 01:56:11 --> Helper loaded: form_helper
INFO - 2021-12-18 01:56:11 --> Helper loaded: my_helper
INFO - 2021-12-18 01:56:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:56:11 --> Controller Class Initialized
DEBUG - 2021-12-18 01:56:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:56:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:56:11 --> Final output sent to browser
DEBUG - 2021-12-18 01:56:11 --> Total execution time: 0.0560
INFO - 2021-12-18 01:56:53 --> Config Class Initialized
INFO - 2021-12-18 01:56:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:56:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:56:53 --> Utf8 Class Initialized
INFO - 2021-12-18 01:56:53 --> URI Class Initialized
INFO - 2021-12-18 01:56:53 --> Router Class Initialized
INFO - 2021-12-18 01:56:53 --> Output Class Initialized
INFO - 2021-12-18 01:56:53 --> Security Class Initialized
DEBUG - 2021-12-18 01:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:56:53 --> Input Class Initialized
INFO - 2021-12-18 01:56:53 --> Language Class Initialized
INFO - 2021-12-18 01:56:53 --> Language Class Initialized
INFO - 2021-12-18 01:56:53 --> Config Class Initialized
INFO - 2021-12-18 01:56:53 --> Loader Class Initialized
INFO - 2021-12-18 01:56:53 --> Helper loaded: url_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: file_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: form_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: my_helper
INFO - 2021-12-18 01:56:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:56:53 --> Controller Class Initialized
INFO - 2021-12-18 01:56:53 --> Config Class Initialized
INFO - 2021-12-18 01:56:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:56:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:56:53 --> Utf8 Class Initialized
INFO - 2021-12-18 01:56:53 --> URI Class Initialized
INFO - 2021-12-18 01:56:53 --> Router Class Initialized
INFO - 2021-12-18 01:56:53 --> Output Class Initialized
INFO - 2021-12-18 01:56:53 --> Security Class Initialized
DEBUG - 2021-12-18 01:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:56:53 --> Input Class Initialized
INFO - 2021-12-18 01:56:53 --> Language Class Initialized
INFO - 2021-12-18 01:56:53 --> Language Class Initialized
INFO - 2021-12-18 01:56:53 --> Config Class Initialized
INFO - 2021-12-18 01:56:53 --> Loader Class Initialized
INFO - 2021-12-18 01:56:53 --> Helper loaded: url_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: file_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: form_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: my_helper
INFO - 2021-12-18 01:56:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:56:53 --> Controller Class Initialized
DEBUG - 2021-12-18 01:56:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:56:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:56:53 --> Final output sent to browser
DEBUG - 2021-12-18 01:56:53 --> Total execution time: 0.0370
INFO - 2021-12-18 01:56:53 --> Config Class Initialized
INFO - 2021-12-18 01:56:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:56:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:56:53 --> Utf8 Class Initialized
INFO - 2021-12-18 01:56:53 --> URI Class Initialized
INFO - 2021-12-18 01:56:53 --> Router Class Initialized
INFO - 2021-12-18 01:56:53 --> Output Class Initialized
INFO - 2021-12-18 01:56:53 --> Security Class Initialized
DEBUG - 2021-12-18 01:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:56:53 --> Input Class Initialized
INFO - 2021-12-18 01:56:53 --> Language Class Initialized
INFO - 2021-12-18 01:56:53 --> Language Class Initialized
INFO - 2021-12-18 01:56:53 --> Config Class Initialized
INFO - 2021-12-18 01:56:53 --> Loader Class Initialized
INFO - 2021-12-18 01:56:53 --> Helper loaded: url_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: file_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: form_helper
INFO - 2021-12-18 01:56:53 --> Helper loaded: my_helper
INFO - 2021-12-18 01:56:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:56:53 --> Controller Class Initialized
INFO - 2021-12-18 01:56:54 --> Config Class Initialized
INFO - 2021-12-18 01:56:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:56:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:56:54 --> Utf8 Class Initialized
INFO - 2021-12-18 01:56:54 --> URI Class Initialized
INFO - 2021-12-18 01:56:54 --> Router Class Initialized
INFO - 2021-12-18 01:56:54 --> Output Class Initialized
INFO - 2021-12-18 01:56:54 --> Security Class Initialized
DEBUG - 2021-12-18 01:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:56:54 --> Input Class Initialized
INFO - 2021-12-18 01:56:54 --> Language Class Initialized
INFO - 2021-12-18 01:56:54 --> Language Class Initialized
INFO - 2021-12-18 01:56:54 --> Config Class Initialized
INFO - 2021-12-18 01:56:54 --> Loader Class Initialized
INFO - 2021-12-18 01:56:54 --> Helper loaded: url_helper
INFO - 2021-12-18 01:56:54 --> Helper loaded: file_helper
INFO - 2021-12-18 01:56:54 --> Helper loaded: form_helper
INFO - 2021-12-18 01:56:54 --> Helper loaded: my_helper
INFO - 2021-12-18 01:56:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:56:54 --> Controller Class Initialized
DEBUG - 2021-12-18 01:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:56:54 --> Final output sent to browser
DEBUG - 2021-12-18 01:56:54 --> Total execution time: 0.0560
INFO - 2021-12-18 01:57:06 --> Config Class Initialized
INFO - 2021-12-18 01:57:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:57:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:57:06 --> Utf8 Class Initialized
INFO - 2021-12-18 01:57:06 --> URI Class Initialized
INFO - 2021-12-18 01:57:06 --> Router Class Initialized
INFO - 2021-12-18 01:57:06 --> Output Class Initialized
INFO - 2021-12-18 01:57:06 --> Security Class Initialized
DEBUG - 2021-12-18 01:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:57:06 --> Input Class Initialized
INFO - 2021-12-18 01:57:06 --> Language Class Initialized
INFO - 2021-12-18 01:57:06 --> Language Class Initialized
INFO - 2021-12-18 01:57:06 --> Config Class Initialized
INFO - 2021-12-18 01:57:06 --> Loader Class Initialized
INFO - 2021-12-18 01:57:06 --> Helper loaded: url_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: file_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: form_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: my_helper
INFO - 2021-12-18 01:57:06 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:57:06 --> Controller Class Initialized
INFO - 2021-12-18 01:57:06 --> Config Class Initialized
INFO - 2021-12-18 01:57:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:57:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:57:06 --> Utf8 Class Initialized
INFO - 2021-12-18 01:57:06 --> URI Class Initialized
INFO - 2021-12-18 01:57:06 --> Router Class Initialized
INFO - 2021-12-18 01:57:06 --> Output Class Initialized
INFO - 2021-12-18 01:57:06 --> Security Class Initialized
DEBUG - 2021-12-18 01:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:57:06 --> Input Class Initialized
INFO - 2021-12-18 01:57:06 --> Language Class Initialized
INFO - 2021-12-18 01:57:06 --> Language Class Initialized
INFO - 2021-12-18 01:57:06 --> Config Class Initialized
INFO - 2021-12-18 01:57:06 --> Loader Class Initialized
INFO - 2021-12-18 01:57:06 --> Helper loaded: url_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: file_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: form_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: my_helper
INFO - 2021-12-18 01:57:06 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:57:06 --> Controller Class Initialized
DEBUG - 2021-12-18 01:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:57:06 --> Final output sent to browser
DEBUG - 2021-12-18 01:57:06 --> Total execution time: 0.0370
INFO - 2021-12-18 01:57:06 --> Config Class Initialized
INFO - 2021-12-18 01:57:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:57:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:57:06 --> Utf8 Class Initialized
INFO - 2021-12-18 01:57:06 --> URI Class Initialized
INFO - 2021-12-18 01:57:06 --> Router Class Initialized
INFO - 2021-12-18 01:57:06 --> Output Class Initialized
INFO - 2021-12-18 01:57:06 --> Security Class Initialized
DEBUG - 2021-12-18 01:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:57:06 --> Input Class Initialized
INFO - 2021-12-18 01:57:06 --> Language Class Initialized
INFO - 2021-12-18 01:57:06 --> Language Class Initialized
INFO - 2021-12-18 01:57:06 --> Config Class Initialized
INFO - 2021-12-18 01:57:06 --> Loader Class Initialized
INFO - 2021-12-18 01:57:06 --> Helper loaded: url_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: file_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: form_helper
INFO - 2021-12-18 01:57:06 --> Helper loaded: my_helper
INFO - 2021-12-18 01:57:06 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:57:06 --> Controller Class Initialized
INFO - 2021-12-18 01:57:17 --> Config Class Initialized
INFO - 2021-12-18 01:57:17 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:57:17 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:57:17 --> Utf8 Class Initialized
INFO - 2021-12-18 01:57:17 --> URI Class Initialized
INFO - 2021-12-18 01:57:17 --> Router Class Initialized
INFO - 2021-12-18 01:57:17 --> Output Class Initialized
INFO - 2021-12-18 01:57:17 --> Security Class Initialized
DEBUG - 2021-12-18 01:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:57:17 --> Input Class Initialized
INFO - 2021-12-18 01:57:17 --> Language Class Initialized
INFO - 2021-12-18 01:57:17 --> Language Class Initialized
INFO - 2021-12-18 01:57:17 --> Config Class Initialized
INFO - 2021-12-18 01:57:17 --> Loader Class Initialized
INFO - 2021-12-18 01:57:17 --> Helper loaded: url_helper
INFO - 2021-12-18 01:57:17 --> Helper loaded: file_helper
INFO - 2021-12-18 01:57:17 --> Helper loaded: form_helper
INFO - 2021-12-18 01:57:17 --> Helper loaded: my_helper
INFO - 2021-12-18 01:57:17 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:57:17 --> Controller Class Initialized
DEBUG - 2021-12-18 01:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:57:17 --> Final output sent to browser
DEBUG - 2021-12-18 01:57:17 --> Total execution time: 0.0460
INFO - 2021-12-18 01:57:59 --> Config Class Initialized
INFO - 2021-12-18 01:57:59 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:57:59 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:57:59 --> Utf8 Class Initialized
INFO - 2021-12-18 01:57:59 --> URI Class Initialized
INFO - 2021-12-18 01:57:59 --> Router Class Initialized
INFO - 2021-12-18 01:57:59 --> Output Class Initialized
INFO - 2021-12-18 01:57:59 --> Security Class Initialized
DEBUG - 2021-12-18 01:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:57:59 --> Input Class Initialized
INFO - 2021-12-18 01:57:59 --> Language Class Initialized
INFO - 2021-12-18 01:57:59 --> Language Class Initialized
INFO - 2021-12-18 01:57:59 --> Config Class Initialized
INFO - 2021-12-18 01:57:59 --> Loader Class Initialized
INFO - 2021-12-18 01:57:59 --> Helper loaded: url_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: file_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: form_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: my_helper
INFO - 2021-12-18 01:57:59 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:57:59 --> Controller Class Initialized
INFO - 2021-12-18 01:57:59 --> Config Class Initialized
INFO - 2021-12-18 01:57:59 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:57:59 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:57:59 --> Utf8 Class Initialized
INFO - 2021-12-18 01:57:59 --> URI Class Initialized
INFO - 2021-12-18 01:57:59 --> Router Class Initialized
INFO - 2021-12-18 01:57:59 --> Output Class Initialized
INFO - 2021-12-18 01:57:59 --> Security Class Initialized
DEBUG - 2021-12-18 01:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:57:59 --> Input Class Initialized
INFO - 2021-12-18 01:57:59 --> Language Class Initialized
INFO - 2021-12-18 01:57:59 --> Language Class Initialized
INFO - 2021-12-18 01:57:59 --> Config Class Initialized
INFO - 2021-12-18 01:57:59 --> Loader Class Initialized
INFO - 2021-12-18 01:57:59 --> Helper loaded: url_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: file_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: form_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: my_helper
INFO - 2021-12-18 01:57:59 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:57:59 --> Controller Class Initialized
DEBUG - 2021-12-18 01:57:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:57:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:57:59 --> Final output sent to browser
DEBUG - 2021-12-18 01:57:59 --> Total execution time: 0.0360
INFO - 2021-12-18 01:57:59 --> Config Class Initialized
INFO - 2021-12-18 01:57:59 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:57:59 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:57:59 --> Utf8 Class Initialized
INFO - 2021-12-18 01:57:59 --> URI Class Initialized
INFO - 2021-12-18 01:57:59 --> Router Class Initialized
INFO - 2021-12-18 01:57:59 --> Output Class Initialized
INFO - 2021-12-18 01:57:59 --> Security Class Initialized
DEBUG - 2021-12-18 01:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:57:59 --> Input Class Initialized
INFO - 2021-12-18 01:57:59 --> Language Class Initialized
INFO - 2021-12-18 01:57:59 --> Language Class Initialized
INFO - 2021-12-18 01:57:59 --> Config Class Initialized
INFO - 2021-12-18 01:57:59 --> Loader Class Initialized
INFO - 2021-12-18 01:57:59 --> Helper loaded: url_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: file_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: form_helper
INFO - 2021-12-18 01:57:59 --> Helper loaded: my_helper
INFO - 2021-12-18 01:57:59 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:57:59 --> Controller Class Initialized
INFO - 2021-12-18 01:58:00 --> Config Class Initialized
INFO - 2021-12-18 01:58:00 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:58:00 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:58:00 --> Utf8 Class Initialized
INFO - 2021-12-18 01:58:00 --> URI Class Initialized
INFO - 2021-12-18 01:58:00 --> Router Class Initialized
INFO - 2021-12-18 01:58:00 --> Output Class Initialized
INFO - 2021-12-18 01:58:00 --> Security Class Initialized
DEBUG - 2021-12-18 01:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:58:00 --> Input Class Initialized
INFO - 2021-12-18 01:58:00 --> Language Class Initialized
INFO - 2021-12-18 01:58:00 --> Language Class Initialized
INFO - 2021-12-18 01:58:00 --> Config Class Initialized
INFO - 2021-12-18 01:58:00 --> Loader Class Initialized
INFO - 2021-12-18 01:58:00 --> Helper loaded: url_helper
INFO - 2021-12-18 01:58:00 --> Helper loaded: file_helper
INFO - 2021-12-18 01:58:00 --> Helper loaded: form_helper
INFO - 2021-12-18 01:58:00 --> Helper loaded: my_helper
INFO - 2021-12-18 01:58:00 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:58:00 --> Controller Class Initialized
DEBUG - 2021-12-18 01:58:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:58:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:58:00 --> Final output sent to browser
DEBUG - 2021-12-18 01:58:00 --> Total execution time: 0.0460
INFO - 2021-12-18 01:58:13 --> Config Class Initialized
INFO - 2021-12-18 01:58:13 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:58:13 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:58:13 --> Utf8 Class Initialized
INFO - 2021-12-18 01:58:13 --> URI Class Initialized
INFO - 2021-12-18 01:58:13 --> Router Class Initialized
INFO - 2021-12-18 01:58:13 --> Output Class Initialized
INFO - 2021-12-18 01:58:13 --> Security Class Initialized
DEBUG - 2021-12-18 01:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:58:13 --> Input Class Initialized
INFO - 2021-12-18 01:58:13 --> Language Class Initialized
INFO - 2021-12-18 01:58:13 --> Language Class Initialized
INFO - 2021-12-18 01:58:13 --> Config Class Initialized
INFO - 2021-12-18 01:58:13 --> Loader Class Initialized
INFO - 2021-12-18 01:58:13 --> Helper loaded: url_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: file_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: form_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: my_helper
INFO - 2021-12-18 01:58:13 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:58:13 --> Controller Class Initialized
INFO - 2021-12-18 01:58:13 --> Config Class Initialized
INFO - 2021-12-18 01:58:13 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:58:13 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:58:13 --> Utf8 Class Initialized
INFO - 2021-12-18 01:58:13 --> URI Class Initialized
INFO - 2021-12-18 01:58:13 --> Router Class Initialized
INFO - 2021-12-18 01:58:13 --> Output Class Initialized
INFO - 2021-12-18 01:58:13 --> Security Class Initialized
DEBUG - 2021-12-18 01:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:58:13 --> Input Class Initialized
INFO - 2021-12-18 01:58:13 --> Language Class Initialized
INFO - 2021-12-18 01:58:13 --> Language Class Initialized
INFO - 2021-12-18 01:58:13 --> Config Class Initialized
INFO - 2021-12-18 01:58:13 --> Loader Class Initialized
INFO - 2021-12-18 01:58:13 --> Helper loaded: url_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: file_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: form_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: my_helper
INFO - 2021-12-18 01:58:13 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:58:13 --> Controller Class Initialized
DEBUG - 2021-12-18 01:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:58:13 --> Final output sent to browser
DEBUG - 2021-12-18 01:58:13 --> Total execution time: 0.0350
INFO - 2021-12-18 01:58:13 --> Config Class Initialized
INFO - 2021-12-18 01:58:13 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:58:13 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:58:13 --> Utf8 Class Initialized
INFO - 2021-12-18 01:58:13 --> URI Class Initialized
INFO - 2021-12-18 01:58:13 --> Router Class Initialized
INFO - 2021-12-18 01:58:13 --> Output Class Initialized
INFO - 2021-12-18 01:58:13 --> Security Class Initialized
DEBUG - 2021-12-18 01:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:58:13 --> Input Class Initialized
INFO - 2021-12-18 01:58:13 --> Language Class Initialized
INFO - 2021-12-18 01:58:13 --> Language Class Initialized
INFO - 2021-12-18 01:58:13 --> Config Class Initialized
INFO - 2021-12-18 01:58:13 --> Loader Class Initialized
INFO - 2021-12-18 01:58:13 --> Helper loaded: url_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: file_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: form_helper
INFO - 2021-12-18 01:58:13 --> Helper loaded: my_helper
INFO - 2021-12-18 01:58:13 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:58:13 --> Controller Class Initialized
INFO - 2021-12-18 01:58:19 --> Config Class Initialized
INFO - 2021-12-18 01:58:19 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:58:19 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:58:19 --> Utf8 Class Initialized
INFO - 2021-12-18 01:58:19 --> URI Class Initialized
INFO - 2021-12-18 01:58:19 --> Router Class Initialized
INFO - 2021-12-18 01:58:19 --> Output Class Initialized
INFO - 2021-12-18 01:58:19 --> Security Class Initialized
DEBUG - 2021-12-18 01:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:58:19 --> Input Class Initialized
INFO - 2021-12-18 01:58:19 --> Language Class Initialized
INFO - 2021-12-18 01:58:19 --> Language Class Initialized
INFO - 2021-12-18 01:58:19 --> Config Class Initialized
INFO - 2021-12-18 01:58:19 --> Loader Class Initialized
INFO - 2021-12-18 01:58:19 --> Helper loaded: url_helper
INFO - 2021-12-18 01:58:19 --> Helper loaded: file_helper
INFO - 2021-12-18 01:58:19 --> Helper loaded: form_helper
INFO - 2021-12-18 01:58:19 --> Helper loaded: my_helper
INFO - 2021-12-18 01:58:19 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:58:19 --> Controller Class Initialized
DEBUG - 2021-12-18 01:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:58:19 --> Final output sent to browser
DEBUG - 2021-12-18 01:58:19 --> Total execution time: 0.0490
INFO - 2021-12-18 01:59:14 --> Config Class Initialized
INFO - 2021-12-18 01:59:14 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:14 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:14 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:14 --> URI Class Initialized
INFO - 2021-12-18 01:59:14 --> Router Class Initialized
INFO - 2021-12-18 01:59:14 --> Output Class Initialized
INFO - 2021-12-18 01:59:14 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:14 --> Input Class Initialized
INFO - 2021-12-18 01:59:14 --> Language Class Initialized
INFO - 2021-12-18 01:59:14 --> Language Class Initialized
INFO - 2021-12-18 01:59:14 --> Config Class Initialized
INFO - 2021-12-18 01:59:14 --> Loader Class Initialized
INFO - 2021-12-18 01:59:14 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:14 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:14 --> Controller Class Initialized
INFO - 2021-12-18 01:59:14 --> Config Class Initialized
INFO - 2021-12-18 01:59:14 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:14 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:14 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:14 --> URI Class Initialized
INFO - 2021-12-18 01:59:14 --> Router Class Initialized
INFO - 2021-12-18 01:59:14 --> Output Class Initialized
INFO - 2021-12-18 01:59:14 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:14 --> Input Class Initialized
INFO - 2021-12-18 01:59:14 --> Language Class Initialized
INFO - 2021-12-18 01:59:14 --> Language Class Initialized
INFO - 2021-12-18 01:59:14 --> Config Class Initialized
INFO - 2021-12-18 01:59:14 --> Loader Class Initialized
INFO - 2021-12-18 01:59:14 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:14 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:14 --> Controller Class Initialized
DEBUG - 2021-12-18 01:59:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:59:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:59:14 --> Final output sent to browser
DEBUG - 2021-12-18 01:59:14 --> Total execution time: 0.0390
INFO - 2021-12-18 01:59:14 --> Config Class Initialized
INFO - 2021-12-18 01:59:14 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:14 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:14 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:14 --> URI Class Initialized
INFO - 2021-12-18 01:59:14 --> Router Class Initialized
INFO - 2021-12-18 01:59:14 --> Output Class Initialized
INFO - 2021-12-18 01:59:14 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:14 --> Input Class Initialized
INFO - 2021-12-18 01:59:14 --> Language Class Initialized
INFO - 2021-12-18 01:59:14 --> Language Class Initialized
INFO - 2021-12-18 01:59:14 --> Config Class Initialized
INFO - 2021-12-18 01:59:14 --> Loader Class Initialized
INFO - 2021-12-18 01:59:14 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:14 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:14 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:14 --> Controller Class Initialized
INFO - 2021-12-18 01:59:15 --> Config Class Initialized
INFO - 2021-12-18 01:59:15 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:15 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:15 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:15 --> URI Class Initialized
INFO - 2021-12-18 01:59:15 --> Router Class Initialized
INFO - 2021-12-18 01:59:15 --> Output Class Initialized
INFO - 2021-12-18 01:59:15 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:15 --> Input Class Initialized
INFO - 2021-12-18 01:59:15 --> Language Class Initialized
INFO - 2021-12-18 01:59:15 --> Language Class Initialized
INFO - 2021-12-18 01:59:15 --> Config Class Initialized
INFO - 2021-12-18 01:59:15 --> Loader Class Initialized
INFO - 2021-12-18 01:59:15 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:15 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:15 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:15 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:15 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:15 --> Controller Class Initialized
DEBUG - 2021-12-18 01:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-18 01:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:59:15 --> Final output sent to browser
DEBUG - 2021-12-18 01:59:15 --> Total execution time: 0.0420
INFO - 2021-12-18 01:59:15 --> Config Class Initialized
INFO - 2021-12-18 01:59:15 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:15 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:15 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:15 --> URI Class Initialized
INFO - 2021-12-18 01:59:15 --> Router Class Initialized
INFO - 2021-12-18 01:59:15 --> Output Class Initialized
INFO - 2021-12-18 01:59:15 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:15 --> Input Class Initialized
INFO - 2021-12-18 01:59:15 --> Language Class Initialized
INFO - 2021-12-18 01:59:15 --> Language Class Initialized
INFO - 2021-12-18 01:59:15 --> Config Class Initialized
INFO - 2021-12-18 01:59:15 --> Loader Class Initialized
INFO - 2021-12-18 01:59:15 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:15 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:15 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:15 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:15 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:15 --> Controller Class Initialized
INFO - 2021-12-18 01:59:16 --> Config Class Initialized
INFO - 2021-12-18 01:59:16 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:16 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:16 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:16 --> URI Class Initialized
INFO - 2021-12-18 01:59:16 --> Router Class Initialized
INFO - 2021-12-18 01:59:16 --> Output Class Initialized
INFO - 2021-12-18 01:59:16 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:16 --> Input Class Initialized
INFO - 2021-12-18 01:59:16 --> Language Class Initialized
INFO - 2021-12-18 01:59:16 --> Language Class Initialized
INFO - 2021-12-18 01:59:16 --> Config Class Initialized
INFO - 2021-12-18 01:59:16 --> Loader Class Initialized
INFO - 2021-12-18 01:59:16 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:16 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:16 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:16 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:16 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:16 --> Controller Class Initialized
INFO - 2021-12-18 01:59:17 --> Config Class Initialized
INFO - 2021-12-18 01:59:17 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:17 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:17 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:17 --> URI Class Initialized
INFO - 2021-12-18 01:59:17 --> Router Class Initialized
INFO - 2021-12-18 01:59:17 --> Output Class Initialized
INFO - 2021-12-18 01:59:17 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:17 --> Input Class Initialized
INFO - 2021-12-18 01:59:17 --> Language Class Initialized
INFO - 2021-12-18 01:59:17 --> Language Class Initialized
INFO - 2021-12-18 01:59:17 --> Config Class Initialized
INFO - 2021-12-18 01:59:17 --> Loader Class Initialized
INFO - 2021-12-18 01:59:17 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:17 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:17 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:17 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:17 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:17 --> Controller Class Initialized
INFO - 2021-12-18 01:59:21 --> Config Class Initialized
INFO - 2021-12-18 01:59:21 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:21 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:21 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:21 --> URI Class Initialized
INFO - 2021-12-18 01:59:21 --> Router Class Initialized
INFO - 2021-12-18 01:59:21 --> Output Class Initialized
INFO - 2021-12-18 01:59:21 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:21 --> Input Class Initialized
INFO - 2021-12-18 01:59:21 --> Language Class Initialized
INFO - 2021-12-18 01:59:21 --> Language Class Initialized
INFO - 2021-12-18 01:59:21 --> Config Class Initialized
INFO - 2021-12-18 01:59:21 --> Loader Class Initialized
INFO - 2021-12-18 01:59:21 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:21 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:21 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:21 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:21 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:21 --> Controller Class Initialized
DEBUG - 2021-12-18 01:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:59:21 --> Final output sent to browser
DEBUG - 2021-12-18 01:59:21 --> Total execution time: 0.0470
INFO - 2021-12-18 01:59:21 --> Config Class Initialized
INFO - 2021-12-18 01:59:21 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:21 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:21 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:21 --> URI Class Initialized
INFO - 2021-12-18 01:59:21 --> Router Class Initialized
INFO - 2021-12-18 01:59:21 --> Output Class Initialized
INFO - 2021-12-18 01:59:21 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:21 --> Input Class Initialized
INFO - 2021-12-18 01:59:21 --> Language Class Initialized
INFO - 2021-12-18 01:59:21 --> Language Class Initialized
INFO - 2021-12-18 01:59:21 --> Config Class Initialized
INFO - 2021-12-18 01:59:21 --> Loader Class Initialized
INFO - 2021-12-18 01:59:21 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:21 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:21 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:21 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:21 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:21 --> Controller Class Initialized
INFO - 2021-12-18 01:59:31 --> Config Class Initialized
INFO - 2021-12-18 01:59:31 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:31 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:31 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:31 --> URI Class Initialized
INFO - 2021-12-18 01:59:31 --> Router Class Initialized
INFO - 2021-12-18 01:59:31 --> Output Class Initialized
INFO - 2021-12-18 01:59:31 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:31 --> Input Class Initialized
INFO - 2021-12-18 01:59:31 --> Language Class Initialized
INFO - 2021-12-18 01:59:31 --> Language Class Initialized
INFO - 2021-12-18 01:59:31 --> Config Class Initialized
INFO - 2021-12-18 01:59:31 --> Loader Class Initialized
INFO - 2021-12-18 01:59:31 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:31 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:31 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:31 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:31 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:31 --> Controller Class Initialized
DEBUG - 2021-12-18 01:59:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:59:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:59:31 --> Final output sent to browser
DEBUG - 2021-12-18 01:59:31 --> Total execution time: 0.0650
INFO - 2021-12-18 01:59:43 --> Config Class Initialized
INFO - 2021-12-18 01:59:43 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:43 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:43 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:43 --> URI Class Initialized
INFO - 2021-12-18 01:59:43 --> Router Class Initialized
INFO - 2021-12-18 01:59:43 --> Output Class Initialized
INFO - 2021-12-18 01:59:43 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:43 --> Input Class Initialized
INFO - 2021-12-18 01:59:43 --> Language Class Initialized
INFO - 2021-12-18 01:59:43 --> Language Class Initialized
INFO - 2021-12-18 01:59:43 --> Config Class Initialized
INFO - 2021-12-18 01:59:43 --> Loader Class Initialized
INFO - 2021-12-18 01:59:43 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:43 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:43 --> Controller Class Initialized
INFO - 2021-12-18 01:59:43 --> Config Class Initialized
INFO - 2021-12-18 01:59:43 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:43 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:43 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:43 --> URI Class Initialized
INFO - 2021-12-18 01:59:43 --> Router Class Initialized
INFO - 2021-12-18 01:59:43 --> Output Class Initialized
INFO - 2021-12-18 01:59:43 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:43 --> Input Class Initialized
INFO - 2021-12-18 01:59:43 --> Language Class Initialized
INFO - 2021-12-18 01:59:43 --> Language Class Initialized
INFO - 2021-12-18 01:59:43 --> Config Class Initialized
INFO - 2021-12-18 01:59:43 --> Loader Class Initialized
INFO - 2021-12-18 01:59:43 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:43 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:43 --> Controller Class Initialized
DEBUG - 2021-12-18 01:59:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 01:59:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:59:43 --> Final output sent to browser
DEBUG - 2021-12-18 01:59:43 --> Total execution time: 0.0260
INFO - 2021-12-18 01:59:43 --> Config Class Initialized
INFO - 2021-12-18 01:59:43 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:43 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:43 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:43 --> URI Class Initialized
INFO - 2021-12-18 01:59:43 --> Router Class Initialized
INFO - 2021-12-18 01:59:43 --> Output Class Initialized
INFO - 2021-12-18 01:59:43 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:43 --> Input Class Initialized
INFO - 2021-12-18 01:59:43 --> Language Class Initialized
INFO - 2021-12-18 01:59:43 --> Language Class Initialized
INFO - 2021-12-18 01:59:43 --> Config Class Initialized
INFO - 2021-12-18 01:59:43 --> Loader Class Initialized
INFO - 2021-12-18 01:59:43 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:43 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:43 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:43 --> Controller Class Initialized
INFO - 2021-12-18 01:59:51 --> Config Class Initialized
INFO - 2021-12-18 01:59:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 01:59:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 01:59:51 --> Utf8 Class Initialized
INFO - 2021-12-18 01:59:51 --> URI Class Initialized
INFO - 2021-12-18 01:59:51 --> Router Class Initialized
INFO - 2021-12-18 01:59:51 --> Output Class Initialized
INFO - 2021-12-18 01:59:51 --> Security Class Initialized
DEBUG - 2021-12-18 01:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 01:59:51 --> Input Class Initialized
INFO - 2021-12-18 01:59:51 --> Language Class Initialized
INFO - 2021-12-18 01:59:51 --> Language Class Initialized
INFO - 2021-12-18 01:59:51 --> Config Class Initialized
INFO - 2021-12-18 01:59:51 --> Loader Class Initialized
INFO - 2021-12-18 01:59:51 --> Helper loaded: url_helper
INFO - 2021-12-18 01:59:51 --> Helper loaded: file_helper
INFO - 2021-12-18 01:59:51 --> Helper loaded: form_helper
INFO - 2021-12-18 01:59:51 --> Helper loaded: my_helper
INFO - 2021-12-18 01:59:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 01:59:51 --> Controller Class Initialized
DEBUG - 2021-12-18 01:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 01:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 01:59:51 --> Final output sent to browser
DEBUG - 2021-12-18 01:59:51 --> Total execution time: 0.0450
INFO - 2021-12-18 02:00:30 --> Config Class Initialized
INFO - 2021-12-18 02:00:30 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:00:30 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:00:30 --> Utf8 Class Initialized
INFO - 2021-12-18 02:00:30 --> URI Class Initialized
INFO - 2021-12-18 02:00:30 --> Router Class Initialized
INFO - 2021-12-18 02:00:30 --> Output Class Initialized
INFO - 2021-12-18 02:00:30 --> Security Class Initialized
DEBUG - 2021-12-18 02:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:00:30 --> Input Class Initialized
INFO - 2021-12-18 02:00:30 --> Language Class Initialized
INFO - 2021-12-18 02:00:30 --> Language Class Initialized
INFO - 2021-12-18 02:00:30 --> Config Class Initialized
INFO - 2021-12-18 02:00:30 --> Loader Class Initialized
INFO - 2021-12-18 02:00:30 --> Helper loaded: url_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: file_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: form_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: my_helper
INFO - 2021-12-18 02:00:30 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:00:30 --> Controller Class Initialized
INFO - 2021-12-18 02:00:30 --> Config Class Initialized
INFO - 2021-12-18 02:00:30 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:00:30 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:00:30 --> Utf8 Class Initialized
INFO - 2021-12-18 02:00:30 --> URI Class Initialized
INFO - 2021-12-18 02:00:30 --> Router Class Initialized
INFO - 2021-12-18 02:00:30 --> Output Class Initialized
INFO - 2021-12-18 02:00:30 --> Security Class Initialized
DEBUG - 2021-12-18 02:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:00:30 --> Input Class Initialized
INFO - 2021-12-18 02:00:30 --> Language Class Initialized
INFO - 2021-12-18 02:00:30 --> Language Class Initialized
INFO - 2021-12-18 02:00:30 --> Config Class Initialized
INFO - 2021-12-18 02:00:30 --> Loader Class Initialized
INFO - 2021-12-18 02:00:30 --> Helper loaded: url_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: file_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: form_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: my_helper
INFO - 2021-12-18 02:00:30 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:00:30 --> Controller Class Initialized
DEBUG - 2021-12-18 02:00:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:00:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:00:30 --> Final output sent to browser
DEBUG - 2021-12-18 02:00:30 --> Total execution time: 0.0350
INFO - 2021-12-18 02:00:30 --> Config Class Initialized
INFO - 2021-12-18 02:00:30 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:00:30 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:00:30 --> Utf8 Class Initialized
INFO - 2021-12-18 02:00:30 --> URI Class Initialized
INFO - 2021-12-18 02:00:30 --> Router Class Initialized
INFO - 2021-12-18 02:00:30 --> Output Class Initialized
INFO - 2021-12-18 02:00:30 --> Security Class Initialized
DEBUG - 2021-12-18 02:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:00:30 --> Input Class Initialized
INFO - 2021-12-18 02:00:30 --> Language Class Initialized
INFO - 2021-12-18 02:00:30 --> Language Class Initialized
INFO - 2021-12-18 02:00:30 --> Config Class Initialized
INFO - 2021-12-18 02:00:30 --> Loader Class Initialized
INFO - 2021-12-18 02:00:30 --> Helper loaded: url_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: file_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: form_helper
INFO - 2021-12-18 02:00:30 --> Helper loaded: my_helper
INFO - 2021-12-18 02:00:30 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:00:30 --> Controller Class Initialized
INFO - 2021-12-18 02:00:32 --> Config Class Initialized
INFO - 2021-12-18 02:00:32 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:00:32 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:00:32 --> Utf8 Class Initialized
INFO - 2021-12-18 02:00:32 --> URI Class Initialized
INFO - 2021-12-18 02:00:32 --> Router Class Initialized
INFO - 2021-12-18 02:00:32 --> Output Class Initialized
INFO - 2021-12-18 02:00:32 --> Security Class Initialized
DEBUG - 2021-12-18 02:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:00:32 --> Input Class Initialized
INFO - 2021-12-18 02:00:32 --> Language Class Initialized
INFO - 2021-12-18 02:00:32 --> Language Class Initialized
INFO - 2021-12-18 02:00:32 --> Config Class Initialized
INFO - 2021-12-18 02:00:32 --> Loader Class Initialized
INFO - 2021-12-18 02:00:32 --> Helper loaded: url_helper
INFO - 2021-12-18 02:00:32 --> Helper loaded: file_helper
INFO - 2021-12-18 02:00:32 --> Helper loaded: form_helper
INFO - 2021-12-18 02:00:32 --> Helper loaded: my_helper
INFO - 2021-12-18 02:00:32 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:00:32 --> Controller Class Initialized
DEBUG - 2021-12-18 02:00:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:00:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:00:32 --> Final output sent to browser
DEBUG - 2021-12-18 02:00:32 --> Total execution time: 0.0440
INFO - 2021-12-18 02:01:04 --> Config Class Initialized
INFO - 2021-12-18 02:01:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:01:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:01:04 --> Utf8 Class Initialized
INFO - 2021-12-18 02:01:04 --> URI Class Initialized
INFO - 2021-12-18 02:01:04 --> Router Class Initialized
INFO - 2021-12-18 02:01:04 --> Output Class Initialized
INFO - 2021-12-18 02:01:04 --> Security Class Initialized
DEBUG - 2021-12-18 02:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:01:04 --> Input Class Initialized
INFO - 2021-12-18 02:01:04 --> Language Class Initialized
INFO - 2021-12-18 02:01:04 --> Language Class Initialized
INFO - 2021-12-18 02:01:04 --> Config Class Initialized
INFO - 2021-12-18 02:01:04 --> Loader Class Initialized
INFO - 2021-12-18 02:01:04 --> Helper loaded: url_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: file_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: form_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: my_helper
INFO - 2021-12-18 02:01:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:01:04 --> Controller Class Initialized
INFO - 2021-12-18 02:01:04 --> Config Class Initialized
INFO - 2021-12-18 02:01:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:01:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:01:04 --> Utf8 Class Initialized
INFO - 2021-12-18 02:01:04 --> URI Class Initialized
INFO - 2021-12-18 02:01:04 --> Router Class Initialized
INFO - 2021-12-18 02:01:04 --> Output Class Initialized
INFO - 2021-12-18 02:01:04 --> Security Class Initialized
DEBUG - 2021-12-18 02:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:01:04 --> Input Class Initialized
INFO - 2021-12-18 02:01:04 --> Language Class Initialized
INFO - 2021-12-18 02:01:04 --> Language Class Initialized
INFO - 2021-12-18 02:01:04 --> Config Class Initialized
INFO - 2021-12-18 02:01:04 --> Loader Class Initialized
INFO - 2021-12-18 02:01:04 --> Helper loaded: url_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: file_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: form_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: my_helper
INFO - 2021-12-18 02:01:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:01:04 --> Controller Class Initialized
DEBUG - 2021-12-18 02:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:01:04 --> Final output sent to browser
DEBUG - 2021-12-18 02:01:04 --> Total execution time: 0.0360
INFO - 2021-12-18 02:01:04 --> Config Class Initialized
INFO - 2021-12-18 02:01:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:01:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:01:04 --> Utf8 Class Initialized
INFO - 2021-12-18 02:01:04 --> URI Class Initialized
INFO - 2021-12-18 02:01:04 --> Router Class Initialized
INFO - 2021-12-18 02:01:04 --> Output Class Initialized
INFO - 2021-12-18 02:01:04 --> Security Class Initialized
DEBUG - 2021-12-18 02:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:01:04 --> Input Class Initialized
INFO - 2021-12-18 02:01:04 --> Language Class Initialized
INFO - 2021-12-18 02:01:04 --> Language Class Initialized
INFO - 2021-12-18 02:01:04 --> Config Class Initialized
INFO - 2021-12-18 02:01:04 --> Loader Class Initialized
INFO - 2021-12-18 02:01:04 --> Helper loaded: url_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: file_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: form_helper
INFO - 2021-12-18 02:01:04 --> Helper loaded: my_helper
INFO - 2021-12-18 02:01:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:01:04 --> Controller Class Initialized
INFO - 2021-12-18 02:01:11 --> Config Class Initialized
INFO - 2021-12-18 02:01:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:01:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:01:11 --> Utf8 Class Initialized
INFO - 2021-12-18 02:01:11 --> URI Class Initialized
INFO - 2021-12-18 02:01:11 --> Router Class Initialized
INFO - 2021-12-18 02:01:11 --> Output Class Initialized
INFO - 2021-12-18 02:01:11 --> Security Class Initialized
DEBUG - 2021-12-18 02:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:01:11 --> Input Class Initialized
INFO - 2021-12-18 02:01:11 --> Language Class Initialized
INFO - 2021-12-18 02:01:11 --> Language Class Initialized
INFO - 2021-12-18 02:01:11 --> Config Class Initialized
INFO - 2021-12-18 02:01:11 --> Loader Class Initialized
INFO - 2021-12-18 02:01:11 --> Helper loaded: url_helper
INFO - 2021-12-18 02:01:11 --> Helper loaded: file_helper
INFO - 2021-12-18 02:01:11 --> Helper loaded: form_helper
INFO - 2021-12-18 02:01:11 --> Helper loaded: my_helper
INFO - 2021-12-18 02:01:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:01:11 --> Controller Class Initialized
INFO - 2021-12-18 02:01:12 --> Config Class Initialized
INFO - 2021-12-18 02:01:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:01:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:01:12 --> Utf8 Class Initialized
INFO - 2021-12-18 02:01:12 --> URI Class Initialized
INFO - 2021-12-18 02:01:12 --> Router Class Initialized
INFO - 2021-12-18 02:01:12 --> Output Class Initialized
INFO - 2021-12-18 02:01:12 --> Security Class Initialized
DEBUG - 2021-12-18 02:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:01:12 --> Input Class Initialized
INFO - 2021-12-18 02:01:12 --> Language Class Initialized
INFO - 2021-12-18 02:01:12 --> Language Class Initialized
INFO - 2021-12-18 02:01:12 --> Config Class Initialized
INFO - 2021-12-18 02:01:12 --> Loader Class Initialized
INFO - 2021-12-18 02:01:12 --> Helper loaded: url_helper
INFO - 2021-12-18 02:01:12 --> Helper loaded: file_helper
INFO - 2021-12-18 02:01:12 --> Helper loaded: form_helper
INFO - 2021-12-18 02:01:12 --> Helper loaded: my_helper
INFO - 2021-12-18 02:01:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:01:12 --> Controller Class Initialized
INFO - 2021-12-18 02:01:15 --> Config Class Initialized
INFO - 2021-12-18 02:01:15 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:01:15 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:01:15 --> Utf8 Class Initialized
INFO - 2021-12-18 02:01:15 --> URI Class Initialized
INFO - 2021-12-18 02:01:15 --> Router Class Initialized
INFO - 2021-12-18 02:01:15 --> Output Class Initialized
INFO - 2021-12-18 02:01:15 --> Security Class Initialized
DEBUG - 2021-12-18 02:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:01:15 --> Input Class Initialized
INFO - 2021-12-18 02:01:15 --> Language Class Initialized
INFO - 2021-12-18 02:01:15 --> Language Class Initialized
INFO - 2021-12-18 02:01:15 --> Config Class Initialized
INFO - 2021-12-18 02:01:15 --> Loader Class Initialized
INFO - 2021-12-18 02:01:15 --> Helper loaded: url_helper
INFO - 2021-12-18 02:01:15 --> Helper loaded: file_helper
INFO - 2021-12-18 02:01:15 --> Helper loaded: form_helper
INFO - 2021-12-18 02:01:15 --> Helper loaded: my_helper
INFO - 2021-12-18 02:01:15 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:01:15 --> Controller Class Initialized
INFO - 2021-12-18 02:01:16 --> Config Class Initialized
INFO - 2021-12-18 02:01:16 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:01:16 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:01:16 --> Utf8 Class Initialized
INFO - 2021-12-18 02:01:16 --> URI Class Initialized
INFO - 2021-12-18 02:01:16 --> Router Class Initialized
INFO - 2021-12-18 02:01:16 --> Output Class Initialized
INFO - 2021-12-18 02:01:16 --> Security Class Initialized
DEBUG - 2021-12-18 02:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:01:16 --> Input Class Initialized
INFO - 2021-12-18 02:01:16 --> Language Class Initialized
INFO - 2021-12-18 02:01:16 --> Language Class Initialized
INFO - 2021-12-18 02:01:16 --> Config Class Initialized
INFO - 2021-12-18 02:01:16 --> Loader Class Initialized
INFO - 2021-12-18 02:01:16 --> Helper loaded: url_helper
INFO - 2021-12-18 02:01:16 --> Helper loaded: file_helper
INFO - 2021-12-18 02:01:16 --> Helper loaded: form_helper
INFO - 2021-12-18 02:01:16 --> Helper loaded: my_helper
INFO - 2021-12-18 02:01:16 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:01:16 --> Controller Class Initialized
INFO - 2021-12-18 02:01:36 --> Config Class Initialized
INFO - 2021-12-18 02:01:36 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:01:36 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:01:36 --> Utf8 Class Initialized
INFO - 2021-12-18 02:01:36 --> URI Class Initialized
INFO - 2021-12-18 02:01:36 --> Router Class Initialized
INFO - 2021-12-18 02:01:36 --> Output Class Initialized
INFO - 2021-12-18 02:01:36 --> Security Class Initialized
DEBUG - 2021-12-18 02:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:01:36 --> Input Class Initialized
INFO - 2021-12-18 02:01:36 --> Language Class Initialized
INFO - 2021-12-18 02:01:36 --> Language Class Initialized
INFO - 2021-12-18 02:01:36 --> Config Class Initialized
INFO - 2021-12-18 02:01:36 --> Loader Class Initialized
INFO - 2021-12-18 02:01:36 --> Helper loaded: url_helper
INFO - 2021-12-18 02:01:36 --> Helper loaded: file_helper
INFO - 2021-12-18 02:01:36 --> Helper loaded: form_helper
INFO - 2021-12-18 02:01:36 --> Helper loaded: my_helper
INFO - 2021-12-18 02:01:36 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:01:36 --> Controller Class Initialized
DEBUG - 2021-12-18 02:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:01:36 --> Final output sent to browser
DEBUG - 2021-12-18 02:01:36 --> Total execution time: 0.0430
INFO - 2021-12-18 02:02:03 --> Config Class Initialized
INFO - 2021-12-18 02:02:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:02:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:02:03 --> Utf8 Class Initialized
INFO - 2021-12-18 02:02:03 --> URI Class Initialized
INFO - 2021-12-18 02:02:03 --> Router Class Initialized
INFO - 2021-12-18 02:02:03 --> Output Class Initialized
INFO - 2021-12-18 02:02:03 --> Security Class Initialized
DEBUG - 2021-12-18 02:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:02:03 --> Input Class Initialized
INFO - 2021-12-18 02:02:03 --> Language Class Initialized
INFO - 2021-12-18 02:02:03 --> Language Class Initialized
INFO - 2021-12-18 02:02:03 --> Config Class Initialized
INFO - 2021-12-18 02:02:03 --> Loader Class Initialized
INFO - 2021-12-18 02:02:03 --> Helper loaded: url_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: file_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: form_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: my_helper
INFO - 2021-12-18 02:02:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:02:03 --> Controller Class Initialized
INFO - 2021-12-18 02:02:03 --> Config Class Initialized
INFO - 2021-12-18 02:02:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:02:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:02:03 --> Utf8 Class Initialized
INFO - 2021-12-18 02:02:03 --> URI Class Initialized
INFO - 2021-12-18 02:02:03 --> Router Class Initialized
INFO - 2021-12-18 02:02:03 --> Output Class Initialized
INFO - 2021-12-18 02:02:03 --> Security Class Initialized
DEBUG - 2021-12-18 02:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:02:03 --> Input Class Initialized
INFO - 2021-12-18 02:02:03 --> Language Class Initialized
INFO - 2021-12-18 02:02:03 --> Language Class Initialized
INFO - 2021-12-18 02:02:03 --> Config Class Initialized
INFO - 2021-12-18 02:02:03 --> Loader Class Initialized
INFO - 2021-12-18 02:02:03 --> Helper loaded: url_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: file_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: form_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: my_helper
INFO - 2021-12-18 02:02:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:02:03 --> Controller Class Initialized
DEBUG - 2021-12-18 02:02:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:02:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:02:03 --> Final output sent to browser
DEBUG - 2021-12-18 02:02:03 --> Total execution time: 0.0350
INFO - 2021-12-18 02:02:03 --> Config Class Initialized
INFO - 2021-12-18 02:02:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:02:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:02:03 --> Utf8 Class Initialized
INFO - 2021-12-18 02:02:03 --> URI Class Initialized
INFO - 2021-12-18 02:02:03 --> Router Class Initialized
INFO - 2021-12-18 02:02:03 --> Output Class Initialized
INFO - 2021-12-18 02:02:03 --> Security Class Initialized
DEBUG - 2021-12-18 02:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:02:03 --> Input Class Initialized
INFO - 2021-12-18 02:02:03 --> Language Class Initialized
INFO - 2021-12-18 02:02:03 --> Language Class Initialized
INFO - 2021-12-18 02:02:03 --> Config Class Initialized
INFO - 2021-12-18 02:02:03 --> Loader Class Initialized
INFO - 2021-12-18 02:02:03 --> Helper loaded: url_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: file_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: form_helper
INFO - 2021-12-18 02:02:03 --> Helper loaded: my_helper
INFO - 2021-12-18 02:02:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:02:03 --> Controller Class Initialized
INFO - 2021-12-18 02:02:04 --> Config Class Initialized
INFO - 2021-12-18 02:02:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:02:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:02:04 --> Utf8 Class Initialized
INFO - 2021-12-18 02:02:04 --> URI Class Initialized
INFO - 2021-12-18 02:02:04 --> Router Class Initialized
INFO - 2021-12-18 02:02:04 --> Output Class Initialized
INFO - 2021-12-18 02:02:04 --> Security Class Initialized
DEBUG - 2021-12-18 02:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:02:04 --> Input Class Initialized
INFO - 2021-12-18 02:02:04 --> Language Class Initialized
INFO - 2021-12-18 02:02:04 --> Language Class Initialized
INFO - 2021-12-18 02:02:04 --> Config Class Initialized
INFO - 2021-12-18 02:02:04 --> Loader Class Initialized
INFO - 2021-12-18 02:02:04 --> Helper loaded: url_helper
INFO - 2021-12-18 02:02:04 --> Helper loaded: file_helper
INFO - 2021-12-18 02:02:04 --> Helper loaded: form_helper
INFO - 2021-12-18 02:02:04 --> Helper loaded: my_helper
INFO - 2021-12-18 02:02:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:02:04 --> Controller Class Initialized
INFO - 2021-12-18 02:02:05 --> Config Class Initialized
INFO - 2021-12-18 02:02:05 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:02:05 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:02:05 --> Utf8 Class Initialized
INFO - 2021-12-18 02:02:05 --> URI Class Initialized
INFO - 2021-12-18 02:02:05 --> Router Class Initialized
INFO - 2021-12-18 02:02:05 --> Output Class Initialized
INFO - 2021-12-18 02:02:05 --> Security Class Initialized
DEBUG - 2021-12-18 02:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:02:05 --> Input Class Initialized
INFO - 2021-12-18 02:02:05 --> Language Class Initialized
INFO - 2021-12-18 02:02:05 --> Language Class Initialized
INFO - 2021-12-18 02:02:05 --> Config Class Initialized
INFO - 2021-12-18 02:02:05 --> Loader Class Initialized
INFO - 2021-12-18 02:02:05 --> Helper loaded: url_helper
INFO - 2021-12-18 02:02:05 --> Helper loaded: file_helper
INFO - 2021-12-18 02:02:05 --> Helper loaded: form_helper
INFO - 2021-12-18 02:02:05 --> Helper loaded: my_helper
INFO - 2021-12-18 02:02:05 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:02:05 --> Controller Class Initialized
INFO - 2021-12-18 02:02:08 --> Config Class Initialized
INFO - 2021-12-18 02:02:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:02:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:02:08 --> Utf8 Class Initialized
INFO - 2021-12-18 02:02:08 --> URI Class Initialized
INFO - 2021-12-18 02:02:08 --> Router Class Initialized
INFO - 2021-12-18 02:02:08 --> Output Class Initialized
INFO - 2021-12-18 02:02:08 --> Security Class Initialized
DEBUG - 2021-12-18 02:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:02:08 --> Input Class Initialized
INFO - 2021-12-18 02:02:08 --> Language Class Initialized
INFO - 2021-12-18 02:02:08 --> Language Class Initialized
INFO - 2021-12-18 02:02:08 --> Config Class Initialized
INFO - 2021-12-18 02:02:08 --> Loader Class Initialized
INFO - 2021-12-18 02:02:08 --> Helper loaded: url_helper
INFO - 2021-12-18 02:02:08 --> Helper loaded: file_helper
INFO - 2021-12-18 02:02:08 --> Helper loaded: form_helper
INFO - 2021-12-18 02:02:08 --> Helper loaded: my_helper
INFO - 2021-12-18 02:02:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:02:08 --> Controller Class Initialized
DEBUG - 2021-12-18 02:02:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:02:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:02:08 --> Final output sent to browser
DEBUG - 2021-12-18 02:02:08 --> Total execution time: 0.0440
INFO - 2021-12-18 02:03:54 --> Config Class Initialized
INFO - 2021-12-18 02:03:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:03:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:03:54 --> Utf8 Class Initialized
INFO - 2021-12-18 02:03:54 --> URI Class Initialized
INFO - 2021-12-18 02:03:54 --> Router Class Initialized
INFO - 2021-12-18 02:03:54 --> Output Class Initialized
INFO - 2021-12-18 02:03:54 --> Security Class Initialized
DEBUG - 2021-12-18 02:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:03:54 --> Input Class Initialized
INFO - 2021-12-18 02:03:54 --> Language Class Initialized
INFO - 2021-12-18 02:03:54 --> Language Class Initialized
INFO - 2021-12-18 02:03:54 --> Config Class Initialized
INFO - 2021-12-18 02:03:54 --> Loader Class Initialized
INFO - 2021-12-18 02:03:54 --> Helper loaded: url_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: file_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: form_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: my_helper
INFO - 2021-12-18 02:03:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:03:54 --> Controller Class Initialized
INFO - 2021-12-18 02:03:54 --> Config Class Initialized
INFO - 2021-12-18 02:03:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:03:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:03:54 --> Utf8 Class Initialized
INFO - 2021-12-18 02:03:54 --> URI Class Initialized
INFO - 2021-12-18 02:03:54 --> Router Class Initialized
INFO - 2021-12-18 02:03:54 --> Output Class Initialized
INFO - 2021-12-18 02:03:54 --> Security Class Initialized
DEBUG - 2021-12-18 02:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:03:54 --> Input Class Initialized
INFO - 2021-12-18 02:03:54 --> Language Class Initialized
INFO - 2021-12-18 02:03:54 --> Language Class Initialized
INFO - 2021-12-18 02:03:54 --> Config Class Initialized
INFO - 2021-12-18 02:03:54 --> Loader Class Initialized
INFO - 2021-12-18 02:03:54 --> Helper loaded: url_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: file_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: form_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: my_helper
INFO - 2021-12-18 02:03:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:03:54 --> Controller Class Initialized
DEBUG - 2021-12-18 02:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:03:54 --> Final output sent to browser
DEBUG - 2021-12-18 02:03:54 --> Total execution time: 0.0350
INFO - 2021-12-18 02:03:54 --> Config Class Initialized
INFO - 2021-12-18 02:03:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:03:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:03:54 --> Utf8 Class Initialized
INFO - 2021-12-18 02:03:54 --> URI Class Initialized
INFO - 2021-12-18 02:03:54 --> Router Class Initialized
INFO - 2021-12-18 02:03:54 --> Output Class Initialized
INFO - 2021-12-18 02:03:54 --> Security Class Initialized
DEBUG - 2021-12-18 02:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:03:54 --> Input Class Initialized
INFO - 2021-12-18 02:03:54 --> Language Class Initialized
INFO - 2021-12-18 02:03:54 --> Language Class Initialized
INFO - 2021-12-18 02:03:54 --> Config Class Initialized
INFO - 2021-12-18 02:03:54 --> Loader Class Initialized
INFO - 2021-12-18 02:03:54 --> Helper loaded: url_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: file_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: form_helper
INFO - 2021-12-18 02:03:54 --> Helper loaded: my_helper
INFO - 2021-12-18 02:03:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:03:55 --> Controller Class Initialized
INFO - 2021-12-18 02:03:56 --> Config Class Initialized
INFO - 2021-12-18 02:03:56 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:03:56 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:03:56 --> Utf8 Class Initialized
INFO - 2021-12-18 02:03:56 --> URI Class Initialized
INFO - 2021-12-18 02:03:56 --> Router Class Initialized
INFO - 2021-12-18 02:03:56 --> Output Class Initialized
INFO - 2021-12-18 02:03:56 --> Security Class Initialized
DEBUG - 2021-12-18 02:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:03:56 --> Input Class Initialized
INFO - 2021-12-18 02:03:56 --> Language Class Initialized
INFO - 2021-12-18 02:03:56 --> Language Class Initialized
INFO - 2021-12-18 02:03:56 --> Config Class Initialized
INFO - 2021-12-18 02:03:56 --> Loader Class Initialized
INFO - 2021-12-18 02:03:56 --> Helper loaded: url_helper
INFO - 2021-12-18 02:03:56 --> Helper loaded: file_helper
INFO - 2021-12-18 02:03:56 --> Helper loaded: form_helper
INFO - 2021-12-18 02:03:56 --> Helper loaded: my_helper
INFO - 2021-12-18 02:03:56 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:03:56 --> Controller Class Initialized
DEBUG - 2021-12-18 02:03:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:03:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:03:56 --> Final output sent to browser
DEBUG - 2021-12-18 02:03:56 --> Total execution time: 0.0540
INFO - 2021-12-18 02:03:59 --> Config Class Initialized
INFO - 2021-12-18 02:03:59 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:03:59 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:03:59 --> Utf8 Class Initialized
INFO - 2021-12-18 02:03:59 --> URI Class Initialized
INFO - 2021-12-18 02:03:59 --> Router Class Initialized
INFO - 2021-12-18 02:03:59 --> Output Class Initialized
INFO - 2021-12-18 02:03:59 --> Security Class Initialized
DEBUG - 2021-12-18 02:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:03:59 --> Input Class Initialized
INFO - 2021-12-18 02:03:59 --> Language Class Initialized
INFO - 2021-12-18 02:03:59 --> Language Class Initialized
INFO - 2021-12-18 02:03:59 --> Config Class Initialized
INFO - 2021-12-18 02:03:59 --> Loader Class Initialized
INFO - 2021-12-18 02:03:59 --> Helper loaded: url_helper
INFO - 2021-12-18 02:03:59 --> Helper loaded: file_helper
INFO - 2021-12-18 02:03:59 --> Helper loaded: form_helper
INFO - 2021-12-18 02:03:59 --> Helper loaded: my_helper
INFO - 2021-12-18 02:03:59 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:03:59 --> Controller Class Initialized
DEBUG - 2021-12-18 02:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:03:59 --> Final output sent to browser
DEBUG - 2021-12-18 02:03:59 --> Total execution time: 0.0480
INFO - 2021-12-18 02:03:59 --> Config Class Initialized
INFO - 2021-12-18 02:03:59 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:03:59 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:03:59 --> Utf8 Class Initialized
INFO - 2021-12-18 02:03:59 --> URI Class Initialized
INFO - 2021-12-18 02:03:59 --> Router Class Initialized
INFO - 2021-12-18 02:03:59 --> Output Class Initialized
INFO - 2021-12-18 02:03:59 --> Security Class Initialized
DEBUG - 2021-12-18 02:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:03:59 --> Input Class Initialized
INFO - 2021-12-18 02:03:59 --> Language Class Initialized
INFO - 2021-12-18 02:03:59 --> Language Class Initialized
INFO - 2021-12-18 02:03:59 --> Config Class Initialized
INFO - 2021-12-18 02:03:59 --> Loader Class Initialized
INFO - 2021-12-18 02:03:59 --> Helper loaded: url_helper
INFO - 2021-12-18 02:03:59 --> Helper loaded: file_helper
INFO - 2021-12-18 02:03:59 --> Helper loaded: form_helper
INFO - 2021-12-18 02:03:59 --> Helper loaded: my_helper
INFO - 2021-12-18 02:03:59 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:03:59 --> Controller Class Initialized
INFO - 2021-12-18 02:04:00 --> Config Class Initialized
INFO - 2021-12-18 02:04:00 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:00 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:00 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:00 --> URI Class Initialized
INFO - 2021-12-18 02:04:00 --> Router Class Initialized
INFO - 2021-12-18 02:04:00 --> Output Class Initialized
INFO - 2021-12-18 02:04:00 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:00 --> Input Class Initialized
INFO - 2021-12-18 02:04:00 --> Language Class Initialized
INFO - 2021-12-18 02:04:00 --> Language Class Initialized
INFO - 2021-12-18 02:04:00 --> Config Class Initialized
INFO - 2021-12-18 02:04:00 --> Loader Class Initialized
INFO - 2021-12-18 02:04:00 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:00 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:00 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:00 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:00 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:00 --> Controller Class Initialized
INFO - 2021-12-18 02:04:01 --> Config Class Initialized
INFO - 2021-12-18 02:04:01 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:01 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:01 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:01 --> URI Class Initialized
INFO - 2021-12-18 02:04:01 --> Router Class Initialized
INFO - 2021-12-18 02:04:01 --> Output Class Initialized
INFO - 2021-12-18 02:04:01 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:01 --> Input Class Initialized
INFO - 2021-12-18 02:04:01 --> Language Class Initialized
INFO - 2021-12-18 02:04:01 --> Language Class Initialized
INFO - 2021-12-18 02:04:01 --> Config Class Initialized
INFO - 2021-12-18 02:04:01 --> Loader Class Initialized
INFO - 2021-12-18 02:04:01 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:01 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:01 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:01 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:01 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:01 --> Controller Class Initialized
INFO - 2021-12-18 02:04:01 --> Config Class Initialized
INFO - 2021-12-18 02:04:01 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:01 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:01 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:01 --> URI Class Initialized
INFO - 2021-12-18 02:04:01 --> Router Class Initialized
INFO - 2021-12-18 02:04:01 --> Output Class Initialized
INFO - 2021-12-18 02:04:01 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:01 --> Input Class Initialized
INFO - 2021-12-18 02:04:01 --> Language Class Initialized
INFO - 2021-12-18 02:04:01 --> Language Class Initialized
INFO - 2021-12-18 02:04:01 --> Config Class Initialized
INFO - 2021-12-18 02:04:01 --> Loader Class Initialized
INFO - 2021-12-18 02:04:01 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:01 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:01 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:01 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:01 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:01 --> Controller Class Initialized
INFO - 2021-12-18 02:04:02 --> Config Class Initialized
INFO - 2021-12-18 02:04:02 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:02 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:02 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:02 --> URI Class Initialized
INFO - 2021-12-18 02:04:02 --> Router Class Initialized
INFO - 2021-12-18 02:04:02 --> Output Class Initialized
INFO - 2021-12-18 02:04:02 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:02 --> Input Class Initialized
INFO - 2021-12-18 02:04:02 --> Language Class Initialized
INFO - 2021-12-18 02:04:02 --> Language Class Initialized
INFO - 2021-12-18 02:04:02 --> Config Class Initialized
INFO - 2021-12-18 02:04:02 --> Loader Class Initialized
INFO - 2021-12-18 02:04:02 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:02 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:02 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:02 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:02 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:02 --> Controller Class Initialized
INFO - 2021-12-18 02:04:03 --> Config Class Initialized
INFO - 2021-12-18 02:04:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:03 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:03 --> URI Class Initialized
INFO - 2021-12-18 02:04:03 --> Router Class Initialized
INFO - 2021-12-18 02:04:03 --> Output Class Initialized
INFO - 2021-12-18 02:04:03 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:03 --> Input Class Initialized
INFO - 2021-12-18 02:04:03 --> Language Class Initialized
INFO - 2021-12-18 02:04:03 --> Language Class Initialized
INFO - 2021-12-18 02:04:03 --> Config Class Initialized
INFO - 2021-12-18 02:04:03 --> Loader Class Initialized
INFO - 2021-12-18 02:04:03 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:03 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:03 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:03 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:03 --> Controller Class Initialized
INFO - 2021-12-18 02:04:04 --> Config Class Initialized
INFO - 2021-12-18 02:04:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:04 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:04 --> URI Class Initialized
INFO - 2021-12-18 02:04:04 --> Router Class Initialized
INFO - 2021-12-18 02:04:04 --> Output Class Initialized
INFO - 2021-12-18 02:04:04 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:04 --> Input Class Initialized
INFO - 2021-12-18 02:04:04 --> Language Class Initialized
INFO - 2021-12-18 02:04:04 --> Language Class Initialized
INFO - 2021-12-18 02:04:04 --> Config Class Initialized
INFO - 2021-12-18 02:04:04 --> Loader Class Initialized
INFO - 2021-12-18 02:04:04 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:04 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:04 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:04 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:04 --> Controller Class Initialized
INFO - 2021-12-18 02:04:07 --> Config Class Initialized
INFO - 2021-12-18 02:04:07 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:07 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:07 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:07 --> URI Class Initialized
INFO - 2021-12-18 02:04:07 --> Router Class Initialized
INFO - 2021-12-18 02:04:07 --> Output Class Initialized
INFO - 2021-12-18 02:04:07 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:07 --> Input Class Initialized
INFO - 2021-12-18 02:04:07 --> Language Class Initialized
INFO - 2021-12-18 02:04:07 --> Language Class Initialized
INFO - 2021-12-18 02:04:07 --> Config Class Initialized
INFO - 2021-12-18 02:04:07 --> Loader Class Initialized
INFO - 2021-12-18 02:04:07 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:07 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:07 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:07 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:07 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:07 --> Controller Class Initialized
DEBUG - 2021-12-18 02:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:04:07 --> Final output sent to browser
DEBUG - 2021-12-18 02:04:07 --> Total execution time: 0.0430
INFO - 2021-12-18 02:04:33 --> Config Class Initialized
INFO - 2021-12-18 02:04:33 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:33 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:33 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:33 --> URI Class Initialized
INFO - 2021-12-18 02:04:33 --> Router Class Initialized
INFO - 2021-12-18 02:04:33 --> Output Class Initialized
INFO - 2021-12-18 02:04:33 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:33 --> Input Class Initialized
INFO - 2021-12-18 02:04:33 --> Language Class Initialized
INFO - 2021-12-18 02:04:33 --> Language Class Initialized
INFO - 2021-12-18 02:04:33 --> Config Class Initialized
INFO - 2021-12-18 02:04:33 --> Loader Class Initialized
INFO - 2021-12-18 02:04:33 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:33 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:33 --> Controller Class Initialized
INFO - 2021-12-18 02:04:33 --> Config Class Initialized
INFO - 2021-12-18 02:04:33 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:33 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:33 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:33 --> URI Class Initialized
INFO - 2021-12-18 02:04:33 --> Router Class Initialized
INFO - 2021-12-18 02:04:33 --> Output Class Initialized
INFO - 2021-12-18 02:04:33 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:33 --> Input Class Initialized
INFO - 2021-12-18 02:04:33 --> Language Class Initialized
INFO - 2021-12-18 02:04:33 --> Language Class Initialized
INFO - 2021-12-18 02:04:33 --> Config Class Initialized
INFO - 2021-12-18 02:04:33 --> Loader Class Initialized
INFO - 2021-12-18 02:04:33 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:33 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:33 --> Controller Class Initialized
DEBUG - 2021-12-18 02:04:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:04:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:04:33 --> Final output sent to browser
DEBUG - 2021-12-18 02:04:33 --> Total execution time: 0.0360
INFO - 2021-12-18 02:04:33 --> Config Class Initialized
INFO - 2021-12-18 02:04:33 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:33 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:33 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:33 --> URI Class Initialized
INFO - 2021-12-18 02:04:33 --> Router Class Initialized
INFO - 2021-12-18 02:04:33 --> Output Class Initialized
INFO - 2021-12-18 02:04:33 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:33 --> Input Class Initialized
INFO - 2021-12-18 02:04:33 --> Language Class Initialized
INFO - 2021-12-18 02:04:33 --> Language Class Initialized
INFO - 2021-12-18 02:04:33 --> Config Class Initialized
INFO - 2021-12-18 02:04:33 --> Loader Class Initialized
INFO - 2021-12-18 02:04:33 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:33 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:33 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:33 --> Controller Class Initialized
INFO - 2021-12-18 02:04:34 --> Config Class Initialized
INFO - 2021-12-18 02:04:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:34 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:34 --> URI Class Initialized
INFO - 2021-12-18 02:04:34 --> Router Class Initialized
INFO - 2021-12-18 02:04:34 --> Output Class Initialized
INFO - 2021-12-18 02:04:34 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:34 --> Input Class Initialized
INFO - 2021-12-18 02:04:34 --> Language Class Initialized
INFO - 2021-12-18 02:04:34 --> Language Class Initialized
INFO - 2021-12-18 02:04:34 --> Config Class Initialized
INFO - 2021-12-18 02:04:34 --> Loader Class Initialized
INFO - 2021-12-18 02:04:34 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:34 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:34 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:34 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:34 --> Controller Class Initialized
DEBUG - 2021-12-18 02:04:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:04:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:04:34 --> Final output sent to browser
DEBUG - 2021-12-18 02:04:34 --> Total execution time: 0.0500
INFO - 2021-12-18 02:04:49 --> Config Class Initialized
INFO - 2021-12-18 02:04:49 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:50 --> URI Class Initialized
INFO - 2021-12-18 02:04:50 --> Router Class Initialized
INFO - 2021-12-18 02:04:50 --> Output Class Initialized
INFO - 2021-12-18 02:04:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:50 --> Input Class Initialized
INFO - 2021-12-18 02:04:50 --> Language Class Initialized
INFO - 2021-12-18 02:04:50 --> Language Class Initialized
INFO - 2021-12-18 02:04:50 --> Config Class Initialized
INFO - 2021-12-18 02:04:50 --> Loader Class Initialized
INFO - 2021-12-18 02:04:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:50 --> Controller Class Initialized
DEBUG - 2021-12-18 02:04:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:04:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:04:50 --> Final output sent to browser
DEBUG - 2021-12-18 02:04:50 --> Total execution time: 0.0430
INFO - 2021-12-18 02:04:50 --> Config Class Initialized
INFO - 2021-12-18 02:04:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:50 --> URI Class Initialized
INFO - 2021-12-18 02:04:50 --> Router Class Initialized
INFO - 2021-12-18 02:04:50 --> Output Class Initialized
INFO - 2021-12-18 02:04:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:50 --> Input Class Initialized
INFO - 2021-12-18 02:04:50 --> Language Class Initialized
INFO - 2021-12-18 02:04:50 --> Language Class Initialized
INFO - 2021-12-18 02:04:50 --> Config Class Initialized
INFO - 2021-12-18 02:04:50 --> Loader Class Initialized
INFO - 2021-12-18 02:04:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:50 --> Controller Class Initialized
INFO - 2021-12-18 02:04:51 --> Config Class Initialized
INFO - 2021-12-18 02:04:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:51 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:51 --> URI Class Initialized
INFO - 2021-12-18 02:04:51 --> Router Class Initialized
INFO - 2021-12-18 02:04:51 --> Output Class Initialized
INFO - 2021-12-18 02:04:51 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:51 --> Input Class Initialized
INFO - 2021-12-18 02:04:51 --> Language Class Initialized
INFO - 2021-12-18 02:04:51 --> Language Class Initialized
INFO - 2021-12-18 02:04:51 --> Config Class Initialized
INFO - 2021-12-18 02:04:51 --> Loader Class Initialized
INFO - 2021-12-18 02:04:51 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:51 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:51 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:51 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:51 --> Controller Class Initialized
INFO - 2021-12-18 02:04:51 --> Config Class Initialized
INFO - 2021-12-18 02:04:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:51 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:51 --> URI Class Initialized
INFO - 2021-12-18 02:04:51 --> Router Class Initialized
INFO - 2021-12-18 02:04:51 --> Output Class Initialized
INFO - 2021-12-18 02:04:51 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:51 --> Input Class Initialized
INFO - 2021-12-18 02:04:51 --> Language Class Initialized
INFO - 2021-12-18 02:04:51 --> Language Class Initialized
INFO - 2021-12-18 02:04:51 --> Config Class Initialized
INFO - 2021-12-18 02:04:51 --> Loader Class Initialized
INFO - 2021-12-18 02:04:51 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:51 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:51 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:51 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:51 --> Controller Class Initialized
INFO - 2021-12-18 02:04:52 --> Config Class Initialized
INFO - 2021-12-18 02:04:52 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:52 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:52 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:52 --> URI Class Initialized
INFO - 2021-12-18 02:04:52 --> Router Class Initialized
INFO - 2021-12-18 02:04:52 --> Output Class Initialized
INFO - 2021-12-18 02:04:52 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:52 --> Input Class Initialized
INFO - 2021-12-18 02:04:52 --> Language Class Initialized
INFO - 2021-12-18 02:04:52 --> Language Class Initialized
INFO - 2021-12-18 02:04:52 --> Config Class Initialized
INFO - 2021-12-18 02:04:52 --> Loader Class Initialized
INFO - 2021-12-18 02:04:52 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:52 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:52 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:52 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:52 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:52 --> Controller Class Initialized
INFO - 2021-12-18 02:04:54 --> Config Class Initialized
INFO - 2021-12-18 02:04:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:04:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:04:54 --> Utf8 Class Initialized
INFO - 2021-12-18 02:04:54 --> URI Class Initialized
INFO - 2021-12-18 02:04:54 --> Router Class Initialized
INFO - 2021-12-18 02:04:54 --> Output Class Initialized
INFO - 2021-12-18 02:04:54 --> Security Class Initialized
DEBUG - 2021-12-18 02:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:04:54 --> Input Class Initialized
INFO - 2021-12-18 02:04:54 --> Language Class Initialized
INFO - 2021-12-18 02:04:54 --> Language Class Initialized
INFO - 2021-12-18 02:04:54 --> Config Class Initialized
INFO - 2021-12-18 02:04:54 --> Loader Class Initialized
INFO - 2021-12-18 02:04:54 --> Helper loaded: url_helper
INFO - 2021-12-18 02:04:54 --> Helper loaded: file_helper
INFO - 2021-12-18 02:04:54 --> Helper loaded: form_helper
INFO - 2021-12-18 02:04:54 --> Helper loaded: my_helper
INFO - 2021-12-18 02:04:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:04:54 --> Controller Class Initialized
DEBUG - 2021-12-18 02:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:04:54 --> Final output sent to browser
DEBUG - 2021-12-18 02:04:54 --> Total execution time: 0.0450
INFO - 2021-12-18 02:05:08 --> Config Class Initialized
INFO - 2021-12-18 02:05:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:05:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:05:08 --> Utf8 Class Initialized
INFO - 2021-12-18 02:05:08 --> URI Class Initialized
INFO - 2021-12-18 02:05:08 --> Router Class Initialized
INFO - 2021-12-18 02:05:08 --> Output Class Initialized
INFO - 2021-12-18 02:05:08 --> Security Class Initialized
DEBUG - 2021-12-18 02:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:05:08 --> Input Class Initialized
INFO - 2021-12-18 02:05:08 --> Language Class Initialized
INFO - 2021-12-18 02:05:08 --> Language Class Initialized
INFO - 2021-12-18 02:05:08 --> Config Class Initialized
INFO - 2021-12-18 02:05:08 --> Loader Class Initialized
INFO - 2021-12-18 02:05:08 --> Helper loaded: url_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: file_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: form_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: my_helper
INFO - 2021-12-18 02:05:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:05:08 --> Controller Class Initialized
INFO - 2021-12-18 02:05:08 --> Config Class Initialized
INFO - 2021-12-18 02:05:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:05:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:05:08 --> Utf8 Class Initialized
INFO - 2021-12-18 02:05:08 --> URI Class Initialized
INFO - 2021-12-18 02:05:08 --> Router Class Initialized
INFO - 2021-12-18 02:05:08 --> Output Class Initialized
INFO - 2021-12-18 02:05:08 --> Security Class Initialized
DEBUG - 2021-12-18 02:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:05:08 --> Input Class Initialized
INFO - 2021-12-18 02:05:08 --> Language Class Initialized
INFO - 2021-12-18 02:05:08 --> Language Class Initialized
INFO - 2021-12-18 02:05:08 --> Config Class Initialized
INFO - 2021-12-18 02:05:08 --> Loader Class Initialized
INFO - 2021-12-18 02:05:08 --> Helper loaded: url_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: file_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: form_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: my_helper
INFO - 2021-12-18 02:05:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:05:08 --> Controller Class Initialized
DEBUG - 2021-12-18 02:05:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:05:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:05:08 --> Final output sent to browser
DEBUG - 2021-12-18 02:05:08 --> Total execution time: 0.0350
INFO - 2021-12-18 02:05:08 --> Config Class Initialized
INFO - 2021-12-18 02:05:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:05:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:05:08 --> Utf8 Class Initialized
INFO - 2021-12-18 02:05:08 --> URI Class Initialized
INFO - 2021-12-18 02:05:08 --> Router Class Initialized
INFO - 2021-12-18 02:05:08 --> Output Class Initialized
INFO - 2021-12-18 02:05:08 --> Security Class Initialized
DEBUG - 2021-12-18 02:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:05:08 --> Input Class Initialized
INFO - 2021-12-18 02:05:08 --> Language Class Initialized
INFO - 2021-12-18 02:05:08 --> Language Class Initialized
INFO - 2021-12-18 02:05:08 --> Config Class Initialized
INFO - 2021-12-18 02:05:08 --> Loader Class Initialized
INFO - 2021-12-18 02:05:08 --> Helper loaded: url_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: file_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: form_helper
INFO - 2021-12-18 02:05:08 --> Helper loaded: my_helper
INFO - 2021-12-18 02:05:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:05:08 --> Controller Class Initialized
INFO - 2021-12-18 02:05:10 --> Config Class Initialized
INFO - 2021-12-18 02:05:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:05:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:05:10 --> Utf8 Class Initialized
INFO - 2021-12-18 02:05:10 --> URI Class Initialized
INFO - 2021-12-18 02:05:10 --> Router Class Initialized
INFO - 2021-12-18 02:05:10 --> Output Class Initialized
INFO - 2021-12-18 02:05:10 --> Security Class Initialized
DEBUG - 2021-12-18 02:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:05:10 --> Input Class Initialized
INFO - 2021-12-18 02:05:10 --> Language Class Initialized
INFO - 2021-12-18 02:05:10 --> Language Class Initialized
INFO - 2021-12-18 02:05:10 --> Config Class Initialized
INFO - 2021-12-18 02:05:10 --> Loader Class Initialized
INFO - 2021-12-18 02:05:10 --> Helper loaded: url_helper
INFO - 2021-12-18 02:05:10 --> Helper loaded: file_helper
INFO - 2021-12-18 02:05:10 --> Helper loaded: form_helper
INFO - 2021-12-18 02:05:10 --> Helper loaded: my_helper
INFO - 2021-12-18 02:05:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:05:10 --> Controller Class Initialized
DEBUG - 2021-12-18 02:05:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:05:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:05:10 --> Final output sent to browser
DEBUG - 2021-12-18 02:05:10 --> Total execution time: 0.0540
INFO - 2021-12-18 02:09:42 --> Config Class Initialized
INFO - 2021-12-18 02:09:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:09:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:09:42 --> Utf8 Class Initialized
INFO - 2021-12-18 02:09:42 --> URI Class Initialized
INFO - 2021-12-18 02:09:42 --> Router Class Initialized
INFO - 2021-12-18 02:09:42 --> Output Class Initialized
INFO - 2021-12-18 02:09:42 --> Security Class Initialized
DEBUG - 2021-12-18 02:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:09:42 --> Input Class Initialized
INFO - 2021-12-18 02:09:42 --> Language Class Initialized
INFO - 2021-12-18 02:09:42 --> Language Class Initialized
INFO - 2021-12-18 02:09:42 --> Config Class Initialized
INFO - 2021-12-18 02:09:42 --> Loader Class Initialized
INFO - 2021-12-18 02:09:42 --> Helper loaded: url_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: file_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: form_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: my_helper
INFO - 2021-12-18 02:09:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:09:42 --> Controller Class Initialized
INFO - 2021-12-18 02:09:42 --> Config Class Initialized
INFO - 2021-12-18 02:09:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:09:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:09:42 --> Utf8 Class Initialized
INFO - 2021-12-18 02:09:42 --> URI Class Initialized
INFO - 2021-12-18 02:09:42 --> Router Class Initialized
INFO - 2021-12-18 02:09:42 --> Output Class Initialized
INFO - 2021-12-18 02:09:42 --> Security Class Initialized
DEBUG - 2021-12-18 02:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:09:42 --> Input Class Initialized
INFO - 2021-12-18 02:09:42 --> Language Class Initialized
INFO - 2021-12-18 02:09:42 --> Language Class Initialized
INFO - 2021-12-18 02:09:42 --> Config Class Initialized
INFO - 2021-12-18 02:09:42 --> Loader Class Initialized
INFO - 2021-12-18 02:09:42 --> Helper loaded: url_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: file_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: form_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: my_helper
INFO - 2021-12-18 02:09:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:09:42 --> Controller Class Initialized
DEBUG - 2021-12-18 02:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:09:42 --> Final output sent to browser
DEBUG - 2021-12-18 02:09:42 --> Total execution time: 0.0360
INFO - 2021-12-18 02:09:42 --> Config Class Initialized
INFO - 2021-12-18 02:09:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:09:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:09:42 --> Utf8 Class Initialized
INFO - 2021-12-18 02:09:42 --> URI Class Initialized
INFO - 2021-12-18 02:09:42 --> Router Class Initialized
INFO - 2021-12-18 02:09:42 --> Output Class Initialized
INFO - 2021-12-18 02:09:42 --> Security Class Initialized
DEBUG - 2021-12-18 02:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:09:42 --> Input Class Initialized
INFO - 2021-12-18 02:09:42 --> Language Class Initialized
INFO - 2021-12-18 02:09:42 --> Language Class Initialized
INFO - 2021-12-18 02:09:42 --> Config Class Initialized
INFO - 2021-12-18 02:09:42 --> Loader Class Initialized
INFO - 2021-12-18 02:09:42 --> Helper loaded: url_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: file_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: form_helper
INFO - 2021-12-18 02:09:42 --> Helper loaded: my_helper
INFO - 2021-12-18 02:09:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:09:42 --> Controller Class Initialized
INFO - 2021-12-18 02:10:32 --> Config Class Initialized
INFO - 2021-12-18 02:10:32 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:10:32 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:10:32 --> Utf8 Class Initialized
INFO - 2021-12-18 02:10:32 --> URI Class Initialized
INFO - 2021-12-18 02:10:32 --> Router Class Initialized
INFO - 2021-12-18 02:10:32 --> Output Class Initialized
INFO - 2021-12-18 02:10:32 --> Security Class Initialized
DEBUG - 2021-12-18 02:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:10:32 --> Input Class Initialized
INFO - 2021-12-18 02:10:32 --> Language Class Initialized
INFO - 2021-12-18 02:10:32 --> Language Class Initialized
INFO - 2021-12-18 02:10:32 --> Config Class Initialized
INFO - 2021-12-18 02:10:32 --> Loader Class Initialized
INFO - 2021-12-18 02:10:32 --> Helper loaded: url_helper
INFO - 2021-12-18 02:10:32 --> Helper loaded: file_helper
INFO - 2021-12-18 02:10:32 --> Helper loaded: form_helper
INFO - 2021-12-18 02:10:32 --> Helper loaded: my_helper
INFO - 2021-12-18 02:10:32 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:10:32 --> Controller Class Initialized
INFO - 2021-12-18 02:10:33 --> Config Class Initialized
INFO - 2021-12-18 02:10:33 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:10:33 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:10:33 --> Utf8 Class Initialized
INFO - 2021-12-18 02:10:33 --> URI Class Initialized
INFO - 2021-12-18 02:10:33 --> Router Class Initialized
INFO - 2021-12-18 02:10:33 --> Output Class Initialized
INFO - 2021-12-18 02:10:33 --> Security Class Initialized
DEBUG - 2021-12-18 02:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:10:33 --> Input Class Initialized
INFO - 2021-12-18 02:10:33 --> Language Class Initialized
INFO - 2021-12-18 02:10:33 --> Language Class Initialized
INFO - 2021-12-18 02:10:33 --> Config Class Initialized
INFO - 2021-12-18 02:10:33 --> Loader Class Initialized
INFO - 2021-12-18 02:10:33 --> Helper loaded: url_helper
INFO - 2021-12-18 02:10:33 --> Helper loaded: file_helper
INFO - 2021-12-18 02:10:33 --> Helper loaded: form_helper
INFO - 2021-12-18 02:10:33 --> Helper loaded: my_helper
INFO - 2021-12-18 02:10:33 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:10:33 --> Controller Class Initialized
INFO - 2021-12-18 02:10:34 --> Config Class Initialized
INFO - 2021-12-18 02:10:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:10:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:10:34 --> Utf8 Class Initialized
INFO - 2021-12-18 02:10:34 --> URI Class Initialized
INFO - 2021-12-18 02:10:34 --> Router Class Initialized
INFO - 2021-12-18 02:10:34 --> Output Class Initialized
INFO - 2021-12-18 02:10:34 --> Security Class Initialized
DEBUG - 2021-12-18 02:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:10:34 --> Input Class Initialized
INFO - 2021-12-18 02:10:34 --> Language Class Initialized
INFO - 2021-12-18 02:10:34 --> Language Class Initialized
INFO - 2021-12-18 02:10:34 --> Config Class Initialized
INFO - 2021-12-18 02:10:34 --> Loader Class Initialized
INFO - 2021-12-18 02:10:34 --> Helper loaded: url_helper
INFO - 2021-12-18 02:10:34 --> Helper loaded: file_helper
INFO - 2021-12-18 02:10:34 --> Helper loaded: form_helper
INFO - 2021-12-18 02:10:34 --> Helper loaded: my_helper
INFO - 2021-12-18 02:10:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:10:34 --> Controller Class Initialized
INFO - 2021-12-18 02:10:35 --> Config Class Initialized
INFO - 2021-12-18 02:10:35 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:10:35 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:10:35 --> Utf8 Class Initialized
INFO - 2021-12-18 02:10:35 --> URI Class Initialized
INFO - 2021-12-18 02:10:35 --> Router Class Initialized
INFO - 2021-12-18 02:10:35 --> Output Class Initialized
INFO - 2021-12-18 02:10:35 --> Security Class Initialized
DEBUG - 2021-12-18 02:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:10:35 --> Input Class Initialized
INFO - 2021-12-18 02:10:35 --> Language Class Initialized
INFO - 2021-12-18 02:10:35 --> Language Class Initialized
INFO - 2021-12-18 02:10:35 --> Config Class Initialized
INFO - 2021-12-18 02:10:35 --> Loader Class Initialized
INFO - 2021-12-18 02:10:35 --> Helper loaded: url_helper
INFO - 2021-12-18 02:10:35 --> Helper loaded: file_helper
INFO - 2021-12-18 02:10:35 --> Helper loaded: form_helper
INFO - 2021-12-18 02:10:35 --> Helper loaded: my_helper
INFO - 2021-12-18 02:10:35 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:10:35 --> Controller Class Initialized
INFO - 2021-12-18 02:10:35 --> Config Class Initialized
INFO - 2021-12-18 02:10:35 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:10:35 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:10:35 --> Utf8 Class Initialized
INFO - 2021-12-18 02:10:35 --> URI Class Initialized
INFO - 2021-12-18 02:10:35 --> Router Class Initialized
INFO - 2021-12-18 02:10:35 --> Output Class Initialized
INFO - 2021-12-18 02:10:35 --> Security Class Initialized
DEBUG - 2021-12-18 02:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:10:35 --> Input Class Initialized
INFO - 2021-12-18 02:10:35 --> Language Class Initialized
INFO - 2021-12-18 02:10:35 --> Language Class Initialized
INFO - 2021-12-18 02:10:35 --> Config Class Initialized
INFO - 2021-12-18 02:10:35 --> Loader Class Initialized
INFO - 2021-12-18 02:10:35 --> Helper loaded: url_helper
INFO - 2021-12-18 02:10:35 --> Helper loaded: file_helper
INFO - 2021-12-18 02:10:35 --> Helper loaded: form_helper
INFO - 2021-12-18 02:10:35 --> Helper loaded: my_helper
INFO - 2021-12-18 02:10:35 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:10:35 --> Controller Class Initialized
INFO - 2021-12-18 02:10:36 --> Config Class Initialized
INFO - 2021-12-18 02:10:36 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:10:36 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:10:36 --> Utf8 Class Initialized
INFO - 2021-12-18 02:10:36 --> URI Class Initialized
INFO - 2021-12-18 02:10:36 --> Router Class Initialized
INFO - 2021-12-18 02:10:36 --> Output Class Initialized
INFO - 2021-12-18 02:10:36 --> Security Class Initialized
DEBUG - 2021-12-18 02:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:10:36 --> Input Class Initialized
INFO - 2021-12-18 02:10:36 --> Language Class Initialized
INFO - 2021-12-18 02:10:36 --> Language Class Initialized
INFO - 2021-12-18 02:10:36 --> Config Class Initialized
INFO - 2021-12-18 02:10:36 --> Loader Class Initialized
INFO - 2021-12-18 02:10:36 --> Helper loaded: url_helper
INFO - 2021-12-18 02:10:36 --> Helper loaded: file_helper
INFO - 2021-12-18 02:10:36 --> Helper loaded: form_helper
INFO - 2021-12-18 02:10:36 --> Helper loaded: my_helper
INFO - 2021-12-18 02:10:36 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:10:36 --> Controller Class Initialized
INFO - 2021-12-18 02:10:36 --> Config Class Initialized
INFO - 2021-12-18 02:10:36 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:10:36 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:10:36 --> Utf8 Class Initialized
INFO - 2021-12-18 02:10:36 --> URI Class Initialized
INFO - 2021-12-18 02:10:36 --> Router Class Initialized
INFO - 2021-12-18 02:10:36 --> Output Class Initialized
INFO - 2021-12-18 02:10:36 --> Security Class Initialized
DEBUG - 2021-12-18 02:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:10:36 --> Input Class Initialized
INFO - 2021-12-18 02:10:36 --> Language Class Initialized
INFO - 2021-12-18 02:10:36 --> Language Class Initialized
INFO - 2021-12-18 02:10:36 --> Config Class Initialized
INFO - 2021-12-18 02:10:36 --> Loader Class Initialized
INFO - 2021-12-18 02:10:36 --> Helper loaded: url_helper
INFO - 2021-12-18 02:10:36 --> Helper loaded: file_helper
INFO - 2021-12-18 02:10:36 --> Helper loaded: form_helper
INFO - 2021-12-18 02:10:36 --> Helper loaded: my_helper
INFO - 2021-12-18 02:10:36 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:10:36 --> Controller Class Initialized
INFO - 2021-12-18 02:10:40 --> Config Class Initialized
INFO - 2021-12-18 02:10:40 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:10:40 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:10:40 --> Utf8 Class Initialized
INFO - 2021-12-18 02:10:40 --> URI Class Initialized
INFO - 2021-12-18 02:10:40 --> Router Class Initialized
INFO - 2021-12-18 02:10:40 --> Output Class Initialized
INFO - 2021-12-18 02:10:40 --> Security Class Initialized
DEBUG - 2021-12-18 02:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:10:40 --> Input Class Initialized
INFO - 2021-12-18 02:10:40 --> Language Class Initialized
INFO - 2021-12-18 02:10:40 --> Language Class Initialized
INFO - 2021-12-18 02:10:40 --> Config Class Initialized
INFO - 2021-12-18 02:10:40 --> Loader Class Initialized
INFO - 2021-12-18 02:10:40 --> Helper loaded: url_helper
INFO - 2021-12-18 02:10:40 --> Helper loaded: file_helper
INFO - 2021-12-18 02:10:40 --> Helper loaded: form_helper
INFO - 2021-12-18 02:10:40 --> Helper loaded: my_helper
INFO - 2021-12-18 02:10:40 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:10:40 --> Controller Class Initialized
DEBUG - 2021-12-18 02:10:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:10:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:10:40 --> Final output sent to browser
DEBUG - 2021-12-18 02:10:40 --> Total execution time: 0.0550
INFO - 2021-12-18 02:11:21 --> Config Class Initialized
INFO - 2021-12-18 02:11:21 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:11:21 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:11:21 --> Utf8 Class Initialized
INFO - 2021-12-18 02:11:21 --> URI Class Initialized
INFO - 2021-12-18 02:11:21 --> Router Class Initialized
INFO - 2021-12-18 02:11:21 --> Output Class Initialized
INFO - 2021-12-18 02:11:21 --> Security Class Initialized
DEBUG - 2021-12-18 02:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:11:21 --> Input Class Initialized
INFO - 2021-12-18 02:11:21 --> Language Class Initialized
INFO - 2021-12-18 02:11:21 --> Language Class Initialized
INFO - 2021-12-18 02:11:21 --> Config Class Initialized
INFO - 2021-12-18 02:11:21 --> Loader Class Initialized
INFO - 2021-12-18 02:11:21 --> Helper loaded: url_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: file_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: form_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: my_helper
INFO - 2021-12-18 02:11:21 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:11:21 --> Controller Class Initialized
INFO - 2021-12-18 02:11:21 --> Config Class Initialized
INFO - 2021-12-18 02:11:21 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:11:21 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:11:21 --> Utf8 Class Initialized
INFO - 2021-12-18 02:11:21 --> URI Class Initialized
INFO - 2021-12-18 02:11:21 --> Router Class Initialized
INFO - 2021-12-18 02:11:21 --> Output Class Initialized
INFO - 2021-12-18 02:11:21 --> Security Class Initialized
DEBUG - 2021-12-18 02:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:11:21 --> Input Class Initialized
INFO - 2021-12-18 02:11:21 --> Language Class Initialized
INFO - 2021-12-18 02:11:21 --> Language Class Initialized
INFO - 2021-12-18 02:11:21 --> Config Class Initialized
INFO - 2021-12-18 02:11:21 --> Loader Class Initialized
INFO - 2021-12-18 02:11:21 --> Helper loaded: url_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: file_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: form_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: my_helper
INFO - 2021-12-18 02:11:21 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:11:21 --> Controller Class Initialized
DEBUG - 2021-12-18 02:11:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:11:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:11:21 --> Final output sent to browser
DEBUG - 2021-12-18 02:11:21 --> Total execution time: 0.0380
INFO - 2021-12-18 02:11:21 --> Config Class Initialized
INFO - 2021-12-18 02:11:21 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:11:21 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:11:21 --> Utf8 Class Initialized
INFO - 2021-12-18 02:11:21 --> URI Class Initialized
INFO - 2021-12-18 02:11:21 --> Router Class Initialized
INFO - 2021-12-18 02:11:21 --> Output Class Initialized
INFO - 2021-12-18 02:11:21 --> Security Class Initialized
DEBUG - 2021-12-18 02:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:11:21 --> Input Class Initialized
INFO - 2021-12-18 02:11:21 --> Language Class Initialized
INFO - 2021-12-18 02:11:21 --> Language Class Initialized
INFO - 2021-12-18 02:11:21 --> Config Class Initialized
INFO - 2021-12-18 02:11:21 --> Loader Class Initialized
INFO - 2021-12-18 02:11:21 --> Helper loaded: url_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: file_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: form_helper
INFO - 2021-12-18 02:11:21 --> Helper loaded: my_helper
INFO - 2021-12-18 02:11:21 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:11:21 --> Controller Class Initialized
INFO - 2021-12-18 02:16:33 --> Config Class Initialized
INFO - 2021-12-18 02:16:33 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:16:33 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:16:33 --> Utf8 Class Initialized
INFO - 2021-12-18 02:16:33 --> URI Class Initialized
INFO - 2021-12-18 02:16:33 --> Router Class Initialized
INFO - 2021-12-18 02:16:33 --> Output Class Initialized
INFO - 2021-12-18 02:16:33 --> Security Class Initialized
DEBUG - 2021-12-18 02:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:16:33 --> Input Class Initialized
INFO - 2021-12-18 02:16:33 --> Language Class Initialized
INFO - 2021-12-18 02:16:33 --> Language Class Initialized
INFO - 2021-12-18 02:16:33 --> Config Class Initialized
INFO - 2021-12-18 02:16:33 --> Loader Class Initialized
INFO - 2021-12-18 02:16:33 --> Helper loaded: url_helper
INFO - 2021-12-18 02:16:33 --> Helper loaded: file_helper
INFO - 2021-12-18 02:16:33 --> Helper loaded: form_helper
INFO - 2021-12-18 02:16:33 --> Helper loaded: my_helper
INFO - 2021-12-18 02:16:33 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:16:33 --> Controller Class Initialized
DEBUG - 2021-12-18 02:16:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:16:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:16:33 --> Final output sent to browser
DEBUG - 2021-12-18 02:16:33 --> Total execution time: 0.0630
INFO - 2021-12-18 02:17:08 --> Config Class Initialized
INFO - 2021-12-18 02:17:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:08 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:08 --> URI Class Initialized
INFO - 2021-12-18 02:17:08 --> Router Class Initialized
INFO - 2021-12-18 02:17:08 --> Output Class Initialized
INFO - 2021-12-18 02:17:08 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:08 --> Input Class Initialized
INFO - 2021-12-18 02:17:08 --> Language Class Initialized
INFO - 2021-12-18 02:17:08 --> Language Class Initialized
INFO - 2021-12-18 02:17:08 --> Config Class Initialized
INFO - 2021-12-18 02:17:08 --> Loader Class Initialized
INFO - 2021-12-18 02:17:08 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:08 --> Controller Class Initialized
INFO - 2021-12-18 02:17:08 --> Config Class Initialized
INFO - 2021-12-18 02:17:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:08 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:08 --> URI Class Initialized
INFO - 2021-12-18 02:17:08 --> Router Class Initialized
INFO - 2021-12-18 02:17:08 --> Output Class Initialized
INFO - 2021-12-18 02:17:08 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:08 --> Input Class Initialized
INFO - 2021-12-18 02:17:08 --> Language Class Initialized
INFO - 2021-12-18 02:17:08 --> Language Class Initialized
INFO - 2021-12-18 02:17:08 --> Config Class Initialized
INFO - 2021-12-18 02:17:08 --> Loader Class Initialized
INFO - 2021-12-18 02:17:08 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:08 --> Controller Class Initialized
DEBUG - 2021-12-18 02:17:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:17:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:17:08 --> Final output sent to browser
DEBUG - 2021-12-18 02:17:08 --> Total execution time: 0.0370
INFO - 2021-12-18 02:17:08 --> Config Class Initialized
INFO - 2021-12-18 02:17:08 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:08 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:08 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:08 --> URI Class Initialized
INFO - 2021-12-18 02:17:08 --> Router Class Initialized
INFO - 2021-12-18 02:17:08 --> Output Class Initialized
INFO - 2021-12-18 02:17:08 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:08 --> Input Class Initialized
INFO - 2021-12-18 02:17:08 --> Language Class Initialized
INFO - 2021-12-18 02:17:08 --> Language Class Initialized
INFO - 2021-12-18 02:17:08 --> Config Class Initialized
INFO - 2021-12-18 02:17:08 --> Loader Class Initialized
INFO - 2021-12-18 02:17:08 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:08 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:08 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:08 --> Controller Class Initialized
INFO - 2021-12-18 02:17:10 --> Config Class Initialized
INFO - 2021-12-18 02:17:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:10 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:10 --> URI Class Initialized
INFO - 2021-12-18 02:17:10 --> Router Class Initialized
INFO - 2021-12-18 02:17:10 --> Output Class Initialized
INFO - 2021-12-18 02:17:10 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:10 --> Input Class Initialized
INFO - 2021-12-18 02:17:10 --> Language Class Initialized
INFO - 2021-12-18 02:17:10 --> Language Class Initialized
INFO - 2021-12-18 02:17:10 --> Config Class Initialized
INFO - 2021-12-18 02:17:10 --> Loader Class Initialized
INFO - 2021-12-18 02:17:10 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:10 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:10 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:10 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:10 --> Controller Class Initialized
INFO - 2021-12-18 02:17:10 --> Config Class Initialized
INFO - 2021-12-18 02:17:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:10 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:10 --> URI Class Initialized
INFO - 2021-12-18 02:17:10 --> Router Class Initialized
INFO - 2021-12-18 02:17:10 --> Output Class Initialized
INFO - 2021-12-18 02:17:10 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:10 --> Input Class Initialized
INFO - 2021-12-18 02:17:10 --> Language Class Initialized
INFO - 2021-12-18 02:17:10 --> Language Class Initialized
INFO - 2021-12-18 02:17:10 --> Config Class Initialized
INFO - 2021-12-18 02:17:10 --> Loader Class Initialized
INFO - 2021-12-18 02:17:10 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:10 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:10 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:10 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:10 --> Controller Class Initialized
INFO - 2021-12-18 02:17:11 --> Config Class Initialized
INFO - 2021-12-18 02:17:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:11 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:11 --> URI Class Initialized
INFO - 2021-12-18 02:17:11 --> Router Class Initialized
INFO - 2021-12-18 02:17:11 --> Output Class Initialized
INFO - 2021-12-18 02:17:11 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:11 --> Input Class Initialized
INFO - 2021-12-18 02:17:11 --> Language Class Initialized
INFO - 2021-12-18 02:17:11 --> Language Class Initialized
INFO - 2021-12-18 02:17:11 --> Config Class Initialized
INFO - 2021-12-18 02:17:11 --> Loader Class Initialized
INFO - 2021-12-18 02:17:11 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:11 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:11 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:11 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:11 --> Controller Class Initialized
INFO - 2021-12-18 02:17:16 --> Config Class Initialized
INFO - 2021-12-18 02:17:16 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:16 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:16 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:16 --> URI Class Initialized
INFO - 2021-12-18 02:17:16 --> Router Class Initialized
INFO - 2021-12-18 02:17:16 --> Output Class Initialized
INFO - 2021-12-18 02:17:16 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:16 --> Input Class Initialized
INFO - 2021-12-18 02:17:16 --> Language Class Initialized
INFO - 2021-12-18 02:17:16 --> Language Class Initialized
INFO - 2021-12-18 02:17:16 --> Config Class Initialized
INFO - 2021-12-18 02:17:16 --> Loader Class Initialized
INFO - 2021-12-18 02:17:16 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:16 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:16 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:16 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:16 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:16 --> Controller Class Initialized
DEBUG - 2021-12-18 02:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:17:16 --> Final output sent to browser
DEBUG - 2021-12-18 02:17:16 --> Total execution time: 0.0530
INFO - 2021-12-18 02:17:38 --> Config Class Initialized
INFO - 2021-12-18 02:17:38 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:38 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:38 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:38 --> URI Class Initialized
INFO - 2021-12-18 02:17:38 --> Router Class Initialized
INFO - 2021-12-18 02:17:38 --> Output Class Initialized
INFO - 2021-12-18 02:17:38 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:38 --> Input Class Initialized
INFO - 2021-12-18 02:17:38 --> Language Class Initialized
INFO - 2021-12-18 02:17:38 --> Language Class Initialized
INFO - 2021-12-18 02:17:38 --> Config Class Initialized
INFO - 2021-12-18 02:17:38 --> Loader Class Initialized
INFO - 2021-12-18 02:17:38 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:38 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:38 --> Controller Class Initialized
INFO - 2021-12-18 02:17:38 --> Config Class Initialized
INFO - 2021-12-18 02:17:38 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:38 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:38 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:38 --> URI Class Initialized
INFO - 2021-12-18 02:17:38 --> Router Class Initialized
INFO - 2021-12-18 02:17:38 --> Output Class Initialized
INFO - 2021-12-18 02:17:38 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:38 --> Input Class Initialized
INFO - 2021-12-18 02:17:38 --> Language Class Initialized
INFO - 2021-12-18 02:17:38 --> Language Class Initialized
INFO - 2021-12-18 02:17:38 --> Config Class Initialized
INFO - 2021-12-18 02:17:38 --> Loader Class Initialized
INFO - 2021-12-18 02:17:38 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:38 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:38 --> Controller Class Initialized
DEBUG - 2021-12-18 02:17:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:17:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:17:38 --> Final output sent to browser
DEBUG - 2021-12-18 02:17:38 --> Total execution time: 0.0370
INFO - 2021-12-18 02:17:38 --> Config Class Initialized
INFO - 2021-12-18 02:17:38 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:38 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:38 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:38 --> URI Class Initialized
INFO - 2021-12-18 02:17:38 --> Router Class Initialized
INFO - 2021-12-18 02:17:38 --> Output Class Initialized
INFO - 2021-12-18 02:17:38 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:38 --> Input Class Initialized
INFO - 2021-12-18 02:17:38 --> Language Class Initialized
INFO - 2021-12-18 02:17:38 --> Language Class Initialized
INFO - 2021-12-18 02:17:38 --> Config Class Initialized
INFO - 2021-12-18 02:17:38 --> Loader Class Initialized
INFO - 2021-12-18 02:17:38 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:38 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:38 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:38 --> Controller Class Initialized
INFO - 2021-12-18 02:17:39 --> Config Class Initialized
INFO - 2021-12-18 02:17:39 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:39 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:39 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:39 --> URI Class Initialized
INFO - 2021-12-18 02:17:39 --> Router Class Initialized
INFO - 2021-12-18 02:17:39 --> Output Class Initialized
INFO - 2021-12-18 02:17:39 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:39 --> Input Class Initialized
INFO - 2021-12-18 02:17:39 --> Language Class Initialized
INFO - 2021-12-18 02:17:39 --> Language Class Initialized
INFO - 2021-12-18 02:17:39 --> Config Class Initialized
INFO - 2021-12-18 02:17:39 --> Loader Class Initialized
INFO - 2021-12-18 02:17:39 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:39 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:39 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:39 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:39 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:39 --> Controller Class Initialized
DEBUG - 2021-12-18 02:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:17:39 --> Final output sent to browser
DEBUG - 2021-12-18 02:17:39 --> Total execution time: 0.0280
INFO - 2021-12-18 02:17:47 --> Config Class Initialized
INFO - 2021-12-18 02:17:47 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:47 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:47 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:47 --> URI Class Initialized
INFO - 2021-12-18 02:17:47 --> Router Class Initialized
INFO - 2021-12-18 02:17:47 --> Output Class Initialized
INFO - 2021-12-18 02:17:47 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:47 --> Input Class Initialized
INFO - 2021-12-18 02:17:47 --> Language Class Initialized
INFO - 2021-12-18 02:17:47 --> Language Class Initialized
INFO - 2021-12-18 02:17:47 --> Config Class Initialized
INFO - 2021-12-18 02:17:47 --> Loader Class Initialized
INFO - 2021-12-18 02:17:47 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:47 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:47 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:47 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:47 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:47 --> Controller Class Initialized
DEBUG - 2021-12-18 02:17:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:17:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:17:47 --> Final output sent to browser
DEBUG - 2021-12-18 02:17:47 --> Total execution time: 0.0410
INFO - 2021-12-18 02:17:47 --> Config Class Initialized
INFO - 2021-12-18 02:17:47 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:47 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:47 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:47 --> URI Class Initialized
INFO - 2021-12-18 02:17:47 --> Router Class Initialized
INFO - 2021-12-18 02:17:47 --> Output Class Initialized
INFO - 2021-12-18 02:17:47 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:47 --> Input Class Initialized
INFO - 2021-12-18 02:17:47 --> Language Class Initialized
INFO - 2021-12-18 02:17:47 --> Language Class Initialized
INFO - 2021-12-18 02:17:47 --> Config Class Initialized
INFO - 2021-12-18 02:17:47 --> Loader Class Initialized
INFO - 2021-12-18 02:17:47 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:47 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:47 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:47 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:47 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:47 --> Controller Class Initialized
INFO - 2021-12-18 02:17:48 --> Config Class Initialized
INFO - 2021-12-18 02:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:48 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:48 --> URI Class Initialized
INFO - 2021-12-18 02:17:48 --> Router Class Initialized
INFO - 2021-12-18 02:17:48 --> Output Class Initialized
INFO - 2021-12-18 02:17:48 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:48 --> Input Class Initialized
INFO - 2021-12-18 02:17:48 --> Language Class Initialized
INFO - 2021-12-18 02:17:48 --> Language Class Initialized
INFO - 2021-12-18 02:17:48 --> Config Class Initialized
INFO - 2021-12-18 02:17:48 --> Loader Class Initialized
INFO - 2021-12-18 02:17:48 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:48 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:48 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:48 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:48 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:48 --> Controller Class Initialized
INFO - 2021-12-18 02:17:48 --> Config Class Initialized
INFO - 2021-12-18 02:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:49 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:49 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:49 --> URI Class Initialized
INFO - 2021-12-18 02:17:49 --> Router Class Initialized
INFO - 2021-12-18 02:17:49 --> Output Class Initialized
INFO - 2021-12-18 02:17:49 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:49 --> Input Class Initialized
INFO - 2021-12-18 02:17:49 --> Language Class Initialized
INFO - 2021-12-18 02:17:49 --> Language Class Initialized
INFO - 2021-12-18 02:17:49 --> Config Class Initialized
INFO - 2021-12-18 02:17:49 --> Loader Class Initialized
INFO - 2021-12-18 02:17:49 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:49 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:49 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:49 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:49 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:49 --> Controller Class Initialized
INFO - 2021-12-18 02:17:49 --> Config Class Initialized
INFO - 2021-12-18 02:17:49 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:49 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:49 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:49 --> URI Class Initialized
INFO - 2021-12-18 02:17:49 --> Router Class Initialized
INFO - 2021-12-18 02:17:49 --> Output Class Initialized
INFO - 2021-12-18 02:17:49 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:49 --> Input Class Initialized
INFO - 2021-12-18 02:17:49 --> Language Class Initialized
INFO - 2021-12-18 02:17:49 --> Language Class Initialized
INFO - 2021-12-18 02:17:49 --> Config Class Initialized
INFO - 2021-12-18 02:17:49 --> Loader Class Initialized
INFO - 2021-12-18 02:17:49 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:49 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:49 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:49 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:49 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:49 --> Controller Class Initialized
INFO - 2021-12-18 02:17:50 --> Config Class Initialized
INFO - 2021-12-18 02:17:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:50 --> URI Class Initialized
INFO - 2021-12-18 02:17:50 --> Router Class Initialized
INFO - 2021-12-18 02:17:50 --> Output Class Initialized
INFO - 2021-12-18 02:17:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:50 --> Input Class Initialized
INFO - 2021-12-18 02:17:50 --> Language Class Initialized
INFO - 2021-12-18 02:17:50 --> Language Class Initialized
INFO - 2021-12-18 02:17:50 --> Config Class Initialized
INFO - 2021-12-18 02:17:50 --> Loader Class Initialized
INFO - 2021-12-18 02:17:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:50 --> Controller Class Initialized
INFO - 2021-12-18 02:17:50 --> Config Class Initialized
INFO - 2021-12-18 02:17:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:50 --> URI Class Initialized
INFO - 2021-12-18 02:17:50 --> Router Class Initialized
INFO - 2021-12-18 02:17:50 --> Output Class Initialized
INFO - 2021-12-18 02:17:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:50 --> Input Class Initialized
INFO - 2021-12-18 02:17:50 --> Language Class Initialized
INFO - 2021-12-18 02:17:50 --> Language Class Initialized
INFO - 2021-12-18 02:17:50 --> Config Class Initialized
INFO - 2021-12-18 02:17:50 --> Loader Class Initialized
INFO - 2021-12-18 02:17:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:50 --> Controller Class Initialized
INFO - 2021-12-18 02:17:50 --> Config Class Initialized
INFO - 2021-12-18 02:17:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:17:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:17:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:17:50 --> URI Class Initialized
INFO - 2021-12-18 02:17:50 --> Router Class Initialized
INFO - 2021-12-18 02:17:50 --> Output Class Initialized
INFO - 2021-12-18 02:17:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:17:50 --> Input Class Initialized
INFO - 2021-12-18 02:17:50 --> Language Class Initialized
INFO - 2021-12-18 02:17:50 --> Language Class Initialized
INFO - 2021-12-18 02:17:50 --> Config Class Initialized
INFO - 2021-12-18 02:17:50 --> Loader Class Initialized
INFO - 2021-12-18 02:17:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:17:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:17:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:17:51 --> Controller Class Initialized
INFO - 2021-12-18 02:18:07 --> Config Class Initialized
INFO - 2021-12-18 02:18:07 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:07 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:07 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:07 --> URI Class Initialized
INFO - 2021-12-18 02:18:07 --> Router Class Initialized
INFO - 2021-12-18 02:18:07 --> Output Class Initialized
INFO - 2021-12-18 02:18:07 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:07 --> Input Class Initialized
INFO - 2021-12-18 02:18:07 --> Language Class Initialized
INFO - 2021-12-18 02:18:07 --> Language Class Initialized
INFO - 2021-12-18 02:18:07 --> Config Class Initialized
INFO - 2021-12-18 02:18:07 --> Loader Class Initialized
INFO - 2021-12-18 02:18:07 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:07 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:07 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:07 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:07 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:07 --> Controller Class Initialized
DEBUG - 2021-12-18 02:18:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:18:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:18:07 --> Final output sent to browser
DEBUG - 2021-12-18 02:18:07 --> Total execution time: 0.0430
INFO - 2021-12-18 02:18:22 --> Config Class Initialized
INFO - 2021-12-18 02:18:22 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:22 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:22 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:22 --> URI Class Initialized
INFO - 2021-12-18 02:18:22 --> Router Class Initialized
INFO - 2021-12-18 02:18:22 --> Output Class Initialized
INFO - 2021-12-18 02:18:22 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:22 --> Input Class Initialized
INFO - 2021-12-18 02:18:22 --> Language Class Initialized
INFO - 2021-12-18 02:18:22 --> Language Class Initialized
INFO - 2021-12-18 02:18:22 --> Config Class Initialized
INFO - 2021-12-18 02:18:22 --> Loader Class Initialized
INFO - 2021-12-18 02:18:22 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:22 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:22 --> Controller Class Initialized
INFO - 2021-12-18 02:18:22 --> Config Class Initialized
INFO - 2021-12-18 02:18:22 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:22 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:22 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:22 --> URI Class Initialized
INFO - 2021-12-18 02:18:22 --> Router Class Initialized
INFO - 2021-12-18 02:18:22 --> Output Class Initialized
INFO - 2021-12-18 02:18:22 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:22 --> Input Class Initialized
INFO - 2021-12-18 02:18:22 --> Language Class Initialized
INFO - 2021-12-18 02:18:22 --> Language Class Initialized
INFO - 2021-12-18 02:18:22 --> Config Class Initialized
INFO - 2021-12-18 02:18:22 --> Loader Class Initialized
INFO - 2021-12-18 02:18:22 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:22 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:22 --> Controller Class Initialized
DEBUG - 2021-12-18 02:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:18:22 --> Final output sent to browser
DEBUG - 2021-12-18 02:18:22 --> Total execution time: 0.0350
INFO - 2021-12-18 02:18:22 --> Config Class Initialized
INFO - 2021-12-18 02:18:22 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:22 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:22 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:22 --> URI Class Initialized
INFO - 2021-12-18 02:18:22 --> Router Class Initialized
INFO - 2021-12-18 02:18:22 --> Output Class Initialized
INFO - 2021-12-18 02:18:22 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:22 --> Input Class Initialized
INFO - 2021-12-18 02:18:22 --> Language Class Initialized
INFO - 2021-12-18 02:18:22 --> Language Class Initialized
INFO - 2021-12-18 02:18:22 --> Config Class Initialized
INFO - 2021-12-18 02:18:22 --> Loader Class Initialized
INFO - 2021-12-18 02:18:22 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:22 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:22 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:22 --> Controller Class Initialized
INFO - 2021-12-18 02:18:23 --> Config Class Initialized
INFO - 2021-12-18 02:18:23 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:23 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:23 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:23 --> URI Class Initialized
INFO - 2021-12-18 02:18:24 --> Router Class Initialized
INFO - 2021-12-18 02:18:24 --> Output Class Initialized
INFO - 2021-12-18 02:18:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:24 --> Input Class Initialized
INFO - 2021-12-18 02:18:24 --> Language Class Initialized
INFO - 2021-12-18 02:18:24 --> Language Class Initialized
INFO - 2021-12-18 02:18:24 --> Config Class Initialized
INFO - 2021-12-18 02:18:24 --> Loader Class Initialized
INFO - 2021-12-18 02:18:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:24 --> Controller Class Initialized
INFO - 2021-12-18 02:18:24 --> Config Class Initialized
INFO - 2021-12-18 02:18:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:24 --> URI Class Initialized
INFO - 2021-12-18 02:18:24 --> Router Class Initialized
INFO - 2021-12-18 02:18:24 --> Output Class Initialized
INFO - 2021-12-18 02:18:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:24 --> Input Class Initialized
INFO - 2021-12-18 02:18:24 --> Language Class Initialized
INFO - 2021-12-18 02:18:24 --> Language Class Initialized
INFO - 2021-12-18 02:18:24 --> Config Class Initialized
INFO - 2021-12-18 02:18:24 --> Loader Class Initialized
INFO - 2021-12-18 02:18:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:24 --> Controller Class Initialized
INFO - 2021-12-18 02:18:25 --> Config Class Initialized
INFO - 2021-12-18 02:18:25 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:25 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:25 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:25 --> URI Class Initialized
INFO - 2021-12-18 02:18:25 --> Router Class Initialized
INFO - 2021-12-18 02:18:25 --> Output Class Initialized
INFO - 2021-12-18 02:18:25 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:25 --> Input Class Initialized
INFO - 2021-12-18 02:18:25 --> Language Class Initialized
INFO - 2021-12-18 02:18:25 --> Language Class Initialized
INFO - 2021-12-18 02:18:25 --> Config Class Initialized
INFO - 2021-12-18 02:18:25 --> Loader Class Initialized
INFO - 2021-12-18 02:18:25 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:25 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:25 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:25 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:25 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:25 --> Controller Class Initialized
INFO - 2021-12-18 02:18:30 --> Config Class Initialized
INFO - 2021-12-18 02:18:30 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:30 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:30 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:30 --> URI Class Initialized
INFO - 2021-12-18 02:18:30 --> Router Class Initialized
INFO - 2021-12-18 02:18:30 --> Output Class Initialized
INFO - 2021-12-18 02:18:30 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:30 --> Input Class Initialized
INFO - 2021-12-18 02:18:30 --> Language Class Initialized
INFO - 2021-12-18 02:18:30 --> Language Class Initialized
INFO - 2021-12-18 02:18:30 --> Config Class Initialized
INFO - 2021-12-18 02:18:30 --> Loader Class Initialized
INFO - 2021-12-18 02:18:30 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:30 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:30 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:30 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:30 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:30 --> Controller Class Initialized
INFO - 2021-12-18 02:18:31 --> Config Class Initialized
INFO - 2021-12-18 02:18:31 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:31 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:31 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:31 --> URI Class Initialized
INFO - 2021-12-18 02:18:31 --> Router Class Initialized
INFO - 2021-12-18 02:18:31 --> Output Class Initialized
INFO - 2021-12-18 02:18:31 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:31 --> Input Class Initialized
INFO - 2021-12-18 02:18:31 --> Language Class Initialized
INFO - 2021-12-18 02:18:31 --> Language Class Initialized
INFO - 2021-12-18 02:18:31 --> Config Class Initialized
INFO - 2021-12-18 02:18:31 --> Loader Class Initialized
INFO - 2021-12-18 02:18:31 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:31 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:31 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:31 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:31 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:31 --> Controller Class Initialized
INFO - 2021-12-18 02:18:32 --> Config Class Initialized
INFO - 2021-12-18 02:18:32 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:32 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:32 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:32 --> URI Class Initialized
INFO - 2021-12-18 02:18:32 --> Router Class Initialized
INFO - 2021-12-18 02:18:32 --> Output Class Initialized
INFO - 2021-12-18 02:18:32 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:32 --> Input Class Initialized
INFO - 2021-12-18 02:18:32 --> Language Class Initialized
INFO - 2021-12-18 02:18:32 --> Language Class Initialized
INFO - 2021-12-18 02:18:32 --> Config Class Initialized
INFO - 2021-12-18 02:18:32 --> Loader Class Initialized
INFO - 2021-12-18 02:18:32 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:32 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:32 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:32 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:32 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:32 --> Controller Class Initialized
INFO - 2021-12-18 02:18:38 --> Config Class Initialized
INFO - 2021-12-18 02:18:38 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:38 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:38 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:38 --> URI Class Initialized
INFO - 2021-12-18 02:18:38 --> Router Class Initialized
INFO - 2021-12-18 02:18:38 --> Output Class Initialized
INFO - 2021-12-18 02:18:38 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:38 --> Input Class Initialized
INFO - 2021-12-18 02:18:38 --> Language Class Initialized
INFO - 2021-12-18 02:18:38 --> Language Class Initialized
INFO - 2021-12-18 02:18:38 --> Config Class Initialized
INFO - 2021-12-18 02:18:38 --> Loader Class Initialized
INFO - 2021-12-18 02:18:38 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:38 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:38 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:38 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:38 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:38 --> Controller Class Initialized
INFO - 2021-12-18 02:18:39 --> Config Class Initialized
INFO - 2021-12-18 02:18:39 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:39 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:39 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:39 --> URI Class Initialized
INFO - 2021-12-18 02:18:39 --> Router Class Initialized
INFO - 2021-12-18 02:18:39 --> Output Class Initialized
INFO - 2021-12-18 02:18:39 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:39 --> Input Class Initialized
INFO - 2021-12-18 02:18:39 --> Language Class Initialized
INFO - 2021-12-18 02:18:39 --> Language Class Initialized
INFO - 2021-12-18 02:18:39 --> Config Class Initialized
INFO - 2021-12-18 02:18:39 --> Loader Class Initialized
INFO - 2021-12-18 02:18:39 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:39 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:39 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:39 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:39 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:39 --> Controller Class Initialized
INFO - 2021-12-18 02:18:39 --> Config Class Initialized
INFO - 2021-12-18 02:18:39 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:39 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:39 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:39 --> URI Class Initialized
INFO - 2021-12-18 02:18:39 --> Router Class Initialized
INFO - 2021-12-18 02:18:39 --> Output Class Initialized
INFO - 2021-12-18 02:18:39 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:39 --> Input Class Initialized
INFO - 2021-12-18 02:18:39 --> Language Class Initialized
INFO - 2021-12-18 02:18:39 --> Language Class Initialized
INFO - 2021-12-18 02:18:39 --> Config Class Initialized
INFO - 2021-12-18 02:18:39 --> Loader Class Initialized
INFO - 2021-12-18 02:18:39 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:39 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:39 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:39 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:39 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:39 --> Controller Class Initialized
INFO - 2021-12-18 02:18:40 --> Config Class Initialized
INFO - 2021-12-18 02:18:40 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:40 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:40 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:40 --> URI Class Initialized
INFO - 2021-12-18 02:18:40 --> Router Class Initialized
INFO - 2021-12-18 02:18:40 --> Output Class Initialized
INFO - 2021-12-18 02:18:40 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:40 --> Input Class Initialized
INFO - 2021-12-18 02:18:40 --> Language Class Initialized
INFO - 2021-12-18 02:18:40 --> Language Class Initialized
INFO - 2021-12-18 02:18:40 --> Config Class Initialized
INFO - 2021-12-18 02:18:40 --> Loader Class Initialized
INFO - 2021-12-18 02:18:40 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:40 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:40 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:40 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:40 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:40 --> Controller Class Initialized
INFO - 2021-12-18 02:18:41 --> Config Class Initialized
INFO - 2021-12-18 02:18:41 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:41 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:41 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:41 --> URI Class Initialized
INFO - 2021-12-18 02:18:41 --> Router Class Initialized
INFO - 2021-12-18 02:18:41 --> Output Class Initialized
INFO - 2021-12-18 02:18:41 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:41 --> Input Class Initialized
INFO - 2021-12-18 02:18:41 --> Language Class Initialized
INFO - 2021-12-18 02:18:41 --> Language Class Initialized
INFO - 2021-12-18 02:18:41 --> Config Class Initialized
INFO - 2021-12-18 02:18:41 --> Loader Class Initialized
INFO - 2021-12-18 02:18:41 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:41 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:41 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:41 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:41 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:41 --> Controller Class Initialized
INFO - 2021-12-18 02:18:41 --> Config Class Initialized
INFO - 2021-12-18 02:18:41 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:41 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:41 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:42 --> URI Class Initialized
INFO - 2021-12-18 02:18:42 --> Router Class Initialized
INFO - 2021-12-18 02:18:42 --> Output Class Initialized
INFO - 2021-12-18 02:18:42 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:42 --> Input Class Initialized
INFO - 2021-12-18 02:18:42 --> Language Class Initialized
INFO - 2021-12-18 02:18:42 --> Language Class Initialized
INFO - 2021-12-18 02:18:42 --> Config Class Initialized
INFO - 2021-12-18 02:18:42 --> Loader Class Initialized
INFO - 2021-12-18 02:18:42 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:42 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:42 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:42 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:42 --> Controller Class Initialized
INFO - 2021-12-18 02:18:43 --> Config Class Initialized
INFO - 2021-12-18 02:18:43 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:43 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:43 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:43 --> URI Class Initialized
INFO - 2021-12-18 02:18:43 --> Router Class Initialized
INFO - 2021-12-18 02:18:43 --> Output Class Initialized
INFO - 2021-12-18 02:18:43 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:43 --> Input Class Initialized
INFO - 2021-12-18 02:18:43 --> Language Class Initialized
INFO - 2021-12-18 02:18:43 --> Language Class Initialized
INFO - 2021-12-18 02:18:43 --> Config Class Initialized
INFO - 2021-12-18 02:18:43 --> Loader Class Initialized
INFO - 2021-12-18 02:18:43 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:43 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:43 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:43 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:43 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:43 --> Controller Class Initialized
INFO - 2021-12-18 02:18:43 --> Config Class Initialized
INFO - 2021-12-18 02:18:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:44 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:44 --> URI Class Initialized
INFO - 2021-12-18 02:18:44 --> Router Class Initialized
INFO - 2021-12-18 02:18:44 --> Output Class Initialized
INFO - 2021-12-18 02:18:44 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:44 --> Input Class Initialized
INFO - 2021-12-18 02:18:44 --> Language Class Initialized
INFO - 2021-12-18 02:18:44 --> Language Class Initialized
INFO - 2021-12-18 02:18:44 --> Config Class Initialized
INFO - 2021-12-18 02:18:44 --> Loader Class Initialized
INFO - 2021-12-18 02:18:44 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:44 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:44 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:44 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:44 --> Controller Class Initialized
INFO - 2021-12-18 02:18:44 --> Config Class Initialized
INFO - 2021-12-18 02:18:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:44 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:44 --> URI Class Initialized
INFO - 2021-12-18 02:18:44 --> Router Class Initialized
INFO - 2021-12-18 02:18:44 --> Output Class Initialized
INFO - 2021-12-18 02:18:44 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:44 --> Input Class Initialized
INFO - 2021-12-18 02:18:44 --> Language Class Initialized
INFO - 2021-12-18 02:18:44 --> Language Class Initialized
INFO - 2021-12-18 02:18:44 --> Config Class Initialized
INFO - 2021-12-18 02:18:44 --> Loader Class Initialized
INFO - 2021-12-18 02:18:44 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:44 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:44 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:44 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:44 --> Controller Class Initialized
INFO - 2021-12-18 02:18:46 --> Config Class Initialized
INFO - 2021-12-18 02:18:46 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:46 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:46 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:46 --> URI Class Initialized
INFO - 2021-12-18 02:18:46 --> Router Class Initialized
INFO - 2021-12-18 02:18:46 --> Output Class Initialized
INFO - 2021-12-18 02:18:46 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:46 --> Input Class Initialized
INFO - 2021-12-18 02:18:46 --> Language Class Initialized
INFO - 2021-12-18 02:18:46 --> Language Class Initialized
INFO - 2021-12-18 02:18:46 --> Config Class Initialized
INFO - 2021-12-18 02:18:46 --> Loader Class Initialized
INFO - 2021-12-18 02:18:46 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:46 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:46 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:46 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:46 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:46 --> Controller Class Initialized
DEBUG - 2021-12-18 02:18:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:18:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:18:46 --> Final output sent to browser
DEBUG - 2021-12-18 02:18:46 --> Total execution time: 0.0440
INFO - 2021-12-18 02:18:46 --> Config Class Initialized
INFO - 2021-12-18 02:18:46 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:46 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:46 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:46 --> URI Class Initialized
INFO - 2021-12-18 02:18:46 --> Router Class Initialized
INFO - 2021-12-18 02:18:46 --> Output Class Initialized
INFO - 2021-12-18 02:18:46 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:46 --> Input Class Initialized
INFO - 2021-12-18 02:18:46 --> Language Class Initialized
INFO - 2021-12-18 02:18:46 --> Language Class Initialized
INFO - 2021-12-18 02:18:46 --> Config Class Initialized
INFO - 2021-12-18 02:18:46 --> Loader Class Initialized
INFO - 2021-12-18 02:18:46 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:46 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:46 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:46 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:46 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:46 --> Controller Class Initialized
INFO - 2021-12-18 02:18:50 --> Config Class Initialized
INFO - 2021-12-18 02:18:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:50 --> URI Class Initialized
INFO - 2021-12-18 02:18:50 --> Router Class Initialized
INFO - 2021-12-18 02:18:50 --> Output Class Initialized
INFO - 2021-12-18 02:18:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:50 --> Input Class Initialized
INFO - 2021-12-18 02:18:50 --> Language Class Initialized
INFO - 2021-12-18 02:18:50 --> Language Class Initialized
INFO - 2021-12-18 02:18:50 --> Config Class Initialized
INFO - 2021-12-18 02:18:50 --> Loader Class Initialized
INFO - 2021-12-18 02:18:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:50 --> Controller Class Initialized
INFO - 2021-12-18 02:18:51 --> Config Class Initialized
INFO - 2021-12-18 02:18:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:51 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:51 --> URI Class Initialized
INFO - 2021-12-18 02:18:51 --> Router Class Initialized
INFO - 2021-12-18 02:18:51 --> Output Class Initialized
INFO - 2021-12-18 02:18:51 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:51 --> Input Class Initialized
INFO - 2021-12-18 02:18:51 --> Language Class Initialized
INFO - 2021-12-18 02:18:51 --> Language Class Initialized
INFO - 2021-12-18 02:18:51 --> Config Class Initialized
INFO - 2021-12-18 02:18:51 --> Loader Class Initialized
INFO - 2021-12-18 02:18:51 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:51 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:51 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:51 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:51 --> Controller Class Initialized
INFO - 2021-12-18 02:18:52 --> Config Class Initialized
INFO - 2021-12-18 02:18:52 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:52 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:52 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:52 --> URI Class Initialized
INFO - 2021-12-18 02:18:52 --> Router Class Initialized
INFO - 2021-12-18 02:18:52 --> Output Class Initialized
INFO - 2021-12-18 02:18:52 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:52 --> Input Class Initialized
INFO - 2021-12-18 02:18:52 --> Language Class Initialized
INFO - 2021-12-18 02:18:52 --> Language Class Initialized
INFO - 2021-12-18 02:18:52 --> Config Class Initialized
INFO - 2021-12-18 02:18:52 --> Loader Class Initialized
INFO - 2021-12-18 02:18:52 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:52 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:52 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:52 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:52 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:52 --> Controller Class Initialized
INFO - 2021-12-18 02:18:52 --> Config Class Initialized
INFO - 2021-12-18 02:18:52 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:52 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:52 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:52 --> URI Class Initialized
INFO - 2021-12-18 02:18:52 --> Router Class Initialized
INFO - 2021-12-18 02:18:52 --> Output Class Initialized
INFO - 2021-12-18 02:18:52 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:52 --> Input Class Initialized
INFO - 2021-12-18 02:18:52 --> Language Class Initialized
INFO - 2021-12-18 02:18:52 --> Language Class Initialized
INFO - 2021-12-18 02:18:52 --> Config Class Initialized
INFO - 2021-12-18 02:18:52 --> Loader Class Initialized
INFO - 2021-12-18 02:18:52 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:52 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:52 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:52 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:52 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:52 --> Controller Class Initialized
INFO - 2021-12-18 02:18:53 --> Config Class Initialized
INFO - 2021-12-18 02:18:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:53 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:53 --> URI Class Initialized
INFO - 2021-12-18 02:18:53 --> Router Class Initialized
INFO - 2021-12-18 02:18:53 --> Output Class Initialized
INFO - 2021-12-18 02:18:53 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:53 --> Input Class Initialized
INFO - 2021-12-18 02:18:53 --> Language Class Initialized
INFO - 2021-12-18 02:18:53 --> Language Class Initialized
INFO - 2021-12-18 02:18:53 --> Config Class Initialized
INFO - 2021-12-18 02:18:53 --> Loader Class Initialized
INFO - 2021-12-18 02:18:53 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:53 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:53 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:53 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:53 --> Controller Class Initialized
INFO - 2021-12-18 02:18:54 --> Config Class Initialized
INFO - 2021-12-18 02:18:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:18:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:18:54 --> Utf8 Class Initialized
INFO - 2021-12-18 02:18:54 --> URI Class Initialized
INFO - 2021-12-18 02:18:54 --> Router Class Initialized
INFO - 2021-12-18 02:18:54 --> Output Class Initialized
INFO - 2021-12-18 02:18:54 --> Security Class Initialized
DEBUG - 2021-12-18 02:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:18:54 --> Input Class Initialized
INFO - 2021-12-18 02:18:54 --> Language Class Initialized
INFO - 2021-12-18 02:18:54 --> Language Class Initialized
INFO - 2021-12-18 02:18:54 --> Config Class Initialized
INFO - 2021-12-18 02:18:54 --> Loader Class Initialized
INFO - 2021-12-18 02:18:54 --> Helper loaded: url_helper
INFO - 2021-12-18 02:18:54 --> Helper loaded: file_helper
INFO - 2021-12-18 02:18:54 --> Helper loaded: form_helper
INFO - 2021-12-18 02:18:54 --> Helper loaded: my_helper
INFO - 2021-12-18 02:18:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:18:54 --> Controller Class Initialized
INFO - 2021-12-18 02:19:12 --> Config Class Initialized
INFO - 2021-12-18 02:19:12 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:19:12 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:19:12 --> Utf8 Class Initialized
INFO - 2021-12-18 02:19:12 --> URI Class Initialized
INFO - 2021-12-18 02:19:12 --> Router Class Initialized
INFO - 2021-12-18 02:19:12 --> Output Class Initialized
INFO - 2021-12-18 02:19:12 --> Security Class Initialized
DEBUG - 2021-12-18 02:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:19:12 --> Input Class Initialized
INFO - 2021-12-18 02:19:12 --> Language Class Initialized
INFO - 2021-12-18 02:19:12 --> Language Class Initialized
INFO - 2021-12-18 02:19:12 --> Config Class Initialized
INFO - 2021-12-18 02:19:12 --> Loader Class Initialized
INFO - 2021-12-18 02:19:12 --> Helper loaded: url_helper
INFO - 2021-12-18 02:19:12 --> Helper loaded: file_helper
INFO - 2021-12-18 02:19:12 --> Helper loaded: form_helper
INFO - 2021-12-18 02:19:12 --> Helper loaded: my_helper
INFO - 2021-12-18 02:19:12 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:19:12 --> Controller Class Initialized
INFO - 2021-12-18 02:19:13 --> Config Class Initialized
INFO - 2021-12-18 02:19:13 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:19:13 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:19:13 --> Utf8 Class Initialized
INFO - 2021-12-18 02:19:13 --> URI Class Initialized
INFO - 2021-12-18 02:19:13 --> Router Class Initialized
INFO - 2021-12-18 02:19:13 --> Output Class Initialized
INFO - 2021-12-18 02:19:13 --> Security Class Initialized
DEBUG - 2021-12-18 02:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:19:13 --> Input Class Initialized
INFO - 2021-12-18 02:19:13 --> Language Class Initialized
INFO - 2021-12-18 02:19:13 --> Language Class Initialized
INFO - 2021-12-18 02:19:13 --> Config Class Initialized
INFO - 2021-12-18 02:19:13 --> Loader Class Initialized
INFO - 2021-12-18 02:19:13 --> Helper loaded: url_helper
INFO - 2021-12-18 02:19:13 --> Helper loaded: file_helper
INFO - 2021-12-18 02:19:13 --> Helper loaded: form_helper
INFO - 2021-12-18 02:19:13 --> Helper loaded: my_helper
INFO - 2021-12-18 02:19:13 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:19:13 --> Controller Class Initialized
INFO - 2021-12-18 02:19:53 --> Config Class Initialized
INFO - 2021-12-18 02:19:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:19:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:19:53 --> Utf8 Class Initialized
INFO - 2021-12-18 02:19:53 --> URI Class Initialized
INFO - 2021-12-18 02:19:53 --> Router Class Initialized
INFO - 2021-12-18 02:19:53 --> Output Class Initialized
INFO - 2021-12-18 02:19:53 --> Security Class Initialized
DEBUG - 2021-12-18 02:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:19:53 --> Input Class Initialized
INFO - 2021-12-18 02:19:53 --> Language Class Initialized
INFO - 2021-12-18 02:19:53 --> Language Class Initialized
INFO - 2021-12-18 02:19:53 --> Config Class Initialized
INFO - 2021-12-18 02:19:53 --> Loader Class Initialized
INFO - 2021-12-18 02:19:53 --> Helper loaded: url_helper
INFO - 2021-12-18 02:19:53 --> Helper loaded: file_helper
INFO - 2021-12-18 02:19:53 --> Helper loaded: form_helper
INFO - 2021-12-18 02:19:53 --> Helper loaded: my_helper
INFO - 2021-12-18 02:19:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:19:53 --> Controller Class Initialized
INFO - 2021-12-18 02:19:54 --> Config Class Initialized
INFO - 2021-12-18 02:19:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:19:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:19:54 --> Utf8 Class Initialized
INFO - 2021-12-18 02:19:54 --> URI Class Initialized
INFO - 2021-12-18 02:19:54 --> Router Class Initialized
INFO - 2021-12-18 02:19:54 --> Output Class Initialized
INFO - 2021-12-18 02:19:54 --> Security Class Initialized
DEBUG - 2021-12-18 02:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:19:54 --> Input Class Initialized
INFO - 2021-12-18 02:19:54 --> Language Class Initialized
INFO - 2021-12-18 02:19:54 --> Language Class Initialized
INFO - 2021-12-18 02:19:54 --> Config Class Initialized
INFO - 2021-12-18 02:19:54 --> Loader Class Initialized
INFO - 2021-12-18 02:19:54 --> Helper loaded: url_helper
INFO - 2021-12-18 02:19:54 --> Helper loaded: file_helper
INFO - 2021-12-18 02:19:54 --> Helper loaded: form_helper
INFO - 2021-12-18 02:19:54 --> Helper loaded: my_helper
INFO - 2021-12-18 02:19:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:19:54 --> Controller Class Initialized
INFO - 2021-12-18 02:19:55 --> Config Class Initialized
INFO - 2021-12-18 02:19:55 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:19:55 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:19:55 --> Utf8 Class Initialized
INFO - 2021-12-18 02:19:55 --> URI Class Initialized
INFO - 2021-12-18 02:19:55 --> Router Class Initialized
INFO - 2021-12-18 02:19:55 --> Output Class Initialized
INFO - 2021-12-18 02:19:55 --> Security Class Initialized
DEBUG - 2021-12-18 02:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:19:55 --> Input Class Initialized
INFO - 2021-12-18 02:19:55 --> Language Class Initialized
INFO - 2021-12-18 02:19:55 --> Language Class Initialized
INFO - 2021-12-18 02:19:55 --> Config Class Initialized
INFO - 2021-12-18 02:19:55 --> Loader Class Initialized
INFO - 2021-12-18 02:19:55 --> Helper loaded: url_helper
INFO - 2021-12-18 02:19:55 --> Helper loaded: file_helper
INFO - 2021-12-18 02:19:55 --> Helper loaded: form_helper
INFO - 2021-12-18 02:19:55 --> Helper loaded: my_helper
INFO - 2021-12-18 02:19:55 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:19:55 --> Controller Class Initialized
INFO - 2021-12-18 02:20:01 --> Config Class Initialized
INFO - 2021-12-18 02:20:01 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:20:01 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:20:01 --> Utf8 Class Initialized
INFO - 2021-12-18 02:20:01 --> URI Class Initialized
INFO - 2021-12-18 02:20:01 --> Router Class Initialized
INFO - 2021-12-18 02:20:01 --> Output Class Initialized
INFO - 2021-12-18 02:20:01 --> Security Class Initialized
DEBUG - 2021-12-18 02:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:20:01 --> Input Class Initialized
INFO - 2021-12-18 02:20:01 --> Language Class Initialized
INFO - 2021-12-18 02:20:01 --> Language Class Initialized
INFO - 2021-12-18 02:20:01 --> Config Class Initialized
INFO - 2021-12-18 02:20:01 --> Loader Class Initialized
INFO - 2021-12-18 02:20:01 --> Helper loaded: url_helper
INFO - 2021-12-18 02:20:01 --> Helper loaded: file_helper
INFO - 2021-12-18 02:20:01 --> Helper loaded: form_helper
INFO - 2021-12-18 02:20:01 --> Helper loaded: my_helper
INFO - 2021-12-18 02:20:01 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:20:01 --> Controller Class Initialized
INFO - 2021-12-18 02:20:03 --> Config Class Initialized
INFO - 2021-12-18 02:20:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:20:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:20:03 --> Utf8 Class Initialized
INFO - 2021-12-18 02:20:03 --> URI Class Initialized
INFO - 2021-12-18 02:20:03 --> Router Class Initialized
INFO - 2021-12-18 02:20:03 --> Output Class Initialized
INFO - 2021-12-18 02:20:03 --> Security Class Initialized
DEBUG - 2021-12-18 02:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:20:03 --> Input Class Initialized
INFO - 2021-12-18 02:20:03 --> Language Class Initialized
INFO - 2021-12-18 02:20:03 --> Language Class Initialized
INFO - 2021-12-18 02:20:03 --> Config Class Initialized
INFO - 2021-12-18 02:20:03 --> Loader Class Initialized
INFO - 2021-12-18 02:20:03 --> Helper loaded: url_helper
INFO - 2021-12-18 02:20:03 --> Helper loaded: file_helper
INFO - 2021-12-18 02:20:03 --> Helper loaded: form_helper
INFO - 2021-12-18 02:20:03 --> Helper loaded: my_helper
INFO - 2021-12-18 02:20:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:20:03 --> Controller Class Initialized
DEBUG - 2021-12-18 02:20:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:20:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:20:03 --> Final output sent to browser
DEBUG - 2021-12-18 02:20:03 --> Total execution time: 0.0480
INFO - 2021-12-18 02:20:46 --> Config Class Initialized
INFO - 2021-12-18 02:20:46 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:20:46 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:20:46 --> Utf8 Class Initialized
INFO - 2021-12-18 02:20:46 --> URI Class Initialized
INFO - 2021-12-18 02:20:46 --> Router Class Initialized
INFO - 2021-12-18 02:20:46 --> Output Class Initialized
INFO - 2021-12-18 02:20:46 --> Security Class Initialized
DEBUG - 2021-12-18 02:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:20:46 --> Input Class Initialized
INFO - 2021-12-18 02:20:46 --> Language Class Initialized
INFO - 2021-12-18 02:20:46 --> Language Class Initialized
INFO - 2021-12-18 02:20:46 --> Config Class Initialized
INFO - 2021-12-18 02:20:46 --> Loader Class Initialized
INFO - 2021-12-18 02:20:46 --> Helper loaded: url_helper
INFO - 2021-12-18 02:20:46 --> Helper loaded: file_helper
INFO - 2021-12-18 02:20:46 --> Helper loaded: form_helper
INFO - 2021-12-18 02:20:46 --> Helper loaded: my_helper
INFO - 2021-12-18 02:20:46 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:20:46 --> Controller Class Initialized
INFO - 2021-12-18 02:20:46 --> Config Class Initialized
INFO - 2021-12-18 02:20:46 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:20:46 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:20:46 --> Utf8 Class Initialized
INFO - 2021-12-18 02:20:46 --> URI Class Initialized
INFO - 2021-12-18 02:20:46 --> Router Class Initialized
INFO - 2021-12-18 02:20:46 --> Output Class Initialized
INFO - 2021-12-18 02:20:46 --> Security Class Initialized
DEBUG - 2021-12-18 02:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:20:46 --> Input Class Initialized
INFO - 2021-12-18 02:20:46 --> Language Class Initialized
INFO - 2021-12-18 02:20:46 --> Language Class Initialized
INFO - 2021-12-18 02:20:46 --> Config Class Initialized
INFO - 2021-12-18 02:20:46 --> Loader Class Initialized
INFO - 2021-12-18 02:20:46 --> Helper loaded: url_helper
INFO - 2021-12-18 02:20:46 --> Helper loaded: file_helper
INFO - 2021-12-18 02:20:46 --> Helper loaded: form_helper
INFO - 2021-12-18 02:20:46 --> Helper loaded: my_helper
INFO - 2021-12-18 02:20:46 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:20:46 --> Controller Class Initialized
DEBUG - 2021-12-18 02:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:20:46 --> Final output sent to browser
DEBUG - 2021-12-18 02:20:46 --> Total execution time: 0.0260
INFO - 2021-12-18 02:20:47 --> Config Class Initialized
INFO - 2021-12-18 02:20:47 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:20:47 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:20:47 --> Utf8 Class Initialized
INFO - 2021-12-18 02:20:47 --> URI Class Initialized
INFO - 2021-12-18 02:20:47 --> Router Class Initialized
INFO - 2021-12-18 02:20:47 --> Output Class Initialized
INFO - 2021-12-18 02:20:47 --> Security Class Initialized
DEBUG - 2021-12-18 02:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:20:47 --> Input Class Initialized
INFO - 2021-12-18 02:20:47 --> Language Class Initialized
INFO - 2021-12-18 02:20:47 --> Language Class Initialized
INFO - 2021-12-18 02:20:47 --> Config Class Initialized
INFO - 2021-12-18 02:20:47 --> Loader Class Initialized
INFO - 2021-12-18 02:20:47 --> Helper loaded: url_helper
INFO - 2021-12-18 02:20:47 --> Helper loaded: file_helper
INFO - 2021-12-18 02:20:47 --> Helper loaded: form_helper
INFO - 2021-12-18 02:20:47 --> Helper loaded: my_helper
INFO - 2021-12-18 02:20:47 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:20:47 --> Controller Class Initialized
INFO - 2021-12-18 02:21:24 --> Config Class Initialized
INFO - 2021-12-18 02:21:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:21:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:21:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:21:24 --> URI Class Initialized
INFO - 2021-12-18 02:21:24 --> Router Class Initialized
INFO - 2021-12-18 02:21:24 --> Output Class Initialized
INFO - 2021-12-18 02:21:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:21:24 --> Input Class Initialized
INFO - 2021-12-18 02:21:24 --> Language Class Initialized
INFO - 2021-12-18 02:21:24 --> Language Class Initialized
INFO - 2021-12-18 02:21:24 --> Config Class Initialized
INFO - 2021-12-18 02:21:24 --> Loader Class Initialized
INFO - 2021-12-18 02:21:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:21:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:21:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:21:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:21:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:21:24 --> Controller Class Initialized
INFO - 2021-12-18 02:21:24 --> Config Class Initialized
INFO - 2021-12-18 02:21:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:21:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:21:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:21:24 --> URI Class Initialized
INFO - 2021-12-18 02:21:24 --> Router Class Initialized
INFO - 2021-12-18 02:21:24 --> Output Class Initialized
INFO - 2021-12-18 02:21:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:21:24 --> Input Class Initialized
INFO - 2021-12-18 02:21:24 --> Language Class Initialized
INFO - 2021-12-18 02:21:24 --> Language Class Initialized
INFO - 2021-12-18 02:21:24 --> Config Class Initialized
INFO - 2021-12-18 02:21:24 --> Loader Class Initialized
INFO - 2021-12-18 02:21:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:21:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:21:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:21:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:21:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:21:24 --> Controller Class Initialized
INFO - 2021-12-18 02:21:25 --> Config Class Initialized
INFO - 2021-12-18 02:21:25 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:21:25 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:21:25 --> Utf8 Class Initialized
INFO - 2021-12-18 02:21:25 --> URI Class Initialized
INFO - 2021-12-18 02:21:25 --> Router Class Initialized
INFO - 2021-12-18 02:21:25 --> Output Class Initialized
INFO - 2021-12-18 02:21:25 --> Security Class Initialized
DEBUG - 2021-12-18 02:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:21:25 --> Input Class Initialized
INFO - 2021-12-18 02:21:25 --> Language Class Initialized
INFO - 2021-12-18 02:21:25 --> Language Class Initialized
INFO - 2021-12-18 02:21:25 --> Config Class Initialized
INFO - 2021-12-18 02:21:25 --> Loader Class Initialized
INFO - 2021-12-18 02:21:25 --> Helper loaded: url_helper
INFO - 2021-12-18 02:21:25 --> Helper loaded: file_helper
INFO - 2021-12-18 02:21:25 --> Helper loaded: form_helper
INFO - 2021-12-18 02:21:25 --> Helper loaded: my_helper
INFO - 2021-12-18 02:21:25 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:21:25 --> Controller Class Initialized
INFO - 2021-12-18 02:21:25 --> Config Class Initialized
INFO - 2021-12-18 02:21:25 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:21:25 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:21:25 --> Utf8 Class Initialized
INFO - 2021-12-18 02:21:25 --> URI Class Initialized
INFO - 2021-12-18 02:21:25 --> Router Class Initialized
INFO - 2021-12-18 02:21:25 --> Output Class Initialized
INFO - 2021-12-18 02:21:25 --> Security Class Initialized
DEBUG - 2021-12-18 02:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:21:25 --> Input Class Initialized
INFO - 2021-12-18 02:21:25 --> Language Class Initialized
INFO - 2021-12-18 02:21:25 --> Language Class Initialized
INFO - 2021-12-18 02:21:25 --> Config Class Initialized
INFO - 2021-12-18 02:21:25 --> Loader Class Initialized
INFO - 2021-12-18 02:21:25 --> Helper loaded: url_helper
INFO - 2021-12-18 02:21:25 --> Helper loaded: file_helper
INFO - 2021-12-18 02:21:25 --> Helper loaded: form_helper
INFO - 2021-12-18 02:21:25 --> Helper loaded: my_helper
INFO - 2021-12-18 02:21:25 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:21:25 --> Controller Class Initialized
INFO - 2021-12-18 02:21:33 --> Config Class Initialized
INFO - 2021-12-18 02:21:33 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:21:33 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:21:33 --> Utf8 Class Initialized
INFO - 2021-12-18 02:21:33 --> URI Class Initialized
INFO - 2021-12-18 02:21:33 --> Router Class Initialized
INFO - 2021-12-18 02:21:33 --> Output Class Initialized
INFO - 2021-12-18 02:21:33 --> Security Class Initialized
DEBUG - 2021-12-18 02:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:21:33 --> Input Class Initialized
INFO - 2021-12-18 02:21:33 --> Language Class Initialized
INFO - 2021-12-18 02:21:33 --> Language Class Initialized
INFO - 2021-12-18 02:21:33 --> Config Class Initialized
INFO - 2021-12-18 02:21:33 --> Loader Class Initialized
INFO - 2021-12-18 02:21:33 --> Helper loaded: url_helper
INFO - 2021-12-18 02:21:33 --> Helper loaded: file_helper
INFO - 2021-12-18 02:21:33 --> Helper loaded: form_helper
INFO - 2021-12-18 02:21:33 --> Helper loaded: my_helper
INFO - 2021-12-18 02:21:33 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:21:33 --> Controller Class Initialized
DEBUG - 2021-12-18 02:21:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:21:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:21:33 --> Final output sent to browser
DEBUG - 2021-12-18 02:21:33 --> Total execution time: 0.0290
INFO - 2021-12-18 02:22:00 --> Config Class Initialized
INFO - 2021-12-18 02:22:00 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:22:00 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:22:00 --> Utf8 Class Initialized
INFO - 2021-12-18 02:22:00 --> URI Class Initialized
INFO - 2021-12-18 02:22:00 --> Router Class Initialized
INFO - 2021-12-18 02:22:00 --> Output Class Initialized
INFO - 2021-12-18 02:22:00 --> Security Class Initialized
DEBUG - 2021-12-18 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:22:00 --> Input Class Initialized
INFO - 2021-12-18 02:22:00 --> Language Class Initialized
INFO - 2021-12-18 02:22:00 --> Language Class Initialized
INFO - 2021-12-18 02:22:00 --> Config Class Initialized
INFO - 2021-12-18 02:22:00 --> Loader Class Initialized
INFO - 2021-12-18 02:22:00 --> Helper loaded: url_helper
INFO - 2021-12-18 02:22:00 --> Helper loaded: file_helper
INFO - 2021-12-18 02:22:00 --> Helper loaded: form_helper
INFO - 2021-12-18 02:22:00 --> Helper loaded: my_helper
INFO - 2021-12-18 02:22:00 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:22:00 --> Controller Class Initialized
INFO - 2021-12-18 02:22:00 --> Config Class Initialized
INFO - 2021-12-18 02:22:00 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:22:00 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:22:00 --> Utf8 Class Initialized
INFO - 2021-12-18 02:22:01 --> URI Class Initialized
INFO - 2021-12-18 02:22:01 --> Router Class Initialized
INFO - 2021-12-18 02:22:01 --> Output Class Initialized
INFO - 2021-12-18 02:22:01 --> Security Class Initialized
DEBUG - 2021-12-18 02:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:22:01 --> Input Class Initialized
INFO - 2021-12-18 02:22:01 --> Language Class Initialized
INFO - 2021-12-18 02:22:01 --> Language Class Initialized
INFO - 2021-12-18 02:22:01 --> Config Class Initialized
INFO - 2021-12-18 02:22:01 --> Loader Class Initialized
INFO - 2021-12-18 02:22:01 --> Helper loaded: url_helper
INFO - 2021-12-18 02:22:01 --> Helper loaded: file_helper
INFO - 2021-12-18 02:22:01 --> Helper loaded: form_helper
INFO - 2021-12-18 02:22:01 --> Helper loaded: my_helper
INFO - 2021-12-18 02:22:01 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:22:01 --> Controller Class Initialized
DEBUG - 2021-12-18 02:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:22:01 --> Final output sent to browser
DEBUG - 2021-12-18 02:22:01 --> Total execution time: 0.0350
INFO - 2021-12-18 02:22:01 --> Config Class Initialized
INFO - 2021-12-18 02:22:01 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:22:01 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:22:01 --> Utf8 Class Initialized
INFO - 2021-12-18 02:22:01 --> URI Class Initialized
INFO - 2021-12-18 02:22:01 --> Router Class Initialized
INFO - 2021-12-18 02:22:01 --> Output Class Initialized
INFO - 2021-12-18 02:22:01 --> Security Class Initialized
DEBUG - 2021-12-18 02:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:22:01 --> Input Class Initialized
INFO - 2021-12-18 02:22:01 --> Language Class Initialized
INFO - 2021-12-18 02:22:01 --> Language Class Initialized
INFO - 2021-12-18 02:22:01 --> Config Class Initialized
INFO - 2021-12-18 02:22:01 --> Loader Class Initialized
INFO - 2021-12-18 02:22:01 --> Helper loaded: url_helper
INFO - 2021-12-18 02:22:01 --> Helper loaded: file_helper
INFO - 2021-12-18 02:22:01 --> Helper loaded: form_helper
INFO - 2021-12-18 02:22:01 --> Helper loaded: my_helper
INFO - 2021-12-18 02:22:01 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:22:01 --> Controller Class Initialized
INFO - 2021-12-18 02:22:13 --> Config Class Initialized
INFO - 2021-12-18 02:22:13 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:22:13 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:22:13 --> Utf8 Class Initialized
INFO - 2021-12-18 02:22:13 --> URI Class Initialized
INFO - 2021-12-18 02:22:13 --> Router Class Initialized
INFO - 2021-12-18 02:22:13 --> Output Class Initialized
INFO - 2021-12-18 02:22:13 --> Security Class Initialized
DEBUG - 2021-12-18 02:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:22:13 --> Input Class Initialized
INFO - 2021-12-18 02:22:13 --> Language Class Initialized
INFO - 2021-12-18 02:22:13 --> Language Class Initialized
INFO - 2021-12-18 02:22:13 --> Config Class Initialized
INFO - 2021-12-18 02:22:13 --> Loader Class Initialized
INFO - 2021-12-18 02:22:13 --> Helper loaded: url_helper
INFO - 2021-12-18 02:22:13 --> Helper loaded: file_helper
INFO - 2021-12-18 02:22:13 --> Helper loaded: form_helper
INFO - 2021-12-18 02:22:13 --> Helper loaded: my_helper
INFO - 2021-12-18 02:22:13 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:22:13 --> Controller Class Initialized
DEBUG - 2021-12-18 02:22:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:22:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:22:13 --> Final output sent to browser
DEBUG - 2021-12-18 02:22:13 --> Total execution time: 0.0440
INFO - 2021-12-18 02:23:11 --> Config Class Initialized
INFO - 2021-12-18 02:23:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:23:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:23:11 --> Utf8 Class Initialized
INFO - 2021-12-18 02:23:11 --> URI Class Initialized
INFO - 2021-12-18 02:23:11 --> Router Class Initialized
INFO - 2021-12-18 02:23:11 --> Output Class Initialized
INFO - 2021-12-18 02:23:11 --> Security Class Initialized
DEBUG - 2021-12-18 02:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:23:11 --> Input Class Initialized
INFO - 2021-12-18 02:23:11 --> Language Class Initialized
INFO - 2021-12-18 02:23:11 --> Language Class Initialized
INFO - 2021-12-18 02:23:11 --> Config Class Initialized
INFO - 2021-12-18 02:23:11 --> Loader Class Initialized
INFO - 2021-12-18 02:23:11 --> Helper loaded: url_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: file_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: form_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: my_helper
INFO - 2021-12-18 02:23:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:23:11 --> Controller Class Initialized
INFO - 2021-12-18 02:23:11 --> Config Class Initialized
INFO - 2021-12-18 02:23:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:23:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:23:11 --> Utf8 Class Initialized
INFO - 2021-12-18 02:23:11 --> URI Class Initialized
INFO - 2021-12-18 02:23:11 --> Router Class Initialized
INFO - 2021-12-18 02:23:11 --> Output Class Initialized
INFO - 2021-12-18 02:23:11 --> Security Class Initialized
DEBUG - 2021-12-18 02:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:23:11 --> Input Class Initialized
INFO - 2021-12-18 02:23:11 --> Language Class Initialized
INFO - 2021-12-18 02:23:11 --> Language Class Initialized
INFO - 2021-12-18 02:23:11 --> Config Class Initialized
INFO - 2021-12-18 02:23:11 --> Loader Class Initialized
INFO - 2021-12-18 02:23:11 --> Helper loaded: url_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: file_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: form_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: my_helper
INFO - 2021-12-18 02:23:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:23:11 --> Controller Class Initialized
DEBUG - 2021-12-18 02:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:23:11 --> Final output sent to browser
DEBUG - 2021-12-18 02:23:11 --> Total execution time: 0.0360
INFO - 2021-12-18 02:23:11 --> Config Class Initialized
INFO - 2021-12-18 02:23:11 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:23:11 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:23:11 --> Utf8 Class Initialized
INFO - 2021-12-18 02:23:11 --> URI Class Initialized
INFO - 2021-12-18 02:23:11 --> Router Class Initialized
INFO - 2021-12-18 02:23:11 --> Output Class Initialized
INFO - 2021-12-18 02:23:11 --> Security Class Initialized
DEBUG - 2021-12-18 02:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:23:11 --> Input Class Initialized
INFO - 2021-12-18 02:23:11 --> Language Class Initialized
INFO - 2021-12-18 02:23:11 --> Language Class Initialized
INFO - 2021-12-18 02:23:11 --> Config Class Initialized
INFO - 2021-12-18 02:23:11 --> Loader Class Initialized
INFO - 2021-12-18 02:23:11 --> Helper loaded: url_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: file_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: form_helper
INFO - 2021-12-18 02:23:11 --> Helper loaded: my_helper
INFO - 2021-12-18 02:23:11 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:23:11 --> Controller Class Initialized
INFO - 2021-12-18 02:23:50 --> Config Class Initialized
INFO - 2021-12-18 02:23:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:23:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:23:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:23:50 --> URI Class Initialized
INFO - 2021-12-18 02:23:50 --> Router Class Initialized
INFO - 2021-12-18 02:23:50 --> Output Class Initialized
INFO - 2021-12-18 02:23:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:23:50 --> Input Class Initialized
INFO - 2021-12-18 02:23:50 --> Language Class Initialized
INFO - 2021-12-18 02:23:50 --> Language Class Initialized
INFO - 2021-12-18 02:23:50 --> Config Class Initialized
INFO - 2021-12-18 02:23:50 --> Loader Class Initialized
INFO - 2021-12-18 02:23:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:23:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:23:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:23:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:23:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:23:50 --> Controller Class Initialized
DEBUG - 2021-12-18 02:23:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:23:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:23:50 --> Final output sent to browser
DEBUG - 2021-12-18 02:23:50 --> Total execution time: 0.0390
INFO - 2021-12-18 02:25:42 --> Config Class Initialized
INFO - 2021-12-18 02:25:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:25:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:25:42 --> Utf8 Class Initialized
INFO - 2021-12-18 02:25:42 --> URI Class Initialized
INFO - 2021-12-18 02:25:42 --> Router Class Initialized
INFO - 2021-12-18 02:25:42 --> Output Class Initialized
INFO - 2021-12-18 02:25:42 --> Security Class Initialized
DEBUG - 2021-12-18 02:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:25:42 --> Input Class Initialized
INFO - 2021-12-18 02:25:42 --> Language Class Initialized
INFO - 2021-12-18 02:25:42 --> Language Class Initialized
INFO - 2021-12-18 02:25:42 --> Config Class Initialized
INFO - 2021-12-18 02:25:42 --> Loader Class Initialized
INFO - 2021-12-18 02:25:42 --> Helper loaded: url_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: file_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: form_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: my_helper
INFO - 2021-12-18 02:25:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:25:42 --> Controller Class Initialized
INFO - 2021-12-18 02:25:42 --> Config Class Initialized
INFO - 2021-12-18 02:25:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:25:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:25:42 --> Utf8 Class Initialized
INFO - 2021-12-18 02:25:42 --> URI Class Initialized
INFO - 2021-12-18 02:25:42 --> Router Class Initialized
INFO - 2021-12-18 02:25:42 --> Output Class Initialized
INFO - 2021-12-18 02:25:42 --> Security Class Initialized
DEBUG - 2021-12-18 02:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:25:42 --> Input Class Initialized
INFO - 2021-12-18 02:25:42 --> Language Class Initialized
INFO - 2021-12-18 02:25:42 --> Language Class Initialized
INFO - 2021-12-18 02:25:42 --> Config Class Initialized
INFO - 2021-12-18 02:25:42 --> Loader Class Initialized
INFO - 2021-12-18 02:25:42 --> Helper loaded: url_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: file_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: form_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: my_helper
INFO - 2021-12-18 02:25:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:25:42 --> Controller Class Initialized
DEBUG - 2021-12-18 02:25:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:25:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:25:42 --> Final output sent to browser
DEBUG - 2021-12-18 02:25:42 --> Total execution time: 0.0360
INFO - 2021-12-18 02:25:42 --> Config Class Initialized
INFO - 2021-12-18 02:25:42 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:25:42 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:25:42 --> Utf8 Class Initialized
INFO - 2021-12-18 02:25:42 --> URI Class Initialized
INFO - 2021-12-18 02:25:42 --> Router Class Initialized
INFO - 2021-12-18 02:25:42 --> Output Class Initialized
INFO - 2021-12-18 02:25:42 --> Security Class Initialized
DEBUG - 2021-12-18 02:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:25:42 --> Input Class Initialized
INFO - 2021-12-18 02:25:42 --> Language Class Initialized
INFO - 2021-12-18 02:25:42 --> Language Class Initialized
INFO - 2021-12-18 02:25:42 --> Config Class Initialized
INFO - 2021-12-18 02:25:42 --> Loader Class Initialized
INFO - 2021-12-18 02:25:42 --> Helper loaded: url_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: file_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: form_helper
INFO - 2021-12-18 02:25:42 --> Helper loaded: my_helper
INFO - 2021-12-18 02:25:42 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:25:42 --> Controller Class Initialized
INFO - 2021-12-18 02:25:44 --> Config Class Initialized
INFO - 2021-12-18 02:25:44 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:25:44 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:25:44 --> Utf8 Class Initialized
INFO - 2021-12-18 02:25:44 --> URI Class Initialized
INFO - 2021-12-18 02:25:44 --> Router Class Initialized
INFO - 2021-12-18 02:25:44 --> Output Class Initialized
INFO - 2021-12-18 02:25:44 --> Security Class Initialized
DEBUG - 2021-12-18 02:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:25:44 --> Input Class Initialized
INFO - 2021-12-18 02:25:44 --> Language Class Initialized
INFO - 2021-12-18 02:25:44 --> Language Class Initialized
INFO - 2021-12-18 02:25:44 --> Config Class Initialized
INFO - 2021-12-18 02:25:44 --> Loader Class Initialized
INFO - 2021-12-18 02:25:44 --> Helper loaded: url_helper
INFO - 2021-12-18 02:25:44 --> Helper loaded: file_helper
INFO - 2021-12-18 02:25:44 --> Helper loaded: form_helper
INFO - 2021-12-18 02:25:44 --> Helper loaded: my_helper
INFO - 2021-12-18 02:25:44 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:25:44 --> Controller Class Initialized
DEBUG - 2021-12-18 02:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:25:44 --> Final output sent to browser
DEBUG - 2021-12-18 02:25:44 --> Total execution time: 0.0450
INFO - 2021-12-18 02:26:17 --> Config Class Initialized
INFO - 2021-12-18 02:26:17 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:26:17 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:26:17 --> Utf8 Class Initialized
INFO - 2021-12-18 02:26:17 --> URI Class Initialized
INFO - 2021-12-18 02:26:17 --> Router Class Initialized
INFO - 2021-12-18 02:26:17 --> Output Class Initialized
INFO - 2021-12-18 02:26:17 --> Security Class Initialized
DEBUG - 2021-12-18 02:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:26:17 --> Input Class Initialized
INFO - 2021-12-18 02:26:17 --> Language Class Initialized
INFO - 2021-12-18 02:26:17 --> Language Class Initialized
INFO - 2021-12-18 02:26:17 --> Config Class Initialized
INFO - 2021-12-18 02:26:17 --> Loader Class Initialized
INFO - 2021-12-18 02:26:17 --> Helper loaded: url_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: file_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: form_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: my_helper
INFO - 2021-12-18 02:26:17 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:26:17 --> Controller Class Initialized
INFO - 2021-12-18 02:26:17 --> Config Class Initialized
INFO - 2021-12-18 02:26:17 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:26:17 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:26:17 --> Utf8 Class Initialized
INFO - 2021-12-18 02:26:17 --> URI Class Initialized
INFO - 2021-12-18 02:26:17 --> Router Class Initialized
INFO - 2021-12-18 02:26:17 --> Output Class Initialized
INFO - 2021-12-18 02:26:17 --> Security Class Initialized
DEBUG - 2021-12-18 02:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:26:17 --> Input Class Initialized
INFO - 2021-12-18 02:26:17 --> Language Class Initialized
INFO - 2021-12-18 02:26:17 --> Language Class Initialized
INFO - 2021-12-18 02:26:17 --> Config Class Initialized
INFO - 2021-12-18 02:26:17 --> Loader Class Initialized
INFO - 2021-12-18 02:26:17 --> Helper loaded: url_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: file_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: form_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: my_helper
INFO - 2021-12-18 02:26:17 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:26:17 --> Controller Class Initialized
DEBUG - 2021-12-18 02:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:26:17 --> Final output sent to browser
DEBUG - 2021-12-18 02:26:17 --> Total execution time: 0.0360
INFO - 2021-12-18 02:26:17 --> Config Class Initialized
INFO - 2021-12-18 02:26:17 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:26:17 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:26:17 --> Utf8 Class Initialized
INFO - 2021-12-18 02:26:17 --> URI Class Initialized
INFO - 2021-12-18 02:26:17 --> Router Class Initialized
INFO - 2021-12-18 02:26:17 --> Output Class Initialized
INFO - 2021-12-18 02:26:17 --> Security Class Initialized
DEBUG - 2021-12-18 02:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:26:17 --> Input Class Initialized
INFO - 2021-12-18 02:26:17 --> Language Class Initialized
INFO - 2021-12-18 02:26:17 --> Language Class Initialized
INFO - 2021-12-18 02:26:17 --> Config Class Initialized
INFO - 2021-12-18 02:26:17 --> Loader Class Initialized
INFO - 2021-12-18 02:26:17 --> Helper loaded: url_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: file_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: form_helper
INFO - 2021-12-18 02:26:17 --> Helper loaded: my_helper
INFO - 2021-12-18 02:26:17 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:26:17 --> Controller Class Initialized
INFO - 2021-12-18 02:26:29 --> Config Class Initialized
INFO - 2021-12-18 02:26:29 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:26:29 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:26:29 --> Utf8 Class Initialized
INFO - 2021-12-18 02:26:29 --> URI Class Initialized
INFO - 2021-12-18 02:26:29 --> Router Class Initialized
INFO - 2021-12-18 02:26:29 --> Output Class Initialized
INFO - 2021-12-18 02:26:29 --> Security Class Initialized
DEBUG - 2021-12-18 02:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:26:29 --> Input Class Initialized
INFO - 2021-12-18 02:26:29 --> Language Class Initialized
INFO - 2021-12-18 02:26:29 --> Language Class Initialized
INFO - 2021-12-18 02:26:29 --> Config Class Initialized
INFO - 2021-12-18 02:26:29 --> Loader Class Initialized
INFO - 2021-12-18 02:26:29 --> Helper loaded: url_helper
INFO - 2021-12-18 02:26:29 --> Helper loaded: file_helper
INFO - 2021-12-18 02:26:29 --> Helper loaded: form_helper
INFO - 2021-12-18 02:26:29 --> Helper loaded: my_helper
INFO - 2021-12-18 02:26:29 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:26:29 --> Controller Class Initialized
DEBUG - 2021-12-18 02:26:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:26:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:26:29 --> Final output sent to browser
DEBUG - 2021-12-18 02:26:29 --> Total execution time: 0.0470
INFO - 2021-12-18 02:27:03 --> Config Class Initialized
INFO - 2021-12-18 02:27:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:27:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:27:03 --> Utf8 Class Initialized
INFO - 2021-12-18 02:27:03 --> URI Class Initialized
INFO - 2021-12-18 02:27:03 --> Router Class Initialized
INFO - 2021-12-18 02:27:03 --> Output Class Initialized
INFO - 2021-12-18 02:27:03 --> Security Class Initialized
DEBUG - 2021-12-18 02:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:27:03 --> Input Class Initialized
INFO - 2021-12-18 02:27:03 --> Language Class Initialized
INFO - 2021-12-18 02:27:03 --> Language Class Initialized
INFO - 2021-12-18 02:27:03 --> Config Class Initialized
INFO - 2021-12-18 02:27:03 --> Loader Class Initialized
INFO - 2021-12-18 02:27:03 --> Helper loaded: url_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: file_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: form_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: my_helper
INFO - 2021-12-18 02:27:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:27:03 --> Controller Class Initialized
INFO - 2021-12-18 02:27:03 --> Config Class Initialized
INFO - 2021-12-18 02:27:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:27:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:27:03 --> Utf8 Class Initialized
INFO - 2021-12-18 02:27:03 --> URI Class Initialized
INFO - 2021-12-18 02:27:03 --> Router Class Initialized
INFO - 2021-12-18 02:27:03 --> Output Class Initialized
INFO - 2021-12-18 02:27:03 --> Security Class Initialized
DEBUG - 2021-12-18 02:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:27:03 --> Input Class Initialized
INFO - 2021-12-18 02:27:03 --> Language Class Initialized
INFO - 2021-12-18 02:27:03 --> Language Class Initialized
INFO - 2021-12-18 02:27:03 --> Config Class Initialized
INFO - 2021-12-18 02:27:03 --> Loader Class Initialized
INFO - 2021-12-18 02:27:03 --> Helper loaded: url_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: file_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: form_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: my_helper
INFO - 2021-12-18 02:27:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:27:03 --> Controller Class Initialized
DEBUG - 2021-12-18 02:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:27:03 --> Final output sent to browser
DEBUG - 2021-12-18 02:27:03 --> Total execution time: 0.0360
INFO - 2021-12-18 02:27:03 --> Config Class Initialized
INFO - 2021-12-18 02:27:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:27:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:27:03 --> Utf8 Class Initialized
INFO - 2021-12-18 02:27:03 --> URI Class Initialized
INFO - 2021-12-18 02:27:03 --> Router Class Initialized
INFO - 2021-12-18 02:27:03 --> Output Class Initialized
INFO - 2021-12-18 02:27:03 --> Security Class Initialized
DEBUG - 2021-12-18 02:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:27:03 --> Input Class Initialized
INFO - 2021-12-18 02:27:03 --> Language Class Initialized
INFO - 2021-12-18 02:27:03 --> Language Class Initialized
INFO - 2021-12-18 02:27:03 --> Config Class Initialized
INFO - 2021-12-18 02:27:03 --> Loader Class Initialized
INFO - 2021-12-18 02:27:03 --> Helper loaded: url_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: file_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: form_helper
INFO - 2021-12-18 02:27:03 --> Helper loaded: my_helper
INFO - 2021-12-18 02:27:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:27:03 --> Controller Class Initialized
INFO - 2021-12-18 02:27:05 --> Config Class Initialized
INFO - 2021-12-18 02:27:05 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:27:05 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:27:05 --> Utf8 Class Initialized
INFO - 2021-12-18 02:27:05 --> URI Class Initialized
INFO - 2021-12-18 02:27:05 --> Router Class Initialized
INFO - 2021-12-18 02:27:05 --> Output Class Initialized
INFO - 2021-12-18 02:27:05 --> Security Class Initialized
DEBUG - 2021-12-18 02:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:27:05 --> Input Class Initialized
INFO - 2021-12-18 02:27:05 --> Language Class Initialized
INFO - 2021-12-18 02:27:05 --> Language Class Initialized
INFO - 2021-12-18 02:27:05 --> Config Class Initialized
INFO - 2021-12-18 02:27:05 --> Loader Class Initialized
INFO - 2021-12-18 02:27:05 --> Helper loaded: url_helper
INFO - 2021-12-18 02:27:05 --> Helper loaded: file_helper
INFO - 2021-12-18 02:27:05 --> Helper loaded: form_helper
INFO - 2021-12-18 02:27:05 --> Helper loaded: my_helper
INFO - 2021-12-18 02:27:05 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:27:05 --> Controller Class Initialized
DEBUG - 2021-12-18 02:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:27:05 --> Final output sent to browser
DEBUG - 2021-12-18 02:27:05 --> Total execution time: 0.0530
INFO - 2021-12-18 02:27:53 --> Config Class Initialized
INFO - 2021-12-18 02:27:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:27:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:27:53 --> Utf8 Class Initialized
INFO - 2021-12-18 02:27:53 --> URI Class Initialized
INFO - 2021-12-18 02:27:53 --> Router Class Initialized
INFO - 2021-12-18 02:27:53 --> Output Class Initialized
INFO - 2021-12-18 02:27:53 --> Security Class Initialized
DEBUG - 2021-12-18 02:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:27:53 --> Input Class Initialized
INFO - 2021-12-18 02:27:53 --> Language Class Initialized
INFO - 2021-12-18 02:27:53 --> Language Class Initialized
INFO - 2021-12-18 02:27:53 --> Config Class Initialized
INFO - 2021-12-18 02:27:53 --> Loader Class Initialized
INFO - 2021-12-18 02:27:53 --> Helper loaded: url_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: file_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: form_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: my_helper
INFO - 2021-12-18 02:27:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:27:53 --> Controller Class Initialized
INFO - 2021-12-18 02:27:53 --> Config Class Initialized
INFO - 2021-12-18 02:27:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:27:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:27:53 --> Utf8 Class Initialized
INFO - 2021-12-18 02:27:53 --> URI Class Initialized
INFO - 2021-12-18 02:27:53 --> Router Class Initialized
INFO - 2021-12-18 02:27:53 --> Output Class Initialized
INFO - 2021-12-18 02:27:53 --> Security Class Initialized
DEBUG - 2021-12-18 02:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:27:53 --> Input Class Initialized
INFO - 2021-12-18 02:27:53 --> Language Class Initialized
INFO - 2021-12-18 02:27:53 --> Language Class Initialized
INFO - 2021-12-18 02:27:53 --> Config Class Initialized
INFO - 2021-12-18 02:27:53 --> Loader Class Initialized
INFO - 2021-12-18 02:27:53 --> Helper loaded: url_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: file_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: form_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: my_helper
INFO - 2021-12-18 02:27:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:27:53 --> Controller Class Initialized
DEBUG - 2021-12-18 02:27:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:27:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:27:53 --> Final output sent to browser
DEBUG - 2021-12-18 02:27:53 --> Total execution time: 0.0350
INFO - 2021-12-18 02:27:53 --> Config Class Initialized
INFO - 2021-12-18 02:27:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:27:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:27:53 --> Utf8 Class Initialized
INFO - 2021-12-18 02:27:53 --> URI Class Initialized
INFO - 2021-12-18 02:27:53 --> Router Class Initialized
INFO - 2021-12-18 02:27:53 --> Output Class Initialized
INFO - 2021-12-18 02:27:53 --> Security Class Initialized
DEBUG - 2021-12-18 02:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:27:53 --> Input Class Initialized
INFO - 2021-12-18 02:27:53 --> Language Class Initialized
INFO - 2021-12-18 02:27:53 --> Language Class Initialized
INFO - 2021-12-18 02:27:53 --> Config Class Initialized
INFO - 2021-12-18 02:27:53 --> Loader Class Initialized
INFO - 2021-12-18 02:27:53 --> Helper loaded: url_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: file_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: form_helper
INFO - 2021-12-18 02:27:53 --> Helper loaded: my_helper
INFO - 2021-12-18 02:27:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:27:53 --> Controller Class Initialized
INFO - 2021-12-18 02:27:55 --> Config Class Initialized
INFO - 2021-12-18 02:27:55 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:27:55 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:27:55 --> Utf8 Class Initialized
INFO - 2021-12-18 02:27:55 --> URI Class Initialized
INFO - 2021-12-18 02:27:55 --> Router Class Initialized
INFO - 2021-12-18 02:27:55 --> Output Class Initialized
INFO - 2021-12-18 02:27:55 --> Security Class Initialized
DEBUG - 2021-12-18 02:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:27:55 --> Input Class Initialized
INFO - 2021-12-18 02:27:55 --> Language Class Initialized
INFO - 2021-12-18 02:27:55 --> Language Class Initialized
INFO - 2021-12-18 02:27:55 --> Config Class Initialized
INFO - 2021-12-18 02:27:55 --> Loader Class Initialized
INFO - 2021-12-18 02:27:55 --> Helper loaded: url_helper
INFO - 2021-12-18 02:27:55 --> Helper loaded: file_helper
INFO - 2021-12-18 02:27:55 --> Helper loaded: form_helper
INFO - 2021-12-18 02:27:55 --> Helper loaded: my_helper
INFO - 2021-12-18 02:27:55 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:27:55 --> Controller Class Initialized
DEBUG - 2021-12-18 02:27:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:27:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:27:55 --> Final output sent to browser
DEBUG - 2021-12-18 02:27:55 --> Total execution time: 0.0510
INFO - 2021-12-18 02:28:24 --> Config Class Initialized
INFO - 2021-12-18 02:28:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:28:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:28:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:28:24 --> URI Class Initialized
INFO - 2021-12-18 02:28:24 --> Router Class Initialized
INFO - 2021-12-18 02:28:24 --> Output Class Initialized
INFO - 2021-12-18 02:28:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:28:24 --> Input Class Initialized
INFO - 2021-12-18 02:28:24 --> Language Class Initialized
INFO - 2021-12-18 02:28:24 --> Language Class Initialized
INFO - 2021-12-18 02:28:24 --> Config Class Initialized
INFO - 2021-12-18 02:28:24 --> Loader Class Initialized
INFO - 2021-12-18 02:28:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:28:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:28:24 --> Controller Class Initialized
INFO - 2021-12-18 02:28:24 --> Config Class Initialized
INFO - 2021-12-18 02:28:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:28:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:28:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:28:24 --> URI Class Initialized
INFO - 2021-12-18 02:28:24 --> Router Class Initialized
INFO - 2021-12-18 02:28:24 --> Output Class Initialized
INFO - 2021-12-18 02:28:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:28:24 --> Input Class Initialized
INFO - 2021-12-18 02:28:24 --> Language Class Initialized
INFO - 2021-12-18 02:28:24 --> Language Class Initialized
INFO - 2021-12-18 02:28:24 --> Config Class Initialized
INFO - 2021-12-18 02:28:24 --> Loader Class Initialized
INFO - 2021-12-18 02:28:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:28:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:28:24 --> Controller Class Initialized
DEBUG - 2021-12-18 02:28:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:28:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:28:24 --> Final output sent to browser
DEBUG - 2021-12-18 02:28:24 --> Total execution time: 0.0360
INFO - 2021-12-18 02:28:24 --> Config Class Initialized
INFO - 2021-12-18 02:28:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:28:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:28:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:28:24 --> URI Class Initialized
INFO - 2021-12-18 02:28:24 --> Router Class Initialized
INFO - 2021-12-18 02:28:24 --> Output Class Initialized
INFO - 2021-12-18 02:28:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:28:24 --> Input Class Initialized
INFO - 2021-12-18 02:28:24 --> Language Class Initialized
INFO - 2021-12-18 02:28:24 --> Language Class Initialized
INFO - 2021-12-18 02:28:24 --> Config Class Initialized
INFO - 2021-12-18 02:28:24 --> Loader Class Initialized
INFO - 2021-12-18 02:28:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:28:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:28:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:28:24 --> Controller Class Initialized
INFO - 2021-12-18 02:33:33 --> Config Class Initialized
INFO - 2021-12-18 02:33:33 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:33:33 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:33:33 --> Utf8 Class Initialized
INFO - 2021-12-18 02:33:33 --> URI Class Initialized
INFO - 2021-12-18 02:33:33 --> Router Class Initialized
INFO - 2021-12-18 02:33:33 --> Output Class Initialized
INFO - 2021-12-18 02:33:33 --> Security Class Initialized
DEBUG - 2021-12-18 02:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:33:33 --> Input Class Initialized
INFO - 2021-12-18 02:33:33 --> Language Class Initialized
INFO - 2021-12-18 02:33:33 --> Language Class Initialized
INFO - 2021-12-18 02:33:33 --> Config Class Initialized
INFO - 2021-12-18 02:33:33 --> Loader Class Initialized
INFO - 2021-12-18 02:33:33 --> Helper loaded: url_helper
INFO - 2021-12-18 02:33:33 --> Helper loaded: file_helper
INFO - 2021-12-18 02:33:33 --> Helper loaded: form_helper
INFO - 2021-12-18 02:33:33 --> Helper loaded: my_helper
INFO - 2021-12-18 02:33:33 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:33:33 --> Controller Class Initialized
INFO - 2021-12-18 02:33:34 --> Config Class Initialized
INFO - 2021-12-18 02:33:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:33:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:33:34 --> Utf8 Class Initialized
INFO - 2021-12-18 02:33:34 --> URI Class Initialized
INFO - 2021-12-18 02:33:34 --> Router Class Initialized
INFO - 2021-12-18 02:33:34 --> Output Class Initialized
INFO - 2021-12-18 02:33:34 --> Security Class Initialized
DEBUG - 2021-12-18 02:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:33:34 --> Input Class Initialized
INFO - 2021-12-18 02:33:34 --> Language Class Initialized
INFO - 2021-12-18 02:33:34 --> Language Class Initialized
INFO - 2021-12-18 02:33:34 --> Config Class Initialized
INFO - 2021-12-18 02:33:34 --> Loader Class Initialized
INFO - 2021-12-18 02:33:34 --> Helper loaded: url_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: file_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: form_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: my_helper
INFO - 2021-12-18 02:33:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:33:34 --> Controller Class Initialized
INFO - 2021-12-18 02:33:34 --> Config Class Initialized
INFO - 2021-12-18 02:33:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:33:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:33:34 --> Utf8 Class Initialized
INFO - 2021-12-18 02:33:34 --> URI Class Initialized
INFO - 2021-12-18 02:33:34 --> Router Class Initialized
INFO - 2021-12-18 02:33:34 --> Output Class Initialized
INFO - 2021-12-18 02:33:34 --> Security Class Initialized
DEBUG - 2021-12-18 02:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:33:34 --> Input Class Initialized
INFO - 2021-12-18 02:33:34 --> Language Class Initialized
INFO - 2021-12-18 02:33:34 --> Language Class Initialized
INFO - 2021-12-18 02:33:34 --> Config Class Initialized
INFO - 2021-12-18 02:33:34 --> Loader Class Initialized
INFO - 2021-12-18 02:33:34 --> Helper loaded: url_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: file_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: form_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: my_helper
INFO - 2021-12-18 02:33:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:33:34 --> Controller Class Initialized
INFO - 2021-12-18 02:33:34 --> Config Class Initialized
INFO - 2021-12-18 02:33:34 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:33:34 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:33:34 --> Utf8 Class Initialized
INFO - 2021-12-18 02:33:34 --> URI Class Initialized
INFO - 2021-12-18 02:33:34 --> Router Class Initialized
INFO - 2021-12-18 02:33:34 --> Output Class Initialized
INFO - 2021-12-18 02:33:34 --> Security Class Initialized
DEBUG - 2021-12-18 02:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:33:34 --> Input Class Initialized
INFO - 2021-12-18 02:33:34 --> Language Class Initialized
INFO - 2021-12-18 02:33:34 --> Language Class Initialized
INFO - 2021-12-18 02:33:34 --> Config Class Initialized
INFO - 2021-12-18 02:33:34 --> Loader Class Initialized
INFO - 2021-12-18 02:33:34 --> Helper loaded: url_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: file_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: form_helper
INFO - 2021-12-18 02:33:34 --> Helper loaded: my_helper
INFO - 2021-12-18 02:33:34 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:33:34 --> Controller Class Initialized
INFO - 2021-12-18 02:33:39 --> Config Class Initialized
INFO - 2021-12-18 02:33:39 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:33:39 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:33:39 --> Utf8 Class Initialized
INFO - 2021-12-18 02:33:39 --> URI Class Initialized
INFO - 2021-12-18 02:33:39 --> Router Class Initialized
INFO - 2021-12-18 02:33:39 --> Output Class Initialized
INFO - 2021-12-18 02:33:39 --> Security Class Initialized
DEBUG - 2021-12-18 02:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:33:39 --> Input Class Initialized
INFO - 2021-12-18 02:33:39 --> Language Class Initialized
INFO - 2021-12-18 02:33:39 --> Language Class Initialized
INFO - 2021-12-18 02:33:39 --> Config Class Initialized
INFO - 2021-12-18 02:33:39 --> Loader Class Initialized
INFO - 2021-12-18 02:33:39 --> Helper loaded: url_helper
INFO - 2021-12-18 02:33:39 --> Helper loaded: file_helper
INFO - 2021-12-18 02:33:39 --> Helper loaded: form_helper
INFO - 2021-12-18 02:33:39 --> Helper loaded: my_helper
INFO - 2021-12-18 02:33:39 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:33:39 --> Controller Class Initialized
INFO - 2021-12-18 02:33:41 --> Config Class Initialized
INFO - 2021-12-18 02:33:41 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:33:41 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:33:41 --> Utf8 Class Initialized
INFO - 2021-12-18 02:33:41 --> URI Class Initialized
INFO - 2021-12-18 02:33:41 --> Router Class Initialized
INFO - 2021-12-18 02:33:41 --> Output Class Initialized
INFO - 2021-12-18 02:33:41 --> Security Class Initialized
DEBUG - 2021-12-18 02:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:33:41 --> Input Class Initialized
INFO - 2021-12-18 02:33:41 --> Language Class Initialized
INFO - 2021-12-18 02:33:41 --> Language Class Initialized
INFO - 2021-12-18 02:33:41 --> Config Class Initialized
INFO - 2021-12-18 02:33:41 --> Loader Class Initialized
INFO - 2021-12-18 02:33:41 --> Helper loaded: url_helper
INFO - 2021-12-18 02:33:41 --> Helper loaded: file_helper
INFO - 2021-12-18 02:33:41 --> Helper loaded: form_helper
INFO - 2021-12-18 02:33:41 --> Helper loaded: my_helper
INFO - 2021-12-18 02:33:41 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:33:41 --> Controller Class Initialized
INFO - 2021-12-18 02:34:01 --> Config Class Initialized
INFO - 2021-12-18 02:34:01 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:34:01 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:34:01 --> Utf8 Class Initialized
INFO - 2021-12-18 02:34:01 --> URI Class Initialized
INFO - 2021-12-18 02:34:01 --> Router Class Initialized
INFO - 2021-12-18 02:34:01 --> Output Class Initialized
INFO - 2021-12-18 02:34:01 --> Security Class Initialized
DEBUG - 2021-12-18 02:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:34:01 --> Input Class Initialized
INFO - 2021-12-18 02:34:01 --> Language Class Initialized
INFO - 2021-12-18 02:34:01 --> Language Class Initialized
INFO - 2021-12-18 02:34:01 --> Config Class Initialized
INFO - 2021-12-18 02:34:01 --> Loader Class Initialized
INFO - 2021-12-18 02:34:01 --> Helper loaded: url_helper
INFO - 2021-12-18 02:34:01 --> Helper loaded: file_helper
INFO - 2021-12-18 02:34:01 --> Helper loaded: form_helper
INFO - 2021-12-18 02:34:01 --> Helper loaded: my_helper
INFO - 2021-12-18 02:34:01 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:34:01 --> Controller Class Initialized
DEBUG - 2021-12-18 02:34:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:34:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:34:01 --> Final output sent to browser
DEBUG - 2021-12-18 02:34:01 --> Total execution time: 0.0550
INFO - 2021-12-18 02:34:50 --> Config Class Initialized
INFO - 2021-12-18 02:34:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:34:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:34:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:34:50 --> URI Class Initialized
INFO - 2021-12-18 02:34:50 --> Router Class Initialized
INFO - 2021-12-18 02:34:50 --> Output Class Initialized
INFO - 2021-12-18 02:34:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:34:50 --> Input Class Initialized
INFO - 2021-12-18 02:34:50 --> Language Class Initialized
INFO - 2021-12-18 02:34:50 --> Language Class Initialized
INFO - 2021-12-18 02:34:50 --> Config Class Initialized
INFO - 2021-12-18 02:34:50 --> Loader Class Initialized
INFO - 2021-12-18 02:34:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:34:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:34:50 --> Controller Class Initialized
INFO - 2021-12-18 02:34:50 --> Config Class Initialized
INFO - 2021-12-18 02:34:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:34:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:34:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:34:50 --> URI Class Initialized
INFO - 2021-12-18 02:34:50 --> Router Class Initialized
INFO - 2021-12-18 02:34:50 --> Output Class Initialized
INFO - 2021-12-18 02:34:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:34:50 --> Input Class Initialized
INFO - 2021-12-18 02:34:50 --> Language Class Initialized
INFO - 2021-12-18 02:34:50 --> Language Class Initialized
INFO - 2021-12-18 02:34:50 --> Config Class Initialized
INFO - 2021-12-18 02:34:50 --> Loader Class Initialized
INFO - 2021-12-18 02:34:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:34:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:34:50 --> Controller Class Initialized
DEBUG - 2021-12-18 02:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:34:50 --> Final output sent to browser
DEBUG - 2021-12-18 02:34:50 --> Total execution time: 0.0360
INFO - 2021-12-18 02:34:50 --> Config Class Initialized
INFO - 2021-12-18 02:34:50 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:34:50 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:34:50 --> Utf8 Class Initialized
INFO - 2021-12-18 02:34:50 --> URI Class Initialized
INFO - 2021-12-18 02:34:50 --> Router Class Initialized
INFO - 2021-12-18 02:34:50 --> Output Class Initialized
INFO - 2021-12-18 02:34:50 --> Security Class Initialized
DEBUG - 2021-12-18 02:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:34:50 --> Input Class Initialized
INFO - 2021-12-18 02:34:50 --> Language Class Initialized
INFO - 2021-12-18 02:34:50 --> Language Class Initialized
INFO - 2021-12-18 02:34:50 --> Config Class Initialized
INFO - 2021-12-18 02:34:50 --> Loader Class Initialized
INFO - 2021-12-18 02:34:50 --> Helper loaded: url_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: file_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: form_helper
INFO - 2021-12-18 02:34:50 --> Helper loaded: my_helper
INFO - 2021-12-18 02:34:50 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:34:50 --> Controller Class Initialized
INFO - 2021-12-18 02:34:51 --> Config Class Initialized
INFO - 2021-12-18 02:34:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:34:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:34:51 --> Utf8 Class Initialized
INFO - 2021-12-18 02:34:51 --> URI Class Initialized
INFO - 2021-12-18 02:34:51 --> Router Class Initialized
INFO - 2021-12-18 02:34:51 --> Output Class Initialized
INFO - 2021-12-18 02:34:51 --> Security Class Initialized
DEBUG - 2021-12-18 02:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:34:51 --> Input Class Initialized
INFO - 2021-12-18 02:34:51 --> Language Class Initialized
INFO - 2021-12-18 02:34:51 --> Language Class Initialized
INFO - 2021-12-18 02:34:51 --> Config Class Initialized
INFO - 2021-12-18 02:34:51 --> Loader Class Initialized
INFO - 2021-12-18 02:34:51 --> Helper loaded: url_helper
INFO - 2021-12-18 02:34:51 --> Helper loaded: file_helper
INFO - 2021-12-18 02:34:51 --> Helper loaded: form_helper
INFO - 2021-12-18 02:34:51 --> Helper loaded: my_helper
INFO - 2021-12-18 02:34:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:34:51 --> Controller Class Initialized
DEBUG - 2021-12-18 02:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:34:51 --> Final output sent to browser
DEBUG - 2021-12-18 02:34:51 --> Total execution time: 0.0470
INFO - 2021-12-18 02:35:18 --> Config Class Initialized
INFO - 2021-12-18 02:35:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:35:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:35:18 --> Utf8 Class Initialized
INFO - 2021-12-18 02:35:18 --> URI Class Initialized
INFO - 2021-12-18 02:35:18 --> Router Class Initialized
INFO - 2021-12-18 02:35:18 --> Output Class Initialized
INFO - 2021-12-18 02:35:18 --> Security Class Initialized
DEBUG - 2021-12-18 02:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:35:18 --> Input Class Initialized
INFO - 2021-12-18 02:35:18 --> Language Class Initialized
INFO - 2021-12-18 02:35:18 --> Language Class Initialized
INFO - 2021-12-18 02:35:18 --> Config Class Initialized
INFO - 2021-12-18 02:35:18 --> Loader Class Initialized
INFO - 2021-12-18 02:35:18 --> Helper loaded: url_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: file_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: form_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: my_helper
INFO - 2021-12-18 02:35:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:35:18 --> Controller Class Initialized
INFO - 2021-12-18 02:35:18 --> Config Class Initialized
INFO - 2021-12-18 02:35:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:35:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:35:18 --> Utf8 Class Initialized
INFO - 2021-12-18 02:35:18 --> URI Class Initialized
INFO - 2021-12-18 02:35:18 --> Router Class Initialized
INFO - 2021-12-18 02:35:18 --> Output Class Initialized
INFO - 2021-12-18 02:35:18 --> Security Class Initialized
DEBUG - 2021-12-18 02:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:35:18 --> Input Class Initialized
INFO - 2021-12-18 02:35:18 --> Language Class Initialized
INFO - 2021-12-18 02:35:18 --> Language Class Initialized
INFO - 2021-12-18 02:35:18 --> Config Class Initialized
INFO - 2021-12-18 02:35:18 --> Loader Class Initialized
INFO - 2021-12-18 02:35:18 --> Helper loaded: url_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: file_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: form_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: my_helper
INFO - 2021-12-18 02:35:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:35:18 --> Controller Class Initialized
DEBUG - 2021-12-18 02:35:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:35:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:35:18 --> Final output sent to browser
DEBUG - 2021-12-18 02:35:18 --> Total execution time: 0.0360
INFO - 2021-12-18 02:35:18 --> Config Class Initialized
INFO - 2021-12-18 02:35:18 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:35:18 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:35:18 --> Utf8 Class Initialized
INFO - 2021-12-18 02:35:18 --> URI Class Initialized
INFO - 2021-12-18 02:35:18 --> Router Class Initialized
INFO - 2021-12-18 02:35:18 --> Output Class Initialized
INFO - 2021-12-18 02:35:18 --> Security Class Initialized
DEBUG - 2021-12-18 02:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:35:18 --> Input Class Initialized
INFO - 2021-12-18 02:35:18 --> Language Class Initialized
INFO - 2021-12-18 02:35:18 --> Language Class Initialized
INFO - 2021-12-18 02:35:18 --> Config Class Initialized
INFO - 2021-12-18 02:35:18 --> Loader Class Initialized
INFO - 2021-12-18 02:35:18 --> Helper loaded: url_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: file_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: form_helper
INFO - 2021-12-18 02:35:18 --> Helper loaded: my_helper
INFO - 2021-12-18 02:35:18 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:35:18 --> Controller Class Initialized
INFO - 2021-12-18 02:35:19 --> Config Class Initialized
INFO - 2021-12-18 02:35:19 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:35:19 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:35:19 --> Utf8 Class Initialized
INFO - 2021-12-18 02:35:19 --> URI Class Initialized
INFO - 2021-12-18 02:35:19 --> Router Class Initialized
INFO - 2021-12-18 02:35:19 --> Output Class Initialized
INFO - 2021-12-18 02:35:19 --> Security Class Initialized
DEBUG - 2021-12-18 02:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:35:19 --> Input Class Initialized
INFO - 2021-12-18 02:35:19 --> Language Class Initialized
INFO - 2021-12-18 02:35:19 --> Language Class Initialized
INFO - 2021-12-18 02:35:19 --> Config Class Initialized
INFO - 2021-12-18 02:35:19 --> Loader Class Initialized
INFO - 2021-12-18 02:35:19 --> Helper loaded: url_helper
INFO - 2021-12-18 02:35:19 --> Helper loaded: file_helper
INFO - 2021-12-18 02:35:19 --> Helper loaded: form_helper
INFO - 2021-12-18 02:35:19 --> Helper loaded: my_helper
INFO - 2021-12-18 02:35:19 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:35:19 --> Controller Class Initialized
INFO - 2021-12-18 02:35:20 --> Config Class Initialized
INFO - 2021-12-18 02:35:20 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:35:20 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:35:20 --> Utf8 Class Initialized
INFO - 2021-12-18 02:35:20 --> URI Class Initialized
INFO - 2021-12-18 02:35:20 --> Router Class Initialized
INFO - 2021-12-18 02:35:20 --> Output Class Initialized
INFO - 2021-12-18 02:35:20 --> Security Class Initialized
DEBUG - 2021-12-18 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:35:20 --> Input Class Initialized
INFO - 2021-12-18 02:35:20 --> Language Class Initialized
INFO - 2021-12-18 02:35:20 --> Language Class Initialized
INFO - 2021-12-18 02:35:20 --> Config Class Initialized
INFO - 2021-12-18 02:35:20 --> Loader Class Initialized
INFO - 2021-12-18 02:35:20 --> Helper loaded: url_helper
INFO - 2021-12-18 02:35:20 --> Helper loaded: file_helper
INFO - 2021-12-18 02:35:20 --> Helper loaded: form_helper
INFO - 2021-12-18 02:35:20 --> Helper loaded: my_helper
INFO - 2021-12-18 02:35:20 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:35:20 --> Controller Class Initialized
INFO - 2021-12-18 02:35:20 --> Config Class Initialized
INFO - 2021-12-18 02:35:20 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:35:20 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:35:20 --> Utf8 Class Initialized
INFO - 2021-12-18 02:35:20 --> URI Class Initialized
INFO - 2021-12-18 02:35:20 --> Router Class Initialized
INFO - 2021-12-18 02:35:20 --> Output Class Initialized
INFO - 2021-12-18 02:35:20 --> Security Class Initialized
DEBUG - 2021-12-18 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:35:20 --> Input Class Initialized
INFO - 2021-12-18 02:35:20 --> Language Class Initialized
INFO - 2021-12-18 02:35:20 --> Language Class Initialized
INFO - 2021-12-18 02:35:20 --> Config Class Initialized
INFO - 2021-12-18 02:35:20 --> Loader Class Initialized
INFO - 2021-12-18 02:35:20 --> Helper loaded: url_helper
INFO - 2021-12-18 02:35:20 --> Helper loaded: file_helper
INFO - 2021-12-18 02:35:20 --> Helper loaded: form_helper
INFO - 2021-12-18 02:35:20 --> Helper loaded: my_helper
INFO - 2021-12-18 02:35:20 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:35:20 --> Controller Class Initialized
INFO - 2021-12-18 02:35:27 --> Config Class Initialized
INFO - 2021-12-18 02:35:27 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:35:27 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:35:27 --> Utf8 Class Initialized
INFO - 2021-12-18 02:35:27 --> URI Class Initialized
INFO - 2021-12-18 02:35:27 --> Router Class Initialized
INFO - 2021-12-18 02:35:27 --> Output Class Initialized
INFO - 2021-12-18 02:35:27 --> Security Class Initialized
DEBUG - 2021-12-18 02:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:35:27 --> Input Class Initialized
INFO - 2021-12-18 02:35:27 --> Language Class Initialized
INFO - 2021-12-18 02:35:27 --> Language Class Initialized
INFO - 2021-12-18 02:35:27 --> Config Class Initialized
INFO - 2021-12-18 02:35:27 --> Loader Class Initialized
INFO - 2021-12-18 02:35:27 --> Helper loaded: url_helper
INFO - 2021-12-18 02:35:27 --> Helper loaded: file_helper
INFO - 2021-12-18 02:35:27 --> Helper loaded: form_helper
INFO - 2021-12-18 02:35:27 --> Helper loaded: my_helper
INFO - 2021-12-18 02:35:27 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:35:27 --> Controller Class Initialized
DEBUG - 2021-12-18 02:35:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:35:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:35:27 --> Final output sent to browser
DEBUG - 2021-12-18 02:35:27 --> Total execution time: 0.0440
INFO - 2021-12-18 02:36:09 --> Config Class Initialized
INFO - 2021-12-18 02:36:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:09 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:09 --> URI Class Initialized
INFO - 2021-12-18 02:36:09 --> Router Class Initialized
INFO - 2021-12-18 02:36:09 --> Output Class Initialized
INFO - 2021-12-18 02:36:09 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:09 --> Input Class Initialized
INFO - 2021-12-18 02:36:09 --> Language Class Initialized
INFO - 2021-12-18 02:36:09 --> Language Class Initialized
INFO - 2021-12-18 02:36:09 --> Config Class Initialized
INFO - 2021-12-18 02:36:09 --> Loader Class Initialized
INFO - 2021-12-18 02:36:09 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:09 --> Controller Class Initialized
INFO - 2021-12-18 02:36:09 --> Config Class Initialized
INFO - 2021-12-18 02:36:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:09 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:09 --> URI Class Initialized
INFO - 2021-12-18 02:36:09 --> Router Class Initialized
INFO - 2021-12-18 02:36:09 --> Output Class Initialized
INFO - 2021-12-18 02:36:09 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:09 --> Input Class Initialized
INFO - 2021-12-18 02:36:09 --> Language Class Initialized
INFO - 2021-12-18 02:36:09 --> Language Class Initialized
INFO - 2021-12-18 02:36:09 --> Config Class Initialized
INFO - 2021-12-18 02:36:09 --> Loader Class Initialized
INFO - 2021-12-18 02:36:09 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:09 --> Controller Class Initialized
DEBUG - 2021-12-18 02:36:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:36:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:36:09 --> Final output sent to browser
DEBUG - 2021-12-18 02:36:09 --> Total execution time: 0.0350
INFO - 2021-12-18 02:36:09 --> Config Class Initialized
INFO - 2021-12-18 02:36:09 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:09 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:09 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:09 --> URI Class Initialized
INFO - 2021-12-18 02:36:09 --> Router Class Initialized
INFO - 2021-12-18 02:36:09 --> Output Class Initialized
INFO - 2021-12-18 02:36:09 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:09 --> Input Class Initialized
INFO - 2021-12-18 02:36:09 --> Language Class Initialized
INFO - 2021-12-18 02:36:09 --> Language Class Initialized
INFO - 2021-12-18 02:36:09 --> Config Class Initialized
INFO - 2021-12-18 02:36:09 --> Loader Class Initialized
INFO - 2021-12-18 02:36:09 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:09 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:09 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:09 --> Controller Class Initialized
INFO - 2021-12-18 02:36:22 --> Config Class Initialized
INFO - 2021-12-18 02:36:22 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:22 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:22 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:22 --> URI Class Initialized
INFO - 2021-12-18 02:36:22 --> Router Class Initialized
INFO - 2021-12-18 02:36:22 --> Output Class Initialized
INFO - 2021-12-18 02:36:22 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:22 --> Input Class Initialized
INFO - 2021-12-18 02:36:22 --> Language Class Initialized
INFO - 2021-12-18 02:36:22 --> Language Class Initialized
INFO - 2021-12-18 02:36:22 --> Config Class Initialized
INFO - 2021-12-18 02:36:22 --> Loader Class Initialized
INFO - 2021-12-18 02:36:22 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:22 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:22 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:22 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:22 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:22 --> Controller Class Initialized
DEBUG - 2021-12-18 02:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:36:22 --> Final output sent to browser
DEBUG - 2021-12-18 02:36:22 --> Total execution time: 0.0510
INFO - 2021-12-18 02:36:37 --> Config Class Initialized
INFO - 2021-12-18 02:36:37 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:37 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:37 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:37 --> URI Class Initialized
INFO - 2021-12-18 02:36:37 --> Router Class Initialized
INFO - 2021-12-18 02:36:37 --> Output Class Initialized
INFO - 2021-12-18 02:36:37 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:37 --> Input Class Initialized
INFO - 2021-12-18 02:36:37 --> Language Class Initialized
INFO - 2021-12-18 02:36:37 --> Language Class Initialized
INFO - 2021-12-18 02:36:37 --> Config Class Initialized
INFO - 2021-12-18 02:36:37 --> Loader Class Initialized
INFO - 2021-12-18 02:36:37 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:37 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:37 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:37 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:37 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:37 --> Controller Class Initialized
INFO - 2021-12-18 02:36:37 --> Config Class Initialized
INFO - 2021-12-18 02:36:37 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:37 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:37 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:37 --> URI Class Initialized
INFO - 2021-12-18 02:36:37 --> Router Class Initialized
INFO - 2021-12-18 02:36:37 --> Output Class Initialized
INFO - 2021-12-18 02:36:37 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:37 --> Input Class Initialized
INFO - 2021-12-18 02:36:37 --> Language Class Initialized
INFO - 2021-12-18 02:36:37 --> Language Class Initialized
INFO - 2021-12-18 02:36:37 --> Config Class Initialized
INFO - 2021-12-18 02:36:37 --> Loader Class Initialized
INFO - 2021-12-18 02:36:37 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:37 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:37 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:37 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:37 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:37 --> Controller Class Initialized
DEBUG - 2021-12-18 02:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:36:37 --> Final output sent to browser
DEBUG - 2021-12-18 02:36:37 --> Total execution time: 0.0360
INFO - 2021-12-18 02:36:37 --> Config Class Initialized
INFO - 2021-12-18 02:36:37 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:38 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:38 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:38 --> URI Class Initialized
INFO - 2021-12-18 02:36:38 --> Router Class Initialized
INFO - 2021-12-18 02:36:38 --> Output Class Initialized
INFO - 2021-12-18 02:36:38 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:38 --> Input Class Initialized
INFO - 2021-12-18 02:36:38 --> Language Class Initialized
INFO - 2021-12-18 02:36:38 --> Language Class Initialized
INFO - 2021-12-18 02:36:38 --> Config Class Initialized
INFO - 2021-12-18 02:36:38 --> Loader Class Initialized
INFO - 2021-12-18 02:36:38 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:38 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:38 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:38 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:38 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:38 --> Controller Class Initialized
INFO - 2021-12-18 02:36:45 --> Config Class Initialized
INFO - 2021-12-18 02:36:45 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:45 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:45 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:45 --> URI Class Initialized
INFO - 2021-12-18 02:36:45 --> Router Class Initialized
INFO - 2021-12-18 02:36:45 --> Output Class Initialized
INFO - 2021-12-18 02:36:45 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:45 --> Input Class Initialized
INFO - 2021-12-18 02:36:45 --> Language Class Initialized
INFO - 2021-12-18 02:36:45 --> Language Class Initialized
INFO - 2021-12-18 02:36:45 --> Config Class Initialized
INFO - 2021-12-18 02:36:45 --> Loader Class Initialized
INFO - 2021-12-18 02:36:45 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:45 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:45 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:45 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:45 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:45 --> Controller Class Initialized
DEBUG - 2021-12-18 02:36:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:36:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:36:45 --> Final output sent to browser
DEBUG - 2021-12-18 02:36:45 --> Total execution time: 0.0500
INFO - 2021-12-18 02:36:57 --> Config Class Initialized
INFO - 2021-12-18 02:36:57 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:57 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:57 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:57 --> URI Class Initialized
INFO - 2021-12-18 02:36:57 --> Router Class Initialized
INFO - 2021-12-18 02:36:57 --> Output Class Initialized
INFO - 2021-12-18 02:36:57 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:57 --> Input Class Initialized
INFO - 2021-12-18 02:36:57 --> Language Class Initialized
INFO - 2021-12-18 02:36:57 --> Language Class Initialized
INFO - 2021-12-18 02:36:57 --> Config Class Initialized
INFO - 2021-12-18 02:36:57 --> Loader Class Initialized
INFO - 2021-12-18 02:36:57 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:57 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:57 --> Controller Class Initialized
INFO - 2021-12-18 02:36:57 --> Config Class Initialized
INFO - 2021-12-18 02:36:57 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:57 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:57 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:57 --> URI Class Initialized
INFO - 2021-12-18 02:36:57 --> Router Class Initialized
INFO - 2021-12-18 02:36:57 --> Output Class Initialized
INFO - 2021-12-18 02:36:57 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:57 --> Input Class Initialized
INFO - 2021-12-18 02:36:57 --> Language Class Initialized
INFO - 2021-12-18 02:36:57 --> Language Class Initialized
INFO - 2021-12-18 02:36:57 --> Config Class Initialized
INFO - 2021-12-18 02:36:57 --> Loader Class Initialized
INFO - 2021-12-18 02:36:57 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:57 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:57 --> Controller Class Initialized
DEBUG - 2021-12-18 02:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:36:57 --> Final output sent to browser
DEBUG - 2021-12-18 02:36:57 --> Total execution time: 0.0360
INFO - 2021-12-18 02:36:57 --> Config Class Initialized
INFO - 2021-12-18 02:36:57 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:36:57 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:36:57 --> Utf8 Class Initialized
INFO - 2021-12-18 02:36:57 --> URI Class Initialized
INFO - 2021-12-18 02:36:57 --> Router Class Initialized
INFO - 2021-12-18 02:36:57 --> Output Class Initialized
INFO - 2021-12-18 02:36:57 --> Security Class Initialized
DEBUG - 2021-12-18 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:36:57 --> Input Class Initialized
INFO - 2021-12-18 02:36:57 --> Language Class Initialized
INFO - 2021-12-18 02:36:57 --> Language Class Initialized
INFO - 2021-12-18 02:36:57 --> Config Class Initialized
INFO - 2021-12-18 02:36:57 --> Loader Class Initialized
INFO - 2021-12-18 02:36:57 --> Helper loaded: url_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: file_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: form_helper
INFO - 2021-12-18 02:36:57 --> Helper loaded: my_helper
INFO - 2021-12-18 02:36:57 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:36:57 --> Controller Class Initialized
INFO - 2021-12-18 02:37:04 --> Config Class Initialized
INFO - 2021-12-18 02:37:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:04 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:04 --> URI Class Initialized
INFO - 2021-12-18 02:37:04 --> Router Class Initialized
INFO - 2021-12-18 02:37:04 --> Output Class Initialized
INFO - 2021-12-18 02:37:04 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:04 --> Input Class Initialized
INFO - 2021-12-18 02:37:04 --> Language Class Initialized
INFO - 2021-12-18 02:37:04 --> Language Class Initialized
INFO - 2021-12-18 02:37:04 --> Config Class Initialized
INFO - 2021-12-18 02:37:04 --> Loader Class Initialized
INFO - 2021-12-18 02:37:04 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:04 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:04 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:04 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:04 --> Controller Class Initialized
DEBUG - 2021-12-18 02:37:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:37:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:37:04 --> Final output sent to browser
DEBUG - 2021-12-18 02:37:04 --> Total execution time: 0.0430
INFO - 2021-12-18 02:37:24 --> Config Class Initialized
INFO - 2021-12-18 02:37:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:24 --> URI Class Initialized
INFO - 2021-12-18 02:37:24 --> Router Class Initialized
INFO - 2021-12-18 02:37:24 --> Output Class Initialized
INFO - 2021-12-18 02:37:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:24 --> Input Class Initialized
INFO - 2021-12-18 02:37:24 --> Language Class Initialized
INFO - 2021-12-18 02:37:24 --> Language Class Initialized
INFO - 2021-12-18 02:37:24 --> Config Class Initialized
INFO - 2021-12-18 02:37:24 --> Loader Class Initialized
INFO - 2021-12-18 02:37:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:24 --> Controller Class Initialized
INFO - 2021-12-18 02:37:24 --> Config Class Initialized
INFO - 2021-12-18 02:37:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:24 --> URI Class Initialized
INFO - 2021-12-18 02:37:24 --> Router Class Initialized
INFO - 2021-12-18 02:37:24 --> Output Class Initialized
INFO - 2021-12-18 02:37:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:24 --> Input Class Initialized
INFO - 2021-12-18 02:37:24 --> Language Class Initialized
INFO - 2021-12-18 02:37:24 --> Language Class Initialized
INFO - 2021-12-18 02:37:24 --> Config Class Initialized
INFO - 2021-12-18 02:37:24 --> Loader Class Initialized
INFO - 2021-12-18 02:37:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:24 --> Controller Class Initialized
DEBUG - 2021-12-18 02:37:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:37:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:37:24 --> Final output sent to browser
DEBUG - 2021-12-18 02:37:24 --> Total execution time: 0.0360
INFO - 2021-12-18 02:37:24 --> Config Class Initialized
INFO - 2021-12-18 02:37:24 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:24 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:24 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:24 --> URI Class Initialized
INFO - 2021-12-18 02:37:24 --> Router Class Initialized
INFO - 2021-12-18 02:37:24 --> Output Class Initialized
INFO - 2021-12-18 02:37:24 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:24 --> Input Class Initialized
INFO - 2021-12-18 02:37:24 --> Language Class Initialized
INFO - 2021-12-18 02:37:24 --> Language Class Initialized
INFO - 2021-12-18 02:37:24 --> Config Class Initialized
INFO - 2021-12-18 02:37:24 --> Loader Class Initialized
INFO - 2021-12-18 02:37:24 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:24 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:24 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:24 --> Controller Class Initialized
INFO - 2021-12-18 02:37:25 --> Config Class Initialized
INFO - 2021-12-18 02:37:25 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:25 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:25 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:25 --> URI Class Initialized
INFO - 2021-12-18 02:37:25 --> Router Class Initialized
INFO - 2021-12-18 02:37:25 --> Output Class Initialized
INFO - 2021-12-18 02:37:25 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:25 --> Input Class Initialized
INFO - 2021-12-18 02:37:25 --> Language Class Initialized
INFO - 2021-12-18 02:37:25 --> Language Class Initialized
INFO - 2021-12-18 02:37:25 --> Config Class Initialized
INFO - 2021-12-18 02:37:25 --> Loader Class Initialized
INFO - 2021-12-18 02:37:25 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:25 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:25 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:25 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:25 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:25 --> Controller Class Initialized
DEBUG - 2021-12-18 02:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:37:25 --> Final output sent to browser
DEBUG - 2021-12-18 02:37:25 --> Total execution time: 0.0510
INFO - 2021-12-18 02:37:52 --> Config Class Initialized
INFO - 2021-12-18 02:37:52 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:52 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:52 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:52 --> URI Class Initialized
INFO - 2021-12-18 02:37:52 --> Router Class Initialized
INFO - 2021-12-18 02:37:52 --> Output Class Initialized
INFO - 2021-12-18 02:37:52 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:52 --> Input Class Initialized
INFO - 2021-12-18 02:37:52 --> Language Class Initialized
INFO - 2021-12-18 02:37:52 --> Language Class Initialized
INFO - 2021-12-18 02:37:52 --> Config Class Initialized
INFO - 2021-12-18 02:37:52 --> Loader Class Initialized
INFO - 2021-12-18 02:37:52 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:52 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:52 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:52 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:52 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:53 --> Controller Class Initialized
INFO - 2021-12-18 02:37:53 --> Config Class Initialized
INFO - 2021-12-18 02:37:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:53 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:53 --> URI Class Initialized
INFO - 2021-12-18 02:37:53 --> Router Class Initialized
INFO - 2021-12-18 02:37:53 --> Output Class Initialized
INFO - 2021-12-18 02:37:53 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:53 --> Input Class Initialized
INFO - 2021-12-18 02:37:53 --> Language Class Initialized
INFO - 2021-12-18 02:37:53 --> Language Class Initialized
INFO - 2021-12-18 02:37:53 --> Config Class Initialized
INFO - 2021-12-18 02:37:53 --> Loader Class Initialized
INFO - 2021-12-18 02:37:53 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:53 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:53 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:53 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:53 --> Controller Class Initialized
DEBUG - 2021-12-18 02:37:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:37:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:37:53 --> Final output sent to browser
DEBUG - 2021-12-18 02:37:53 --> Total execution time: 0.0370
INFO - 2021-12-18 02:37:53 --> Config Class Initialized
INFO - 2021-12-18 02:37:53 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:53 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:53 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:53 --> URI Class Initialized
INFO - 2021-12-18 02:37:53 --> Router Class Initialized
INFO - 2021-12-18 02:37:53 --> Output Class Initialized
INFO - 2021-12-18 02:37:53 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:53 --> Input Class Initialized
INFO - 2021-12-18 02:37:53 --> Language Class Initialized
INFO - 2021-12-18 02:37:53 --> Language Class Initialized
INFO - 2021-12-18 02:37:53 --> Config Class Initialized
INFO - 2021-12-18 02:37:53 --> Loader Class Initialized
INFO - 2021-12-18 02:37:53 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:53 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:53 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:53 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:53 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:53 --> Controller Class Initialized
INFO - 2021-12-18 02:37:54 --> Config Class Initialized
INFO - 2021-12-18 02:37:54 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:37:54 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:37:54 --> Utf8 Class Initialized
INFO - 2021-12-18 02:37:54 --> URI Class Initialized
INFO - 2021-12-18 02:37:54 --> Router Class Initialized
INFO - 2021-12-18 02:37:54 --> Output Class Initialized
INFO - 2021-12-18 02:37:54 --> Security Class Initialized
DEBUG - 2021-12-18 02:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:37:54 --> Input Class Initialized
INFO - 2021-12-18 02:37:54 --> Language Class Initialized
INFO - 2021-12-18 02:37:54 --> Language Class Initialized
INFO - 2021-12-18 02:37:54 --> Config Class Initialized
INFO - 2021-12-18 02:37:54 --> Loader Class Initialized
INFO - 2021-12-18 02:37:54 --> Helper loaded: url_helper
INFO - 2021-12-18 02:37:54 --> Helper loaded: file_helper
INFO - 2021-12-18 02:37:54 --> Helper loaded: form_helper
INFO - 2021-12-18 02:37:54 --> Helper loaded: my_helper
INFO - 2021-12-18 02:37:54 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:37:54 --> Controller Class Initialized
DEBUG - 2021-12-18 02:37:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-12-18 02:37:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:37:54 --> Final output sent to browser
DEBUG - 2021-12-18 02:37:54 --> Total execution time: 0.0530
INFO - 2021-12-18 02:38:20 --> Config Class Initialized
INFO - 2021-12-18 02:38:20 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:38:20 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:38:20 --> Utf8 Class Initialized
INFO - 2021-12-18 02:38:20 --> URI Class Initialized
INFO - 2021-12-18 02:38:20 --> Router Class Initialized
INFO - 2021-12-18 02:38:20 --> Output Class Initialized
INFO - 2021-12-18 02:38:20 --> Security Class Initialized
DEBUG - 2021-12-18 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:38:20 --> Input Class Initialized
INFO - 2021-12-18 02:38:20 --> Language Class Initialized
INFO - 2021-12-18 02:38:20 --> Language Class Initialized
INFO - 2021-12-18 02:38:20 --> Config Class Initialized
INFO - 2021-12-18 02:38:20 --> Loader Class Initialized
INFO - 2021-12-18 02:38:20 --> Helper loaded: url_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: file_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: form_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: my_helper
INFO - 2021-12-18 02:38:20 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:38:20 --> Controller Class Initialized
INFO - 2021-12-18 02:38:20 --> Config Class Initialized
INFO - 2021-12-18 02:38:20 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:38:20 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:38:20 --> Utf8 Class Initialized
INFO - 2021-12-18 02:38:20 --> URI Class Initialized
INFO - 2021-12-18 02:38:20 --> Router Class Initialized
INFO - 2021-12-18 02:38:20 --> Output Class Initialized
INFO - 2021-12-18 02:38:20 --> Security Class Initialized
DEBUG - 2021-12-18 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:38:20 --> Input Class Initialized
INFO - 2021-12-18 02:38:20 --> Language Class Initialized
INFO - 2021-12-18 02:38:20 --> Language Class Initialized
INFO - 2021-12-18 02:38:20 --> Config Class Initialized
INFO - 2021-12-18 02:38:20 --> Loader Class Initialized
INFO - 2021-12-18 02:38:20 --> Helper loaded: url_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: file_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: form_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: my_helper
INFO - 2021-12-18 02:38:20 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:38:20 --> Controller Class Initialized
DEBUG - 2021-12-18 02:38:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-18 02:38:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:38:20 --> Final output sent to browser
DEBUG - 2021-12-18 02:38:20 --> Total execution time: 0.0360
INFO - 2021-12-18 02:38:20 --> Config Class Initialized
INFO - 2021-12-18 02:38:20 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:38:20 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:38:20 --> Utf8 Class Initialized
INFO - 2021-12-18 02:38:20 --> URI Class Initialized
INFO - 2021-12-18 02:38:20 --> Router Class Initialized
INFO - 2021-12-18 02:38:20 --> Output Class Initialized
INFO - 2021-12-18 02:38:20 --> Security Class Initialized
DEBUG - 2021-12-18 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:38:20 --> Input Class Initialized
INFO - 2021-12-18 02:38:20 --> Language Class Initialized
INFO - 2021-12-18 02:38:20 --> Language Class Initialized
INFO - 2021-12-18 02:38:20 --> Config Class Initialized
INFO - 2021-12-18 02:38:20 --> Loader Class Initialized
INFO - 2021-12-18 02:38:20 --> Helper loaded: url_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: file_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: form_helper
INFO - 2021-12-18 02:38:20 --> Helper loaded: my_helper
INFO - 2021-12-18 02:38:20 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:38:20 --> Controller Class Initialized
INFO - 2021-12-18 02:58:19 --> Config Class Initialized
INFO - 2021-12-18 02:58:19 --> Hooks Class Initialized
DEBUG - 2021-12-18 02:58:19 --> UTF-8 Support Enabled
INFO - 2021-12-18 02:58:19 --> Utf8 Class Initialized
INFO - 2021-12-18 02:58:19 --> URI Class Initialized
DEBUG - 2021-12-18 02:58:19 --> No URI present. Default controller set.
INFO - 2021-12-18 02:58:19 --> Router Class Initialized
INFO - 2021-12-18 02:58:19 --> Output Class Initialized
INFO - 2021-12-18 02:58:19 --> Security Class Initialized
DEBUG - 2021-12-18 02:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 02:58:19 --> Input Class Initialized
INFO - 2021-12-18 02:58:19 --> Language Class Initialized
INFO - 2021-12-18 02:58:19 --> Language Class Initialized
INFO - 2021-12-18 02:58:19 --> Config Class Initialized
INFO - 2021-12-18 02:58:19 --> Loader Class Initialized
INFO - 2021-12-18 02:58:19 --> Helper loaded: url_helper
INFO - 2021-12-18 02:58:19 --> Helper loaded: file_helper
INFO - 2021-12-18 02:58:19 --> Helper loaded: form_helper
INFO - 2021-12-18 02:58:19 --> Helper loaded: my_helper
INFO - 2021-12-18 02:58:19 --> Database Driver Class Initialized
DEBUG - 2021-12-18 02:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 02:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 02:58:19 --> Controller Class Initialized
DEBUG - 2021-12-18 02:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-18 02:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-18 02:58:19 --> Final output sent to browser
DEBUG - 2021-12-18 02:58:19 --> Total execution time: 0.1780
