<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-02 07:58:40 --> Config Class Initialized
INFO - 2019-11-02 07:58:40 --> Hooks Class Initialized
DEBUG - 2019-11-02 07:58:40 --> UTF-8 Support Enabled
INFO - 2019-11-02 07:58:40 --> Utf8 Class Initialized
INFO - 2019-11-02 07:58:40 --> URI Class Initialized
INFO - 2019-11-02 07:58:41 --> Router Class Initialized
INFO - 2019-11-02 07:58:41 --> Output Class Initialized
INFO - 2019-11-02 07:58:41 --> Security Class Initialized
DEBUG - 2019-11-02 07:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 07:58:41 --> Input Class Initialized
INFO - 2019-11-02 07:58:41 --> Language Class Initialized
INFO - 2019-11-02 07:58:41 --> Language Class Initialized
INFO - 2019-11-02 07:58:41 --> Config Class Initialized
INFO - 2019-11-02 07:58:41 --> Loader Class Initialized
INFO - 2019-11-02 07:58:41 --> Helper loaded: url_helper
INFO - 2019-11-02 07:58:41 --> Helper loaded: file_helper
INFO - 2019-11-02 07:58:41 --> Helper loaded: form_helper
INFO - 2019-11-02 07:58:41 --> Helper loaded: my_helper
INFO - 2019-11-02 07:58:41 --> Database Driver Class Initialized
DEBUG - 2019-11-02 07:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 07:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 07:58:41 --> Controller Class Initialized
DEBUG - 2019-11-02 07:58:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 07:58:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 07:58:41 --> Final output sent to browser
DEBUG - 2019-11-02 07:58:41 --> Total execution time: 0.7579
INFO - 2019-11-02 07:59:49 --> Config Class Initialized
INFO - 2019-11-02 07:59:49 --> Hooks Class Initialized
DEBUG - 2019-11-02 07:59:49 --> UTF-8 Support Enabled
INFO - 2019-11-02 07:59:49 --> Utf8 Class Initialized
INFO - 2019-11-02 07:59:49 --> URI Class Initialized
INFO - 2019-11-02 07:59:49 --> Router Class Initialized
INFO - 2019-11-02 07:59:49 --> Output Class Initialized
INFO - 2019-11-02 07:59:49 --> Security Class Initialized
DEBUG - 2019-11-02 07:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 07:59:49 --> Input Class Initialized
INFO - 2019-11-02 07:59:49 --> Language Class Initialized
INFO - 2019-11-02 07:59:49 --> Language Class Initialized
INFO - 2019-11-02 07:59:49 --> Config Class Initialized
INFO - 2019-11-02 07:59:49 --> Loader Class Initialized
INFO - 2019-11-02 07:59:49 --> Helper loaded: url_helper
INFO - 2019-11-02 07:59:49 --> Helper loaded: file_helper
INFO - 2019-11-02 07:59:49 --> Helper loaded: form_helper
INFO - 2019-11-02 07:59:49 --> Helper loaded: my_helper
INFO - 2019-11-02 07:59:49 --> Database Driver Class Initialized
DEBUG - 2019-11-02 07:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 07:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 07:59:49 --> Controller Class Initialized
DEBUG - 2019-11-02 07:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2019-11-02 07:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 07:59:49 --> Final output sent to browser
DEBUG - 2019-11-02 07:59:49 --> Total execution time: 0.0828
INFO - 2019-11-02 07:59:49 --> Config Class Initialized
INFO - 2019-11-02 07:59:49 --> Hooks Class Initialized
DEBUG - 2019-11-02 07:59:49 --> UTF-8 Support Enabled
INFO - 2019-11-02 07:59:49 --> Utf8 Class Initialized
INFO - 2019-11-02 07:59:49 --> URI Class Initialized
INFO - 2019-11-02 07:59:49 --> Router Class Initialized
INFO - 2019-11-02 07:59:49 --> Output Class Initialized
INFO - 2019-11-02 07:59:49 --> Security Class Initialized
DEBUG - 2019-11-02 07:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 07:59:49 --> Input Class Initialized
INFO - 2019-11-02 07:59:49 --> Language Class Initialized
INFO - 2019-11-02 07:59:49 --> Language Class Initialized
INFO - 2019-11-02 07:59:49 --> Config Class Initialized
INFO - 2019-11-02 07:59:49 --> Loader Class Initialized
INFO - 2019-11-02 07:59:49 --> Helper loaded: url_helper
INFO - 2019-11-02 07:59:49 --> Helper loaded: file_helper
INFO - 2019-11-02 07:59:49 --> Helper loaded: form_helper
INFO - 2019-11-02 07:59:49 --> Helper loaded: my_helper
INFO - 2019-11-02 07:59:49 --> Database Driver Class Initialized
DEBUG - 2019-11-02 07:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 07:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 07:59:49 --> Controller Class Initialized
INFO - 2019-11-02 08:00:11 --> Config Class Initialized
INFO - 2019-11-02 08:00:11 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:00:11 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:00:11 --> Utf8 Class Initialized
INFO - 2019-11-02 08:00:11 --> URI Class Initialized
INFO - 2019-11-02 08:00:11 --> Router Class Initialized
INFO - 2019-11-02 08:00:11 --> Output Class Initialized
INFO - 2019-11-02 08:00:11 --> Security Class Initialized
DEBUG - 2019-11-02 08:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:00:11 --> Input Class Initialized
INFO - 2019-11-02 08:00:11 --> Language Class Initialized
INFO - 2019-11-02 08:00:11 --> Language Class Initialized
INFO - 2019-11-02 08:00:11 --> Config Class Initialized
INFO - 2019-11-02 08:00:11 --> Loader Class Initialized
INFO - 2019-11-02 08:00:11 --> Helper loaded: url_helper
INFO - 2019-11-02 08:00:11 --> Helper loaded: file_helper
INFO - 2019-11-02 08:00:11 --> Helper loaded: form_helper
INFO - 2019-11-02 08:00:11 --> Helper loaded: my_helper
INFO - 2019-11-02 08:00:11 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:00:11 --> Controller Class Initialized
INFO - 2019-11-02 08:00:11 --> Final output sent to browser
DEBUG - 2019-11-02 08:00:11 --> Total execution time: 0.0461
INFO - 2019-11-02 08:00:11 --> Config Class Initialized
INFO - 2019-11-02 08:00:11 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:00:11 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:00:11 --> Utf8 Class Initialized
INFO - 2019-11-02 08:00:11 --> URI Class Initialized
INFO - 2019-11-02 08:00:11 --> Router Class Initialized
INFO - 2019-11-02 08:00:11 --> Output Class Initialized
INFO - 2019-11-02 08:00:11 --> Security Class Initialized
DEBUG - 2019-11-02 08:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:00:11 --> Input Class Initialized
INFO - 2019-11-02 08:00:11 --> Language Class Initialized
INFO - 2019-11-02 08:00:11 --> Language Class Initialized
INFO - 2019-11-02 08:00:11 --> Config Class Initialized
INFO - 2019-11-02 08:00:11 --> Loader Class Initialized
INFO - 2019-11-02 08:00:11 --> Helper loaded: url_helper
INFO - 2019-11-02 08:00:11 --> Helper loaded: file_helper
INFO - 2019-11-02 08:00:11 --> Helper loaded: form_helper
INFO - 2019-11-02 08:00:11 --> Helper loaded: my_helper
INFO - 2019-11-02 08:00:11 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:00:11 --> Controller Class Initialized
INFO - 2019-11-02 08:00:13 --> Config Class Initialized
INFO - 2019-11-02 08:00:13 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:00:13 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:00:13 --> Utf8 Class Initialized
INFO - 2019-11-02 08:00:13 --> URI Class Initialized
INFO - 2019-11-02 08:00:13 --> Router Class Initialized
INFO - 2019-11-02 08:00:13 --> Output Class Initialized
INFO - 2019-11-02 08:00:13 --> Security Class Initialized
DEBUG - 2019-11-02 08:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:00:13 --> Input Class Initialized
INFO - 2019-11-02 08:00:13 --> Language Class Initialized
INFO - 2019-11-02 08:00:13 --> Language Class Initialized
INFO - 2019-11-02 08:00:13 --> Config Class Initialized
INFO - 2019-11-02 08:00:13 --> Loader Class Initialized
INFO - 2019-11-02 08:00:13 --> Helper loaded: url_helper
INFO - 2019-11-02 08:00:13 --> Helper loaded: file_helper
INFO - 2019-11-02 08:00:13 --> Helper loaded: form_helper
INFO - 2019-11-02 08:00:13 --> Helper loaded: my_helper
INFO - 2019-11-02 08:00:13 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:00:13 --> Controller Class Initialized
DEBUG - 2019-11-02 08:00:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 08:00:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:00:13 --> Final output sent to browser
DEBUG - 2019-11-02 08:00:13 --> Total execution time: 0.0817
INFO - 2019-11-02 08:00:31 --> Config Class Initialized
INFO - 2019-11-02 08:00:31 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:00:31 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:00:31 --> Utf8 Class Initialized
INFO - 2019-11-02 08:00:31 --> URI Class Initialized
INFO - 2019-11-02 08:00:31 --> Router Class Initialized
INFO - 2019-11-02 08:00:31 --> Output Class Initialized
INFO - 2019-11-02 08:00:31 --> Security Class Initialized
DEBUG - 2019-11-02 08:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:00:31 --> Input Class Initialized
INFO - 2019-11-02 08:00:31 --> Language Class Initialized
INFO - 2019-11-02 08:00:31 --> Language Class Initialized
INFO - 2019-11-02 08:00:31 --> Config Class Initialized
INFO - 2019-11-02 08:00:31 --> Loader Class Initialized
INFO - 2019-11-02 08:00:31 --> Helper loaded: url_helper
INFO - 2019-11-02 08:00:31 --> Helper loaded: file_helper
INFO - 2019-11-02 08:00:31 --> Helper loaded: form_helper
INFO - 2019-11-02 08:00:31 --> Helper loaded: my_helper
INFO - 2019-11-02 08:00:31 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:00:31 --> Controller Class Initialized
DEBUG - 2019-11-02 08:00:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2019-11-02 08:00:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:00:31 --> Final output sent to browser
DEBUG - 2019-11-02 08:00:31 --> Total execution time: 0.0822
INFO - 2019-11-02 08:00:31 --> Config Class Initialized
INFO - 2019-11-02 08:00:31 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:00:31 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:00:31 --> Utf8 Class Initialized
INFO - 2019-11-02 08:00:31 --> URI Class Initialized
INFO - 2019-11-02 08:00:31 --> Router Class Initialized
INFO - 2019-11-02 08:00:31 --> Output Class Initialized
INFO - 2019-11-02 08:00:31 --> Security Class Initialized
DEBUG - 2019-11-02 08:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:00:31 --> Input Class Initialized
INFO - 2019-11-02 08:00:31 --> Language Class Initialized
INFO - 2019-11-02 08:00:31 --> Language Class Initialized
INFO - 2019-11-02 08:00:31 --> Config Class Initialized
INFO - 2019-11-02 08:00:31 --> Loader Class Initialized
INFO - 2019-11-02 08:00:31 --> Helper loaded: url_helper
INFO - 2019-11-02 08:00:31 --> Helper loaded: file_helper
INFO - 2019-11-02 08:00:31 --> Helper loaded: form_helper
INFO - 2019-11-02 08:00:31 --> Helper loaded: my_helper
INFO - 2019-11-02 08:00:31 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:00:31 --> Controller Class Initialized
INFO - 2019-11-02 08:00:33 --> Config Class Initialized
INFO - 2019-11-02 08:00:33 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:00:33 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:00:33 --> Utf8 Class Initialized
INFO - 2019-11-02 08:00:33 --> URI Class Initialized
INFO - 2019-11-02 08:00:33 --> Router Class Initialized
INFO - 2019-11-02 08:00:33 --> Output Class Initialized
INFO - 2019-11-02 08:00:33 --> Security Class Initialized
DEBUG - 2019-11-02 08:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:00:33 --> Input Class Initialized
INFO - 2019-11-02 08:00:33 --> Language Class Initialized
INFO - 2019-11-02 08:00:33 --> Language Class Initialized
INFO - 2019-11-02 08:00:33 --> Config Class Initialized
INFO - 2019-11-02 08:00:33 --> Loader Class Initialized
INFO - 2019-11-02 08:00:33 --> Helper loaded: url_helper
INFO - 2019-11-02 08:00:33 --> Helper loaded: file_helper
INFO - 2019-11-02 08:00:33 --> Helper loaded: form_helper
INFO - 2019-11-02 08:00:33 --> Helper loaded: my_helper
INFO - 2019-11-02 08:00:33 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:00:33 --> Controller Class Initialized
INFO - 2019-11-02 08:00:33 --> Final output sent to browser
DEBUG - 2019-11-02 08:00:33 --> Total execution time: 0.0623
INFO - 2019-11-02 08:02:07 --> Config Class Initialized
INFO - 2019-11-02 08:02:07 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:02:07 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:02:07 --> Utf8 Class Initialized
INFO - 2019-11-02 08:02:07 --> URI Class Initialized
INFO - 2019-11-02 08:02:07 --> Router Class Initialized
INFO - 2019-11-02 08:02:07 --> Output Class Initialized
INFO - 2019-11-02 08:02:07 --> Security Class Initialized
DEBUG - 2019-11-02 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:02:07 --> Input Class Initialized
INFO - 2019-11-02 08:02:07 --> Language Class Initialized
INFO - 2019-11-02 08:02:07 --> Language Class Initialized
INFO - 2019-11-02 08:02:07 --> Config Class Initialized
INFO - 2019-11-02 08:02:07 --> Loader Class Initialized
INFO - 2019-11-02 08:02:07 --> Helper loaded: url_helper
INFO - 2019-11-02 08:02:07 --> Helper loaded: file_helper
INFO - 2019-11-02 08:02:07 --> Helper loaded: form_helper
INFO - 2019-11-02 08:02:07 --> Helper loaded: my_helper
INFO - 2019-11-02 08:02:07 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:02:07 --> Controller Class Initialized
DEBUG - 2019-11-02 08:02:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 08:02:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:02:07 --> Final output sent to browser
DEBUG - 2019-11-02 08:02:07 --> Total execution time: 0.0841
INFO - 2019-11-02 08:02:19 --> Config Class Initialized
INFO - 2019-11-02 08:02:19 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:02:19 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:02:19 --> Utf8 Class Initialized
INFO - 2019-11-02 08:02:19 --> URI Class Initialized
INFO - 2019-11-02 08:02:19 --> Router Class Initialized
INFO - 2019-11-02 08:02:19 --> Output Class Initialized
INFO - 2019-11-02 08:02:19 --> Security Class Initialized
DEBUG - 2019-11-02 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:02:19 --> Input Class Initialized
INFO - 2019-11-02 08:02:19 --> Language Class Initialized
INFO - 2019-11-02 08:02:19 --> Language Class Initialized
INFO - 2019-11-02 08:02:19 --> Config Class Initialized
INFO - 2019-11-02 08:02:19 --> Loader Class Initialized
INFO - 2019-11-02 08:02:19 --> Helper loaded: url_helper
INFO - 2019-11-02 08:02:19 --> Helper loaded: file_helper
INFO - 2019-11-02 08:02:19 --> Helper loaded: form_helper
INFO - 2019-11-02 08:02:19 --> Helper loaded: my_helper
INFO - 2019-11-02 08:02:19 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:02:19 --> Controller Class Initialized
DEBUG - 2019-11-02 08:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2019-11-02 08:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:02:19 --> Final output sent to browser
DEBUG - 2019-11-02 08:02:19 --> Total execution time: 0.0639
INFO - 2019-11-02 08:02:19 --> Config Class Initialized
INFO - 2019-11-02 08:02:19 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:02:19 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:02:19 --> Utf8 Class Initialized
INFO - 2019-11-02 08:02:19 --> URI Class Initialized
INFO - 2019-11-02 08:02:19 --> Router Class Initialized
INFO - 2019-11-02 08:02:19 --> Output Class Initialized
INFO - 2019-11-02 08:02:19 --> Security Class Initialized
DEBUG - 2019-11-02 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:02:19 --> Input Class Initialized
INFO - 2019-11-02 08:02:19 --> Language Class Initialized
INFO - 2019-11-02 08:02:19 --> Language Class Initialized
INFO - 2019-11-02 08:02:19 --> Config Class Initialized
INFO - 2019-11-02 08:02:19 --> Loader Class Initialized
INFO - 2019-11-02 08:02:19 --> Helper loaded: url_helper
INFO - 2019-11-02 08:02:19 --> Helper loaded: file_helper
INFO - 2019-11-02 08:02:19 --> Helper loaded: form_helper
INFO - 2019-11-02 08:02:19 --> Helper loaded: my_helper
INFO - 2019-11-02 08:02:19 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:02:19 --> Controller Class Initialized
INFO - 2019-11-02 08:02:20 --> Config Class Initialized
INFO - 2019-11-02 08:02:20 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:02:20 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:02:20 --> Utf8 Class Initialized
INFO - 2019-11-02 08:02:20 --> URI Class Initialized
INFO - 2019-11-02 08:02:20 --> Router Class Initialized
INFO - 2019-11-02 08:02:20 --> Output Class Initialized
INFO - 2019-11-02 08:02:20 --> Security Class Initialized
DEBUG - 2019-11-02 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:02:20 --> Input Class Initialized
INFO - 2019-11-02 08:02:20 --> Language Class Initialized
INFO - 2019-11-02 08:02:20 --> Language Class Initialized
INFO - 2019-11-02 08:02:20 --> Config Class Initialized
INFO - 2019-11-02 08:02:20 --> Loader Class Initialized
INFO - 2019-11-02 08:02:20 --> Helper loaded: url_helper
INFO - 2019-11-02 08:02:20 --> Helper loaded: file_helper
INFO - 2019-11-02 08:02:20 --> Helper loaded: form_helper
INFO - 2019-11-02 08:02:20 --> Helper loaded: my_helper
INFO - 2019-11-02 08:02:20 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:02:20 --> Controller Class Initialized
INFO - 2019-11-02 08:02:20 --> Final output sent to browser
DEBUG - 2019-11-02 08:02:20 --> Total execution time: 0.0561
INFO - 2019-11-02 08:02:20 --> Config Class Initialized
INFO - 2019-11-02 08:02:20 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:02:20 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:02:20 --> Utf8 Class Initialized
INFO - 2019-11-02 08:02:20 --> URI Class Initialized
INFO - 2019-11-02 08:02:20 --> Router Class Initialized
INFO - 2019-11-02 08:02:20 --> Output Class Initialized
INFO - 2019-11-02 08:02:20 --> Security Class Initialized
DEBUG - 2019-11-02 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:02:20 --> Input Class Initialized
INFO - 2019-11-02 08:02:20 --> Language Class Initialized
INFO - 2019-11-02 08:02:20 --> Language Class Initialized
INFO - 2019-11-02 08:02:20 --> Config Class Initialized
INFO - 2019-11-02 08:02:20 --> Loader Class Initialized
INFO - 2019-11-02 08:02:20 --> Helper loaded: url_helper
INFO - 2019-11-02 08:02:20 --> Helper loaded: file_helper
INFO - 2019-11-02 08:02:20 --> Helper loaded: form_helper
INFO - 2019-11-02 08:02:20 --> Helper loaded: my_helper
INFO - 2019-11-02 08:02:20 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:02:20 --> Controller Class Initialized
INFO - 2019-11-02 08:05:36 --> Config Class Initialized
INFO - 2019-11-02 08:05:36 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:05:36 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:05:36 --> Utf8 Class Initialized
INFO - 2019-11-02 08:05:36 --> URI Class Initialized
INFO - 2019-11-02 08:05:36 --> Router Class Initialized
INFO - 2019-11-02 08:05:36 --> Output Class Initialized
INFO - 2019-11-02 08:05:36 --> Security Class Initialized
DEBUG - 2019-11-02 08:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:05:36 --> Input Class Initialized
INFO - 2019-11-02 08:05:36 --> Language Class Initialized
INFO - 2019-11-02 08:05:36 --> Language Class Initialized
INFO - 2019-11-02 08:05:36 --> Config Class Initialized
INFO - 2019-11-02 08:05:36 --> Loader Class Initialized
INFO - 2019-11-02 08:05:36 --> Helper loaded: url_helper
INFO - 2019-11-02 08:05:36 --> Helper loaded: file_helper
INFO - 2019-11-02 08:05:36 --> Helper loaded: form_helper
INFO - 2019-11-02 08:05:36 --> Helper loaded: my_helper
INFO - 2019-11-02 08:05:36 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:05:36 --> Controller Class Initialized
INFO - 2019-11-02 08:05:36 --> Helper loaded: cookie_helper
INFO - 2019-11-02 08:05:36 --> Config Class Initialized
INFO - 2019-11-02 08:05:36 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:05:36 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:05:36 --> Utf8 Class Initialized
INFO - 2019-11-02 08:05:36 --> URI Class Initialized
INFO - 2019-11-02 08:05:36 --> Router Class Initialized
INFO - 2019-11-02 08:05:36 --> Output Class Initialized
INFO - 2019-11-02 08:05:36 --> Security Class Initialized
DEBUG - 2019-11-02 08:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:05:36 --> Input Class Initialized
INFO - 2019-11-02 08:05:36 --> Language Class Initialized
INFO - 2019-11-02 08:05:36 --> Language Class Initialized
INFO - 2019-11-02 08:05:36 --> Config Class Initialized
INFO - 2019-11-02 08:05:36 --> Loader Class Initialized
INFO - 2019-11-02 08:05:36 --> Helper loaded: url_helper
INFO - 2019-11-02 08:05:36 --> Helper loaded: file_helper
INFO - 2019-11-02 08:05:36 --> Helper loaded: form_helper
INFO - 2019-11-02 08:05:36 --> Helper loaded: my_helper
INFO - 2019-11-02 08:05:36 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:05:36 --> Controller Class Initialized
DEBUG - 2019-11-02 08:05:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-11-02 08:05:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:05:36 --> Final output sent to browser
DEBUG - 2019-11-02 08:05:36 --> Total execution time: 0.0513
INFO - 2019-11-02 08:05:52 --> Config Class Initialized
INFO - 2019-11-02 08:05:52 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:05:52 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:05:52 --> Utf8 Class Initialized
INFO - 2019-11-02 08:05:52 --> URI Class Initialized
INFO - 2019-11-02 08:05:52 --> Router Class Initialized
INFO - 2019-11-02 08:05:52 --> Output Class Initialized
INFO - 2019-11-02 08:05:52 --> Security Class Initialized
DEBUG - 2019-11-02 08:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:05:52 --> Input Class Initialized
INFO - 2019-11-02 08:05:52 --> Language Class Initialized
INFO - 2019-11-02 08:05:52 --> Language Class Initialized
INFO - 2019-11-02 08:05:52 --> Config Class Initialized
INFO - 2019-11-02 08:05:52 --> Loader Class Initialized
INFO - 2019-11-02 08:05:52 --> Helper loaded: url_helper
INFO - 2019-11-02 08:05:52 --> Helper loaded: file_helper
INFO - 2019-11-02 08:05:52 --> Helper loaded: form_helper
INFO - 2019-11-02 08:05:52 --> Helper loaded: my_helper
INFO - 2019-11-02 08:05:52 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:05:53 --> Controller Class Initialized
INFO - 2019-11-02 08:05:53 --> Helper loaded: cookie_helper
INFO - 2019-11-02 08:05:53 --> Final output sent to browser
DEBUG - 2019-11-02 08:05:53 --> Total execution time: 0.0763
INFO - 2019-11-02 08:05:53 --> Config Class Initialized
INFO - 2019-11-02 08:05:53 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:05:53 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:05:53 --> Utf8 Class Initialized
INFO - 2019-11-02 08:05:53 --> URI Class Initialized
INFO - 2019-11-02 08:05:53 --> Router Class Initialized
INFO - 2019-11-02 08:05:53 --> Output Class Initialized
INFO - 2019-11-02 08:05:53 --> Security Class Initialized
DEBUG - 2019-11-02 08:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:05:53 --> Input Class Initialized
INFO - 2019-11-02 08:05:53 --> Language Class Initialized
INFO - 2019-11-02 08:05:53 --> Language Class Initialized
INFO - 2019-11-02 08:05:53 --> Config Class Initialized
INFO - 2019-11-02 08:05:53 --> Loader Class Initialized
INFO - 2019-11-02 08:05:53 --> Helper loaded: url_helper
INFO - 2019-11-02 08:05:53 --> Helper loaded: file_helper
INFO - 2019-11-02 08:05:53 --> Helper loaded: form_helper
INFO - 2019-11-02 08:05:53 --> Helper loaded: my_helper
INFO - 2019-11-02 08:05:53 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:05:53 --> Controller Class Initialized
DEBUG - 2019-11-02 08:05:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-11-02 08:05:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:05:53 --> Final output sent to browser
DEBUG - 2019-11-02 08:05:53 --> Total execution time: 0.1650
INFO - 2019-11-02 08:05:55 --> Config Class Initialized
INFO - 2019-11-02 08:05:55 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:05:55 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:05:55 --> Utf8 Class Initialized
INFO - 2019-11-02 08:05:55 --> URI Class Initialized
INFO - 2019-11-02 08:05:55 --> Router Class Initialized
INFO - 2019-11-02 08:05:55 --> Output Class Initialized
INFO - 2019-11-02 08:05:55 --> Security Class Initialized
DEBUG - 2019-11-02 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:05:55 --> Input Class Initialized
INFO - 2019-11-02 08:05:55 --> Language Class Initialized
INFO - 2019-11-02 08:05:55 --> Language Class Initialized
INFO - 2019-11-02 08:05:55 --> Config Class Initialized
INFO - 2019-11-02 08:05:55 --> Loader Class Initialized
INFO - 2019-11-02 08:05:55 --> Helper loaded: url_helper
INFO - 2019-11-02 08:05:55 --> Helper loaded: file_helper
INFO - 2019-11-02 08:05:55 --> Helper loaded: form_helper
INFO - 2019-11-02 08:05:55 --> Helper loaded: my_helper
INFO - 2019-11-02 08:05:55 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:05:55 --> Controller Class Initialized
DEBUG - 2019-11-02 08:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-11-02 08:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:05:55 --> Final output sent to browser
DEBUG - 2019-11-02 08:05:55 --> Total execution time: 0.1040
INFO - 2019-11-02 08:06:19 --> Config Class Initialized
INFO - 2019-11-02 08:06:19 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:06:19 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:06:19 --> Utf8 Class Initialized
INFO - 2019-11-02 08:06:19 --> URI Class Initialized
INFO - 2019-11-02 08:06:19 --> Router Class Initialized
INFO - 2019-11-02 08:06:19 --> Output Class Initialized
INFO - 2019-11-02 08:06:19 --> Security Class Initialized
DEBUG - 2019-11-02 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:06:19 --> Input Class Initialized
INFO - 2019-11-02 08:06:19 --> Language Class Initialized
INFO - 2019-11-02 08:06:19 --> Language Class Initialized
INFO - 2019-11-02 08:06:19 --> Config Class Initialized
INFO - 2019-11-02 08:06:19 --> Loader Class Initialized
INFO - 2019-11-02 08:06:19 --> Helper loaded: url_helper
INFO - 2019-11-02 08:06:19 --> Helper loaded: file_helper
INFO - 2019-11-02 08:06:19 --> Helper loaded: form_helper
INFO - 2019-11-02 08:06:19 --> Helper loaded: my_helper
INFO - 2019-11-02 08:06:19 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:06:19 --> Controller Class Initialized
DEBUG - 2019-11-02 08:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:06:19 --> Final output sent to browser
DEBUG - 2019-11-02 08:06:19 --> Total execution time: 0.0981
INFO - 2019-11-02 08:06:19 --> Config Class Initialized
INFO - 2019-11-02 08:06:19 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:06:19 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:06:19 --> Utf8 Class Initialized
INFO - 2019-11-02 08:06:19 --> URI Class Initialized
INFO - 2019-11-02 08:06:19 --> Router Class Initialized
INFO - 2019-11-02 08:06:19 --> Output Class Initialized
INFO - 2019-11-02 08:06:19 --> Security Class Initialized
DEBUG - 2019-11-02 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:06:19 --> Input Class Initialized
INFO - 2019-11-02 08:06:19 --> Language Class Initialized
INFO - 2019-11-02 08:06:19 --> Language Class Initialized
INFO - 2019-11-02 08:06:19 --> Config Class Initialized
INFO - 2019-11-02 08:06:19 --> Loader Class Initialized
INFO - 2019-11-02 08:06:19 --> Helper loaded: url_helper
INFO - 2019-11-02 08:06:19 --> Helper loaded: file_helper
INFO - 2019-11-02 08:06:19 --> Helper loaded: form_helper
INFO - 2019-11-02 08:06:19 --> Helper loaded: my_helper
INFO - 2019-11-02 08:06:19 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:06:19 --> Controller Class Initialized
INFO - 2019-11-02 08:06:20 --> Config Class Initialized
INFO - 2019-11-02 08:06:20 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:06:20 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:06:20 --> Utf8 Class Initialized
INFO - 2019-11-02 08:06:20 --> URI Class Initialized
INFO - 2019-11-02 08:06:20 --> Router Class Initialized
INFO - 2019-11-02 08:06:20 --> Output Class Initialized
INFO - 2019-11-02 08:06:20 --> Security Class Initialized
DEBUG - 2019-11-02 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:06:20 --> Input Class Initialized
INFO - 2019-11-02 08:06:20 --> Language Class Initialized
INFO - 2019-11-02 08:06:20 --> Language Class Initialized
INFO - 2019-11-02 08:06:20 --> Config Class Initialized
INFO - 2019-11-02 08:06:20 --> Loader Class Initialized
INFO - 2019-11-02 08:06:20 --> Helper loaded: url_helper
INFO - 2019-11-02 08:06:20 --> Helper loaded: file_helper
INFO - 2019-11-02 08:06:20 --> Helper loaded: form_helper
INFO - 2019-11-02 08:06:20 --> Helper loaded: my_helper
INFO - 2019-11-02 08:06:20 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:06:20 --> Controller Class Initialized
DEBUG - 2019-11-02 08:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:06:20 --> Final output sent to browser
DEBUG - 2019-11-02 08:06:20 --> Total execution time: 0.1134
INFO - 2019-11-02 08:06:23 --> Config Class Initialized
INFO - 2019-11-02 08:06:23 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:06:23 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:06:23 --> Utf8 Class Initialized
INFO - 2019-11-02 08:06:23 --> URI Class Initialized
INFO - 2019-11-02 08:06:23 --> Router Class Initialized
INFO - 2019-11-02 08:06:23 --> Output Class Initialized
INFO - 2019-11-02 08:06:23 --> Security Class Initialized
DEBUG - 2019-11-02 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:06:23 --> Input Class Initialized
INFO - 2019-11-02 08:06:23 --> Language Class Initialized
INFO - 2019-11-02 08:06:23 --> Language Class Initialized
INFO - 2019-11-02 08:06:23 --> Config Class Initialized
INFO - 2019-11-02 08:06:23 --> Loader Class Initialized
INFO - 2019-11-02 08:06:23 --> Helper loaded: url_helper
INFO - 2019-11-02 08:06:23 --> Helper loaded: file_helper
INFO - 2019-11-02 08:06:23 --> Helper loaded: form_helper
INFO - 2019-11-02 08:06:23 --> Helper loaded: my_helper
INFO - 2019-11-02 08:06:23 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:06:23 --> Controller Class Initialized
INFO - 2019-11-02 08:06:23 --> Final output sent to browser
DEBUG - 2019-11-02 08:06:23 --> Total execution time: 0.0652
INFO - 2019-11-02 08:07:01 --> Config Class Initialized
INFO - 2019-11-02 08:07:01 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:07:01 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:07:01 --> Utf8 Class Initialized
INFO - 2019-11-02 08:07:01 --> URI Class Initialized
INFO - 2019-11-02 08:07:01 --> Router Class Initialized
INFO - 2019-11-02 08:07:01 --> Output Class Initialized
INFO - 2019-11-02 08:07:01 --> Security Class Initialized
DEBUG - 2019-11-02 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:07:01 --> Input Class Initialized
INFO - 2019-11-02 08:07:01 --> Language Class Initialized
INFO - 2019-11-02 08:07:01 --> Language Class Initialized
INFO - 2019-11-02 08:07:01 --> Config Class Initialized
INFO - 2019-11-02 08:07:01 --> Loader Class Initialized
INFO - 2019-11-02 08:07:01 --> Helper loaded: url_helper
INFO - 2019-11-02 08:07:01 --> Helper loaded: file_helper
INFO - 2019-11-02 08:07:01 --> Helper loaded: form_helper
INFO - 2019-11-02 08:07:01 --> Helper loaded: my_helper
INFO - 2019-11-02 08:07:01 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:07:01 --> Controller Class Initialized
INFO - 2019-11-02 08:07:05 --> Config Class Initialized
INFO - 2019-11-02 08:07:05 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:07:05 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:07:05 --> Utf8 Class Initialized
INFO - 2019-11-02 08:07:05 --> URI Class Initialized
INFO - 2019-11-02 08:07:05 --> Router Class Initialized
INFO - 2019-11-02 08:07:05 --> Output Class Initialized
INFO - 2019-11-02 08:07:05 --> Security Class Initialized
DEBUG - 2019-11-02 08:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:07:05 --> Input Class Initialized
INFO - 2019-11-02 08:07:05 --> Language Class Initialized
INFO - 2019-11-02 08:07:05 --> Language Class Initialized
INFO - 2019-11-02 08:07:05 --> Config Class Initialized
INFO - 2019-11-02 08:07:05 --> Loader Class Initialized
INFO - 2019-11-02 08:07:05 --> Helper loaded: url_helper
INFO - 2019-11-02 08:07:05 --> Helper loaded: file_helper
INFO - 2019-11-02 08:07:05 --> Helper loaded: form_helper
INFO - 2019-11-02 08:07:05 --> Helper loaded: my_helper
INFO - 2019-11-02 08:07:05 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:07:05 --> Controller Class Initialized
INFO - 2019-11-02 08:07:34 --> Config Class Initialized
INFO - 2019-11-02 08:07:34 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:07:34 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:07:34 --> Utf8 Class Initialized
INFO - 2019-11-02 08:07:34 --> URI Class Initialized
INFO - 2019-11-02 08:07:34 --> Router Class Initialized
INFO - 2019-11-02 08:07:34 --> Output Class Initialized
INFO - 2019-11-02 08:07:34 --> Security Class Initialized
DEBUG - 2019-11-02 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:07:34 --> Input Class Initialized
INFO - 2019-11-02 08:07:34 --> Language Class Initialized
INFO - 2019-11-02 08:07:34 --> Language Class Initialized
INFO - 2019-11-02 08:07:34 --> Config Class Initialized
INFO - 2019-11-02 08:07:34 --> Loader Class Initialized
INFO - 2019-11-02 08:07:34 --> Helper loaded: url_helper
INFO - 2019-11-02 08:07:34 --> Helper loaded: file_helper
INFO - 2019-11-02 08:07:34 --> Helper loaded: form_helper
INFO - 2019-11-02 08:07:34 --> Helper loaded: my_helper
INFO - 2019-11-02 08:07:34 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:07:34 --> Controller Class Initialized
DEBUG - 2019-11-02 08:07:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:07:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:07:34 --> Final output sent to browser
DEBUG - 2019-11-02 08:07:34 --> Total execution time: 0.0519
INFO - 2019-11-02 08:07:34 --> Config Class Initialized
INFO - 2019-11-02 08:07:34 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:07:34 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:07:34 --> Utf8 Class Initialized
INFO - 2019-11-02 08:07:34 --> URI Class Initialized
INFO - 2019-11-02 08:07:34 --> Router Class Initialized
INFO - 2019-11-02 08:07:34 --> Output Class Initialized
INFO - 2019-11-02 08:07:34 --> Security Class Initialized
DEBUG - 2019-11-02 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:07:34 --> Input Class Initialized
INFO - 2019-11-02 08:07:34 --> Language Class Initialized
INFO - 2019-11-02 08:07:34 --> Language Class Initialized
INFO - 2019-11-02 08:07:34 --> Config Class Initialized
INFO - 2019-11-02 08:07:34 --> Loader Class Initialized
INFO - 2019-11-02 08:07:34 --> Helper loaded: url_helper
INFO - 2019-11-02 08:07:34 --> Helper loaded: file_helper
INFO - 2019-11-02 08:07:34 --> Helper loaded: form_helper
INFO - 2019-11-02 08:07:34 --> Helper loaded: my_helper
INFO - 2019-11-02 08:07:34 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:07:34 --> Controller Class Initialized
INFO - 2019-11-02 08:07:36 --> Config Class Initialized
INFO - 2019-11-02 08:07:36 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:07:36 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:07:36 --> Utf8 Class Initialized
INFO - 2019-11-02 08:07:36 --> URI Class Initialized
INFO - 2019-11-02 08:07:36 --> Router Class Initialized
INFO - 2019-11-02 08:07:36 --> Output Class Initialized
INFO - 2019-11-02 08:07:36 --> Security Class Initialized
DEBUG - 2019-11-02 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:07:36 --> Input Class Initialized
INFO - 2019-11-02 08:07:36 --> Language Class Initialized
INFO - 2019-11-02 08:07:36 --> Language Class Initialized
INFO - 2019-11-02 08:07:36 --> Config Class Initialized
INFO - 2019-11-02 08:07:36 --> Loader Class Initialized
INFO - 2019-11-02 08:07:36 --> Helper loaded: url_helper
INFO - 2019-11-02 08:07:36 --> Helper loaded: file_helper
INFO - 2019-11-02 08:07:36 --> Helper loaded: form_helper
INFO - 2019-11-02 08:07:36 --> Helper loaded: my_helper
INFO - 2019-11-02 08:07:36 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:07:36 --> Controller Class Initialized
DEBUG - 2019-11-02 08:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:07:36 --> Final output sent to browser
DEBUG - 2019-11-02 08:07:36 --> Total execution time: 0.0497
INFO - 2019-11-02 08:07:41 --> Config Class Initialized
INFO - 2019-11-02 08:07:41 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:07:41 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:07:41 --> Utf8 Class Initialized
INFO - 2019-11-02 08:07:41 --> URI Class Initialized
INFO - 2019-11-02 08:07:41 --> Router Class Initialized
INFO - 2019-11-02 08:07:41 --> Output Class Initialized
INFO - 2019-11-02 08:07:41 --> Security Class Initialized
DEBUG - 2019-11-02 08:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:07:41 --> Input Class Initialized
INFO - 2019-11-02 08:07:41 --> Language Class Initialized
INFO - 2019-11-02 08:07:41 --> Language Class Initialized
INFO - 2019-11-02 08:07:41 --> Config Class Initialized
INFO - 2019-11-02 08:07:41 --> Loader Class Initialized
INFO - 2019-11-02 08:07:41 --> Helper loaded: url_helper
INFO - 2019-11-02 08:07:41 --> Helper loaded: file_helper
INFO - 2019-11-02 08:07:41 --> Helper loaded: form_helper
INFO - 2019-11-02 08:07:41 --> Helper loaded: my_helper
INFO - 2019-11-02 08:07:41 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:07:41 --> Controller Class Initialized
INFO - 2019-11-02 08:07:41 --> Final output sent to browser
DEBUG - 2019-11-02 08:07:41 --> Total execution time: 0.0614
INFO - 2019-11-02 08:07:43 --> Config Class Initialized
INFO - 2019-11-02 08:07:43 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:07:43 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:07:43 --> Utf8 Class Initialized
INFO - 2019-11-02 08:07:43 --> URI Class Initialized
INFO - 2019-11-02 08:07:43 --> Router Class Initialized
INFO - 2019-11-02 08:07:43 --> Output Class Initialized
INFO - 2019-11-02 08:07:43 --> Security Class Initialized
DEBUG - 2019-11-02 08:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:07:43 --> Input Class Initialized
INFO - 2019-11-02 08:07:43 --> Language Class Initialized
INFO - 2019-11-02 08:07:43 --> Language Class Initialized
INFO - 2019-11-02 08:07:43 --> Config Class Initialized
INFO - 2019-11-02 08:07:43 --> Loader Class Initialized
INFO - 2019-11-02 08:07:43 --> Helper loaded: url_helper
INFO - 2019-11-02 08:07:43 --> Helper loaded: file_helper
INFO - 2019-11-02 08:07:43 --> Helper loaded: form_helper
INFO - 2019-11-02 08:07:43 --> Helper loaded: my_helper
INFO - 2019-11-02 08:07:43 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:07:43 --> Controller Class Initialized
INFO - 2019-11-02 08:07:45 --> Config Class Initialized
INFO - 2019-11-02 08:07:45 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:07:45 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:07:45 --> Utf8 Class Initialized
INFO - 2019-11-02 08:07:45 --> URI Class Initialized
INFO - 2019-11-02 08:07:45 --> Router Class Initialized
INFO - 2019-11-02 08:07:45 --> Output Class Initialized
INFO - 2019-11-02 08:07:45 --> Security Class Initialized
DEBUG - 2019-11-02 08:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:07:45 --> Input Class Initialized
INFO - 2019-11-02 08:07:45 --> Language Class Initialized
INFO - 2019-11-02 08:07:45 --> Language Class Initialized
INFO - 2019-11-02 08:07:45 --> Config Class Initialized
INFO - 2019-11-02 08:07:45 --> Loader Class Initialized
INFO - 2019-11-02 08:07:45 --> Helper loaded: url_helper
INFO - 2019-11-02 08:07:45 --> Helper loaded: file_helper
INFO - 2019-11-02 08:07:45 --> Helper loaded: form_helper
INFO - 2019-11-02 08:07:45 --> Helper loaded: my_helper
INFO - 2019-11-02 08:07:45 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:07:45 --> Controller Class Initialized
INFO - 2019-11-02 08:08:15 --> Config Class Initialized
INFO - 2019-11-02 08:08:15 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:15 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:15 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:15 --> URI Class Initialized
INFO - 2019-11-02 08:08:15 --> Router Class Initialized
INFO - 2019-11-02 08:08:15 --> Output Class Initialized
INFO - 2019-11-02 08:08:15 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:15 --> Input Class Initialized
INFO - 2019-11-02 08:08:15 --> Language Class Initialized
INFO - 2019-11-02 08:08:15 --> Language Class Initialized
INFO - 2019-11-02 08:08:15 --> Config Class Initialized
INFO - 2019-11-02 08:08:15 --> Loader Class Initialized
INFO - 2019-11-02 08:08:15 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:15 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:15 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:15 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:15 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:15 --> Controller Class Initialized
DEBUG - 2019-11-02 08:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:08:15 --> Final output sent to browser
DEBUG - 2019-11-02 08:08:15 --> Total execution time: 0.0516
INFO - 2019-11-02 08:08:16 --> Config Class Initialized
INFO - 2019-11-02 08:08:16 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:16 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:16 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:16 --> URI Class Initialized
INFO - 2019-11-02 08:08:16 --> Router Class Initialized
INFO - 2019-11-02 08:08:16 --> Output Class Initialized
INFO - 2019-11-02 08:08:16 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:16 --> Input Class Initialized
INFO - 2019-11-02 08:08:16 --> Language Class Initialized
INFO - 2019-11-02 08:08:16 --> Language Class Initialized
INFO - 2019-11-02 08:08:16 --> Config Class Initialized
INFO - 2019-11-02 08:08:16 --> Loader Class Initialized
INFO - 2019-11-02 08:08:16 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:16 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:16 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:16 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:16 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:16 --> Controller Class Initialized
INFO - 2019-11-02 08:08:19 --> Config Class Initialized
INFO - 2019-11-02 08:08:19 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:19 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:19 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:19 --> URI Class Initialized
INFO - 2019-11-02 08:08:19 --> Router Class Initialized
INFO - 2019-11-02 08:08:19 --> Output Class Initialized
INFO - 2019-11-02 08:08:19 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:19 --> Input Class Initialized
INFO - 2019-11-02 08:08:19 --> Language Class Initialized
INFO - 2019-11-02 08:08:19 --> Language Class Initialized
INFO - 2019-11-02 08:08:19 --> Config Class Initialized
INFO - 2019-11-02 08:08:19 --> Loader Class Initialized
INFO - 2019-11-02 08:08:19 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:19 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:19 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:19 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:19 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:19 --> Controller Class Initialized
DEBUG - 2019-11-02 08:08:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:08:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:08:19 --> Final output sent to browser
DEBUG - 2019-11-02 08:08:19 --> Total execution time: 0.0497
INFO - 2019-11-02 08:08:21 --> Config Class Initialized
INFO - 2019-11-02 08:08:21 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:21 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:21 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:21 --> URI Class Initialized
INFO - 2019-11-02 08:08:21 --> Router Class Initialized
INFO - 2019-11-02 08:08:21 --> Output Class Initialized
INFO - 2019-11-02 08:08:21 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:21 --> Input Class Initialized
INFO - 2019-11-02 08:08:21 --> Language Class Initialized
INFO - 2019-11-02 08:08:21 --> Language Class Initialized
INFO - 2019-11-02 08:08:21 --> Config Class Initialized
INFO - 2019-11-02 08:08:21 --> Loader Class Initialized
INFO - 2019-11-02 08:08:21 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:21 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:21 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:21 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:21 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:21 --> Controller Class Initialized
INFO - 2019-11-02 08:08:22 --> Config Class Initialized
INFO - 2019-11-02 08:08:22 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:22 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:22 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:22 --> URI Class Initialized
INFO - 2019-11-02 08:08:22 --> Router Class Initialized
INFO - 2019-11-02 08:08:22 --> Output Class Initialized
INFO - 2019-11-02 08:08:22 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:22 --> Input Class Initialized
INFO - 2019-11-02 08:08:22 --> Language Class Initialized
INFO - 2019-11-02 08:08:22 --> Language Class Initialized
INFO - 2019-11-02 08:08:22 --> Config Class Initialized
INFO - 2019-11-02 08:08:22 --> Loader Class Initialized
INFO - 2019-11-02 08:08:22 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:22 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:22 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:22 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:22 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:22 --> Controller Class Initialized
INFO - 2019-11-02 08:08:41 --> Config Class Initialized
INFO - 2019-11-02 08:08:41 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:41 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:41 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:41 --> URI Class Initialized
INFO - 2019-11-02 08:08:41 --> Router Class Initialized
INFO - 2019-11-02 08:08:41 --> Output Class Initialized
INFO - 2019-11-02 08:08:41 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:41 --> Input Class Initialized
INFO - 2019-11-02 08:08:41 --> Language Class Initialized
INFO - 2019-11-02 08:08:41 --> Language Class Initialized
INFO - 2019-11-02 08:08:41 --> Config Class Initialized
INFO - 2019-11-02 08:08:41 --> Loader Class Initialized
INFO - 2019-11-02 08:08:41 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:41 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:41 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:41 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:41 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:42 --> Controller Class Initialized
DEBUG - 2019-11-02 08:08:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:08:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:08:42 --> Final output sent to browser
DEBUG - 2019-11-02 08:08:42 --> Total execution time: 0.0501
INFO - 2019-11-02 08:08:42 --> Config Class Initialized
INFO - 2019-11-02 08:08:42 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:42 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:42 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:42 --> URI Class Initialized
INFO - 2019-11-02 08:08:42 --> Router Class Initialized
INFO - 2019-11-02 08:08:42 --> Output Class Initialized
INFO - 2019-11-02 08:08:42 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:42 --> Input Class Initialized
INFO - 2019-11-02 08:08:42 --> Language Class Initialized
INFO - 2019-11-02 08:08:42 --> Language Class Initialized
INFO - 2019-11-02 08:08:42 --> Config Class Initialized
INFO - 2019-11-02 08:08:42 --> Loader Class Initialized
INFO - 2019-11-02 08:08:42 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:42 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:42 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:42 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:42 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:42 --> Controller Class Initialized
INFO - 2019-11-02 08:08:44 --> Config Class Initialized
INFO - 2019-11-02 08:08:44 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:44 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:44 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:44 --> URI Class Initialized
INFO - 2019-11-02 08:08:44 --> Router Class Initialized
INFO - 2019-11-02 08:08:44 --> Output Class Initialized
INFO - 2019-11-02 08:08:44 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:44 --> Input Class Initialized
INFO - 2019-11-02 08:08:44 --> Language Class Initialized
INFO - 2019-11-02 08:08:44 --> Language Class Initialized
INFO - 2019-11-02 08:08:44 --> Config Class Initialized
INFO - 2019-11-02 08:08:44 --> Loader Class Initialized
INFO - 2019-11-02 08:08:44 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:44 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:44 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:44 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:44 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:44 --> Controller Class Initialized
DEBUG - 2019-11-02 08:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:08:44 --> Final output sent to browser
DEBUG - 2019-11-02 08:08:44 --> Total execution time: 0.0500
INFO - 2019-11-02 08:08:47 --> Config Class Initialized
INFO - 2019-11-02 08:08:47 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:47 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:47 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:47 --> URI Class Initialized
INFO - 2019-11-02 08:08:47 --> Router Class Initialized
INFO - 2019-11-02 08:08:47 --> Output Class Initialized
INFO - 2019-11-02 08:08:47 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:47 --> Input Class Initialized
INFO - 2019-11-02 08:08:47 --> Language Class Initialized
INFO - 2019-11-02 08:08:47 --> Language Class Initialized
INFO - 2019-11-02 08:08:47 --> Config Class Initialized
INFO - 2019-11-02 08:08:47 --> Loader Class Initialized
INFO - 2019-11-02 08:08:47 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:47 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:47 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:47 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:47 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:47 --> Controller Class Initialized
INFO - 2019-11-02 08:08:47 --> Final output sent to browser
DEBUG - 2019-11-02 08:08:47 --> Total execution time: 0.0648
INFO - 2019-11-02 08:08:48 --> Config Class Initialized
INFO - 2019-11-02 08:08:48 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:48 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:48 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:48 --> URI Class Initialized
INFO - 2019-11-02 08:08:48 --> Router Class Initialized
INFO - 2019-11-02 08:08:48 --> Output Class Initialized
INFO - 2019-11-02 08:08:48 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:48 --> Input Class Initialized
INFO - 2019-11-02 08:08:48 --> Language Class Initialized
INFO - 2019-11-02 08:08:48 --> Language Class Initialized
INFO - 2019-11-02 08:08:48 --> Config Class Initialized
INFO - 2019-11-02 08:08:48 --> Loader Class Initialized
INFO - 2019-11-02 08:08:48 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:48 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:48 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:48 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:48 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:48 --> Controller Class Initialized
INFO - 2019-11-02 08:08:51 --> Config Class Initialized
INFO - 2019-11-02 08:08:51 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:08:51 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:08:51 --> Utf8 Class Initialized
INFO - 2019-11-02 08:08:51 --> URI Class Initialized
INFO - 2019-11-02 08:08:51 --> Router Class Initialized
INFO - 2019-11-02 08:08:51 --> Output Class Initialized
INFO - 2019-11-02 08:08:51 --> Security Class Initialized
DEBUG - 2019-11-02 08:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:08:51 --> Input Class Initialized
INFO - 2019-11-02 08:08:51 --> Language Class Initialized
INFO - 2019-11-02 08:08:51 --> Language Class Initialized
INFO - 2019-11-02 08:08:51 --> Config Class Initialized
INFO - 2019-11-02 08:08:51 --> Loader Class Initialized
INFO - 2019-11-02 08:08:51 --> Helper loaded: url_helper
INFO - 2019-11-02 08:08:51 --> Helper loaded: file_helper
INFO - 2019-11-02 08:08:51 --> Helper loaded: form_helper
INFO - 2019-11-02 08:08:51 --> Helper loaded: my_helper
INFO - 2019-11-02 08:08:51 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:08:51 --> Controller Class Initialized
INFO - 2019-11-02 08:09:01 --> Config Class Initialized
INFO - 2019-11-02 08:09:01 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:01 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:01 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:01 --> URI Class Initialized
INFO - 2019-11-02 08:09:01 --> Router Class Initialized
INFO - 2019-11-02 08:09:01 --> Output Class Initialized
INFO - 2019-11-02 08:09:01 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:01 --> Input Class Initialized
INFO - 2019-11-02 08:09:01 --> Language Class Initialized
INFO - 2019-11-02 08:09:01 --> Language Class Initialized
INFO - 2019-11-02 08:09:01 --> Config Class Initialized
INFO - 2019-11-02 08:09:01 --> Loader Class Initialized
INFO - 2019-11-02 08:09:01 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:01 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:01 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:01 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:01 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:01 --> Controller Class Initialized
DEBUG - 2019-11-02 08:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:09:01 --> Final output sent to browser
DEBUG - 2019-11-02 08:09:01 --> Total execution time: 0.0494
INFO - 2019-11-02 08:09:01 --> Config Class Initialized
INFO - 2019-11-02 08:09:01 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:01 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:01 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:01 --> URI Class Initialized
INFO - 2019-11-02 08:09:01 --> Router Class Initialized
INFO - 2019-11-02 08:09:01 --> Output Class Initialized
INFO - 2019-11-02 08:09:01 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:01 --> Input Class Initialized
INFO - 2019-11-02 08:09:01 --> Language Class Initialized
INFO - 2019-11-02 08:09:01 --> Language Class Initialized
INFO - 2019-11-02 08:09:01 --> Config Class Initialized
INFO - 2019-11-02 08:09:01 --> Loader Class Initialized
INFO - 2019-11-02 08:09:01 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:01 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:01 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:01 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:01 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:01 --> Controller Class Initialized
INFO - 2019-11-02 08:09:02 --> Config Class Initialized
INFO - 2019-11-02 08:09:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:02 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:02 --> URI Class Initialized
INFO - 2019-11-02 08:09:02 --> Router Class Initialized
INFO - 2019-11-02 08:09:02 --> Output Class Initialized
INFO - 2019-11-02 08:09:02 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:02 --> Input Class Initialized
INFO - 2019-11-02 08:09:02 --> Language Class Initialized
INFO - 2019-11-02 08:09:02 --> Language Class Initialized
INFO - 2019-11-02 08:09:02 --> Config Class Initialized
INFO - 2019-11-02 08:09:02 --> Loader Class Initialized
INFO - 2019-11-02 08:09:02 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:02 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:02 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:02 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:02 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:02 --> Controller Class Initialized
DEBUG - 2019-11-02 08:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:09:02 --> Final output sent to browser
DEBUG - 2019-11-02 08:09:02 --> Total execution time: 0.0507
INFO - 2019-11-02 08:09:03 --> Config Class Initialized
INFO - 2019-11-02 08:09:03 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:03 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:03 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:03 --> URI Class Initialized
INFO - 2019-11-02 08:09:03 --> Router Class Initialized
INFO - 2019-11-02 08:09:03 --> Output Class Initialized
INFO - 2019-11-02 08:09:03 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:03 --> Input Class Initialized
INFO - 2019-11-02 08:09:03 --> Language Class Initialized
INFO - 2019-11-02 08:09:03 --> Language Class Initialized
INFO - 2019-11-02 08:09:03 --> Config Class Initialized
INFO - 2019-11-02 08:09:03 --> Loader Class Initialized
INFO - 2019-11-02 08:09:03 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:03 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:03 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:03 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:03 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:03 --> Controller Class Initialized
INFO - 2019-11-02 08:09:05 --> Config Class Initialized
INFO - 2019-11-02 08:09:05 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:05 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:05 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:05 --> URI Class Initialized
INFO - 2019-11-02 08:09:05 --> Router Class Initialized
INFO - 2019-11-02 08:09:05 --> Output Class Initialized
INFO - 2019-11-02 08:09:05 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:05 --> Input Class Initialized
INFO - 2019-11-02 08:09:05 --> Language Class Initialized
INFO - 2019-11-02 08:09:05 --> Language Class Initialized
INFO - 2019-11-02 08:09:05 --> Config Class Initialized
INFO - 2019-11-02 08:09:05 --> Loader Class Initialized
INFO - 2019-11-02 08:09:05 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:05 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:05 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:05 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:05 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:05 --> Controller Class Initialized
INFO - 2019-11-02 08:09:21 --> Config Class Initialized
INFO - 2019-11-02 08:09:21 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:21 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:21 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:21 --> URI Class Initialized
INFO - 2019-11-02 08:09:21 --> Router Class Initialized
INFO - 2019-11-02 08:09:21 --> Output Class Initialized
INFO - 2019-11-02 08:09:21 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:21 --> Input Class Initialized
INFO - 2019-11-02 08:09:21 --> Language Class Initialized
INFO - 2019-11-02 08:09:21 --> Language Class Initialized
INFO - 2019-11-02 08:09:21 --> Config Class Initialized
INFO - 2019-11-02 08:09:21 --> Loader Class Initialized
INFO - 2019-11-02 08:09:21 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:21 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:21 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:21 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:21 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:21 --> Controller Class Initialized
DEBUG - 2019-11-02 08:09:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:09:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:09:21 --> Final output sent to browser
DEBUG - 2019-11-02 08:09:21 --> Total execution time: 0.0506
INFO - 2019-11-02 08:09:22 --> Config Class Initialized
INFO - 2019-11-02 08:09:22 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:22 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:22 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:22 --> URI Class Initialized
INFO - 2019-11-02 08:09:22 --> Router Class Initialized
INFO - 2019-11-02 08:09:22 --> Output Class Initialized
INFO - 2019-11-02 08:09:22 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:22 --> Input Class Initialized
INFO - 2019-11-02 08:09:22 --> Language Class Initialized
INFO - 2019-11-02 08:09:22 --> Language Class Initialized
INFO - 2019-11-02 08:09:22 --> Config Class Initialized
INFO - 2019-11-02 08:09:22 --> Loader Class Initialized
INFO - 2019-11-02 08:09:22 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:22 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:22 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:22 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:22 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:22 --> Controller Class Initialized
INFO - 2019-11-02 08:09:23 --> Config Class Initialized
INFO - 2019-11-02 08:09:23 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:23 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:23 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:23 --> URI Class Initialized
INFO - 2019-11-02 08:09:23 --> Router Class Initialized
INFO - 2019-11-02 08:09:23 --> Output Class Initialized
INFO - 2019-11-02 08:09:23 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:23 --> Input Class Initialized
INFO - 2019-11-02 08:09:23 --> Language Class Initialized
INFO - 2019-11-02 08:09:23 --> Language Class Initialized
INFO - 2019-11-02 08:09:23 --> Config Class Initialized
INFO - 2019-11-02 08:09:23 --> Loader Class Initialized
INFO - 2019-11-02 08:09:23 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:23 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:23 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:23 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:23 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:23 --> Controller Class Initialized
DEBUG - 2019-11-02 08:09:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:09:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:09:23 --> Final output sent to browser
DEBUG - 2019-11-02 08:09:23 --> Total execution time: 0.0499
INFO - 2019-11-02 08:09:24 --> Config Class Initialized
INFO - 2019-11-02 08:09:24 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:24 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:24 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:24 --> URI Class Initialized
INFO - 2019-11-02 08:09:24 --> Router Class Initialized
INFO - 2019-11-02 08:09:24 --> Output Class Initialized
INFO - 2019-11-02 08:09:24 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:24 --> Input Class Initialized
INFO - 2019-11-02 08:09:24 --> Language Class Initialized
INFO - 2019-11-02 08:09:24 --> Language Class Initialized
INFO - 2019-11-02 08:09:24 --> Config Class Initialized
INFO - 2019-11-02 08:09:24 --> Loader Class Initialized
INFO - 2019-11-02 08:09:24 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:24 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:24 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:24 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:24 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:24 --> Controller Class Initialized
INFO - 2019-11-02 08:09:26 --> Config Class Initialized
INFO - 2019-11-02 08:09:26 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:26 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:26 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:26 --> URI Class Initialized
INFO - 2019-11-02 08:09:26 --> Router Class Initialized
INFO - 2019-11-02 08:09:26 --> Output Class Initialized
INFO - 2019-11-02 08:09:26 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:26 --> Input Class Initialized
INFO - 2019-11-02 08:09:26 --> Language Class Initialized
INFO - 2019-11-02 08:09:26 --> Language Class Initialized
INFO - 2019-11-02 08:09:26 --> Config Class Initialized
INFO - 2019-11-02 08:09:26 --> Loader Class Initialized
INFO - 2019-11-02 08:09:26 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:26 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:26 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:26 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:26 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:26 --> Controller Class Initialized
INFO - 2019-11-02 08:09:40 --> Config Class Initialized
INFO - 2019-11-02 08:09:40 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:40 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:40 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:40 --> URI Class Initialized
INFO - 2019-11-02 08:09:40 --> Router Class Initialized
INFO - 2019-11-02 08:09:40 --> Output Class Initialized
INFO - 2019-11-02 08:09:40 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:40 --> Input Class Initialized
INFO - 2019-11-02 08:09:40 --> Language Class Initialized
INFO - 2019-11-02 08:09:40 --> Language Class Initialized
INFO - 2019-11-02 08:09:40 --> Config Class Initialized
INFO - 2019-11-02 08:09:40 --> Loader Class Initialized
INFO - 2019-11-02 08:09:40 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:40 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:40 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:40 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:40 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:40 --> Controller Class Initialized
DEBUG - 2019-11-02 08:09:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:09:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:09:40 --> Final output sent to browser
DEBUG - 2019-11-02 08:09:40 --> Total execution time: 0.0492
INFO - 2019-11-02 08:09:40 --> Config Class Initialized
INFO - 2019-11-02 08:09:40 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:40 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:40 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:40 --> URI Class Initialized
INFO - 2019-11-02 08:09:40 --> Router Class Initialized
INFO - 2019-11-02 08:09:40 --> Output Class Initialized
INFO - 2019-11-02 08:09:40 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:40 --> Input Class Initialized
INFO - 2019-11-02 08:09:40 --> Language Class Initialized
INFO - 2019-11-02 08:09:40 --> Language Class Initialized
INFO - 2019-11-02 08:09:40 --> Config Class Initialized
INFO - 2019-11-02 08:09:40 --> Loader Class Initialized
INFO - 2019-11-02 08:09:40 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:40 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:40 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:40 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:40 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:40 --> Controller Class Initialized
INFO - 2019-11-02 08:09:41 --> Config Class Initialized
INFO - 2019-11-02 08:09:41 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:41 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:41 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:41 --> URI Class Initialized
INFO - 2019-11-02 08:09:41 --> Router Class Initialized
INFO - 2019-11-02 08:09:41 --> Output Class Initialized
INFO - 2019-11-02 08:09:41 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:41 --> Input Class Initialized
INFO - 2019-11-02 08:09:41 --> Language Class Initialized
INFO - 2019-11-02 08:09:41 --> Language Class Initialized
INFO - 2019-11-02 08:09:41 --> Config Class Initialized
INFO - 2019-11-02 08:09:41 --> Loader Class Initialized
INFO - 2019-11-02 08:09:41 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:41 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:41 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:41 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:41 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:41 --> Controller Class Initialized
DEBUG - 2019-11-02 08:09:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:09:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:09:41 --> Final output sent to browser
DEBUG - 2019-11-02 08:09:41 --> Total execution time: 0.0492
INFO - 2019-11-02 08:09:45 --> Config Class Initialized
INFO - 2019-11-02 08:09:45 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:45 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:45 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:45 --> URI Class Initialized
INFO - 2019-11-02 08:09:45 --> Router Class Initialized
INFO - 2019-11-02 08:09:45 --> Output Class Initialized
INFO - 2019-11-02 08:09:45 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:45 --> Input Class Initialized
INFO - 2019-11-02 08:09:45 --> Language Class Initialized
INFO - 2019-11-02 08:09:45 --> Language Class Initialized
INFO - 2019-11-02 08:09:45 --> Config Class Initialized
INFO - 2019-11-02 08:09:45 --> Loader Class Initialized
INFO - 2019-11-02 08:09:45 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:45 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:45 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:45 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:45 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:45 --> Controller Class Initialized
INFO - 2019-11-02 08:09:46 --> Config Class Initialized
INFO - 2019-11-02 08:09:46 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:09:46 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:09:46 --> Utf8 Class Initialized
INFO - 2019-11-02 08:09:46 --> URI Class Initialized
INFO - 2019-11-02 08:09:46 --> Router Class Initialized
INFO - 2019-11-02 08:09:46 --> Output Class Initialized
INFO - 2019-11-02 08:09:46 --> Security Class Initialized
DEBUG - 2019-11-02 08:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:09:46 --> Input Class Initialized
INFO - 2019-11-02 08:09:46 --> Language Class Initialized
INFO - 2019-11-02 08:09:46 --> Language Class Initialized
INFO - 2019-11-02 08:09:46 --> Config Class Initialized
INFO - 2019-11-02 08:09:46 --> Loader Class Initialized
INFO - 2019-11-02 08:09:46 --> Helper loaded: url_helper
INFO - 2019-11-02 08:09:46 --> Helper loaded: file_helper
INFO - 2019-11-02 08:09:46 --> Helper loaded: form_helper
INFO - 2019-11-02 08:09:46 --> Helper loaded: my_helper
INFO - 2019-11-02 08:09:46 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:09:46 --> Controller Class Initialized
INFO - 2019-11-02 08:10:02 --> Config Class Initialized
INFO - 2019-11-02 08:10:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:02 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:02 --> URI Class Initialized
INFO - 2019-11-02 08:10:02 --> Router Class Initialized
INFO - 2019-11-02 08:10:02 --> Output Class Initialized
INFO - 2019-11-02 08:10:02 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:02 --> Input Class Initialized
INFO - 2019-11-02 08:10:02 --> Language Class Initialized
INFO - 2019-11-02 08:10:02 --> Language Class Initialized
INFO - 2019-11-02 08:10:02 --> Config Class Initialized
INFO - 2019-11-02 08:10:02 --> Loader Class Initialized
INFO - 2019-11-02 08:10:02 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:02 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:02 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:02 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:02 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:02 --> Controller Class Initialized
DEBUG - 2019-11-02 08:10:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:10:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:10:02 --> Final output sent to browser
DEBUG - 2019-11-02 08:10:02 --> Total execution time: 0.0516
INFO - 2019-11-02 08:10:02 --> Config Class Initialized
INFO - 2019-11-02 08:10:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:02 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:02 --> URI Class Initialized
INFO - 2019-11-02 08:10:02 --> Router Class Initialized
INFO - 2019-11-02 08:10:02 --> Output Class Initialized
INFO - 2019-11-02 08:10:02 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:02 --> Input Class Initialized
INFO - 2019-11-02 08:10:02 --> Language Class Initialized
INFO - 2019-11-02 08:10:02 --> Language Class Initialized
INFO - 2019-11-02 08:10:02 --> Config Class Initialized
INFO - 2019-11-02 08:10:02 --> Loader Class Initialized
INFO - 2019-11-02 08:10:02 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:02 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:02 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:02 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:02 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:02 --> Controller Class Initialized
INFO - 2019-11-02 08:10:04 --> Config Class Initialized
INFO - 2019-11-02 08:10:04 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:04 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:04 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:04 --> URI Class Initialized
INFO - 2019-11-02 08:10:04 --> Router Class Initialized
INFO - 2019-11-02 08:10:04 --> Output Class Initialized
INFO - 2019-11-02 08:10:04 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:04 --> Input Class Initialized
INFO - 2019-11-02 08:10:04 --> Language Class Initialized
INFO - 2019-11-02 08:10:04 --> Language Class Initialized
INFO - 2019-11-02 08:10:04 --> Config Class Initialized
INFO - 2019-11-02 08:10:04 --> Loader Class Initialized
INFO - 2019-11-02 08:10:04 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:04 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:04 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:04 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:04 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:04 --> Controller Class Initialized
DEBUG - 2019-11-02 08:10:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:10:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:10:04 --> Final output sent to browser
DEBUG - 2019-11-02 08:10:04 --> Total execution time: 0.0515
INFO - 2019-11-02 08:10:06 --> Config Class Initialized
INFO - 2019-11-02 08:10:06 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:06 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:06 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:06 --> URI Class Initialized
INFO - 2019-11-02 08:10:06 --> Router Class Initialized
INFO - 2019-11-02 08:10:06 --> Output Class Initialized
INFO - 2019-11-02 08:10:06 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:06 --> Input Class Initialized
INFO - 2019-11-02 08:10:06 --> Language Class Initialized
INFO - 2019-11-02 08:10:06 --> Language Class Initialized
INFO - 2019-11-02 08:10:06 --> Config Class Initialized
INFO - 2019-11-02 08:10:06 --> Loader Class Initialized
INFO - 2019-11-02 08:10:06 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:06 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:06 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:06 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:06 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:06 --> Controller Class Initialized
INFO - 2019-11-02 08:10:07 --> Config Class Initialized
INFO - 2019-11-02 08:10:07 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:07 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:07 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:07 --> URI Class Initialized
INFO - 2019-11-02 08:10:07 --> Router Class Initialized
INFO - 2019-11-02 08:10:07 --> Output Class Initialized
INFO - 2019-11-02 08:10:07 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:07 --> Input Class Initialized
INFO - 2019-11-02 08:10:07 --> Language Class Initialized
INFO - 2019-11-02 08:10:07 --> Language Class Initialized
INFO - 2019-11-02 08:10:07 --> Config Class Initialized
INFO - 2019-11-02 08:10:07 --> Loader Class Initialized
INFO - 2019-11-02 08:10:07 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:07 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:07 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:07 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:07 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:07 --> Controller Class Initialized
INFO - 2019-11-02 08:10:24 --> Config Class Initialized
INFO - 2019-11-02 08:10:24 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:24 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:24 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:24 --> URI Class Initialized
INFO - 2019-11-02 08:10:24 --> Router Class Initialized
INFO - 2019-11-02 08:10:24 --> Output Class Initialized
INFO - 2019-11-02 08:10:24 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:24 --> Input Class Initialized
INFO - 2019-11-02 08:10:24 --> Language Class Initialized
INFO - 2019-11-02 08:10:24 --> Language Class Initialized
INFO - 2019-11-02 08:10:24 --> Config Class Initialized
INFO - 2019-11-02 08:10:24 --> Loader Class Initialized
INFO - 2019-11-02 08:10:24 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:24 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:24 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:24 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:24 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:24 --> Controller Class Initialized
DEBUG - 2019-11-02 08:10:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:10:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:10:25 --> Final output sent to browser
DEBUG - 2019-11-02 08:10:25 --> Total execution time: 0.0506
INFO - 2019-11-02 08:10:25 --> Config Class Initialized
INFO - 2019-11-02 08:10:25 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:25 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:25 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:25 --> URI Class Initialized
INFO - 2019-11-02 08:10:25 --> Router Class Initialized
INFO - 2019-11-02 08:10:25 --> Output Class Initialized
INFO - 2019-11-02 08:10:25 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:25 --> Input Class Initialized
INFO - 2019-11-02 08:10:25 --> Language Class Initialized
INFO - 2019-11-02 08:10:25 --> Language Class Initialized
INFO - 2019-11-02 08:10:25 --> Config Class Initialized
INFO - 2019-11-02 08:10:25 --> Loader Class Initialized
INFO - 2019-11-02 08:10:25 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:25 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:25 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:25 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:25 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:25 --> Controller Class Initialized
INFO - 2019-11-02 08:10:26 --> Config Class Initialized
INFO - 2019-11-02 08:10:26 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:26 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:26 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:26 --> URI Class Initialized
INFO - 2019-11-02 08:10:26 --> Router Class Initialized
INFO - 2019-11-02 08:10:26 --> Output Class Initialized
INFO - 2019-11-02 08:10:26 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:26 --> Input Class Initialized
INFO - 2019-11-02 08:10:26 --> Language Class Initialized
INFO - 2019-11-02 08:10:26 --> Language Class Initialized
INFO - 2019-11-02 08:10:26 --> Config Class Initialized
INFO - 2019-11-02 08:10:26 --> Loader Class Initialized
INFO - 2019-11-02 08:10:26 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:26 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:26 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:26 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:26 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:26 --> Controller Class Initialized
DEBUG - 2019-11-02 08:10:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:10:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:10:26 --> Final output sent to browser
DEBUG - 2019-11-02 08:10:26 --> Total execution time: 0.0514
INFO - 2019-11-02 08:10:29 --> Config Class Initialized
INFO - 2019-11-02 08:10:29 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:29 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:29 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:29 --> URI Class Initialized
INFO - 2019-11-02 08:10:29 --> Router Class Initialized
INFO - 2019-11-02 08:10:29 --> Output Class Initialized
INFO - 2019-11-02 08:10:29 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:29 --> Input Class Initialized
INFO - 2019-11-02 08:10:29 --> Language Class Initialized
INFO - 2019-11-02 08:10:29 --> Language Class Initialized
INFO - 2019-11-02 08:10:29 --> Config Class Initialized
INFO - 2019-11-02 08:10:29 --> Loader Class Initialized
INFO - 2019-11-02 08:10:29 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:29 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:29 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:29 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:29 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:29 --> Controller Class Initialized
INFO - 2019-11-02 08:10:32 --> Config Class Initialized
INFO - 2019-11-02 08:10:32 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:10:32 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:10:32 --> Utf8 Class Initialized
INFO - 2019-11-02 08:10:32 --> URI Class Initialized
INFO - 2019-11-02 08:10:32 --> Router Class Initialized
INFO - 2019-11-02 08:10:32 --> Output Class Initialized
INFO - 2019-11-02 08:10:32 --> Security Class Initialized
DEBUG - 2019-11-02 08:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:10:32 --> Input Class Initialized
INFO - 2019-11-02 08:10:32 --> Language Class Initialized
INFO - 2019-11-02 08:10:32 --> Language Class Initialized
INFO - 2019-11-02 08:10:32 --> Config Class Initialized
INFO - 2019-11-02 08:10:32 --> Loader Class Initialized
INFO - 2019-11-02 08:10:32 --> Helper loaded: url_helper
INFO - 2019-11-02 08:10:32 --> Helper loaded: file_helper
INFO - 2019-11-02 08:10:32 --> Helper loaded: form_helper
INFO - 2019-11-02 08:10:32 --> Helper loaded: my_helper
INFO - 2019-11-02 08:10:32 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:10:32 --> Controller Class Initialized
INFO - 2019-11-02 08:11:55 --> Config Class Initialized
INFO - 2019-11-02 08:11:55 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:11:55 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:11:55 --> Utf8 Class Initialized
INFO - 2019-11-02 08:11:55 --> URI Class Initialized
INFO - 2019-11-02 08:11:55 --> Router Class Initialized
INFO - 2019-11-02 08:11:55 --> Output Class Initialized
INFO - 2019-11-02 08:11:55 --> Security Class Initialized
DEBUG - 2019-11-02 08:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:11:55 --> Input Class Initialized
INFO - 2019-11-02 08:11:55 --> Language Class Initialized
INFO - 2019-11-02 08:11:55 --> Language Class Initialized
INFO - 2019-11-02 08:11:55 --> Config Class Initialized
INFO - 2019-11-02 08:11:55 --> Loader Class Initialized
INFO - 2019-11-02 08:11:55 --> Helper loaded: url_helper
INFO - 2019-11-02 08:11:55 --> Helper loaded: file_helper
INFO - 2019-11-02 08:11:55 --> Helper loaded: form_helper
INFO - 2019-11-02 08:11:55 --> Helper loaded: my_helper
INFO - 2019-11-02 08:11:55 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:11:55 --> Controller Class Initialized
DEBUG - 2019-11-02 08:11:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:11:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:11:55 --> Final output sent to browser
DEBUG - 2019-11-02 08:11:55 --> Total execution time: 0.0520
INFO - 2019-11-02 08:11:55 --> Config Class Initialized
INFO - 2019-11-02 08:11:55 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:11:55 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:11:55 --> Utf8 Class Initialized
INFO - 2019-11-02 08:11:55 --> URI Class Initialized
INFO - 2019-11-02 08:11:55 --> Router Class Initialized
INFO - 2019-11-02 08:11:55 --> Output Class Initialized
INFO - 2019-11-02 08:11:55 --> Security Class Initialized
DEBUG - 2019-11-02 08:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:11:55 --> Input Class Initialized
INFO - 2019-11-02 08:11:55 --> Language Class Initialized
INFO - 2019-11-02 08:11:55 --> Language Class Initialized
INFO - 2019-11-02 08:11:55 --> Config Class Initialized
INFO - 2019-11-02 08:11:55 --> Loader Class Initialized
INFO - 2019-11-02 08:11:55 --> Helper loaded: url_helper
INFO - 2019-11-02 08:11:55 --> Helper loaded: file_helper
INFO - 2019-11-02 08:11:55 --> Helper loaded: form_helper
INFO - 2019-11-02 08:11:55 --> Helper loaded: my_helper
INFO - 2019-11-02 08:11:55 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:11:55 --> Controller Class Initialized
INFO - 2019-11-02 08:11:56 --> Config Class Initialized
INFO - 2019-11-02 08:11:56 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:11:56 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:11:56 --> Utf8 Class Initialized
INFO - 2019-11-02 08:11:56 --> URI Class Initialized
INFO - 2019-11-02 08:11:56 --> Router Class Initialized
INFO - 2019-11-02 08:11:56 --> Output Class Initialized
INFO - 2019-11-02 08:11:56 --> Security Class Initialized
DEBUG - 2019-11-02 08:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:11:56 --> Input Class Initialized
INFO - 2019-11-02 08:11:56 --> Language Class Initialized
INFO - 2019-11-02 08:11:56 --> Language Class Initialized
INFO - 2019-11-02 08:11:56 --> Config Class Initialized
INFO - 2019-11-02 08:11:56 --> Loader Class Initialized
INFO - 2019-11-02 08:11:56 --> Helper loaded: url_helper
INFO - 2019-11-02 08:11:56 --> Helper loaded: file_helper
INFO - 2019-11-02 08:11:56 --> Helper loaded: form_helper
INFO - 2019-11-02 08:11:56 --> Helper loaded: my_helper
INFO - 2019-11-02 08:11:56 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:11:56 --> Controller Class Initialized
DEBUG - 2019-11-02 08:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:11:56 --> Final output sent to browser
DEBUG - 2019-11-02 08:11:56 --> Total execution time: 0.0514
INFO - 2019-11-02 08:11:58 --> Config Class Initialized
INFO - 2019-11-02 08:11:58 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:11:58 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:11:58 --> Utf8 Class Initialized
INFO - 2019-11-02 08:11:58 --> URI Class Initialized
INFO - 2019-11-02 08:11:58 --> Router Class Initialized
INFO - 2019-11-02 08:11:58 --> Output Class Initialized
INFO - 2019-11-02 08:11:58 --> Security Class Initialized
DEBUG - 2019-11-02 08:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:11:58 --> Input Class Initialized
INFO - 2019-11-02 08:11:58 --> Language Class Initialized
INFO - 2019-11-02 08:11:58 --> Language Class Initialized
INFO - 2019-11-02 08:11:58 --> Config Class Initialized
INFO - 2019-11-02 08:11:58 --> Loader Class Initialized
INFO - 2019-11-02 08:11:58 --> Helper loaded: url_helper
INFO - 2019-11-02 08:11:58 --> Helper loaded: file_helper
INFO - 2019-11-02 08:11:58 --> Helper loaded: form_helper
INFO - 2019-11-02 08:11:58 --> Helper loaded: my_helper
INFO - 2019-11-02 08:11:58 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:11:58 --> Controller Class Initialized
INFO - 2019-11-02 08:12:00 --> Config Class Initialized
INFO - 2019-11-02 08:12:00 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:00 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:00 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:00 --> URI Class Initialized
INFO - 2019-11-02 08:12:00 --> Router Class Initialized
INFO - 2019-11-02 08:12:00 --> Output Class Initialized
INFO - 2019-11-02 08:12:00 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:00 --> Input Class Initialized
INFO - 2019-11-02 08:12:00 --> Language Class Initialized
INFO - 2019-11-02 08:12:00 --> Language Class Initialized
INFO - 2019-11-02 08:12:00 --> Config Class Initialized
INFO - 2019-11-02 08:12:00 --> Loader Class Initialized
INFO - 2019-11-02 08:12:00 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:00 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:00 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:00 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:00 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:00 --> Controller Class Initialized
INFO - 2019-11-02 08:12:10 --> Config Class Initialized
INFO - 2019-11-02 08:12:10 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:10 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:10 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:10 --> URI Class Initialized
INFO - 2019-11-02 08:12:10 --> Router Class Initialized
INFO - 2019-11-02 08:12:10 --> Output Class Initialized
INFO - 2019-11-02 08:12:10 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:10 --> Input Class Initialized
INFO - 2019-11-02 08:12:10 --> Language Class Initialized
INFO - 2019-11-02 08:12:10 --> Language Class Initialized
INFO - 2019-11-02 08:12:10 --> Config Class Initialized
INFO - 2019-11-02 08:12:10 --> Loader Class Initialized
INFO - 2019-11-02 08:12:10 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:10 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:10 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:10 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:10 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:10 --> Controller Class Initialized
DEBUG - 2019-11-02 08:12:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:12:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:12:10 --> Final output sent to browser
DEBUG - 2019-11-02 08:12:10 --> Total execution time: 0.0504
INFO - 2019-11-02 08:12:10 --> Config Class Initialized
INFO - 2019-11-02 08:12:10 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:10 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:10 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:10 --> URI Class Initialized
INFO - 2019-11-02 08:12:10 --> Router Class Initialized
INFO - 2019-11-02 08:12:10 --> Output Class Initialized
INFO - 2019-11-02 08:12:10 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:10 --> Input Class Initialized
INFO - 2019-11-02 08:12:10 --> Language Class Initialized
INFO - 2019-11-02 08:12:10 --> Language Class Initialized
INFO - 2019-11-02 08:12:10 --> Config Class Initialized
INFO - 2019-11-02 08:12:10 --> Loader Class Initialized
INFO - 2019-11-02 08:12:10 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:10 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:10 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:10 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:10 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:10 --> Controller Class Initialized
INFO - 2019-11-02 08:12:11 --> Config Class Initialized
INFO - 2019-11-02 08:12:11 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:11 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:11 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:11 --> URI Class Initialized
INFO - 2019-11-02 08:12:11 --> Router Class Initialized
INFO - 2019-11-02 08:12:11 --> Output Class Initialized
INFO - 2019-11-02 08:12:11 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:11 --> Input Class Initialized
INFO - 2019-11-02 08:12:11 --> Language Class Initialized
INFO - 2019-11-02 08:12:11 --> Language Class Initialized
INFO - 2019-11-02 08:12:11 --> Config Class Initialized
INFO - 2019-11-02 08:12:11 --> Loader Class Initialized
INFO - 2019-11-02 08:12:11 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:11 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:11 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:11 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:11 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:11 --> Controller Class Initialized
DEBUG - 2019-11-02 08:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:12:11 --> Final output sent to browser
DEBUG - 2019-11-02 08:12:11 --> Total execution time: 0.0490
INFO - 2019-11-02 08:12:13 --> Config Class Initialized
INFO - 2019-11-02 08:12:13 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:13 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:13 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:13 --> URI Class Initialized
INFO - 2019-11-02 08:12:13 --> Router Class Initialized
INFO - 2019-11-02 08:12:13 --> Output Class Initialized
INFO - 2019-11-02 08:12:13 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:13 --> Input Class Initialized
INFO - 2019-11-02 08:12:13 --> Language Class Initialized
INFO - 2019-11-02 08:12:13 --> Language Class Initialized
INFO - 2019-11-02 08:12:13 --> Config Class Initialized
INFO - 2019-11-02 08:12:13 --> Loader Class Initialized
INFO - 2019-11-02 08:12:13 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:13 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:13 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:13 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:13 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:13 --> Controller Class Initialized
INFO - 2019-11-02 08:12:14 --> Config Class Initialized
INFO - 2019-11-02 08:12:14 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:14 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:14 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:14 --> URI Class Initialized
INFO - 2019-11-02 08:12:14 --> Router Class Initialized
INFO - 2019-11-02 08:12:14 --> Output Class Initialized
INFO - 2019-11-02 08:12:14 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:14 --> Input Class Initialized
INFO - 2019-11-02 08:12:14 --> Language Class Initialized
INFO - 2019-11-02 08:12:14 --> Language Class Initialized
INFO - 2019-11-02 08:12:14 --> Config Class Initialized
INFO - 2019-11-02 08:12:14 --> Loader Class Initialized
INFO - 2019-11-02 08:12:14 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:14 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:14 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:14 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:14 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:14 --> Controller Class Initialized
INFO - 2019-11-02 08:12:34 --> Config Class Initialized
INFO - 2019-11-02 08:12:34 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:34 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:34 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:34 --> URI Class Initialized
INFO - 2019-11-02 08:12:34 --> Router Class Initialized
INFO - 2019-11-02 08:12:34 --> Output Class Initialized
INFO - 2019-11-02 08:12:34 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:34 --> Input Class Initialized
INFO - 2019-11-02 08:12:34 --> Language Class Initialized
INFO - 2019-11-02 08:12:34 --> Language Class Initialized
INFO - 2019-11-02 08:12:34 --> Config Class Initialized
INFO - 2019-11-02 08:12:34 --> Loader Class Initialized
INFO - 2019-11-02 08:12:34 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:34 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:34 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:34 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:34 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:34 --> Controller Class Initialized
DEBUG - 2019-11-02 08:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:12:34 --> Final output sent to browser
DEBUG - 2019-11-02 08:12:34 --> Total execution time: 0.0511
INFO - 2019-11-02 08:12:34 --> Config Class Initialized
INFO - 2019-11-02 08:12:34 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:34 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:34 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:34 --> URI Class Initialized
INFO - 2019-11-02 08:12:34 --> Router Class Initialized
INFO - 2019-11-02 08:12:34 --> Output Class Initialized
INFO - 2019-11-02 08:12:34 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:34 --> Input Class Initialized
INFO - 2019-11-02 08:12:34 --> Language Class Initialized
INFO - 2019-11-02 08:12:34 --> Language Class Initialized
INFO - 2019-11-02 08:12:34 --> Config Class Initialized
INFO - 2019-11-02 08:12:34 --> Loader Class Initialized
INFO - 2019-11-02 08:12:34 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:34 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:34 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:34 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:34 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:34 --> Controller Class Initialized
INFO - 2019-11-02 08:12:35 --> Config Class Initialized
INFO - 2019-11-02 08:12:35 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:35 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:35 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:35 --> URI Class Initialized
INFO - 2019-11-02 08:12:35 --> Router Class Initialized
INFO - 2019-11-02 08:12:35 --> Output Class Initialized
INFO - 2019-11-02 08:12:35 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:35 --> Input Class Initialized
INFO - 2019-11-02 08:12:35 --> Language Class Initialized
INFO - 2019-11-02 08:12:35 --> Language Class Initialized
INFO - 2019-11-02 08:12:35 --> Config Class Initialized
INFO - 2019-11-02 08:12:35 --> Loader Class Initialized
INFO - 2019-11-02 08:12:35 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:35 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:35 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:35 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:35 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:35 --> Controller Class Initialized
DEBUG - 2019-11-02 08:12:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:12:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:12:35 --> Final output sent to browser
DEBUG - 2019-11-02 08:12:35 --> Total execution time: 0.0518
INFO - 2019-11-02 08:12:37 --> Config Class Initialized
INFO - 2019-11-02 08:12:37 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:37 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:37 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:37 --> URI Class Initialized
INFO - 2019-11-02 08:12:37 --> Router Class Initialized
INFO - 2019-11-02 08:12:37 --> Output Class Initialized
INFO - 2019-11-02 08:12:37 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:37 --> Input Class Initialized
INFO - 2019-11-02 08:12:37 --> Language Class Initialized
INFO - 2019-11-02 08:12:37 --> Language Class Initialized
INFO - 2019-11-02 08:12:37 --> Config Class Initialized
INFO - 2019-11-02 08:12:37 --> Loader Class Initialized
INFO - 2019-11-02 08:12:37 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:37 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:37 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:37 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:37 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:37 --> Controller Class Initialized
INFO - 2019-11-02 08:12:38 --> Config Class Initialized
INFO - 2019-11-02 08:12:38 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:38 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:38 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:38 --> URI Class Initialized
INFO - 2019-11-02 08:12:38 --> Router Class Initialized
INFO - 2019-11-02 08:12:38 --> Output Class Initialized
INFO - 2019-11-02 08:12:38 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:39 --> Input Class Initialized
INFO - 2019-11-02 08:12:39 --> Language Class Initialized
INFO - 2019-11-02 08:12:39 --> Language Class Initialized
INFO - 2019-11-02 08:12:39 --> Config Class Initialized
INFO - 2019-11-02 08:12:39 --> Loader Class Initialized
INFO - 2019-11-02 08:12:39 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:39 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:39 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:39 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:39 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:39 --> Controller Class Initialized
INFO - 2019-11-02 08:12:54 --> Config Class Initialized
INFO - 2019-11-02 08:12:54 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:54 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:54 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:54 --> URI Class Initialized
INFO - 2019-11-02 08:12:54 --> Router Class Initialized
INFO - 2019-11-02 08:12:54 --> Output Class Initialized
INFO - 2019-11-02 08:12:54 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:54 --> Input Class Initialized
INFO - 2019-11-02 08:12:54 --> Language Class Initialized
INFO - 2019-11-02 08:12:54 --> Language Class Initialized
INFO - 2019-11-02 08:12:54 --> Config Class Initialized
INFO - 2019-11-02 08:12:54 --> Loader Class Initialized
INFO - 2019-11-02 08:12:54 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:54 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:54 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:54 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:54 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:54 --> Controller Class Initialized
DEBUG - 2019-11-02 08:12:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:12:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:12:54 --> Final output sent to browser
DEBUG - 2019-11-02 08:12:54 --> Total execution time: 0.0506
INFO - 2019-11-02 08:12:54 --> Config Class Initialized
INFO - 2019-11-02 08:12:54 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:54 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:54 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:54 --> URI Class Initialized
INFO - 2019-11-02 08:12:54 --> Router Class Initialized
INFO - 2019-11-02 08:12:54 --> Output Class Initialized
INFO - 2019-11-02 08:12:54 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:54 --> Input Class Initialized
INFO - 2019-11-02 08:12:54 --> Language Class Initialized
INFO - 2019-11-02 08:12:54 --> Language Class Initialized
INFO - 2019-11-02 08:12:54 --> Config Class Initialized
INFO - 2019-11-02 08:12:54 --> Loader Class Initialized
INFO - 2019-11-02 08:12:54 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:54 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:54 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:54 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:54 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:54 --> Controller Class Initialized
INFO - 2019-11-02 08:12:55 --> Config Class Initialized
INFO - 2019-11-02 08:12:55 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:55 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:55 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:55 --> URI Class Initialized
INFO - 2019-11-02 08:12:55 --> Router Class Initialized
INFO - 2019-11-02 08:12:55 --> Output Class Initialized
INFO - 2019-11-02 08:12:55 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:55 --> Input Class Initialized
INFO - 2019-11-02 08:12:55 --> Language Class Initialized
INFO - 2019-11-02 08:12:55 --> Language Class Initialized
INFO - 2019-11-02 08:12:55 --> Config Class Initialized
INFO - 2019-11-02 08:12:55 --> Loader Class Initialized
INFO - 2019-11-02 08:12:55 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:55 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:55 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:55 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:55 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:55 --> Controller Class Initialized
DEBUG - 2019-11-02 08:12:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:12:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:12:55 --> Final output sent to browser
DEBUG - 2019-11-02 08:12:55 --> Total execution time: 0.0485
INFO - 2019-11-02 08:12:57 --> Config Class Initialized
INFO - 2019-11-02 08:12:57 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:57 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:57 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:57 --> URI Class Initialized
INFO - 2019-11-02 08:12:57 --> Router Class Initialized
INFO - 2019-11-02 08:12:57 --> Output Class Initialized
INFO - 2019-11-02 08:12:57 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:57 --> Input Class Initialized
INFO - 2019-11-02 08:12:57 --> Language Class Initialized
INFO - 2019-11-02 08:12:57 --> Language Class Initialized
INFO - 2019-11-02 08:12:57 --> Config Class Initialized
INFO - 2019-11-02 08:12:57 --> Loader Class Initialized
INFO - 2019-11-02 08:12:57 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:57 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:57 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:57 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:57 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:57 --> Controller Class Initialized
INFO - 2019-11-02 08:12:58 --> Config Class Initialized
INFO - 2019-11-02 08:12:58 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:12:58 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:12:58 --> Utf8 Class Initialized
INFO - 2019-11-02 08:12:58 --> URI Class Initialized
INFO - 2019-11-02 08:12:58 --> Router Class Initialized
INFO - 2019-11-02 08:12:58 --> Output Class Initialized
INFO - 2019-11-02 08:12:58 --> Security Class Initialized
DEBUG - 2019-11-02 08:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:12:58 --> Input Class Initialized
INFO - 2019-11-02 08:12:58 --> Language Class Initialized
INFO - 2019-11-02 08:12:58 --> Language Class Initialized
INFO - 2019-11-02 08:12:58 --> Config Class Initialized
INFO - 2019-11-02 08:12:58 --> Loader Class Initialized
INFO - 2019-11-02 08:12:58 --> Helper loaded: url_helper
INFO - 2019-11-02 08:12:58 --> Helper loaded: file_helper
INFO - 2019-11-02 08:12:58 --> Helper loaded: form_helper
INFO - 2019-11-02 08:12:58 --> Helper loaded: my_helper
INFO - 2019-11-02 08:12:58 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:12:58 --> Controller Class Initialized
INFO - 2019-11-02 08:13:13 --> Config Class Initialized
INFO - 2019-11-02 08:13:13 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:13 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:13 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:13 --> URI Class Initialized
INFO - 2019-11-02 08:13:13 --> Router Class Initialized
INFO - 2019-11-02 08:13:13 --> Output Class Initialized
INFO - 2019-11-02 08:13:13 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:13 --> Input Class Initialized
INFO - 2019-11-02 08:13:13 --> Language Class Initialized
INFO - 2019-11-02 08:13:13 --> Language Class Initialized
INFO - 2019-11-02 08:13:13 --> Config Class Initialized
INFO - 2019-11-02 08:13:13 --> Loader Class Initialized
INFO - 2019-11-02 08:13:13 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:13 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:13 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:13 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:13 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:13 --> Controller Class Initialized
DEBUG - 2019-11-02 08:13:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:13:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:13:13 --> Final output sent to browser
DEBUG - 2019-11-02 08:13:13 --> Total execution time: 0.0499
INFO - 2019-11-02 08:13:13 --> Config Class Initialized
INFO - 2019-11-02 08:13:13 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:13 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:13 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:13 --> URI Class Initialized
INFO - 2019-11-02 08:13:13 --> Router Class Initialized
INFO - 2019-11-02 08:13:13 --> Output Class Initialized
INFO - 2019-11-02 08:13:13 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:13 --> Input Class Initialized
INFO - 2019-11-02 08:13:13 --> Language Class Initialized
INFO - 2019-11-02 08:13:13 --> Language Class Initialized
INFO - 2019-11-02 08:13:13 --> Config Class Initialized
INFO - 2019-11-02 08:13:13 --> Loader Class Initialized
INFO - 2019-11-02 08:13:13 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:13 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:13 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:13 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:13 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:13 --> Controller Class Initialized
INFO - 2019-11-02 08:13:14 --> Config Class Initialized
INFO - 2019-11-02 08:13:14 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:14 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:14 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:14 --> URI Class Initialized
INFO - 2019-11-02 08:13:14 --> Router Class Initialized
INFO - 2019-11-02 08:13:14 --> Output Class Initialized
INFO - 2019-11-02 08:13:14 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:14 --> Input Class Initialized
INFO - 2019-11-02 08:13:14 --> Language Class Initialized
INFO - 2019-11-02 08:13:14 --> Language Class Initialized
INFO - 2019-11-02 08:13:14 --> Config Class Initialized
INFO - 2019-11-02 08:13:14 --> Loader Class Initialized
INFO - 2019-11-02 08:13:14 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:14 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:14 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:14 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:14 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:14 --> Controller Class Initialized
DEBUG - 2019-11-02 08:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:13:14 --> Final output sent to browser
DEBUG - 2019-11-02 08:13:14 --> Total execution time: 0.0509
INFO - 2019-11-02 08:13:16 --> Config Class Initialized
INFO - 2019-11-02 08:13:16 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:16 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:16 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:16 --> URI Class Initialized
INFO - 2019-11-02 08:13:16 --> Router Class Initialized
INFO - 2019-11-02 08:13:16 --> Output Class Initialized
INFO - 2019-11-02 08:13:16 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:16 --> Input Class Initialized
INFO - 2019-11-02 08:13:16 --> Language Class Initialized
INFO - 2019-11-02 08:13:16 --> Language Class Initialized
INFO - 2019-11-02 08:13:16 --> Config Class Initialized
INFO - 2019-11-02 08:13:16 --> Loader Class Initialized
INFO - 2019-11-02 08:13:16 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:16 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:16 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:16 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:16 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:16 --> Controller Class Initialized
INFO - 2019-11-02 08:13:17 --> Config Class Initialized
INFO - 2019-11-02 08:13:17 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:17 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:17 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:17 --> URI Class Initialized
INFO - 2019-11-02 08:13:17 --> Router Class Initialized
INFO - 2019-11-02 08:13:17 --> Output Class Initialized
INFO - 2019-11-02 08:13:17 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:17 --> Input Class Initialized
INFO - 2019-11-02 08:13:17 --> Language Class Initialized
INFO - 2019-11-02 08:13:17 --> Language Class Initialized
INFO - 2019-11-02 08:13:17 --> Config Class Initialized
INFO - 2019-11-02 08:13:17 --> Loader Class Initialized
INFO - 2019-11-02 08:13:17 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:17 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:17 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:17 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:17 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:17 --> Controller Class Initialized
INFO - 2019-11-02 08:13:30 --> Config Class Initialized
INFO - 2019-11-02 08:13:30 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:30 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:30 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:30 --> URI Class Initialized
INFO - 2019-11-02 08:13:30 --> Router Class Initialized
INFO - 2019-11-02 08:13:30 --> Output Class Initialized
INFO - 2019-11-02 08:13:30 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:30 --> Input Class Initialized
INFO - 2019-11-02 08:13:30 --> Language Class Initialized
INFO - 2019-11-02 08:13:30 --> Language Class Initialized
INFO - 2019-11-02 08:13:30 --> Config Class Initialized
INFO - 2019-11-02 08:13:30 --> Loader Class Initialized
INFO - 2019-11-02 08:13:30 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:30 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:30 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:30 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:30 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:30 --> Controller Class Initialized
DEBUG - 2019-11-02 08:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-02 08:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:13:30 --> Final output sent to browser
DEBUG - 2019-11-02 08:13:30 --> Total execution time: 0.0488
INFO - 2019-11-02 08:13:30 --> Config Class Initialized
INFO - 2019-11-02 08:13:30 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:30 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:30 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:30 --> URI Class Initialized
INFO - 2019-11-02 08:13:30 --> Router Class Initialized
INFO - 2019-11-02 08:13:30 --> Output Class Initialized
INFO - 2019-11-02 08:13:30 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:30 --> Input Class Initialized
INFO - 2019-11-02 08:13:30 --> Language Class Initialized
INFO - 2019-11-02 08:13:30 --> Language Class Initialized
INFO - 2019-11-02 08:13:30 --> Config Class Initialized
INFO - 2019-11-02 08:13:30 --> Loader Class Initialized
INFO - 2019-11-02 08:13:30 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:30 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:30 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:30 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:30 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:30 --> Controller Class Initialized
INFO - 2019-11-02 08:13:31 --> Config Class Initialized
INFO - 2019-11-02 08:13:31 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:31 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:31 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:31 --> URI Class Initialized
INFO - 2019-11-02 08:13:31 --> Router Class Initialized
INFO - 2019-11-02 08:13:31 --> Output Class Initialized
INFO - 2019-11-02 08:13:31 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:31 --> Input Class Initialized
INFO - 2019-11-02 08:13:31 --> Language Class Initialized
INFO - 2019-11-02 08:13:31 --> Language Class Initialized
INFO - 2019-11-02 08:13:31 --> Config Class Initialized
INFO - 2019-11-02 08:13:31 --> Loader Class Initialized
INFO - 2019-11-02 08:13:31 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:31 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:31 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:31 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:31 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:31 --> Controller Class Initialized
DEBUG - 2019-11-02 08:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-02 08:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:13:31 --> Final output sent to browser
DEBUG - 2019-11-02 08:13:31 --> Total execution time: 0.0504
INFO - 2019-11-02 08:13:33 --> Config Class Initialized
INFO - 2019-11-02 08:13:33 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:33 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:33 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:33 --> URI Class Initialized
INFO - 2019-11-02 08:13:33 --> Router Class Initialized
INFO - 2019-11-02 08:13:33 --> Output Class Initialized
INFO - 2019-11-02 08:13:33 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:33 --> Input Class Initialized
INFO - 2019-11-02 08:13:33 --> Language Class Initialized
INFO - 2019-11-02 08:13:33 --> Language Class Initialized
INFO - 2019-11-02 08:13:33 --> Config Class Initialized
INFO - 2019-11-02 08:13:33 --> Loader Class Initialized
INFO - 2019-11-02 08:13:33 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:33 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:33 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:33 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:33 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:33 --> Controller Class Initialized
INFO - 2019-11-02 08:13:34 --> Config Class Initialized
INFO - 2019-11-02 08:13:34 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:13:34 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:13:34 --> Utf8 Class Initialized
INFO - 2019-11-02 08:13:34 --> URI Class Initialized
INFO - 2019-11-02 08:13:34 --> Router Class Initialized
INFO - 2019-11-02 08:13:34 --> Output Class Initialized
INFO - 2019-11-02 08:13:34 --> Security Class Initialized
DEBUG - 2019-11-02 08:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:13:34 --> Input Class Initialized
INFO - 2019-11-02 08:13:34 --> Language Class Initialized
INFO - 2019-11-02 08:13:34 --> Language Class Initialized
INFO - 2019-11-02 08:13:34 --> Config Class Initialized
INFO - 2019-11-02 08:13:34 --> Loader Class Initialized
INFO - 2019-11-02 08:13:34 --> Helper loaded: url_helper
INFO - 2019-11-02 08:13:34 --> Helper loaded: file_helper
INFO - 2019-11-02 08:13:34 --> Helper loaded: form_helper
INFO - 2019-11-02 08:13:34 --> Helper loaded: my_helper
INFO - 2019-11-02 08:13:34 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:13:34 --> Controller Class Initialized
INFO - 2019-11-02 08:36:54 --> Config Class Initialized
INFO - 2019-11-02 08:36:54 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:36:54 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:36:54 --> Utf8 Class Initialized
INFO - 2019-11-02 08:36:54 --> URI Class Initialized
INFO - 2019-11-02 08:36:54 --> Router Class Initialized
INFO - 2019-11-02 08:36:54 --> Output Class Initialized
INFO - 2019-11-02 08:36:54 --> Security Class Initialized
DEBUG - 2019-11-02 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:36:54 --> Input Class Initialized
INFO - 2019-11-02 08:36:54 --> Language Class Initialized
INFO - 2019-11-02 08:36:54 --> Language Class Initialized
INFO - 2019-11-02 08:36:54 --> Config Class Initialized
INFO - 2019-11-02 08:36:54 --> Loader Class Initialized
INFO - 2019-11-02 08:36:54 --> Helper loaded: url_helper
INFO - 2019-11-02 08:36:54 --> Helper loaded: file_helper
INFO - 2019-11-02 08:36:54 --> Helper loaded: form_helper
INFO - 2019-11-02 08:36:54 --> Helper loaded: my_helper
INFO - 2019-11-02 08:36:54 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:36:54 --> Controller Class Initialized
INFO - 2019-11-02 08:36:54 --> Helper loaded: cookie_helper
INFO - 2019-11-02 08:36:54 --> Config Class Initialized
INFO - 2019-11-02 08:36:54 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:36:54 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:36:54 --> Utf8 Class Initialized
INFO - 2019-11-02 08:36:54 --> URI Class Initialized
INFO - 2019-11-02 08:36:54 --> Router Class Initialized
INFO - 2019-11-02 08:36:54 --> Output Class Initialized
INFO - 2019-11-02 08:36:54 --> Security Class Initialized
DEBUG - 2019-11-02 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:36:54 --> Input Class Initialized
INFO - 2019-11-02 08:36:54 --> Language Class Initialized
INFO - 2019-11-02 08:36:54 --> Language Class Initialized
INFO - 2019-11-02 08:36:54 --> Config Class Initialized
INFO - 2019-11-02 08:36:54 --> Loader Class Initialized
INFO - 2019-11-02 08:36:54 --> Helper loaded: url_helper
INFO - 2019-11-02 08:36:54 --> Helper loaded: file_helper
INFO - 2019-11-02 08:36:54 --> Helper loaded: form_helper
INFO - 2019-11-02 08:36:54 --> Helper loaded: my_helper
INFO - 2019-11-02 08:36:54 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:36:54 --> Controller Class Initialized
DEBUG - 2019-11-02 08:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-11-02 08:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:36:54 --> Final output sent to browser
DEBUG - 2019-11-02 08:36:54 --> Total execution time: 0.0542
INFO - 2019-11-02 08:36:59 --> Config Class Initialized
INFO - 2019-11-02 08:36:59 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:36:59 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:36:59 --> Utf8 Class Initialized
INFO - 2019-11-02 08:36:59 --> URI Class Initialized
INFO - 2019-11-02 08:36:59 --> Router Class Initialized
INFO - 2019-11-02 08:36:59 --> Output Class Initialized
INFO - 2019-11-02 08:36:59 --> Security Class Initialized
DEBUG - 2019-11-02 08:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:36:59 --> Input Class Initialized
INFO - 2019-11-02 08:36:59 --> Language Class Initialized
INFO - 2019-11-02 08:36:59 --> Language Class Initialized
INFO - 2019-11-02 08:36:59 --> Config Class Initialized
INFO - 2019-11-02 08:36:59 --> Loader Class Initialized
INFO - 2019-11-02 08:36:59 --> Helper loaded: url_helper
INFO - 2019-11-02 08:36:59 --> Helper loaded: file_helper
INFO - 2019-11-02 08:36:59 --> Helper loaded: form_helper
INFO - 2019-11-02 08:36:59 --> Helper loaded: my_helper
INFO - 2019-11-02 08:36:59 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:36:59 --> Controller Class Initialized
INFO - 2019-11-02 08:36:59 --> Helper loaded: cookie_helper
INFO - 2019-11-02 08:36:59 --> Final output sent to browser
DEBUG - 2019-11-02 08:36:59 --> Total execution time: 0.0534
INFO - 2019-11-02 08:36:59 --> Config Class Initialized
INFO - 2019-11-02 08:36:59 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:36:59 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:36:59 --> Utf8 Class Initialized
INFO - 2019-11-02 08:36:59 --> URI Class Initialized
INFO - 2019-11-02 08:36:59 --> Router Class Initialized
INFO - 2019-11-02 08:36:59 --> Output Class Initialized
INFO - 2019-11-02 08:36:59 --> Security Class Initialized
DEBUG - 2019-11-02 08:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:36:59 --> Input Class Initialized
INFO - 2019-11-02 08:36:59 --> Language Class Initialized
INFO - 2019-11-02 08:36:59 --> Language Class Initialized
INFO - 2019-11-02 08:36:59 --> Config Class Initialized
INFO - 2019-11-02 08:36:59 --> Loader Class Initialized
INFO - 2019-11-02 08:36:59 --> Helper loaded: url_helper
INFO - 2019-11-02 08:36:59 --> Helper loaded: file_helper
INFO - 2019-11-02 08:36:59 --> Helper loaded: form_helper
INFO - 2019-11-02 08:36:59 --> Helper loaded: my_helper
INFO - 2019-11-02 08:36:59 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:36:59 --> Controller Class Initialized
DEBUG - 2019-11-02 08:36:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-11-02 08:36:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:36:59 --> Final output sent to browser
DEBUG - 2019-11-02 08:36:59 --> Total execution time: 0.1060
INFO - 2019-11-02 08:37:02 --> Config Class Initialized
INFO - 2019-11-02 08:37:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:37:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:37:02 --> Utf8 Class Initialized
INFO - 2019-11-02 08:37:02 --> URI Class Initialized
INFO - 2019-11-02 08:37:02 --> Router Class Initialized
INFO - 2019-11-02 08:37:02 --> Output Class Initialized
INFO - 2019-11-02 08:37:02 --> Security Class Initialized
DEBUG - 2019-11-02 08:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:37:02 --> Input Class Initialized
INFO - 2019-11-02 08:37:02 --> Language Class Initialized
INFO - 2019-11-02 08:37:02 --> Language Class Initialized
INFO - 2019-11-02 08:37:02 --> Config Class Initialized
INFO - 2019-11-02 08:37:02 --> Loader Class Initialized
INFO - 2019-11-02 08:37:02 --> Helper loaded: url_helper
INFO - 2019-11-02 08:37:02 --> Helper loaded: file_helper
INFO - 2019-11-02 08:37:02 --> Helper loaded: form_helper
INFO - 2019-11-02 08:37:02 --> Helper loaded: my_helper
INFO - 2019-11-02 08:37:02 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:37:02 --> Controller Class Initialized
DEBUG - 2019-11-02 08:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 08:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:37:02 --> Final output sent to browser
DEBUG - 2019-11-02 08:37:02 --> Total execution time: 0.0551
INFO - 2019-11-02 08:43:25 --> Config Class Initialized
INFO - 2019-11-02 08:43:25 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:43:25 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:43:25 --> Utf8 Class Initialized
INFO - 2019-11-02 08:43:25 --> URI Class Initialized
INFO - 2019-11-02 08:43:25 --> Router Class Initialized
INFO - 2019-11-02 08:43:25 --> Output Class Initialized
INFO - 2019-11-02 08:43:25 --> Security Class Initialized
DEBUG - 2019-11-02 08:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:43:25 --> Input Class Initialized
INFO - 2019-11-02 08:43:25 --> Language Class Initialized
INFO - 2019-11-02 08:43:25 --> Language Class Initialized
INFO - 2019-11-02 08:43:25 --> Config Class Initialized
INFO - 2019-11-02 08:43:25 --> Loader Class Initialized
INFO - 2019-11-02 08:43:25 --> Helper loaded: url_helper
INFO - 2019-11-02 08:43:25 --> Helper loaded: file_helper
INFO - 2019-11-02 08:43:25 --> Helper loaded: form_helper
INFO - 2019-11-02 08:43:25 --> Helper loaded: my_helper
INFO - 2019-11-02 08:43:25 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:43:25 --> Controller Class Initialized
INFO - 2019-11-02 08:43:25 --> Final output sent to browser
DEBUG - 2019-11-02 08:43:25 --> Total execution time: 0.0523
INFO - 2019-11-02 08:43:27 --> Config Class Initialized
INFO - 2019-11-02 08:43:27 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:43:27 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:43:27 --> Utf8 Class Initialized
INFO - 2019-11-02 08:43:27 --> URI Class Initialized
INFO - 2019-11-02 08:43:27 --> Router Class Initialized
INFO - 2019-11-02 08:43:27 --> Output Class Initialized
INFO - 2019-11-02 08:43:27 --> Security Class Initialized
DEBUG - 2019-11-02 08:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:43:27 --> Input Class Initialized
INFO - 2019-11-02 08:43:27 --> Language Class Initialized
INFO - 2019-11-02 08:43:27 --> Language Class Initialized
INFO - 2019-11-02 08:43:27 --> Config Class Initialized
INFO - 2019-11-02 08:43:27 --> Loader Class Initialized
INFO - 2019-11-02 08:43:27 --> Helper loaded: url_helper
INFO - 2019-11-02 08:43:27 --> Helper loaded: file_helper
INFO - 2019-11-02 08:43:27 --> Helper loaded: form_helper
INFO - 2019-11-02 08:43:27 --> Helper loaded: my_helper
INFO - 2019-11-02 08:43:27 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:43:27 --> Controller Class Initialized
DEBUG - 2019-11-02 08:43:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 08:43:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:43:27 --> Final output sent to browser
DEBUG - 2019-11-02 08:43:27 --> Total execution time: 0.0619
INFO - 2019-11-02 08:43:45 --> Config Class Initialized
INFO - 2019-11-02 08:43:45 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:43:45 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:43:45 --> Utf8 Class Initialized
INFO - 2019-11-02 08:43:45 --> URI Class Initialized
INFO - 2019-11-02 08:43:45 --> Router Class Initialized
INFO - 2019-11-02 08:43:45 --> Output Class Initialized
INFO - 2019-11-02 08:43:45 --> Security Class Initialized
DEBUG - 2019-11-02 08:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:43:45 --> Input Class Initialized
INFO - 2019-11-02 08:43:45 --> Language Class Initialized
INFO - 2019-11-02 08:43:45 --> Language Class Initialized
INFO - 2019-11-02 08:43:45 --> Config Class Initialized
INFO - 2019-11-02 08:43:45 --> Loader Class Initialized
INFO - 2019-11-02 08:43:45 --> Helper loaded: url_helper
INFO - 2019-11-02 08:43:45 --> Helper loaded: file_helper
INFO - 2019-11-02 08:43:45 --> Helper loaded: form_helper
INFO - 2019-11-02 08:43:45 --> Helper loaded: my_helper
INFO - 2019-11-02 08:43:45 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:43:45 --> Controller Class Initialized
INFO - 2019-11-02 08:43:45 --> Final output sent to browser
DEBUG - 2019-11-02 08:43:45 --> Total execution time: 0.0650
INFO - 2019-11-02 08:46:30 --> Config Class Initialized
INFO - 2019-11-02 08:46:30 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:46:30 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:46:30 --> Utf8 Class Initialized
INFO - 2019-11-02 08:46:30 --> URI Class Initialized
INFO - 2019-11-02 08:46:30 --> Router Class Initialized
INFO - 2019-11-02 08:46:30 --> Output Class Initialized
INFO - 2019-11-02 08:46:30 --> Security Class Initialized
DEBUG - 2019-11-02 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:46:30 --> Input Class Initialized
INFO - 2019-11-02 08:46:30 --> Language Class Initialized
INFO - 2019-11-02 08:46:30 --> Language Class Initialized
INFO - 2019-11-02 08:46:30 --> Config Class Initialized
INFO - 2019-11-02 08:46:30 --> Loader Class Initialized
INFO - 2019-11-02 08:46:30 --> Helper loaded: url_helper
INFO - 2019-11-02 08:46:30 --> Helper loaded: file_helper
INFO - 2019-11-02 08:46:30 --> Helper loaded: form_helper
INFO - 2019-11-02 08:46:30 --> Helper loaded: my_helper
INFO - 2019-11-02 08:46:30 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:46:30 --> Controller Class Initialized
INFO - 2019-11-02 08:46:30 --> Final output sent to browser
DEBUG - 2019-11-02 08:46:30 --> Total execution time: 0.0634
INFO - 2019-11-02 08:46:33 --> Config Class Initialized
INFO - 2019-11-02 08:46:33 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:46:33 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:46:33 --> Utf8 Class Initialized
INFO - 2019-11-02 08:46:33 --> URI Class Initialized
INFO - 2019-11-02 08:46:33 --> Router Class Initialized
INFO - 2019-11-02 08:46:33 --> Output Class Initialized
INFO - 2019-11-02 08:46:33 --> Security Class Initialized
DEBUG - 2019-11-02 08:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:46:33 --> Input Class Initialized
INFO - 2019-11-02 08:46:33 --> Language Class Initialized
INFO - 2019-11-02 08:46:33 --> Language Class Initialized
INFO - 2019-11-02 08:46:33 --> Config Class Initialized
INFO - 2019-11-02 08:46:33 --> Loader Class Initialized
INFO - 2019-11-02 08:46:33 --> Helper loaded: url_helper
INFO - 2019-11-02 08:46:33 --> Helper loaded: file_helper
INFO - 2019-11-02 08:46:33 --> Helper loaded: form_helper
INFO - 2019-11-02 08:46:33 --> Helper loaded: my_helper
INFO - 2019-11-02 08:46:33 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:46:33 --> Controller Class Initialized
DEBUG - 2019-11-02 08:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 08:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:46:33 --> Final output sent to browser
DEBUG - 2019-11-02 08:46:33 --> Total execution time: 0.0651
INFO - 2019-11-02 08:50:28 --> Config Class Initialized
INFO - 2019-11-02 08:50:28 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:50:28 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:50:28 --> Utf8 Class Initialized
INFO - 2019-11-02 08:50:28 --> URI Class Initialized
INFO - 2019-11-02 08:50:28 --> Router Class Initialized
INFO - 2019-11-02 08:50:28 --> Output Class Initialized
INFO - 2019-11-02 08:50:28 --> Security Class Initialized
DEBUG - 2019-11-02 08:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:50:28 --> Input Class Initialized
INFO - 2019-11-02 08:50:28 --> Language Class Initialized
INFO - 2019-11-02 08:50:28 --> Language Class Initialized
INFO - 2019-11-02 08:50:28 --> Config Class Initialized
INFO - 2019-11-02 08:50:28 --> Loader Class Initialized
INFO - 2019-11-02 08:50:28 --> Helper loaded: url_helper
INFO - 2019-11-02 08:50:28 --> Helper loaded: file_helper
INFO - 2019-11-02 08:50:28 --> Helper loaded: form_helper
INFO - 2019-11-02 08:50:28 --> Helper loaded: my_helper
INFO - 2019-11-02 08:50:28 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:50:28 --> Controller Class Initialized
INFO - 2019-11-02 08:50:28 --> Final output sent to browser
DEBUG - 2019-11-02 08:50:28 --> Total execution time: 0.0460
INFO - 2019-11-02 08:50:30 --> Config Class Initialized
INFO - 2019-11-02 08:50:30 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:50:30 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:50:30 --> Utf8 Class Initialized
INFO - 2019-11-02 08:50:30 --> URI Class Initialized
INFO - 2019-11-02 08:50:30 --> Router Class Initialized
INFO - 2019-11-02 08:50:30 --> Output Class Initialized
INFO - 2019-11-02 08:50:30 --> Security Class Initialized
DEBUG - 2019-11-02 08:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:50:30 --> Input Class Initialized
INFO - 2019-11-02 08:50:30 --> Language Class Initialized
INFO - 2019-11-02 08:50:30 --> Language Class Initialized
INFO - 2019-11-02 08:50:30 --> Config Class Initialized
INFO - 2019-11-02 08:50:30 --> Loader Class Initialized
INFO - 2019-11-02 08:50:30 --> Helper loaded: url_helper
INFO - 2019-11-02 08:50:30 --> Helper loaded: file_helper
INFO - 2019-11-02 08:50:30 --> Helper loaded: form_helper
INFO - 2019-11-02 08:50:30 --> Helper loaded: my_helper
INFO - 2019-11-02 08:50:30 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:50:30 --> Controller Class Initialized
DEBUG - 2019-11-02 08:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 08:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:50:30 --> Final output sent to browser
DEBUG - 2019-11-02 08:50:30 --> Total execution time: 0.0620
INFO - 2019-11-02 08:51:24 --> Config Class Initialized
INFO - 2019-11-02 08:51:24 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:51:24 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:51:24 --> Utf8 Class Initialized
INFO - 2019-11-02 08:51:24 --> URI Class Initialized
INFO - 2019-11-02 08:51:24 --> Router Class Initialized
INFO - 2019-11-02 08:51:24 --> Output Class Initialized
INFO - 2019-11-02 08:51:24 --> Security Class Initialized
DEBUG - 2019-11-02 08:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:51:24 --> Input Class Initialized
INFO - 2019-11-02 08:51:24 --> Language Class Initialized
INFO - 2019-11-02 08:51:24 --> Language Class Initialized
INFO - 2019-11-02 08:51:24 --> Config Class Initialized
INFO - 2019-11-02 08:51:24 --> Loader Class Initialized
INFO - 2019-11-02 08:51:24 --> Helper loaded: url_helper
INFO - 2019-11-02 08:51:24 --> Helper loaded: file_helper
INFO - 2019-11-02 08:51:24 --> Helper loaded: form_helper
INFO - 2019-11-02 08:51:24 --> Helper loaded: my_helper
INFO - 2019-11-02 08:51:24 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:51:24 --> Controller Class Initialized
INFO - 2019-11-02 08:51:24 --> Final output sent to browser
DEBUG - 2019-11-02 08:51:24 --> Total execution time: 0.0470
INFO - 2019-11-02 08:51:26 --> Config Class Initialized
INFO - 2019-11-02 08:51:26 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:51:26 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:51:26 --> Utf8 Class Initialized
INFO - 2019-11-02 08:51:26 --> URI Class Initialized
INFO - 2019-11-02 08:51:26 --> Router Class Initialized
INFO - 2019-11-02 08:51:26 --> Output Class Initialized
INFO - 2019-11-02 08:51:26 --> Security Class Initialized
DEBUG - 2019-11-02 08:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:51:26 --> Input Class Initialized
INFO - 2019-11-02 08:51:26 --> Language Class Initialized
INFO - 2019-11-02 08:51:26 --> Language Class Initialized
INFO - 2019-11-02 08:51:26 --> Config Class Initialized
INFO - 2019-11-02 08:51:26 --> Loader Class Initialized
INFO - 2019-11-02 08:51:26 --> Helper loaded: url_helper
INFO - 2019-11-02 08:51:26 --> Helper loaded: file_helper
INFO - 2019-11-02 08:51:26 --> Helper loaded: form_helper
INFO - 2019-11-02 08:51:26 --> Helper loaded: my_helper
INFO - 2019-11-02 08:51:26 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:51:26 --> Controller Class Initialized
DEBUG - 2019-11-02 08:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 08:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 08:51:26 --> Final output sent to browser
DEBUG - 2019-11-02 08:51:26 --> Total execution time: 0.0516
INFO - 2019-11-02 08:52:38 --> Config Class Initialized
INFO - 2019-11-02 08:52:38 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:52:38 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:52:38 --> Utf8 Class Initialized
INFO - 2019-11-02 08:52:38 --> URI Class Initialized
INFO - 2019-11-02 08:52:38 --> Router Class Initialized
INFO - 2019-11-02 08:52:38 --> Output Class Initialized
INFO - 2019-11-02 08:52:38 --> Security Class Initialized
DEBUG - 2019-11-02 08:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:52:38 --> Input Class Initialized
INFO - 2019-11-02 08:52:38 --> Language Class Initialized
INFO - 2019-11-02 08:52:38 --> Language Class Initialized
INFO - 2019-11-02 08:52:38 --> Config Class Initialized
INFO - 2019-11-02 08:52:38 --> Loader Class Initialized
INFO - 2019-11-02 08:52:38 --> Helper loaded: url_helper
INFO - 2019-11-02 08:52:38 --> Helper loaded: file_helper
INFO - 2019-11-02 08:52:38 --> Helper loaded: form_helper
INFO - 2019-11-02 08:52:38 --> Helper loaded: my_helper
INFO - 2019-11-02 08:52:38 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:52:38 --> Controller Class Initialized
INFO - 2019-11-02 08:52:38 --> Final output sent to browser
DEBUG - 2019-11-02 08:52:38 --> Total execution time: 0.0622
INFO - 2019-11-02 08:52:59 --> Config Class Initialized
INFO - 2019-11-02 08:52:59 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:52:59 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:52:59 --> Utf8 Class Initialized
INFO - 2019-11-02 08:52:59 --> URI Class Initialized
INFO - 2019-11-02 08:52:59 --> Router Class Initialized
INFO - 2019-11-02 08:52:59 --> Output Class Initialized
INFO - 2019-11-02 08:52:59 --> Security Class Initialized
DEBUG - 2019-11-02 08:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:52:59 --> Input Class Initialized
INFO - 2019-11-02 08:52:59 --> Language Class Initialized
INFO - 2019-11-02 08:52:59 --> Language Class Initialized
INFO - 2019-11-02 08:52:59 --> Config Class Initialized
INFO - 2019-11-02 08:52:59 --> Loader Class Initialized
INFO - 2019-11-02 08:52:59 --> Helper loaded: url_helper
INFO - 2019-11-02 08:52:59 --> Helper loaded: file_helper
INFO - 2019-11-02 08:52:59 --> Helper loaded: form_helper
INFO - 2019-11-02 08:52:59 --> Helper loaded: my_helper
INFO - 2019-11-02 08:52:59 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:52:59 --> Controller Class Initialized
INFO - 2019-11-02 08:52:59 --> Final output sent to browser
DEBUG - 2019-11-02 08:52:59 --> Total execution time: 0.0583
INFO - 2019-11-02 08:53:02 --> Config Class Initialized
INFO - 2019-11-02 08:53:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:53:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:53:02 --> Utf8 Class Initialized
INFO - 2019-11-02 08:53:02 --> URI Class Initialized
INFO - 2019-11-02 08:53:02 --> Router Class Initialized
INFO - 2019-11-02 08:53:02 --> Output Class Initialized
INFO - 2019-11-02 08:53:02 --> Security Class Initialized
DEBUG - 2019-11-02 08:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:53:02 --> Input Class Initialized
INFO - 2019-11-02 08:53:02 --> Language Class Initialized
INFO - 2019-11-02 08:53:02 --> Language Class Initialized
INFO - 2019-11-02 08:53:02 --> Config Class Initialized
INFO - 2019-11-02 08:53:02 --> Loader Class Initialized
INFO - 2019-11-02 08:53:02 --> Helper loaded: url_helper
INFO - 2019-11-02 08:53:02 --> Helper loaded: file_helper
INFO - 2019-11-02 08:53:02 --> Helper loaded: form_helper
INFO - 2019-11-02 08:53:02 --> Helper loaded: my_helper
INFO - 2019-11-02 08:53:02 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:53:02 --> Controller Class Initialized
INFO - 2019-11-02 08:53:02 --> Final output sent to browser
DEBUG - 2019-11-02 08:53:02 --> Total execution time: 0.0650
INFO - 2019-11-02 08:53:35 --> Config Class Initialized
INFO - 2019-11-02 08:53:35 --> Hooks Class Initialized
DEBUG - 2019-11-02 08:53:35 --> UTF-8 Support Enabled
INFO - 2019-11-02 08:53:35 --> Utf8 Class Initialized
INFO - 2019-11-02 08:53:35 --> URI Class Initialized
INFO - 2019-11-02 08:53:35 --> Router Class Initialized
INFO - 2019-11-02 08:53:35 --> Output Class Initialized
INFO - 2019-11-02 08:53:35 --> Security Class Initialized
DEBUG - 2019-11-02 08:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 08:53:35 --> Input Class Initialized
INFO - 2019-11-02 08:53:35 --> Language Class Initialized
INFO - 2019-11-02 08:53:35 --> Language Class Initialized
INFO - 2019-11-02 08:53:35 --> Config Class Initialized
INFO - 2019-11-02 08:53:35 --> Loader Class Initialized
INFO - 2019-11-02 08:53:35 --> Helper loaded: url_helper
INFO - 2019-11-02 08:53:35 --> Helper loaded: file_helper
INFO - 2019-11-02 08:53:35 --> Helper loaded: form_helper
INFO - 2019-11-02 08:53:35 --> Helper loaded: my_helper
INFO - 2019-11-02 08:53:35 --> Database Driver Class Initialized
DEBUG - 2019-11-02 08:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 08:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 08:53:35 --> Controller Class Initialized
INFO - 2019-11-02 08:53:35 --> Final output sent to browser
DEBUG - 2019-11-02 08:53:35 --> Total execution time: 0.0644
INFO - 2019-11-02 09:06:33 --> Config Class Initialized
INFO - 2019-11-02 09:06:33 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:06:33 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:06:33 --> Utf8 Class Initialized
INFO - 2019-11-02 09:06:33 --> URI Class Initialized
INFO - 2019-11-02 09:06:33 --> Router Class Initialized
INFO - 2019-11-02 09:06:33 --> Output Class Initialized
INFO - 2019-11-02 09:06:33 --> Security Class Initialized
DEBUG - 2019-11-02 09:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:06:33 --> Input Class Initialized
INFO - 2019-11-02 09:06:33 --> Language Class Initialized
INFO - 2019-11-02 09:06:33 --> Language Class Initialized
INFO - 2019-11-02 09:06:33 --> Config Class Initialized
INFO - 2019-11-02 09:06:33 --> Loader Class Initialized
INFO - 2019-11-02 09:06:33 --> Helper loaded: url_helper
INFO - 2019-11-02 09:06:33 --> Helper loaded: file_helper
INFO - 2019-11-02 09:06:33 --> Helper loaded: form_helper
INFO - 2019-11-02 09:06:33 --> Helper loaded: my_helper
INFO - 2019-11-02 09:06:33 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:06:33 --> Controller Class Initialized
DEBUG - 2019-11-02 09:06:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:06:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:06:33 --> Final output sent to browser
DEBUG - 2019-11-02 09:06:33 --> Total execution time: 0.0539
INFO - 2019-11-02 09:15:43 --> Config Class Initialized
INFO - 2019-11-02 09:15:43 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:43 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:43 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:43 --> URI Class Initialized
INFO - 2019-11-02 09:15:43 --> Router Class Initialized
INFO - 2019-11-02 09:15:43 --> Output Class Initialized
INFO - 2019-11-02 09:15:43 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:43 --> Input Class Initialized
INFO - 2019-11-02 09:15:43 --> Language Class Initialized
INFO - 2019-11-02 09:15:43 --> Language Class Initialized
INFO - 2019-11-02 09:15:43 --> Config Class Initialized
INFO - 2019-11-02 09:15:43 --> Loader Class Initialized
INFO - 2019-11-02 09:15:43 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:43 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:43 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:43 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:43 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:43 --> Controller Class Initialized
DEBUG - 2019-11-02 09:15:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-11-02 09:15:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:15:43 --> Final output sent to browser
DEBUG - 2019-11-02 09:15:43 --> Total execution time: 0.0806
INFO - 2019-11-02 09:15:43 --> Config Class Initialized
INFO - 2019-11-02 09:15:43 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:43 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:43 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:43 --> URI Class Initialized
INFO - 2019-11-02 09:15:43 --> Router Class Initialized
INFO - 2019-11-02 09:15:43 --> Output Class Initialized
INFO - 2019-11-02 09:15:43 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:43 --> Input Class Initialized
INFO - 2019-11-02 09:15:43 --> Language Class Initialized
INFO - 2019-11-02 09:15:43 --> Language Class Initialized
INFO - 2019-11-02 09:15:43 --> Config Class Initialized
INFO - 2019-11-02 09:15:43 --> Loader Class Initialized
INFO - 2019-11-02 09:15:43 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:43 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:43 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:43 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:43 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:43 --> Controller Class Initialized
INFO - 2019-11-02 09:15:46 --> Config Class Initialized
INFO - 2019-11-02 09:15:46 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:46 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:46 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:46 --> URI Class Initialized
INFO - 2019-11-02 09:15:46 --> Router Class Initialized
INFO - 2019-11-02 09:15:46 --> Output Class Initialized
INFO - 2019-11-02 09:15:46 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:46 --> Input Class Initialized
INFO - 2019-11-02 09:15:46 --> Language Class Initialized
INFO - 2019-11-02 09:15:46 --> Language Class Initialized
INFO - 2019-11-02 09:15:46 --> Config Class Initialized
INFO - 2019-11-02 09:15:46 --> Loader Class Initialized
INFO - 2019-11-02 09:15:46 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:46 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:46 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:46 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:46 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:46 --> Controller Class Initialized
INFO - 2019-11-02 09:15:47 --> Config Class Initialized
INFO - 2019-11-02 09:15:47 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:47 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:47 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:47 --> URI Class Initialized
INFO - 2019-11-02 09:15:47 --> Router Class Initialized
INFO - 2019-11-02 09:15:47 --> Output Class Initialized
INFO - 2019-11-02 09:15:47 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:47 --> Input Class Initialized
INFO - 2019-11-02 09:15:47 --> Language Class Initialized
INFO - 2019-11-02 09:15:47 --> Language Class Initialized
INFO - 2019-11-02 09:15:47 --> Config Class Initialized
INFO - 2019-11-02 09:15:47 --> Loader Class Initialized
INFO - 2019-11-02 09:15:47 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:47 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:47 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:47 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:47 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:47 --> Controller Class Initialized
INFO - 2019-11-02 09:15:47 --> Config Class Initialized
INFO - 2019-11-02 09:15:47 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:47 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:47 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:47 --> URI Class Initialized
INFO - 2019-11-02 09:15:47 --> Router Class Initialized
INFO - 2019-11-02 09:15:47 --> Output Class Initialized
INFO - 2019-11-02 09:15:47 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:47 --> Input Class Initialized
INFO - 2019-11-02 09:15:47 --> Language Class Initialized
INFO - 2019-11-02 09:15:47 --> Language Class Initialized
INFO - 2019-11-02 09:15:47 --> Config Class Initialized
INFO - 2019-11-02 09:15:47 --> Loader Class Initialized
INFO - 2019-11-02 09:15:47 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:47 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:47 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:47 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:47 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:47 --> Controller Class Initialized
INFO - 2019-11-02 09:15:48 --> Config Class Initialized
INFO - 2019-11-02 09:15:48 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:48 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:48 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:48 --> URI Class Initialized
INFO - 2019-11-02 09:15:48 --> Router Class Initialized
INFO - 2019-11-02 09:15:48 --> Output Class Initialized
INFO - 2019-11-02 09:15:48 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:48 --> Input Class Initialized
INFO - 2019-11-02 09:15:48 --> Language Class Initialized
INFO - 2019-11-02 09:15:48 --> Language Class Initialized
INFO - 2019-11-02 09:15:48 --> Config Class Initialized
INFO - 2019-11-02 09:15:48 --> Loader Class Initialized
INFO - 2019-11-02 09:15:48 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:48 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:48 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:48 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:48 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:48 --> Controller Class Initialized
INFO - 2019-11-02 09:15:51 --> Config Class Initialized
INFO - 2019-11-02 09:15:51 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:51 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:51 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:51 --> URI Class Initialized
INFO - 2019-11-02 09:15:51 --> Router Class Initialized
INFO - 2019-11-02 09:15:51 --> Output Class Initialized
INFO - 2019-11-02 09:15:51 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:51 --> Input Class Initialized
INFO - 2019-11-02 09:15:51 --> Language Class Initialized
INFO - 2019-11-02 09:15:51 --> Language Class Initialized
INFO - 2019-11-02 09:15:51 --> Config Class Initialized
INFO - 2019-11-02 09:15:51 --> Loader Class Initialized
INFO - 2019-11-02 09:15:51 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:51 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:51 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:51 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:51 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:51 --> Controller Class Initialized
INFO - 2019-11-02 09:15:51 --> Config Class Initialized
INFO - 2019-11-02 09:15:51 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:51 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:51 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:51 --> URI Class Initialized
INFO - 2019-11-02 09:15:51 --> Router Class Initialized
INFO - 2019-11-02 09:15:51 --> Output Class Initialized
INFO - 2019-11-02 09:15:51 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:51 --> Input Class Initialized
INFO - 2019-11-02 09:15:51 --> Language Class Initialized
INFO - 2019-11-02 09:15:51 --> Language Class Initialized
INFO - 2019-11-02 09:15:51 --> Config Class Initialized
INFO - 2019-11-02 09:15:51 --> Loader Class Initialized
INFO - 2019-11-02 09:15:51 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:51 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:51 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:51 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:51 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:51 --> Controller Class Initialized
INFO - 2019-11-02 09:15:52 --> Config Class Initialized
INFO - 2019-11-02 09:15:52 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:52 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:52 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:52 --> URI Class Initialized
INFO - 2019-11-02 09:15:52 --> Router Class Initialized
INFO - 2019-11-02 09:15:52 --> Output Class Initialized
INFO - 2019-11-02 09:15:52 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:52 --> Input Class Initialized
INFO - 2019-11-02 09:15:52 --> Language Class Initialized
INFO - 2019-11-02 09:15:52 --> Language Class Initialized
INFO - 2019-11-02 09:15:52 --> Config Class Initialized
INFO - 2019-11-02 09:15:52 --> Loader Class Initialized
INFO - 2019-11-02 09:15:52 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:52 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:52 --> Controller Class Initialized
INFO - 2019-11-02 09:15:52 --> Config Class Initialized
INFO - 2019-11-02 09:15:52 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:52 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:52 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:52 --> URI Class Initialized
INFO - 2019-11-02 09:15:52 --> Router Class Initialized
INFO - 2019-11-02 09:15:52 --> Output Class Initialized
INFO - 2019-11-02 09:15:52 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:52 --> Input Class Initialized
INFO - 2019-11-02 09:15:52 --> Language Class Initialized
INFO - 2019-11-02 09:15:52 --> Language Class Initialized
INFO - 2019-11-02 09:15:52 --> Config Class Initialized
INFO - 2019-11-02 09:15:52 --> Loader Class Initialized
INFO - 2019-11-02 09:15:52 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:52 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:52 --> Controller Class Initialized
INFO - 2019-11-02 09:15:52 --> Config Class Initialized
INFO - 2019-11-02 09:15:52 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:52 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:52 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:52 --> URI Class Initialized
INFO - 2019-11-02 09:15:52 --> Router Class Initialized
INFO - 2019-11-02 09:15:52 --> Output Class Initialized
INFO - 2019-11-02 09:15:52 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:52 --> Input Class Initialized
INFO - 2019-11-02 09:15:52 --> Language Class Initialized
INFO - 2019-11-02 09:15:52 --> Language Class Initialized
INFO - 2019-11-02 09:15:52 --> Config Class Initialized
INFO - 2019-11-02 09:15:52 --> Loader Class Initialized
INFO - 2019-11-02 09:15:52 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:52 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:52 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:52 --> Controller Class Initialized
INFO - 2019-11-02 09:15:53 --> Config Class Initialized
INFO - 2019-11-02 09:15:53 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:53 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:53 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:53 --> URI Class Initialized
INFO - 2019-11-02 09:15:53 --> Router Class Initialized
INFO - 2019-11-02 09:15:53 --> Output Class Initialized
INFO - 2019-11-02 09:15:53 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:53 --> Input Class Initialized
INFO - 2019-11-02 09:15:53 --> Language Class Initialized
INFO - 2019-11-02 09:15:53 --> Language Class Initialized
INFO - 2019-11-02 09:15:53 --> Config Class Initialized
INFO - 2019-11-02 09:15:53 --> Loader Class Initialized
INFO - 2019-11-02 09:15:53 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:53 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:53 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:53 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:53 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:53 --> Controller Class Initialized
INFO - 2019-11-02 09:15:58 --> Config Class Initialized
INFO - 2019-11-02 09:15:58 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:15:58 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:15:58 --> Utf8 Class Initialized
INFO - 2019-11-02 09:15:58 --> URI Class Initialized
INFO - 2019-11-02 09:15:58 --> Router Class Initialized
INFO - 2019-11-02 09:15:58 --> Output Class Initialized
INFO - 2019-11-02 09:15:58 --> Security Class Initialized
DEBUG - 2019-11-02 09:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:15:58 --> Input Class Initialized
INFO - 2019-11-02 09:15:58 --> Language Class Initialized
INFO - 2019-11-02 09:15:58 --> Language Class Initialized
INFO - 2019-11-02 09:15:58 --> Config Class Initialized
INFO - 2019-11-02 09:15:58 --> Loader Class Initialized
INFO - 2019-11-02 09:15:58 --> Helper loaded: url_helper
INFO - 2019-11-02 09:15:58 --> Helper loaded: file_helper
INFO - 2019-11-02 09:15:58 --> Helper loaded: form_helper
INFO - 2019-11-02 09:15:58 --> Helper loaded: my_helper
INFO - 2019-11-02 09:15:58 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:15:58 --> Controller Class Initialized
ERROR - 2019-11-02 09:15:58 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2019-11-02 09:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2019-11-02 09:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:15:58 --> Final output sent to browser
DEBUG - 2019-11-02 09:15:58 --> Total execution time: 0.1208
INFO - 2019-11-02 09:16:07 --> Config Class Initialized
INFO - 2019-11-02 09:16:07 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:07 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:07 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:07 --> URI Class Initialized
INFO - 2019-11-02 09:16:07 --> Router Class Initialized
INFO - 2019-11-02 09:16:07 --> Output Class Initialized
INFO - 2019-11-02 09:16:07 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:07 --> Input Class Initialized
INFO - 2019-11-02 09:16:07 --> Language Class Initialized
INFO - 2019-11-02 09:16:07 --> Language Class Initialized
INFO - 2019-11-02 09:16:07 --> Config Class Initialized
INFO - 2019-11-02 09:16:07 --> Loader Class Initialized
INFO - 2019-11-02 09:16:07 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:07 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:07 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:07 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:07 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:07 --> Controller Class Initialized
INFO - 2019-11-02 09:16:07 --> Upload Class Initialized
INFO - 2019-11-02 09:16:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-11-02 09:16:07 --> The upload path does not appear to be valid.
INFO - 2019-11-02 09:16:07 --> Config Class Initialized
INFO - 2019-11-02 09:16:07 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:07 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:07 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:07 --> URI Class Initialized
INFO - 2019-11-02 09:16:07 --> Router Class Initialized
INFO - 2019-11-02 09:16:07 --> Output Class Initialized
INFO - 2019-11-02 09:16:07 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:07 --> Input Class Initialized
INFO - 2019-11-02 09:16:07 --> Language Class Initialized
INFO - 2019-11-02 09:16:07 --> Language Class Initialized
INFO - 2019-11-02 09:16:07 --> Config Class Initialized
INFO - 2019-11-02 09:16:07 --> Loader Class Initialized
INFO - 2019-11-02 09:16:07 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:07 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:07 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:07 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:07 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:07 --> Controller Class Initialized
DEBUG - 2019-11-02 09:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-11-02 09:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:16:07 --> Final output sent to browser
DEBUG - 2019-11-02 09:16:07 --> Total execution time: 0.0558
INFO - 2019-11-02 09:16:07 --> Config Class Initialized
INFO - 2019-11-02 09:16:07 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:07 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:07 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:07 --> URI Class Initialized
INFO - 2019-11-02 09:16:08 --> Router Class Initialized
INFO - 2019-11-02 09:16:08 --> Output Class Initialized
INFO - 2019-11-02 09:16:08 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:08 --> Input Class Initialized
INFO - 2019-11-02 09:16:08 --> Language Class Initialized
INFO - 2019-11-02 09:16:08 --> Language Class Initialized
INFO - 2019-11-02 09:16:08 --> Config Class Initialized
INFO - 2019-11-02 09:16:08 --> Loader Class Initialized
INFO - 2019-11-02 09:16:08 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:08 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:08 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:08 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:08 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:08 --> Controller Class Initialized
INFO - 2019-11-02 09:16:09 --> Config Class Initialized
INFO - 2019-11-02 09:16:09 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:09 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:09 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:09 --> URI Class Initialized
INFO - 2019-11-02 09:16:09 --> Router Class Initialized
INFO - 2019-11-02 09:16:09 --> Output Class Initialized
INFO - 2019-11-02 09:16:09 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:09 --> Input Class Initialized
INFO - 2019-11-02 09:16:09 --> Language Class Initialized
INFO - 2019-11-02 09:16:09 --> Language Class Initialized
INFO - 2019-11-02 09:16:09 --> Config Class Initialized
INFO - 2019-11-02 09:16:09 --> Loader Class Initialized
INFO - 2019-11-02 09:16:09 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:09 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:09 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:09 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:09 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:09 --> Controller Class Initialized
DEBUG - 2019-11-02 09:16:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:16:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:16:09 --> Final output sent to browser
DEBUG - 2019-11-02 09:16:09 --> Total execution time: 0.0628
INFO - 2019-11-02 09:16:22 --> Config Class Initialized
INFO - 2019-11-02 09:16:22 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:22 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:22 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:22 --> URI Class Initialized
INFO - 2019-11-02 09:16:22 --> Router Class Initialized
INFO - 2019-11-02 09:16:22 --> Output Class Initialized
INFO - 2019-11-02 09:16:22 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:22 --> Input Class Initialized
INFO - 2019-11-02 09:16:22 --> Language Class Initialized
INFO - 2019-11-02 09:16:22 --> Language Class Initialized
INFO - 2019-11-02 09:16:22 --> Config Class Initialized
INFO - 2019-11-02 09:16:22 --> Loader Class Initialized
INFO - 2019-11-02 09:16:22 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:22 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:22 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:22 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:22 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:22 --> Controller Class Initialized
INFO - 2019-11-02 09:16:22 --> Config Class Initialized
INFO - 2019-11-02 09:16:22 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:22 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:22 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:22 --> URI Class Initialized
INFO - 2019-11-02 09:16:22 --> Router Class Initialized
INFO - 2019-11-02 09:16:22 --> Output Class Initialized
INFO - 2019-11-02 09:16:22 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:22 --> Input Class Initialized
INFO - 2019-11-02 09:16:22 --> Language Class Initialized
INFO - 2019-11-02 09:16:22 --> Language Class Initialized
INFO - 2019-11-02 09:16:22 --> Config Class Initialized
INFO - 2019-11-02 09:16:22 --> Loader Class Initialized
INFO - 2019-11-02 09:16:22 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:22 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:22 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:22 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:22 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:22 --> Controller Class Initialized
INFO - 2019-11-02 09:16:23 --> Config Class Initialized
INFO - 2019-11-02 09:16:23 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:23 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:23 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:23 --> URI Class Initialized
INFO - 2019-11-02 09:16:23 --> Router Class Initialized
INFO - 2019-11-02 09:16:23 --> Output Class Initialized
INFO - 2019-11-02 09:16:23 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:23 --> Input Class Initialized
INFO - 2019-11-02 09:16:23 --> Language Class Initialized
INFO - 2019-11-02 09:16:23 --> Language Class Initialized
INFO - 2019-11-02 09:16:23 --> Config Class Initialized
INFO - 2019-11-02 09:16:23 --> Loader Class Initialized
INFO - 2019-11-02 09:16:23 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:23 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:23 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:23 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:23 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:23 --> Controller Class Initialized
INFO - 2019-11-02 09:16:23 --> Config Class Initialized
INFO - 2019-11-02 09:16:23 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:23 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:23 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:23 --> URI Class Initialized
INFO - 2019-11-02 09:16:23 --> Router Class Initialized
INFO - 2019-11-02 09:16:23 --> Output Class Initialized
INFO - 2019-11-02 09:16:23 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:23 --> Input Class Initialized
INFO - 2019-11-02 09:16:23 --> Language Class Initialized
INFO - 2019-11-02 09:16:23 --> Language Class Initialized
INFO - 2019-11-02 09:16:23 --> Config Class Initialized
INFO - 2019-11-02 09:16:23 --> Loader Class Initialized
INFO - 2019-11-02 09:16:23 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:23 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:23 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:23 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:23 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:23 --> Controller Class Initialized
INFO - 2019-11-02 09:16:25 --> Config Class Initialized
INFO - 2019-11-02 09:16:25 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:25 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:25 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:25 --> URI Class Initialized
INFO - 2019-11-02 09:16:25 --> Router Class Initialized
INFO - 2019-11-02 09:16:25 --> Output Class Initialized
INFO - 2019-11-02 09:16:25 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:25 --> Input Class Initialized
INFO - 2019-11-02 09:16:25 --> Language Class Initialized
INFO - 2019-11-02 09:16:25 --> Language Class Initialized
INFO - 2019-11-02 09:16:25 --> Config Class Initialized
INFO - 2019-11-02 09:16:25 --> Loader Class Initialized
INFO - 2019-11-02 09:16:25 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:25 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:25 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:25 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:25 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:25 --> Controller Class Initialized
ERROR - 2019-11-02 09:16:25 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2019-11-02 09:16:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2019-11-02 09:16:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:16:25 --> Final output sent to browser
DEBUG - 2019-11-02 09:16:25 --> Total execution time: 0.0462
INFO - 2019-11-02 09:16:54 --> Config Class Initialized
INFO - 2019-11-02 09:16:54 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:54 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:54 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:54 --> URI Class Initialized
INFO - 2019-11-02 09:16:54 --> Router Class Initialized
INFO - 2019-11-02 09:16:54 --> Output Class Initialized
INFO - 2019-11-02 09:16:54 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:54 --> Input Class Initialized
INFO - 2019-11-02 09:16:54 --> Language Class Initialized
INFO - 2019-11-02 09:16:54 --> Language Class Initialized
INFO - 2019-11-02 09:16:54 --> Config Class Initialized
INFO - 2019-11-02 09:16:54 --> Loader Class Initialized
INFO - 2019-11-02 09:16:54 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:54 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:54 --> Controller Class Initialized
INFO - 2019-11-02 09:16:54 --> Upload Class Initialized
INFO - 2019-11-02 09:16:54 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-11-02 09:16:54 --> The upload path does not appear to be valid.
INFO - 2019-11-02 09:16:54 --> Config Class Initialized
INFO - 2019-11-02 09:16:54 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:54 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:54 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:54 --> URI Class Initialized
INFO - 2019-11-02 09:16:54 --> Router Class Initialized
INFO - 2019-11-02 09:16:54 --> Output Class Initialized
INFO - 2019-11-02 09:16:54 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:54 --> Input Class Initialized
INFO - 2019-11-02 09:16:54 --> Language Class Initialized
INFO - 2019-11-02 09:16:54 --> Language Class Initialized
INFO - 2019-11-02 09:16:54 --> Config Class Initialized
INFO - 2019-11-02 09:16:54 --> Loader Class Initialized
INFO - 2019-11-02 09:16:54 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:54 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:54 --> Controller Class Initialized
DEBUG - 2019-11-02 09:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-11-02 09:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:16:54 --> Final output sent to browser
DEBUG - 2019-11-02 09:16:54 --> Total execution time: 0.0566
INFO - 2019-11-02 09:16:54 --> Config Class Initialized
INFO - 2019-11-02 09:16:54 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:54 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:54 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:54 --> URI Class Initialized
INFO - 2019-11-02 09:16:54 --> Router Class Initialized
INFO - 2019-11-02 09:16:54 --> Output Class Initialized
INFO - 2019-11-02 09:16:54 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:54 --> Input Class Initialized
INFO - 2019-11-02 09:16:54 --> Language Class Initialized
INFO - 2019-11-02 09:16:54 --> Language Class Initialized
INFO - 2019-11-02 09:16:54 --> Config Class Initialized
INFO - 2019-11-02 09:16:54 --> Loader Class Initialized
INFO - 2019-11-02 09:16:54 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:54 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:54 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:54 --> Controller Class Initialized
INFO - 2019-11-02 09:16:57 --> Config Class Initialized
INFO - 2019-11-02 09:16:57 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:16:57 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:16:57 --> Utf8 Class Initialized
INFO - 2019-11-02 09:16:57 --> URI Class Initialized
INFO - 2019-11-02 09:16:57 --> Router Class Initialized
INFO - 2019-11-02 09:16:57 --> Output Class Initialized
INFO - 2019-11-02 09:16:57 --> Security Class Initialized
DEBUG - 2019-11-02 09:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:16:57 --> Input Class Initialized
INFO - 2019-11-02 09:16:57 --> Language Class Initialized
INFO - 2019-11-02 09:16:57 --> Language Class Initialized
INFO - 2019-11-02 09:16:57 --> Config Class Initialized
INFO - 2019-11-02 09:16:57 --> Loader Class Initialized
INFO - 2019-11-02 09:16:57 --> Helper loaded: url_helper
INFO - 2019-11-02 09:16:57 --> Helper loaded: file_helper
INFO - 2019-11-02 09:16:57 --> Helper loaded: form_helper
INFO - 2019-11-02 09:16:57 --> Helper loaded: my_helper
INFO - 2019-11-02 09:16:57 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:16:57 --> Controller Class Initialized
DEBUG - 2019-11-02 09:16:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:16:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:16:57 --> Final output sent to browser
DEBUG - 2019-11-02 09:16:57 --> Total execution time: 0.0729
INFO - 2019-11-02 09:17:28 --> Config Class Initialized
INFO - 2019-11-02 09:17:28 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:28 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:28 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:28 --> URI Class Initialized
INFO - 2019-11-02 09:17:28 --> Router Class Initialized
INFO - 2019-11-02 09:17:28 --> Output Class Initialized
INFO - 2019-11-02 09:17:28 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:28 --> Input Class Initialized
INFO - 2019-11-02 09:17:28 --> Language Class Initialized
INFO - 2019-11-02 09:17:28 --> Language Class Initialized
INFO - 2019-11-02 09:17:28 --> Config Class Initialized
INFO - 2019-11-02 09:17:28 --> Loader Class Initialized
INFO - 2019-11-02 09:17:28 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:28 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:28 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:28 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:28 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:28 --> Controller Class Initialized
INFO - 2019-11-02 09:17:29 --> Config Class Initialized
INFO - 2019-11-02 09:17:29 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:29 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:29 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:29 --> URI Class Initialized
INFO - 2019-11-02 09:17:29 --> Router Class Initialized
INFO - 2019-11-02 09:17:29 --> Output Class Initialized
INFO - 2019-11-02 09:17:29 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:29 --> Input Class Initialized
INFO - 2019-11-02 09:17:29 --> Language Class Initialized
INFO - 2019-11-02 09:17:29 --> Language Class Initialized
INFO - 2019-11-02 09:17:29 --> Config Class Initialized
INFO - 2019-11-02 09:17:29 --> Loader Class Initialized
INFO - 2019-11-02 09:17:29 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:29 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:29 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:29 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:29 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:29 --> Controller Class Initialized
ERROR - 2019-11-02 09:17:29 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2019-11-02 09:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2019-11-02 09:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:17:29 --> Final output sent to browser
DEBUG - 2019-11-02 09:17:29 --> Total execution time: 0.0482
INFO - 2019-11-02 09:17:33 --> Config Class Initialized
INFO - 2019-11-02 09:17:33 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:33 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:33 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:33 --> URI Class Initialized
INFO - 2019-11-02 09:17:33 --> Router Class Initialized
INFO - 2019-11-02 09:17:33 --> Output Class Initialized
INFO - 2019-11-02 09:17:33 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:33 --> Input Class Initialized
INFO - 2019-11-02 09:17:33 --> Language Class Initialized
INFO - 2019-11-02 09:17:33 --> Language Class Initialized
INFO - 2019-11-02 09:17:33 --> Config Class Initialized
INFO - 2019-11-02 09:17:33 --> Loader Class Initialized
INFO - 2019-11-02 09:17:33 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:33 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:33 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:33 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:33 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:33 --> Controller Class Initialized
INFO - 2019-11-02 09:17:33 --> Upload Class Initialized
INFO - 2019-11-02 09:17:33 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-11-02 09:17:33 --> The upload path does not appear to be valid.
INFO - 2019-11-02 09:17:33 --> Config Class Initialized
INFO - 2019-11-02 09:17:33 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:33 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:33 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:33 --> URI Class Initialized
INFO - 2019-11-02 09:17:33 --> Router Class Initialized
INFO - 2019-11-02 09:17:33 --> Output Class Initialized
INFO - 2019-11-02 09:17:33 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:33 --> Input Class Initialized
INFO - 2019-11-02 09:17:33 --> Language Class Initialized
INFO - 2019-11-02 09:17:33 --> Language Class Initialized
INFO - 2019-11-02 09:17:33 --> Config Class Initialized
INFO - 2019-11-02 09:17:33 --> Loader Class Initialized
INFO - 2019-11-02 09:17:33 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:33 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:33 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:33 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:33 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:33 --> Controller Class Initialized
DEBUG - 2019-11-02 09:17:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-11-02 09:17:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:17:33 --> Final output sent to browser
DEBUG - 2019-11-02 09:17:33 --> Total execution time: 0.0402
INFO - 2019-11-02 09:17:34 --> Config Class Initialized
INFO - 2019-11-02 09:17:34 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:34 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:34 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:34 --> URI Class Initialized
INFO - 2019-11-02 09:17:34 --> Router Class Initialized
INFO - 2019-11-02 09:17:34 --> Output Class Initialized
INFO - 2019-11-02 09:17:34 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:34 --> Input Class Initialized
INFO - 2019-11-02 09:17:34 --> Language Class Initialized
INFO - 2019-11-02 09:17:34 --> Language Class Initialized
INFO - 2019-11-02 09:17:34 --> Config Class Initialized
INFO - 2019-11-02 09:17:34 --> Loader Class Initialized
INFO - 2019-11-02 09:17:34 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:34 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:34 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:34 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:34 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:34 --> Controller Class Initialized
INFO - 2019-11-02 09:17:35 --> Config Class Initialized
INFO - 2019-11-02 09:17:35 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:35 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:35 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:35 --> URI Class Initialized
INFO - 2019-11-02 09:17:35 --> Router Class Initialized
INFO - 2019-11-02 09:17:35 --> Output Class Initialized
INFO - 2019-11-02 09:17:35 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:35 --> Input Class Initialized
INFO - 2019-11-02 09:17:35 --> Language Class Initialized
INFO - 2019-11-02 09:17:35 --> Language Class Initialized
INFO - 2019-11-02 09:17:35 --> Config Class Initialized
INFO - 2019-11-02 09:17:35 --> Loader Class Initialized
INFO - 2019-11-02 09:17:35 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:35 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:35 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:35 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:35 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:35 --> Controller Class Initialized
DEBUG - 2019-11-02 09:17:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:17:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:17:35 --> Final output sent to browser
DEBUG - 2019-11-02 09:17:35 --> Total execution time: 0.0711
INFO - 2019-11-02 09:17:50 --> Config Class Initialized
INFO - 2019-11-02 09:17:50 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:50 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:50 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:50 --> URI Class Initialized
INFO - 2019-11-02 09:17:50 --> Router Class Initialized
INFO - 2019-11-02 09:17:50 --> Output Class Initialized
INFO - 2019-11-02 09:17:50 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:50 --> Input Class Initialized
INFO - 2019-11-02 09:17:50 --> Language Class Initialized
INFO - 2019-11-02 09:17:50 --> Language Class Initialized
INFO - 2019-11-02 09:17:50 --> Config Class Initialized
INFO - 2019-11-02 09:17:50 --> Loader Class Initialized
INFO - 2019-11-02 09:17:50 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:50 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:50 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:50 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:50 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:50 --> Controller Class Initialized
INFO - 2019-11-02 09:17:51 --> Config Class Initialized
INFO - 2019-11-02 09:17:51 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:51 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:51 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:51 --> URI Class Initialized
INFO - 2019-11-02 09:17:51 --> Router Class Initialized
INFO - 2019-11-02 09:17:51 --> Output Class Initialized
INFO - 2019-11-02 09:17:51 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:51 --> Input Class Initialized
INFO - 2019-11-02 09:17:51 --> Language Class Initialized
INFO - 2019-11-02 09:17:51 --> Language Class Initialized
INFO - 2019-11-02 09:17:51 --> Config Class Initialized
INFO - 2019-11-02 09:17:51 --> Loader Class Initialized
INFO - 2019-11-02 09:17:51 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:51 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:51 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:51 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:51 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:51 --> Controller Class Initialized
INFO - 2019-11-02 09:17:53 --> Config Class Initialized
INFO - 2019-11-02 09:17:53 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:17:53 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:17:53 --> Utf8 Class Initialized
INFO - 2019-11-02 09:17:53 --> URI Class Initialized
INFO - 2019-11-02 09:17:53 --> Router Class Initialized
INFO - 2019-11-02 09:17:53 --> Output Class Initialized
INFO - 2019-11-02 09:17:53 --> Security Class Initialized
DEBUG - 2019-11-02 09:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:17:53 --> Input Class Initialized
INFO - 2019-11-02 09:17:53 --> Language Class Initialized
INFO - 2019-11-02 09:17:53 --> Language Class Initialized
INFO - 2019-11-02 09:17:53 --> Config Class Initialized
INFO - 2019-11-02 09:17:53 --> Loader Class Initialized
INFO - 2019-11-02 09:17:53 --> Helper loaded: url_helper
INFO - 2019-11-02 09:17:53 --> Helper loaded: file_helper
INFO - 2019-11-02 09:17:53 --> Helper loaded: form_helper
INFO - 2019-11-02 09:17:53 --> Helper loaded: my_helper
INFO - 2019-11-02 09:17:53 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:17:53 --> Controller Class Initialized
ERROR - 2019-11-02 09:17:53 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2019-11-02 09:17:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2019-11-02 09:17:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:17:53 --> Final output sent to browser
DEBUG - 2019-11-02 09:17:53 --> Total execution time: 0.0699
INFO - 2019-11-02 09:18:03 --> Config Class Initialized
INFO - 2019-11-02 09:18:03 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:18:03 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:18:03 --> Utf8 Class Initialized
INFO - 2019-11-02 09:18:03 --> URI Class Initialized
INFO - 2019-11-02 09:18:03 --> Router Class Initialized
INFO - 2019-11-02 09:18:03 --> Output Class Initialized
INFO - 2019-11-02 09:18:03 --> Security Class Initialized
DEBUG - 2019-11-02 09:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:18:03 --> Input Class Initialized
INFO - 2019-11-02 09:18:03 --> Language Class Initialized
INFO - 2019-11-02 09:18:03 --> Language Class Initialized
INFO - 2019-11-02 09:18:03 --> Config Class Initialized
INFO - 2019-11-02 09:18:03 --> Loader Class Initialized
INFO - 2019-11-02 09:18:03 --> Helper loaded: url_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: file_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: form_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: my_helper
INFO - 2019-11-02 09:18:03 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:18:03 --> Controller Class Initialized
INFO - 2019-11-02 09:18:03 --> Upload Class Initialized
INFO - 2019-11-02 09:18:03 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-11-02 09:18:03 --> The upload path does not appear to be valid.
INFO - 2019-11-02 09:18:03 --> Config Class Initialized
INFO - 2019-11-02 09:18:03 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:18:03 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:18:03 --> Utf8 Class Initialized
INFO - 2019-11-02 09:18:03 --> URI Class Initialized
INFO - 2019-11-02 09:18:03 --> Router Class Initialized
INFO - 2019-11-02 09:18:03 --> Output Class Initialized
INFO - 2019-11-02 09:18:03 --> Security Class Initialized
DEBUG - 2019-11-02 09:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:18:03 --> Input Class Initialized
INFO - 2019-11-02 09:18:03 --> Language Class Initialized
INFO - 2019-11-02 09:18:03 --> Language Class Initialized
INFO - 2019-11-02 09:18:03 --> Config Class Initialized
INFO - 2019-11-02 09:18:03 --> Loader Class Initialized
INFO - 2019-11-02 09:18:03 --> Helper loaded: url_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: file_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: form_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: my_helper
INFO - 2019-11-02 09:18:03 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:18:03 --> Controller Class Initialized
DEBUG - 2019-11-02 09:18:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-11-02 09:18:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:18:03 --> Final output sent to browser
DEBUG - 2019-11-02 09:18:03 --> Total execution time: 0.0647
INFO - 2019-11-02 09:18:03 --> Config Class Initialized
INFO - 2019-11-02 09:18:03 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:18:03 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:18:03 --> Utf8 Class Initialized
INFO - 2019-11-02 09:18:03 --> URI Class Initialized
INFO - 2019-11-02 09:18:03 --> Router Class Initialized
INFO - 2019-11-02 09:18:03 --> Output Class Initialized
INFO - 2019-11-02 09:18:03 --> Security Class Initialized
DEBUG - 2019-11-02 09:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:18:03 --> Input Class Initialized
INFO - 2019-11-02 09:18:03 --> Language Class Initialized
INFO - 2019-11-02 09:18:03 --> Language Class Initialized
INFO - 2019-11-02 09:18:03 --> Config Class Initialized
INFO - 2019-11-02 09:18:03 --> Loader Class Initialized
INFO - 2019-11-02 09:18:03 --> Helper loaded: url_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: file_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: form_helper
INFO - 2019-11-02 09:18:03 --> Helper loaded: my_helper
INFO - 2019-11-02 09:18:03 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:18:03 --> Controller Class Initialized
INFO - 2019-11-02 09:18:05 --> Config Class Initialized
INFO - 2019-11-02 09:18:05 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:18:05 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:18:05 --> Utf8 Class Initialized
INFO - 2019-11-02 09:18:05 --> URI Class Initialized
INFO - 2019-11-02 09:18:05 --> Router Class Initialized
INFO - 2019-11-02 09:18:05 --> Output Class Initialized
INFO - 2019-11-02 09:18:05 --> Security Class Initialized
DEBUG - 2019-11-02 09:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:18:05 --> Input Class Initialized
INFO - 2019-11-02 09:18:05 --> Language Class Initialized
INFO - 2019-11-02 09:18:05 --> Language Class Initialized
INFO - 2019-11-02 09:18:05 --> Config Class Initialized
INFO - 2019-11-02 09:18:05 --> Loader Class Initialized
INFO - 2019-11-02 09:18:05 --> Helper loaded: url_helper
INFO - 2019-11-02 09:18:05 --> Helper loaded: file_helper
INFO - 2019-11-02 09:18:05 --> Helper loaded: form_helper
INFO - 2019-11-02 09:18:05 --> Helper loaded: my_helper
INFO - 2019-11-02 09:18:05 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:18:05 --> Controller Class Initialized
DEBUG - 2019-11-02 09:18:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:18:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:18:05 --> Final output sent to browser
DEBUG - 2019-11-02 09:18:05 --> Total execution time: 0.0697
INFO - 2019-11-02 09:26:41 --> Config Class Initialized
INFO - 2019-11-02 09:26:41 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:41 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:41 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:41 --> URI Class Initialized
INFO - 2019-11-02 09:26:41 --> Router Class Initialized
INFO - 2019-11-02 09:26:41 --> Output Class Initialized
INFO - 2019-11-02 09:26:41 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:41 --> Input Class Initialized
INFO - 2019-11-02 09:26:41 --> Language Class Initialized
INFO - 2019-11-02 09:26:41 --> Language Class Initialized
INFO - 2019-11-02 09:26:41 --> Config Class Initialized
INFO - 2019-11-02 09:26:41 --> Loader Class Initialized
INFO - 2019-11-02 09:26:41 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:41 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:41 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:41 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:41 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:41 --> Controller Class Initialized
INFO - 2019-11-02 09:26:42 --> Config Class Initialized
INFO - 2019-11-02 09:26:42 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:42 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:42 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:42 --> URI Class Initialized
INFO - 2019-11-02 09:26:42 --> Router Class Initialized
INFO - 2019-11-02 09:26:42 --> Output Class Initialized
INFO - 2019-11-02 09:26:42 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:42 --> Input Class Initialized
INFO - 2019-11-02 09:26:42 --> Language Class Initialized
INFO - 2019-11-02 09:26:42 --> Language Class Initialized
INFO - 2019-11-02 09:26:42 --> Config Class Initialized
INFO - 2019-11-02 09:26:42 --> Loader Class Initialized
INFO - 2019-11-02 09:26:42 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:42 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:42 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:42 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:42 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:42 --> Controller Class Initialized
ERROR - 2019-11-02 09:26:42 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2019-11-02 09:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2019-11-02 09:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:26:42 --> Final output sent to browser
DEBUG - 2019-11-02 09:26:42 --> Total execution time: 0.0575
INFO - 2019-11-02 09:26:51 --> Config Class Initialized
INFO - 2019-11-02 09:26:51 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:51 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:51 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:51 --> URI Class Initialized
INFO - 2019-11-02 09:26:51 --> Router Class Initialized
INFO - 2019-11-02 09:26:51 --> Output Class Initialized
INFO - 2019-11-02 09:26:51 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:51 --> Input Class Initialized
INFO - 2019-11-02 09:26:51 --> Language Class Initialized
INFO - 2019-11-02 09:26:51 --> Language Class Initialized
INFO - 2019-11-02 09:26:51 --> Config Class Initialized
INFO - 2019-11-02 09:26:51 --> Loader Class Initialized
INFO - 2019-11-02 09:26:51 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:51 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:51 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:51 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:51 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:51 --> Controller Class Initialized
DEBUG - 2019-11-02 09:26:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-11-02 09:26:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:26:51 --> Final output sent to browser
DEBUG - 2019-11-02 09:26:51 --> Total execution time: 0.0529
INFO - 2019-11-02 09:26:51 --> Config Class Initialized
INFO - 2019-11-02 09:26:51 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:51 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:51 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:51 --> URI Class Initialized
INFO - 2019-11-02 09:26:51 --> Router Class Initialized
INFO - 2019-11-02 09:26:51 --> Output Class Initialized
INFO - 2019-11-02 09:26:51 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:51 --> Input Class Initialized
INFO - 2019-11-02 09:26:51 --> Language Class Initialized
INFO - 2019-11-02 09:26:51 --> Language Class Initialized
INFO - 2019-11-02 09:26:51 --> Config Class Initialized
INFO - 2019-11-02 09:26:51 --> Loader Class Initialized
INFO - 2019-11-02 09:26:51 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:51 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:51 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:51 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:51 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:51 --> Controller Class Initialized
INFO - 2019-11-02 09:26:53 --> Config Class Initialized
INFO - 2019-11-02 09:26:53 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:53 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:53 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:53 --> URI Class Initialized
INFO - 2019-11-02 09:26:53 --> Router Class Initialized
INFO - 2019-11-02 09:26:53 --> Output Class Initialized
INFO - 2019-11-02 09:26:53 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:53 --> Input Class Initialized
INFO - 2019-11-02 09:26:53 --> Language Class Initialized
INFO - 2019-11-02 09:26:53 --> Language Class Initialized
INFO - 2019-11-02 09:26:53 --> Config Class Initialized
INFO - 2019-11-02 09:26:53 --> Loader Class Initialized
INFO - 2019-11-02 09:26:53 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:53 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:53 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:53 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:53 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:53 --> Controller Class Initialized
INFO - 2019-11-02 09:26:56 --> Config Class Initialized
INFO - 2019-11-02 09:26:56 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:56 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:56 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:56 --> URI Class Initialized
INFO - 2019-11-02 09:26:56 --> Router Class Initialized
INFO - 2019-11-02 09:26:56 --> Output Class Initialized
INFO - 2019-11-02 09:26:56 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:56 --> Input Class Initialized
INFO - 2019-11-02 09:26:56 --> Language Class Initialized
INFO - 2019-11-02 09:26:56 --> Language Class Initialized
INFO - 2019-11-02 09:26:56 --> Config Class Initialized
INFO - 2019-11-02 09:26:56 --> Loader Class Initialized
INFO - 2019-11-02 09:26:56 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:56 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:56 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:56 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:56 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:56 --> Controller Class Initialized
INFO - 2019-11-02 09:26:56 --> Config Class Initialized
INFO - 2019-11-02 09:26:56 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:56 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:56 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:56 --> URI Class Initialized
INFO - 2019-11-02 09:26:56 --> Router Class Initialized
INFO - 2019-11-02 09:26:56 --> Output Class Initialized
INFO - 2019-11-02 09:26:56 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:56 --> Input Class Initialized
INFO - 2019-11-02 09:26:56 --> Language Class Initialized
INFO - 2019-11-02 09:26:56 --> Language Class Initialized
INFO - 2019-11-02 09:26:56 --> Config Class Initialized
INFO - 2019-11-02 09:26:56 --> Loader Class Initialized
INFO - 2019-11-02 09:26:56 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:56 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:56 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:56 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:56 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:56 --> Controller Class Initialized
INFO - 2019-11-02 09:26:58 --> Config Class Initialized
INFO - 2019-11-02 09:26:58 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:58 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:58 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:58 --> URI Class Initialized
INFO - 2019-11-02 09:26:58 --> Router Class Initialized
INFO - 2019-11-02 09:26:58 --> Output Class Initialized
INFO - 2019-11-02 09:26:58 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:58 --> Input Class Initialized
INFO - 2019-11-02 09:26:58 --> Language Class Initialized
INFO - 2019-11-02 09:26:58 --> Language Class Initialized
INFO - 2019-11-02 09:26:58 --> Config Class Initialized
INFO - 2019-11-02 09:26:58 --> Loader Class Initialized
INFO - 2019-11-02 09:26:58 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:58 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:58 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:58 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:58 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:58 --> Controller Class Initialized
INFO - 2019-11-02 09:26:58 --> Config Class Initialized
INFO - 2019-11-02 09:26:58 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:26:58 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:26:58 --> Utf8 Class Initialized
INFO - 2019-11-02 09:26:58 --> URI Class Initialized
INFO - 2019-11-02 09:26:58 --> Router Class Initialized
INFO - 2019-11-02 09:26:58 --> Output Class Initialized
INFO - 2019-11-02 09:26:58 --> Security Class Initialized
DEBUG - 2019-11-02 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:26:58 --> Input Class Initialized
INFO - 2019-11-02 09:26:58 --> Language Class Initialized
INFO - 2019-11-02 09:26:58 --> Language Class Initialized
INFO - 2019-11-02 09:26:58 --> Config Class Initialized
INFO - 2019-11-02 09:26:58 --> Loader Class Initialized
INFO - 2019-11-02 09:26:58 --> Helper loaded: url_helper
INFO - 2019-11-02 09:26:58 --> Helper loaded: file_helper
INFO - 2019-11-02 09:26:58 --> Helper loaded: form_helper
INFO - 2019-11-02 09:26:58 --> Helper loaded: my_helper
INFO - 2019-11-02 09:26:58 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:26:58 --> Controller Class Initialized
INFO - 2019-11-02 09:27:01 --> Config Class Initialized
INFO - 2019-11-02 09:27:01 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:27:01 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:27:01 --> Utf8 Class Initialized
INFO - 2019-11-02 09:27:01 --> URI Class Initialized
INFO - 2019-11-02 09:27:01 --> Router Class Initialized
INFO - 2019-11-02 09:27:01 --> Output Class Initialized
INFO - 2019-11-02 09:27:01 --> Security Class Initialized
DEBUG - 2019-11-02 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:27:01 --> Input Class Initialized
INFO - 2019-11-02 09:27:01 --> Language Class Initialized
INFO - 2019-11-02 09:27:01 --> Language Class Initialized
INFO - 2019-11-02 09:27:01 --> Config Class Initialized
INFO - 2019-11-02 09:27:01 --> Loader Class Initialized
INFO - 2019-11-02 09:27:01 --> Helper loaded: url_helper
INFO - 2019-11-02 09:27:01 --> Helper loaded: file_helper
INFO - 2019-11-02 09:27:01 --> Helper loaded: form_helper
INFO - 2019-11-02 09:27:01 --> Helper loaded: my_helper
INFO - 2019-11-02 09:27:01 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:27:01 --> Controller Class Initialized
INFO - 2019-11-02 09:27:02 --> Config Class Initialized
INFO - 2019-11-02 09:27:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:27:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:27:02 --> Utf8 Class Initialized
INFO - 2019-11-02 09:27:02 --> URI Class Initialized
INFO - 2019-11-02 09:27:02 --> Router Class Initialized
INFO - 2019-11-02 09:27:02 --> Output Class Initialized
INFO - 2019-11-02 09:27:02 --> Security Class Initialized
DEBUG - 2019-11-02 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:27:02 --> Input Class Initialized
INFO - 2019-11-02 09:27:02 --> Language Class Initialized
INFO - 2019-11-02 09:27:02 --> Language Class Initialized
INFO - 2019-11-02 09:27:02 --> Config Class Initialized
INFO - 2019-11-02 09:27:02 --> Loader Class Initialized
INFO - 2019-11-02 09:27:02 --> Helper loaded: url_helper
INFO - 2019-11-02 09:27:02 --> Helper loaded: file_helper
INFO - 2019-11-02 09:27:02 --> Helper loaded: form_helper
INFO - 2019-11-02 09:27:02 --> Helper loaded: my_helper
INFO - 2019-11-02 09:27:02 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:27:02 --> Controller Class Initialized
ERROR - 2019-11-02 09:27:03 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2019-11-02 09:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2019-11-02 09:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:27:03 --> Final output sent to browser
DEBUG - 2019-11-02 09:27:03 --> Total execution time: 0.0702
INFO - 2019-11-02 09:27:30 --> Config Class Initialized
INFO - 2019-11-02 09:27:30 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:27:30 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:27:30 --> Utf8 Class Initialized
INFO - 2019-11-02 09:27:30 --> URI Class Initialized
INFO - 2019-11-02 09:27:30 --> Router Class Initialized
INFO - 2019-11-02 09:27:30 --> Output Class Initialized
INFO - 2019-11-02 09:27:30 --> Security Class Initialized
DEBUG - 2019-11-02 09:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:27:30 --> Input Class Initialized
INFO - 2019-11-02 09:27:30 --> Language Class Initialized
INFO - 2019-11-02 09:27:30 --> Language Class Initialized
INFO - 2019-11-02 09:27:30 --> Config Class Initialized
INFO - 2019-11-02 09:27:30 --> Loader Class Initialized
INFO - 2019-11-02 09:27:30 --> Helper loaded: url_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: file_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: form_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: my_helper
INFO - 2019-11-02 09:27:30 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:27:30 --> Controller Class Initialized
INFO - 2019-11-02 09:27:30 --> Upload Class Initialized
INFO - 2019-11-02 09:27:30 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-11-02 09:27:30 --> The upload path does not appear to be valid.
INFO - 2019-11-02 09:27:30 --> Config Class Initialized
INFO - 2019-11-02 09:27:30 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:27:30 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:27:30 --> Utf8 Class Initialized
INFO - 2019-11-02 09:27:30 --> URI Class Initialized
INFO - 2019-11-02 09:27:30 --> Router Class Initialized
INFO - 2019-11-02 09:27:30 --> Output Class Initialized
INFO - 2019-11-02 09:27:30 --> Security Class Initialized
DEBUG - 2019-11-02 09:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:27:30 --> Input Class Initialized
INFO - 2019-11-02 09:27:30 --> Language Class Initialized
INFO - 2019-11-02 09:27:30 --> Language Class Initialized
INFO - 2019-11-02 09:27:30 --> Config Class Initialized
INFO - 2019-11-02 09:27:30 --> Loader Class Initialized
INFO - 2019-11-02 09:27:30 --> Helper loaded: url_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: file_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: form_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: my_helper
INFO - 2019-11-02 09:27:30 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:27:30 --> Controller Class Initialized
DEBUG - 2019-11-02 09:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-11-02 09:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:27:30 --> Final output sent to browser
DEBUG - 2019-11-02 09:27:30 --> Total execution time: 0.0419
INFO - 2019-11-02 09:27:30 --> Config Class Initialized
INFO - 2019-11-02 09:27:30 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:27:30 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:27:30 --> Utf8 Class Initialized
INFO - 2019-11-02 09:27:30 --> URI Class Initialized
INFO - 2019-11-02 09:27:30 --> Router Class Initialized
INFO - 2019-11-02 09:27:30 --> Output Class Initialized
INFO - 2019-11-02 09:27:30 --> Security Class Initialized
DEBUG - 2019-11-02 09:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:27:30 --> Input Class Initialized
INFO - 2019-11-02 09:27:30 --> Language Class Initialized
INFO - 2019-11-02 09:27:30 --> Language Class Initialized
INFO - 2019-11-02 09:27:30 --> Config Class Initialized
INFO - 2019-11-02 09:27:30 --> Loader Class Initialized
INFO - 2019-11-02 09:27:30 --> Helper loaded: url_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: file_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: form_helper
INFO - 2019-11-02 09:27:30 --> Helper loaded: my_helper
INFO - 2019-11-02 09:27:30 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:27:30 --> Controller Class Initialized
INFO - 2019-11-02 09:27:32 --> Config Class Initialized
INFO - 2019-11-02 09:27:32 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:27:32 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:27:32 --> Utf8 Class Initialized
INFO - 2019-11-02 09:27:32 --> URI Class Initialized
INFO - 2019-11-02 09:27:32 --> Router Class Initialized
INFO - 2019-11-02 09:27:32 --> Output Class Initialized
INFO - 2019-11-02 09:27:32 --> Security Class Initialized
DEBUG - 2019-11-02 09:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:27:32 --> Input Class Initialized
INFO - 2019-11-02 09:27:32 --> Language Class Initialized
INFO - 2019-11-02 09:27:32 --> Language Class Initialized
INFO - 2019-11-02 09:27:32 --> Config Class Initialized
INFO - 2019-11-02 09:27:32 --> Loader Class Initialized
INFO - 2019-11-02 09:27:32 --> Helper loaded: url_helper
INFO - 2019-11-02 09:27:32 --> Helper loaded: file_helper
INFO - 2019-11-02 09:27:32 --> Helper loaded: form_helper
INFO - 2019-11-02 09:27:32 --> Helper loaded: my_helper
INFO - 2019-11-02 09:27:32 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:27:32 --> Controller Class Initialized
DEBUG - 2019-11-02 09:27:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:27:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:27:32 --> Final output sent to browser
DEBUG - 2019-11-02 09:27:32 --> Total execution time: 0.0619
INFO - 2019-11-02 09:28:14 --> Config Class Initialized
INFO - 2019-11-02 09:28:14 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:28:14 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:28:14 --> Utf8 Class Initialized
INFO - 2019-11-02 09:28:14 --> URI Class Initialized
INFO - 2019-11-02 09:28:14 --> Router Class Initialized
INFO - 2019-11-02 09:28:14 --> Output Class Initialized
INFO - 2019-11-02 09:28:14 --> Security Class Initialized
DEBUG - 2019-11-02 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:28:14 --> Input Class Initialized
INFO - 2019-11-02 09:28:14 --> Language Class Initialized
INFO - 2019-11-02 09:28:14 --> Language Class Initialized
INFO - 2019-11-02 09:28:14 --> Config Class Initialized
INFO - 2019-11-02 09:28:14 --> Loader Class Initialized
INFO - 2019-11-02 09:28:14 --> Helper loaded: url_helper
INFO - 2019-11-02 09:28:14 --> Helper loaded: file_helper
INFO - 2019-11-02 09:28:14 --> Helper loaded: form_helper
INFO - 2019-11-02 09:28:14 --> Helper loaded: my_helper
INFO - 2019-11-02 09:28:14 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:28:14 --> Controller Class Initialized
INFO - 2019-11-02 09:28:14 --> Final output sent to browser
DEBUG - 2019-11-02 09:28:14 --> Total execution time: 0.0706
INFO - 2019-11-02 09:29:04 --> Config Class Initialized
INFO - 2019-11-02 09:29:04 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:29:04 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:29:04 --> Utf8 Class Initialized
INFO - 2019-11-02 09:29:04 --> URI Class Initialized
INFO - 2019-11-02 09:29:04 --> Router Class Initialized
INFO - 2019-11-02 09:29:04 --> Output Class Initialized
INFO - 2019-11-02 09:29:04 --> Security Class Initialized
DEBUG - 2019-11-02 09:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:29:04 --> Input Class Initialized
INFO - 2019-11-02 09:29:04 --> Language Class Initialized
INFO - 2019-11-02 09:29:04 --> Language Class Initialized
INFO - 2019-11-02 09:29:04 --> Config Class Initialized
INFO - 2019-11-02 09:29:04 --> Loader Class Initialized
INFO - 2019-11-02 09:29:04 --> Helper loaded: url_helper
INFO - 2019-11-02 09:29:04 --> Helper loaded: file_helper
INFO - 2019-11-02 09:29:04 --> Helper loaded: form_helper
INFO - 2019-11-02 09:29:04 --> Helper loaded: my_helper
INFO - 2019-11-02 09:29:04 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:29:04 --> Controller Class Initialized
INFO - 2019-11-02 09:29:04 --> Final output sent to browser
DEBUG - 2019-11-02 09:29:04 --> Total execution time: 0.0668
INFO - 2019-11-02 09:29:19 --> Config Class Initialized
INFO - 2019-11-02 09:29:19 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:29:19 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:29:19 --> Utf8 Class Initialized
INFO - 2019-11-02 09:29:19 --> URI Class Initialized
INFO - 2019-11-02 09:29:19 --> Router Class Initialized
INFO - 2019-11-02 09:29:19 --> Output Class Initialized
INFO - 2019-11-02 09:29:19 --> Security Class Initialized
DEBUG - 2019-11-02 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:29:19 --> Input Class Initialized
INFO - 2019-11-02 09:29:19 --> Language Class Initialized
INFO - 2019-11-02 09:29:19 --> Language Class Initialized
INFO - 2019-11-02 09:29:19 --> Config Class Initialized
INFO - 2019-11-02 09:29:19 --> Loader Class Initialized
INFO - 2019-11-02 09:29:19 --> Helper loaded: url_helper
INFO - 2019-11-02 09:29:19 --> Helper loaded: file_helper
INFO - 2019-11-02 09:29:19 --> Helper loaded: form_helper
INFO - 2019-11-02 09:29:19 --> Helper loaded: my_helper
INFO - 2019-11-02 09:29:19 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:29:19 --> Controller Class Initialized
INFO - 2019-11-02 09:29:19 --> Final output sent to browser
DEBUG - 2019-11-02 09:29:19 --> Total execution time: 0.0652
INFO - 2019-11-02 09:29:19 --> Config Class Initialized
INFO - 2019-11-02 09:29:19 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:29:19 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:29:19 --> Utf8 Class Initialized
INFO - 2019-11-02 09:29:19 --> URI Class Initialized
INFO - 2019-11-02 09:29:19 --> Router Class Initialized
INFO - 2019-11-02 09:29:19 --> Output Class Initialized
INFO - 2019-11-02 09:29:19 --> Security Class Initialized
DEBUG - 2019-11-02 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:29:19 --> Input Class Initialized
INFO - 2019-11-02 09:29:19 --> Language Class Initialized
INFO - 2019-11-02 09:29:19 --> Language Class Initialized
INFO - 2019-11-02 09:29:19 --> Config Class Initialized
INFO - 2019-11-02 09:29:19 --> Loader Class Initialized
INFO - 2019-11-02 09:29:19 --> Helper loaded: url_helper
INFO - 2019-11-02 09:29:19 --> Helper loaded: file_helper
INFO - 2019-11-02 09:29:19 --> Helper loaded: form_helper
INFO - 2019-11-02 09:29:19 --> Helper loaded: my_helper
INFO - 2019-11-02 09:29:19 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:29:20 --> Controller Class Initialized
DEBUG - 2019-11-02 09:29:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:29:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:29:20 --> Final output sent to browser
DEBUG - 2019-11-02 09:29:20 --> Total execution time: 0.0678
INFO - 2019-11-02 09:30:21 --> Config Class Initialized
INFO - 2019-11-02 09:30:21 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:30:21 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:30:21 --> Utf8 Class Initialized
INFO - 2019-11-02 09:30:21 --> URI Class Initialized
INFO - 2019-11-02 09:30:21 --> Router Class Initialized
INFO - 2019-11-02 09:30:21 --> Output Class Initialized
INFO - 2019-11-02 09:30:21 --> Security Class Initialized
DEBUG - 2019-11-02 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:30:21 --> Input Class Initialized
INFO - 2019-11-02 09:30:21 --> Language Class Initialized
INFO - 2019-11-02 09:30:21 --> Language Class Initialized
INFO - 2019-11-02 09:30:21 --> Config Class Initialized
INFO - 2019-11-02 09:30:21 --> Loader Class Initialized
INFO - 2019-11-02 09:30:21 --> Helper loaded: url_helper
INFO - 2019-11-02 09:30:21 --> Helper loaded: file_helper
INFO - 2019-11-02 09:30:21 --> Helper loaded: form_helper
INFO - 2019-11-02 09:30:21 --> Helper loaded: my_helper
INFO - 2019-11-02 09:30:21 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:30:21 --> Controller Class Initialized
INFO - 2019-11-02 09:30:21 --> Final output sent to browser
DEBUG - 2019-11-02 09:30:21 --> Total execution time: 0.0629
INFO - 2019-11-02 09:31:00 --> Config Class Initialized
INFO - 2019-11-02 09:31:00 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:31:00 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:31:00 --> Utf8 Class Initialized
INFO - 2019-11-02 09:31:00 --> URI Class Initialized
INFO - 2019-11-02 09:31:00 --> Router Class Initialized
INFO - 2019-11-02 09:31:00 --> Output Class Initialized
INFO - 2019-11-02 09:31:00 --> Security Class Initialized
DEBUG - 2019-11-02 09:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:31:00 --> Input Class Initialized
INFO - 2019-11-02 09:31:00 --> Language Class Initialized
INFO - 2019-11-02 09:31:00 --> Language Class Initialized
INFO - 2019-11-02 09:31:00 --> Config Class Initialized
INFO - 2019-11-02 09:31:00 --> Loader Class Initialized
INFO - 2019-11-02 09:31:00 --> Helper loaded: url_helper
INFO - 2019-11-02 09:31:00 --> Helper loaded: file_helper
INFO - 2019-11-02 09:31:00 --> Helper loaded: form_helper
INFO - 2019-11-02 09:31:00 --> Helper loaded: my_helper
INFO - 2019-11-02 09:31:00 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:31:00 --> Controller Class Initialized
DEBUG - 2019-11-02 09:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:31:00 --> Final output sent to browser
DEBUG - 2019-11-02 09:31:00 --> Total execution time: 0.0742
INFO - 2019-11-02 09:33:55 --> Config Class Initialized
INFO - 2019-11-02 09:33:55 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:33:55 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:33:55 --> Utf8 Class Initialized
INFO - 2019-11-02 09:33:55 --> URI Class Initialized
INFO - 2019-11-02 09:33:55 --> Router Class Initialized
INFO - 2019-11-02 09:33:55 --> Output Class Initialized
INFO - 2019-11-02 09:33:55 --> Security Class Initialized
DEBUG - 2019-11-02 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:33:55 --> Input Class Initialized
INFO - 2019-11-02 09:33:55 --> Language Class Initialized
INFO - 2019-11-02 09:33:55 --> Language Class Initialized
INFO - 2019-11-02 09:33:55 --> Config Class Initialized
INFO - 2019-11-02 09:33:55 --> Loader Class Initialized
INFO - 2019-11-02 09:33:55 --> Helper loaded: url_helper
INFO - 2019-11-02 09:33:55 --> Helper loaded: file_helper
INFO - 2019-11-02 09:33:55 --> Helper loaded: form_helper
INFO - 2019-11-02 09:33:55 --> Helper loaded: my_helper
INFO - 2019-11-02 09:33:55 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:33:55 --> Controller Class Initialized
INFO - 2019-11-02 09:33:55 --> Final output sent to browser
DEBUG - 2019-11-02 09:33:55 --> Total execution time: 0.0641
INFO - 2019-11-02 09:34:35 --> Config Class Initialized
INFO - 2019-11-02 09:34:35 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:34:35 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:34:35 --> Utf8 Class Initialized
INFO - 2019-11-02 09:34:35 --> URI Class Initialized
INFO - 2019-11-02 09:34:35 --> Router Class Initialized
INFO - 2019-11-02 09:34:35 --> Output Class Initialized
INFO - 2019-11-02 09:34:35 --> Security Class Initialized
DEBUG - 2019-11-02 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:34:35 --> Input Class Initialized
INFO - 2019-11-02 09:34:35 --> Language Class Initialized
INFO - 2019-11-02 09:34:35 --> Language Class Initialized
INFO - 2019-11-02 09:34:35 --> Config Class Initialized
INFO - 2019-11-02 09:34:35 --> Loader Class Initialized
INFO - 2019-11-02 09:34:35 --> Helper loaded: url_helper
INFO - 2019-11-02 09:34:35 --> Helper loaded: file_helper
INFO - 2019-11-02 09:34:35 --> Helper loaded: form_helper
INFO - 2019-11-02 09:34:35 --> Helper loaded: my_helper
INFO - 2019-11-02 09:34:35 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:34:35 --> Controller Class Initialized
DEBUG - 2019-11-02 09:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:34:35 --> Final output sent to browser
DEBUG - 2019-11-02 09:34:35 --> Total execution time: 0.0652
INFO - 2019-11-02 09:36:06 --> Config Class Initialized
INFO - 2019-11-02 09:36:06 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:36:06 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:36:06 --> Utf8 Class Initialized
INFO - 2019-11-02 09:36:06 --> URI Class Initialized
INFO - 2019-11-02 09:36:06 --> Router Class Initialized
INFO - 2019-11-02 09:36:06 --> Output Class Initialized
INFO - 2019-11-02 09:36:06 --> Security Class Initialized
DEBUG - 2019-11-02 09:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:36:06 --> Input Class Initialized
INFO - 2019-11-02 09:36:06 --> Language Class Initialized
INFO - 2019-11-02 09:36:06 --> Language Class Initialized
INFO - 2019-11-02 09:36:06 --> Config Class Initialized
INFO - 2019-11-02 09:36:06 --> Loader Class Initialized
INFO - 2019-11-02 09:36:06 --> Helper loaded: url_helper
INFO - 2019-11-02 09:36:06 --> Helper loaded: file_helper
INFO - 2019-11-02 09:36:06 --> Helper loaded: form_helper
INFO - 2019-11-02 09:36:06 --> Helper loaded: my_helper
INFO - 2019-11-02 09:36:06 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:36:06 --> Controller Class Initialized
INFO - 2019-11-02 09:36:06 --> Final output sent to browser
DEBUG - 2019-11-02 09:36:06 --> Total execution time: 0.0653
INFO - 2019-11-02 09:36:18 --> Config Class Initialized
INFO - 2019-11-02 09:36:18 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:36:18 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:36:18 --> Utf8 Class Initialized
INFO - 2019-11-02 09:36:18 --> URI Class Initialized
INFO - 2019-11-02 09:36:18 --> Router Class Initialized
INFO - 2019-11-02 09:36:18 --> Output Class Initialized
INFO - 2019-11-02 09:36:18 --> Security Class Initialized
DEBUG - 2019-11-02 09:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:36:18 --> Input Class Initialized
INFO - 2019-11-02 09:36:18 --> Language Class Initialized
INFO - 2019-11-02 09:36:18 --> Language Class Initialized
INFO - 2019-11-02 09:36:18 --> Config Class Initialized
INFO - 2019-11-02 09:36:18 --> Loader Class Initialized
INFO - 2019-11-02 09:36:18 --> Helper loaded: url_helper
INFO - 2019-11-02 09:36:18 --> Helper loaded: file_helper
INFO - 2019-11-02 09:36:18 --> Helper loaded: form_helper
INFO - 2019-11-02 09:36:18 --> Helper loaded: my_helper
INFO - 2019-11-02 09:36:18 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:36:18 --> Controller Class Initialized
INFO - 2019-11-02 09:36:18 --> Final output sent to browser
DEBUG - 2019-11-02 09:36:18 --> Total execution time: 0.0689
INFO - 2019-11-02 09:36:31 --> Config Class Initialized
INFO - 2019-11-02 09:36:31 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:36:31 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:36:31 --> Utf8 Class Initialized
INFO - 2019-11-02 09:36:31 --> URI Class Initialized
INFO - 2019-11-02 09:36:31 --> Router Class Initialized
INFO - 2019-11-02 09:36:31 --> Output Class Initialized
INFO - 2019-11-02 09:36:31 --> Security Class Initialized
DEBUG - 2019-11-02 09:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:36:31 --> Input Class Initialized
INFO - 2019-11-02 09:36:31 --> Language Class Initialized
INFO - 2019-11-02 09:36:31 --> Language Class Initialized
INFO - 2019-11-02 09:36:31 --> Config Class Initialized
INFO - 2019-11-02 09:36:31 --> Loader Class Initialized
INFO - 2019-11-02 09:36:31 --> Helper loaded: url_helper
INFO - 2019-11-02 09:36:31 --> Helper loaded: file_helper
INFO - 2019-11-02 09:36:31 --> Helper loaded: form_helper
INFO - 2019-11-02 09:36:31 --> Helper loaded: my_helper
INFO - 2019-11-02 09:36:31 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:36:31 --> Controller Class Initialized
INFO - 2019-11-02 09:36:31 --> Final output sent to browser
DEBUG - 2019-11-02 09:36:31 --> Total execution time: 0.0689
INFO - 2019-11-02 09:36:38 --> Config Class Initialized
INFO - 2019-11-02 09:36:38 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:36:38 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:36:38 --> Utf8 Class Initialized
INFO - 2019-11-02 09:36:38 --> URI Class Initialized
INFO - 2019-11-02 09:36:38 --> Router Class Initialized
INFO - 2019-11-02 09:36:38 --> Output Class Initialized
INFO - 2019-11-02 09:36:38 --> Security Class Initialized
DEBUG - 2019-11-02 09:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:36:38 --> Input Class Initialized
INFO - 2019-11-02 09:36:38 --> Language Class Initialized
INFO - 2019-11-02 09:36:38 --> Language Class Initialized
INFO - 2019-11-02 09:36:38 --> Config Class Initialized
INFO - 2019-11-02 09:36:38 --> Loader Class Initialized
INFO - 2019-11-02 09:36:38 --> Helper loaded: url_helper
INFO - 2019-11-02 09:36:38 --> Helper loaded: file_helper
INFO - 2019-11-02 09:36:38 --> Helper loaded: form_helper
INFO - 2019-11-02 09:36:38 --> Helper loaded: my_helper
INFO - 2019-11-02 09:36:38 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:36:38 --> Controller Class Initialized
INFO - 2019-11-02 09:36:38 --> Final output sent to browser
DEBUG - 2019-11-02 09:36:38 --> Total execution time: 0.0639
INFO - 2019-11-02 09:36:40 --> Config Class Initialized
INFO - 2019-11-02 09:36:40 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:36:40 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:36:40 --> Utf8 Class Initialized
INFO - 2019-11-02 09:36:40 --> URI Class Initialized
INFO - 2019-11-02 09:36:40 --> Router Class Initialized
INFO - 2019-11-02 09:36:40 --> Output Class Initialized
INFO - 2019-11-02 09:36:40 --> Security Class Initialized
DEBUG - 2019-11-02 09:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:36:40 --> Input Class Initialized
INFO - 2019-11-02 09:36:40 --> Language Class Initialized
INFO - 2019-11-02 09:36:40 --> Language Class Initialized
INFO - 2019-11-02 09:36:40 --> Config Class Initialized
INFO - 2019-11-02 09:36:40 --> Loader Class Initialized
INFO - 2019-11-02 09:36:40 --> Helper loaded: url_helper
INFO - 2019-11-02 09:36:40 --> Helper loaded: file_helper
INFO - 2019-11-02 09:36:40 --> Helper loaded: form_helper
INFO - 2019-11-02 09:36:40 --> Helper loaded: my_helper
INFO - 2019-11-02 09:36:40 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:36:40 --> Controller Class Initialized
DEBUG - 2019-11-02 09:36:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:36:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:36:40 --> Final output sent to browser
DEBUG - 2019-11-02 09:36:40 --> Total execution time: 0.0525
INFO - 2019-11-02 09:36:59 --> Config Class Initialized
INFO - 2019-11-02 09:36:59 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:36:59 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:36:59 --> Utf8 Class Initialized
INFO - 2019-11-02 09:36:59 --> URI Class Initialized
INFO - 2019-11-02 09:36:59 --> Router Class Initialized
INFO - 2019-11-02 09:36:59 --> Output Class Initialized
INFO - 2019-11-02 09:36:59 --> Security Class Initialized
DEBUG - 2019-11-02 09:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:36:59 --> Input Class Initialized
INFO - 2019-11-02 09:36:59 --> Language Class Initialized
INFO - 2019-11-02 09:36:59 --> Language Class Initialized
INFO - 2019-11-02 09:36:59 --> Config Class Initialized
INFO - 2019-11-02 09:36:59 --> Loader Class Initialized
INFO - 2019-11-02 09:36:59 --> Helper loaded: url_helper
INFO - 2019-11-02 09:36:59 --> Helper loaded: file_helper
INFO - 2019-11-02 09:36:59 --> Helper loaded: form_helper
INFO - 2019-11-02 09:36:59 --> Helper loaded: my_helper
INFO - 2019-11-02 09:36:59 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:36:59 --> Controller Class Initialized
DEBUG - 2019-11-02 09:36:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2019-11-02 09:36:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:36:59 --> Final output sent to browser
DEBUG - 2019-11-02 09:36:59 --> Total execution time: 0.0544
INFO - 2019-11-02 09:36:59 --> Config Class Initialized
INFO - 2019-11-02 09:36:59 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:36:59 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:36:59 --> Utf8 Class Initialized
INFO - 2019-11-02 09:36:59 --> URI Class Initialized
INFO - 2019-11-02 09:37:00 --> Router Class Initialized
INFO - 2019-11-02 09:37:00 --> Output Class Initialized
INFO - 2019-11-02 09:37:00 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:00 --> Input Class Initialized
INFO - 2019-11-02 09:37:00 --> Language Class Initialized
INFO - 2019-11-02 09:37:00 --> Language Class Initialized
INFO - 2019-11-02 09:37:00 --> Config Class Initialized
INFO - 2019-11-02 09:37:00 --> Loader Class Initialized
INFO - 2019-11-02 09:37:00 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:00 --> Helper loaded: file_helper
INFO - 2019-11-02 09:37:00 --> Helper loaded: form_helper
INFO - 2019-11-02 09:37:00 --> Helper loaded: my_helper
INFO - 2019-11-02 09:37:00 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:37:00 --> Controller Class Initialized
INFO - 2019-11-02 09:37:04 --> Config Class Initialized
INFO - 2019-11-02 09:37:04 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:37:04 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:37:04 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:04 --> URI Class Initialized
INFO - 2019-11-02 09:37:04 --> Router Class Initialized
INFO - 2019-11-02 09:37:04 --> Output Class Initialized
INFO - 2019-11-02 09:37:04 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:04 --> Input Class Initialized
INFO - 2019-11-02 09:37:04 --> Language Class Initialized
INFO - 2019-11-02 09:37:04 --> Language Class Initialized
INFO - 2019-11-02 09:37:04 --> Config Class Initialized
INFO - 2019-11-02 09:37:04 --> Loader Class Initialized
INFO - 2019-11-02 09:37:04 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:04 --> Helper loaded: file_helper
INFO - 2019-11-02 09:37:04 --> Helper loaded: form_helper
INFO - 2019-11-02 09:37:04 --> Helper loaded: my_helper
INFO - 2019-11-02 09:37:04 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:37:04 --> Controller Class Initialized
INFO - 2019-11-02 09:37:04 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:04 --> Total execution time: 0.0564
INFO - 2019-11-02 09:37:04 --> Config Class Initialized
INFO - 2019-11-02 09:37:04 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:37:04 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:37:04 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:04 --> URI Class Initialized
INFO - 2019-11-02 09:37:04 --> Router Class Initialized
INFO - 2019-11-02 09:37:04 --> Output Class Initialized
INFO - 2019-11-02 09:37:04 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:04 --> Input Class Initialized
INFO - 2019-11-02 09:37:04 --> Language Class Initialized
INFO - 2019-11-02 09:37:04 --> Language Class Initialized
INFO - 2019-11-02 09:37:04 --> Config Class Initialized
INFO - 2019-11-02 09:37:04 --> Loader Class Initialized
INFO - 2019-11-02 09:37:04 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:04 --> Helper loaded: file_helper
INFO - 2019-11-02 09:37:04 --> Helper loaded: form_helper
INFO - 2019-11-02 09:37:04 --> Helper loaded: my_helper
INFO - 2019-11-02 09:37:04 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:37:04 --> Controller Class Initialized
INFO - 2019-11-02 09:37:06 --> Config Class Initialized
INFO - 2019-11-02 09:37:06 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:37:06 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:37:06 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:06 --> URI Class Initialized
INFO - 2019-11-02 09:37:06 --> Router Class Initialized
INFO - 2019-11-02 09:37:06 --> Output Class Initialized
INFO - 2019-11-02 09:37:06 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:06 --> Input Class Initialized
INFO - 2019-11-02 09:37:06 --> Language Class Initialized
INFO - 2019-11-02 09:37:06 --> Language Class Initialized
INFO - 2019-11-02 09:37:06 --> Config Class Initialized
INFO - 2019-11-02 09:37:06 --> Loader Class Initialized
INFO - 2019-11-02 09:37:06 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:06 --> Helper loaded: file_helper
INFO - 2019-11-02 09:37:06 --> Helper loaded: form_helper
INFO - 2019-11-02 09:37:06 --> Helper loaded: my_helper
INFO - 2019-11-02 09:37:06 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:37:06 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:37:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:37:06 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:06 --> Total execution time: 0.0698
INFO - 2019-11-02 09:38:00 --> Config Class Initialized
INFO - 2019-11-02 09:38:00 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:00 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:00 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:00 --> URI Class Initialized
INFO - 2019-11-02 09:38:00 --> Router Class Initialized
INFO - 2019-11-02 09:38:00 --> Output Class Initialized
INFO - 2019-11-02 09:38:00 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:00 --> Input Class Initialized
INFO - 2019-11-02 09:38:00 --> Language Class Initialized
INFO - 2019-11-02 09:38:00 --> Language Class Initialized
INFO - 2019-11-02 09:38:00 --> Config Class Initialized
INFO - 2019-11-02 09:38:00 --> Loader Class Initialized
INFO - 2019-11-02 09:38:00 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:00 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:00 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:00 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:00 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:00 --> Controller Class Initialized
DEBUG - 2019-11-02 09:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2019-11-02 09:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:38:00 --> Final output sent to browser
DEBUG - 2019-11-02 09:38:00 --> Total execution time: 0.0544
INFO - 2019-11-02 09:38:00 --> Config Class Initialized
INFO - 2019-11-02 09:38:00 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:00 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:00 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:00 --> URI Class Initialized
INFO - 2019-11-02 09:38:00 --> Router Class Initialized
INFO - 2019-11-02 09:38:00 --> Output Class Initialized
INFO - 2019-11-02 09:38:00 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:00 --> Input Class Initialized
INFO - 2019-11-02 09:38:00 --> Language Class Initialized
INFO - 2019-11-02 09:38:00 --> Language Class Initialized
INFO - 2019-11-02 09:38:00 --> Config Class Initialized
INFO - 2019-11-02 09:38:00 --> Loader Class Initialized
INFO - 2019-11-02 09:38:00 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:00 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:00 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:00 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:00 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:00 --> Controller Class Initialized
INFO - 2019-11-02 09:38:04 --> Config Class Initialized
INFO - 2019-11-02 09:38:04 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:04 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:04 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:04 --> URI Class Initialized
INFO - 2019-11-02 09:38:04 --> Router Class Initialized
INFO - 2019-11-02 09:38:04 --> Output Class Initialized
INFO - 2019-11-02 09:38:04 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:04 --> Input Class Initialized
INFO - 2019-11-02 09:38:04 --> Language Class Initialized
INFO - 2019-11-02 09:38:04 --> Language Class Initialized
INFO - 2019-11-02 09:38:04 --> Config Class Initialized
INFO - 2019-11-02 09:38:04 --> Loader Class Initialized
INFO - 2019-11-02 09:38:04 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:04 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:04 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:04 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:04 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:04 --> Controller Class Initialized
INFO - 2019-11-02 09:38:04 --> Final output sent to browser
DEBUG - 2019-11-02 09:38:04 --> Total execution time: 0.0656
INFO - 2019-11-02 09:38:04 --> Config Class Initialized
INFO - 2019-11-02 09:38:04 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:04 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:04 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:04 --> URI Class Initialized
INFO - 2019-11-02 09:38:04 --> Router Class Initialized
INFO - 2019-11-02 09:38:04 --> Output Class Initialized
INFO - 2019-11-02 09:38:04 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:04 --> Input Class Initialized
INFO - 2019-11-02 09:38:04 --> Language Class Initialized
INFO - 2019-11-02 09:38:04 --> Language Class Initialized
INFO - 2019-11-02 09:38:04 --> Config Class Initialized
INFO - 2019-11-02 09:38:04 --> Loader Class Initialized
INFO - 2019-11-02 09:38:04 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:04 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:04 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:04 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:04 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:04 --> Controller Class Initialized
INFO - 2019-11-02 09:38:06 --> Config Class Initialized
INFO - 2019-11-02 09:38:06 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:06 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:06 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:06 --> URI Class Initialized
INFO - 2019-11-02 09:38:06 --> Router Class Initialized
INFO - 2019-11-02 09:38:06 --> Output Class Initialized
INFO - 2019-11-02 09:38:06 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:06 --> Input Class Initialized
INFO - 2019-11-02 09:38:06 --> Language Class Initialized
INFO - 2019-11-02 09:38:06 --> Language Class Initialized
INFO - 2019-11-02 09:38:06 --> Config Class Initialized
INFO - 2019-11-02 09:38:06 --> Loader Class Initialized
INFO - 2019-11-02 09:38:06 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:06 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:06 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:06 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:06 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:06 --> Controller Class Initialized
DEBUG - 2019-11-02 09:38:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:38:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:38:06 --> Final output sent to browser
DEBUG - 2019-11-02 09:38:06 --> Total execution time: 0.0651
INFO - 2019-11-02 09:38:33 --> Config Class Initialized
INFO - 2019-11-02 09:38:33 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:33 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:33 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:33 --> URI Class Initialized
INFO - 2019-11-02 09:38:33 --> Router Class Initialized
INFO - 2019-11-02 09:38:33 --> Output Class Initialized
INFO - 2019-11-02 09:38:33 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:33 --> Input Class Initialized
INFO - 2019-11-02 09:38:33 --> Language Class Initialized
INFO - 2019-11-02 09:38:33 --> Language Class Initialized
INFO - 2019-11-02 09:38:33 --> Config Class Initialized
INFO - 2019-11-02 09:38:33 --> Loader Class Initialized
INFO - 2019-11-02 09:38:33 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:33 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:33 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:33 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:33 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:33 --> Controller Class Initialized
INFO - 2019-11-02 09:38:33 --> Final output sent to browser
DEBUG - 2019-11-02 09:38:33 --> Total execution time: 0.0658
INFO - 2019-11-02 09:38:35 --> Config Class Initialized
INFO - 2019-11-02 09:38:35 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:35 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:35 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:35 --> URI Class Initialized
INFO - 2019-11-02 09:38:35 --> Router Class Initialized
INFO - 2019-11-02 09:38:35 --> Output Class Initialized
INFO - 2019-11-02 09:38:35 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:35 --> Input Class Initialized
INFO - 2019-11-02 09:38:35 --> Language Class Initialized
INFO - 2019-11-02 09:38:35 --> Language Class Initialized
INFO - 2019-11-02 09:38:35 --> Config Class Initialized
INFO - 2019-11-02 09:38:35 --> Loader Class Initialized
INFO - 2019-11-02 09:38:35 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:35 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:35 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:35 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:35 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:35 --> Controller Class Initialized
DEBUG - 2019-11-02 09:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:38:35 --> Final output sent to browser
DEBUG - 2019-11-02 09:38:35 --> Total execution time: 0.0680
INFO - 2019-11-02 09:38:49 --> Config Class Initialized
INFO - 2019-11-02 09:38:49 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:49 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:49 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:49 --> URI Class Initialized
INFO - 2019-11-02 09:38:49 --> Router Class Initialized
INFO - 2019-11-02 09:38:49 --> Output Class Initialized
INFO - 2019-11-02 09:38:49 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:49 --> Input Class Initialized
INFO - 2019-11-02 09:38:49 --> Language Class Initialized
INFO - 2019-11-02 09:38:49 --> Language Class Initialized
INFO - 2019-11-02 09:38:49 --> Config Class Initialized
INFO - 2019-11-02 09:38:49 --> Loader Class Initialized
INFO - 2019-11-02 09:38:49 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:49 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:49 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:49 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:49 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:49 --> Controller Class Initialized
INFO - 2019-11-02 09:38:49 --> Final output sent to browser
DEBUG - 2019-11-02 09:38:49 --> Total execution time: 0.0696
INFO - 2019-11-02 09:38:51 --> Config Class Initialized
INFO - 2019-11-02 09:38:51 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:51 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:51 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:51 --> URI Class Initialized
INFO - 2019-11-02 09:38:51 --> Router Class Initialized
INFO - 2019-11-02 09:38:51 --> Output Class Initialized
INFO - 2019-11-02 09:38:51 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:51 --> Input Class Initialized
INFO - 2019-11-02 09:38:51 --> Language Class Initialized
INFO - 2019-11-02 09:38:51 --> Language Class Initialized
INFO - 2019-11-02 09:38:51 --> Config Class Initialized
INFO - 2019-11-02 09:38:51 --> Loader Class Initialized
INFO - 2019-11-02 09:38:51 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:51 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:51 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:51 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:51 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:51 --> Controller Class Initialized
INFO - 2019-11-02 09:38:51 --> Final output sent to browser
DEBUG - 2019-11-02 09:38:51 --> Total execution time: 0.0622
INFO - 2019-11-02 09:38:55 --> Config Class Initialized
INFO - 2019-11-02 09:38:55 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:38:55 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:38:55 --> Utf8 Class Initialized
INFO - 2019-11-02 09:38:55 --> URI Class Initialized
INFO - 2019-11-02 09:38:55 --> Router Class Initialized
INFO - 2019-11-02 09:38:55 --> Output Class Initialized
INFO - 2019-11-02 09:38:55 --> Security Class Initialized
DEBUG - 2019-11-02 09:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:38:55 --> Input Class Initialized
INFO - 2019-11-02 09:38:55 --> Language Class Initialized
INFO - 2019-11-02 09:38:55 --> Language Class Initialized
INFO - 2019-11-02 09:38:55 --> Config Class Initialized
INFO - 2019-11-02 09:38:55 --> Loader Class Initialized
INFO - 2019-11-02 09:38:55 --> Helper loaded: url_helper
INFO - 2019-11-02 09:38:55 --> Helper loaded: file_helper
INFO - 2019-11-02 09:38:55 --> Helper loaded: form_helper
INFO - 2019-11-02 09:38:55 --> Helper loaded: my_helper
INFO - 2019-11-02 09:38:55 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:38:55 --> Controller Class Initialized
DEBUG - 2019-11-02 09:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:38:55 --> Final output sent to browser
DEBUG - 2019-11-02 09:38:55 --> Total execution time: 0.0677
INFO - 2019-11-02 09:39:04 --> Config Class Initialized
INFO - 2019-11-02 09:39:04 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:39:04 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:39:04 --> Utf8 Class Initialized
INFO - 2019-11-02 09:39:04 --> URI Class Initialized
INFO - 2019-11-02 09:39:04 --> Router Class Initialized
INFO - 2019-11-02 09:39:04 --> Output Class Initialized
INFO - 2019-11-02 09:39:04 --> Security Class Initialized
DEBUG - 2019-11-02 09:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:39:04 --> Input Class Initialized
INFO - 2019-11-02 09:39:04 --> Language Class Initialized
INFO - 2019-11-02 09:39:04 --> Language Class Initialized
INFO - 2019-11-02 09:39:04 --> Config Class Initialized
INFO - 2019-11-02 09:39:04 --> Loader Class Initialized
INFO - 2019-11-02 09:39:04 --> Helper loaded: url_helper
INFO - 2019-11-02 09:39:04 --> Helper loaded: file_helper
INFO - 2019-11-02 09:39:04 --> Helper loaded: form_helper
INFO - 2019-11-02 09:39:04 --> Helper loaded: my_helper
INFO - 2019-11-02 09:39:04 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:39:04 --> Controller Class Initialized
INFO - 2019-11-02 09:39:04 --> Final output sent to browser
DEBUG - 2019-11-02 09:39:04 --> Total execution time: 0.0603
INFO - 2019-11-02 09:39:06 --> Config Class Initialized
INFO - 2019-11-02 09:39:06 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:39:06 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:39:06 --> Utf8 Class Initialized
INFO - 2019-11-02 09:39:06 --> URI Class Initialized
INFO - 2019-11-02 09:39:06 --> Router Class Initialized
INFO - 2019-11-02 09:39:06 --> Output Class Initialized
INFO - 2019-11-02 09:39:06 --> Security Class Initialized
DEBUG - 2019-11-02 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:39:06 --> Input Class Initialized
INFO - 2019-11-02 09:39:06 --> Language Class Initialized
INFO - 2019-11-02 09:39:06 --> Language Class Initialized
INFO - 2019-11-02 09:39:06 --> Config Class Initialized
INFO - 2019-11-02 09:39:06 --> Loader Class Initialized
INFO - 2019-11-02 09:39:06 --> Helper loaded: url_helper
INFO - 2019-11-02 09:39:06 --> Helper loaded: file_helper
INFO - 2019-11-02 09:39:06 --> Helper loaded: form_helper
INFO - 2019-11-02 09:39:06 --> Helper loaded: my_helper
INFO - 2019-11-02 09:39:06 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:39:06 --> Controller Class Initialized
INFO - 2019-11-02 09:39:06 --> Final output sent to browser
DEBUG - 2019-11-02 09:39:06 --> Total execution time: 0.0476
INFO - 2019-11-02 09:39:09 --> Config Class Initialized
INFO - 2019-11-02 09:39:09 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:39:09 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:39:09 --> Utf8 Class Initialized
INFO - 2019-11-02 09:39:09 --> URI Class Initialized
INFO - 2019-11-02 09:39:09 --> Router Class Initialized
INFO - 2019-11-02 09:39:09 --> Output Class Initialized
INFO - 2019-11-02 09:39:09 --> Security Class Initialized
DEBUG - 2019-11-02 09:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:39:09 --> Input Class Initialized
INFO - 2019-11-02 09:39:09 --> Language Class Initialized
INFO - 2019-11-02 09:39:09 --> Language Class Initialized
INFO - 2019-11-02 09:39:09 --> Config Class Initialized
INFO - 2019-11-02 09:39:09 --> Loader Class Initialized
INFO - 2019-11-02 09:39:09 --> Helper loaded: url_helper
INFO - 2019-11-02 09:39:09 --> Helper loaded: file_helper
INFO - 2019-11-02 09:39:09 --> Helper loaded: form_helper
INFO - 2019-11-02 09:39:09 --> Helper loaded: my_helper
INFO - 2019-11-02 09:39:09 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:39:09 --> Controller Class Initialized
DEBUG - 2019-11-02 09:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:39:09 --> Final output sent to browser
DEBUG - 2019-11-02 09:39:09 --> Total execution time: 0.0572
INFO - 2019-11-02 09:40:05 --> Config Class Initialized
INFO - 2019-11-02 09:40:05 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:40:05 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:40:05 --> Utf8 Class Initialized
INFO - 2019-11-02 09:40:05 --> URI Class Initialized
INFO - 2019-11-02 09:40:05 --> Router Class Initialized
INFO - 2019-11-02 09:40:05 --> Output Class Initialized
INFO - 2019-11-02 09:40:05 --> Security Class Initialized
DEBUG - 2019-11-02 09:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:40:05 --> Input Class Initialized
INFO - 2019-11-02 09:40:05 --> Language Class Initialized
INFO - 2019-11-02 09:40:05 --> Language Class Initialized
INFO - 2019-11-02 09:40:05 --> Config Class Initialized
INFO - 2019-11-02 09:40:05 --> Loader Class Initialized
INFO - 2019-11-02 09:40:05 --> Helper loaded: url_helper
INFO - 2019-11-02 09:40:05 --> Helper loaded: file_helper
INFO - 2019-11-02 09:40:05 --> Helper loaded: form_helper
INFO - 2019-11-02 09:40:05 --> Helper loaded: my_helper
INFO - 2019-11-02 09:40:05 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:40:05 --> Controller Class Initialized
INFO - 2019-11-02 09:40:05 --> Final output sent to browser
DEBUG - 2019-11-02 09:40:05 --> Total execution time: 0.0694
INFO - 2019-11-02 09:40:24 --> Config Class Initialized
INFO - 2019-11-02 09:40:24 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:40:24 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:40:24 --> Utf8 Class Initialized
INFO - 2019-11-02 09:40:24 --> URI Class Initialized
INFO - 2019-11-02 09:40:24 --> Router Class Initialized
INFO - 2019-11-02 09:40:24 --> Output Class Initialized
INFO - 2019-11-02 09:40:24 --> Security Class Initialized
DEBUG - 2019-11-02 09:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:40:24 --> Input Class Initialized
INFO - 2019-11-02 09:40:24 --> Language Class Initialized
INFO - 2019-11-02 09:40:24 --> Language Class Initialized
INFO - 2019-11-02 09:40:24 --> Config Class Initialized
INFO - 2019-11-02 09:40:24 --> Loader Class Initialized
INFO - 2019-11-02 09:40:24 --> Helper loaded: url_helper
INFO - 2019-11-02 09:40:24 --> Helper loaded: file_helper
INFO - 2019-11-02 09:40:24 --> Helper loaded: form_helper
INFO - 2019-11-02 09:40:24 --> Helper loaded: my_helper
INFO - 2019-11-02 09:40:24 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:40:24 --> Controller Class Initialized
INFO - 2019-11-02 09:40:24 --> Final output sent to browser
DEBUG - 2019-11-02 09:40:24 --> Total execution time: 0.0479
INFO - 2019-11-02 09:41:11 --> Config Class Initialized
INFO - 2019-11-02 09:41:11 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:41:11 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:41:11 --> Utf8 Class Initialized
INFO - 2019-11-02 09:41:11 --> URI Class Initialized
INFO - 2019-11-02 09:41:11 --> Router Class Initialized
INFO - 2019-11-02 09:41:11 --> Output Class Initialized
INFO - 2019-11-02 09:41:11 --> Security Class Initialized
DEBUG - 2019-11-02 09:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:41:11 --> Input Class Initialized
INFO - 2019-11-02 09:41:11 --> Language Class Initialized
INFO - 2019-11-02 09:41:11 --> Language Class Initialized
INFO - 2019-11-02 09:41:11 --> Config Class Initialized
INFO - 2019-11-02 09:41:11 --> Loader Class Initialized
INFO - 2019-11-02 09:41:11 --> Helper loaded: url_helper
INFO - 2019-11-02 09:41:11 --> Helper loaded: file_helper
INFO - 2019-11-02 09:41:11 --> Helper loaded: form_helper
INFO - 2019-11-02 09:41:11 --> Helper loaded: my_helper
INFO - 2019-11-02 09:41:11 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:41:11 --> Controller Class Initialized
INFO - 2019-11-02 09:41:11 --> Final output sent to browser
DEBUG - 2019-11-02 09:41:11 --> Total execution time: 0.0602
INFO - 2019-11-02 09:41:39 --> Config Class Initialized
INFO - 2019-11-02 09:41:39 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:41:39 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:41:39 --> Utf8 Class Initialized
INFO - 2019-11-02 09:41:39 --> URI Class Initialized
INFO - 2019-11-02 09:41:39 --> Router Class Initialized
INFO - 2019-11-02 09:41:39 --> Output Class Initialized
INFO - 2019-11-02 09:41:39 --> Security Class Initialized
DEBUG - 2019-11-02 09:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:41:39 --> Input Class Initialized
INFO - 2019-11-02 09:41:39 --> Language Class Initialized
INFO - 2019-11-02 09:41:39 --> Language Class Initialized
INFO - 2019-11-02 09:41:39 --> Config Class Initialized
INFO - 2019-11-02 09:41:39 --> Loader Class Initialized
INFO - 2019-11-02 09:41:39 --> Helper loaded: url_helper
INFO - 2019-11-02 09:41:39 --> Helper loaded: file_helper
INFO - 2019-11-02 09:41:39 --> Helper loaded: form_helper
INFO - 2019-11-02 09:41:39 --> Helper loaded: my_helper
INFO - 2019-11-02 09:41:39 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:41:39 --> Controller Class Initialized
INFO - 2019-11-02 09:41:39 --> Final output sent to browser
DEBUG - 2019-11-02 09:41:39 --> Total execution time: 0.0502
INFO - 2019-11-02 09:41:43 --> Config Class Initialized
INFO - 2019-11-02 09:41:43 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:41:43 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:41:43 --> Utf8 Class Initialized
INFO - 2019-11-02 09:41:43 --> URI Class Initialized
INFO - 2019-11-02 09:41:43 --> Router Class Initialized
INFO - 2019-11-02 09:41:43 --> Output Class Initialized
INFO - 2019-11-02 09:41:43 --> Security Class Initialized
DEBUG - 2019-11-02 09:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:41:43 --> Input Class Initialized
INFO - 2019-11-02 09:41:43 --> Language Class Initialized
INFO - 2019-11-02 09:41:43 --> Language Class Initialized
INFO - 2019-11-02 09:41:43 --> Config Class Initialized
INFO - 2019-11-02 09:41:43 --> Loader Class Initialized
INFO - 2019-11-02 09:41:43 --> Helper loaded: url_helper
INFO - 2019-11-02 09:41:43 --> Helper loaded: file_helper
INFO - 2019-11-02 09:41:43 --> Helper loaded: form_helper
INFO - 2019-11-02 09:41:43 --> Helper loaded: my_helper
INFO - 2019-11-02 09:41:43 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:41:43 --> Controller Class Initialized
DEBUG - 2019-11-02 09:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:41:43 --> Final output sent to browser
DEBUG - 2019-11-02 09:41:43 --> Total execution time: 0.0675
INFO - 2019-11-02 09:42:23 --> Config Class Initialized
INFO - 2019-11-02 09:42:23 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:42:23 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:42:23 --> Utf8 Class Initialized
INFO - 2019-11-02 09:42:23 --> URI Class Initialized
INFO - 2019-11-02 09:42:23 --> Router Class Initialized
INFO - 2019-11-02 09:42:23 --> Output Class Initialized
INFO - 2019-11-02 09:42:23 --> Security Class Initialized
DEBUG - 2019-11-02 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:42:23 --> Input Class Initialized
INFO - 2019-11-02 09:42:23 --> Language Class Initialized
INFO - 2019-11-02 09:42:23 --> Language Class Initialized
INFO - 2019-11-02 09:42:23 --> Config Class Initialized
INFO - 2019-11-02 09:42:23 --> Loader Class Initialized
INFO - 2019-11-02 09:42:23 --> Helper loaded: url_helper
INFO - 2019-11-02 09:42:23 --> Helper loaded: file_helper
INFO - 2019-11-02 09:42:23 --> Helper loaded: form_helper
INFO - 2019-11-02 09:42:23 --> Helper loaded: my_helper
INFO - 2019-11-02 09:42:23 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:42:23 --> Controller Class Initialized
INFO - 2019-11-02 09:42:23 --> Final output sent to browser
DEBUG - 2019-11-02 09:42:23 --> Total execution time: 0.0507
INFO - 2019-11-02 09:43:00 --> Config Class Initialized
INFO - 2019-11-02 09:43:00 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:43:00 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:43:00 --> Utf8 Class Initialized
INFO - 2019-11-02 09:43:00 --> URI Class Initialized
INFO - 2019-11-02 09:43:00 --> Router Class Initialized
INFO - 2019-11-02 09:43:00 --> Output Class Initialized
INFO - 2019-11-02 09:43:00 --> Security Class Initialized
DEBUG - 2019-11-02 09:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:43:00 --> Input Class Initialized
INFO - 2019-11-02 09:43:00 --> Language Class Initialized
INFO - 2019-11-02 09:43:00 --> Language Class Initialized
INFO - 2019-11-02 09:43:00 --> Config Class Initialized
INFO - 2019-11-02 09:43:00 --> Loader Class Initialized
INFO - 2019-11-02 09:43:00 --> Helper loaded: url_helper
INFO - 2019-11-02 09:43:00 --> Helper loaded: file_helper
INFO - 2019-11-02 09:43:00 --> Helper loaded: form_helper
INFO - 2019-11-02 09:43:00 --> Helper loaded: my_helper
INFO - 2019-11-02 09:43:00 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:43:00 --> Controller Class Initialized
INFO - 2019-11-02 09:43:00 --> Final output sent to browser
DEBUG - 2019-11-02 09:43:00 --> Total execution time: 0.0657
INFO - 2019-11-02 09:43:02 --> Config Class Initialized
INFO - 2019-11-02 09:43:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:43:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:43:02 --> Utf8 Class Initialized
INFO - 2019-11-02 09:43:02 --> URI Class Initialized
INFO - 2019-11-02 09:43:02 --> Router Class Initialized
INFO - 2019-11-02 09:43:02 --> Output Class Initialized
INFO - 2019-11-02 09:43:02 --> Security Class Initialized
DEBUG - 2019-11-02 09:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:43:02 --> Input Class Initialized
INFO - 2019-11-02 09:43:02 --> Language Class Initialized
INFO - 2019-11-02 09:43:02 --> Language Class Initialized
INFO - 2019-11-02 09:43:02 --> Config Class Initialized
INFO - 2019-11-02 09:43:02 --> Loader Class Initialized
INFO - 2019-11-02 09:43:02 --> Helper loaded: url_helper
INFO - 2019-11-02 09:43:02 --> Helper loaded: file_helper
INFO - 2019-11-02 09:43:02 --> Helper loaded: form_helper
INFO - 2019-11-02 09:43:02 --> Helper loaded: my_helper
INFO - 2019-11-02 09:43:02 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:43:02 --> Controller Class Initialized
INFO - 2019-11-02 09:43:02 --> Final output sent to browser
DEBUG - 2019-11-02 09:43:02 --> Total execution time: 0.0475
INFO - 2019-11-02 09:43:21 --> Config Class Initialized
INFO - 2019-11-02 09:43:21 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:43:21 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:43:21 --> Utf8 Class Initialized
INFO - 2019-11-02 09:43:21 --> URI Class Initialized
INFO - 2019-11-02 09:43:21 --> Router Class Initialized
INFO - 2019-11-02 09:43:21 --> Output Class Initialized
INFO - 2019-11-02 09:43:21 --> Security Class Initialized
DEBUG - 2019-11-02 09:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:43:21 --> Input Class Initialized
INFO - 2019-11-02 09:43:21 --> Language Class Initialized
INFO - 2019-11-02 09:43:21 --> Language Class Initialized
INFO - 2019-11-02 09:43:21 --> Config Class Initialized
INFO - 2019-11-02 09:43:21 --> Loader Class Initialized
INFO - 2019-11-02 09:43:21 --> Helper loaded: url_helper
INFO - 2019-11-02 09:43:21 --> Helper loaded: file_helper
INFO - 2019-11-02 09:43:21 --> Helper loaded: form_helper
INFO - 2019-11-02 09:43:21 --> Helper loaded: my_helper
INFO - 2019-11-02 09:43:21 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:43:21 --> Controller Class Initialized
INFO - 2019-11-02 09:43:21 --> Final output sent to browser
DEBUG - 2019-11-02 09:43:21 --> Total execution time: 0.0578
INFO - 2019-11-02 09:44:05 --> Config Class Initialized
INFO - 2019-11-02 09:44:05 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:44:05 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:44:05 --> Utf8 Class Initialized
INFO - 2019-11-02 09:44:05 --> URI Class Initialized
INFO - 2019-11-02 09:44:05 --> Router Class Initialized
INFO - 2019-11-02 09:44:05 --> Output Class Initialized
INFO - 2019-11-02 09:44:05 --> Security Class Initialized
DEBUG - 2019-11-02 09:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:44:05 --> Input Class Initialized
INFO - 2019-11-02 09:44:05 --> Language Class Initialized
INFO - 2019-11-02 09:44:05 --> Language Class Initialized
INFO - 2019-11-02 09:44:05 --> Config Class Initialized
INFO - 2019-11-02 09:44:05 --> Loader Class Initialized
INFO - 2019-11-02 09:44:05 --> Helper loaded: url_helper
INFO - 2019-11-02 09:44:05 --> Helper loaded: file_helper
INFO - 2019-11-02 09:44:05 --> Helper loaded: form_helper
INFO - 2019-11-02 09:44:05 --> Helper loaded: my_helper
INFO - 2019-11-02 09:44:05 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:44:05 --> Controller Class Initialized
INFO - 2019-11-02 09:44:05 --> Final output sent to browser
DEBUG - 2019-11-02 09:44:05 --> Total execution time: 0.0658
INFO - 2019-11-02 09:45:02 --> Config Class Initialized
INFO - 2019-11-02 09:45:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:45:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:45:02 --> Utf8 Class Initialized
INFO - 2019-11-02 09:45:02 --> URI Class Initialized
INFO - 2019-11-02 09:45:02 --> Router Class Initialized
INFO - 2019-11-02 09:45:02 --> Output Class Initialized
INFO - 2019-11-02 09:45:02 --> Security Class Initialized
DEBUG - 2019-11-02 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:45:02 --> Input Class Initialized
INFO - 2019-11-02 09:45:02 --> Language Class Initialized
INFO - 2019-11-02 09:45:02 --> Language Class Initialized
INFO - 2019-11-02 09:45:02 --> Config Class Initialized
INFO - 2019-11-02 09:45:02 --> Loader Class Initialized
INFO - 2019-11-02 09:45:02 --> Helper loaded: url_helper
INFO - 2019-11-02 09:45:02 --> Helper loaded: file_helper
INFO - 2019-11-02 09:45:02 --> Helper loaded: form_helper
INFO - 2019-11-02 09:45:02 --> Helper loaded: my_helper
INFO - 2019-11-02 09:45:02 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:45:02 --> Controller Class Initialized
INFO - 2019-11-02 09:45:02 --> Final output sent to browser
DEBUG - 2019-11-02 09:45:02 --> Total execution time: 0.0678
INFO - 2019-11-02 09:45:10 --> Config Class Initialized
INFO - 2019-11-02 09:45:10 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:45:10 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:45:10 --> Utf8 Class Initialized
INFO - 2019-11-02 09:45:10 --> URI Class Initialized
INFO - 2019-11-02 09:45:10 --> Router Class Initialized
INFO - 2019-11-02 09:45:10 --> Output Class Initialized
INFO - 2019-11-02 09:45:10 --> Security Class Initialized
DEBUG - 2019-11-02 09:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:45:10 --> Input Class Initialized
INFO - 2019-11-02 09:45:10 --> Language Class Initialized
INFO - 2019-11-02 09:45:10 --> Language Class Initialized
INFO - 2019-11-02 09:45:10 --> Config Class Initialized
INFO - 2019-11-02 09:45:10 --> Loader Class Initialized
INFO - 2019-11-02 09:45:10 --> Helper loaded: url_helper
INFO - 2019-11-02 09:45:10 --> Helper loaded: file_helper
INFO - 2019-11-02 09:45:10 --> Helper loaded: form_helper
INFO - 2019-11-02 09:45:10 --> Helper loaded: my_helper
INFO - 2019-11-02 09:45:10 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:45:10 --> Controller Class Initialized
INFO - 2019-11-02 09:45:10 --> Final output sent to browser
DEBUG - 2019-11-02 09:45:10 --> Total execution time: 0.0537
INFO - 2019-11-02 09:45:11 --> Config Class Initialized
INFO - 2019-11-02 09:45:11 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:45:11 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:45:11 --> Utf8 Class Initialized
INFO - 2019-11-02 09:45:11 --> URI Class Initialized
INFO - 2019-11-02 09:45:11 --> Router Class Initialized
INFO - 2019-11-02 09:45:11 --> Output Class Initialized
INFO - 2019-11-02 09:45:11 --> Security Class Initialized
DEBUG - 2019-11-02 09:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:45:11 --> Input Class Initialized
INFO - 2019-11-02 09:45:11 --> Language Class Initialized
INFO - 2019-11-02 09:45:11 --> Language Class Initialized
INFO - 2019-11-02 09:45:11 --> Config Class Initialized
INFO - 2019-11-02 09:45:11 --> Loader Class Initialized
INFO - 2019-11-02 09:45:11 --> Helper loaded: url_helper
INFO - 2019-11-02 09:45:11 --> Helper loaded: file_helper
INFO - 2019-11-02 09:45:11 --> Helper loaded: form_helper
INFO - 2019-11-02 09:45:11 --> Helper loaded: my_helper
INFO - 2019-11-02 09:45:11 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:45:11 --> Controller Class Initialized
DEBUG - 2019-11-02 09:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:45:11 --> Final output sent to browser
DEBUG - 2019-11-02 09:45:11 --> Total execution time: 0.0740
INFO - 2019-11-02 09:45:27 --> Config Class Initialized
INFO - 2019-11-02 09:45:27 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:45:27 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:45:27 --> Utf8 Class Initialized
INFO - 2019-11-02 09:45:27 --> URI Class Initialized
INFO - 2019-11-02 09:45:27 --> Router Class Initialized
INFO - 2019-11-02 09:45:27 --> Output Class Initialized
INFO - 2019-11-02 09:45:27 --> Security Class Initialized
DEBUG - 2019-11-02 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:45:27 --> Input Class Initialized
INFO - 2019-11-02 09:45:27 --> Language Class Initialized
INFO - 2019-11-02 09:45:27 --> Language Class Initialized
INFO - 2019-11-02 09:45:27 --> Config Class Initialized
INFO - 2019-11-02 09:45:27 --> Loader Class Initialized
INFO - 2019-11-02 09:45:27 --> Helper loaded: url_helper
INFO - 2019-11-02 09:45:27 --> Helper loaded: file_helper
INFO - 2019-11-02 09:45:27 --> Helper loaded: form_helper
INFO - 2019-11-02 09:45:27 --> Helper loaded: my_helper
INFO - 2019-11-02 09:45:27 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:45:27 --> Controller Class Initialized
INFO - 2019-11-02 09:45:27 --> Final output sent to browser
DEBUG - 2019-11-02 09:45:27 --> Total execution time: 0.0477
INFO - 2019-11-02 09:45:29 --> Config Class Initialized
INFO - 2019-11-02 09:45:29 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:45:29 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:45:29 --> Utf8 Class Initialized
INFO - 2019-11-02 09:45:29 --> URI Class Initialized
INFO - 2019-11-02 09:45:29 --> Router Class Initialized
INFO - 2019-11-02 09:45:29 --> Output Class Initialized
INFO - 2019-11-02 09:45:29 --> Security Class Initialized
DEBUG - 2019-11-02 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:45:29 --> Input Class Initialized
INFO - 2019-11-02 09:45:29 --> Language Class Initialized
INFO - 2019-11-02 09:45:29 --> Language Class Initialized
INFO - 2019-11-02 09:45:29 --> Config Class Initialized
INFO - 2019-11-02 09:45:29 --> Loader Class Initialized
INFO - 2019-11-02 09:45:29 --> Helper loaded: url_helper
INFO - 2019-11-02 09:45:29 --> Helper loaded: file_helper
INFO - 2019-11-02 09:45:29 --> Helper loaded: form_helper
INFO - 2019-11-02 09:45:29 --> Helper loaded: my_helper
INFO - 2019-11-02 09:45:29 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:45:29 --> Controller Class Initialized
DEBUG - 2019-11-02 09:45:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:45:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:45:29 --> Final output sent to browser
DEBUG - 2019-11-02 09:45:29 --> Total execution time: 0.0827
INFO - 2019-11-02 09:47:08 --> Config Class Initialized
INFO - 2019-11-02 09:47:08 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:47:08 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:47:08 --> Utf8 Class Initialized
INFO - 2019-11-02 09:47:08 --> URI Class Initialized
INFO - 2019-11-02 09:47:08 --> Router Class Initialized
INFO - 2019-11-02 09:47:08 --> Output Class Initialized
INFO - 2019-11-02 09:47:08 --> Security Class Initialized
DEBUG - 2019-11-02 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:47:08 --> Input Class Initialized
INFO - 2019-11-02 09:47:08 --> Language Class Initialized
INFO - 2019-11-02 09:47:08 --> Language Class Initialized
INFO - 2019-11-02 09:47:08 --> Config Class Initialized
INFO - 2019-11-02 09:47:08 --> Loader Class Initialized
INFO - 2019-11-02 09:47:08 --> Helper loaded: url_helper
INFO - 2019-11-02 09:47:08 --> Helper loaded: file_helper
INFO - 2019-11-02 09:47:08 --> Helper loaded: form_helper
INFO - 2019-11-02 09:47:08 --> Helper loaded: my_helper
INFO - 2019-11-02 09:47:08 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:47:08 --> Controller Class Initialized
INFO - 2019-11-02 09:47:08 --> Final output sent to browser
DEBUG - 2019-11-02 09:47:08 --> Total execution time: 0.0625
INFO - 2019-11-02 09:47:47 --> Config Class Initialized
INFO - 2019-11-02 09:47:47 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:47:47 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:47:47 --> Utf8 Class Initialized
INFO - 2019-11-02 09:47:47 --> URI Class Initialized
INFO - 2019-11-02 09:47:47 --> Router Class Initialized
INFO - 2019-11-02 09:47:47 --> Output Class Initialized
INFO - 2019-11-02 09:47:47 --> Security Class Initialized
DEBUG - 2019-11-02 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:47:47 --> Input Class Initialized
INFO - 2019-11-02 09:47:47 --> Language Class Initialized
INFO - 2019-11-02 09:47:47 --> Language Class Initialized
INFO - 2019-11-02 09:47:47 --> Config Class Initialized
INFO - 2019-11-02 09:47:47 --> Loader Class Initialized
INFO - 2019-11-02 09:47:47 --> Helper loaded: url_helper
INFO - 2019-11-02 09:47:47 --> Helper loaded: file_helper
INFO - 2019-11-02 09:47:47 --> Helper loaded: form_helper
INFO - 2019-11-02 09:47:47 --> Helper loaded: my_helper
INFO - 2019-11-02 09:47:47 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:47:47 --> Controller Class Initialized
DEBUG - 2019-11-02 09:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:47:47 --> Final output sent to browser
DEBUG - 2019-11-02 09:47:47 --> Total execution time: 0.0554
INFO - 2019-11-02 09:48:50 --> Config Class Initialized
INFO - 2019-11-02 09:48:50 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:48:50 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:48:50 --> Utf8 Class Initialized
INFO - 2019-11-02 09:48:50 --> URI Class Initialized
INFO - 2019-11-02 09:48:50 --> Router Class Initialized
INFO - 2019-11-02 09:48:50 --> Output Class Initialized
INFO - 2019-11-02 09:48:50 --> Security Class Initialized
DEBUG - 2019-11-02 09:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:48:50 --> Input Class Initialized
INFO - 2019-11-02 09:48:50 --> Language Class Initialized
INFO - 2019-11-02 09:48:50 --> Language Class Initialized
INFO - 2019-11-02 09:48:50 --> Config Class Initialized
INFO - 2019-11-02 09:48:50 --> Loader Class Initialized
INFO - 2019-11-02 09:48:50 --> Helper loaded: url_helper
INFO - 2019-11-02 09:48:50 --> Helper loaded: file_helper
INFO - 2019-11-02 09:48:50 --> Helper loaded: form_helper
INFO - 2019-11-02 09:48:50 --> Helper loaded: my_helper
INFO - 2019-11-02 09:48:50 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:48:50 --> Controller Class Initialized
INFO - 2019-11-02 09:48:50 --> Final output sent to browser
DEBUG - 2019-11-02 09:48:50 --> Total execution time: 0.0606
INFO - 2019-11-02 09:49:03 --> Config Class Initialized
INFO - 2019-11-02 09:49:03 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:03 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:03 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:03 --> URI Class Initialized
INFO - 2019-11-02 09:49:03 --> Router Class Initialized
INFO - 2019-11-02 09:49:03 --> Output Class Initialized
INFO - 2019-11-02 09:49:03 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:03 --> Input Class Initialized
INFO - 2019-11-02 09:49:03 --> Language Class Initialized
INFO - 2019-11-02 09:49:03 --> Language Class Initialized
INFO - 2019-11-02 09:49:03 --> Config Class Initialized
INFO - 2019-11-02 09:49:03 --> Loader Class Initialized
INFO - 2019-11-02 09:49:03 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:03 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:03 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:03 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:03 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:03 --> Controller Class Initialized
INFO - 2019-11-02 09:49:03 --> Final output sent to browser
DEBUG - 2019-11-02 09:49:03 --> Total execution time: 0.0691
INFO - 2019-11-02 09:49:12 --> Config Class Initialized
INFO - 2019-11-02 09:49:12 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:12 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:12 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:12 --> URI Class Initialized
INFO - 2019-11-02 09:49:12 --> Router Class Initialized
INFO - 2019-11-02 09:49:12 --> Output Class Initialized
INFO - 2019-11-02 09:49:12 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:12 --> Input Class Initialized
INFO - 2019-11-02 09:49:12 --> Language Class Initialized
INFO - 2019-11-02 09:49:12 --> Language Class Initialized
INFO - 2019-11-02 09:49:12 --> Config Class Initialized
INFO - 2019-11-02 09:49:12 --> Loader Class Initialized
INFO - 2019-11-02 09:49:12 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:12 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:12 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:12 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:12 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:12 --> Controller Class Initialized
INFO - 2019-11-02 09:49:12 --> Final output sent to browser
DEBUG - 2019-11-02 09:49:12 --> Total execution time: 0.0621
INFO - 2019-11-02 09:49:18 --> Config Class Initialized
INFO - 2019-11-02 09:49:18 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:18 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:18 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:18 --> URI Class Initialized
INFO - 2019-11-02 09:49:18 --> Router Class Initialized
INFO - 2019-11-02 09:49:18 --> Output Class Initialized
INFO - 2019-11-02 09:49:18 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:18 --> Input Class Initialized
INFO - 2019-11-02 09:49:18 --> Language Class Initialized
INFO - 2019-11-02 09:49:18 --> Language Class Initialized
INFO - 2019-11-02 09:49:18 --> Config Class Initialized
INFO - 2019-11-02 09:49:18 --> Loader Class Initialized
INFO - 2019-11-02 09:49:18 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:18 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:18 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:18 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:18 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:18 --> Controller Class Initialized
INFO - 2019-11-02 09:49:18 --> Final output sent to browser
DEBUG - 2019-11-02 09:49:18 --> Total execution time: 0.0652
INFO - 2019-11-02 09:49:22 --> Config Class Initialized
INFO - 2019-11-02 09:49:22 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:22 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:22 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:22 --> URI Class Initialized
INFO - 2019-11-02 09:49:22 --> Router Class Initialized
INFO - 2019-11-02 09:49:22 --> Output Class Initialized
INFO - 2019-11-02 09:49:22 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:22 --> Input Class Initialized
INFO - 2019-11-02 09:49:22 --> Language Class Initialized
INFO - 2019-11-02 09:49:22 --> Language Class Initialized
INFO - 2019-11-02 09:49:22 --> Config Class Initialized
INFO - 2019-11-02 09:49:22 --> Loader Class Initialized
INFO - 2019-11-02 09:49:22 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:22 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:22 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:22 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:22 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:22 --> Controller Class Initialized
DEBUG - 2019-11-02 09:49:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:49:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:49:22 --> Final output sent to browser
DEBUG - 2019-11-02 09:49:22 --> Total execution time: 0.0561
INFO - 2019-11-02 09:49:32 --> Config Class Initialized
INFO - 2019-11-02 09:49:32 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:32 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:32 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:32 --> URI Class Initialized
INFO - 2019-11-02 09:49:32 --> Router Class Initialized
INFO - 2019-11-02 09:49:32 --> Output Class Initialized
INFO - 2019-11-02 09:49:32 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:32 --> Input Class Initialized
INFO - 2019-11-02 09:49:32 --> Language Class Initialized
INFO - 2019-11-02 09:49:32 --> Language Class Initialized
INFO - 2019-11-02 09:49:32 --> Config Class Initialized
INFO - 2019-11-02 09:49:32 --> Loader Class Initialized
INFO - 2019-11-02 09:49:32 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:32 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:32 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:32 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:32 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:32 --> Controller Class Initialized
DEBUG - 2019-11-02 09:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2019-11-02 09:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:49:32 --> Final output sent to browser
DEBUG - 2019-11-02 09:49:32 --> Total execution time: 0.0518
INFO - 2019-11-02 09:49:32 --> Config Class Initialized
INFO - 2019-11-02 09:49:32 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:32 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:32 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:32 --> URI Class Initialized
INFO - 2019-11-02 09:49:32 --> Router Class Initialized
INFO - 2019-11-02 09:49:32 --> Output Class Initialized
INFO - 2019-11-02 09:49:32 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:32 --> Input Class Initialized
INFO - 2019-11-02 09:49:32 --> Language Class Initialized
INFO - 2019-11-02 09:49:32 --> Language Class Initialized
INFO - 2019-11-02 09:49:32 --> Config Class Initialized
INFO - 2019-11-02 09:49:32 --> Loader Class Initialized
INFO - 2019-11-02 09:49:32 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:32 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:32 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:32 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:32 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:32 --> Controller Class Initialized
INFO - 2019-11-02 09:49:34 --> Config Class Initialized
INFO - 2019-11-02 09:49:34 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:34 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:34 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:34 --> URI Class Initialized
INFO - 2019-11-02 09:49:34 --> Router Class Initialized
INFO - 2019-11-02 09:49:34 --> Output Class Initialized
INFO - 2019-11-02 09:49:34 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:34 --> Input Class Initialized
INFO - 2019-11-02 09:49:34 --> Language Class Initialized
INFO - 2019-11-02 09:49:34 --> Language Class Initialized
INFO - 2019-11-02 09:49:34 --> Config Class Initialized
INFO - 2019-11-02 09:49:34 --> Loader Class Initialized
INFO - 2019-11-02 09:49:34 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:34 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:34 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:34 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:34 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:34 --> Controller Class Initialized
INFO - 2019-11-02 09:49:34 --> Final output sent to browser
DEBUG - 2019-11-02 09:49:34 --> Total execution time: 0.0600
INFO - 2019-11-02 09:49:34 --> Config Class Initialized
INFO - 2019-11-02 09:49:34 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:34 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:34 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:34 --> URI Class Initialized
INFO - 2019-11-02 09:49:34 --> Router Class Initialized
INFO - 2019-11-02 09:49:34 --> Output Class Initialized
INFO - 2019-11-02 09:49:34 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:34 --> Input Class Initialized
INFO - 2019-11-02 09:49:34 --> Language Class Initialized
INFO - 2019-11-02 09:49:34 --> Language Class Initialized
INFO - 2019-11-02 09:49:34 --> Config Class Initialized
INFO - 2019-11-02 09:49:34 --> Loader Class Initialized
INFO - 2019-11-02 09:49:34 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:34 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:34 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:34 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:34 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:34 --> Controller Class Initialized
INFO - 2019-11-02 09:49:42 --> Config Class Initialized
INFO - 2019-11-02 09:49:42 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:49:42 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:49:42 --> Utf8 Class Initialized
INFO - 2019-11-02 09:49:42 --> URI Class Initialized
INFO - 2019-11-02 09:49:42 --> Router Class Initialized
INFO - 2019-11-02 09:49:42 --> Output Class Initialized
INFO - 2019-11-02 09:49:42 --> Security Class Initialized
DEBUG - 2019-11-02 09:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:49:42 --> Input Class Initialized
INFO - 2019-11-02 09:49:42 --> Language Class Initialized
INFO - 2019-11-02 09:49:42 --> Language Class Initialized
INFO - 2019-11-02 09:49:42 --> Config Class Initialized
INFO - 2019-11-02 09:49:42 --> Loader Class Initialized
INFO - 2019-11-02 09:49:42 --> Helper loaded: url_helper
INFO - 2019-11-02 09:49:42 --> Helper loaded: file_helper
INFO - 2019-11-02 09:49:42 --> Helper loaded: form_helper
INFO - 2019-11-02 09:49:42 --> Helper loaded: my_helper
INFO - 2019-11-02 09:49:42 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:49:42 --> Controller Class Initialized
DEBUG - 2019-11-02 09:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-11-02 09:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:49:42 --> Final output sent to browser
DEBUG - 2019-11-02 09:49:42 --> Total execution time: 0.0573
INFO - 2019-11-02 09:51:06 --> Config Class Initialized
INFO - 2019-11-02 09:51:06 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:51:06 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:51:06 --> Utf8 Class Initialized
INFO - 2019-11-02 09:51:06 --> URI Class Initialized
INFO - 2019-11-02 09:51:06 --> Router Class Initialized
INFO - 2019-11-02 09:51:06 --> Output Class Initialized
INFO - 2019-11-02 09:51:06 --> Security Class Initialized
DEBUG - 2019-11-02 09:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:51:06 --> Input Class Initialized
INFO - 2019-11-02 09:51:06 --> Language Class Initialized
INFO - 2019-11-02 09:51:06 --> Language Class Initialized
INFO - 2019-11-02 09:51:06 --> Config Class Initialized
INFO - 2019-11-02 09:51:06 --> Loader Class Initialized
INFO - 2019-11-02 09:51:06 --> Helper loaded: url_helper
INFO - 2019-11-02 09:51:06 --> Helper loaded: file_helper
INFO - 2019-11-02 09:51:06 --> Helper loaded: form_helper
INFO - 2019-11-02 09:51:06 --> Helper loaded: my_helper
INFO - 2019-11-02 09:51:06 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:51:06 --> Controller Class Initialized
INFO - 2019-11-02 09:51:06 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:51:06 --> Config Class Initialized
INFO - 2019-11-02 09:51:06 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:51:06 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:51:06 --> Utf8 Class Initialized
INFO - 2019-11-02 09:51:06 --> URI Class Initialized
INFO - 2019-11-02 09:51:06 --> Router Class Initialized
INFO - 2019-11-02 09:51:06 --> Output Class Initialized
INFO - 2019-11-02 09:51:06 --> Security Class Initialized
DEBUG - 2019-11-02 09:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:51:06 --> Input Class Initialized
INFO - 2019-11-02 09:51:06 --> Language Class Initialized
INFO - 2019-11-02 09:51:06 --> Language Class Initialized
INFO - 2019-11-02 09:51:06 --> Config Class Initialized
INFO - 2019-11-02 09:51:06 --> Loader Class Initialized
INFO - 2019-11-02 09:51:06 --> Helper loaded: url_helper
INFO - 2019-11-02 09:51:06 --> Helper loaded: file_helper
INFO - 2019-11-02 09:51:06 --> Helper loaded: form_helper
INFO - 2019-11-02 09:51:06 --> Helper loaded: my_helper
INFO - 2019-11-02 09:51:06 --> Database Driver Class Initialized
DEBUG - 2019-11-02 09:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-02 09:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-02 09:51:06 --> Controller Class Initialized
DEBUG - 2019-11-02 09:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-11-02 09:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-02 09:51:06 --> Final output sent to browser
DEBUG - 2019-11-02 09:51:06 --> Total execution time: 0.0538
