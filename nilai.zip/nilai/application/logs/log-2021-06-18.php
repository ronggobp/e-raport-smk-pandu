<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-18 03:20:00 --> Config Class Initialized
INFO - 2021-06-18 03:20:00 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:20:01 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:20:01 --> Utf8 Class Initialized
INFO - 2021-06-18 03:20:01 --> URI Class Initialized
DEBUG - 2021-06-18 03:20:01 --> No URI present. Default controller set.
INFO - 2021-06-18 03:20:01 --> Router Class Initialized
INFO - 2021-06-18 03:20:01 --> Output Class Initialized
INFO - 2021-06-18 03:20:01 --> Security Class Initialized
DEBUG - 2021-06-18 03:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:20:01 --> Input Class Initialized
INFO - 2021-06-18 03:20:01 --> Language Class Initialized
INFO - 2021-06-18 03:20:01 --> Language Class Initialized
INFO - 2021-06-18 03:20:01 --> Config Class Initialized
INFO - 2021-06-18 03:20:01 --> Loader Class Initialized
INFO - 2021-06-18 03:20:01 --> Helper loaded: url_helper
INFO - 2021-06-18 03:20:01 --> Helper loaded: file_helper
INFO - 2021-06-18 03:20:01 --> Helper loaded: form_helper
INFO - 2021-06-18 03:20:01 --> Helper loaded: my_helper
INFO - 2021-06-18 03:20:01 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:20:01 --> Controller Class Initialized
INFO - 2021-06-18 03:20:01 --> Config Class Initialized
INFO - 2021-06-18 03:20:01 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:20:01 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:20:01 --> Utf8 Class Initialized
INFO - 2021-06-18 03:20:01 --> URI Class Initialized
INFO - 2021-06-18 03:20:01 --> Router Class Initialized
INFO - 2021-06-18 03:20:01 --> Output Class Initialized
INFO - 2021-06-18 03:20:01 --> Security Class Initialized
DEBUG - 2021-06-18 03:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:20:01 --> Input Class Initialized
INFO - 2021-06-18 03:20:01 --> Language Class Initialized
INFO - 2021-06-18 03:20:01 --> Language Class Initialized
INFO - 2021-06-18 03:20:01 --> Config Class Initialized
INFO - 2021-06-18 03:20:01 --> Loader Class Initialized
INFO - 2021-06-18 03:20:01 --> Helper loaded: url_helper
INFO - 2021-06-18 03:20:01 --> Helper loaded: file_helper
INFO - 2021-06-18 03:20:01 --> Helper loaded: form_helper
INFO - 2021-06-18 03:20:01 --> Helper loaded: my_helper
INFO - 2021-06-18 03:20:01 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:20:01 --> Controller Class Initialized
DEBUG - 2021-06-18 03:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-18 03:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:20:01 --> Final output sent to browser
DEBUG - 2021-06-18 03:20:01 --> Total execution time: 0.0885
INFO - 2021-06-18 03:28:09 --> Config Class Initialized
INFO - 2021-06-18 03:28:09 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:09 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:09 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:09 --> URI Class Initialized
INFO - 2021-06-18 03:28:09 --> Router Class Initialized
INFO - 2021-06-18 03:28:09 --> Output Class Initialized
INFO - 2021-06-18 03:28:09 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:09 --> Input Class Initialized
INFO - 2021-06-18 03:28:09 --> Language Class Initialized
INFO - 2021-06-18 03:28:09 --> Language Class Initialized
INFO - 2021-06-18 03:28:09 --> Config Class Initialized
INFO - 2021-06-18 03:28:09 --> Loader Class Initialized
INFO - 2021-06-18 03:28:09 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:09 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:09 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:09 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:09 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:09 --> Controller Class Initialized
INFO - 2021-06-18 03:28:09 --> Helper loaded: cookie_helper
INFO - 2021-06-18 03:28:09 --> Final output sent to browser
DEBUG - 2021-06-18 03:28:09 --> Total execution time: 0.0912
INFO - 2021-06-18 03:28:10 --> Config Class Initialized
INFO - 2021-06-18 03:28:10 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:10 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:10 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:10 --> URI Class Initialized
INFO - 2021-06-18 03:28:10 --> Router Class Initialized
INFO - 2021-06-18 03:28:10 --> Output Class Initialized
INFO - 2021-06-18 03:28:10 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:10 --> Input Class Initialized
INFO - 2021-06-18 03:28:10 --> Language Class Initialized
INFO - 2021-06-18 03:28:10 --> Language Class Initialized
INFO - 2021-06-18 03:28:10 --> Config Class Initialized
INFO - 2021-06-18 03:28:10 --> Loader Class Initialized
INFO - 2021-06-18 03:28:10 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:10 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:10 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:10 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:10 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:10 --> Controller Class Initialized
DEBUG - 2021-06-18 03:28:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-18 03:28:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:28:10 --> Final output sent to browser
DEBUG - 2021-06-18 03:28:10 --> Total execution time: 0.2740
INFO - 2021-06-18 03:28:20 --> Config Class Initialized
INFO - 2021-06-18 03:28:20 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:20 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:20 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:20 --> URI Class Initialized
INFO - 2021-06-18 03:28:20 --> Router Class Initialized
INFO - 2021-06-18 03:28:20 --> Output Class Initialized
INFO - 2021-06-18 03:28:20 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:20 --> Input Class Initialized
INFO - 2021-06-18 03:28:20 --> Language Class Initialized
INFO - 2021-06-18 03:28:20 --> Language Class Initialized
INFO - 2021-06-18 03:28:20 --> Config Class Initialized
INFO - 2021-06-18 03:28:20 --> Loader Class Initialized
INFO - 2021-06-18 03:28:20 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:20 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:20 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:20 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:20 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:20 --> Controller Class Initialized
DEBUG - 2021-06-18 03:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-18 03:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:28:20 --> Final output sent to browser
DEBUG - 2021-06-18 03:28:20 --> Total execution time: 0.0900
INFO - 2021-06-18 03:28:22 --> Config Class Initialized
INFO - 2021-06-18 03:28:22 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:22 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:22 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:22 --> URI Class Initialized
INFO - 2021-06-18 03:28:22 --> Router Class Initialized
INFO - 2021-06-18 03:28:22 --> Output Class Initialized
INFO - 2021-06-18 03:28:22 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:22 --> Input Class Initialized
INFO - 2021-06-18 03:28:22 --> Language Class Initialized
INFO - 2021-06-18 03:28:22 --> Language Class Initialized
INFO - 2021-06-18 03:28:22 --> Config Class Initialized
INFO - 2021-06-18 03:28:22 --> Loader Class Initialized
INFO - 2021-06-18 03:28:22 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:22 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:22 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:22 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:22 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:22 --> Controller Class Initialized
DEBUG - 2021-06-18 03:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-18 03:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:28:22 --> Final output sent to browser
DEBUG - 2021-06-18 03:28:22 --> Total execution time: 0.0998
INFO - 2021-06-18 03:28:22 --> Config Class Initialized
INFO - 2021-06-18 03:28:22 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:22 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:22 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:22 --> URI Class Initialized
INFO - 2021-06-18 03:28:22 --> Router Class Initialized
INFO - 2021-06-18 03:28:22 --> Output Class Initialized
INFO - 2021-06-18 03:28:22 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:22 --> Input Class Initialized
INFO - 2021-06-18 03:28:22 --> Language Class Initialized
INFO - 2021-06-18 03:28:22 --> Language Class Initialized
INFO - 2021-06-18 03:28:22 --> Config Class Initialized
INFO - 2021-06-18 03:28:22 --> Loader Class Initialized
INFO - 2021-06-18 03:28:22 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:22 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:22 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:22 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:22 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:22 --> Controller Class Initialized
INFO - 2021-06-18 03:28:23 --> Config Class Initialized
INFO - 2021-06-18 03:28:23 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:23 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:23 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:23 --> URI Class Initialized
INFO - 2021-06-18 03:28:23 --> Router Class Initialized
INFO - 2021-06-18 03:28:23 --> Output Class Initialized
INFO - 2021-06-18 03:28:23 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:23 --> Input Class Initialized
INFO - 2021-06-18 03:28:23 --> Language Class Initialized
INFO - 2021-06-18 03:28:23 --> Language Class Initialized
INFO - 2021-06-18 03:28:23 --> Config Class Initialized
INFO - 2021-06-18 03:28:23 --> Loader Class Initialized
INFO - 2021-06-18 03:28:23 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:23 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:23 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:23 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:23 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:23 --> Controller Class Initialized
DEBUG - 2021-06-18 03:28:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:28:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:28:23 --> Final output sent to browser
DEBUG - 2021-06-18 03:28:23 --> Total execution time: 0.1081
INFO - 2021-06-18 03:28:24 --> Config Class Initialized
INFO - 2021-06-18 03:28:24 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:24 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:24 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:24 --> URI Class Initialized
INFO - 2021-06-18 03:28:24 --> Router Class Initialized
INFO - 2021-06-18 03:28:24 --> Output Class Initialized
INFO - 2021-06-18 03:28:24 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:24 --> Input Class Initialized
INFO - 2021-06-18 03:28:24 --> Language Class Initialized
INFO - 2021-06-18 03:28:24 --> Language Class Initialized
INFO - 2021-06-18 03:28:24 --> Config Class Initialized
INFO - 2021-06-18 03:28:24 --> Loader Class Initialized
INFO - 2021-06-18 03:28:24 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:24 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:24 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:24 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:24 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:24 --> Controller Class Initialized
INFO - 2021-06-18 03:28:24 --> Final output sent to browser
DEBUG - 2021-06-18 03:28:24 --> Total execution time: 0.0902
INFO - 2021-06-18 03:28:27 --> Config Class Initialized
INFO - 2021-06-18 03:28:27 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:27 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:27 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:27 --> URI Class Initialized
INFO - 2021-06-18 03:28:27 --> Router Class Initialized
INFO - 2021-06-18 03:28:27 --> Output Class Initialized
INFO - 2021-06-18 03:28:27 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:27 --> Input Class Initialized
INFO - 2021-06-18 03:28:27 --> Language Class Initialized
INFO - 2021-06-18 03:28:27 --> Language Class Initialized
INFO - 2021-06-18 03:28:27 --> Config Class Initialized
INFO - 2021-06-18 03:28:27 --> Loader Class Initialized
INFO - 2021-06-18 03:28:27 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:27 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:27 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:27 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:27 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:27 --> Controller Class Initialized
INFO - 2021-06-18 03:28:27 --> Final output sent to browser
DEBUG - 2021-06-18 03:28:27 --> Total execution time: 0.0709
INFO - 2021-06-18 03:28:36 --> Config Class Initialized
INFO - 2021-06-18 03:28:36 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:36 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:36 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:36 --> URI Class Initialized
INFO - 2021-06-18 03:28:36 --> Router Class Initialized
INFO - 2021-06-18 03:28:36 --> Output Class Initialized
INFO - 2021-06-18 03:28:36 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:36 --> Input Class Initialized
INFO - 2021-06-18 03:28:36 --> Language Class Initialized
INFO - 2021-06-18 03:28:36 --> Language Class Initialized
INFO - 2021-06-18 03:28:36 --> Config Class Initialized
INFO - 2021-06-18 03:28:36 --> Loader Class Initialized
INFO - 2021-06-18 03:28:36 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:36 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:36 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:36 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:36 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:36 --> Controller Class Initialized
INFO - 2021-06-18 03:28:38 --> Config Class Initialized
INFO - 2021-06-18 03:28:38 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:28:38 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:28:38 --> Utf8 Class Initialized
INFO - 2021-06-18 03:28:38 --> URI Class Initialized
INFO - 2021-06-18 03:28:38 --> Router Class Initialized
INFO - 2021-06-18 03:28:38 --> Output Class Initialized
INFO - 2021-06-18 03:28:38 --> Security Class Initialized
DEBUG - 2021-06-18 03:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:28:38 --> Input Class Initialized
INFO - 2021-06-18 03:28:38 --> Language Class Initialized
INFO - 2021-06-18 03:28:38 --> Language Class Initialized
INFO - 2021-06-18 03:28:38 --> Config Class Initialized
INFO - 2021-06-18 03:28:38 --> Loader Class Initialized
INFO - 2021-06-18 03:28:38 --> Helper loaded: url_helper
INFO - 2021-06-18 03:28:38 --> Helper loaded: file_helper
INFO - 2021-06-18 03:28:38 --> Helper loaded: form_helper
INFO - 2021-06-18 03:28:38 --> Helper loaded: my_helper
INFO - 2021-06-18 03:28:38 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:28:38 --> Controller Class Initialized
INFO - 2021-06-18 03:39:52 --> Config Class Initialized
INFO - 2021-06-18 03:39:52 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:39:52 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:39:52 --> Utf8 Class Initialized
INFO - 2021-06-18 03:39:52 --> URI Class Initialized
INFO - 2021-06-18 03:39:52 --> Router Class Initialized
INFO - 2021-06-18 03:39:52 --> Output Class Initialized
INFO - 2021-06-18 03:39:52 --> Security Class Initialized
DEBUG - 2021-06-18 03:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:39:52 --> Input Class Initialized
INFO - 2021-06-18 03:39:52 --> Language Class Initialized
INFO - 2021-06-18 03:39:52 --> Language Class Initialized
INFO - 2021-06-18 03:39:52 --> Config Class Initialized
INFO - 2021-06-18 03:39:52 --> Loader Class Initialized
INFO - 2021-06-18 03:39:52 --> Helper loaded: url_helper
INFO - 2021-06-18 03:39:52 --> Helper loaded: file_helper
INFO - 2021-06-18 03:39:52 --> Helper loaded: form_helper
INFO - 2021-06-18 03:39:52 --> Helper loaded: my_helper
INFO - 2021-06-18 03:39:52 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:39:52 --> Controller Class Initialized
DEBUG - 2021-06-18 03:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-18 03:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:39:52 --> Final output sent to browser
DEBUG - 2021-06-18 03:39:52 --> Total execution time: 0.0498
INFO - 2021-06-18 03:40:22 --> Config Class Initialized
INFO - 2021-06-18 03:40:22 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:40:22 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:40:22 --> Utf8 Class Initialized
INFO - 2021-06-18 03:40:22 --> URI Class Initialized
INFO - 2021-06-18 03:40:22 --> Router Class Initialized
INFO - 2021-06-18 03:40:22 --> Output Class Initialized
INFO - 2021-06-18 03:40:22 --> Security Class Initialized
DEBUG - 2021-06-18 03:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:40:22 --> Input Class Initialized
INFO - 2021-06-18 03:40:22 --> Language Class Initialized
INFO - 2021-06-18 03:40:22 --> Language Class Initialized
INFO - 2021-06-18 03:40:22 --> Config Class Initialized
INFO - 2021-06-18 03:40:22 --> Loader Class Initialized
INFO - 2021-06-18 03:40:22 --> Helper loaded: url_helper
INFO - 2021-06-18 03:40:22 --> Helper loaded: file_helper
INFO - 2021-06-18 03:40:22 --> Helper loaded: form_helper
INFO - 2021-06-18 03:40:22 --> Helper loaded: my_helper
INFO - 2021-06-18 03:40:22 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:40:22 --> Controller Class Initialized
INFO - 2021-06-18 03:40:22 --> Helper loaded: cookie_helper
INFO - 2021-06-18 03:40:22 --> Final output sent to browser
DEBUG - 2021-06-18 03:40:22 --> Total execution time: 0.0494
INFO - 2021-06-18 03:40:40 --> Config Class Initialized
INFO - 2021-06-18 03:40:40 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:40:40 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:40:40 --> Utf8 Class Initialized
INFO - 2021-06-18 03:40:40 --> URI Class Initialized
INFO - 2021-06-18 03:40:40 --> Router Class Initialized
INFO - 2021-06-18 03:40:40 --> Output Class Initialized
INFO - 2021-06-18 03:40:40 --> Security Class Initialized
DEBUG - 2021-06-18 03:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:40:40 --> Input Class Initialized
INFO - 2021-06-18 03:40:40 --> Language Class Initialized
INFO - 2021-06-18 03:40:40 --> Language Class Initialized
INFO - 2021-06-18 03:40:40 --> Config Class Initialized
INFO - 2021-06-18 03:40:40 --> Loader Class Initialized
INFO - 2021-06-18 03:40:40 --> Helper loaded: url_helper
INFO - 2021-06-18 03:40:40 --> Helper loaded: file_helper
INFO - 2021-06-18 03:40:40 --> Helper loaded: form_helper
INFO - 2021-06-18 03:40:40 --> Helper loaded: my_helper
INFO - 2021-06-18 03:40:40 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:40:40 --> Controller Class Initialized
DEBUG - 2021-06-18 03:40:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-18 03:40:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:40:40 --> Final output sent to browser
DEBUG - 2021-06-18 03:40:40 --> Total execution time: 0.1938
INFO - 2021-06-18 03:41:03 --> Config Class Initialized
INFO - 2021-06-18 03:41:03 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:41:03 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:41:03 --> Utf8 Class Initialized
INFO - 2021-06-18 03:41:03 --> URI Class Initialized
INFO - 2021-06-18 03:41:03 --> Router Class Initialized
INFO - 2021-06-18 03:41:03 --> Output Class Initialized
INFO - 2021-06-18 03:41:03 --> Security Class Initialized
DEBUG - 2021-06-18 03:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:41:03 --> Input Class Initialized
INFO - 2021-06-18 03:41:03 --> Language Class Initialized
INFO - 2021-06-18 03:41:03 --> Language Class Initialized
INFO - 2021-06-18 03:41:03 --> Config Class Initialized
INFO - 2021-06-18 03:41:03 --> Loader Class Initialized
INFO - 2021-06-18 03:41:03 --> Helper loaded: url_helper
INFO - 2021-06-18 03:41:03 --> Helper loaded: file_helper
INFO - 2021-06-18 03:41:03 --> Helper loaded: form_helper
INFO - 2021-06-18 03:41:03 --> Helper loaded: my_helper
INFO - 2021-06-18 03:41:03 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:41:03 --> Controller Class Initialized
DEBUG - 2021-06-18 03:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-18 03:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:41:03 --> Final output sent to browser
DEBUG - 2021-06-18 03:41:03 --> Total execution time: 0.0502
INFO - 2021-06-18 03:41:36 --> Config Class Initialized
INFO - 2021-06-18 03:41:36 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:41:36 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:41:36 --> Utf8 Class Initialized
INFO - 2021-06-18 03:41:36 --> URI Class Initialized
INFO - 2021-06-18 03:41:36 --> Router Class Initialized
INFO - 2021-06-18 03:41:36 --> Output Class Initialized
INFO - 2021-06-18 03:41:36 --> Security Class Initialized
DEBUG - 2021-06-18 03:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:41:36 --> Input Class Initialized
INFO - 2021-06-18 03:41:36 --> Language Class Initialized
INFO - 2021-06-18 03:41:36 --> Language Class Initialized
INFO - 2021-06-18 03:41:36 --> Config Class Initialized
INFO - 2021-06-18 03:41:36 --> Loader Class Initialized
INFO - 2021-06-18 03:41:36 --> Helper loaded: url_helper
INFO - 2021-06-18 03:41:36 --> Helper loaded: file_helper
INFO - 2021-06-18 03:41:36 --> Helper loaded: form_helper
INFO - 2021-06-18 03:41:36 --> Helper loaded: my_helper
INFO - 2021-06-18 03:41:36 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:41:36 --> Controller Class Initialized
DEBUG - 2021-06-18 03:41:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-18 03:41:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:41:36 --> Final output sent to browser
DEBUG - 2021-06-18 03:41:36 --> Total execution time: 0.0505
INFO - 2021-06-18 03:41:45 --> Config Class Initialized
INFO - 2021-06-18 03:41:45 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:41:45 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:41:45 --> Utf8 Class Initialized
INFO - 2021-06-18 03:41:45 --> URI Class Initialized
INFO - 2021-06-18 03:41:45 --> Router Class Initialized
INFO - 2021-06-18 03:41:45 --> Output Class Initialized
INFO - 2021-06-18 03:41:45 --> Security Class Initialized
DEBUG - 2021-06-18 03:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:41:45 --> Input Class Initialized
INFO - 2021-06-18 03:41:45 --> Language Class Initialized
INFO - 2021-06-18 03:41:45 --> Language Class Initialized
INFO - 2021-06-18 03:41:45 --> Config Class Initialized
INFO - 2021-06-18 03:41:45 --> Loader Class Initialized
INFO - 2021-06-18 03:41:45 --> Helper loaded: url_helper
INFO - 2021-06-18 03:41:45 --> Helper loaded: file_helper
INFO - 2021-06-18 03:41:45 --> Helper loaded: form_helper
INFO - 2021-06-18 03:41:45 --> Helper loaded: my_helper
INFO - 2021-06-18 03:41:45 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:41:45 --> Controller Class Initialized
DEBUG - 2021-06-18 03:41:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:41:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:41:45 --> Final output sent to browser
DEBUG - 2021-06-18 03:41:45 --> Total execution time: 0.0497
INFO - 2021-06-18 03:41:48 --> Config Class Initialized
INFO - 2021-06-18 03:41:48 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:41:48 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:41:48 --> Utf8 Class Initialized
INFO - 2021-06-18 03:41:48 --> URI Class Initialized
INFO - 2021-06-18 03:41:48 --> Router Class Initialized
INFO - 2021-06-18 03:41:48 --> Output Class Initialized
INFO - 2021-06-18 03:41:48 --> Security Class Initialized
DEBUG - 2021-06-18 03:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:41:48 --> Input Class Initialized
INFO - 2021-06-18 03:41:48 --> Language Class Initialized
INFO - 2021-06-18 03:41:48 --> Language Class Initialized
INFO - 2021-06-18 03:41:48 --> Config Class Initialized
INFO - 2021-06-18 03:41:48 --> Loader Class Initialized
INFO - 2021-06-18 03:41:48 --> Helper loaded: url_helper
INFO - 2021-06-18 03:41:48 --> Helper loaded: file_helper
INFO - 2021-06-18 03:41:48 --> Helper loaded: form_helper
INFO - 2021-06-18 03:41:48 --> Helper loaded: my_helper
INFO - 2021-06-18 03:41:48 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:41:48 --> Controller Class Initialized
INFO - 2021-06-18 03:43:45 --> Config Class Initialized
INFO - 2021-06-18 03:43:45 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:43:45 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:43:45 --> Utf8 Class Initialized
INFO - 2021-06-18 03:43:45 --> URI Class Initialized
INFO - 2021-06-18 03:43:45 --> Router Class Initialized
INFO - 2021-06-18 03:43:45 --> Output Class Initialized
INFO - 2021-06-18 03:43:45 --> Security Class Initialized
DEBUG - 2021-06-18 03:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:43:45 --> Input Class Initialized
INFO - 2021-06-18 03:43:45 --> Language Class Initialized
INFO - 2021-06-18 03:43:45 --> Language Class Initialized
INFO - 2021-06-18 03:43:45 --> Config Class Initialized
INFO - 2021-06-18 03:43:45 --> Loader Class Initialized
INFO - 2021-06-18 03:43:45 --> Helper loaded: url_helper
INFO - 2021-06-18 03:43:45 --> Helper loaded: file_helper
INFO - 2021-06-18 03:43:45 --> Helper loaded: form_helper
INFO - 2021-06-18 03:43:45 --> Helper loaded: my_helper
INFO - 2021-06-18 03:43:45 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:43:45 --> Controller Class Initialized
INFO - 2021-06-18 03:43:45 --> Final output sent to browser
DEBUG - 2021-06-18 03:43:45 --> Total execution time: 0.0596
INFO - 2021-06-18 03:45:27 --> Config Class Initialized
INFO - 2021-06-18 03:45:27 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:45:27 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:45:27 --> Utf8 Class Initialized
INFO - 2021-06-18 03:45:27 --> URI Class Initialized
INFO - 2021-06-18 03:45:27 --> Router Class Initialized
INFO - 2021-06-18 03:45:27 --> Output Class Initialized
INFO - 2021-06-18 03:45:27 --> Security Class Initialized
DEBUG - 2021-06-18 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:45:27 --> Input Class Initialized
INFO - 2021-06-18 03:45:27 --> Language Class Initialized
INFO - 2021-06-18 03:45:27 --> Language Class Initialized
INFO - 2021-06-18 03:45:27 --> Config Class Initialized
INFO - 2021-06-18 03:45:27 --> Loader Class Initialized
INFO - 2021-06-18 03:45:27 --> Helper loaded: url_helper
INFO - 2021-06-18 03:45:27 --> Helper loaded: file_helper
INFO - 2021-06-18 03:45:27 --> Helper loaded: form_helper
INFO - 2021-06-18 03:45:27 --> Helper loaded: my_helper
INFO - 2021-06-18 03:45:27 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:45:27 --> Controller Class Initialized
INFO - 2021-06-18 03:45:27 --> Final output sent to browser
DEBUG - 2021-06-18 03:45:27 --> Total execution time: 0.0495
INFO - 2021-06-18 03:45:27 --> Config Class Initialized
INFO - 2021-06-18 03:45:27 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:45:27 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:45:27 --> Utf8 Class Initialized
INFO - 2021-06-18 03:45:27 --> URI Class Initialized
INFO - 2021-06-18 03:45:27 --> Router Class Initialized
INFO - 2021-06-18 03:45:27 --> Output Class Initialized
INFO - 2021-06-18 03:45:27 --> Security Class Initialized
DEBUG - 2021-06-18 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:45:27 --> Input Class Initialized
INFO - 2021-06-18 03:45:27 --> Language Class Initialized
INFO - 2021-06-18 03:45:27 --> Language Class Initialized
INFO - 2021-06-18 03:45:27 --> Config Class Initialized
INFO - 2021-06-18 03:45:27 --> Loader Class Initialized
INFO - 2021-06-18 03:45:27 --> Helper loaded: url_helper
INFO - 2021-06-18 03:45:27 --> Helper loaded: file_helper
INFO - 2021-06-18 03:45:27 --> Helper loaded: form_helper
INFO - 2021-06-18 03:45:27 --> Helper loaded: my_helper
INFO - 2021-06-18 03:45:27 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:45:27 --> Controller Class Initialized
INFO - 2021-06-18 03:45:31 --> Config Class Initialized
INFO - 2021-06-18 03:45:31 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:45:31 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:45:31 --> Utf8 Class Initialized
INFO - 2021-06-18 03:45:31 --> URI Class Initialized
INFO - 2021-06-18 03:45:31 --> Router Class Initialized
INFO - 2021-06-18 03:45:31 --> Output Class Initialized
INFO - 2021-06-18 03:45:31 --> Security Class Initialized
DEBUG - 2021-06-18 03:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:45:31 --> Input Class Initialized
INFO - 2021-06-18 03:45:31 --> Language Class Initialized
INFO - 2021-06-18 03:45:31 --> Language Class Initialized
INFO - 2021-06-18 03:45:31 --> Config Class Initialized
INFO - 2021-06-18 03:45:31 --> Loader Class Initialized
INFO - 2021-06-18 03:45:31 --> Helper loaded: url_helper
INFO - 2021-06-18 03:45:31 --> Helper loaded: file_helper
INFO - 2021-06-18 03:45:31 --> Helper loaded: form_helper
INFO - 2021-06-18 03:45:31 --> Helper loaded: my_helper
INFO - 2021-06-18 03:45:31 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:45:31 --> Controller Class Initialized
INFO - 2021-06-18 03:45:31 --> Final output sent to browser
DEBUG - 2021-06-18 03:45:31 --> Total execution time: 0.0482
INFO - 2021-06-18 03:45:34 --> Config Class Initialized
INFO - 2021-06-18 03:45:34 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:45:34 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:45:34 --> Utf8 Class Initialized
INFO - 2021-06-18 03:45:34 --> URI Class Initialized
INFO - 2021-06-18 03:45:34 --> Router Class Initialized
INFO - 2021-06-18 03:45:34 --> Output Class Initialized
INFO - 2021-06-18 03:45:34 --> Security Class Initialized
DEBUG - 2021-06-18 03:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:45:34 --> Input Class Initialized
INFO - 2021-06-18 03:45:34 --> Language Class Initialized
INFO - 2021-06-18 03:45:34 --> Language Class Initialized
INFO - 2021-06-18 03:45:34 --> Config Class Initialized
INFO - 2021-06-18 03:45:34 --> Loader Class Initialized
INFO - 2021-06-18 03:45:34 --> Helper loaded: url_helper
INFO - 2021-06-18 03:45:34 --> Helper loaded: file_helper
INFO - 2021-06-18 03:45:34 --> Helper loaded: form_helper
INFO - 2021-06-18 03:45:34 --> Helper loaded: my_helper
INFO - 2021-06-18 03:45:34 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:45:34 --> Controller Class Initialized
INFO - 2021-06-18 03:45:34 --> Final output sent to browser
DEBUG - 2021-06-18 03:45:34 --> Total execution time: 0.0471
INFO - 2021-06-18 03:46:13 --> Config Class Initialized
INFO - 2021-06-18 03:46:13 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:46:13 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:46:13 --> Utf8 Class Initialized
INFO - 2021-06-18 03:46:13 --> URI Class Initialized
INFO - 2021-06-18 03:46:13 --> Router Class Initialized
INFO - 2021-06-18 03:46:13 --> Output Class Initialized
INFO - 2021-06-18 03:46:13 --> Security Class Initialized
DEBUG - 2021-06-18 03:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:46:13 --> Input Class Initialized
INFO - 2021-06-18 03:46:13 --> Language Class Initialized
INFO - 2021-06-18 03:46:13 --> Language Class Initialized
INFO - 2021-06-18 03:46:13 --> Config Class Initialized
INFO - 2021-06-18 03:46:13 --> Loader Class Initialized
INFO - 2021-06-18 03:46:13 --> Helper loaded: url_helper
INFO - 2021-06-18 03:46:13 --> Helper loaded: file_helper
INFO - 2021-06-18 03:46:13 --> Helper loaded: form_helper
INFO - 2021-06-18 03:46:13 --> Helper loaded: my_helper
INFO - 2021-06-18 03:46:13 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:46:13 --> Controller Class Initialized
INFO - 2021-06-18 03:46:13 --> Final output sent to browser
DEBUG - 2021-06-18 03:46:13 --> Total execution time: 0.0483
INFO - 2021-06-18 03:46:13 --> Config Class Initialized
INFO - 2021-06-18 03:46:13 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:46:13 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:46:13 --> Utf8 Class Initialized
INFO - 2021-06-18 03:46:13 --> URI Class Initialized
INFO - 2021-06-18 03:46:13 --> Router Class Initialized
INFO - 2021-06-18 03:46:13 --> Output Class Initialized
INFO - 2021-06-18 03:46:13 --> Security Class Initialized
DEBUG - 2021-06-18 03:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:46:13 --> Input Class Initialized
INFO - 2021-06-18 03:46:13 --> Language Class Initialized
INFO - 2021-06-18 03:46:13 --> Language Class Initialized
INFO - 2021-06-18 03:46:13 --> Config Class Initialized
INFO - 2021-06-18 03:46:13 --> Loader Class Initialized
INFO - 2021-06-18 03:46:13 --> Helper loaded: url_helper
INFO - 2021-06-18 03:46:13 --> Helper loaded: file_helper
INFO - 2021-06-18 03:46:13 --> Helper loaded: form_helper
INFO - 2021-06-18 03:46:13 --> Helper loaded: my_helper
INFO - 2021-06-18 03:46:13 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:46:13 --> Controller Class Initialized
INFO - 2021-06-18 03:46:21 --> Config Class Initialized
INFO - 2021-06-18 03:46:21 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:46:21 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:46:21 --> Utf8 Class Initialized
INFO - 2021-06-18 03:46:21 --> URI Class Initialized
INFO - 2021-06-18 03:46:21 --> Router Class Initialized
INFO - 2021-06-18 03:46:21 --> Output Class Initialized
INFO - 2021-06-18 03:46:21 --> Security Class Initialized
DEBUG - 2021-06-18 03:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:46:21 --> Input Class Initialized
INFO - 2021-06-18 03:46:21 --> Language Class Initialized
INFO - 2021-06-18 03:46:21 --> Language Class Initialized
INFO - 2021-06-18 03:46:21 --> Config Class Initialized
INFO - 2021-06-18 03:46:21 --> Loader Class Initialized
INFO - 2021-06-18 03:46:21 --> Helper loaded: url_helper
INFO - 2021-06-18 03:46:21 --> Helper loaded: file_helper
INFO - 2021-06-18 03:46:21 --> Helper loaded: form_helper
INFO - 2021-06-18 03:46:21 --> Helper loaded: my_helper
INFO - 2021-06-18 03:46:21 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:46:21 --> Controller Class Initialized
INFO - 2021-06-18 03:46:21 --> Final output sent to browser
DEBUG - 2021-06-18 03:46:21 --> Total execution time: 0.0470
INFO - 2021-06-18 03:47:16 --> Config Class Initialized
INFO - 2021-06-18 03:47:16 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:47:16 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:47:16 --> Utf8 Class Initialized
INFO - 2021-06-18 03:47:16 --> URI Class Initialized
INFO - 2021-06-18 03:47:16 --> Router Class Initialized
INFO - 2021-06-18 03:47:16 --> Output Class Initialized
INFO - 2021-06-18 03:47:16 --> Security Class Initialized
DEBUG - 2021-06-18 03:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:47:16 --> Input Class Initialized
INFO - 2021-06-18 03:47:16 --> Language Class Initialized
INFO - 2021-06-18 03:47:16 --> Language Class Initialized
INFO - 2021-06-18 03:47:16 --> Config Class Initialized
INFO - 2021-06-18 03:47:16 --> Loader Class Initialized
INFO - 2021-06-18 03:47:16 --> Helper loaded: url_helper
INFO - 2021-06-18 03:47:16 --> Helper loaded: file_helper
INFO - 2021-06-18 03:47:16 --> Helper loaded: form_helper
INFO - 2021-06-18 03:47:16 --> Helper loaded: my_helper
INFO - 2021-06-18 03:47:16 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:47:16 --> Controller Class Initialized
INFO - 2021-06-18 03:47:16 --> Final output sent to browser
DEBUG - 2021-06-18 03:47:16 --> Total execution time: 0.0494
INFO - 2021-06-18 03:47:16 --> Config Class Initialized
INFO - 2021-06-18 03:47:16 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:47:16 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:47:16 --> Utf8 Class Initialized
INFO - 2021-06-18 03:47:16 --> URI Class Initialized
INFO - 2021-06-18 03:47:16 --> Router Class Initialized
INFO - 2021-06-18 03:47:16 --> Output Class Initialized
INFO - 2021-06-18 03:47:16 --> Security Class Initialized
DEBUG - 2021-06-18 03:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:47:16 --> Input Class Initialized
INFO - 2021-06-18 03:47:16 --> Language Class Initialized
INFO - 2021-06-18 03:47:16 --> Language Class Initialized
INFO - 2021-06-18 03:47:16 --> Config Class Initialized
INFO - 2021-06-18 03:47:16 --> Loader Class Initialized
INFO - 2021-06-18 03:47:16 --> Helper loaded: url_helper
INFO - 2021-06-18 03:47:16 --> Helper loaded: file_helper
INFO - 2021-06-18 03:47:16 --> Helper loaded: form_helper
INFO - 2021-06-18 03:47:16 --> Helper loaded: my_helper
INFO - 2021-06-18 03:47:16 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:47:16 --> Controller Class Initialized
INFO - 2021-06-18 03:47:18 --> Config Class Initialized
INFO - 2021-06-18 03:47:18 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:47:18 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:47:18 --> Utf8 Class Initialized
INFO - 2021-06-18 03:47:18 --> URI Class Initialized
INFO - 2021-06-18 03:47:18 --> Router Class Initialized
INFO - 2021-06-18 03:47:18 --> Output Class Initialized
INFO - 2021-06-18 03:47:18 --> Security Class Initialized
DEBUG - 2021-06-18 03:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:47:18 --> Input Class Initialized
INFO - 2021-06-18 03:47:18 --> Language Class Initialized
INFO - 2021-06-18 03:47:18 --> Language Class Initialized
INFO - 2021-06-18 03:47:18 --> Config Class Initialized
INFO - 2021-06-18 03:47:18 --> Loader Class Initialized
INFO - 2021-06-18 03:47:18 --> Helper loaded: url_helper
INFO - 2021-06-18 03:47:18 --> Helper loaded: file_helper
INFO - 2021-06-18 03:47:18 --> Helper loaded: form_helper
INFO - 2021-06-18 03:47:18 --> Helper loaded: my_helper
INFO - 2021-06-18 03:47:18 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:47:18 --> Controller Class Initialized
INFO - 2021-06-18 03:47:18 --> Final output sent to browser
DEBUG - 2021-06-18 03:47:18 --> Total execution time: 0.0461
INFO - 2021-06-18 03:47:56 --> Config Class Initialized
INFO - 2021-06-18 03:47:56 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:47:56 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:47:56 --> Utf8 Class Initialized
INFO - 2021-06-18 03:47:56 --> URI Class Initialized
INFO - 2021-06-18 03:47:56 --> Router Class Initialized
INFO - 2021-06-18 03:47:56 --> Output Class Initialized
INFO - 2021-06-18 03:47:56 --> Security Class Initialized
DEBUG - 2021-06-18 03:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:47:56 --> Input Class Initialized
INFO - 2021-06-18 03:47:56 --> Language Class Initialized
INFO - 2021-06-18 03:47:56 --> Language Class Initialized
INFO - 2021-06-18 03:47:56 --> Config Class Initialized
INFO - 2021-06-18 03:47:56 --> Loader Class Initialized
INFO - 2021-06-18 03:47:56 --> Helper loaded: url_helper
INFO - 2021-06-18 03:47:56 --> Helper loaded: file_helper
INFO - 2021-06-18 03:47:56 --> Helper loaded: form_helper
INFO - 2021-06-18 03:47:56 --> Helper loaded: my_helper
INFO - 2021-06-18 03:47:56 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:47:56 --> Controller Class Initialized
INFO - 2021-06-18 03:47:56 --> Final output sent to browser
DEBUG - 2021-06-18 03:47:56 --> Total execution time: 0.0478
INFO - 2021-06-18 03:47:56 --> Config Class Initialized
INFO - 2021-06-18 03:47:56 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:47:56 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:47:56 --> Utf8 Class Initialized
INFO - 2021-06-18 03:47:56 --> URI Class Initialized
INFO - 2021-06-18 03:47:56 --> Router Class Initialized
INFO - 2021-06-18 03:47:56 --> Output Class Initialized
INFO - 2021-06-18 03:47:56 --> Security Class Initialized
DEBUG - 2021-06-18 03:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:47:56 --> Input Class Initialized
INFO - 2021-06-18 03:47:56 --> Language Class Initialized
INFO - 2021-06-18 03:47:56 --> Language Class Initialized
INFO - 2021-06-18 03:47:56 --> Config Class Initialized
INFO - 2021-06-18 03:47:56 --> Loader Class Initialized
INFO - 2021-06-18 03:47:56 --> Helper loaded: url_helper
INFO - 2021-06-18 03:47:56 --> Helper loaded: file_helper
INFO - 2021-06-18 03:47:56 --> Helper loaded: form_helper
INFO - 2021-06-18 03:47:56 --> Helper loaded: my_helper
INFO - 2021-06-18 03:47:56 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:47:56 --> Controller Class Initialized
INFO - 2021-06-18 03:48:05 --> Config Class Initialized
INFO - 2021-06-18 03:48:05 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:48:05 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:48:05 --> Utf8 Class Initialized
INFO - 2021-06-18 03:48:05 --> URI Class Initialized
INFO - 2021-06-18 03:48:05 --> Router Class Initialized
INFO - 2021-06-18 03:48:05 --> Output Class Initialized
INFO - 2021-06-18 03:48:05 --> Security Class Initialized
DEBUG - 2021-06-18 03:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:48:05 --> Input Class Initialized
INFO - 2021-06-18 03:48:05 --> Language Class Initialized
INFO - 2021-06-18 03:48:05 --> Language Class Initialized
INFO - 2021-06-18 03:48:05 --> Config Class Initialized
INFO - 2021-06-18 03:48:05 --> Loader Class Initialized
INFO - 2021-06-18 03:48:05 --> Helper loaded: url_helper
INFO - 2021-06-18 03:48:05 --> Helper loaded: file_helper
INFO - 2021-06-18 03:48:05 --> Helper loaded: form_helper
INFO - 2021-06-18 03:48:05 --> Helper loaded: my_helper
INFO - 2021-06-18 03:48:05 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:48:05 --> Controller Class Initialized
INFO - 2021-06-18 03:48:05 --> Final output sent to browser
DEBUG - 2021-06-18 03:48:05 --> Total execution time: 0.0472
INFO - 2021-06-18 03:48:56 --> Config Class Initialized
INFO - 2021-06-18 03:48:56 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:48:56 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:48:56 --> Utf8 Class Initialized
INFO - 2021-06-18 03:48:56 --> URI Class Initialized
INFO - 2021-06-18 03:48:56 --> Router Class Initialized
INFO - 2021-06-18 03:48:56 --> Output Class Initialized
INFO - 2021-06-18 03:48:56 --> Security Class Initialized
DEBUG - 2021-06-18 03:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:48:56 --> Input Class Initialized
INFO - 2021-06-18 03:48:56 --> Language Class Initialized
INFO - 2021-06-18 03:48:56 --> Language Class Initialized
INFO - 2021-06-18 03:48:56 --> Config Class Initialized
INFO - 2021-06-18 03:48:56 --> Loader Class Initialized
INFO - 2021-06-18 03:48:56 --> Helper loaded: url_helper
INFO - 2021-06-18 03:48:56 --> Helper loaded: file_helper
INFO - 2021-06-18 03:48:56 --> Helper loaded: form_helper
INFO - 2021-06-18 03:48:56 --> Helper loaded: my_helper
INFO - 2021-06-18 03:48:56 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:48:56 --> Controller Class Initialized
INFO - 2021-06-18 03:48:56 --> Final output sent to browser
DEBUG - 2021-06-18 03:48:56 --> Total execution time: 0.0492
INFO - 2021-06-18 03:48:56 --> Config Class Initialized
INFO - 2021-06-18 03:48:56 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:48:56 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:48:56 --> Utf8 Class Initialized
INFO - 2021-06-18 03:48:56 --> URI Class Initialized
INFO - 2021-06-18 03:48:56 --> Router Class Initialized
INFO - 2021-06-18 03:48:56 --> Output Class Initialized
INFO - 2021-06-18 03:48:56 --> Security Class Initialized
DEBUG - 2021-06-18 03:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:48:56 --> Input Class Initialized
INFO - 2021-06-18 03:48:56 --> Language Class Initialized
INFO - 2021-06-18 03:48:56 --> Language Class Initialized
INFO - 2021-06-18 03:48:56 --> Config Class Initialized
INFO - 2021-06-18 03:48:56 --> Loader Class Initialized
INFO - 2021-06-18 03:48:56 --> Helper loaded: url_helper
INFO - 2021-06-18 03:48:56 --> Helper loaded: file_helper
INFO - 2021-06-18 03:48:56 --> Helper loaded: form_helper
INFO - 2021-06-18 03:48:56 --> Helper loaded: my_helper
INFO - 2021-06-18 03:48:56 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:48:56 --> Controller Class Initialized
INFO - 2021-06-18 03:50:06 --> Config Class Initialized
INFO - 2021-06-18 03:50:06 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:50:06 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:50:06 --> Utf8 Class Initialized
INFO - 2021-06-18 03:50:06 --> URI Class Initialized
INFO - 2021-06-18 03:50:06 --> Router Class Initialized
INFO - 2021-06-18 03:50:06 --> Output Class Initialized
INFO - 2021-06-18 03:50:06 --> Security Class Initialized
DEBUG - 2021-06-18 03:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:50:06 --> Input Class Initialized
INFO - 2021-06-18 03:50:06 --> Language Class Initialized
INFO - 2021-06-18 03:50:06 --> Language Class Initialized
INFO - 2021-06-18 03:50:06 --> Config Class Initialized
INFO - 2021-06-18 03:50:06 --> Loader Class Initialized
INFO - 2021-06-18 03:50:06 --> Helper loaded: url_helper
INFO - 2021-06-18 03:50:06 --> Helper loaded: file_helper
INFO - 2021-06-18 03:50:06 --> Helper loaded: form_helper
INFO - 2021-06-18 03:50:06 --> Helper loaded: my_helper
INFO - 2021-06-18 03:50:06 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:50:06 --> Controller Class Initialized
INFO - 2021-06-18 03:50:06 --> Final output sent to browser
DEBUG - 2021-06-18 03:50:06 --> Total execution time: 0.0573
INFO - 2021-06-18 03:50:53 --> Config Class Initialized
INFO - 2021-06-18 03:50:53 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:50:53 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:50:53 --> Utf8 Class Initialized
INFO - 2021-06-18 03:50:53 --> URI Class Initialized
INFO - 2021-06-18 03:50:53 --> Router Class Initialized
INFO - 2021-06-18 03:50:53 --> Output Class Initialized
INFO - 2021-06-18 03:50:53 --> Security Class Initialized
DEBUG - 2021-06-18 03:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:50:53 --> Input Class Initialized
INFO - 2021-06-18 03:50:53 --> Language Class Initialized
INFO - 2021-06-18 03:50:53 --> Language Class Initialized
INFO - 2021-06-18 03:50:53 --> Config Class Initialized
INFO - 2021-06-18 03:50:53 --> Loader Class Initialized
INFO - 2021-06-18 03:50:53 --> Helper loaded: url_helper
INFO - 2021-06-18 03:50:53 --> Helper loaded: file_helper
INFO - 2021-06-18 03:50:53 --> Helper loaded: form_helper
INFO - 2021-06-18 03:50:53 --> Helper loaded: my_helper
INFO - 2021-06-18 03:50:53 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:50:53 --> Controller Class Initialized
INFO - 2021-06-18 03:50:53 --> Final output sent to browser
DEBUG - 2021-06-18 03:50:53 --> Total execution time: 0.0491
INFO - 2021-06-18 03:50:53 --> Config Class Initialized
INFO - 2021-06-18 03:50:53 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:50:53 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:50:53 --> Utf8 Class Initialized
INFO - 2021-06-18 03:50:53 --> URI Class Initialized
INFO - 2021-06-18 03:50:53 --> Router Class Initialized
INFO - 2021-06-18 03:50:53 --> Output Class Initialized
INFO - 2021-06-18 03:50:53 --> Security Class Initialized
DEBUG - 2021-06-18 03:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:50:53 --> Input Class Initialized
INFO - 2021-06-18 03:50:53 --> Language Class Initialized
INFO - 2021-06-18 03:50:53 --> Language Class Initialized
INFO - 2021-06-18 03:50:53 --> Config Class Initialized
INFO - 2021-06-18 03:50:53 --> Loader Class Initialized
INFO - 2021-06-18 03:50:53 --> Helper loaded: url_helper
INFO - 2021-06-18 03:50:53 --> Helper loaded: file_helper
INFO - 2021-06-18 03:50:53 --> Helper loaded: form_helper
INFO - 2021-06-18 03:50:53 --> Helper loaded: my_helper
INFO - 2021-06-18 03:50:53 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:50:53 --> Controller Class Initialized
DEBUG - 2021-06-18 03:50:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:50:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:50:53 --> Final output sent to browser
DEBUG - 2021-06-18 03:50:53 --> Total execution time: 0.0508
INFO - 2021-06-18 03:51:08 --> Config Class Initialized
INFO - 2021-06-18 03:51:08 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:51:08 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:51:08 --> Utf8 Class Initialized
INFO - 2021-06-18 03:51:08 --> URI Class Initialized
INFO - 2021-06-18 03:51:08 --> Router Class Initialized
INFO - 2021-06-18 03:51:08 --> Output Class Initialized
INFO - 2021-06-18 03:51:08 --> Security Class Initialized
DEBUG - 2021-06-18 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:51:08 --> Input Class Initialized
INFO - 2021-06-18 03:51:08 --> Language Class Initialized
INFO - 2021-06-18 03:51:08 --> Language Class Initialized
INFO - 2021-06-18 03:51:08 --> Config Class Initialized
INFO - 2021-06-18 03:51:08 --> Loader Class Initialized
INFO - 2021-06-18 03:51:08 --> Helper loaded: url_helper
INFO - 2021-06-18 03:51:08 --> Helper loaded: file_helper
INFO - 2021-06-18 03:51:08 --> Helper loaded: form_helper
INFO - 2021-06-18 03:51:08 --> Helper loaded: my_helper
INFO - 2021-06-18 03:51:08 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:51:08 --> Controller Class Initialized
INFO - 2021-06-18 03:51:08 --> Final output sent to browser
DEBUG - 2021-06-18 03:51:08 --> Total execution time: 0.0397
INFO - 2021-06-18 03:51:49 --> Config Class Initialized
INFO - 2021-06-18 03:51:49 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:51:49 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:51:49 --> Utf8 Class Initialized
INFO - 2021-06-18 03:51:49 --> URI Class Initialized
INFO - 2021-06-18 03:51:49 --> Router Class Initialized
INFO - 2021-06-18 03:51:49 --> Output Class Initialized
INFO - 2021-06-18 03:51:49 --> Security Class Initialized
DEBUG - 2021-06-18 03:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:51:49 --> Input Class Initialized
INFO - 2021-06-18 03:51:49 --> Language Class Initialized
INFO - 2021-06-18 03:51:49 --> Language Class Initialized
INFO - 2021-06-18 03:51:49 --> Config Class Initialized
INFO - 2021-06-18 03:51:49 --> Loader Class Initialized
INFO - 2021-06-18 03:51:49 --> Helper loaded: url_helper
INFO - 2021-06-18 03:51:49 --> Helper loaded: file_helper
INFO - 2021-06-18 03:51:49 --> Helper loaded: form_helper
INFO - 2021-06-18 03:51:49 --> Helper loaded: my_helper
INFO - 2021-06-18 03:51:49 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:51:49 --> Controller Class Initialized
INFO - 2021-06-18 03:51:49 --> Final output sent to browser
DEBUG - 2021-06-18 03:51:49 --> Total execution time: 0.0481
INFO - 2021-06-18 03:51:49 --> Config Class Initialized
INFO - 2021-06-18 03:51:49 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:51:49 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:51:49 --> Utf8 Class Initialized
INFO - 2021-06-18 03:51:49 --> URI Class Initialized
INFO - 2021-06-18 03:51:49 --> Router Class Initialized
INFO - 2021-06-18 03:51:49 --> Output Class Initialized
INFO - 2021-06-18 03:51:49 --> Security Class Initialized
DEBUG - 2021-06-18 03:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:51:49 --> Input Class Initialized
INFO - 2021-06-18 03:51:49 --> Language Class Initialized
INFO - 2021-06-18 03:51:49 --> Language Class Initialized
INFO - 2021-06-18 03:51:49 --> Config Class Initialized
INFO - 2021-06-18 03:51:49 --> Loader Class Initialized
INFO - 2021-06-18 03:51:49 --> Helper loaded: url_helper
INFO - 2021-06-18 03:51:49 --> Helper loaded: file_helper
INFO - 2021-06-18 03:51:49 --> Helper loaded: form_helper
INFO - 2021-06-18 03:51:49 --> Helper loaded: my_helper
INFO - 2021-06-18 03:51:49 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:51:49 --> Controller Class Initialized
DEBUG - 2021-06-18 03:51:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:51:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:51:49 --> Final output sent to browser
DEBUG - 2021-06-18 03:51:49 --> Total execution time: 0.0408
INFO - 2021-06-18 03:52:43 --> Config Class Initialized
INFO - 2021-06-18 03:52:43 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:52:43 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:52:43 --> Utf8 Class Initialized
INFO - 2021-06-18 03:52:43 --> URI Class Initialized
INFO - 2021-06-18 03:52:43 --> Router Class Initialized
INFO - 2021-06-18 03:52:43 --> Output Class Initialized
INFO - 2021-06-18 03:52:43 --> Security Class Initialized
DEBUG - 2021-06-18 03:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:52:43 --> Input Class Initialized
INFO - 2021-06-18 03:52:43 --> Language Class Initialized
INFO - 2021-06-18 03:52:43 --> Language Class Initialized
INFO - 2021-06-18 03:52:43 --> Config Class Initialized
INFO - 2021-06-18 03:52:43 --> Loader Class Initialized
INFO - 2021-06-18 03:52:43 --> Helper loaded: url_helper
INFO - 2021-06-18 03:52:43 --> Helper loaded: file_helper
INFO - 2021-06-18 03:52:43 --> Helper loaded: form_helper
INFO - 2021-06-18 03:52:43 --> Helper loaded: my_helper
INFO - 2021-06-18 03:52:43 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:52:43 --> Controller Class Initialized
INFO - 2021-06-18 03:52:43 --> Final output sent to browser
DEBUG - 2021-06-18 03:52:43 --> Total execution time: 0.0465
INFO - 2021-06-18 03:54:11 --> Config Class Initialized
INFO - 2021-06-18 03:54:11 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:54:11 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:54:11 --> Utf8 Class Initialized
INFO - 2021-06-18 03:54:11 --> URI Class Initialized
INFO - 2021-06-18 03:54:11 --> Router Class Initialized
INFO - 2021-06-18 03:54:11 --> Output Class Initialized
INFO - 2021-06-18 03:54:11 --> Security Class Initialized
DEBUG - 2021-06-18 03:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:54:11 --> Input Class Initialized
INFO - 2021-06-18 03:54:11 --> Language Class Initialized
INFO - 2021-06-18 03:54:11 --> Language Class Initialized
INFO - 2021-06-18 03:54:11 --> Config Class Initialized
INFO - 2021-06-18 03:54:11 --> Loader Class Initialized
INFO - 2021-06-18 03:54:11 --> Helper loaded: url_helper
INFO - 2021-06-18 03:54:11 --> Helper loaded: file_helper
INFO - 2021-06-18 03:54:11 --> Helper loaded: form_helper
INFO - 2021-06-18 03:54:11 --> Helper loaded: my_helper
INFO - 2021-06-18 03:54:11 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:54:11 --> Controller Class Initialized
INFO - 2021-06-18 03:54:11 --> Final output sent to browser
DEBUG - 2021-06-18 03:54:11 --> Total execution time: 0.0484
INFO - 2021-06-18 03:54:11 --> Config Class Initialized
INFO - 2021-06-18 03:54:11 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:54:11 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:54:11 --> Utf8 Class Initialized
INFO - 2021-06-18 03:54:11 --> URI Class Initialized
INFO - 2021-06-18 03:54:11 --> Router Class Initialized
INFO - 2021-06-18 03:54:11 --> Output Class Initialized
INFO - 2021-06-18 03:54:11 --> Security Class Initialized
DEBUG - 2021-06-18 03:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:54:11 --> Input Class Initialized
INFO - 2021-06-18 03:54:11 --> Language Class Initialized
INFO - 2021-06-18 03:54:11 --> Language Class Initialized
INFO - 2021-06-18 03:54:11 --> Config Class Initialized
INFO - 2021-06-18 03:54:11 --> Loader Class Initialized
INFO - 2021-06-18 03:54:11 --> Helper loaded: url_helper
INFO - 2021-06-18 03:54:11 --> Helper loaded: file_helper
INFO - 2021-06-18 03:54:11 --> Helper loaded: form_helper
INFO - 2021-06-18 03:54:11 --> Helper loaded: my_helper
INFO - 2021-06-18 03:54:11 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:54:11 --> Controller Class Initialized
DEBUG - 2021-06-18 03:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:54:11 --> Final output sent to browser
DEBUG - 2021-06-18 03:54:11 --> Total execution time: 0.0506
INFO - 2021-06-18 03:54:31 --> Config Class Initialized
INFO - 2021-06-18 03:54:31 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:54:31 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:54:31 --> Utf8 Class Initialized
INFO - 2021-06-18 03:54:31 --> URI Class Initialized
INFO - 2021-06-18 03:54:31 --> Router Class Initialized
INFO - 2021-06-18 03:54:31 --> Output Class Initialized
INFO - 2021-06-18 03:54:31 --> Security Class Initialized
DEBUG - 2021-06-18 03:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:54:31 --> Input Class Initialized
INFO - 2021-06-18 03:54:31 --> Language Class Initialized
INFO - 2021-06-18 03:54:31 --> Language Class Initialized
INFO - 2021-06-18 03:54:31 --> Config Class Initialized
INFO - 2021-06-18 03:54:31 --> Loader Class Initialized
INFO - 2021-06-18 03:54:31 --> Helper loaded: url_helper
INFO - 2021-06-18 03:54:31 --> Helper loaded: file_helper
INFO - 2021-06-18 03:54:31 --> Helper loaded: form_helper
INFO - 2021-06-18 03:54:31 --> Helper loaded: my_helper
INFO - 2021-06-18 03:54:31 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:54:31 --> Controller Class Initialized
INFO - 2021-06-18 03:54:31 --> Final output sent to browser
DEBUG - 2021-06-18 03:54:31 --> Total execution time: 0.0465
INFO - 2021-06-18 03:55:00 --> Config Class Initialized
INFO - 2021-06-18 03:55:00 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:55:00 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:55:00 --> Utf8 Class Initialized
INFO - 2021-06-18 03:55:00 --> URI Class Initialized
INFO - 2021-06-18 03:55:00 --> Router Class Initialized
INFO - 2021-06-18 03:55:00 --> Output Class Initialized
INFO - 2021-06-18 03:55:00 --> Security Class Initialized
DEBUG - 2021-06-18 03:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:55:00 --> Input Class Initialized
INFO - 2021-06-18 03:55:00 --> Language Class Initialized
INFO - 2021-06-18 03:55:00 --> Language Class Initialized
INFO - 2021-06-18 03:55:00 --> Config Class Initialized
INFO - 2021-06-18 03:55:00 --> Loader Class Initialized
INFO - 2021-06-18 03:55:00 --> Helper loaded: url_helper
INFO - 2021-06-18 03:55:00 --> Helper loaded: file_helper
INFO - 2021-06-18 03:55:00 --> Helper loaded: form_helper
INFO - 2021-06-18 03:55:00 --> Helper loaded: my_helper
INFO - 2021-06-18 03:55:00 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:55:00 --> Controller Class Initialized
INFO - 2021-06-18 03:55:00 --> Final output sent to browser
DEBUG - 2021-06-18 03:55:00 --> Total execution time: 0.0400
INFO - 2021-06-18 03:55:01 --> Config Class Initialized
INFO - 2021-06-18 03:55:01 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:55:01 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:55:01 --> Utf8 Class Initialized
INFO - 2021-06-18 03:55:01 --> URI Class Initialized
INFO - 2021-06-18 03:55:01 --> Router Class Initialized
INFO - 2021-06-18 03:55:01 --> Output Class Initialized
INFO - 2021-06-18 03:55:01 --> Security Class Initialized
DEBUG - 2021-06-18 03:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:55:01 --> Input Class Initialized
INFO - 2021-06-18 03:55:01 --> Language Class Initialized
INFO - 2021-06-18 03:55:01 --> Language Class Initialized
INFO - 2021-06-18 03:55:01 --> Config Class Initialized
INFO - 2021-06-18 03:55:01 --> Loader Class Initialized
INFO - 2021-06-18 03:55:01 --> Helper loaded: url_helper
INFO - 2021-06-18 03:55:01 --> Helper loaded: file_helper
INFO - 2021-06-18 03:55:01 --> Helper loaded: form_helper
INFO - 2021-06-18 03:55:01 --> Helper loaded: my_helper
INFO - 2021-06-18 03:55:01 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:55:01 --> Controller Class Initialized
DEBUG - 2021-06-18 03:55:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:55:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:55:01 --> Final output sent to browser
DEBUG - 2021-06-18 03:55:01 --> Total execution time: 0.0417
INFO - 2021-06-18 03:55:14 --> Config Class Initialized
INFO - 2021-06-18 03:55:14 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:55:14 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:55:14 --> Utf8 Class Initialized
INFO - 2021-06-18 03:55:14 --> URI Class Initialized
INFO - 2021-06-18 03:55:14 --> Router Class Initialized
INFO - 2021-06-18 03:55:14 --> Output Class Initialized
INFO - 2021-06-18 03:55:14 --> Security Class Initialized
DEBUG - 2021-06-18 03:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:55:14 --> Input Class Initialized
INFO - 2021-06-18 03:55:14 --> Language Class Initialized
INFO - 2021-06-18 03:55:14 --> Language Class Initialized
INFO - 2021-06-18 03:55:14 --> Config Class Initialized
INFO - 2021-06-18 03:55:14 --> Loader Class Initialized
INFO - 2021-06-18 03:55:14 --> Helper loaded: url_helper
INFO - 2021-06-18 03:55:14 --> Helper loaded: file_helper
INFO - 2021-06-18 03:55:14 --> Helper loaded: form_helper
INFO - 2021-06-18 03:55:14 --> Helper loaded: my_helper
INFO - 2021-06-18 03:55:14 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:55:14 --> Controller Class Initialized
INFO - 2021-06-18 03:55:14 --> Final output sent to browser
DEBUG - 2021-06-18 03:55:14 --> Total execution time: 0.0474
INFO - 2021-06-18 03:55:46 --> Config Class Initialized
INFO - 2021-06-18 03:55:46 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:55:46 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:55:46 --> Utf8 Class Initialized
INFO - 2021-06-18 03:55:46 --> URI Class Initialized
INFO - 2021-06-18 03:55:46 --> Router Class Initialized
INFO - 2021-06-18 03:55:46 --> Output Class Initialized
INFO - 2021-06-18 03:55:46 --> Security Class Initialized
DEBUG - 2021-06-18 03:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:55:46 --> Input Class Initialized
INFO - 2021-06-18 03:55:46 --> Language Class Initialized
INFO - 2021-06-18 03:55:46 --> Language Class Initialized
INFO - 2021-06-18 03:55:46 --> Config Class Initialized
INFO - 2021-06-18 03:55:46 --> Loader Class Initialized
INFO - 2021-06-18 03:55:46 --> Helper loaded: url_helper
INFO - 2021-06-18 03:55:46 --> Helper loaded: file_helper
INFO - 2021-06-18 03:55:46 --> Helper loaded: form_helper
INFO - 2021-06-18 03:55:46 --> Helper loaded: my_helper
INFO - 2021-06-18 03:55:46 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:55:46 --> Controller Class Initialized
INFO - 2021-06-18 03:55:46 --> Final output sent to browser
DEBUG - 2021-06-18 03:55:46 --> Total execution time: 0.0409
INFO - 2021-06-18 03:55:47 --> Config Class Initialized
INFO - 2021-06-18 03:55:47 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:55:47 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:55:47 --> Utf8 Class Initialized
INFO - 2021-06-18 03:55:47 --> URI Class Initialized
INFO - 2021-06-18 03:55:47 --> Router Class Initialized
INFO - 2021-06-18 03:55:47 --> Output Class Initialized
INFO - 2021-06-18 03:55:47 --> Security Class Initialized
DEBUG - 2021-06-18 03:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:55:47 --> Input Class Initialized
INFO - 2021-06-18 03:55:47 --> Language Class Initialized
INFO - 2021-06-18 03:55:47 --> Language Class Initialized
INFO - 2021-06-18 03:55:47 --> Config Class Initialized
INFO - 2021-06-18 03:55:47 --> Loader Class Initialized
INFO - 2021-06-18 03:55:47 --> Helper loaded: url_helper
INFO - 2021-06-18 03:55:47 --> Helper loaded: file_helper
INFO - 2021-06-18 03:55:47 --> Helper loaded: form_helper
INFO - 2021-06-18 03:55:47 --> Helper loaded: my_helper
INFO - 2021-06-18 03:55:47 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:55:47 --> Controller Class Initialized
DEBUG - 2021-06-18 03:55:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:55:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:55:47 --> Final output sent to browser
DEBUG - 2021-06-18 03:55:47 --> Total execution time: 0.0421
INFO - 2021-06-18 03:56:24 --> Config Class Initialized
INFO - 2021-06-18 03:56:24 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:56:24 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:56:24 --> Utf8 Class Initialized
INFO - 2021-06-18 03:56:24 --> URI Class Initialized
INFO - 2021-06-18 03:56:24 --> Router Class Initialized
INFO - 2021-06-18 03:56:24 --> Output Class Initialized
INFO - 2021-06-18 03:56:24 --> Security Class Initialized
DEBUG - 2021-06-18 03:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:56:24 --> Input Class Initialized
INFO - 2021-06-18 03:56:24 --> Language Class Initialized
INFO - 2021-06-18 03:56:24 --> Language Class Initialized
INFO - 2021-06-18 03:56:24 --> Config Class Initialized
INFO - 2021-06-18 03:56:24 --> Loader Class Initialized
INFO - 2021-06-18 03:56:24 --> Helper loaded: url_helper
INFO - 2021-06-18 03:56:24 --> Helper loaded: file_helper
INFO - 2021-06-18 03:56:24 --> Helper loaded: form_helper
INFO - 2021-06-18 03:56:24 --> Helper loaded: my_helper
INFO - 2021-06-18 03:56:24 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:56:24 --> Controller Class Initialized
INFO - 2021-06-18 03:56:24 --> Final output sent to browser
DEBUG - 2021-06-18 03:56:24 --> Total execution time: 0.0380
INFO - 2021-06-18 03:56:32 --> Config Class Initialized
INFO - 2021-06-18 03:56:32 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:56:32 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:56:32 --> Utf8 Class Initialized
INFO - 2021-06-18 03:56:32 --> URI Class Initialized
INFO - 2021-06-18 03:56:32 --> Router Class Initialized
INFO - 2021-06-18 03:56:32 --> Output Class Initialized
INFO - 2021-06-18 03:56:32 --> Security Class Initialized
DEBUG - 2021-06-18 03:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:56:32 --> Input Class Initialized
INFO - 2021-06-18 03:56:32 --> Language Class Initialized
INFO - 2021-06-18 03:56:32 --> Language Class Initialized
INFO - 2021-06-18 03:56:32 --> Config Class Initialized
INFO - 2021-06-18 03:56:32 --> Loader Class Initialized
INFO - 2021-06-18 03:56:32 --> Helper loaded: url_helper
INFO - 2021-06-18 03:56:32 --> Helper loaded: file_helper
INFO - 2021-06-18 03:56:32 --> Helper loaded: form_helper
INFO - 2021-06-18 03:56:32 --> Helper loaded: my_helper
INFO - 2021-06-18 03:56:32 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:56:32 --> Controller Class Initialized
INFO - 2021-06-18 03:56:32 --> Final output sent to browser
DEBUG - 2021-06-18 03:56:32 --> Total execution time: 0.0472
INFO - 2021-06-18 03:56:38 --> Config Class Initialized
INFO - 2021-06-18 03:56:38 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:56:38 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:56:38 --> Utf8 Class Initialized
INFO - 2021-06-18 03:56:38 --> URI Class Initialized
INFO - 2021-06-18 03:56:38 --> Router Class Initialized
INFO - 2021-06-18 03:56:38 --> Output Class Initialized
INFO - 2021-06-18 03:56:38 --> Security Class Initialized
DEBUG - 2021-06-18 03:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:56:38 --> Input Class Initialized
INFO - 2021-06-18 03:56:38 --> Language Class Initialized
INFO - 2021-06-18 03:56:38 --> Language Class Initialized
INFO - 2021-06-18 03:56:38 --> Config Class Initialized
INFO - 2021-06-18 03:56:38 --> Loader Class Initialized
INFO - 2021-06-18 03:56:38 --> Helper loaded: url_helper
INFO - 2021-06-18 03:56:38 --> Helper loaded: file_helper
INFO - 2021-06-18 03:56:38 --> Helper loaded: form_helper
INFO - 2021-06-18 03:56:38 --> Helper loaded: my_helper
INFO - 2021-06-18 03:56:38 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:56:38 --> Controller Class Initialized
INFO - 2021-06-18 03:56:38 --> Final output sent to browser
DEBUG - 2021-06-18 03:56:38 --> Total execution time: 0.0486
INFO - 2021-06-18 03:56:38 --> Config Class Initialized
INFO - 2021-06-18 03:56:38 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:56:38 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:56:38 --> Utf8 Class Initialized
INFO - 2021-06-18 03:56:38 --> URI Class Initialized
INFO - 2021-06-18 03:56:38 --> Router Class Initialized
INFO - 2021-06-18 03:56:38 --> Output Class Initialized
INFO - 2021-06-18 03:56:38 --> Security Class Initialized
DEBUG - 2021-06-18 03:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:56:38 --> Input Class Initialized
INFO - 2021-06-18 03:56:38 --> Language Class Initialized
INFO - 2021-06-18 03:56:38 --> Language Class Initialized
INFO - 2021-06-18 03:56:38 --> Config Class Initialized
INFO - 2021-06-18 03:56:38 --> Loader Class Initialized
INFO - 2021-06-18 03:56:38 --> Helper loaded: url_helper
INFO - 2021-06-18 03:56:38 --> Helper loaded: file_helper
INFO - 2021-06-18 03:56:38 --> Helper loaded: form_helper
INFO - 2021-06-18 03:56:38 --> Helper loaded: my_helper
INFO - 2021-06-18 03:56:38 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:56:38 --> Controller Class Initialized
DEBUG - 2021-06-18 03:56:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:56:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:56:38 --> Final output sent to browser
DEBUG - 2021-06-18 03:56:38 --> Total execution time: 0.0505
INFO - 2021-06-18 03:57:00 --> Config Class Initialized
INFO - 2021-06-18 03:57:00 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:57:00 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:57:00 --> Utf8 Class Initialized
INFO - 2021-06-18 03:57:00 --> URI Class Initialized
INFO - 2021-06-18 03:57:00 --> Router Class Initialized
INFO - 2021-06-18 03:57:00 --> Output Class Initialized
INFO - 2021-06-18 03:57:00 --> Security Class Initialized
DEBUG - 2021-06-18 03:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:57:00 --> Input Class Initialized
INFO - 2021-06-18 03:57:00 --> Language Class Initialized
INFO - 2021-06-18 03:57:00 --> Language Class Initialized
INFO - 2021-06-18 03:57:00 --> Config Class Initialized
INFO - 2021-06-18 03:57:00 --> Loader Class Initialized
INFO - 2021-06-18 03:57:00 --> Helper loaded: url_helper
INFO - 2021-06-18 03:57:00 --> Helper loaded: file_helper
INFO - 2021-06-18 03:57:00 --> Helper loaded: form_helper
INFO - 2021-06-18 03:57:00 --> Helper loaded: my_helper
INFO - 2021-06-18 03:57:00 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:57:00 --> Controller Class Initialized
INFO - 2021-06-18 03:57:00 --> Final output sent to browser
DEBUG - 2021-06-18 03:57:00 --> Total execution time: 0.0380
INFO - 2021-06-18 03:57:06 --> Config Class Initialized
INFO - 2021-06-18 03:57:06 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:57:06 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:57:06 --> Utf8 Class Initialized
INFO - 2021-06-18 03:57:06 --> URI Class Initialized
INFO - 2021-06-18 03:57:06 --> Router Class Initialized
INFO - 2021-06-18 03:57:06 --> Output Class Initialized
INFO - 2021-06-18 03:57:06 --> Security Class Initialized
DEBUG - 2021-06-18 03:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:57:06 --> Input Class Initialized
INFO - 2021-06-18 03:57:06 --> Language Class Initialized
INFO - 2021-06-18 03:57:06 --> Language Class Initialized
INFO - 2021-06-18 03:57:06 --> Config Class Initialized
INFO - 2021-06-18 03:57:06 --> Loader Class Initialized
INFO - 2021-06-18 03:57:06 --> Helper loaded: url_helper
INFO - 2021-06-18 03:57:06 --> Helper loaded: file_helper
INFO - 2021-06-18 03:57:06 --> Helper loaded: form_helper
INFO - 2021-06-18 03:57:06 --> Helper loaded: my_helper
INFO - 2021-06-18 03:57:06 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:57:06 --> Controller Class Initialized
INFO - 2021-06-18 03:57:06 --> Final output sent to browser
DEBUG - 2021-06-18 03:57:06 --> Total execution time: 0.0486
INFO - 2021-06-18 03:57:06 --> Config Class Initialized
INFO - 2021-06-18 03:57:06 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:57:06 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:57:06 --> Utf8 Class Initialized
INFO - 2021-06-18 03:57:06 --> URI Class Initialized
INFO - 2021-06-18 03:57:06 --> Router Class Initialized
INFO - 2021-06-18 03:57:06 --> Output Class Initialized
INFO - 2021-06-18 03:57:06 --> Security Class Initialized
DEBUG - 2021-06-18 03:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:57:06 --> Input Class Initialized
INFO - 2021-06-18 03:57:06 --> Language Class Initialized
INFO - 2021-06-18 03:57:06 --> Language Class Initialized
INFO - 2021-06-18 03:57:06 --> Config Class Initialized
INFO - 2021-06-18 03:57:06 --> Loader Class Initialized
INFO - 2021-06-18 03:57:06 --> Helper loaded: url_helper
INFO - 2021-06-18 03:57:06 --> Helper loaded: file_helper
INFO - 2021-06-18 03:57:06 --> Helper loaded: form_helper
INFO - 2021-06-18 03:57:06 --> Helper loaded: my_helper
INFO - 2021-06-18 03:57:06 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:57:06 --> Controller Class Initialized
DEBUG - 2021-06-18 03:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:57:06 --> Final output sent to browser
DEBUG - 2021-06-18 03:57:06 --> Total execution time: 0.0495
INFO - 2021-06-18 03:58:13 --> Config Class Initialized
INFO - 2021-06-18 03:58:13 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:58:13 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:58:13 --> Utf8 Class Initialized
INFO - 2021-06-18 03:58:13 --> URI Class Initialized
INFO - 2021-06-18 03:58:13 --> Router Class Initialized
INFO - 2021-06-18 03:58:13 --> Output Class Initialized
INFO - 2021-06-18 03:58:13 --> Security Class Initialized
DEBUG - 2021-06-18 03:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:58:13 --> Input Class Initialized
INFO - 2021-06-18 03:58:13 --> Language Class Initialized
INFO - 2021-06-18 03:58:13 --> Language Class Initialized
INFO - 2021-06-18 03:58:13 --> Config Class Initialized
INFO - 2021-06-18 03:58:13 --> Loader Class Initialized
INFO - 2021-06-18 03:58:13 --> Helper loaded: url_helper
INFO - 2021-06-18 03:58:13 --> Helper loaded: file_helper
INFO - 2021-06-18 03:58:13 --> Helper loaded: form_helper
INFO - 2021-06-18 03:58:13 --> Helper loaded: my_helper
INFO - 2021-06-18 03:58:13 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:58:13 --> Controller Class Initialized
DEBUG - 2021-06-18 03:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-18 03:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:58:13 --> Final output sent to browser
DEBUG - 2021-06-18 03:58:13 --> Total execution time: 0.0496
INFO - 2021-06-18 03:58:14 --> Config Class Initialized
INFO - 2021-06-18 03:58:14 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:58:14 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:58:14 --> Utf8 Class Initialized
INFO - 2021-06-18 03:58:14 --> URI Class Initialized
INFO - 2021-06-18 03:58:14 --> Router Class Initialized
INFO - 2021-06-18 03:58:14 --> Output Class Initialized
INFO - 2021-06-18 03:58:14 --> Security Class Initialized
DEBUG - 2021-06-18 03:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:58:14 --> Input Class Initialized
INFO - 2021-06-18 03:58:14 --> Language Class Initialized
INFO - 2021-06-18 03:58:14 --> Language Class Initialized
INFO - 2021-06-18 03:58:14 --> Config Class Initialized
INFO - 2021-06-18 03:58:14 --> Loader Class Initialized
INFO - 2021-06-18 03:58:14 --> Helper loaded: url_helper
INFO - 2021-06-18 03:58:14 --> Helper loaded: file_helper
INFO - 2021-06-18 03:58:14 --> Helper loaded: form_helper
INFO - 2021-06-18 03:58:14 --> Helper loaded: my_helper
INFO - 2021-06-18 03:58:14 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:58:14 --> Controller Class Initialized
DEBUG - 2021-06-18 03:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 03:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 03:58:14 --> Final output sent to browser
DEBUG - 2021-06-18 03:58:14 --> Total execution time: 0.0495
INFO - 2021-06-18 03:58:18 --> Config Class Initialized
INFO - 2021-06-18 03:58:18 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:58:18 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:58:18 --> Utf8 Class Initialized
INFO - 2021-06-18 03:58:18 --> URI Class Initialized
INFO - 2021-06-18 03:58:18 --> Router Class Initialized
INFO - 2021-06-18 03:58:18 --> Output Class Initialized
INFO - 2021-06-18 03:58:18 --> Security Class Initialized
DEBUG - 2021-06-18 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:58:18 --> Input Class Initialized
INFO - 2021-06-18 03:58:18 --> Language Class Initialized
INFO - 2021-06-18 03:58:18 --> Language Class Initialized
INFO - 2021-06-18 03:58:18 --> Config Class Initialized
INFO - 2021-06-18 03:58:18 --> Loader Class Initialized
INFO - 2021-06-18 03:58:18 --> Helper loaded: url_helper
INFO - 2021-06-18 03:58:18 --> Helper loaded: file_helper
INFO - 2021-06-18 03:58:18 --> Helper loaded: form_helper
INFO - 2021-06-18 03:58:18 --> Helper loaded: my_helper
INFO - 2021-06-18 03:58:18 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:58:18 --> Controller Class Initialized
INFO - 2021-06-18 03:58:25 --> Config Class Initialized
INFO - 2021-06-18 03:58:25 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:58:25 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:58:25 --> Utf8 Class Initialized
INFO - 2021-06-18 03:58:25 --> URI Class Initialized
INFO - 2021-06-18 03:58:25 --> Router Class Initialized
INFO - 2021-06-18 03:58:25 --> Output Class Initialized
INFO - 2021-06-18 03:58:25 --> Security Class Initialized
DEBUG - 2021-06-18 03:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:58:25 --> Input Class Initialized
INFO - 2021-06-18 03:58:25 --> Language Class Initialized
INFO - 2021-06-18 03:58:25 --> Language Class Initialized
INFO - 2021-06-18 03:58:25 --> Config Class Initialized
INFO - 2021-06-18 03:58:25 --> Loader Class Initialized
INFO - 2021-06-18 03:58:25 --> Helper loaded: url_helper
INFO - 2021-06-18 03:58:25 --> Helper loaded: file_helper
INFO - 2021-06-18 03:58:25 --> Helper loaded: form_helper
INFO - 2021-06-18 03:58:25 --> Helper loaded: my_helper
INFO - 2021-06-18 03:58:25 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:58:25 --> Controller Class Initialized
INFO - 2021-06-18 03:58:26 --> Config Class Initialized
INFO - 2021-06-18 03:58:26 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:58:26 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:58:26 --> Utf8 Class Initialized
INFO - 2021-06-18 03:58:26 --> URI Class Initialized
INFO - 2021-06-18 03:58:26 --> Router Class Initialized
INFO - 2021-06-18 03:58:26 --> Output Class Initialized
INFO - 2021-06-18 03:58:26 --> Security Class Initialized
DEBUG - 2021-06-18 03:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:58:26 --> Input Class Initialized
INFO - 2021-06-18 03:58:26 --> Language Class Initialized
INFO - 2021-06-18 03:58:26 --> Language Class Initialized
INFO - 2021-06-18 03:58:26 --> Config Class Initialized
INFO - 2021-06-18 03:58:26 --> Loader Class Initialized
INFO - 2021-06-18 03:58:26 --> Helper loaded: url_helper
INFO - 2021-06-18 03:58:26 --> Helper loaded: file_helper
INFO - 2021-06-18 03:58:26 --> Helper loaded: form_helper
INFO - 2021-06-18 03:58:26 --> Helper loaded: my_helper
INFO - 2021-06-18 03:58:26 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:58:26 --> Controller Class Initialized
INFO - 2021-06-18 03:58:31 --> Config Class Initialized
INFO - 2021-06-18 03:58:31 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:58:31 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:58:31 --> Utf8 Class Initialized
INFO - 2021-06-18 03:58:31 --> URI Class Initialized
INFO - 2021-06-18 03:58:31 --> Router Class Initialized
INFO - 2021-06-18 03:58:31 --> Output Class Initialized
INFO - 2021-06-18 03:58:31 --> Security Class Initialized
DEBUG - 2021-06-18 03:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:58:31 --> Input Class Initialized
INFO - 2021-06-18 03:58:31 --> Language Class Initialized
INFO - 2021-06-18 03:58:31 --> Language Class Initialized
INFO - 2021-06-18 03:58:31 --> Config Class Initialized
INFO - 2021-06-18 03:58:31 --> Loader Class Initialized
INFO - 2021-06-18 03:58:31 --> Helper loaded: url_helper
INFO - 2021-06-18 03:58:31 --> Helper loaded: file_helper
INFO - 2021-06-18 03:58:31 --> Helper loaded: form_helper
INFO - 2021-06-18 03:58:31 --> Helper loaded: my_helper
INFO - 2021-06-18 03:58:31 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:58:31 --> Controller Class Initialized
INFO - 2021-06-18 03:58:39 --> Config Class Initialized
INFO - 2021-06-18 03:58:39 --> Hooks Class Initialized
DEBUG - 2021-06-18 03:58:39 --> UTF-8 Support Enabled
INFO - 2021-06-18 03:58:39 --> Utf8 Class Initialized
INFO - 2021-06-18 03:58:39 --> URI Class Initialized
INFO - 2021-06-18 03:58:39 --> Router Class Initialized
INFO - 2021-06-18 03:58:39 --> Output Class Initialized
INFO - 2021-06-18 03:58:39 --> Security Class Initialized
DEBUG - 2021-06-18 03:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 03:58:39 --> Input Class Initialized
INFO - 2021-06-18 03:58:39 --> Language Class Initialized
INFO - 2021-06-18 03:58:39 --> Language Class Initialized
INFO - 2021-06-18 03:58:39 --> Config Class Initialized
INFO - 2021-06-18 03:58:39 --> Loader Class Initialized
INFO - 2021-06-18 03:58:39 --> Helper loaded: url_helper
INFO - 2021-06-18 03:58:39 --> Helper loaded: file_helper
INFO - 2021-06-18 03:58:39 --> Helper loaded: form_helper
INFO - 2021-06-18 03:58:39 --> Helper loaded: my_helper
INFO - 2021-06-18 03:58:39 --> Database Driver Class Initialized
DEBUG - 2021-06-18 03:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 03:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 03:58:39 --> Controller Class Initialized
INFO - 2021-06-18 04:01:01 --> Config Class Initialized
INFO - 2021-06-18 04:01:01 --> Hooks Class Initialized
DEBUG - 2021-06-18 04:01:01 --> UTF-8 Support Enabled
INFO - 2021-06-18 04:01:01 --> Utf8 Class Initialized
INFO - 2021-06-18 04:01:01 --> URI Class Initialized
INFO - 2021-06-18 04:01:01 --> Router Class Initialized
INFO - 2021-06-18 04:01:01 --> Output Class Initialized
INFO - 2021-06-18 04:01:01 --> Security Class Initialized
DEBUG - 2021-06-18 04:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 04:01:01 --> Input Class Initialized
INFO - 2021-06-18 04:01:01 --> Language Class Initialized
INFO - 2021-06-18 04:01:01 --> Language Class Initialized
INFO - 2021-06-18 04:01:01 --> Config Class Initialized
INFO - 2021-06-18 04:01:01 --> Loader Class Initialized
INFO - 2021-06-18 04:01:01 --> Helper loaded: url_helper
INFO - 2021-06-18 04:01:01 --> Helper loaded: file_helper
INFO - 2021-06-18 04:01:01 --> Helper loaded: form_helper
INFO - 2021-06-18 04:01:01 --> Helper loaded: my_helper
INFO - 2021-06-18 04:01:01 --> Database Driver Class Initialized
DEBUG - 2021-06-18 04:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 04:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 04:01:01 --> Controller Class Initialized
DEBUG - 2021-06-18 04:01:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-18 04:01:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 04:01:01 --> Final output sent to browser
DEBUG - 2021-06-18 04:01:01 --> Total execution time: 0.0529
INFO - 2021-06-18 04:01:13 --> Config Class Initialized
INFO - 2021-06-18 04:01:13 --> Hooks Class Initialized
DEBUG - 2021-06-18 04:01:13 --> UTF-8 Support Enabled
INFO - 2021-06-18 04:01:13 --> Utf8 Class Initialized
INFO - 2021-06-18 04:01:13 --> URI Class Initialized
INFO - 2021-06-18 04:01:13 --> Router Class Initialized
INFO - 2021-06-18 04:01:13 --> Output Class Initialized
INFO - 2021-06-18 04:01:13 --> Security Class Initialized
DEBUG - 2021-06-18 04:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 04:01:13 --> Input Class Initialized
INFO - 2021-06-18 04:01:13 --> Language Class Initialized
INFO - 2021-06-18 04:01:13 --> Language Class Initialized
INFO - 2021-06-18 04:01:13 --> Config Class Initialized
INFO - 2021-06-18 04:01:13 --> Loader Class Initialized
INFO - 2021-06-18 04:01:13 --> Helper loaded: url_helper
INFO - 2021-06-18 04:01:13 --> Helper loaded: file_helper
INFO - 2021-06-18 04:01:13 --> Helper loaded: form_helper
INFO - 2021-06-18 04:01:13 --> Helper loaded: my_helper
INFO - 2021-06-18 04:01:13 --> Database Driver Class Initialized
DEBUG - 2021-06-18 04:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 04:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 04:01:13 --> Controller Class Initialized
INFO - 2021-06-18 04:01:20 --> Config Class Initialized
INFO - 2021-06-18 04:01:20 --> Hooks Class Initialized
DEBUG - 2021-06-18 04:01:20 --> UTF-8 Support Enabled
INFO - 2021-06-18 04:01:20 --> Utf8 Class Initialized
INFO - 2021-06-18 04:01:20 --> URI Class Initialized
INFO - 2021-06-18 04:01:20 --> Router Class Initialized
INFO - 2021-06-18 04:01:20 --> Output Class Initialized
INFO - 2021-06-18 04:01:20 --> Security Class Initialized
DEBUG - 2021-06-18 04:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 04:01:20 --> Input Class Initialized
INFO - 2021-06-18 04:01:20 --> Language Class Initialized
INFO - 2021-06-18 04:01:20 --> Language Class Initialized
INFO - 2021-06-18 04:01:20 --> Config Class Initialized
INFO - 2021-06-18 04:01:20 --> Loader Class Initialized
INFO - 2021-06-18 04:01:20 --> Helper loaded: url_helper
INFO - 2021-06-18 04:01:20 --> Helper loaded: file_helper
INFO - 2021-06-18 04:01:20 --> Helper loaded: form_helper
INFO - 2021-06-18 04:01:20 --> Helper loaded: my_helper
INFO - 2021-06-18 04:01:20 --> Database Driver Class Initialized
DEBUG - 2021-06-18 04:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 04:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 04:01:20 --> Controller Class Initialized
INFO - 2021-06-18 04:01:20 --> Helper loaded: cookie_helper
INFO - 2021-06-18 04:01:20 --> Config Class Initialized
INFO - 2021-06-18 04:01:20 --> Hooks Class Initialized
DEBUG - 2021-06-18 04:01:20 --> UTF-8 Support Enabled
INFO - 2021-06-18 04:01:20 --> Utf8 Class Initialized
INFO - 2021-06-18 04:01:20 --> URI Class Initialized
INFO - 2021-06-18 04:01:20 --> Router Class Initialized
INFO - 2021-06-18 04:01:20 --> Output Class Initialized
INFO - 2021-06-18 04:01:20 --> Security Class Initialized
DEBUG - 2021-06-18 04:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 04:01:20 --> Input Class Initialized
INFO - 2021-06-18 04:01:20 --> Language Class Initialized
INFO - 2021-06-18 04:01:20 --> Language Class Initialized
INFO - 2021-06-18 04:01:20 --> Config Class Initialized
INFO - 2021-06-18 04:01:20 --> Loader Class Initialized
INFO - 2021-06-18 04:01:20 --> Helper loaded: url_helper
INFO - 2021-06-18 04:01:20 --> Helper loaded: file_helper
INFO - 2021-06-18 04:01:20 --> Helper loaded: form_helper
INFO - 2021-06-18 04:01:20 --> Helper loaded: my_helper
INFO - 2021-06-18 04:01:20 --> Database Driver Class Initialized
DEBUG - 2021-06-18 04:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 04:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 04:01:20 --> Controller Class Initialized
DEBUG - 2021-06-18 04:01:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-18 04:01:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 04:01:20 --> Final output sent to browser
DEBUG - 2021-06-18 04:01:20 --> Total execution time: 0.0489
INFO - 2021-06-18 05:06:41 --> Config Class Initialized
INFO - 2021-06-18 05:06:41 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:06:41 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:06:41 --> Utf8 Class Initialized
INFO - 2021-06-18 05:06:41 --> URI Class Initialized
INFO - 2021-06-18 05:06:41 --> Router Class Initialized
INFO - 2021-06-18 05:06:41 --> Output Class Initialized
INFO - 2021-06-18 05:06:41 --> Security Class Initialized
DEBUG - 2021-06-18 05:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:06:41 --> Input Class Initialized
INFO - 2021-06-18 05:06:41 --> Language Class Initialized
INFO - 2021-06-18 05:06:41 --> Language Class Initialized
INFO - 2021-06-18 05:06:41 --> Config Class Initialized
INFO - 2021-06-18 05:06:41 --> Loader Class Initialized
INFO - 2021-06-18 05:06:41 --> Helper loaded: url_helper
INFO - 2021-06-18 05:06:41 --> Helper loaded: file_helper
INFO - 2021-06-18 05:06:41 --> Helper loaded: form_helper
INFO - 2021-06-18 05:06:41 --> Helper loaded: my_helper
INFO - 2021-06-18 05:06:41 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:06:41 --> Controller Class Initialized
INFO - 2021-06-18 05:06:41 --> Helper loaded: cookie_helper
INFO - 2021-06-18 05:06:41 --> Config Class Initialized
INFO - 2021-06-18 05:06:41 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:06:41 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:06:41 --> Utf8 Class Initialized
INFO - 2021-06-18 05:06:41 --> URI Class Initialized
INFO - 2021-06-18 05:06:41 --> Router Class Initialized
INFO - 2021-06-18 05:06:41 --> Output Class Initialized
INFO - 2021-06-18 05:06:41 --> Security Class Initialized
DEBUG - 2021-06-18 05:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:06:41 --> Input Class Initialized
INFO - 2021-06-18 05:06:41 --> Language Class Initialized
INFO - 2021-06-18 05:06:41 --> Language Class Initialized
INFO - 2021-06-18 05:06:41 --> Config Class Initialized
INFO - 2021-06-18 05:06:41 --> Loader Class Initialized
INFO - 2021-06-18 05:06:41 --> Helper loaded: url_helper
INFO - 2021-06-18 05:06:41 --> Helper loaded: file_helper
INFO - 2021-06-18 05:06:41 --> Helper loaded: form_helper
INFO - 2021-06-18 05:06:41 --> Helper loaded: my_helper
INFO - 2021-06-18 05:06:41 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:06:41 --> Controller Class Initialized
DEBUG - 2021-06-18 05:06:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-18 05:06:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 05:06:41 --> Final output sent to browser
DEBUG - 2021-06-18 05:06:41 --> Total execution time: 0.0413
INFO - 2021-06-18 05:06:46 --> Config Class Initialized
INFO - 2021-06-18 05:06:46 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:06:46 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:06:46 --> Utf8 Class Initialized
INFO - 2021-06-18 05:06:46 --> URI Class Initialized
INFO - 2021-06-18 05:06:46 --> Router Class Initialized
INFO - 2021-06-18 05:06:46 --> Output Class Initialized
INFO - 2021-06-18 05:06:46 --> Security Class Initialized
DEBUG - 2021-06-18 05:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:06:46 --> Input Class Initialized
INFO - 2021-06-18 05:06:46 --> Language Class Initialized
INFO - 2021-06-18 05:06:46 --> Language Class Initialized
INFO - 2021-06-18 05:06:46 --> Config Class Initialized
INFO - 2021-06-18 05:06:46 --> Loader Class Initialized
INFO - 2021-06-18 05:06:46 --> Helper loaded: url_helper
INFO - 2021-06-18 05:06:46 --> Helper loaded: file_helper
INFO - 2021-06-18 05:06:46 --> Helper loaded: form_helper
INFO - 2021-06-18 05:06:46 --> Helper loaded: my_helper
INFO - 2021-06-18 05:06:46 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:06:46 --> Controller Class Initialized
INFO - 2021-06-18 05:06:46 --> Helper loaded: cookie_helper
INFO - 2021-06-18 05:06:46 --> Final output sent to browser
DEBUG - 2021-06-18 05:06:46 --> Total execution time: 0.0520
INFO - 2021-06-18 05:06:46 --> Config Class Initialized
INFO - 2021-06-18 05:06:46 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:06:46 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:06:46 --> Utf8 Class Initialized
INFO - 2021-06-18 05:06:46 --> URI Class Initialized
INFO - 2021-06-18 05:06:46 --> Router Class Initialized
INFO - 2021-06-18 05:06:46 --> Output Class Initialized
INFO - 2021-06-18 05:06:46 --> Security Class Initialized
DEBUG - 2021-06-18 05:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:06:46 --> Input Class Initialized
INFO - 2021-06-18 05:06:46 --> Language Class Initialized
INFO - 2021-06-18 05:06:46 --> Language Class Initialized
INFO - 2021-06-18 05:06:46 --> Config Class Initialized
INFO - 2021-06-18 05:06:46 --> Loader Class Initialized
INFO - 2021-06-18 05:06:46 --> Helper loaded: url_helper
INFO - 2021-06-18 05:06:46 --> Helper loaded: file_helper
INFO - 2021-06-18 05:06:46 --> Helper loaded: form_helper
INFO - 2021-06-18 05:06:46 --> Helper loaded: my_helper
INFO - 2021-06-18 05:06:46 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:06:46 --> Controller Class Initialized
DEBUG - 2021-06-18 05:06:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-18 05:06:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 05:06:46 --> Final output sent to browser
DEBUG - 2021-06-18 05:06:46 --> Total execution time: 0.1997
INFO - 2021-06-18 05:07:28 --> Config Class Initialized
INFO - 2021-06-18 05:07:28 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:07:28 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:07:28 --> Utf8 Class Initialized
INFO - 2021-06-18 05:07:28 --> URI Class Initialized
INFO - 2021-06-18 05:07:28 --> Router Class Initialized
INFO - 2021-06-18 05:07:28 --> Output Class Initialized
INFO - 2021-06-18 05:07:28 --> Security Class Initialized
DEBUG - 2021-06-18 05:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:07:28 --> Input Class Initialized
INFO - 2021-06-18 05:07:28 --> Language Class Initialized
INFO - 2021-06-18 05:07:28 --> Language Class Initialized
INFO - 2021-06-18 05:07:28 --> Config Class Initialized
INFO - 2021-06-18 05:07:28 --> Loader Class Initialized
INFO - 2021-06-18 05:07:28 --> Helper loaded: url_helper
INFO - 2021-06-18 05:07:28 --> Helper loaded: file_helper
INFO - 2021-06-18 05:07:28 --> Helper loaded: form_helper
INFO - 2021-06-18 05:07:28 --> Helper loaded: my_helper
INFO - 2021-06-18 05:07:28 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:07:28 --> Controller Class Initialized
DEBUG - 2021-06-18 05:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-18 05:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 05:07:28 --> Final output sent to browser
DEBUG - 2021-06-18 05:07:28 --> Total execution time: 0.0517
INFO - 2021-06-18 05:07:31 --> Config Class Initialized
INFO - 2021-06-18 05:07:31 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:07:31 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:07:31 --> Utf8 Class Initialized
INFO - 2021-06-18 05:07:31 --> URI Class Initialized
INFO - 2021-06-18 05:07:31 --> Router Class Initialized
INFO - 2021-06-18 05:07:31 --> Output Class Initialized
INFO - 2021-06-18 05:07:31 --> Security Class Initialized
DEBUG - 2021-06-18 05:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:07:31 --> Input Class Initialized
INFO - 2021-06-18 05:07:31 --> Language Class Initialized
INFO - 2021-06-18 05:07:31 --> Language Class Initialized
INFO - 2021-06-18 05:07:31 --> Config Class Initialized
INFO - 2021-06-18 05:07:31 --> Loader Class Initialized
INFO - 2021-06-18 05:07:31 --> Helper loaded: url_helper
INFO - 2021-06-18 05:07:31 --> Helper loaded: file_helper
INFO - 2021-06-18 05:07:31 --> Helper loaded: form_helper
INFO - 2021-06-18 05:07:31 --> Helper loaded: my_helper
INFO - 2021-06-18 05:07:31 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:07:31 --> Controller Class Initialized
DEBUG - 2021-06-18 05:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-18 05:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 05:07:31 --> Final output sent to browser
DEBUG - 2021-06-18 05:07:31 --> Total execution time: 0.0472
INFO - 2021-06-18 05:07:31 --> Config Class Initialized
INFO - 2021-06-18 05:07:31 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:07:31 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:07:31 --> Utf8 Class Initialized
INFO - 2021-06-18 05:07:31 --> URI Class Initialized
INFO - 2021-06-18 05:07:31 --> Router Class Initialized
INFO - 2021-06-18 05:07:31 --> Output Class Initialized
INFO - 2021-06-18 05:07:31 --> Security Class Initialized
DEBUG - 2021-06-18 05:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:07:31 --> Input Class Initialized
INFO - 2021-06-18 05:07:31 --> Language Class Initialized
INFO - 2021-06-18 05:07:31 --> Language Class Initialized
INFO - 2021-06-18 05:07:31 --> Config Class Initialized
INFO - 2021-06-18 05:07:31 --> Loader Class Initialized
INFO - 2021-06-18 05:07:31 --> Helper loaded: url_helper
INFO - 2021-06-18 05:07:31 --> Helper loaded: file_helper
INFO - 2021-06-18 05:07:31 --> Helper loaded: form_helper
INFO - 2021-06-18 05:07:31 --> Helper loaded: my_helper
INFO - 2021-06-18 05:07:31 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:07:31 --> Controller Class Initialized
INFO - 2021-06-18 05:07:33 --> Config Class Initialized
INFO - 2021-06-18 05:07:33 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:07:33 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:07:33 --> Utf8 Class Initialized
INFO - 2021-06-18 05:07:33 --> URI Class Initialized
INFO - 2021-06-18 05:07:33 --> Router Class Initialized
INFO - 2021-06-18 05:07:33 --> Output Class Initialized
INFO - 2021-06-18 05:07:33 --> Security Class Initialized
DEBUG - 2021-06-18 05:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:07:33 --> Input Class Initialized
INFO - 2021-06-18 05:07:33 --> Language Class Initialized
INFO - 2021-06-18 05:07:33 --> Language Class Initialized
INFO - 2021-06-18 05:07:33 --> Config Class Initialized
INFO - 2021-06-18 05:07:33 --> Loader Class Initialized
INFO - 2021-06-18 05:07:33 --> Helper loaded: url_helper
INFO - 2021-06-18 05:07:33 --> Helper loaded: file_helper
INFO - 2021-06-18 05:07:33 --> Helper loaded: form_helper
INFO - 2021-06-18 05:07:33 --> Helper loaded: my_helper
INFO - 2021-06-18 05:07:33 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:07:33 --> Controller Class Initialized
DEBUG - 2021-06-18 05:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 05:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 05:07:33 --> Final output sent to browser
DEBUG - 2021-06-18 05:07:33 --> Total execution time: 0.0484
INFO - 2021-06-18 05:07:52 --> Config Class Initialized
INFO - 2021-06-18 05:07:52 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:07:52 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:07:52 --> Utf8 Class Initialized
INFO - 2021-06-18 05:07:52 --> URI Class Initialized
INFO - 2021-06-18 05:07:52 --> Router Class Initialized
INFO - 2021-06-18 05:07:52 --> Output Class Initialized
INFO - 2021-06-18 05:07:52 --> Security Class Initialized
DEBUG - 2021-06-18 05:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:07:52 --> Input Class Initialized
INFO - 2021-06-18 05:07:52 --> Language Class Initialized
INFO - 2021-06-18 05:07:52 --> Language Class Initialized
INFO - 2021-06-18 05:07:52 --> Config Class Initialized
INFO - 2021-06-18 05:07:52 --> Loader Class Initialized
INFO - 2021-06-18 05:07:52 --> Helper loaded: url_helper
INFO - 2021-06-18 05:07:52 --> Helper loaded: file_helper
INFO - 2021-06-18 05:07:52 --> Helper loaded: form_helper
INFO - 2021-06-18 05:07:52 --> Helper loaded: my_helper
INFO - 2021-06-18 05:07:52 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:07:52 --> Controller Class Initialized
INFO - 2021-06-18 05:07:54 --> Config Class Initialized
INFO - 2021-06-18 05:07:54 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:07:54 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:07:54 --> Utf8 Class Initialized
INFO - 2021-06-18 05:07:54 --> URI Class Initialized
INFO - 2021-06-18 05:07:54 --> Router Class Initialized
INFO - 2021-06-18 05:07:54 --> Output Class Initialized
INFO - 2021-06-18 05:07:54 --> Security Class Initialized
DEBUG - 2021-06-18 05:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:07:54 --> Input Class Initialized
INFO - 2021-06-18 05:07:54 --> Language Class Initialized
INFO - 2021-06-18 05:07:54 --> Language Class Initialized
INFO - 2021-06-18 05:07:54 --> Config Class Initialized
INFO - 2021-06-18 05:07:54 --> Loader Class Initialized
INFO - 2021-06-18 05:07:54 --> Helper loaded: url_helper
INFO - 2021-06-18 05:07:54 --> Helper loaded: file_helper
INFO - 2021-06-18 05:07:54 --> Helper loaded: form_helper
INFO - 2021-06-18 05:07:54 --> Helper loaded: my_helper
INFO - 2021-06-18 05:07:54 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:07:54 --> Controller Class Initialized
INFO - 2021-06-18 05:08:27 --> Config Class Initialized
INFO - 2021-06-18 05:08:27 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:08:27 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:08:27 --> Utf8 Class Initialized
INFO - 2021-06-18 05:08:27 --> URI Class Initialized
INFO - 2021-06-18 05:08:27 --> Router Class Initialized
INFO - 2021-06-18 05:08:27 --> Output Class Initialized
INFO - 2021-06-18 05:08:27 --> Security Class Initialized
DEBUG - 2021-06-18 05:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:08:27 --> Input Class Initialized
INFO - 2021-06-18 05:08:27 --> Language Class Initialized
INFO - 2021-06-18 05:08:27 --> Language Class Initialized
INFO - 2021-06-18 05:08:27 --> Config Class Initialized
INFO - 2021-06-18 05:08:27 --> Loader Class Initialized
INFO - 2021-06-18 05:08:27 --> Helper loaded: url_helper
INFO - 2021-06-18 05:08:27 --> Helper loaded: file_helper
INFO - 2021-06-18 05:08:27 --> Helper loaded: form_helper
INFO - 2021-06-18 05:08:27 --> Helper loaded: my_helper
INFO - 2021-06-18 05:08:27 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:08:27 --> Controller Class Initialized
DEBUG - 2021-06-18 05:08:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-18 05:08:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 05:08:27 --> Final output sent to browser
DEBUG - 2021-06-18 05:08:27 --> Total execution time: 0.0455
INFO - 2021-06-18 05:08:27 --> Config Class Initialized
INFO - 2021-06-18 05:08:27 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:08:27 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:08:27 --> Utf8 Class Initialized
INFO - 2021-06-18 05:08:27 --> URI Class Initialized
INFO - 2021-06-18 05:08:27 --> Router Class Initialized
INFO - 2021-06-18 05:08:27 --> Output Class Initialized
INFO - 2021-06-18 05:08:27 --> Security Class Initialized
DEBUG - 2021-06-18 05:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:08:27 --> Input Class Initialized
INFO - 2021-06-18 05:08:27 --> Language Class Initialized
INFO - 2021-06-18 05:08:27 --> Language Class Initialized
INFO - 2021-06-18 05:08:27 --> Config Class Initialized
INFO - 2021-06-18 05:08:27 --> Loader Class Initialized
INFO - 2021-06-18 05:08:27 --> Helper loaded: url_helper
INFO - 2021-06-18 05:08:27 --> Helper loaded: file_helper
INFO - 2021-06-18 05:08:27 --> Helper loaded: form_helper
INFO - 2021-06-18 05:08:27 --> Helper loaded: my_helper
INFO - 2021-06-18 05:08:27 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:08:27 --> Controller Class Initialized
INFO - 2021-06-18 05:08:29 --> Config Class Initialized
INFO - 2021-06-18 05:08:29 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:08:29 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:08:29 --> Utf8 Class Initialized
INFO - 2021-06-18 05:08:29 --> URI Class Initialized
INFO - 2021-06-18 05:08:29 --> Router Class Initialized
INFO - 2021-06-18 05:08:29 --> Output Class Initialized
INFO - 2021-06-18 05:08:29 --> Security Class Initialized
DEBUG - 2021-06-18 05:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:08:29 --> Input Class Initialized
INFO - 2021-06-18 05:08:29 --> Language Class Initialized
INFO - 2021-06-18 05:08:29 --> Language Class Initialized
INFO - 2021-06-18 05:08:29 --> Config Class Initialized
INFO - 2021-06-18 05:08:29 --> Loader Class Initialized
INFO - 2021-06-18 05:08:29 --> Helper loaded: url_helper
INFO - 2021-06-18 05:08:29 --> Helper loaded: file_helper
INFO - 2021-06-18 05:08:29 --> Helper loaded: form_helper
INFO - 2021-06-18 05:08:29 --> Helper loaded: my_helper
INFO - 2021-06-18 05:08:29 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:08:29 --> Controller Class Initialized
DEBUG - 2021-06-18 05:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-18 05:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 05:08:29 --> Final output sent to browser
DEBUG - 2021-06-18 05:08:29 --> Total execution time: 0.0466
INFO - 2021-06-18 05:08:32 --> Config Class Initialized
INFO - 2021-06-18 05:08:32 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:08:32 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:08:32 --> Utf8 Class Initialized
INFO - 2021-06-18 05:08:32 --> URI Class Initialized
INFO - 2021-06-18 05:08:32 --> Router Class Initialized
INFO - 2021-06-18 05:08:32 --> Output Class Initialized
INFO - 2021-06-18 05:08:32 --> Security Class Initialized
DEBUG - 2021-06-18 05:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:08:32 --> Input Class Initialized
INFO - 2021-06-18 05:08:32 --> Language Class Initialized
INFO - 2021-06-18 05:08:32 --> Language Class Initialized
INFO - 2021-06-18 05:08:32 --> Config Class Initialized
INFO - 2021-06-18 05:08:32 --> Loader Class Initialized
INFO - 2021-06-18 05:08:32 --> Helper loaded: url_helper
INFO - 2021-06-18 05:08:32 --> Helper loaded: file_helper
INFO - 2021-06-18 05:08:32 --> Helper loaded: form_helper
INFO - 2021-06-18 05:08:32 --> Helper loaded: my_helper
INFO - 2021-06-18 05:08:32 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:08:32 --> Controller Class Initialized
INFO - 2021-06-18 05:08:33 --> Config Class Initialized
INFO - 2021-06-18 05:08:33 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:08:33 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:08:33 --> Utf8 Class Initialized
INFO - 2021-06-18 05:08:33 --> URI Class Initialized
INFO - 2021-06-18 05:08:33 --> Router Class Initialized
INFO - 2021-06-18 05:08:33 --> Output Class Initialized
INFO - 2021-06-18 05:08:33 --> Security Class Initialized
DEBUG - 2021-06-18 05:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:08:33 --> Input Class Initialized
INFO - 2021-06-18 05:08:33 --> Language Class Initialized
INFO - 2021-06-18 05:08:33 --> Language Class Initialized
INFO - 2021-06-18 05:08:33 --> Config Class Initialized
INFO - 2021-06-18 05:08:33 --> Loader Class Initialized
INFO - 2021-06-18 05:08:33 --> Helper loaded: url_helper
INFO - 2021-06-18 05:08:33 --> Helper loaded: file_helper
INFO - 2021-06-18 05:08:33 --> Helper loaded: form_helper
INFO - 2021-06-18 05:08:33 --> Helper loaded: my_helper
INFO - 2021-06-18 05:08:33 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:08:33 --> Controller Class Initialized
INFO - 2021-06-18 05:11:12 --> Config Class Initialized
INFO - 2021-06-18 05:11:12 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:11:12 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:11:12 --> Utf8 Class Initialized
INFO - 2021-06-18 05:11:12 --> URI Class Initialized
INFO - 2021-06-18 05:11:12 --> Router Class Initialized
INFO - 2021-06-18 05:11:12 --> Output Class Initialized
INFO - 2021-06-18 05:11:12 --> Security Class Initialized
DEBUG - 2021-06-18 05:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:11:12 --> Input Class Initialized
INFO - 2021-06-18 05:11:12 --> Language Class Initialized
INFO - 2021-06-18 05:11:12 --> Language Class Initialized
INFO - 2021-06-18 05:11:12 --> Config Class Initialized
INFO - 2021-06-18 05:11:12 --> Loader Class Initialized
INFO - 2021-06-18 05:11:12 --> Helper loaded: url_helper
INFO - 2021-06-18 05:11:12 --> Helper loaded: file_helper
INFO - 2021-06-18 05:11:12 --> Helper loaded: form_helper
INFO - 2021-06-18 05:11:12 --> Helper loaded: my_helper
INFO - 2021-06-18 05:11:12 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:11:12 --> Controller Class Initialized
INFO - 2021-06-18 05:11:12 --> Helper loaded: cookie_helper
INFO - 2021-06-18 05:11:12 --> Config Class Initialized
INFO - 2021-06-18 05:11:12 --> Hooks Class Initialized
DEBUG - 2021-06-18 05:11:12 --> UTF-8 Support Enabled
INFO - 2021-06-18 05:11:12 --> Utf8 Class Initialized
INFO - 2021-06-18 05:11:12 --> URI Class Initialized
INFO - 2021-06-18 05:11:12 --> Router Class Initialized
INFO - 2021-06-18 05:11:12 --> Output Class Initialized
INFO - 2021-06-18 05:11:12 --> Security Class Initialized
DEBUG - 2021-06-18 05:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 05:11:12 --> Input Class Initialized
INFO - 2021-06-18 05:11:12 --> Language Class Initialized
INFO - 2021-06-18 05:11:12 --> Language Class Initialized
INFO - 2021-06-18 05:11:12 --> Config Class Initialized
INFO - 2021-06-18 05:11:12 --> Loader Class Initialized
INFO - 2021-06-18 05:11:12 --> Helper loaded: url_helper
INFO - 2021-06-18 05:11:12 --> Helper loaded: file_helper
INFO - 2021-06-18 05:11:12 --> Helper loaded: form_helper
INFO - 2021-06-18 05:11:12 --> Helper loaded: my_helper
INFO - 2021-06-18 05:11:12 --> Database Driver Class Initialized
DEBUG - 2021-06-18 05:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 05:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 05:11:12 --> Controller Class Initialized
DEBUG - 2021-06-18 05:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-18 05:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-18 05:11:12 --> Final output sent to browser
DEBUG - 2021-06-18 05:11:12 --> Total execution time: 0.0499
