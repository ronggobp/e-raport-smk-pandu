<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-17 01:24:53 --> Config Class Initialized
INFO - 2020-12-17 01:24:53 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:24:53 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:24:53 --> Utf8 Class Initialized
INFO - 2020-12-17 01:24:53 --> URI Class Initialized
DEBUG - 2020-12-17 01:24:53 --> No URI present. Default controller set.
INFO - 2020-12-17 01:24:53 --> Router Class Initialized
INFO - 2020-12-17 01:24:53 --> Output Class Initialized
INFO - 2020-12-17 01:24:53 --> Security Class Initialized
DEBUG - 2020-12-17 01:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:24:53 --> Input Class Initialized
INFO - 2020-12-17 01:24:53 --> Language Class Initialized
INFO - 2020-12-17 01:24:53 --> Language Class Initialized
INFO - 2020-12-17 01:24:53 --> Config Class Initialized
INFO - 2020-12-17 01:24:53 --> Loader Class Initialized
INFO - 2020-12-17 01:24:53 --> Helper loaded: url_helper
INFO - 2020-12-17 01:24:53 --> Helper loaded: file_helper
INFO - 2020-12-17 01:24:53 --> Helper loaded: form_helper
INFO - 2020-12-17 01:24:53 --> Helper loaded: my_helper
INFO - 2020-12-17 01:24:53 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:24:53 --> Controller Class Initialized
INFO - 2020-12-17 01:24:53 --> Config Class Initialized
INFO - 2020-12-17 01:24:53 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:24:53 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:24:53 --> Utf8 Class Initialized
INFO - 2020-12-17 01:24:53 --> URI Class Initialized
INFO - 2020-12-17 01:24:53 --> Router Class Initialized
INFO - 2020-12-17 01:24:53 --> Output Class Initialized
INFO - 2020-12-17 01:24:53 --> Security Class Initialized
DEBUG - 2020-12-17 01:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:24:53 --> Input Class Initialized
INFO - 2020-12-17 01:24:53 --> Language Class Initialized
INFO - 2020-12-17 01:24:53 --> Language Class Initialized
INFO - 2020-12-17 01:24:53 --> Config Class Initialized
INFO - 2020-12-17 01:24:53 --> Loader Class Initialized
INFO - 2020-12-17 01:24:53 --> Helper loaded: url_helper
INFO - 2020-12-17 01:24:53 --> Helper loaded: file_helper
INFO - 2020-12-17 01:24:53 --> Helper loaded: form_helper
INFO - 2020-12-17 01:24:53 --> Helper loaded: my_helper
INFO - 2020-12-17 01:24:53 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:24:54 --> Controller Class Initialized
DEBUG - 2020-12-17 01:24:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-17 01:24:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-17 01:24:54 --> Final output sent to browser
DEBUG - 2020-12-17 01:24:54 --> Total execution time: 0.2866
INFO - 2020-12-17 01:25:24 --> Config Class Initialized
INFO - 2020-12-17 01:25:24 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:25:24 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:25:24 --> Utf8 Class Initialized
INFO - 2020-12-17 01:25:24 --> URI Class Initialized
INFO - 2020-12-17 01:25:24 --> Router Class Initialized
INFO - 2020-12-17 01:25:24 --> Output Class Initialized
INFO - 2020-12-17 01:25:24 --> Security Class Initialized
DEBUG - 2020-12-17 01:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:25:24 --> Input Class Initialized
INFO - 2020-12-17 01:25:24 --> Language Class Initialized
INFO - 2020-12-17 01:25:24 --> Language Class Initialized
INFO - 2020-12-17 01:25:24 --> Config Class Initialized
INFO - 2020-12-17 01:25:24 --> Loader Class Initialized
INFO - 2020-12-17 01:25:24 --> Helper loaded: url_helper
INFO - 2020-12-17 01:25:24 --> Helper loaded: file_helper
INFO - 2020-12-17 01:25:24 --> Helper loaded: form_helper
INFO - 2020-12-17 01:25:24 --> Helper loaded: my_helper
INFO - 2020-12-17 01:25:24 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:25:24 --> Controller Class Initialized
INFO - 2020-12-17 01:25:24 --> Helper loaded: cookie_helper
INFO - 2020-12-17 01:25:24 --> Final output sent to browser
DEBUG - 2020-12-17 01:25:24 --> Total execution time: 0.2064
INFO - 2020-12-17 01:25:28 --> Config Class Initialized
INFO - 2020-12-17 01:25:28 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:25:28 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:25:28 --> Utf8 Class Initialized
INFO - 2020-12-17 01:25:28 --> URI Class Initialized
INFO - 2020-12-17 01:25:28 --> Router Class Initialized
INFO - 2020-12-17 01:25:28 --> Output Class Initialized
INFO - 2020-12-17 01:25:28 --> Security Class Initialized
DEBUG - 2020-12-17 01:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:25:28 --> Input Class Initialized
INFO - 2020-12-17 01:25:28 --> Language Class Initialized
INFO - 2020-12-17 01:25:28 --> Language Class Initialized
INFO - 2020-12-17 01:25:28 --> Config Class Initialized
INFO - 2020-12-17 01:25:28 --> Loader Class Initialized
INFO - 2020-12-17 01:25:28 --> Helper loaded: url_helper
INFO - 2020-12-17 01:25:28 --> Helper loaded: file_helper
INFO - 2020-12-17 01:25:28 --> Helper loaded: form_helper
INFO - 2020-12-17 01:25:28 --> Helper loaded: my_helper
INFO - 2020-12-17 01:25:28 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:25:28 --> Controller Class Initialized
DEBUG - 2020-12-17 01:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-17 01:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-17 01:25:28 --> Final output sent to browser
DEBUG - 2020-12-17 01:25:28 --> Total execution time: 0.1851
INFO - 2020-12-17 01:43:15 --> Config Class Initialized
INFO - 2020-12-17 01:43:15 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:43:15 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:43:15 --> Utf8 Class Initialized
INFO - 2020-12-17 01:43:15 --> URI Class Initialized
INFO - 2020-12-17 01:43:15 --> Router Class Initialized
INFO - 2020-12-17 01:43:15 --> Output Class Initialized
INFO - 2020-12-17 01:43:15 --> Security Class Initialized
DEBUG - 2020-12-17 01:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:43:15 --> Input Class Initialized
INFO - 2020-12-17 01:43:15 --> Language Class Initialized
INFO - 2020-12-17 01:43:15 --> Language Class Initialized
INFO - 2020-12-17 01:43:15 --> Config Class Initialized
INFO - 2020-12-17 01:43:15 --> Loader Class Initialized
INFO - 2020-12-17 01:43:15 --> Helper loaded: url_helper
INFO - 2020-12-17 01:43:15 --> Helper loaded: file_helper
INFO - 2020-12-17 01:43:15 --> Helper loaded: form_helper
INFO - 2020-12-17 01:43:15 --> Helper loaded: my_helper
INFO - 2020-12-17 01:43:16 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:43:16 --> Controller Class Initialized
DEBUG - 2020-12-17 01:43:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-17 01:43:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-17 01:43:16 --> Final output sent to browser
DEBUG - 2020-12-17 01:43:16 --> Total execution time: 0.7003
INFO - 2020-12-17 01:43:17 --> Config Class Initialized
INFO - 2020-12-17 01:43:17 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:43:17 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:43:17 --> Utf8 Class Initialized
INFO - 2020-12-17 01:43:17 --> URI Class Initialized
INFO - 2020-12-17 01:43:17 --> Router Class Initialized
INFO - 2020-12-17 01:43:17 --> Output Class Initialized
INFO - 2020-12-17 01:43:17 --> Security Class Initialized
DEBUG - 2020-12-17 01:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:43:17 --> Input Class Initialized
INFO - 2020-12-17 01:43:17 --> Language Class Initialized
INFO - 2020-12-17 01:43:17 --> Language Class Initialized
INFO - 2020-12-17 01:43:17 --> Config Class Initialized
INFO - 2020-12-17 01:43:17 --> Loader Class Initialized
INFO - 2020-12-17 01:43:17 --> Helper loaded: url_helper
INFO - 2020-12-17 01:43:17 --> Helper loaded: file_helper
INFO - 2020-12-17 01:43:17 --> Helper loaded: form_helper
INFO - 2020-12-17 01:43:17 --> Helper loaded: my_helper
INFO - 2020-12-17 01:43:17 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:43:17 --> Controller Class Initialized
ERROR - 2020-12-17 01:43:17 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-17 01:43:50 --> Config Class Initialized
INFO - 2020-12-17 01:43:50 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:43:50 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:43:50 --> Utf8 Class Initialized
INFO - 2020-12-17 01:43:50 --> URI Class Initialized
INFO - 2020-12-17 01:43:50 --> Router Class Initialized
INFO - 2020-12-17 01:43:50 --> Output Class Initialized
INFO - 2020-12-17 01:43:50 --> Security Class Initialized
DEBUG - 2020-12-17 01:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:43:50 --> Input Class Initialized
INFO - 2020-12-17 01:43:50 --> Language Class Initialized
INFO - 2020-12-17 01:43:50 --> Language Class Initialized
INFO - 2020-12-17 01:43:50 --> Config Class Initialized
INFO - 2020-12-17 01:43:50 --> Loader Class Initialized
INFO - 2020-12-17 01:43:50 --> Helper loaded: url_helper
INFO - 2020-12-17 01:43:50 --> Helper loaded: file_helper
INFO - 2020-12-17 01:43:50 --> Helper loaded: form_helper
INFO - 2020-12-17 01:43:50 --> Helper loaded: my_helper
INFO - 2020-12-17 01:43:50 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:43:50 --> Controller Class Initialized
ERROR - 2020-12-17 01:43:50 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
INFO - 2020-12-17 01:48:29 --> Config Class Initialized
INFO - 2020-12-17 01:48:29 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:48:29 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:48:29 --> Utf8 Class Initialized
INFO - 2020-12-17 01:48:29 --> URI Class Initialized
INFO - 2020-12-17 01:48:29 --> Router Class Initialized
INFO - 2020-12-17 01:48:29 --> Output Class Initialized
INFO - 2020-12-17 01:48:29 --> Security Class Initialized
DEBUG - 2020-12-17 01:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:48:29 --> Input Class Initialized
INFO - 2020-12-17 01:48:29 --> Language Class Initialized
INFO - 2020-12-17 01:48:29 --> Language Class Initialized
INFO - 2020-12-17 01:48:29 --> Config Class Initialized
INFO - 2020-12-17 01:48:29 --> Loader Class Initialized
INFO - 2020-12-17 01:48:29 --> Helper loaded: url_helper
INFO - 2020-12-17 01:48:29 --> Helper loaded: file_helper
INFO - 2020-12-17 01:48:29 --> Helper loaded: form_helper
INFO - 2020-12-17 01:48:29 --> Helper loaded: my_helper
INFO - 2020-12-17 01:48:29 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:48:29 --> Controller Class Initialized
ERROR - 2020-12-17 01:48:29 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
INFO - 2020-12-17 01:49:10 --> Config Class Initialized
INFO - 2020-12-17 01:49:10 --> Hooks Class Initialized
DEBUG - 2020-12-17 01:49:10 --> UTF-8 Support Enabled
INFO - 2020-12-17 01:49:10 --> Utf8 Class Initialized
INFO - 2020-12-17 01:49:10 --> URI Class Initialized
INFO - 2020-12-17 01:49:10 --> Router Class Initialized
INFO - 2020-12-17 01:49:10 --> Output Class Initialized
INFO - 2020-12-17 01:49:10 --> Security Class Initialized
DEBUG - 2020-12-17 01:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 01:49:10 --> Input Class Initialized
INFO - 2020-12-17 01:49:10 --> Language Class Initialized
INFO - 2020-12-17 01:49:10 --> Language Class Initialized
INFO - 2020-12-17 01:49:10 --> Config Class Initialized
INFO - 2020-12-17 01:49:10 --> Loader Class Initialized
INFO - 2020-12-17 01:49:10 --> Helper loaded: url_helper
INFO - 2020-12-17 01:49:10 --> Helper loaded: file_helper
INFO - 2020-12-17 01:49:10 --> Helper loaded: form_helper
INFO - 2020-12-17 01:49:10 --> Helper loaded: my_helper
INFO - 2020-12-17 01:49:10 --> Database Driver Class Initialized
DEBUG - 2020-12-17 01:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 01:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 01:49:10 --> Controller Class Initialized
ERROR - 2020-12-17 01:49:10 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
INFO - 2020-12-17 04:28:40 --> Config Class Initialized
INFO - 2020-12-17 04:28:40 --> Hooks Class Initialized
DEBUG - 2020-12-17 04:28:40 --> UTF-8 Support Enabled
INFO - 2020-12-17 04:28:40 --> Utf8 Class Initialized
INFO - 2020-12-17 04:28:40 --> URI Class Initialized
INFO - 2020-12-17 04:28:40 --> Router Class Initialized
INFO - 2020-12-17 04:28:40 --> Output Class Initialized
INFO - 2020-12-17 04:28:40 --> Security Class Initialized
DEBUG - 2020-12-17 04:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 04:28:40 --> Input Class Initialized
INFO - 2020-12-17 04:28:40 --> Language Class Initialized
INFO - 2020-12-17 04:28:40 --> Language Class Initialized
INFO - 2020-12-17 04:28:40 --> Config Class Initialized
INFO - 2020-12-17 04:28:40 --> Loader Class Initialized
INFO - 2020-12-17 04:28:40 --> Helper loaded: url_helper
INFO - 2020-12-17 04:28:40 --> Helper loaded: file_helper
INFO - 2020-12-17 04:28:40 --> Helper loaded: form_helper
INFO - 2020-12-17 04:28:40 --> Helper loaded: my_helper
INFO - 2020-12-17 04:28:40 --> Database Driver Class Initialized
DEBUG - 2020-12-17 04:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 04:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 04:28:40 --> Controller Class Initialized
DEBUG - 2020-12-17 04:28:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-17 04:28:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-17 04:28:40 --> Final output sent to browser
DEBUG - 2020-12-17 04:28:40 --> Total execution time: 0.2051
INFO - 2020-12-17 04:28:42 --> Config Class Initialized
INFO - 2020-12-17 04:28:42 --> Hooks Class Initialized
DEBUG - 2020-12-17 04:28:42 --> UTF-8 Support Enabled
INFO - 2020-12-17 04:28:42 --> Utf8 Class Initialized
INFO - 2020-12-17 04:28:42 --> URI Class Initialized
INFO - 2020-12-17 04:28:42 --> Router Class Initialized
INFO - 2020-12-17 04:28:42 --> Output Class Initialized
INFO - 2020-12-17 04:28:42 --> Security Class Initialized
DEBUG - 2020-12-17 04:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 04:28:42 --> Input Class Initialized
INFO - 2020-12-17 04:28:42 --> Language Class Initialized
INFO - 2020-12-17 04:28:42 --> Language Class Initialized
INFO - 2020-12-17 04:28:42 --> Config Class Initialized
INFO - 2020-12-17 04:28:42 --> Loader Class Initialized
INFO - 2020-12-17 04:28:42 --> Helper loaded: url_helper
INFO - 2020-12-17 04:28:42 --> Helper loaded: file_helper
INFO - 2020-12-17 04:28:42 --> Helper loaded: form_helper
INFO - 2020-12-17 04:28:42 --> Helper loaded: my_helper
INFO - 2020-12-17 04:28:42 --> Database Driver Class Initialized
DEBUG - 2020-12-17 04:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 04:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 04:28:42 --> Controller Class Initialized
DEBUG - 2020-12-17 04:28:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-17 04:28:42 --> Final output sent to browser
DEBUG - 2020-12-17 04:28:42 --> Total execution time: 0.3588
INFO - 2020-12-17 05:27:59 --> Config Class Initialized
INFO - 2020-12-17 05:27:59 --> Hooks Class Initialized
DEBUG - 2020-12-17 05:27:59 --> UTF-8 Support Enabled
INFO - 2020-12-17 05:27:59 --> Utf8 Class Initialized
INFO - 2020-12-17 05:27:59 --> URI Class Initialized
INFO - 2020-12-17 05:27:59 --> Router Class Initialized
INFO - 2020-12-17 05:27:59 --> Output Class Initialized
INFO - 2020-12-17 05:27:59 --> Security Class Initialized
DEBUG - 2020-12-17 05:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 05:27:59 --> Input Class Initialized
INFO - 2020-12-17 05:27:59 --> Language Class Initialized
INFO - 2020-12-17 05:27:59 --> Language Class Initialized
INFO - 2020-12-17 05:27:59 --> Config Class Initialized
INFO - 2020-12-17 05:27:59 --> Loader Class Initialized
INFO - 2020-12-17 05:27:59 --> Helper loaded: url_helper
INFO - 2020-12-17 05:27:59 --> Helper loaded: file_helper
INFO - 2020-12-17 05:27:59 --> Helper loaded: form_helper
INFO - 2020-12-17 05:27:59 --> Helper loaded: my_helper
INFO - 2020-12-17 05:27:59 --> Database Driver Class Initialized
DEBUG - 2020-12-17 05:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 05:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 05:27:59 --> Controller Class Initialized
DEBUG - 2020-12-17 05:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-17 05:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-17 05:27:59 --> Final output sent to browser
DEBUG - 2020-12-17 05:27:59 --> Total execution time: 0.1860
INFO - 2020-12-17 09:12:11 --> Config Class Initialized
INFO - 2020-12-17 09:12:11 --> Hooks Class Initialized
DEBUG - 2020-12-17 09:12:11 --> UTF-8 Support Enabled
INFO - 2020-12-17 09:12:11 --> Utf8 Class Initialized
INFO - 2020-12-17 09:12:11 --> URI Class Initialized
INFO - 2020-12-17 09:12:12 --> Router Class Initialized
INFO - 2020-12-17 09:12:12 --> Output Class Initialized
INFO - 2020-12-17 09:12:12 --> Security Class Initialized
DEBUG - 2020-12-17 09:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 09:12:12 --> Input Class Initialized
INFO - 2020-12-17 09:12:12 --> Language Class Initialized
INFO - 2020-12-17 09:12:12 --> Language Class Initialized
INFO - 2020-12-17 09:12:12 --> Config Class Initialized
INFO - 2020-12-17 09:12:12 --> Loader Class Initialized
INFO - 2020-12-17 09:12:12 --> Helper loaded: url_helper
INFO - 2020-12-17 09:12:12 --> Helper loaded: file_helper
INFO - 2020-12-17 09:12:12 --> Helper loaded: form_helper
INFO - 2020-12-17 09:12:12 --> Helper loaded: my_helper
INFO - 2020-12-17 09:12:12 --> Database Driver Class Initialized
DEBUG - 2020-12-17 09:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 09:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 09:12:12 --> Controller Class Initialized
ERROR - 2020-12-17 09:12:12 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                    a.*, b.nama, a.integritas, a.religius, a.nasionalis, a.mandiri, a.gotong
                                                    FROM t_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-12-17 09:12:12 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-17 09:18:11 --> Config Class Initialized
INFO - 2020-12-17 09:18:11 --> Hooks Class Initialized
DEBUG - 2020-12-17 09:18:11 --> UTF-8 Support Enabled
INFO - 2020-12-17 09:18:11 --> Utf8 Class Initialized
INFO - 2020-12-17 09:18:11 --> URI Class Initialized
INFO - 2020-12-17 09:18:11 --> Router Class Initialized
INFO - 2020-12-17 09:18:11 --> Output Class Initialized
INFO - 2020-12-17 09:18:11 --> Security Class Initialized
DEBUG - 2020-12-17 09:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-17 09:18:11 --> Input Class Initialized
INFO - 2020-12-17 09:18:11 --> Language Class Initialized
INFO - 2020-12-17 09:18:11 --> Language Class Initialized
INFO - 2020-12-17 09:18:11 --> Config Class Initialized
INFO - 2020-12-17 09:18:11 --> Loader Class Initialized
INFO - 2020-12-17 09:18:11 --> Helper loaded: url_helper
INFO - 2020-12-17 09:18:11 --> Helper loaded: file_helper
INFO - 2020-12-17 09:18:11 --> Helper loaded: form_helper
INFO - 2020-12-17 09:18:11 --> Helper loaded: my_helper
INFO - 2020-12-17 09:18:11 --> Database Driver Class Initialized
DEBUG - 2020-12-17 09:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-17 09:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-17 09:18:11 --> Controller Class Initialized
ERROR - 2020-12-17 09:18:11 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                    a.*, b.nama, a.integritas, a.religius, a.nasionalis, a.mandiri, a.gotong
                                                    FROM t_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-12-17 09:18:11 --> Language file loaded: language/english/db_lang.php
